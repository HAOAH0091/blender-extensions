"""Test script for Cache Collector addon.

Run with: blender --background --python test_cache_collector.py
"""

import os
import sys
import tempfile
import json

# Path to our addon
ADDON_DIR = r"C:\Users\Administrator\AppData\Roaming\Blender Foundation\Blender\5.2\scripts\addons"
if ADDON_DIR not in sys.path:
    sys.path.insert(0, ADDON_DIR)

import bpy

# Ensure our addon is enabled
if "cache_collector" not in bpy.context.preferences.addons:
    bpy.ops.preferences.addon_enable(module="cache_collector")
print("Addon enabled")

from cache_collector import utils

# =============================================================
# Setup: create separate dirs for project and source files
# =============================================================
# Source files go to a location OUTSIDE the project directory so they're "external"
test_root = tempfile.mkdtemp(prefix="cache_collector_test_")
project_dir = os.path.join(test_root, "project")
source_dir = os.path.join(test_root, "source_cache")  # sibling, not nested
os.makedirs(project_dir, exist_ok=True)
os.makedirs(source_dir, exist_ok=True)

blend_path = os.path.join(project_dir, "test_project.blend")

# Create dummy cache files in source_dir (outside project)
dummy_abc = os.path.join(source_dir, "cloth_sim.abc")
dummy_usd = os.path.join(source_dir, "hair_sim.usdc")
dummy_layers = os.path.join(source_dir, "overlay.usd")
with open(dummy_abc, "w") as f: f.write("dummy abc")
with open(dummy_usd, "w") as f: f.write("dummy usd")
with open(dummy_layers, "w") as f: f.write("dummy layer")

# Create dummy sequence files
seq_dir = os.path.join(source_dir, "seq")
os.makedirs(seq_dir, exist_ok=True)
for i in range(1, 6):
    with open(os.path.join(seq_dir, f"cloth_sim_{i:04d}.abc"), "w") as f:
        f.write(f"dummy seq frame {i}")

# Save the blend file so bpy.data.filepath is set
bpy.ops.wm.save_as_mainfile(filepath=blend_path)
print(f"Test blend saved to: {blend_path}")
print(f"Source cache at: {source_dir}")

# =============================================================
# Test 1: Register CacheCollector data-blocks
# =============================================================
print("\n" + "=" * 60)
print("TEST 1: Create CacheFile data-blocks with external references")
print("=" * 60)

# Create CacheFiles via cachefile operator
bpy.ops.cachefile.open(filepath=dummy_abc, filter_alembic=True, relative_path=False)
cf1 = bpy.data.cache_files[-1]
cf1.name = "cloth_main"
print(f"  Created CacheFile: {cf1.name}, filepath={cf1.filepath}")

bpy.ops.cachefile.open(filepath=dummy_usd, filter_alembic=False, filter_usd=True, relative_path=False)
cf2 = bpy.data.cache_files[-1]
cf2.name = "hair_main"
# Add a layer
layer = cf2.layers.new(dummy_layers)
layer.filepath = dummy_layers
print(f"  Created CacheFile: {cf2.name}, filepath={cf2.filepath}")
print(f"    Layer 0: {layer.filepath}")

# =============================================================
# Test 2: Scan
# =============================================================
print("\n" + "=" * 60)
print("TEST 2: Scan cache entries")
print("=" * 60)

entries = utils.collect_cache_entries()
print(f"  Found {len(entries)} entries:")
for e in entries:
    print(f"    [{e.status}] {e.source:5s} | {os.path.basename(e.abs_path):30s} | dest: {e.cache_rel_path}")

# Verify
assert len(entries) == 3, f"Expected 3 entries, got {len(entries)}"
for e in entries:
    assert e.status == "external", f"Expected external, got {e.status}"
    assert e.cache_file is not None, "CacheFile should not be None"
print("  PASSED")

# =============================================================
# Test 3: Encode/Decode round-trip
# =============================================================
print("\n" + "=" * 60)
print("TEST 3: JSON encode/decode round-trip")
print("=" * 60)

json_str = utils.encode_entries_to_json(entries)
decoded = utils.decode_entries_from_json(json_str)
assert len(decoded) == len(entries), f"Loss during round-trip: {len(entries)} -> {len(decoded)}"
print(f"  {len(entries)} entries -> JSON ({len(json_str)} chars) -> {len(decoded)} entries")
print("  PASSED")

# =============================================================
# Test 4: Pack to cache
# =============================================================
print("\n" + "=" * 60)
print("TEST 4: Pack to cache/")
print("=" * 60)

blend_dir = os.path.dirname(bpy.data.filepath)
cache_dir = os.path.join(blend_dir, "cache")
external_entries = [e for e in entries if e.status == "external"]

results, abs_to_actual = utils.copy_to_cache(external_entries, cache_dir)
print(f"  Copy results:")
for k, v in results.items():
    print(f"    {os.path.basename(k):25s} -> {v}")

# Verify files exist in cache (using actual cache_rel_path from entries)
for e in entries:
    expected = os.path.join(cache_dir, e.cache_rel_path)
    assert os.path.exists(expected), f"{e.cache_rel_path} not in cache ({expected})"
    print(f"  Verified: {e.cache_rel_path}")

# Verify sequence files
for e in entries:
    if e.is_sequence:
        seq_entry = e
        break
else:
    seq_entry = None

if seq_entry:
    seq_dest = os.path.join(cache_dir, seq_entry.cache_rel_path)
    seq_dir_path = os.path.dirname(seq_dest)
    for i in range(1, 6):
        seq_file = os.path.join(seq_dir_path, f"cloth_sim_{i:04d}.abc")
        assert os.path.exists(seq_file), f"seq frame {i} not found at {seq_file}"

print("  All files correctly copied to cache/")
print("  PASSED")

# =============================================================
# Test 5: Update paths
# =============================================================
print("\n" + "=" * 60)
print("TEST 5: Update CacheFile paths")
print("=" * 60)

snapshot = utils.make_snapshot(entries)
snap_data = json.loads(snapshot)
print(f"  Snapshot captured {len(snap_data)} CacheFile records")

messages = utils.update_paths(external_entries, abs_to_actual)
for msg in messages:
    print(f"  {msg}")

# Verify paths were updated to //cache/... format
for cf_name in ("cloth_main", "hair_main"):
    cf = bpy.data.cache_files[cf_name]
    assert cf.filepath.startswith("//cache/"), f"{cf_name}.filepath not updated to //cache/ format: {cf.filepath}"
    print(f"  {cf_name}.filepath = {cf.filepath}")

# Verify layer path was updated
for layer in bpy.data.cache_files["hair_main"].layers:
    assert layer.filepath.startswith("//cache/"), f"Layer filepath not updated: {layer.filepath}"
    print(f"  hair_main.layer[0].filepath = {layer.filepath}")

print("  PASSED")

# =============================================================
# Test 6: Idempotency — paths are still cache-relative after Test 5
# =============================================================
print("\n" + "=" * 60)
print("TEST 6: Idempotency - Pack after paths are already cache-relative")
print("=" * 60)

# After paths were updated to //cache/..., re-scan should show them as internal
entries_after = utils.collect_cache_entries()
external_after = [e for e in entries_after if e.status == "external"]
internal_count = sum(1 for e in entries_after if e.status == "internal")
print(f"  After path update: {len(entries_after)} total, {external_after} external, {internal_count} internal")

# Re-pack with re-scanned entries (should be no-op)
results2, abs_to_actual2 = utils.copy_to_cache(external_after, cache_dir)
print(f"  Second pack results: {results2}")
assert len(external_after) == 0, f"All should be internal after packing, got {len(external_after)} external"
print("  PASSED - second pack is no-op (no external files found)")

# =============================================================
# Test 7: Snapshot and Restore
# =============================================================
print("\n" + "=" * 60)
print("TEST 7: Snapshot and Restore")
print("=" * 60)

# Restore
messages = utils.restore_from_snapshot(snapshot)
for msg in messages:
    print(f"  {msg}")

# Verify paths are restored
assert bpy.data.cache_files["cloth_main"].filepath == dummy_abc, \
    f"cloth_main not restored: {bpy.data.cache_files['cloth_main'].filepath}"
print(f"  cloth_main.filepath restored to: {bpy.data.cache_files['cloth_main'].filepath}")

assert bpy.data.cache_files["hair_main"].filepath == dummy_usd, \
    f"hair_main not restored: {bpy.data.cache_files['hair_main'].filepath}"
print(f"  hair_main.filepath restored to: {bpy.data.cache_files['hair_main'].filepath}")

print("  PASSED")

# =============================================================
# Test 8: Missing file handling
# =============================================================
print("\n" + "=" * 60)
print("TEST 8: Missing file detection")
print("=" * 60)

# Create a CacheFile pointing to a non-existent file
# We have to use the operator, but since the file doesn't exist,
# the operator will fail. Instead, manually rename an existing
# cache_file and change its path.
cf3 = bpy.data.cache_files[0].copy()
cf3.name = "missing_test"
cf3.filepath = os.path.join(source_dir, "nonexistent.abc")

entries2 = utils.collect_cache_entries()
for e in entries2:
    if "nonexistent" in e.abs_path:
        assert e.status == "missing", f"Non-existent file not marked missing: {e.status}"
        print(f"  Missing file detected: {os.path.basename(e.abs_path)} -> {e.status}")

# Note: CacheFile data-block persists in this test blend but will be
# cleaned up when the temp directory is deleted
print("  PASSED")

# =============================================================
# Cleanup
# =============================================================
print("\n" + "=" * 60)
print("ALL TESTS PASSED")
print("=" * 60)
print(f"\nTest artifacts at: {test_root}")

import shutil
shutil.rmtree(test_root, ignore_errors=True)
print("Temp directory cleaned up")
