bl_info = {
    "name": "Cache Collector",
    "author": "HAOAH",
    "version": (1, 0, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Cache Collector",
    "description": "Scan and pack Alembic/USD cache files into the project's cache/ folder",
    "category": "System",
    "support": "COMMUNITY",
}

import bpy


def register():
    if bpy.app.version < (5, 2, 0):
        raise ImportError("Cache Collector requires Blender 5.2 or newer")

    from . import operators
    from . import ui
    operators.register()
    ui.register()


def unregister():
    from . import ui
    from . import operators
    ui.unregister()
    operators.unregister()
