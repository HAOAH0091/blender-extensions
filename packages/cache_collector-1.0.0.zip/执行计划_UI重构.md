# Cache Collector — UI 重构 + 折叠列表 + 单选 — 执行计划

## 1. 问题回顾

### 当前现状

UI 列表每行直接平铺：文件名 + 大小 + 状态 + 物体列表（截断到 3 个）。点击选中按钮时对当前 View Layer 外的物体会报 `RuntimeError`。同一缓存在多个物体间的对应关系不直观——几个物体挤在一行，看不清谁是谁。

### 核心矛盾

1. **选中报错**：`obj.select_set(True)` 对不在当前 View Layer 的物体会抛异常
2. **信息扁平**：引用同一缓存的 N 个物体被挤在同一行截断显示，无法逐个确认或选中
3. **缺少单文件操作**：没有"只打包这一个文件"的功能

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| 修复选中报错 | P0 | 当前 View Layer 外的物体跳过并显示其场景名 |
| 折叠列表 | P0 | 每个缓存条目可展开/折叠，展开后逐行列出所有引用物体 |
| 物体逐行选中 | P0 | 展开后的每个物体行可单独点击选中，只选那一个物体 |
| 主行全选按钮 | P0 | 主行右侧的"全选"按钮选中该缓存文件的所有物体（仅当前 View Layer） |
| 单文件打包 | P1 | 每条缓存行有独立打包按钮，只打包该文件并更新对应路径 |
| 场景信息展示 | P1 | 物体不在当前 View Layer 时，标注所在场景名 |
| UI 整洁化 | P1 | 信息分层清晰：主行（文件基本信息 + 操作按钮）→ 展开行（物体清单） |

---

## 3. 设计方案

### 3.1 数据结构变更

`CacheEntry.ref_objects` 从 `list[str]` 改为 `list[dict]`：

```python
# 改前
ref_objects: ["Cube", "Sphere"]

# 改后
ref_objects: [
    {"name": "Cube", "scenes": ["Scene", "Scene.001"]},
    {"name": "Sphere", "scenes": ["Scene"]},
]
```

场景信息在扫描时一次性收集（`obj.users_scene` 属性）。

### 3.2 折叠机制

利用 Blender 的 `bpy.props.StringProperty` 存储展开状态。在 `bpy.types.Scene` 上新增 `cache_expanded_states` 属性（StringProperty，JSON 编码的 `{cache_file_name: true/false}` 字典）。

**状态切换**：通过新增的 `CACHE_OT_toggle_expand` 操作符实现。该操作符接收 `cache_file_name` 参数，在 `execute()` 中读取 `cache_expanded_states` → 解析 JSON → 翻转对应 key → 写回。UI 的 `▶`/`▼` 按钮绑定该操作符。

**扫描时重置**：用户每次重新 Scan 时，`cache_expanded_states` 整体清空为 `{}`（所有条目默认折叠）。设计理由：新扫描结果是新的数据快照，上次的展开状态不一定对应本次条目，全部折叠是最安全的起点。

### 3.3 UI 布局（最终版）

```
┌─────────────────────────────────────────────┐
│ 🔄 Scan                                     │
├─────────────────────────────────────────────┤
│ References: 3  (2 ext / 1 int / 0 miss)     │
│                                             │
│ ✓ cloth_sim.abc    245MB  OUT  [▶] [📦]    │
│   └─ 3 objects                              │
│       ├─ ▶ Cube (Scene_01)          [👁]    │
│       ├─ ▶ Sphere (Scene_01)        [👁]    │
│       └─ ▶ mesh_0 (FG_场景) ← 不在当前场景  │
│                                             │
│ ✓ hair_sim.usd     89MB   IN   [▶] [📦]    │
│   └─ 0 objects                              │
│                                             │
│ ✗ broken.abc       0B     MISS [▶] [📦]    │
│   └─ File not found                         │
├─────────────────────────────────────────────┤
│ [📦 Pack All External]  [↩ Restore]        │
└─────────────────────────────────────────────┘
```

设计要点：
- 状态栏改为汇总：external 数量 / internal 数量 / missing 数量
- 展开/折叠箭头 `▶`/`▼` 用文字按钮（`text="▶"` / `text="▼"`），不用 icon
- 主行操作按钮：📦（单文件打包）、👁（全选）
- 展开后每个物体行：物体名 + 场景名 + 👁（单选该物体）
- 不在当前 View Layer 的物体：不显示 👁 按钮，用灰色文字标注场景名
- 没有引用物体的缓存：展开后显示 "0 objects"
- missing 文件：不显示物体信息，展开后只显示错误提示

### 3.4 选中逻辑

**全选按钮（主行）**：遍历 `ref_objects`，对每个在当前 View Layer 中的物体执行 `select_set(True)`。

**单选按钮（物体行）**：只选中该物体，先取消所有选择，再 `select_set(True)`。

**View Layer 判断**（性能优化）：
```python
# 在 draw() 顶部一次性构建 set，避免逐次 O(n) 遍历
view_layer_names = {obj.name for obj in context.view_layer.objects}
# 后续判断改为 O(1)：obj_name in view_layer_names
```

### 3.5 单文件打包

新增 `CACHE_OT_pack_single` 操作符。逻辑上从 Pack 中提取：只处理一个 CacheFile 的主文件和它关联的 layers。流程与 Pack 相同但只面向一个 CacheFile。

**与快照/恢复的交互**（关键设计决策）：

单文件打包**不写快照**。`scene.cache_snapshot` 只被全局 Pack 覆盖写入，只存储最后一次全局 Pack 前的状态。单文件打包后如需回退，用户手动编辑 CacheFile.filepath 或依赖全局 Restore。

理由：
- 如果 `pack_single` 也覆盖写入快照，后续对另一个文件执行 `pack_single` 会把前一个的快照信息冲掉，恢复时状态不完整。
- 如果改为追加模式，`restore_from_snapshot` 要支持部分恢复，复杂度大幅增加，对 P1 功能性价比不高。
- 测试验收：\"单文件打包后全局快照不受影响，Restore 按钮仍恢复到全局 Pack 前的状态\"。

---

## 4. 修改清单

| 文件 | 改动 |
|------|------|
| `utils.py` | `build_cache_file_users_map()` 返回 `dict[str, list[dict]]`（含 scenes）；JSON encode/decode 适配，**decode 中加旧格式兼容**（`ref_objects` 为 `list[str]` 时自动转为 `list[dict]`，scenes 留空） |
| `operators.py` | 新增 `CACHE_OT_pack_single`（不写快照）；新增 `CACHE_OT_toggle_expand`；新增 `CACHE_OT_select_single_object`；修复 `CACHE_OT_select_objects` 的 View Layer 检查 |
| `ui.py` | 新增 `cache_expanded_states` 场景属性；**移除旧版 `ref_objects` 截断字符串拼接逻辑**，列表区重构为折叠式布局；draw 顶部预构建 `view_layer_names` set |
| `__init__.py` | 无改动 |

---

## 5. 实现步骤

### 步骤 1：数据结构调整

- `build_cache_file_users_map()` 返回 `{cf_name: [{"name": ..., "scenes": [...]}, ...]}`
- `CacheEntry.ref_objects` 类型更新
- JSON encode/decode 适配 **（含旧格式兼容：`list[str]` → `list[dict]` 自动迁移）**
- 更新测试脚本

### 步骤 2：选中修复 + View Layer 检查

- `CACHE_OT_select_objects` 加 View Layer 检查，跳过后提示
- 新增 `CACHE_OT_select_single_object`（接收 object_name 参数）

### 步骤 3：UI 折叠列表重构

- 注册 `cache_expanded_states` StringProperty
- 绘制折叠式条目（翻牌箭头 + 主行 + 子行）
- 物体行：场景名 + 单选按钮（仅当前 View Layer 的物体有按钮）

### 步骤 4：单文件打包

- 新增 `CACHE_OT_toggle_expand`（翻转折叠状态）
- 新增 `CACHE_OT_pack_single` 操作符（不写快照）

### 步骤 5：验证

- 编译检查 + 自动化测试全绿

---

## 6. 测试策略

| 场景 | 预期 |
|------|------|
| 点击展开箭头 | 对应的条目展开/折叠 |
| 展开后物件逐行显示 | 物体名 + 场景名 + 单选按钮 |
| 点击全选按钮 | 选中当前场景中所有引用该缓存文件的物体 |
| 点击单选按钮 | 只选中该物体 |
| 不在当前 View Layer 的物体 | 显示场景名但不显示单选按钮 |
| 点击单文件打包 | 只打包该缓存文件到 cache/，更新该 CacheFile 路径 |
| 单文件打包幂等 | 已打包的不重复复制 |
| 全 Pack 按钮不受影响 | 原有功能正常工作 |

---

## 7. 参考

- `bpy.types.Object.users_scene` — 返回物体所属场景列表
- `bpy.types.ViewLayer.objects` — 当前视图层中的物体集合
- `bpy.types.Object.select_set()` — 仅对当前 View Layer 中的物体有效
