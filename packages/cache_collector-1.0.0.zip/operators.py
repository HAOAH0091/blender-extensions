"""Blender operators for Cache Collector."""

import os
import json
import bpy
from bpy.types import Operator

from . import utils


def _wm(context):
    """Shortcut to window manager for property access."""
    return context.window_manager


# -------------------------------------------------------------------
# Scan
# -------------------------------------------------------------------

class CACHE_OT_scan(Operator):
    """Scan the current blend file for all referenced cache files."""
    bl_idname = "cache.scan"
    bl_label = "Scan Cache Files"
    bl_description = "Scan for all Alembic/USD cache files referenced in this blend file"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath)

    def execute(self, context):
        if not bpy.data.filepath:
            self.report({"ERROR"}, "Please save the blend file first")
            return {"CANCELLED"}

        utils.debug_log('Scan started')
        entries = utils.collect_cache_entries()
        wm = _wm(context)
        wm.cache_scan_results = utils.encode_entries_to_json(entries)
        wm.cache_expanded_states = "{}"
        wm.cache_status = f"Found {len(entries)} cache references"

        internal = sum(1 for e in entries if e.status == "internal")
        external = sum(1 for e in entries if e.status == "external")
        missing = sum(1 for e in entries if e.status == "missing")

        self.report({"INFO"},
                     f"Scan complete: {internal} internal, {external} external, {missing} missing")
        return {"FINISHED"}


# -------------------------------------------------------------------
# Pack / Restore
# -------------------------------------------------------------------

class CACHE_OT_pack(Operator):
    """Copy external cache files into the project cache/ folder and update references."""
    bl_idname = "cache.pack"
    bl_label = "Pack to Cache"
    bl_description = "Copy external cache files into cache/ and update paths"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath) and bool(_wm(context).cache_scan_results)

    def execute(self, context):
        wm = _wm(context)
        entries = utils.decode_entries_from_json(wm.cache_scan_results)

        external_entries = [e for e in entries if e.status == "external"]
        if not external_entries:
            self.report({"INFO"}, "No external cache files to pack")
            return {"FINISHED"}

        wm.cache_snapshot = utils.make_snapshot(entries)

        blend_dir = os.path.dirname(bpy.data.filepath)
        cache_dir = os.path.join(blend_dir, "cache")

        copy_results, abs_to_actual_dest = utils.copy_to_cache(external_entries, cache_dir)
        utils.update_paths(external_entries, abs_to_actual_dest)

        copied = sum(1 for v in copy_results.values() if v == "copied")
        errors = [k for k, v in copy_results.items() if v.startswith("error")]
        warnings = [k for k, v in copy_results.items() if v.startswith("warning")]
        skipped = sum(1 for v in copy_results.values() if v.startswith("skipped"))

        msg_parts = []
        if copied:
            msg_parts.append(f"{copied} copied")
        if skipped:
            msg_parts.append(f"{skipped} skipped")
        if warnings:
            msg_parts.append(f"{len(warnings)} warnings")
        if errors:
            msg_parts.append(f"{len(errors)} errors")
        msg = "Packed: " + ", ".join(msg_parts)

        wm.cache_status = msg
        bpy.ops.cache.scan()

        if errors:
            self.report({"WARNING"}, msg)
        else:
            self.report({"INFO"}, msg)

        return {"FINISHED"}


class CACHE_OT_pack_single(Operator):
    """Pack a single cache file to the cache/ folder (no global snapshot)."""
    bl_idname = "cache.pack_single"
    bl_label = "Pack This File"
    bl_description = "Pack only this cache file to cache/. Does not affect the global Restore snapshot"
    bl_options = {"REGISTER", "UNDO"}

    cache_file_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath) and bool(_wm(context).cache_scan_results)

    def execute(self, context):
        if not self.cache_file_name:
            return {"CANCELLED"}

        utils.debug_log(f'Pack single: {self.cache_file_name}')
        wm = _wm(context)
        entries = utils.decode_entries_from_json(wm.cache_scan_results)
        wm.cache_snapshot = utils.make_snapshot(entries)

        target = [e for e in entries
                  if e.cache_file_names and self.cache_file_name in e.cache_file_names
                  and e.status == "external"]
        if not target:
            self.report({"INFO"}, "No external files to pack for this entry")
            return {"FINISHED"}

        blend_dir = os.path.dirname(bpy.data.filepath)
        cache_dir = os.path.join(blend_dir, "cache")

        copy_results, abs_to_actual_dest = utils.copy_to_cache(target, cache_dir)
        utils.update_paths(target, abs_to_actual_dest)

        copied = sum(1 for v in copy_results.values() if v == "copied")
        self.report({"INFO"}, f"Single pack: {copied} file(s) copied")
        bpy.ops.cache.scan()
        return {"FINISHED"}


class CACHE_OT_restore(Operator):
    """Restore original cache file paths from the pre-pack snapshot."""
    bl_idname = "cache.restore"
    bl_label = "Restore Original Paths"
    bl_description = "Restore original cache file paths from the global Pack snapshot"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(_wm(context).cache_snapshot)

    def execute(self, context):
        wm = _wm(context)
        if not wm.cache_snapshot:
            self.report({"ERROR"}, "No snapshot to restore from")
            return {"CANCELLED"}

        utils.debug_log("Restore started")
        messages = utils.restore_from_snapshot(wm.cache_snapshot)

        has_error = any(m.startswith("Error") for m in messages)
        if has_error:
            self.report({"ERROR"}, "Restore failed — snapshot preserved for retry")
            return {"CANCELLED"}

        bpy.ops.cache.scan()
        wm.cache_snapshot = ""
        wm.cache_status = "Paths restored. Cache files remain in cache/ for manual cleanup."
        self.report({"INFO"}, f"Restored: {len(messages)} paths updated")
        return {"FINISHED"}


# -------------------------------------------------------------------
# Selection / Expand
# -------------------------------------------------------------------

class CACHE_OT_select_single_object(Operator):
    """Select a single object. If not in the current view layer, offers to switch scenes."""
    bl_idname = "cache.select_single"
    bl_label = "Select Object"
    bl_description = "Select this object in the viewport (switch scenes if needed)"
    bl_options = {"REGISTER", "UNDO"}

    object_name: bpy.props.StringProperty()

    def execute(self, context):
        utils.debug_log(f"Select single: {self.object_name}")
        obj = bpy.data.objects.get(self.object_name)
        if obj is None:
            self.report({"WARNING"}, "Object not found")
            return {"CANCELLED"}

        # Already in current view layer → select directly
        if obj.name in context.view_layer.objects:
            for o in bpy.data.objects:
                o.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({"INFO"}, f"Selected: {obj.name}")
            return {"FINISHED"}

        # Not in current view layer → switch to its first scene and try
        scenes = [s.name for s in obj.users_scene]
        if not scenes:
            self.report({"WARNING"}, f"'{obj.name}' is not in any scene")
            return {"CANCELLED"}

        target_scene = scenes[0]
        context.window.scene = bpy.data.scenes[target_scene]

        # Try selecting in the new context
        try:
            for o in bpy.data.objects:
                o.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({"INFO"}, f"Switched to '{target_scene}' and selected: {obj.name}")
        except RuntimeError:
            self.report(
                {"WARNING"},
                f"'{obj.name}' is in scene '{target_scene}' "
                f"but not visible in the active view layer. "
                f"Check collection visibility."
            )
        return {"FINISHED"}


class CACHE_OT_toggle_expand(Operator):
    """Toggle the expanded state of a cache entry in the list."""
    bl_idname = "cache.toggle_expand"
    bl_label = "Toggle Expand"
    bl_description = "Show or hide details for this cache file"
    bl_options = {"REGISTER"}

    cache_file_name: bpy.props.StringProperty()

    def execute(self, context):
        wm = _wm(context)
        raw = wm.cache_expanded_states
        try:
            states = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            states = {}

        is_now_expanded = not states.get(self.cache_file_name, False)
        states[self.cache_file_name] = is_now_expanded
        wm.cache_expanded_states = json.dumps(states)

        # Lazy-populate users when expanding for the first time
        utils.debug_log(f"Toggle expand: {os.path.basename(self.cache_file_name)} -> {is_now_expanded}")
        if is_now_expanded and wm.cache_scan_results:
            entries = utils.decode_entries_from_json(wm.cache_scan_results)
            updated = False
            for e in entries:
                if not e.ref_objects and e.abs_path == self.cache_file_name:
                    all_refs: list[dict] = []
                    seen: set[str] = set()
                    for name in (e.cache_file_names or []):
                        for r in utils.populate_entry_users(name):
                            if r["name"] not in seen:
                                seen.add(r["name"])
                                all_refs.append(r)
                    e.ref_objects = all_refs
                    e.is_orphan = not bool(all_refs)
                    updated = True
                    break  # one match per cache_file is enough
            if updated:
                wm.cache_scan_results = utils.encode_entries_to_json(entries)

        return {"FINISHED"}


# -------------------------------------------------------------------
# Registration
# -------------------------------------------------------------------

class CACHE_OT_delete_cachefile(Operator):
    """Delete an orphaned CacheFile data-block."""
    bl_idname = "cache.delete_cachefile"
    bl_label = "Delete CacheFile"
    bl_description = "Delete this unused CacheFile data-block from the blend file"
    bl_options = {"REGISTER", "UNDO"}

    cache_file_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath)

    def execute(self, context):
        cf = bpy.data.cache_files.get(self.cache_file_name)
        if cf is None:
            self.report({"WARNING"}, f"CacheFile '{self.cache_file_name}' not found")
            return {"CANCELLED"}

        if cf.users > 0:
            self.report(
                {"ERROR"},
                f"Cannot delete '{self.cache_file_name}': still in use by {cf.users} data-block(s)"
            )
            return {"CANCELLED"}

        utils.debug_log(f"Deleting orphan CacheFile: {self.cache_file_name}")
        bpy.data.batch_remove([cf])
        bpy.ops.cache.scan()
        self.report({"INFO"}, f"Deleted: {self.cache_file_name}")
        return {"FINISHED"}


classes = (
    CACHE_OT_scan,
    CACHE_OT_pack,
    CACHE_OT_pack_single,
    CACHE_OT_restore,
    CACHE_OT_select_single_object,
    CACHE_OT_toggle_expand,
    CACHE_OT_delete_cachefile,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
