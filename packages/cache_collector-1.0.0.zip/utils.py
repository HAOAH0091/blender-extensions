"""Utility functions for Cache Collector addon."""

from __future__ import annotations

import os
import glob
import json
import shutil
import re
import time
from dataclasses import dataclass, field
from typing import Optional

import bpy


# -------------------------------------------------------------------
# Debug logging
# -------------------------------------------------------------------

def _debug_wm():
    try:
        return bpy.context.window_manager
    except Exception:
        return None


def debug_log(msg: str) -> None:
    wm = _debug_wm()
    if wm is None:
        return
    if not getattr(wm, "cache_debug", False):
        return
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    current = getattr(wm, "cache_debug_log", "")
    wm.cache_debug_log = (current + line + "\n")[-8000:]


# -------------------------------------------------------------------
# Data structures
# -------------------------------------------------------------------

@dataclass
class CacheEntry:
    cache_file: "bpy.types.CacheFile"            # primary CacheFile (may be None after decode if deleted)
    cache_file_names: list[str] = field(default_factory=list)  # all CacheFile names (multi-source after dedup)
    source: str = ""                              # "main" | "layer" | "merged"
    filepath: str = ""                            # original filepath
    abs_path: str = ""                            # normalized absolute path
    status: str = ""                              # "internal" | "external" | "missing"
    size: int = 0                                 # file size in bytes
    cache_rel_path: str = ""                      # relative destination path under cache/
    is_sequence: bool = False                     # sequence flag
    ref_objects: list[dict] = field(default_factory=list)  # [{name, scenes}, ...]
    is_orphan: bool = False                       # no objects reference this CacheFile


# -------------------------------------------------------------------
# JSON serialization
# -------------------------------------------------------------------

def encode_entries_to_json(entries: list[CacheEntry]) -> str:
    data = []
    for e in entries:
        data.append({
            "cache_file_name": e.cache_file.name if e.cache_file else "",
            "cache_file_names": e.cache_file_names,
            "source": e.source,
            "filepath": e.filepath,
            "abs_path": e.abs_path,
            "status": e.status,
            "size": e.size,
            "cache_rel_path": e.cache_rel_path,
            "is_sequence": e.is_sequence,
            "ref_objects": e.ref_objects,
            "is_orphan": e.is_orphan,
        })
    return json.dumps(data, ensure_ascii=False)


def decode_entries_from_json(json_str: str) -> list[CacheEntry]:
    data = json.loads(json_str)
    entries = []
    for d in data:
        # Resolve primary cache_file
        cf_name = d.get("cache_file_name", "")
        cf_names = d.get("cache_file_names", [cf_name] if cf_name else [])
        cf = bpy.data.cache_files.get(cf_names[0]) if cf_names else None

        # Old format compat: list[str] → list[dict]
        refs = d.get("ref_objects", [])
        if refs and all(isinstance(r, str) for r in refs):
            refs = [{"name": n, "scenes": []} for n in refs]

        entries.append(CacheEntry(
            cache_file=cf,
            cache_file_names=cf_names,
            source=d.get("source", "main"),
            filepath=d.get("filepath", ""),
            abs_path=d.get("abs_path", ""),
            status=d.get("status", "missing"),
            size=d.get("size", 0),
            cache_rel_path=d.get("cache_rel_path", ""),
            is_sequence=d.get("is_sequence", False),
            ref_objects=refs,
            is_orphan=d.get("is_orphan", False),
        ))
    return entries


# -------------------------------------------------------------------
# CacheFile → object lookup
# -------------------------------------------------------------------

def build_cache_file_users_map() -> dict[str, list[dict]]:
    cf_users: dict[str, set[str]] = {}
    obj_scenes: dict[str, list[str]] = {}
    for obj in bpy.data.objects:
        scenes = [s.name for s in obj.users_scene]
        obj_scenes[obj.name] = scenes
        for modifier in obj.modifiers:
            if modifier.type == "MESH_SEQUENCE_CACHE":
                cf = getattr(modifier, "cache_file", None)
                if cf is not None:
                    cf_users.setdefault(cf.name, set()).add(obj.name)
        for constraint in obj.constraints:
            if constraint.type == "TRANSFORM_CACHE":
                cf = getattr(constraint, "cache_file", None)
                if cf is not None:
                    cf_users.setdefault(cf.name, set()).add(obj.name)
    return {
        k: [{"name": n, "scenes": obj_scenes.get(n, [])} for n in sorted(v)]
        for k, v in cf_users.items()
    }


def populate_entry_users(cache_file_name: str) -> list[dict]:
    refs: set[str] = set()
    for obj in bpy.data.objects:
        for modifier in obj.modifiers:
            if modifier.type == "MESH_SEQUENCE_CACHE":
                cf = getattr(modifier, "cache_file", None)
                if cf and cf.name == cache_file_name:
                    refs.add(obj.name)
        for constraint in obj.constraints:
            if constraint.type == "TRANSFORM_CACHE":
                cf = getattr(constraint, "cache_file", None)
                if cf and cf.name == cache_file_name:
                    refs.add(obj.name)
    return [
        {"name": n, "scenes": [s.name for s in bpy.data.objects[n].users_scene]}
        for n in sorted(refs)
    ]


# -------------------------------------------------------------------
# Path utilities
# -------------------------------------------------------------------

def normalize_path(raw_path: str) -> str:
    path = os.path.normpath(raw_path)
    if os.path.exists(path):
        path = os.path.realpath(path)
    else:
        path = os.path.normcase(path)
    return path


# -------------------------------------------------------------------
# Scan
# -------------------------------------------------------------------

_STATUS_ORDER = {"internal": 0, "external": 1, "missing": 2}


def _best_status(a: str, b: str) -> str:
    return a if _STATUS_ORDER.get(a, 99) <= _STATUS_ORDER.get(b, 99) else b


def _dedupe_entries(raw: list[CacheEntry]) -> list[CacheEntry]:
    """Merge entries with the same abs_path."""
    groups: dict[str, list[CacheEntry]] = {}
    for e in raw:
        groups.setdefault(e.abs_path, []).append(e)

    merged = []
    for abs_path, group in groups.items():
        if len(group) == 1:
            merged.append(group[0])
            continue

        first = group[0]
        best_st = first.status
        all_names: list[str] = []
        all_refs: list[dict] = []
        seen_refs: set[str] = set()

        for e in group:
            best_st = _best_status(best_st, e.status)
            if e.cache_file and e.cache_file.name not in all_names:
                all_names.append(e.cache_file.name)
            for r in e.ref_objects:
                key = r.get("name", "")
                if key and key not in seen_refs:
                    seen_refs.add(key)
                    all_refs.append(r)

        if first.status != best_st:
            debug_log(f"Dedup '{os.path.basename(abs_path)}': status {first.status}→{best_st}")

        first.status = best_st
        first.cache_file_names = all_names
        first.source = "merged" if len(group) > 1 else first.source
        first.ref_objects = all_refs
        merged.append(first)

    return merged


def collect_cache_entries() -> list[CacheEntry]:
    """Scan all CacheFile data-blocks, deduplicate by abs_path, detect orphans."""
    entries: list[CacheEntry] = []
    blend_dir = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else ""
    if blend_dir:
        blend_dir = os.path.realpath(blend_dir) if os.path.exists(blend_dir) else os.path.normpath(blend_dir)

    for cache_file in bpy.data.cache_files:
        if cache_file is None:
            continue

        if cache_file.filepath:
            _add_entry(entries, cache_file, "main",
                       cache_file.filepath, cache_file.is_sequence, blend_dir)

        for layer in cache_file.layers:
            if layer and layer.filepath:
                _add_entry(entries, cache_file, "layer",
                           layer.filepath, False, blend_dir)

    # Deduplicate by abs_path
    entries = _dedupe_entries(entries)

    # Orphans detected lazily when user expands (toggle_expand operator)

    return entries


def _add_entry(
    entries: list[CacheEntry],
    cache_file: "bpy.types.CacheFile",
    source: str,
    filepath: str,
    is_sequence: bool,
    blend_dir: str,
) -> None:
    raw_abs = bpy.path.abspath(filepath)

    if is_sequence and "#" in os.path.basename(raw_abs):
        norm_abs = normalize_path(os.path.dirname(raw_abs))
        norm_abs = os.path.join(norm_abs, os.path.basename(raw_abs))
    else:
        norm_abs = normalize_path(raw_abs)

    if not os.path.exists(norm_abs) and not (is_sequence and "#" in os.path.basename(norm_abs)):
        status = "missing"
        size = 0
    elif blend_dir and norm_abs.startswith(os.path.join(blend_dir, "cache") + os.sep):
        status = "internal"
        size = _get_file_size(norm_abs, is_sequence)
    else:
        status = "external"
        size = _get_file_size(norm_abs, is_sequence)

    cache_rel_path = _compute_cache_rel_path(norm_abs, is_sequence, blend_dir)

    entries.append(CacheEntry(
        cache_file=cache_file,
        cache_file_names=[cache_file.name] if cache_file else [],
        source=source,
        filepath=filepath,
        abs_path=norm_abs,
        status=status,
        size=size,
        cache_rel_path=cache_rel_path,
        is_sequence=is_sequence,
        ref_objects=[],
        is_orphan=False,
    ))


def _get_file_size(path: str, is_sequence: bool) -> int:
    if is_sequence and "#" in os.path.basename(path):
        total = 0
        for f in glob.iglob(re.sub(r"#+", "*", path)):
            try:
                total += os.path.getsize(f)
            except OSError:
                pass
        return total
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _last_path_levels(abs_path: str, levels: int = 2) -> str:
    _, path_no_drive = os.path.splitdrive(abs_path)
    parts = path_no_drive.replace("\\", "/").strip("/").split("/")
    return "/".join(parts[-levels:]) if len(parts) >= levels else "/".join(parts) if parts else os.path.basename(abs_path)


def _compute_cache_rel_path(abs_path: str, _is_sequence: bool, blend_dir: str) -> str:
    if not blend_dir:
        return os.path.basename(abs_path)

    blend_norm = os.path.normpath(blend_dir)
    abs_norm = os.path.normpath(abs_path)
    blend_drive = os.path.splitdrive(blend_norm)[0]
    abs_drive = os.path.splitdrive(abs_norm)[0]

    if blend_drive != abs_drive:
        return _last_path_levels(abs_norm, 2)

    try:
        rel = os.path.relpath(abs_norm, blend_norm)
        if rel.startswith(".."):
            return _last_path_levels(abs_norm, 2)
        return rel
    except ValueError:
        return _last_path_levels(abs_norm, 2)


# -------------------------------------------------------------------
# Sequence globbing
# -------------------------------------------------------------------

def glob_sequence(template_path: str) -> tuple[list[str], list[int]]:
    if "#" not in os.path.basename(template_path):
        return [template_path], []

    glob_pattern = re.sub(r"#+", "*", template_path)
    matched = sorted(glob.glob(glob_pattern))
    if not matched:
        return [], []

    base = os.path.basename(template_path)
    start = base.find("#")
    end = base.rfind("#") + 1
    frame_pattern = base[:start] + r"(\d+)" + base[end:]
    frame_re = re.compile(frame_pattern)

    actual_nums: set[int] = set()
    for fpath in matched:
        m = frame_re.match(os.path.basename(fpath))
        if m:
            actual_nums.add(int(m.group(1)))

    missing: list[int] = []
    if actual_nums:
        missing = sorted(set(range(min(actual_nums), max(actual_nums) + 1)) - actual_nums)

    return matched, missing


# -------------------------------------------------------------------
# Pack
# -------------------------------------------------------------------

def copy_to_cache(
    entries: list[CacheEntry], cache_dir: str,
) -> tuple[dict[str, str], dict[str, str]]:
    os.makedirs(cache_dir, exist_ok=True)
    results: dict[str, str] = {}
    abs_to_actual_dest: dict[str, str] = {}
    seen_abs: set[str] = set()

    for entry in entries:
        if entry.status == "internal":
            results[entry.abs_path] = "skipped_internal"
            continue
        if entry.status == "missing":
            results[entry.abs_path] = "skipped_missing"
            continue
        if entry.abs_path in seen_abs:
            results[entry.abs_path] = "already_copied"
            continue

        dest = os.path.normpath(os.path.join(cache_dir, entry.cache_rel_path))
        dest_dir = os.path.dirname(dest)

        already_there = os.path.exists(dest) and entry.abs_path == os.path.realpath(dest)
        if already_there:
            results[entry.abs_path] = "skipped_internal"
            abs_to_actual_dest[entry.abs_path] = dest
            continue

        if os.path.exists(dest):
            base, ext = os.path.splitext(dest)
            counter = 1
            new_dest = f"{base}_{counter}{ext}"
            while os.path.exists(new_dest):
                counter += 1
                new_dest = f"{base}_{counter}{ext}"
            dest = new_dest

        try:
            os.makedirs(dest_dir, exist_ok=True)

            if entry.is_sequence and "#" in os.path.basename(entry.abs_path):
                matched, missing_frames = glob_sequence(entry.abs_path)
                if not matched:
                    results[entry.abs_path] = "warning: sequence glob returned no files"
                    abs_to_actual_dest[entry.abs_path] = dest
                    continue
                if missing_frames:
                    results[entry.abs_path] = f"warning: {len(missing_frames)} missing frame(s)"

                for src in matched:
                    shutil.copy2(src, os.path.join(dest_dir, os.path.basename(src)))
                abs_to_actual_dest[entry.abs_path] = dest
            else:
                shutil.copy2(entry.abs_path, dest)
                abs_to_actual_dest[entry.abs_path] = dest

            if entry.abs_path not in results:
                results[entry.abs_path] = "copied"
            seen_abs.add(entry.abs_path)
        except OSError as e:
            results[entry.abs_path] = f"error: {e}"

    return results, abs_to_actual_dest


def update_paths(
    entries: list[CacheEntry],
    abs_to_actual_dest: dict[str, str],
) -> list[str]:
    messages: list[str] = []
    updated_keys: set[tuple[str, str, str]] = set()
    blend_dir = os.path.dirname(bpy.data.filepath)

    for entry in entries:
        if entry.status != "external":
            continue
        if entry.abs_path not in abs_to_actual_dest:
            continue

        actual_dest = abs_to_actual_dest[entry.abs_path]
        try:
            rel_target = os.path.relpath(actual_dest, blend_dir)
        except ValueError:
            rel_target = actual_dest
        new_filepath = "//" + rel_target.replace("\\", "/")

        # Update ALL CacheFiles that share this abs_path (merged entries)
        names = entry.cache_file_names if entry.cache_file_names else (
            [entry.cache_file.name] if entry.cache_file else [])
        for name in names:
            cf = bpy.data.cache_files.get(name)
            if cf is None:
                continue
            key = (name, entry.source, entry.filepath)
            if key in updated_keys:
                continue
            updated_keys.add(key)

            cf.filepath = new_filepath
            cf.tag = True
            messages.append(f"Updated {name}.filepath → {new_filepath}")

            # Update layers for this CacheFile (if the entry was from a layer)
            if entry.source in ("layer", "merged"):
                for layer in cf.layers:
                    if layer and layer.filepath == entry.filepath:
                        layer.filepath = new_filepath
                        messages.append(f"Updated {name}.layer → {new_filepath}")
                        break

    return messages


# -------------------------------------------------------------------
# Snapshot / Restore
# -------------------------------------------------------------------

def make_snapshot(entries: list[CacheEntry]) -> str:
    snap: list[dict] = []
    seen: set[str] = set()

    for entry in entries:
        for name in (entry.cache_file_names or [entry.cache_file.name if entry.cache_file else ""]):
            if not name or name in seen:
                continue
            seen.add(name)
            cf = bpy.data.cache_files.get(name)
            if cf is None:
                continue
            snap.append({
                "name": name,
                "old_filepath": cf.filepath,
                "old_layers": [layer.filepath for layer in cf.layers if layer and layer.filepath],
            })

    return json.dumps(snap, indent=2)


def restore_from_snapshot(snapshot_json: str) -> list[str]:
    messages: list[str] = []
    try:
        snap = json.loads(snapshot_json)
    except json.JSONDecodeError:
        return ["Error: invalid snapshot JSON"]

    for item in snap:
        name = item.get("name", "")
        if name not in bpy.data.cache_files:
            messages.append(f"Warning: CacheFile '{name}' not found, skipping")
            continue

        cf = bpy.data.cache_files[name]
        old_main = item.get("old_filepath", "")
        if old_main:
            cf.filepath = old_main
            messages.append(f"Restored {name}.filepath → {old_main}")

        old_layers = item.get("old_layers", [])
        while len(cf.layers) > len(old_layers):
            cf.layers.remove(cf.layers[-1])
        for i, layer_path in enumerate(old_layers):
            if not layer_path:
                continue
            if i < len(cf.layers):
                cf.layers[i].filepath = layer_path
            else:
                cf.layers.new(layer_path)
                if cf.layers[-1] is not None:
                    cf.layers[-1].filepath = layer_path
                messages.append(f"Restored {name}.layer → {layer_path}")

        cf.tag = True

    return messages
