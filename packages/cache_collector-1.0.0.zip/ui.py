"""UI panel for Cache Collector."""

import os
import json
import bpy
from bpy.types import Panel
from bpy.props import StringProperty, BoolProperty

from . import utils


# -------------------------------------------------------------------
# WindowManager properties
# -------------------------------------------------------------------

def register_props():
    if not hasattr(bpy.types.WindowManager, "cache_scan_results"):
        bpy.types.WindowManager.cache_scan_results = StringProperty(default="")
    if not hasattr(bpy.types.WindowManager, "cache_snapshot"):
        bpy.types.WindowManager.cache_snapshot = StringProperty(default="")
    if not hasattr(bpy.types.WindowManager, "cache_status"):
        bpy.types.WindowManager.cache_status = StringProperty(default="")
    if not hasattr(bpy.types.WindowManager, "cache_expanded_states"):
        bpy.types.WindowManager.cache_expanded_states = StringProperty(default="{}")
    if not hasattr(bpy.types.WindowManager, "cache_debug"):
        bpy.types.WindowManager.cache_debug = BoolProperty(
            name="Debug Mode", default=False)
    if not hasattr(bpy.types.WindowManager, "cache_debug_log"):
        bpy.types.WindowManager.cache_debug_log = StringProperty(default="")


def unregister_props():
    for attr in ("cache_scan_results", "cache_snapshot", "cache_status",
                 "cache_expanded_states", "cache_debug", "cache_debug_log"):
        if hasattr(bpy.types.WindowManager, attr):
            delattr(bpy.types.WindowManager, attr)


# -------------------------------------------------------------------
# Panel
# -------------------------------------------------------------------

class VIEW3D_PT_cache_collector(Panel):
    bl_label = "Cache Collector"
    bl_idname = "VIEW3D_PT_cache_collector"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Cache"

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager

        row = layout.row(align=True)
        row.scale_y = 1.5
        row.operator("cache.scan", text="Scan Cache Files", icon="FILE_REFRESH")

        if not bpy.data.filepath:
            layout.label(text="Save the blend file first", icon="ERROR")
            return

        if wm.cache_status:
            box = layout.box()
            box.label(text=wm.cache_status, icon="INFO")

        if not wm.cache_scan_results:
            return

        entries = utils.decode_entries_from_json(wm.cache_scan_results)
        if not entries:
            return

        num_in = sum(1 for e in entries if e.status == "internal")
        num_ex = sum(1 for e in entries if e.status == "external")
        num_mi = sum(1 for e in entries if e.status == "missing")

        box = layout.box()
        box.label(
            text=f"References: {len(entries)}  ({num_ex} ext / {num_in} int / {num_mi} miss)",
            icon="FILEBROWSER",
        )

        raw = wm.cache_expanded_states
        try:
            expanded_states = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            expanded_states = {}

        view_layer_names = {obj.name for obj in context.view_layer.objects}

        for entry in entries:
            is_expandable = entry.status == "missing" or entry.is_orphan
            entry_key = entry.abs_path
            is_expanded = expanded_states.get(entry_key, False)

            # ── Main row ──────────────────────────────────
            main = box.row(align=True)

            icon = "CHECKBOX_HLT" if entry.status == "internal" else \
                   "EXPORT" if entry.status == "external" else "ERROR"
            main.label(text="", icon=icon)

            # Expand arrow — always present for alignment; only interactive for expandable
            arrow = "▼" if is_expanded else "▶"
            if is_expandable:
                op = main.operator("cache.toggle_expand", text=arrow, emboss=False)
                op.cache_file_name = entry_key
            else:
                main.label(text=" ")

            # Name
            name = os.path.basename(entry.abs_path) if entry.abs_path else "?"
            if entry.source == "layer":
                name = f"[layer] {name}"

            # Multi-source marker
            if len(entry.cache_file_names) > 1:
                name += f" (×{len(entry.cache_file_names)})"

            size_str = ""
            if entry.size > 1024 * 1024:
                size_str = f"  {entry.size / 1024 / 1024:.1f}MB"
            elif entry.size > 1024:
                size_str = f"  {entry.size / 1024:.1f}KB"

            main.label(text=name + size_str)

            # Badge
            badge = {"internal": "IN", "external": "OUT", "missing": "MISS"}.get(entry.status, "?")
            if entry.is_orphan:
                badge = "ORPHAN"
            main.label(text=badge)

            # Pack single (external only)
            if entry.status == "external":
                for cf_name in (entry.cache_file_names or ["__none__"]):
                    op = main.operator("cache.pack_single", text="", icon="PACKAGE", emboss=False)
                    op.cache_file_name = cf_name
                    break  # one pack button per entry

            # ── Expanded (missing / orphan only) ─────────
            if not is_expandable or not is_expanded:
                continue

            # MISSING detail
            if entry.status == "missing":
                sub = box.row(align=True)
                sub.label(text="", icon="BLANK1")
                sub.label(text="File not found", icon="ERROR")

                sub = box.row(align=True)
                sub.label(text="", icon="BLANK1")
                sub.label(text="", icon="BLANK1")
                sub.label(text=f"Stored path: {entry.filepath}")

                sub = box.row(align=True)
                sub.label(text="", icon="BLANK1")
                sub.label(text="", icon="BLANK1")
                sub.label(text=f"Expected at: {entry.abs_path}")

                if entry.cache_file and entry.cache_file.filepath.startswith("//"):
                    txt = "Relocate the cache file or update the path in the CacheFile data-block"
                else:
                    txt = "File was moved or deleted. Restore or relink it."
                sub = box.row(align=True)
                sub.label(text="", icon="BLANK1")
                sub.label(text="", icon="BLANK1")
                sub.label(text=txt, icon="INFO")

                # Objects
                refs = entry.ref_objects or []
                if refs:
                    sub = box.row(align=True)
                    sub.label(text="", icon="BLANK1")
                    sub.label(text="", icon="BLANK1")
                    sub.label(text=f"Affected: {len(refs)} object(s)")

                    for r in refs[:20]:
                        obj_name = r.get("name", "?")
                        in_vl = obj_name in view_layer_names
                        scenes = ", ".join(r.get("scenes", []))

                        orow = box.row(align=True)
                        orow.label(text="", icon="BLANK1")
                        orow.label(text="", icon="BLANK1")
                        orow.label(text="", icon="BLANK1")
                        orow.label(text=obj_name, icon="OBJECT_DATA")
                        orow.label(text=f"({scenes})")

                        op = orow.operator("cache.select_single", text="", icon="RESTRICT_SELECT_OFF", emboss=False)
                        op.object_name = obj_name
                else:
                    sub = box.row(align=True)
                    sub.label(text="", icon="BLANK1")
                    sub.label(text="", icon="BLANK1")
                    sub.label(text="0 objects (orphaned)", icon="GHOST_ENABLED")

            # ORPHAN detail
            elif entry.is_orphan:
                sub = box.row(align=True)
                sub.label(text="", icon="BLANK1")
                sub.label(text="0 objects — unused CacheFile", icon="GHOST_ENABLED")

                # Delete button for each CacheFile name
                for cf_name in entry.cache_file_names:
                    sub = box.row(align=True)
                    sub.label(text="", icon="BLANK1")
                    sub.label(text="", icon="BLANK1")
                    op = sub.operator("cache.delete_cachefile", text=f"Delete '{cf_name}'", icon="TRASH")
                    op.cache_file_name = cf_name

        # ── Global actions ────────────────────────────────
        col = layout.column(align=True)
        col.scale_y = 1.5

        has_external = any(e.status == "external" for e in entries)
        has_snapshot = bool(wm.cache_snapshot)

        if has_external:
            col.operator("cache.pack", text="Pack All External", icon="PACKAGE")
        if has_snapshot:
            col.operator("cache.restore", text="Restore Original Paths", icon="LOOP_BACK")
        if not has_external and not has_snapshot:
            col.label(text="No external files to pack", icon="CHECKMARK")

        # ── Debug ─────────────────────────────────────────
        layout.separator()
        row = layout.row(align=True)
        row.prop(wm, "cache_debug", text="Debug Log")
        if wm.cache_debug and wm.cache_debug_log:
            box = layout.box()
            for line in wm.cache_debug_log.strip().split("\n")[-20:]:
                box.label(text=line)


# -------------------------------------------------------------------
# Registration
# -------------------------------------------------------------------

classes = (VIEW3D_PT_cache_collector,)


def register():
    register_props()
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    unregister_props()
