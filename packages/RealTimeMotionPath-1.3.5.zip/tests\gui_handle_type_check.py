# -*- coding: utf-8 -*-
"""手柄类型与写入生效性（2026-09-16 新增）

背景（用户实测反馈"R/S 没反应"的第三个根因）：
    Blender 新建关键帧的默认手柄类型是 **AUTO_CLAMPED** —— 派生类型，
    坐标由 Blender 公式导出，**不接受外部写入**（`fc.update()` 会覆盖）。

实测（单点旋转 30°，纯直线路径）：
    FREE          Δhandle = 0.800000   手柄生效
    AUTO_CLAMPED  Δhandle = 0.000000   ★ 被吞掉 → 看起来"完全没反应"
    ALIGNED       Δhandle = 0.800000   手柄生效

修法：R/S 在 begin 时把选中关键帧的两侧手柄转成 FREE（保留坐标），
      与 Blender 原生语义一致（显式变换手柄 → 它变 FREE）。
      取消时恢复原类型。

本测试钉死：
  A. 三种初始类型下，R/S 的**结果必须一致**（与初始类型无关）
  B. 单点旋转真的改变了手柄（不再"没反应"）
  C. 多点旋转手柄跟着转（不是只平移）
  D. 取消后手柄类型恢复原样
  E. G（移动）不受影响（它本来在派生类型下也正确）
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_ht_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf

    def build(htype):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
                       (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]:
            sc.frame_set(f); o.location = loc; o.keyframe_insert("location", frame=f)
        act = o.animation_data.action
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype
                kp.handle_right_type = htype
            fc.update()
        return o, act

    def read(act, o, frame=14.0):
        """每次现取（避免缓存对象「钝」）。"""
        out = {}
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 0.5:
                    out[fc.array_index] = (float(kp.co[1]),
                                           float(kp.handle_left[1]),
                                           float(kp.handle_right[1]),
                                           str(kp.handle_left_type),
                                           str(kp.handle_right_type))
        return out

    def select_one(act, o, frame=14.0):
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.select_control_point = (abs(kp.co[0] - frame) < 0.5)
            fc.update()

    def select_two(act, o):
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.select_control_point = (abs(kp.co[0] - 14) < 0.5
                                           or abs(kp.co[0] - 27) < 0.5)
            fc.update()

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d

    def setup_view():
        rv3d.view_location = mathutils.Vector((6, 0, 0))
        rv3d.view_distance = 20.0
        rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))   # 顶视：轴 = 世界 Z
        bpy.context.view_layer.update()

    # =========================================================
    # A. 三种初始类型，结果必须一致
    # =========================================================
    setup_view()
    results = {}
    for htype in ('FREE', 'AUTO_CLAMPED', 'ALIGNED', 'AUTO', 'VECTOR'):
        o, act = build(htype)
        select_one(act, o)
        b0 = read(act, o)
        s = me.RotateSession('ROTATE')
        ok = s.begin(o, act, region, rv3d, 600.0, 400.0)
        if not ok:
            step("A: %s 单点旋转 begin" % htype, False, s.message)
            continue
        s.apply_numeric(30.0)
        b1 = read(act, o)
        d_co = max(abs(b1[i][0] - b0[i][0]) for i in b0)
        d_h = max(max(abs(b1[i][1] - b0[i][1]), abs(b1[i][2] - b0[i][2])) for i in b0)
        results[htype] = (d_co, d_h, b1[0][1])
        step("★ A: 初始类型 %-12s → 单点旋转生效（Δhandle=%.6f）" % (htype, d_h),
             d_h > 1e-4, "Δco=%.6f Δhandle=%.6f hl=%.4f" % (d_co, d_h, b1[0][1]))
        step("A: %s 单点旋转 co 不动" % htype, d_co < 1e-6, "Δco=%.6f" % d_co)
        s.cancel()

    if len(results) >= 2:
        # ⚠️ 断言是"**全都生效**"，不是"数值相同" ——
        #    VECTOR 的手柄初始几何本来就不同（指向相邻关键帧），
        #    旋转同样角度后位移量自然不同。那是几何差异，不是类型影响。
        vals = [v[1] for v in results.values()]
        step("★ A: 五种初始类型下 R/S 全都生效（初始类型不影响可用性）",
             all(v > 1e-4 for v in vals),
             "Δhandle: %s" % {k: round(v[1], 6) for k, v in results.items()})

    # =========================================================
    # B. 多点旋转：手柄跟着转（不是只平移）
    # =========================================================
    for htype in ('FREE', 'AUTO_CLAMPED'):
        o, act = build(htype)
        select_two(act, o)
        b0 = {f: read(act, o, f) for f in (14.0, 27.0)}
        s = me.RotateSession('ROTATE')
        if not s.begin(o, act, region, rv3d, 600.0, 400.0):
            step("B: %s 多点 begin" % htype, False, s.message); continue
        s.apply_numeric(30.0)
        b1 = {f: read(act, o, f) for f in (14.0, 27.0)}
        d_h = max(max(abs(b1[f][i][1] - b0[f][i][1]), abs(b1[f][i][2] - b0[f][i][2]))
                  for f in b0 for i in b0[f])
        step("★ B: %s 多点旋转手柄跟着转（Δhandle=%.6f）" % (htype, d_h),
             d_h > 0.5, "Δhandle=%.6f" % d_h)
        s.cancel()

    # =========================================================
    # C. 取消后手柄类型恢复
    # =========================================================
    for htype in ('AUTO_CLAMPED', 'ALIGNED'):
        o, act = build(htype)
        select_one(act, o)
        before = read(act, o)
        t_before = (before[0][3], before[0][4])
        s = me.RotateSession('ROTATE')
        s.begin(o, act, region, rv3d, 600.0, 400.0)
        during = read(act, o)
        step("C: %s begin 后手柄已转 FREE（可写入）" % htype,
             during[0][3] == 'FREE' and during[0][4] == 'FREE',
             "during=(%s, %s)" % (during[0][3], during[0][4]))
        s.apply_numeric(30.0)
        s.cancel()
        after = read(act, o)
        step("★ C: %s 取消后类型恢复原样" % htype,
             (after[0][3], after[0][4]) == t_before,
             "%s -> %s" % (t_before, (after[0][3], after[0][4])))
        worst = max(abs(after[i][k] - before[i][k]) for i in before for k in range(3))
        step("★ C: %s 取消后数值精确还原" % htype, worst < 1e-6,
             "max偏差=%.10f" % worst)

    # =========================================================
    # D. G（移动）不受影响
    # =========================================================
    for htype in ('FREE', 'AUTO_CLAMPED'):
        o, act = build(htype)
        select_one(act, o)
        b0 = read(act, o)
        s = me.MoveSession('MOVE')
        if not s.begin(o, act, region, rv3d, 600.0, 400.0):
            step("D: %s G begin" % htype, False, s.message); continue
        s.apply_numeric(2.0)
        b1 = read(act, o)
        d_co = max(abs(b1[i][0] - b0[i][0]) for i in b0)
        step("D: %s G 移动生效（Δco=%.6f）" % (htype, d_co), abs(d_co - 2.0) < 1e-4,
             "Δco=%.6f" % d_co)
        s.cancel()

    # =========================================================
    # E. 缩放同理
    # =========================================================
    for htype in ('FREE', 'AUTO_CLAMPED'):
        o, act = build(htype)
        select_one(act, o)
        b0 = read(act, o)
        s = me.ScaleSession('SCALE')
        if not s.begin(o, act, region, rv3d, 600.0, 400.0):
            step("E: %s S begin" % htype, False, s.message); continue
        s.apply_numeric(2.0)
        b1 = read(act, o)
        d_h = max(max(abs(b1[i][1] - b0[i][1]), abs(b1[i][2] - b0[i][2])) for i in b0)
        step("★ E: %s 单点缩放生效（Δhandle=%.6f）" % (htype, d_h), d_h > 1e-4,
             "Δhandle=%.6f" % d_h)
        s.cancel()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("HANDLE_TYPE_CHECK_DONE")
os._exit(0)
