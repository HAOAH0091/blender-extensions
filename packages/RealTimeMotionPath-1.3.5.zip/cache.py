import bpy
import mathutils
from .state import _session, _cache_update_lock, SAFE_LIMIT


def _resolve_slot(action, obj=None):
    """决定读取哪个 slot：优先对象自己的 action_slot，否则第 0 个。

    Blender 4.4+ 起，一个 action 可含多个 slot（可被多个对象共享，各用一个）。
    不按对象区分的话，共享同一 action 时第二个对象会读到第一个的数据。
    """
    if action is None:
        return None
    try:
        action_slots = action.slots
        if not action_slots:
            return None

        target_slot = action_slots[0]

        if obj is not None:
            ad = getattr(obj, "animation_data", None)
            if ad is not None and getattr(ad, "action", None) is action:
                obj_slot = getattr(ad, "action_slot", None)
                if obj_slot is not None:
                    target_slot = obj_slot

        return target_slot
    except Exception:
        return None


def _fcurves_collection(action, obj=None, ensure=False):
    """取底层曲线集合（原生 bpy_prop_collection，支持 .new()），失败返回 None。

    ensure=True   channelbag 不存在时创建 —— 写路径（新建曲线）需要。
    ensure=False  只读，不存在返回 None —— 避免读取时产生副作用。
    """
    if action is None:
        return None
    try:
        target_slot = _resolve_slot(action, obj)
        if target_slot is None:
            return None

        action_layers = action.layers
        if not action_layers:
            return None

        target_layer = action_layers[0]
        if not target_layer.strips:
            return None

        target_strip = target_layer.strips[0]
        channel_container = target_strip.channelbag(target_slot, ensure=ensure)

        if channel_container is None:
            return None

        return channel_container.fcurves
    except Exception:
        return None


def collect_animation_curves(action, obj=None):
    """以「只读快照」（普通 list）返回动画曲线集合，供遍历与求值使用。

    注意：list 没有 .new()。若要新建曲线，请用 get_writable_fcurves()。
    """
    collection = _fcurves_collection(action, obj, ensure=False)
    if collection is None:
        return []
    try:
        return list(collection)
    except Exception:
        return []


def get_writable_fcurves(action, obj=None):
    """返回可直接 .new() 的原生曲线集合，供新建 F-Curve 使用。

    collect_animation_curves() 返回的是 list 快照，没有 .new()；
    需要新建曲线时用本函数（channelbag 不存在会被创建）。
    不可用时返回 None。
    """
    return _fcurves_collection(action, obj, ensure=True)


def is_position_animation(fcurve, target_bone=None):
    """判断动画曲线是否控制位置属性"""
    expected_path = 'location'
    if target_bone is not None:
        expected_path = f'pose.bones["{target_bone}"].location'
    
    return fcurve.data_path == expected_path


def frame_has_keyframe(curves_collection, frame_number, target_bone=None):
    """检查指定帧是否存在关键帧"""
    for curve in curves_collection:
        if is_position_animation(curve, target_bone):
            for keypoint in curve.keyframe_points:
                # ⚠️ 容差 1e-3（不是 0.5）：关键帧可只相隔 0.4 帧，0.5 会误匹配相邻帧
                if abs(keypoint.co[0] - frame_number) < 1e-3:
                    return True
    return False


def compute_motion_positions(obj, action, frame_list, target_bone=None):
    """从动画曲线计算指定帧的位置数据"""
    position_data = {}
    
    relevant_curves = [curve for curve in collect_animation_curves(action, obj) if is_position_animation(curve, target_bone)]
    
    curves_by_axis = {}
    for curve in relevant_curves:
        curves_by_axis[curve.array_index] = curve
        
    if target_bone:
        if target_bone in obj.pose.bones:
            base_values = obj.pose.bones[target_bone].location.copy()
        else:
            base_values = mathutils.Vector((0, 0, 0))
        delta_offset = mathutils.Vector((0, 0, 0))
    else:
        base_values = obj.location.copy()
        delta_offset = obj.delta_location
    
    for frame in frame_list:
        computed_pos = base_values.copy()
        for axis in range(3):
            if axis in curves_by_axis:
                computed_pos[axis] = curves_by_axis[axis].evaluate(frame)
        
        computed_pos = computed_pos + delta_offset
        
        position_data[frame] = {
            'position': computed_pos
        }
        
    return position_data


FRAME_INT_EPS = 1e-4
"""判定"帧号是不是整数帧"的容差。

★ 2026-09-18（盲审 S1）：本插件**按整数帧建模**（`int(kp.co[0])`），
  实测：F-Curve 上是 [1.0, 14.0, 14.4, 27.0] 四个关键帧，
  插件 cache 只拿到 [1, 14, 27] —— **14.4 被 int() 截成 14 后与 14.0 合并**，
  后写覆盖先写 ⇒ 该关键帧的路径点与手柄点**静默消失**（用户看不到任何提示）。

  这是**架构性选择**（写入路径同样按整数帧匹配：`abs(kp.co[0]-frame) < FRAME_EPS`），
  经用户 2026-09-18 拍板：**不支持子帧关键帧**。
  ⇒ 既然不支持，就**不能静默吞** —— 检测到就明确告诉用户，
     别让他对着一条"少了半个关键帧"的路径猜原因。
"""


def detect_subframe_keyframes(context):
    """检测当前可编辑对象上是否存在**非整数帧**关键帧（本插件不支持）。

    返回 `(count, examples)`：`count` = 被并掉的子帧关键帧个数，
    `examples` = 最多 3 个帧号的示例（用于提示文案）。
    检测失败一律返回 `(0, [])`（本函数只做提示，绝不影响主流程）。
    """
    try:
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return 0, []
        action = obj.animation_data.action
        bone_name = None
        if obj.mode == 'POSE':
            bone = context.active_pose_bone
            bone_name = bone.name if bone else None
        seen = set()
        total, examples = 0, []
        for curve in collect_animation_curves(action, obj):
            if not is_position_animation(curve, bone_name):
                continue
            for kp in curve.keyframe_points:
                f = float(kp.co[0])
                # 同一帧号会在 x/y/z 三条曲线上各出现一次 ⇒ 去重后再计数
                if abs(f - round(f)) > FRAME_INT_EPS and f not in seen:
                    seen.add(f)
                    total += 1
                    if len(examples) < 3:
                        examples.append(f)
        return total, examples
    except Exception:
        return 0, []


def refresh_position_store(context):
    """刷新位置缓存存储"""
    global _session, _cache_update_lock
    
    if _cache_update_lock:
        return
        
    _cache_update_lock = True
    
    try:
        _session.cached_positions = {}
        _session.path_point_sequence = {}

        # ★ 盲审 S1：先记下"被 int() 并掉的子帧关键帧"数量，供 UI 提示。
        #   放在最前，保证即使后面 return 也已有值；只读、不改动任何数据。
        _session.subframe_keyframe_count, _session.subframe_keyframe_examples = \
            detect_subframe_keyframes(context)
        
        if hasattr(context.window_manager, 'skip_motion_path_cache'):
            if context.window_manager.skip_motion_path_cache:
                return
        
        obj = context.active_object
        wm = context.window_manager
        frame_start = context.scene.frame_start
        frame_end = context.scene.frame_end
        frames_range = range(frame_start, frame_end + 1)
        
        if obj and obj.mode == 'POSE':
            if not obj.animation_data or not obj.animation_data.action:
                return
            action = obj.animation_data.action
            obj_name = obj.name
            
            bones_to_process = set(context.selected_pose_bones or [])
            if context.active_pose_bone:
                bones_to_process.add(context.active_pose_bone)

            for bone in bones_to_process:
                try:
                    bone_name = bone.name
                    curves = [curve for curve in collect_animation_curves(action, obj) if is_position_animation(curve, bone_name)]
                    frames = set(int(kp.co[0]) for curve in curves for kp in curve.keyframe_points
                                 if frame_start <= kp.co[0] <= frame_end)
                    if not frames:
                        continue
                    position_data = compute_motion_positions(obj, action, frames, target_bone=bone_name)
                    _session.cached_positions.setdefault(obj_name, {})[bone_name] = position_data
                    
                    if wm.rtmp_path_display_enabled:
                        dense_data = compute_motion_positions(obj, action, frames_range, target_bone=bone_name)
                        _session.path_point_sequence[(obj_name, bone_name)] = [dense_data[f]['position'] for f in frames_range]
                except Exception:
                    continue
        else:
            objects_to_process = list(context.selected_objects or [])
            if obj and obj not in objects_to_process:
                objects_to_process.append(obj)
            
            for cache_obj in objects_to_process:
                try:
                    if not cache_obj.animation_data or not cache_obj.animation_data.action:
                        continue
                    action = cache_obj.animation_data.action
                    obj_name = cache_obj.name
                    
                    curves = [curve for curve in collect_animation_curves(action, cache_obj) if is_position_animation(curve)]
                    frames = sorted(set(int(kp.co[0]) for curve in curves for kp in curve.keyframe_points
                                 if frame_start <= kp.co[0] <= frame_end))
                    if not frames:
                        continue
                    position_data = compute_motion_positions(cache_obj, action, frames)
                    _session.cached_positions.setdefault(obj_name, {})[None] = position_data
                    
                    if wm.rtmp_path_display_enabled:
                        dense_data = compute_motion_positions(cache_obj, action, frames_range)
                        _session.path_point_sequence[(obj_name, None)] = [dense_data[f]['position'] for f in frames_range]
                except Exception:
                    continue
     
    finally:
        _cache_update_lock = False


def resolve_parent_transform(obj, bone=None):
    """解析父级变换矩阵"""
    try:
        if obj.mode == 'POSE' and bone:
            if bone.parent:
                parent_to_child_rest = bone.parent.bone.matrix_local.inverted() @ bone.bone.matrix_local
                return obj.matrix_world @ bone.parent.matrix @ parent_to_child_rest
            else:
                return obj.matrix_world @ bone.bone.matrix_local
        else:
            if obj.parent is None:
                return mathutils.Matrix.Identity(4)
            else:
                parent_mat = obj.parent.matrix_world.copy()
                if obj.parent_type == 'BONE' and obj.parent_bone:
                    if obj.parent.pose and obj.parent_bone in obj.parent.pose.bones:
                        pb = obj.parent.pose.bones[obj.parent_bone]
                        # Blender 把 bone-parented 物体挂在骨骼的【尾部】(tail)，
                        # 而 pb.matrix 是骨骼【头部】(head) 的矩阵，两者相差一个骨长。
                        # 需再沿骨骼 Y 轴平移 pb.bone.length 才是物体真正的父级变换。
                        parent_mat = (obj.parent.matrix_world @ pb.matrix
                                      @ mathutils.Matrix.Translation((0, pb.bone.length, 0)))
                return parent_mat @ obj.matrix_parent_inverse
    except Exception:
        return mathutils.Matrix.Identity(4)
