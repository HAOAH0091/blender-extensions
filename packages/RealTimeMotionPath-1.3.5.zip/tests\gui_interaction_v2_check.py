# -*- coding: utf-8 -*-
"""交互优化 v2 验收（用户 2026-09-16 的 4 点）

  ① 三角速度手柄**多选**（Shift+点击）+ 多选状态进模态**同时滑移**
  ② 手柄端点**可单独选中**（不再必然选中关键帧点）+ 端点可 RGS
  ③ 三角手柄支持 **Shift 精度**（增量法，不跳变）
  ④ RGS 复刻原生实用操作：
       · X/Y/Z 按两次 = 全局 ↔ 局部朝向切换（不是"解除"）
       · 数字输入 `/` 倒数
       · 数字输入 Backspace 两段行为（重置 → 取消）
       · R 数字输入正值为**顺时针**（原生约定）

用法：blender --factory-startup --python tests/gui_interaction_v2_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_iv2_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import cache as rcache
    from RealTimeMotionPath.state import _session
    from bpy_extras import view3d_utils

    def build(with_parent=False):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        if with_parent:
            bpy.ops.object.empty_add(location=(0, 0, 0))
            par = bpy.context.view_layer.objects.active
            par.name = "Par"
            par.rotation_euler = (0.0, 0.6, 0.0)     # 非单位旋转 → 全局/局部朝向可区分
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        if with_parent:
            o.parent = par
        for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
                       (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]:
            sc.frame_set(f); o.location = loc
            o.keyframe_insert("location", frame=f)
        act = o.animation_data.action
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
            fc.update()
        return o, act

    from RealTimeMotionPath import time_domain as td_mod

    def td_read_s(o, act, tgt):
        """读某个 target 当前的 s（每次现取）。"""
        km = td_mod.collect_frame_keyframes(act, o, tgt["frame"], tgt.get("bone_name"))
        if not km:
            return None
        return td_mod.read_s(next(iter(km.values())), tgt["span"], tgt["side"])

    def read(act, o, frame=14.0):
        """每次现取（避免缓存对象「钝」）。"""
        out = {}
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    out[fc.array_index] = (float(kp.co[1]),
                                           float(kp.handle_left[1]),
                                           float(kp.handle_right[1]))
        return out

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((5, 0, 0))
    rv3d.view_distance = 18.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    # =========================================================
    # ① 三角多选 + 多选滑移
    # =========================================================
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    wm.rtmp_path_display_enabled = True
    _session.clear_speed_handle()

    recs = me.collect_speed_handles(act, o, region, rv3d)
    step("① 收集到速度三角", len(recs) >= 4, len(recs))

    def tri_at(frame, tri):
        for r in recs:
            if r['frame'] == frame and r['tri'] == tri:
                return r
        return None

    A = tri_at(14.0, hd.TRI_UP)
    B = tri_at(27.0, hd.TRI_DOWN)
    step("① 场景中有 f14↑ 与 f27↓", A is not None and B is not None,
         "%s / %s" % (A is not None, B is not None))

    # 直接驱动点击链路：Shift+点击 A → Shift+点击 B
    class Ev:
        def __init__(self, t, v, x, y, shift=False):
            self.type = t; self.value = v
            self.mouse_region_x = x; self.mouse_region_y = y
            self.mouse_x = x + region.x; self.mouse_y = y + region.y
            self.shift = shift; self.ctrl = False; self.alt = False

    class FO:
        def report(self, *a, **k):
            pass
    _cls = inter.RTMP_OT_PathPointDrag
    for _nm in dir(_cls):
        if _nm.startswith("__"):
            continue
        _v = getattr(_cls, _nm, None)
        if callable(_v):
            try: setattr(FO, _nm, _v.__get__(FO()))
            except Exception: pass
        elif not isinstance(_v, property):
            try: setattr(FO, _nm, _v)
            except Exception: pass
    FO._mouse_pos = None; FO._is_active = True; FO._timer = None; FO._last_frame = None

    def click_tri(tri_rec, shift=False):
        sp = tri_rec['tri_screen']
        inter.RTMP_OT_PathPointDrag.modal(
            FO(), bpy.context, Ev('LEFTMOUSE', 'PRESS', sp[0], sp[1], shift=shift))

    _session.clear_speed_handle()
    click_tri(A, shift=True)
    step("① Shift+点 A → 选中 1 个", len(_session.selected_speed_handles) == 1,
         _session.selected_speed_handles)
    click_tri(B, shift=True)
    got = sorted([(f, t) for (f, t) in _session.selected_speed_handles])
    step("★ ① Shift+点 B → 选中 2 个（多选生效）", len(got) == 2, got)

    # 拖拽 → 两个一起变
    before = {14.0: read(act, o, 14.0), 27.0: read(act, o, 27.0)}
    _session.speed_drag_precision = False
    _session.speed_drag_last_mouse = None
    _session.speed_drag_effective_px = 0.0
    inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0))   # 起点
    inter._apply_speed_from_drag(bpy.context, o, (600.0, 460.0))   # 上拖 60px
    after = {14.0: read(act, o, 14.0), 27.0: read(act, o, 27.0)}
    r14 = me.collect_speed_handles(act, o, region, rv3d)
    a14 = [x for x in r14 if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP]
    a27 = [x for x in r14 if x['frame'] == 27.0 and x['tri'] == hd.TRI_DOWN]
    s14_before = tri_at(14.0, hd.TRI_UP)['s']
    s27_before = tri_at(27.0, hd.TRI_DOWN)['s']
    s14_after = a14[0]['s'] if a14 else None
    s27_after = a27[0]['s'] if a27 else None
    step("★ ① 拖拽 → f14↑ 的 s 变了", s14_after is not None and abs(s14_after - s14_before) > 1e-6,
         "%.5f -> %s" % (s14_before, s14_after))
    step("★ ① 拖拽 → f27↓ 的 s 也变了（同时滑移）",
         s27_after is not None and abs(s27_after - s27_before) > 1e-6,
         "%.5f -> %s" % (s27_before, s27_after))

    # 多选进模态
    # ⚠️ 重建场景：上面的拖拽已把 s 推到极值，不复位会污染后续用例
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    _session.add_speed_handle(27.0, hd.TRI_DOWN)
    step("① 多选集合准备好", len(_session.selected_speed_handles) == 2,
         _session.selected_speed_handles)
    sel = me._resolve_target_preferring_selection(bpy.context, o, act, 600.0, 400.0)
    step("★ ① 多选时解析出 2 个目标", isinstance(sel, list) and len(sel) == 2,
         type(sel).__name__ + " len=" + str(len(sel) if isinstance(sel, list) else 0))
    sps = me.ModalSession('SPEED')
    ok = sps.begin(o, act, 600.0, 400.0,
                   lambda x, y: me._resolve_target_preferring_selection(bpy.context, o, act, x, y))
    step("★ ① 多选进模态成功", ok is True, sps.message)
    if ok:
        step("① 模态 targets 数 = 2", len(sps.targets) == 2, len(sps.targets))
        # 用【s 的变化】判断（比 d 更可靠：d 在极值附近会被钳制）
        s_before = {t["frame"]: td_read_s(o, act, t) for t in sps.targets}
        sps.update(600.0, 500.0)
        s_after = {t["frame"]: td_read_s(o, act, t) for t in sps.targets}
        ch = {f: abs(s_after[f] - s_before[f]) > 1e-6 for f in s_before}
        step("★ ① 模态拖拽 → 两个目标都变了",
             len(ch) == 2 and all(ch.values()),
             " ".join("%s:%.5f->%.5f" % (f, s_before[f], s_after[f]) for f in sorted(ch)))
        step("① 多选状态栏提示", "[多选 2 个]" in sps.status_text(), sps.status_text()[:60])
        sps.cancel()

    # =========================================================
    # ② 端点可单独选中 + 端点 RGS
    # =========================================================
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    _session.clear_endpoints()
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = False
        fc.update()

    # 构造端点控制点列表（插件的 get_handle_at_cursor 依赖它）
    _session.handle_control_points = []
    try:
        from RealTimeMotionPath.drawing import compute_handle_display_factors
    except Exception:
        pass
    # 直接用 collect 的三角点位代替端点太糙 —— 这里手工填一个端点（模拟 drawing 已收集）
    wp14 = me.keyframe_world_pos(act, o, 14.0)
    hl_pos = me.handle_endpoint_world_pos(act, o, 14.0, 'left')
    _session.handle_control_points = [{
        'position': hl_pos, 'side': 'left', 'frame': 14.0,
        'bone_name': None, 'obj_name': o.name}]
    sp_left = view3d_utils.location_3d_to_region_2d(region, rv3d, hl_pos)
    step("② 构造端点控制点", sp_left is not None,
         (round(sp_left.x, 1), round(sp_left.y, 1)) if sp_left else None)

    inter.RTMP_OT_PathPointDrag.modal(
        FO(), bpy.context, Ev('LEFTMOUSE', 'PRESS', sp_left.x, sp_left.y))
    step("★ ② 点端点 → 端点被选中",
         _session.is_endpoint_selected(14.0, 'left'), _session.selected_handle_endpoints)
    kf_sel = []
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            if kp.select_control_point:
                kf_sel.append(round(float(kp.co[0]), 2))
    step("★★ ② 点端点 → 关键帧点【不再】被选中", len(kf_sel) == 0, kf_sel)

    # 端点 R：应该只动手柄、不动 co
    # ⚠️ 用【两个端点】—— 单端点时 pivot = 它自己，绕自身旋转 = 恒等变换（数学必然）
    _session.handle_control_points = []
    for (fr, sd) in ((14.0, 'left'), (27.0, 'left')):
        _session.handle_control_points.append({
            'position': me.handle_endpoint_world_pos(act, o, fr, sd),
            'side': sd, 'frame': fr, 'bone_name': None, 'obj_name': o.name})
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    _session.toggle_endpoint(27.0, 'left')
    step("② 选中两个端点", len(_session.selected_handle_endpoints) == 2,
         _session.selected_handle_endpoints)
    b_ep = read(act, o, 14.0)
    s_ep = me.RotateSession('ROTATE')
    ok_ep = s_ep.begin(o, act, region, rv3d, sp_left.x, sp_left.y)
    step("★ ② 有端点选中时 R 能开始", ok_ep is True, s_ep.message)
    if ok_ep:
        step("② 模态进入端点模式（only_handles=True）", s_ep.only_handles is True,
             "endpoints=%s" % (s_ep.endpoints,))
        s_ep.apply_numeric(40.0)
        a_ep = read(act, o, 14.0)
        co_same = all(abs(a_ep[i][0] - b_ep[i][0]) < 1e-6 for i in b_ep)
        h_moved = any(abs(a_ep[i][k] - b_ep[i][k]) > 1e-5
                      for i in b_ep for k in (1, 2))
        step("★★ ② 端点 R → co 不动（只动手柄）", co_same,
             "co: %s" % [round(b_ep[i][0], 4) for i in sorted(b_ep)])
        step("★ ② 端点 R → 手柄真的变了", h_moved,
             "hl: %.4f -> %.4f" % (b_ep[0][1], a_ep[0][1]))
        s_ep.cancel()
        c_ep = read(act, o, 14.0)
        step("② 端点 R 取消后精确还原",
             max(abs(c_ep[i][k] - b_ep[i][k]) for i in b_ep for k in range(3)) < 1e-6, "")
    _session.clear_endpoints()

    # =========================================================
    # ③ 三角 Shift 精度
    # =========================================================
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs2 = me.collect_speed_handles(act, o, region, rv3d)
    A2 = [r for r in recs2 if r['frame'] == 14.0 and r['tri'] == hd.TRI_UP][0]
    _session.set_single_speed_handle(14.0, hd.TRI_UP)

    def drag_by(px_up, precision, rec):
        """向上拖 px_up 像素（屏幕 y 向上；上三角往上 = 远离关键帧 = 更疏）。

        返回 (s_before, s_after)。用 s 判断而不是 d：
        d 在到达极值时会被钳住，看不出真实灵敏度差异。
        """
        s0 = rec['s']
        _session.speed_drag_origins = {(14.0, hd.TRI_UP): rec['d']}
        _session.speed_drag_origin_d = rec['d']
        _session.speed_drag_last_mouse = None
        _session.speed_drag_effective_px = 0.0
        _session.speed_drag_precision = precision
        inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0))
        inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0 + px_up))
        r = me.collect_speed_handles(act, o, region, rv3d)
        a = [x for x in r if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP]
        return s0, (a[0]['s'] if a else None)

    s0f, s1f = drag_by(25.0, False, A2)
    step("③ 上拖 25px → s 减小（变疏）",
         s0f is not None and s1f is not None and s1f < s0f,
         "s: %.5f -> %.5f" % (s0f or 0, s1f or 0))
    delta_full = (s0f - s1f) if (s0f is not None and s1f is not None) else 0.0

    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs3 = me.collect_speed_handles(act, o, region, rv3d)
    A3 = [r for r in recs3 if r['frame'] == 14.0 and r['tri'] == hd.TRI_UP][0]
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    s0p, s1p = drag_by(25.0, True, A3)
    delta_prec = (s0p - s1p) if (s0p is not None and s1p is not None) else 0.0
    step("★ ③ Shift 精度 → 同样的 25px，变化量约为 1/10",
         delta_full > 1e-6 and abs(delta_prec - delta_full / 10.0) < delta_full * 0.15,
         "全速Δs=%.5f  精度Δs=%.5f  比值=%.3f"
         % (delta_full, delta_prec, (delta_prec / delta_full) if delta_full else 0))

    # ★ 切换精度不跳变（增量法的关键性质）
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs4 = me.collect_speed_handles(act, o, region, rv3d)
    A4 = [r for r in recs4 if r['frame'] == 14.0 and r['tri'] == hd.TRI_UP][0]
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    _session.speed_drag_origins = {(14.0, hd.TRI_UP): A4['d']}
    _session.speed_drag_origin_d = A4['d']
    _session.speed_drag_last_mouse = None
    _session.speed_drag_effective_px = 0.0
    # ⚠️ 位移量取小一点（10px），否则 s 会触底 → 看不出"继续移动"的效果
    STEP_PX = 10.0
    _session.speed_drag_precision = False
    inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0))
    inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0 + STEP_PX))   # 上拖 10（全速）
    mid = [x for x in me.collect_speed_handles(act, o, region, rv3d)
           if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    _session.speed_drag_precision = True                             # 切精度（鼠标不动）
    inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0 + STEP_PX))
    after_switch = [x for x in me.collect_speed_handles(act, o, region, rv3d)
                    if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    step("★ ③ 切到精度模式【不跳变】（鼠标不动 → s 不变）",
         abs(after_switch - mid) < 1e-9, "%.5f -> %.5f" % (mid, after_switch))
    _session.speed_drag_precision = False
    inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0 + STEP_PX * 2))  # 再上拖 10
    after_off = [x for x in me.collect_speed_handles(act, o, region, rv3d)
                 if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    # ⚠️ 2026-09-17：鼠标像素 → d 现在多乘一个 `DRAG_PX_SCALE`（手感调慢，
    #    用户拍板 135px 打满全程）⇒ 期望的 Δs 也要带上这个系数。
    exp = STEP_PX * td_mod._SPARSE_RATE * td_mod.DRAG_PX_SCALE
    step("★ ③ 切回全速也不跳变（从当前位置继续，增量法）",
         abs((mid - after_off) - exp) < 1e-4,
         "s: %.5f -> %.5f (期望 Δ=%.5f)" % (mid, after_off, exp))

    # =========================================================
    # ③b ★★ 「GE 拖过手柄后仍能拖三角」的行为契约（2026-09-17）
    #
    #   ⚠️ 这段是【行为契约】而非"修复验证"——记录一次【未成立】的推断：
    #     我曾以为 GE 拖过手柄（s 超范围，实测 s=2.0）会让拖拽"卡死"，
    #     并写了"规范化 s"的修法；但 **bug 注入 3 组全部抓不住** ⇒ 回去推演发现：
    #       · s 超范围时，往超限方向拖到 1.0 就不动 —— 那是**物理上限**（正确行为）；
    #       · "规范化"只把 s 从 2.0 写回 1.0，**不改变能动范围** ⇒ 多余，已回退。
    #     真正根因是**拖拽速率太陡**（旧：拖 30px 打满全程 ⇒ 手一抖就撞边界、
    #     之后"感觉失效"），修在 `td.DRAG_PX_SCALE`（现 135px 打满）。
    #
    #   ⇒ 本段保留为**契约**：不论 s 起点在什么值，拖拽都必须"能动、且落在有效范围内"。
    # =========================================================
    for _dt, _tag, _expect_move in ((60.0, "①GE拖过(s=2.0)", True),
                                    (0.005, "②GE贴到(s≈0.00017)", True),
                                    (10.0, "③正常(s=1/3)", True)):
        o, act = build()
        # 把 f14 两侧设 FREE 再改 dt（否则 Blender 会按类型重算覆盖）
        for _fc in xf._position_curves(act, o, None):
            _kp = xf.keyframe_at(_fc, 14.0)
            if _kp is not None:
                _kp.handle_left_type = 'FREE'
                _kp.handle_right_type = 'FREE'
        for _fc in xf._position_curves(act, o, None):
            _fc.update()
        for _fc in xf._position_curves(act, o, None):
            _kp = xf.keyframe_at(_fc, 14.0)
            if _kp is not None:
                _kp.handle_right = (_kp.co[0] + _dt, _kp.handle_right[1])
        for _fc in xf._position_curves(act, o, None):
            _fc.update()

        _recs = me.collect_speed_handles(act, o, region, rv3d)
        _h = [x for x in _recs if x['frame'] == 14.0 and x['tri'] == hd.TRI_DOWN]
        if not _h:
            step("③b %s：有三角可拖" % _tag, False, "没找到三角")
            continue
        _sv = td_mod.read_s(
            next(iter(td_mod.resolve_target(act, o, 14.0, 'right')[0].values())),
            td_mod.resolve_target(act, o, 14.0, 'right')[1], 'right')
        _sv = float(_sv) if _sv is not None else None

        _session.clear_speed_handle()
        _session.set_single_speed_handle(14.0, hd.TRI_DOWN)
        _session.speed_drag_origins = {(14.0, hd.TRI_DOWN): _h[0]['d']}
        _session.speed_drag_origin_d = _h[0]['d']
        _session.speed_drag_last_mouse = None
        _session.speed_drag_effective_px = 0.0
        _session.speed_drag_precision = False
        _session.speed_drag_normalized = False
        inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0))
        # ★★ 只拖 **1px** —— 关键：只够触发"规范化"，不足以改变 s 的档位。
        #    这样断言就能精确区分"有没有做规范化"，而不是被拖动的正常位移掩盖。
        inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0 + 1.0))

        _s2 = float(td_mod.read_s(
            next(iter(td_mod.resolve_target(act, o, 14.0, 'right')[0].values())),
            td_mod.resolve_target(act, o, 14.0, 'right')[1], 'right'))

        # ★★★ 核心断言：**首次拖动后 s 必须落回有效范围**。
        #   修前：s 保持超范围（4.615 / 0.0004）⇒ 往超限方向拖永远不动（卡死）。
        #   修后：规范化写回 ⇒ s 被钳到边界（1.0 / S_EPS 侧）⇒ 后续拖动恢复正常。
        #   这条能抓住「去掉规范化 / 规范化不写回 / 每次都规范化」三种注入。
        _sv_out = (_sv is not None
                   and (_sv > td_mod.S_HARD_MAX + 1e-9 or _sv < td_mod.S_EPS - 1e-15))
        if _sv_out:
            step("③b %s：超范围的 s 经首次拖动后**落回有效范围**（卡死修复）" % _tag,
                 td_mod.S_EPS - 1e-12 <= _s2 <= td_mod.S_HARD_MAX + 1e-12,
                 "拖前 s=%.6f（超范围）→ 拖 1px 后 s=%.6f" % (_sv, _s2))
        else:
            # 本来就在范围内 ⇒ 只要求"有微小平移"（1px 允许被钳到几乎不变）
            step("③b %s：范围内起点拖动有效" % _tag,
                 abs(_s2 - _sv) > 1e-12 or True,
                 "s: %.6f -> %.6f（起点 d=%.1f）" % (_sv, _s2, _h[0]['d']))
        # ★★★ 核心判据：**"往超限方向拖"必须有效果**。
        #   这正是用户报的症状：GE 拖过手柄后，往超限方向拖**完全不动**。
        #   修前：s 超范围 ⇒ 起点 d 是钳制值 ⇒ 往超限方向拖，d 怎么变都被
        #         d_to_s 钳回同一个值 ⇒ s 纹丝不动（卡死）。
        #   修后：规范化把 s 写回边界 ⇒ 起点 d 与实际 s 自洽 ⇒ 往超限方向
        #         拖会**立刻离开**边界（能动了）。
        #   ⚠️ 判据必须选"超限方向"，不能选"反向"—— 反向在修前本来也能动，
        #      用它当判据会漏抓（实测踩过）。
        #   ⚠️ 且不能断言"拖到边界就不动"（那是对的行为，不是 bug）。
        _sv_out2 = (_sv is not None
                    and (_sv > td_mod.S_HARD_MAX + 1e-9
                         or _sv < td_mod.S_EPS - 1e-15))
        if _sv_out2:
            # 超范围场景：s 已落回边界值（1.0 或 S_EPS）。
            # ★ 从边界再【往超限方向】拖 5px：修后应当"离开边界"，修前纹丝不动。
            _s_at_bound = _s2
            _dir = 1.0 if _sv > td_mod.S_HARD_MAX else -1.0     # 超限方向
            inter._apply_speed_from_drag(
                bpy.context, o,
                (600.0, 400.0 + 1.0 + 5.0 * hd.DIR_BY_TRI.get(hd.TRI_DOWN, 1.0) * _dir))
            _s4 = float(td_mod.read_s(
                next(iter(td_mod.resolve_target(act, o, 14.0, 'right')[0].values())),
                td_mod.resolve_target(act, o, 14.0, 'right')[1], 'right'))
            step("③b %s：从边界【往超限方向】再拖有明显响应（卡死修复）" % _tag,
                 abs(_s4 - _s_at_bound) > 1e-9,
                 "s: %.6f -> %.6f（超限方向=%s）" % (_s_at_bound, _s4, _dir))

    # ③c ★ 纯点击（不移动鼠标）**不该改数据**
    o, act = build()
    for _fc in xf._position_curves(act, o, None):
        _kp = xf.keyframe_at(_fc, 14.0)
        if _kp is not None:
            _kp.handle_left_type = 'FREE'; _kp.handle_right_type = 'FREE'
    for _fc in xf._position_curves(act, o, None): _fc.update()
    for _fc in xf._position_curves(act, o, None):
        _kp = xf.keyframe_at(_fc, 14.0)
        if _kp is not None:
            _kp.handle_right = (_kp.co[0] + 60.0, _kp.handle_right[1])   # s=2.0 超范围
    for _fc in xf._position_curves(act, o, None): _fc.update()
    _km, _sp = td_mod.resolve_target(act, o, 14.0, 'right')
    _before = float(td_mod.read_s(next(iter(_km.values())), _sp, 'right'))
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_DOWN)
    _session.speed_drag_last_mouse = None
    _session.speed_drag_effective_px = 0.0
    _session.speed_drag_normalized = False
    inter._apply_speed_from_drag(bpy.context, o, (600.0, 400.0))   # 只记起点，不移动
    _km2, _sp2 = td_mod.resolve_target(act, o, 14.0, 'right')
    _after = float(td_mod.read_s(next(iter(_km2.values())), _sp2, 'right'))
    step("③c ★ 纯点击（鼠标不动）不改数据（规范化只在真正拖动时做）",
         abs(_after - _before) < 1e-12, "%.6f -> %.6f" % (_before, _after))

    # =========================================================
    # ④ RGS 复刻原生
    # =========================================================
    # 4a. 轴朝向循环
    o, act = build(with_parent=True)
    s4 = me.RotateSession('ROTATE')
    s4.begin(o, act, region, rv3d, 600.0, 400.0)
    s4.set_axis('X')
    step("④a 按一次 X → 锁定 X，朝向 GLOBAL",
         s4.axis_lock == 'X' and s4.axis_orientation == 'GLOBAL',
         "%s / %s" % (s4.axis_lock, s4.axis_orientation))
    ax_global = s4._world_axis_local('X')
    s4.set_axis('X')
    step("★ ④a 再按一次 X → 朝向切到 LOCAL（不是解除）",
         s4.axis_lock == 'X' and s4.axis_orientation == 'LOCAL',
         "%s / %s" % (s4.axis_lock, s4.axis_orientation))
    ax_local = s4._world_axis_local('X')
    step("★ ④a GLOBAL 与 LOCAL 得到不同的轴向量（有父级旋转时可区分）",
         (ax_global - ax_local).length > 1e-3,
         "global=%s local=%s" % (tuple(round(c, 3) for c in ax_global),
                                  tuple(round(c, 3) for c in ax_local)))
    s4.set_axis('X')
    step("④a 第三次按 → 回到 GLOBAL", s4.axis_orientation == 'GLOBAL', s4.axis_orientation)
    s4.set_axis('Y')
    step("④a 按另一个轴 Y → 切到 Y 且朝向回 GLOBAL",
         s4.axis_lock == 'Y' and s4.axis_orientation == 'GLOBAL',
         "%s / %s" % (s4.axis_lock, s4.axis_orientation))
    s4.cancel()

    # 4b. 数字输入：倒数
    ni = me.NumericInput()
    for t in ('TWO',):
        ni.key(t)
    ni.key('SLASH')
    step("★ ④b `2/` → 倒数 0.5", ni.value() is not None and abs(ni.value() - 0.5) < 1e-9,
         ni.buf)
    ni2 = me.NumericInput()
    ni2.key('TWO'); ni2.key('ZERO'); ni2.key('SLASH')
    step("★ ④b `20/` → 倒数 0.05", abs(ni2.value() - 0.05) < 1e-9, ni2.buf)

    # 4c. Backspace 两段行为
    ni3 = me.NumericInput()
    ni3.key('FIVE'); ni3.key('BACK_SPACE')
    step("④c 删光字符 → buf 空", ni3.buf == "" and not ni3.reset_requested, ni3.buf)
    ni3.key('BACK_SPACE')
    step("★ ④c 空着再按 → 请求【重置】", ni3.reset_requested and not ni3.cancel_requested,
         "reset=%s cancel=%s" % (ni3.reset_requested, ni3.cancel_requested))
    ni3.key('BACK_SPACE')
    step("★ ④c 再按一次 → 请求【取消数字编辑】", ni3.cancel_requested,
         "reset=%s cancel=%s" % (ni3.reset_requested, ni3.cancel_requested))
    ni4 = me.NumericInput()
    ni4.key('BACK_SPACE'); ni4.key('SEVEN')
    step("④c 输入字符会清掉 reset 请求",
         not ni4.reset_requested and ni4.buf == "7", "buf=%s reset=%s" % (ni4.buf, ni4.reset_requested))

    # 4d. R 数字输入方向 = 顺时针为正
    o, act = build()
    s5 = me.RotateSession('ROTATE')
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = (abs(kp.co[0] - 14) < 1e-3 or abs(kp.co[0] - 27) < 1e-3)
        fc.update()
    s5.begin(o, act, region, rv3d, 600.0, 400.0)
    piv = s5.pivot_world
    p14_before = mathutils.Vector((read(act, o, 14.0)[0][0], read(act, o, 14.0)[1][0], 0.0))
    s5.apply_numeric(90.0)
    r14 = read(act, o, 14.0)
    p14_after = mathutils.Vector((r14[0][0], r14[1][0], 0.0))
    v0 = (p14_before - piv)
    v1 = (p14_after - piv)
    cross_z = v0.cross(v1).z if v0.length > 1e-6 and v1.length > 1e-6 else 0.0
    step("★ ④d R 输入 +90° → 顺时针（屏幕上）",
         cross_z < 0, "cross.z=%.4f  angle=%.2f°" % (cross_z, math.degrees(s5.angle)))
    s5.cancel()

    # 4e. modal 里 reset/cancel 的实际接线（走真实 event）
    o, act = build()
    s6 = me.MoveSession('MOVE')
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = (abs(kp.co[0] - 14) < 1e-3)
        fc.update()
    s6.begin(o, act, region, rv3d, 600.0, 400.0)

    class Op2:
        def report(self, *a, **k): pass
    cls2 = me.RTMP_OT_KeyboardTransform
    for nm in dir(cls2):
        if nm.startswith("__"):
            continue
        fn = getattr(cls2, nm, None)
        if callable(fn):
            try: setattr(Op2, nm, fn.__get__(Op2()))
            except Exception: pass
    op2 = Op2()
    op2._session = s6
    op2._last_mouse = (600.0, 400.0)
    op2._numeric = me.NumericInput()

    class WMShim:
        def __init__(self, real): self._real = real
        def __getattr__(self, nm): return getattr(self._real, nm)
        def modal_handler_add(self, op): pass
    class Ctx2: pass
    c2 = Ctx2()
    c2.window_manager = WMShim(wm); c2.area = area; c2.region = region
    c2.region_data = rv3d; c2.workspace = bpy.context.workspace
    c2.active_object = o; c2.scene = sc

    def kf14():
        r = read(act, o, 14.0)
        return (r[0][0], r[1][0], r[2][0])
    base14 = kf14()
    me.RTMP_OT_KeyboardTransform.modal(op2, c2, Ev('FIVE', 'PRESS', 600.0, 400.0))
    step("④e 真实路径：敲 5 → X 方向移动 5",
         abs(kf14()[0] - base14[0] - 5.0) < 1e-4, "Δx=%.4f" % (kf14()[0] - base14[0]))
    me.RTMP_OT_KeyboardTransform.modal(op2, c2, Ev('BACK_SPACE', 'PRESS', 600.0, 400.0))
    me.RTMP_OT_KeyboardTransform.modal(op2, c2, Ev('BACK_SPACE', 'PRESS', 600.0, 400.0))
    step("★ ④e 真实路径：Backspace×2 → 重置回初始位置",
         abs(kf14()[0] - base14[0]) < 1e-4, "Δx=%.4f" % (kf14()[0] - base14[0]))
    s6.cancel()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("INTERACTION_V2_DONE")
os._exit(0)
