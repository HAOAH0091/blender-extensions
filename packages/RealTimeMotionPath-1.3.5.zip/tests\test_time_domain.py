# -*- coding: utf-8 -*-
"""time_domain 数据层验证（headless）

验证口径：
  1. 纯数学自洽（d_to_s / s_to_d 互逆、边界）
  2. 写入 s 后能读回
  3. 三轴同步写入
  4. 手柄转 FREE
  5. 路径形状【严格不变】（关键帧位置 + 曲线在关键帧处的值）
  6. 采样点疏密【真的变了】（段首帧距）
  7. 段平均守恒（帧距之和 = 段弧长）
"""
import sys, os, json

import types, importlib

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)          # 沙盒根（插件目录）
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)                       # ⚠️ 必须包上下文：cache.py 有相对导入
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    _pkg = types.ModuleType(PKG)
    _pkg.__path__ = [ADDON_DIR]
    _pkg.__package__ = PKG
    sys.modules[PKG] = _pkg

import bpy
td = importlib.import_module(PKG + ".time_domain")

KF = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
      (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]

results = []
def check(name, ok, detail=""):
    results.append(("PASS" if ok else "FAIL", name, str(detail)))
def note(name, detail=""):
    results.append(("NOTE", name, str(detail)))


# ---------------- 1. 纯数学 ----------------
for s in [0.02, 1/3, 0.5, 1.0]:
    d = td.s_to_d(s)
    back = td.d_to_s(d)
    check("math roundtrip s=%.4f" % s, abs(back - s) < 1e-9, "d=%.4f back=%.4f" % (d, back))

check("d_to_s(CV_MID)==S_LIN", abs(td.d_to_s(td.CV_MID) - td.S_LIN) < 1e-12,
      td.d_to_s(td.CV_MID))
check("d_to_s(CV_FAR) still passes reference point S_MIN",
      abs(td.d_to_s(td.CV_FAR) - td.S_MIN) < 1e-9, td.d_to_s(td.CV_FAR))
check("d_to_s(CV_NEAR) still passes reference point S_MAX",
      abs(td.d_to_s(td.CV_NEAR) - td.S_MAX) < 1e-9, td.d_to_s(td.CV_NEAR))

# ★ 用户 2026-09-15：「速度手柄不需要设置极值限制」
check("NO hard limit: d beyond CV_FAR keeps getting sparser (linear, no floor)",
      td.d_to_s(999) < td.d_to_s(td.CV_FAR),
      "d=70 -> %.6f ; d=999 -> %.8f" % (td.d_to_s(td.CV_FAR), td.d_to_s(999)))
check("NO hard limit: still > 0 (只有 dt>0 的物理下限)",
      td.d_to_s(1e6) > 0.0, td.d_to_s(1e6))
check("NO hard limit on the SPARSE side: keeps getting sparser",
      td.d_to_s(300) < td.d_to_s(td.CV_FAR),
      "d=70 -> %.6f ; d=300 -> %.8f" % (td.d_to_s(td.CV_FAR), td.d_to_s(300)))
# ★ 线性（不再指数衰减）—— 每像素变化量应恒定
_r1 = td.d_to_s(100) - td.d_to_s(101)
_r2 = td.d_to_s(300) - td.d_to_s(301)
check("★ sparse side is LINEAR (constant rate, not asymptotic)",
      abs(_r1 - _r2) < 1e-12, "rate@100=%.8f rate@300=%.8f" % (_r1, _r2))
_r3 = td.d_to_s(-5) - td.d_to_s(-6)
_r4 = td.d_to_s(-20) - td.d_to_s(-21)
check("★ dense side is LINEAR too (within range)",
      abs(_r3 - _r4) < 1e-12, "rate@-5=%.8f rate@-20=%.8f" % (_r3, _r4))
# ⚠️ 2026-09-16 修订：变密方向有【几何上限】s ≤ 1.0（dt ≤ 段长）
#    —— 超过它 f(t) 会非单调（时间折返），实测 s=1.36 出现 43 个折返采样。
#    这是"曲线有效性"边界，不是手感限制。
check("dense direction caps at the GEOMETRIC limit s=1.0 (dt<=span)",
      abs(td.d_to_s(0) - 1.0) < 1e-9 and abs(td.S_HARD_MAX - 1.0) < 1e-9,
      "d_to_s(0)=%.6f  S_HARD_MAX=%.2f" % (td.d_to_s(0), td.S_HARD_MAX))
check("d below CV_NEAR keeps getting denser up to the limit",
      td.d_to_s(-999) >= td.d_to_s(td.CV_NEAR),
      "d=14 -> %.6f ; d=-999 -> %.6f" % (td.d_to_s(td.CV_NEAR), td.d_to_s(-999)))
check("dense extreme reachable: s hits S_MAX(=1.0) at d=CV_NEAR",
      abs(td.d_to_s(td.CV_NEAR) - td.S_MAX) < 1e-9,
      "d_to_s(CV_NEAR)=%.6f" % td.d_to_s(td.CV_NEAR))
check("write_s does NOT clamp to [S_MIN, S_MAX]",
      True, "见下方真实写入用例")
check("px>0 (down) -> sparser (smaller s)", td.pixels_to_s(+30) < td.pixels_to_s(0))
check("px<0 (up)   -> denser  (larger s)", td.pixels_to_s(-30) > td.pixels_to_s(0))


# ---------------- 场地 ----------------
def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = "TestObj"
    for f, loc in KF:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    act = o.animation_data.action
    for fc in _fcs(o, act):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()
    return o, act


def _fcs(o, act):
    out = []
    for fc in td._collect_position_curves(act, o, None):
        out.append(fc)
    return out


def sample_x(o, act):
    for fc in _fcs(o, act):
        if fc.array_index == 0:
            return [round(fc.evaluate(f), 8) for f in range(1, 41)]
    return []


def seg_span_frame_dists(o, act):
    """段1（帧14→27）的逐帧距离 = 用户眼睛看到的疏密"""
    X = sample_x(o, act)
    d = [abs(X[i] - X[i - 1]) for i in range(1, 40)]
    return d[13:26]      # 帧15..27 相对前一帧的距离，共 13 个


# ---------------- 2. 匀速基线（s=1/3） ----------------
o, act = build()
kf_map, span = td.resolve_target(act, o, 14, 'right')
check("resolve_target finds 3 axes", len(kf_map) == 3, "axes=%s" % sorted(kf_map.keys()))
check("segment span = 13 frames", span == 13.0, span)

w = td.write_s(kf_map, 'right', td.S_LIN, span)
for fc in _fcs(o, act):
    fc.update()
d_lin = seg_span_frame_dists(o, act)
s_read = td.read_s(kf_map[0], span, 'right')
check("write s=1/3 then read back", abs(s_read - td.S_LIN) < 1e-6, "read=%.8f" % s_read)
check("uniform baseline: first ~= last",
      abs(d_lin[0] - d_lin[-1]) < 1e-5, "first=%.6f last=%.6f" % (d_lin[0], d_lin[-1]))


# ---------------- 3. 写 s=0.02（最疏） ----------------
o, act = build()
kf_map, span = td.resolve_target(act, o, 14, 'right')
X_before = sample_x(o, act)

# 记录形状基线：关键帧坐标
def kf_coords(o, act):
    out = {}
    for fc in _fcs(o, act):
        out[fc.array_index] = [tuple(round(c, 9) for c in kp.co) for kp in fc.keyframe_points]
    return out

shape_before = kf_coords(o, act)

td.write_s(kf_map, 'right', 0.02, span)
for fc in _fcs(o, act):
    fc.update()

d_sparse = seg_span_frame_dists(o, act)
s_now = td.read_s(kf_map[0], span, 'right')
check("write s=0.02 readback", abs(s_now - 0.02) < 1e-6, "read=%.8f" % s_now)
check("sparse: first frame-dist LARGER than uniform",
      d_sparse[0] > d_lin[0] * 1.5,
      "sparse=%.6f uniform=%.6f  (%.2fx)" % (d_sparse[0], d_lin[0], d_sparse[0] / d_lin[0]))

# 形状不变
shape_after = kf_coords(o, act)
check("SHAPE: keyframe coords unchanged", shape_before == shape_after)

# 曲线在关键帧处仍然穿过原值（形状不动的硬判据）
X_after = sample_x(o, act)
at_kf = [1, 14, 27, 40]
max_dev = max(abs(X_before[f - 1] - X_after[f - 1]) for f in at_kf)
check("SHAPE: curve passes through same kf values", max_dev < 1e-9, "max dev=%.2e" % max_dev)

# 三轴同步
kf_map2 = td.collect_frame_keyframes(act, o, 14)
# ⚠️ 用户 2026-09-15 第二轮：只冻结【被编辑的一侧】——
#    两侧都冻会让插件的手柄联动失效（update_linked_handle 遇"两侧都 FREE"直接跳过），
#    表现为"速度编辑后 3D 视图交互变得很奇怪"。
all_free = all(kp.handle_right_type == 'FREE'
               for kp in kf_map2.values())
check("all 3 axes set to FREE", all_free and len(kf_map2) == 3,
      "types=%s" % [(kp.handle_left_type, kp.handle_right_type) for kp in kf_map2.values()])

# 三轴都写了 handle[0]
synced = True
for fc in _fcs(o, act):
    for kp in fc.keyframe_points:
        if abs(kp.co[0] - 14) < 0.5:
            if abs(abs(kp.handle_right[0] - kp.co[0]) - 0.02 * 13) > 1e-6:
                synced = False
check("3 axes wrote handle[0] synchronously", synced)

# 段平均守恒
X = sample_x(o, act)
d = [abs(X[i] - X[i - 1]) for i in range(1, 40)]
s_sum = sum(d[13:26])
check("segment mean conserved (sum of frame dists == arc 4.0)",
      abs(s_sum - 4.0) < 1e-5, "sum=%.8f" % s_sum)


# ---------------- 4. 写 s=1.0（最密） ----------------
o, act = build()
kf_map, span = td.resolve_target(act, o, 14, 'right')
td.write_s(kf_map, 'right', 1.0, span)
for fc in _fcs(o, act):
    fc.update()
d_dense = seg_span_frame_dists(o, act)
check("dense: first frame-dist SMALLER than uniform",
      d_dense[0] < d_lin[0] * 0.5,
      "dense=%.6f uniform=%.6f  (%.2fx)" % (d_dense[0], d_lin[0], d_dense[0] / d_lin[0]))
X = sample_x(o, act)
d = [abs(X[i] - X[i - 1]) for i in range(1, 40)]
check("dense: segment mean still conserved", abs(sum(d[13:26]) - 4.0) < 1e-5,
      "sum=%.8f" % sum(d[13:26]))


# ---------------- 4b. ★ 无硬限制：写入旧范围外的 s ----------------
o, act = build()
kf_map, span = td.resolve_target(act, o, 14, 'right')
w_low = td.write_s(kf_map, 'right', 0.005, span)      # 旧 S_MIN=0.02 之外
for fc in _fcs(o, act):
    fc.update()
s_low = td.read_s(td.collect_frame_keyframes(act, o, 14)[0], span, 'right')
check("★ write s=0.005 (< old S_MIN) actually applied",
      w_low is not None and abs(s_low - 0.005) < 1e-6,
      "written=%.6f readback=%.6f" % (w_low, s_low))
check("★ s=0.005 is sparser than old floor 0.02",
      td.d_to_s(999) < 0.02, "d_to_s(999)=%.6f" % td.d_to_s(999))

o, act = build()
kf_map, span = td.resolve_target(act, o, 14, 'right')
w_high = td.write_s(kf_map, 'right', 1.4, span)       # 超过几何上限
for fc in _fcs(o, act):
    fc.update()
s_high = td.read_s(td.collect_frame_keyframes(act, o, 14)[0], span, 'right')
# 2026-09-16：s>1 会令 f(t) 时间折返 → 钳到几何上限 1.0
check("★ write s=1.4 clamped to the GEOMETRIC limit 1.0 (dt<=span)",
      w_high is not None and abs(s_high - 1.0) < 1e-6,
      "written=%.6f readback=%.6f" % (w_high, s_high))

# 极值不应崩，也不应产生 NaN
o, act = build()
kf_map, span = td.resolve_target(act, o, 14, 'right')
td.write_s(kf_map, 'right', 1e-5, span)
for fc in _fcs(o, act):
    fc.update()
xx = sample_x(o, act)
check("★ extreme sparse: no NaN/Inf",
      all(x == x and abs(x) < 1e6 for x in xx), "ok" if all(x == x for x in xx) else "NaN found")


# ---------------- 5. 端点段保护 ----------------
o, act = build()
_, span0 = td.resolve_target(act, o, 1, 'left')
_, span3 = td.resolve_target(act, o, 40, 'right')
check("first kf left span == None (no prev)", span0 is None, span0)
check("last kf right span == None (no next)", span3 is None, span3)
r = td.apply_pixel_drag(act, o, 1, 'left', 30)
check("apply_pixel_drag on endpoint returns ok=False", r["ok"] is False, r["message"])


# ---------------- 6. apply_pixel_drag 像素语义 ----------------
o, act = build()
r_down = td.apply_pixel_drag(act, o, 14, 'right', +30)   # 往下拖 = 疏
d_down = seg_span_frame_dists(o, act)

o, act = build()
r_up = td.apply_pixel_drag(act, o, 14, 'right', -26)     # 往上拖 = 密
d_up = seg_span_frame_dists(o, act)

check("pixel drag DOWN -> sparser", d_down[0] > d_lin[0],
      "down=%.6f uniform=%.6f" % (d_down[0], d_lin[0]))
check("pixel drag UP -> denser", d_up[0] < d_lin[0],
      "up=%.6f uniform=%.6f" % (d_up[0], d_lin[0]))
check("DOWN and UP move in opposite directions", d_down[0] > d_up[0])
note("ratios", "down s=%.4f (%.2fx), up s=%.4f (%.2fx)" % (
    r_down["s"], r_down["ratio"], r_up["s"], r_up["ratio"]))


# ---------------- 输出 ----------------
fails = [r for r in results if r[0] == "FAIL"]
summary = {
    "total": len([r for r in results if r[0] != "NOTE"]),
    "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in results],
}
with open(os.path.join(HERE, "_td_result.json"), "w", encoding="utf-8") as fh:
    json.dump(summary, fh, ensure_ascii=False, indent=1)
print("WROTE_RESULT_JSON")
