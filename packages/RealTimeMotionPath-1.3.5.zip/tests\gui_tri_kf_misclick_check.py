# -*- coding: utf-8 -*-
"""关键帧点 / 三角控制柄 误触修复（用户 2026-09-18 反馈）。

用户原话
--------
    "关键帧点和三角控制柄容易误触，用户想选择关键帧点时容易误触选择三角控制器，
     可以保关键帧点的识别范围适当扩大一点点"

复现的根因（**实测数据，不是感觉**）
----------------------------------
    关键帧点可见半径 = keyframe_point_size / 2 = **5px**
    三角画在距关键帧 [18.5, 33.5]（尖端 18.5、本体中心 TRI_FIXED_D=26）
    而三角的拾取盘 = 「以三角中心 26 为圆心、半径 SPEED_TRI_PICK_RADIUS=22」
    ⇒ 覆盖 [4, 48]

    ⇒ **[4, 18.5] 这段"什么都没画"的空白区也被算成三角**：
       用户瞄着关键帧点往上偏一点点（>4px）就掉进这块虚拟领地 ⇒ 误触。
       实测扫描（真实工程）：偏移 4~18px 全部 `hit_test` 命中三角。

修复
----
    `KEYFRAME_PICK_PRIORITY_RADIUS = 14`：鼠标离该三角所属**关键帧点**
    这么近时，三角**不参与命中**（让给关键帧）。

    取值依据（两个方向都量过）：
      · 下界 > 可见半径 5（且给手抖留余量）
      · 上界 < 三角尖端 18.5（用户瞄三角时先够到的是三角）
      ⇒ 14 落在 [5, 18.5] 中间偏上。

    修复前后（沿关键帧 → 三角 的连线扫描）：
        偏移 0..13px  ：修复前**误判三角** → 修复后 正确给关键帧
        偏移 14..48px ：修复前后都命中三角（且**覆盖更全**：现在含整个三角本体）

本测试
------
A 组：**扫描式**判据 —— 关键帧保护区内任一点都不得命中三角（用户症状）
B 组：反方向 —— 瞄三角时仍必须命中（不能修过头）
C 组：口径唯一性（点击 / 悬停 / 双击共用同一个查询）
D 组：几何契约（半径取值落在合法区间）
E 组：bug 注入必须被抓
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils
from bpy_extras import view3d_utils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import interaction as it, handles as hd, cache as rcache
from RealTimeMotionPath import transform_domain as xf
from RealTimeMotionPath.state import _session, KEYFRAME_PICK_PRIORITY_RADIUS

OUT = os.path.join(HERE, "_tri_kf_misclick_result.json")
steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:900]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())


# ---------------------------------------------------------------- 真实场景
sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 60
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
obj = bpy.context.view_layer.objects.active
obj.name = "MisclickObj"
for f, loc in [(1, (0.0, 0.0, 0.0)), (25, (5.0, 0.0, 0.0)), (55, (10.0, 2.0, 0.0))]:
    sc.frame_set(f)
    obj.location = loc
    obj.keyframe_insert("location", frame=f)
sc.frame_set(25)

wm = bpy.context.window_manager
wm.rtmp_edit_mode_active = True
wm.rtmp_path_display_enabled = True
win = wm.windows[0]
AREA = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
REGION = next(r for r in AREA.regions if r.type == 'WINDOW')
RV3D = AREA.spaces.active.region_3d
RV3D.view_location = mathutils.Vector((5.0, 1.0, 0.0))
RV3D.view_distance = 22.0
RV3D.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
bpy.context.view_layer.update()
rcache.refresh_position_store(bpy.context)

MID = 25.0
TRI_TIP_FROM_KF = hd.TRI_FIXED_D - hd.TRI_HEIGHT_PX      # 18.5：三角尖端离关键帧
TRI_FAR_FROM_KF = hd.TRI_FIXED_D + hd.TRI_HEIGHT_PX      # 33.5：三角底边


def fresh_handles():
    with bpy.context.temp_override(area=AREA, region=REGION, region_data=RV3D):
        return it._all_speed_handles(bpy.context, obj, REGION, RV3D)


def offset_point(kf_screen, tri, dist):
    """从关键帧点沿"朝该三角"的方向，偏移 dist 像素。"""
    return (kf_screen[0], kf_screen[1] + hd.DIR_BY_TRI[tri] * dist)


def hit_at(handles, pt):
    h = it._triangle_under_cursor(handles, pt)
    return (h['frame'], h['tri']) if h is not None else None


try:
    HS = fresh_handles()
    step("S0 前置：真实收集到 4 个三角（1/25/55 三个关键帧，两端各只有 1 个）",
         len(HS) == 4 and {h['frame'] for h in HS} == {1.0, 25.0, 55.0},
         "n=%d frames=%s" % (len(HS), sorted({h['frame'] for h in HS})))

    step("S1 前置：三角实际画在距关键帧 [%.1f, %.1f]（与代码常量一致）"
         % (TRI_TIP_FROM_KF, TRI_FAR_FROM_KF),
         abs(TRI_TIP_FROM_KF - 18.5) < 1e-6 and abs(TRI_FAR_FROM_KF - 33.5) < 1e-6,
         "tip=%.1f far=%.1f" % (TRI_TIP_FROM_KF, TRI_FAR_FROM_KF))

    # ============================================ A 组：扫描（用户症状）
    # ★ 关键：不是"只点一个点"，而是沿关键帧→三角的连线**整条扫**
    #   （上一轮教训：命中是"盘"不是"点"，只点中心会漏掉重叠区）。
    R = KEYFRAME_PICK_PRIORITY_RADIUS
    print("KEYFRAME_PICK_PRIORITY_RADIUS = %s" % R)

    bad_up, bad_down = [], []
    for t in range(0, int(math.floor(R)) + 1):        # 0..14 含边界内
        for tri, bucket in ((hd.TRI_UP, bad_up), (hd.TRI_DOWN, bad_down)):
            kf = hd.find_handle(HS, MID, tri)['kf_screen']
            pt = offset_point(kf, tri, float(t))
            got = hit_at(HS, pt)
            if got is not None:
                bucket.append((t, got))
    step("A1 ★★★【核心】关键帧保护区内（0..%d px）任一点都**不得**命中三角" % R,
         not bad_up and not bad_down,
         "上三角误触档=%s 下三角误触档=%s" % (bad_up[:6], bad_down[:6]))

    # A2：用户症状的**原始触发点**（旧实现从 4px 起就误判）
    o, a = MID, None
    hits_orig = []
    for t in (4, 6, 8, 10, 12):
        kf = hd.find_handle(HS, MID, hd.TRI_UP)['kf_screen']
        hits_orig.append((t, hit_at(HS, offset_point(kf, hd.TRI_UP, float(t)))))
    step("A2 ★★★ 旧根因触发档（4/6/8/10/12 px）现在全部**不命中三角**",
         all(g is None for _, g in hits_orig), "%s" % (hits_orig,))

    # A3：关键帧点中心（最容易发生的瞄准点）
    kf_c = hd.find_handle(HS, MID, hd.TRI_UP)['kf_screen']
    step("A3 ★★★ 点在关键帧点**正中** ⇒ 不得命中三角（让给关键帧）",
         hit_at(HS, kf_c) is None, "got=%s" % (hit_at(HS, kf_c),))

    # A4：边界外一点点（R+0.5）应当恢复命中 —— 证明保护是"有限度"的
    kf = hd.find_handle(HS, MID, hd.TRI_UP)['kf_screen']
    just_out = hit_at(HS, offset_point(kf, hd.TRI_UP, R + 0.5))
    step("A4 ★★ 保护半径**外**一点点（%.1f px）⇒ 恢复命中三角（保护有边界，不是一刀切）"
         % (R + 0.5),
         just_out == (MID, hd.TRI_UP), "got=%s" % (just_out,))

    # A5：三个关键帧都要保护（不能只对中间帧生效）
    ok_all = True
    det_all = []
    for f in (1.0, 25.0, 55.0):
        for tri in (hd.TRI_UP, hd.TRI_DOWN):
            h = hd.find_handle(HS, f, tri)
            if h is None:
                continue
            g = hit_at(HS, h['kf_screen'])
            det_all.append((f, tri, g))
            if g is not None:
                ok_all = False
    step("A5 ★★★ 每个关键帧的**上下两侧**都受保护（不只中间帧）", ok_all, "%s" % (det_all,))

    # ============================================ B 组：反方向（别修过头）
    aim = []
    for t in (19.0, 22.0, 26.0, 30.0, 33.0):          # 整个三角本体
        kf = hd.find_handle(HS, MID, hd.TRI_UP)['kf_screen']
        aim.append((t, hit_at(HS, offset_point(kf, hd.TRI_UP, t))))
    step("B1 ★★★ 瞄三角本体（19~33 px，覆盖尖端到根部）⇒ **仍必须**命中三角",
         all(g == (MID, hd.TRI_UP) for _, g in aim), "%s" % (aim,))

    tip_hit = hit_at(HS, offset_point(
        hd.find_handle(HS, MID, hd.TRI_UP)['kf_screen'], hd.TRI_UP, TRI_TIP_FROM_KF + 0.2))
    step("B2 ★★★ 瞄三角**尖端**（%.2f px，用户最自然的瞄准点之一）⇒ 仍命中"
         % (TRI_TIP_FROM_KF + 0.2),
         tip_hit == (MID, hd.TRI_UP), "got=%s" % (tip_hit,))

    dnc = []
    for t in (19.0, 26.0, 33.0):
        kf = hd.find_handle(HS, MID, hd.TRI_DOWN)['kf_screen']
        dnc.append((t, hit_at(HS, offset_point(kf, hd.TRI_DOWN, t))))
    step("B3 ★★ 下三角同样不受影响（上下对称）",
         all(g == (MID, hd.TRI_DOWN) for _, g in dnc), "%s" % (dnc,))

    # B4：三角中心处仍能命中（最粗的瞄准点）
    c_up = hd.find_handle(HS, MID, hd.TRI_UP)['tri_screen']
    step("B4 ★★ 三角**中心**（画在哪）⇒ 命中",
         hit_at(HS, c_up) == (MID, hd.TRI_UP), "got=%s" % (hit_at(HS, c_up),))

    # B5：相邻关键帧的保护盘**不会**挡住别的关键帧的三角
    #     （保护只看"该三角自己的关键帧"—— 这是刻意的设计，得钉住）
    kf25 = hd.find_handle(HS, MID, hd.TRI_DOWN)['kf_screen']
    far_down = offset_point(kf25, hd.TRI_DOWN, 20.0)   # 25 帧下方 20px
    # 若 25 帧下方 20px 恰好离别的关键帧很近也要命中 25 的 down 三角
    got_b5 = hit_at(HS, far_down)
    step("B5 ★★ 保护只认【该三角自己的关键帧】（别的关键帧不会挡住它）",
         got_b5 == (MID, hd.TRI_DOWN), "got=%s" % (got_b5,))

    # ============================================ C 组：口径唯一
    src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    step("C1 ★★★ 全仓已无裸的三角命中（都走 _triangle_under_cursor）",
         src.count("hd.hit_test(s_handles, local_mouse_pos, SPEED_TRI_PICK_RADIUS)") == 0
         and src.count("hd.hit_test(handles, mouse_pos, SPEED_TRI_PICK_RADIUS)") == 0,
         "")

    n_entries = src.count("_triangle_under_cursor(s_handles, local_mouse_pos)") + \
        src.count("_triangle_under_cursor(handles, mouse_pos)")
    step("C2 ★★★ 点击 / 悬停 / 双击 / 恢复默认 **四处**都走同一个查询",
         n_entries >= 4, "调用点=%d" % n_entries)

    # C3：**悬停路径**也受保护（否则光标停在关键帧上按 Backspace 会误重置三角）
    with bpy.context.temp_override(area=AREA, region=REGION, region_data=RV3D):
        kf = hd.find_handle(HS, MID, hd.TRI_UP)['kf_screen']
        it._update_speed_hover(bpy.context, obj, REGION, RV3D, kf)
        hover_near_kf = _session.hover_speed_tri
        tri_c = hd.find_handle(HS, MID, hd.TRI_UP)['tri_screen']
        it._update_speed_hover(bpy.context, obj, REGION, RV3D, tri_c)
        hover_on_tri = _session.hover_speed_tri
    step("C3 ★★★ 悬停在关键帧上 ⇒ `hover_speed_tri` 为空（Backspace 不会误重置三角）",
         hover_near_kf is None, "hover_near_kf=%s" % (hover_near_kf,))
    step("C4 ★★★ 悬停在三角上 ⇒ `hover_speed_tri` 正确指向该三角",
         hover_on_tri == (MID, hd.TRI_UP), "hover_on_tri=%s" % (hover_on_tri,))

    # C5：双击路径同样受保护（在关键帧近旁双击不得切换锁定）
    try:
        xf.clear_tri_lock(obj.animation_data.action)
    except Exception:
        pass
    _session.speed_click_info = None
    kf = hd.find_handle(HS, MID, hd.TRI_UP)['kf_screen']
    it.try_toggle_tri_lock_click(bpy.context, obj, HS, kf)
    c5, m5 = it.try_toggle_tri_lock_click(bpy.context, obj, HS, kf)
    step("C5 ★★★ 在关键帧近旁双击 ⇒ **不触发**三角锁定切换（不消费）",
         c5 is False and m5 is None, "consumed=%s msg=%r" % (c5, m5))

    # ============================================ D 组：几何契约
    step("D1 ★★★ 保护半径 > 关键帧点可见半径 5（否则等于没保护）",
         R > 5.0, "R=%.1f 可见半径=%.1f" % (R, 5.0))

    step("D2 ★★★ 保护半径 < 三角尖端 18.5（否则瞄三角会被关键帧抢走）",
         R < TRI_TIP_FROM_KF, "R=%.1f 尖端=%.1f" % (R, TRI_TIP_FROM_KF))

    step("D3 ★★ 保护半径落在 [可见半径, 三角尖端] 的**中间偏上**（两边余量都够）",
         R > 5.0 + 4.0 and (TRI_TIP_FROM_KF - R) >= 3.0,
         "下余量=%.1f 上余量=%.1f" % (R - 5.0, TRI_TIP_FROM_KF - R))

    # ============================================ E 组：bug 注入
    def _sweep_hits(handles, upto=None):
        """保护区扫描：返回被误判成三角的偏移档。"""
        R_ = upto if upto is not None else KEYFRAME_PICK_PRIORITY_RADIUS
        bad = []
        for t in range(0, int(math.floor(R_)) + 1):
            kf_ = hd.find_handle(handles, MID, hd.TRI_UP)['kf_screen']
            if hit_at(handles, offset_point(kf_, hd.TRI_UP, float(t))) is not None:
                bad.append(t)
        return bad

    def _aim_miss(handles):
        """瞄三角扫描：返回**没命中**三角的偏移档（修过头的症状）。"""
        miss = []
        for t in (19.0, 22.0, 26.0, 30.0, 33.0):
            kf_ = hd.find_handle(handles, MID, hd.TRI_UP)['kf_screen']
            if hit_at(handles, offset_point(kf_, hd.TRI_UP, t)) != (MID, hd.TRI_UP):
                miss.append(t)
        return miss

    HS2 = fresh_handles()
    step("E0 基线：未注入时 保护区无误触(0档) + 瞄三角无漏(0档)",
         _sweep_hits(HS2) == [] and _aim_miss(HS2) == [],
         "误触=%s 漏=%s" % (_sweep_hits(HS2), _aim_miss(HS2)))

    # I1：把保护半径设成 0（= 退回有 bug 的行为）
    _orig_R = it.KEYFRAME_PICK_PRIORITY_RADIUS
    it.KEYFRAME_PICK_PRIORITY_RADIUS = 0.0
    hs_i1 = fresh_handles()
    bad_i1 = _sweep_hits(hs_i1, upto=12.0)
    it.KEYFRAME_PICK_PRIORITY_RADIUS = _orig_R
    step("★ I1 保护半径归零（退回旧行为）⇒ 保护区扫描应抓到误触",
         len(bad_i1) > 0, "误触档=%s" % (bad_i1[:8],))

    # I2：保护半径设得太大（26 > 尖端 18.5）⇒ 瞄三角会被关键帧抢走
    it.KEYFRAME_PICK_PRIORITY_RADIUS = 26.0
    hs_i2 = fresh_handles()
    miss_i2 = _aim_miss(hs_i2)
    it.KEYFRAME_PICK_PRIORITY_RADIUS = _orig_R
    step("★ I2 保护半径过大（26 > 尖端 18.5）⇒ 瞄三角扫描应抓到漏判",
         len(miss_i2) > 0, "没命中的档=%s" % (miss_i2,))

    # I3：把唯一查询换成"裸的" hit_test（绕过保护）⇒ 保护区扫描 + 悬停都出问题
    #     （这条替代了早先那个"永远为 True"的占位断言 —— 那种断言是假测试）
    _orig_query = it._triangle_under_cursor
    it._triangle_under_cursor = lambda hs, mp: hd.hit_test(hs, mp, it.SPEED_TRI_PICK_RADIUS)
    try:
        bad_i3 = _sweep_hits(fresh_handles(), upto=12.0)
    except Exception as e:
        bad_i3 = ["ERR:%s" % e]
    try:
        with bpy.context.temp_override(area=AREA, region=REGION, region_data=RV3D):
            # ⚠️ 必须用**重叠区内的点**（t=8）：关键帧正中心距三角中心 26 > 22，
            #    裸 hit_test 在那里本来就不命中 —— 用它测不出"绕过保护"。
            #    （这正是"只点一个点抓不住 bug、必须扫一整条"的现场例证。）
            kf_ = hd.find_handle(fresh_handles(), MID, hd.TRI_UP)['kf_screen']
            pt8 = offset_point(kf_, hd.TRI_UP, 8.0)
            it._update_speed_hover(bpy.context, obj, REGION, RV3D, pt8)
            hover_i3 = _session.hover_speed_tri
    except Exception as e:
        hover_i3 = "ERR:%s" % e
    it._triangle_under_cursor = _orig_query
    step("★ I3 唯一查询被换成裸 hit_test ⇒ 保护区扫描 + 悬停**都**出问题",
         len(bad_i3) > 0 and hover_i3 is not None,
         "误触档=%s 悬停=%s" % (bad_i3[:8], hover_i3))

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-1500:])
finally:
    try:
        _session.clear_speed_handle()
        _session.speed_click_info = None
    except Exception:
        pass

try:
    x = bpy.data.objects.get("MisclickObj")
    if x:
        bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
