"""RTMP 视口覆盖层（模态 / 手柄的视觉反馈）

两套绘制，各司其职
------------------
① POST_VIEW（3D 世界空间）
     轴约束指示线 —— 参照 Blender 原生 transform 模态实测效果：
        锁单轴 → 一条轴色直线，穿过 pivot，贯穿视口
        锁平面 → 平面内另两轴各一条
     颜色从用户主题读（不硬编码）。

② POST_PIXEL（2D 屏幕空间）
     速度手柄（关键帧上下两个三角）+ 1.00x 匀速基准虚线 + 倍数标签。
     用户定义（2026-09-15）：
        三角始终是 **2D 视口里**描绘在关键帧点上下位置的图形，
        永远沿视口 Y 轴排列 —— 所以用屏幕空间画，换视角时行为一致。

     手柄数据只在【悬停关键帧】或【被选中】时绘制（平时不出现）。

生命周期
--------
    start_*() 注册 draw handler；stop() 必须调用，否则 handler 泄漏。
"""

import bpy
import math
import mathutils

from . import handles as hd

try:
    from bpy_extras import view3d_utils
except Exception:
    view3d_utils = None


# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# 主题读不到时的兜底（来自 Blender 默认主题，非臆造）
_FALLBACK_AXIS = {
    'X': (1.0, 0.2, 0.3216),
    'Y': (0.5451, 0.8627, 0.0),
    'Z': (0.1569, 0.5647, 1.0),
}

AXIS_DIR = {
    'X': mathutils.Vector((1.0, 0.0, 0.0)),
    'Y': mathutils.Vector((0.0, 1.0, 0.0)),
    'Z': mathutils.Vector((0.0, 0.0, 1.0)),
}

EXTENT = 1.0e5          # 轴线的延伸范围（必被视口裁剪 → "贯穿屏幕"）
LINE_WIDTH = 1.6
ALPHA = 0.8

# ★ 鼠标引导（复刻原生 R/S 的"支点 → 鼠标"虚线 + 会转的双向箭头）— 2026-09-16
#
# ▎下面这些数**全部来自对用户提供的原生截图做像素级测量**（不是目测定、不是猜）：
#
#     · 颜色      : 纯白 (255,255,255)          ← 实测中位值
#     · 虚线 段长 : 4.2 px                       ← 33 段的 run-length 中位数
#     · 虚线 间隔 : 5.1 px
#     · 虚线 线宽 : 1.0 px
#     · 箭头轴 vs 虚线 : **89.9°（垂直）**        ← 两箭头中心连线 vs 虚线主轴
#     · 每个箭头  : 约 13x14 px（主干+尖端）
#     · 两箭头中心距 : 30.5 px（中间有 ~14px 空档）
#
#   ⚠️ 关键形态：原生**不是**"一根连续的双向箭头线段"，
#      而是**两段各自独立的箭头**（中间留空隙、虚线穿过空隙），
#      每个箭头只有**朝外的一端**有箭尖。
GUIDE_COLOR = (1.0, 1.0, 1.0, 1.0)
DASH_LEN = 4.2
DASH_GAP = 5.1
GUIDE_WIDTH = 1.0

# 以下四项来自对原生箭头做的**逐像素 ASCII 分析**（不是目测）：
#   箭尖：y214 处 2px 宽 → 向下张开；到 y218 已分成「斜笔 | 主干 | 斜笔」三段
#   主干：x736~738 共 2px 宽，从箭尖一路到 y227（长 13px）
#   斜笔：单侧 Δx≈6 / Δy≈8 → 长 ≈9px，与主轴夹角 ≈40°
#   两斜笔末端间距 ≈12px  （= 2 × head × sin(HEAD_ANGLE) = 2×9×sin40° ≈ 11.6 ✓）
ARROW_HALF = 20.0       # 中心 → 箭尖（总跨度 2×20 = 40px，实测 40）
ARROW_GAP = 14.0        # 中心处的空档（实测两箭头间 14px）
ARROW_HEAD = 9.0        # 箭尖斜笔长度（实测 ≈9px）
ARROW_WIDTH = 2.0       # 主干线宽（实测主干 "##" = 2px）
HEAD_ANGLE = 40.0       # 箭尖斜笔与主轴的夹角（度；实测 ≈40°）

# 速度手柄视觉
# 用户 2026-09-15：「速度手柄只需要三角，不需要其他 UI 元素」
#   → 去掉 1.00x 基准虚线、去掉倍数标签，只剩三角。
# 「三角交互后不需要移动，固定住就行」
#   → 三角画在【固定偏移】处；疏密变化不再靠三角位置表达，
#      而是让【受影响的路径段变色】。
#
# ★★ 2026-09-18（用户需求）：三角的**锁定状态**也用外观区分
#   · 一体（默认）  → **黄色实心 + 黑色细边框**
#   · 分离          → **空心三角**（描边用当前状态色）
#   用户原话：「默认情况下三角控制柄都是黄色实心黑色细边框……分离后的
#             三角控制柄外观变为空心三角」
HANDLE_COLOR = (1.0, 0.78, 0.05, 1.0)            # 默认：黄（实心 + 黑边）
HANDLE_SELECTED_COLOR = (1.0, 1.0, 1.0, 1.0)     # 选中：亮白（高亮）
# ⚠️ 默认色改成黄之后，原来的"琥珀"拖拽色与它几乎同色 ⇒ 必须换成一个
#    明显不同的色相，否则「正在拖」这个状态看不出来（这算引入的新问题）。
HANDLE_DRAG_COLOR = (1.0, 0.42, 0.08, 1.0)       # 拖拽中：橙红
# 一体态的三角描边色（用户：黑色细边框）
HANDLE_OUTLINE_COLOR = (0.05, 0.05, 0.05, 1.0)
HANDLE_OUTLINE_WIDTH = 1.2
TRI_HALF_PX = hd.TRI_HALF_PX
TRI_HEIGHT_PX = hd.TRI_HEIGHT_PX
# ⚠️ 三角的屏幕位置统一由 handles.TRI_FIXED_D 决定（绘制与命中检测必须一致，
#    否则会出现「看得见却点不中」）。这里只是别名，避免两处常量漂移。
TRI_FIXED_D = hd.TRI_FIXED_D

# 受影响路径段的高亮色（拖拽 / 模态操作时）
#
# 用户 2026-09-15：「收缩采样密度时（变密）的路径颜色改为蓝色，区分一下橙色」
#   → 两种方向用两种颜色：
#       变疏（更快 / 采样点拉散）  → 橙色
#       变密（更慢 / 采样点聚拢）  → 蓝色
SEGMENT_HIGHLIGHT_COLOR = (1.0, 0.62, 0.12, 0.95)        # 兼容旧名 = 变疏（橙）
SEGMENT_SPARSE_COLOR = (1.0, 0.62, 0.12, 0.95)           # 变疏：橙
SEGMENT_DENSE_COLOR = (0.22, 0.55, 1.0, 0.95)            # 变密：蓝
SEGMENT_HIGHLIGHT_WIDTH = 4.0


def highlight_color(dense):
    """按方向取高亮色。"""
    return SEGMENT_DENSE_COLOR if dense else SEGMENT_SPARSE_COLOR


def _norm_selected(selected):
    """把"单个 / 多个"统一成 set{(frame, tri)}。"""
    if selected is None:
        return set()
    if isinstance(selected, (list, set, tuple)):
        if len(selected) == 0:
            return set()
        first = selected[0]
        if isinstance(first, (list, tuple)) and len(first) >= 2 and not isinstance(first, str):
            return {(float(x[0]), x[1]) for x in selected}
        # 单个 (frame, tri)
        if len(selected) >= 2 and isinstance(selected[1], str):
            return {(float(selected[0]), selected[1])}
    return set()


# 受影响路径段：由交互层设置，drawing.py 读取（画高亮子折线）
#
# 用户 2026-09-15 的定义：
#   「路径变色可以理解为原来的三角UI移动，变色胀满路径就是速度拉伸至
#     理论上几乎不会变化的极限了」
#   → 高亮不再是"标出这一段"，而是【长度随疏密程度增长的量尺】：
#       t=0（匀速）  → 不画
#       t=1（到极值）→ 从关键帧一直胀满到相邻关键帧
#   → 颜色区分方向：变疏=橙，变密=蓝
_segment_highlight = None      # (frame, side, t, dense) 或 None


def set_segment_highlights(items):
    """一次设置**多个**受影响路径段（多选三角时全部高亮）。

    items: [(frame, side, t, dense), ...]
    """
    global _segment_highlight
    out = []
    for it in (items or []):
        try:
            f, side, t, dense = it
        except Exception:
            continue
        if f is None or side is None:
            continue
        try:
            t = max(0.0, min(1.0, float(t)))
        except Exception:
            t = 1.0
        out.append((f, side, t, bool(dense)))
    _segment_highlight = out if out else None


def get_segment_highlights():
    """返回全部高亮段（list）；兼容旧接口返回第一个。"""
    if _segment_highlight is None:
        return []
    return list(_segment_highlight)


def set_segment_highlight(frame, side, t=1.0, dense=False):
    """标记【正在被调整】的路径段。

    t     : 0..1 —— 离匀速的"极端程度"，决定高亮要胀满多少（见 td.extremeness）
    dense : True = 变密方向（蓝），False = 变疏方向（橙）
    """
    set_segment_highlights([] if (frame is None or side is None)
                           else [(frame, side, t, dense)])


def get_segment_highlight():
    """兼容旧接口：返回第一个高亮段（tuple）或 None。"""
    hs = get_segment_highlights()
    return hs[0] if hs else None


def clear_segment_highlight():
    global _segment_highlight
    _segment_highlight = None


def get_axis_colors():
    """从用户主题取轴色（权威来源，跟随主题变化）。"""
    try:
        ui = bpy.context.preferences.themes[0].user_interface
        return {'X': tuple(ui.axis_x), 'Y': tuple(ui.axis_y), 'Z': tuple(ui.axis_z)}
    except Exception:
        return dict(_FALLBACK_AXIS)


def axes_for(axis_lock, plane_lock):
    """当前约束下应该画哪几条轴指示线。"""
    if plane_lock:
        return [a for a in plane_lock if a in AXIS_DIR]
    if axis_lock and axis_lock in AXIS_DIR:
        return [axis_lock]
    return []


def draw_axis_lines(pivot, axes, colors, line_width=LINE_WIDTH, alpha=ALPHA):
    """POST_VIEW：画轴约束指示线（世界坐标）。"""
    if pivot is None or not axes:
        return
    import gpu
    from gpu_extras.batch import batch_for_shader

    try:
        shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    except Exception:
        return

    try:
        viewport = gpu.state.viewport_get()[2:]
    except Exception:
        viewport = (1, 1)

    try:
        gpu.state.blend_set('ALPHA')
    except Exception:
        pass

    for ax in axes:
        d = AXIS_DIR.get(ax)
        if d is None:
            continue
        c = colors.get(ax) or _FALLBACK_AXIS[ax]
        p0 = tuple(pivot - d * EXTENT)
        p1 = tuple(pivot + d * EXTENT)
        try:
            batch = batch_for_shader(shader, 'LINES', {"pos": [p0, p1]})
            shader.bind()
            shader.uniform_float("viewportSize", viewport)
            shader.uniform_float("lineWidth", line_width)
            shader.uniform_float("color", (c[0], c[1], c[2], alpha))
            batch.draw(shader)
        except Exception:
            continue

    try:
        gpu.state.blend_set('NONE')
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 2D 绘制工具（POST_PIXEL 阶段，坐标为 region 空间）
# ---------------------------------------------------------------------------

def _tri_verts_2d(cx, cy, pointing, half=TRI_HALF_PX, height=TRI_HEIGHT_PX):
    """三角顶点。pointing 表示【尖端朝向】。

    'down' → 尖端朝下（用于关键帧【上方】的三角，指向关键帧）
    'up'   → 尖端朝上（用于关键帧【下方】的三角，指向关键帧）
    """
    if pointing == 'down':
        return [(cx - half, cy + height), (cx + half, cy + height), (cx, cy - height)]
    return [(cx - half, cy - height), (cx + half, cy - height), (cx, cy + height)]


def draw_triangle_2d(cx, cy, pointing, color, filled=True,
                     outline_color=None, outline_width=None):
    """在屏幕坐标 (cx, cy) 画三角。

    参数（★ 2026-09-18 扩展，用于「一体实心 / 分离空心」的区分）：
      color          —— 填充色（`filled=False` 时**忽略**）
      filled         —— True = 实心；False = **空心**（只画描边）
      outline_color  —— 描边色；缺省 = 与填充同色（旧行为）
      outline_width  —— 描边线宽；缺省 = 旧值 1.4

    ⚠️ 空心时的描边色**必须显式给**（否则 `color` 是填充色、空心就看不见了）。
    """
    try:
        import gpu
        from gpu_extras.batch import batch_for_shader
    except Exception:
        return
    verts = _tri_verts_2d(cx, cy, pointing)
    try:
        gpu.state.blend_set('ALPHA')
    except Exception:
        pass

    try:
        if filled:
            try:
                sh = gpu.shader.from_builtin('UNIFORM_COLOR')
            except Exception:
                sh = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
            batch = batch_for_shader(sh, 'TRIS', {"pos": verts})
            sh.bind()
            sh.uniform_float("color", color)
            batch.draw(sh)
    except Exception:
        pass

    # 描边（用同一组点闭合）
    if outline_color is None:
        outline_color = color
    if outline_width is None:
        outline_width = 1.4
    try:
        sh2 = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        batch2 = batch_for_shader(sh2, 'LINE_STRIP', {"pos": verts + [verts[0]]})
        try:
            viewport = gpu.state.viewport_get()[2:]
        except Exception:
            viewport = (1, 1)
        sh2.bind()
        sh2.uniform_float("viewportSize", viewport)
        sh2.uniform_float("lineWidth", outline_width)
        sh2.uniform_float("color", outline_color)
        batch2.draw(sh2)
    except Exception:
        pass

    try:
        gpu.state.blend_set('NONE')
    except Exception:
        pass


def draw_dashed_line_2d(p1, p2, color, dash=DASH_LEN, gap=DASH_GAP, width=GUIDE_WIDTH):
    """在屏幕坐标画一条虚线（复刻原生 R/S 的"支点→鼠标"引导线）。

    ⚠️ 原生行为实测（`_shot_S.png` + `GetCursorInfo`）：
       Blender 在 R/S 模态下**隐藏系统光标**（h=0）**并自绘**箭头 + 这条虚线。
       插件这里只补虚线 —— 箭头交给系统光标（`MOVE_Y`/`MOVE_X`），
       省掉自绘箭头的位置同步问题，视觉上等价。
    """
    try:
        import gpu
        from gpu_extras.batch import batch_for_shader
    except Exception:
        return
    dx, dy = (p2[0] - p1[0]), (p2[1] - p1[1])
    length = (dx * dx + dy * dy) ** 0.5
    if length < 1e-6:
        return
    ux, uy = dx / length, dy / length
    verts = []
    t = 0.0
    while t < length:
        t2 = min(t + dash, length)
        verts.append((p1[0] + ux * t, p1[1] + uy * t))
        verts.append((p1[0] + ux * t2, p1[1] + uy * t2))
        t = t2 + gap
    if not verts:
        return
    try:
        gpu.state.blend_set('ALPHA')
    except Exception:
        pass
    try:
        sh = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        batch = batch_for_shader(sh, 'LINES', {"pos": verts})
        try:
            viewport = gpu.state.viewport_get()[2:]
        except Exception:
            viewport = (1, 1)
        sh.bind()
        sh.uniform_float("viewportSize", viewport)
        sh.uniform_float("lineWidth", width)
        sh.uniform_float("color", color)
        batch.draw(sh)
    except Exception:
        try:
            sh = gpu.shader.from_builtin('UNIFORM_COLOR')
            batch = batch_for_shader(sh, 'LINES', {"pos": verts})
            sh.bind()
            sh.uniform_float("color", color)
            batch.draw(sh)
        except Exception:
            pass
    try:
        gpu.state.blend_set('NONE')
    except Exception:
        pass


def arrow_verts_2d(center, direction, half=None, gap=None, head=None):
    """构造**两段式**双向箭头的顶点列表（供绘制与测试共用）。

    ⚠️ 形态**照实测的原生截图做**（2026-09-16）：
       原生不是"一根连续的双向箭头线段"，而是**两段各自独立的箭头**：
         · 各自从离中心 gap/2 处起步，走到 half 处
         · **只有朝外的那一端**有箭尖（两条斜笔，与主轴成 ±HEAD_ANGLE）
         · 中间留 gap 的空档 —— 虚线正好从空档穿过去

    实测依据（对用户提供的原生截图逐像素量）：
      每个箭头 ≈ 13x14px、两箭头中心距 30.5px、箭头轴 ⊥ 虚线（89.9°）

    返回 [ (x,y), (x,y), ... ]（LINES 图元：每两个点一条线），参数非法返回 []。
    """
    if half is None:
        half = ARROW_HALF
    if gap is None:
        gap = ARROW_GAP
    if head is None:
        head = ARROW_HEAD
    dx, dy = float(direction[0]), float(direction[1])
    ln = (dx * dx + dy * dy) ** 0.5
    if ln < 1e-9:
        return []
    dx, dy = dx / ln, dy / ln
    cx, cy = float(center[0]), float(center[1])
    r0 = float(gap) * 0.5                 # 主干起点（离中心 gap/2）
    if r0 >= half:                        # 参数不合理 → 退化成连续线段（不静默出错）
        r0 = 0.0
    verts = []
    for sgn in (1.0, -1.0):
        bx = cx + dx * r0 * sgn
        by = cy + dy * r0 * sgn
        tx = cx + dx * half * sgn
        ty = cy + dy * half * sgn
        verts += [(bx, by), (tx, ty)]                       # 主干
        hx, hy = -dx * sgn, -dy * sgn                       # 指向中心（箭尖朝外张开）
        hth = math.radians(HEAD_ANGLE)
        ch, sh = math.cos(hth), math.sin(hth)
        for s2 in (1.0, -1.0):
            rx = hx * ch - hy * sh * s2
            ry = hx * sh * s2 + hy * ch
            verts += [(tx, ty), (tx + rx * head, ty + ry * head)]
    return verts


def draw_double_arrow_2d(center, direction, half=None, gap=None, head=None, color=None, width=None):
    """在屏幕坐标画一个**双向箭头**（复刻原生 R 的旋转箭头）。

    ⚠️ 为什么必须自绘（2026-09-16 实测 + 用户反馈）：
       原生的旋转箭头**会随鼠标绕支点转动**（用户：「跟随旋转操作一起旋转」），
       而 Windows 的 `MOVE_Y`/`MOVE_X` 系统光标是**固定方向**的，做不到。
       原生正是**隐藏系统光标 + 自绘**（实测 `GetCursorInfo` 得 h=0）。

    ▎方向 = 有效拖动方向（实测用户提供的原生截图验证）
       · 旋转（R）：箭头 **⊥** 支点→鼠标 连线（**切向**）—— 因为径向拖动不改变角度
       · 缩放（S）：箭头 **∥** 支点→鼠标 连线（**径向**）
       实测：原生 R 截图里虚线约 −15°、箭头约 75°（相互垂直）；
             原生 S 截图里虚线 0°、箭头 0°（平行）。
    """
    verts = arrow_verts_2d(center, direction, half, gap, head)
    if not verts:
        return
    if color is None:
        color = GUIDE_COLOR
    if width is None:
        width = ARROW_WIDTH
    try:
        import gpu
        from gpu_extras.batch import batch_for_shader
    except Exception:
        return
    try:
        gpu.state.blend_set('ALPHA')
    except Exception:
        pass
    try:
        sh = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        batch = batch_for_shader(sh, 'LINES', {"pos": verts})
        try:
            viewport = gpu.state.viewport_get()[2:]
        except Exception:
            viewport = (1, 1)
        sh.bind()
        sh.uniform_float("viewportSize", viewport)
        sh.uniform_float("lineWidth", width)
        sh.uniform_float("color", color)
        batch.draw(sh)
    except Exception:
        try:
            sh = gpu.shader.from_builtin('UNIFORM_COLOR')
            batch = batch_for_shader(sh, 'LINES', {"pos": verts})
            sh.bind()
            sh.uniform_float("color", color)
            batch.draw(sh)
        except Exception:
            pass
    try:
        gpu.state.blend_set('NONE')
    except Exception:
        pass


# 注：原先还有 draw_dashed_hline_2d / draw_text_2d（1.00x 基准虚线 + 倍数标签），
#     用户 2026-09-15 要求「速度手柄只需要三角，不需要其他 UI 元素」→ 已移除。
#     ⚠️ 移除时曾漏删函数签名里的默认参数，导致模块导入失败，
#        而 modal_edit 的 try/except 把 ImportError 吞了 → 覆盖层静默失效。
#        教训：删常量时要把引用它的地方一起清掉；宽 except 要配可观测信号。


# ---------------------------------------------------------------------------
# 覆盖层单例
# ---------------------------------------------------------------------------

class Overlay:
    """管理两套 draw handler 的生命周期与绘制内容。

    ⚠️ **所有权分离**（这是 bug 修复的关键）

        _h_pixel（速度手柄，2D）
            由 `RTMP_OT_PathPointDrag` 持有 —— 它随【直接编辑模式】长期存活。

        _h_view（轴约束线，3D）
            由【模态会话】持有 —— 只在模态运行期间需要。

    之前两者共用一个 `stop()`：模态结束时把 pixel handler 一起删掉了，
    而 path_point_drag 仍在运行且不会重新注册 →
    **表现就是「一顿操作后三角消失、鼠标过去也不显现」**（用户反馈的 bug）。
    """

    def __init__(self):
        self._h_view = None
        self._h_pixel = None
        # 3D：变换会话（轴约束线）
        self._session = None
        self._colors = None
        # 2D：速度手柄（存【数据】而非屏幕坐标 —— 换视角时现算，不会过期）
        self._handle_records = []
        self._selected = set()     # {(frame, tri), ...} 支持多选
        self._dragging = False
        self._split_frames = set()  # ★ 2026-09-18：处于【分离】状态的帧号
        self.last_error = None     # 诊断用：最近一次绘制/收集异常

    # ---- 生命周期 ----

    @property
    def active(self):
        return self._h_view is not None or self._h_pixel is not None

    @property
    def has_pixel(self):
        return self._h_pixel is not None

    @property
    def has_view(self):
        return self._h_view is not None

    def start(self, session=None):
        """注册 draw handler。

        session 非 None 时同时注册 3D（轴约束线）handler。
        **不会**清掉已有的 pixel handler。
        """
        if session is not None:
            self._session = session
        if self._colors is None:
            self._colors = get_axis_colors()
        try:
            if self._h_pixel is None:
                self._h_pixel = bpy.types.SpaceView3D.draw_handler_add(
                    self._draw_2d, (), 'WINDOW', 'POST_PIXEL')
            if self._session is not None and self._h_view is None:
                self._h_view = bpy.types.SpaceView3D.draw_handler_add(
                    self._draw_3d, (), 'WINDOW', 'POST_VIEW')
            return True
        except Exception:
            self.last_error = "start failed"
            return False

    def stop_view_only(self):
        """只撤掉 3D（轴约束线）handler —— 模态结束时调用。

        **保留 pixel handler**，否则 path_point_drag 的速度手柄会永久消失。
        """
        h = self._h_view
        if h is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
            except Exception:
                pass
            self._h_view = None
        self._session = None

    def stop(self):
        """完全拆除（编辑模式关闭 / 插件卸载时用）。"""
        self.stop_view_only()
        h = self._h_pixel
        if h is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
            except Exception:
                pass
            self._h_pixel = None
        self._handle_records = []
        self._selected = set()
        self._dragging = False
        self._split_frames = set()      # ★ 2026-09-18：处于【分离】状态的帧号

    def set_session(self, session):
        """设置/清除轴约束线的来源会话（按需增删 view handler）。"""
        self._session = session
        self.start(session) if session is not None else self.stop_view_only()

    def set_handles(self, records, selected=None, dragging=False,
                    split_frames=None):
        """设置要显示的速度手柄（records 由 handles.collect_handles 产出）。

        `selected` 支持**多选**（用户 2026-09-16）：
          · None                → 无选中
          · (frame, tri)        → 单个
          · [(frame, tri), ...] → 多个
        内部统一存成 set，绘制时逐个判断。

        `split_frames`（★ 2026-09-18）：处于**分离**状态的帧号集合。
          · 不在集合里（默认）→ 一体：**黄色实心 + 黑细边**
          · 在集合里           → 分离：**空心三角**
        """
        self._handle_records = list(records or [])
        self._selected = _norm_selected(selected)
        self._dragging = bool(dragging)
        self._split_frames = set()
        for f in (split_frames or []):
            try:
                self._split_frames.add(round(float(f), 4))
            except Exception:
                continue

    def refresh_colors(self):
        self._colors = get_axis_colors()

    # ---- 3D：轴约束线 ----

    def _draw_3d(self):
        s = self._session
        if s is None or getattr(s, "state", None) != "RUNNING":
            return
        axes = axes_for(getattr(s, "axis_lock", None), getattr(s, "plane_lock", None))
        if not axes:
            return
        pivot = getattr(s, "pivot_world", None)
        if pivot is None:
            return
        draw_axis_lines(pivot, axes, self._colors or _FALLBACK_AXIS)

    # ---- 2D：速度手柄 ----

    def _fresh_kf_world(self, rec):
        """每帧现算关键帧的世界位置。

        ⚠️ 不能用 rec['kf_world']：那是**收集时**的快照。
           用户拖动关键帧点后，快照就过期了 → 三角会留在原地，
           要等下一次重新收集才跳过去（用户反馈的 #4）。

        这里改为按 (obj_name, frame) 从 action 现取。
        """
        try:
            from . import modal_edit as _me
            name = rec.get('obj_name')
            obj = bpy.data.objects.get(name) if name else None
            if obj is None or not obj.animation_data or not obj.animation_data.action:
                return rec.get('kf_world')
            wp = _me.keyframe_world_pos(obj.animation_data.action, obj,
                                        rec.get('frame'), rec.get('bone_name'))
            return wp if wp is not None else rec.get('kf_world')
        except Exception:
            return rec.get('kf_world')

    def _draw_mouse_guide(self):
        """★ 复刻原生 R/S 的「支点 → 鼠标」虚线（2026-09-16）。

        ⚠️ 原生实测：R/S 模态下 Blender **隐藏系统光标并自绘**箭头 + 这条虚线。
           插件用系统光标（MOVE_Y/MOVE_X）当箭头，虚线在这里补。

        ⚠️ 只对"带支点"的变换会话（Rotate/Scale）画 —— 靠会话上的
           `mouse_guide` 标志判定，**不在 overlay 里 import modal_edit**
           （那会循环导入：modal_edit 已经 import 了 overlay）。
        """
        s = self._session
        guide = getattr(s, "mouse_guide", False)
        if s is None or not guide:
            return
        if getattr(s, "state", None) != "RUNNING":
            return
        ms = getattr(s, "mouse_screen", None)
        if ms is None:
            return
        try:
            sp = s._pivot_screen()
        except Exception:
            sp = None
        if sp is None:
            return
        draw_dashed_line_2d((sp.x, sp.y), (ms[0], ms[1]), GUIDE_COLOR)
        # ★ 双向箭头（2026-09-16）：方向 = 有效拖动方向
        #   'tangent' → 旋转 R：⊥ 连线（切向）；'radial' → 缩放 S：∥ 连线（径向）
        mode = guide if isinstance(guide, str) else 'plain'
        dx, dy = (ms[0] - sp.x), (ms[1] - sp.y)
        ln = (dx * dx + dy * dy) ** 0.5
        if mode in ('tangent', 'radial') and ln > 1e-6:
            d = (-dy / ln, dx / ln) if mode == 'tangent' else (dx / ln, dy / ln)
            draw_double_arrow_2d((ms[0], ms[1]), d)

    def _draw_2d(self):
        # ★ 引导虚线优先画（下面的手柄绘制会 early return，不能放它后面）
        self._draw_mouse_guide()
        recs = self._handle_records
        if not recs or view3d_utils is None:
            return
        ctx = bpy.context
        region = getattr(ctx, "region", None)
        rv3d = getattr(ctx, "region_data", None)
        if region is None or rv3d is None:
            return

        for rec in recs:
            kf_world = self._fresh_kf_world(rec)     # ★ 实时跟随关键帧
            if kf_world is None:
                continue
            sp = view3d_utils.location_3d_to_region_2d(region, rv3d, kf_world)
            if sp is None:
                continue

            tri = rec['tri']
            # ★ 固定偏移：三角不随疏密值移动（用户 2026-09-15）
            cx, cy = hd.tri_center((sp.x, sp.y), tri, TRI_FIXED_D)
            pointing = 'down' if tri == hd.TRI_UP else 'up'

            key = (rec['frame'], tri)
            if key in self._selected:
                color = HANDLE_DRAG_COLOR if self._dragging else HANDLE_SELECTED_COLOR
            else:
                color = HANDLE_COLOR

            # ★★ 2026-09-18（用户需求）：按【锁定状态】决定外观
            #   · 一体（默认）→ 黄色实心 + 黑色细边框
            #   · 分离        → 空心三角（描边用当前状态色，保证选中/拖拽色仍可见）
            #
            # ⚠️ 判定用 rec['frame'] 的**取整规范**，与 `_split_frames` 的存入口径
            #    一致（都走 round(...,4)）—— 否则 14.0 与 14.00000001 判不上。
            try:
                _f_norm = round(float(rec['frame']), 4)
            except Exception:
                _f_norm = None
            split = (_f_norm in self._split_frames)

            # 只有三角，没有虚线 / 标签（用户要求）
            if split:
                # 空心：不填充，描边用当前状态色（默认黄 / 选中白 / 拖拽橙红）
                draw_triangle_2d(cx, cy, pointing, color, filled=False,
                                 outline_color=color, outline_width=1.6)
            else:
                # 实心 + 黑色细边框
                draw_triangle_2d(cx, cy, pointing, color, filled=True,
                                 outline_color=HANDLE_OUTLINE_COLOR,
                                 outline_width=HANDLE_OUTLINE_WIDTH)


# 全局单例
_overlay = Overlay()


def start_overlay(session=None):
    return _overlay.start(session)


def stop_overlay():
    _overlay.stop()


def get_overlay():
    return _overlay
