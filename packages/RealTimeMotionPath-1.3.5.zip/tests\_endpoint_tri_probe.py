# -*- coding: utf-8 -*-
"""实测：端点段的三角到底能不能拖？（"有时拖动失效"的嫌疑）

假设：端点段 span is None ⇒ _apply_speed_d 静默返回 None ⇒ 三角能点中却拖不动。
"""
import os
import sys
import json

REPO = r"F:\desktop\BaiduSyncdisk\addons\RealTimeMotionPath"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import time_domain as td, handles as hd, modal_edit as me

rows = []


def rec(n, **k):
    k["name"] = n
    rows.append(k)
    print("[ROW]", json.dumps(k, ensure_ascii=False)[:900])


sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 40
bpy.ops.mesh.primitive_cube_add()
o = bpy.context.active_object
for f, loc in ((1, (0, 0, 0)), (14, (3, 0, 0)), (40, (6, 0, 0))):
    sc.frame_set(f)
    o.location = loc
    o.keyframe_insert("location", frame=f)
act = o.animation_data.action
act.name = "SpeedAct"

win = bpy.context.window_manager.windows[0]
area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
region = next(r for r in area.regions if r.type == 'WINDOW')
rv3d = area.spaces.active.region_3d

try:
    hs = me.collect_speed_handles(act, o, region, rv3d)
    rec("T4 收集到的三角", 个数=len(hs),
        明细=[{"frame": h["frame"], "tri": h["tri"],
               "d": round(h["d"], 3), "s": round(h["s"], 4),
               "span": (None if h.get("span") is None else "有")} for h in hs])

    out = []
    for h in hs:
        side = hd.SIDE_BY_TRI[h["tri"]]
        kf_map, span = td.resolve_target(act, o, h["frame"], side)
        out.append({"frame": h["frame"], "tri": h["tri"], "side": side,
                    "kf_map非空": bool(kf_map),
                    "span": (None if span is None else "有"),
                    "★可拖": bool(kf_map) and span is not None})
    rec("T5 ★ resolve_target 逐三角", 明细=out)

    # ★★ 关键：走【完整拖拽路径】_apply_speed_from_drag，看数据到底变没变
    from RealTimeMotionPath import interaction as it
    from RealTimeMotionPath.state import _session

    def s_of(o2, act2, frame, side):
        kf_map, span = td.resolve_target(act2, o2, frame, side)
        if not kf_map or span is None:
            return None
        any_kp = next(iter(kf_map.values()))
        v = td.read_s(any_kp, span, side)     # 签名：read_s(keyframe, span, side)
        return None if v is None else round(float(v), 6)

    out2 = []
    for h in hs:
        fr, tri = h["frame"], h["tri"]
        side = hd.SIDE_BY_TRI[tri]
        s_before = s_of(o, act, fr, side)

        # 模拟一次"按下 → 移动 20px"
        _session.selected_speed_handles = [(fr, tri)]
        _session.speed_drag_origins = {(fr, tri): h["d"]}
        _session.speed_drag_origin_d = h["d"]
        _session.speed_drag_effective_px = 0.0
        _session.speed_drag_precision = False
        _session.speed_drag_last_mouse = (500.0, 500.0)
        r1 = it._apply_speed_from_drag(bpy.context, o, (500.0, 500.0))   # 首次=记起点
        r2 = it._apply_speed_from_drag(bpy.context, o, (500.0, 480.0))   # 上移 20px
        s_after = s_of(o, act, fr, side)

        out2.append({"frame": fr, "tri": tri, "side": side,
                     "s_前": s_before, "s_后": s_after,
                     "首次返回": r1, "移动后返回": (None if r2 is None else round(r2, 6)),
                     "★写进去了": (s_before is not None and s_after is not None
                                and abs(s_after - s_before) > 1e-9)})
        # 复位，避免互相影响
        _session.speed_drag_effective_px = 0.0
    rec("T6 ★★ 走完整拖拽路径（上移 20px）", 明细=out2)

except Exception:
    import traceback
    rec("FATAL", tb=traceback.format_exc()[-1200:])

with open(os.path.join(HERE, "_endpoint_tri_result.json"), "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=1)
print("ENDPOINT_TRI_DONE")
os._exit(0)
