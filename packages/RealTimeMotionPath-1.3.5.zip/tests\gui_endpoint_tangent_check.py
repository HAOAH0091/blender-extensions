# -*- coding: utf-8 -*-
"""零长端点手柄拖出 ⇒ 方向锁切线（A）+ 极短基线不同比例（B）。

用户报告（2026-09-17）
--------------------
> "我关闭重开工程，然后拖尾部端点的手柄出来时，尾部端点的手柄不会和路径相切，
>   也没有和路径有预期交互"

从【磁盘干净状态】（末帧内侧手柄 = 0 长、AUTO_CLAMPED）实测，是两个独立问题：

**A：方向 = 纯鼠标方向（不相切）**
    零长手柄的基线是 0 ⇒ 同比例"无定义" ⇒ 走退化分支（只写鼠标位移）
    ⇒ 手柄方向 = 鼠标拖动方向。实测（只改拖动方向）与来路夹角：
        沿 +X → 155.4° ；沿 +Y → 95.0° ；沿 +Z → 66.0° ；斜 X+Y → 134.8°
    碰巧沿切线拖时才看着正常 ⇒ 用户"有时对有时不对、难复现"。

**B：极短基线 ⇒ dt 爆炸**
    k = |dv_new| / |dv_base| ⇒ 基线越短 k 越大 ⇒ dt = dt_base · k 爆掉。
    实测 L0=0.0242 → 拖到 3.96 → k=164.6 → dt = 1646.3（用户实测 1634 同源）。
    dt 过大 ⇒ 曲线该段饱和 ⇒ **拖手柄路径几乎不动**（"没有预期交互"）。

修法
----
A：零长（≤ UNIFORM_LEN_MIN）**端点内侧**手柄拖出时，方向锁到**路径切向**
   （`interaction._path_tangent_unit`，自适应步长），长度仍跟鼠标。
B：`transform_domain.handle_scale_k` 在 `L0 <= UNIFORM_LEN_MIN(1.0)` 时返回 None
   ⇒ 退回"只写 dv、dt 不变"（与"端点第一次拖出"的既定行为一致）。

⚠️ 两个踩坑记录（都在这里钉住，防回归）
--------------------------------------
1. **eps 必须自适应**：端点处曲线常"减速到停"（dv≈0）⇒ 位移 ∝ eps²。
   实测 f55：eps=0.01 时 |位移| = 2e-6（**纯浮点噪声**）⇒ 方向随机（差 19.5°）；
   eps ≥ 0.05 才稳定。⇒ `_path_tangent_unit` 从小步长起试，取第一个脱离噪声的。
2. **"端点内侧"不能用 `span is None` 判断**：实测 f55 的**左手柄**（内侧）
   返回 span=30.0；`span is None` 对应**朝外**那一侧，正好相反。
   ⇒ 判据 = 首帧的 right / 末帧的 left。
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, interaction as it

OUT = os.path.join(HERE, "_endpoint_tangent_result.json")
steps = []

KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))
F0, FM, F1 = 1.0, 25.0, 55.0


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:2000]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


def build(name):
    """建 3 关键帧对象（全 FREE，控制变量）。

    端点内侧手柄保持**零长**（= 用户"重开工程"时的状态）。
    """
    sc = bpy.context.scene
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in KFS:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(1)
    a = o.animation_data.action
    for c in xf._position_curves(a, o, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        c.update()
    bpy.context.view_layer.objects.active = o
    for ob in bpy.data.objects:
        ob.select_set(ob is o)
    return o, a


def curves(o):
    return {c.array_index: c for c in
            xf._position_curves(o.animation_data.action, o, None)}


def kf(o, frame, ax):
    for k in curves(o)[ax].keyframe_points:
        if abs(k.co[0] - frame) < 1e-3:
            return k


def hvec(o, frame, side):
    v = []
    for ax in (0, 1, 2):
        k = kf(o, frame, ax)
        h = k.handle_left if side == 'left' else k.handle_right
        v.append(float(h[1]) - float(k.co[1]))
    return v


def dt(o, frame, side='left'):
    k = kf(o, frame, 0)
    return (float(k.co[0]) - float(k.handle_left[0])) if side == 'left' \
        else (float(k.handle_right[0]) - float(k.co[0]))


def unit(v):
    n = math.sqrt(sum(x * x for x in v))
    return ([x / n for x in v] if n > 1e-12 else [0.0, 0.0, 0.0]), n


def ang(u, v):
    d = sum(u[i] * v[i] for i in range(3))
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def ref_macro(o, frame, side, span=2.0):
    """参照① 宏观差分：P(frame ∓ span) − P(frame)（独立于被测函数）"""
    c = curves(o)
    s = -1.0 if side == 'left' else 1.0
    p0 = [float(c[ax].evaluate(frame)) for ax in (0, 1, 2)]
    p1 = [float(c[ax].evaluate(frame + s * span)) for ax in (0, 1, 2)]
    return unit([p1[i] - p0[i] for i in range(3)])[0]


def ref_pca(o, frame, side, window=5.0):
    """参照② PCA：对 [frame-window, frame] 采样点求主方向（≈肉眼看到的走向）"""
    c = curves(o)
    n = 40
    pts = [[float(c[ax].evaluate(frame - window * k / n)) for ax in (0, 1, 2)]
           for k in range(n + 1)]
    cen = [sum(p[i] for p in pts) / len(pts) for i in range(3)]
    cov = [[sum((p[i] - cen[i]) * (p[j] - cen[j]) for p in pts) for j in range(3)]
           for i in range(3)]
    v = [1.0, 0.3, -0.4]
    for _ in range(60):
        w = [sum(cov[i][j] * v[j] for j in range(3)) for i in range(3)]
        nv = math.sqrt(sum(x * x for x in w))
        if nv < 1e-15:
            break
        v = [x / nv for x in w]
    u = unit(v)[0]
    # 与"来路"对齐符号（左手柄应指向来路）
    if side == 'left':
        ref = ref_macro(o, frame, side)
    else:
        ref = ref_macro(o, frame, side)
    if sum(u[i] * ref[i] for i in range(3)) < 0:
        u = [-x for x in u]
    return u


def make_shim():
    """造一个能调 operator 内部方法的假实例。

    ⚠️ Blender 的 `bpy.types.Operator` **不能直接实例化**（实测：
       `bpy_struct.__new__(struct): expected a single argument`），
       子类化也不行。⇒ 只能把类上的成员**逐个拷到假类**上。
       实测这样能拿到 `record_handle_baseline` / `record_endpoint_snapshot` /
       `apply_handle_point_offset` 等全部需要的绑定方法。
    """
    class Shim:
        def report(self, *a, **k):
            pass

    cls = it.RTMP_OT_PathPointDrag
    for name in dir(cls):
        if name.startswith("__"):
            continue
        try:
            setattr(Shim, name, getattr(cls, name))
        except Exception:
            pass
    return Shim()


SHIM = make_shim()


def drag(o, frame, side, offs):
    """走【拖端点空心圆】的真实入口 `apply_handle_point_offset`。"""
    a = o.animation_data.action
    bpy.context.view_layer.objects.active = o
    for ob in bpy.data.objects:
        ob.select_set(ob is o)
    it._session.active_frame_number = float(frame)
    it._session.active_handle_direction = side
    it._session.active_bone_identifier = None
    it._session.handle_start_values.clear()
    SHIM.record_handle_baseline(bpy.context, float(frame), None, side)
    hp = {"frame": float(frame), "side": side, "bone_name": None}
    for off in offs:
        SHIM.apply_handle_point_offset(bpy.context, mathutils.Vector(off), hp)
    it._session.handle_start_values.clear()
    return o


# ================================================================ A 组
try:
    # A1：朝任意方向拖 ⇒ 手柄方向都相同（不再跟随鼠标）
    DIRS = [(1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0),
            (1.0, 1.0, 0.0), (-1.0, 0.0, 0.0), (0.5, 1.5, 2.5)]
    got = []
    for off in DIRS:
        o, a = build("_ET1")
        drag(o, F1, 'left', [off])
        got.append(unit(hvec(o, F1, 'left'))[0])
    base = got[0]
    maxdev = max(ang(g, base) for g in got)
    step("A1 ★★★ 零长端点手柄：朝任意方向拖 ⇒ 手柄方向【完全相同】",
         maxdev < 1.0, "6 个方向彼此最大夹角 %.3f°" % maxdev)

    # A2/A3：与两个独立参照相切
    o, a = build("_ET2")
    r1 = ref_macro(o, F1, 'left')
    r2 = ref_pca(o, F1, 'left')
    drag(o, F1, 'left', [(2.0, 0.0, 0.0)])
    u = unit(hvec(o, F1, 'left'))[0]
    a1, a2 = ang(u, r1), ang(u, r2)
    step("A2 ★★★ 与【宏观差分】参照相切（<3°）", a1 < 3.0,
         "夹角 %.2f°  手柄=%s 参照=%s"
         % (a1, [round(x, 3) for x in u], [round(x, 3) for x in r1]))
    step("A3 ★★★ 与【PCA】参照相切（<3°）", a2 < 3.0, "夹角 %.2f°" % a2)

    # A4：长度跟手（= 鼠标位移长度）
    #    ⚠️ 每个 case 都要 **rebuild**（从零长起点拖）—— 首版在同一个对象上连续拖，
    #       第二次的基线已非零 ⇒ 走同比例 ⇒ 长度不是 2.5（**测试自己写错了**）。
    for off, want in (((2.0, 0.0, 0.0), 2.0), ((1.5, 2.0, 0.0), 2.5)):
        o, a = build("_ET3")
        drag(o, F1, 'left', [off])
        L = unit(hvec(o, F1, 'left'))[1]
        step("A4 长度跟手：位移 |%s| = %.2f ⇒ 手柄长 %.4f"
             % (str(off), want, L), abs(L - want) < 1e-4, "")

    # A5：首帧内侧（right）也锁
    o, a = build("_ET4")
    r1f = ref_macro(o, F0, 'right')
    drag(o, F0, 'right', [(0.0, 2.0, 0.0)])
    u = unit(hvec(o, F0, 'right'))[0]
    step("A5 ★★ 首帧内侧（right）同样锁切线",
         ang(u, r1f) < 3.0,
         "夹角 %.2f°  手柄=%s" % (ang(u, r1f), [round(x, 3) for x in u]))

    # A6：不崩 —— 单关键帧对象
    sc = bpy.context.scene
    o6 = bpy.data.objects.get("_ET5")
    if o6:
        bpy.data.objects.remove(o6, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o6 = bpy.context.active_object
    o6.name = "_ET5"
    sc.frame_set(1)
    o6.location = (0, 0, 0)
    o6.keyframe_insert("location", frame=1)
    a6 = o6.animation_data.action
    d = it._path_tangent_unit(a6, o6, 1.0, 'left', None)
    step("A6 单关键帧 / 无相邻段 ⇒ _path_tangent_unit 安全返回（None 或向量）",
         d is None or len(d) == 3, "返回 %r" % (d,))

    # ============================================================ B 组（不误伤）
    # B1：中间帧零长手柄 ⇒ 不锁（保留自由拖）
    o, a = build("_ET6")
    # 把 f25 的手柄清零
    for ax in (0, 1, 2):
        k = kf(o, FM, ax)
        k.handle_left = (17.0, float(k.co[1]))
        k.handle_right = (35.0, float(k.co[1]))
    for c in curves(o).values():
        c.update()
    drag(o, FM, 'left', [(0.0, 2.0, 0.0)])
    u = unit(hvec(o, FM, 'left'))[0]
    step("B1 ★★ 中间帧零长手柄【不锁】（保留自由拖方向）",
         abs(abs(u[1]) - 1.0) < 1e-6,
         "沿 +Y 拖 ⇒ 手柄=%s（应 ≈[0,1,0]）" % [round(x, 3) for x in u])

    # B2：端点手柄**已有长度** ⇒ **不锁切线**（走同比例）
    #   ⚠️ 同比例模式下方向本来就**跟鼠标**（dv = dv_new，用户要自由拖 + 保速）
    #      ⇒ 判据不是"方向不变"，而是"方向明显偏离切线"（= 锁没介入）。
    o, a = build("_ET7")
    for ax in (0, 1, 2):
        k = kf(o, F1, ax)
        k.handle_left = (45.0, float(k.co[1]) + (2.0 if ax == 0 else 0.0))
    for c in curves(o).values():
        c.update()
    #   ⚠️ 别用"与切线夹角大"当判据 —— 实测沿 +Z 拖时，向量和 [2,0,0]+[0,0,1.5]
    #      的归一方向恰好 ≈ 新曲线的切线（**巧合**），判别不出来。
    #      改用**定义式**：手柄应 = 基线 + 鼠标位移（向量和）⇒ 与它比对。
    drag(o, F1, 'left', [(0.0, 0.0, -1.5)])
    u = unit(hvec(o, F1, 'left'))[0]
    expect = unit([2.0, 0.0, -1.5])[0]        # 基线 [2,0,0] + 位移 [0,0,-1.5]
    dev = ang(u, expect)
    step("B2 ★ 端点手柄已有长度（>阈值）⇒ 【不锁切线】（手柄 = 基线 + 鼠标位移）",
         dev < 5.0,
         "手柄=%s  期望(基线+位移)=%s  夹角=%.2f°（小=走同比例/退化，没锁）"
         % ([round(x, 3) for x in u], [round(x, 3) for x in expect], dev))

    # B3：判据函数本身的语义
    o, a = build("_ET8")
    ck = (it._is_endpoint_inner_handle(a, o, F1, 'left', None),
          it._is_endpoint_inner_handle(a, o, F0, 'right', None),
          it._is_endpoint_inner_handle(a, o, F1, 'right', None),
          it._is_endpoint_inner_handle(a, o, F0, 'left', None),
          it._is_endpoint_inner_handle(a, o, FM, 'left', None))
    step("B3 ★★ 「端点内侧」判据：末帧-left / 首帧-right 为真，其余为假",
         ck == (True, True, False, False, False), "实测 %s" % (ck,))

    # ============================================================ C 组（dt 不爆）
    o, a = build("_ET9")
    d0 = dt(o, F1)
    drag(o, F1, 'left', [(0.02, 0.0, 0.0)])          # 第一次：拖出极短
    d1 = dt(o, F1)
    Lb = unit(hvec(o, F1, 'left'))[1]
    drag(o, F1, 'left', [(3.96, 0.0, 0.0)])          # 第二次：拖到很长
    d2 = dt(o, F1)
    step("C1 ★★★ 极短基线（0.02）→ 松手 → 再拖到 3.96 ⇒ dt 【不爆炸】",
         d1 == d0 and d2 == d0,
         "dt: 原始 %.1f → 拖出短后 %.1f → 再拖长后 %.1f（应恒为 %.1f）"
         % (d0, d1, d2, d0))

    # C2：正常基线 ⇒ 照常同比例（dt 随 k 变 = 保速）
    o, a = build("_ET10")
    for ax in (0, 1, 2):
        k = kf(o, F1, ax)
        k.handle_left = (45.0, float(k.co[1]) + (3.0 if ax == 0 else 0.0))
    for c in curves(o).values():
        c.update()
    dA = dt(o, F1)
    drag(o, F1, 'left', [(3.0, 0.0, 0.0)])           # 拖到 ~6（k≈2）
    dB = dt(o, F1)
    step("C2 正常基线（3.0）：仍走同比例（dt 随 k 变 ⇒ 保速）",
         dB > dA + 1.0, "dt %.3f → %.3f" % (dA, dB))

    # C3：阈值边界
    res = []
    for L0 in (0.99, 1.01):
        o, a = build("_ET11")
        for ax in (0, 1, 2):
            k = kf(o, F1, ax)
            k.handle_left = (45.0, float(k.co[1]) + (L0 if ax == 0 else 0.0))
        for c in curves(o).values():
            c.update()
        kk = xf.handle_scale_k([L0, 0.0, 0.0], [4.0, 0.0, 0.0], [10.0, 10.0, 10.0], 30.0)
        res.append(kk is None)
    step("C3 ★ 阈值边界：L0=0.99 ⇒ 不同比例(None)；L0=1.01 ⇒ 同比例",
         res == [True, False], "0.99→%s  1.01→%s" % (res[0], res[1]))

    # ============================================================ D 组（静态契约）
    src_it = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    src_xf = open(os.path.join(REPO, "transform_domain.py"), encoding="utf-8").read()
    step("D1 handle_scale_k 用 UNIFORM_LEN_MIN 判据",
         "L0 <= UNIFORM_LEN_MIN" in src_xf and "UNIFORM_LEN_MIN = 1.0" in src_xf,
         "")
    step("D2 ★ _path_tangent_unit 用自适应步长（不再固定 eps=0.01）",
         "for eps in (0.05, 0.1, 0.5, 1.0, 2.0, 5.0)" in src_it
         and "def _path_tangent_unit(action, obj, frame, side, bone_name=None):" in src_it,
         "")
    n_lock = src_it.count("_is_endpoint_inner_handle(")
    step("D3 ★★ 两条拖拽路径都接上了方向锁（+ 判据函数定义）",
         n_lock >= 3, "出现 %d 次（应 ≥3：判据定义处的调用 + 两条路径）" % n_lock)
    # ⚠️ 只看**函数体代码**（docstring 里明确记录了"别用 span is None"这个坑，
    #    含该字串是**故意的**）⇒ 按三引号切出 docstring 之后的代码再判断。
    _blk = src_it.split("def _is_endpoint_inner_handle")[1] \
        .split("def _path_tangent_unit")[0]
    _body = _blk.split('"""')[-1]
    step("D4 ★ 「端点内侧」判据【代码】不用 resolve_target/span（踩过的坑）",
         "resolve_target" not in _body and "span" not in _body,
         "函数体长度 %d 字符" % len(_body))

    # ============================================================ E 组（注入）
    def _scen_A1():
        """朝任意方向拖 ⇒ 方向是否恒定（= 方向锁生效）。"""
        gs = []
        for off in DIRS:
            o, a = build("_EI1")
            drag(o, F1, 'left', [off])
            gs.append(unit(hvec(o, F1, 'left'))[0])
        return max(ang(g, gs[0]) for g in gs) < 1.0

    def _scen_C1():
        o, a = build("_EI2")
        d0 = dt(o, F1)
        drag(o, F1, 'left', [(0.02, 0.0, 0.0)])
        d1 = dt(o, F1)
        drag(o, F1, 'left', [(3.96, 0.0, 0.0)])
        return dt(o, F1) == d0 and d1 == d0

    def _mk_no_dir_lock():
        _o = it._path_tangent_unit

        def do():
            it._path_tangent_unit = lambda *a, **k: None

        def undo():
            it._path_tangent_unit = _o
        return do, undo, "I1 方向锁失效（_path_tangent_unit→None）"

    def _mk_fixed_eps():
        """I2：固定 eps=0.01（旧实现）⇒ 位移落在浮点噪声 ⇒ 方向随机。"""
        _o = it._path_tangent_unit

        def bad(action, obj, frame, side, bone_name=None):
            try:
                cs = {}
                for fc in it.collect_animation_curves(action, obj):
                    if it.is_position_animation(fc, bone_name):
                        cs[fc.array_index] = fc
                if not cs:
                    return None
                d = (0.01 if side == 'right' else -0.01)
                v = [float(cs[ax].evaluate(frame + d)) - float(cs[ax].evaluate(frame))
                     for ax in (0, 1, 2)]
                n = math.sqrt(sum(x * x for x in v))
                return [x / n for x in v] if n > 1e-12 else None
            except Exception:
                return None

        def do():
            it._path_tangent_unit = bad

        def undo():
            it._path_tangent_unit = _o
        return do, undo, "I2 固定 eps=0.01（落在浮点噪声 ⇒ 方向随机/偏 19°）"

    def _mk_len_eps():
        _o = xf.UNIFORM_LEN_MIN

        def do():
            xf.UNIFORM_LEN_MIN = xf.UNIFORM_LEN_EPS    # 退回旧判据

        def undo():
            xf.UNIFORM_LEN_MIN = _o
        return do, undo, "I3 基线判据退回 EPS(1e-6) ⇒ 极短基线仍走同比例 ⇒ dt 爆"

    base = (_scen_A1(), _scen_C1())
    step("E0 基线：未注入时两个场景都通过", all(base), "A1/C1 = %s" % (base,))
    for mk, chk in ((_mk_no_dir_lock, _scen_A1), (_mk_len_eps, _scen_C1)):
        do, undo, label = mk()
        try:
            do()
            caught = not chk()
        except Exception:
            caught = True
            label += "（异常也算抓住）"
        finally:
            undo()
        step("★ %s ⇒ 测试抓住" % label, caught, "")

    # I2 单独判：固定 eps 应该让"相切"变差（角度变大）
    o, a = build("_EI3")
    r1 = ref_macro(o, F1, 'left')
    do, undo, label = _mk_fixed_eps()
    try:
        do()
        drag(o, F1, 'left', [(2.0, 0.0, 0.0)])
        u_bad = unit(hvec(o, F1, 'left'))[0]
        a_bad = ang(u_bad, r1)
    except Exception:
        a_bad = -1.0
    finally:
        undo()
    o, a = build("_EI3b")
    drag(o, F1, 'left', [(2.0, 0.0, 0.0)])
    a_good = ang(unit(hvec(o, F1, 'left'))[0], ref_macro(o, F1, 'left'))
    step("★ %s ⇒ 相切角度明显变差（测试能区分）" % label,
         a_bad > a_good * 3 and a_bad > 3.0,
         "固定 eps 夹角 %.2f°  vs  自适应 %.2f°" % (a_bad, a_good))

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-900:])
finally:
    try:
        it._session.handle_start_values.clear()
    except Exception:
        pass

try:
    for n in ("_ET1", "_ET2", "_ET3", "_ET4", "_ET5", "_ET6", "_ET7", "_ET8",
              "_ET9", "_ET10", "_ET11", "_EI1", "_EI2", "_EI3", "_EI3b"):
        x = bpy.data.objects.get(n)
        if x:
            bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
