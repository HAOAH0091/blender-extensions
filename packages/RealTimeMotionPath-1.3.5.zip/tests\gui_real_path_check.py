# -*- coding: utf-8 -*-
"""真实操作路径驱动测试（走 operator.modal，不手动塞 session 状态）

为什么需要它
------------
之前用"手动设置 `_session` 状态 + 直接调内部函数"的方式测速度手柄，
**结果漏掉了一个真实崩溃**：

    AttributeError: 'MotionPathSession' object has no attribute '_mouse_pos'

因为测试自己往 session 上塞了 `_mouse_pos`（真实运行时不存在的属性），
于是掩盖了"代码从哪里读鼠标位置"这个错误。

本测试改为**真实驱动**：
    构造 fake context / fake event（鸭子类型，指向真实的 area/region/rv3d），
    直接调用 `RTMP_OT_PathPointDrag.modal(fake_self, ctx, event)`，
    完整走一遍用户的操作序列：

        ① LEFTMOUSE PRESS 在三角上   -> 选中三角、进入拖拽
        ② MOUSEMOVE（拖远）           -> ★ 曾经在这里崩
        ③ LEFTMOUSE RELEASE          -> 结束拖拽，保留选中

fake_self 只提供 operator 的**实例属性**（`_mouse_pos` 等，都是类里真实定义的），
绝不给 session 凭空加属性。

用法：blender --factory-startup --python tests/gui_real_path_check.py
"""
import bpy, os, sys, json, traceback, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_rp_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())


class FakeEvent:
    """鸭子类型的 Blender 事件。"""
    def __init__(self, type_, value='PRESS', mouse_x=0.0, mouse_y=0.0,
                 shift=False, ctrl=False, alt=False):
        self.type = type_
        self.value = value
        self.mouse_x = mouse_x            # 全局坐标（find_region_under_mouse 用）
        self.mouse_y = mouse_y
        self.mouse_region_x = mouse_x     # 会在下面被覆盖成 region 局部
        self.mouse_region_y = mouse_y
        self.shift = shift
        self.ctrl = ctrl
        self.alt = alt


class FakeOp:
    """operator 实例的替身：只带真实存在的实例属性。"""
    def __init__(self):
        self._mouse_pos = None            # 真实类属性（interaction.py 里定义）
        self._last_draw_time = 0.0
        self._timer = None
        self._is_active = True
        self._redraw_count = 0
        self._last_frame = None


try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
           (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath import overlay as ovmod
    from RealTimeMotionPath.state import _session

    step("addon loaded from REPO",
         os.path.normcase(os.path.dirname(os.path.abspath(inter.__file__))) == os.path.normcase(REPO),
         inter.__file__)

    # 匀速基线 + 全 FREE
    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        pts = list(fc.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()

    wm = bpy.context.window_manager
    wm.rtmp_path_display_enabled = True
    wm.rtmp_edit_mode_active = True

    win = wm.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    # ---- fake context（指向真实的 area/region/window） ----
    class FakeCtx:
        pass
    ctx = FakeCtx()
    ctx.window = win
    ctx.window_manager = wm
    ctx.area = area
    ctx.region = region
    ctx.region_data = rv3d
    ctx.screen = win.screen
    ctx.active_object = obj
    ctx.scene = sc

    # ---- 覆盖层（path_point_drag.invoke 会做的事） ----
    over = ovmod.get_overlay()
    over.stop()
    over.start(session=None)
    _session.clear_speed_handle()

    # ---- 取三角的屏幕位置 -> 全局鼠标坐标 ----
    from RealTimeMotionPath import modal_edit as me
    recs = me.collect_speed_handles(act, obj, region, rv3d)
    r14d = [r for r in recs if r['frame'] == 14.0 and r['tri'] == hd.TRI_DOWN][0]
    tri_local = r14d['tri_screen']
    # region 局部 -> 全局
    gx = region.x + tri_local[0]
    gy = region.y + tri_local[1]
    step("have triangle screen pos", tri_local is not None,
         "local=(%.0f,%.0f) global=(%.0f,%.0f)" % (tri_local[0], tri_local[1], gx, gy))

    def ev(type_, value='PRESS', local=None, shift=False):
        e = FakeEvent(type_, value, mouse_x=gx, mouse_y=gy, shift=shift)
        if local is not None:
            e.mouse_region_x, e.mouse_region_y = local
        else:
            e.mouse_region_x, e.mouse_region_y = tri_local
        return e

    op = FakeOp()
    Modal = inter.RTMP_OT_PathPointDrag.modal

    # ================= ① LEFTMOUSE PRESS 命中三角 =================
    try:
        r = Modal(op, ctx, ev('LEFTMOUSE', 'PRESS'))
        step("① modal(LEFTMOUSE PRESS) ran", True, "returned %s" % (r,))
    except Exception as e:
        step("① modal(LEFTMOUSE PRESS) ran", False, "%s: %s" % (type(e).__name__, e))
        flush(); os._exit(0)

    step("① triangle selected", _session.selected_speed_frame == 14.0,
         "frame=%s tri=%s" % (_session.selected_speed_frame, _session.selected_speed_tri))
    step("① drag armed (speed_drag_active)", _session.speed_drag_active is True,
         _session.speed_drag_active)
    step("① origin recorded", _session.speed_drag_origin_mouse is not None,
         _session.speed_drag_origin_mouse)

    # ================= ② MOUSEMOVE ★ 曾经的崩溃点 =================
    def first_dist():
        for fc in xf._position_curves(act, obj, None):
            if fc.array_index == 0:
                X = [fc.evaluate(f) for f in range(1, 41)]
                return abs(X[14] - X[13])

    base = first_dist()
    # 往下拖 60px（下三角：往下 = 更疏）。用【真实路径】：设置 operator 的 _mouse_pos
    op._mouse_pos = (tri_local[0], tri_local[1] - 60)
    try:
        r2 = Modal(op, ctx, ev('MOUSEMOVE', 'NOTHING',
                               local=(tri_local[0], tri_local[1] - 60)))
        step("② ★ modal(MOUSEMOVE) did NOT crash (former AttributeError point)",
             True, "returned %s" % (r2,))
    except Exception as e:
        step("② ★ modal(MOUSEMOVE) did NOT crash (former AttributeError point)",
             False, "%s: %s" % (type(e).__name__, e))
    after = first_dist()
    step("② drag down -> sparser", after > base * 1.1,
         "%.6f -> %.6f (%.2fx)" % (base, after, after / base))

    # 再拖远一点
    # ⚠️ 断言用"单调不降"而非"显著增大"：段长是固定的，帧距存在物理上限
    #    （本场景收敛到 ≈0.828），越接近饱和变化越小 —— 那是数学必然，不是限制。
    op._mouse_pos = (tri_local[0], tri_local[1] - 140)
    try:
        Modal(op, ctx, ev('MOUSEMOVE', 'NOTHING', local=(tri_local[0], tri_local[1] - 140)))
        step("② continued drag ok (monotone non-decreasing)",
             first_dist() >= after - 1e-9,
             "%.6f -> %.6f" % (after, first_dist()))
    except Exception as e:
        step("② continued drag ok (monotone non-decreasing)", False,
             "%s: %s" % (type(e).__name__, e))

    # ================= ③ LEFTMOUSE RELEASE =================
    try:
        Modal(op, ctx, ev('LEFTMOUSE', 'RELEASE'))
        step("③ modal(LEFTMOUSE RELEASE) ran", True)
    except Exception as e:
        step("③ modal(LEFTMOUSE RELEASE) ran", False, "%s: %s" % (type(e).__name__, e))
    step("③ drag ended", _session.speed_drag_active is False, _session.speed_drag_active)
    step("③ selection KEPT after release", _session.selected_speed_frame == 14.0,
         _session.selected_speed_frame)

    # ================= ④ 反复循环（"一顿操作"） =================
    ok_cycles = True
    for i in range(3):
        try:
            Modal(op, ctx, ev('LEFTMOUSE', 'PRESS'))
            op._mouse_pos = (tri_local[0], tri_local[1] - 40)
            Modal(op, ctx, ev('MOUSEMOVE', 'NOTHING', local=(tri_local[0], tri_local[1] - 40)))
            Modal(op, ctx, ev('LEFTMOUSE', 'RELEASE'))
        except Exception as e:
            ok_cycles = False
            step("④ cycle %d" % i, False, "%s: %s" % (type(e).__name__, e))
            break
    if ok_cycles:
        step("④ 3 full press/drag/release cycles OK", True)
    step("④ overlay pixel handler survived", over.has_pixel, over.has_pixel)

    # ================= ⑤ 全程走完还能改（选中保持） =================
    # ⚠️ 现在用多选集合（selected_speed_handles）作为路由依据，单值字段只作兼容
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    tgt = me._resolve_target_preferring_selection(ctx, obj, act, 5.0, 5.0)
    step("⑤ selection routing intact after cycles",
         bool(tgt) and tgt["frame"] == 14.0 and tgt["side"] == 'left',
         tgt and (tgt["frame"], tgt["side"]))

    _session.clear_speed_handle()
    over.stop()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("REAL_PATH_CHECK_DONE")
os._exit(0)
