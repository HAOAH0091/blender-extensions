"""RealTimeMotionPath 回归测试

用法
----
    blender --background --factory-startup --python tests/regression.py

Windows 下双击 tests\\run_tests.bat 亦可。

判定口径（重要）
----------------
本插件的设计目标是「位移动画路径的实时显示与直接编辑」。
路径的采样点定义为：

    物体  ->  物体原点的世界位置
    骨骼  ->  骨骼 head（关节点）的世界位置

与 Blender 原生运动路径的默认行为（bake_location='HEADS'）一致。
父级变换在绘制阶段施加，因此「路径随当前帧的父级位置整体摆放」
是设计预期，不作为错误。

标注 [NOTE] 的项是「已知行为 / 设计范围外」，不计入失败。

退出码
------
    0 = 全部通过（NOTE 不算失败）
    1 = 存在 FAIL
"""

import contextlib
import io
import mathutils
import os
import re
import sys
import time
import traceback

import bpy

# --------------------------------------------------------------------------
# 定位插件：测的是本项目里的源码，而非 Blender 里已安装的副本
# --------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
ADDON_NAME = os.path.basename(ADDON_DIR)
_PARENT = os.path.dirname(ADDON_DIR)
if _PARENT not in sys.path:
    sys.path.insert(0, _PARENT)

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

TOL = 1e-5            # 位置误差容差
PERF_BUDGET_MS = 50.0  # 250 帧刷新的耗时上限（实测约 1 ms）

_results = []


def check(name, ok, detail=""):
    _results.append(("PASS" if ok else "FAIL", name, detail))


def note(name, detail=""):
    _results.append(("NOTE", name, detail))


def fresh():
    """重置到干净场景并启用插件，返回 cache 模块。"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.preferences.addon_enable(module=ADDON_NAME)
    from RealTimeMotionPath import cache
    return cache


def drawn_world(cache, obj, frames, bone=None):
    """按绘制路径复算世界坐标：本地坐标 × 父级变换。

    注意：父级变换取自「当前帧」（与绘制行为一致），因此必须逐帧重新取，
    否则父级带动画时会用到错误的矩阵。
    """
    act = obj.animation_data.action
    local = cache.compute_motion_positions(obj, act, frames, target_bone=bone)
    out = {}
    for f in frames:
        bpy.context.scene.frame_set(f)
        bpy.context.view_layer.update()
        pbone = obj.pose.bones[bone] if bone else None
        pm = cache.resolve_parent_transform(obj, pbone)
        out[f] = pm @ local[f]["position"]
    return out


def worst_error(got, frames, target_fn):
    """逐帧比较复算结果与目标函数返回的世界位置，返回最大误差。"""
    worst = 0.0
    for f in frames:
        bpy.context.scene.frame_set(f)
        bpy.context.view_layer.update()
        worst = max(worst, (got[f] - target_fn(f)).length)
    return worst


# ==========================================================================
# 测试项
# ==========================================================================

def t_source():
    """自检：确认加载的是本项目源码，而非 Blender 用户目录里的副本。

    若加载到副本，后续所有测试都在测错误的代码 —— 这比测试失败更危险。
    """
    lib = sys.modules.get(ADDON_NAME)
    if lib is None:
        check("测试目标为本项目源码", False, "模块未加载")
        return
    loaded = os.path.dirname(os.path.abspath(getattr(lib, "__file__", "")))
    same = os.path.normcase(loaded) == os.path.normcase(ADDON_DIR)
    check("测试目标为本项目源码", same,
          "加载自 %s" % loaded if same else
          "**加载的是 %s，而非 %s**" % (loaded, ADDON_DIR))


def t_load():
    """加载 / 卸载 / 重装。"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    try:
        bpy.ops.preferences.addon_enable(module=ADDON_NAME)
    except Exception as e:
        check("插件加载", False, repr(e))
        return
    props = [p for p in dir(bpy.types.WindowManager) if p.startswith("rtmp_")]
    ops = len(dir(bpy.ops.rtmp)) if hasattr(bpy.ops, "rtmp") else 0
    check("插件加载", True, "WM 属性 %d 个 / Operator %d 个" % (len(props), ops))
    t_source()

    try:
        bpy.ops.preferences.addon_disable(module=ADDON_NAME)
        left = [p for p in dir(bpy.types.WindowManager) if p.startswith("rtmp_")]
        check("卸载无残留", not left, ("残留: %s" % left) if left else "零残留")
        bpy.ops.preferences.addon_enable(module=ADDON_NAME)
        check("二次启用无冲突", True, "")
    except Exception as e:
        check("卸载 / 重装", False, repr(e))


def t_core():
    """核心数值：路径点是否等于 F-Curve 求值。"""
    cache = fresh()
    bpy.ops.mesh.primitive_cube_add()
    o = bpy.context.active_object
    o.keyframe_insert("location", index=0, frame=1)
    o.location = (10, 5, 0)
    o.keyframe_insert("location", index=0, frame=10)
    o.keyframe_insert("location", index=1, frame=10)
    act = o.animation_data.action
    frames = [1, 5, 10]
    pos = cache.compute_motion_positions(o, act, frames)
    curves = {c.array_index: c for c in cache.collect_animation_curves(act)
              if c.data_path == "location"}
    worst = 0.0
    for f in frames:
        for ax, c in curves.items():
            worst = max(worst, abs(pos[f]["position"][ax] - c.evaluate(f)))
    check("核心数值（路径点 vs F-Curve 求值）", worst < TOL, "最大误差 %.2e" % worst)


def t_obj_no_parent():
    """物体位移路径 —— 无父级。"""
    cache = fresh()
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.keyframe_insert("location", index=0, frame=1)
    o.location = (10, 0, 0)
    o.keyframe_insert("location", index=0, frame=10)
    frames = [1, 5, 10]
    got = drawn_world(cache, o, frames)
    worst = worst_error(got, frames, lambda f: o.matrix_world.translation)
    check("物体位移路径 · 无父级", worst < TOL, "误差 %.2e" % worst)


def t_obj_static_parent():
    """物体位移路径 —— 父级静止。"""
    cache = fresh()
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 50))
    par = bpy.context.active_object
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    ch = bpy.context.active_object
    ch.parent = par
    ch.matrix_parent_inverse = mathutils.Matrix.Identity(4)
    ch.keyframe_insert("location", index=0, frame=1)
    ch.location = (10, 0, 0)
    ch.keyframe_insert("location", index=0, frame=10)
    frames = [1, 5, 10]
    got = drawn_world(cache, ch, frames)
    worst = worst_error(got, frames, lambda f: ch.matrix_world.translation)
    check("物体位移路径 · 父级静止", worst < TOL, "误差 %.2e" % worst)


def t_bone():
    """骨骼位移路径 —— 追踪 head 的世界位置（rest 头不在原点）。"""
    cache = fresh()
    bpy.ops.object.armature_add(location=(0, 0, 0))
    arm = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    eb = arm.data.edit_bones[0]
    eb.head = (0, 0, 5)
    eb.tail = (0, 0, 7)
    bpy.ops.object.mode_set(mode='POSE')
    pb = arm.pose.bones[0]
    pb.keyframe_insert("location", index=0, frame=1)
    pb.location = (2, 0, 0)
    pb.keyframe_insert("location", index=0, frame=10)

    frames = [1, 5, 10]
    got = drawn_world(cache, arm, frames, bone=pb.name)
    worst = worst_error(got, frames, lambda f: arm.matrix_world @ pb.head)
    check("骨骼位移路径 · head 世界位置", worst < TOL, "误差 %.2e" % worst)


def t_bone_child():
    """骨骼位移路径 —— 子骨骼被父骨骼旋转带动。"""
    cache = fresh()
    bpy.ops.object.armature_add(location=(0, 0, 0))
    arm = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    ebs = arm.data.edit_bones
    b0 = ebs[0]
    b0.head = (0, 0, 0)
    b0.tail = (0, 0, 2)
    b1 = ebs.new("Child")
    b1.head = (0, 0, 2)
    b1.tail = (0, 0, 4)
    b1.parent = b0
    b1.use_connect = False
    bpy.ops.object.mode_set(mode='POSE')
    p0 = arm.pose.bones[0]
    pc = arm.pose.bones["Child"]
    p0.rotation_mode = 'XYZ'
    p0.keyframe_insert("rotation_euler", index=2, frame=1)
    p0.rotation_euler = (0, 0, 1.5708)
    p0.keyframe_insert("rotation_euler", index=2, frame=10)
    pc.keyframe_insert("location", index=0, frame=1)
    pc.location = (0.5, 0, 0)
    pc.keyframe_insert("location", index=0, frame=10)

    frames = [1, 5, 10]
    got = drawn_world(cache, arm, frames, bone="Child")
    worst = worst_error(got, frames, lambda f: arm.matrix_world @ pc.head)
    check("骨骼位移路径 · 子骨骼随父级", worst < TOL, "误差 %.2e" % worst)


def t_bone_parented_object():
    """物体挂在骨骼上（bone-parented）—— 骨长平移修复项。"""
    cache = fresh()
    bpy.ops.object.armature_add(location=(0, 0, 0))
    arm = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    e = arm.data.edit_bones[0]
    e.head = (0, 0, 0)
    e.tail = (0, 0, 2)
    bpy.ops.object.mode_set(mode='OBJECT')

    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    cube = bpy.context.active_object
    arm.select_set(True)
    cube.select_set(True)
    bpy.context.view_layer.objects.active = arm
    bpy.ops.object.mode_set(mode='POSE')
    arm.data.bones.active = arm.data.bones[0]
    bpy.ops.object.parent_set(type='BONE')
    bpy.ops.object.mode_set(mode='OBJECT')

    bpy.context.view_layer.objects.active = cube
    cube.keyframe_insert("location", index=0, frame=1)
    cube.location = (2, 0, 0)
    cube.keyframe_insert("location", index=0, frame=10)

    frames = [1, 5, 10]
    got = drawn_world(cache, cube, frames)
    worst = worst_error(got, frames, lambda f: cube.matrix_world.translation)
    check("物体挂骨骼（骨长平移）", worst < TOL, "误差 %.2e" % worst)


def t_axis_backfill():
    """补轴：某轴完全没有曲线时，应能新建该轴曲线，且不打印错误。

    collect_animation_curves() 返回的是 list 快照（没有 .new()）；
    新建曲线须走 get_writable_fcurves()。此处正是此前失效的分支。
    """
    cache = fresh()
    from RealTimeMotionPath import interaction

    bpy.ops.mesh.primitive_cube_add()
    o = bpy.context.active_object
    for f in (1, 5, 10):
        o.location = (float(f), 0, 0)
        o.keyframe_insert("location", index=0, frame=f)   # 只打 x 轴
    act = o.animation_data.action

    before = len(cache.collect_animation_curves(act, o))

    o.select_set(True)
    bpy.context.view_layer.objects.active = o
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = 10

    sink = io.StringIO()
    with contextlib.redirect_stdout(sink):
        interaction.ensure_location_keyframes(bpy.context, o)

    after = len(cache.collect_animation_curves(act, o))
    noise = len([l for l in sink.getvalue().splitlines() if l.strip()])

    ok = (before == 1 and after == 3 and noise == 0)
    check("补轴能新建缺失轴且无刷屏", ok,
          "曲线 %d -> %d，控制台输出 %d 行（期望 1 -> 3，0 行）"
          % (before, after, noise))


def t_invoke_guard():
    """非区域上下文（context.area = None）调用 operator 不应崩溃。

    timer 回调、后台运行、全局脚本里 context.area 为 None；
    若 invoke 直接访问 .type 会抛 AttributeError。
    """
    from RealTimeMotionPath import interaction

    class FakeCtx:
        area = None
        window = None

    class FakeOp:
        _timer = None
        _is_active = False

        def report(self, *a, **k):
            pass

    # 只针对 PathPointDrag：它的 invoke 带 area 判断，可以脱离真实上下文测试。
    # PathRefreshDaemon.invoke 无 area 判断、依赖真实窗口上下文，不在此测。
    bad = []
    cls = getattr(interaction, "RTMP_OT_PathPointDrag", None)
    invoke = getattr(cls, "invoke", None) if cls else None
    if invoke is None:
        bad.append("找不到 RTMP_OT_PathPointDrag.invoke")
    else:
        try:
            r = invoke(FakeOp(), FakeCtx(), None)
            if r != {'CANCELLED'}:
                bad.append("area=None 时返回 %s（期望 CANCELLED）" % r)
        except AttributeError as e:
            bad.append("抛 AttributeError: %s" % e)
        except Exception as e:
            bad.append("抛 %s: %s" % (type(e).__name__, e))

    check("area=None 时 invoke 不崩", not bad,
          "；".join(bad) if bad else "PathPointDrag 安全返回 CANCELLED")


def t_multi_slot():
    """多 slot：两个对象共享同一 action、各自一个 slot 时，不应互相串数据。"""
    cache = fresh()

    bpy.ops.mesh.primitive_cube_add()
    a = bpy.context.active_object
    a.name = "SlotA_Obj"
    bpy.ops.mesh.primitive_cube_add()
    b = bpy.context.active_object
    b.name = "SlotB_Obj"

    act = bpy.data.actions.new("MultiSlotAct")
    sa = act.slots.new(a.id_type, "ForA")
    sb = act.slots.new(b.id_type, "ForB")
    strip = act.layers.new("L").strips.new(type='KEYFRAME')

    ca = strip.channelbag(sa, ensure=True).fcurves.new(data_path="location", index=0)
    ca.keyframe_points.insert(1, 111.0)
    cb = strip.channelbag(sb, ensure=True).fcurves.new(data_path="location", index=0)
    cb.keyframe_points.insert(1, 222.0)

    a.animation_data_create()
    a.animation_data.action = act
    a.animation_data.action_slot = sa
    b.animation_data_create()
    b.animation_data.action = act
    b.animation_data.action_slot = sb

    def value_for(obj):
        curves = cache.collect_animation_curves(act, obj)
        vals = [kp.co[1] for c in curves for kp in c.keyframe_points]
        return vals

    va = value_for(a)
    vb = value_for(b)

    ok = (va == [111.0] and vb == [222.0])
    check("多 slot 共享 action 不串数据", ok,
          "A 读到 %s，B 读到 %s（期望 [111.0] / [222.0]）" % (va, vb))


def t_i18n():
    """i18n：代码里的界面字符串是否 100% 有翻译、且无僵尸条目。"""

    def rd(f):
        with open(os.path.join(ADDON_DIR, f), encoding="utf-8") as fh:
            return fh.read()

    # ★★ 2026-09-18（盲审 R7）：原实现只扫 4 个文件
    #    ("__init__"/"ui"/"interaction"/"drawing") ⇒ **另外 8 个模块的界面字符串
    #    完全不在覆盖内**，于是"109/109 覆盖"这个数字是**虚的**。
    #    实测证据：`modal_edit.py` 里有 20+ 处**硬编码中文**状态栏文案，
    #    却从未被这项检查发现（因为它不在扫描列表里）。
    #    ⇒ 改成扫【全部源码模块】，让覆盖数字名副其实。
    #    ⚠️ 别用 `not f.startswith("_")` 过滤 —— 那会把 **`__init__.py` 也滤掉**
    #       （实测踩坑：僵尸数虚增 13 个，全是 __init__ 里的属性文案）。
    #       `__init__.py` 必须留在列表里，只是**排除 dunder 文件**。
    _ALL_SRC = sorted(f for f in os.listdir(ADDON_DIR)
                      if f.endswith(".py") and not (f.startswith("__") and f.endswith("__")))
    code = {}
    for f in _ALL_SRC:
        s = rd(f)
        for m in re.finditer(r'\b(name|description)\s*=\s*"([^"]*)"', s):
            code[m.group(2)] = 1
        for m in re.finditer(r'bl_(label|description)\s*=\s*"([^"]*)"', s):
            code[m.group(2)] = 1
        for m in re.finditer(r'iface_\(\s*"([^"]*)"', s):
            code[m.group(1)] = 1
    for f in ("__init__.py", "ui.py"):
        s = rd(f)
        for m in re.finditer(
                r"\(\s*'[A-Z_]+'\s*,\s*\"([^\"]+)\"\s*,\s*\"([^\"]+)\"\s*\)", s):
            code[m.group(1)] = 1
            code[m.group(2)] = 1
    bi = rd("__init__.py")
    code[re.search(r'"name"\s*:\s*"([^"]+)"', bi).group(1)] = 1
    code[re.search(r'"description"\s*:\s*"([^"]+)"', bi).group(1)] = 1

    # call_menu 的菜单 id 不是界面文字，排除
    code.pop("RTMP_MT_context_menu", None)

    # 用 AST 提取翻译表 key —— 正则会把注释里的示例误当成条目
    import ast
    tree = ast.parse(rd("translations.py"))
    table = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Dict):
            for k in node.keys:
                if isinstance(k, ast.Tuple):
                    vals = [e.value for e in k.elts if isinstance(e, ast.Constant)]
                    if len(vals) == 2:
                        table.add(vals[1])
    missing = sorted(k for k in code if k not in table)
    zombie = sorted(k for k in table if k not in code)

    detail = "覆盖 %d/%d，僵尸 %d" % (len(code) - len(missing), len(code), len(zombie))
    if missing:
        detail += "；未翻译 %s" % missing[:2]
    if zombie:
        detail += "；僵尸 %s" % zombie[:2]
    check("i18n 覆盖完整（0 漏翻 0 僵尸）", not missing and not zombie, detail)


def t_perf():
    """性能：250 帧对象的刷新耗时。"""
    cache = fresh()
    bpy.ops.mesh.primitive_cube_add()
    o = bpy.context.active_object
    for f in range(1, 251):
        o.location = (f * 0.1, 0, 0)
        o.keyframe_insert("location", index=0, frame=f)
    o.select_set(True)
    bpy.context.view_layer.objects.active = o
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = 250
    bpy.context.window_manager.rtmp_path_display_enabled = True

    t0 = time.perf_counter()
    cache.refresh_position_store(bpy.context)
    ms = (time.perf_counter() - t0) * 1000
    check("性能（250 帧刷新）", ms < PERF_BUDGET_MS,
          "%.2f ms（上限 %.0f ms）" % (ms, PERF_BUDGET_MS))


def t_notes():
    """已知行为 / 设计范围外 —— 记录但不计失败。"""
    note("骨骼仅旋转不产生路径",
         "head 是旋转支点本身不动，与原生 HEADS 一致")
    note("补轴会新建缺失轴的曲线",
         "仅某轴完全没有曲线时触发；补入常数值，不改变动画形状（有意设计）")


# ==========================================================================

def main():
    print("RealTimeMotionPath 回归测试")
    print("Blender %s" % bpy.app.version_string)
    print("插件目录 %s" % ADDON_DIR)
    print("=" * 78)

    tests = [
        t_load, t_core, t_obj_no_parent, t_obj_static_parent,
        t_bone, t_bone_child, t_bone_parented_object,
        t_axis_backfill, t_invoke_guard, t_multi_slot, t_i18n, t_perf,
    ]
    # 测试期间插件自身可能向 stdout 打印（如单轴动画时的补轴提示），
    # 统一吞掉，避免污染结果表格。
    import contextlib
    import io
    sink = io.StringIO()
    with contextlib.redirect_stdout(sink):
        for t in tests:
            try:
                t()
            except Exception:
                check(t.__name__, False,
                      traceback.format_exc(limit=3).replace("\n", " | ")[:200])
        t_notes()

    n_pass = sum(1 for s, _, _ in _results if s == "PASS")
    n_fail = sum(1 for s, _, _ in _results if s == "FAIL")
    n_note = len(_results) - n_pass - n_fail

    for status, name, detail in _results:
        print("[%-4s] %-38s %s" % (status, name, detail))

    print("=" * 78)
    print("PASS %d  FAIL %d  NOTE %d" % (n_pass, n_fail, n_note))
    print("结果: %s" % ("全部通过" if n_fail == 0 else "有 %d 项失败" % n_fail))

    if n_fail:
        sys.exit(1)


main()
