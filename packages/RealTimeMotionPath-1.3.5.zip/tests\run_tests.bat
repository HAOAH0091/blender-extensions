@echo off
REM ===========================================================================
REM  RealTimeMotionPath 回归测试
REM
REM  用法:
REM      双击本文件即可
REM      或指定 Blender 路径:  run_tests.bat "D:\path\to\blender.exe"
REM
REM  说明:
REM      在后台以出厂设置运行，不会改动你的 Blender 配置和场景。
REM      退出码 0 = 全部通过，1 = 有失败项。
REM
REM  找 Blender 的顺序:
REM      1) 命令行传入的路径
REM      2) 常见安装位置（C/D/E/F/G 盘，Steam 与官方安装版）
REM      3) PATH 里的 blender
REM ===========================================================================

setlocal
chcp 65001 >nul 2>nul

REM ---- 0. 命令行传入的路径（仅当它真实存在时才采用；否则继续自动查找）----
if not "%~1"=="" if exist "%~1" set "BLENDER=%~1"

REM ---- 1. 常见安装位置：扫多个盘符（兼容不同机器 / 不同盘）----
if not defined BLENDER call :probe "C:\Program Files (x86)\Steam\steamapps\common\Blender\blender.exe"
if not defined BLENDER call :probe "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe"
if not defined BLENDER call :probe "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe"
if not defined BLENDER call :probe "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe"
if not defined BLENDER for %%D in (D E F G) do call :probe "%%D:\Program Files (x86)\Steam\steamapps\common\Blender\blender.exe"
if not defined BLENDER for %%D in (D E F G) do call :probe "%%D:\Program Files\Blender Foundation\Blender 5.2\blender.exe"
if not defined BLENDER for %%D in (D E F G) do call :probe "%%D:\steam\steamapps\common\Blender\blender.exe"
if not defined BLENDER for %%D in (D E F G) do call :probe "%%D:\Steam\steamapps\common\Blender\blender.exe"

REM ---- 2. 兜底：PATH 里的 blender ----
if not defined BLENDER (
    for /f "delims=" %%P in ('where blender 2^>nul') do (
        if not defined BLENDER if exist "%%P" set "BLENDER=%%P"
    )
)

if not defined BLENDER (
    if not "%~1"=="" echo [提示] 指定的路径不存在: %~1
    echo [错误] 未找到 blender.exe
    echo        请把 Blender 路径作为参数传入，例如:
    echo        run_tests.bat "D:\program\blender\blender.exe"
    echo.
    pause
    exit /b 1
)

echo 使用 Blender: %BLENDER%
echo.

"%BLENDER%" --background --factory-startup --python "%~dp0regression.py"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo [完成] 全部通过
) else (
    echo [完成] 有失败项，请查看上方输出
)

pause
exit /b %RC%

REM ---- 子程序：存在则采用 ----
:probe
if not defined BLENDER if exist "%~1" set "BLENDER=%~1"
goto :eof
