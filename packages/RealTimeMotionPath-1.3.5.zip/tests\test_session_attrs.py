# -*- coding: utf-8 -*-
"""静态契约检查（纯静态，不需要 bpy / Blender，秒级跑完）

存在意义
--------
用户连续踩到几类"改了 A 忘了 B"的运行时错误，它们**本该在测试阶段暴露**：

  ① `AttributeError: 'MotionPathSession' object has no attribute '_mouse_pos'`
     —— 读了**不属于该对象**的属性（鼠标位置其实在 operator 实例上）。

  ② `KeyError: 'kf_map'`
     —— 两条解析路径返回的 dict 形状不一致（已在 test_target_contract 覆盖）。

  ③ 签名改了、调用处没改（少传参数）→ TypeError。

本文件用**静态扫描**兜住 ① 和 ③，以及同族的拼写/来源错误：

  [A] 所有 `_session.X` 引用，X 必须是 MotionPathSession 上真实定义过的
  [B] 所有 `self.X` 引用，X 必须是该类定义过（赋值 / 注解 / 方法）或 bpy 内建的
  [C] 同文件内的函数调用，位置参数个数必须在签名允许范围内
  [D] 测试代码不得给 `_session` 凭空新增属性
      —— 这正是 ① 被漏掉的原因：测试自己造了个真实环境不存在的属性

用法：python tests/test_session_attrs.py
      （也可以 blender --background --python 跑，无 bpy 依赖）
"""
import os
import re
import ast
import json

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)

RESULTS = []
def check(name, ok, detail=""):
    RESULTS.append(("PASS" if ok else "FAIL", name, str(detail)))


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------

def strip_strings(src):
    """把字符串字面量（含三引号 docstring）替换成空白，保留换行以维持行号。

    避免把注释/docstring 里提到的 `_session.xxx` 误判成代码引用。
    """
    out = []
    i, n = 0, len(src)
    while i < n:
        if src.startswith('"""', i) or src.startswith("'''", i):
            q = src[i:i + 3]
            j = src.find(q, i + 3)
            j = n if j < 0 else j + 3
            out.append(re.sub(r'[^\n]', ' ', src[i:j]))
            i = j
            continue
        ch = src[i]
        if ch in ('"', "'"):
            j = i + 1
            while j < n and src[j] != ch:
                if src[j] == "\\":
                    j += 1
                if src[j:j + 1] == "\n":
                    break
                j += 1
            j = min(j + 1, n)
            out.append(re.sub(r'[^\n]', ' ', src[i:j]))
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def read(fn):
    with open(os.path.join(ADDON_DIR, fn), encoding="utf-8", errors="replace") as fh:
        return fh.read()


PY_FILES = [f for f in sorted(os.listdir(ADDON_DIR)) if f.endswith(".py")]


# ---------------------------------------------------------------------------
# [A] `_session.X` 引用检查
# ---------------------------------------------------------------------------

def class_members(source, class_name):
    m = re.search(r'class\s+%s\b(.*?)(?=\nclass\s|\Z)' % re.escape(class_name),
                  source, re.S)
    if not m:
        return set(), set()
    block = m.group(1)
    attrs = set(re.findall(r'self\.([A-Za-z_]\w*)\s*=', block))
    meths = set(re.findall(r'def\s+([A-Za-z_]\w*)\s*\(self', block))
    return attrs, meths


state_src = read("state.py")
sess_attrs, sess_meths = class_members(state_src, "MotionPathSession")
SESS_DEFINED = sess_attrs | sess_meths

check("[A0] parsed MotionPathSession members", len(SESS_DEFINED) > 0,
      "attrs=%d methods=%d" % (len(sess_attrs), len(sess_meths)))

session_usage = {}
for fn in PY_FILES:
    code = strip_strings(read(fn))
    for i, line in enumerate(code.splitlines(), 1):
        line = line.split("#")[0]
        for mm in re.finditer(r'\b_session\.([A-Za-z_]\w*)', line):
            session_usage.setdefault(mm.group(1), []).append((fn, i))

session_missing = {k: v for k, v in session_usage.items() if k not in SESS_DEFINED
                   if k != "keys"}     # 少量 dunder/特殊访问留白
check("[A1] ★ every `_session.X` reference exists on MotionPathSession",
      not session_missing,
      "; ".join("%s @ %s" % (k, ",".join("%s:%d" % l for l in v[:3]))
                for k, v in sorted(session_missing.items()))
      or "all %d referenced names defined" % len(session_usage))

check("[A2] ★ regression: `_mouse_pos` must NOT live on _session",
      "_mouse_pos" not in session_usage,
      session_usage.get("_mouse_pos", "not referenced"))


# ---------------------------------------------------------------------------
# [B] `self.X` 引用检查（按类分析）
# ---------------------------------------------------------------------------

# bpy 内建 / 动态属性白名单
SELF_WHITELIST = {
    "report", "layout", "bl_rna", "rna_type", "__dict__", "__class__", "__module__",
    "get", "as_keywords", "as_pointer", "driver_add", "driver_remove", "id_data",
    "is_property_hidden", "is_property_overridable_library", "is_property_readonly",
    "is_property_set", "keyframe_delete", "keyframe_insert", "path_from_id",
    "path_resolve", "pop", "prop", "properties", "update", "items", "draw",
    "invoke", "execute", "modal", "cancel", "poll", "check", "invoke_confirm",
}

self_issues = []
for fn in PY_FILES:
    src = read(fn)
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        self_issues.append("%s: SYNTAX %s" % (fn, e))
        continue

    # 先把所有类收集起来（支持继承：子类可见父类的成员）
    all_classes = {}
    for fn2 in PY_FILES:
        try:
            t2 = ast.parse(read(fn2))
        except SyntaxError:
            continue
        for c in [n for n in ast.walk(t2) if isinstance(n, ast.ClassDef)]:
            mem = set()
            for node in ast.walk(c):
                if isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Store) \
                        and isinstance(node.value, ast.Name) and node.value.id == "self":
                    mem.add(node.attr)
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    mem.add(node.name)
            for stmt in c.body:
                if isinstance(stmt, ast.Assign):
                    for t in stmt.targets:
                        if isinstance(t, ast.Name):
                            mem.add(t.id)
                elif isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                    mem.add(stmt.target.id)
            all_classes[c.name] = (mem, [b.id for b in c.bases if isinstance(b, ast.Name)])

    def members_with_bases(name, seen=None):
        """递归收集（含父类）。"""
        seen = seen or set()
        if name in seen or name not in all_classes:
            return set()
        seen.add(name)
        mem, bases = all_classes[name]
        out = set(mem)
        for b in bases:
            out |= members_with_bases(b, seen)
        return out

    for cls in [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]:
        known = members_with_bases(cls.name)
        known |= SELF_WHITELIST

        for node in ast.walk(cls):
            if isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load) \
                    and isinstance(node.value, ast.Name) and node.value.id == "self":
                if node.attr not in known:
                    self_issues.append("%s:%d  self.%s  (class %s)"
                                       % (fn, node.lineno, node.attr, cls.name))

check("[B1] ★ every `self.X` reference resolves (assign/annotation/method/builtin)",
      not self_issues, "; ".join(self_issues[:6]) or "clean")


# ---------------------------------------------------------------------------
# [C] 同文件函数调用参数个数检查
# ---------------------------------------------------------------------------

def collect_sigs(tree):
    sigs = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            a = node.args
            pos = [x.arg for x in a.posonlyargs] + [x.arg for x in a.args]
            mn = len(pos) - len(a.defaults)
            mx = 10 ** 9 if a.vararg else len(pos)
            sigs[node.name] = (mn, mx, a.vararg is not None)
    return sigs


call_issues = []
for fn in PY_FILES:
    try:
        tree = ast.parse(read(fn))
    except SyntaxError:
        continue
    sigs = collect_sigs(tree)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        f = node.func
        if not isinstance(f, ast.Name) or f.id not in sigs:
            continue
        mn, mx, has_var = sigs[f.id]
        if has_var or any(isinstance(x, ast.Starred) for x in node.args):
            continue
        npos = len(node.args)
        if npos > mx:
            call_issues.append("%s:%d  %s(): 传 %d，最多 %d"
                               % (fn, node.lineno, f.id, npos, mx))
        elif npos < mn:
            call_issues.append("%s:%d  %s(): 传 %d，至少 %d"
                               % (fn, node.lineno, f.id, npos, mn))

check("[C1] ★ same-file calls match function signatures",
      not call_issues, "; ".join(call_issues[:6]) or "clean")


# ---------------------------------------------------------------------------
# [D] 测试不得给 _session 凭空新增属性
# ---------------------------------------------------------------------------

suspicious = []
for fn in sorted(os.listdir(HERE)):
    if not fn.endswith(".py") or fn == os.path.basename(__file__):
        continue
    src = open(os.path.join(HERE, fn), encoding="utf-8", errors="replace").read()
    code = strip_strings(src)
    for i, line in enumerate(code.splitlines(), 1):
        line = line.split("#")[0]
        for mm in re.finditer(r'_session\.([A-Za-z_]\w*)\s*=', line):
            if mm.group(1) not in SESS_DEFINED:
                suspicious.append("%s:%d sets _session.%s" % (fn, i, mm.group(1)))

check("[D1] ★ tests don't invent new _session attributes (masks real bugs)",
      not suspicious, "; ".join(suspicious) or "clean")


# ---------------------------------------------------------------------------
fails = [r for r in RESULTS if r[0] == "FAIL"]
summary = {
    "total": len(RESULTS),
    "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in RESULTS],
}
with open(os.path.join(HERE, "_sa_result.json"), "w", encoding="utf-8") as fh:
    json.dump(summary, fh, ensure_ascii=False, indent=1)

print("STATIC_CONTRACTS: %s (%d/%d)"
      % (summary["result"], summary["total"] - summary["fails"], summary["total"]))
for s, n, d in RESULTS:
    print("  [%s] %-62s %s" % (s, n[:62], d[:78]))
