# -*- coding: utf-8 -*-
"""极端边界回归测试（2026-09-16，来源：并行实测 agent 的发现）

Agent 实测抓到两个**真实边界缺陷**，本文件固化它们防回归：

  ① **帧距 < 0.5 帧时 `keyframe_at` 匹配错关键帧**
     `keyframe_at` 原用 `abs(kp.co[0] - frame) < 0.5`。
     关键帧可以只相隔 0.4 帧 → 相邻的那个也会落进容差 → 写入**错的**关键帧
     → 用户看到"R 完全没反应"（agent 实测：帧距 0.4 无效果，0.6 正常）。
     已改为【最近匹配 + 1e-3 精确容差】。

  ② **`SAFE_LIMIT` 被用于写入 → 大倍率缩放静默失效**
     `SAFE_LIMIT = 1e6` 是**绘制**用的（防 GPU 崩溃）；写入也用它 →
     `factor = 1e7` 时坐标超限被静默跳过（agent 实测：点间距纹丝不动、无任何提示）。
     已拆成两套限制：写入用 `WRITE_LIMIT = 1e12`（只挡 NaN/Inf/溢出），
     且被拒时写入 `last_skip_reason` 供状态栏提示。
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_ec_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.fsync if False else fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 60
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf

    def build(frame_list):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in frame_list:
            sc.frame_set(int(f)); o.location = loc
            o.keyframe_insert("location", frame=f)
        act = o.animation_data.action
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
            fc.update()
        return o, act

    def select(act, o, frame):
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.select_control_point = (abs(kp.co[0] - frame) < 1e-4)
            fc.update()

    def state(act, o, frame):
        out = {}
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-4:
                    out[fc.array_index] = (float(kp.co[1]),
                                           float(kp.handle_left[1]),
                                           float(kp.handle_right[1]))
        return out

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    # =========================================================
    # ① 帧距 < 0.5：keyframe_at 必须命中【最近】的那个
    # =========================================================
    o, act = build([(1, (0, 0, 0)), (14, (4, 0, 0)),
                    (14.4, (4.4, 0, 0)), (27, (8, 0, 0))])
    frames = sorted({round(float(kp.co[0]), 4)
                     for fc in xf._position_curves(act, o, None)
                     for kp in fc.keyframe_points})
    step("① 关键是能建出帧距 0.4 的两个关键帧", 14.0 in frames and 14.4 in frames, frames)

    fc0 = [fc for fc in xf._position_curves(act, o, None) if fc.array_index == 0][0]
    kp_a = xf.keyframe_at(fc0, 14.0)
    kp_b = xf.keyframe_at(fc0, 14.4)
    step("① keyframe_at(14.0) 命中 14.0（不是 14.4）",
         kp_a is not None and abs(kp_a.co[0] - 14.0) < 1e-6,
         "命中 %.4f" % (kp_a.co[0] if kp_a else -1))
    step("① keyframe_at(14.4) 命中 14.4（不是 14.0）",
         kp_b is not None and abs(kp_b.co[0] - 14.4) < 1e-6,
         "命中 %.4f" % (kp_b.co[0] if kp_b else -1))

    # 端到端：对帧距 0.4 的关键帧做 R，必须有反应
    select(act, o, 14.4)
    b0 = state(act, o, 14.4)
    s = me.RotateSession('ROTATE')
    ok = s.begin(o, act, region, rv3d, 600.0, 400.0)
    if ok:
        s.apply_numeric(30.0)
        b1 = state(act, o, 14.4)
        d_h = max(max(abs(b1[i][1] - b0[i][1]), abs(b1[i][2] - b0[i][2])) for i in b0)
        # 同时确认邻居没被误改
        n0 = state(act, o, 14.0)
        step("★ ① 帧距 0.4 时 R 有效果（agent 实测原本无反应）", d_h > 1e-4,
             "Δhandle=%.6f" % d_h)
        s.cancel()
        n1 = state(act, o, 14.0)
    else:
        step("★ ① 帧距 0.4 时 R 有效果", False, s.message)

    # 对照：帧距 0.6（原本就正常）
    o2, act2 = build([(1, (0, 0, 0)), (14, (4, 0, 0)),
                      (14.6, (4.6, 0, 0)), (27, (8, 0, 0))])
    select(act2, o2, 14.6)
    b0c = state(act2, o2, 14.6)
    s2 = me.RotateSession('ROTATE')
    if s2.begin(o2, act2, region, rv3d, 600.0, 400.0):
        s2.apply_numeric(30.0)
        b1c = state(act2, o2, 14.6)
        d_hc = max(max(abs(b1c[i][1] - b0c[i][1]), abs(b1c[i][2] - b0c[i][2])) for i in b0c)
        step("① 对照：帧距 0.6 同样有效", d_hc > 1e-4, "Δhandle=%.6f" % d_hc)
        s2.cancel()

    # =========================================================
    # ② 写入上限：大倍率缩放不再静默失效
    # =========================================================
    o3, act3 = build([(1, (0, 0, 0)), (14, (4, 0, 0)),
                      (27, (8, 0, 0)), (40, (12, 0, 0))])
    step("② WRITE_LIMIT 存在且远大于 SAFE_LIMIT",
         hasattr(xf, "WRITE_LIMIT") and xf.WRITE_LIMIT > xf.SAFE_LIMIT,
         "WRITE_LIMIT=%g SAFE_LIMIT=%g" % (getattr(xf, "WRITE_LIMIT", -1), xf.SAFE_LIMIT))
    step("② is_writable 对正常值返回 True",
         xf.is_writable(mathutils.Vector((4.0, 10.0, 0.0))) is True, "")
    step("② is_writable 挡住 NaN / Inf",
         xf.is_writable(mathutils.Vector((float("nan"), 0.0, 0.0))) is False
         and xf.is_writable(mathutils.Vector((float("inf"), 0.0, 0.0))) is False, "")

    # 大倍率缩放：必须真的生效（agent 实测 1e7 时纹丝不动）
    select(act3, o3, 14)
    for fc in xf._position_curves(act3, o3, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - 1) < 1e-4:
                kp.select_control_point = True
        fc.update()
    b0s = {f: state(act3, o3, f) for f in (1.0, 14.0)}
    s3 = me.ScaleSession('SCALE')
    if s3.begin(o3, act3, region, rv3d, 600.0, 400.0):
        s3.apply_numeric(1000.0)
        b1s = {f: state(act3, o3, f) for f in (1.0, 14.0)}
        d_co = max(abs(b1s[f][i][0] - b0s[f][i][0]) for f in b0s for i in b0s[f])
        step("★ ② 1000× 缩放真的写入了（不再静默跳过）", d_co > 1e-3,
             "Δco=%.6f skip=%s" % (d_co, getattr(xf, "last_skip_reason", None)))
        # 点间距应显著拉大
        def gap(st):
            return abs(st[14.0][0][0] - st[1.0][0][0])
        step("★ ② 1000× 后点间距显著变大",
             gap(b1s) > gap(b0s) * 10, "%.4f -> %.4f" % (gap(b0s), gap(b1s)))
        s3.cancel()

    # 提示机制：正常操作不应留下 skip 原因
    o4, act4 = build([(1, (0, 0, 0)), (14, (4, 0, 0)), (27, (8, 0, 0))])
    select(act4, o4, 14)
    s4 = me.RotateSession('ROTATE')
    if s4.begin(o4, act4, region, rv3d, 600.0, 400.0):
        s4.apply_numeric(30.0)
        step("② 正常操作不留 skip 提示",
             getattr(xf, "last_skip_reason", None) is None,
             getattr(xf, "last_skip_reason", None))
        s4.cancel()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("EDGE_CASES_DONE")
os._exit(0)
