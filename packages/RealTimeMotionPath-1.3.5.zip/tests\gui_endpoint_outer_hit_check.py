# -*- coding: utf-8 -*-
"""端点【外侧】手柄的交互命中 —— 与绘制侧对称性验收。

背景（2026-09-18 盲审 S2）
--------------------------
绘制侧 `drawing.py:739` 对「首帧 left / 末帧 right」是 `continue`：
**不画手柄线、不登记抓取点**（注释原文："拖了也没效果"）。
但交互侧 `locate_handle_under_cursor` 原先**没有对应守卫**
⇒ 用户能点到一根【看不见的线】，拖了还不动（体验断档）。

用户 2026-09-16 早已拍板："只做内侧 2 个（首帧右 / 末帧左）；外侧不画不抓"
（见 gui_endpoint_hollow_check.py 文件头）—— 本测试把"不抓"这半边也钉住。

※ 盲审原文称"拖外侧会改变动画"，实测**不成立**
  （gui_endpoint_hollow_check.py:11 已记载外侧对曲线影响 = 0.00000000）
  ⇒ 本项是"对称性 / 体验"修复，不是"数据被改坏"。

覆盖
----
  A. 外侧手柄（有非零长度）在几何上【不能命中】（本修复的核心）
  B. 内侧手柄仍能正常命中（不误伤 —— 若把守卫写反就会全挂）
  C. 判据来源唯一：interaction 复用 drawing._endpoint_is_hidden_side（静态契约）
  D. 单关键帧场景：两侧都是外侧 ⇒ 都不命中
  E. 行为对称：绘制侧不登记 ⇔ 交互侧不命中（同一帧、同一 side）

用法：blender --background --factory-startup --python tests/gui_endpoint_outer_hit_check.py
"""
import bpy, os, sys, json, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_outer_hit_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if steps and all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)

try:
    sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import interaction as I, drawing as D, cache as C, state as S
    from RealTimeMotionPath.state import _session

    # ---------------- 环境：真实 3D 视图 ----------------
    w0 = bpy.context.window_manager.windows[0]
    area = next((a for a in w0.screen.areas if a.type == 'VIEW_3D'), None)
    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
    rv3d = area.spaces.active.region_3d
    step("环境：拿到真实 3D 视图 region/rv3d", bool(region and rv3d))

    from bpy_extras import view3d_utils

    def build_scene(frames):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add()
        ob = bpy.context.active_object
        for f in frames:
            ob.location = (f * 0.3, 0, 0)
            for ax in (0, 1, 2):
                ob.keyframe_insert("location", index=ax, frame=f)
        bpy.context.window_manager.rtmp_path_display_enabled = True
        C.refresh_position_store(bpy.context)
        return ob

    def set_outer_handles(ob, length=2.0):
        """把【内外两侧】手柄都设成明显非零长度。

        ⚠️ 必须四侧都设：若内侧手柄长度为 0，产品会走「空心圆抓取点」通路
           （故意不做几何命中，见 gui_endpoint_hollow_check），
           本测试想验证的是「几何命中」这条路上的外侧守卫 ⇒ 先让四侧都非零。
        """
        curves = C.collect_animation_curves(ob.animation_data.action, ob)
        for c in curves:
            kps = sorted(c.keyframe_points, key=lambda k: k.co[0])
            for kp in (kps[0], kps[-1]):
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
            # ⚠️ 外/内两侧必须给【不同】的值分量偏移！
            #    端点的世界位置只由【值分量】决定（帧号是时间轴，不参与空间投影）
            #    ⇒ 偏移相同 = 投影到同一屏幕点，测试会退化成"命中另一个侧"。
            #    （实测踩过：外/内都给 +2.0 时，点外侧坐标命中了内侧 side='right'。）
            # 外侧：首帧 left / 末帧 right —— 用较长偏移（+4）
            kps[0].handle_left = (kps[0].co[0] - 5.0, kps[0].co[1] + 4.0)
            kps[-1].handle_right = (kps[-1].co[0] + 5.0, kps[-1].co[1] + 4.0)
            # 内侧：首帧 right / 末帧 left —— 用较短偏移（+1，位置明确分开）
            kps[0].handle_right = (kps[0].co[0] + 5.0, kps[0].co[1] + 1.0)
            kps[-1].handle_left = (kps[-1].co[0] - 5.0, kps[-1].co[1] + 1.0)
        return curves

    def handle_endpoint_screen(ob, frame_no, side):
        """算出某帧某侧手柄端点的屏幕坐标（走与产品同一条投影链）。"""
        from RealTimeMotionPath.cache import resolve_parent_transform
        curves = [c for c in C.collect_animation_curves(ob.animation_data.action, ob)
                  if c.array_index == 0]
        fc = curves[0]
        kp = min(fc.keyframe_points, key=lambda k: abs(k.co[0] - frame_no))
        # 三维端点：x=帧号(时间轴不参与世界位置) —— 用与产品一致的 cache 位置 +
        # 屏幕投影由 view3d_utils 完成
        pos = _session.cached_positions.get(ob.name, {}).get(None, {}).get(frame_no)
        if pos is None:
            return None, None
        point_3d = resolve_parent_transform(ob) @ pos['position']
        gs = bpy.context.window_manager.rtmp_handle_scale
        # 手柄世界向量：用与产品同样的 handle_vector 口径（值分量 × factor）
        from RealTimeMotionPath.drawing import compute_handle_display_factors
        fmap = {c.array_index: min(c.keyframe_points, key=lambda k: abs(k.co[0] - frame_no))
                for c in C.collect_animation_curves(ob.animation_data.action, ob)}
        fl, fr = compute_handle_display_factors(fmap)
        vec = mathutils.Vector((0.0, 0.0, 0.0))
        for ai, k in fmap.items():
            f = fl.get(ai, 1.0) if side == 'left' else fr.get(ai, 1.0)
            d = (k.handle_left[1] - k.co[1]) if side == 'left' else (k.handle_right[1] - k.co[1])
            vec[ai] = d * f
        rot = resolve_parent_transform(ob).to_3x3()
        wvec = rot @ vec
        hpos = point_3d + wvec * gs
        return view3d_utils.location_3d_to_region_2d(region, rv3d, hpos), hpos

    class FakeEvent:
        def __init__(self, x, y):
            self.mouse_region_x = x
            self.mouse_region_y = y

    # ⚠️ Operator 不能实例化（实测："is not safe, use RTMP_OT_xxx.__new__()"）
    #    ⇒ 必须把方法设成【类属性】（`setattr(Shim, name, getattr(原类, name))`），
    #      这样函数描述符才会在实例调用时自动绑 self。
    #    ★ 若设成【实例属性】，bpy 的 Operator 方法不会被绑定，
    #      第一个参数会收到 context 而不是 self（实测报
    #      `'FakeEvent' object has no attribute 'space_data'`）。
    #    （与 gui_endpoint_tangent_check.py 的 make_shim 同一做法。）
    class Shim:
        pass
    for _n in ("locate_handle_under_cursor",):
        setattr(Shim, _n, getattr(I.RTMP_OT_PathPointDrag, _n))
    _shim = Shim()

    def hit(ob, scr):
        """用鼠标位置调真实交互函数，返回命中的 (side, frame)。"""
        if scr is None:
            return None, None
        ev = FakeEvent(scr[0], scr[1])
        r = _shim.locate_handle_under_cursor(bpy.context, ev, region, rv3d, None)
        if r and r[0]:
            return r[0], r[2]
        return None, None

    # ============ A. 外侧不命中 ============
    ob = build_scene((1, 14, 27))
    set_outer_handles(ob)
    C.refresh_position_store(bpy.context)

    scr_first_left, _ = handle_endpoint_screen(ob, 1, 'left')
    scr_last_right, _ = handle_endpoint_screen(ob, 27, 'right')
    step("A1 外侧端点几何上确实存在（屏幕坐标算得出）",
         scr_first_left is not None and scr_last_right is not None,
         "首帧left=%s 末帧right=%s" % (scr_first_left, scr_last_right))

    side_l, fr_l = hit(ob, scr_first_left)
    step("A2 ★★ 点「首帧 left」（外侧）**不应命中**", side_l is None,
         "实测 side=%s frame=%s" % (side_l, fr_l))

    side_r, fr_r = hit(ob, scr_last_right)
    step("A3 ★★ 点「末帧 right」（外侧）**不应命中**", side_r is None,
         "实测 side=%s frame=%s" % (side_r, fr_r))

    # ============ B. 内侧仍能命中（不误伤）============
    scr_first_right, _ = handle_endpoint_screen(ob, 1, 'right')
    if scr_first_right is not None:
        s2, f2 = hit(ob, scr_first_right)
        step("B1 点「首帧 right」（内侧）**应命中**（守卫没写反）",
             s2 == 'right', "实测 side=%s frame=%s" % (s2, f2))
    else:
        step("B1 首帧 right 内侧端点可算", False, "屏幕坐标为 None")

    scr_last_left, _ = handle_endpoint_screen(ob, 27, 'left')
    if scr_last_left is not None:
        s3, f3 = hit(ob, scr_last_left)
        step("B2 点「末帧 left」（内侧）**应命中**", s3 == 'left',
             "实测 side=%s frame=%s" % (s3, f3))
    else:
        step("B2 末帧 left 内侧端点可算", False, "屏幕坐标为 None")

    # 中间帧两侧都算内侧
    scr_mid_left, _ = handle_endpoint_screen(ob, 14, 'left')
    if scr_mid_left is not None:
        s4, f4 = hit(ob, scr_mid_left)
        step("B3 中间帧 left 是内侧 ⇒ 应命中", s4 == 'left',
             "实测 side=%s frame=%s" % (s4, f4))

    # ============ C. 判据来源唯一（静态契约）============
    isrc = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    dsrc = open(os.path.join(REPO, "drawing.py"), encoding="utf-8").read()
    step("C1 interaction 复用 drawing._endpoint_is_hidden_side（不自己重写判据）",
         "_endpoint_is_hidden_side" in isrc)
    step("C2 该函数是从 drawing 导入的（唯一来源）",
         "_endpoint_is_hidden_side)" in isrc or "_endpoint_is_hidden_side," in isrc)
    step("C3 绘制侧仍在用它跳过外侧（两侧判据同源）",
         "_endpoint_is_hidden_side(is_first_keyframe, is_last_keyframe, side)" in dsrc)

    # ============ D. 单关键帧：两侧都是外侧 ============
    ob1 = build_scene((10,))
    set_outer_handles(ob1)
    C.refresh_position_store(bpy.context)
    step("D1 单关键帧：drawing 判两侧都为外侧",
         D._endpoint_is_hidden_side(True, True, 'left') and
         D._endpoint_is_hidden_side(True, True, 'right'))
    scr_one_left, _ = handle_endpoint_screen(ob1, 10, 'left')
    if scr_one_left is not None:
        s5, f5 = hit(ob1, scr_one_left)
        step("D2 ★ 单关键帧：外侧 left 不命中", s5 is None,
             "实测 side=%s frame=%s" % (s5, f5))

    # ============ E. 行为对称 ============
    # 绘制侧"不登记"由 gui_endpoint_hollow_check 钉住；这里断言互动侧口径一致
    step("E1 对称：drawing 判为外侧 ⇒ interaction 不命中（同类判据）",
         D._endpoint_is_hidden_side(True, False, 'left') is True and side_l is None)

except Exception:
    import traceback
    step("未捕获异常", False, traceback.format_exc()[-900:])
finally:
    flush()
    fails = sum(1 for s in steps if not s["ok"])
    for s in steps:
        print("%s  %s%s" % ("[OK]  " if s["ok"] else "[FAIL]", s["name"],
                            ("  -- " + s["detail"][:130]) if s["detail"] else ""))
    print("\n总计 %d 项 | PASS %d | FAIL %d | %s" % (
        len(steps), len(steps) - fails, fails,
        "ALL PASS" if fails == 0 else "HAS FAILURES"))
