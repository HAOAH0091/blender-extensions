# -*- coding: utf-8 -*-
"""双进程验证：**体感手柄类型**（_FEEL）持久化。

进程1 保存 .blend（写入体感记录）→ 进程2 打开（内存空，靠 custom property 恢复）。

用法：
    blender -b --factory-startup --python tests/_feel_persist_probe.py -- save
    blender -b --factory-startup --python tests/_feel_persist_probe.py -- load
"""
import os
import sys
import json
import traceback

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
BLEND = os.path.join(HERE, "_feel_persist.blend")
OUT = os.path.join(HERE, "_feel_persist_result.json")

FRAME = 14.0
steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())


def load():
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import transform_domain as xf
    return xf


def build():
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    bpy.ops.mesh.primitive_cube_add()
    o = bpy.context.active_object
    o.name = "T"
    for f, loc in ((1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)), (40, (6.0, 0.0, 0.0))):
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    act = o.animation_data.action
    try:
        act.name = "FeelAct"
    except Exception:
        pass
    return o, act


def kp_at(xf, act, o, frame):
    for fc in xf._position_curves(act, o, None):
        return xf.keyframe_at(fc, frame)
    return None


try:
    mode = sys.argv[-1] if len(sys.argv) else "?"
    xf = load()
    step("插件已加载 (mode=%s)" % mode, xf is not None)

    if mode == "save":
        o, act = build()
        kp = kp_at(xf, act, o, FRAME)
        step("构造关键帧", kp is not None)

        xf.clear_feel()
        xf.mark_feel(kp, 'left', 'LINK')
        xf.mark_feel(kp, 'right', 'FREE')
        step("mark_feel 后内存命中",
             xf.feel_type(kp, 'left') == 'LINK' and xf.feel_type(kp, 'right') == 'FREE',
             "L=%s R=%s" % (xf.feel_type(kp, 'left'), xf.feel_type(kp, 'right')))
        has = "rtmp_feel" in act.keys()
        vals = sorted(act["rtmp_feel"]) if has else None
        step("写进 action 的 custom property（持久化）",
             has and any("LINK" in str(v) for v in (vals or []))
             and any("FREE" in str(v) for v in (vals or [])), "act[rtmp_feel]=%s" % vals)

        # 幂等
        xf.mark_feel(kp, 'left', 'LINK')
        v2 = sorted(act["rtmp_feel"]) if "rtmp_feel" in act.keys() else []
        step("重复 mark 不产生重复条目", len(v2) == len(set(v2)), v2)

        bpy.ops.wm.save_as_mainfile(filepath=BLEND)
        step("保存 .blend", os.path.isfile(BLEND), BLEND)

    elif mode == "load":
        bpy.ops.wm.open_mainfile(filepath=BLEND)
        xf = load()
        act = bpy.data.actions.get("FeelAct")
        step("打开 .blend 拿到 action", act is not None, getattr(act, "name", None))

        mem = len(xf._FEEL)
        step("★ 新进程内存体感表为空（不是内存残留）", mem == 0, "len(_FEEL)=%d" % mem)

        prop = act.get("rtmp_feel")
        step("custom property 随文件持久化", prop is not None,
             "act[rtmp_feel]=%s" % (sorted(prop) if prop is not None else None))

        kp = kp_at(xf, act, o=None) if False else None
        # 拿 kp（load 后对象是新的）
        kp = None
        for fc in xf._position_curves(act, bpy.data.objects.get("T"), None):
            kp = xf.keyframe_at(fc, FRAME)
            if kp is not None:
                break
        step("拿到关键帧", kp is not None)

        L = xf.feel_type(kp, 'left')
        R = xf.feel_type(kp, 'right')
        step("★★ 惰性恢复：体感类型不丢（重启 Blender 后仍是记录的体感）",
             L == 'LINK' and R == 'FREE', "L=%s R=%s | 恢复后 len(_FEEL)=%d"
             % (L, R, len(xf._FEEL)))

        # ★★★ 体感是权威：改了**原始类型**，体感不应跟着变（方案 A 的定义）
        for fc in xf._position_curves(act, bpy.data.objects.get("T"), None):
            k = xf.keyframe_at(fc, FRAME)
            if k is not None:
                k.handle_left_type = 'ALIGNED'      # 模拟用户在 GE 里改原始类型
        step("★★★ 方案A：改原始类型后，体感【不跟着变】（体感绝对权威）",
             xf.feel_type(kp, 'left') == 'LINK', "改原始→体感=%s" % xf.feel_type(kp, 'left'))

        step("反向：未记录的侧 ⇒ 透传原始类型",
             xf.feel_type(kp, 'left') == 'LINK', "")

except Exception:
    step("FATAL", False, traceback.format_exc()[-1500:])

flush()
print("FEEL_PERSIST_DONE")
