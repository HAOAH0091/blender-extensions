# -*- coding: utf-8 -*-
"""E2E 真机验证：双击三角 ⇒ GE 手柄共线（走真实 modal operator 入口）。

用户需求（2026-09-18）：双击「分离 → 一体」时，不再复制对侧疏密，
而是【对齐 Graph Editor 手柄】—— 保持被双击侧不动、按公式算对侧。

完整操作序列：双击切分离 → 分离态拖单侧（出折角）→ 双击锁回一体（对齐共线）。

复刻用户真实痛点流程：
  ① 建场景 → 拖三角调速（modal 真入口）→ GE 出现折角   ← 用户截图里那个
  ② 双击三角（modal 真入口）→ GE 手柄共线
  ③ 独立口径验证：三轴 cross ≈ 0、A/B 值分量（3D 形状）不变

判据全用【独立口径】（直接读 F-Curve），不调产品函数算。
"""
import os, sys, json, mathutils
HERE = r"F:\desktop\BaiduSyncdisk\addons\RealTimeMotionPath\tests"
sys.path.insert(0, r"F:\desktop\BaiduSyncdisk\addons")
sys.stdout.reconfigure(encoding="utf-8")

import bpy
bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, interaction as it
from RealTimeMotionPath import time_domain as td, handles as hd
from RealTimeMotionPath import modal_edit as me, overlay as ovmod
from RealTimeMotionPath.state import _session

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:500]})


def ge_state(o, frame):
    """独立口径：直接读 F-Curve 的 (co, hl, hr)。"""
    act = o.animation_data.action
    out = {}
    for c in xf._position_curves(act, o, None):
        for kp in c.keyframe_points:
            if abs(kp.co[0] - float(frame)) < 1e-3:
                co, hl, hr = tuple(kp.co), tuple(kp.handle_left), tuple(kp.handle_right)
                dtl, dtr = co[0]-hl[0], hr[0]-co[0]
                A, B = co[1]-hl[1], hr[1]-co[1]
                scale = max(abs(dtl*B), abs(A*dtr), 1e-12)
                out[c.array_index] = {"A": A, "B": B, "dtl": dtl, "dtr": dtr,
                                      "rel": abs(dtl*B - A*dtr)/scale, "sR": dtr/30.0}
                break
    return out


FR = 25.0
# ★ 场景选【三轴各自线性】—— 这样 1/3 归一化后初始手柄真共线（= 用户的原生曲线），
#   拖动调速才会产生折角（= 用户截图里的痛点）。
KFS = ((1, (0.0, 0.0, 0.0)), (25, (2.4, 4.8, -1.2)), (55, (5.4, 10.8, -2.7)))


class FakeCtx: pass
class FakeEvent:
    def __init__(self, t, value, mx, my, mer):
        self.type = t; self.value = value
        self.mouse_x, self.mouse_y = mx, my
        self.mouse_region_x, self.mouse_region_y = mer
        self.shift = self.ctrl = self.alt = False
        self.is_repeat = False


class FakeOp:
    """operator 实例替身：补齐真实存在的实例属性/方法（鸭子类型必须自己给）。"""
    def __init__(self):
        self._mouse_pos = None
        self._last_draw_time = 0.0
        self._timer = None
        self._is_active = True
        self._redraw_count = 0
        self._last_frame = None
    def report(self, *a, **k):
        pass
    def cancel(self, context):
        return {'CANCELLED'}
    def finish(self, context):
        return {'FINISHED'}


def flush():
    open(os.path.join(HERE, "_ge_align_result.json"), "w", encoding="utf-8").write(json.dumps(
        {"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
         "result": ("ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES"),
         "steps": steps}, ensure_ascii=False, indent=1))


try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 60
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.active_object
    obj.name = "_E2E"
    for f, v in KFS:
        sc.frame_set(f)
        obj.location = v
        obj.keyframe_insert("location", frame=f)
    sc.frame_set(1)
    act = obj.animation_data.action
    # 手柄归一化：两侧都设成 1/3 处（= 共线、匀速），与真实路径测试同款
    for c in xf._position_curves(act, obj, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        pts = list(c.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        c.update()
    bpy.context.view_layer.objects.active = obj

    wm = bpy.context.window_manager
    wm.rtmp_path_display_enabled = True
    wm.rtmp_edit_mode_active = True

    win = wm.windows[0]
    area = next((a for a in win.screen.areas if a.type == 'VIEW_3D'), None)
    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((3, 0, 0))
    rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    ctx = FakeCtx()
    ctx.window = win; ctx.window_manager = bpy.context.window_manager
    ctx.area = area; ctx.region = region; ctx.region_data = rv3d
    ctx.screen = win.screen; ctx.active_object = obj; ctx.scene = sc

    over = ovmod.get_overlay(); over.stop(); over.start(session=None)
    _session.clear_speed_handle()

    recs = me.collect_speed_handles(act, obj, region, rv3d)
    r25 = [r for r in recs if abs(r['frame'] - FR) < 1e-3 and r['tri'] == hd.TRI_DOWN]
    step("① 收集到 f25 下三角", len(r25) == 1, "记录数=%d" % len(r25))
    tri_local = r25[0]['tri_screen']
    gx, gy = region.x + tri_local[0], region.y + tri_local[1]

    def ev(t, value='PRESS', local=None, shift=False):
        e = FakeEvent(t, value, gx, gy, local if local else tri_local)
        e.shift = shift
        return e

    op = FakeOp()
    Modal = it.RTMP_OT_PathPointDrag.modal

    before = ge_state(obj, FR)
    step("② 初始：GE 手柄共线（Blender 原生）",
         all(v["rel"] < 1e-5 for v in before.values()),
         "rel=%s" % {k: round(v["rel"], 8) for k, v in before.items()})

    def dblclick():
        """真实 modal 双击（PRESS/RELEASE ×2，落在双击时间窗内）。"""
        it.clear_speed_click_chain()
        for _ in range(2):
            Modal(op, ctx, ev('LEFTMOUSE', 'PRESS'))
            Modal(op, ctx, ev('LEFTMOUSE', 'RELEASE'))

    # ============ ① 双击 → 切成【分离】（此时值不该变） ============
    dblclick()
    split = ge_state(obj, FR)
    step("① 双击 ⇒ 切成分离态，值不变",
         xf.is_tri_locked(act, FR) is False and
         all(abs(split[a]["dtl"]-before[a]["dtl"]) < 1e-9 and
             abs(split[a]["dtr"]-before[a]["dtr"]) < 1e-9 for a in before),
         "locked=%s dtl=%s" % (xf.is_tri_locked(act, FR),
                               [round(split[a]["dtl"], 3) for a in sorted(split)]))

    # ============ ② 分离态下拖动单侧（真实 modal） ⇒ 产生折角 ============
    def drag_and_read(dy):
        it.clear_speed_click_chain()
        Modal(op, ctx, ev('LEFTMOUSE', 'PRESS'))
        op._mouse_pos = (tri_local[0], tri_local[1] + dy)
        Modal(op, ctx, ev('MOUSEMOVE', 'NOTHING', local=(tri_local[0], tri_local[1] + dy)))
        Modal(op, ctx, ev('LEFTMOUSE', 'RELEASE'))
        return ge_state(obj, FR)

    messed = None
    used_dy = None
    for dy in (25, 40, 60, 90, 130):
        st = drag_and_read(dy)
        # 「分离」态下只该动一侧；且要真动过（dtl 变了）
        if any(abs(st[a]["dtl"] - split[a]["dtl"]) > 0.5 for a in st):
            messed, used_dy = st, dy
            break
    if messed is None:
        messed = st
    step("② 分离态拖单侧 ⇒ GE 出现【折角】（复刻用户痛点）",
         messed is not None and any(v["rel"] > 1e-3 for v in messed.values()),
         "dy=%s rel=%s dtl=%s dtr=%s" % (used_dy,
                                         {k: round(v["rel"], 6) for k, v in messed.items()},
                                         [round(messed[a]["dtl"], 3) for a in sorted(messed)],
                                         [round(messed[a]["dtr"], 3) for a in sorted(messed)]))
    ab_before = {ax: (messed[ax]["A"], messed[ax]["B"]) for ax in messed}

    # ============ ③ 双击 → 锁回一体 + 对齐 GE 手柄 ============
    dblclick()
    aligned = ge_state(obj, FR)
    step("③ 双击 ⇒ 锁回一体", xf.is_tri_locked(act, FR) is True,
         "locked=%s" % xf.is_tri_locked(act, FR))
    step("④ 对齐后 GE 三轴共线（rel<1e-5）",
         all(v["rel"] < 1e-5 for v in aligned.values()),
         "rel=%s" % {k: round(v["rel"], 9) for k, v in aligned.items()})
    step("⑤ 保形状：A/B 值分量（3D 路径形状）不变",
         all(abs(aligned[ax]["A"]-ab_before[ax][0]) < 1e-7 and
             abs(aligned[ax]["B"]-ab_before[ax][1]) < 1e-7 for ax in ab_before),
         "A %s → %s" % ([round(ab_before[a][0], 6) for a in sorted(ab_before)],
                        [round(aligned[a]["A"], 6) for a in sorted(aligned)]))
    # 双击的是【下三角 = 管右段】⇒ 语义 = 保持右段(dtr)不动、改左段(dtl)
    step("⑥ 被双击侧（右段 dtr）不动、对侧（左段 dtl）确实被改",
         all(abs(aligned[a]["dtr"]-messed[a]["dtr"]) < 1e-9 for a in messed) and
         any(abs(aligned[a]["dtl"]-messed[a]["dtl"]) > 1e-6 for a in messed),
         "dtr %s→%s（应不变）; dtl %s→%s（应被改）"
         % ([round(messed[a]["dtr"], 4) for a in sorted(messed)],
            [round(aligned[a]["dtr"], 4) for a in sorted(aligned)],
            [round(messed[a]["dtl"], 4) for a in sorted(messed)],
            [round(aligned[a]["dtl"], 4) for a in sorted(aligned)]))

except Exception:
    import traceback
    step("EXCEPTION", False, traceback.format_exc()[-900:])

flush()
print("\n".join("%s %s | %s" % ("PASS" if s["ok"] else "FAIL", s["name"], s["detail"])
                for s in steps))
print("总计 %d | FAIL %d" % (len(steps), sum(1 for s in steps if not s["ok"])))
