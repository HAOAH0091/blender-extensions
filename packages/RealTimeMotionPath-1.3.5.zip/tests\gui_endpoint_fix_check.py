# -*- coding: utf-8 -*-
"""端点选中修复 + S 缩放语义 验收（2026-09-16）

用户反馈：
  ② 「顶点单选的端点实测选不中，点击后直接消失了，应该没选中判定」
  ① 「多选按 S 进入模态拖动应该是：放大 = 同时橙线扩散、缩小 = 同时蓝线收缩聚拢」

⚠️ 本测试的**关键**：必须【真实触发 render】，让 drawing.py 去填充
   `_session.handle_control_points` —— 之前的测试是手工填的，所以漏掉了这个 bug。

用法：blender --factory-startup --python tests/gui_endpoint_fix_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_ep_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    # ⚠️ headless（--background）下 GPU 模块**默认未初始化** ⇒
    #    `drawing.render_path_overlay()` 开头的 `gpu.state.blend_set('ALPHA')` 抛
    #    SystemError → 函数内部 try 吞掉 → **端点收集代码根本不执行** →
    #    `handle_control_points` 恒为 0（本测试因此报"测试前提不成立"而 FATAL）。
    #    实测 `gpu.init()`（Blender 5.2.1, --background）后一切正常。
    import gpu as _gpu
    _gpu.init()

    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import cache as rcache
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath.state import _session
    from bpy_extras import view3d_utils

    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "T"
    for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
                   (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]:
        sc.frame_set(f); obj.location = loc
        obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action
    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        fc.update()

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((5, 0, 0)); rv3d.view_distance = 18.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))

    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    wm.rtmp_path_display_enabled = True
    sc.frame_set(1)
    bpy.context.view_layer.update()
    rcache.refresh_position_store(bpy.context)

    # ⚠️ 真实触发 render：让 drawing 去填充 handle_control_points
    #    （`redraw_timer` 不会触发 draw_handler，所以改为【直接调用】注册的那个 handler）
    from RealTimeMotionPath import drawing as dw

    def real_render(n=1):
        ovr = {"window": win, "screen": win.screen, "area": area,
               "region": region, "space_data": area.spaces.active}
        err = None
        for _ in range(n):
            try:
                with bpy.context.temp_override(**ovr):
                    dw.render_path_overlay()
            except Exception as e:
                err = "%s: %s" % (type(e).__name__, e)
        return err

    _rerr = real_render()
    step("② render handler 可调用", _rerr is None, _rerr or "ok")

    def click(x, y, shift=False):
        class Ev:
            def __init__(self):
                self.type = 'LEFTMOUSE'; self.value = 'PRESS'
                self.mouse_region_x = x; self.mouse_region_y = y
                self.mouse_x = x + region.x; self.mouse_y = y + region.y
                self.shift = shift; self.ctrl = False; self.alt = False
        class FO:
            def report(self, *a, **k):
                pass
        _cls = inter.RTMP_OT_PathPointDrag
        if not getattr(FO, "_patched", False):
            for _nm in dir(_cls):
                if _nm.startswith("__"):
                    continue
                _v = getattr(_cls, _nm, None)
                if callable(_v):
                    try: setattr(FO, _nm, _v.__get__(FO()))
                    except Exception: pass
                elif not isinstance(_v, property):
                    try: setattr(FO, _nm, _v)
                    except Exception: pass
            FO._mouse_pos = None; FO._is_active = True
            FO._timer = None; FO._last_frame = None; FO._patched = True
        return inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context, Ev())

    # =========================================================
    # ② 端点：真实 render → 收集 → 命中 → 不消失 → 可再命中
    # =========================================================
    _session.clear_endpoints()
    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True      # 先全选，确保端点会被绘制
        fc.update()

    real_render()
    pts = list(_session.handle_control_points)
    step("② 真实 render 后收集到端点控制点（前提成立）", len(pts) > 0,
         "收集到 %d 个（4 关键帧 × 2 侧 = 8）" % len(pts))
    if len(pts) == 0:
        step("FATAL: render 未触发放置端点 —— 测试前提不成立", False,
             "handle_control_points 为空；rtmp_path_display_enabled=%s"
             % wm.rtmp_path_display_enabled)
        raise SystemExit

    # 找一个端点（f14 的 left）
    target = None
    for p in pts:
        if abs(p['frame'] - 14.0) < 1e-3 and p['side'] == 'left':
            target = p
            break
    step("② 找到 f14 的左手柄端点", target is not None,
         target and (target['side'], target['frame']))
    if target is None:
        raise SystemExit

    sp = view3d_utils.location_3d_to_region_2d(region, rv3d, target['position'])
    step("② 端点可投影到屏幕", sp is not None,
         sp and (round(sp.x, 1), round(sp.y, 1)))

    # 点它
    r = click(sp.x, sp.y)
    step("★ ② 点端点 → 命中并选中", len(_session.selected_handle_endpoints) > 0,
         _session.selected_handle_endpoints)
    step("② 命中返回 RUNNING_MODAL", r == {'RUNNING_MODAL'}, r)

    # ★ 关键：再 render 一次，端点必须仍在（修复前会消失）
    real_render()
    pts2 = list(_session.handle_control_points)
    still = any(abs(p['frame'] - 14.0) < 1e-3 and p['side'] == 'left' for p in pts2)
    step("★★ ② 选中端点后再 render → 端点仍被收集（不消失）", still,
         "收集到 %d 个" % len(pts2))

    # ★ 关键：再点一次，仍能命中（修复前 handle_control_points 空 → 命中不了）
    _session.clear_endpoints()
    sp2 = None
    for p in pts2:
        if abs(p['frame'] - 14.0) < 1e-3 and p['side'] == 'left':
            sp2 = view3d_utils.location_3d_to_region_2d(region, rv3d, p['position'])
    if sp2 is not None:
        click(sp2.x, sp2.y)
    step("★★ ② 再次点击仍能命中（修复前会失败）",
         len(_session.selected_handle_endpoints) > 0,
         _session.selected_handle_endpoints)

    # 关键帧点应保持未选中（互斥）
    kf_sel = [round(float(kp.co[0]), 1)
              for fc in xf._position_curves(act, obj, None)
              for kp in fc.keyframe_points if kp.select_control_point]
    step("★ ② 端点选中时关键帧点【未被选中】（原生语义）", len(kf_sel) == 0, kf_sel)

    # Shift 多选端点（先把关键帧点全选 + render，保证所有端点都被收集）
    _session.clear_endpoints()
    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True
        fc.update()
    real_render()
    pts3 = list(_session.handle_control_points)
    sp_f14 = sp_f27 = None
    for p in pts3:
        if p['side'] != 'left':
            continue
        s2 = view3d_utils.location_3d_to_region_2d(region, rv3d, p['position'])
        if s2 is None:
            continue
        if abs(p['frame'] - 14.0) < 1e-3:
            sp_f14 = s2
        elif abs(p['frame'] - 27.0) < 1e-3:
            sp_f27 = s2
    step("② 两个帧的端点都能投影", sp_f14 is not None and sp_f27 is not None,
         "f14=%s f27=%s" % (sp_f14 is not None, sp_f27 is not None))
    if sp_f14 is not None and sp_f27 is not None:
        click(sp_f14.x, sp_f14.y)
        n1 = len(_session.selected_handle_endpoints)
        click(sp_f27.x, sp_f27.y, shift=True)
        n2 = len(_session.selected_handle_endpoints)
        step("★ ② Shift+点第二个端点 → 累加（1 → 2）", n1 == 1 and n2 == 2,
             "%d -> %d  %s" % (n1, n2, _session.selected_handle_endpoints))
    _session.clear_endpoints()

    # =========================================================
    # ① 按 S 进入模态 → 径向（放大=疏 / 缩小=密）
    # =========================================================
    def build2():
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
                       (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]:
            sc.frame_set(f); o.location = loc
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
            fc.update()
        return o, a

    def s_of(o, a, frame, tri):
        recs = me.collect_speed_handles(a, o, region, rv3d)
        for r in recs:
            if r['frame'] == frame and r['tri'] == tri:
                return r['s'], r['d']
        return None, None

    o2, a2 = build2()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    # 多选两个三角
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    _session.add_speed_handle(27.0, hd.TRI_DOWN)
    step("① 多选两个三角", len(_session.selected_speed_handles) == 2,
         _session.selected_speed_handles)

    sps = me.ModalSession('SPEED')
    ok = sps.begin(o2, a2, 600.0, 400.0,
                   lambda x, y: me._resolve_target_preferring_selection(
                       bpy.context, o2, a2, x, y),
                   drag_mode='radial')
    step("★ ① 按 S（radial）进入模态", ok is True, sps.message)
    if ok:
        step("★ ① 拖拽模式 = radial", sps.drag_mode == 'radial', sps.drag_mode)
        step("① targets = 2", len(sps.targets) == 2, len(sps.targets))
        s14_0, d14_0 = s_of(o2, a2, 14.0, hd.TRI_UP)
        s27_0, d27_0 = s_of(o2, a2, 27.0, hd.TRI_DOWN)

        # ⚠️ 显式设定支点：测试环境里 `context.region` 可能无效 → target 的
        #    screen 会 fallback 成鼠标位置（pivot 退化）。这里给一个明确支点，
        #    才能干净地验证"往外/往里"两个方向。
        sps.pivot_screen = (200.0, 400.0)     # 支点在左
        sps.start_dist = 400.0                # 鼠标起点在 (600,400)
        sps._last_raw_px = 0.0
        sps.px_offset = 0.0

        # 往外拖（远离支点）→ 放大 → 变疏（s 减小）
        sps.update(800.0, 400.0)              # cur=600 → raw=+200
        s14_1, _ = s_of(o2, a2, 14.0, hd.TRI_UP)
        s27_1, _ = s_of(o2, a2, 27.0, hd.TRI_DOWN)
        step("★★ ① 往外拖（放大）→ f14 变疏（s 减小）", s14_1 < s14_0,
             "s: %.5f -> %.5f" % (s14_0, s14_1))
        step("★★ ① 往外拖（放大）→ f27 也变疏（同时）", s27_1 < s27_0,
             "s: %.5f -> %.5f" % (s27_0, s27_1))
        step("★ ① 两个的变化量一致（同一个径向位移）",
             abs((s14_0 - s14_1) - (s27_0 - s27_1)) < 1e-5,
             "Δ14=%.6f Δ27=%.6f" % (s14_0 - s14_1, s27_0 - s27_1))

        # 往里拖（靠近支点）→ 缩小 → 变密（s 增大）
        sps.update(400.0, 400.0)              # cur=200 → raw=-200 → 从 +200 回落到 -200
        s14_3, _ = s_of(o2, a2, 14.0, hd.TRI_UP)
        s27_3, _ = s_of(o2, a2, 27.0, hd.TRI_DOWN)
        step("★★ ① 往里拖（缩小）→ 变密（s 增大，且超过初始）",
             s14_3 > s14_0 and s27_3 > s27_0,
             "f14 %.5f->%.5f  f27 %.5f->%.5f" % (s14_0, s14_3, s27_0, s27_3))
        _txt = sps.status_text()
        step("① 状态栏文案用缩放语义（含「缩放」与「往外拖」）",
             ("缩放" in _txt) and ("往外拖" in _txt), _txt[:70])
        sps.cancel()

    # 对照：按 G 进入 → 仍是 vertical（上下拖）
    o3, a3 = build2()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    spg = me.ModalSession('SPEED')
    okg = spg.begin(o3, a3, 600.0, 400.0,
                    lambda x, y: me._resolve_target_preferring_selection(
                        bpy.context, o3, a3, x, y),
                    drag_mode='vertical')
    step("★ ① 按 G（vertical）仍是竖直语义", okg and spg.drag_mode == 'vertical',
         getattr(spg, 'drag_mode', None))

except SystemExit:
    pass
except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("ENDPOINT_FIX_DONE")
os._exit(0)
