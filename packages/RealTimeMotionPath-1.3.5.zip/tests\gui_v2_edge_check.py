# -*- coding: utf-8 -*-
"""交互优化 v2 —— 极端边界验收（2026-09-16）

覆盖用户要求的"极限极端边界场景"：

  A. 三角多选：全选 / 跨关键帧 / 混合方向 / 极值 / 未选中不受影响 / 反复 toggle
  B. 端点单选：单端点（恒等）/ 多端点 / 互斥 / 取消精确还原
  C. RGS 原生：轴朝向 10 连按 / 倒数边界 / 极端数值 / 反复切精度 20 次
  D. 数据安全：全程无 NaN / Inf

用法：blender --factory-startup --python tests/gui_v2_edge_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_ve_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import cache as rcache
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath.state import _session

    def build(with_parent=False, frames=None):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        if with_parent:
            bpy.ops.object.empty_add(location=(0, 0, 0))
            par = bpy.context.view_layer.objects.active
            par.name = "Par"; par.rotation_euler = (0.0, 0.6, 0.0)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        if with_parent:
            o.parent = par
        KFS = frames or [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
                         (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]
        for f, loc in KFS:
            sc.frame_set(int(f)); o.location = loc
            o.keyframe_insert("location", frame=f)
        act = o.animation_data.action
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
            fc.update()
        return o, act

    def nan_check(o, act):
        """遍历所有 fcurve 的 co/handle，检查 NaN/Inf。"""
        bad = []
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                for v in (kp.co[0], kp.co[1], kp.handle_left[0], kp.handle_left[1],
                          kp.handle_right[0], kp.handle_right[1]):
                    if not (v == v) or abs(v) == float("inf"):
                        bad.append((round(float(kp.co[0]), 2), v))
        return bad

    def all_s(o, act, recs):
        return {(r['frame'], r['tri']): r['s'] for r in recs}

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((5, 0, 0)); rv3d.view_distance = 18.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    wm.rtmp_path_display_enabled = True

    def drag(o, pts, precision=False, reset=True, origins=None):
        """模拟拖拽。

        ⚠️ `origins` 必须显式给（{(frame, tri): d0}）—— 那是"按下时的 d"，
           不给的话会落到 `speed_drag_origin_d`（可能是上次测试的残留）。
        """
        if reset:
            _session.speed_drag_last_mouse = None
            _session.speed_drag_effective_px = 0.0
        if origins:
            _session.speed_drag_origins = dict(origins)
            _session.speed_drag_origin_d = list(origins.values())[0]
        _session.speed_drag_precision = precision
        inter._apply_speed_from_drag(bpy.context, o, pts[0])
        for p in pts[1:]:
            inter._apply_speed_from_drag(bpy.context, o, p)

    # =========================================================
    # A. 三角多选 —— 极端
    # =========================================================
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs = me.collect_speed_handles(act, o, region, rv3d)
    step("A: 三角总数（4 关键帧 → 6 个）", len(recs) == 6, len(recs))

    # A1: 全选 6 个
    _session.clear_speed_handle()
    for r in recs:
        _session.toggle_speed_handle(r['frame'], r['tri'])
    step("★ A1 全选 6 个三角", len(_session.selected_speed_handles) == 6,
         len(_session.selected_speed_handles))

    before = all_s(o, act, recs)
    drag(o, [(600.0, 400.0), (600.0, 420.0)])       # 上拖 20px
    r2 = me.collect_speed_handles(act, o, region, rv3d)
    after = all_s(o, act, r2)
    changed = [k for k in before if k in after and abs(after[k] - before[k]) > 1e-6]
    step("★ A1 全选拖拽 → 6 个都变", len(changed) == 6, "%d/%d 变化" % (len(changed), len(before)))

    # A2: 混合方向（上三角 vs 下三角 同一次拖拽）
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs = me.collect_speed_handles(act, o, region, rv3d)
    up = [r for r in recs if r['tri'] == hd.TRI_UP][0]
    dn = [r for r in recs if r['tri'] == hd.TRI_DOWN and r['frame'] != up['frame']][0]
    _session.set_single_speed_handle(up['frame'], up['tri'])
    _session.add_speed_handle(dn['frame'], dn['tri'])
    b = {up['frame']: up['s'], dn['frame']: dn['s']}
    drag(o, [(600.0, 400.0), (600.0, 420.0)],       # 上拖 → 上三角变疏、下三角变密
         origins={(up['frame'], up['tri']): up['d'],
                  (dn['frame'], dn['tri']): dn['d']})
    r3 = me.collect_speed_handles(act, o, region, rv3d)
    a_up = [x for x in r3 if x['frame'] == up['frame'] and x['tri'] == hd.TRI_UP][0]['s']
    a_dn = [x for x in r3 if x['frame'] == dn['frame'] and x['tri'] == hd.TRI_DOWN][0]['s']
    step("★ A2 混合方向：上三角上拖 → 变疏（s 减小）", a_up < b[up['frame']],
         "%.5f -> %.5f" % (b[up['frame']], a_up))
    step("★ A2 混合方向：下三角上拖 → 变密（s 增大）", a_dn > b[dn['frame']],
         "%.5f -> %.5f" % (b[dn['frame']], a_dn))

    # A3: 未选中的不受影响
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs = me.collect_speed_handles(act, o, region, rv3d)
    pick = recs[0]
    _session.set_single_speed_handle(pick['frame'], pick['tri'])
    others = {(r['frame'], r['tri']): r['s'] for r in recs
              if not (r['frame'] == pick['frame'] and r['tri'] == pick['tri'])}
    drag(o, [(600.0, 400.0), (600.0, 420.0)])
    r4 = me.collect_speed_handles(act, o, region, rv3d)
    now_others = {(r['frame'], r['tri']): r['s'] for r in r4
                  if (r['frame'], r['tri']) in others}
    untouched = all(abs(now_others[k] - others[k]) < 1e-9 for k in others)
    step("★ A3 未选中的三角不受影响", untouched,
         "检查 %d 个" % len(others))

    # A4: 极值（拖到触底 / 撞上限）→ 无 NaN
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs = me.collect_speed_handles(act, o, region, rv3d)
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    drag(o, [(600.0, 400.0), (600.0, 5000.0)])       # 疯狂上拖 → 触底
    r5 = me.collect_speed_handles(act, o, region, rv3d)
    s_low = [x for x in r5 if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    # ⚠️ Blender 数据层对 dt 有分辨率下限（实测 ≈0.001 帧）→ s 不会低于约 7.7e-5
    #    （span=13 时）。这是【平台限制】，不是插件缺陷。
    step("★ A4 疯狂上拖 → s 触底（>0，受 Blender dt 分辨率限制）",
         0 < s_low <= 1e-4, "s=%.8f (S_EPS=%g)" % (s_low, td.S_EPS))
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_DOWN)
    drag(o, [(600.0, 400.0), (600.0, -5000.0)])      # 疯狂下拖 → 撞上限
    r6 = me.collect_speed_handles(act, o, region, rv3d)
    s_hi = [x for x in r6 if x['frame'] == 14.0 and x['tri'] == hd.TRI_DOWN][0]['s']
    step("★ A4 疯狂下拖 → s 撞上限 1.0 且不超", 0 < s_hi <= 1.0 + 1e-9,
         "s=%.6f" % s_hi)
    bad = nan_check(o, act)
    step("★ A4 极值拖拽后无 NaN/Inf", not bad, bad[:3])

    # A5: 反复 toggle 20 次
    _session.clear_speed_handle()
    for i in range(20):
        _session.toggle_speed_handle(14.0, hd.TRI_UP)
    step("A5 反复 toggle 20 次 → 集合为空（偶数次）", len(_session.selected_speed_handles) == 0,
         len(_session.selected_speed_handles))
    for i in range(19):
        _session.toggle_speed_handle(14.0, hd.TRI_UP)
    step("A5 再 toggle 19 次 → 集合为 1", len(_session.selected_speed_handles) == 1,
         _session.selected_speed_handles)
    _session.clear_speed_handle()

    # A6: 同一关键帧的上下两个三角
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    _session.add_speed_handle(14.0, hd.TRI_DOWN)
    recs = me.collect_speed_handles(act, o, region, rv3d)
    b14u = [x for x in recs if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    b14d = [x for x in recs if x['frame'] == 14.0 and x['tri'] == hd.TRI_DOWN][0]['s']
    recs6 = me.collect_speed_handles(act, o, region, rv3d)
    d14u = [x for x in recs6 if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['d']
    d14d = [x for x in recs6 if x['frame'] == 14.0 and x['tri'] == hd.TRI_DOWN][0]['d']
    drag(o, [(600.0, 400.0), (600.0, 415.0)],
         origins={(14.0, hd.TRI_UP): d14u, (14.0, hd.TRI_DOWN): d14d})
    r7 = me.collect_speed_handles(act, o, region, rv3d)
    a14u = [x for x in r7 if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    a14d = [x for x in r7 if x['frame'] == 14.0 and x['tri'] == hd.TRI_DOWN][0]['s']
    step("★ A6 同关键帧上下两三角 → 都变（方向相反）",
         a14u < b14u and a14d > b14d,
         "上 %.5f->%.5f  下 %.5f->%.5f" % (b14u, a14u, b14d, a14d))

    # =========================================================
    # B. 端点单选 —— 极端
    # =========================================================
    o, act = build()
    _session.clear_speed_handle()
    _session.clear_endpoints()
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = False
        fc.update()

    # B1: 单端点 R —— 支点 = 【对应控制点 co】（2026-09-16 修订）
    # ⚠️ 原以为"单端点绕自身转 = 恒等变换"，所以断言"不动"。
    #    但用户要的是原生曲线编辑语义：**手柄绕它的关键帧点(co)转**。
    #    故支点改为 co → 单端点 R 会真的转动手柄、且 co 不动。
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    co_w = me.keyframe_world_pos(act, o, 14.0)
    s1 = me.RotateSession('ROTATE')
    ok1 = s1.begin(o, act, region, rv3d, 600.0, 400.0)
    step("B1 单端点 R 能开始", ok1 is True, s1.message)
    if ok1:
        ch = s1.pivot_world - co_w
        step("★ B1 单端点 pivot == 对应控制点 co（原生：手柄绕它的关键帧点转）",
             ch.length < 1e-6, "偏差=%.9f" % ch.length)
        def snap14():
            d = {}
            for fc in xf._position_curves(act, o, None):
                for kp in fc.keyframe_points:
                    if abs(kp.co[0]-14) < 1e-3:
                        d[fc.array_index] = (float(kp.co[1]), float(kp.handle_left[1]))
            return d
        b0 = snap14()
        s1.apply_numeric(60.0)
        a0 = snap14()
        co_moved = max(abs(a0[i][0] - b0[i][0]) for i in b0)
        hl_moved = max(abs(a0[i][1] - b0[i][1]) for i in b0)
        step("★ B1 单端点 R → 手柄真的转了（不再是恒等变换）", hl_moved > 1e-4,
             "Δhandle=%.6f" % hl_moved)
        step("★ B1 单端点 R → co 不动", co_moved < 1e-6, "Δco=%.9f" % co_moved)
        s1.cancel()

    # B2: 多端点 R → 只动手柄、co 不动
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    _session.toggle_endpoint(27.0, 'left')
    s2 = me.RotateSession('ROTATE')
    ok2 = s2.begin(o, act, region, rv3d, 600.0, 400.0)
    step("B2 两端点 R 能开始", ok2 is True, s2.message)
    if ok2:
        def full():
            d = {}
            for fc in xf._position_curves(act, o, None):
                for kp in fc.keyframe_points:
                    fr = round(float(kp.co[0]), 2)
                    d.setdefault(fr, {})[fc.array_index] = (
                        float(kp.co[1]), float(kp.handle_left[1]), float(kp.handle_right[1]))
            return d
        fb = full()
        s2.apply_numeric(35.0)
        fa = full()
        co_same = all(abs(fa[f][i][0] - fb[f][i][0]) < 1e-6
                      for f in fb for i in fb[f])
        h_changed = any(abs(fa[f][i][k] - fb[f][i][k]) > 1e-6
                        for f in fb for i in fb[f] for k in (1, 2))
        step("★★ B2 两端点 R → 所有 co 不动", co_same, "")
        step("★ B2 两端点 R → 手柄变了", h_changed, "")
        s2.cancel()
        fc_ = full()
        worst = max(abs(fc_[f][i][k] - fb[f][i][k])
                    for f in fb for i in fb[f] for k in range(3))
        step("★ B2 取消 → 精确还原（co + 手柄）", worst < 1e-6, "最大差=%.9f" % worst)

    # B3: 互斥 —— 有端点选中时点关键帧点
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    _session.handle_control_points = []
    from bpy_extras import view3d_utils
    wp = me.keyframe_world_pos(act, o, 27.0)
    sp = view3d_utils.location_3d_to_region_2d(region, rv3d, wp)

    class Ev:
        def __init__(self, t, v, x, y, shift=False):
            self.type = t; self.value = v
            self.mouse_region_x = x; self.mouse_region_y = y
            self.mouse_x = x + region.x; self.mouse_y = y + region.y
            self.shift = shift; self.ctrl = False; self.alt = False
    class FO:
        def report(self, *a, **k):
            pass
    _cls = inter.RTMP_OT_PathPointDrag
    for _nm in dir(_cls):
        if _nm.startswith("__"):
            continue
        _v = getattr(_cls, _nm, None)
        if callable(_v):
            try: setattr(FO, _nm, _v.__get__(FO()))
            except Exception: pass
        elif not isinstance(_v, property):
            try: setattr(FO, _nm, _v)
            except Exception: pass
    FO._mouse_pos = None; FO._is_active = True; FO._timer = None; FO._last_frame = None

    inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context,
                                      Ev('LEFTMOUSE', 'PRESS', sp.x, sp.y))
    step("★ B3 点关键帧点 → 端点选中被清（互斥）",
         len(_session.selected_handle_endpoints) == 0, _session.selected_handle_endpoints)
    kf_sel = [round(float(kp.co[0]), 1)
              for fc in xf._position_curves(act, o, None)
              for kp in fc.keyframe_points if kp.select_control_point]
    step("★ B3 关键帧点被选中", len(kf_sel) >= 1, kf_sel)

    # =========================================================
    # C. RGS 原生 —— 极端
    # =========================================================
    # C1: 连按 X 10 次
    o, act = build(with_parent=True)
    s3 = me.RotateSession('ROTATE')
    s3.begin(o, act, region, rv3d, 600.0, 400.0)
    seq = []
    for i in range(10):
        s3.set_axis('X')
        seq.append(s3.axis_orientation)
    # 第一次按 = 设轴（GLOBAL），之后每次 = 切换朝向
    ok_alt = (seq[0] == 'GLOBAL'
              and all(seq[i] != seq[i-1] for i in range(1, len(seq)))
              and all(o in ('GLOBAL', 'LOCAL') for o in seq))
    step("★ C1 连按 X 10 次 → 朝向每次正确交替", ok_alt, seq)
    s3.cancel()

    # C2: 极端数值
    o, act = build()
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = (abs(kp.co[0]-14) < 1e-3)
        fc.update()
    s4 = me.MoveSession('MOVE')
    ok4 = s4.begin(o, act, region, rv3d, 600.0, 400.0)
    if ok4:
        for v in (1e6, 1e9, -1e9, 0.0000001):
            try:
                s4.apply_numeric(v)
                bad = nan_check(o, act)
                step("C2 数字输入 %g → 无 NaN/Inf" % v, not bad, bad[:2])
            except Exception as e:
                step("C2 数字输入 %g" % v, False, "%s: %s" % (type(e).__name__, e))
        s4.cancel()

    # C3: 反复切精度 20 次（鼠标不动）
    o, act = build()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    recs = me.collect_speed_handles(act, o, region, rv3d)
    A = [r for r in recs if r['frame'] == 14.0 and r['tri'] == hd.TRI_UP][0]
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    _session.speed_drag_origins = {(14.0, hd.TRI_UP): A['d']}
    _session.speed_drag_origin_d = A['d']
    drag(o, [(600.0, 400.0), (600.0, 410.0)])       # 拖 10px
    mid = [x for x in me.collect_speed_handles(act, o, region, rv3d)
           if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    for i in range(20):
        _session.speed_drag_precision = (i % 2 == 0)
        inter._apply_speed_from_drag(bpy.context, o, (600.0, 410.0))   # 鼠标不动
    after = [x for x in me.collect_speed_handles(act, o, region, rv3d)
             if x['frame'] == 14.0 and x['tri'] == hd.TRI_UP][0]['s']
    step("★ C3 反复切精度 20 次（鼠标不动）→ 值绝对不变",
         abs(after - mid) < 1e-12, "%.9f -> %.9f" % (mid, after))

    # C4: 倒数边界
    ni = me.NumericInput()
    ni.key('ZERO'); ni.key('SLASH')
    step("C4 `0/` → 不做倒数（避免除零）", ni.buf == "0", ni.buf)
    ni2 = me.NumericInput()
    ni2.key('SLASH')
    step("C4 空 buf 按 / → 不崩", ni2.value() in (None, 0.0), ni2.buf)

    # =========================================================
    # D. 全局数据安全
    # =========================================================
    o, act = build(with_parent=True)
    bad_all = nan_check(o, act)
    step("D 全程结束后所有 fcurve 无 NaN/Inf", not bad_all, bad_all[:3])

except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("V2_EDGE_DONE")
os._exit(0)
