# -*- coding: utf-8 -*-
"""实测：VECTOR 在插件里到底有没有用？AUTO_CLAMPED 是什么"性格"？

三问：
  Q1 VECTOR 原始类型下，拖一侧手柄，对侧怎么动？
  Q2 VECTOR 是否"活性"（被 Blender 重算）？
  Q3 AUTO_CLAMPED 原始类型下，手柄是活是死？拖一侧对侧怎么动？
"""
import os
import sys
import json
import mathutils

import bpy

REPO = r"F:\desktop\BaiduSyncdisk\addons\RealTimeMotionPath"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import gpu
gpu.init()
bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")

from RealTimeMotionPath import (drawing as dw, transform_domain as xf,
                                cache as rcache, overlay as ovmod, interaction as it)
from RealTimeMotionPath.state import _session

sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 40
KFS = [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
       (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]
FRAME = 14.0

win = bpy.context.window_manager.windows[0]
area = next(x for x in win.screen.areas if x.type == 'VIEW_3D')
region = next(r for r in area.regions if r.type == 'WINDOW')
rv3d = area.spaces.active.region_3d
rv3d.view_location = mathutils.Vector((5, 0, 0))
rv3d.view_distance = 18.0
rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
wm = bpy.context.window_manager
wm.rtmp_edit_mode_active = True
wm.rtmp_path_display_enabled = True
OVR = {"window": win, "screen": win.screen, "area": area,
       "region": region, "space_data": area.spaces.active}

rows = []


def rec(name, **kw):
    kw["name"] = name
    rows.append(kw)
    print("[ROW]", json.dumps(kw, ensure_ascii=False)[:600])


def each_kp(o, act, frame, fn):
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - frame) < 1e-3:
                fn(fc, kp)


def read(o, act, frame):
    got = {}
    def f(fc, kp):
        got[fc.array_index] = (str(kp.handle_left_type), str(kp.handle_right_type),
                               round(float(kp.handle_left[1] - kp.co[1]), 6),
                               round(float(kp.handle_right[1] - kp.co[1]), 6))
    each_kp(o, act, frame, f)
    return got


def set_types(o, act, frame, t):
    def f(fc, kp):
        kp.handle_left_type = t
        kp.handle_right_type = t
    each_kp(o, act, frame, f)


def build():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.view_layer.objects.active
    o.name = "T"
    for f, loc in KFS:
        sc.frame_set(f); o.location = loc
        o.keyframe_insert("location", frame=f)
    return o, o.animation_data.action


def make_op():
    class FO:
        def report(self, *a, **k):
            pass
    cls = it.RTMP_OT_PathPointDrag
    for nm in dir(cls):
        if nm.startswith("__"):
            continue
        v = getattr(cls, nm, None)
        if callable(v):
            try:
                setattr(FO, nm, v.__get__(FO()))
            except Exception:
                pass
    return FO()


def refresh(o, act):
    ovmod.get_overlay().start(session=None)
    dw.attach_render_callback()
    def sel(fc, kp):
        kp.select_control_point = True
    each_kp(o, act, FRAME, sel)
    for fc in xf._position_curves(act, o, None):
        fc.update()
    rcache.refresh_position_store(bpy.context)
    _session.handle_control_points = []
    with bpy.context.temp_override(**OVR):
        dw.render_path_overlay()
    return {p["side"]: p for p in _session.handle_control_points
            if abs(p["frame"] - FRAME) < 1e-3}


def drag(o, act, op, ctx, side, vec):
    pts = refresh(o, act)
    hp = pts.get(side)
    if hp is None:
        return False
    _session.drag_in_progress = False
    _session.active_path_point = None
    _session.active_frame_number = None
    op.record_handle_baseline(ctx, FRAME, None, side)
    op.apply_handle_point_offset(ctx, vec, hp)
    return True


try:
    for tag, T in (("VECTOR", "VECTOR"), ("AUTO_CLAMPED", "AUTO_CLAMPED"),
                   ("ALIGNED", "ALIGNED")):
        # --- Q1/Q3: 拖一侧，看对侧动不动 ---
        o, act = build()
        set_types(o, act, FRAME, T)
        for fc in xf._position_curves(act, o, None):
            fc.update()
        before = read(o, act, FRAME)

        op = make_op()
        with bpy.context.temp_override(**OVR):
            ctx = bpy.context
            bpy.context.view_layer.objects.active = o
            it._session.drag_target_object = o.name
            drag(o, act, op, ctx, 'right', mathutils.Vector((1.2, 0.0, 0.0)))
        after = read(o, act, FRAME)

        def dl(b, a):
            return round(sum(abs(b[k][3] - a[k][3]) for k in b if k in a), 6)
        def dlt(b, a):
            return round(sum(abs(b[k][2] - a[k][2]) for k in b if k in a), 6)

        rec("%s 拖右手柄" % tag,
            拖前_类型=[before[1][0], before[1][1]],
            拖后_类型=[after[1][0], after[1][1]],
            对侧左手柄变化=dl(before, after),
            被拖侧右手柄变化=dlt(before, after))

        # --- Q2: 活性（只移动关键帧 co 后 Blender 重算）---
        o2, act2 = build()
        set_types(o2, act2, FRAME, "VECTOR" if T == "VECTOR" else T)
        for fc in xf._position_curves(act2, o2, None):
            fc.update()
        b2 = read(o2, act2, FRAME)
        for fc in xf._position_curves(act2, o2, None):
            kp = xf.keyframe_at(fc, FRAME)
            if kp:
                kp.co = (kp.co[0], kp.co[1] + 0.8)
        for fc in xf._position_curves(act2, o2, None):
            fc.update()
        a2 = read(o2, act2, FRAME)
        rec("%s 只移动关键帧后（活性）" % tag,
            手柄坐标变化=round(sum(abs(b2[k][2] - a2[k][2]) + abs(b2[k][3] - a2[k][3])
                              for k in b2 if k in a2), 8))

except Exception:
    import traceback
    rec("FATAL", tb=traceback.format_exc()[-1500:])

with open(os.path.join(HERE, "_vecal_probe.json"), "w", encoding="utf-8") as fh:
    json.dump(rows, fh, ensure_ascii=False, indent=1)
print("VECAL_DONE")
os._exit(0)
