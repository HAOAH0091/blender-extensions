"""RTMP 速度手柄几何（关键帧上下两个三角）

设计（用户 2026-09-15 定稿，见标注图）
--------------------------------------
每个关键帧有【两个】速度手柄，分别负责两侧：

        ▼  ← 上三角，尖端【朝下】指向关键帧，负责【左段】（上一关键帧 → 本关键帧）
        ▪  ← 关键帧点
        ▲  ← 下三角，尖端【朝上】指向关键帧，负责【右段】（本关键帧 → 下一关键帧）

    离关键帧的垂直距离 d 表示该侧的疏密：
        d = CV_MID   → 1.00x 匀速（虚线基准位置）
        d 越大        → 越疏（采样点被拉散）
        d 越小        → 越密

    端点段（第一帧的左段 / 最后一帧的右段）没有相邻关键帧 → **不生成手柄**。

坐标约定
--------
所有屏幕坐标都是 Blender region 坐标（**y 向上为正**）。
本模块【不依赖 bpy】，纯几何，便于 headless 测试。
"""

# 三角种类
TRI_UP = 'up'      # ▼ 在关键帧上方，管左段
TRI_DOWN = 'down'  # ▲ 在关键帧下方，管右段

TRI_KINDS = (TRI_UP, TRI_DOWN)

# 三角 -> 负责的段（与 time_domain 的 side 语义一致）
SIDE_BY_TRI = {TRI_UP: 'left', TRI_DOWN: 'right'}

# 三角 -> 屏幕 y 方向（+1 = 在关键帧上方）
DIR_BY_TRI = {TRI_UP: 1.0, TRI_DOWN: -1.0}

# 三角种类 -> 显示名
LABEL_BY_TRI = {TRI_UP: '左段', TRI_DOWN: '右段'}

# ---------------------------------------------------------------------------
# 视觉常量
# ---------------------------------------------------------------------------
# 用户 2026-09-15：「三角交互后不需要移动，固定住就行」
#   → 三角永远画在距关键帧【固定偏移】处；疏密值只存在于数据里，
#     交互反馈改为「受影响的路径段变色」。
#   ⚠️ 【绘制位置】与【命中检测位置】必须用同一个常量，
#      否则会出现"看得见却点不中"。
TRI_FIXED_D = 26.0        # 屏幕像素（用户 2026-09-15：40 有点远，靠近一点）
TRI_HALF_PX = 6.5
TRI_HEIGHT_PX = 7.5

# 段 -> 三角（SIDE_BY_TRI 的逆）
TRI_BY_SIDE = {v: k for k, v in SIDE_BY_TRI.items()}


# ---------------------------------------------------------------------------
# 纯几何
# ---------------------------------------------------------------------------

def tri_center(kf_screen, tri, d):
    """三角的屏幕中心位置。

    kf_screen : (x, y) 关键帧的屏幕坐标
    tri       : TRI_UP / TRI_DOWN
    d         : 该侧的垂直距离（像素，>= 0）
    """
    return (kf_screen[0], kf_screen[1] + DIR_BY_TRI[tri] * d)


def d_from_mouse(kf_screen, tri, mouse_xy):
    """鼠标【绝对】位置 -> 该三角的 d 值（钳到 >= 0）。

    只有【垂直于关键帧的那条线】上的距离算数（与用户定的"屏幕垂直"语义一致）。
    """
    dy = (mouse_xy[1] - kf_screen[1]) * DIR_BY_TRI[tri]
    return dy if dy > 0.0 else 0.0


def drag_delta_px(tri, start_mouse, cur_mouse):
    """拖拽产生的 d 增量（屏幕像素）。

    用户 2026-09-15：三角【固定不动】，拖拽改为【相对量】——
    往"远离关键帧"的方向拖 = 更疏。

        TRI_UP  （在关键帧上方）→ 往上拖 = 更疏（+）
        TRI_DOWN（在关键帧下方）→ 往下拖 = 更疏（-）
    """
    return (cur_mouse[1] - start_mouse[1]) * DIR_BY_TRI[tri]


def dist2(a, b):
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    return dx * dx + dy * dy


def hit_test(handles, mouse_xy, radius):
    """在 handles 里找离鼠标最近、且在 radius 内的手柄。命中返回该手柄，否则 None。"""
    best = None
    best_d2 = radius * radius
    for h in handles:
        c = h.get('tri_screen')
        if c is None:
            continue
        d2 = dist2(c, mouse_xy)
        if d2 <= best_d2:
            best_d2 = d2
            best = h
    return best


def keyframe_hit(frames_screen, mouse_xy, radius):
    """在 {frame: (x,y)} 里找离鼠标最近、且在 radius 内的关键帧。返回 frame 或 None。"""
    best = None
    best_d2 = radius * radius
    for f, c in frames_screen.items():
        if c is None:
            continue
        d2 = dist2(c, mouse_xy)
        if d2 <= best_d2:
            best_d2 = d2
            best = f
    return best


# ---------------------------------------------------------------------------
# 组装（依赖注入 project / world_of，避免与 modal_edit 循环导入）
# ---------------------------------------------------------------------------

def make_handle(frame, tri, span, s, d, kf_screen, kf_world):
    """构造一条手柄描述。

    · `s` / `d` 是【数据】（该侧的疏密状态）
    · `tri_screen` 是【画在哪 / 点哪】—— 固定偏移，与 d 无关
    ⚠️ 两者必须分开：绘制与命中都用 tri_screen，否则会"看得见点不中"。
    """
    return {
        'frame': frame,
        'tri': tri,
        'side': SIDE_BY_TRI[tri],
        'span': span,
        's': s,
        'd': d,
        'kf_screen': kf_screen,
        'kf_world': kf_world,
        # 固定偏移（用户：三角不随交互移动）
        'tri_screen': tri_center(kf_screen, tri, TRI_FIXED_D),
    }


def collect_handles(frames, resolve, read_s, s_to_d, project, world_of):
    """列出所有【可编辑】的速度手柄。

    frames    : 关键帧帧号序列
    resolve   : (frame, side) -> (kf_map, span)；span 为 None 表示端点段
    read_s    : (kf_map, span, side) -> s
    s_to_d    : s -> 屏幕垂直距离
    project   : 世界坐标 -> 屏幕坐标（或 None）
    world_of  : frame -> 世界坐标（或 None）
    """
    out = []
    for f in frames:
        kf_world = world_of(f)
        if kf_world is None:
            continue
        kf_screen = project(kf_world)
        if kf_screen is None:
            continue
        for tri in TRI_KINDS:
            side = SIDE_BY_TRI[tri]
            kf_map, span = resolve(f, side)
            if not kf_map or span is None:
                continue                      # 端点段：无相邻关键帧，不生成
            s = read_s(kf_map, span, side)
            if s is None:
                continue
            d = s_to_d(s)
            out.append(make_handle(f, tri, span, s, d, kf_screen, kf_world))
    return out


def find_handle(handles, frame, tri):
    """按 (frame, tri) 查手柄。"""
    for h in handles:
        if h['frame'] == frame and h['tri'] == tri:
            return h
    return None


def ratio_of(s, lin_s):
    """相对匀速的倍数（1.00 = 匀速）。仅用于显示。"""
    if not s or s <= 1e-9:
        return 0.0
    return lin_s / s
