# -*- coding: utf-8 -*-
"""R 旋转 / S 缩放 验收测试

覆盖（用户 2026-09-15：「继续其他剩下的开发全部完成」）：
  · R：绕【选中点中位点】旋转；角度跟鼠标；Shift 精度 ×1/30；锁轴
  · S：以中位点为中心缩放；比例跟鼠标距离；Shift 精度；限制轴/平面
  · 两者都应：手柄同步（形状相似变换）、ESC 精确恢复、多选点一起动

用法：blender --factory-startup --python tests/gui_transform_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_xf_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    # XY 平面上的点群（便于验证旋转/缩放的几何）
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
           (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath.state import _session

    fcs = xf._position_curves(act, obj, None)

    def reset():
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
                kp.select_control_point = False
            pts = list(fc.keyframe_points)
            for i in range(len(pts)-1):
                k0, k1 = pts[i], pts[i+1]
                t0,v0,t1,v1 = k0.co[0],k0.co[1],k1.co[0],k1.co[1]
                k0.handle_right = (t0+(t1-t0)/3, v0+(v1-v0)/3)
                k1.handle_left  = (t0+2*(t1-t0)/3, v0+2*(v1-v0)/3)
            fc.update()
        # 恢复原始位置
        for f, loc in KFS:
            for fc in fcs:
                for kp in fc.keyframe_points:
                    if abs(kp.co[0]-f) < 0.5:
                        kp.co = (kp.co[0], loc[fc.array_index])
            for fc in fcs: fc.update()

    def select_only(frames):
        want = [float(f) for f in frames]
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.select_control_point = any(abs(kp.co[0]-f) < 0.5 for f in want)
            fc.update()

    def pose(frame):
        v = [0.0, 0.0, 0.0]
        for fc in fcs:
            for kp in fc.keyframe_points:
                if abs(kp.co[0]-frame) < 0.5:
                    v[fc.array_index] = kp.co[1]
        return mathutils.Vector(v)

    def handle_pose(frame):
        """返回 (hl, hr) 三轴向量（验证手柄是否跟随）。"""
        hl = [0.0,0.0,0.0]; hr = [0.0,0.0,0.0]
        for fc in fcs:
            for kp in fc.keyframe_points:
                if abs(kp.co[0]-frame) < 0.5:
                    hl[fc.array_index] = kp.handle_left[1]
                    hr[fc.array_index] = kp.handle_right[1]
        return mathutils.Vector(hl), mathutils.Vector(hr)

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))   # 正对 XY 平面（顶视）
    bpy.context.view_layer.update()

    # ================================================================
    # R 旋转
    # ================================================================
    reset(); select_only([1, 14])
    p1 = pose(1.0); p14 = pose(14.0)
    pivot = (p1 + p14) / 2.0
    step("R setup: pivot == mean of selected", True,
         "p1=%s p14=%s pivot=%s" % (tuple(round(c,2) for c in p1),
                                    tuple(round(c,2) for c in p14),
                                    tuple(round(c,2) for c in pivot)))

    s = me.RotateSession('ROTATE')
    ok = s.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("R begin", ok is True, s.message)
    step("R pivot_world computed", s.pivot_world is not None,
         tuple(round(c,3) for c in s.pivot_world) if s.pivot_world else None)
    step("R axis = 屏幕法线（顶视 = 世界 Z）",
         s.axis_local is not None and abs(abs(s.axis_local.z) - 1.0) < 1e-6,
         tuple(round(c,4) for c in s.axis_local) if s.axis_local else None)

    # 旋转 90°：把鼠标【绕 pivot 转 90°】
    sp = me._screen_pos(region, rv3d, s.pivot_world)
    r = 100.0
    # ★ 2026-09-16：R 已改为【角度式】—— 鼠标绕支点转 θ → 手柄转 θ（1:1，复刻原生）。
    #   旧口径是"切向位移 ÷ REF_RADIUS"，会随支点距离线性放大
    #   （实测 R=800px 时鼠标转 5° 手柄却转 26.6°），用户反馈"数值不对等"。
    #   基准：鼠标在支点正右方 r 处（_last_mouse_angle = 0）
    s.start_vec = mathutils.Vector((r, 0.0))
    s._last_mouse_angle = 0.0
    s._set_angle_raw(0.0)
    s.update(sp.x + r, sp.y)                 # 基准帧（角度不变）
    a0 = pose(1.0)
    s.update(sp.x, sp.y + r)                 # 绕 pivot +90°，半径保持 r（屏幕 y 向上 = 逆时针）
    step("★ R angle ≈ 90°（鼠标绕支点转 90° → 1:1）",
         abs(abs(math.degrees(s.angle)) - 90.0) < 0.1,
         "%.4f°" % math.degrees(s.angle))
    a1 = pose(1.0)
    # 验证：点到 pivot 的距离不变（旋转是刚体变换）
    d0 = (a0 - s.pivot_world).length
    d1 = (a1 - s.pivot_world).length
    step("R preserves distance to pivot (刚体)", abs(d0 - d1) < 1e-5,
         "%.6f -> %.6f" % (d0, d1))
    # 验证：三个选中点的相对关系保持（p1-p14 长度不变）
    b14 = pose(14.0)
    step("R preserves pairwise distance", abs((a1-b14).length - (a0-p14).length) < 1e-5,
         "%.6f -> %.6f" % ((a0-p14).length, (a1-b14).length))
    # 手柄跟随
    hl, hr = handle_pose(1.0)
    step("R: handles move with point (相似变换)",
         abs((hl - a1).length - (hl - a0).length) < 1e-5 or (hl - a1).length < 1e-6,
         "handle offset preserved")
    # 未选中的点不动
    step("R: unselected point (f40) untouched",
         abs((pose(40.0) - mathutils.Vector((12.0, 0.0, 0.0))).length) < 1e-6,
         tuple(round(c,3) for c in pose(40.0)))

    # ESC 精确恢复
    s.cancel()
    step("R cancel restores exactly", abs((pose(1.0) - p1).length) < 1e-6,
         tuple(round(c,4) for c in pose(1.0)))

    # 精度 ×1/30
    reset(); select_only([1, 14])
    s2 = me.RotateSession('ROTATE')
    s2.begin(obj, act, region, rv3d, 600.0, 400.0)
    sp2 = me._screen_pos(region, rv3d, s2.pivot_world)
    s2.start_vec = mathutils.Vector((100.0, 0.0))
    s2.update(sp2.x, sp2.y + 100.0)
    full_angle = s2.angle
    s2.cancel()
    s3 = me.RotateSession('ROTATE')
    s3.begin(obj, act, region, rv3d, 600.0, 400.0)
    s3.set_precision(True)
    s3.start_vec = mathutils.Vector((100.0, 0.0))
    sp3 = me._screen_pos(region, rv3d, s3.pivot_world)
    s3.update(sp3.x, sp3.y + 100.0)
    step("R precision ×1/30", abs(s3.angle - full_angle / 30.0) < 1e-6,
         "full=%.6f prec=%.6f ratio=%.4f" % (full_angle, s3.angle,
                                             s3.angle/full_angle if full_angle else 0))
    s3.cancel()

    # ================================================================
    # S 缩放
    # ================================================================
    reset(); select_only([1, 14])
    s4 = me.ScaleSession('SCALE')
    ok = s4.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("S begin", ok is True, s4.message)
    sp4 = me._screen_pos(region, rv3d, s4.pivot_world)
    s4.start_vec = mathutils.Vector((100.0, 0.0))
    s4.start_len = 100.0
    b4 = pose(14.0)
    # ⚠️ 2026-09-16：手感改为【径向位移 ÷ REF_RADIUS】。
    #    要 factor = 2.0，径向位移 = REF_RADIUS（起点在 +100，故终点在 +100+REF）
    s4.update(sp4.x + 100.0 + me.REF_RADIUS, sp4.y)
    step("S factor == 2.0（径向位移 = REF）", abs(s4.factor - 2.0) < 1e-6, "%.4f" % s4.factor)
    a4 = pose(14.0)
    d_before = (b4 - s4.pivot_world).length
    d_after = (a4 - s4.pivot_world).length
    step("S doubles distance to pivot", abs(d_after - 2.0*d_before) < 1e-3,
         "%.4f -> %.4f" % (d_before, d_after))
    # pivot 本身不动（但 pivot 不在关键帧上，所以检查点群中心保持）
    c_after = (pose(1.0) + pose(14.0)) / 2.0
    step("S keeps the group centre (pivot) fixed",
         abs((c_after - s4.pivot_world).length) < 1e-4,
         "centre offset=%.6f" % (c_after - s4.pivot_world).length)
    s4.cancel()
    step("S cancel restores exactly", abs((pose(14.0) - b4).length) < 1e-6,
         tuple(round(c,4) for c in pose(14.0)))

    # S：限制到 X 轴
    reset(); select_only([1, 14])
    s5 = me.ScaleSession('SCALE')
    s5.begin(obj, act, region, rv3d, 600.0, 400.0)
    b5 = pose(14.0)
    s5.set_axis('X')
    s5.start_vec = mathutils.Vector((100.0, 0.0)); s5.start_len = 100.0
    sp5 = me._screen_pos(region, rv3d, s5.pivot_world)
    s5.update(sp5.x + 200.0, sp5.y)
    a5 = pose(14.0)
    step("S axis-lock X: only X changes",
         abs(a5.x - b5.x) > 1e-4 and abs(a5.y - b5.y) < 1e-6 and abs(a5.z - b5.z) < 1e-6,
         "d=(%.4f, %.4f, %.4f)" % (a5.x-b5.x, a5.y-b5.y, a5.z-b5.z))
    s5.cancel()

    # S：Shift+Y → 排除 Y（在 XZ 缩放）
    reset(); select_only([1, 14])
    s6 = me.ScaleSession('SCALE')
    s6.begin(obj, act, region, rv3d, 600.0, 400.0)
    s6.set_plane('Y')
    step("S plane-lock Shift+Y -> mask excludes Y",
         s6._axis_mask() == (1.0, 0.0, 1.0), s6._axis_mask())
    s6.cancel()

    # S 精度
    reset(); select_only([1, 14])
    s7 = me.ScaleSession('SCALE')
    s7.begin(obj, act, region, rv3d, 600.0, 400.0)
    s7.start_vec = mathutils.Vector((100.0, 0.0)); s7.start_len = 100.0
    sp7 = me._screen_pos(region, rv3d, s7.pivot_world)
    s7.update(sp7.x + 200.0, sp7.y)
    full_f = s7.factor            # ≈2.0
    s7.set_precision(True)
    s7.update(sp7.x + 200.0, sp7.y)
    step("S precision: (factor-1) scaled by 0.1",
         abs(s7.factor - (1.0 + (full_f - 1.0)*0.1)) < 1e-6,
         "full=%.4f prec=%.4f" % (full_f, s7.factor))
    s7.cancel()

    # ================================================================
    # 通用：无选中 / 多选
    # ================================================================
    reset()
    step("R without selection -> begin False (no crash)",
         me.RotateSession('ROTATE').begin(obj, act, region, rv3d, 600, 400) is False, "")
    step("S without selection -> begin False (no crash)",
         me.ScaleSession('SCALE').begin(obj, act, region, rv3d, 600, 400) is False, "")

    reset(); select_only([1, 14, 27, 40])
    s8 = me.ScaleSession('SCALE')
    s8.begin(obj, act, region, rv3d, 600.0, 400.0)
    bs = [pose(f) for f in (1.0, 14.0, 27.0, 40.0)]
    s8.start_vec = mathutils.Vector((100.0, 0.0)); s8.start_len = 100.0
    sp8 = me._screen_pos(region, rv3d, s8.pivot_world)
    s8.update(sp8.x + 150.0, sp8.y)
    ratios = []
    for f, b in zip((1.0,14.0,27.0,40.0), bs):
        d0 = (b - s8.pivot_world).length
        d1 = (pose(f) - s8.pivot_world).length
        if d0 > 1e-6:
            ratios.append(d1/d0)
    step("S multi-select: all points scaled by same ratio",
         ratios and max(ratios) - min(ratios) < 1e-4,
         "ratios=%s" % [round(r,4) for r in ratios])
    s8.cancel()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("TRANSFORM_CHECK_DONE")
os._exit(0)
