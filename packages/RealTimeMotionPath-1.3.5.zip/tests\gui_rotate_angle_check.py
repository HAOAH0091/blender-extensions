# -*- coding: utf-8 -*-
"""R（旋转）角度口径验收（2026-09-16）

═══ 用户反馈 ═══

「r的虚线还有实际的带动数值量有不对等的问题，就是光标只相对移动了5°，
  但是实际3d手柄却旋转了更多，虚线也没有紧跟光标」

═══ 根因（实测 `_rot.py` 量化）═══

旧实现 `angle = 切向位移(px) / REF_RADIUS(150)` —— **像素口径**。
鼠标绕支点转 θ 时切向位移 ≈ R·θ → `angle ≈ (R/150)·θ`，**倍率 R/150**：

    | 支点离鼠标 R | 鼠标转 5° → 手柄转 | 倍率 |
    |---|---|---|
    | 150 px  |  4.99° |  1.0  |
    | 400 px  | 13.32° |  2.66 |
    | 800 px  | 26.63° |  5.33 |
    | 1500 px | 49.94° |  9.99 |

虚线方向 = 鼠标绕支点的**真实角度**（转 5°），手柄却转 26.6°
→ 视觉与数值对不上 → 用户觉得「虚线没紧跟 + 数值不对等」。**同一根因。**

═══ 本测试的断言 ═══

  A. ★★ **1:1 对等**：任意 R 下，鼠标转 θ → angle == θ（这是本次修复的核心）
  B. ★ 倍率**不随 R 变化**（旧实现会随 R 线性放大 → 这条能抓住它）
  C. 跨 ±180° 不翻转（连续转 200° 就是 200°，不是 -160°）
  D. 可连续转多圈（720°）
  E. 鼠标贴近支点不抖动
  F. 精度（Shift）× 1/30，且 angle/raw 不变式成立
  G. 数字输入与角度同步（apply_numeric 后继续拖不出错）
  H. 虚线端点严格跟随鼠标（用户说"没紧跟"→ 要证明它跟）

用法：blender --background --factory-startup --python tests/gui_rotate_angle_check.py
"""
import bpy, os, sys, json, math, traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_ra_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())


def make_session(me, ob, act, region, rv3d, R, start_deg=0.0):
    """建一个 R 会话，把鼠标放在「支点 + R·(cos start, sin start)」处。"""
    s = me.RotateSession('ROTATE')
    ok = s.begin(ob, act, region, rv3d, 0, 0, None)
    if not ok:
        raise RuntimeError("begin failed: %s" % s.message)
    sp = s._pivot_screen()
    if sp is None:
        raise RuntimeError("no pivot screen")
    p0 = (sp.x + R * math.cos(math.radians(start_deg)),
          sp.y + R * math.sin(math.radians(start_deg)))
    # 重设基准：让 start_vec / _last_mouse_angle 对应 p0
    s.start_vec = s._mouse_vec(p0[0], p0[1])
    s._last_mouse_angle = math.atan2(s.start_vec.y, s.start_vec.x)
    s._set_angle_raw(0.0)
    s.update(p0[0], p0[1])
    return s, sp, p0


try:
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me, transform_domain as xf

    # ---- 场景 ----
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    ob = bpy.context.view_layer.objects.active
    ob.name = "RA"
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 60
    for f, loc in ((1, (0.0, 0.0, 0.0)), (30, (4.0, 3.0, 1.0)), (60, (10.0, -2.0, 2.0))):
        sc.frame_set(f)
        ob.location = loc
        ob.keyframe_insert("location", frame=f)
    act = ob.animation_data.action
    for fc in xf._position_curves(act, ob, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - 30.0) < 1e-3:
                kp.select_control_point = True
    sc.frame_set(30)

    win = bpy.context.window
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d

    def turn(s, sp, R, th_deg, base_deg=0.0):
        """把鼠标绕支点转，返回 (angle_deg, mouse_screen)。"""
        th = math.radians(base_deg + th_deg)
        px = sp.x + R * math.cos(th)
        py = sp.y + R * math.sin(th)
        s.update(px, py)
        return math.degrees(s.angle), (px, py)

    # =====================================================================
    # A. ★★ 1:1 对等（任意 R）
    # =====================================================================
    for R in (150.0, 400.0, 800.0, 1500.0):
        s, sp, _ = make_session(me, ob, act, region, rv3d, R)
        for th in (5.0, 10.0, 30.0):
            got, _ = turn(s, sp, R, th)
            step("★A R=%4dpx 鼠标转 %4.1f° → 手柄转 %.4f°（应 1:1）" % (R, th, got),
                 abs(got - th) < 0.05, "差 %.5f°" % (got - th))

    # =====================================================================
    # B. ★ 倍率不随 R 变化（旧实现会线性放大 → 这条抓它）
    # =====================================================================
    ratios = []
    for R in (150.0, 400.0, 800.0, 1500.0):
        s, sp, _ = make_session(me, ob, act, region, rv3d, R)
        got, _ = turn(s, sp, R, 5.0)
        ratios.append(round(got / 5.0, 4))
    step("★★B 各 R 下倍率全为 1.0（旧实现 = R/150，会随 R 放大 5.33 倍）",
         all(abs(r - 1.0) < 1e-3 for r in ratios), "实测倍率=%s" % ratios)

    # =====================================================================
    # C. 跨 ±180° 不翻转（真实拖动是**连续小步**，逐步累加不会翻转）
    # =====================================================================
    s, sp, _ = make_session(me, ob, act, region, rv3d, 600.0)
    acc = 0.0
    for d in (50.0, 50.0, 50.0, 50.0):        # 0° → 50 → 100 → 150 → 200
        acc += d
        got, _ = turn(s, sp, 600.0, acc)
    step("★C 连续小步转到 200° → angle = 200°（不是 -160°；逐帧累加不会翻转）",
         abs(got - 200.0) < 0.2, "got %.4f" % got)

    # 已知限制：单帧跨越 ±180° 时，无法判定方向，按最短路径解释（取增量绝对值最小）
    s, sp, _ = make_session(me, ob, act, region, rv3d, 600.0)
    one, _ = turn(s, sp, 600.0, 200.0)        # 一步 0°→200°
    two, _ = turn(s, sp, 600.0, 200.0 - 360.0)  # 等价位置的另一侧
    step("★C[已知限制] **单帧**一步跨过 180° → 按最短路径解释为 -160°"
         "（鼠标单帧移动不会这么大；真实拖动走小步累加，见上一条）",
         abs(one - (-160.0)) < 0.2, "got %.4f（这是设计内行为，不是 bug）" % one)

    # =====================================================================
    # D. 多圈
    # =====================================================================
    s, sp, _ = make_session(me, ob, act, region, rv3d, 600.0)
    acc = 0.0
    for th in (90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0):
        got, _ = turn(s, sp, 600.0, (acc + th) % 360.0)
        acc += th
    step("D 连续转 720°（8×90°）→ angle ≈ 720°（可多圈）",
         abs(got - 720.0) < 0.5, "got %.4f" % got)

    # =====================================================================
    # E. 贴近支点不抖动
    # =====================================================================
    s, sp, _ = make_session(me, ob, act, region, rv3d, 400.0)
    before = math.degrees(s.angle)
    s.update(sp.x + 1.0, sp.y + 1.0)      # 距支点 ~1.4px < _MIN_LEVER_PX
    after = math.degrees(s.angle)
    ms = getattr(s, "mouse_screen", None)
    step("★E 鼠标贴到支点上（<%.0fpx）→ 角度不动（防 atan2 抖动）"
         % me._MIN_LEVER_PX,
         abs(after - before) < 1e-6,
         "before=%.5f after=%.5f" % (before, after))
    step("★E 但虚线端点仍更新到鼠标位置（线不卡住）",
         ms is not None and abs(ms[0] - (sp.x + 1.0)) < 1e-6,
         "mouse_screen=%s" % (ms,))

    # =====================================================================
    # F. 精度（Shift）× 1/30 + 不变式 angle = raw × k
    # =====================================================================
    s, sp, _ = make_session(me, ob, act, region, rv3d, 400.0)
    turn(s, sp, 400.0, 30.0)
    raw30 = s.angle_raw
    s.set_precision(True)
    step("★F Shift 后 angle = raw/30",
         abs(math.degrees(s.angle) - math.degrees(raw30) / 30.0) < 1e-6,
         "angle=%.5f° raw=%.5f°" % (math.degrees(s.angle), math.degrees(raw30)))
    step("★F 不变式 angle == raw × _prec_scale() 成立",
         abs(s.angle - s.angle_raw * s._prec_scale()) < 1e-12, "")
    s.set_precision(False)
    step("★F 关闭 Shift 后恢复 raw",
         abs(s.angle - raw30) < 1e-9, "angle=%.6f raw=%.6f" % (s.angle, raw30))

    # =====================================================================
    # G. 数字输入与角度同步
    # =====================================================================
    s, sp, _ = make_session(me, ob, act, region, rv3d, 400.0)
    turn(s, sp, 400.0, 40.0)
    s.apply_numeric(30.0)
    step("★G apply_numeric(30) → angle = -30°（原生：正值=顺时针）",
         abs(math.degrees(s.angle) + 30.0) < 1e-6, "%.6f°" % math.degrees(s.angle))
    step("★G apply_numeric 后不变式仍成立（raw 已同步，继续拖不会跳）",
         abs(s.angle - s.angle_raw * s._prec_scale()) < 1e-12,
         "angle=%.6f raw=%.6f" % (s.angle, s.angle_raw))
    got, _ = turn(s, sp, 400.0, 45.0)
    step("★G 接着继续拖 → 从 -30° 起算（+5° → -25°）",
         abs(got + 25.0) < 0.1, "got %.4f" % got)

    # =====================================================================
    # H. 虚线端点严格跟随鼠标
    # =====================================================================
    s, sp, _ = make_session(me, ob, act, region, rv3d, 400.0)
    mism = 0
    for th in (5.0, 17.0, 33.0, 61.0, 129.0):
        px = sp.x + 400.0 * math.cos(math.radians(th))
        py = sp.y + 400.0 * math.sin(math.radians(th))
        s.update(px, py)
        ms = s.mouse_screen
        if abs(ms[0] - px) > 1e-6 or abs(ms[1] - py) > 1e-6:
            mism += 1
    step("★★H 虚线端点 == 传入的鼠标坐标（逐点比对，5 个角度全 MATCH）",
         mism == 0, "不匹配 %d/5" % mism)

    # =====================================================================
    # I. 旧实现会怎样（反向探针：证明这条测试真能抓住旧口径）
    # =====================================================================
    def old_pixel_angle(R, th_deg, ref=me.REF_RADIUS):
        """旧口径：angle = 切向位移 / REF_RADIUS。R 越大越放大。"""
        th = math.radians(th_deg)
        return math.degrees(R * math.sin(th) / ref)

    e800 = old_pixel_angle(800.0, 5.0)
    step("★[probe] 旧口径在 R=800px 时会把 5° 放大成 ~26.6°（证明本测试的 1:1 断言有意义）",
         abs(e800 - 26.6) < 1.0, "旧口径算出 %.3f°" % e800)

except Exception:
    step("FATAL", False, traceback.format_exc()[-1500:])

flush()
print("ROTATE_ANGLE_CHECK_DONE")
os._exit(0)
