import bpy

# 翻译表说明
# ---------------------------------------------------------------------------
# 代码里所有界面字符串统一用「英文原文」，中文靠本表提供。
# 若日后修改了代码中的 name=/description=/bl_label= 等文字，
# 请同步更新下面对应的 key —— 否则中文界面会回退成英文原文。
#
# key 写法 ("*", "English") 表示无上下文（iface 层）翻译。
# ---------------------------------------------------------------------------

translations_dict = {
    "zh_HANS": {
        # --- Add-on Info ---
        ("*", "RealTimeMotionPath"): "实时运动路径",
        ("*", "Display and edit motion paths in real time in the 3D Viewport, with direct handle editing and Graph Editor sync"): "在 3D 视口中实时显示和编辑运动路径，支持直接手柄编辑和图形编辑器同步",

        # --- Operators ---
        ("*", "Auto Update Motion Paths"): "自动更新运动路径",
        ("*", "Real time update motion paths"): "实时更新运动路径",
        ("*", "Set Handle Type"): "设置手柄类型",
        ("*", "Toggle Direct Manipulation"): "切换直接操控模式",
        ("*", "Enable/Disable Motion Path Editing"): "启用/禁用运动路径编辑",
        ("*", "Enable Direct Path Editing"): "启用直接路径编辑",
        ("*", "Disable Direct Path Editing"): "已禁用直接路径编辑",
        ("*", "Direct Motion Path Manipulation"): "直接操控运动路径",
        ("*", "Move Motion Path Points"): "移动运动路径点",
        ("*", "Move Motion Path Handle"): "移动运动路径手柄",
        ("*", "Adjust Motion Path Speed"): "调整运动路径速度",
        # ★★ 2026-09-18 语义升级：双击速度三角 ⇒ 切换【一体 / 分离】
        #    （旧的四条"复制对侧值"文案已随之下线，见下方 git 历史）
        ("*", "Handles split - you can now adjust each side on its own"):
            "两个三角已分离，现在可以单独调整任意一侧",
        # ★★ 2026-09-18：双击「分离 → 锁回一体」的数据行为改为【对齐 GE 手柄】。
        #    共线（同一侧穿过）→ smooth；异号（人为拖歪）→ 镜像（对称尖峰）。
        ("*", "Handles locked together - GE handles aligned (smooth)"):
            "两个三角已锁定为一体，GE 手柄已共线（平滑过渡）",
        ("*", "Handles locked together - GE handles mirrored (symmetric peak)"):
            "两个三角已锁定为一体，GE 手柄已镜像（对称尖峰）",
        ("*", "Handles locked together (no opposite handle to match)"):
            "两个三角已锁定为一体（对侧无可同步的三角）",
        ("*", "Handles locked together (handle is flat, cannot align)"):
            "两个三角已锁定为一体（手柄是水平的，无法对齐）",
        ("*", "Handles locked together"): "两个三角已锁定为一体",
        ("*", "Lock Handles Together"): "锁定三角手柄为一体",
        ("*", "View3D not found, cannot run operator"): "未找到3D视图，无法运行操作",
        ("*", "Toggle Custom Path"): "切换自定义路径显示",
        ("*", "Enable/Disable Custom Motion Path Drawing"): "启用/禁用自定义运动路径绘制",
        ("*", "Enabled Motion Path, but no 3D View found for interaction."): "已启用运动路径，但未找到可交互的3D视图。",
        ("*", "Motion Path Context Menu"): "运动路径上下文菜单",

        # --- Properties & Settings ---
        ("*", "Motion Path Settings"): "运动路径设置",
        ("*", "Performance"): "性能",
        ("*", "Update Mode"): "更新模式",
        ("*", "Interaction FPS"): "交互帧率上限",
        ("*", "Auto Update FPS"): "自动更新频率",

        # Style Settings
        ("*", "Style Settings"): "样式设置",
        ("*", "Path Width"): "路径宽度",
        ("*", "Path Color"): "路径颜色",
        ("*", "Show Frame Points"): "显示帧点",
        ("*", "Frame Point Size"): "帧点大小",
        ("*", "Frame Point Color"): "帧点颜色",

        # Keyframes
        ("*", "Keyframes"): "关键帧",
        ("*", "Keyframe Size"): "关键帧大小",
        ("*", "Keyframe Color"): "关键帧颜色",
        ("*", "Selected Keyframe Color"): "选中关键帧颜色",

        # Handles
        ("*", "Handles"): "手柄",
        ("*", "Handle Line Width"): "手柄线宽",
        ("*", "Handle Line Color"): "手柄线颜色",
        ("*", "Selected Handle Line Color"): "选中的手柄线颜色",
        ("*", "Handle Endpoint Size"): "手柄端点大小",
        ("*", "Handle Endpoint Color"): "手柄端点颜色",
        ("*", "Selected Handle Endpoint Color"): "选中的手柄端点颜色",

        # Origin Indicator
        ("*", "Origin Indicator"): "原点指示器",
        ("*", "Show Origin Indicator"): "显示原点指示器",
        ("*", "Origin Style"): "原点样式",
        ("*", "Origin Size"): "原点大小",
        ("*", "Origin Color"): "原点颜色",
        ("*", "Origin Inner Color"): "原点内圈颜色",
        ("*", "Ring"): "圆环",
        ("*", "Hollow circle ring"): "空心圆环",
        ("*", "Dot"): "圆点",
        ("*", "Filled circle dot"): "实心圆点",
        ("*", "Ring+Dot"): "圆环+圆点",
        ("*", "Ring with center dot (like Blender origin)"): "带中心点的圆环（类似 Blender 原点）",

        # --- WindowManager Properties ---
        ("*", "Enable Motion Path"): "启用运动路径",
        ("*", "Enable custom motion path drawing"): "启用自定义运动路径绘制",
        ("*", "Direct Edit Active"): "直接编辑已激活",
        ("*", "Enable real-time direct editing of motion path control points"): "启用对运动路径控制点的实时直接编辑",
        ("*", "Auto Update Active"): "自动更新已激活",
        # ⚠️ 2026-09-17：`Max FPS Limit` 的词条已删除 —— 该属性名随
        #    性能设置迁到 AddonPreferences 而改名为 `Interaction FPS`
        #    （名字直接对齐已有的 "Interaction FPS" 词条），旧名成了僵尸词条。
        ("*", "Addon preferences unavailable"): "插件偏好设置不可用",
        ("*", "Limit the frame rate of interaction and redrawing to save power"): "限制交互与重绘的帧率以节省电量",
        ("*", "Choose how the motion path updates"): "选择运动路径的更新方式",
        ("*", "Smart (Event)"): "智能 (事件驱动)",
        ("*", "Update only when relevant data changes (Zero idle power)"): "仅在相关数据变化时更新 (零空闲功耗)",
        ("*", "Timer (Polling)"): "计时器 (轮询)",
        ("*", "Update periodically (Stable but higher power)"): "定期更新 (稳定但功耗较高)",
        ("*", "Frequency of checks in Timer mode (Hz)"): "计时器模式下的检查频率 (Hz)",

        ("*", "Keyframe Handle Type"): "关键帧手柄类型",
        ("*", "Handle type used when editing keyframes on the motion path"): "在运动路径上编辑关键帧时使用的手柄类型",
        ("*", "Free"): "自由 (Free)",
        ("*", "Handles can be adjusted independently"): "手柄可以独立调整",
        ("*", "Aligned"): "对齐 (Aligned)",
        ("*", "Handles are aligned to maintain smoothness"): "手柄对齐以保持平滑",
        ("*", "Vector"): "矢量 (Vector)",
        ("*", "Creates linear interpolation"): "创建线性插值",
        ("*", "Auto"): "自动 (Auto)",
        ("*", "Automatic smooth handles"): "自动平滑手柄",
        ("*", "Auto Clamped"): "自动钳位 (Auto Clamped)",
        ("*", "Automatic handles with clamped values"): "具有钳位值的自动手柄",

        # ★ 2026-09-17（方案 A）：右键菜单顶部的【体感手柄类型】只读标签
        ("*", "Feel: %s"): "体感: %s",
        ("*", "Feel: (mixed / original)"): "体感: (混合 / 原始类型)",

        ("*", "Snap to Grid"): "吸附到网格",
        ("*", "Snap handles to grid while dragging"): "拖拽时将手柄吸附到网格",
        ("*", "Snap Step"): "吸附步长",
        ("*", "Grid step size for handle snapping"): "手柄吸附的网格步长",
        ("*", "Handle Scale"): "手柄缩放",
        ("*", "Visual scale multiplier for handle display in viewport"): "视口中手柄显示的视觉缩放倍数",

        # --- Add-on Preferences ---
        ("*", "Restore Defaults"): "恢复默认值",
        ("*", "Reset to Default"): "重置为默认",
        ("*", "Reset all motion path settings to default values"): "将所有运动路径设置重置为默认值",

        # --- 手柄拖拽模式（2026-09-17 文案改写）---
        # ★ 命名原则：直接说出【它保住了什么 + 代价是什么】。
        #   拖手柄改的是手柄长度 |dv|，而时间跨度 dt 只有一个位置可站
        #   ⇒ 速度 与 三角疏密 数学上只能保住一个：
        #        速度 = |dv| ÷ dt   ；三角 s = dt ÷ span
        ("*", "Handle Drag Mode"): "拖动手柄 = 做什么",
        # 按钮名（短，popover 窄）
        ("*", "Change Speed"): "改速度",
        ("*", "Keep Speed"): "保速度",
        # ★ 按钮的【悬停说明】：只描述功能效果，一句话说清（不解释原因、不写"适合…"）
        ("*", "Drag changes the speed only; the speed distribution stays"):
            "拖手柄只改快慢；速度分布保持不变",
        ("*", "Drag changes the shape only; speed stays, the speed distribution follows"):
            "拖手柄只改形状；快慢不变，速度分布跟着变",
        ("*", "What a handle drag keeps: speed or speed distribution"):
            "拖手柄时保住哪个：快慢 或 速度分布",
        # ★ 盲审 S1（2026-09-18）：插件按整数帧建模，非整数帧关键帧会被合并掉。
        #   明确提示（原先完全静默）。
        ("*", "Subframe keyframes are not supported"):
            "不支持非整数帧的关键帧（已被合并）：",

        # ★ 盲审 R7（2026-09-18）：i18n 自测原先只扫 4 个文件 ⇒ 这两条
        #   `modal_edit.py` 里的 bl_label **从未被发现漏翻**。
        #   （改扫全目录后暴露出来。）
        ("*", "RTMP Modal Edit"): "运动路径 · 模态编辑",
        ("*", "RTMP Keyboard Transform"): "运动路径 · 键盘变换",

        # --- 调试日志（2026-09-17）---
        ("*", "Debug"): "调试",
        ("*", "Debug Log"): "调试日志",
        ("*", "Open Debug Log"): "打开调试日志",
        ("*", "Clear Debug Log"): "清空调试日志",
        ("*", "Log:"): "日志：",
        ("*", "Open"): "打开",
        ("*", "Clear"): "清空",
        ("*", "打开调试日志所在的文件夹"): "打开调试日志所在的文件夹",
        ("*", "清空调试日志文件"): "清空调试日志文件",
        ("*", "把交互过程写入 JSONL 日志，便于排查交互问题"): "把交互过程写入 JSONL 日志，便于排查交互问题",
        ("*", "debug_log unavailable"): "调试日志不可用",
    }
}


def register(module_name):
    # Try to unregister first to avoid "cache already contains some data" warning on reload
    try:
        bpy.app.translations.unregister(module_name)
    except Exception:
        pass

    try:
        bpy.app.translations.register(module_name, translations_dict)
    except Exception as e:
        print(f"Warning: Could not register translations for {module_name}: {e}")


def unregister(module_name):
    try:
        bpy.app.translations.unregister(module_name)
    except Exception:
        pass
