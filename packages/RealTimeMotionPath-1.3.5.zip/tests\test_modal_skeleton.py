# -*- coding: utf-8 -*-
"""modal_edit 骨架冒烟测试（headless 能测的部分）

GUI 交互（真鼠标拖拽）测不了，这里只验证：
  1. 模块能在【包上下文】里导入（相对导入生效）
  2. operator 能注册 / 注销
  3. keymap 注册函数不崩
  4. 无 3D 视图 context 时，目标解析优雅返回 None（不抛异常）
  5. keyframe_world_pos 数值正确（与 fcurve 关键帧一致）
"""
import sys, os, json, types, importlib

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)

# 手工构造包上下文（避免执行 __init__.py 的副作用）
PKG = os.path.basename(ADDON_DIR)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    pkg = types.ModuleType(PKG)
    pkg.__path__ = [ADDON_DIR]
    pkg.__package__ = PKG
    sys.modules[PKG] = pkg

import bpy
import mathutils

results = []
def check(name, ok, detail=""):
    results.append(("PASS" if ok else "FAIL", name, str(detail)))
def note(name, detail=""):
    results.append(("NOTE", name, str(detail)))

# ---- 1. import ----
td = me = None
try:
    td = importlib.import_module(PKG + ".time_domain")
    check("import time_domain", True, "ok")
except Exception as e:
    check("import time_domain", False, repr(e))
try:
    me = importlib.import_module(PKG + ".modal_edit")
    check("import modal_edit", True, "size=%d" % len(open(os.path.join(ADDON_DIR, "modal_edit.py"), encoding="utf-8").read()))
except Exception as e:
    check("import modal_edit", False, repr(e))

if me is None:
    json.dump({"rows": results}, open(os.path.join(HERE, "_me_result.json"), "w", encoding="utf-8"))
    print("WROTE"); raise SystemExit

# ---- 2. 常量 / 结构 ----
check("MODE_ITEMS has 4 modes", len(me.MODE_ITEMS) == 4,
      [m[0] for m in me.MODE_ITEMS])
check("DEFAULT_ENTRY_KEY == J", me.DEFAULT_ENTRY_KEY == 'J', me.DEFAULT_ENTRY_KEY)
check("SIDE_BELOW == right", me.SIDE_BELOW == 'right')
check("bl_idname", me.RTMP_OT_ModalEdit.bl_idname == "rtmp.modal_edit",
      me.RTMP_OT_ModalEdit.bl_idname)
check("has modal()", hasattr(me.RTMP_OT_ModalEdit, "modal"))
check("has invoke()", hasattr(me.RTMP_OT_ModalEdit, "invoke"))

# ---- 3. 注册 / 注销 ----
reg_ok = unreg_ok = False
try:
    bpy.utils.register_class(me.RTMP_OT_ModalEdit)
    reg_ok = True
except Exception as e:
    check("register_class", False, repr(e))
check("register_class", reg_ok)

# ---- 4. 场地 ----
def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = "TestObj"
    for f, loc in [(1, (0, 0, 0)), (14, (4, 3, 0)), (27, (8, -2, 0)), (40, (12, 1, 0))]:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    return o, o.animation_data.action

o, act = build()

# ---- 5. keyframe_world_pos ----
wp = me.keyframe_world_pos(act, o, 14)
check("keyframe_world_pos(f14)", wp is not None and
      abs(wp.x - 4) < 1e-6 and abs(wp.y - 3) < 1e-6 and abs(wp.z) < 1e-6,
      tuple(round(c, 4) for c in wp) if wp else None)

wp2 = me.keyframe_world_pos(act, o, 27)
check("keyframe_world_pos(f27)", wp2 is not None and
      abs(wp2.x - 8) < 1e-6 and abs(wp2.y + 2) < 1e-6,
      tuple(round(c, 4) for c in wp2) if wp2 else None)

# 父级变换测试：有 parent 时，世界位置应含 parent 的位移
bpy.ops.object.empty_add(location=(10, 0, 0))
par = bpy.context.active_object
par.name = "ParentEmpty"
o.parent = par
# 不设 matrix_parent_inverse（保持 Identity），这样 world = parent_world @ local
wp3 = me.keyframe_world_pos(act, o, 14)
check("keyframe_world_pos applies PARENT transform", wp3 is not None and
      abs(wp3.x - 14) < 1e-6 and abs(wp3.y - 3) < 1e-6,
      tuple(round(c, 4) for c in wp3) if wp3 else None)

# ⚠️ 反例（bug 注入自检）：绝不能用 matrix_world —— 它含自身 location
o.parent = None
o.location = (99, 99, 0)
wp_bad = me.keyframe_world_pos(act, o, 14)
check("does NOT re-apply own location (matrix_world trap)", wp_bad is not None and
      abs(wp_bad.x - 4) < 1e-6 and abs(wp_bad.y - 3) < 1e-6,
      "got " + str(tuple(round(c, 4) for c in wp_bad) if wp_bad else None)
      + " (should be (4,3,0) regardless of o.location)")

# ---- 6. _keyframes_of ----
kfs = me._keyframes_of(act, o)
check("_keyframes_of returns 4 frames", kfs == [1.0, 14.0, 27.0, 40.0], kfs)

# ---- 7. resolve_speed_target 无 region 时优雅返回 ----
class FakeCtx:
    region = None
    region_data = None
try:
    r = me.resolve_speed_target(FakeCtx(), o, act, 100, 100)
    check("resolve_speed_target(None region) -> None", r is None, r)
except Exception as e:
    check("resolve_speed_target(None region) -> None", False, "raised " + repr(e))

# ---- 8. keymap 注册不崩 ----
try:
    got = me.register_keymaps()
    check("register_keymaps() runs", True, "returned %s (background: addon keyconfig may be None)" % got)
    note("keymap in background", "OK=%s（headless 下 keymap_items 不加载，真实绑定需 GUI 验证）" % got)
    me.unregister_keymaps()
    check("unregister_keymaps() runs", True)
except Exception as e:
    check("register_keymaps() runs", False, "raised " + repr(e))

# ---- 9. 模式未实现时的提示 ----
note("unimplemented modes", "MOVE/ROTATE/SCALE 会返回 CANCELLED + warning（骨架已留位）")

# ---- 输出 ----
try:
    bpy.utils.unregister_class(me.RTMP_OT_ModalEdit)
    unreg_ok = True
except Exception as e:
    check("unregister_class", False, repr(e))
check("unregister_class", unreg_ok)

fails = [r for r in results if r[0] == "FAIL"]
summary = {
    "total": len([r for r in results if r[0] != "NOTE"]),
    "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in results],
}
json.dump(summary, open(os.path.join(HERE, "_me_result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("WROTE_ME_JSON")
