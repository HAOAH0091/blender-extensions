# -*- coding: utf-8 -*-
"""第四轮反馈专项验收（2026-09-16）

用户反馈：
  #1 R/S 能进模态但没实际效果
  #2 收缩采样点(变密)会影响路径形态，拉伸(变疏)不会
  #3 拉下方三角时左边路径会变形

本测试逐条钉死：
  A. 形状不变：编辑右段/左段时，两侧【值分量】都不得变化（= 3D 形状不变）
  B. 时间不折返：dt ≤ 段长，f(t) 单调
  C. R/S 手感：切向/径向位移 → 角度/倍数，与支点距离无关；方向不反
  D. 联动：速度编辑后，3D 视图拖手柄仍然联动
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_r4_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

FIELDS = ("co_v", "hl_t", "hl_v", "hr_t", "hr_v")

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 3.0, 0.0)),
           (27, (8.0, -2.0, 1.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath.state import _session

    fcs = xf._position_curves(act, obj, None)

    def reset(htype='AUTO_CLAMPED'):
        td.clear_frozen()
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype; kp.handle_right_type = htype
            fc.update()
        for f, loc in KFS:
            for fc in fcs:
                for kp in fc.keyframe_points:
                    if abs(kp.co[0]-f) < 0.5:
                        kp.co = (kp.co[0], loc[fc.array_index])
            for fc in fcs: fc.update()

    def snap():
        d = {}
        for fc in fcs:
            for kp in fc.keyframe_points:
                d[(round(float(kp.co[0]),3), fc.array_index)] = (
                    float(kp.co[1]),
                    float(kp.handle_left[0]-kp.co[0]), float(kp.handle_left[1]-kp.co[1]),
                    float(kp.handle_right[0]-kp.co[0]), float(kp.handle_right[1]-kp.co[1]))
        return d

    def shape_delta(a, b):
        m = 0.0; where = None
        for k in a:
            for i, fn in enumerate(FIELDS):
                if fn not in ("co_v", "hl_v", "hr_v"): continue
                dd = abs(b[k][i] - a[k][i])
                if dd > m: m, where = dd, (k, fn)
        return m, where

    # =====================================================
    # A. ★ 形状不变（#2 #3 的核心）
    # =====================================================
    for label, s_val in [("变疏 s=0.15", 0.15), ("匀速 s=1/3", 1.0/3.0),
                         ("变密 s=0.60", 0.60), ("变密 s=1.0（上限）", 1.0)]:
        reset()
        a = snap()
        kf_map, span = td.resolve_target(act, obj, 14.0, 'right')
        td.write_s(kf_map, 'right', s_val, span, act=act, obj=obj)
        for fc in fcs: fc.update()
        d, where = shape_delta(a, snap())
        step("★ A: 编辑【右段】%s → 形状零变化" % label, d < 1e-6,
             "Δ=%.9f%s" % (d, ("  (%s)" % (where,)) if where else ""))

    for label, s_val in [("变疏 s=0.15", 0.15), ("变密 s=0.60", 0.60)]:
        reset()
        a = snap()
        kf_map, span = td.resolve_target(act, obj, 14.0, 'left')
        td.write_s(kf_map, 'left', s_val, span, act=act, obj=obj)
        for fc in fcs: fc.update()
        d, where = shape_delta(a, snap())
        step("★ A: 编辑【左段】%s → 形状零变化" % label, d < 1e-6,
             "Δ=%.9f%s" % (d, ("  (%s)" % (where,)) if where else ""))

    # 只有目标关键帧的时间分量应变化
    reset()
    a = snap()
    kf_map, span = td.resolve_target(act, obj, 14.0, 'right')
    td.write_s(kf_map, 'right', 0.15, span, act=act, obj=obj)
    for fc in fcs: fc.update()
    b = snap()
    changed = [(k, FIELDS[i]) for k in a for i in range(5) if abs(b[k][i]-a[k][i]) > 1e-6]
    only_target_time = all(k[0] == 14.0 and f == 'hr_t' for k, f in changed)
    step("★ A: 只有目标关键帧的 hr_t 被改", only_target_time, changed[:6])

    # =====================================================
    # B. ★ 时间不折返
    # =====================================================
    def fold_count(f0=14, f1=27, n=400):
        for fc in fcs:
            if fc.array_index != 0: continue
            pts = list(fc.keyframe_points)
            for i in range(len(pts)-1):
                A, B = pts[i], pts[i+1]
                if abs(A.co[0]-f0) > 0.5: continue
                t0, t1 = float(A.co[0]), float(B.co[0])
                c1 = t0 + float(A.handle_right[0]-A.co[0])
                c2 = t1 + float(B.handle_left[0]-B.co[0])
                v = []
                for k in range(n+1):
                    t = k/n; mt = 1-t
                    v.append((mt**3)*t0 + 3*(mt**2)*t*c1 + 3*mt*(t**2)*c2 + (t**3)*t1)
                return sum(1 for j in range(1, len(v)) if v[j] < v[j-1] - 1e-9)
        return None

    reset()
    step("B baseline: 原始曲线 f(t) 单调", fold_count() == 0, fold_count())
    for s_val in (0.60, 1.0, 1.36, 2.0):
        reset()
        kf_map, span = td.resolve_target(act, obj, 14.0, 'right')
        w = td.write_s(kf_map, 'right', s_val, span, act=act, obj=obj)
        for fc in fcs: fc.update()
        fc_ = fold_count()
        step("★ B: s=%.2f (写入后 %.4f) → f(t) 无折返" % (s_val, w or 0),
             fc_ == 0 and (w or 0) <= 1.0 + 1e-9,
             "折返=%s written=%.4f" % (fc_, w or -1))

    # =====================================================
    # C. ★ R/S 手感
    # =====================================================
    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0)); rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))   # 顶视：轴 = 世界 Z
    bpy.context.view_layer.update()

    def sel(frames):
        want = [float(f) for f in frames]
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.select_control_point = any(abs(kp.co[0]-f) < 0.5 for f in want)
            fc.update()

    def pose(f):
        v = [0.0, 0.0, 0.0]
        for fc in fcs:
            for kp in fc.keyframe_points:
                if abs(kp.co[0]-f) < 0.5: v[fc.array_index] = kp.co[1]
        return mathutils.Vector(v)

    # C1: ★ 1:1 对等（2026-09-16 改口径）
    #
    #   ⚠️ 旧口径是「切向位移 ÷ REF_RADIUS」：与支点距离无关，
    #      但**角度会随 R 线性放大**（实测 R=800px 时鼠标转 5° → 手柄转 26.6°）。
    #      用户反馈「光标只转 5°，手柄却转更多，虚线也没紧跟」→ 改为角度式。
    #      ⇒ 断言也要跟着变：不再断言"距离无关"，而是断言 **1:1**。
    #
    #   ⚠️ 起点与终点必须用【同一个支点投影】换算，否则测的是"支点不一致"而非手感
    def rot_effect(radius, turn_deg):
        """让鼠标**绕支点转 turn_deg 度**，返回手柄实际转角。"""
        reset(); sel([1, 14])
        s = me.RotateSession('ROTATE')
        s.begin(obj, act, region, rv3d, 600.0, 400.0)
        sp = me._screen_pos(region, rv3d, s.pivot_world)
        # 基准：鼠标在支点正右方 radius 处（屏幕 y 向上 → 逆时针为正）
        s.start_vec = mathutils.Vector((float(radius), 0.0))
        s._last_mouse_angle = 0.0
        s._set_angle_raw(0.0)
        s.update(sp.x + radius, sp.y)
        th = math.radians(turn_deg)
        s.update(sp.x + radius * math.cos(th), sp.y + radius * math.sin(th))
        return math.degrees(s.angle)

    near = rot_effect(100.0, 45.0)
    far = rot_effect(1000.0, 45.0)
    step("★★ C: 旋转 **1:1** —— 鼠标绕支点转 45°，支点近/远手柄都转 45°",
         abs(near - 45.0) < 1e-6 and abs(far - 45.0) < 1e-6,
         "近=%.4f° 远=%.4f° 期望=45°" % (near, far))
    step("★ C: 逆时针拖 = 正角度（方向不反）", near > 0, "%.3f°" % near)

    # C1b: 记录【取舍】—— 角度式下"同样的鼠标像素位移"在支点远时转得少
    #      （几何必然，原生 Blender 亦然）。这是为"1:1 对等"付出的代价。
    def rot_effect_px(radius, tangential_px):
        reset(); sel([1, 14])
        s = me.RotateSession('ROTATE')
        s.begin(obj, act, region, rv3d, 600.0, 400.0)
        sp = me._screen_pos(region, rv3d, s.pivot_world)
        s.start_vec = mathutils.Vector((float(radius), 0.0))
        s._last_mouse_angle = 0.0
        s._set_angle_raw(0.0)
        s.update(sp.x + radius, sp.y)
        s.update(sp.x + radius, sp.y + tangential_px)
        return math.degrees(s.angle)

    d_near = rot_effect_px(100.0, 100.0)     # atan2(100, 100)   = 45°
    d_far = rot_effect_px(1000.0, 100.0)     # atan2(100, 1000)  ≈ 5.71°
    step("★ C[取舍记录] 同样向上移 100px：支点近转 %.2f°、支点远转 %.2f°"
         "（角度式固有性质，与原生一致；想省力把鼠标拖近支点）" % (d_near, d_far),
         abs(d_near - 45.0) < 0.1 and abs(d_far - 5.71) < 0.1,
         "近=%.3f° 远=%.3f°" % (d_near, d_far))

    # C2: 方向正确性 —— 90° 逆时针应把 (4,0,0) 转到 (0,4,0) 方向
    reset(); sel([1, 14])
    s = me.RotateSession('ROTATE')
    s.begin(obj, act, region, rv3d, 600.0, 400.0)
    piv = s.pivot_world
    b14 = pose(14.0)
    s.apply_numeric(90.0)
    a14 = pose(14.0)
    v0 = (b14 - piv).normalized(); v1 = (a14 - piv).normalized()
    cross = v0.cross(v1)
    # ⚠️ 2026-09-16：R 数字输入按原生约定"正值为顺时针" → 屏幕上 cross.z < 0
    step("★ C: 旋转 90° 的实际转向 = 顺时针（原生约定）",
         cross.z < 0, "cross.z=%.4f" % cross.z)

    # C3: 缩放 —— 距离无关 + 方向正确
    def scl_effect(radius, radial_px):
        reset(); sel([1, 14])
        s = me.ScaleSession('SCALE')
        s.begin(obj, act, region, rv3d, 600.0, 400.0)
        sp = me._screen_pos(region, rv3d, s.pivot_world)
        s.start_vec = mathutils.Vector((float(radius), 0.0))
        s.update(sp.x + radius + radial_px, sp.y)
        return s.factor

    fn = scl_effect(100.0, 150.0)      # 向外 150px
    ff = scl_effect(1000.0, 150.0)     # 同样 150px，支点远 10 倍
    step("★ C: 缩放手感与支点距离无关",
         abs(fn - ff) < 1e-9 and abs(fn - 2.0) < 1e-6,
         "近=%.4f 远=%.4f 期望=2.0000" % (fn, ff))
    f_in = scl_effect(1000.0, -75.0)   # 向内 75px
    step("★ C: 向内拖 = 缩小", abs(f_in - 0.5) < 1e-6, "%.4f" % f_in)

    # =====================================================
    # D. ★ 联动：速度编辑后拖手柄仍联动
    # =====================================================
    reset()
    kf_map, span = td.resolve_target(act, obj, 14.0, 'right')
    td.write_s(kf_map, 'right', 0.15, span, act=act, obj=obj)
    for fc in fcs: fc.update()
    t14 = [(i, kp.handle_left_type, kp.handle_right_type)
           for i, kp in ((fc.array_index, kp) for fc in fcs for kp in fc.keyframe_points
                         if abs(kp.co[0]-14) < 0.5)]
    step("★ D: 编辑后两侧都是 FREE", all(a == 'FREE' and b == 'FREE' for _, a, b in t14), t14)
    step("★ D: 关键帧已登记（联动会继续生效）", td.is_frozen(act, 14.0), td.is_frozen(act, 14.0))

    class FakeOp:
        pass
    fo = FakeOp()
    linked = False; detail = ""
    for i, kp in ((fc.array_index, kp) for fc in fcs for kp in fc.keyframe_points
                  if abs(kp.co[0]-14) < 0.5):
        bl = tuple(kp.handle_left)
        vec = mathutils.Vector((0.0, 0.0, 0.0)); vec[i] = 1.0
        inter.RTMP_OT_PathPointDrag.update_linked_handle(fo, kp, 'right', vec, i)
        linked = tuple(kp.handle_left) != bl
        detail = "轴%d 左手柄 %s -> %s" % (i, round(bl[1],4), round(kp.handle_left[1],4))
        break
    step("★ D: 速度编辑后【拖手柄仍联动】（不再因两侧 FREE 而早退）", linked, detail)

    # 反向探针：未登记的关键帧，两侧 FREE 时不应联动
    reset('FREE')
    probe = False
    for i, kp in ((fc.array_index, kp) for fc in fcs for kp in fc.keyframe_points
                  if abs(kp.co[0]-14) < 0.5):
        bl = tuple(kp.handle_left)
        vec = mathutils.Vector((0.0, 0.0, 0.0)); vec[i] = 1.0
        inter.RTMP_OT_PathPointDrag.update_linked_handle(fo, kp, 'right', vec, i)
        probe = tuple(kp.handle_left) != bl
        break
    step("[probe] 未登记的 FREE 关键帧 → 联动按 Blender 原生语义不生效",
         probe is False, probe)

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("ROUND4_CHECK_DONE")
os._exit(0)
