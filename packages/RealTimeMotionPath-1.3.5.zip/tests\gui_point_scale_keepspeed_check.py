# -*- coding: utf-8 -*-
"""选中关键帧点后按 S 缩放 —— 【保速】回归。

用户拍板语义（2026-09-17）
--------------------------
    "改关键帧点选中时用 S 进行缩放可以保速度不变"

即：**单点 S 缩放后，该关键帧处的路径速度不变**（手柄变长/变短、速度恒定）。

为什么原来不保速
----------------
    速度 = |dv / dt|

插件原来只缩**值分量** dv、**时间分量** dt 不动 ⇒ 速度 ×factor。
（实测 k=1.5：0.170833 → 0.25625）

修法：单点缩放时让 **dt 也 ×factor** ⇒ dv 与 dt 同比例 ⇒ 速度不变
（= 在「值-时间」平面上等比缩放，曲线形状相似 ⇒ 各关键帧处速度恒定）。

三条边界（都有 ⚠️ 实测/推理依据）
--------------------------------
 ① **多点缩放不缩 dt** —— 支点是中位点、各点位移不同，"保速"无统一语义。
 ② **轴锁定不缩 dt** —— 各轴手柄的时间分量彼此独立；只缩某轴的值分量时，
    把时间分量也缩会牵连**未参与缩放的轴**的速度。
 ③ **端点模式不走这条通路**（走 apply_endpoint_transform），不受影响。

钉住的坑
--------
 1. **时间分量必须从 snapshot 读，不能从 kp 读** —— 模态里鼠标每动一次就
    `_apply()` 一次；从 kp（当前值）读会**累乘**（k^n），dt 越拖越大。
 2. **判据用"选中点数 == 1"** —— 单点时支点就是该点自己（co 不动）。
 3. `snapshot_positions` 里早已存了 `hl_t` / `hr_t`（时间分量），不必新增存储。
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, modal_edit as me

OUT = os.path.join(HERE, "_point_scale_result.json")
steps = []

# 1 / 25 / 55 —— 中间帧两侧 dt 不同（8 / 10），能验出"左右都缩"
KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))
MID = 25.0
TOL = 1e-6


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


def build(name):
    """建 3 关键帧对象，全 FREE（排除 AUTO_CLAMPED 重算干扰 ⇒ 控制变量）。"""
    sc = bpy.context.scene
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in KFS:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(int(KFS[0][0]))
    a = o.animation_data.action
    for c in xf._position_curves(a, o, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        c.update()
    return o, a


def curves(o):
    return {c.array_index: c for c in
            xf._position_curves(o.animation_data.action, o, None)}


def kf(o, frame, axis):
    for k in curves(o)[axis].keyframe_points:
        if abs(k.co[0] - frame) < 1e-3:
            return k


def speeds(o, frame=MID):
    """返回 {'left': 速度, 'right': 速度, 'left_axes': [每轴 dv/dt], ...}。

    ★ 速度 = |dv/dt|，**逐轴算再三维合成**（每轴 F-Curve 的手柄各有自己的时间分量）。
    """
    res = {}
    for side in ('left', 'right'):
        per_axis = []
        for ax in (0, 1, 2):
            k = kf(o, frame, ax)
            h = k.handle_right if side == 'right' else k.handle_left
            dv = float(h[1]) - float(k.co[1])
            dt = (float(h[0]) - float(k.co[0])) if side == 'right' \
                else (float(k.co[0]) - float(h[0]))
            per_axis.append(dv / dt if abs(dt) > 1e-9 else 0.0)
        res[side] = math.sqrt(sum(v * v for v in per_axis))
        res[side + "_axes"] = per_axis
    return res


def dts(o, frame=MID):
    k = kf(o, frame, 0)
    return (round(float(k.co[0] - k.handle_left[0]), 4),
            round(float(k.handle_right[0] - k.co[0]), 4))


def mk_session(o, a, frames, factor, plane_lock=None, axis_lock=None,
               only_handles=False):
    """构造真实 ScaleSession（走真实 _apply 通路，不复制逻辑）。"""
    s = me.ScaleSession('SCALE')
    s.act = a
    s.obj = o
    s.bone_name = None
    s.snapshot = xf.snapshot_positions(
        a, o, {f: {c.array_index: c for c in xf._position_curves(a, o, None)}
               for f in frames})
    s.factor = factor
    s.plane_lock = plane_lock
    s.axis_lock = axis_lock
    s.only_handles = only_handles
    s.endpoints = None
    first = sorted(frames)[0]
    s.pivot_local = mathutils.Vector([float(kf(o, first, ax).co[1])
                                      for ax in (0, 1, 2)])
    return s


# ================================================================ 正例
try:
    # ---------- A1/A2/A3：单点缩放保速 ----------
    o, a = build("_PS1")
    s0 = speeds(o)
    d0 = dts(o)
    sess = mk_session(o, a, [MID], 1.5)
    sess._apply()
    s1 = speeds(o)
    d1 = dts(o)

    step("A1 ★★★ 单点 S 缩放 k=1.5：速度【不变】",
         abs(s1["left"] - s0["left"]) < TOL and abs(s1["right"] - s0["right"]) < TOL,
         "左 %.6f→%.6f  右 %.6f→%.6f" % (s0["left"], s1["left"],
                                         s0["right"], s1["right"]))
    step("A2 ★★ 单点缩放：dt 也 ×factor（形状相似）",
         abs(d1[0] - d0[0] * 1.5) < TOL and abs(d1[1] - d0[1] * 1.5) < TOL,
         "dt %s → %s（期望 %s）" % (d0, d1, (round(d0[0] * 1.5, 4), round(d0[1] * 1.5, 4))))
    step("A3 ★ 逐轴速度都不变（不只是合成值）",
         all(abs(s1["left_axes"][i] - s0["left_axes"][i]) < TOL for i in range(3)),
         "左逐轴 %s → %s" % ([round(v, 6) for v in s0["left_axes"]],
                             [round(v, 6) for v in s1["left_axes"]]))

    # ---------- A4：模态里反复 _apply 不累乘 ----------
    for _ in range(4):
        sess._apply()
    s4 = speeds(o)
    d4 = dts(o)
    step("A4 ★★★ 反复 _apply 不累乘（时间分量从 snapshot 读）",
         abs(s4["left"] - s0["left"]) < TOL and d4 == (round(d0[0] * 1.5, 4),
                                                       round(d0[1] * 1.5, 4)),
         "5 次后 速度=%.6f dt=%s（若累乘会是 k^5）" % (s4["left"], d4))

    # ---------- A5：数字输入 / reset ----------
    sess.apply_numeric(2.0)
    sN = speeds(o)
    dN = dts(o)
    step("A5 数字输入 2.0×：保速 + dt ×2",
         abs(sN["left"] - s0["left"]) < TOL and abs(dN[0] - d0[0] * 2.0) < TOL,
         "速度=%.6f dt=%s" % (sN["left"], dN))
    sess.reset_numeric()
    sR = speeds(o)
    step("A6 reset（1.0×）：速度与 dt 都回到原始",
         abs(sR["left"] - s0["left"]) < TOL and dts(o) == d0,
         "速度=%.6f dt=%s" % (sR["left"], dts(o)))

    # ---------- A7：缩小（k<1）也保速 ----------
    sess2 = mk_session(o, a, [MID], 0.5)
    sess2._apply()
    sH = speeds(o)
    step("A7 缩小 k=0.5：也保速",
         abs(sH["left"] - s0["left"]) < TOL,
         "速度=%.6f dt=%s" % (sH["left"], dts(o)))

    # ---------- A8：多点缩放保持历史行为（dt 不变）----------
    o2, a2 = build("_PS2")
    d2_before = dts(o2)
    v2_before = speeds(o2)
    sess3 = mk_session(o2, a2, [1.0, MID], 1.5)
    sess3._apply()
    step("A8 ★★ 多点缩放：dt 不变（保速无统一语义，保持历史行为）",
         dts(o2) == d2_before and abs(speeds(o2)["left"] - v2_before["left"]) > 1e-6,
         "dt %s→%s（应不变）速度 %.6f→%.6f（会变，符合预期）"
         % (d2_before, dts(o2), v2_before["left"], speeds(o2)["left"]))

    # ---------- A9：轴锁定不缩 dt ----------
    o3, a3 = build("_PS3")
    d3_before = dts(o3)
    sess4 = mk_session(o3, a3, [MID], 1.5, axis_lock='X')
    sess4._apply()
    step("A9 ★ 轴锁定（X）：dt 不变（不牵连未参与轴的速度）",
         dts(o3) == d3_before and sess4._axis_mask() != (1.0, 1.0, 1.0),
         "mask=%s dt %s→%s" % (sess4._axis_mask(), d3_before, dts(o3)))

    # ---------- A10：静态契约 ----------
    import inspect as _inspect
    _sig = _inspect.signature(xf.apply_point_transform).parameters
    step("A10 静态契约：apply_point_transform 有 time_scale 参数",
         "time_scale" in _sig, "参数=%s" % (list(_sig.keys()),))
    _sig2 = _inspect.signature(me._apply_xf).parameters
    step("A11 静态契约：_apply_xf 透传 time_scale",
         "time_scale" in _sig2, "参数=%s" % (list(_sig2.keys()),))

    # ---------- A12：time_scale=None ⇒ 历史行为不变 ----------
    o4, a4 = build("_PS4")
    d4_before = dts(o4)
    v4_before = speeds(o4)
    xf.apply_point_transform(a4, o4, xf.snapshot_positions(
        a4, o4, {MID: {c.array_index: c for c in xf._position_curves(a4, o4, None)}}),
        xf.scale_fn(mathutils.Vector([float(kf(o4, MID, ax).co[1])
                                      for ax in (0, 1, 2)]), 1.5), None)
    step("A12 time_scale 缺省 None ⇒ dt 不动（历史行为）",
         dts(o4) == d4_before and abs(speeds(o4)["left"] - v4_before["left"]) > 1e-6,
         "dt %s→%s" % (d4_before, dts(o4)))

    # ---------- A13：数据完好（值分量确实被缩了）----------
    o5, a5 = build("_PS5")
    co_before = [float(kf(o5, MID, ax).co[1]) for ax in (0, 1, 2)]
    hl_before = [float(kf(o5, MID, ax).handle_left[1]) for ax in (0, 1, 2)]
    sess5 = mk_session(o5, a5, [MID], 1.5)
    sess5._apply()
    co_after = [float(kf(o5, MID, ax).co[1]) for ax in (0, 1, 2)]
    hl_after = [float(kf(o5, MID, ax).handle_left[1]) for ax in (0, 1, 2)]
    step("A13 支点 co 不动（单点缩放支点就是自己）",
         max(abs(co_after[i] - co_before[i]) for i in range(3)) < TOL,
         "co %s → %s" % ([round(v, 4) for v in co_before], [round(v, 4) for v in co_after]))
    step("A14 手柄值分量确实 ×1.5（缩放生效，不是没动）",
         all(abs(hl_after[i] - co_after[i] - (hl_before[i] - co_before[i]) * 1.5) < 1e-5
             for i in range(3)),
         "dv %s → %s" % ([round(hl_before[i] - co_before[i], 4) for i in range(3)],
                         [round(hl_after[i] - co_after[i], 4) for i in range(3)]))

    # ---------- A15：曲线健全性（既不折返、也不爆值）----------
    #  ⚠️ 这里【不能】断言"形状相似" —— 本测试首版就是这么写的，实测 FAIL：
    #      该操作只动【一个点的手柄】，关键帧的**时间坐标不动** ⇒
    #      曲线的整体形状**确实会变**（值被拉伸的同时，手柄的时间跨度也变大）。
    #      "保速"指的是**关键帧处的切线斜率**不变（= A1/A3），不是"形状相似"。
    o6, a6 = build("_PS6")

    def samp():
        cc = {c.array_index: c for c in xf._position_curves(a6, o6, None)}
        return [[float(cc[ax].evaluate(1.0 + 54.0 * i / 40.0)) for ax in (0, 1, 2)]
                for i in range(41)]

    before6 = samp()
    mk_session(o6, a6, [MID], 1.5)._apply()
    after6 = samp()
    finite_ok = all(math.isfinite(v) for row in after6 for v in row)
    # 单调性保持：原来在某轴单调增/减的，缩放后仍单调（不引入折返）
    def mono(rows, k):
        d = [rows[i + 1][k] - rows[i][k] for i in range(len(rows) - 1)]
        nz = [x for x in d if abs(x) > 1e-9]
        return (not nz) or all(x > 0 for x in nz) or all(x < 0 for x in nz)

    mono_ok = all(mono(before6, k) == mono(after6, k) for k in range(3))
    step("A15 缩放后曲线健全：采样有限 + 不引入折返",
         finite_ok and mono_ok,
         "有限=%s 单调性保持=%s" % (finite_ok, mono_ok))

    # ---------- A16：把"形状会变"这个事实钉住（防后人误解）----------
    # （A16 在下面）
    mid6 = [float(kf(o6, MID, ax).co[1]) for ax in (0, 1, 2)]
    idx_mid = 40 * 24 // 54
    idx_pick = max(0, idx_mid - 4)
    r_before = [before6[idx_pick][k] - before6[idx_mid][k] for k in range(3)]
    r_after = [after6[idx_pick][k] - after6[idx_mid][k] for k in range(3)]
    # 关键帧自身 co 不变（支点），但同一时间点上曲线的值确实变了
    step("A16 记录语义：形状确实改变（不是'形状相似'）",
         any(abs(r_after[k] - r_before[k]) > 1e-3 for k in range(3))
         and abs(mid6[0] - 3.0) < TOL,
         "同时间点 Δ 前 %s 后 %s；支点 co 不变=%s"
         % ([round(v, 4) for v in r_before], [round(v, 4) for v in r_after],
            abs(mid6[0] - 3.0) < TOL))

    # ================================================================
    # B 组：选中【手柄端点】后按 S 缩放（端点模式 only_handles）
    # ================================================================
    #  用户 2026-09-17 追加反馈："手柄端点的缩放…没保速"
    #  根因：端点模式走 `apply_endpoint_transform`，那条通路**只写值分量**
    #        （`_set_handle_point` 不动时间分量）⇒ 速度 ×scale。
    #  修法：同样让 dt ×scale（基准时间从 snapshot 读）。
    #  边界：支点 = 选中关键帧点的**中位点** ⇒ 只有【单端点】时它才等于该帧 co
    #        ⇒ 才缩 dt（与"多点不缩 dt"同一口径）。
    #        ⚠️ dv=0 的端点不缩 dt（无速度可保，缩了只会压平曲线）。

    def s_ep(o, a, eps, factor, times=1):
        """建真实端点模式 ScaleSession 并 _apply（走真实通路）。"""
        s = me.ScaleSession('SCALE')
        s.obj, s.act, s.bone_name = o, a, None
        s.endpoints = list(eps)
        s.only_handles = True
        frames = sorted({float(f) for (f, _sd) in eps})
        s.snapshot = xf.snapshot_positions(a, o, {f: curves(o) for f in frames}, None)
        s.factor = factor
        s.plane_lock = None
        s.axis_lock = None
        s.pivot_local = mathutils.Vector(
            [float(kf(o, frames[0], ax).co[1]) for ax in (0, 1, 2)])
        r = None
        for _ in range(times):
            r = s._apply()
        return r

    def spd_side(o, frame, side):
        v = []
        for ax in (0, 1, 2):
            k = kf(o, frame, ax)
            h = k.handle_right if side == 'right' else k.handle_left
            dv = float(h[1]) - float(k.co[1])
            dt = (float(h[0]) - float(k.co[0])) if side == 'right' \
                else (float(k.co[0]) - float(h[0]))
            v.append(dv / dt if abs(dt) > 1e-9 else 0.0)
        return math.sqrt(sum(x * x for x in v))

    # B1：中间帧左手柄
    o7, a7 = build("_PS7")
    v0_7 = spd_side(o7, MID, 'left')
    s_ep(o7, a7, [(MID, 'left')], 1.5)
    step("B1 ★★★ 单端点（中间帧·左）S 缩放：速度不变",
         abs(spd_side(o7, MID, 'left') - v0_7) < TOL,
         "%.6f → %.6f" % (v0_7, spd_side(o7, MID, 'left')))

    # B2：中间帧右手柄
    o8, a8 = build("_PS8")
    v0_8 = spd_side(o8, MID, 'right')
    s_ep(o8, a8, [(MID, 'right')], 1.5)
    step("B2 ★★ 单端点（中间帧·右）S 缩放：速度不变",
         abs(spd_side(o8, MID, 'right') - v0_8) < TOL,
         "%.6f → %.6f" % (v0_8, spd_side(o8, MID, 'right')))

    # B3：端点（首帧）已有长度
    o9, a9 = build("_PS9")
    cs9 = curves(o9)
    for ax in (0, 1, 2):
        for k in cs9[ax].keyframe_points:
            if abs(k.co[0] - 1.0) < 1e-3:
                k.handle_right_type = 'FREE'
                k.handle_right = (k.handle_right[0],
                                  float(k.co[1]) + (1.0 if ax == 0 else 0.0))
        cs9[ax].update()
    v0_9 = spd_side(o9, 1.0, 'right')
    s_ep(o9, a9, [(1.0, 'right')], 1.5)
    step("B3 ★★ 端点（已有长度）S 缩放：速度不变",
         abs(spd_side(o9, 1.0, 'right') - v0_9) < TOL,
         "%.6f → %.6f" % (v0_9, spd_side(o9, 1.0, 'right')))

    # B4：端点无长度 ⇒ 不缩 dt（无速度可保）
    o10, a10 = build("_PS10")
    d10 = dts(o10, 1.0)
    v0_10 = spd_side(o10, 1.0, 'right')
    s_ep(o10, a10, [(1.0, 'right')], 1.5)
    step("B4 ★ dv=0 的端点不缩 dt（无速度可保，缩了只会压平曲线）",
         dts(o10, 1.0) == d10 and abs(spd_side(o10, 1.0, 'right') - v0_10) < TOL,
         "dt %s → %s（应不变）" % (d10, dts(o10, 1.0)))

    # B5：缩小 k<1
    o11, a11 = build("_PS11")
    v0_11 = spd_side(o11, MID, 'left')
    s_ep(o11, a11, [(MID, 'left')], 0.5)
    step("B5 缩小 k=0.5 也保速",
         abs(spd_side(o11, MID, 'left') - v0_11) < TOL,
         "%.6f → %.6f dt=%s" % (v0_11, spd_side(o11, MID, 'left'), dts(o11)))

    # B6：跨帧多端点 ⇒ 不缩 dt（保持历史行为）
    o12, a12 = build("_PS12")
    d12 = dts(o12, MID)
    v0_12 = spd_side(o12, MID, 'left')
    s_ep(o12, a12, [(MID, 'left'), (55.0, 'left')], 1.5)
    step("B6 ★ 跨帧多端点：不缩 dt（支点非各帧 co，保速无统一语义）",
         dts(o12, MID) == d12 and abs(spd_side(o12, MID, 'left') - v0_12) > 1e-6,
         "dt %s→%s（应不变）速度 %.6f→%.6f（会变，符合预期）"
         % (d12, dts(o12, MID), v0_12, spd_side(o12, MID, 'left')))

    # B7：反复 _apply 不累乘
    o13, a13 = build("_PS13")
    v0_13 = spd_side(o13, MID, 'left')
    d13 = dts(o13, MID)
    s_ep(o13, a13, [(MID, 'left')], 1.5, times=5)
    step("B7 ★★ 端点模式反复 _apply 不累乘（基准时间从 snapshot 读）",
         abs(spd_side(o13, MID, 'left') - v0_13) < TOL
         and dts(o13, MID)[0] == round(d13[0] * 1.5, 4),
         "5 次后 速度=%.6f dt=%s" % (spd_side(o13, MID, 'left'), dts(o13, MID)))

    # B8：静态契约
    _sig3 = _inspect.signature(xf.apply_endpoint_transform).parameters
    step("B8 静态契约：apply_endpoint_transform 有 time_scale 参数",
         "time_scale" in _sig3, "参数=%s" % (list(_sig3.keys()),))

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-700:])

# ================================================================ bug 注入
INJ = []


def _mk_time_scale_off():
    """I1：退回旧行为（不传 time_scale）⇒ 速度 ×k，A1 必须抓住。"""
    _orig = me._apply_xf

    def do():
        def bad(session, fn=None, delta=None, only_handles=None, time_scale=None):
            return _orig(session, fn=fn, delta=delta, only_handles=only_handles,
                         time_scale=None)
        me._apply_xf = bad

    def undo():
        me._apply_xf = _orig
    return do, undo, "I1 ★退回旧行为（不缩 dt）⇒ 速度 ×k"


def _mk_t_from_kp():
    """I2：时间分量从 kp 读（而非 snapshot）⇒ 反复 _apply 累乘 k^n。"""
    _orig = xf.apply_point_transform

    def do():
        def bad(action, obj, snapshot, fn, bone_name=None, only_handles=False,
                time_scale=None):
            # 把 snapshot 里的时间分量改成"当前值"，模拟从 kp 读
            for frame, per_axis in (snapshot or {}).items():
                for axis, vals in per_axis.items():
                    try:
                        o = obj
                        fc = {c.array_index: c for c in
                              xf._position_curves(action, o, bone_name)}.get(axis)
                        kp = None
                        for k in fc.keyframe_points:
                            if abs(k.co[0] - frame) < 1e-3:
                                kp = k
                                break
                        if kp is not None:
                            vals['hl_t'] = float(kp.handle_left[0])
                            vals['hr_t'] = float(kp.handle_right[0])
                    except Exception:
                        pass
            return _orig(action, obj, snapshot, fn, bone_name, only_handles, time_scale)
        xf.apply_point_transform = bad

    def undo():
        xf.apply_point_transform = _orig
    return do, undo, "I2 ★时间分量从 kp 读（模态里累乘 k^n）"


def _mk_ep_no_timescale():
    """I4：端点模式不传 time_scale（= 我上一版的状态）⇒ 端点 S 缩放不保速，B1 必须抓住。"""
    _orig = me._apply_xf

    def do():
        def bad(session, fn=None, delta=None, only_handles=None, time_scale=None):
            if getattr(session, "only_handles", False):
                time_scale = None            # 端点模式退回"只缩 dv"
            return _orig(session, fn=fn, delta=delta, only_handles=only_handles,
                         time_scale=time_scale)
        me._apply_xf = bad

    def undo():
        me._apply_xf = _orig
    return do, undo, "I4 ★端点模式不缩 dt ⇒ 端点 S 缩放不保速"


def _check_B1():
    """端点模式单端点 S 缩放：速度必须不变。"""
    o, a = build("_IB")
    v0 = _spd_side(o, MID, 'left')
    _s_ep(o, a, [(MID, 'left')], 1.5)
    return abs(_spd_side(o, MID, 'left') - v0) < TOL


def _spd_side(o, frame, side):
    v = []
    for ax in (0, 1, 2):
        k = kf(o, frame, ax)
        h = k.handle_right if side == 'right' else k.handle_left
        dv = float(h[1]) - float(k.co[1])
        dt = (float(h[0]) - float(k.co[0])) if side == 'right' \
            else (float(k.co[0]) - float(h[0]))
        v.append(dv / dt if abs(dt) > 1e-9 else 0.0)
    return math.sqrt(sum(x * x for x in v))


def _s_ep(o, a, eps, factor, times=1):
    s = me.ScaleSession('SCALE')
    s.obj, s.act, s.bone_name = o, a, None
    s.endpoints = list(eps)
    s.only_handles = True
    frames = sorted({float(f) for (f, _sd) in eps})
    s.snapshot = xf.snapshot_positions(a, o, {f: curves(o) for f in frames}, None)
    s.factor = factor
    s.plane_lock = None
    s.axis_lock = None
    s.pivot_local = mathutils.Vector(
        [float(kf(o, frames[0], ax).co[1]) for ax in (0, 1, 2)])
    r = None
    for _ in range(times):
        r = s._apply()
    return r


def _mk_multi_also_scale():
    """I3：多点也缩 dt ⇒ 破坏历史行为，A8 必须抓住。"""
    _orig = me.ScaleSession._apply

    def do():
        def bad(self):
            mask = self._axis_mask()
            if mask == (1.0, 1.0, 1.0):
                fn = xf.scale_fn(self.pivot_local, self.factor)
            else:
                fn = xf.scale_fn_masked(self.pivot_local, self.factor, mask)
            return me._apply_xf(self, fn=fn, time_scale=self.factor)   # 无条件缩
        me.ScaleSession._apply = bad

    def undo():
        me.ScaleSession._apply = _orig
    return do, undo, "I3 ★多点也缩 dt（破坏多点历史行为）"


def _check_A1():
    o, a = build("_I1")
    s0 = speeds(o)
    mk_session(o, a, [MID], 1.5)._apply()
    return abs(speeds(o)["left"] - s0["left"]) < TOL


def _check_A4():
    o, a = build("_I2")
    s0 = speeds(o)
    d0 = dts(o)
    s = mk_session(o, a, [MID], 1.5)
    for _ in range(5):
        s._apply()
    return abs(speeds(o)["left"] - s0["left"]) < TOL and dts(o) == (
        round(d0[0] * 1.5, 4), round(d0[1] * 1.5, 4))


def _check_A8():
    o, a = build("_I3")
    d0 = dts(o)
    mk_session(o, a, [1.0, MID], 1.5)._apply()
    return dts(o) == d0


_base = (_check_A1(), _check_A4(), _check_A8(), _check_B1())
step("I0 基线：四个检查未注入时全 True", all(_base),
     "A1 A4 A8 B1 = %s" % (_base,))

for mk, checker in ((_mk_time_scale_off, _check_A1),
                    (_mk_t_from_kp, _check_A4),
                    (_mk_multi_also_scale, _check_A8),
                    (_mk_ep_no_timescale, _check_B1)):
    do, undo, label = mk()
    try:
        do()
        caught = not checker()
    except Exception:
        caught = True
        label += "（异常也算抓住）"
    finally:
        undo()
    INJ.append((label, caught))
    step("★ %s ⇒ 测试抓住" % label, caught, "")

# ================================================================ 收尾
try:
    for n in ("_PS1", "_PS2", "_PS3", "_PS4", "_PS5", "_PS6",
              "_PS7", "_PS8", "_PS9", "_PS10", "_PS11", "_PS12", "_PS13",
              "_I1", "_I2", "_I3", "_IB"):
        x = bpy.data.objects.get(n)
        if x:
            bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
