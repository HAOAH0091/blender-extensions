# -*- coding: utf-8 -*-
"""数字输入（原生 G/R/S 的"敲数字"）测试

规格：
  · G：沿锁定轴精确移动 value（未锁轴默认 X）
  · R：旋转 value 度（绕当前轴）
  · S：缩放到 value 倍
  · 输入中鼠标移动【不改变】数值
  · 回车确认 / ESC 取消

用法：blender --factory-startup --python tests/gui_numeric_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_num_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
           (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf

    fcs = xf._position_curves(act, obj, None)

    def select_only(frames):
        want = [float(f) for f in frames]
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.select_control_point = any(abs(kp.co[0]-f) < 0.5 for f in want)
                kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
            fc.update()

    def pose(frame):
        v = [0.0, 0.0, 0.0]
        for fc in fcs:
            for kp in fc.keyframe_points:
                if abs(kp.co[0]-frame) < 0.5:
                    v[fc.array_index] = kp.co[1]
        return mathutils.Vector(v)

    def orig(f):
        for k, loc in KFS:
            if abs(k-f) < 0.5:
                return mathutils.Vector(loc)
        return None

    # ============================================================
    # NumericInput 单元逻辑
    # ============================================================
    ni = me.NumericInput()
    step("NumericInput starts empty", not ni.active and ni.value() is None, ni)

    ni.key('ONE'); ni.key('PERIOD'); ni.key('FIVE')
    step("types '1.5'", ni.buf == "1.5" and abs(ni.value()-1.5) < 1e-9, ni.buf)

    ni2 = me.NumericInput()
    ni2.key('MINUS'); ni2.key('TWO')
    step("types '-2'", ni2.buf == "-2" and abs(ni2.value()+2.0) < 1e-9, ni2.buf)

    ni3 = me.NumericInput()
    ni3.key('FIVE'); ni3.key('MINUS')
    step("minus only allowed at start (ignored mid-string)", ni3.buf == "5", ni3.buf)

    ni4 = me.NumericInput()
    ni4.key('ONE'); ni4.key('PERIOD'); ni4.key('PERIOD'); ni4.key('TWO')
    step("only one decimal point", ni4.buf == "1.2", ni4.buf)

    ni5 = me.NumericInput()
    for t in ('NUMPAD_7', 'NUMPAD_PERIOD', 'NUMPAD_5'):
        ni5.key(t)
    step("numpad keys work", ni5.buf == "7.5", ni5.buf)

    ni6 = me.NumericInput()
    ni6.key('ONE'); ni6.key('TWO'); ni6.key('BACK_SPACE')
    step("backspace works", ni6.buf == "1", ni6.buf)

    ni7 = me.NumericInput()
    ni7.key('MINUS')
    step("lone '-' parses as None (not a crash)", ni7.value() is None, ni7.buf)

    # ============================================================
    # G + 数字
    # ============================================================
    select_only([14])
    s = me.MoveSession('MOVE')
    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0)); rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    ok = s.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("G begin", ok is True, s.message)
    b0 = pose(14.0)
    s.apply_numeric(3.0)               # 未锁轴 -> 默认 X
    a0 = pose(14.0)
    step("G numeric 3.0 (no lock) -> moves X by 3",
         abs((a0.x - b0.x) - 3.0) < 1e-5 and abs(a0.y-b0.y) < 1e-6 and abs(a0.z-b0.z) < 1e-6,
         "d=(%.4f, %.4f, %.4f)" % (a0.x-b0.x, a0.y-b0.y, a0.z-b0.z))

    s.set_axis('Y')
    s.apply_numeric(2.5)
    a1 = pose(14.0)
    step("G numeric 2.5 with Y lock -> moves Y by 2.5",
         abs((a1.y - b0.y) - 2.5) < 1e-5 and abs(a1.x - b0.x) < 1e-6,
         "d=(%.4f, %.4f, %.4f)" % (a1.x-b0.x, a1.y-b0.y, a1.z-b0.z))

    s.apply_numeric(-1.5)
    a2 = pose(14.0)
    step("G numeric negative works", abs((a2.y - b0.y) + 1.5) < 1e-5,
         "dY=%.4f" % (a2.y-b0.y))

    s.numeric = "2.5"
    txt = s.status_text()
    step("G status shows the typed number",
         "[输入 2.5]" in txt, txt[:90])
    s.cancel()
    step("G cancel after numeric restores exactly",
         abs((pose(14.0) - orig(14)).length) < 1e-6, tuple(round(c,4) for c in pose(14.0)))

    # ============================================================
    # R + 数字
    # ============================================================
    select_only([1, 14])
    sr = me.RotateSession('ROTATE')
    sr.begin(obj, act, region, rv3d, 600.0, 400.0)
    br = pose(14.0)
    pivot = sr.pivot_world
    sr.apply_numeric(90.0)
    ar = pose(14.0)
    # ⚠️ 2026-09-16：R 方向按原生约定 —— 正值为【顺时针】，故 angle = -π/2
    step("R numeric 90° -> angle == -pi/2（原生：正值为顺时针）",
         abs(sr.angle + math.pi/2) < 1e-6, "%.6f rad" % sr.angle)
    d0 = (br - pivot).length; d1 = (ar - pivot).length
    step("R numeric preserves distance (刚体)", abs(d0 - d1) < 1e-5,
         "%.6f -> %.6f" % (d0, d1))
    sr.numeric = "90"
    step("R status shows typed number", "[输入 90]" in sr.status_text(),
         sr.status_text()[:80])
    sr.cancel()
    step("R cancel restores", abs((pose(14.0) - orig(14)).length) < 1e-6,
         tuple(round(c,4) for c in pose(14.0)))

    # ============================================================
    # S + 数字
    # ============================================================
    select_only([1, 14])
    ss = me.ScaleSession('SCALE')
    ss.begin(obj, act, region, rv3d, 600.0, 400.0)
    bs = pose(14.0); piv = ss.pivot_world
    ss.apply_numeric(2.0)
    as_ = pose(14.0)
    step("S numeric 2.0 -> factor == 2.0", abs(ss.factor - 2.0) < 1e-9, ss.factor)
    step("S numeric doubles distance to pivot",
         abs((as_ - piv).length - 2.0*(bs - piv).length) < 1e-4,
         "%.4f -> %.4f" % ((bs-piv).length, (as_-piv).length))
    ss.apply_numeric(0.5)
    step("S numeric 0.5 halves from ORIGINAL (not cumulative)",
         abs((pose(14.0) - piv).length - 0.5*(bs - piv).length) < 1e-4,
         "%.4f" % (pose(14.0)-piv).length)
    ss.numeric = "0.5"
    step("S status shows typed number", "[输入 0.5]" in ss.status_text(),
         ss.status_text()[:80])
    ss.cancel()
    step("S cancel restores", abs((pose(14.0) - orig(14)).length) < 1e-6,
         tuple(round(c,4) for c in pose(14.0)))

    # ============================================================
    # 完整性：三个 session 都有 apply_numeric
    # ============================================================
    for cls, name in ((me.MoveSession, "MoveSession"),
                      (me.RotateSession, "RotateSession"),
                      (me.ScaleSession, "ScaleSession")):
        step("%s has apply_numeric" % name, hasattr(cls, "apply_numeric"), True)
    step("SPEED 会话不参与数字输入（hasattr False）",
         not hasattr(me.ModalSession, "apply_numeric"), True)

    # ============================================================
    # ★ 真实路径：驱动 operator.modal() 喂数字按键
    #   （单元测过 ≠ 接线对 —— 曾因测试摆状态而漏掉真实崩溃）
    # ============================================================
    class FakeOp:
        """operator 替身：属性/方法都【来自真实类】，不凭空造。"""
        def __init__(self, session):
            self._session = session
            self._last_mouse = (600.0, 400.0)
            self._numeric = me.NumericInput()
            # 把真实 operator 的方法绑上来（否则 modal() 里调 self._set_status 会炸）
            for nm in ("_set_status", "_redraw", "_finish"):
                fn = getattr(me.RTMP_OT_KeyboardTransform, nm, None)
                if fn is not None:
                    setattr(self, nm, fn.__get__(self))

    class FakeEvent:
        def __init__(self, type_, value='PRESS', shift=False):
            self.type = type_
            self.value = value
            self.mouse_region_x = 600.0
            self.mouse_region_y = 400.0
            self.shift = shift
            self.ctrl = False
            self.alt = False

    class FakeCtx:
        pass

    fctx = FakeCtx()
    fctx.window_manager = bpy.context.window_manager
    fctx.area = area
    fctx.region = region
    fctx.region_data = rv3d
    fctx.workspace = bpy.context.workspace

    Modal = me.RTMP_OT_KeyboardTransform.modal

    select_only([14])
    s9 = me.MoveSession('MOVE')
    s9.begin(obj, act, region, rv3d, 600.0, 400.0)
    fake = FakeOp(s9)
    b9 = pose(14.0)
    try:
        # 敲 "2" "5" -> 25
        Modal(fake, fctx, FakeEvent('TWO'))
        step("real path: modal consumes digit '2'", fake._numeric.buf == "2", fake._numeric.buf)
        Modal(fake, fctx, FakeEvent('FIVE'))
        step("real path: modal consumes digit '5'", fake._numeric.buf == "25", fake._numeric.buf)
        step("real path: G applied 25 along X",
             abs((pose(14.0).x - b9.x) - 25.0) < 1e-5,
             "dX=%.4f" % (pose(14.0).x - b9.x))
        step("real path: session.numeric mirrors buffer", s9.numeric == "25", s9.numeric)

        # 小数点 + 退格
        Modal(fake, fctx, FakeEvent('PERIOD'))
        Modal(fake, fctx, FakeEvent('FIVE'))
        step("real path: '25.5' applies", fake._numeric.buf == "25.5",
             "dX=%.4f" % (pose(14.0).x - b9.x))
        Modal(fake, fctx, FakeEvent('BACK_SPACE'))
        step("real path: backspace drops last char",
             fake._numeric.buf == "25." and abs((pose(14.0).x - b9.x) - 25.0) < 1e-5,
             "buf=%s dX=%.4f" % (fake._numeric.buf, pose(14.0).x - b9.x))

        # ★ 输入中鼠标移动不应改值
        before_move = pose(14.0)
        Modal(fake, fctx, FakeEvent('MOUSEMOVE', 'NOTHING'))
        step("★ real path: MOUSEMOVE ignored while typing",
             abs((pose(14.0) - before_move).length) < 1e-9,
             "moved=%.9f" % (pose(14.0) - before_move).length)

        # 回车确认
        Modal(fake, fctx, FakeEvent('RETURN'))
        step("real path: RETURN confirms (state DONE)", s9.state == me.STATE_DONE, s9.state)
        step("real path: value survives confirm",
             abs((pose(14.0).x - b9.x) - 25.0) < 1e-5,
             "dX=%.4f" % (pose(14.0).x - b9.x))
    except Exception as e:
        step("real path: numeric via modal", False,
             "%s: %s" % (type(e).__name__, e))

    # 真实路径：R 的数字输入
    select_only([1, 14])
    sr2 = me.RotateSession('ROTATE')
    sr2.begin(obj, act, region, rv3d, 600.0, 400.0)
    fake2 = FakeOp(sr2)
    try:
        for t in ('FOUR', 'FIVE'):
            Modal(fake2, fctx, FakeEvent(t))
        step("real path: R typed '45' -> -45°（原生：正值为顺时针）",
             abs(math.degrees(sr2.angle) + 45.0) < 1e-4,
             "%.4f°" % math.degrees(sr2.angle))
        Modal(fake2, fctx, FakeEvent('ESC'))
        step("real path: ESC cancels R", sr2.state == me.STATE_DONE, sr2.state)
    except Exception as e:
        step("real path: R numeric via modal", False, "%s: %s" % (type(e).__name__, e))

    # 真实路径：S 的数字输入
    select_only([1, 14])
    ss2 = me.ScaleSession('SCALE')
    ss2.begin(obj, act, region, rv3d, 600.0, 400.0)
    fake3 = FakeOp(ss2)
    try:
        Modal(fake3, fctx, FakeEvent('THREE'))
        step("real path: S typed '3' -> factor 3",
             abs(ss2.factor - 3.0) < 1e-6, ss2.factor)
        Modal(fake3, fctx, FakeEvent('RETURN'))
        step("real path: S confirmed", ss2.state == me.STATE_DONE, ss2.state)
    except Exception as e:
        step("real path: S numeric via modal", False, "%s: %s" % (type(e).__name__, e))

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("NUMERIC_CHECK_DONE")
os._exit(0)
