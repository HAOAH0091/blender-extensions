# -*- coding: utf-8 -*-
"""双进程验证：_FROZEN 持久化（进程1 保存 .blend → 进程2 打开）。

用法：
    blender -b --factory-startup --python tests/_frozen_persist_probe.py -- save
    blender -b --factory-startup --python tests/_frozen_persist_probe.py -- load
"""
import os
import sys
import json
import traceback

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
BLEND = os.path.join(HERE, "_frozen_persist.blend")
OUT = os.path.join(HERE, "_frozen_persist_result.json")

FRAME = 14.0
steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())


def load_addon():
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import time_domain as td
    return td


def build():
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    bpy.ops.mesh.primitive_cube_add()
    o = bpy.context.active_object
    o.name = "T"
    for f, loc in ((1, (0.0, 0.0, 0.0)), (14, (3.0, 0.0, 0.0)), (40, (6.0, 0.0, 0.0))):
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    act = o.animation_data.action
    try:
        act.name = "FrozenAct"          # ★ 显式命名，否则 open 时按自动名找不到
    except Exception:
        pass
    return o, act


try:
    mode = sys.argv[-1] if len(sys.argv) else "?"
    td = load_addon()
    step("插件已加载 (mode=%s)" % mode, td is not None)

    if mode == "save":
        o, act = build()
        step("构造 action", act is not None, "action=%s" % getattr(act, "name", None))

        td.clear_frozen()
        td.mark_frozen(act, FRAME)
        step("mark_frozen 后内存命中", td.is_frozen(act, FRAME) is True)
        has_prop = "rtmp_frozen" in act.keys()
        vals = list(act["rtmp_frozen"]) if has_prop else None
        step("mark_frozen 写进 action 的 custom property",
             has_prop and "14" in [str(v) for v in vals],
             "act[rtmp_frozen]=%s" % vals)

        bpy.ops.wm.save_as_mainfile(filepath=BLEND)
        step("保存 .blend", os.path.isfile(BLEND), BLEND)

    elif mode == "load":
        bpy.ops.wm.open_mainfile(filepath=BLEND)
        td = load_addon()
        act = bpy.data.actions.get("FrozenAct")
        step("打开 .blend 拿到 action", act is not None,
             "action=%s" % getattr(act, "name", None))

        mem_before = len(td._FROZEN)
        step("★ 新进程内存登记表为空（证明不是内存残留）", mem_before == 0,
             "len(_FROZEN)=%d" % mem_before)

        prop = act.get("rtmp_frozen")
        step("custom property 随文件持久化", prop is not None,
             "act[rtmp_frozen]=%s" % (list(prop) if prop is not None else None))

        got = td.is_frozen(act, FRAME)
        step("★★ is_frozen 惰性恢复后返回 True（重启不丢体感类型）", got is True,
             "is_frozen=%s | 恢复后 len(_FROZEN)=%d" % (got, len(td._FROZEN)))

        step("反向：未登记的帧仍为 False", td.is_frozen(act, 27.0) is False)

        try:
            other = bpy.data.actions.new("OtherAct")
            r2 = td.is_frozen(other, FRAME)
            step("反向：未登记的 action 仍为 False", r2 is False)
        except Exception as e:
            step("反向：未登记的 action 仍为 False", False, repr(e))

except Exception:
    step("FATAL", False, traceback.format_exc()[-1500:])

flush()
print("FROZEN_PERSIST_DONE")
