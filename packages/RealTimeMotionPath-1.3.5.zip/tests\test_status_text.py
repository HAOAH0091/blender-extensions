# -*- coding: utf-8 -*-
"""状态栏文本全覆盖测试（headless）

存在意义
--------
用户实测时抓到 `TypeError: not all arguments converted during string formatting`
—— `MoveSession.status_text()` 的格式串占位符数量与参数对不上。

**根因不是格式串本身，而是我的测试从没调用过它。**
GUI 测试只调了 SPEED 的 status_text，MOVE 的从没跑过。

所以这个测试把两个会话、所有状态分支的 status_text 全跑一遍，
任何格式错误都会在这里暴露（而不是等用户在 Blender 里按 G 才炸）。
"""
import sys, os, json, types, importlib

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    pkg = types.ModuleType(PKG)
    pkg.__path__ = [ADDON_DIR]
    pkg.__package__ = PKG
    sys.modules[PKG] = pkg

import bpy, mathutils
td = importlib.import_module(PKG + ".time_domain")
xf = importlib.import_module(PKG + ".transform_domain")
me = importlib.import_module(PKG + ".modal_edit")

results = []
def check(name, fn):
    """fn() 抛异常 = FAIL（这正是我们要抓的）"""
    try:
        txt = fn()
        ok = isinstance(txt, str) and len(txt) > 0
        results.append(("PASS" if ok else "FAIL", name, (txt or "")[:90]))
    except Exception as e:
        results.append(("FAIL", name, "%s: %s" % (type(e).__name__, e)))


# ---------------------------------------------------------------
# MOVE 会话的状态栏：所有分支
# ---------------------------------------------------------------

def move_session(state, **kw):
    s = me.MoveSession('MOVE')
    s.state = state
    s.offset = mathutils.Vector((0.1, -0.2, 0.3))
    s.axis_lock = kw.get("axis_lock")
    s.plane_lock = kw.get("plane_lock")
    s.precision = kw.get("precision", False)
    return s

check("MOVE / IDLE (未开始)",
      lambda: move_session(me.STATE_IDLE).status_text())

check("MOVE / RUNNING 无锁",
      lambda: move_session(me.STATE_RUNNING).status_text())

check("MOVE / RUNNING 锁 X 轴",
      lambda: move_session(me.STATE_RUNNING, axis_lock='X').status_text())

check("MOVE / RUNNING 锁 YZ 平面",
      lambda: move_session(me.STATE_RUNNING, plane_lock=('Y', 'Z')).status_text())

check("MOVE / RUNNING 精度模式",
      lambda: move_session(me.STATE_RUNNING, precision=True).status_text())

check("MOVE / RUNNING 锁轴+精度 同时",
      lambda: move_session(me.STATE_RUNNING, axis_lock='Z', precision=True).status_text())

check("MOVE / DONE",
      lambda: move_session(me.STATE_DONE).status_text())

# ROTATE / SCALE 现在是独立会话类（2026-09-15 实现）
def _rot(state, **kw):
    s = me.RotateSession('ROTATE')
    s.state = state
    s.angle = 0.7854
    for k, v in kw.items():
        setattr(s, k, v)
    return s.status_text()

def _scl(state, **kw):
    s = me.ScaleSession('SCALE')
    s.state = state
    s.factor = 1.5
    for k, v in kw.items():
        setattr(s, k, v)
    return s.status_text()

check("ROTATE / IDLE", lambda: _rot(me.STATE_IDLE))
check("ROTATE / RUNNING", lambda: _rot(me.STATE_RUNNING))
check("ROTATE / RUNNING 精度", lambda: _rot(me.STATE_RUNNING, precision=True))
check("ROTATE / RUNNING 锁 X 轴", lambda: _rot(me.STATE_RUNNING, axis_lock='X'))
check("ROTATE / DONE", lambda: _rot(me.STATE_DONE))
check("SCALE / IDLE", lambda: _scl(me.STATE_IDLE))
check("SCALE / RUNNING", lambda: _scl(me.STATE_RUNNING))
check("SCALE / RUNNING 精度", lambda: _scl(me.STATE_RUNNING, precision=True))
check("SCALE / RUNNING 锁 X 轴", lambda: _scl(me.STATE_RUNNING, axis_lock='X'))
check("SCALE / RUNNING YZ 平面", lambda: _scl(me.STATE_RUNNING, plane_lock=('Y','Z')))
check("SCALE / DONE", lambda: _scl(me.STATE_DONE))


# ---------------------------------------------------------------
# SPEED 会话的状态栏：所有分支
# ---------------------------------------------------------------

def speed_session(state, with_target=True, s_val=td.S_LIN):
    s = me.ModalSession('SPEED')
    s.state = state
    if with_target:
        s.target = {"frame": 14.0, "side": 'right', "span": 13.0, "kf_map": {}}
        s.last_s = s_val
    return s

check("SPEED / IDLE 无 target", lambda: speed_session(me.STATE_IDLE, with_target=False).status_text())
check("SPEED / RUNNING 有 target 右段",
      lambda: speed_session(me.STATE_RUNNING).status_text())

def _left():
    s = speed_session(me.STATE_RUNNING)
    s.target["side"] = 'left'
    return s.status_text()
check("SPEED / RUNNING 左段", _left)

check("SPEED / RUNNING 无 last_s（未拖）",
      lambda: speed_session(me.STATE_RUNNING, s_val=None).status_text())
check("SPEED / DONE", lambda: speed_session(me.STATE_DONE).status_text())

# 非 SPEED 模式（走 else 分支）
def _other_mode():
    s = me.ModalSession('MOVE')
    s.state = me.STATE_RUNNING
    return s.status_text()
check("ModalSession / 非 SPEED 模式", _other_mode)


# ---------------------------------------------------------------
# 顺带：所有 status_text 的返回值都应能被 saf 显示（非空、无未替换的 %）
# ---------------------------------------------------------------
def _no_leftover_placeholder():
    texts = []
    for st in (me.STATE_IDLE, me.STATE_RUNNING, me.STATE_DONE):
        texts.append(move_session(st, axis_lock='X', precision=True).status_text())
        texts.append(speed_session(st).status_text())
        texts.append(_rot(st, axis_lock='X', precision=True))
        texts.append(_scl(st, plane_lock=('Y', 'Z'), precision=True))
    bad = [t for t in texts if "%" in t and "%s" in t or "%.4f" in t]
    if bad:
        raise AssertionError("leftover placeholder: %r" % bad[:1])
    long_ones = [t for t in texts if len(t) < 5]
    if long_ones:
        raise AssertionError("suspiciously short text: %r" % long_ones)
    return "all %d texts clean" % len(texts)
check("no leftover format placeholders", _no_leftover_placeholder)


# ---------------------------------------------------------------
fails = [r for r in results if r[0] == "FAIL"]
summary = {
    "total": len(results),
    "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in results],
}
json.dump(summary, open(os.path.join(HERE, "_st_result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("WROTE_STATUS_JSON")
