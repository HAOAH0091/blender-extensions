# -*- coding: utf-8 -*-
"""P1 + P2.2 验收：鼠标拖手柄后的【类型契约】与【真的动了】

═══ 契约（2026-09-16 修订）═══

拖一侧手柄之后：

  1. **被拖侧**：
       · ALIGNED / FREE        → **保持不变**（它们本来就能写入）
       · AUTO / AUTO_CLAMPED / VECTOR
                               → 转 **FREE**（用户接管了这个手柄，与原生一致）
       判据来源：`_DERIVED_TYPES` 的坐标由 Blender 公式**导出**，`fc.update()`
       会把外部写入覆盖掉 → 不接管就**拖不动**。

  2. **对侧**：**一律不变**（这才是 P1 真正要守的：别去动没被拖的那一侧）

  3. **被拖侧必须真的移动**（位移 = 拖动量）。
     ⚠️ 这条是本轮补上的 —— 老版本只验类型，**从没验过手柄有没有动**，
        于是"默认 AUTO_CLAMPED 下拖手柄位移 = 0.0000"这个缺陷一直没被测出来。

═══ 历史（P1，2026-09-16 上午）═══
    interaction.apply_handle_offset 里
      1252 行  self.prepare_handles_for_edit(frame_kf_map)   ← 先把 VECTOR 改成 FREE
      1259 行  original_left_type = keyframe.handle_left_type ← 此时读到的已是 FREE
      1310 行  if original in {'VECTOR','FREE'}: 恢复          → 恢复成 FREE
    ⇒ VECTOR 类型被永久破坏（且当时的代码意图是"恢复"，属意外破坏）。

    P1 修的是"意外破坏"；P2.2 改的是"**有意接管**"（拖不动必须解决）。
    两者不矛盾：P1 保护**对侧**与**未拖拽**的情形，P2.2 只接管**被拖的那一侧**。

用法：blender --factory-startup --python tests/gui_handle_preserve_check.py
"""
import os
import sys
import json
import traceback

import bpy
import mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_hp_result.json")

steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})


def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())


try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath.state import _session

    DRAG = mathutils.Vector((0.0, 2.0, 0.0))
    EXPECT = DRAG.length

    def build(htype):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
                       (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]:
            sc.frame_set(f)
            o.location = loc
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype
                kp.handle_right_type = htype
            fc.update()
        return o, a

    def side_state(o, a, frame=14.0):
        """返回 (左类型, 右类型, 左三维手柄点, 右三维手柄点)。"""
        lt = rt = None
        hl = [0.0, 0.0, 0.0]
        hr = [0.0, 0.0, 0.0]
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    lt, rt = str(kp.handle_left_type), str(kp.handle_right_type)
                    hl[fc.array_index] = float(kp.handle_left[1])
                    hr[fc.array_index] = float(kp.handle_right[1])
        return lt, rt, mathutils.Vector(hl), mathutils.Vector(hr)

    def make_op():
        class FO:
            def report(self, *a, **k):
                pass
        cls = inter.RTMP_OT_PathPointDrag
        for nm in dir(cls):
            if nm.startswith("__"):
                continue
            v = getattr(cls, nm, None)
            if callable(v):
                try:
                    setattr(FO, nm, v.__get__(FO()))
                except Exception:
                    pass
        return FO()

    def drag(htype):
        """走真实入口：record_handle_baseline（按下）→ apply_handle_offset（移动）。"""
        o, act = build(htype)
        before = side_state(o, act)
        fo = make_op()
        _session.handle_start_values = {}
        _session.endpoint_snapshot = {}
        _session.clear_endpoints()
        _session.active_frame_number = 14.0
        _session.active_handle_direction = 'left'
        _session.drag_target_object = "T"
        _session.active_bone_identifier = None
        _session.handle_edit_in_progress = True
        fo.record_handle_baseline(bpy.context, 14.0, None, 'left')
        fo.apply_handle_offset(bpy.context, DRAG, 'left')
        return before, side_state(o, act)

    # ---------------- 1. 被拖侧的类型契约 ----------------
    # ALIGNED / FREE：保持；派生类型：转 FREE（接管）
    # ★★ 2026-09-16 二次修订：按 Blender **原生语义**（官方手册原文）
    #      Automatic / Auto Clamped：「convert to **Align** handles when moved」
    #      Vector                    ：「convert to **Free** handles when moved」
    #    所以 AUTO* 的目标类型是 ALIGNED（**不是** FREE —— 早先实现转 FREE 是错的）。
    MOVED_EXPECT = {
        'FREE': 'FREE',
        'ALIGNED': 'ALIGNED',
        'AUTO': 'ALIGNED',
        'AUTO_CLAMPED': 'ALIGNED',
        'VECTOR': 'FREE',
    }
    # 对侧也按下同一条原生规则接管（`link_opposite=True`）：
    # 不接管的话 Blender 会重算它 → 臂长突变 + 永久不共线（实测 dev 0.832）。
    # ⚠️ 唯一的例外：对侧 VECTOR **保持**（用户显式"贴相邻关键帧"语义）。
    # ★★ 2026-09-16（第十轮）**再次修订**：对侧收尾要「封口」成 **FREE**。
    #    原因（实测 `_probeZ.py`）：对侧若留 ALIGNED，Blender 在**任何一次后续
    #    `fc.update()`** 里都会按它的 "(t,v) 平面共线" 重算它 ——
    #    而那个约束与插件要的 **3D 值空间共线不等价**：
    #        3D 点线距 1.45e-07 → 0.2697（破相）；对侧 dt 13.0 → 11.07（速度分布被改）
    #    转 FREE 后 Blender 不再碰它 → 3D 形状稳定 + 速度分布一个数不动。
    #    ⚠️ 但这只对"插件接管过的"FREE 成立；用户手动设的 FREE 仍然不联动
    #       （见 transform_domain._plugin_owned_free）。
    OPP_EXPECT = {
        'FREE': 'FREE',
        'ALIGNED': 'FREE',
        'AUTO': 'FREE',
        'AUTO_CLAMPED': 'FREE',
        'VECTOR': 'VECTOR',
    }
    for ht in ('FREE', 'ALIGNED', 'AUTO', 'AUTO_CLAMPED', 'VECTOR'):
        before, after = drag(ht)
        exp = MOVED_EXPECT[ht]
        step("★ 被拖侧 %-13s 拖后类型 = %s（原生规则）" % (ht, exp),
             after[0] == exp,
             "左 %s→%s（期望 %s） 右 %s→%s（期望 %s）"
             % (before[0], after[0], exp, before[1], after[1], OPP_EXPECT[ht]))

    # ---------------- 2. 对侧：按同一条原生规则接管 ----------------
    for ht in ('FREE', 'ALIGNED', 'AUTO', 'AUTO_CLAMPED', 'VECTOR'):
        before, after = drag(ht)
        moved_r = (after[3] - before[3]).length
        exp = OPP_EXPECT[ht]
        step("★ 对侧 %-13s 拖后类型（原生接管规则）" % ht, after[1] == exp,
             "右 %s→%s（期望 %s）" % (before[1], after[1], exp))
        # ⚠️ 只有【用户手动 FREE】才必须一动不动（原生：自由手柄互不影响）。
        #    AUTO* 现在会被接管 → 对侧**应该**跟着走（这正是用户要的"一直线"）。
        step("★ 对侧 %-13s 为 FREE 时不动它" % ht,
             (ht != 'FREE') or moved_r < 1e-6,
             "右位移=%.6f" % moved_r)

    # ---------------- 3. 被拖侧必须真的移动（本轮补的覆盖）----------------
    for ht in ('FREE', 'ALIGNED', 'AUTO', 'AUTO_CLAMPED', 'VECTOR'):
        before, after = drag(ht)
        moved_l = (after[2] - before[2]).length
        step("★★ 被拖侧 %-13s 真的移动了（位移=%.4f，期望 %.4f）"
             % (ht, moved_l, EXPECT), abs(moved_l - EXPECT) < 1e-4,
             "实际 %.6f" % moved_l)

except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("HANDLE_PRESERVE_DONE")
os._exit(0)
