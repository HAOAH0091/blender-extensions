# -*- coding: utf-8 -*-
"""实测：三角速度手柄拖拽 —— 多少像素位移会把数值"拉满"？

复现用户报告：
  「点击拖动后直接数值拉满」
  「有时拖动会失效」

测三件事：
  T1 拖拽的像素灵敏度（dy=1/2/5/10/20/30/50 px 各得到什么 s / 倍率）
  T2 命中半径 vs 三角几何尺寸（"拖不动"嫌疑）
  T3 第一次 MOUSEMOVE 就大幅移动时会不会直接跳满
"""
import os
import sys
import json

REPO = r"F:\desktop\BaiduSyncdisk\addons\RealTimeMotionPath"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import time_domain as td
from RealTimeMotionPath import handles as hd
from RealTimeMotionPath import interaction as it
from RealTimeMotionPath.state import _session

rows = []


def rec(name, **kw):
    kw["name"] = name
    rows.append(kw)
    print("[ROW]", json.dumps(kw, ensure_ascii=False)[:700])


# ---------------------------------------------------------------- T1 速率
try:
    d0 = td.CV_MID          # 匀速时的基准 d
    rec("T0 常量",
        CV_MID=td.CV_MID, S_LIN=round(td.S_LIN, 6),
        _SPARSE_RATE=round(td._SPARSE_RATE, 8), _DENSE_RATE=round(td._DENSE_RATE, 8),
        S_HARD_MAX=td.S_HARD_MAX, S_EPS=td.S_EPS)

    out = []
    for dy in (1, 2, 5, 10, 20, 30, 50):
        # 上三角 DIR=+1：往上拖 = d 增大 = 变疏
        d = d0 + dy
        s = td.d_to_s(d)
        # 倍率（与匀速的比值）
        ratio = (td.S_LIN / s) if s > 1e-12 else float("inf")
        out.append({"dy_px": dy, "d": d, "s": round(s, 6),
                    "倍率": round(ratio, 3),
                    "触底(达极小 S_EPS)": abs(s - td.S_EPS) < 1e-9})
    rec("T1 变疏方向：向上拖 N 像素", 明细=out)

    out2 = []
    for dy in (1, 2, 5, 10, 20, 30):
        d = d0 - dy       # 变密：d 减小
        s = td.d_to_s(d)
        out2.append({"dy_px": dy, "d": d, "s": round(s, 6),
                     "倍率": round((td.S_LIN / s) if s else 0, 3),
                     "顶到上限": abs(s - td.S_HARD_MAX) < 1e-9})
    rec("T1b 变密方向：向下拖 N 像素", 明细=out2)

    # 结论数字
    import math
    px_sparse = (td.S_LIN - td.S_MIN) / td._SPARSE_RATE
    px_dense = (td.S_MAX - td.S_LIN) / td._DENSE_RATE
    rec("T1c ★ 灵敏度结论",
        变疏到参考下界需像素=round(px_sparse, 1),
        变密到上限需像素=round(px_dense, 1),
        说明="视口高约 1000px ⇒ 拖 30px 就打满全程（约 3% 视口高度）")

    # 多久到 S_EPS（真·拉满）
    px_to_eps = (td.S_LIN - td.S_EPS) / td._SPARSE_RATE
    rec("T1d 到真·下限(S_EPS)需像素", 像素=round(px_to_eps, 1),
        s_at_100=td.d_to_s(100.0))

except Exception:
    import traceback
    rec("T1 FATAL", tb=traceback.format_exc()[-800:])

# ---------------------------------------------------------------- T2 命中
try:
    # 三角几何：中心距关键帧 TRI_FIXED_D，半宽 TRI_HALF_PX，高 TRI_HEIGHT_PX
    # 三角的三个顶点相对其【中心】的距离
    import math
    w = hd.TRI_HALF_PX
    hgt = hd.TRI_HEIGHT_PX
    # 顶点（相对中心）：尖端朝关键帧，底边在外侧
    verts = [(0.0, -hgt / 2.0), (-w, hgt / 2.0), (w, hgt / 2.0)]
    far = max(math.hypot(vx, vy) for vx, vy in verts)
    rec("T2 命中半径 vs 三角几何",
        三角中心距关键帧=hd.TRI_FIXED_D,
        半宽=w, 高=hgt,
        顶点离中心最远=round(far, 2),
        命中半径=it.SPEED_TRI_PICK_RADIUS,
        悬停半径=it.SPEED_HOVER_RADIUS,
        覆盖整个三角=(it.SPEED_TRI_PICK_RADIUS >= far))

    # 三角整体占的屏幕范围（相对关键帧）：从 26-7.5 到 26+7.5
    rec("T2b 三角相对关键帧的纵向范围",
        近端像素=round(hd.TRI_FIXED_D - hgt / 2, 2),
        远端像素=round(hd.TRI_FIXED_D + hgt / 2, 2),
        命中半径=it.SPEED_TRI_PICK_RADIUS,
        说明="半径 22 > 远端的 29.75？→ 若否，三角外侧部分点不中")

    # 详细：离中心 d px 处能否命中
    hitmap = []
    for dy in range(0, int(hd.TRI_FIXED_D + hgt) + 4, 2):
        # 三角内部该高度处的实际半宽
        frac = (dy - (hd.TRI_FIXED_D - hgt / 2)) / max(hgt, 1e-9)
        inside = (0.0 <= frac <= 1.0)
        hit = (dy <= it.SPEED_TRI_PICK_RADIUS)
        hitmap.append({"离关键帧px": dy, "在三角内": inside, "能命中": hit})
    rec("T2c 沿关键帧中轴线逐点命中测试", 明细=hitmap)

except Exception:
    import traceback
    rec("T2 FATAL", tb=traceback.format_exc()[-800:])

# ---------------------------------------------------------------- T3 首帧跳变
try:
    # 模拟：PRESS 时记 last_mouse，第一次 MOUSEMOVE 若已移动 N 像素
    for first_dy in (0, 3, 10, 50, 200):
        _session.speed_drag_effective_px = 0.0
        _session.speed_drag_precision = False
        start = (500.0, 500.0)
        cur = (500.0, 500.0 - first_dy)
        _session.speed_drag_last_mouse = start          # PRESS 时设的
        last = _session.speed_drag_last_mouse
        dy_raw = float(cur[1]) - float(last[1])
        _session.speed_drag_last_mouse = cur
        scale = 1.0
        _session.speed_drag_effective_px += dy_raw * scale
        eff = _session.speed_drag_effective_px
        d = td.CV_MID + eff * hd.DIR_BY_TRI['up']
        s = td.d_to_s(d)
        rec("T3 第一次 MOUSEMOVE 就移动 N px",
            first_dy=first_dy, eff=round(eff, 3), d=round(d, 3),
            s=round(s, 8), 倍率=round(td.S_LIN / s if s else 0, 3),
            已拉满=(abs(s - td.S_EPS) < 1e-9))

except Exception:
    import traceback
    rec("T3 FATAL", tb=traceback.format_exc()[-800:])

with open(os.path.join(HERE, "_speed_drag_probe.json"), "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=1)
print("SPEED_DRAG_DONE")
os._exit(0)
