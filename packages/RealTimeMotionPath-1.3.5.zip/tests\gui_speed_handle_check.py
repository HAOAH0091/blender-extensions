# -*- coding: utf-8 -*-
"""速度手柄（两个三角）GUI 检查 —— 匹配 2026-09-15 定稿的新交互

新交互要点：
  ① 三角固定不动（不再随疏密值移动）
  ② 只有三角，没有基准虚线 / 倍数标签
  ③ 拖拽用【相对位移】驱动
  ④ 拖拽/选中后，受影响的【路径段变色】
  ⑤ 选中三角后按 G 进入疏密模态（不再需要 J）

用法：blender --factory-startup --python tests/gui_speed_handle_check.py
"""
import bpy, os, sys, json, traceback, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_sh_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
           (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    import RealTimeMotionPath as RTMP
    from RealTimeMotionPath import overlay as ovmod
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath.state import _session

    step("addon loaded from REPO",
         os.path.normcase(os.path.dirname(os.path.abspath(RTMP.__file__))) == os.path.normcase(REPO),
         RTMP.__file__)

    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        pts = list(fc.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()

    wm = bpy.context.window_manager
    wm.rtmp_path_display_enabled = True
    win = wm.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    d = mathutils.Vector((0.55, -1.0, 0.35)).normalized()
    rv3d.view_rotation = (-d).to_track_quat('-Z', 'Y')
    sc.frame_set(1)
    bpy.context.view_layer.update()

    over = ovmod.get_overlay()
    ctx = type('C', (), {})()

    def fresh():
        return me.collect_speed_handles(act, obj, region, rv3d)

    def pick(recs_, frame, tri):
        for r in recs_:
            if r['frame'] == frame and r['tri'] == tri:
                return r
        return None

    # ---------------- 手柄收集 ----------------
    recs = fresh()
    step("collect 6 handles", len(recs) == 6, len(recs))
    pairs = sorted((r['frame'], r['tri']) for r in recs)
    step("endpoint sides excluded",
         pairs == sorted([(1.0, 'down'), (14.0, 'up'), (14.0, 'down'),
                          (27.0, 'up'), (27.0, 'down'), (40.0, 'up')]), pairs)

    r14u = pick(recs, 14.0, hd.TRI_UP)
    r14d = pick(recs, 14.0, hd.TRI_DOWN)
    step("UP tri above keyframe on screen",
         r14u['tri_screen'][1] > r14u['kf_screen'][1],
         "kf_y=%.0f tri_y=%.0f" % (r14u['kf_screen'][1], r14u['tri_screen'][1]))
    step("DOWN tri below keyframe on screen",
         r14d['tri_screen'][1] < r14d['kf_screen'][1],
         "kf_y=%.0f tri_y=%.0f" % (r14d['kf_screen'][1], r14d['tri_screen'][1]))
    step("x aligned for both", r14u['tri_screen'][0] == r14d['tri_screen'][0])

    # ---------------- ① 三角固定不动 ----------------
    step("TRI_FIXED_D constant exists", hasattr(ovmod, 'TRI_FIXED_D'), ovmod.TRI_FIXED_D)
    # 绘制位置 = tri_center(kf, tri, TRI_FIXED_D)，与 rec['d'] 无关
    draw_u = hd.tri_center(r14u['kf_screen'], hd.TRI_UP, ovmod.TRI_FIXED_D)
    # 人为改 d（模拟疏密变化），绘制位置应不变
    fake = dict(r14u); fake['d'] = r14u['d'] + 300.0
    draw_u2 = hd.tri_center(fake['kf_screen'], hd.TRI_UP, ovmod.TRI_FIXED_D)
    step("★ drawn triangle position independent of d (fixed)",
         draw_u == draw_u2, "%s vs %s" % (draw_u, draw_u2))

    # ---------------- ② 无虚线/标签 ----------------
    step("★ no baseline color constant (removed)", not hasattr(ovmod, 'BASELINE_COLOR'))
    step("★ no label constant (removed)", not hasattr(ovmod, 'LABEL_COLOR'))

    # ---------------- ③ 相对拖拽 ----------------
    over.stop()
    over.start(session=None)      # = path_point_drag

    def first_dist(kf_frame=14):
        for fc in xf._position_curves(act, obj, None):
            if fc.array_index == 0:
                X = [fc.evaluate(f) for f in range(1, 41)]
                i = kf_frame
                return abs(X[i] - X[i - 1])

    base = first_dist()
    _session.clear_speed_handle()
    # ⚠️ 用多选集合（selected_speed_handles 是路由/高亮的依据）
    _session.set_single_speed_handle(14.0, hd.TRI_DOWN)
    origin_d = pick(fresh(), 14.0, hd.TRI_DOWN)['d']
    _session.speed_drag_origin_d = origin_d
    _session.speed_drag_origins = {(14.0, hd.TRI_DOWN): origin_d}
    start = (600.0, 400.0)
    _session.speed_drag_origin_mouse = start
    _session.speed_drag_last_mouse = None
    _session.speed_drag_effective_px = 0.0
    _session.speed_drag_active = True
    # 向下拖 60px（下三角：往下 = 更疏）
    # ⚠️ 鼠标位置【按真实签名传入】，不要往 session 上塞：
    #    塞属性会掩盖"这个值到底从哪来"的错误（曾因此漏掉一个 AttributeError）。
    # ⚠️ 增量法：第一次调用只记起点，第二次才产生位移
    inter._apply_speed_from_drag(ctx, obj, start)
    inter._apply_speed_from_drag(ctx, obj, (600.0, 340.0))
    after = first_dist()
    step("★ relative drag DOWN -> sparser", after > base * 1.1,
         "%.6f -> %.6f (%.2fx)" % (base, after, after / base))

    # 三角绘制位置仍固定（不随值移动）
    r14d2 = pick(fresh(), 14.0, hd.TRI_DOWN)
    step("★ triangle stays at fixed offset after edit",
         abs(abs(r14d2['tri_screen'][1] - r14d2['kf_screen'][1]) - ovmod.TRI_FIXED_D) < 0.6,
         "offset=%.1f (fixed=%.1f)" % (
             abs(r14d2['tri_screen'][1] - r14d2['kf_screen'][1]), ovmod.TRI_FIXED_D))
    step("internal d DID change (值变了但外观没动)",
         abs(r14d2['d'] - origin_d) > 5.0,
         "d: %.1f -> %.1f" % (origin_d, r14d2['d']))

    # ---------------- ④ 路径段高亮 ----------------
    inter._update_speed_hover(ctx, obj, region, rv3d, r14u['kf_screen'])
    _hl = ovmod.get_segment_highlight()
    step("★ selected handle triggers segment highlight",
         _hl is not None and _hl[0] == 14.0 and _hl[1] == 'right',
         _hl)
    step("★ highlight carries direction flag (橙=疏 / 蓝=密)",
         _hl is not None and len(_hl) >= 4 and isinstance(_hl[3], bool),
         _hl and (_hl[3] if len(_hl) > 3 else None))
    _session.clear_speed_handle()
    inter._update_speed_hover(ctx, obj, region, rv3d, (5.0, 5.0))
    step("clearing selection clears highlight",
         ovmod.get_segment_highlight() is None, ovmod.get_segment_highlight())

    # ---------------- ⑤ 选中三角后按 G 走疏密模态 ----------------
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    sel = me._selected_speed_handle()
    step("_selected_speed_handle returns selection", sel == (14.0, hd.TRI_UP), sel)
    tgt = me._resolve_target_preferring_selection(ctx, obj, act, 5.0, 5.0)
    step("★ G-routing: resolve uses SELECTED tri (side=left, frame=14)",
         bool(tgt) and tgt['frame'] == 14.0 and tgt['side'] == 'left',
         tgt and (tgt['frame'], tgt['side']))
    _session.clear_speed_handle()
    step("no selection -> _selected_speed_handle None",
         me._selected_speed_handle() is None)

    # ---------------- ⑥ 无硬限制（拖很远也不封顶） ----------------
    o2, act2 = obj, act
    _session.selected_speed_frame = 14.0
    _session.selected_speed_tri = hd.TRI_DOWN
    _session.speed_drag_origin_d = td.CV_MID
    _session.speed_drag_origin_mouse = (600.0, 400.0)
    d_vals = []
    for px in (30, 90, 200, 600):
        # ⚠️ 每段重新起手（增量法：第一次只记起点）
        _session.speed_drag_last_mouse = None
        _session.speed_drag_effective_px = 0.0
        _session.speed_drag_origins = {(14.0, hd.TRI_DOWN): td.CV_MID}
        inter._apply_speed_from_drag(ctx, obj, (600.0, 400.0))
        w = inter._apply_speed_from_drag(ctx, obj, (600.0, 400.0 - px))
        d_vals.append(w)
    # 单调不增（最后触到 S_EPS 数值保护下限，那不是"手感限制"而是 dt>0 的保证）
    step("★ no hard limit: drag distance keeps decreasing s (monotone non-increasing)",
         all(d_vals[i] >= d_vals[i + 1] for i in range(len(d_vals) - 1))
         and d_vals[-1] < d_vals[0],
         " > ".join("%.5f" % v for v in d_vals if v))
    step("★ s goes below old floor 0.02", d_vals[-1] < 0.02, "s=%.6f" % d_vals[-1])

    _session.clear_speed_handle()
    over.stop()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("SPEED_HANDLE_CHECK_DONE")
os._exit(0)
