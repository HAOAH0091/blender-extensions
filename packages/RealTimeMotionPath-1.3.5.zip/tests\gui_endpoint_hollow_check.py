# -*- coding: utf-8 -*-
"""端点手柄「空心圆抓取点」验收（用户 2026-09-16 需求）

需求原文：
    "关于首尾端点手柄收缩到关键帧的情况，实际交互体验时用户每次想挪动首位关键帧点位置
     都会先拖动到手柄，有点影响体验，我希望可以在首尾关键帧点的左右放置空心原点，
     用户点击拖动空心原点时才是选中首尾帧的手柄，这样就不会误触了"

用户拍板（2026-09-16）：
    · 只做【内侧 2 个】（首帧右 / 末帧左）；外侧不画不抓
      （实测外侧手柄不参与任何曲线段，值分量/时间分量对曲线影响都是 0.00000000）
    · 偏移 = 屏幕水平 ±32px（2026-09-17 由 28 上调，见下）
    · 单击空心圆 = 选中；拖拽 = 手柄从 0 连续长出来；长出后空心圆消失

用户拍板（2026-09-17，方案 A）—— 修 code review 抓到的两个漏：
    · 【P1-1】判据不再限定首末帧：停顿/保持段的【中间帧】手柄长度同样为 0，
      误触是同一个根因 ⇒ 中间帧也走空心态
    · 【P1-2】两盘重叠 `[8,20]px` ⇒ 偏移 28→32、并给空心圆【独立】拾取半径 12
      （32 ≥ 关键帧盘 20 + 空心盘 12 ⇒ 相切不重叠）
    · `_endpoint_offset_px(side)` 简化为只按 side 定方向（背离关键帧中心）

覆盖：
  A. 外侧（首帧 left / 末帧 right）不登记、不画
  B. 内侧端点 -> 空心圆抓取点（hollow 标记）
  C. 抓取点与关键帧【屏幕错开】≈32px，方向正确（首帧向右 / 末帧向左）
  D. 中间帧在本场景（非零长度）行为不变；偏移函数只按 side 定方向
  E. ★ 核心：点关键帧中心【不再】命中端点（误触消除）；点空心圆才命中端点
  F. ★ 拖拽：从空心圆拖 -> 手柄从 0 连续长出来
     （★ 2026-09-17 语义变更：方向【锁到路径切向】、长度跟鼠标
      ⇒ 判据 = 合成模长增量恒定 + 各步方向一致；不再是"逐轴增量各自恒定"）
  G. 拖出长度后：hollow 消失、抓取点回到手柄末端
  P. ★★★ 方案 A 核心：停顿段【中间帧】长度为 0 的一侧也走空心态；
     点中间帧中心不被抢；关键帧盘内 7 点扫描全不被抢；
     独立半径 12 生效（距圆心 15px 不命中）★ 含不变式断言
  H. 单关键帧场景（首=末）-> 两侧都算外侧 -> 不画不抓
  I. 登记抓取点【不改变数据】（路径几何不受影响）
  J. 静态契约（含 P1-1/P1-2 的 4 项新契约：J5b/J7b/J11/J12）

用法：blender --background --factory-startup --python tests/gui_endpoint_hollow_check.py
"""
import bpy, os, sys, json, traceback, mathutils
import math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_eh_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())


try:
    # ⚠️ headless 下 GPU 未初始化 -> render_path_overlay 会静默抛异常
    import gpu as _gpu
    _gpu.init()

    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")

    from bpy_extras import view3d_utils
    from RealTimeMotionPath import drawing as dw
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import cache as rcache
    from RealTimeMotionPath import overlay as ovmod
    from RealTimeMotionPath.state import _session

    KFS4 = [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
            (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]

    def build(kfs):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in kfs:
            sc.frame_set(f); o.location = loc
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
            fc.update()
        return o, a

    win = bpy.context.window_manager.windows[0]
    area = next(x for x in win.screen.areas if x.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((5, 0, 0)); rv3d.view_distance = 18.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    wm.rtmp_path_display_enabled = True
    rcache.refresh_position_store(bpy.context)
    ovmod.get_overlay().start(session=None)

    def real_render():
        ovr = {"window": win, "screen": win.screen, "area": area,
               "region": region, "space_data": area.spaces.active}
        with bpy.context.temp_override(**ovr):
            dw.render_path_overlay()

    def collect():
        real_render()
        return list(_session.handle_control_points)

    def screen_of(world_pos):
        return view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)

    def find(pts, frame, side):
        for p in pts:
            if abs(p["frame"] - frame) < 1e-3 and p["side"] == side:
                return p
        return None

    def select_all_keyframes(a_):
        """手柄只在「关键帧被选中」时渲染 —— 选中端点会清掉关键帧选中（两者互斥），
        所以每次要收集手柄前都得先把关键帧选回来。"""
        for fc in xf._position_curves(a_, None, None):
            for kp in fc.keyframe_points:
                kp.select_control_point = True
            fc.update()
        rcache.refresh_position_store(bpy.context)

    # =========================================================
    # 渲染（需选中，手柄才出现 —— 现状的显示条件）
    # =========================================================
    o, act = build(KFS4)
    _session.clear_endpoints(); _session.clear_speed_handle()
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True
        fc.update()
    rcache.refresh_position_store(bpy.context)
    pts = collect()

    # ---------- A. 外侧不画不抓 ----------
    step("A1 首帧 left（外侧）**不登记**", find(pts, 1, "left") is None,
         "f1.left = %r" % (find(pts, 1, "left"),))
    step("A2 末帧 right（外侧）**不登记**", find(pts, 40, "right") is None,
         "f40.right = %r" % (find(pts, 40, "right"),))
    step("A3 总抓取点数 = 6（4 关键帧：1 + 2 + 2 + 1）", len(pts) == 6, len(pts))

    # ---------- B. 内侧端点 = 空心圆 ----------
    p1r = find(pts, 1, "right")
    p40l = find(pts, 40, "left")
    step("B1 首帧 right（内侧）被登记且标记 hollow", p1r is not None and p1r.get("hollow") is True,
         p1r)
    step("B2 末帧 left（内侧）被登记且标记 hollow", p40l is not None and p40l.get("hollow") is True,
         p40l)

    # ---------- C. 屏幕错开 ----------
    if p1r and p40l:
        base = {}
        for f in (1, 40):
            e = next((p for p in [p1r if f == 1 else p40l]), None)
            d = next((p for p in pts if p["frame"] == f and p["side"] in ("left", "right")), None)
            base[f] = d
        # 关键帧点的世界位置 = 缓存里的点
        kf_world = {}
        for f in (1, 40):
            kf_world[f] = _session.cached_positions["T"][None][f]["position"]
        s_kf1 = screen_of(kf_world[1])
        s_kf40 = screen_of(kf_world[40])
        s_p1r = screen_of(p1r["position"])
        s_p40l = screen_of(p40l["position"])
        if s_kf1 and s_p1r and s_kf40 and s_p40l:
            dx1 = s_p1r.x - s_kf1.x
            dy1 = s_p1r.y - s_kf1.y
            dx40 = s_p40l.x - s_kf40.x
            dy40 = s_p40l.y - s_kf40.y
            step("C1 首帧空心圆在关键帧【右侧】≈+28px",
                 abs(dx1 - dw.ENDPOINT_PICK_OFFSET_PX) < 1.5 and abs(dy1) < 1.5,
                 "dx=%.3f dy=%.3f（期望 +%.1f, 0）" % (dx1, dy1, dw.ENDPOINT_PICK_OFFSET_PX))
            step("C2 末帧空心圆在关键帧【左侧】≈-28px",
                 abs(dx40 + dw.ENDPOINT_PICK_OFFSET_PX) < 1.5 and abs(dy40) < 1.5,
                 "dx=%.3f dy=%.3f（期望 -%.1f, 0）" % (dx40, dy40, dw.ENDPOINT_PICK_OFFSET_PX))
            step("C3 空心圆与关键帧的屏幕距离 > 拾取半径（不重叠，才不误触）",
                 abs(dx1) > 20.0 and abs(dx40) > 20.0,
                 "|dx1|=%.2f |dx40|=%.2f  拾取半径=20" % (abs(dx1), abs(dx40)))

    # ---------- D. 中间帧不受影响 ----------
    step("D1 中帧 f14 两侧都登记", find(pts, 14, "left") is not None and find(pts, 14, "right") is not None,
         "f14 left=%r right=%r" % (find(pts, 14, "left") is not None, find(pts, 14, "right") is not None))
    step("D2 中帧两侧都【不是】空心态",
         not find(pts, 14, "left").get("hollow") and not find(pts, 14, "right").get("hollow"),
         "")
    # ⚠️ 注意：中帧手柄本来就有非零长度（FREE 保留 AUTO_CLAMPED 算出的位置），
    #    所以它的抓取点在"手柄末端"，不在关键帧上 —— 这是【正常】的。
    #    （"中帧手柄长度为 0" 的情形由下面的 P 段用【停顿段】场景专门覆盖）
    step("D3 偏移函数只按 side 定方向 —— 与帧位置无关（方案 A，2026-09-17）",
         dw._endpoint_offset_px("right") == 32.0
         and dw._endpoint_offset_px("left") == -32.0,
         "%r / %r" % (dw._endpoint_offset_px("right"), dw._endpoint_offset_px("left")))
    step("D4 偏移方向 = 【背离】关键帧中心（right 正 / left 负）",
         dw._endpoint_offset_px("right") > 0 > dw._endpoint_offset_px("left"),
         "")

    # =========================================================
    # E. ★ 核心：误触消除
    # =========================================================
    def click(x, y, shift=False):
        class Ev:
            def __init__(self):
                self.type = 'LEFTMOUSE'; self.value = 'PRESS'
                self.mouse_region_x = x; self.mouse_region_y = y
                self.mouse_x = x + region.x; self.mouse_y = y + region.y
                self.shift = shift; self.ctrl = False; self.alt = False
        class FO:
            def report(self, *a, **k): pass
        _cls = inter.RTMP_OT_PathPointDrag
        if not getattr(FO, "_patched", False):
            for _nm in dir(_cls):
                if _nm.startswith("__"): continue
                _v = getattr(_cls, _nm, None)
                if callable(_v):
                    try: setattr(FO, _nm, _v.__get__(FO()))
                    except Exception: pass
                elif not isinstance(_v, property):
                    try: setattr(FO, _nm, _v)
                    except Exception: pass
            FO._mouse_pos = None; FO._is_active = True
            FO._timer = None; FO._last_frame = None; FO._patched = True
        return inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context, Ev())

    ovr = {"window": win, "screen": win.screen, "area": area,
           "region": region, "space_data": area.spaces.active}
    with bpy.context.temp_override(**ovr):
        # E1: 点【关键帧中心】不应命中端点
        _session.clear_endpoints()
        _session.active_frame_number = None
        s_c = screen_of(_session.cached_positions["T"][None][1]["position"])
        click(s_c.x, s_c.y)
        step("E1 ★ 点关键帧中心 -> 【不】选中端点（误触消除）",
             not _session.selected_handle_endpoints,
             "选中端点=%r" % (_session.selected_handle_endpoints,))
        step("E2 ★ 点关键帧中心 -> 落到【关键帧】上",
             _session.active_frame_number is not None,
             "active_frame_number=%r" % (_session.active_frame_number,))

        # E3: 点空心圆 -> 命中端点
        _session.clear_endpoints()
        real_render()
        pts3 = list(_session.handle_control_points)
        p1r3 = find(pts3, 1, "right")
        s_h = screen_of(p1r3["position"])
        click(s_h.x, s_h.y)
        step("E3 ★ 点空心圆 -> 选中端点 (1,'right')",
             _session.is_endpoint_selected(1, "right") is True,
             "选中=%r" % (_session.selected_handle_endpoints,))

        # E4: 末帧同理
        # ⚠️ E3 的点击会【清掉关键帧选中】（端点与关键帧选中互斥，与原生一致），
        #    而手柄只在"关键帧被选中"时渲染 ⇒ 这里要先把关键帧选回来。
        _session.clear_endpoints()
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.select_control_point = True
            fc.update()
        rcache.refresh_position_store(bpy.context)
        real_render()
        pts4 = list(_session.handle_control_points)
        p40l4 = find(pts4, 40, "left")
        s_h40 = screen_of(p40l4["position"])
        click(s_h40.x, s_h40.y)
        step("E4 ★ 点末帧空心圆 -> 选中端点 (40,'left')",
             _session.is_endpoint_selected(40, "left") is True,
             "选中=%r" % (_session.selected_handle_endpoints,))

        # =========================================================
        # F. ★ 拖拽：手柄从 0 连续长出来
        # =========================================================
        _session.clear_endpoints()
        _session.speed_drag_active = False
        _session.handle_edit_in_progress = False
        # ⚠️ 必须清 drag_in_progress —— E2（点关键帧中心）会把它置 True，
        #    残留的话 MOUSEMOVE 会走"关键帧拖动"分支，而不是端点拖动分支。
        _session.drag_in_progress = False
        _session.active_path_point = None
        # 把端点右手柄的 (t,v) 都摆回关键帧上（长度 0）—— 回到"未拖过"的初始态
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                kp.handle_right[1] = kp.co[1]
                kp.handle_right[0] = kp.co[0]
            fc.update()
        select_all_keyframes(act)
        real_render()
        pts5 = list(_session.handle_control_points)
        p1r5 = find(pts5, 1, "right")
        s_p = screen_of(p1r5["position"])

        # 按下（真入口）
        click(s_p.x, s_p.y)
        v_after_press = [float(kp.handle_right[1]) - float(kp.co[1])
                         for fc in xf._position_curves(act, o, None) for kp in fc.keyframe_points
                         if abs(kp.co[0] - 1) < 1e-3]
        step("F1 按下瞬间手柄值偏移仍为 0（不跳）",
             all(abs(v) < 1e-6 for v in v_after_press), v_after_press)

        class EvM:
            def __init__(self, x, y):
                self.type = 'MOUSEMOVE'; self.value = 'NOTHING'
                self.mouse_region_x = x; self.mouse_region_y = y
                self.mouse_x = x + region.x; self.mouse_y = y + region.y
                self.shift = False; self.ctrl = False; self.alt = False
        # Blender operator 不能直接实例化；把【全部】方法绑到普通对象上，
        # 免得漏绑某个 helper（modal 会调到 prepare_handles_for_edit / apply_point_offset 等）。
        import types as _t
        op = _t.SimpleNamespace()
        for _nm in dir(inter.RTMP_OT_PathPointDrag):
            if _nm.startswith("__"):
                continue
            _fn = getattr(inter.RTMP_OT_PathPointDrag, _nm, None)
            if callable(_fn):
                try:
                    setattr(op, _nm, _t.MethodType(_fn, op))
                except Exception:
                    pass
        op._is_active = True; op._mouse_pos = None
        op._last_draw_time = 0.0; op._timer = None; op._last_frame = None

        def axis_vals():
            """{array_index: 该轴右手柄的值偏移}"""
            out = {}
            for fc in xf._position_curves(act, o, None):
                for kp in fc.keyframe_points:
                    if abs(kp.co[0] - 1) < 1e-3:
                        out[fc.array_index] = round(float(kp.handle_right[1]) - float(kp.co[1]), 6)
            return out

        rec = []
        for i in range(1, 6):
            op._last_draw_time = 0.0
            inter.RTMP_OT_PathPointDrag.modal(op, bpy.context, EvM(s_p.x + i * 20, s_p.y - i * 8))
            rec.append(axis_vals())

        axes = sorted(rec[0].keys())
        # ⚠️ 拖拽的是【世界位移向量】，三轴分量本来就不同（甚至可能为负）⇒
        #    不能要求"三轴相等"，要【逐轴】按绝对值检查单调。
        mono = all(all(abs(rec[i][a]) >= abs(rec[i - 1][a]) - 1e-9
                       for i in range(1, len(rec))) for a in axes)
        grew = any(abs(rec[-1][a]) > 1e-6 for a in axes)
        step("F2 拖拽中每个轴都【绝对值单调不减】且总体确实在长（从 0 长出来）",
             mono and grew, rec)

        # ★★ 2026-09-17 **语义变更**（用户拍板：端点手柄拖出来要与路径「相切」）：
        #    零长端点手柄拖出时**方向锁到该点路径切向**、长度 = 鼠标位移模长
        #    ⇒ 逐轴分量**不再** ∝ 鼠标位移的逐轴分量（某个轴的分量可能恒为 0，
        #      实测这里轴 2 就是"无位移"）。
        #    ⇒ 判据从「每轴增量各自恒定」改为：
        #       ① **合成模长**增量恒定（线性、无死区、无台阶）
        #       ② 各步**方向一致**（= 方向被锁定，这是新语义的核心）
        #    ⚠️ 容差：headless 下 `region_2d_to_location_3d` 走 float32 透视矩阵，
        #       实测每步增量有 ~0.5%~1.5% 浮点噪声（不随步数累积 —— 因为
        #       `handle = 按下初始值 + 绝对位移`，不是累加式）⇒ 判"相对偏差 < 5%"。
        lens = [math.sqrt(sum(rec[i][a] ** 2 for a in axes)) for i in range(len(rec))]
        dl = [lens[i] - lens[i - 1] for i in range(1, len(lens))]
        rel = {}
        ok_rel = False
        amax = max(abs(v) for v in dl) if dl else 0.0
        if amax < 1e-9:
            rel = "无位移"
        else:
            r = (amax - min(abs(v) for v in dl)) / amax
            rel["模长相对偏差"] = round(r, 5)
            ok_rel = r < 0.05

        dirs = []
        for i in range(len(rec)):
            v = [rec[i][a] for a in axes]
            n = math.sqrt(sum(x * x for x in v))
            if n > 1e-9:
                dirs.append([x / n for x in v])
        dir_dev = 0.0
        if len(dirs) >= 2:
            for d in dirs[1:]:
                dir_dev = max(dir_dev, max(abs(d[k] - dirs[0][k]) for k in range(len(axes))))
        dir_locked = len(dirs) >= 2 and dir_dev < 1e-3
        rel["方向最大偏差"] = round(dir_dev, 6)
        step("F3 ★ 合成模长增量恒定（<5%）+ 各步方向锁定（= 锁切线的新语义）",
             ok_rel and dir_locked, rel)

    # ---------- G. 长出长度后：hollow 消失 ----------
    select_all_keyframes(act)
    real_render()
    pts6 = list(_session.handle_control_points)
    p1r6 = find(pts6, 1, "right")
    step("G1 手柄长出长度后，抓取点【不再是】空心态",
         p1r6 is not None and not p1r6.get("hollow"), p1r6)
    step("G2 抓取点回到【手柄末端】（不再是偏移位置）",
         p1r6 is not None and (screen_of(p1r6["position"]) -
                               screen_of(_session.cached_positions["T"][None][1]["position"])).length > 5.0,
         "")

    # =========================================================
    # P. ★★★ 方案 A 核心（2026-09-17 用户拍板）
    #    停顿/保持段：相邻关键帧值相同 ⇒ 朝该段的【手柄长度 = 0】
    #    ⇒ 与端点误触【同一个根因】，只是发生在中间帧。
    #    场景 f14(3,0,0) == f27(3,0,0)：f14→f27 是停顿段
    #      ⇒ f14.right / f27.left 手柄长度为 0（应走空心态）
    #      ⇒ f14.left  / f27.right 长度非零（应走常规）
    # =========================================================
    from RealTimeMotionPath.state import HANDLE_ZERO_EPS
    KFS_STALL = [(1, (0.0, 0.0, 0.0)), (14, (3.0, 0.0, 0.0)),
                 (27, (3.0, 0.0, 0.0)), (40, (6.0, 0.0, 0.0))]
    oS, actS = build(KFS_STALL)
    _session.clear_endpoints(); _session.clear_speed_handle()
    _session.drag_in_progress = False
    _session.active_path_point = None
    _session.active_frame_number = None
    select_all_keyframes(actS)
    ptsP = collect()

    def _vec_len(frame, side):
        """该帧该侧手柄的【未乘-scale】值偏移（各轴取最大）。"""
        best = 0.0
        for fc in xf._position_curves(actS, oS, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    h = kp.handle_right if side == "right" else kp.handle_left
                    best = max(best, abs(float(h[1]) - float(kp.co[1])))
        return best

    step("P0 前提：停顿段确实让 f14.right / f27.left 的手柄长度 = 0",
         _vec_len(14, "right") <= HANDLE_ZERO_EPS and _vec_len(27, "left") <= HANDLE_ZERO_EPS,
         "f14.right=%r  f27.left=%r" % (_vec_len(14, "right"), _vec_len(27, "left")))

    p14r = find(ptsP, 14, "right")
    p27l = find(ptsP, 27, "left")
    step("P1 ★ 中间帧【长度为 0】的一侧也登记为空心态（方案 A 放宽判据）",
         p14r is not None and p14r.get("hollow") is True
         and p27l is not None and p27l.get("hollow") is True,
         "f14.right=%r  f27.left=%r" % (p14r, p27l))
    # ★ 不变式（比"猜哪一侧是 0"更强，且不依赖对 Blender 手柄算法的假设）：
    #   登记点的 hollow 标记必须与【该侧实测的未乘-scale 手柄长度】一致，
    #   与帧是不是首/末帧无关。
    #   实测本场景：X 轴被 AUTO_CLAMPED 在平台段压平（防过冲），Y/Z 轴恒 0
    #   ⇒ f14/f27 的【两侧】长度都是 0 ⇒ 两侧都该是空心态。
    def _hollow_of(frame, side):
        p = find(ptsP, frame, side)
        return None if p is None else bool(p.get("hollow"))

    _chk = []
    _ok = True
    for (_f, _s) in ((1, "right"), (14, "left"), (14, "right"),
                     (27, "left"), (27, "right"), (40, "left")):
        _h = _hollow_of(_f, _s)
        if _h is None:
            _ok = False; _chk.append((_f, _s, "未登记")); continue
        _L = _vec_len(_f, _s)
        if (_L <= HANDLE_ZERO_EPS) != _h:
            _ok = False
        _chk.append((_f, _s, round(_L, 6), _h))
    step("P2 ★★ 不变式：每个登记点的 hollow 标记 == (该侧实测手柄长度 ≤ 阈值)", _ok, _chk)

    # ★★ 一致性不变式（2026-09-17 口径改屏幕像素后新增）：
    #    登记点的 hollow 标记必须与【共享判据】handle_is_zero_length() 的返回一致 ——
    #    防止绘制侧又冒出第二份判据（这正是"两边判据漂移 ⇒ 打架"的根源）。
    def _zero_flag(frame, side):
        kf_w = _session.cached_positions["T"][None][frame]["position"]
        vec = mathutils.Vector((0.0, 0.0, 0.0))
        for fc in xf._position_curves(actS, oS, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    h = kp.handle_right if side == "right" else kp.handle_left
                    vec[fc.array_index] = float(h[1]) - float(kp.co[1])
        with bpy.context.temp_override(**ovr):
            return dw.handle_is_zero_length(bpy.context, kf_w, vec,
                                            wm.rtmp_handle_scale)

    _ok2, _chk2 = True, []
    for (_f, _s) in ((1, "right"), (14, "left"), (14, "right"),
                     (27, "left"), (27, "right"), (40, "left")):
        _h = _hollow_of(_f, _s)
        _z = _zero_flag(_f, _s)
        if _h is None or _z is None:
            _ok2 = False; _chk2.append((_f, _s, "未登记/无标记")); continue
        if bool(_h) != bool(_z):
            _ok2 = False
        _chk2.append((_f, _s, "hollow=%s" % _h, "judge=%s" % _z))
    step("P2b ★★ 一致性不变式：hollow 标记 == 共享判据 handle_is_zero_length()", _ok2, _chk2)

    if p14r is not None and p27l is not None:
        s_k14 = screen_of(_session.cached_positions["T"][None][14]["position"])
        s_h14 = screen_of(p14r["position"])
        s_h27 = screen_of(p27l["position"])
        step("P3 ★ 中间帧空心圆同样是关键帧水平 ±32px（右 + / 左 −）",
             abs((s_h14.x - s_k14.x) - 32.0) < 1.5 and abs(s_h14.y - s_k14.y) < 1.5
             and abs((s_h27.x - s_k14.x) + 32.0) < 1.5 and abs(s_h27.y - s_k14.y) < 1.5,
             "f14.right dx=%.2f  f27.left dx=%.2f" % (s_h14.x - s_k14.x, s_h27.x - s_k14.x))

    # ---- P4~P8：真入口点击验证（误触消除 + 独立半径） ----
    with bpy.context.temp_override(**ovr):
        def fresh():
            _session.clear_endpoints()
            _session.drag_in_progress = False
            _session.active_path_point = None
            _session.active_frame_number = None

        fresh()
        s_c14 = screen_of(_session.cached_positions["T"][None][14]["position"])
        click(s_c14.x, s_c14.y)
        step("P4 ★★ 点【停顿段中间帧】中心 -> 不选中端点（方案 A 修掉的那类误触）",
             not _session.selected_handle_endpoints,
             "选中端点=%r" % (_session.selected_handle_endpoints,))
        step("P5 ★ 点停顿段中间帧中心 -> 落到【关键帧】上",
             _session.active_frame_number is not None,
             "active_frame_number=%r" % (_session.active_frame_number,))

        # 沿水平方向扫描关键帧盘（半径 20）内的 7 个点 —— 全部不该被空心圆抢走
        hits = []
        for dx in (-16, -12, -8, 0, 8, 12, 16):
            fresh()
            click(s_c14.x + dx, s_c14.y)
            if _session.selected_handle_endpoints:
                hits.append(dx)
        step("P6 ★★ 关键帧盘内 7 个采样点【全部】不被手柄抢（重叠区已消除）",
             not hits, "被抢的 dx=%r（期望空）" % (hits,))

        # 空心圆仍可抓：距圆心 8px < 独立半径 12
        fresh(); select_all_keyframes(actS); collect()
        s_h = screen_of(find(list(_session.handle_control_points), 14, "right")["position"])
        click(s_h.x, s_h.y + 8)
        step("P7 ★ 点空心圆（距圆心 8px < 12px 盘）-> 选中端点 (14,'right')",
             _session.is_endpoint_selected(14, "right") is True,
             "选中=%r" % (_session.selected_handle_endpoints,))

        # ★ 区分 12px 与 20px：点距圆心 15px
        #   · 12px 独立盘 ⇒ 不命中（正确）
        #   · 20px 盘     ⇒ 会命中（回归）
        #   同时该点到关键帧中心 35.3px > 20 ⇒ 本就不该命中关键帧
        fresh(); select_all_keyframes(actS); collect()
        s_h3 = screen_of(find(list(_session.handle_control_points), 14, "right")["position"])
        click(s_h3.x, s_h3.y + 15)
        step("P8 ★★ 距空心圆心 15px（> 12 但 < 20）-> 不命中端点（证明独立半径生效）",
             not _session.selected_handle_endpoints,
             "选中端点=%r（若空心盘是 20px 会误命中）" % (_session.selected_handle_endpoints,))

    # =========================================================
    # Q. ★★★ 死区验收（2026-09-17 用户实测反馈）
    #    "中间帧手柄缩小至关键帧点处后，空心圆有时会不出现"
    #
    #    根因：判据原为【世界长度】<= HANDLE_ZERO_EPS(1e-4)，
    #          实测 1 世界单位 ≈ 49px ⇒ 1e-4 世界 ≈ **0.005px**
    #          ⇒ 用户用手拖出来的"很短"（屏幕上还有 1~20px）**永远够不到**
    #          ⇒ 死区：既不画圆环、抓取点又落回关键帧上（误触回归）。
    #    修法：判据改【屏幕像素】口径 HANDLE_ZERO_SCREEN_PX(6px)，
    #          且与交互侧共用 handle_is_zero_length()。
    # =========================================================
    from RealTimeMotionPath.state import HANDLE_ZERO_SCREEN_PX
    oQ, actQ = build(KFS4)
    _session.clear_endpoints(); _session.clear_speed_handle()
    _session.drag_in_progress = False
    _session.active_path_point = None
    _session.active_frame_number = None
    select_all_keyframes(actQ)
    collect()

    _kf14w = _session.cached_positions["T"][None][14]["position"]
    _s_a = screen_of(_kf14w)
    _s_b = screen_of(_kf14w + mathutils.Vector((1.0, 0.0, 0.0)))
    PX_PER_WORLD = (_s_b - _s_a).length
    step("Q0 ★ 钉死根因：旧判据 1e-4 世界单位换算到屏幕 ≈ 0.005px（用户够不到）",
         PX_PER_WORLD > 1.0 and HANDLE_ZERO_EPS * PX_PER_WORLD < 0.5,
         "1 世界=%.1fpx ⇒ 1e-4 世界=%.4fpx" % (PX_PER_WORLD, HANDLE_ZERO_EPS * PX_PER_WORLD))

    def set_f14_right_px(d_px):
        """把 f14.right 的手柄长度设成「屏幕上约 d_px」（scale=1，沿 +X 世界）。"""
        L = d_px / PX_PER_WORLD
        for fc in xf._position_curves(actQ, oQ, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - 14) < 1e-3:
                    kp.handle_right_type = 'FREE'
                    kp.handle_right[1] = kp.co[1] + (L if fc.array_index == 0 else 0.0)
            fc.update()
        return L

    def probe_px(d_px):
        set_f14_right_px(d_px)
        pts = collect()
        p = find(pts, 14, "right")
        return None if p is None else bool(p.get("hollow"))

    # Q1 ★ 核心：屏幕上只有零点几~几 px 的【极小非零】手柄，必须判空心态
    _q1 = []
    for d in (0.5, 1.0, 2.0, 4.0, 5.0):
        _q1.append((d, probe_px(d)))
    step("Q1 ★★★ 屏幕 0.5~5px 的【极小非零】手柄 -> 全部判空心态（本次 bug 场景）",
         all(h is True for _, h in _q1), _q1)

    # Q2 边界：阈值 6px 两侧
    _q2 = ((5.9, probe_px(5.9)), (6.1, probe_px(6.1)),
           (6.5, probe_px(6.5)), (8.0, probe_px(8.0)))
    step("Q2 ★ 边界：≤6px 判空心态 / >6px 走常规（阈值 HANDLE_ZERO_SCREEN_PX=%.1f）"
         % HANDLE_ZERO_SCREEN_PX,
         _q2[0][1] is True and _q2[1][1] is True and _q2[2][1] is False and _q2[3][1] is False,
         _q2)

    # Q3 屏幕上明显可见的手柄线（10/20px）不得被误判成零长度
    _q3 = ((10.0, probe_px(10.0)), (20.0, probe_px(20.0)))
    step("Q3 ★ 屏幕上明显可见的手柄（10/20px）走常规，不误判零长度",
         all(h is False for _, h in _q3), _q3)

    # Q4 ★ 尺度自适应：同样【数据长度】，handle_scale 调小后屏幕变短 ⇒ 应判空心态
    #    （世界长度判据没有这个性质 —— 它跟 scale 无关）
    _L20 = set_f14_right_px(20.0)
    _h_before = probe_px(20.0)
    wm.rtmp_handle_scale = 0.2          # 屏幕上变成 20*0.2 = 4px
    _pts4 = collect()
    _p4 = find(_pts4, 14, "right")
    _h_after = None if _p4 is None else bool(_p4.get("hollow"))
    wm.rtmp_handle_scale = 1.0
    step("Q4 ★★ 尺度自适应：数据长度不变、scale 0.2 使屏幕 20px→4px ⇒ 转为空心态",
         _h_before is False and _h_after is True,
         "scale=1 时 hollow=%s ; scale=0.2 时 hollow=%s（数据长度 %.6f 未变）"
         % (_h_before, _h_after, _L20))

    # Q5 ★★ 交互侧互补（真入口）：数据非零但屏幕上只有 3px 的手柄，
    #    点关键帧中心【不得】选中端点（否则说明几何守卫没跟着口径走）
    #    ⚠️ 必须同时看 `active_handle_direction`：
    #      点击链路是【两条路】——
    #        ① `get_handle_at_cursor` 遍历 handle_control_points（圆环抓取点在这条）
    #        ② 没中 ⇒ `locate_handle_under_cursor` 几何命中「手柄线」，设 active_handle_direction
    #        ③ 再没中 ⇒ `locate_point_under_cursor` 命中关键帧，把 direction 置 None
    #      只看 selected_handle_endpoints 会漏掉 ②（②设的是别的状态）——
    #      bug 注入实测：交互侧守卫退回旧口径时，②会把 3px 手柄当成"有长度的线"抓走。
    with bpy.context.temp_override(**ovr):
        _session.clear_endpoints()
        _session.drag_in_progress = False
        _session.active_path_point = None
        _session.active_frame_number = None
        _session.active_handle_direction = None
        set_f14_right_px(3.0)
        collect()
        select_all_keyframes(actQ)
        collect()
        _s_c14 = screen_of(_session.cached_positions["T"][None][14]["position"])
        click(_s_c14.x, _s_c14.y)
        _sel_after = list(_session.selected_handle_endpoints)
        _dir_after = _session.active_handle_direction
    step("Q5 ★★ 数据非零但屏幕仅 3px 的手柄：点关键帧中心 -> 既不选端点、也不抓手柄线",
         (not _sel_after) and _dir_after is None,
         "选中端点=%r ; active_handle_direction=%r（非 None 说明被手柄线路径抢走）"
         % (_sel_after, _dir_after))

    # Q6 静态契约：绘制侧只有【一处】判据、且用共享函数；无裸的世界长度判据
    _src_now = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "..", "drawing.py"), encoding="utf-8").read()
    _isrc_now = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "..", "interaction.py"), encoding="utf-8").read()
    step("Q6 ★ 静态契约：drawing 判据 = handle_is_zero_length()（唯一调用点）",
         _src_now.count("handle_is_zero_length(context, point_3d, wvec") == 1
         and "if wvec.length <= HANDLE_ZERO_EPS:" not in _src_now,
         "")
    step("Q7 ★ 静态契约：interaction 几何守卫 = not handle_is_zero_length()×2，无裸判据",
         _isrc_now.count("not handle_is_zero_length(") == 2
         and "length > HANDLE_ZERO_EPS" not in _isrc_now,
         "")

    # =========================================================
    # R. ★★★ 「视觉零」场景【不该改手柄类型】（2026-09-17 用户实测反馈）
    #
    #    现象：ALIGNED 手柄缩到关键帧点（出现空心圆）后，拖空心圆，
    #          手柄类型变成 FREE。
    #    根因：同一个语义「手柄长度是否为零」有【两份判据、口径差 6 个数量级】——
    #          · 空心圆判据 = 屏幕 6px（HANDLE_ZERO_SCREEN_PX）
    #          · 封口闸门   = 世界 1e-9（xf._ARM_EPS）
    #          用户把两侧缩到关键帧点（长度 ~1e-3 世界 = 0.05px）落在两者之间：
    #          空心圆出现 ✓，一拖却触发封口 ⇒ 对侧 ALIGNED → FREE ✗
    #    修法：把「视觉零」的【世界】阈值换算好传给封口闸门（world_eps_for_screen）。
    # =========================================================
    from RealTimeMotionPath.state import HANDLE_ZERO_SCREEN_PX as _HZSP2
    from RealTimeMotionPath import transform_domain as _xf

    def _kfs(o_, a_, frame):
        m = {}
        for fc in _xf._position_curves(a_, o_, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    m[fc.array_index] = kp
        return m

    def _types(o_, a_, frame):
        return sorted(set((str(k.handle_left_type), str(k.handle_right_type))
                          for k in _kfs(o_, a_, frame).values()))

    def _set_visual_zero(o_, a_, frame, L, t='ALIGNED'):
        """两侧手柄长度都设成 L（值偏移），类型设成 t。每次重新取 kp。"""
        for fc in _xf._position_curves(a_, o_, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    kp.handle_left_type = 'FREE'
                    kp.handle_right_type = 'FREE'
        for fc in _xf._position_curves(a_, o_, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    kp.handle_left[1] = kp.co[1] - L
                    kp.handle_right[1] = kp.co[1] + L
        for fc in _xf._position_curves(a_, o_, None):
            fc.update()
        for fc in _xf._position_curves(a_, o_, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    kp.handle_left_type = t
                    kp.handle_right_type = t

    def _op(o_, a_, frame, side, hp_):
        class FO:
            def report(self, *x, **k):
                pass
        cls = inter.RTMP_OT_PathPointDrag
        for nm in dir(cls):
            if nm.startswith("__"):
                continue
            v = getattr(cls, nm, None)
            if callable(v):
                try:
                    setattr(FO, nm, v.__get__(FO()))
                except Exception:
                    pass
        fo = FO()
        with bpy.context.temp_override(**ovr):
            ctx = bpy.context
            bpy.context.view_layer.objects.active = o_
            inter._session.drag_target_object = o_.name
            fo.record_handle_baseline(ctx, frame, None, side)
            fo.apply_handle_point_offset(ctx, mathutils.Vector((0.5, 0.0, 0.0)), hp_)
            fo.apply_handle_point_offset(ctx, mathutils.Vector((0.5, 0.0, 0.0)), hp_)
        return fo

    def _drag_case(L):
        """构造两侧视觉零(长度 L)的 ALIGNED，拖空心圆，返回 (hollow, 拖前类型, 拖后类型)。"""
        o_, a_ = build(KFS4)
        _set_visual_zero(o_, a_, 14, L)
        _session.clear_endpoints(); _session.clear_speed_handle()
        _session.drag_in_progress = False
        for fc in _xf._position_curves(a_, o_, None):
            for kp in fc.keyframe_points:
                kp.select_control_point = True
            fc.update()
        rcache.refresh_position_store(bpy.context)
        pts_ = collect()
        hp_ = find(pts_, 14, "right")
        before = _types(o_, a_, 14)
        hollow = None if hp_ is None else bool(hp_.get("hollow"))
        if hp_ is not None:
            _op(o_, a_, 14, "right", hp_)
        return hollow, before, _types(o_, a_, 14)

    # R0 前提：本场景确实"空心圆出现 + 类型原本是 ALIGNED"
    _h0, _b0, _a0 = _drag_case(1e-3)
    step("R0 前提：两侧长度 1e-3 世界（屏幕 ≈0.05px）时空心圆出现、原类型 ALIGNED",
         _h0 is True and _b0 == [('ALIGNED', 'ALIGNED')],
         "hollow=%s 原类型=%s" % (_h0, _b0))

    # R1 ★★★ 核心：拖空心圆【不得】改类型
    step("R1 ★★★ 拖空心圆后类型仍为 ALIGNED（本 bug 的核心回归）",
         _a0 == [('ALIGNED', 'ALIGNED')],
         "拖后类型=%s（若含 FREE 说明封口闸门口径又没跟上）" % (_a0,))

    # R2 扫一列"视觉零"长度，全部保持类型
    _r2 = []
    _ok2 = True
    for _L in (0.0, 1e-9, 1e-8, 1e-6, 1e-4, 1e-3, 1e-2):
        _h, _b, _a = _drag_case(_L)
        if _h is not True or _a != _b:
            _ok2 = False
        _r2.append((_L, _h, _a))
    step("R2 ★★ 扫 L=0~1e-2（全在视觉零内）：空心圆出现 且 拖后类型不变", _ok2, _r2)

    # R3 换算 helper 行为：屏幕 6px 对应的世界阈值应远大于 _ARM_EPS
    oR, aR = build(KFS4)
    kf14w = None
    with bpy.context.temp_override(**ovr):
        kf14w = _session.cached_positions["T"][None][14]["position"] if _session.cached_positions else None
    if kf14w is None:
        kf14w = mathutils.Vector((3.0, 2.0, 0.0))
    with bpy.context.temp_override(**ovr):
        _we = dw.world_eps_for_screen(bpy.context, kf14w)
        _hpz = dw.handle_is_zero_length(bpy.context, kf14w,
                                        mathutils.Vector((1e-3, 0.0, 0.0)), 1.0)
    step("R3 ★ world_eps_for_screen 换算合理：远大于 _ARM_EPS(1e-9) 且 ≤ 1 世界单位",
         1e-9 < _we <= 1.0, "zero_eps=%.6g（屏幕 %.1fpx 对应）" % (_we, _HZSP2))
    step("R3b 与 handle_is_zero_length 语义一致：1e-3 世界判为「视觉零」", _hpz is True,
         "handle_is_zero_length(1e-3)=%s" % (_hpz,))
    step("R3c 明显可见的手柄（1 世界单位）不判视觉零", _hpz is True and
         dw.handle_is_zero_length(bpy.context, kf14w, mathutils.Vector((1.0, 0.0, 0.0)), 1.0) is False,
         "")

    # R4 静态契约：封口闸门已参数化 + interaction 传入换算值
    _src_td = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "transform_domain.py"), encoding="utf-8").read()
    _src_it = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "interaction.py"), encoding="utf-8").read()
    step("R4 ★ 静态契约：finish/maintain_linked_handle 都有 zero_eps 形参",
         "def finish_linked_handle(action, obj, snapshot, frame, moved_side,\n"
         "                         bone_name=None, weighted=True, zero_eps=_ARM_EPS)" in _src_td
         and "opp_len=None, weighted=True, zero_eps=_ARM_EPS)" in _src_td,
         "")
    step("R5 ★ 静态契约：封口闸门用 zero_eps（不再裸用 _ARM_EPS）",
         "if opp_len < zero_eps:" in _src_td
         and "if d.length < _ARM_EPS or opp_len < zero_eps:" in _src_td,
         "")
    step("R6 ★ 静态契约：interaction 用 world_eps_for_screen 换算后传入",
         "world_eps_for_screen" in _src_it and "zero_eps=zero_eps" in _src_it,
         "")

    # =========================================================
    # S. ★★★ 关键帧模态转 FREE 必须【登记】+ 体感类型【持久化】
    #    （2026-09-17 用户实测反馈）
    #
    #    用户路径：「选中关键帧 → 缩放使两侧手柄同时缩到关键帧点重合
    #              → 插件长出两个空心圆 → 拖一侧空心圆拉出手柄
    #              → 再拖另一侧拉出手柄 → 两根手柄【对不上】」
    #
    #    根因：关键帧模态的 `xf.make_handles_editable` 会把两侧手柄无条件转 FREE
    #          （为了能写入 —— 派生类型 AUTO_CLAMPED 不接受外部写入），
    #          但**没有登记** `_plugin_owned_free`，且 `confirm()` 不恢复类型
    #          （只有 `cancel()` 恢复）⇒ 手柄永久停在"未登记的 FREE"
    #          ⇒ `_link_mode` 判成"用户手动 FREE" ⇒ 对侧不联动。
    #    实测：漏登记 3D 共线偏差 0.6899；登记后 1.19e-07。
    #
    #    附带：登记原本是纯内存集合（键含 action 的**内存地址**）⇒
    #          重开文件全失效 ⇒ 体感类型丢失。现改为 action **名** + 持久化到
    #          `act["rtmp_owned_free"]`，打开文件时惰性恢复。
    # =========================================================

    def _pld3(o_, a_, frame):
        """三点 (hl, co, hr) 的 3D 共线偏差（co 到 hl→hr 直线的距离）。"""
        ks = _kfs(o_, a_, frame)
        if len(ks) < 3:
            return None
        hl = mathutils.Vector([ks[i].handle_left[1] for i in (0, 1, 2)])
        co = mathutils.Vector([ks[i].co[1] for i in (0, 1, 2)])
        hr = mathutils.Vector([ks[i].handle_right[1] for i in (0, 1, 2)])
        d = hr - hl
        if d.length < 1e-12:
            return 0.0
        t = (co - hl).dot(d) / d.dot(d)
        return (co - (hl + d * t)).length

    def _mk_editable(o_, a_, frame):
        fmap = {frame: {fc.array_index: fc
                        for fc in _xf._position_curves(a_, o_, None)}}
        return fmap, _xf.make_handles_editable(a_, o_, fmap, None)

    def _drag_side(o_, a_, frame, side, off):
        class FO:
            def report(self, *x, **k):
                pass
        cls = inter.RTMP_OT_PathPointDrag
        for nm in dir(cls):
            if nm.startswith("__"):
                continue
            v = getattr(cls, nm, None)
            if callable(v):
                try:
                    setattr(FO, nm, v.__get__(FO()))
                except Exception:
                    pass
        fo = FO()
        hp = {'frame': frame, 'side': side, 'position': mathutils.Vector((0, 0, 0))}
        with bpy.context.temp_override(**ovr):
            ctx = bpy.context
            bpy.context.view_layer.objects.active = o_
            inter._session.drag_target_object = o_.name
            _session.drag_in_progress = False
            _session.active_path_point = None
            _session.active_frame_number = None
            fo.record_handle_baseline(ctx, frame, None, side)
            fo.apply_handle_point_offset(ctx, off, hp)
            fo.apply_handle_point_offset(ctx, off, hp)

    # ---- 走用户路径 ----
    oS, aS = build(KFS4)
    _session.clear_endpoints(); _session.clear_speed_handle()
    _session.drag_in_progress = False
    _session.active_path_point = None
    _session.active_frame_number = None

    _fmapS, _prevS = _mk_editable(oS, aS, 14)
    step("S1 ★ 前提：关键帧模态 make_handles_editable 把两侧转成 FREE",
         _types(oS, aS, 14) == [('FREE', 'FREE')], _types(oS, aS, 14))

    _ks = _kfs(oS, aS, 14)
    _own = {s: bool(_xf._is_plugin_owned_free(_ks[0], s)) for s in ('left', 'right')}
    step("S2 ★★★ 转 FREE 的同时【登记为插件接管】（本次修复的核心）",
         _own['left'] and _own['right'], _own)

    _toks = [str(t) for t in _xf.owned_free_tokens(aS)]
    step("S3 ★ 登记已写入 action 的 custom property（持久化）",
         any('14.0000|left' == t for t in _toks) and any('14.0000|right' == t for t in _toks),
         _toks)

    # 缩到关键帧点（两侧长度 0）
    for fc in _xf._position_curves(aS, oS, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - 14) < 1e-3:
                kp.handle_left[1] = kp.co[1]
                kp.handle_right[1] = kp.co[1]
    for fc in _xf._position_curves(aS, oS, None):
        fc.update()

    # 拖一侧拉出手柄，再拖另一侧拉出
    _drag_side(oS, aS, 14, 'left', mathutils.Vector((0.9, 0.5, 0.2)))
    _lm = None
    if 0 in _kfs(oS, aS, 14):
        _lm = _xf._link_mode(_kfs(oS, aS, 14)[0], 'right')
    _drag_side(oS, aS, 14, 'right', mathutils.Vector((0.4, -0.7, 0.3)))
    _dev = _pld3(oS, aS, 14)

    step("S4 ★★ 拖右侧时对侧的联动判定 = 'link'（联动）", _lm == 'link', _lm)
    step("S5 ★★★ 两根手柄拉出后【对齐】（用户报的 bug 的直接判据）",
         _dev is not None and _dev < 1e-4,
         "3D 共线偏差=%.6e（>1e-4 即两根手柄对不上）" % (_dev or -1))

    # ---- 持久化：模拟"重开文件"（内存清空 -> 从 custom property 惰性恢复）----
    _xf._plugin_owned_free.clear()
    _xf._owned_warmed.clear()          # ★ 关键：连"已恢复"标记一起清，模拟新进程
    _ks2 = _kfs(oS, aS, 14)
    _restored = bool(_xf._is_plugin_owned_free(_ks2[0], 'left'))
    step("S6 ★★★ 模拟重开 Blender：内存清空后仍能从 action 恢复登记（体感类型不丢）",
         _restored, "恢复后 _is_plugin_owned_free(left)=%s" % _restored)

    # ---- unmark 配套：恢复类型时应移除登记 ----
    _xf.restore_handle_types(aS, oS, _fmapS, _prevS, None)
    _ks3 = _kfs(oS, aS, 14)
    _un = bool(_xf._is_plugin_owned_free(_ks3[0], 'left'))
    step("S7 ★ 类型被恢复时同步移除登记（防陈旧条目误联动）",
         _un is False, "_is_plugin_owned_free(left) after restore=%s（应为 False）" % _un)
    _toks2 = [str(t) for t in _xf.owned_free_tokens(aS)]
    step("S7b ★ custom property 里的对应条目也被移除",
         not any(t == '14.0000|left' for t in _toks2), _toks2)

    # ---- 静态契约 ----
    _src3 = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "..", "transform_domain.py"), encoding="utf-8").read()
    step("S8 ★ 静态契约：make_handles_editable 里调用了 mark_owned_free",
         "mark_owned_free(kp, 'left')" in _src3.split("def make_handles_editable")[1].split("\ndef ")[0],
         "")
    # ⚠️ 只看 return 语句（实际代码）—— docstring 里会提到 as_pointer 作为反例
    _ownkey_body = _src3.split("def _own_key")[1].split("\ndef ")[0]
    _ret_lines = [l.strip() for l in _ownkey_body.splitlines() if l.strip().startswith("return")]
    step("S9 ★★ 静态契约：_own_key 用 action【名】（跨会话稳定），不用 as_pointer（内存地址）",
         any("str(act.name)" in l for l in _ret_lines)
         and not any("as_pointer" in l for l in _ret_lines),
         _ret_lines)
    step("S10 ★ 静态契约：登记表有持久化 API（mark / unmark / warm / tokens）",
         all(s in _src3 for s in ("def mark_owned_free", "def unmark_owned_free",
                                  "def warm_owned_free", "def owned_free_tokens",
                                  "def clear_owned_free")),
         "")
    step("S11 ★ 静态契约：_is_plugin_owned_free 内做惰性恢复（warm）",
         "warm_owned_free(kp.id_data)" in _src3.split("def _is_plugin_owned_free")[1].split("\ndef ")[0],
         "")

    # ---------- H. 单关键帧：两侧都是外侧 ----------
    o2, act2 = build([(5, (0.0, 0.0, 0.0))])
    _session.clear_endpoints()
    for fc in xf._position_curves(act2, o2, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True
        fc.update()
    rcache.refresh_position_store(bpy.context)
    pts7 = collect()
    step("H1 只有 1 个关键帧（首=末）-> 两侧都算外侧 -> 不画不抓",
         len(pts7) == 0, len(pts7))

    # ---------- I. 不改变数据 ----------
    o3, act3 = build(KFS4)
    _session.clear_endpoints()
    for fc in xf._position_curves(act3, o3, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True
        fc.update()
    rcache.refresh_position_store(bpy.context)
    def snapshot(a_):
        out = []
        for fc in xf._position_curves(a_, None, None):
            out.extend([(round(float(kp.co[0]), 6), round(float(kp.co[1]), 6)) for kp in fc.keyframe_points])
        return sorted(out)
    before_s = snapshot(act3)
    collect()
    after_s = snapshot(act3)
    step("I1 渲染（登记空心圆抓取点）【不改动】任何关键帧数据",
         before_s == after_s, "一致" if before_s == after_s else "有差异")

    # ---------- J. 静态契约 ----------
    _src = open(os.path.join(REPO, "drawing.py"), encoding="utf-8").read()
    _isrc = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    step("J1 静态契约：存在「外侧跳过」逻辑",
         "_endpoint_is_hidden_side(is_first_keyframe, is_last_keyframe, side)" in _src, "")
    step("J2 静态契约：空心态不画手柄线（continue）",
         "continue          # ← 空心态不画手柄线" in _src, "")
    step("J3 静态契约：空心态抓取点带 hollow 标记",
         "'hollow': True," in _src, "")
    step("J4 静态契约：偏移常量 = 32px（方案 A）", dw.ENDPOINT_PICK_OFFSET_PX == 32.0,
         dw.ENDPOINT_PICK_OFFSET_PX)
    from RealTimeMotionPath.state import HANDLE_HOLLOW_PICK_RADIUS
    step("J5 ★ 静态契约：偏移 ≥ 关键帧盘(20) + 空心盘(12) ⇒ 两盘相切不重叠",
         dw.ENDPOINT_PICK_OFFSET_PX >= 20 + HANDLE_HOLLOW_PICK_RADIUS,
         "%s >= 20 + %s" % (dw.ENDPOINT_PICK_OFFSET_PX, HANDLE_HOLLOW_PICK_RADIUS))
    step("J5b ★ 静态契约：空心盘半径【严格小于】手柄盘半径（否则必然重叠）",
         HANDLE_HOLLOW_PICK_RADIUS < 20, "%s < 20" % HANDLE_HOLLOW_PICK_RADIUS)

    # ★★ 判据互补（code review 2026-09-16 发现并修复的问题）
    #    「手柄长度为 0」这个语义有两个使用者，必须共用同一个常量、方向相反：
    #      drawing：  length <= HANDLE_ZERO_EPS  -> 画空心圆抓取点
    #      interaction：length > HANDLE_ZERO_EPS -> 才做几何命中
    #    若两者阈值/基准不一致（例如一个乘了 handle_scale），就会出现
    #    "几何拾取不认它、空心态也不认它"的缝 ⇒ 抓取点落回关键帧 ⇒ 误触复现。
    from RealTimeMotionPath.state import HANDLE_ZERO_EPS
    step("J6 静态契约：HANDLE_ZERO_EPS 存在且为正",
         isinstance(HANDLE_ZERO_EPS, float) and HANDLE_ZERO_EPS > 0, HANDLE_ZERO_EPS)
    step("J7 ★ 静态契约：drawing 空心态判据 = 共享函数（屏幕像素口径），无裸世界长度判据",
         "if handle_is_zero_length(context, point_3d, wvec, global_scale):" in _src
         and "if wvec.length <= HANDLE_ZERO_EPS:" not in _src,
         "")
    step("J7b ★ 静态契约：判据【不再】限定首末帧（is_endpoint 已移除，方案 A）",
         "is_endpoint = bool(is_first_keyframe" not in _src and "if is_endpoint and" not in _src,
         "")
    step("J8 ★ 静态契约：interaction 几何守卫用同一函数（严格互补）",
         _isrc.count("not handle_is_zero_length(") == 2,
         "出现 %d 次（期望 2：left/right 各一）" % _isrc.count("not handle_is_zero_length("))
    from RealTimeMotionPath.state import HANDLE_ZERO_SCREEN_PX as _HZSP
    step("J8b ★ 静态契约：屏幕阈值 HANDLE_ZERO_SCREEN_PX 为正值（> 关键帧点半径 5px）",
         isinstance(_HZSP, float) and _HZSP >= 5.0,
         "%r（关键帧点默认半径 5px）" % (_HZSP,))
    step("J9 ★ 静态契约：不再有各自为政的 1e-4 / scaled_vec 判据",
         "> 1e-4" not in _isrc and "_ENDPOINT_ZERO_EPS" not in _src,
         "interaction 残留 '> 1e-4': %d ; drawing 残留 '_ENDPOINT_ZERO_EPS': %d"
         % (_isrc.count("> 1e-4"), _src.count("_ENDPOINT_ZERO_EPS")))
    # 行为验证：端点的未乘-scale 手柄向量长度确实 ≤ 阈值（所以走空心态）
    _endpoint_vec_len = None
    try:
        _a5 = act3 if 'act3' in dir() else act
        _o5 = o3 if 'o3' in dir() else o
        for _fc in xf._position_curves(_a5, _o5, None):
            for _kp in _fc.keyframe_points:
                if abs(_kp.co[0] - 1) < 1e-3:
                    _endpoint_vec_len = abs(float(_kp.handle_right[1]) - float(_kp.co[1]))
                    break
    except Exception:
        pass
    step("J10 行为：首帧右手柄的未乘-scale 长度 ≤ 阈值（⇒ 判 hollow）",
         _endpoint_vec_len is not None and _endpoint_vec_len <= HANDLE_ZERO_EPS,
         "len=%r  阈值=%r" % (_endpoint_vec_len, HANDLE_ZERO_EPS))

    # ★★ 独立拾取半径（方案 A / code review 2026-09-17）
    #    `get_handle_at_cursor` 若对空心点也用 20px，则与关键帧的 20px 盘
    #    必然重叠（圆心距仅 32px < 40）⇒ 点关键帧盘边缘仍被抢。
    step("J11 ★ 静态契约：get_handle_at_cursor 对 hollow 点用独立半径",
         "HANDLE_HOLLOW_PICK_RADIUS if handle_point.get('hollow') else HANDLE_SELECT_RADIUS" in _isrc,
         "")
    step("J12 ★ 静态契约：state 中 HANDLE_HOLLOW_PICK_RADIUS 为正且 < 20",
         isinstance(HANDLE_HOLLOW_PICK_RADIUS, int) and 0 < HANDLE_HOLLOW_PICK_RADIUS < 20,
         HANDLE_HOLLOW_PICK_RADIUS)

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-2500:])

flush()
print("EH_RESULT " + ("ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES"))
for s in steps:
    print(("[OK] " if s["ok"] else "[FAIL] ") + s["name"] + ("  :: " + s["detail"] if s["detail"] else ""))
try:
    bpy.ops.wm.quit_blender()
except Exception:
    pass
os._exit(0)
