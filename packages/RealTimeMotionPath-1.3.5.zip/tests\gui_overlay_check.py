# -*- coding: utf-8 -*-
"""视口覆盖层（轴约束线 + 关键帧标记）GUI 检查

用法：blender --factory-startup --python tests/gui_overlay_check.py

截图输出到 tests/_ov_*.png（供人工/vision 复核）。
"""
import bpy, os, sys, json, traceback, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_ov_result.json")

steps = []
def step(n, ok, d=""): steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    for f, loc in [(1, (0, 0, 0)), (14, (4, 0, 0)), (27, (8, 0, 0)), (40, (12, 0, 0))]:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    import RealTimeMotionPath as RTMP
    ov, me, xf = RTMP.overlay, RTMP.modal_edit, RTMP.transform_domain
    step("addon loaded from REPO",
         os.path.normcase(os.path.dirname(os.path.abspath(RTMP.__file__))) == os.path.normcase(REPO),
         RTMP.__file__)

    colors = ov.get_axis_colors()
    step("axis colors from theme", all(k in colors for k in "XYZ"), str(colors)[:90])

    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = (abs(kp.co[0] - 14) < 0.5)
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        pts = list(fc.keyframe_points)      # 匀速基线
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 18.0
    d = mathutils.Vector((1.0, -1.4, 0.8)).normalized()
    rv3d.view_rotation = (-d).to_track_quat('-Z', 'Y')
    sc.frame_set(14)
    bpy.context.view_layer.update()

    def shoot(name, label):
        # ⚠️ 整块都在 try 内 —— 原版把 `tag_redraw()` / `redraw_timer(DRAW_WIN_SWAP)`
        #    放在 try **外面**，而它们在 headless 下就会抛（后台没有真实窗口可交换帧缓冲）
        #    ⇒ 异常直接冒泡到顶层，整个测试以 FATAL 收场（后面的断言全没跑）。
        #    headless 下截图**只有 GUI 模式才有意义**（用途是"给人眼看轴约束线"），
        #    所以后台记 NOTE（不算失败），逻辑断言照常跑完。
        p = os.path.join(HERE, name)
        try:
            area.tag_redraw()
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=4)
            ovr = {"window": win, "screen": win.screen, "area": area, "region": region}
            with bpy.context.temp_override(**ovr):
                bpy.ops.screen.screenshot_area(filepath=p)
            step("shot " + label, os.path.exists(p), name)
        except Exception as e:
            if bpy.app.background:
                step("shot " + label + "（headless 跳过截图，仅 GUI 可截）", True,
                     "NOTE: " + repr(e)[:90])
            else:
                step("shot " + label, False, repr(e)[:100])

    # ---------------- 变换模态：轴约束线 ----------------
    s = me.MoveSession('MOVE')
    ok = s.begin(obj, act, region, rv3d, 600, 400)
    step("MOVE begin", ok is True, s.message)
    step("overlay inactive before start", ov._overlay.active is False, ov._overlay.active)
    step("overlay started", ov.start_overlay(s) and ov._overlay.active, ov._overlay.active)

    step("no lock -> no axes", ov.axes_for(None, None) == [], ov.axes_for(None, None))
    s.set_axis('X')
    step("lock X -> ['X']", ov.axes_for(s.axis_lock, s.plane_lock) == ['X'],
         ov.axes_for(s.axis_lock, s.plane_lock))
    shoot("_ov_x.png", "lock X")
    s.set_axis('Z')
    shoot("_ov_z.png", "lock Z")
    s.set_plane('X')
    step("plane (Shift+X) -> ['Y','Z']",
         sorted(ov.axes_for(s.axis_lock, s.plane_lock)) == ['Y', 'Z'],
         ov.axes_for(s.axis_lock, s.plane_lock))
    shoot("_ov_yz.png", "lock YZ plane")
    ov.stop_overlay()
    step("overlay stopped", ov._overlay.active is False, ov._overlay.active)

    # ---------------- SPEED 模态：关键帧倒三角标记 ----------------
    class C: pass
    c = C(); c.region = region; c.region_data = rv3d
    from bpy_extras import view3d_utils
    wp = me.keyframe_world_pos(act, obj, 14)
    sp = view3d_utils.location_3d_to_region_2d(region, rv3d, wp)
    step("f14 projects to screen", sp is not None, (round(sp.x,1), round(sp.y,1)) if sp else None)

    tgt = me.resolve_speed_target(c, obj, act, sp.x, sp.y - 25)
    step("target resolved (side right)", bool(tgt) and tgt["side"] == 'right', tgt and tgt["side"])
    # ⚠️ 必须校验【值】，不能只校验"非 None"。
    #    曾经这里只查非 None，结果漏掉了"world 拿到的是循环最后一次迭代的
    #    关键帧（f40 的 (12,0,0)）而不是匹配到的 f14 (4,0,0)"这个 bug。
    wgot = tgt.get("world") if tgt else None
    want = me.keyframe_world_pos(act, obj, 14)
    step("target world == f14 position (value check)",
         wgot is not None and want is not None
         and (wgot - want).length < 1e-6,
         "got=%s want=%s" % (
             tuple(round(v, 3) for v in wgot) if wgot else None,
             tuple(round(v, 3) for v in want) if want else None))

    sps = me.ModalSession('SPEED')
    ok = sps.begin(obj, act, sp.x, sp.y - 25,
                   lambda x, y: me.resolve_speed_target(c, obj, act, x, y))
    step("SPEED begin", ok is True, sps.message)
    step("SPEED has marker_world", sps.marker_world is not None, sps.marker_world)
    ov.start_overlay(sps)
    shoot("_ov_speed.png", "SPEED marker")
    ov.stop_overlay()

    # ---------------- draw 函数健壮性 ----------------
    try:
        ov.draw_axis_lines(s.pivot_world, ['X', 'Y', 'Z'], colors)
        ov.draw_triangle_2d(500.0, 400.0, 'down', ov.HANDLE_COLOR)   # ▼ 朝下（上三角）
        ov.draw_triangle_2d(500.0, 300.0, 'up', ov.HANDLE_COLOR)     # ▲ 朝上（下三角）
        step("draw functions run without raising", True)
    except Exception as e:
        step("draw functions run without raising", False, repr(e)[:120])
    # 空输入不应炸
    try:
        ov.draw_axis_lines(None, [], colors)
        ov.draw_axis_lines(None, ['X'], colors)
        step("draw functions tolerate empty input", True)
    except Exception as e:
        step("draw functions tolerate empty input", False, repr(e)[:120])

    # ---------------- 路径段高亮 API ----------------
    ov.clear_segment_highlight()
    step("segment highlight starts cleared", ov.get_segment_highlight() is None,
         ov.get_segment_highlight())
    ov.set_segment_highlight(14.0, 'right')
    _hl = ov.get_segment_highlight()
    # 现在存 3 元组 (frame, side, t)：t = 高亮要胀满多少（0=匀速, 1=到极值）
    step("set_segment_highlight stores (frame, side, t)",
         _hl is not None and _hl[0] == 14.0 and _hl[1] == 'right'
         and isinstance(_hl[2], float), _hl)
    ov.set_segment_highlight(None, None)
    step("set_segment_highlight(None) clears", ov.get_segment_highlight() is None)

    # 段帧区间（端点段应为 None）
    from RealTimeMotionPath.drawing import segment_frame_range
    rng = segment_frame_range(act, obj, 14.0, 'right')
    step("segment_frame_range(14, right) == (14, 27)", rng == (14.0, 27.0), rng)
    rng_l = segment_frame_range(act, obj, 14.0, 'left')
    step("segment_frame_range(14, left) == (1, 14)", rng_l == (1.0, 14.0), rng_l)
    step("segment_frame_range(1, left) == None (endpoint)",
         segment_frame_range(act, obj, 1.0, 'left') is None,
         segment_frame_range(act, obj, 1.0, 'left'))

except Exception:
    step("FATAL", False, traceback.format_exc()[-900:])

flush()
print("OVERLAY_CHECK_DONE")
os._exit(0)
