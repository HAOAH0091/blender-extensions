# -*- coding: utf-8 -*-
"""P2.1 验收：鼠标【直接拖手柄】路径的加权（覆盖缺口补齐）

═══ 背景（2026-09-16）═══
插件里手柄有**两条写入路径**：

  · 端点模态（选中端点按 G/R/S） → `apply_endpoint_transform`　**已接加权**（P2）
  · 鼠标直接拖手柄（点小圆点 / 拖手柄线）
        → `apply_handle_point_offset` / `_apply_handle_offset`
        → 老代码 `update_linked_handle` 只逐轴按 (t,v) 斜率写对侧的**值分量**，
          **没有加权** —— 这就是覆盖缺口。

═══ 实测（修复前，`_gap2.py`）═══
关键帧【不共线】+ 各轴手柄时间比例 λ **不同**（分歧场景）：

    | 路径        | 3D 点线距 | (t,v) 折角 | 对侧长度比 |
    |---|---:|---:|---:|
    | 初始状态    | 5.237     | 0°         | 1.000 |
    | 老鼠标路径  | **4.457**（几乎没修） | 0° | 0.973 |
    | 加权路径    | **0.0000** | 2.9e-6° | 1.000 |

⇒ 老路径在 λ 不一致时**修不动 3D 折角**，用户会看到折角。

═══ 本测试断言 ═══
  1. 鼠标路径的 3D 点线距 ≈ 0（消除折角）
  2. (t,v) 折角 ≈ 0（Graph Editor 干净）
  3. **对侧手柄 3D 长度守恒**（原生 ALIGNED「只旋转不缩放」）
  4. 被拖侧位移 = 拖动量、co 不动
  5. 鼠标路径与端点模态路径**结果一致**（两条路一个数学）

⚠️ 度量必须用【点到直线距离】，不能用夹角 —— `acos` 在 0 附近精度塌缩
   （float32 分辨率 1.19e-7 会把 1−1.7e-8 舍成 1−1.19e-7 → 反解出假偏差）。

⚠️ 场景必须【不共线】+【各轴 λ 不同】，否则退化、测不出问题
   （第一版探针两个坑都踩过，3D 点线距恒为 0，测试台自己喂了"没问题"）。

用法：blender --factory-startup --python tests/gui_mouse_drag_weight_check.py
"""
import os
import sys
import json
import math
import traceback

import bpy
import mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_mdw_result.json")

steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})


def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())


try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath.state import _session

    # ⚠️ 三个关键帧【不共线】
    P1 = mathutils.Vector((0.0, 0.0, 0.0))
    P20 = mathutils.Vector((4.0, 1.0, 0.5))
    P40 = mathutils.Vector((6.0, 6.0, 5.0))
    DT = mathutils.Vector((0.0, 3.0, 0.0))
    LABEL = "MouseDragWeight"

    def pt_line_dist(p, a, b):
        ab = b - a
        return 0.0 if ab.length < 1e-12 else (p - a).cross(ab).length / ab.length

    def tv_kink(a):
        mx = 0.0
        for axis, v in a.items():
            hl, co, hr = v['hl'], v['co'], v['hr']
            A = mathutils.Vector((co[0] - hl[0], co[1] - hl[1]))
            B = mathutils.Vector((hr[0] - hl[0], hr[1] - hl[1]))
            if A.length < 1e-12 or B.length < 1e-12:
                continue
            mx = max(mx, abs(A.cross(B) / (A.length * B.length)))
        return mx

    def build(uneven, htype='ALIGNED'):
        """uneven=True → 各轴 λ 不同（分歧场景），每轴自身仍严格 (t,v) 共线。

        ⚠️ htype=None 表示**不动类型**，保持 Blender 默认（= AUTO_CLAMPED）
           —— 这正是"新建工程"的真实状态。
        """
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = LABEL
        for f, v in zip((1, 20, 40), (P1, P20, P40)):
            sc.frame_set(f)
            o.location = tuple(v)
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        if htype is not None:
            for fc in xf._position_curves(a, o, None):
                for kp in fc.keyframe_points:
                    kp.handle_left_type = htype
                    kp.handle_right_type = htype
                fc.update()
        if uneven:
            spec = {0: (4.0, 4.0), 1: (6.0, 2.0), 2: (2.0, 6.0)}
            for fc in xf._position_curves(a, o, None):
                dtL, dtR = spec[fc.array_index]
                lam = dtL / (dtL + dtR)
                S = 8.0
                for kp in fc.keyframe_points:
                    if abs(kp.co[0] - 20.0) < 1e-3:
                        co_t, co_v = float(kp.co[0]), float(kp.co[1])
                        kp.handle_left = (co_t - dtL, co_v - lam * S)
                        kp.handle_right = (co_t + dtR, co_v + (1.0 - lam) * S)
                fc.update()
        return o, a

    def snap(o, a, frame=20.0):
        d = {}
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    d[fc.array_index] = dict(
                        co=(float(kp.co[0]), float(kp.co[1])),
                        hl=(float(kp.handle_left[0]), float(kp.handle_left[1])),
                        hr=(float(kp.handle_right[0]), float(kp.handle_right[1])),
                        hlt=str(kp.handle_left_type),
                        hrt=str(kp.handle_right_type))
        return d

    def v3(b, k):
        return mathutils.Vector([b[i][k][1] for i in sorted(b)])

    def dt_of(b, side):
        """某侧手柄的时间分量 dt = 手柄时间 − co 时间（各轴）。"""
        key = 'hl' if side == 'left' else 'hr'
        return [b[i][key][0] - b[i]['co'][0] for i in sorted(b)]

    def metrics(b0, a1, side='left'):
        mk = 'hl' if side == 'left' else 'hr'
        ok_ = 'hr' if side == 'left' else 'hl'
        co0, m0, o0 = v3(b0, 'co'), v3(b0, mk), v3(b0, ok_)
        co1, m1, o1 = v3(a1, 'co'), v3(a1, mk), v3(a1, ok_)
        d0, d1 = dt_of(b0, ok_), dt_of(a1, ok_)
        return {
            '3d': pt_line_dist(o1, co1, m1),
            'tv_deg': math.degrees(math.asin(min(1.0, tv_kink(a1)))),
            'opp_ratio': (o1 - co1).length / max(1e-12, (o0 - co0).length),
            'moved': (m1 - m0).length,
            'co_moved': (co1 - co0).length,
            # ★ 新契约核心：对侧 dt（= 速度分布）动没动
            'opp_dt_shift': max(abs(d1[i] - d0[i]) for i in range(len(d0))),
        }

    class FakeOp:
        pass

    for nm in dir(inter.RTMP_OT_PathPointDrag):
        if nm.startswith("__"):
            continue
        try:
            setattr(FakeOp, nm, getattr(inter.RTMP_OT_PathPointDrag, nm))
        except Exception:
            pass
    fo = FakeOp()

    def mouse_drag(uneven, side='left', use_baseline=True, htype='ALIGNED'):
        """走**真实入口**：record_handle_baseline（按下）→ apply_handle_point_offset（移动）。"""
        o, act = build(uneven, htype)
        b0 = snap(o, act)
        _session.selected_handle_endpoints = [(20.0, side)]
        _session.active_bone_identifier = None
        _session.active_frame_number = 20.0
        _session.active_handle_direction = side
        _session.drag_target_object = LABEL
        if use_baseline:
            fo.record_handle_baseline(bpy.context, 20.0, None, side)
        else:
            _session.handle_start_values = {}
            _session.endpoint_snapshot = {}
            for fc in xf._position_curves(act, o, None):
                for kp in fc.keyframe_points:
                    if abs(kp.co[0] - 20.0) < 1e-3:
                        h = kp.handle_left if side == 'left' else kp.handle_right
                        _session.handle_start_values[(20.0, fc.array_index)] = (
                            float(h[0]), float(h[1]))
                        break
        fo.apply_handle_point_offset(
            bpy.context, DT,
            {'frame': 20.0, 'side': side, 'bone_name': None,
             'position': mathutils.Vector((0, 0, 0))})
        return b0, snap(o, act)

    def modal_drag(uneven, side='left'):
        """参照：端点模态路径（P2 已接加权）。"""
        o, act = build(uneven)
        b0 = snap(o, act)
        sep = xf.snapshot_endpoints(act, o, [(20.0, side)], None)
        xf.apply_endpoint_transform(
            act, o, sep, (lambda f, v: v + DT), [(20.0, side)], None)
        return b0, snap(o, act)

    # ------------------------------------------------------------------
    # A/B. 鼠标路径：等 λ 与不等 λ
    # ------------------------------------------------------------------
    for uneven, tag in ((False, '等λ'), (True, '各轴λ不同')):
        b0, a1 = mouse_drag(uneven)
        m = metrics(b0, a1)
        step("★ 鼠标拖手柄 [%s] 3D 点线距 ≈ 0（无折角）" % tag,
             m['3d'] < 1e-5, "3D点线距=%.3e" % m['3d'])
        # ★★ 契约变更（第十轮）：不再要求 (t,v) 共线。
        #    用户拍板「3D 视图优先，Graph Editor 不需要共线」——
        #    改 dt 换 (t,v) 共线会把用户的速度分布抹掉，而对 3D 零收益。
        #    新契约：**对侧 dt 一个数不动**（= 速度分布保住）。
        step("★ 鼠标拖手柄 [%s] 对侧 dt【一个数不动】（速度分布保住）" % tag,
             m['opp_dt_shift'] < 1e-5,
             "对侧dt最大变化=%.3e  (t,v)折角=%.3e°（不再要求为0）"
             % (m['opp_dt_shift'], m['tv_deg']))
        step("★ 鼠标拖手柄 [%s] 对侧 3D 长度守恒（只旋转不缩放）" % tag,
             abs(m['opp_ratio'] - 1.0) < 1e-4, "长度比=%.6f" % m['opp_ratio'])
        step("★ 鼠标拖手柄 [%s] 被拖侧位移 = 拖动量、co 不动" % tag,
             abs(m['moved'] - DT.length) < 1e-4 and m['co_moved'] < 1e-6,
             "位移=%.6f(期望%.1f) co位移=%.3e"
             % (m['moved'], DT.length, m['co_moved']))

    # ------------------------------------------------------------------
    # C. 与端点模态路径【结果一致】（两条路一个数学）
    # ------------------------------------------------------------------
    for uneven, tag in ((False, '等λ'), (True, '各轴λ不同')):
        _, am = mouse_drag(uneven)
        _, ar = modal_drag(uneven)
        mm, mr = metrics(_, am), metrics(_, ar)
        same = (abs(mm['3d'] - mr['3d']) < 1e-5
                and abs(mm['opp_ratio'] - mr['opp_ratio']) < 1e-4)
        step("★ 鼠标路径 vs 端点模态路径 [%s] 结果一致" % tag, same,
             "鼠标(3D=%.3e 比=%.5f) 模态(3D=%.3e 比=%.5f)"
             % (mm['3d'], mm['opp_ratio'], mr['3d'], mr['opp_ratio']))

    # ------------------------------------------------------------------
    # D. 拖【右侧】手柄同样生效
    # ------------------------------------------------------------------
    b0, a1 = mouse_drag(True, side='right')
    m = metrics(b0, a1, side='right')
    step("★ 拖右侧手柄 3D 共线 + 长度守恒 + 位移正确",
         m['3d'] < 1e-5 and abs(m['opp_ratio'] - 1.0) < 1e-4
         and abs(m['moved'] - DT.length) < 1e-4,
         "3D=%.3e 比=%.6f 位移=%.6f" % (m['3d'], m['opp_ratio'], m['moved']))

    # ------------------------------------------------------------------
    # E. 路径 A（拖手柄线 apply_handle_offset）也接上了
    # ------------------------------------------------------------------
    o, act = build(True)
    b0 = snap(o, act)
    _session.selected_handle_endpoints = []
    _session.active_frame_number = 20.0
    _session.active_handle_direction = 'left'
    _session.drag_target_object = LABEL
    _session.active_bone_identifier = None
    fo.record_handle_baseline(bpy.context, 20.0, None, 'left')
    fo.apply_handle_offset(bpy.context, DT, 'left')
    a1 = snap(o, act)
    m = metrics(b0, a1)
    step("★ 路径A apply_handle_offset 也接上加权",
         m['3d'] < 1e-5 and abs(m['opp_ratio'] - 1.0) < 1e-4
         and abs(m['moved'] - DT.length) < 1e-4,
         "3D=%.3e 比=%.6f 位移=%.6f" % (m['3d'], m['opp_ratio'], m['moved']))

    # ------------------------------------------------------------------
    # G. ★★ 新建工程【默认类型】—— 用户 2026-09-16 报的场景
    #
    #    真实新工程里 `keyframe_insert` 给的是 **AUTO_CLAMPED**（派生类型）。
    #    实测（修复前）：对侧被 Blender 重算 → 臂长 1.33333→1.16667（"跳"），
    #    之后永久不共线（dev 0.832）。
    #    修复后：两侧按原生语义接管为 ALIGNED → 共线 0.0 + 臂长守恒。
    # ------------------------------------------------------------------
    for uneven, tag in ((False, '等λ'), (True, '各轴λ不同')):
        b0, a1 = mouse_drag(uneven, htype=None)
        m = metrics(b0, a1)
        step("★★ 默认工程(AUTO_CLAMPED)拖手柄 3D 共线 + 臂长守恒 + 位移正确 [%s]" % tag,
             m['3d'] < 1e-5 and abs(m['opp_ratio'] - 1.0) < 1e-4
             and abs(m['moved'] - DT.length) < 1e-4,
             "3D=%.3e 臂长比=%.6f 位移=%.6f 类型 %s→%s"
             % (m['3d'], m['opp_ratio'], m['moved'],
                b0[0]['hlt'], a1[0]['hlt']))
    # ★★ 拖后类型（第十轮契约）：
    #    · 被拖侧 = ALIGNED（原生："Automatic convert to **Align** when moved"）
    #    · 对侧   = **FREE**  ← 关键！对侧若留 ALIGNED，Blender 之后每次
    #      `fc.update()` 都会按它的 (t,v) 共线重算它 —— 而那个约束与 3D 共线
    #      **不等价** → 3D 形状破相（实测 1.45e-07 → 0.2697）+ dt 被改（13.0 → 11.07）。
    b0, a1 = mouse_drag(True, htype=None)
    step("★★ 默认工程拖后类型：被拖侧 ALIGNED + 对侧 FREE（防 Blender 重算）",
         a1[0]['hlt'] == 'ALIGNED' and a1[0]['hrt'] == 'FREE',
         "拖前 %s/%s → 拖后 %s/%s"
         % (b0[0]['hlt'], b0[0]['hrt'], a1[0]['hlt'], a1[0]['hrt']))

    # ------------------------------------------------------------------
    # F. 没有快照（老测试的调用方式）时：不崩、优雅降级
    # ------------------------------------------------------------------
    b0, a1 = mouse_drag(True, use_baseline=False)
    m = metrics(b0, a1)
    step("★ 无快照时不崩、被拖侧仍移动（降级为不带加权）",
         abs(m['moved'] - DT.length) < 1e-4,
         "位移=%.6f 3D=%.3e" % (m['moved'], m['3d']))

except Exception:
    step("FATAL", False, traceback.format_exc()[-1600:])

flush()
print("MOUSE_DRAG_WEIGHT_DONE")
os._exit(0)
