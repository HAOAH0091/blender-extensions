# -*- coding: utf-8 -*-
"""P2 验收（2026-09-16 第十轮修订）：3D 视图优先 —— 共线 + 速度分布保住

═══ 契约变更说明 ═══

原契约（P2，2026-09-16 上午）：
    「3D 共线 **且** (t,v) 平面也共线」—— 靠改对侧手柄的**时间分量 dt** 实现。

新契约（第十轮，**用户拍板**）：
    「**一切以 3D 视图的手柄操作体验为优先，Graph Editor 里不需要共线。**」

    ⇒ 不再改对侧 dt。3D 共线完全由【值分量】决定，与 dt 无关。

═══ 为什么改（实测，`_probeX.py`，速度编辑后拖手柄）═══

    | 指标 | 旧(带加权) | 新(当前) |
    |---|---:|---:|
    | 3D 点线距 | 7.262321574669722e-08 | **7.262321574669722e-08** ← 逐位相同 |
    | 对侧三维臂长 | 1.333334 | 1.333334 ← 逐位相同 |
    | 对侧 dt（= 速度分布） | 13.0 → **1.76** ❌ 被改掉 86% | 13.0 → **13.0** ✅ 不动 |
    | 左右速度比 | 0.3333 → **1.0** ❌ 被抹成匀速 | 0.3333 → 0.1354 ✅ 保留 |

    ⇒ 改 dt 对 3D 体验**零收益**，却把用户精心调好的**速度分布整个抹掉**。

═══ 本测试的断言 ═══

  A. 各拖拽量下：① 3D 精确共线  ② **对侧 dt 完全不变**（速度分布保住）③ 位移正确
  B. 反向探针：直接调 `_apply_weight` → 证明"改 dt 会毁掉速度分布"（记录停用理由）
  C. 边界：巨大拖拽量 / 无 NaN
  D. co（关键帧值）不动

⚠️ 度量必须用【点到直线距离】，不能用夹角 ——
   `acos` 在 0 附近精度塌缩（float32 分辨率 1.19e-7 会把 1−1.7e-8 舍成 1−1.19e-7
   → 反解出 ~0.03° 的假偏差）。

用法：blender --factory-startup --python tests/gui_weighted_handle_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_wh_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import transform_domain as xf

    def pt_line_dist(p, a, b):
        """点到直线距离（避开 acos 精度问题）。"""
        ab = b - a
        if ab.length < 1e-12:
            return 0.0
        return (p - a).cross(ab).length / ab.length

    def build(vals=(0.0, 4.0, 10.0), scale=(1.0, 0.7, 0.4), htype='FREE'):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, v in zip((1, 20, 40), vals):
            sc.frame_set(f)
            o.location = (v*scale[0], v*scale[1], v*scale[2])
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype
                kp.handle_right_type = htype
            fc.update()
        return o, a

    def snap(o, a, frame=20.0):
        d = {}
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    d[fc.array_index] = dict(
                        co=(float(kp.co[0]), float(kp.co[1])),
                        hl=(float(kp.handle_left[0]), float(kp.handle_left[1])),
                        hr=(float(kp.handle_right[0]), float(kp.handle_right[1])))
        return d

    def v3(b, key):
        return mathutils.Vector([b[i][key][1] for i in sorted(b)])

    def dts(b):
        """各轴的 (dt_left, dt_right) —— dt = 手柄时间 − co 时间。"""
        return {i: (b[i]['hl'][0] - b[i]['co'][0], b[i]['hr'][0] - b[i]['co'][0])
                for i in sorted(b)}

    def make_asym_dt(o, act, frame=20.0, dr=13.0):
        """造一个【不对称的 dt 分布】= 模拟用户拖过三角后的状态。"""
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    kp.handle_right = (kp.co[0] + dr, kp.handle_right[1])
            fc.update()

    # =========================================================
    # A. 各拖拽量：3D 精确共线 + 对侧 dt 不变 + 位移正确
    # =========================================================
    MOVES = [(1.0, 0.0, 0.0), (0.5, 0.0, 0.0), (3.0, 0.0, 0.0),
             (0.0, 3.0, 0.0), (3.0, 3.0, 3.0), (-1.5, 0.0, 0.0)]
    ok_all = True
    for mv in MOVES:
        o, act = build(htype='ALIGNED')
        snap_ep = xf.snapshot_endpoints(act, o, [(20.0, 'left')], None)
        b = snap(o, act)
        hl3 = v3(b, 'hl')
        dt0 = dts(b)

        xf.apply_endpoint_transform(
            act, o, snap_ep,
            (lambda f, v: v + mathutils.Vector(mv)), [(20.0, 'left')], None)

        a = snap(o, act)
        co3b, hl3b, hr3b = v3(a, 'co'), v3(a, 'hl'), v3(a, 'hr')
        dist = pt_line_dist(hr3b, co3b, hl3b)
        dt1 = dts(a)
        dt_shift = max(abs(dt1[i][k] - dt0[i][k]) for i in dt0 for k in (0, 1))
        gotten = (hl3b - hl3).length
        want = mathutils.Vector(mv).length

        # ⚠️ dt 阈值用 1e-5 而非 1e-9：Blender 的帧号是 float32（对 ~13 的量
        #    分辨率约 1e-6），残留几个 ulp 是正常的。真正被改掉时量级是 0.3~11。
        good = (dist < 1e-5 and dt_shift < 1e-5 and abs(gotten - want) < 1e-4)
        step("P2 拖拽%-16s 3D点线距=%.3e 对侧dt变化=%.3e 位移=%.4f(期望%.4f)"
             % (str(mv), dist, dt_shift, gotten, want), good, "")
        if not good:
            ok_all = False
    step("★★ P2 全部拖拽量：3D 精确共线 + 对侧 dt【完全不变】 + 位移正确", ok_all, "")

    # =========================================================
    # A2. ★ 核心新契约：有【不对称 dt】时，拖手柄后 dt 依然一个数不动
    #     （这是用户真正在意的：好不容易调好的速度分布不能被抹掉）
    # =========================================================
    o, act = build(htype='ALIGNED')
    make_asym_dt(o, act, dr=13.0)
    b = snap(o, act)
    dt0 = dts(b)
    snap_ep = xf.snapshot_endpoints(act, o, [(20.0, 'left')], None)
    xf.apply_endpoint_transform(
        act, o, snap_ep, (lambda f, v: v + mathutils.Vector((0.0, 3.0, 0.0))),
        [(20.0, 'left')], None)
    a = snap(o, act)
    dt1 = dts(a)
    co3b, hl3b, hr3b = v3(a, 'co'), v3(a, 'hl'), v3(a, 'hr')
    dist = pt_line_dist(hr3b, co3b, hl3b)
    dt_shift = max(abs(dt1[i][k] - dt0[i][k]) for i in dt0 for k in (0, 1))
    step("★★ 不对称 dt（右13.0/左−4.33）下拖手柄：dt 一个数不动 + 3D 仍共线",
         dt_shift < 1e-5 and dist < 1e-5,
         "dt前=%s dt后=%s 3D点线距=%.3e"
         % ({i: tuple(round(x, 4) for x in dt0[i]) for i in sorted(dt0)},
            {i: tuple(round(x, 4) for x in dt1[i]) for i in sorted(dt1)}, dist))

    # =========================================================
    # A3. ★★★ 本轮核心回归：拖完之后【再来一次 fc.update()】不许破相
    #
    #  这是第十轮反馈的**真正的根因**：对侧若留 ALIGNED，Blender 会在
    #  **任何一次后续 `fc.update()`**（下一次重绘 / 下一次操作 / 拖别的关键帧）
    #  里按它的 "(t,v) 平面共线" 重算对侧 —— 而那个约束与 3D 共线**不等价**：
    #
    #      实测（对侧 ALIGNED）：3D 点线距 1.452e-07 → **0.2697**（破相）
    #                           对侧 dt    13.0      → **11.07**（速度分布被改）
    #      实测（对侧 FREE）  ：3D 点线距 1.452e-07 →  1.452e-07（稳定）
    #                           对侧 dt    13.0      →  **13.0**（稳定）
    #
    #  ⇒ 所以收尾必须把对侧**封口成 FREE**（见 `xf._seal_opposite_handle`）。
    # =========================================================
    o, act = build(htype='ALIGNED')
    make_asym_dt(o, act, dr=13.0)
    b0 = snap(o, act)
    dt0 = dts(b0)
    snap_ep = xf.snapshot_endpoints(act, o, [(20.0, 'left')], None)
    xf.apply_endpoint_transform(
        act, o, snap_ep, (lambda f, v: v + mathutils.Vector((0.0, 3.0, 0.0))),
        [(20.0, 'left')], None)
    a1 = snap(o, act)
    d1 = pt_line_dist(v3(a1, 'hr'), v3(a1, 'co'), v3(a1, 'hl'))
    # 模拟"下一次重绘 / 下一次操作"
    for fc in xf._position_curves(act, o, None):
        fc.update()
    a2 = snap(o, act)
    d2 = pt_line_dist(v3(a2, 'hr'), v3(a2, 'co'), v3(a2, 'hl'))
    dt2 = dts(a2)
    dt_shift2 = max(abs(dt2[i][k] - dt0[i][k]) for i in dt0 for k in (0, 1))
    jump = max((v3(a2, 'hl') - v3(a1, 'hl')).length,
               (v3(a2, 'hr') - v3(a1, 'hr')).length)
    step("★★★ 拖完后再来一次 fc.update()：3D 不破相 + dt 不变 + 手柄不跳",
         d2 < 1e-5 and dt_shift2 < 1e-5 and jump < 1e-5,
         "3D %.3e→%.3e  dt变化=%.3e  跳变=%.3e" % (d1, d2, dt_shift2, jump))

    # 对侧封口后的类型（FREE）—— 防止 Blender 重算
    # ⚠️ 本文件的 `snap()` 只存 co/hl/hr（不存类型），所以单独读一次类型
    _lt = _rt = None
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - 20.0) < 1e-3:
                _lt, _rt = str(kp.handle_left_type), str(kp.handle_right_type)
    step("★★ 收尾后对侧类型 = FREE（封口，防 Blender 重算）",
         _rt == 'FREE', "左/右类型=%s/%s" % (_lt, _rt))

    # =========================================================
    # B. 反向探针：直接调 `_apply_weight` → 证明它会【毁掉速度分布】
    #    （记录停用理由；也防止有人无声地把加权重新接回来而不改测试）
    # =========================================================
    o, act = build(htype='ALIGNED')
    make_asym_dt(o, act, dr=13.0)
    b = snap(o, act)
    dt0 = dts(b)
    curves = xf._position_curves(act, o, None)
    # 模拟"若启用加权"：k = 1.0（对侧 dt 被改成本侧 dt × k）
    xf._apply_weight(curves, 20.0, 'right', 1.0, 'left')
    a = snap(o, act)
    dt1 = dts(a)
    changed = max(abs(dt1[i][1] - dt0[i][1]) for i in dt0)
    step("★[probe] 若启用 `_apply_weight` → 对侧 dt 确实被改（证明停用有价值）",
         changed > 1e-6,
         "对侧 dt %.4f → %.4f（变化 %.4f）" % (dt0[0][1], dt1[0][1], changed))

    # =========================================================
    # C. 边界：极端拖拽量 / NaN
    # =========================================================
    o, act = build()
    snap_ep = xf.snapshot_endpoints(act, o, [(20.0, 'left')], None)
    xf.apply_endpoint_transform(
        act, o, snap_ep, (lambda f, v: v + mathutils.Vector((1000.0, 0, 0))),
        [(20.0, 'left')], None)
    a = snap(o, act)
    # ⚠️ 现在不再改 dt，所以手柄时间【必然】不会越过相邻关键帧（本来就不动它）
    bad = []
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - 20.0) < 1e-3:
                for h in (kp.handle_left, kp.handle_right):
                    for other in fc.keyframe_points:
                        ot = float(other.co[0])
                        if ot < 19.9 and float(h[0]) < ot - 1e-6:
                            bad.append((fc.array_index, 'L', float(h[0]), ot))
                        if ot > 20.1 and float(h[0]) > ot + 1e-6:
                            bad.append((fc.array_index, 'R', float(h[0]), ot))
    step("★ P2 边界：巨大拖拽量下手柄时间不越界", not bad, bad[:3])
    nan_bad = []
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            for v in (kp.co[0], kp.co[1], kp.handle_left[0], kp.handle_left[1],
                      kp.handle_right[0], kp.handle_right[1]):
                if not (v == v) or abs(v) == float("inf"):
                    nan_bad.append(v)
    step("★ P2 边界：无 NaN / Inf", not nan_bad, nan_bad[:3])

    # =========================================================
    # D. co（关键帧值）不动
    # =========================================================
    o, act = build(htype='ALIGNED')
    b0 = snap(o, act)
    snap_ep = xf.snapshot_endpoints(act, o, [(20.0, 'left')], None)
    xf.apply_endpoint_transform(
        act, o, snap_ep, (lambda f, v: v + mathutils.Vector((1.0, 0, 0))),
        [(20.0, 'left')], None)
    a = snap(o, act)
    co_same = all(abs(a[i]['co'][1] - b0[i]['co'][1]) < 1e-6 for i in b0)
    step("★ P2 co（关键帧值）不动", co_same, "")

    # =========================================================
    # E. 曲线形状（动画值集）不受影响
    # =========================================================
    o, act = build(htype='ALIGNED')
    samples0 = []
    for f in range(1, 41):
        sc.frame_set(f)
        samples0.append(tuple(round(c, 6) for c in o.location))
    snap_ep = xf.snapshot_endpoints(act, o, [(20.0, 'left')], None)
    xf.apply_endpoint_transform(
        act, o, snap_ep, (lambda f, v: v + mathutils.Vector((0.0, 0.0, 0.0))),
        [(20.0, 'left')], None)
    samples1 = []
    for f in range(1, 41):
        sc.frame_set(f)
        samples1.append(tuple(round(c, 6) for c in o.location))
    step("★ P2 零位移拖拽：采样点完全不变（幂等）",
         samples0 == samples1, "")

except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("WEIGHTED_DONE")
os._exit(0)
