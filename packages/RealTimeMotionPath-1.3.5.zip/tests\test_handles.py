# -*- coding: utf-8 -*-
"""速度手柄几何验证（headless）

覆盖：
  1. 三角位置：上三角在关键帧上方(屏幕y更大)、下三角在下方
  2. 侧对应：上三角=左段、下三角=右段
  3. 鼠标 -> d 映射（含钳位、方向）
  4. 命中检测（最近优先、超范围返回 None）
  5. collect_handles 排除端点段
  6. s <-> d 单调性：越远越疏
"""
import sys, os, json, types, importlib

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    pkg = types.ModuleType(PKG); pkg.__path__ = [ADDON_DIR]; pkg.__package__ = PKG
    sys.modules[PKG] = pkg

import bpy
td = importlib.import_module(PKG + ".time_domain")
hd = importlib.import_module(PKG + ".handles")
xf = importlib.import_module(PKG + ".transform_domain")

results = []
def check(n, ok, d=""):
    results.append(("PASS" if ok else "FAIL", n, str(d)))


# ---------------- 1~3. 纯几何 ----------------
KF = (600.0, 400.0)

c_up = hd.tri_center(KF, hd.TRI_UP, 40.0)
check("UP triangle above keyframe (screen y larger)", c_up[1] > KF[1] and c_up[1] == 440.0,
      "kf_y=%.0f tri_y=%.0f" % (KF[1], c_up[1]))

c_dn = hd.tri_center(KF, hd.TRI_DOWN, 40.0)
check("DOWN triangle below keyframe (screen y smaller)", c_dn[1] < KF[1] and c_dn[1] == 360.0,
      "kf_y=%.0f tri_y=%.0f" % (KF[1], c_dn[1]))

check("x stays aligned with keyframe", c_up[0] == KF[0] and c_dn[0] == KF[0])

check("UP -> left side", hd.SIDE_BY_TRI[hd.TRI_UP] == 'left')
check("DOWN -> right side", hd.SIDE_BY_TRI[hd.TRI_DOWN] == 'right')

# 鼠标在上方 -> 只有上三角的 d > 0
mouse_up = (600.0, 460.0)
check("mouse above: UP d == 60", abs(hd.d_from_mouse(KF, hd.TRI_UP, mouse_up) - 60.0) < 1e-9,
      hd.d_from_mouse(KF, hd.TRI_UP, mouse_up))
check("mouse above: DOWN d clamped to 0", hd.d_from_mouse(KF, hd.TRI_DOWN, mouse_up) == 0.0,
      hd.d_from_mouse(KF, hd.TRI_DOWN, mouse_up))

mouse_dn = (600.0, 340.0)
check("mouse below: DOWN d == 60", abs(hd.d_from_mouse(KF, hd.TRI_DOWN, mouse_dn) - 60.0) < 1e-9,
      hd.d_from_mouse(KF, hd.TRI_DOWN, mouse_dn))
check("mouse below: UP d clamped to 0", hd.d_from_mouse(KF, hd.TRI_UP, mouse_dn) == 0.0)

# ---------------- 4. 命中检测 ----------------
H = [
    {'frame': 14.0, 'tri': hd.TRI_UP,   'tri_screen': (600.0, 440.0)},
    {'frame': 14.0, 'tri': hd.TRI_DOWN, 'tri_screen': (600.0, 360.0)},
    {'frame': 27.0, 'tri': hd.TRI_UP,   'tri_screen': (900.0, 440.0)},
]
hit = hd.hit_test(H, (605.0, 442.0), 20.0)
check("hit_test picks nearest UP@14", hit and hit['frame'] == 14.0 and hit['tri'] == hd.TRI_UP,
      hit and (hit['frame'], hit['tri']))
hit2 = hd.hit_test(H, (598.0, 356.0), 20.0)
check("hit_test picks DOWN@14", hit2 and hit2['tri'] == hd.TRI_DOWN, hit2 and hit2['tri'])
check("hit_test out of radius -> None", hd.hit_test(H, (600.0, 400.0), 20.0) is None,
      hd.hit_test(H, (600.0, 400.0), 20.0))
check("hit_test empty list -> None", hd.hit_test([], (600.0, 440.0), 20.0) is None)

kf_hit = hd.keyframe_hit({14.0: (600.0, 400.0), 27.0: (900.0, 400.0)}, (610.0, 405.0), 30.0)
check("keyframe_hit finds nearest", kf_hit == 14.0, kf_hit)
check("keyframe_hit out of range -> None",
      hd.keyframe_hit({14.0: (600.0, 400.0)}, (700.0, 400.0), 30.0) is None)


# ---------------- 5~6. 真实场景（collect_handles） ----------------
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 40
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
obj = bpy.context.view_layer.objects.active
obj.name = "T"
KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
       (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
for f, loc in KFS:
    sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
act = obj.animation_data.action

for fc in xf._position_curves(act, obj, None):
    for kp in fc.keyframe_points:
        kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
    pts = list(fc.keyframe_points)
    for i in range(len(pts) - 1):
        k0, k1 = pts[i], pts[i + 1]
        t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
        k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
        k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
    fc.update()

FRAMES = [1.0, 14.0, 27.0, 40.0]
SCREEN = {1.0: (100.0, 400.0), 14.0: (400.0, 400.0),
          27.0: (700.0, 400.0), 40.0: (1000.0, 400.0)}

def project(wp):
    for f, p in KFS:
        if abs(wp.x - p[0]) < 1e-6 and abs(wp.y - p[1]) < 1e-6:
            return SCREEN[float(f)]
    return None

def world_of(f):
    for fr, p in KFS:
        if abs(fr - f) < 0.5:
            return bpy.app.driver_namespace.get('_v', None) or _vec(p)
    return None

def _vec(p):
    import mathutils
    return mathutils.Vector(p)

def resolve(f, side):
    return td.resolve_target(act, obj, f, side)

def read_s(kf_map, span, side):
    return td.read_s(next(iter(kf_map.values())), span, side)

hs = hd.collect_handles(FRAMES, resolve, read_s, td.s_to_d, project, world_of)
check("collect_handles count == 6 (4 kf x 2, minus 2 endpoint sides)", len(hs) == 6, len(hs))

pairs = sorted((h['frame'], h['tri']) for h in hs)
expect = sorted([(1.0, 'down'), (14.0, 'up'), (14.0, 'down'),
                 (27.0, 'up'), (27.0, 'down'), (40.0, 'up')])
check("endpoint sides excluded (f1-up and f40-down missing)", pairs == expect, pairs)

h14u = hd.find_handle(hs, 14.0, hd.TRI_UP)
check("uniform -> d == CV_MID (1.00x baseline)",
      h14u and abs(h14u['d'] - td.CV_MID) < 1e-3,   # 屏幕像素尺度：float32 精度足够
      h14u and h14u['d'])
check("uniform -> ratio == 1.00",
      h14u and abs(hd.ratio_of(h14u['s'], td.S_LIN) - 1.0) < 1e-6,
      h14u and hd.ratio_of(h14u['s'], td.S_LIN))
check("UP triangle is above its keyframe",
      h14u and h14u['tri_screen'][1] > h14u['kf_screen'][1],
      h14u and (h14u['kf_screen'], h14u['tri_screen']))

# 单调性：s 越小(越疏) -> d 越大
d_sparse = td.s_to_d(0.02)
d_lin = td.s_to_d(td.S_LIN)
d_dense = td.s_to_d(1.0)
check("monotonic: sparser(s smaller) => d LARGER",
      d_sparse > d_lin > d_dense,
      "sparse_d=%.1f lin_d=%.1f dense_d=%.1f" % (d_sparse, d_lin, d_dense))

# 拖拽往返：d -> s -> d
for d0 in (td.CV_NEAR, td.CV_MID, td.CV_FAR):
    s0 = td.d_to_s(d0)
    back = td.s_to_d(s0)
    check("roundtrip d=%.0f" % d0, abs(back - d0) < 1e-6, "back=%.6f" % back)

fails = [r for r in results if r[0] == "FAIL"]
summary = {
    "total": len(results), "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in results],
}
json.dump(summary, open(os.path.join(HERE, "_hd_result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("WROTE_HANDLES_JSON")
