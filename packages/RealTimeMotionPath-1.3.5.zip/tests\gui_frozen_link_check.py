# -*- coding: utf-8 -*-
"""用户 2 个反馈的回归测试（2026-09-16）

▌反馈 1
  「手柄端点的模态操作，在手柄是【对齐(ALIGNED)】状态下只能作用于一端手柄；
    应用修改后再拖手柄，对端手柄会【跳变】。
    期望：模态操作一段手柄时，另一端**实时联动对齐**（前提是它本来是对齐类型），
          而不是操作完再操作时才跳变。」

▌反馈 2
  「使用三角速度手柄后，再拖动贝塞尔手柄会发生【跳变】。」

--------------------------------------------------------------------
▌同一个根因（实测确认，见 `_probe2.py` / `_probe3.py`）

  速度编辑（拖三角）会把**被编辑关键帧及其邻居的【两侧】手柄转成 FREE**
  （`time_domain.freeze_keyframe_pair`，并登记到冻结表）。

  于是同一个关键帧，两条写入路径的判据**不一致**：

    · 端点模态 → `xf.maintain_linked_handle` **只看类型** → 见 FREE 就 return
                  ⇒ **模态操作时对侧完全不联动**（= 反馈 1 的前半）
    · 鼠标拖拽 → 老 `interaction.update_linked_handle` 有 `is_frozen` 例外 → 联动
                  ⇒ 操作完再拖时对侧突然补上 ⇒ **跳变**（= 反馈 1 的后半）

  实测（速度编辑后做端点模态 G，对侧 3D 共线偏差）：
      修复前 0.35 → 0.97（两根手柄散开 ~75°，正是截图里的折角）
      修复后 0.0   全程共线

  实测（速度编辑后鼠标拖拽，对侧单步位移；被拖侧单步 0.25）：
      修复前 **2.77**（跳 11 倍）→ 修复后 0.24678（平滑）

▌反馈 2 的第二个形态（数值爆炸，更严重）

  老 `update_linked_handle` 走的是 `slope = dv / dt` 的 (t,v) 直线外推，
  **dt 在分母上**。速度编辑能把 dt 压到 ~1e-3 帧（旧阈值 0.0001 拦不住）：

      实测：拖被速度编辑过的一侧 → 对侧手柄炸到 **(-5766, -8652)**

--------------------------------------------------------------------
▌修法

  1. 联动判据收敛到 **`xf._link_mode`**（唯一来源，两条路径共用）：
        ALIGNED / **插件冻的 FREE** → 'link'（对侧绕 co 旋转保持共线）
        用户手动 FREE               → 'free'（原生：完全独立，绝不动）
        AUTO / AUTO_CLAMPED         → 'auto'（交给 Blender 重算）
        VECTOR                      → 'vector'（对侧贴到控制点）
  2. (t,v) 外推加**两道数值保护**：dt ≤ `xf.DT_EPS` 放弃；外推结果偏离 co
     超过 `_MAX_TV_EXTRAP` 也放弃。放弃不是丢功能 —— 紧随其后的
     `xf.finish_linked_handle` 用三维通路（方向 + 臂长，全程不除 dt）摆正对侧。
  3. `_apply_weight` 的 dt 加可分辨下限（原 ±1e-6 低于 Blender 分辨率）。

用法：blender --factory-startup --python tests/gui_frozen_link_check.py
"""
import os
import sys
import json
import math
import traceback

import bpy
import mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_fl_result.json")

FRAME = 14.0
DT_LIST = (0.001, 0.0015, 0.005, 0.05, 0.5, 1.0, 4.333)

steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})


def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())


try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath.state import _session

    # ⚠️ 关键帧【不共线】——否则 3D 共线退化，测不出折角
    KEYS = [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
            (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]

    class FakeOp:
        pass
    for _nm in dir(inter.RTMP_OT_PathPointDrag):
        if _nm.startswith("__"):
            continue
        try:
            setattr(FakeOp, _nm, getattr(inter.RTMP_OT_PathPointDrag, _nm))
        except Exception:
            pass
    fo = FakeOp()

    def build(htype='ALIGNED'):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in KEYS:
            sc.frame_set(f)
            o.location = loc
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype
                kp.handle_right_type = htype
            fc.update()
        return o, a

    def st(o, a, frame=FRAME):
        d = {'hl': [0.0] * 3, 'hr': [0.0] * 3, 'co': [0.0] * 3,
             'dtl': [0.0] * 3, 'dtr': [0.0] * 3, 'hlt': None, 'hrt': None}
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    i = fc.array_index
                    d['hl'][i] = float(kp.handle_left[1])
                    d['hr'][i] = float(kp.handle_right[1])
                    d['co'][i] = float(kp.co[1])
                    d['dtl'][i] = float(kp.handle_left[0]) - float(kp.co[0])
                    d['dtr'][i] = float(kp.handle_right[0]) - float(kp.co[0])
                    d['hlt'], d['hrt'] = str(kp.handle_left_type), str(kp.handle_right_type)
        d['hlv'] = mathutils.Vector(d['hl'])
        d['hrv'] = mathutils.Vector(d['hr'])
        d['cov'] = mathutils.Vector(d['co'])
        return d

    def dev(s):
        a, b = s['hlv'] - s['cov'], s['hrv'] - s['cov']
        if a.length < 1e-9 or b.length < 1e-9:
            return None
        return a.normalized().cross(b.normalized()).length

    def arm(s, side):
        return ((s['hlv'] if side == 'left' else s['hrv']) - s['cov']).length

    def speed_edit(o, frame=FRAME, side='right', px=0.0):
        """真实入口：拖三角速度手柄。"""
        inter._apply_speed_d(bpy.context, o, frame, side, px)

    def force_dt(o, a, dtv, side='right', freeze=True, frame=FRAME):
        """把【被拖侧】dt 设成指定值；模拟速度编辑后的 FREE + 登记状态。"""
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    if side == 'right':
                        kp.handle_right = (kp.co[0] + dtv, kp.handle_right[1])
                    else:
                        kp.handle_left = (kp.co[0] - dtv, kp.handle_left[1])
                    if freeze:
                        td.freeze_handle_side(kp, 'left')
                        td.freeze_handle_side(kp, 'right')
            fc.update()
        if freeze:
            for fc in xf._position_curves(a, o, None):
                kp = xf.keyframe_at(fc, frame)
                if kp is not None:
                    td.mark_frozen(kp.id_data, frame)
                    break

    def modal_run(o, act, deltas, side='left', frame=FRAME):
        snap = xf.snapshot_endpoints(act, o, [(frame, side)], None)
        mk = 'hlv' if side == 'left' else 'hrv'
        p0 = st(o, act, frame)[mk]          # ⚠️ 起点：位移要相对它算，不是臂长
        rows = []
        for dd in deltas:
            xf.apply_endpoint_transform(
                act, o, snap,
                (lambda f, v, _d=dd: v + mathutils.Vector((0.0, _d, 0.0))),
                [(frame, side)], None)
            s = st(o, act, frame)
            rows.append({'delta': dd, 's': s,
                         'dragged_disp': (s[mk] - p0).length,
                         'opp_arm': arm(s, 'right' if side == 'left' else 'left'),
                         'dev': dev(s)})
        return rows

    def mouse_run(o, act, deltas, side='left', frame=FRAME):
        _session.selected_handle_endpoints = [(frame, side)]
        _session.active_bone_identifier = None
        _session.active_frame_number = frame
        _session.active_handle_direction = side
        _session.drag_target_object = "T"
        _session.handle_edit_in_progress = True
        fo.record_handle_baseline(bpy.context, frame, None, side)
        rows = []
        prev = st(o, act, frame)
        for dd in deltas:
            fo.apply_handle_point_offset(
                bpy.context, mathutils.Vector((0.0, dd, 0.0)),
                {'frame': frame, 'side': side, 'bone_name': None,
                 'position': mathutils.Vector((0, 0, 0))})
            s = st(o, act, frame)
            mk = 'hlv' if side == 'left' else 'hrv'
            ok_ = 'hrv' if side == 'left' else 'hlv'
            rows.append({'delta': dd, 's': s,
                         'dragged_step': (s[mk] - prev[mk]).length,
                         'opp_step': (s[ok_] - prev[ok_]).length,
                         'dev': dev(s)})
            prev = s
        return rows

    # =================================================================
    # 1. 反馈 1：速度编辑后，端点模态【必须实时联动对齐】
    # =================================================================
    for px, tag in ((0.0, '温和'), (320.0, '极端变疏')):
        td.clear_frozen()
        o, act = build('ALIGNED')
        speed_edit(o, FRAME, 'right', px)
        s0 = st(o, act)
        step("[前置] 速度编辑后手柄变 FREE 且已登记（%s）" % tag,
             s0['hlt'] == 'FREE' and s0['hrt'] == 'FREE' and td.is_frozen(act, FRAME),
             "类型=%s/%s frozen=%s" % (s0['hlt'], s0['hrt'], td.is_frozen(act, FRAME)))

        for side in ('left', 'right'):
            td.clear_frozen()
            o, act = build('ALIGNED')
            speed_edit(o, FRAME, 'right', px)
            rows = modal_run(o, act, (0.5, 1.0, 2.0, 3.0), side=side)
            devs = [r['dev'] for r in rows]
            opp_side = 'right' if side == 'left' else 'left'
            arms = [r['opp_arm'] for r in rows]
            base_arm = arm(st(o, act), opp_side)
            step("★[%s] 模态 G(%s) 对侧【全程实时共线】 dev≈0" % (tag, side),
                 all(x is not None and x < 1e-5 for x in devs),
                 "dev=%s" % [round(x, 8) for x in devs])
            step("★[%s] 模态 G(%s) 对侧【臂长守恒】" % (tag, side),
                 all(abs(x - base_arm) < 1e-4 for x in arms),
                 "臂长=%s (基准 %.5f)" % ([round(x, 5) for x in arms], base_arm))
            step("★[%s] 模态 G(%s) 被拖侧【跟手】且 co 不动" % (tag, side),
                 all(abs(r['dragged_disp'] - r['delta']) < 1e-3 for r in rows),
                 "位移=%s" % [round(r['dragged_disp'], 5) for r in rows])

    # 模态 R（旋转）也要联动
    td.clear_frozen()
    o, act = build('ALIGNED')
    speed_edit(o, FRAME, 'right', 0.0)
    snap = xf.snapshot_endpoints(act, o, [(FRAME, 'left')], None)
    row_devs = []
    for ang in (5.0, 15.0, 30.0):
        _rot = mathutils.Matrix.Rotation(math.radians(ang), 3, 'Z')
        xf.apply_endpoint_transform(
            act, o, snap,
            (lambda f, v, _r=_rot: _r @ v),
            [(FRAME, 'left')], None)
        row_devs.append(dev(st(o, act)))
    step("★ 模态 R（旋转端点）在速度编辑后仍实时共线",
         all(x is not None and x < 1e-5 for x in row_devs),
         "dev=%s" % [round(x, 8) for x in row_devs])

    # =================================================================
    # 2. 反馈 1 后半：之后再【鼠标拖拽】不许跳变
    # =================================================================
    for px, tag in ((0.0, '温和'), (320.0, '极端变疏')):
        td.clear_frozen()
        o, act = build('ALIGNED')
        speed_edit(o, FRAME, 'right', px)
        rows = mouse_run(o, act, (0.25, 0.5, 0.75, 1.0, 1.5, 2.0), side='left')
        first = rows[0]
        ratio = first['opp_step'] / max(first['dragged_step'], 1e-9)
        step("★[%s] 速度编辑后鼠标拖拽【第一步不跳变】" % tag,
             ratio < 2.0, "对侧/被拖侧 = %.4f（跳变时是 11 倍）" % ratio)
        step("★[%s] 速度编辑后鼠标拖拽全程共线 + 对侧有界" % tag,
             all(r['dev'] is not None and r['dev'] < 1e-5 for r in rows)
             and max(max(abs(v) for v in r['s']['hrv']) for r in rows) < 30.0,
             "dev=%s 对侧|max|=%.4f"
             % ([round(r['dev'], 8) for r in rows],
                max(max(abs(v) for v in r['s']['hrv']) for r in rows)))

    # =================================================================
    # 3. 两条路径【结果一致】（这正是修复的核心）
    # =================================================================
    td.clear_frozen()
    o1, a1 = build('ALIGNED')
    speed_edit(o1, FRAME, 'right', 0.0)
    m_rows = modal_run(o1, a1, (0.5, 1.0, 2.0), side='left')
    td.clear_frozen()
    o2, a2 = build('ALIGNED')
    speed_edit(o2, FRAME, 'right', 0.0)
    u_rows = mouse_run(o2, a2, (0.5, 1.0, 2.0), side='left')
    same = all(abs(m_rows[i]['opp_arm'] - arm(u_rows[i]['s'], 'right')) < 1e-3
               for i in range(len(m_rows)))
    step("★ 模态路径 vs 鼠标路径【结果一致】（冻结场景）", same,
         "模态对侧臂长=%s 鼠标对侧臂长=%s"
         % ([round(r['opp_arm'], 5) for r in m_rows],
            [round(arm(r['s'], 'right'), 5) for r in u_rows]))

    # =================================================================
    # 4. 反馈 2：dt 边界矩阵 —— 任意 dt 档位都不许爆
    # =================================================================
    worst = 0.0
    worst_key = ""
    bad_dev = []
    for dtv in DT_LIST:
        for side in ('left', 'right'):
            td.clear_frozen()
            o, act = build('ALIGNED')
            force_dt(o, act, dtv, side)
            rows = mouse_run(o, act, (0.25, 0.5, 1.0, 2.0), side=side)
            opp_key = 'hrv' if side == 'left' else 'hlv'
            mx = max(max(abs(v) for v in r['s'][opp_key]) for r in rows)
            if mx > worst:
                worst, worst_key = mx, "dt=%s_%s" % (dtv, side)
            if any(r['dev'] is None or r['dev'] >= 1e-5 for r in rows):
                bad_dev.append("dt=%s_%s" % (dtv, side))
    step("★ dt 边界矩阵（%d 档 × 左右）对侧【绝不爆炸】" % len(DT_LIST),
         worst < 30.0, "最差 %s 对侧|max|=%.4f（修复前 dt=0.001 时是 8652）"
         % (worst_key, worst))
    step("★ dt 边界矩阵全程共线（无一档退化）",
         not bad_dev, "有问题的档位=%s" % (bad_dev or "无"))

    # =================================================================
    # 5. 反向探针：证明测试真的抓得住（不联动的情形必须【不】联动）
    # =================================================================
    # (a) 未登记的 FREE → 原生语义：不联动
    td.clear_frozen()
    o, act = build('FREE')
    rows = mouse_run(o, act, (0.25, 0.5, 1.0), side='left')
    step("[probe] 未登记的手动 FREE → 对侧【不联动】（证明测试有效）",
         all(r['opp_step'] < 1e-6 for r in rows),
         "对侧步进=%s" % [round(r['opp_step'], 8) for r in rows])

    # (b) 对侧是手动 FREE、被拖侧是 ALIGNED → 也【不联动】（原生：FREE 完全独立）
    o, act = build('ALIGNED')
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - FRAME) < 1e-3:
                kp.handle_right_type = 'FREE'
        fc.update()
    rows = mouse_run(o, act, (0.25, 0.5, 1.0), side='left')
    step("★[本轮新修] 对侧是手动 FREE → 按原生语义【不被联动】",
         all(r['opp_step'] < 1e-6 for r in rows),
         "对侧步进=%s" % [round(r['opp_step'], 8) for r in rows])

    # (c) 已登记的冻结 FREE → 必须联动（与 (a) 成对照）
    td.clear_frozen()
    o, act = build('ALIGNED')
    speed_edit(o, FRAME, 'right', 0.0)
    rows = mouse_run(o, act, (0.25, 0.5, 1.0), side='left')
    step("[probe] 已登记的冻结 FREE → 对侧【必须联动】（与上一条成对照）",
         all(r['opp_step'] > 1e-6 for r in rows),
         "对侧步进=%s" % [round(r['opp_step'], 8) for r in rows])

    # =================================================================
    # 6. 往返操作：速度编辑 → 拖手柄 → 再速度编辑 → 再拖
    # =================================================================
    td.clear_frozen()
    o, act = build('ALIGNED')
    worst2 = 0.0
    devs2 = []
    for i, px in enumerate((300.0, 0.0, 320.0, -200.0)):
        speed_edit(o, FRAME, 'right', px)
        rows = mouse_run(o, act, (0.25, 0.5, 1.0), side='left')
        worst2 = max(worst2, max(max(abs(v) for v in r['s']['hrv']) for r in rows))
        devs2 += [r['dev'] for r in rows]
    step("★ 速度编辑↔拖手柄 往复 4 轮：全程有界 + 共线",
         worst2 < 30.0 and all(x is not None and x < 1e-5 for x in devs2),
         "对侧|max|=%.4f dev_max=%.3e" % (worst2, max(devs2)))

    td.clear_frozen()

    # =================================================================
    # 7. _FROZEN 冻结表【持久化】（2026-09-17 用户拍板）
    #
    #    与 _plugin_owned_free 同类：只活在内存里 ⇒ 重开 .blend 就丢
    #    ⇒ 速度编辑过的关键帧退化成"用户手动 FREE" ⇒ 拖一侧、对侧不联动。
    # =================================================================
    td.clear_frozen()
    o, act = build('ALIGNED')
    FR = FRAME

    # T0 前提（既有行为，防回归）
    td.mark_frozen(act, FR)
    step("T0 [前提] mark_frozen 后内存命中", td.is_frozen(act, FR) is True)

    # T1 写入 action 的 custom property
    _toks = [str(t) for t in td.frozen_tokens(act)]
    step("T1 ★ 登记写进 action 的 custom property（持久化）",
         ("rtmp_frozen" in act.keys()) and (str(int(FR)) in _toks),
         "act[rtmp_frozen]=%s" % (list(act["rtmp_frozen"]) if "rtmp_frozen" in act.keys() else None))

    # T2 幂等：重复登记不产生重复条目
    td.mark_frozen(act, FR)
    _toks2 = [str(t) for t in td.frozen_tokens(act)]
    step("T2 ★ 重复登记不产生重复条目",
         len(_toks2) == len(set(_toks2)), _toks2)

    # T3 ★★★ 核心：模拟"重开 Blender"（内存清空 → 从 property 惰性恢复）
    td._FROZEN.clear()
    td._frozen_warmed.clear()          # 连"已恢复"标记一起清，才算模拟新进程
    _restored = td.is_frozen(act, FR)
    step("T3 ★★★ 模拟重开 Blender：内存清空后仍能从 action 恢复登记（体感不丢）",
         _restored is True and len(td._FROZEN) == 1,
         "is_frozen=%s | 恢复后 len(_FROZEN)=%d" % (_restored, len(td._FROZEN)))

    # T4 惰性恢复只做一次（有 warmed 标记，不在重绘热路径上反复读 property）
    step("T4 ★ 惰性恢复带 warmed 标记（每 action 只读一次 property）",
         str(act.name) in td._frozen_warmed, sorted(td._frozen_warmed))

    # T5 ★★★ 端到端：重开后"插件冻过"的判据仍成立 ⇒ 联动不丢（用户要的体感）
    _kp = None
    for _fc in xf._position_curves(act, o, None):
        for _k in _fc.keyframe_points:
            if abs(_k.co[0] - FR) < 1e-3:
                _kp = _k
                break
    step("T5 ★★★ 重开后 _is_plugin_frozen 仍为 True（联动的前提不丢）",
         _kp is not None and xf._is_plugin_frozen(_kp) is True,
         "_is_plugin_frozen=%s" % (None if _kp is None else xf._is_plugin_frozen(_kp)))

    # T6 反向：未登记的帧 / action 仍为 False
    step("T6 ★ 反向：未登记的帧仍为 False", td.is_frozen(act, 27.0) is False)
    step("T6b ★ 反向：未登记的 action 仍为 False",
         td.is_frozen(bpy.data.actions.new("OtherX"), FR) is False)

    # T7 unmark：内存 + property 同步移除（防陈旧条目）
    td.unmark_frozen(act, FR)
    _toks3 = [str(t) for t in td.frozen_tokens(act)]
    step("T7 ★ unmark_frozen 同时移除内存与 property 条目",
         td.is_frozen(act, FR) is False and str(int(FR)) not in _toks3, _toks3)

    # T8 clear_frozen(action) 清掉该 action 的 property
    td.mark_frozen(act, FR)
    td.clear_frozen(act)
    step("T8 ★ clear_frozen(action) 连 property 一起清",
         ("rtmp_frozen" not in act.keys()) and td.is_frozen(act, FR) is False,
         list(act.keys()))

    # T12 ★★ 键的身份：必须是 action【名】（字符串）而不是内存地址（整数）。
    #     ⚠️ 这条是【行为断言】—— 光靠静态契约抓不住"三处各写一份键"的漂移：
    #        实测（bug 注入）只改 mark_frozen 用 as_pointer 时，
    #        静态契约会挂、但所有行为断言都"恰好"还能跑（跨会话才暴露）。
    td.clear_frozen()
    td.mark_frozen(act, FR)
    _keys = [k for k in td._FROZEN if k[1] == int(FR)]
    step("T12 ★★ 冻结表的键 = (action 名, 帧号)，不是内存地址",
         bool(_keys) and all(isinstance(k[0], str) for k in _keys)
         and any(k[0] == str(act.name) for k in _keys),
         _keys)

    # T13 ★★★ 跨会话语义：换一个"同名的不同 action 对象"来查（模拟重开文件后
    #      Python 对象重建）—— 键是名字，所以**应当命中**；键若是内存地址则必然落空。
    td._FROZEN.clear()
    td._frozen_warmed.clear()
    _fake = type("FakeAct", (), {"name": str(act.name),
                                 "get": lambda self, k: list(act["rtmp_frozen"])
                                 if k in act.keys() else None})()
    step("T13 ★★★ 键跨会话稳定（新对象但同名 ⇒ 仍命中；用内存地址必落空）",
         td.is_frozen(_fake, FR) is True, "is_frozen(fake-with-same-name)=%s" % td.is_frozen(_fake, FR))

    # ---- 静态契约 ----
    _src_td = open(os.path.join(HERE, "..", "time_domain.py"), encoding="utf-8").read()
    step("T9 ★ 静态契约：冻结表有持久化 API（mark / unmark / warm / tokens / clear）",
         all(s in _src_td for s in ("def mark_frozen", "def unmark_frozen",
                                    "def warm_frozen", "def frozen_tokens",
                                    "def clear_frozen")), "")
    step("T10 ★★ 静态契约：is_frozen 内做惰性恢复（warm_frozen）",
         "warm_frozen(action)" in _src_td.split("def is_frozen")[1].split("\ndef ")[0], "")
    _fk_body = _src_td.split("def _frozen_key")[1].split("\ndef ")[0]
    # ⚠️ 只看 return 语句（实际代码）—— docstring 里会提到 as_pointer 作为反例
    #    （上一轮 S9 就栽在这儿：字符串命中 docstring → 误判失败）
    _fk_rets = [l.strip() for l in _fk_body.splitlines() if l.strip().startswith("return")]
    step("T11 ★★ 静态契约：键的唯一来源 _frozen_key 用 action【名】（跨会话稳定）",
         any("getattr(action, \"name\", None)" in l for l in _fk_rets)
         and not any("as_pointer" in l for l in _fk_rets), _fk_rets)
    step("T11b ★★★ 静态契约：mark / unmark / is_frozen 三处都调 _frozen_key（唯一来源）",
         all("_frozen_key(action, frame)" in _src_td.split("def %s" % _fn)[1].split("\ndef ")[0]
             for _fn in ("mark_frozen", "unmark_frozen", "is_frozen")),
         "三处各写一份键 = 同一语义两份判据（实测漏抓过）")

    td.clear_frozen()

    # =================================================================
    # 8. ★★★ 体感手柄类型（_FEEL）—— 方案 A（2026-09-17 用户拍板）
    #
    #    体感=权威数据；原始类型=实现细节（按需写 FREE 防 Blender 重算）。
    # =================================================================
    xf.clear_feel()
    o, act = build('ALIGNED')
    _kp = None
    for _fc in xf._position_curves(act, o, None):
        _kp = xf.keyframe_at(_fc, FR)
        if _kp is not None:
            break

    # U0 前提
    step("U0 体感表初始为空（未记录 ⇒ 透传）", xf.feel_type(_kp, 'left') is None,
         "feel_type=%s" % xf.feel_type(_kp, 'left'))

    # U1 未记录 ⇒ 透传原始类型（用户没碰过的关键帧别管）
    step("U1 ★ 未记录时透传原始类型（新关键帧不受影响）",
         xf.effective_feel(_kp, 'left') == str(_kp.handle_left_type),
         "effective=%s 原始=%s" % (xf.effective_feel(_kp, 'left'), _kp.handle_left_type))

    # U2 记录体感 + 持久化
    xf.mark_feel(_kp, 'left', 'LINK')
    xf.mark_feel(_kp, 'right', 'FREE')
    step("U2 ★ 体感记录写进 action 的 custom property",
         ("rtmp_feel" in act.keys())
         and any("LINK" in str(t) for t in act["rtmp_feel"])
         and any("FREE" in str(t) for t in act["rtmp_feel"]),
         sorted(act["rtmp_feel"]) if "rtmp_feel" in act.keys() else None)

    # U3 ★★★ 方案 A 的核心：体感绝对权威 —— 改【原始】类型，体感不变
    _kp.handle_left_type = 'ALIGNED'
    _kp.handle_right_type = 'ALIGNED'
    step("U3 ★★★ 方案A核心：用户在 GE 改【原始】类型后，【体感】不跟着变",
         xf.feel_type(_kp, 'left') == 'LINK' and xf.feel_type(_kp, 'right') == 'FREE',
         "改原始→体感 L=%s R=%s" % (xf.feel_type(_kp, 'left'), xf.feel_type(_kp, 'right')))

    # U4 联动判据只看体感
    step("U4 ★★ 联动判据只看体感：右=体感 FREE ⇒ 对侧不动（哪怕原始是 ALIGNED）",
         xf._link_mode(_kp, 'left') == 'free',
         "_link_mode(move left)=%s" % xf._link_mode(_kp, 'left'))
    step("U4b ★★ 体感 LINK ⇒ 联动（哪怕原始类型被改成别的）",
         xf._link_mode(_kp, 'right') == 'link',
         "_link_mode(move right)=%s" % xf._link_mode(_kp, 'right'))

    # U5 unmark ⇒ 回到透传
    xf.unmark_feel(_kp, 'left')
    step("U5 ★ unmark_feel 后回到透传原始类型",
         xf.feel_type(_kp, 'left') is None, "feel_type=%s" % xf.feel_type(_kp, 'left'))

    # U6 静态契约：键的唯一来源
    _src_f = open(os.path.join(HERE, "..", "transform_domain.py"), encoding="utf-8").read()
    step("U6 ★ 静态契约：体感表有完整 API（mark/unmark/query/warm/tokens/clear）",
         all(s in _src_f for s in ("def mark_feel", "def unmark_feel", "def feel_type",
                                   "def warm_feel", "def feel_tokens", "def clear_feel")), "")
    _fk_rets2 = [l.strip() for l in
                 _src_f.split("def _feel_key_of")[1].split("\ndef ")[0].splitlines()
                 if l.strip().startswith("return")]
    step("U7 ★★ 静态契约：体感键的唯一来源用 action【名】（跨会话稳定）",
         any("action.name" in l for l in _fk_rets2)
         and not any("as_pointer" in l for l in _fk_rets2), _fk_rets2)
    step("U8 ★★★ 静态契约：联动判据 _link_mode 里**读体感表**（方案 A 的收敛点）",
         "feel_type(kp, opp)" in _src_f.split("def _link_mode")[1].split("\ndef ")[0], "")
    step("U9 ★★ 静态契约：所有插件改类型处都记体感"
         "（封口 / 关键帧模态 / 速度冻结）",
         _src_f.split("def _seal_opposite_handle")[1].split("\ndef ")[0].count("mark_feel") >= 1
         and _src_f.split("def make_handles_editable")[1].split("\ndef ")[0].count("mark_feel") >= 1,
         "")
    _src_td2 = open(os.path.join(HERE, "..", "time_domain.py"), encoding="utf-8").read()
    step("U10 ★★ 静态契约：速度编辑冻结时也记体感（time_domain.mark_frozen）",
         "mark_feel_at" in _src_td2.split("def mark_frozen")[1].split("\ndef ")[0], "")

    # U12 ★★★ 模拟"重开 Blender"：内存清空（含 warmed 标记）但 property 还在
    #      ⇒ 必须靠【惰性恢复】从 property 读回来。这条抓 I2 那种"去掉 warm"的注入。
    xf.clear_feel()
    xf.mark_feel(_kp, 'left', 'VECTOR')
    xf.mark_feel(_kp, 'right', 'LINK')
    xf._FEEL.clear()                 # 清内存（模拟新进程）
    xf._feel_warmed.clear()          # ★ 连"已恢复"标记一起清，才算真·新进程
    _r_l = xf.feel_type(_kp, 'left')
    _r_r = xf.feel_type(_kp, 'right')
    step("U12 ★★★ 模拟重开 Blender：内存清空后从 property 惰性恢复体感",
         _r_l == 'VECTOR' and _r_r == 'LINK' and len(xf._FEEL) == 2,
         "L=%s R=%s | 恢复后 len(_FEEL)=%d" % (_r_l, _r_r, len(xf._FEEL)))

    # U13 ★★★ 双进程语义等价：造"同名不同对象"的 fake，键是名字才命中
    xf.clear_feel()
    xf.mark_feel(_kp, 'left', 'VECTOR')
    _fake2 = type("FakeKP", (), {
        "id_data": type("FakeAct2", (), {"name": str(act.name)})(),
        "co": (float(FR), 0.0),
    })()
    step("U13 ★★★ 体感键跨会话稳定（同名新对象仍命中；用内存地址必落空）",
         xf.feel_type(_fake2, 'left') == 'VECTOR',
         "feel_type(fake-same-name)=%s" % xf.feel_type(_fake2, 'left'))

    # U14 ★ clear_feel(action) 连 property 一起删（防陈旧条目随文件留存）
    xf.mark_feel(_kp, 'left', 'LINK')
    xf.clear_feel(act)
    step("U14 ★ clear_feel(action) 连 property 一起清（不留陈旧条目）",
         ("rtmp_feel" not in act.keys()) and xf.feel_type(_kp, 'left') is None,
         "act keys=%s" % [k for k in act.keys() if k.startswith("rtmp")])

    # U15 ★★★ 'CLAMPED'（Auto Clamped）与 'LINK'（Aligned）**联动行为相同**，
    #       但**原始类型不同**（菜单高亮要 1:1 ⇒ 体感取值必须分开）。
    xf.clear_feel()
    xf.mark_feel(_kp, 'left', 'CLAMPED')
    xf.mark_feel(_kp, 'right', 'LINK')
    step("U15 ★★ 体感 CLAMPED 与 LINK 都判为联动（行为相同）",
         xf._link_mode(_kp, 'right') == 'link' and xf._link_mode(_kp, 'left') == 'link',
         "move-right=%s move-left=%s" % (xf._link_mode(_kp, 'right'),
                                         xf._link_mode(_kp, 'left')))
    step("U16 ★★★ 体感 CLAMPED / LINK 的**原始类型不同**（菜单高亮才能 1:1）",
         xf.orig_type_for_feel('CLAMPED') == 'AUTO_CLAMPED'
         and xf.orig_type_for_feel('LINK') == 'ALIGNED'
         and xf.orig_type_for_feel('FREE') == 'FREE',
         "CLAMPED→%s LINK→%s FREE→%s" % (xf.orig_type_for_feel('CLAMPED'),
                                         xf.orig_type_for_feel('LINK'),
                                         xf.orig_type_for_feel('FREE')))

    # U17 ★★ 断言「两种体感都联动」——**别断言"钳制谁更强"**：
    #     我实测过 AUTO_CLAMPED < ALIGNED（0.51 vs 4.60）的那个场景是
    #     「单侧手柄被 Blender 重算」；换成"两侧同类型"就反过来了（4.80 vs 4.60）。
    #     ⇒ 该口径**依赖具体场景**，不适合作回归断言。这里只钉行为契约。
    #     （原始数据见 tests/_vecal_probe.py 的实测输出。）
    _m_clamped = xf._link_mode(_kp, 'right')
    step("U17 ★★ 行为契约：CLAMPED 与 LINK 在联动判据上等价（都 'link'）",
         _m_clamped == 'link' and xf.orig_type_for_feel('CLAMPED') != xf.orig_type_for_feel('LINK'),
         "link_mode=%s | 原始类型 CLAMPED=%s LINK=%s"
         % (_m_clamped, xf.orig_type_for_feel('CLAMPED'),
            xf.orig_type_for_feel('LINK')))

    xf.clear_feel()

    # -----------------------------------------------------------------
    # 9. 右键菜单（RTMP_MT_context_menu）能正常构造
    #
    #    ⚠️ 实测踩坑（2026-09-17 用户报告"菜单只剩 1~2 项，选完更少"）：
    #      `op = layout.operator(...); op.depress = True` 会抛 AttributeError
    #      （OperatorProperties 只声明了 handle_type），**draw() 当场中断，
    #      后面的项全不渲染** ⇒ 菜单项数随"体感"取值变化。
    #    修法：`depress` 必须作为 layout.operator() 的**关键字参数**传。
    # -----------------------------------------------------------------
    _src_ui = open(os.path.join(HERE, "..", "ui.py"), encoding="utf-8").read()
    # 只扫【真代码行】（跳过注释），否则注释里那句反例说明会误判
    _ui_code = [l for l in _src_ui.splitlines()
                if l.strip() and not l.strip().startswith("#")]
    _bad = [l for l in _ui_code
            if ".depress" in l and "=" in l.split(".depress")[1][:2]]
    step("W1 ★★★ 静态契约：菜单高亮必须用 `depress=` 参数，不能对返回的 operator 赋属性",
         len(_bad) == 0 and "depress=" in _src_ui, "可疑行=%s" % _bad[:2])

    # W2 ★★★ draw() 的每一项都用 **真 UILayout 语义**演练一遍。
    #
    #   ⚠️ 不能在 headless 里调 `wm.call_menu` —— 实测会把 Blender 直接打崩
    #      （EXCEPTION_ACCESS_VIOLATION，因为没有真正的 UI 上下文；
    #        `--background` 下没有 window/region 可用）。
    #   ⇒ 改为：用 **真 UILayout 的 RNA 签名**做校验 + 逐条演练 draw 的调用序列。
    #      核心是抓住"给 operator 返回对象设属性"这种致命写法（它会让 draw 中断）。
    _menu_err = None
    try:
        _rna = bpy.types.UILayout.bl_rna.functions.get("operator")
        _params = {p.identifier for p in _rna.parameters}
        _ok_param = "depress" in _params            # depress 是 layout.operator 的参数
        # OperatorProperties 只声明了 handle_type ⇒ 设别的属性必抛
        # （`rna_type` 是每个 RNA 都有的，不算"业务属性"）
        _declared = {p.identifier for p in
                     bpy.ops.rtmp.change_handle_mode.get_rna_type().properties}
        _declared.discard("rna_type")

        class _ProbeOp:
            """模拟 Blender 的 OperatorProperties（只接受已声明的属性）。"""
            def __init__(self, log):
                object.__setattr__(self, "_log", log)
            def __setattr__(self, k, v):
                if k == "handle_type":
                    self._log.append(("set", k, v))
                    return
                raise AttributeError(
                    "'OperatorProperties' object has no attribute '%s'" % k)

        class _ProbeLayout:
            """按真 UILayout 的签名模拟。"""
            def __init__(self):
                self.log = []
                self.err = None
            def column(self, **kw): return self
            def label(self, **kw): return self
            def separator(self, **kw): return self
            def operator(self, idname, text="", depress=False, **kw):
                self.log.append(("op", text, depress))
                return _ProbeOp(self.log)

        # ★★★ 从 ui.py **源码解析**出真实的 (体感取值, 菜单标签) 序列 ——
        #     硬编码项列表抓不到"把 CLAMPED 折回 LINK"这类注入（实测漏抓过）。
        import re as _re
        _ui_src = open(os.path.join(HERE, "..", "ui.py"), encoding="utf-8").read()
        # ⚠️ 不能用 `.split(")")[0]` 截块 —— `iface_("Free")` 里的 `)` 会提前截断
        #    （实测：块内容只剩第一项的开头，正则匹配为空 → 断言假失败）。
        #    改为：从 `items = (` 取到匹配的收尾 `)`（用"缩进 + )"定位）。
        _after = _ui_src.split("items = (", 1)[1]
        _end = _after.find("\n        )")           # 缩进 8 空格的收尾
        _items_blk = _after[:_end] if _end > 0 else _after[:400]
        _ITEMS = _re.findall(r"\('([A-Z_]+)',\s*iface_\(\"([^\"]+)\"\)\)", _items_blk)

        # 逐条演练 draw 的真实调用序列（用**源码里的**项列表）
        _detail = []
        for _cur in ('LINK', 'FREE', 'CLAMPED', 'VECTOR', None):
            _lay = _ProbeLayout()
            _menu_vals = [v for v, _l in _ITEMS]
            _expect_dep = 1 if _cur in _menu_vals else 0
            try:
                for _value, _label in _ITEMS:
                    _o = _lay.operator("rtmp.change_handle_mode", text=_label,
                                       depress=bool(_cur and _value == _cur))
                    _o.handle_type = _value
            except AttributeError as _e:
                _menu_err = "cur=%s → %s" % (_cur, _e)
                break
            _ops = [c for c in _lay.log if c[0] == "op"]
            _n_ops = len(_ops)
            _n_dep = sum(1 for c in _ops if c[2])
            _hl = [c[1] for c in _ops if c[2]]
            _detail.append("cur=%s: %d 项/高亮 %d" % (_cur, _n_ops, _n_dep))
            # ★ 断言：**源码里几项就渲染几项**（不写死项数——写死了改菜单就假失败）
            #   + 高亮恰好 1 项 + 高亮项与该 cur 对应的标签一致
            _expect_hl = [lbl for v, lbl in _ITEMS if v == _cur]
            if _n_ops != len(_ITEMS) or _n_dep != _expect_dep or _hl != _expect_hl:
                _menu_err = "cur=%s: 渲染 %d 项 / 高亮 %s（期望 %s）" % (
                    _cur, _n_ops, _hl, _expect_hl)
                break
        # ★★ 菜单项取值必须与体感语义 1:1（用户拍板：最终 Free / Aligned 两项）
        _vals_ok = ([v for v, _ in _ITEMS] == ['FREE', 'LINK'])
        step("W2 ★★★ 菜单 draw 演练：项取值与源码 1:1、全项渲染、高亮恰好 1 项、不抛异常",
             _menu_err is None and _vals_ok and _ok_param
             and _declared == {"handle_type"} and len(_ITEMS) == 2,
             _menu_err or ("项=%s | %s" % (_ITEMS, " | ".join(_detail))))
    except Exception as _e:
        _menu_err = "harness: %s" % _e
        step("W2 ★★★ 菜单 draw 演练", False, _menu_err)

    xf.clear_feel()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1800:])

flush()
print("FROZEN_LINK_DONE")
os._exit(0)
