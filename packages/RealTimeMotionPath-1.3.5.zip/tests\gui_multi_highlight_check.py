# -*- coding: utf-8 -*-
"""多选高亮 + 端点交互 验收（2026-09-16 第三批）

用户反馈：
  ① 「路径上的颜色高亮在多选情况下可以都显示」
  ② 「手柄端点的交互逻辑和体验还是没还原 blender 曲线对象编辑模式」

② 我实测了原生（Curve Edit Mode）后确定的差异：
   · 原生有 **3 个独立选择标志**：select_control_point / select_left_handle / select_right_handle
   · 端点的"选中态"必须基于 **身份 (frame, side)**，不能用"收集顺序的索引"
     —— 旧实现用 `idx == active_handle_index`，而列表每帧重建 → 索引错位 → 选中态显示不出来
   · 原生支持 **多个端点一起拖拽**（插件之前只处理当前一个）

用法：blender --factory-startup --python tests/gui_multi_highlight_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_mh_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    # ⚠️ headless（--background）下 GPU 模块**默认未初始化**。
    #    后果：`drawing.render_path_overlay()` 第 5 行的 `gpu.state.blend_set('ALPHA')`
    #    会抛 SystemError: "GPU functions for drawing requires the gpu module to be initialized.
    #    See gpu.init." → 整个函数跳到 except → **后面的端点收集代码根本不执行**
    #    → `handle_control_points` 恒为 0（实测：该项得到 0 个端点）。
    #    ⇒ 这不是产品 bug，是测试环境缺一步。实测 `gpu.init()`（Blender 5.2.1, --background）
    #      调用后 `blend_set` 正常 ⇒ 加这一行即可让测试走【完全真实的绘制入口】。
    import gpu as _gpu
    _gpu.init()

    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import overlay as ovmod
    from RealTimeMotionPath import cache as rcache
    from RealTimeMotionPath import drawing as dw
    from RealTimeMotionPath import time_domain as td_mod
    from RealTimeMotionPath.state import _session
    from bpy_extras import view3d_utils

    def build():
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
                       (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]:
            sc.frame_set(f); o.location = loc
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
            fc.update()
        return o, a

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((5, 0, 0)); rv3d.view_distance = 18.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    wm.rtmp_path_display_enabled = True

    def real_render():
        ovr = {"window": win, "screen": win.screen, "area": area,
               "region": region, "space_data": area.spaces.active}
        with bpy.context.temp_override(**ovr):
            dw.render_path_overlay()

    def click(x, y, shift=False):
        class Ev:
            def __init__(self):
                self.type = 'LEFTMOUSE'; self.value = 'PRESS'
                self.mouse_region_x = x; self.mouse_region_y = y
                self.mouse_x = x + region.x; self.mouse_y = y + region.y
                self.shift = shift; self.ctrl = False; self.alt = False
        class FO:
            def report(self, *a, **k):
                pass
        _cls = inter.RTMP_OT_PathPointDrag
        if not getattr(FO, "_patched", False):
            for _nm in dir(_cls):
                if _nm.startswith("__"):
                    continue
                _v = getattr(_cls, _nm, None)
                if callable(_v):
                    try: setattr(FO, _nm, _v.__get__(FO()))
                    except Exception: pass
                elif not isinstance(_v, property):
                    try: setattr(FO, _nm, _v)
                    except Exception: pass
            FO._mouse_pos = None; FO._is_active = True
            FO._timer = None; FO._last_frame = None; FO._patched = True
        return inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context, Ev())

    # =========================================================
    # ① 多选三角 → 每段都高亮
    # =========================================================
    o, act = build()
    sc.frame_set(1); bpy.context.view_layer.update()
    rcache.refresh_position_store(bpy.context)
    _session.clear_speed_handle()
    ovmod.clear_segment_highlight()

    recs = me.collect_speed_handles(act, o, region, rv3d)
    step("① 收集到三角", len(recs) == 6, len(recs))

    # 单选一个 → 1 段高亮
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    inter._update_speed_hover(bpy.context, o, region, rv3d, (600.0, 400.0))
    g1 = ovmod.get_segment_highlights()
    step("① 单选 → 1 段高亮", len(g1) == 1, g1)

    # 多选 3 个（不同关键帧）→ 3 段高亮
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    _session.add_speed_handle(27.0, hd.TRI_DOWN)
    _session.add_speed_handle(1.0, hd.TRI_DOWN)
    inter._update_speed_hover(bpy.context, o, region, rv3d, (600.0, 400.0))
    g3 = ovmod.get_segment_highlights()
    step("★★ ① 多选 3 个 → 3 段都高亮", len(g3) == 3, g3)
    frames_in = sorted(set(x[0] for x in g3))
    step("★ ① 高亮覆盖正确的关键帧", frames_in == [1.0, 14.0, 27.0], frames_in)
    sides_in = sorted(set(x[1] for x in g3))
    step("★ ① 高亮覆盖正确的段（up→left, down→right）",
         sides_in == ['left', 'right'], sides_in)

    # 全选 6 个 → 6 段
    _session.clear_speed_handle()
    for r in recs:
        _session.add_speed_handle(r['frame'], r['tri'])
    inter._update_speed_hover(bpy.context, o, region, rv3d, (600.0, 400.0))
    g6 = ovmod.get_segment_highlights()
    step("★★ ① 全选 6 个 → 6 段都高亮", len(g6) == 6, len(g6))

    # 颜色区分：疏=橙、密=蓝 同时存在
    _session.clear_speed_handle()
    _session.set_single_speed_handle(14.0, hd.TRI_UP)
    _session.add_speed_handle(27.0, hd.TRI_DOWN)
    # 手动把 f14 设成疏（s < S_LIN）、f27 设成密（s > S_LIN）
    # ⚠️ side 必须与三角对应：TRI_UP 管【左段】，TRI_DOWN 管【右段】
    #    （方向：s < S_LIN = 疏/橙；s > S_LIN = 密/蓝）
    _s14 = hd.SIDE_BY_TRI[hd.TRI_UP]      # 'left'
    _s27 = hd.SIDE_BY_TRI[hd.TRI_DOWN]    # 'right'
    kf14, _sp = td_mod.resolve_target(act, o, 14.0, _s14)
    td_mod.write_s(kf14, _s14, 0.15, _sp, act=act, obj=o)          # 疏
    kf27, _sp2 = td_mod.resolve_target(act, o, 27.0, _s27)
    td_mod.write_s(kf27, _s27, 0.90, _sp2, act=act, obj=o)         # 密
    for fc in xf._position_curves(act, o, None):
        fc.update()
    inter._update_speed_hover(bpy.context, o, region, rv3d, (600.0, 400.0))
    g = ovmod.get_segment_highlights()
    colors = {x[0]: ovmod.highlight_color(x[3]) for x in g}
    step("★ ① 不同方向的段用不同颜色（疏=橙 / 密=蓝）",
         any(c == ovmod.SEGMENT_SPARSE_COLOR for c in colors.values())
         and any(c == ovmod.SEGMENT_DENSE_COLOR for c in colors.values()),
         {k: ('橙' if v == ovmod.SEGMENT_SPARSE_COLOR else '蓝') for k, v in colors.items()})

    # 清空 → 无高亮
    _session.clear_speed_handle()
    inter._update_speed_hover(bpy.context, o, region, rv3d, (600.0, 400.0))
    step("① 清空选中 → 无高亮", len(ovmod.get_segment_highlights()) == 0,
         ovmod.get_segment_highlights())

    # =========================================================
    # ② 端点：选中态基于「身份」而非索引
    # =========================================================
    o, act = build()
    _session.clear_endpoints()
    _session.clear_speed_handle()
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True
        fc.update()
    real_render()
    pts = list(_session.handle_control_points)
    # ★ 2026-09-16 起：外侧手柄（首帧 left / 末帧 right）**不画不登记**
    #    （实测外侧不参与任何曲线段，拖了曲线偏差 0.00000000 ⇒ 给了抓取点反而让人"拖了没反应"）
    #    ⇒ 4 关键帧共 **6** 个抓取点：首帧 1（右·空心圆）+ 中间 2 帧各 2 + 末帧 1（左·空心圆）
    step("② render 收集到 6 个端点（外侧不画）", len(pts) == 6, len(pts))

    # 直接按"身份"选中，然后验证绘制判定
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    ok_L = _session.is_endpoint_selected(14.0, 'left')
    ok_R = _session.is_endpoint_selected(14.0, 'right')
    step("★ ② 选中判定基于身份：is_endpoint_selected(14,'left')=True", ok_L, ok_L)
    step("★ ② 同帧另一侧不被误判", ok_R is False, ok_R)
    step("② frame_has_selected_endpoint(14)=True（drawing 靠它画端点）",
         _session.frame_has_selected_endpoint(14.0) is True, "")
    step("② 其它帧不误判",
         _session.frame_has_selected_endpoint(27.0) is False, "")

    # ★ 关键：索引错位不再影响判定（模拟"列表重建导致索引变化"）
    _session.active_handle_index = 999            # 故意设一个无效索引
    real_render()
    pts2 = list(_session.handle_control_points)
    step("★★ ② 索引错位（999）时，应画端点仍被收集（不依赖索引）", len(pts2) == 6,
         len(pts2))
    step("★★ ② 索引错位时，选中判定仍正确（不依赖索引）",
         _session.is_endpoint_selected(14.0, 'left') is True, "")

    # 点击链路：点端点 → 选中（走真实 modal）
    _session.clear_endpoints()
    sp = None
    for p in pts2:
        if abs(p['frame'] - 14.0) < 1e-3 and p['side'] == 'left':
            sp = view3d_utils.location_3d_to_region_2d(region, rv3d, p['position'])
    if sp is not None:
        click(sp.x, sp.y)
    step("★ ② 真实点击 → 端点被选中", _session.is_endpoint_selected(14.0, 'left'),
         _session.selected_handle_endpoints)

    # =========================================================
    # ② 多端点一起拖拽
    # =========================================================
    o, act = build()
    _session.clear_endpoints()
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True
        fc.update()
    real_render()

    def hval(frame, side):
        out = {}
        for fc in xf._position_curves(act, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    h = kp.handle_left if side == 'left' else kp.handle_right
                    out[fc.array_index] = (float(h[0]), float(h[1]))
        return out

    # 选中两个端点（f14-left, f27-left）
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    _session.toggle_endpoint(27.0, 'left')
    step("② 选中两个端点", len(_session.selected_handle_endpoints) == 2,
         _session.selected_handle_endpoints)

    b14 = hval(14.0, 'left'); b27 = hval(27.0, 'left')
    # 走真实拖拽路径
    class FO2:
        """⚠️ 批量绑定【真实类的所有方法】—— 逐个列举会漏（本轮又踩了一次）。"""
        def report(self, *a, **k):
            pass
    _cls2 = inter.RTMP_OT_PathPointDrag
    for _nm in dir(_cls2):
        if _nm.startswith("__"):
            continue
        _v = getattr(_cls2, _nm, None)
        if callable(_v):
            try: setattr(FO2, _nm, _v.__get__(FO2()))
            except Exception: pass
    fo = FO2()
    _session.active_frame_number = 14.0
    _session.active_handle_direction = 'left'
    _session.drag_target_object = "T"
    _session.active_bone_identifier = None
    _session.handle_start_values = {}
    fo.apply_handle_offset(bpy.context, mathutils.Vector((0.0, 3.0, 0.0)), 'left')
    for fc in xf._position_curves(act, o, None):
        fc.update()
    a14 = hval(14.0, 'left'); a27 = hval(27.0, 'left')
    d14 = max(abs(a14[i][1] - b14[i][1]) for i in b14)
    d27 = max(abs(a27[i][1] - b27[i][1]) for i in b27)
    step("★★ ② 拖拽 → f14 端点变了", d14 > 1e-4, "Δ=%.6f" % d14)
    step("★★ ② 拖拽 → f27 端点【也】变了（多端点一起拖）", d27 > 1e-4, "Δ=%.6f" % d27)
    step("★ ② 两个端点的位移量一致（同一位移）",
         abs(d14 - d27) < 1e-4, "Δ14=%.6f Δ27=%.6f" % (d14, d27))

    # 对照：只选一个端点 → 只动它
    o, act = build()
    _session.clear_endpoints()
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = True
        fc.update()
    real_render()
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    b14 = hval(14.0, 'left'); b27 = hval(27.0, 'left')
    _session.handle_start_values = {}
    fo.apply_handle_offset(bpy.context, mathutils.Vector((0.0, 3.0, 0.0)), 'left')
    for fc in xf._position_curves(act, o, None):
        fc.update()
    a14 = hval(14.0, 'left'); a27 = hval(27.0, 'left')
    d14 = max(abs(a14[i][1] - b14[i][1]) for i in b14)
    d27 = max(abs(a27[i][1] - b27[i][1]) for i in b27)
    step("② 对照：只选 1 个端点 → 只动它", d14 > 1e-4 and d27 < 1e-6,
         "Δ14=%.6f Δ27=%.6f" % (d14, d27))

except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("MULTI_HIGHLIGHT_DONE")
os._exit(0)
