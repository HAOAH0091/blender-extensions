# -*- coding: utf-8 -*-
"""D1/D2/D3 验收（2026-09-16，来源：agent 实测报告）

三个真缺陷：

  D1 —— 派生/锁定类型下端点拖拽**写入被吞**（影响最大）
       实测（拖 1.0 单位后的位移比）：
         FREE 1.0000 ✓  ALIGNED 1.0000 ✓
         AUTO 0.0000 ✗  AUTO_CLAMPED 0.0000 ✗  VECTOR 0.0000 ✗
       ⇒ 默认工程（keyframe_insert 给的就是 AUTO_CLAMPED）端点**完全拖不动**
       修：端点模式对派生类型临时转 FREE，结束后恢复

  D2 —— 拖**右**端点被 `fc.update()` 覆盖
       实测：左手柄 ALIGNED 时，update 会按左手柄重算右手柄 → 位移只生效 0.1258/1.0
       修：update 之后把被拖侧再写一遍

  D3 —— 取消不还原手柄**时间分量**（P2 加权改的 dt 无人还原）
       实测：时间残差 7.647692 帧；逐帧采样残留 1.004165
       修：snapshot 记录时间分量，restore 时一并写回

用法：blender --factory-startup --python tests/gui_defect_d123_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_d123_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import transform_domain as xf

    def pt_line_dist(p, a, b):
        ab = b - a
        return 0.0 if ab.length < 1e-12 else (p - a).cross(ab).length / ab.length

    def build(htype=None):
        """htype=None → 用 keyframe_insert 的默认类型（AUTO_CLAMPED）"""
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in [(1, (0.0, 0.0, 0.0)), (20, (4.0, 2.8, 1.6)),
                       (40, (10.0, 7.0, 4.0))]:
            sc.frame_set(f); o.location = loc
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        if htype is not None:
            for fc in xf._position_curves(a, o, None):
                for kp in fc.keyframe_points:
                    kp.handle_left_type = htype
                    kp.handle_right_type = htype
                fc.update()
        return o, a

    def snap(o, a, fr=20.0):
        d = {}
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - fr) < 1e-3:
                    d[fc.array_index] = dict(
                        co=(float(kp.co[0]), float(kp.co[1])),
                        hl=(float(kp.handle_left[0]), float(kp.handle_left[1])),
                        hr=(float(kp.handle_right[0]), float(kp.handle_right[1])),
                        lt=str(kp.handle_left_type), rt=str(kp.handle_right_type))
        return d

    def do_drag(o, a, frame, side, vec, weighted=True):
        ep = xf.snapshot_endpoints(a, o, [(frame, side)], None)
        xf.apply_endpoint_transform(
            a, o, ep, (lambda f, v: v + mathutils.Vector(vec)),
            [(frame, side)], None, weighted=weighted)
        return xf.take_converted_types()

    # =========================================================
    # D1：派生类型下也能拖动 + 类型被恢复
    # =========================================================
    for ht in (None, 'AUTO', 'AUTO_CLAMPED', 'VECTOR', 'FREE', 'ALIGNED'):
        label = ht or '默认(AUTO_CLAMPED)'
        o, act = build(ht)
        b = snap(o, act)
        side = 'left'
        vec = mathutils.Vector((1.0, 0.0, 0.0))
        before_p = mathutils.Vector(b[0]['hl'][1:2] + (b[1]['hl'][1], b[2]['hl'][1]))
        do_drag(o, act, 20.0, side, vec)
        a_ = snap(o, act)
        after_p = mathutils.Vector((a_[0]['hl'][1], a_[1]['hl'][1], a_[2]['hl'][1]))
        moved = (after_p - before_p).length
        step("★ D1 %-18s 端点位移 %.4f / 期望 1.0000" % (label, moved),
             abs(moved - 1.0) < 1e-3, "%.6f" % moved)

    # 类型恢复（取消路径）
    for ht in ('AUTO_CLAMPED', 'AUTO', 'VECTOR'):
        o, act = build(ht)
        t0 = snap(o, act)
        conv = do_drag(o, act, 20.0, 'left', mathutils.Vector((1.0, 0, 0)))
        # 模拟"取消"：恢复类型
        xf.restore_converted_types(act, o, conv, None)
        t1 = snap(o, act)
        same = all(t0[i]['lt'] == t1[i]['lt'] and t0[i]['rt'] == t1[i]['rt'] for i in t0)
        step("★ D1 %-13s 取消后类型恢复原样" % ht, same,
             "%s -> %s" % (t0[0]['lt'], t1[0]['lt']))

    # =========================================================
    # D2：拖右端点也跟手
    # =========================================================
    for vec in ((1.0, 0.0, 0.0), (-2.0, 1.0, 0.5), (3.0, 3.0, 3.0)):
        o, act = build('ALIGNED')
        b = snap(o, act)
        before = mathutils.Vector((b[0]['hr'][1], b[1]['hr'][1], b[2]['hr'][1]))
        do_drag(o, act, 20.0, 'right', vec)
        a_ = snap(o, act)
        after = mathutils.Vector((a_[0]['hr'][1], a_[1]['hr'][1], a_[2]['hr'][1]))
        moved = (after - before).length
        want = mathutils.Vector(vec).length
        step("★ D2 拖右端点 %-16s 位移 %.4f / 期望 %.4f" % (str(vec), moved, want),
             abs(moved - want) < 1e-3, "")
        # 3D 共线
        co3 = mathutils.Vector([a_[i]['co'][1] for i in sorted(a_)])
        hl3 = mathutils.Vector([a_[i]['hl'][1] for i in sorted(a_)])
        hr3 = mathutils.Vector([a_[i]['hr'][1] for i in sorted(a_)])
        d = pt_line_dist(hr3, co3, hl3)
        step("★ D2 拖右端点后 3D 共线（点线距 %.2e）" % d, d < 1e-5, "")

    # =========================================================
    # D3：取消还原【时间分量】
    # =========================================================
    for ht in ('ALIGNED', 'FREE'):
        o, act = build(ht)
        b = snap(o, act)
        ep = xf.snapshot_endpoints(act, o, [(20.0, 'left')], None)
        xf.apply_endpoint_transform(
            act, o, ep, (lambda f, v: v + mathutils.Vector((2.0, 1.0, 0.0))),
            [(20.0, 'left')], None)
        mid = snap(o, act)
        # 还原（走真实路径：restore_positions + reapply + 类型恢复）
        xf.restore_positions(act, o, ep, None)
        xf.reapply_snapshot_handles(act, o, ep, [(20.0, 'left')], None)
        xf.restore_converted_types(act, o, xf.take_converted_types(), None)
        aft = snap(o, act)
        worst_t = 0.0
        for i in b:
            worst_t = max(worst_t,
                          abs(aft[i]['hl'][0] - b[i]['hl'][0]),
                          abs(aft[i]['hr'][0] - b[i]['hr'][0]))
        worst_v = max(max(abs(aft[i]['hl'][1] - b[i]['hl'][1]),
                          abs(aft[i]['hr'][1] - b[i]['hr'][1])) for i in b)
        step("★ D3 %-9s 取消后【时间分量】精确还原（残差 %.2e 帧）" % (ht, worst_t),
             worst_t < 1e-4, "时间最大差=%.6f" % worst_t)
        step("★ D3 %-9s 取消后【值分量】精确还原" % ht, worst_v < 1e-6,
             "值最大差=%.8f" % worst_v)
        # ★★ 2026-09-16（第十轮）**契约反转**：
        #    原断言是"拖拽中途时间确实变了"（用来证明 D3 的还原有意义）。
        #    现在**拖拽全程不再改时间分量** —— 这正是本轮要的
        #    （用户拍板 3D 优先、Graph Editor 不需要共线；改 dt 会抹掉速度分布）。
        #    所以断言反转为"确实没变"，D3 的还原逻辑保留为防御性代码。
        t_changed = max(abs(mid[i]['hr'][0] - b[i]['hr'][0]) for i in b)
        step("★ D3 %-9s （契约）拖拽中途时间分量【未被改动】 %.4f 帧" % (ht, t_changed),
             t_changed < 1e-4, "最大变化=%.6f 帧" % t_changed)

except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("D123_DONE")
os._exit(0)
