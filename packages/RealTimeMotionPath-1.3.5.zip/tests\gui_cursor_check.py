# -*- coding: utf-8 -*-
"""模态光标验收（2026-09-16）：复刻 Blender 原生 G/R/S 的光标变化

═══ 背景 ═══

用户反馈：「Blender 原生进入模态后鼠标光标会发生变化，这部分你也能复刻过来吗？」

═══ 原生行为（**全实测**，见 modal_edit.py 的说明与探针）═══

    | 场景                | 原生光标                  |
    |---------------------|---------------------------|
    | G（自由移动）       | SCROLL_XY（四向箭头）      |
    | G + 锁 X/Y/Z        | SCROLL_XY（**不变**）      |
    | R（旋转）           | NONE（隐藏）               |
    | S（缩放）           | NONE（隐藏）               |
    | 退出                | 自动恢复默认               |

═══ 本测试的断言 ═══

  A. 判据映射 `_cursor_kind_of`（含继承陷阱：ScaleSession 继承 RotateSession）
  B. 光标名**合法性**（动态从 Blender RNA 取枚举，防拼错）
  C. helper 行为：正确设置 / 未定义类别不动 / 无 window 安全 / 异常静默
  D. restore 幂等 + 安全
  E. 静态契约：4 个进入点 + 3 个退出点真的接上了

用法：blender --background --factory-startup --python tests/gui_cursor_check.py
"""
import bpy, os, sys, json, traceback, ast

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_cur_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me

    # =====================================================================
    # A. 判据映射（含继承陷阱）
    # =====================================================================
    def kind(sess):
        try:
            return me._cursor_kind_of(sess)
        except Exception as e:
            return "EXC:%r" % e

    k_move = kind(me.MoveSession('MOVE'))
    step("A MoveSession → 'MOVE'", k_move == 'MOVE', k_move)

    k_rot = kind(me.RotateSession('ROTATE'))
    step("A RotateSession → 'ROTATE'", k_rot == 'ROTATE', k_rot)

    k_scl = kind(me.ScaleSession('SCALE'))
    step("★ A ScaleSession → 'SCALE'", k_scl == 'SCALE', k_scl)

    # ★ 反向探针：证明"继承"在这里**确实是**个坑（不是我空口说）——
    #   若实现改用 isinstance 且先判父类 RotateSession，Scale 实例会被吞掉、
    #   误判成 ROTATE（缩放的光标就错了）。
    #   当前实现用 `type().__name__` **精确匹配**，所以避开了它。
    def naive_isinstance_kind(s):
        if isinstance(s, me.RotateSession):      # ← 先判父类：Scale 实例也会命中
            return 'ROTATE'
        if isinstance(s, me.ScaleSession):
            return 'SCALE'
        return None

    _sc = me.ScaleSession('SCALE')
    mis = naive_isinstance_kind(_sc)
    step("★[probe] isinstance 写法会把 Scale 误判成 ROTATE（证明必须用精确类名）",
         mis == 'ROTATE' and isinstance(_sc, me.RotateSession) is True,
         "naive_isinstance 结果=%s  |  type().__name__=%s  |  isinstance(_,RotateSession)=%s"
         % (mis, type(_sc).__name__, isinstance(_sc, me.RotateSession)))

    k_spd = kind(me.ModalSession('SPEED'))
    step("A ModalSession('SPEED') → 'SPEED'", k_spd == 'SPEED', k_spd)

    step("A session=None → None（不猜）", kind(None) is None, kind(None))

    # =====================================================================
    # B. 光标名合法性 —— 动态从 Blender RNA 取枚举，防拼错
    # =====================================================================
    legal = set()
    for f in bpy.types.Window.bl_rna.functions:
        if f.identifier in ('cursor_modal_set', 'cursor_set'):
            for p in f.parameters:
                if p.type == 'ENUM':
                    legal |= {i.identifier for i in p.enum_items}
    step("B 能读到 Blender 的合法光标名", len(legal) >= 20, "共 %d 种" % len(legal))

    bad = {k: v for k, v in me._CURSOR_FOR_KIND.items() if v not in legal}
    step("★★ B 映射里的光标名**全部合法**（拼错的话这里会抓到）",
         not bad, "非法项=%s  |  映射=%s" % (bad, me._CURSOR_FOR_KIND))

    # ★★ 2026-09-16 二次修正：**R = NONE**（隐藏系统光标，箭头改自绘）。
    #    原因：原生旋转箭头会【跟着鼠标绕支点转】，系统光标 MOVE_Y 是固定方向的、做不到。
    #    原生正是「隐藏系统光标 + 自绘」→ 我们也照做（见 overlay.draw_double_arrow_2d）。
    #    ⚠️ S 仍用系统光标 MOVE_X（用户说「s 没啥问题」，不擅自扩大改动）。
    expect = {'MOVE': 'SCROLL_XY', 'ROTATE': 'NONE',
              'SCALE': 'NONE', 'SPEED': 'MOVE_Y'}
    step("B 四类映射与实测一致（MOVE=SCROLL_XY / **R,S=NONE 自绘** / SPEED=MOVE_Y）",
         me._CURSOR_FOR_KIND == expect, str(me._CURSOR_FOR_KIND))
    step("★★ B R 必须是 NONE（隐藏系统光标 → 改由 overlay 自绘会转的箭头）",
         me._CURSOR_FOR_KIND['ROTATE'] == 'NONE', "R=%s" % me._CURSOR_FOR_KIND['ROTATE'])
    step("★★ B S 也必须是 NONE（用户 2026-09-16：「S 也要旋转的，一起做了吧」——"
         "系统光标 MOVE_X 同样是固定方向、不会转）",
         me._CURSOR_FOR_KIND['SCALE'] == 'NONE', "S=%s" % me._CURSOR_FOR_KIND['SCALE'])

    # =====================================================================
    # C. helper 行为（FakeCtx / FakeWin）
    # =====================================================================
    class FakeWin:
        def __init__(self, raise_on_set=False):
            self.calls = []
            self.raise_on_set = raise_on_set
        def cursor_modal_set(self, cursor):
            if self.raise_on_set:
                raise RuntimeError("boom")
            self.calls.append(('set', cursor))
        def cursor_modal_restore(self):
            self.calls.append(('restore',))

    class FakeCtx:
        def __init__(self, win):
            self.window = win

    for sess, want in ((me.MoveSession('MOVE'), 'SCROLL_XY'),
                       (me.RotateSession('ROTATE'), 'NONE'),
                       (me.ScaleSession('SCALE'), 'NONE'),
                       (me.ModalSession('SPEED'), 'MOVE_Y')):
        w = FakeWin()
        ok = me.set_modal_cursor(FakeCtx(w), sess)
        got = [c[1] for c in w.calls if c[0] == 'set']
        step("C %-22s → cursor_modal_set('%s')" % (type(sess).__name__, want),
             ok is True and got == [want], "ok=%s calls=%s" % (ok, w.calls))

    # 未定义类别 → 不碰光标（保持 Blender 默认）
    class Unknown:
        mode = 'WHATEVER'
    w = FakeWin()
    ok = me.set_modal_cursor(FakeCtx(w), Unknown())
    step("★ C 未定义类别 → **不动**光标（保持 Blender 默认，不乱设）",
         ok is False and w.calls == [], "ok=%s calls=%s" % (ok, w.calls))

    # None session → 不碰
    w = FakeWin()
    ok = me.set_modal_cursor(FakeCtx(w), None)
    step("C session=None → 不动光标", ok is False and w.calls == [], "ok=%s calls=%s" % (ok, w.calls))

    # 无 window（背景模式）→ 静默 False，不抛
    try:
        ok = me.set_modal_cursor(FakeCtx(None), me.MoveSession('MOVE'))
        step("★ C 无 window（背景模式）→ 静默返回 False，不抛异常", ok is False, "ok=%s" % ok)
    except Exception as e:
        step("★ C 无 window（背景模式）→ 静默返回 False，不抛异常", False, repr(e))

    # window 抛异常 → 静默（不能让模态起不来）
    w = FakeWin(raise_on_set=True)
    try:
        ok = me.set_modal_cursor(FakeCtx(w), me.MoveSession('MOVE'))
        step("★ C cursor_modal_set 抛异常 → 静默返回 False（不阻断模态）", ok is False, "ok=%s" % ok)
    except Exception as e:
        step("★ C cursor_modal_set 抛异常 → 静默返回 False（不阻断模态）", False, repr(e))

    # =====================================================================
    # D. restore 幂等 + 安全
    # =====================================================================
    w = FakeWin()
    r1 = me.restore_modal_cursor(FakeCtx(w))
    r2 = me.restore_modal_cursor(FakeCtx(w))
    step("★ D restore 可重复调用（幂等）—— 所以 _finish 与 cancel 都调是安全的",
         r1 is True and r2 is True and w.calls == [('restore',), ('restore',)],
         "r1=%s r2=%s calls=%s" % (r1, r2, w.calls))

    try:
        ok = me.restore_modal_cursor(FakeCtx(None))
        step("D 无 window 时 restore 安全", ok is False, "ok=%s" % ok)
    except Exception as e:
        step("D 无 window 时 restore 安全", False, repr(e))

    # =====================================================================
    # E. 静态契约：接入点是否真的接上了（AST）
    # =====================================================================
    src = open(os.path.join(REPO, "modal_edit.py"), encoding="utf-8").read()
    tree = ast.parse(src)

    def calls_in(node):
        return {n.func.id for n in ast.walk(node)
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}

    def find_class(name):
        for n in tree.body:
            if isinstance(n, ast.ClassDef) and n.name == name:
                return n
        return None

    def find_func(cls, name):
        for n in cls.body:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name:
                return n
        return None

    ME_CLS = find_class("RTMP_OT_ModalEdit")
    KT_CLS = find_class("RTMP_OT_KeyboardTransform")
    step("E 找到两个模态 Operator 类", ME_CLS is not None and KT_CLS is not None, "")

    # E1 ModalEdit.invoke 设光标
    f = find_func(ME_CLS, "invoke")
    step("★★ E ModalEdit.invoke 调用了 set_modal_cursor",
         "set_modal_cursor" in calls_in(f), str(calls_in(f) & {"set_modal_cursor"}))

    # E2 ModalEdit._finish / cancel 恢复
    for fn in ("_finish", "cancel"):
        f = find_func(ME_CLS, fn)
        step("★★ E ModalEdit.%s 调用了 restore_modal_cursor" % fn,
             f is not None and "restore_modal_cursor" in calls_in(f),
             "" if f is not None else "方法不存在")

    # E3 KeyboardTransform.invoke 设光标（两个分支 → 至少 2 处调用）
    f = find_func(KT_CLS, "invoke")
    n_set = sum(1 for n in ast.walk(f) if isinstance(n, ast.Call)
                and isinstance(n.func, ast.Name) and n.func.id == "set_modal_cursor")
    step("★★ E KeyboardTransform.invoke 有 **2 处** set_modal_cursor（SPEED 分支 + R/S 分支）",
         n_set == 2, "实测 %d 处" % n_set)

    # E4 KeyboardTransform._finish / cancel 恢复
    for fn in ("_finish", "cancel"):
        f = find_func(KT_CLS, fn)
        step("★★ E KeyboardTransform.%s 调用了 restore_modal_cursor" % fn,
             f is not None and "restore_modal_cursor" in calls_in(f),
             "" if f is not None else "★ 方法不存在（模态被外部取消时光标会卡住）")

    # =====================================================================
    # F. 鼠标引导虚线（复刻原生 R/S 的"支点 → 鼠标"虚线，2026-09-16）
    # =====================================================================
    from RealTimeMotionPath import overlay as ovl

    step("★★ F RotateSession.mouse_guide = 'tangent'（R 要画**切向**双向箭头，随鼠标转）",
         getattr(me.RotateSession('ROTATE'), 'mouse_guide', None) == 'tangent',
         "mouse_guide=%r" % getattr(me.RotateSession('ROTATE'), 'mouse_guide', None))

    step("★ F overlay 有 draw_double_arrow_2d（自绘会转的箭头）",
         callable(getattr(ovl, 'draw_double_arrow_2d', None)), "")
    try:
        ovl.draw_double_arrow_2d((10.0, 10.0), (0.0, 0.0))      # 零方向
        ovl.draw_double_arrow_2d((10.0, 10.0), (1.0, 1.0))      # 正常
        step("★ F draw_double_arrow_2d 零方向安全 + 正常方向不抛", True, "")
    except Exception as e:
        step("★ F draw_double_arrow_2d 零方向安全 + 正常方向不抛", False, repr(e))

    # 方向语义：切线 = 垂直于连线，不是沿连线
    def arrow_dir(p1, p2, mode):
        dx, dy = p2[0] - p1[0], p2[1] - p1[1]
        ln = (dx * dx + dy * dy) ** 0.5
        if ln < 1e-9:
            return None
        return (-dy / ln, dx / ln) if mode == 'tangent' else (dx / ln, dy / ln)

    a = arrow_dir((0, 0), (100, 0), 'tangent')
    step("★★ F 切向箭头方向：连线水平时箭头应**垂直** (0,1)",
         a is not None and abs(a[0]) < 1e-9 and abs(abs(a[1]) - 1.0) < 1e-9, "%s" % (a,))
    b = arrow_dir((0, 0), (100, 0), 'radial')
    step("★★ F 径向箭头方向：连线水平时箭头应**水平** (1,0)",
         b is not None and abs(b[0] - 1.0) < 1e-9 and abs(b[1]) < 1e-9, "%s" % (b,))
    step("★ F RotateSession.mouse_guide 按 'tangent' 驱动（= 上一条的切向语义）",
         getattr(me.RotateSession('ROTATE'), 'mouse_guide', None) == 'tangent', "")
    step("★★ F ScaleSession.mouse_guide 必须是 'radial'（S 要画**径向**箭头，∥ 连线）"
         "—— 父类是 'tangent'（切向 ⊥ 连线），子类不覆盖就会画反",
         getattr(me.ScaleSession('SCALE'), 'mouse_guide', None) == 'radial',
         "mouse_guide=%r" % getattr(me.ScaleSession('SCALE'), 'mouse_guide', None))
    step("★ F MoveSession **不画**虚线（原生 G 用的是系统光标，没有引导线）",
         not getattr(me.MoveSession('MOVE'), 'mouse_guide', False),
         "mouse_guide=%s" % getattr(me.MoveSession('MOVE'), 'mouse_guide', None))

    step("★ F overlay 有 draw_dashed_line_2d",
         callable(getattr(ovl, 'draw_dashed_line_2d', None)), "")
    step("★ F Overlay 有 _draw_mouse_guide 方法",
         hasattr(ovl.Overlay, '_draw_mouse_guide'), "")

    # 零长度安全（鼠标正好在支点上时不能炸）
    try:
        ovl.draw_dashed_line_2d((10.0, 10.0), (10.0, 10.0), (1, 1, 1, 1))
        step("★ F draw_dashed_line_2d 零长度安全（鼠标压在支点上）", True, "")
    except Exception as e:
        step("★ F draw_dashed_line_2d 零长度安全（鼠标压在支点上）", False, repr(e))

    # _draw_2d 必须在 early return 之前调用引导线（R/S 模态没有速度手柄记录）
    src_ovl = open(os.path.join(REPO, "overlay.py"), encoding="utf-8").read()
    tree_ovl = ast.parse(src_ovl)
    ov_cls = None
    for n in tree_ovl.body:
        if isinstance(n, ast.ClassDef) and n.name == "Overlay":
            ov_cls = n
    d2d = None
    for n in (ov_cls.body if ov_cls else []):
        if isinstance(n, ast.FunctionDef) and n.name == "_draw_2d":
            d2d = n
    ok_order = False
    call_idx = ret_idx = None
    if d2d:
        for i, st in enumerate(d2d.body):
            if isinstance(st, ast.Expr) and isinstance(st.value, ast.Call):
                f = st.value.func
                if isinstance(f, ast.Attribute) and f.attr == "_draw_mouse_guide":
                    call_idx = i
                if isinstance(f, ast.Attribute) and f.attr == "_handle_records":
                    ret_idx = i
            if isinstance(st, ast.If) and 'recs' in ast.dump(st.test):
                if ret_idx is None:
                    ret_idx = i
    ok_order = (call_idx is not None and ret_idx is not None and call_idx <= ret_idx)
    step("★★ F _draw_2d 里引导虚线画在 early return **之前**（否则 R/S 模态根本画不出来）",
         ok_order, "guide@%s earlyreturn@%s" % (call_idx, ret_idx))

    # =====================================================================
    # G. ★★ 绘制集成：箭头真的跟着鼠标绕支点转（2026-09-16）
    #
    #    用户反馈：「原生旋转模态的光标会跟随旋转操作一起旋转，我们的一直保持 Y 轴方向」
    #    ⇒ 必须自绘。这里直接驱动 Overlay._draw_mouse_guide 验证方向。
    # =====================================================================
    try:
        import math as _m
        from RealTimeMotionPath import transform_domain as xf
        _arrow = []
        _dash = []
        _oa, _od = ovl.draw_double_arrow_2d, ovl.draw_dashed_line_2d

        def _spy_a(center, direction, *a, **k):
            _arrow.append(round(_m.degrees(_m.atan2(direction[1], direction[0])), 4))
            return _oa(center, direction)

        def _spy_d(p1, p2, color, *a, **k):
            _dash.append((tuple(p1), tuple(p2)))
            return _od(p1, p2, color)

        ovl.draw_double_arrow_2d, ovl.draw_dashed_line_2d = _spy_a, _spy_d

        # 场景
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        ob2 = bpy.context.view_layer.objects.active
        sc2 = bpy.context.scene
        sc2.frame_start, sc2.frame_end = 1, 60
        for f, lc in ((1, (0.0, 0.0, 0.0)), (30, (4.0, 3.0, 1.0)), (60, (10.0, -2.0, 2.0))):
            sc2.frame_set(f)
            ob2.location = lc
            ob2.keyframe_insert("location", frame=f)
        act2 = ob2.animation_data.action
        for fc in xf._position_curves(act2, ob2, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - 30.0) < 1e-3:
                    kp.select_control_point = True
        sc2.frame_set(30)
        _win = bpy.context.window
        _area = next(a for a in _win.screen.areas if a.type == 'VIEW_3D')
        _reg = next(r for r in _area.regions if r.type == 'WINDOW')
        _rv = _area.spaces.active.region_3d

        ov = ovl.get_overlay()
        rs = me.RotateSession('ROTATE')
        rs.begin(ob2, act2, _reg, _rv, 0, 0, None)
        rs.state = me.STATE_RUNNING
        ov._session = rs
        sp0 = rs._pivot_screen()

        ok_perp, ok_rot = True, []
        # ⚠️ 角度要**等步进**（全 45°），否则相邻增量不齐、断言会误判
        for deg in (0, 45, 90, 135, 180, 225):
            th = _m.radians(deg)
            mx, my = sp0.x + 400.0 * _m.cos(th), sp0.y + 400.0 * _m.sin(th)
            rs.mouse_screen = (mx, my)
            del _arrow[:]
            ov._draw_mouse_guide()
            if len(_arrow) != 1:
                ok_perp = False
                break
            line = _m.degrees(_m.atan2(my - sp0.y, mx - sp0.x))
            diff = (_arrow[0] - (line + 90.0) + 180.0) % 360.0 - 180.0
            if abs(diff) > 1e-6:
                ok_perp = False
            ok_rot.append(round(_arrow[0], 2))
        step("★★ G R：箭头**永远垂直于连线**（切向），6 个鼠标角度 ⊥ 误差全 0",
             ok_perp, "各角度箭头方向=%s" % ok_rot)
        # ⚠️ 别用 sorted() 判"跟着转" —— 角度会绕回 (−180/180)，排序不成立。
        #    正确判据：相邻角度的**增量**应恒等于鼠标的步进（本例 45°）。
        _deltas = [round((ok_rot[(i + 1) % len(ok_rot)] - ok_rot[i] + 180.0) % 360.0 - 180.0, 4)
                   for i in range(len(ok_rot) - 1)]
        step("★★ G R：箭头方向**随鼠标绕支点转**（不是固定 Y 轴 —— 这正是用户报的问题）",
             len(set(ok_rot)) == 6 and all(abs(dd - 45.0) < 1e-6 for dd in _deltas),
             "箭头方向=%s 相邻增量=%s（应全 ≈45°；若全相同说明没跟着转）" % (ok_rot, _deltas))

        # S：也自绘（用户 2026-09-16：「S 也要旋转的，一起做了吧」）
        #    方向 = **径向**（∥ 连线），与 R 的切向（⊥ 连线）相反
        ss = me.ScaleSession('SCALE')
        ss.begin(ob2, act2, _reg, _rv, 0, 0, None)
        ss.state = me.STATE_RUNNING
        ss.mouse_screen = (sp0.x + 300, sp0.y)
        ov._session = ss
        del _arrow[:]; del _dash[:]
        ov._draw_mouse_guide()
        step("★★ G S：**也画箭头**（不再是只有系统光标）",
             len(_arrow) == 1 and len(_dash) == 1,
             "arrow=%d dash=%d" % (len(_arrow), len(_dash)))
        line_s = _m.degrees(_m.atan2(0.0, 300.0))     # 鼠标在正右方 → 连线 0°
        diff_s = (_arrow[0] - line_s + 180.0) % 360.0 - 180.0 if _arrow else None
        step("★★ G S：箭头方向**平行**于连线（径向，0°）—— 与 R 的垂直相反",
             diff_s is not None and abs(diff_s) < 1e-6, "箭头=%.3f° 连线=%.1f°" % (_arrow[0], line_s))

        # 两段式形态（照原生截图的实测形态：两段分离、中间留空隙）
        _v = ovl.arrow_verts_2d((0.0, 0.0), (1.0, 0.0))
        _ts = [p[0] for p in _v]                       # 沿 x 轴的投影
        _inner = min(abs(t) for t in _ts)              # 离中心最近的点
        step("★★ G 箭头是【两段分离】（不是一根连续线段）—— 中心留空档、虚线穿过去",
             len(_v) == 12 and _inner >= ovl.ARROW_GAP / 2.0 - 1e-9,
             "顶点数=%d 离中心最近点=%.2f (期望 gap/2=%.2f)"
             % (len(_v), _inner, ovl.ARROW_GAP / 2.0))
        step("★ G 箭头总跨度 ≈ 40px（实测原生 2×ARROW_HALF）",
             abs(max(_ts) - min(_ts)) - 2 * ovl.ARROW_HALF < 1e-9,
             "跨度=%.1f 期望=%.1f" % (max(_ts) - min(_ts), 2 * ovl.ARROW_HALF))

        # 箭尖几何（照原生截图的逐像素 ASCII 分析锁定：
        #   斜笔长 ≈9px、两斜笔末端间距 ≈12px）
        _h1 = _m.dist(_v[1], _v[3])          # 段1 斜笔1 长度
        _h2 = _m.dist(_v[1], _v[5])          # 段1 斜笔2 长度
        _hw = _m.dist(_v[3], _v[5])          # 两斜笔末端间距
        step("★ G 箭尖斜笔长 ≈ 9px（实测原生 ≈9）", abs(_h1 - 9.0) < 0.05 and abs(_h2 - 9.0) < 0.05,
             "h1=%.2f h2=%.2f" % (_h1, _h2))
        step("★ G 两斜笔末端间距 ≈ 12px（实测原生 ≈12）", abs(_hw - 11.6) < 0.5,
             "间距=%.2f (2×head×sin40°=%.2f)"
             % (_hw, 2 * ovl.ARROW_HEAD * _m.sin(_m.radians(ovl.HEAD_ANGLE))))
        step("★ G 箭尖**朝外**（段1 的斜笔从尖端朝中心方向张开，段2 反之）",
             True if _v[1][0] > _v[3][0] and _v[7][0] < _v[9][0] else False,
             "段1 尖端x=%.1f 斜笔末端x=%.1f / 段2 尖端x=%.1f 末端x=%.1f"
             % (_v[1][0], _v[3][0], _v[7][0], _v[9][0]))
        step("★ G 零方向 / 非法 gap 不炸",
             ovl.arrow_verts_2d((0.0, 0.0), (0.0, 0.0)) == []
             and len(ovl.arrow_verts_2d((0.0, 0.0), (1.0, 0.0), half=5.0, gap=20.0)) == 12,
             "")

        # Move 都不画
        ms2 = me.MoveSession('MOVE')
        ms2.state = me.STATE_RUNNING
        ms2.mouse_screen = (sp0.x + 300, sp0.y)
        ov._session = ms2
        del _arrow[:]; del _dash[:]
        ov._draw_mouse_guide()
        step("★ G Move：虚线与箭头都不画", len(_arrow) == 0 and len(_dash) == 0,
             "arrow=%d dash=%d" % (len(_arrow), len(_dash)))

        ovl.draw_double_arrow_2d, ovl.draw_dashed_line_2d = _oa, _od
        ov._session = None
    except Exception:
        step("G 绘制集成", False, traceback.format_exc()[-600:])

    # E5 判据收敛：不应该有第二处"自己判断该用哪个光标"的地方
    direct = [n for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
              and n.func.attr == 'cursor_modal_set']
    step("★★ E 全模块只有 helper 内部 1 处直接调 cursor_modal_set（判据收敛，不许散落）",
         len(direct) == 1, "实测 %d 处" % len(direct))

except Exception:
    step("FATAL", False, traceback.format_exc()[-1500:])

flush()
print("CURSOR_CHECK_DONE")
os._exit(0)
