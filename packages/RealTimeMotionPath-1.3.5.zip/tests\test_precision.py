# -*- coding: utf-8 -*-
"""精度模式行为验证（headless，用可编程的假投影）

复现用户报告："按住 shift 进入精度模式时物体跳回原来的位置"。

期望（Blender 原生行为）：
  1. 切精度瞬间      -> 位置不变（不跳）
  2. 精度下移动      -> 位移是全速的 1/10
  3. 切回全速瞬间    -> 位置不变（不跳）
  4. 总位移 = 各段按各自速率累积（增量法）
  5. 反复切换不漂移
"""
import sys, os, json, types, importlib

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    pkg = types.ModuleType(PKG); pkg.__path__ = [ADDON_DIR]; pkg.__package__ = PKG
    sys.modules[PKG] = pkg

import bpy, mathutils
td = importlib.import_module(PKG + ".time_domain")
xf = importlib.import_module(PKG + ".transform_domain")
me = importlib.import_module(PKG + ".modal_edit")

results = []
def check(n, ok, d=""):
    results.append(("PASS" if ok else "FAIL", n, str(d)))


# ---------------- 假投影：屏幕 y 每 1px = 世界 y 0.1 单位（线性可预测） ----------------
PX_TO_WORLD = 0.1
START_PY = 400.0

def fake_2d_to_3d(region, rv3d, coord2d, depth_pos):
    return mathutils.Vector((depth_pos.x,
                             depth_pos.y + (START_PY - coord2d.y) * PX_TO_WORLD,
                             depth_pos.z))

me.view3d_utils.region_2d_to_location_3d = fake_2d_to_3d


# ---------------- 场地 ----------------
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 40
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
obj = bpy.context.view_layer.objects.active
obj.name = "T"
for f, loc in [(1, (0, 0, 0)), (14, (4, 0, 0)), (27, (8, 0, 0)), (40, (12, 0, 0))]:
    sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
act = obj.animation_data.action

for fc in xf._position_curves(act, obj, None):
    for kp in fc.keyframe_points:
        kp.select_control_point = (abs(kp.co[0] - 14) < 0.5)
        kp.handle_left_type = 'FREE'
        kp.handle_right_type = 'FREE'
    fc.update()


def ypos():
    for fc in xf._position_curves(act, obj, None):
        if fc.array_index == 1:
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - 14) < 0.5:
                    return kp.co[1]
    return None


class C:
    pass
c = C()
c.region = object()
c.region_data = object()

base = ypos()

# ---------------- 自由拖 100px -> 开精度 -> 再拖 100px ----------------
s = me.MoveSession('MOVE')
ok = s.begin(obj, act, c.region, c.region_data, 0.0, START_PY)
check("begin", ok is True, s.message)

s.update(0.0, START_PY - 100)          # 上移 100px（自由）
p1 = ypos()
check("free drag 100px moved something", abs(p1 - base) > 1e-6, "dy=%.5f" % (p1 - base))

# --- 开精度，鼠标不动 ---
s.set_precision(True)
s.update(0.0, START_PY - 100)          # 同一个鼠标位置
p2 = ypos()
check("★ Shift ON with mouse still -> NO JUMP", abs(p2 - p1) < 1e-9,
      "p1=%.6f p2=%.6f delta=%.9f" % (p1, p2, p2 - p1))

# --- 精度下再拖 100px ---
s.update(0.0, START_PY - 200)
p3 = ypos()
full100 = p1 - base
prec100 = p3 - p2
check("★ precision drag 100px == 1/10 of free",
      abs(prec100 - full100 * 0.1) < 1e-6,
      "free=%.6f precise=%.6f ratio=%.4f" % (full100, prec100, prec100 / full100 if full100 else 0))

# --- 关精度，鼠标不动 ---
s.set_precision(False)
s.update(0.0, START_PY - 200)
p4 = ypos()
check("★ Shift OFF with mouse still -> NO JUMP", abs(p4 - p3) < 1e-9,
      "p3=%.6f p4=%.6f delta=%.9f" % (p3, p4, p4 - p3))

# --- 恢复全速再拖 100px ---
s.update(0.0, START_PY - 300)
p5 = ypos()
check("full speed resumes after Shift OFF", abs((p5 - p4) - full100) < 1e-6,
      "dy=%.6f expect=%.6f" % (p5 - p4, full100))

# --- 总位移核对 ---
total = p5 - base
expect = full100 * (1 + 0.1 + 1)
check("★ total = 100px + 10px(precision) + 100px", abs(total - expect) < 1e-5,
      "total=%.6f expect=%.6f" % (total, expect))

# --- 反复切换不应漂移 ---
s2 = me.MoveSession('MOVE')
s2.begin(obj, act, c.region, c.region_data, 0.0, START_PY)
s2.update(0.0, START_PY - 100)
q1 = ypos()
for _ in range(10):
    s2.set_precision(True);  s2.update(0.0, START_PY - 100)
    s2.set_precision(False); s2.update(0.0, START_PY - 100)
q2 = ypos()
check("repeated Shift toggling does not drift", abs(q2 - q1) < 1e-9,
      "q1=%.9f q2=%.9f" % (q1, q2))

# ⚠️ 上面的用例把位置一路推到了 31，基准已失效。
#    后面的用例必须【重新建场】——否则测的是被污染的状态（这坑踩过好几次）。
def rebuild():
    global obj, act, base
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc2 = bpy.context.scene
    sc2.frame_start, sc2.frame_end = 1, 40
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.view_layer.objects.active
    o.name = "T"
    for f, loc in [(1, (0, 0, 0)), (14, (4, 0, 0)), (27, (8, 0, 0)), (40, (12, 0, 0))]:
        sc2.frame_set(f); o.location = loc; o.keyframe_insert("location", frame=f)
    a = o.animation_data.action
    for fc in xf._position_curves(a, o, None):
        for kp in fc.keyframe_points:
            kp.select_control_point = (abs(kp.co[0] - 14) < 0.5)
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()
    obj, act = o, a
    base = ypos()


# --- 一上来就开精度 ---
rebuild()
s3 = me.MoveSession('MOVE')
s3.begin(obj, act, c.region, c.region_data, 0.0, START_PY)
s3.set_precision(True)
s3.update(0.0, START_PY - 100)
r1 = ypos() - base
check("precision from the very start == 1/10", abs(r1 - full100 * 0.1) < 1e-6,
      "%.6f vs %.6f" % (r1, full100 * 0.1))

# --- 取消后仍能精确恢复 ---
s3.cancel()
check("cancel restores after precision", abs(ypos() - base) < 1e-9,
      "%.6f vs %.6f" % (ypos(), base))


fails = [r for r in results if r[0] == "FAIL"]
summary = {
    "total": len(results),
    "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in results],
}
json.dump(summary, open(os.path.join(HERE, "_prec_result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("WROTE_PREC_JSON")
