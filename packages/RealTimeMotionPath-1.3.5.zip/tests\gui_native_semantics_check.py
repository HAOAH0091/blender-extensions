# -*- coding: utf-8 -*-
"""原生语义对齐 + 跳变修复 验收测试（2026-09-16）

用户诉求（原话）：
  「我预期的效果和 blender 原生的曲线对象的编辑模式一样，
    原生的曲线对象的编辑模式下就算用户只选中一个点也可以进行 G\\R\\S 操作的，
    而且贝塞尔手柄也是一样可以操作的」

权威依据（Blender 官方手册 · Curve Editing）：
  "A Bézier curve can be edited by transforming the locations of
   **both control points and handles**."
  "curve control points and handles **can be moved, rotated, or scaled**"

→ 即：**co 与 handle 是三个独立的可变换顶点**。

本测试钉死：
  A. 单点旋转 = 该点的手柄绕它自己转（co 不动、handle 转）
     （这正是"只选一个点也能 R"有反应的原因）
  B. 多点旋转 = 整体旋转，且**手柄一起转**（不是平移）
  C. 手柄显示因子恒为 1.0（修掉"一拖就跳变、无限跳变"）
  D. 缩放同理：单点时手柄缩放、多点时整体缩放
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_ns_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 3.0, 0.0)),
           (27, (8.0, -2.0, 1.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import drawing as dw

    fcs = xf._position_curves(act, obj, None)

    def reset(htype='FREE'):
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype; kp.handle_right_type = htype
            fc.update()
        for f, loc in KFS:
            for fc in fcs:
                for kp in fc.keyframe_points:
                    if abs(kp.co[0]-f) < 0.5:
                        kp.co = (kp.co[0], loc[fc.array_index])
            for fc in fcs: fc.update()

    def full_state(frame):
        """该关键帧的完整数据：co / hl / hr（各轴值）。"""
        d = {}
        for fc in fcs:
            for kp in fc.keyframe_points:
                if abs(kp.co[0]-frame) < 0.5:
                    d[fc.array_index] = (float(kp.co[1]),
                                         float(kp.handle_left[1]),
                                         float(kp.handle_right[1]))
        return d

    def sel(frames):
        want = [float(f) for f in frames]
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.select_control_point = any(abs(kp.co[0]-f) < 0.5 for f in want)
            fc.update()

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0)); rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))   # 顶视：旋转轴 = 世界 Z
    bpy.context.view_layer.update()

    # =========================================================
    # A. 单点旋转 = 手柄绕它自己转
    # =========================================================
    reset(); sel([14])
    before = full_state(14.0)
    s = me.RotateSession('ROTATE')
    ok = s.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("A: 单点也能 begin（不再被拒绝）", ok is True, s.message)
    if ok:
        s.apply_numeric(45.0)          # 精确转 45°
        after = full_state(14.0)
        co_same = all(abs(after[i][0] - before[i][0]) < 1e-6 for i in before)
        step("★ A: 单点旋转 → co 位置【不动】（pivot = 它自己）", co_same,
             "co: %s -> %s" % ([round(before[i][0],4) for i in sorted(before)],
                               [round(after[i][0],4) for i in sorted(after)]))
        hl_moved = any(abs(after[i][1] - before[i][1]) > 1e-4 for i in before)
        hr_moved = any(abs(after[i][2] - before[i][2]) > 1e-4 for i in before)
        step("★ A: 单点旋转 → 手柄【方向变了】（这才算有反应）",
             hl_moved and hr_moved,
             "hl: %s -> %s" % ([round(before[i][1],4) for i in sorted(before)],
                               [round(after[i][1],4) for i in sorted(after)]))
        # 手柄绕 co 旋转：**三维距离**应守恒（纯旋转，不是平移）
        def d3(state, k):
            """手柄 k（1=左, 2=右）到 co 的三维距离。

            state 形如 {轴: (co值, hl值, hr值)}；要**按轴组装**回三维点才能算距离。
            """
            axes = sorted(state)
            co = tuple(state[a][0] for a in axes)
            h = tuple(state[a][k] for a in axes)
            return math.sqrt(sum((h[i] - co[i]) ** 2 for i in range(len(axes))))
        worst = max(abs(d3(after, k) - d3(before, k)) for k in (1, 2))
        step("A: 手柄到 co 的三维距离守恒（纯旋转，不是平移）", worst < 1e-5,
             "max偏差=%.10f  (d_before=%.6f)" % (worst, d3(before, 1)))
        s.cancel()

    # =========================================================
    # B. 多点旋转：整体旋转 + 手柄一起转
    # =========================================================
    reset(); sel([1, 14])
    before = {f: full_state(f) for f in (1.0, 14.0)}
    s = me.RotateSession('ROTATE')
    ok = s.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("B: 多点 begin", ok is True, s.message)
    if ok:
        pivot = s.pivot_world
        s.apply_numeric(90.0)
        after = {f: full_state(f) for f in (1.0, 14.0)}
        # co 确实动了（绕中位点转）
        moved = any(abs(after[f][i][0] - before[f][i][0]) > 1e-3
                    for f in before for i in before[f])
        step("B: 多点旋转 → co 绕中位点转动", moved, "ok")
        # 手柄跟随（相对 co 的偏移被旋转，而不是完全不变）
        hl_rot = any(abs(after[f][i][1] - before[f][i][1]) > 1e-4
                     for f in before for i in before[f])
        step("★ B: 手柄也参与旋转（不是只平移 co）", hl_rot, "ok")
        s.cancel()

    # =========================================================
    # C. 手柄显示因子恒为 1.0（修掉"一拖就跳变"）
    # =========================================================
    reset()
    from RealTimeMotionPath import time_domain as td_
    kf_map = td_.collect_frame_keyframes(act, obj, 14.0, None)
    kf_map2 = None
    if isinstance(kf_map, tuple):
        kf_map = kf_map[0]
    fl, fr = dw.compute_handle_display_factors(kf_map)
    step("★ C: 显示因子恒为 1.0（不再依赖会变的量）",
         all(abs(v - 1.0) < 1e-12 for v in fl.values()) and
         all(abs(v - 1.0) < 1e-12 for v in fr.values()),
         "left=%s right=%s" % (fl, fr))

    # 模拟"拖手柄"（改值分量）后，因子仍然不动
    for fc in fcs:
        for kp in fc.keyframe_points:
            if abs(kp.co[0]-14) < 0.5:
                kp.handle_right = (kp.handle_right[0], kp.co[1] + 9.0)
        fc.update()
    kf_map2 = td_.collect_frame_keyframes(act, obj, 14.0, None)
    if isinstance(kf_map2, tuple):
        kf_map2 = kf_map2[0]
    fl2, fr2 = dw.compute_handle_display_factors(kf_map2)
    step("★ C: 拖手柄（值分量大变）后因子仍为 1.0 → 不跳变",
         all(abs(v - 1.0) < 1e-12 for v in fl2.values()) and
         all(abs(v - 1.0) < 1e-12 for v in fr2.values()),
         "left=%s right=%s" % (fl2, fr2))

    # =========================================================
    # D. 缩放：单点 —— 手柄绕 co 缩放
    # =========================================================
    reset(); sel([14])
    before = full_state(14.0)
    s2 = me.ScaleSession('SCALE')
    ok = s2.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("D: 单点也能缩放 begin", ok is True, s2.message)
    if ok:
        s2.apply_numeric(2.0)
        after = full_state(14.0)
        co_same = all(abs(after[i][0] - before[i][0]) < 1e-6 for i in before)
        step("D: 单点缩放 → co 不动", co_same, "ok")
        hl_scaled = any(abs(after[i][1] - before[i][1]) > 1e-4 for i in before)
        step("★ D: 单点缩放 → 手柄长度变了（有反应）", hl_scaled,
             "hl: %s -> %s" % ([round(before[i][1],4) for i in sorted(before)],
                               [round(after[i][1],4) for i in sorted(after)]))
        s2.cancel()

    # =========================================================
    # E. 还原精确
    # =========================================================
    reset(); sel([1, 14])
    before = {f: full_state(f) for f in (1.0, 14.0)}
    s3 = me.RotateSession('ROTATE')
    s3.begin(obj, act, region, rv3d, 600.0, 400.0)
    s3.apply_numeric(37.0)
    s3.cancel()
    after = {f: full_state(f) for f in (1.0, 14.0)}
    worst = max(abs(after[f][i][k] - before[f][i][k])
                for f in before for i in before[f] for k in range(3))
    step("E: 取消后精确还原（含手柄）", worst < 1e-6, "max偏差=%.10f" % worst)

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("NATIVE_SEMANTICS_CHECK_DONE")
os._exit(0)
