# -*- coding: utf-8 -*-
"""GUI 端到端检查（需要界面，不能 --background）

用法
----
    blender --factory-startup --python tests/gui_check.py

覆盖（headless 测不了的部分）
-----------------------------
  1. 插件从仓库加载（不是用户目录旧副本）
  2. 真实 3D 视口投影：关键帧 -> 屏幕坐标
  3. G/R/S 动态接管（属性回调驱动；含原生抑制与还原）
  4. MoveSession 全链路：移动 / 锁轴 / 锁平面 / 精度 / 取消恢复 / 多选同步
  5. **状态栏在真实上下文里能安全渲染**
     （用户实测崩溃点：invoke() 里 begin() 之后立刻调 status_text()）
  6. SPEED 会话（第二条线）回归

结果写 tests/_gui_result.json 并进程内退出（避免 Blender 挂住）。
"""
import bpy, os, sys, json, traceback, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_gui_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    ok = all(s["ok"] for s in steps)
    payload = {
        "total": len(steps),
        "fails": sum(1 for s in steps if not s["ok"]),
        "result": "ALL PASS" if ok else "HAS FAILURES",
        "steps": steps,
        "ok": ok,
    }
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    # ---------------- 场景 ----------------
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
           (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    # ---------------- 加载插件 ----------------
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    import RealTimeMotionPath as RTMP
    loaded = os.path.dirname(os.path.abspath(RTMP.__file__))
    step("addon loaded from REPO (self-check)",
         os.path.normcase(loaded) == os.path.normcase(REPO), loaded)

    td, xf, me = RTMP.time_domain, RTMP.transform_domain, RTMP.modal_edit
    wm = bpy.context.window_manager

    # 匀速基线 + 全 FREE
    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        pts = list(fc.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()

    # ---------------- 真实视口 ----------------
    win = wm.windows[0]
    area = next((a for a in win.screen.areas if a.type == 'VIEW_3D'), None)
    step("VIEW_3D area found", area is not None, area.type if area else None)
    if area is None:
        flush(); os._exit(0)
    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    from bpy_extras import view3d_utils
    proj = {}
    for f in [1, 14, 27, 40]:
        wp = me.keyframe_world_pos(act, obj, f)
        sp = view3d_utils.location_3d_to_region_2d(region, rv3d, wp)
        proj[f] = [round(sp.x, 1), round(sp.y, 1)] if sp else None
    step("project keyframes (REAL region)", all(v is not None for v in proj.values()), proj)

    # ---------------- G/R/S 动态接管 ----------------
    def plugin_count():
        return sum(1 for kc in wm.keyconfigs for km in kc.keymaps
                   for kmi in km.keymap_items if kmi.idname == "rtmp.keyboard_transform")

    def native_active(kmap="Object Mode", key="G"):
        kc = wm.keyconfigs.active
        for km in kc.keymaps:
            if km.name != kmap:
                continue
            for kmi in km.keymap_items:
                if (kmi.type == key and not (kmi.shift or kmi.ctrl or kmi.alt)
                        and str(kmi.idname).startswith("transform.")):
                    return bool(kmi.active)
        return None

    # ⚠️ headless（--background）坑：`keyconfigs.active` 里 "Object Mode" / "Pose"
    #    这两张 keymap **存在但是空的**（实测条目数 = 0）—— 原生 G/R/S 条目
    #    在后台模式下根本没被填充。于是 `find_native_transform_items()` 找到 0 条，
    #    抑制逻辑"跑了但什么都没抑制"，5 项断言全 FAIL（detail 全 None）。
    #    ⇒ 不是产品 bug。**做法：先手工注入合成条目，把环境恢复到"像 GUI 一样"**，
    #      再跑真实接管链路 —— 这样测的仍是产品代码本身（探针已实测：
    #      find_native_transform_items 找到 4 条 → 开编辑模式全抑制 → 关掉全恢复）。
    kc = wm.keyconfigs.active
    _injected = []
    if len(kc.keymaps["Object Mode"].keymap_items) == 0:
        _ID = {"G": "transform.translate", "R": "transform.rotate", "S": "transform.resize"}
        for _kmn, _keys in (("Object Mode", ("G", "R", "S")), ("Pose", ("G",))):
            _km = kc.keymaps[_kmn]
            for _k in _keys:
                _injected.append(_km.keymap_items.new(_ID[_k], _k, 'PRESS'))
        step("headless: 已注入合成原生 G/R/S 条目（keymap 空壳）",
             len(_injected) == 4, len(_injected))

    me.unregister_transform_keys()
    wm.rtmp_edit_mode_active = False
    step("before: native G active", native_active() is True, native_active())

    wm.rtmp_edit_mode_active = True          # 只赋属性 -> 回调接管
    step("edit mode ON -> plugin keys auto-registered (6)", plugin_count() == 6, plugin_count())
    step("edit mode ON -> native G suppressed", native_active() is False, native_active())
    step("edit mode ON -> Pose native G suppressed",
         native_active(kmap="Pose", key="G") is False, native_active(kmap="Pose", key="G"))

    # ---------------- 选中路径点 ----------------
    def select_only(frames):
        want = [float(f) for f in frames]
        for fc in xf._position_curves(act, obj, None):
            for kp in fc.keyframe_points:
                kp.select_control_point = any(abs(kp.co[0] - f) < 0.5 for f in want)
            fc.update()

    def kf_pos(frame):
        out = {}
        for fc in xf._position_curves(act, obj, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 0.5:
                    out[fc.array_index] = (round(kp.co[1], 6), round(kp.handle_right[1], 6))
        return out

    def reset():
        """★ 每个用例前重置：匀速基线 + 全 FREE + 清选中。

        教训：不重置会让上一个用例的改动累积，导致
              "基准被污染" → 断言看似失败、其实是测试自己的问题。
        """
        unsel = []
        for fc in xf._position_curves(act, obj, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
                kp.select_control_point = False
            pts = list(fc.keyframe_points)
            for i in range(len(pts) - 1):
                k0, k1 = pts[i], pts[i + 1]
                t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
                k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
                k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
            fc.update()
        return unsel

    # ---------------- ★ 崩溃点复现：begin 后立刻渲染状态栏 ----------------
    select_only([14])
    s = me.MoveSession('MOVE')
    ok = s.begin(obj, act, region, rv3d, proj[14][0], proj[14][1])
    step("MOVE begin (REAL view)", ok is True, s.message)
    try:
        txt = s.status_text()     # ← 用户实测在这里炸过
        step("MOVE status_text right after begin (crash point)", isinstance(txt, str) and len(txt) > 0, txt[:70])
    except Exception as e:
        step("MOVE status_text right after begin (crash point)", False, "%s: %s" % (type(e).__name__, e))

    # 各分支都渲染一次
    for lbl, kw in [("axis X", {"axis_lock": 'X'}),
                    ("plane YZ", {"plane_lock": ('Y', 'Z')}),
                    ("precision", {"precision": True})]:
        s2 = me.MoveSession('MOVE'); s2.state = me.STATE_RUNNING
        s2.offset = mathutils.Vector((0.1, 0.2, 0.3))
        for k, v in kw.items():
            setattr(s2, k, v)
        try:
            step("status_text branch: " + lbl, len(s2.status_text()) > 0, s2.status_text()[:60])
        except Exception as e:
            step("status_text branch: " + lbl, False, repr(e))

    # ---------------- 移动 / 锁轴 / 精度 / 取消（每例先 reset） ----------------
    reset(); select_only([14]); base = kf_pos(14)
    s = me.MoveSession('MOVE')
    s.begin(obj, act, region, rv3d, proj[14][0], proj[14][1])
    s.update(proj[14][0], proj[14][1] - 60)
    m = kf_pos(14)
    step("mouse move -> translated", abs(m[1][0] - base[1][0]) > 1e-6,
         "dy=%.5f" % (m[1][0] - base[1][0]))
    step("handle follows co (no shear)",
         abs((m[1][1] - base[1][1]) - (m[1][0] - base[1][0])) < 1e-5,
         "handle d=%.5f co d=%.5f" % (m[1][1]-base[1][1], m[1][0]-base[1][0]))
    s.cancel()
    step("cancel restores exactly", kf_pos(14) == base, kf_pos(14)[1][0])

    reset(); select_only([14]); base = kf_pos(14)
    s = me.MoveSession('MOVE'); s.begin(obj, act, region, rv3d, proj[14][0], proj[14][1])
    s.set_axis('X'); s.update(proj[14][0], proj[14][1] - 60)
    m = kf_pos(14)
    step("axis lock X: only X changes",
         abs(m[0][0]-base[0][0]) > 1e-6 and abs(m[1][0]-base[1][0]) < 1e-6
         and abs(m[2][0]-base[2][0]) < 1e-6,
         "d=(%.4f, %.4f, %.4f)" % (m[0][0]-base[0][0], m[1][0]-base[1][0], m[2][0]-base[2][0]))
    s.cancel()

    reset(); select_only([14]); base = kf_pos(14)
    s = me.MoveSession('MOVE'); s.begin(obj, act, region, rv3d, proj[14][0], proj[14][1])
    s.set_plane('X'); s.update(proj[14][0], proj[14][1] - 60)
    step("plane lock Shift+X excludes X", abs(kf_pos(14)[0][0]-base[0][0]) < 1e-6,
         "dx=%.6f plane=%s" % (kf_pos(14)[0][0]-base[0][0], s.plane_lock))
    s.cancel()

    reset(); select_only([14]); base = kf_pos(14)
    s1 = me.MoveSession('MOVE'); s1.begin(obj, act, region, rv3d, proj[14][0], proj[14][1])
    s1.update(proj[14][0], proj[14][1] - 60)
    full = kf_pos(14)[1][0] - base[1][0]
    s1.cancel()
    s2 = me.MoveSession('MOVE'); s2.begin(obj, act, region, rv3d, proj[14][0], proj[14][1])
    s2.set_precision(True); s2.update(proj[14][0], proj[14][1] - 60)
    prec = kf_pos(14)[1][0] - base[1][0]
    step("precision x0.1", abs(prec - full * 0.1) < 1e-5,
         "full=%.5f precise=%.5f ratio=%.3f" % (full, prec, prec / full if full else 0))
    s2.cancel()

    reset(); select_only([14, 27])
    b14, b27 = kf_pos(14), kf_pos(27)
    s = me.MoveSession('MOVE'); s.begin(obj, act, region, rv3d, proj[14][0], proj[14][1])
    s.update(proj[14][0], proj[14][1] - 60)
    d14 = kf_pos(14)[1][0] - b14[1][0]; d27 = kf_pos(27)[1][0] - b27[1][0]
    step("multi-select moves together", abs(d14 - d27) < 1e-5, "d14=%.5f d27=%.5f" % (d14, d27))
    s.cancel()

    reset()      # ★ 清掉选中，才能测"无选中"分支
    step("no selection -> begin fails",
         me.MoveSession('MOVE').begin(obj, act, region, rv3d, 600, 400) is False, "")
    step("ROTATE not implemented -> begin fails",
         me.MoveSession('ROTATE').begin(obj, act, region, rv3d, 600, 400) is False, "")

    # ---------------- 归还原生 ----------------
    wm.rtmp_edit_mode_active = False
    step("edit mode OFF -> plugin keys removed", plugin_count() == 0, plugin_count())
    step("edit mode OFF -> native G restored", native_active() is True, native_active())
    step("edit mode OFF -> Pose native G restored",
         native_active(kmap="Pose", key="G") is True, native_active(kmap="Pose", key="G"))
    wm.rtmp_edit_mode_active = True
    wm.rtmp_edit_mode_active = True
    step("idempotent: repeated ON does not stack", plugin_count() == 6, plugin_count())
    wm.rtmp_edit_mode_active = False

    # ---------------- SPEED 回归（先 reset，确保基准是匀速） ----------------
    reset()
    class Ctx: pass
    c = Ctx(); c.region = region; c.region_data = rv3d
    tgt = me.resolve_speed_target(c, obj, act, proj[14][0], proj[14][1] - 30)
    step("SPEED target @f14 right", bool(tgt) and int(tgt["frame"]) == 14, tgt and tgt["side"])

    def first_dist():
        for fc in xf._position_curves(act, obj, None):
            if fc.array_index == 0:
                X = [fc.evaluate(f) for f in range(1, 41)]
                return abs(X[14] - X[13])
    base_d = first_dist()
    sp = me.ModalSession('SPEED')
    ok = sp.begin(obj, act, proj[14][0], proj[14][1] - 30,
                  lambda x, y: me.resolve_speed_target(c, obj, act, x, y))
    step("SPEED begin", ok is True, sp.message)
    try:
        step("SPEED status_text", "疏密" in sp.status_text(), sp.status_text()[:60])
    except Exception as e:
        step("SPEED status_text", False, repr(e))
    sp.update(proj[14][0], proj[14][1] - 90)
    step("SPEED drag -> sparser", first_dist() > base_d * 1.1,
         "%.6f -> %.6f" % (base_d, first_dist()))
    sp.cancel()
    step("SPEED cancel restores", abs(first_dist() - base_d) < 1e-6, "%.8f" % first_dist())

except Exception:
    step("FATAL", False, traceback.format_exc()[-900:])

flush()
print("GUI_CHECK_DONE")
os._exit(0)
