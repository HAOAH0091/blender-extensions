# -*- coding: utf-8 -*-
"""★★★ 回归：拖三角时鼠标坐标取到 `-1`（哨兵值）不得导致数值打满/卡死。

真机定位过程（2026-09-17，用户真机复现 + 插件内诊断钩子记录的 _drag_trace.jsonl）：
  PRESS 时起点 last_mouse = [600, 800]（3D 视图局部坐标）
  第一次 MOUSEMOVE 的 `event.mouse_region_*` = **[-1, -1]**
    ← 鼠标不在任何 Blender 区域上时，Blender 给的就是 -1
  ⇒ dy_raw = -1 - 800 = **-801** ⇒ eff = -332 ⇒ **s 立刻顶到上限（打满）**
  ⇒ 之后 last_mouse 恒为 (-1,-1) ⇒ dy = 0 ⇒ **继续拖也不动（卡死）**

  （"先动过 GE 手柄更容易出现"：那时 s 已在边界附近，一点假位移就撞满。）

修法：`_speed_drag_mouse_local` 显式**拒收 `-1`**；拿不到有效坐标就跳过本次移动。
"""
import os
import sys
import json
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import (transform_domain as xf, time_domain as td,
                                handles as hd, modal_edit as me, interaction as it)
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_mouse_sentinel_result.json")
steps = []
FR = 14.0


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


class FakeEvent:
    def __init__(self, type_, value='PRESS', mouse_x=0.0, mouse_y=0.0,
                 region_x=None, region_y=None):
        self.type = type_
        self.value = value
        self.mouse_x = mouse_x
        self.mouse_y = mouse_y
        self.mouse_region_x = mouse_x if region_x is None else region_x
        self.mouse_region_y = mouse_y if region_y is None else region_y
        self.shift = self.ctrl = self.alt = False
        self.press = value == 'PRESS'


class FakeOp:
    """operator 外壳（提供 modal 用到的实例属性）。"""

    def __init__(self):
        self._is_active = True
        self._mouse_pos = None
        self._last_draw_time = 0.0
        self._last_frame = None

    def report(self, *a, **k):
        pass


try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = "T"
    for f, loc in ((1, (0, 0, 0)), (14, (3, 2, 0)), (40, (6, 0, 0))):
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    act = o.animation_data.action
    act.name = "SentinelAct"
    sc.frame_set(int(FR))

    wm = bpy.context.window_manager
    win = wm.windows[0]
    wm.rtmp_edit_mode_active = True
    v3d = next((a for a in win.screen.areas if a.type == 'VIEW_3D'), None)
    if v3d is None:
        raise RuntimeError("没有 3D 视图")
    region = next(r for r in v3d.regions if r.type == 'WINDOW')
    rv3d = v3d.spaces.active.region_3d

    def s_of():
        km, sp = td.resolve_target(act, o, FR, 'left')
        if not km or sp is None:
            return None
        v = td.read_s(next(iter(km.values())), sp, 'left')
        return float(v) if v is not None else None

    def reset():
        for fc in xf._position_curves(act, o, None):
            kp = xf.keyframe_at(fc, FR)
            if kp is not None:
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
        for fc in xf._position_curves(act, o, None):
            fc.update()

    reset()
    hs = me.collect_speed_handles(act, o, region, rv3d)
    h = [x for x in hs if x["frame"] == FR and x["tri"] == "up"]
    step("① 有可拖的上三角", len(h) > 0, "三角数=%d" % len(hs))
    if not h:
        raise RuntimeError("没找到上三角")
    lx, ly = h[0]["tri_screen"]
    gx, gy = lx + region.x, ly + region.y

    Modal = it.RTMP_OT_PathPointDrag.modal
    ctx = bpy.context

    # ---------------- 核心：MOUSEMOVE 给 -1 ----------------
    reset()
    s_before = s_of()
    op = FakeOp()
    with bpy.context.temp_override(window=win, area=v3d, region=region,
                                   screen=win.screen):
        Modal(op, ctx, FakeEvent('LEFTMOUSE', 'PRESS', gx, gy, lx, ly))
        step("② PRESS 命中三角、进入拖拽",
             _session.speed_drag_active is True,
             "active=%s origin=%s" % (_session.speed_drag_active,
                                      _session.speed_drag_origin_mouse))
        lm = tuple(_session.speed_drag_last_mouse or (0, 0))
        # ★★ 复现真机日志：mouse_region_* = -1（鼠标不在任何区域上）
        Modal(op, ctx, FakeEvent('MOUSEMOVE', 'NOTHING', -1.0, -1.0, -1.0, -1.0))
        s_after = s_of()
        eff = _session.speed_drag_effective_px

    step("★★★ ③ 坐标 = -1 时：数值**不跳变**（旧 bug 会立刻打满）",
         abs((s_after or 0) - (s_before or 0)) < 1e-9 and abs(eff) < 1e-9,
         "s: %.6f → %.6f | eff=%.3f | last_mouse=%s → %s"
         % (s_before, s_after, eff, lm, tuple(_session.speed_drag_last_mouse or (0, 0))))
    step("★★ ③b 数值没有被推到极限（旧 bug：直接顶到 1.0 或 S_EPS）",
         not (s_after is not None
              and (abs(s_after - td.S_HARD_MAX) < 1e-12
                   or abs(s_after - td.S_EPS) < 1e-15)),
         "s=%.6f" % (s_after if s_after is not None else -1))

    # ---------------- 恢复正常坐标后应能继续拖 ----------------
    with bpy.context.temp_override(window=win, area=v3d, region=region,
                                   screen=win.screen):
        # 用真实位移继续拖（鼠标往上 40px = 变疏）
        Modal(op, ctx, FakeEvent('MOUSEMOVE', 'NOTHING', gx, gy - 40, lx, ly - 40))
        s_resumed = s_of()
        eff2 = _session.speed_drag_effective_px

    step("★★★ ④ -1 之后恢复正常坐标：**能继续拖动**（旧 bug 会一直卡死）",
         abs((s_resumed or 0) - (s_before or 0)) > 1e-9 and abs(eff2) > 1e-6,
         "s: %.6f → %.6f | eff=%.3f" % (s_before, s_resumed, eff2))

    # ---------------- 静态契约：必须显式拒收 -1 ----------------
    _src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    _fn = _src.split("def _speed_drag_mouse_local")[1].split("\ndef ")[0]
    step("★★★ ⑤ 静态契约：_speed_drag_mouse_local 显式拒收 `-1` 哨兵值",
         "> -0.5" in _fn and "mouse_region" in _fn,
         "函数内含 -0.5 防护=%s" % ("> -0.5" in _fn))

    # ---------------- 静态契约：调用处必须判 None ----------------
    step("★★★ ⑥ 静态契约：MOUSEMOVE 分支必须判 `_loc is not None` 才更新",
         "_loc = _speed_drag_mouse_local" in _src
         and "if _loc is not None:" in _src, "")

except Exception:
    step("FATAL", False, traceback.format_exc()[-1800:])

flush()
print("MOUSE_SENTINEL_DONE")
