# -*- coding: utf-8 -*-
"""UI 布局回归 —— 性能设置与手柄拖拽模式的**位置对调**（用户 2026-09-17 要求）。

用户要求
--------
    "运动路径曲线的 UI 在 3D 视图右上角…点开下拉后是性能更新模式的设置，
     我想把这个设置挪到插件偏好设置里去，然后把现在偏好设置里的手柄拖拽模式
     的设置挪到 3D 视图的 UI 里"

⇒ 对调：
    · 性能（更新模式 / 交互帧率 / 轮询频率）→ **偏好设置**
    · 手柄拖拽模式（Handle Drag Mode）→ **3D 视图 HEADER popover**

★ 顺带修掉的一个**真问题**（实测依据）
--------------------------------------
这 3 个性能设置原来是 `WindowManager` 属性 —— 而 **WindowManager 上的属性
不写入文件**。实测（本仓库复现）：
    设 TIMER/33/7 → 保存 → 重开 ⇒ 变回默认 SMART/60/10
    RNA `is_runtime` 也是 True（= skip-save 标志）
给用户的实际后果是「改完重启就丢」，与"偏好设置"的语义不符。
⇒ 迁到 `AddonPreferences`（存 userpref，全局 + 持久），读取统一走
  `state.addon_pref(name, default)`。

本测试钉住
----------
A 组：偏好设置里有 3 个新属性；旧 WindowManager 属性已移除；addon_pref 可读
B 组：UI 归属（哪个面板画什么）—— 防"以后有人挪回去"或"两边都画"
C 组：interaction.py 里不再有 `wm.rtmp_*` 旧引用；4 处 addon_pref 调用
D 组：`addon_pref` 的兜底语义（拿不到时返回 default，不抛）
E 组：Reset 算子会重置这 3 项
"""
import os
import sys
import json
import inspect
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
ADDONS = os.path.dirname(REPO)
sys.path.insert(0, ADDONS)
sys.stdout.reconfigure(encoding="utf-8")

OUT = os.path.join(HERE, "_ui_layout_result.json")
steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


try:
    import bpy
    try:
        bpy.ops.preferences.addon_disable(module="RealTimeMotionPath")
    except Exception:
        pass
    for _k in [k for k in sys.modules if k.startswith("RealTimeMotionPath")]:
        del sys.modules[_k]
    import importlib
    importlib.invalidate_caches()
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")

    import RealTimeMotionPath as rt
    from RealTimeMotionPath import state as st, ui as ui_mod

    prefs = bpy.context.preferences.addons["RealTimeMotionPath"].preferences
    wm = bpy.context.window_manager

    # ============================================================ A 组
    NEW = ("refresh_strategy", "max_interaction_fps", "poll_frequency")
    vals = {}
    for n in NEW:
        vals[n] = getattr(prefs, n, "★缺失")
    step("A1 ★★ 偏好设置上有性能三属性",
         all(v != "★缺失" for v in vals.values()),
         json.dumps(vals, ensure_ascii=False))
    step("A2 默认值与旧 WindowManager 版一致（SMART / 60 / 10）",
         vals["refresh_strategy"] == 'SMART' and vals["max_interaction_fps"] == 60
         and vals["poll_frequency"] == 10,
         str(vals))

    OLD = ("rtmp_refresh_strategy", "rtmp_max_interaction_fps", "rtmp_poll_frequency")
    left = [n for n in OLD if hasattr(wm, n)]
    step("A3 ★★ 旧 WindowManager 属性已全部移除",
         not left, "残留=%s" % (left or "无"))

    read = {n: st.addon_pref(n, None) for n in NEW}
    step("A4 state.addon_pref 能读到三属性",
         all(read[n] == vals[n] for n in NEW),
         json.dumps(read, ensure_ascii=False))
    step("A5 handle_scale_mode 仍在偏好设置（未删，只是换了展示位置）",
         getattr(prefs, "handle_scale_mode", None) in ('CLASSIC', 'UNIFORM'),
         "handle_scale_mode=%r" % getattr(prefs, "handle_scale_mode", None))

    # ============================================================ B 组
    src_ui = open(os.path.join(REPO, "ui.py"), encoding="utf-8").read()
    i_pref = src_ui.find("class RTMP_AddonPreferences")
    i_hdr = src_ui.find("class RTMP_PT_header_settings")
    i_menu = src_ui.find("class RTMP_MT_context_menu", i_hdr)
    pref_draw = src_ui[i_pref:i_hdr].split("def draw", 1)[1]
    hdr_draw = src_ui[i_hdr:i_menu].split("def draw", 1)[1]

    step("B1 ★★ 偏好设置 draw 画「更新模式」", "refresh_strategy" in pref_draw)
    step("B2 ★★ 偏好设置 draw 画「交互帧率上限」", "max_interaction_fps" in pref_draw)
    step("B3 偏好设置 draw 画「轮询频率」（TIMER 模式下的）",
         "poll_frequency" in pref_draw)
    step("B4 ★★ 偏好设置 draw **不再**画手柄拖拽模式",
         "handle_scale_mode" not in pref_draw)
    step("B5 ★★ 3D popover draw 画手柄拖拽模式",
         "handle_scale_mode" in hdr_draw)
    step("B6 ★★ 3D popover draw **不再**画性能设置",
         "refresh_strategy" not in hdr_draw
         and "max_interaction_fps" not in hdr_draw)
    step("B7 popover 拿不到偏好时有兜底（不崩 draw）",
         "try:" in hdr_draw and "except" in hdr_draw,
         "draw 内含 try/except")

    # ============================================================ C 组
    import re
    src_it = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    bad = re.findall(
        r"wm\.(rtmp_refresh_strategy|rtmp_max_interaction_fps|rtmp_poll_frequency)",
        src_it)
    step("C1 ★★ interaction.py 无旧 WM 引用残留", not bad, "残留=%s" % (bad or "无"))
    n_pref_call = src_it.count("addon_pref(")
    step("C2 interaction.py 用 addon_pref 读取（4 处）",
         n_pref_call >= 4, "出现 %d 次" % n_pref_call)
    step("C3 addon_pref 已从 state 导入",
         "addon_pref" in src_it.split("\n\n")[0],
         src_it.split("\n")[8].strip()[:110])

    # ============================================================ D 组
    step("D1 ★ addon_pref 取不到时返回 default（不抛）",
         st.addon_pref("__no_such_prop__", "FALLBACK") == "FALLBACK",
         "返回 %r" % st.addon_pref("__no_such_prop__", "FALLBACK"))
    sig = inspect.signature(st.addon_pref).parameters
    step("D2 addon_pref 签名 = (name, default=None)",
         list(sig.keys()) == ["name", "default"], str(list(sig.keys())))

    # ============================================================ E 组
    src_reset = src_ui.split("class RTMP_OT_ResetPreferences", 1)[1]
    src_reset = src_reset.split("class ", 1)[0]
    miss = [n for n in NEW if ('property_unset("%s")' % n) not in src_reset]
    step("E1 ★ Reset 算子会重置性能三属性", not miss, "缺=%s" % (miss or "无"))
    step("E2 属性定义处有「存 userpref ⇒ 持久」的说明注释",
         "AddonPreferences" in src_ui and "is_runtime" in src_ui,
         "注释里记录了实测依据")

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-800:])

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
