# -*- coding: utf-8 -*-
"""Backspace 恢复速度三角默认值 —— GUI / 逻辑检查（用户 2026-09-16 需求）

需求原文：
    "当用户光标停留在三角速度手柄时按 backspace 键盘键时，可以恢复对应三角速度值的默认值"

覆盖：
  A. 默认值 = 匀速 S_LIN（实测依据：Blender 默认手柄 s = dt/span 恒为 1/3）
  B. hover 精确命中三角（hover_speed_tri）
  C. 恢复：改过的三角 -> 回到 S_LIN
  D. 边界：光标不在三角上 -> 不消费按键（返回 False，不影响原生 Backspace）
  E. 边界：拖拽中 -> 不消费
  F. 安全：恢复【只改时间分量】，关键帧帧号/值不变（路径几何与 pose 不受影响）
  G. 幂等：本来就是默认值 -> 再按一次仍是默认值，且不报错
  H. 不影响其他三角

用法：blender --background --factory-startup --python tests/gui_backspace_reset_check.py
"""
import bpy, os, sys, json, traceback, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_bs_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())


class Ev:
    """最小 event 替身（find_region_under_mouse 只读 mouse_x/mouse_y）。"""
    def __init__(self, mx, my):
        self.mouse_x = mx
        self.mouse_y = my
        self.mouse_region_x = mx
        self.mouse_region_y = my
        self.type = 'BACK_SPACE'
        self.value = 'PRESS'
        self.shift = False


try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 1.0, 0.0)),
           (27, (8.0, -1.0, 0.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import overlay as ovmod
    from RealTimeMotionPath.state import _session

    # 把默认手柄显式摆到 1/3 位置（= 插件"未编辑过"的状态，s = S_LIN）
    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        pts = list(fc.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()

    wm = bpy.context.window_manager
    wm.rtmp_path_display_enabled = True
    win = wm.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    d = mathutils.Vector((0.55, -1.0, 0.35)).normalized()
    rv3d.view_rotation = (-d).to_track_quat('-Z', 'Y')
    sc.frame_set(1)
    bpy.context.view_layer.update()
    ovmod.get_overlay().start(session=None)
    ctx = bpy.context

    FRAME = 14          # 中间关键帧（两侧都有相邻关键帧，两个三角都可编辑）
    DEF = td.S_LIN

    def fresh():
        return me.collect_speed_handles(act, obj, region, rv3d)

    def pick(recs, frame, tri):
        for r in recs:
            if r['frame'] == frame and r['tri'] == tri:
                return r
        return None

    def s_of(frame, tri):
        r = pick(fresh(), frame, tri)
        return None if r is None else r['s']

    def co_snapshot():
        out = {}
        for fc in xf._position_curves(act, obj, None):
            for kp in fc.keyframe_points:
                out.setdefault(round(float(kp.co[0]), 4), {})[fc.array_index] = round(float(kp.co[1]), 6)
        return out

    def hover(recs, frame, tri):
        """把鼠标放到某个三角上（走真实 _update_speed_hover 通路）。"""
        r = pick(recs, frame, tri)
        if r is None:
            return None
        tp = r['tri_screen']
        ev = Ev(region.x + tp[0], region.y + tp[1])
        inter._update_speed_hover(ctx, obj, region, rv3d, tp)
        return ev

    def hover_away():
        """把鼠标放到远离所有三角的地方。"""
        ev = Ev(region.x + 2, region.y + 2)
        inter._update_speed_hover(ctx, obj, region, rv3d, (2.0, 2.0))
        return ev

    # ---------- A. 默认值口径 ----------
    s0 = s_of(FRAME, hd.TRI_DOWN)
    step("A1 初始 s == S_LIN（未编辑过 = 默认值口径无歧义）",
         s0 is not None and abs(s0 - DEF) < 1e-4,
         "s=%.6f  S_LIN=%.6f" % (s0 if s0 is not None else -1, DEF))
    step("A2 S_LIN == 1/3", abs(DEF - 1.0 / 3.0) < 1e-9, "S_LIN=%.9f" % DEF)
    step("A3 恢复用的 d == CV_MID（三角显示 1.00x 的位置）",
         abs(td.s_to_d(td.S_LIN) - td.CV_MID) < 1e-6,
         "s_to_d(S_LIN)=%.4f  CV_MID=%.4f" % (td.s_to_d(td.S_LIN), td.CV_MID))

    # ---------- B. hover 精确命中 ----------
    recs = fresh()
    h_down = pick(recs, FRAME, hd.TRI_DOWN)
    ev_hit = hover(recs, FRAME, hd.TRI_DOWN)
    step("B1 光标在三角上 -> hover_speed_tri 命中",
         _session.hover_speed_tri == (FRAME, hd.TRI_DOWN),
         "hover_speed_tri=%r" % (_session.hover_speed_tri,))

    ev_away = hover_away()
    step("B2 光标不在三角上 -> hover_speed_tri 为 None",
         _session.hover_speed_tri is None,
         "hover_speed_tri=%r" % (_session.hover_speed_tri,))

    # ---------- C. 恢复 ----------
    # 先把下三角改成"变疏"（s 明显偏离默认）
    _session.speed_drag_active = False
    inter._apply_speed_d(ctx, obj, FRAME, hd.SIDE_BY_TRI[hd.TRI_DOWN], td.s_to_d(0.08))
    s_sparse = s_of(FRAME, hd.TRI_DOWN)
    step("C1 前置：把下三角改成变疏（s=0.08）",
         s_sparse is not None and abs(s_sparse - 0.08) < 1e-3,
         "s=%.6f" % (s_sparse if s_sparse is not None else -1))

    hover(fresh(), FRAME, hd.TRI_DOWN)
    ok_ret = inter.try_reset_hovered_speed(ctx, ev_hit)
    s_back = s_of(FRAME, hd.TRI_DOWN)
    step("C2 按 Backspace -> try_reset 返回 True（消费按键）", ok_ret is True, "ret=%r" % ok_ret)
    step("C3 恢复后 s == S_LIN（回到匀速 1.00x）",
         s_back is not None and abs(s_back - DEF) < 1e-4,
         "s=%.6f  期望 %.6f" % (s_back if s_back is not None else -1, DEF))

    # 变密方向同样能恢复
    inter._apply_speed_d(ctx, obj, FRAME, hd.SIDE_BY_TRI[hd.TRI_DOWN], td.s_to_d(0.9))
    s_dense = s_of(FRAME, hd.TRI_DOWN)
    hover(fresh(), FRAME, hd.TRI_DOWN)
    inter.try_reset_hovered_speed(ctx, ev_hit)
    s_back2 = s_of(FRAME, hd.TRI_DOWN)
    step("C4 变密方向（s=0.9）也能恢复",
         s_dense is not None and abs(s_dense - 0.9) < 1e-3
         and s_back2 is not None and abs(s_back2 - DEF) < 1e-4,
         "改后 s=%.4f -> 恢复 s=%.6f" % (s_dense if s_dense is not None else -1,
                                        s_back2 if s_back2 is not None else -1))

    # ---------- D. 边界：光标不在三角上 ----------
    hover_away()
    ret_none = inter.try_reset_hovered_speed(ctx, ev_away)
    step("D1 光标不在三角上 -> 不消费按键（返回 False）",
         ret_none is False, "ret=%r" % ret_none)

    # ---------- E. 边界：拖拽中 ----------
    hover(fresh(), FRAME, hd.TRI_DOWN)
    _session.speed_drag_active = True
    ret_drag = inter.try_reset_hovered_speed(ctx, ev_hit)
    _session.speed_drag_active = False
    step("E1 拖拽中 -> 不消费（避免与连续写值冲突）",
         ret_drag is False, "ret=%r" % ret_drag)

    # ---------- F. 安全：只改时间分量 ----------
    inter._apply_speed_d(ctx, obj, FRAME, hd.SIDE_BY_TRI[hd.TRI_DOWN], td.s_to_d(0.06))
    co_before = co_snapshot()
    hover(fresh(), FRAME, hd.TRI_DOWN)
    inter.try_reset_hovered_speed(ctx, ev_hit)
    co_after = co_snapshot()
    step("F1 恢复【不改变】任何关键帧的帧号与值（pose / 路径几何不受影响）",
         co_before == co_after,
         "关键帧快照一致" if co_before == co_after else "差异: %s" % (
             {k: (co_before.get(k), co_after.get(k)) for k in set(co_before) | set(co_after)
              if co_before.get(k) != co_after.get(k)},))

    # 时间分量确实变了（不是"什么都没做"）
    step("F2 时间分量确实被写回（不是空操作）",
         s_of(FRAME, hd.TRI_DOWN) is not None
         and abs(s_of(FRAME, hd.TRI_DOWN) - DEF) < 1e-4,
         "s=%.6f" % s_of(FRAME, hd.TRI_DOWN))

    # ---------- G. 幂等 ----------
    hover(fresh(), FRAME, hd.TRI_DOWN)
    r1 = inter.try_reset_hovered_speed(ctx, ev_hit)
    s_g1 = s_of(FRAME, hd.TRI_DOWN)
    hover(fresh(), FRAME, hd.TRI_DOWN)
    r2 = inter.try_reset_hovered_speed(ctx, ev_hit)
    s_g2 = s_of(FRAME, hd.TRI_DOWN)
    step("G1 已是默认值时再按 -> 仍为默认值，且不报错",
         bool(r1) and bool(r2) and abs(s_g1 - DEF) < 1e-4 and abs(s_g2 - DEF) < 1e-4,
         "s1=%.6f s2=%.6f" % (s_g1, s_g2))

    # ---------- H. 不影响其他三角 ----------
    inter._apply_speed_d(ctx, obj, FRAME, hd.SIDE_BY_TRI[hd.TRI_UP], td.s_to_d(0.10))
    s_up_before = s_of(FRAME, hd.TRI_UP)
    s_prev_before = s_of(1, hd.TRI_DOWN)
    hover(fresh(), FRAME, hd.TRI_DOWN)                 # 只 hover 下三角
    inter.try_reset_hovered_speed(ctx, ev_hit)
    step("H1 恢复下三角【不影响】同帧上三角",
         abs(s_of(FRAME, hd.TRI_UP) - s_up_before) < 1e-6,
         "上三角 s: %.6f -> %.6f" % (s_up_before, s_of(FRAME, hd.TRI_UP)))

    # ---------- I. 端点三角不存在（应与现状一致：端点段不生成手柄） ----------
    step("I1 首帧左段 / 末帧右段仍不生成三角（端点段，与现状一致）",
         pick(fresh(), 1, hd.TRI_UP) is None and pick(fresh(), 40, hd.TRI_DOWN) is None,
         "f1↑=%r  f40↓=%r" % (pick(fresh(), 1, hd.TRI_UP) is not None,
                              pick(fresh(), 40, hd.TRI_DOWN) is not None))

    # ---------- M. ★ 真入口：走 modal 的事件分发（不是只调函数） ----------
    # 前面 A~I 直接调 `try_reset_hovered_speed`，绕过了 operator 的事件通路。
    # 这里补上真入口，确认「BACK_SPACE 确实会被常驻 modal 的分支接住」。
    wm.rtmp_edit_mode_active = True
    # Blender 的 bpy_struct operator 不能直接 `Cls()` 实例化；
    # 把类方法绑到普通对象上，让 `self` 指向它（modal 的 BACK_SPACE 分支只用
    # `self._is_active` / `_mouse_pos` / `_last_draw_time`，都给上即可）。
    import types as _types
    op = _types.SimpleNamespace()
    for _nm in ("modal", "cancel", "invoke"):
        _fn = getattr(inter.RTMP_OT_PathPointDrag, _nm, None)
        if callable(_fn):
            setattr(op, _nm, _types.MethodType(_fn, op))
    op._is_active = True
    op._mouse_pos = (0, 0)
    op._last_draw_time = 0.0
    op._timer = None

    inter._apply_speed_d(ctx, obj, FRAME, hd.SIDE_BY_TRI[hd.TRI_DOWN], td.s_to_d(0.07))
    rec_m = pick(fresh(), FRAME, hd.TRI_DOWN)
    inter._update_speed_hover(ctx, obj, region, rv3d, rec_m['tri_screen'])
    ev_real = Ev(region.x + rec_m['tri_screen'][0], region.y + rec_m['tri_screen'][1])
    res_m = op.modal(ctx, ev_real)
    s_m = s_of(FRAME, hd.TRI_DOWN)
    step("M1 真入口：PathPointDrag.modal 收到 BACK_SPACE -> RUNNING_MODAL",
         isinstance(res_m, set) and 'RUNNING_MODAL' in res_m, "res=%r" % (res_m,))
    step("M2 真入口：三角确实被恢复成默认值",
         s_m is not None and abs(s_m - DEF) < 1e-4, "s=%.6f" % (s_m if s_m is not None else -1))

    # 未命中时：真入口必须放行
    inter._update_speed_hover(ctx, obj, region, rv3d, (2.0, 2.0))
    res_away = op.modal(ctx, Ev(region.x + 2, region.y + 2))
    step("M3 真入口：光标不在三角上 -> PASS_THROUGH（放行给原生）",
         isinstance(res_away, set) and 'PASS_THROUGH' in res_away, "res=%r" % (res_away,))

    # ---------- N. 静态契约：分支必须落在正确的 operator 里 ----------
    # 防「改错分支」：断言 BACK_SPACE 分支确实在 RTMP_OT_PathPointDrag.modal 内。
    import re as _re
    _src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    _i_cls = _src.index("class RTMP_OT_PathPointDrag")
    _nxt = _src.find("\nclass ", _i_cls + 10)
    _body = _src[_i_cls:_nxt if _nxt > 0 else len(_src)]     # 该类的方法体
    step("N1 静态契约：BACK_SPACE 分支位于 RTMP_OT_PathPointDrag 类内",
         "BACK_SPACE" in _body, "类体长度 %d" % len(_body))
    step("N2 静态契约：该分支调用 try_reset_hovered_speed（不是平行复刻）",
         "try_reset_hovered_speed(context, event)" in _body,
         "找到调用" if "try_reset_hovered_speed(context, event)" in _body else "未找到")
    # 栈顶的刷新 daemon 必须放行 BACK_SPACE，否则事件到不了上面的分支
    _i_rf = _src.index("class RTMP_OT_PathRefreshDaemon")
    _nxt2 = _src.find("\nclass ", _i_rf + 10)
    _body_rf = _src[_i_rf:_nxt2 if _nxt2 > 0 else len(_src)]
    step("N3 静态契约：栈顶 PathRefreshDaemon 的 modal 默认放行事件（PASS_THROUGH）",
         "return {'PASS_THROUGH'}" in _body_rf,
         "（栈顺序：后注册的先收到 -> daemon 在栈顶，必须放行）")

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-2500:])

flush()
print("BS_RESULT " + ("ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES"))
for s in steps:
    print(("[OK] " if s["ok"] else "[FAIL] ") + s["name"] + ("  :: " + s["detail"] if s["detail"] else ""))
try:
    bpy.ops.wm.quit_blender()
except Exception:
    pass
os._exit(0)
