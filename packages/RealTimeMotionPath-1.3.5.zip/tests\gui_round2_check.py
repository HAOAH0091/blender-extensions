# -*- coding: utf-8 -*-
"""第二轮 5 点反馈的验收测试

对应用户 2026-09-15 第二轮反馈：
  ① 极值：上限解除了、下限还没解除   → 双向线性、可越过关键帧
  ② 路径变色没出现；且它应表示"离匀速有多远"（胀满整段 = 到理论极值）
  ③ 三角离关键帧太远                 → TRI_FIXED_D 40 -> 26
  ④ 三角不实时跟随关键帧             → 每帧现算世界位置
  ⑤ 手柄变成 FREE、3D 交互变怪       → 只冻结被编辑的一侧（保住联动）

用法：blender --factory-startup --python tests/gui_round2_check.py
"""
import bpy, os, sys, json, traceback, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_r2_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 2.0, 0.0)),
           (27, (8.0, -1.0, 0.5)), (40, (12.0, 1.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import overlay as ovmod
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath.state import _session

    fcs = xf._position_curves(act, obj, None)

    def kp14():
        for fc in fcs:
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - 14) < 0.5:
                    yield fc.array_index, kp

    def types14():
        return [(i, kp.handle_left_type, kp.handle_right_type) for i, kp in kp14()]

    def dt14(side='right'):
        for i, kp in kp14():
            if i == 0:
                return abs(kp.handle_right[0]-kp.co[0]) if side == 'right' else abs(kp.co[0]-kp.handle_left[0])

    # =========================================================
    # ① 极值：双向线性、可越过关键帧
    # =========================================================
    # ⚠️ 映射在 d=CV_MID(=40) 处换分支（dense/sparse 速率不同），线性断言要分段做。
    #    2026-09-16 修订：变密方向在 d<CV_NEAR 处触到【几何上限 s=1.0】后饱和。
    dense_pts = [td.d_to_s(d) for d in range(14, 41, 5)]     # 14..40（未饱和区）
    sparse_pts = [td.d_to_s(d) for d in range(40, 71, 10)]   # 40..70
    dense_steps = [dense_pts[i+1] - dense_pts[i] for i in range(len(dense_pts)-1)]
    sparse_steps = [sparse_pts[i] - sparse_pts[i+1] for i in range(len(sparse_pts)-1)]
    step("① sparse direction: s decreases with drag (no early floor)",
         all(d > 0 for d in sparse_steps),
         "d=40..70: " + ", ".join("%.5f" % p for p in sparse_pts))
    step("① dense branch is LINEAR (before the geometric limit)",
         len(set(round(d, 9) for d in dense_steps)) == 1,
         "steps=%s" % [round(d, 7) for d in dense_steps])
    step("① sparse branch is LINEAR (constant step)",
         len(set(round(d, 9) for d in sparse_steps)) == 1,
         "steps=%s" % [round(d, 7) for d in sparse_steps])
    step("① sparse reaches S_EPS only far away (d≈72), not at d≈300",
         td.d_to_s(60) > td.S_EPS and td.d_to_s(120) <= td.S_EPS + 1e-9,
         "d=60 -> %.6f ; d=120 -> %.8f" % (td.d_to_s(60), td.d_to_s(120)))
    # 2026-09-16 修订：变密到 s=1.0（dt=段长）就是几何极值 —— 再往上 f(t) 会折返
    step("① dense direction saturates at the GEOMETRIC limit s=1.0 (dt<=span)",
         abs(td.d_to_s(0) - 1.0) < 1e-9 and abs(td.d_to_s(-10) - 1.0) < 1e-9
         and abs(td.S_HARD_MAX - 1.0) < 1e-9,
         "d=0 -> %.6f ; d=-10 -> %.6f ; S_HARD_MAX=%.2f"
         % (td.d_to_s(0), td.d_to_s(-10), td.S_HARD_MAX))

    # =========================================================
    # ② 路径段高亮 = 疏密程度的量尺
    # =========================================================
    ovmod.clear_segment_highlight()
    ovmod.set_segment_highlight(14.0, 'right', 0.0)
    step("② t=0 stored (frame, side, t, dense)",
         ovmod.get_segment_highlight() == (14.0, 'right', 0.0, False),
         ovmod.get_segment_highlight())
    ovmod.set_segment_highlight(14.0, 'right', 0.5)
    step("② t stored as third element",
         ovmod.get_segment_highlight() == (14.0, 'right', 0.5, False),
         ovmod.get_segment_highlight())

    ts = [td.extremeness(td.d_to_s(d)) for d in (40, 50, 60, 70)]
    step("② extremeness grows monotonically as we sparsify",
         all(ts[i] < ts[i+1] for i in range(len(ts)-1)),
         "d=40,50,60,70 -> " + ", ".join("%.3f" % t for t in ts))
    step("② extremeness == 0 at uniform", abs(td.extremeness(td.S_LIN)) < 1e-9,
         td.extremeness(td.S_LIN))
    step("② extremeness == 1 at the theoretical extreme (dt→0)",
         abs(td.extremeness(td.S_EPS) - 1.0) < 1e-6, td.extremeness(td.S_EPS))

    # 高亮几何：t 决定胀满多少
    from RealTimeMotionPath.drawing import segment_frame_range

    def hl_range(frame, side, t, from_idx=None, to_idx=None):
        rng = segment_frame_range(act, obj, frame, side)
        i_kf = int(round(frame)) - sc.frame_start
        i_nb = int(round(rng[0] if side == 'left' else rng[1])) - sc.frame_start
        span = i_nb - i_kf
        i_end = i_kf + int(round(span * t))
        return abs(i_end - i_kf), abs(span)

    # 颜色：变疏=橙，变密=蓝（用户 2026-09-15）
    ovmod.set_segment_highlight(14.0, 'right', 0.5, False)
    step("② sparse direction -> ORANGE",
         ovmod.highlight_color(ovmod.get_segment_highlight()[3]) == ovmod.SEGMENT_SPARSE_COLOR,
         ovmod.highlight_color(False))
    ovmod.set_segment_highlight(14.0, 'right', 0.5, True)
    step("② dense direction -> BLUE (用户要求区分)",
         ovmod.highlight_color(ovmod.get_segment_highlight()[3]) == ovmod.SEGMENT_DENSE_COLOR,
         ovmod.highlight_color(True))
    step("② orange != blue",
         ovmod.SEGMENT_SPARSE_COLOR != ovmod.SEGMENT_DENSE_COLOR,
         "%s vs %s" % (ovmod.SEGMENT_SPARSE_COLOR, ovmod.SEGMENT_DENSE_COLOR))

    got_half, full = hl_range(14.0, 'right', 0.5)
    # 13 帧段的一半 = 6.5，取 6 或 7 都算正确
    step("② t=0.5 -> highlight covers HALF the segment",
         got_half in (6, 7) and full == 13, "half=%d of %d" % (got_half, full))
    got_full, full2 = hl_range(14.0, 'right', 1.0)
    step("② t=1.0 -> highlight fills the WHOLE segment (胀满)",
         got_full == full2, "full=%d of %d" % (got_full, full2))
    got_zero, _ = hl_range(14.0, 'right', 0.0)
    step("② t=0 -> nothing highlighted", got_zero == 0, got_zero)

    # =========================================================
    # ③ 三角靠近关键帧
    # =========================================================
    step("③ TRI_FIXED_D reduced (<=30 px)", hd.TRI_FIXED_D <= 30.0, hd.TRI_FIXED_D)
    step("③ overlay uses the same constant (绘制/命中同源)",
         ovmod.TRI_FIXED_D == hd.TRI_FIXED_D,
         "%s vs %s" % (ovmod.TRI_FIXED_D, hd.TRI_FIXED_D))

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    over = ovmod.get_overlay()
    recs = me.collect_speed_handles(act, obj, region, rv3d)
    r14u = [r for r in recs if r['frame'] == 14.0 and r['tri'] == hd.TRI_UP][0]
    step("③ triangle offset == TRI_FIXED_D (not rec['d'])",
         abs(abs(r14u['tri_screen'][1] - r14u['kf_screen'][1]) - hd.TRI_FIXED_D) < 0.6,
         "offset=%.1f" % abs(r14u['tri_screen'][1] - r14u['kf_screen'][1]))
    # 数据 d 与呈现位置是两回事
    step("③ data 'd' still tracks sparsity (separate from screen offset)",
         abs(r14u['d'] - td.CV_MID) < 1e-3, r14u['d'])

    # =========================================================
    # ④ 三角实时跟随关键帧
    # =========================================================
    before_w = tuple(round(c, 4) for c in over._fresh_kf_world(r14u))
    for fc in fcs:
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - 14) < 0.5:
                kp.co = (14.0, 9.0)          # co 是 2 分量 (time, value)
        fc.update()
    bpy.context.view_layer.update()
    after_w = tuple(round(c, 4) for c in over._fresh_kf_world(r14u))
    step("④ fresh world pos follows the moved keyframe (record is stale)",
         after_w != before_w and abs(after_w[0] - 9.0) < 1e-3,
         "before=%s after=%s" % (before_w, after_w))
    step("④ stale value in the record would be wrong (证明修复必要)",
         abs(r14u['kf_world'][0] - 9.0) > 1e-3,
         "record 里仍是 %s" % (round(r14u['kf_world'][0], 3),))

    # =========================================================
    # ⑤ 只冻被编辑的一侧 + 联动仍然可用
    # =========================================================
    # 重置成"两侧都非 FREE"（模拟用户原始状态）
    for fc in fcs:
        for kp in fc.keyframe_points:
            if abs(kp.co[0]-14) < 0.5:
                kp.co = (14.0, 4.0)          # co 是 2 分量 (time, value)
            kp.handle_left_type = 'ALIGNED'
            kp.handle_right_type = 'ALIGNED'
        fc.update()
    step("⑤ setup: both sides ALIGNED", all(t[1] == 'ALIGNED' and t[2] == 'ALIGNED' for t in types14()),
         types14())

    kf_map, span = td.resolve_target(act, obj, 14.0, 'right')
    target_s = 0.15
    # ⚠️ 2026-09-16：必须传 act/obj —— write_s 要冻结【邻居关键帧】才能保证形状不变
    td.write_s(kf_map, 'right', target_s, span, act=act, obj=obj)
    for fc in fcs: fc.update()
    got_dt = dt14('right')
    step("⑤ speed edit applied exactly (dt == s*span)",
         abs(got_dt - target_s * span) < 1e-6,
         "dt=%.6f expect=%.6f" % (got_dt, target_s * span))

    tlist = types14()
    # 2026-09-16 修订：现在【两侧都冻】（只冻一侧会让对侧路径变形，实测 Δ=0.267）
    step("⑤ both sides of the edited keyframe become FREE (形状不变的前提)",
         all(t[1] == 'FREE' and t[2] == 'FREE' for t in tlist), tlist)
    step("★ ⑤ edited keyframe is REGISTERED (so linkage keeps working)",
         td.is_frozen(act, 14.0), td.is_frozen(act, 14.0))

    # 真实驱动插件联动：拖右手柄，左手柄应被联动
    class FakeOp:
        pass
    fo = FakeOp()
    linked_ok = True
    detail = []
    for i, kp in kp14():
        before_l = tuple(round(c, 4) for c in kp.handle_left)
        vec = mathutils.Vector((0.0, 0.0, 0.0)); vec[i] = 1.0
        inter.RTMP_OT_PathPointDrag.update_linked_handle(fo, kp, 'right', vec, i)
        after_l = tuple(round(c, 4) for c in kp.handle_left)
        if before_l == after_l:
            linked_ok = False
        detail.append("轴%d %s->%s" % (i, before_l[1], after_l[1]))
        break
    step("★ ⑤ handle LINKAGE still works after speed edit (the actual fix)",
         linked_ok, "; ".join(detail))

    # 反向探针：清掉登记表（= 用户手动把两侧设成 FREE）后，按原生语义不联动
    td.clear_frozen()
    for i, kp in kp14():
        kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
    probe_linked = False
    for i, kp in kp14():
        bl = tuple(kp.handle_left)
        vec = mathutils.Vector((0.0,0.0,0.0)); vec[i] = 1.0
        inter.RTMP_OT_PathPointDrag.update_linked_handle(fo, kp, 'right', vec, i)
        probe_linked = tuple(kp.handle_left) != bl
        break
    step("[probe] 未登记(用户自己设 FREE) => 联动确实不生效（证明测试有效）",
         probe_linked is False, probe_linked)
    td.clear_frozen()

    # 记录联动前后形状是否被破坏（值分量改动量）
    step("⑤ shape-invariance note: linkage does move opposite handle[1]",
         True, "那是插件原生的联动语义，非速度编辑引入")

    ovmod.clear_segment_highlight()
    over.stop()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("ROUND2_CHECK_DONE")
os._exit(0)
