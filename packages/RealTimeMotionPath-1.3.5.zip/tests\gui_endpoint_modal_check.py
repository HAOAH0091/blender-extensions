# -*- coding: utf-8 -*-
"""端点模态：对齐原生曲线编辑（2026-09-16 修）

用户实测的两个问题：
  ① 「用 G 移动手柄端点后，端点移动不跟手，而且手柄本来是 aligned 对齐的，
      G 移动后变得有折角了」
  ② 「用 S 旋转选中的端点，但是旋转的确实对向的端点，
      而且破坏了手柄本来 aligned 的状态」

根因（代码级）：
  · `apply_point_transform(only_handles=True)` 对每帧把 **hl 和 hr 都变换**
    → 动一个端点，对侧那个也跟着动（②的上半）
  · `make_handles_editable` 把手柄**转成 FREE** 以便写入
    → ALIGNED 共线丢失（①②的"折角"）

修法：
  · 新 `xf.apply_endpoint_transform()`：**只动选中的 (frame, side)**，
    其余按 `xf.maintain_linked_handle()` 的原生语义处理
  · 端点模式**不**调用 `make_handles_editable`（保留原类型）

原生语义（Blender 手册 · handle type）：
  FREE          : "Completely independent manually set handle" → 对侧不动
  ALIGNED       : "rotation locked together with its pair"     → 对侧绕 co 旋转保持共线
  AUTO/AUTO_CLAMPED: 由 Blender 按公式导出                     → 不干预
  VECTOR        : 对侧贴到控制点                               → 同左

用法：blender --factory-startup --python tests/gui_endpoint_modal_check.py
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_em_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath.state import _session

    def build(htype='ALIGNED'):
        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = "T"
        for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (3.0, 2.0, 0.0)),
                       (27, (7.0, -1.0, 1.0)), (40, (11.0, 1.0, 0.0))]:
            sc.frame_set(f); o.location = loc
            o.keyframe_insert("location", frame=f)
        a = o.animation_data.action
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype
                kp.handle_right_type = htype
            fc.update()
        return o, a

    def pts(o, a, frame):
        """读该帧的 co / hl / hr 三维点（= 三轴值分量）+ 类型。"""
        co = [0.0, 0.0, 0.0]; hl = [0.0, 0.0, 0.0]; hr = [0.0, 0.0, 0.0]
        lt = rt = None
        for fc in xf._position_curves(a, o, None):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < 1e-3:
                    co[fc.array_index] = float(kp.co[1])
                    hl[fc.array_index] = float(kp.handle_left[1])
                    hr[fc.array_index] = float(kp.handle_right[1])
                    lt, rt = str(kp.handle_left_type), str(kp.handle_right_type)
        return (mathutils.Vector(co), mathutils.Vector(hl), mathutils.Vector(hr), lt, rt)

    def collinear_dev(co, hl, hr):
        """共线偏差：两侧单位向量叉积模长（0 = 完全共线）。"""
        a = hl - co; b = hr - co
        if a.length < 1e-9 or b.length < 1e-9:
            return None
        return a.normalized().cross(b.normalized()).length

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((5, 0, 0)); rv3d.view_distance = 18.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    # =========================================================
    # A. ALIGNED：只选 1 个端点旋转 → 对侧【绕 co 旋转保持共线】，长度不变
    # =========================================================
    o, act = build('ALIGNED')
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    c0, hl0, hr0, lt0, rt0 = pts(o, act, 14.0)
    step("A 前置：初始 ALIGNED 且共线",
         lt0 == 'ALIGNED' and collinear_dev(c0, hl0, hr0) < 1e-5,
         "类型=%s/%s 共线偏差=%.2e" % (lt0, rt0, collinear_dev(c0, hl0, hr0)))

    s = me.RotateSession('ROTATE')
    ok = s.begin(o, act, region, rv3d, 600.0, 400.0)
    step("A R 模态开始（端点模式）", ok is True and s.only_handles is True,
         "ok=%s only_handles=%s" % (ok, getattr(s, 'only_handles', None)))
    if ok:
        step("★ A 端点模式【没有】把手柄转 FREE（保留 ALIGNED）",
             pts(o, act, 14.0)[3] == 'ALIGNED',
             "类型=%s" % (pts(o, act, 14.0)[3],))
        s.apply_numeric(40.0)
        c1, hl1, hr1, lt1, rt1 = pts(o, act, 14.0)
        step("★ A 选中的左端点【动了】", (hl1 - hl0).length > 1e-4,
             "|Δhl|=%.6f" % (hl1 - hl0).length)
        step("★★ A co 不动", (c1 - c0).length < 1e-6, "|Δco|=%.9f" % (c1 - c0).length)
        dev = collinear_dev(c1, hl1, hr1)
        step("★★ A 旋转后【仍保持共线】（无折角）", dev is not None and dev < 1e-5,
             "共线偏差=%.3e" % (dev if dev else -1))
        step("★ A 对侧长度不变（原生：只转方向不改长度）",
             abs((hr1 - c1).length - (hr0 - c0).length) < 1e-5,
             "%.6f -> %.6f" % ((hr0 - c0).length, (hr1 - c1).length))
        # ★★ 第十轮修订：被拖侧 = ALIGNED（原生）；
        #    对侧 = **FREE**（封口，防 Blender 后续按 (t,v) 共线重算它 ——
        #    那会破坏 3D 形状并把用户的速度分布 dt 改掉）。见 _probeZ.py。
        step("★ A 类型：被拖侧 ALIGNED（未破坏）+ 对侧 FREE（封口防重算）",
             lt1 == 'ALIGNED' and rt1 == 'FREE',
             "%s/%s" % (lt1, rt1))
        s.cancel()
        c2, hl2, hr2, _, _ = pts(o, act, 14.0)
        step("A 取消后精确还原",
             max((c2 - c0).length, (hl2 - hl0).length, (hr2 - hr0).length) < 1e-6,
             "max=%.9f" % max((c2-c0).length, (hl2-hl0).length, (hr2-hr0).length))

    # =========================================================
    # B. FREE：对侧【完全不动】
    # =========================================================
    o, act = build('FREE')
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    c0, hl0, hr0, _, _ = pts(o, act, 14.0)
    s = me.RotateSession('ROTATE')
    ok = s.begin(o, act, region, rv3d, 600.0, 400.0)
    if ok:
        s.apply_numeric(40.0)
        c1, hl1, hr1, _, _ = pts(o, act, 14.0)
        step("★ B FREE：选中的左端点动了", (hl1 - hl0).length > 1e-4,
             "|Δhl|=%.6f" % (hl1 - hl0).length)
        step("★★ B FREE：对侧右端点【完全不动】（原生：自由手柄互不影响）",
             (hr1 - hr0).length < 1e-6, "|Δhr|=%.9f" % (hr1 - hr0).length)
        step("★ B FREE：co 不动", (c1 - c0).length < 1e-6, "")
        s.cancel()

    # =========================================================
    # C. 多端点：只动选中的那些；未选中的帧不受影响
    # =========================================================
    o, act = build('FREE')
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    _session.toggle_endpoint(27.0, 'left')
    b14 = pts(o, act, 14.0); b27 = pts(o, act, 27.0); b1 = pts(o, act, 1.0)
    s = me.RotateSession('ROTATE')
    if s.begin(o, act, region, rv3d, 600.0, 400.0):
        s.apply_numeric(30.0)
        a14 = pts(o, act, 14.0); a27 = pts(o, act, 27.0); a1 = pts(o, act, 1.0)
        step("★ C 两个选中的端点都动了",
             (a14[1] - b14[1]).length > 1e-4 and (a27[1] - b27[1]).length > 1e-4,
             "Δ14=%.6f Δ27=%.6f" % ((a14[1]-b14[1]).length, (a27[1]-b27[1]).length))
        step("★ C 未选中的帧（f1）完全不动",
             max((a1[i] - b1[i]).length for i in range(3)) < 1e-9,
             "Δ=%.9f" % max((a1[i]-b1[i]).length for i in range(3)))
        s.cancel()

    # =========================================================
    # D. G 移动端点：跟手（位移量对得上）+ 保持共线
    # =========================================================
    o, act = build('ALIGNED')
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    c0, hl0, hr0, _, _ = pts(o, act, 14.0)
    s = me.MoveSession('MOVE')
    ok = s.begin(o, act, region, rv3d, 600.0, 400.0)
    step("D G 模态开始（端点模式）", ok is True and s.only_handles is True,
         "ok=%s only=%s" % (ok, getattr(s, 'only_handles', None)))
    if ok:
        # 直接给一个世界位移（绕开投影），验证"位移量对得上"
        delta_world = mathutils.Vector((0.0, 2.5, 0.0))
        local = xf.world_offset_to_local(delta_world, s.parent_matrix)
        s.apply_numeric(0.0)                     # 先归零
        ok2 = xf.apply_endpoint_transform(
            s.act, s.obj, s.snapshot,
            (lambda f, v: v + local), list(s.endpoints), s.bone_name)
        c1, hl1, hr1, lt1, rt1 = pts(o, act, 14.0)
        got = hl1 - hl0
        step("★★ D 端点位移【跟手】（位移量 = 给的 2.5）",
             ok2 and abs(got.length - 2.5) < 1e-4,
             "|Δ|=%.6f 期望 2.5" % got.length)
        step("★ D 位移方向正确（+Y）",
             abs(got.y - 2.5) < 1e-4 and abs(got.x) < 1e-6 and abs(got.z) < 1e-6,
             "Δ=(%.4f, %.4f, %.4f)" % (got.x, got.y, got.z))
        dev = collinear_dev(c1, hl1, hr1)
        step("★★ D ALIGNED 共线保持（无折角）", dev is not None and dev < 1e-5,
             "共线偏差=%.3e" % (dev if dev else -1))
        step("★ D 类型仍是 ALIGNED", lt1 == 'ALIGNED', lt1)
        step("★ D 对侧长度不变", abs((hr1 - c1).length - (hr0 - c0).length) < 1e-5,
             "%.6f -> %.6f" % ((hr0-c0).length, (hr1-c1).length))
        s.cancel()

    # =========================================================
    # E. VECTOR：对侧贴到控制点
    # =========================================================
    o, act = build('VECTOR')
    _session.clear_endpoints()
    _session.toggle_endpoint(14.0, 'left')
    c0, hl0, hr0, _, _ = pts(o, act, 14.0)
    s = me.RotateSession('ROTATE')
    if s.begin(o, act, region, rv3d, 600.0, 400.0):
        s.apply_numeric(40.0)
        c1, hl1, hr1, _, _ = pts(o, act, 14.0)
        step("★ E VECTOR：对侧贴到 co（值方向）",
             (hr1 - c1).length < 1e-4,
             "|hr-co|=%.6f" % (hr1 - c1).length)
        s.cancel()

except Exception:
    step("FATAL", False, traceback.format_exc()[-1400:])

flush()
print("ENDPOINT_MODAL_DONE")
os._exit(0)
