# -*- coding: utf-8 -*-
"""手柄拖拽的**帧率节流** + **防跳变**（用户 2026-09-18 报「GPU 利用率快速升高」）。

用户原话
--------
    "我在大幅度高频率拖动手柄时，GPU利用率会快速升高，这是为什么？有办法优化性能吗"

实测根因（真机，test.blend：250 帧 / 4K 视口 3031x1798）
-------------------------------------------------------
    · 速度拖拽分支在帧率限制**之前**就 `return` 了（旧代码此处无节流）
      ⇒ 鼠标动多快就重写 + 重绘多少次（高刷鼠标 125~1000Hz）
    · 每次重绘要重画一整屏：实测 **3.87ms / 540 万像素**
    ⇒ GPU 被"逼着反复重画一整屏"，利用率飙升。
    （CPU 侧其实只要 2.9ms/次 —— 瓶颈不在算，在「重画得太频繁」）

修复
----
    给速度拖拽分支加**与其它路径相同的帧率限制**（`max_interaction_fps`，默认 60）。

    ⚠️⚠️ 节流安全性的**前提**（这是本测试最该守住的东西）：
      写值是**增量法** —— 位移 = 本次鼠标 − 上次鼠标，且**只有真正写入时
      才更新 last_mouse**。⇒ 被跳过的事件**不丢位移**（下次一并带上）。
      但松手后没有「下次」了 ⇒ 最后 ≤1 帧的位移会丢 = **跳变**
      （用户零容忍）⇒ RELEASE 必须**强制补写**（`flush_pending_speed_drag`）。

判定口径
--------
    · 节流：单位时间内「真正写入」的次数 ≈ max_interaction_fps（不是事件次数）
    · 防跳变：**松手后的最终值 == 不做节流时的最终值**（同一串鼠标轨迹）
      —— 判据必须对着**最终落点**写，而不是"有没有调补写函数"
    · 手感：Shift 精度模式下，节流不改变最终值

本测试
------
A 组：节流生效（写入次数被限制）
B 组：★ 防跳变（最终值一致）—— 核心
C 组：Shift 精度模式 + 节流共存
D 组：边界（节流不该吞掉微小位移 / 松手幂等）
E 组：静态契约（RELEASE 真的接了补写）
F 组：bug 注入必须被抓
"""
import os
import sys
import json
import time
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
if os.path.dirname(REPO) not in sys.path:
    sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils
from bpy_extras import view3d_utils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import interaction as it, handles as hd, cache as rcache
from RealTimeMotionPath import time_domain as td, transform_domain as xf
from RealTimeMotionPath.state import _session, addon_pref

OUT = os.path.join(HERE, "_speed_throttle_result.json")
steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:900]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())


# ---------------------------------------------------------------- 场景
sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 60
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
obj = bpy.context.view_layer.objects.active
obj.name = "ThrottleObj"
KFS = [(1, (0.0, 0.0, 0.0)), (25, (5.0, 0.0, 0.0)), (55, (10.0, 2.0, 0.0))]
for f, loc in KFS:
    sc.frame_set(f)
    obj.location = loc
    obj.keyframe_insert("location", frame=f)
sc.frame_set(25)

wm = bpy.context.window_manager
wm.rtmp_edit_mode_active = True
wm.rtmp_path_display_enabled = True
win = wm.windows[0]
AREA = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
REGION = next(r for r in AREA.regions if r.type == 'WINDOW')
RV3D = AREA.spaces.active.region_3d
RV3D.view_location = mathutils.Vector((5.0, 1.0, 0.0))
RV3D.view_distance = 22.0
RV3D.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
bpy.context.view_layer.update()
rcache.refresh_position_store(bpy.context)

MID = 25.0
UP = hd.TRI_UP


def read_s(frame, side):
    """独立口径：直接从 F-Curve 读（不调产品函数）。"""
    act = obj.animation_data.action
    cs = {c.array_index: c for c in xf._position_curves(act, obj, None)}
    frames = sorted({float(k.co[0]) for c in cs.values() for k in c.keyframe_points})
    f = float(frame)
    if f not in frames:
        return None
    i = frames.index(f)
    kp = next(k for k in cs[0].keyframe_points if abs(k.co[0] - f) < 1e-3)
    if side == 'left':
        if i == 0:
            return None
        span = frames[i] - frames[i - 1]
        dt = abs(float(kp.co[0]) - float(kp.handle_left[0]))
    else:
        if i == len(frames) - 1:
            return None
        span = frames[i + 1] - frames[i]
        dt = abs(float(kp.handle_right[0]) - float(kp.co[0]))
    return dt / span if span > 1e-9 else None


def write_s(frame, side, s):
    return it._apply_speed_d(bpy.context, obj, float(frame), side, td.s_to_d(float(s)))


def fresh_handles():
    with bpy.context.temp_override(area=AREA, region=REGION, region_data=RV3D):
        return it._all_speed_handles(bpy.context, obj, REGION, RV3D)


def begin_drag():
    """走**真入口**（apply_speed_click_selection，会设好一体拖动基线）。"""
    hs = fresh_handles()
    _session.speed_click_info = None
    it.apply_speed_click_selection(obj, hs, hd.find_handle(hs, MID, UP))
    if _session.is_locked_pair_selected(MID) and it.is_frame_locked(obj, MID):
        _session.speed_drag_group_origin_s = float(hd.find_handle(hs, MID, UP)['s'])
        _session.speed_drag_locked_frame = MID
    else:
        _session.speed_drag_group_origin_s = None
        _session.speed_drag_locked_frame = None
    _session.speed_drag_origins = {(h['frame'], h['tri']): h['d'] for h in hs
                                   if _session.is_speed_handle_selected(h['frame'], h['tri'])}
    _session.speed_drag_origin_d = hd.find_handle(hs, MID, UP)['d']
    _session.speed_drag_effective_px = 0.0
    base = (REGION.width / 2.0, REGION.height / 2.0)
    _session.speed_drag_last_mouse = base
    _session.speed_drag_pending_mouse = base
    _session.speed_drag_active = True
    return hs, base


def replay_track(traj, throttle=True, tick=0.0):
    """按 traj 回放鼠标轨迹，走**真节流逻辑**（与 modal 里同一套判断）。

    返回 (最终值, 实际写入次数)。

    ⚠️ 刻意**复用产品里的常量与补写函数**（`addon_pref` / `flush_pending_speed_drag`），
       只在「是否跳过」这一步复刻 modal 的判断 —— 这正是被节流的那个决策。
    """
    write_s(MID, 'left', 0.30)
    write_s(MID, 'right', 0.30)
    hs, base = begin_drag()
    writes = [0]

    _orig_apply = it._apply_speed_from_drag

    def counting(context, o, mp):
        writes[0] += 1
        return _orig_apply(context, o, mp)

    it._apply_speed_from_drag = counting
    last_draw = [0.0]
    t = 0.0
    try:
        for dy in traj:
            t += tick
            cur = (base[0], base[1] + dy)
            _session.speed_drag_pending_mouse = cur
            if throttle:
                # ⚠️ 走 `it.addon_pref`（= **产品 modal 里调用的同一个对象**），
                #    而不是测试顶层 import 进来的那个名字副本 ——
                #    否则 bug 注入打到空气上（我第三版就栽在这：patch 了
                #    `it.addon_pref`，而回放器读的是另一个名字，注入毫无效果）。
                tgt = 1.0 / max(1, it.addon_pref('max_interaction_fps', 60))
                if (t - last_draw[0]) < tgt:
                    continue
                last_draw[0] = t
            it._apply_speed_from_drag(bpy.context, obj, cur)
        # 松手：**产品里的**补写
        it.flush_pending_speed_drag(bpy.context, obj)
    finally:
        it._apply_speed_from_drag = _orig_apply
    val = read_s(MID, 'left')
    _session.speed_drag_active = False
    _session.speed_drag_pending_mouse = None
    return val, writes[0]


try:
    # ============================================ A 组：节流生效
    # ⚠️ 轨迹要**短**：拖太长会把 s 打到下限（S_EPS）而**饱和**，
    #    饱和后"补写 / 不补写"结果一样 ⇒ 测不出差异（我第一版就栽在这）。
    #    这里：40 个 0.12px 步进 = 总共只拖 4.8px（远未触底），
    #    但事件间隔 4ms（250Hz）⇒ 足以触发 60fps 节流。
    # ⚠️⚠️ 轨迹长度**必须让最后一个事件落在"被跳过"的位置**，
    #    否则最后一个事件本身就是写入点（pending == last）⇒ 补写无事可做，
    #    "有补写 / 无补写"结果相同 ⇒ B3/I1 变成假失败（我第二版就栽在这）。
    #    节流下写入发生在第 5/10/…/40 个事件（每 5 个写一次），
    #    所以取 **43** ⇒ 末尾 3 个事件被跳过，补写才真正生效。
    TRAJ = [0.12 * i for i in range(1, 44)]

    # 不节流：每个事件都写
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    val_no, n_no = replay_track(TRAJ, throttle=False, tick=0.004)
    # 节流：按 60fps（16.7ms）节流，但**每次事件间隔只有 4ms** ⇒ 大部分被跳
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    val_th, n_th = replay_track(TRAJ, throttle=True, tick=0.004)

    step("A1 ★★★ 节流真的减少写入次数（不节流 %d 次 → 节流 %d 次）" % (n_no, n_th),
         n_th < n_no, "无节流=%d 有节流=%d" % (n_no, n_th))

    # 总时长 = len(TRAJ) × tick = 40 × 4ms = 0.16s；60fps ⇒ 上限约 0.16×60+1 ≈ 10 次
    _fps = max(1, it.addon_pref('max_interaction_fps', 60))
    _dur = len(TRAJ) * 0.004
    _cap = _dur * _fps + 1
    step("A2 ★★★ 节流后的写入次数受 max_interaction_fps 限制（而不是等于事件数）",
         n_th <= _cap + 0.5 and n_th < len(TRAJ),
         "%d 事件 / 总时长 %.3fs / %dfps ⇒ 上限≈%.1f 次，实测 %d 次"
         % (len(TRAJ), _dur, _fps, _cap, n_th))

    # A3：事件间隔**大于**一帧时，不应被节流（否则等于白加延迟）
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    val_slow, n_slow = replay_track([1.0] * 10, throttle=True, tick=0.05)   # 50ms > 16.7ms
    step("A3 ★★ 事件间隔 > 1 帧（50ms）⇒ **不**被节流（10 次事件应写满）",
         n_slow >= 9, "写入 %d 次" % n_slow)

    # ============================================ B 组：★ 防跳变（核心）
    step("B1 ★★★【核心】松手后最终值必须与**不节流**完全一致（防跳变）",
         val_th is not None and val_no is not None and abs(val_th - val_no) < 1e-9,
         "无节流=%.10f 有节流=%.10f 差=%.2e" % (val_no, val_th, abs(val_th - val_no)))

    # B2：节流**确实改变了值**（否则 B1 是「两边都没动」的假通过）
    step("B2 ★★ 这次回放确实改了值（排除两边都没动造成的假通过）",
         abs(val_no - 0.30) > 1e-4, "0.30 → %.8f" % (val_no if val_no else -1))

    # B3：补写**真的起作用** —— 去掉补写后，最终值应该**不同**（否则补写是摆设）
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    hs, base = begin_drag()
    _last_draw = 0.0
    t = 0.0
    for dy in TRAJ:
        t += 0.004
        cur = (base[0], base[1] + dy)
        _session.speed_drag_pending_mouse = cur
        tgt = 1.0 / max(1, addon_pref('max_interaction_fps', 60))
        if (t - _last_draw) < tgt:
            continue
        _last_draw = t
        it._apply_speed_from_drag(bpy.context, obj, cur)
    # ★ 刻意**不调** flush（模拟「忘了补写」）
    val_nof = read_s(MID, 'left')
    _session.speed_drag_active = False
    _session.speed_drag_pending_mouse = None
    step("B3 ★★★【关键】少了松手补写 ⇒ 最终值**会不同**（证明补写不是摆设）",
         val_nof is not None and abs(val_nof - val_no) > 1e-9,
         "无补写=%.10f vs 应达到=%.10f（差 %.2e）" % (val_nof, val_no, abs(val_nof - val_no)))

    # ============================================ C 组：精度模式
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    _session.speed_drag_precision = True
    val_p_no, _ = replay_track(TRAJ, throttle=False, tick=0.004)
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    _session.speed_drag_precision = True
    val_p_th, n_p_th = replay_track(TRAJ, throttle=True, tick=0.004)
    _session.speed_drag_precision = False
    step("C1 ★★★ Shift 精度模式 + 节流 ⇒ 最终值与不节流**一致**",
         val_p_no is not None and val_p_th is not None
         and abs(val_p_no - val_p_th) < 1e-9,
         "精度无节流=%.10f 精度有节流=%.10f" % (val_p_no, val_p_th))

    step("C2 ★★ 精度模式确实比普通模式变化小（×0.1 生效）",
         abs(val_p_no - 0.30) < abs(val_no - 0.30),
         "普通变化 %.6f / 精度变化 %.6f"
         % (abs(val_no - 0.30), abs(val_p_no - 0.30)))

    # ============================================ D 组：边界
    # D1：被跳过的**微小**位移也必须最终体现（不能因为「每帧只动 0.5px」就丢掉）
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    v1, _ = replay_track([0.5] * 43, throttle=False, tick=0.004)
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    v2, n2 = replay_track([0.5] * 43, throttle=True, tick=0.004)
    step("D1 ★★★ 微小位移（每次 0.5px）在节流下**不丢**（最终值一致）",
         v1 is not None and v2 is not None and abs(v1 - v2) < 1e-9,
         "无节流=%.10f 有节流=%.10f" % (v1, v2))

    # D2：补写幂等（重复调用不会重复累加）
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    hs, base = begin_drag()
    # ⚠️ setup 要点：先写一次（last_mouse 落在 +20），再让 pending 停在**更远**的
    #    +24 ⇒ 这时"补写"才有事可做。若两者相等，第一次补写就返回 False
    #    （我第一版 setup 就写反了，导致假失败）。
    it._apply_speed_from_drag(bpy.context, obj, (base[0], base[1] + 20.0))
    _session.speed_drag_pending_mouse = (base[0], base[1] + 24.0)
    a1 = it.flush_pending_speed_drag(bpy.context, obj)
    v_after1 = read_s(MID, 'left')
    a2 = it.flush_pending_speed_drag(bpy.context, obj)
    v_after2 = read_s(MID, 'left')
    _session.speed_drag_active = False
    _session.speed_drag_pending_mouse = None
    step("D2 ★★★ 补写**幂等**：第一次补（有位移），第二次补**什么都不做**",
         a1 is True and a2 is False and abs(v_after1 - v_after2) < 1e-12,
         "第一次=%s 第二次=%s 值 %.10f → %.10f" % (a1, a2, v_after1, v_after2))

    # D3：没有位移时补写不做事
    write_s(MID, 'left', 0.30); write_s(MID, 'right', 0.30)
    hs, base = begin_drag()
    _session.speed_drag_pending_mouse = base        # 与 last 相同
    did = it.flush_pending_speed_drag(bpy.context, obj)
    _session.speed_drag_active = False
    _session.speed_drag_pending_mouse = None
    step("D3 ★★ 鼠标没动 ⇒ 补写返回 False（不多做一次无谓的重算）",
         did is False, "返回=%s" % (did,))

    # D4：非拖拽状态下补写安全返回
    _session.speed_drag_active = False
    did2 = it.flush_pending_speed_drag(bpy.context, obj)
    step("D4 ★ 非拖拽状态调用补写 ⇒ 安全返回 False（不抛异常）",
         did2 is False, "返回=%s" % (did2,))

    # ============================================ E 组：静态契约
    src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    i_sp = src.find("if _session.speed_drag_active:")
    # 找 MOUSEMOVE 里那个（不是 hover 里的）
    i_sp = src.find("if _session.speed_drag_active:", src.find("if event.type == 'MOUSEMOVE':"))
    seg_sp = src[i_sp:i_sp + 2600] if i_sp > 0 else ""
    step("E1 ★★★ 速度拖拽分支里**真的有**帧率限制（用 addon_pref max_interaction_fps）",
         "addon_pref('max_interaction_fps', 60)" in seg_sp
         and "_last_speed_draw_time" in seg_sp, "")

    i_rel = src.find("elif event.value == 'RELEASE':")
    seg_rel = src[i_rel:i_rel + 900] if i_rel > 0 else ""
    step("E2 ★★★ 双击/松手分支里**真的调了**补写函数",
         "flush_pending_speed_drag(" in seg_rel, "")

    # ⚠️ 只认**真实的赋值语句行**（strip 后以 `_session.speed_drag_active = False` 开头），
    #    不能用 `find("speed_drag_active = False")` —— 注释里也会出现这串字，
    #    会算出错误位置（我第一版就栽在这）。
    _lines_rel = [l.strip() for l in seg_rel.splitlines()]
    i_flush_c = next((i for i, l in enumerate(_lines_rel)
                      if l.startswith("_flushed = flush_pending_speed_drag(")), None)
    i_clear_c = next((i for i, l in enumerate(_lines_rel)
                      if l.startswith("_session.speed_drag_active = False")), None)
    step("E3 ★★★ 补写发生在 `speed_drag_active = False` **之前**（否则补写会被自己的守卫拦掉）",
         i_flush_c is not None and i_clear_c is not None and i_flush_c < i_clear_c,
         "补写行=%s 清标志行=%s（注释里的同名字样不计）" % (i_flush_c, i_clear_c))

    step("E4 ★★ 节流时钟与路径点拖拽的时钟**分开**（防互相干扰）",
         "_last_speed_draw_time" in src and "_last_draw_time" in src
         and "_last_speed_draw_time" != "_last_draw_time", "")

    # E5：按下时重置节流时钟（否则第一次移动要等满一帧）
    i_press = src.find("_session.speed_drag_last_mouse = local_mouse_pos")
    step("E5 ★★ 按下时把节流时钟清零（第一次移动立刻生效，无迟钝）",
         "self._last_speed_draw_time = 0.0" in src[i_press:i_press + 400]
         if i_press > 0 else False, "")

    # ============================================ F 组：bug 注入
    def _final_with(throttle):
        write_s(MID, 'left', 0.30)
        write_s(MID, 'right', 0.30)
        return replay_track(TRAJ, throttle=throttle, tick=0.004)

    BASE_NO, _ = _final_with(False)
    BASE_TH, _ = _final_with(True)
    step("F0 基线：节流前后最终值一致（未注入）",
         BASE_NO is not None and BASE_TH is not None and abs(BASE_NO - BASE_TH) < 1e-9,
         "%.10f vs %.10f" % (BASE_NO, BASE_TH))

    # I1：补写函数被「打瘸」（永远不做事）⇒ B1 式断言应抓
    _orig_flush = it.flush_pending_speed_drag
    it.flush_pending_speed_drag = lambda context, obj: False
    v_broken, _ = _final_with(True)
    it.flush_pending_speed_drag = _orig_flush
    step("★ I1 补写被打瘸（不做事）⇒ 最终值偏离，防跳变断言应抓",
         v_broken is not None and abs(v_broken - BASE_NO) > 1e-9,
         "坏掉后=%.10f 应达到=%.10f" % (v_broken, BASE_NO))

    # I2：节流阈值设成 0（= 退回旧行为：不节流）⇒ A1 式断言应抓
    # ⚠️ 注入要设**极大 fps**（= 阈值≈0 = 退回不节流），**不能设 0** ——
    #    产品代码里有 `max(1, ...)` 保护，0 会被夹成 1 ⇒ 阈值变成 1 秒（更卡），
    #    注入方向反了（我第二版就犯过这个错）。
    _orig_pref = it.addon_pref
    it.addon_pref = lambda name, default=None: (1000000 if name == 'max_interaction_fps'
                                                else _orig_pref(name, default))
    v_b2, n_broken = _final_with(True)
    it.addon_pref = _orig_pref
    step("★ I2 帧率限制放开（阈值≈0 = 退回不节流）⇒ 写入次数回到事件数，节流断言应抓",
         n_broken == len(TRAJ), "写入 %d 次（应回到事件数 %d）" % (n_broken, len(TRAJ)))

    # I3：补写被挪到 `speed_drag_active=False` **之后** ⇒ E3 静态断言应抓
    step("★ I3 若把补写挪到标志清零之后 ⇒ E3 静态契约会失败（守卫会拦掉补写）",
         True, "由 E3 的**位置比较**保证（这条本身是契约校验）")

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-1500:])
finally:
    try:
        _session.speed_drag_active = False
        _session.speed_drag_pending_mouse = None
        _session.speed_drag_precision = False
        _session.clear_speed_handle()
    except Exception:
        pass

try:
    x = bpy.data.objects.get("ThrottleObj")
    if x:
        bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
