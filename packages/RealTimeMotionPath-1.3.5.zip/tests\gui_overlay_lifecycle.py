# -*- coding: utf-8 -*-
"""覆盖层生命周期测试 —— 复现并验证「三角消失」bug 的修复

用户反馈（2026-09-15）：
    「一顿操作后，三角消失了，鼠标过去也不显现」

根因（代码走查 + 本测试确认）：
    `Overlay.stop()` 会同时删掉两个 draw handler：
        · _h_pixel  → 速度三角（2D）—— 归 path_point_drag 所有，长期存活
        · _h_view   → 轴约束线（3D）—— 归模态会话所有，瞬时
    模态结束时调用 stop()，把 pixel handler 一起删了；而 path_point_drag
    仍在运行、不会重新注册 → 三角永久消失。

修复：
    拆成 stop_view_only()（模态结束用）与 stop()（编辑模式关闭/卸载用）。

用法：blender --factory-startup --python tests/gui_overlay_lifecycle.py
"""
import bpy, os, sys, json, traceback, mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_lc_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
           (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
    for f, loc in KFS:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    import RealTimeMotionPath as RTMP
    from RealTimeMotionPath import overlay as ovmod
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath.state import _session

    step("addon loaded from REPO",
         os.path.normcase(os.path.dirname(os.path.abspath(RTMP.__file__))) == os.path.normcase(REPO),
         RTMP.__file__)

    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        pts = list(fc.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()

    wm = bpy.context.window_manager
    win = wm.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0))
    rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()

    over = ovmod.get_overlay()
    Ctx = type('C', (), {})
    ctx = Ctx()

    # ---------------- ① 模拟 path_point_drag 启动 ----------------
    over.stop()
    step("initial: nothing registered", (not over.has_pixel) and (not over.has_view),
         "pixel=%s view=%s" % (over.has_pixel, over.has_view))

    over.start(session=None)          # = path_point_drag.invoke()
    step("drag session started -> pixel handler on", over.has_pixel, over.has_pixel)
    step("drag session started -> no view handler yet", not over.has_view, over.has_view)

    # ---------------- ② 模拟模态启动 ----------------
    sess = me.MoveSession('MOVE')
    ok = sess.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("move session begin (with selection)", ok is True, sess.message)
    over.start(sess)                  # = modal.invoke()
    step("modal started -> view handler on", over.has_view, over.has_view)
    step("modal started -> pixel handler STILL on", over.has_pixel, over.has_pixel)

    # ---------------- ③ 模拟模态结束（★ bug 修复点） ----------------
    over.stop_view_only()             # = modal._finish()
    step("★ after modal finish -> pixel handler SURVIVES", over.has_pixel, over.has_pixel)
    step("after modal finish -> view handler removed", not over.has_view, over.has_view)

    # ---------------- ④ 反复循环（"一顿操作"） ----------------
    for i in range(3):
        over.start(me.MoveSession('MOVE'))
        over.stop_view_only()
    step("★ after 3 modal cycles -> pixel handler STILL on", over.has_pixel, over.has_pixel)

    # ---------------- ⑤ 三角仍能显示（端到端） ----------------
    recs = me.collect_speed_handles(act, obj, region, rv3d)
    step("handles still collectable after cycles", len(recs) == 6, len(recs))
    r14u = [r for r in recs if r['frame'] == 14.0 and r['tri'] == hd.TRI_UP][0]
    inter._update_speed_hover(ctx, obj, region, rv3d, r14u['kf_screen'])
    step("★ hover still shows triangles after cycles",
         len(_session.hover_handles) == 2,
         [(h['frame'], h['tri']) for h in _session.hover_handles])
    # 绘制不炸
    try:
        over._draw_2d()
        step("_draw_2d runs after cycles", True)
    except Exception as e:
        step("_draw_2d runs after cycles", False, repr(e)[:120])

    # ---------------- ⑥ 旧实现会失败的情形（回归探针） ----------------
    # 若错误地调用 stop()（旧行为），pixel handler 会没掉 —— 用来证明本测试有效
    over.stop()
    step("[probe] full stop() removes pixel handler (old buggy behaviour)",
         not over.has_pixel, over.has_pixel)
    over.start(session=None)          # 恢复

    # ---------------- ⑦ 编辑模式关闭 -> 完全拆除 ----------------
    over.stop()
    step("edit-mode off -> nothing registered", (not over.has_pixel) and (not over.has_view),
         "pixel=%s view=%s" % (over.has_pixel, over.has_view))

except Exception:
    step("FATAL", False, traceback.format_exc()[-1000:])

flush()
print("LIFECYCLE_CHECK_DONE")
os._exit(0)
