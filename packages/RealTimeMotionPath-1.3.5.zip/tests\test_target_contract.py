# -*- coding: utf-8 -*-
"""目标描述（target dict）契约测试

存在意义
--------
用户实测崩溃：
    KeyError: 'kf_map'   —— 一选中三角按 G 就报错

根因：`_resolve_target_preferring_selection`（用选中的三角）和
      `resolve_speed_target`（按鼠标位置）都必须返回**同一种** dict，
      但调用方直接取键，没有任何机制保证两者同构。
      前者漏了 `kf_map` → KeyError。

本测试把"契约"钉死：
  ① 两条路径产出的 dict 键集**完全一致**
  ② 键集 == `make_target` 声明的 `TARGET_KEYS`
  ③ 选中路径的 `kf_map` / `span` / `side` 非空且可用
  ④ 走一遍 `ModalSession.begin`（用户崩溃的那条真实路径）
"""
import sys, os, json, types

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    pkg = types.ModuleType(PKG); pkg.__path__ = [ADDON_DIR]; pkg.__package__ = PKG
    sys.modules[PKG] = pkg

import bpy, importlib, mathutils

td = importlib.import_module(PKG + ".time_domain")
xf = importlib.import_module(PKG + ".transform_domain")
hd = importlib.import_module(PKG + ".handles")
me = importlib.import_module(PKG + ".modal_edit")
st = importlib.import_module(PKG + ".state")

results = []
def check(n, ok, d=""):
    results.append(("PASS" if ok else "FAIL", n, str(d)))


# ---------------- 场地 ----------------
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 40
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
obj = bpy.context.view_layer.objects.active
obj.name = "T"
KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
       (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
for f, loc in KFS:
    sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
act = obj.animation_data.action

for fc in xf._position_curves(act, obj, None):
    for kp in fc.keyframe_points:
        kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
    pts = list(fc.keyframe_points)
    for i in range(len(pts) - 1):
        k0, k1 = pts[i], pts[i + 1]
        t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
        k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
        k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
    fc.update()

# 假屏幕投影（可编程）
SCREEN = {1.0: (100.0, 300.0), 14.0: (400.0, 300.0),
          27.0: (700.0, 300.0), 40.0: (1000.0, 300.0)}
def fake_screen_pos(region, rv3d, wp):
    for f, p in KFS:
        if abs(wp.x - p[0]) < 1e-6 and abs(wp.y - p[1]) < 1e-6:
            return mathutils.Vector(SCREEN[float(f)])
    return None
me._screen_pos = fake_screen_pos

class Ctx:
    region = object()
    region_data = object()
ctx = Ctx()


# ---------------- ① 按鼠标路径 ----------------
t_mouse = me.resolve_speed_target(ctx, obj, act, 400.0, 280.0)   # f14 下方
check("mouse path resolves", bool(t_mouse), t_mouse and t_mouse["frame"])
check("mouse path side == right", t_mouse and t_mouse["side"] == 'right',
      t_mouse and t_mouse["side"])

# ---------------- ② 选中三角路径 ----------------
st._session.clear_speed_handle()
st._session.selected_speed_frame = 14.0
st._session.selected_speed_tri = hd.TRI_UP        # 上三角 -> 左段

t_sel = me._resolve_target_preferring_selection(ctx, obj, act, 5.0, 5.0)
check("selection path resolves", bool(t_sel), t_sel and t_sel["frame"])
check("selection path uses SELECTED tri (side=left)",
      t_sel and t_sel["side"] == 'left' and t_sel["frame"] == 14.0,
      t_sel and (t_sel["frame"], t_sel["side"]))

# ---------------- ③ ★ 契约：两条路径键集完全一致 ----------------
km = set(t_mouse.keys())
ks = set(t_sel.keys())
check("★ both paths return SAME key set", km == ks,
      "mouse-only=%s  selection-only=%s" % (sorted(km - ks), sorted(ks - km)))
check("★ key set == declared TARGET_KEYS", km == set(me.TARGET_KEYS),
      "missing=%s extra=%s" % (sorted(set(me.TARGET_KEYS) - km), sorted(km - set(me.TARGET_KEYS))))

# ---------------- ④ ★ 关键字段非空可用（用户崩溃的那个） ----------------
check("★ selection path carries kf_map (was missing -> KeyError)",
      t_sel and isinstance(t_sel["kf_map"], dict) and len(t_sel["kf_map"]) == 3,
      t_sel and len(t_sel.get("kf_map") or {}))
check("selection path carries span", t_sel and t_sel["span"] is not None,
      t_sel and t_sel["span"])
check("mouse path carries kf_map", t_mouse and isinstance(t_mouse["kf_map"], dict),
      t_mouse and len(t_mouse.get("kf_map") or {}))

# ---------------- ⑤ ★ 走一遍真实崩溃路径：ModalSession.begin ----------------
sess = me.ModalSession('SPEED')
try:
    ok = sess.begin(obj, act, 5.0, 5.0,
                    lambda x, y: me._resolve_target_preferring_selection(ctx, obj, act, x, y))
    check("★ ModalSession.begin via selection path (the crash path)", ok is True, sess.message)
    check("session state RUNNING", sess.state == me.STATE_RUNNING, sess.state)
    check("session has marker_world", sess.marker_world is not None, sess.marker_world)
    check("session d_start set", sess.d_start is not None, sess.d_start)
    # 还能真正改动
    before = sess.last_s
    sess.update(5.0, 5.0 - 60)
    check("★ session can actually edit after begin", sess.last_s != before,
         "s: %s -> %s" % (before, sess.last_s))
    sess.cancel()
except Exception as e:
    check("★ ModalSession.begin via selection path (the crash path)", False,
          "%s: %s" % (type(e).__name__, e))

# ---------------- ⑥ 端点段应被拒绝（err 字段而非 crash） ----------------
st._session.clear_speed_handle()
st._session.selected_speed_frame = 1.0
st._session.selected_speed_tri = hd.TRI_UP        # f1 左段 = 端点段
t_end = me._resolve_target_preferring_selection(ctx, obj, act, 5.0, 5.0)
# 端点段：选中路径会 fallback 到按鼠标找（那里会给出 error）
check("endpoint selection path does not crash", True,
      t_end and (t_end.get("error") or "resolved via mouse fallback"))
t_mouse_end = me.resolve_speed_target(ctx, obj, act, 100.0, 320.0)   # f1 上方 = 左段端点
check("endpoint mouse path returns error (not crash)",
      t_mouse_end is not None and t_mouse_end["error"] is not None,
      t_mouse_end and t_mouse_end["error"])
st._session.clear_speed_handle()

fails = [r for r in results if r[0] == "FAIL"]
summary = {
    "total": len(results), "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in results],
}
json.dump(summary, open(os.path.join(HERE, "_tc_result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("WROTE_TARGET_CONTRACT_JSON")
