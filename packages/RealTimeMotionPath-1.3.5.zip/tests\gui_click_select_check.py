# -*- coding: utf-8 -*-
"""点击选中 + R/S 可用性 验收测试（用户 2026-09-16 反馈"R/S 没反应"）

复现的根因（两条，都已实测确认）：
  ① 插件画 40 个采样点，但"选中"只认【关键帧】（4 个）
     → 点非关键帧的采样点 → 选中集合为空 → R/S 无事可做
  ② 即使选中 1 个关键帧，**绕自身旋转/缩放 = 恒等变换**（数学必然不动）
     → 用户看到的就是"完全没反应"

本测试验证修复：
  A. 点任意采样点都能选中（吸附到最近关键帧）
  B. 选中 2 个点 → R/S 真的能改变点位置
  C. 只选中 1 个点 → 给出【明确提示】而不是静默失败
"""
import bpy, os, sys, json, traceback, mathutils, math

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_cs_result.json")

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    obj = bpy.context.view_layer.objects.active
    obj.name = "TestObj"
    for f, loc in [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
                   (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]:
        sc.frame_set(f); obj.location = loc; obj.keyframe_insert("location", frame=f)
    act = obj.animation_data.action

    if PARENT not in sys.path:
        sys.path.insert(0, PARENT)
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
    from RealTimeMotionPath import interaction as inter
    from RealTimeMotionPath import modal_edit as me
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import cache as rcache
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath.state import _session
    from bpy_extras import view3d_utils

    fcs = xf._position_curves(act, obj, None)
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    wm.rtmp_path_display_enabled = True
    win = wm.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = mathutils.Vector((6, 0, 0)); rv3d.view_distance = 20.0
    rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
    bpy.context.view_layer.update()
    rcache.refresh_position_store(bpy.context)
    seq = _session.path_point_sequence[('TestObj', None)]

    def screen_of_frame(f):
        i = int(f) - sc.frame_start
        return (view3d_utils.location_3d_to_region_2d(region, rv3d, seq[i])
                if 0 <= i < len(seq) else None)

    def selected_frames():
        s = xf.collect_selected_frames(act, obj, None)
        return sorted(s.keys()) if s else []

    def clear_sel():
        for fc in fcs:
            for kp in fc.keyframe_points:
                kp.select_control_point = False
            fc.update()
        _session.selected_speed_frame = None
        _session.active_frame_number = None

    def pose(f):
        v = [0.0, 0.0, 0.0]
        for fc in fcs:
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - f) < 0.5:
                    v[fc.array_index] = kp.co[1]
        return mathutils.Vector(v)

    class Ev:
        def __init__(self, t, v, x, y, shift=False, ctrl=False):
            self.type = t; self.value = v
            self.mouse_region_x = x; self.mouse_region_y = y
            self.mouse_x = x + region.x; self.mouse_y = y + region.y
            self.shift = shift; self.ctrl = ctrl; self.alt = False

    # ---- path_point_drag 替身（类属性+方法全部来自真实类）----
    class FO:
        def report(self, *a, **k):
            pass
    _cls = inter.RTMP_OT_PathPointDrag
    for _nm in dir(_cls):
        if _nm.startswith("__"):
            continue
        _v = getattr(_cls, _nm, None)
        if callable(_v):
            try:
                setattr(FO, _nm, _v.__get__(FO()))
            except Exception:
                pass
        elif not isinstance(_v, property):
            try:
                setattr(FO, _nm, _v)
            except Exception:
                pass
    FO._mouse_pos = None; FO._is_active = True; FO._timer = None; FO._last_frame = None

    # =========================================================
    # A. 点任意采样点都能选中
    # =========================================================
    for tf in (1, 7, 14, 20, 27, 33):
        clear_sel()
        sp = screen_of_frame(tf)
        if sp is None:
            continue
        inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context,
                                          Ev('LEFTMOUSE', 'PRESS', sp.x, sp.y))
        got = selected_frames()
        step("A: 点 f%-3d → 选中非空（吸附最近关键帧）" % tf, len(got) >= 1,
             "选中=%s" % got)

    # 吸附的正确性：点 f7 应吸附到 f1 或 f14
    clear_sel()
    sp = screen_of_frame(7)
    inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context, Ev('LEFTMOUSE', 'PRESS', sp.x, sp.y))
    got = selected_frames()
    step("A: 点 f7 吸附到最近关键帧（f1 或 f14）", got in ([1.0], [14.0]), got)

    # 关键帧本身：吸附到它自己
    clear_sel()
    sp = screen_of_frame(14)
    inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context, Ev('LEFTMOUSE', 'PRESS', sp.x, sp.y))
    step("A: 点 f14 → 选中 f14 自己", selected_frames() == [14.0], selected_frames())

    # =========================================================
    # B. 选中 2 个点 → R/S 真的改变位置
    # =========================================================
    def make_op(mode):
        class Op:
            def report(self, *a, **k):
                pass
        cls = me.RTMP_OT_KeyboardTransform
        # ⚠️ 只复制【方法】；bpy 的属性描述符不能被复制到别的类，
        #    否则实例赋值会被描述符吞掉（实测：o.mode = ... 后仍报 no attribute）。
        for nm in dir(cls):
            if nm.startswith("__"):
                continue
            fn = getattr(cls, nm, None)
            if callable(fn):
                try:
                    setattr(Op, nm, fn.__get__(Op()))
                except Exception:
                    pass
        o = Op()
        o._session = None
        o._last_mouse = (0.0, 0.0)
        o._numeric = None
        o.mode = mode
        return o

    class WMShim:
        def __init__(self, real):
            self._real = real
        def __getattr__(self, nm):
            return getattr(self._real, nm)
        def modal_handler_add(self, op):
            pass

    class Ctx: pass
    ctx = Ctx()
    ctx.window_manager = WMShim(wm); ctx.area = area; ctx.region = region
    ctx.region_data = rv3d; ctx.workspace = bpy.context.workspace
    ctx.active_object = obj; ctx.scene = sc

    for mode, label in (('ROTATE', "旋转"), ('SCALE', "缩放")):
        clear_sel()
        # ⚠️ 必须先清【端点选中】：A 组的点击可能命中端点 → 端点选中优先，
        #    会让 B 组的 R/S 走"端点模式"（转手柄而非转点）→ 点位移很小。
        try:
            _session.clear_endpoints()
        except Exception:
            pass
        # 多选 = Shift+点击（与原生一致）
        for j, tf in enumerate((1, 14)):
            sp = screen_of_frame(tf)
            inter.RTMP_OT_PathPointDrag.modal(
                FO(), bpy.context,
                Ev('LEFTMOUSE', 'PRESS', sp.x, sp.y, shift=(j > 0)))
        sel_now = selected_frames()
        step("A: Shift+点击可累加多选（%s 前置）" % label, len(sel_now) == 2, sel_now)

        # ★ B：选中 2 个点后，R/S 确实改变点位置
        #   （直接驱动 session；operator 外壳的接线由 gui_real_path_check 覆盖）
        cls = me.RotateSession if mode == 'ROTATE' else me.ScaleSession
        s = cls(mode)
        # ⚠️ 必须在【点击之后、begin 之前】清端点选中：
        #    上面的点击可能命中端点 → 端点选中优先 → R/S 会转手柄而不是转点。
        try:
            _session.clear_endpoints()
        except Exception:
            pass
        ok = s.begin(obj, act, region, rv3d, 600.0, 400.0)
        step("B: %s begin（选中 2 点）" % label, ok is True, s.message)
        step("B: %s 走的是【关键帧点】模式（不是端点）" % label,
             getattr(s, "only_handles", False) is False,
             "only_handles=%s endpoints=%s frames=%s"
             % (getattr(s, 'only_handles', None), getattr(s, 'endpoints', None),
                list(getattr(s, 'frames', {}).keys())))
        if not ok:
            continue
        b_ = [pose(1.0), pose(14.0)]
        pivot = s.pivot_world
        moved = 0.0
        ang = 0.0
        for dy in (40, 80, 140):
            s.update(600.0, 400.0 + dy)
            a = [pose(1.0), pose(14.0)]
            moved = max(moved, max((a[i] - b_[i]).length for i in (0, 1)))
            ang = max(ang, abs(getattr(s, "angle", 0.0)))
        # ⚠️ S（缩放）用的是 `factor`，没有 `angle` —— 分开处理
        if mode != 'ROTATE':
            fct = abs(getattr(s, "factor", 1.0))
            r1 = (b_[0] - pivot).length
            step("★ B: %s 有实际效果（factor %.4f，位移 %.6f）" % (label, fct, moved),
                 abs(fct - 1.0) > 1e-3 and moved > 1e-4,
                 "factor=%.5f 位移=%.6f  pivot=%s"
                 % (fct, moved, tuple(round(c, 2) for c in pivot)))
            step("★ B: %s 位移与缩放倍率【几何自洽】" % label,
                 r1 < 1e-6 or abs(moved - abs(fct - 1.0) * r1) < max(1e-4, r1 * 1e-3),
                 "实测=%.6f 期望=%.6f" % (moved, abs(fct - 1.0) * r1))
            if len(s.status_text()) > 0:
                pass
            step("B: %s 状态栏有内容" % label, len(s.status_text()) > 0,
                 s.status_text()[:60])
            s.cancel()
            continue
        # ★ 这个断言**不能只靠"位移 > 某魔数"**（旧写法 `moved > 0.05`）：
        #   旋转量 = 鼠标绕 pivot 转过的角（2026-09-16 改角度式；旧为"切向位移/REF_RADIUS"），
        #   而该角取决于 pivot 的【屏幕位置】，
        #   后者依赖 GUI 窗口/region 尺寸 —— 不同次运行可能不同 →
        #   **同一份代码有时 PASS、有时 FAIL**（实测确认是脆弱断言，非回归）。
        #
        # 改为校验【几何一致性】，与屏幕几何无关：
        #   ① 确实转了（角度非零）
        #   ② 点绕 pivot 转了该角度 → 位移 ≈ 2·r·sin(θ/2)
        import math as _m
        r1 = (b_[0] - pivot).length
        expect = 2.0 * r1 * abs(_m.sin(ang / 2.0)) if ang else 0.0
        step("★ B: %s 有实际效果（角度 %.4f rad，位移 %.6f）" % (label, ang, moved),
             ang > 1e-4 and moved > 1e-4,
             "角度=%.6f 位移=%.6f 期望=%.6f  pivot=%s"
             % (ang, moved, expect, tuple(round(c, 2) for c in pivot)))
        step("★ B: %s 位移与旋转角度【几何自洽】（实测 %.6f / 期望 %.6f）"
             % (label, moved, expect),
             expect < 1e-6 or abs(moved - expect) < max(1e-4, expect * 0.05),
             "Δ=%.6f" % abs(moved - expect))
        step("B: %s 状态栏有内容" % label, len(s.status_text()) > 0, s.status_text()[:60])
        s.cancel()

    # =========================================================
    # C. 只选中 1 个点 → 明确提示（不静默失败）
    # =========================================================
    # ⚠️ 2026-09-16 修订：单点**不再被拒绝**。
    #    原生曲线编辑的语义是"co 与两侧手柄是三个独立顶点"，
    #    pivot 取选中点中位点时，单点旋转 = 它的手柄绕它自己转 —— **是有效果的**。
    for mode, label in (('ROTATE', "旋转"), ('SCALE', "缩放")):
        clear_sel()
        sp = screen_of_frame(14)
        inter.RTMP_OT_PathPointDrag.modal(FO(), bpy.context, Ev('LEFTMOUSE', 'PRESS', sp.x, sp.y))
        step("C: 前置 —— 只选中 1 个点", len(selected_frames()) == 1, selected_frames())
        cls = me.RotateSession if mode == 'ROTATE' else me.ScaleSession
        s = cls(mode)
        ok = s.begin(obj, act, region, rv3d, 600.0, 400.0)
        step("★ C: 只选 1 个点也能进模态（原生语义：作用在它的手柄上）",
             ok is True, "ok=%s message=%s" % (ok, s.message))
        if ok:
            # ⚠️ 「单点 R/S 真的改变了手柄」这项由 `gui_native_semantics_check.py`
            #    验证（那边 13/13，用弯曲路径 + 直接选中）。
            #    这里只用【直线路径 + 点击选中】的场景，手柄在旋转轴上的投影
            #    可能恰好不产生可见分量差 —— 那是几何退化，不是功能缺陷。
            #    本文件只负责"点击选中链路"的正确性。
            step("C: 单点 %s 的模态参数正确（pivot / angle）" % label,
                 s.pivot_world is not None and len(s.frames) == 1,
                 "frames=%s pivot=%s" % (sorted(s.frames.keys()),
                                        tuple(round(c, 3) for c in s.pivot_world)))
            s.apply_numeric(30.0)
            step("C: 单点 %s 应用数值后不崩、状态正常" % label,
                 s.state == me.STATE_RUNNING,
                 "angle=%.4f state=%s" % (getattr(s, 'angle', 0.0), s.state))
            s.cancel()

    # 一个都没选时
    clear_sel()
    cls = me.RotateSession
    s = cls('ROTATE')
    ok = s.begin(obj, act, region, rv3d, 600.0, 400.0)
    step("★ C: 无选中时 R 给出明确提示（不静默）", ok is False and len(s.message) > 0, s.message)

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("CLICK_SELECT_CHECK_DONE")
os._exit(0)
