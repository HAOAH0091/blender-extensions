# -*- coding: utf-8 -*-
"""实测：Graph Editor 里「以各自中心缩放关键帧」对我们插件手柄的影响。

用户现象（2026-09-17）：
  「GE 里用各自中心对各个轴的关键帧缩放时，我们插件的手柄长度也会拉伸，
    而且**不会影响当前关键帧点处的速度**（和直接拖插件手柄做 S 缩放不一样，
    后者会改变当前关键帧点处的速度）」

要钉死的问题：
  Q1 GE 缩放具体改的是什么量？（值分量 / 时间分量 / 两者）
  Q2 插件手柄长度（= 值分量偏移的模）怎么变？
  Q3 「当前关键帧点处的速度」怎么变？
  Q4 与「直接拖插件手柄做 S 缩放」的差别到底在哪？

做法：直接对 handle 做三种缩放（数学等价于 GE 里的缩放），各测四项指标。
"""
import os
import sys
import json
import math

REPO = r"F:\desktop\BaiduSyncdisk\addons\RealTimeMotionPath"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, time_domain as td

rows = []


def rec(n, **k):
    k["name"] = n
    rows.append(k)
    print("[ROW]", json.dumps(k, ensure_ascii=False)[:1100])


KFS = [(1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.0)), (55, (6.0, 0.0, 0.0))]
FR = 25.0


def build():
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 55
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = "T"
    for f, loc in KFS:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    act = o.animation_data.action
    act.name = "ScaleAct"
    # 把中间帧两侧设 FREE + 给定初始手柄（值 1.0，时间 10 帧）
    for fc in xf._position_curves(act, o, None):
        kp = xf.keyframe_at(fc, FR)
        if kp is not None:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
            kp.handle_left = (kp.co[0] - 10.0, kp.co[1] - 1.0)
            kp.handle_right = (kp.co[0] + 10.0, kp.co[1] + 1.0)
    for fc in xf._position_curves(act, o, None):
        fc.update()
    sc.frame_set(int(FR))
    return o, act


def measure(o, act, tag):
    """四项指标：
       · 插件手柄长度 = |(Δv_x, Δv_y, Δv_z)|（drawing.py 取的就是这些）
       · 关键帧处三维速度 = |dP/df|（各轴 dy/dx 合成）
       · 各轴 s = dt/span
       · 路径偏差（与基线逐帧比对，由调用方传入基线）
    """
    sc = bpy.context.scene
    dv = []
    for fc in xf._position_curves(act, o, None):
        kp = xf.keyframe_at(fc, FR)
        if kp is not None:
            dv.append(kp.handle_right[1] - kp.co[1])
    dv = sorted(dv, key=abs, reverse=False)
    # 按轴序取（array_index 0/1/2）
    dvv = [None, None, None]
    for fc in xf._position_curves(act, o, None):
        kp = xf.keyframe_at(fc, FR)
        if kp is not None:
            dvv[fc.array_index] = kp.handle_right[1] - kp.co[1]
    handle_len = math.sqrt(sum((v or 0) ** 2 for v in dvv))

    # 关键帧处三维速度：对每轴用中心差分算 dy/df，再合成模
    eps = 0.05
    vels = []
    for fc in xf._position_curves(act, o, None):
        y_p = fc.evaluate(FR + eps)
        y_m = fc.evaluate(FR - eps)
        vels.append((y_p - y_m) / (2 * eps))
    speed = math.sqrt(sum(v ** 2 for v in vels))

    # 各轴 s
    ss = []
    for fc in xf._position_curves(act, o, None):
        kp = xf.keyframe_at(fc, FR)
        if kp is not None:
            km, span = td.resolve_target(act, o, FR, 'right')
            if km and span:
                s = td.read_s(kp, span, 'right')
                ss.append(round(float(s), 5) if s is not None else None)
    rec(tag, Δv各轴=[round(v, 5) if v is not None else None for v in dvv],
        插件手柄长度=round(handle_len, 5),
        关键帧处三维速度=round(speed, 5),
        各轴s=ss)
    return {"dv": dvv, "len": handle_len, "speed": speed}


def sample_path(o, act, n=110):
    pts = []
    for f in range(1, 56):
        bpy.context.scene.frame_set(f)
        pts.append(tuple(o.matrix_world.translation))
    return pts


try:
    # ---------- 基线 ----------
    o, act = build()
    base = measure(o, act, "T0 基线（值1.0 / 时间10）")
    base_path = sample_path(o, act)

    # ---------- 三种缩放（模拟 GE 里"各自中心"缩放）----------
    # "各自中心" = 以关键帧 co 为轴心 ⇒ co 不动，只缩放 handle 相对 co 的偏移
    for k, tag in ((2.0, "×2"), (0.5, "×0.5")):
        for mode in ("only_value", "only_time", "uniform"):
            o, act = build()
            for fc in xf._position_curves(act, o, None):
                kp = xf.keyframe_at(fc, FR)
                if kp is not None:
                    for attr in ("handle_left", "handle_right"):
                        h = list(getattr(kp, attr))
                        dv_ = h[1] - kp.co[1]
                        dt_ = h[0] - kp.co[0]
                        if mode in ("only_value", "uniform"):
                            dv_ *= k
                        if mode in ("only_time", "uniform"):
                            dt_ *= k
                        setattr(kp, attr, (kp.co[0] + dt_, kp.co[1] + dv_))
            for fc in xf._position_curves(act, o, None):
                fc.update()
            bpy.context.scene.frame_set(int(FR))
            m = measure(o, act, "T1 GE缩放 %s / %s" % (tag, mode))
            # 路径偏差
            p = sample_path(o, act)
            dev = max(math.dist(a, b) for a, b in zip(base_path, p))
            rec("   ↳ %s / %s 路径偏差" % (tag, mode), 最大偏差=round(dev, 6))

    # ---------- 对照组：直接拖插件手柄（S 缩放）----------
    #  插件手柄只改【值分量】，时间分量不动 ⇒ 模拟之
    for k, tag in ((2.0, "×2"), (0.5, "×0.5")):
        o, act = build()
        for fc in xf._position_curves(act, o, None):
            kp = xf.keyframe_at(fc, FR)
            if kp is not None:
                for attr in ("handle_left", "handle_right"):
                    h = list(getattr(kp, attr))
                    dv_ = (h[1] - kp.co[1]) * k      # ★ 只改值分量（现有拖拽的语义）
                    setattr(kp, attr, (h[0], kp.co[1] + dv_))
        for fc in xf._position_curves(act, o, None):
            fc.update()
        bpy.context.scene.frame_set(int(FR))
        m = measure(o, act, "T2 插件手柄缩放 %s（只改值分量）" % tag)
        p = sample_path(o, act)
        dev = max(math.dist(a, b) for a, b in zip(base_path, p))
        rec("   ↳ 插件手柄 %s 路径偏差" % tag, 最大偏差=round(dev, 6))

except Exception:
    import traceback
    rec("FATAL", tb=traceback.format_exc()[-1500:])

with open(os.path.join(HERE, "_ge_scale_probe.json"), "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=1)
print("GE_SCALE_DONE")
os._exit(0)
