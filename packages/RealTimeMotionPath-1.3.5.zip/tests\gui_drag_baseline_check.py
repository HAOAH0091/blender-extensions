# -*- coding: utf-8 -*-
"""拖拽位移基准（world_origin）回归 —— 用户 2026-09-17 实测的"跳变"。

用户报告
--------
    "打开工程后开启运动路径，然后拖出结尾帧的手柄，然后再去上一个关键帧的
     右手柄进行拖动时，右手柄发生了跳变，但是其他手柄却没有类似情况"

真因
----
`invoke`（PRESS）里把 `_session.world_origin` 设成了 **关键帧位置** `point_3d`。
（已核实：`cached_positions[obj][None][f]['position']` 与关键帧 co 逐位一致。）

而 modal 里：`total_offset = new_3d_pos - _session.world_origin`
写入是：    `手柄 = 基线 + total_offset`

⇒ 第一次移动（鼠标几乎没动、就在手柄末端附近）：
      total_offset ≈ 鼠标位置 - 关键帧位置 ≈ **手柄向量**
  ⇒ 手柄 = 手柄向量 + 手柄向量 = **2 倍长度** ⇒ **跳变**
  ⇒ **跳幅 ≈ 手柄长度**：
        · 端点手柄（0 长度）⇒ 看不出（用户："其他手柄没这情况"）
        · 最长的 f25 右手柄（|dv| = 10.55）⇒ 跳得最明显（用户实测的正是它）

修法
----
基准取【鼠标按下位置的 3D 投影】（`_mouse_world_ref`）⇒
    total_offset ≡ 鼠标位移量 ⇒ 按下不跳、之后相对跟手。

本测试
------
A 组：`_mouse_world_ref` 语义（投影 / 兜底）
B 组：端到端 —— 第一次移动不跳 + 跟手（**含旧行为对照，证明 bug 真实存在**）
C 组：静态契约（PRESS 两处都用新基准）
D 组：bug 注入（换回旧基准必须被抓）
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, interaction as it
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_drag_baseline_result.json")
steps = []

# ---- 假 region / rv3d + 受控的 2D→3D 投影 ----
CX, CY = 640.0, 360.0          # 屏幕中心
S = 0.01                       # 每像素 → 世界单位
_ORIG = it.view3d_utils.region_2d_to_location_3d


def fake_proj(region, rv3d, coord, depth_location):
    """受控的 2D→3D 投影，**必须幂等**（模拟真实语义）。

    真实 `region_2d_to_location_3d(region, rv3d, coord, depth_location)`：
    把屏幕点 coord 投影到「过 depth_location 且垂直于视线的平面」——
    `depth_location` 提供**深度**。关键性质：
        **proj(M, proj(M, D)) == proj(M, D)**   （同一个屏幕点 + 同一平面）
    ⇒ 鼠标不动时 `new_3d_pos - world_origin == 0`（这正是"按下不跳"的几何依据）。

    ⚠️ 本测试首版写成了 `depth + (coord-CENTER)*S`（平移模型），**不幂等**
       ⇒ 连"新基准"都会算出非零位移 ⇒ 测试自己假失败。
       改成"用 depth 的 X 分量当深度"的模型，幂等性成立。
    """
    d = mathutils.Vector(depth_location)
    depth = d.x if abs(d.x) > 1e-9 else 1.0
    mx = (float(coord[0]) - CX) * S
    my = (float(coord[1]) - CY) * S
    return mathutils.Vector((depth, depth * my, depth * mx))


class FakeRegion:
    pass


class FakeRV3D:
    pass


REGION, RV3D = FakeRegion(), FakeRV3D()


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


# ---------------------------------------------------------------- 构建场景
KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))


def build(name):
    sc = bpy.context.scene
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in KFS:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(1)
    a = o.animation_data.action
    for c in xf._position_curves(a, o, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        c.update()
    bpy.context.view_layer.objects.active = o
    for ob in bpy.data.objects:
        ob.select_set(ob is o)
    return o, a


def curves(o):
    return {c.array_index: c for c in
            xf._position_curves(o.animation_data.action, o, None)}


def kf(o, frame, ax):
    for k in curves(o)[ax].keyframe_points:
        if abs(k.co[0] - frame) < 1e-3:
            return k


def handle_vec(o, frame, side):
    """手柄的 3D 值分量向量（= 视觉长度与方向）"""
    v = []
    for ax in (0, 1, 2):
        k = kf(o, frame, ax)
        h = k.handle_right if side == 'right' else k.handle_left
        v.append(float(h[1]) - float(k.co[1]))
    return v


def vlen(v):
    return math.sqrt(sum(x * x for x in v))


NAMES = ("prepare_handles_for_edit", "update_linked_handle", "finish_linked_handle",
         "_apply_one_handle_offset", "apply_handle_offset", "record_handle_baseline",
         "record_endpoint_snapshot")
class Shim:
    pass
for _n in NAMES:
    _f = getattr(it.RTMP_OT_PathPointDrag, _n, None)
    if _f:
        setattr(Shim, _n, _f)
Shim.report = lambda self, *a, **k: None
shim = Shim()


def press(o, frame, side, mouse_xy, ref_mode):
    """模拟 PRESS：设置 world_origin（new = 鼠标基准 / old = 关键帧位置）。"""
    _session.active_frame_number = float(frame)
    _session.active_handle_direction = side
    _session.active_bone_identifier = None
    _session.handle_start_values.clear()
    _session.handle_edit_in_progress = False
    kfpos = [float(kf(o, float(frame), ax).co[1]) for ax in (0, 1, 2)]
    kp = mathutils.Vector(kfpos)
    if ref_mode == 'new':
        _session.world_origin = it._mouse_world_ref(REGION, RV3D, mouse_xy, kp)
    else:
        _session.world_origin = kp
    shim.record_handle_baseline(bpy.context, float(frame), None, side)


def move(mouse_xy):
    """模拟一次 MOUSEMOVE：返回 total_offset（= modal 里的写法）。"""
    new3d = it.view3d_utils.region_2d_to_location_3d(
        REGION, RV3D, mathutils.Vector(mouse_xy), _session.world_origin)
    return new3d - _session.world_origin


# ================================================================ A 组
try:
    it.view3d_utils.region_2d_to_location_3d = fake_proj

    K = mathutils.Vector((3.0, 2.0, 0.6))
    M = (CX + 500.0, CY + 300.0)          # 鼠标按在手柄末端附近（离屏幕中心很远）
    r = it._mouse_world_ref(REGION, RV3D, M, K)
    exp = fake_proj(REGION, RV3D, M, K)
    step("A1 ★基准 = 鼠标位置的投影（不是关键帧位置）",
         (r - exp).length < 1e-9 and (r - K).length > 1.0,
         "ref=%s  期望=%s  关键帧=%s"
         % ([round(v, 3) for v in r], [round(v, 3) for v in exp],
            [round(v, 3) for v in K]))
    step("A1b ★投影幂等（'按下不跳'的几何依据）",
         (fake_proj(REGION, RV3D, M, fake_proj(REGION, RV3D, M, K))
          - fake_proj(REGION, RV3D, M, K)).length < 1e-12,
         "proj(M, proj(M, D)) == proj(M, D)")

    step("A2 region/rv3d 缺失 ⇒ 退回 ref_point（安全兜底）",
         it._mouse_world_ref(None, RV3D, M, K) is K,
         "返回值 is ref_point")

    _bak = it.view3d_utils.region_2d_to_location_3d
    it.view3d_utils.region_2d_to_location_3d = lambda *a, **k: 1 / 0
    step("A3 投影抛异常 ⇒ 退回 ref_point（不崩）",
         it._mouse_world_ref(REGION, RV3D, M, K) is K, "返回值 is ref_point")
    it.view3d_utils.region_2d_to_location_3d = _bak

    # ============================================================ B 组
    # 鼠标按在手柄末端（|手柄| = 10 附近），先不动，再移动 100px
    o, a = build("_DB1")
    # 造一根长手柄（复现用户 f25 右手柄 |dv|=10.55 的情形）
    for ax in (0, 1, 2):
        k = kf(o, 25.0, ax)
        k.handle_right[1] = float(k.co[1]) + (10.55 if ax == 0 else 0.0)
    for c in curves(o).values():
        c.update()
    L0 = vlen(handle_vec(o, 25.0, 'right'))
    # 鼠标按在"手柄末端"的屏幕位置：把世界位置反推成屏幕坐标（用假投影的逆）
    hend = [float(kf(o, 25.0, ax).co[1]) + handle_vec(o, 25.0, 'right')[ax] for ax in (0, 1, 2)]
    kpos = [float(kf(o, 25.0, ax).co[1]) for ax in (0, 1, 2)]
    MEND = (CX + (hend[0] - kpos[0]) / S, CY + (hend[2] - kpos[2]) / S)

    # ---- 新基准：鼠标不动 → 位移必须为 0 ----
    press(o, 25.0, 'right', MEND, 'new')
    off0 = move(MEND)
    step("B1 ★★★ 新基准：鼠标不动 ⇒ total_offset == 0（按下不跳）",
         off0.length < 1e-9, "|offset| = %.12f" % off0.length)
    pre = handle_vec(o, 25.0, 'right')
    shim.apply_handle_offset(bpy.context, off0, 'right')
    post = handle_vec(o, 25.0, 'right')
    step("B2 ★★★ 新基准：第一次移动后手柄长度不变",
         abs(vlen(post) - L0) < 1e-6,
         "|dv| %.6f → %.6f（跳幅 %.6f）" % (L0, vlen(post), abs(vlen(post) - L0)))
    _session.handle_start_values.clear()

    # ---- 新基准：鼠标移动 100px → 手柄位移 == 鼠标位移（跟手）----
    press(o, 25.0, 'right', MEND, 'new')
    off1 = move((MEND[0] + 100.0, MEND[1] + 60.0))
    # 投影的缩放因子 = world_origin.x（= 关键帧的 depth 分量）
    exp_len = abs(_session.world_origin.x) * math.hypot(100.0 * S, 60.0 * S)
    step("B3 ★新基准：位移量 == 鼠标位移（跟手）",
         abs(off1.length - exp_len) < 1e-5 and off1.length > 1e-6,
         "|offset| = %.6f  期望 %.6f（容差 1e-5，浮点）" % (off1.length, exp_len))
    _session.handle_start_values.clear()

    # ---- ★ 旧行为对照：证明 bug 真实存在 ----
    o2, a2 = build("_DB2")
    for ax in (0, 1, 2):
        k = kf(o2, 25.0, ax)
        k.handle_right[1] = float(k.co[1]) + (10.55 if ax == 0 else 0.0)
    for c in curves(o2).values():
        c.update()
    L0b = vlen(handle_vec(o2, 25.0, 'right'))
    kpos2 = [float(kf(o2, 25.0, ax).co[1]) for ax in (0, 1, 2)]
    hend2 = [kpos2[ax] + handle_vec(o2, 25.0, 'right')[ax] for ax in (0, 1, 2)]
    MEND2 = (CX + (hend2[0] - kpos2[0]) / S, CY + (hend2[2] - kpos2[2]) / S)

    press(o2, 25.0, 'right', MEND2, 'old')
    offO = move(MEND2)                      # 鼠标【没动】
    shim.apply_handle_offset(bpy.context, offO, 'right')
    L2b = vlen(handle_vec(o2, 25.0, 'right'))
    step("B4 ★对照（旧基准）：鼠标【没动】，手柄却跳了 —— bug 复现",
         offO.length > 1.0 and L2b > L0b * 1.2,
         "鼠标没动却 offset=%.4f  |dv| %.4f → %.4f（跳幅 %.4f）"
         % (offO.length, L0b, L2b, abs(L2b - L0b)))
    _session.handle_start_values.clear()

    # ============================================================ C 组
    import inspect as _inspect
    src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    n_ref = src.count("_mouse_world_ref(")
    step("C1 ★静态契约：PRESS 两处（端点 / 普通手柄）都用鼠标基准",
         n_ref >= 3, "interaction.py 出现 _mouse_world_ref 共 %d 次（含定义 1 次）" % n_ref)
    step("C2 ★不再拿关键帧位置直接当位移基准",
         "_session.world_origin = point_3d" not in src
         and "_session.world_origin = handle_point['position']" not in src,
         "旧写法已消失")
    step("C3 _mouse_world_ref 可调用且签名正确",
         "region" in _inspect.signature(it._mouse_world_ref).parameters,
         str(list(_inspect.signature(it._mouse_world_ref).parameters.keys())))

    # ============================================================ D 组
    INJ = []

    def _mk_old_baseline():
        """I1：基准退回关键帧位置（= 用户报的 bug）。"""
        _orig = it._mouse_world_ref

        def do():
            it._mouse_world_ref = lambda region, rv3d, mouse, ref: ref

        def undo():
            it._mouse_world_ref = _orig
        return do, undo, "I1 ★基准退回关键帧位置（手柄跳到 2 倍）"

    def _check_B1():
        o, a = build("_IB")
        kpos = [float(kf(o, 25.0, ax).co[1]) for ax in (0, 1, 2)]
        hend = [kpos[ax] + handle_vec(o, 25.0, 'right')[ax] for ax in (0, 1, 2)]
        MEND = (CX + (hend[0] - kpos[0]) / S, CY + (hend[2] - kpos[2]) / S)
        press(o, 25.0, 'right', MEND, 'new')
        off = move(MEND)
        _session.handle_start_values.clear()
        return off.length < 1e-9

    base = _check_B1()
    step("D0 基线：未注入时 B1 检查为 True", base, "")
    for mk, ck in ((_mk_old_baseline, _check_B1),):
        do, undo, label = mk()
        try:
            do()
            caught = not ck()
        except Exception:
            caught = True
            label += "（异常也算抓住）"
        finally:
            undo()
        INJ.append((label, caught))
        step("★ %s ⇒ 测试抓住" % label, caught, "")

    it.view3d_utils.region_2d_to_location_3d = _ORIG
except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-700:])
finally:
    try:
        it.view3d_utils.region_2d_to_location_3d = _ORIG
    except Exception:
        pass

try:
    for n in ("_DB1", "_DB2", "_IB"):
        x = bpy.data.objects.get(n)
        if x:
            bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
