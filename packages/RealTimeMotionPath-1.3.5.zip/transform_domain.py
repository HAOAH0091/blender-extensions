"""RTMP 变换数据层（第一条线：G 移动 / R 旋转 / S 缩放）

与 time_domain 的分工
---------------------
    time_domain   → 改 handle[0]（时间分量），**不动路径形状**（第二条线）
    transform_domain → 改 keyframe 位置（值分量），**改路径形状**（第一条线）

这是两条独立的线，语义不同，互不干涉。

G 的语义（用户确认，见 设计存档 §11）
-----------------------------------
    移动**选中的路径点**（关键帧控制点），跟随鼠标（屏幕空间 → 世界空间）。
    X/Y/Z 锁轴；Shift+X/Y/Z 锁平面；连按同轴循环朝向；Shift 精度 ×1/10；数字输入。

为什么每个轴要连 handle 一起移动
------------------------------
关键帧的 `co` / `handle_left` / `handle_right` 共同定义曲线形状。
只移 `co` 会让手柄"留在原地"，曲线被拉伸变形；三者同步平移才是"整点搬家"。
（这正是插件现有 `apply_point_offset` 的做法，本模块保持一致。）
"""

import math

import mathutils

# 轴索引
AXIS_INDEX = {'X': 0, 'Y': 1, 'Z': 2}

SAFE_LIMIT = 1000000.0
PRECISION_FACTOR = 0.1      # Shift 精度：原生是 ×1/10

# 手柄的【派生类型】：坐标由 Blender 按公式**导出**，不接受外部写入
# （`fc.update()` 会覆盖它）。拖动时必须先接管。
_DERIVED_TYPES = ('AUTO', 'AUTO_CLAMPED', 'VECTOR')

# ★★ 拖动手柄时，Blender **原生**会把类型转成什么（官方手册原文）：
#
#   · Automatic / Auto Clamped：
#       "These handles **convert to Align handles when moved**."
#   · Vector：
#       "Vector handles **convert to Free handles when moved**."
#   · 并且："If you want to change an automatic handle's position, **just drag it**;
#            you don't need to manually change its type first."
#
#   （来源：Manual → F-Curve Properties → Left/Right Handle Type；
#     以及 Curve Structure → Bézier → Handle Types）
#
# ⚠️⚠️ 这条推翻了早先的实现：以前一律转 **FREE**，于是
#     · 拖完手柄类型变 FREE（原生是 ALIGNED）
#     · **对侧**仍是 AUTO_CLAMPED → 被 Blender 重算 → 永久不共线
#
#   AUTO / AUTO_CLAMPED → ALIGNED，语义恰好就是「handles remain on a straight line」
#   —— 用户在 3D 视图里期望的"两根手柄一条直线"，本来就是 ALIGNED 的定义。
_DRAG_TO_TYPE = {'AUTO': 'ALIGNED', 'AUTO_CLAMPED': 'ALIGNED', 'VECTOR': 'FREE'}

# dt（手柄时间分量离 co 的距离）的【可分辨下限】。
# 实测 Blender 数据层对 dt 的分辨率约为 1e-3 帧（见设计存档）；低于它：
#   · 时间分量已无意义（和 co 同一帧）
#   · 任何 `dv / dt` 形式的斜率计算都会**数值爆炸**
# 所以所有依赖 dt 的运算都要先过这个下限。
DT_EPS = 1e-3

# 手柄【三维长度】的可分辨下限（拖拽量的分母，趋零时方向无定义）
_ARM_EPS = 1e-9


# ★★ 插件「接管为 FREE」的手柄登记：{(action_ptr, frame, axis, side)}
#
# 场景：拖手柄收尾时，为避免 Blender 的 ALIGNED 在**后续任何一次 `fc.update()`**
#       里把它按 "(t,v) 平面共线" 重算（那会破坏 3D 形状 + 改 dt），
#       我们把对侧**转成 FREE**（见 `_seal_opposite_handle`）。
#
# 但这带来一个新问题：FREE 在 `_link_mode` 里默认是「用户手动设的，不联动」——
#       于是**同一次拖动里的下一次调用**（模态是每帧调的）就再也不联动了
#       （实测：D 组共线偏差 0.88）。
#
# 所以必须区分「**插件接管**的 FREE」与「**用户手动**的 FREE」：
#   前者继续联动，后者按原生语义完全不动。
#
# ★ 持久化（2026-09-17）：登记会同步写进 action 的 custom property
#    `act["rtmp_owned_free"]`，打开文件时【惰性恢复】——
#    重启 Blender 后「体感类型」不丢（否则全部退化成"用户手动 FREE"，
#    用户看到的就是"拖一侧手柄、对侧不联动"）。
#    用户原话："让插件能够根据工程记录，以免重启 blender 后丢失手柄的体感类型。"
_plugin_owned_free = set()      # {(action_name, frame, side)}
_owned_warmed = set()           # 已从 custom property 恢复过登记的 action 名

_OWNED_PROP = "rtmp_owned_free"     # action 上的 custom property 名


def _own_key(kp, side):
    """给「某个手柄」算一个稳定标识（用于 `_plugin_owned_free`）。

    ★ 键 = `(action 名, 帧号, 侧)` —— 用 action **名**而不是 `as_pointer()`。

    ⚠️ 为什么不能用内存地址（2026-09-17 改）：
       · 文件重载后指针失效 ⇒ 登记全废（那正是"体感类型丢失"的原因）
       · 指针还可能被**复用**（action 释放后新 action 拿到同一地址）
         ⇒ 陈旧登记误伤新 action（`待决项_手柄联动.md` ①）
       action 名在文件内唯一、且**跨会话稳定**（存在 .blend 里），
       既解决持久化，又顺手消掉指针复用隐患。

    ⚠️ `Keyframe.id_data` 直接就是 **Action**（不是 F-Curve）——
       实测踩过：写成 `kp.id_data.id_data` 会抛 AttributeError 被吞掉，
       登记永远失败 → 封口后的下一次调用仍读成"用户 FREE"，不联动（D 组偏差 0.88）。

    ⚠️ 粒度到 (action, 帧, 侧)，**不带 axis** —— Python API 没有从 Keyframe
       反查 F-Curve 的入口，而封口本来就是三轴一起做的，这个粒度够用。
    """
    try:
        act = kp.id_data                     # ← 直接就是 Action
        return (str(act.name), round(float(kp.co[0]), 4), str(side))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 持久化读写（action 的 custom property）
# ---------------------------------------------------------------------------

def _owned_token(frame, side):
    """登记项在 custom property 里的字符串形式。"""
    return "%s|%s" % (("%.4f" % float(frame)), str(side))


def owned_free_tokens(act):
    """读 action 上持久化的登记项（字符串列表）。拿不到就返回空列表。"""
    try:
        v = act.get(_OWNED_PROP)
    except Exception:
        return []
    if not v:
        return []
    try:
        return [str(x) for x in v]
    except Exception:
        try:
            return [str(v)]
        except Exception:
            return []


def _write_owned_tokens(act, tokens):
    try:
        act[_OWNED_PROP] = sorted(set(str(t) for t in tokens))
        return True
    except Exception:
        return False


def warm_owned_free(act):
    """把 action 上持久化的登记恢复进内存镜像（幂等，每个 action 只做一次）。

    ★ 惰性调用（在 `_is_plugin_owned_free` 里）而不是挂 `load_post`：
      这样"刚打开文件""新建 action""复制 action"都能自动覆盖，
      不依赖某个 handler 是否触发。

    ⚠️ 查询在**重绘路径**上（`_link_mode` → 本函数被频繁调用），
       所以只有首次会读 custom property，之后全走内存 set。
    """
    if act is None:
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    if not nm or nm in _owned_warmed:
        return
    _owned_warmed.add(nm)
    for tok in owned_free_tokens(act):
        try:
            fr_s, side = str(tok).split("|")
            _plugin_owned_free.add((nm, round(float(fr_s), 4), str(side)))
        except Exception:
            continue


def mark_owned_free(kp, side):
    """★ 登记「这根 FREE 是**插件接管**的」⇒ 后续继续联动。**并持久化到 action。**

    所有"插件自己把类型转成 FREE"的地方都应调用本函数
    （封口、关键帧模态的临时转换……），否则那根手柄会被当成"用户手动 FREE"，
    用户看到的体感就是「拖一侧、对侧不联动」。
    """
    k = _own_key(kp, side)
    if not k:
        return False
    _plugin_owned_free.add(k)
    try:
        act = kp.id_data
        toks = owned_free_tokens(act)
        toks.append(_owned_token(k[1], k[2]))
        _write_owned_tokens(act, toks)
    except Exception:
        pass
    # ★ 2026-09-17（方案 A）：同步记录【体感类型 = LINK】—— 这才是权威数据。
    #   （旧表保留是为兼容测试与旧工程；新代码的联动判据只看体感表。）
    try:
        mark_feel(kp, side, 'LINK')
    except Exception:
        pass
    return True


def unmark_owned_free(kp, side):
    """取消登记（类型被**恢复**成原值时调用，防陈旧条目）。

    ★ 2026-09-17（方案 A）：同时清掉【体感记录】⇒ 该手柄回到"透传原始类型"。
    """
    k = _own_key(kp, side)
    if not k:
        return False
    _plugin_owned_free.discard(k)
    try:
        act = kp.id_data
        tok = _owned_token(k[1], k[2])
        _write_owned_tokens(act, [t for t in owned_free_tokens(act) if str(t) != tok])
    except Exception:
        pass
    # ★ 方案 A：同步清掉体感记录（回到透传）
    try:
        unmark_feel(kp, side)
    except Exception:
        pass
    return True


def clear_owned_free(act=None):
    """清空登记（`act=None` 时全清）。供将来"重置"类功能使用。"""
    if act is None:
        _plugin_owned_free.clear()
        _owned_warmed.clear()
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    for k in [k for k in _plugin_owned_free if k[0] == nm]:
        _plugin_owned_free.discard(k)
    _owned_warmed.discard(nm)
    try:
        if _OWNED_PROP in act:
            del act[_OWNED_PROP]
    except Exception:
        pass


def _is_plugin_owned_free(kp, side):
    k = _own_key(kp, side)
    if not k:
        return False
    if k in _plugin_owned_free:
        return True
    # 内存里没有 → 可能是【刚打开文件】（登记还在 action 的 custom property 上）
    # ⇒ 惰性恢复一次再判。这样"重启 Blender 后体感类型不丢"。
    try:
        warm_owned_free(kp.id_data)
    except Exception:
        pass
    return k in _plugin_owned_free


def _is_plugin_frozen(kp):
    """这个 FREE 手柄是【插件自己冻的】吗（速度编辑 `freeze_keyframe_pair`）？

    ⚠️⚠️ 这个判据是 2026-09-16 用户两个反馈的**同一个根因**：

      速度编辑会把被编辑关键帧（及其邻居）的**两侧手柄转成 FREE**，
      并登记到 `time_domain` 的冻结表。

      · 端点模态路径（`maintain_linked_handle`）**只看类型** → 见 FREE 就 return
        → **模态操作时对侧完全不联动**（用户：「只能作用于一端手柄」）
      · 鼠标路径（老 `update_linked_handle`）有 `is_frozen` 例外 → 联动
        → 于是「操作完再操作」时对侧突然补上 → **跳变**

      两条路径对"插件冻的 FREE"判断不一致 → 行为不一致 → 用户看到跳变。

      修法：把判据收敛到**这一个函数**，两条路径共用。
    """
    try:
        from . import time_domain as td
        return bool(td.is_frozen(kp.id_data, kp.co[0]))
    except Exception:
        return False


# ===========================================================================
# ★★★ 体感手柄类型（2026-09-17，用户拍板方案 A）
#
#   背景：以前「体感手柄类型」**不是一份独立数据** —— 它每次都由
#   「原始手柄类型 + 两张登记表」**现算**出来。后果：
#     · 重启 Blender 就丢（登记表在内存里）
#     · 用户在 Graph Editor 改原始类型，体感就跟着变（被牵着走）
#     · 代码里到处 `if 冻过 or 接管过`，只能猜
#
#   方案 A（用户选）：**体感绝对权威**。
#     · 体感类型**独立存**在本表里（权威）
#     · 原始手柄类型**降级成实现细节** —— 为了不让 Blender 重算偷改形状/速度，
#       按需把它写成 FREE（实测：ALIGNED 会被重算，手柄变化 6.54；FREE 是 0.0）
#     · 联动决策**只看体感**，不看原始类型
#
#   语义（`None` = **未记录 ⇒ 透传**）：
#     · 记录 'LINK'    → 联动（原始类型用 ALIGNED；含"插件冻的/接管的 FREE"）
#     · 记录 'CLAMPED' → 联动（原始类型用 AUTO_CLAMPED —— 多一层**钳制防过冲**）
#     · 记录 'VECTOR'  → 贴到控制点（**不在菜单里**，仅为兼容存量数据保留）
#     · 记录 'FREE'    → 不动（用户手动设的）
#     · **没记录**      → 体感 = 原始类型（透传，插件没碰过的关键帧别管）
#
#   ★ 2026-09-17 追加 'CLAMPED'：用户要求右键菜单把 Vector 换成 Auto Clamped。
#     实测（tests/_vecal_probe）：
#       · AUTO_CLAMPED 与 ALIGNED 的**联动行为完全相同**（都 → link）
#       · 区别在**曲线钳制**：只移动关键帧后手柄变化量 AUTO_CLAMPED **0.51**
#         vs ALIGNED **4.60** —— Auto Clamped 会钳制、防过冲
#     ⇒ 两者都归"联动"，但原始类型不同 ⇒ 体感取值分开记，菜单高亮才能 1:1。
#
#   ⚠️ 键 `(action 名, 帧号, 侧)`：与原来两张表同粒度。
#      action 名跨会话稳定（不是内存地址），所以能持久化。
# ===========================================================================

_FEEL = {}                      # {(action_name, frame, side): 'LINK'|'VECTOR'|'FREE'}
_feel_warmed = set()            # 已从 custom property 恢复过的 action 名

_FEEL_PROP = "rtmp_feel"        # action 上的 custom property 名


def _feel_key_of(action, frame, side):
    """★★【唯一的】体感表键 —— `(action 名, 帧号, 侧)`。

    ⚠️ 必须是**唯一来源**（mark / unmark / query 都调它）：
       各写一份时，只改其中一处的 bug 注入**行为测试抓不到**
       （同进程内恰好都"能跑"，跨会话才暴露）。见 `_frozen_key` 的教训。
    ⚠️ 用 action **名**（跨会话稳定）而不是 `as_pointer()`（重载即失效）。
    """
    try:
        return (str(action.name), round(float(frame), 4), str(side))
    except Exception:
        return None


def _feel_key(kp, side):
    """从关键帧取体感表键（**委托给唯一来源** `_feel_key_of`）。

    ⚠️ `Keyframe.id_data` 直接就是 **Action**（不是 F-Curve）——
       写成 `kp.id_data.id_data` 会抛 AttributeError 被吞掉。
    """
    try:
        return _feel_key_of(kp.id_data, kp.co[0], side)
    except Exception:
        return None


def _feel_token(frame, side, value):
    return "%s|%s|%s" % (("%.4f" % float(frame)), str(side), str(value))


def _feel_parse(tok):
    """'14.0000|left|LINK' → (14.0, 'left', 'LINK')，畸形返回 None。"""
    try:
        parts = str(tok).split("|")
        if len(parts) != 3:
            return None
        return (round(float(parts[0]), 4), str(parts[1]), str(parts[2]))
    except Exception:
        return None


def feel_tokens(act):
    """读 action 上持久化的体感记录（字符串列表）。"""
    try:
        v = act.get(_FEEL_PROP)
    except Exception:
        return []
    if not v:
        return []
    try:
        return [str(x) for x in v]
    except Exception:
        try:
            return [str(v)]
        except Exception:
            return []


def _write_feel_tokens(act, tokens):
    try:
        act[_FEEL_PROP] = sorted(set(str(t) for t in tokens))
        return True
    except Exception:
        return False


def warm_feel(act):
    """把 action 上持久化的体感记录恢复进内存镜像（幂等，每个 action 一次）。

    ★ 惰性调用（在 `feel_type` 里）而非挂 `load_post`：
      "刚打开文件 / 新建 action / 复制 action"都能自动覆盖。
    ⚠️ 查询在重绘路径上，所以只有首次会读 custom property。
    """
    if act is None:
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    if not nm or nm in _feel_warmed:
        return
    _feel_warmed.add(nm)
    for tok in feel_tokens(act):
        p = _feel_parse(tok)
        if p is None:
            continue
        frame, side, value = p
        _FEEL[(nm, frame, side)] = value


def mark_feel(kp, side, value):
    """★★ 记录「这根手柄的**体感类型**」并持久化到 action。

    `value` 取 'LINK' / 'VECTOR' / 'FREE'。**所有插件自己改类型的地方都应调用**
    （封口、速度编辑冻结、关键帧模态转 FREE），否则那根手柄会被当成
    "用户手动 FREE"，用户看到的体感就是「拖一侧、对侧不联动」。
    """
    k = _feel_key(kp, side)
    if not k:
        return False
    value = str(value).upper()
    _FEEL[k] = value
    try:
        act = kp.id_data
        toks = [t for t in feel_tokens(act)
                if (_feel_parse(t) or (None, None, None))[:2] != (k[1], k[2])]
        toks.append(_feel_token(k[1], k[2], value))
        _write_feel_tokens(act, toks)
    except Exception:
        pass
    return True


def mark_feel_at(action, frame, side, value):
    """按 `(action, 帧号, 侧)` 直接记体感（不需要 keyframe 对象）。

    供 `time_domain`（速度编辑冻结）这类只拿得到 (action, 帧号) 的调用方使用。
    """
    k = _feel_key_of(action, frame, side)
    if not k:
        return False
    value = str(value).upper()
    _FEEL[k] = value
    try:
        toks = [t for t in feel_tokens(action)
                if (_feel_parse(t) or (None, None, None))[:2] != (k[1], k[2])]
        toks.append(_feel_token(k[1], k[2], value))
        _write_feel_tokens(action, toks)
    except Exception:
        pass
    return True


def unmark_feel_at(action, frame, side):
    """按 `(action, 帧号, 侧)` 清体感记录（回到透传）。"""
    k = _feel_key_of(action, frame, side)
    if not k:
        return False
    _FEEL.pop(k, None)
    try:
        toks = [t for t in feel_tokens(action)
                if (_feel_parse(t) or (None, None, None))[:2] != (k[1], k[2])]
        _write_feel_tokens(action, toks)
    except Exception:
        pass
    return True


def unmark_feel(kp, side):
    """清掉体感记录（**回到透传原始类型**）。类型被"恢复"时调用。"""
    k = _feel_key(kp, side)
    if not k:
        return False
    return unmark_feel_at(kp.id_data, k[1], k[2])


def clear_feel(action=None):
    """清体感记录（action=None 全清；带 action 时连 property 一起删）。"""
    if action is None:
        _FEEL.clear()
        _feel_warmed.clear()
        return
    nm = getattr(action, "name", None)
    for k in [k for k in _FEEL if k[0] == nm]:
        _FEEL.pop(k, None)
    _feel_warmed.discard(nm)
    try:
        if _FEEL_PROP in action:
            del action[_FEEL_PROP]
    except Exception:
        pass


# ===========================================================================
# ★★ 三角「一体 / 分离」锁定状态（用户 2026-09-18 需求）
#
#   语义（用户原话 → 落点）：
#     · LOCKED（一体，**默认**）—— 同一关键帧的上下两个三角**联动**：
#         单击任一个 ⇒ **两个一起选中**；拖动 / 模态操作时两侧速度值恒等。
#     · SPLIT（分离）—— 两个三角各自独立，可单独选中、单独调整。
#
#   交互（见 `interaction.try_toggle_tri_lock_click`）：
#     双击 LOCKED 帧 → 分离（切成单边操作）
#     双击 SPLIT 帧  → 锁定，并**把对侧的值同步到被双击的这个三角**
#
#   ⚠️ 状态按**关键帧**独立（不是按三角），且随 action 持久化。
#   ⚠️ 只有**两个三角都存在的帧**（中间帧）才有"分离"的意义；
#      首帧（只有右段三角）/ 末帧（只有左段三角）永远视为一体。
#
#   实现完全照抄 `rtmp_feel` 那套经过验证的模式：
#     稳定键（action 名 + 帧号，不是内存地址）/ custom property /
#     惰性 warm / set+clear 对称 / clear 带 action 时连 property 一起删。
# ===========================================================================

_TRILOCK = {}                   # {(action_name, frame): False}  只记 SPLIT(=False)
_trilock_warmed = set()         # 已从 custom property 恢复过的 action 名
_TRILOCK_PROP = "rtmp_tri_lock"


def _trilock_key_of(action, frame):
    """★★【唯一的】三角锁定表键 —— `(action 名, 帧号)`。

    ⚠️ 必须是**唯一来源**（set / clear / query 都调它）：
       各写一份时，只改其中一处的 bug 注入**行为测试抓不到**
       （同进程内恰好都"能跑"，跨会话才暴露）。见 `_feel_key_of` 的教训。
    ⚠️ 用 action **名**（跨会话稳定）而不是 `as_pointer()`（重载即失效）。
    """
    try:
        return (str(action.name), round(float(frame), 4))
    except Exception:
        return None


def _trilock_token(frame, locked):
    return "%s|%s" % (("%.4f" % float(frame)), "LOCKED" if locked else "SPLIT")


def _trilock_parse(tok):
    """'14.0000|SPLIT' → (14.0, False)，畸形返回 None。"""
    try:
        parts = str(tok).split("|")
        if len(parts) != 2:
            return None
        return (round(float(parts[0]), 4), str(parts[1]).upper() == "LOCKED")
    except Exception:
        return None


def trilock_tokens(act):
    """读 action 上持久化的锁定记录（字符串列表）。"""
    try:
        v = act.get(_TRILOCK_PROP)
    except Exception:
        return []
    if not v:
        return []
    try:
        return [str(x) for x in v]
    except Exception:
        try:
            return [str(v)]
        except Exception:
            return []


def _write_trilock_tokens(act, tokens):
    try:
        act[_TRILOCK_PROP] = sorted(set(str(t) for t in tokens))
        return True
    except Exception:
        return False


def warm_tri_lock(act):
    """把 action 上持久化的锁定记录恢复进内存镜像（幂等，每个 action 一次）。

    ★ 惰性调用（在 `is_tri_locked` 里）而非挂 `load_post`：
      "刚打开文件 / 新建 action / 复制 action"都能自动覆盖。
    """
    if act is None:
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    if not nm or nm in _trilock_warmed:
        return
    _trilock_warmed.add(nm)
    for tok in trilock_tokens(act):
        p = _trilock_parse(tok)
        if p is None:
            continue
        frame, locked = p
        _TRILOCK[(nm, frame)] = bool(locked)


def is_tri_locked(action, frame):
    """★★【唯一的】三角锁定查询。True = 一体（默认），False = 分离。

    ⚠️ **未记录 ⇒ True**（默认一体）——这是需求里"默认情况下两个三角是一体的"。
    """
    k = _trilock_key_of(action, frame)
    if not k:
        return True
    v = _TRILOCK.get(k)
    if v is not None:
        return bool(v)
    # 内存没有 → 可能刚打开文件，惰性恢复一次
    try:
        warm_tri_lock(action)
    except Exception:
        pass
    v = _TRILOCK.get(k)
    return True if v is None else bool(v)


def set_tri_locked(action, frame, locked):
    """写锁定状态并持久化。

    `locked=True` ⇒ 把该帧的记录**删掉**（回到默认"一体"，词条与行为都干净）。
    `locked=False` ⇒ 记一条 SPLIT。
    """
    k = _trilock_key_of(action, frame)
    if not k:
        return False
    locked = bool(locked)
    if locked:
        _TRILOCK.pop(k, None)
    else:
        _TRILOCK[k] = False
    try:
        toks = [t for t in trilock_tokens(action)
                if (_trilock_parse(t) or (None, None))[0] != k[1]]
        if not locked:
            toks.append(_trilock_token(k[1], locked))
        _write_trilock_tokens(action, toks)
    except Exception:
        pass
    return True


def clear_tri_lock(action=None):
    """清锁定记录（action=None 全清；带 action 时连 property 一起删）。"""
    if action is None:
        _TRILOCK.clear()
        _trilock_warmed.clear()
        return
    nm = getattr(action, "name", None)
    for k in [k for k in _TRILOCK if k[0] == nm]:
        _TRILOCK.pop(k, None)
    _trilock_warmed.discard(nm)
    try:
        if _TRILOCK_PROP in action:
            del action[_TRILOCK_PROP]
    except Exception:
        pass


def feel_type(kp, side):
    """★★【唯一的】体感类型查询。

    返回：'LINK' / 'VECTOR' / 'FREE'，或 **None = 未记录（透传原始类型）**。

    ★ 方案 A 的核心入口：**联动决策只看这里**，不看原始手柄类型。
    """
    k = _feel_key(kp, side)
    if not k:
        return None
    v = _FEEL.get(k)
    if v is not None:
        return v
    # 内存没有 → 可能刚打开文件，惰性恢复一次
    try:
        warm_feel(kp.id_data)
    except Exception:
        pass
    return _FEEL.get(k)


def effective_feel(kp, side):
    """体感类型 + 透传：未记录时返回**原始手柄类型**（用户没碰过的别管）。

    返回 Blender 的原始类型字符串（'FREE'/'ALIGNED'/'AUTO'/'AUTO_CLAMPED'/'VECTOR'）。
    """
    v = feel_type(kp, side)
    if v is not None:
        return v
    try:
        return str(kp.handle_left_type if str(side) == 'left'
                   else kp.handle_right_type)
    except Exception:
        return 'ALIGNED'


def orig_type_for_feel(value):
    """体感类型 ⇒ 要写的**原始手柄类型**（实现细节）。

    ★ 方案 A：原始类型只为"不让 Blender 乱动"服务：
        'LINK'    → 'ALIGNED'      （原生"保持一条直线"，会被 Blender 维护）
        'CLAMPED' → 'AUTO_CLAMPED' （同上 + 钳制防过冲）
        'VECTOR'  → 'VECTOR'       （贴到控制点）
        'FREE'    → 'FREE'         （定住，Blender 绝不动）
    """
    return {'LINK': 'ALIGNED', 'CLAMPED': 'AUTO_CLAMPED',
            'VECTOR': 'VECTOR'}.get(str(value).upper(), 'FREE')


def _link_mode(kp, moved_side):
    """【唯一的】联动判据：被拖侧动了之后，对侧该怎么处理？

    返回（**只有这三个**）：
        'link'   —— 对侧绕 co 旋转保持共线
        'vector' —— 对侧贴到控制点
        'free'   —— 完全不动

    ★★ 2026-09-17（方案 A）：判据**只看体感手柄类型**，不再看原始类型 +
       两张登记表的组合。映射关系（保证与改造前**行为一致**）：

        体感 'LINK'   ← 原来的 ALIGNED / AUTO* / 插件冻的 FREE / 插件接管的 FREE
        体感 'VECTOR' ← 原来的 VECTOR
        体感 'FREE'   ← 原来的"用户手动设的 FREE"
        未记录        → 透传原始类型（新关键帧：插件没碰过就不管）

    原有两条关键语义仍然成立：
      · Automatic 系手柄「convert to Align handles when moved」→ 归入 'link'
      · "插件冻的 FREE"必须继续联动，否则端点模态不联动、鼠标路径却联动 → 跳变
    """
    opp = 'right' if str(moved_side) == 'left' else 'left'

    # ① 体感表有记录 → 按体感走（权威）
    try:
        v = feel_type(kp, opp)
    except Exception:
        v = None
    if v == 'VECTOR':
        return 'vector'
    if v == 'FREE':
        return 'free'
    if v in ('LINK', 'CLAMPED'):
        # 'LINK'（Aligned）与 'CLAMPED'（Auto Clamped）的**联动行为相同**，
        # 区别只在原始类型（Auto Clamped 多一层钳制）⇒ 联动判据都归 'link'。
        return 'link'

    # ② 未记录 → 透传原始类型（保持与改造前完全一致的判定）
    t = str(kp.handle_left_type if opp == 'left' else kp.handle_right_type)
    if t == 'VECTOR':
        return 'vector'
    if t in ('AUTO', 'AUTO_CLAMPED'):
        return 'link'
    if t == 'FREE':
        # ⚠️ 未记录但原始是 FREE —— 兼容旧工程的存量数据：
        #    仍查一次旧登记表（老 .blend 里只有 rtmp_owned_free / rtmp_frozen）。
        try:
            if _is_plugin_frozen(kp) or _is_plugin_owned_free(kp, opp):
                return 'link'
        except Exception:
            pass
        return 'free'
    return 'link'


# ---------------------------------------------------------------------------
# 收集选中的关键帧
# ---------------------------------------------------------------------------

_collect_all = None
_is_pos = None
try:
    from .cache import (collect_animation_curves as _collect_all,
                        is_position_animation as _is_pos)
except Exception:
    try:
        from cache import (collect_animation_curves as _collect_all,
                           is_position_animation as _is_pos)
    except Exception:
        pass


def _position_curves(action, obj, bone_name=None):
    if _collect_all is None or _is_pos is None:
        return []
    try:
        return [fc for fc in _collect_all(action, obj) if _is_pos(fc, bone_name)]
    except Exception:
        return []


def collect_selected_frames(action, obj, bone_name=None):
    """返回 {frame: {axis: fcurve}} —— 有任一轴控制点被选中的帧。

    ⚠️ 只返回【fcurve】，不返回 keyframe 对象：keyframe 包装对象用过一次会「钝」
       （见 blender-addon-dev skill），所以每次操作用的时候现取。
    """
    out = {}
    for fc in _position_curves(action, obj, bone_name):
        for kp in fc.keyframe_points:
            if kp.select_control_point:
                out.setdefault(round(float(kp.co[0]), 4), {})[fc.array_index] = fc
                # ⚠️ 这里【不能 break】：同一条 fcurve 上可以有多个被选中的关键帧，
                #    提前 break 会导致"多选时只有第一个点跟着动"（实测抓到的 bug）。
    return out


def keyframe_at(fcurve, frame):
    """按【最近匹配】找关键帧（容差 1e-3）。

    ⚠️ 容差必须远小于常见帧距。**关键帧可以只相隔 0.4 帧**（agent 实测发现），
       原来用 `< 0.5` 时，帧距 < 0.5 的相邻关键帧会被同一个 frame 匹配到
       → 写入**错的**关键帧 → 用户看到"操作完全没反应"
       （实测：帧距 0.4 时 R 无效果，帧距 0.6 时正常）。

       `collect_selected_frames` 用的 key 是 `round(co[0], 4)`（精确帧号），
       所以这里用 1e-3 的精确容差即可，既能正确匹配、又能区分相邻关键帧。
    """
    best = None
    best_d = 1e-3
    for kp in fcurve.keyframe_points:
        d = abs(kp.co[0] - frame)
        if d < best_d:
            best_d = d
            best = kp
    return best


def snapshot_positions(action, obj, frames, bone_name=None):
    """记录这些帧的 co / handle 的【值分量】+ 手柄【类型】。

    返回 {frame: {axis: {'co': v, 'hl': v, 'hr': v, 'hlt': t, 'hrt': t}}}

    `hlt` / `hrt` 用来在【取消】时恢复手柄类型（见 make_handles_editable）。
    """
    snap = {}
    for frame, axis_map in frames.items():
        per_axis = {}
        for axis, fc in axis_map.items():
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            per_axis[axis] = {
                'co': float(kp.co[1]),
                'hl': float(kp.handle_left[1]),
                'hr': float(kp.handle_right[1]),
                # ★ 时间分量也要记（P2 加权会改对侧的 dt —— 不记就还原不了）
                'hl_t': float(kp.handle_left[0]),
                'hr_t': float(kp.handle_right[0]),
                'hlt': str(kp.handle_left_type),
                'hrt': str(kp.handle_right_type),
            }
        snap[frame] = per_axis
    return snap


def make_handles_editable(action, obj, frames, bone_name=None):
    """把选中关键帧的两侧手柄转成 FREE（**保留坐标**），返回改前的类型以便恢复。

    ⚠️⚠️ 为什么必须做（2026-09-16 实测，见 tests 里的假说验证）

    Blender 新建关键帧的默认手柄类型是 **AUTO_CLAMPED** —— 派生类型，
    手柄坐标由 Blender 的公式**导出**，**不接受外部写入**（`fc.update()` 会覆盖）。

    实测（单点旋转 30°，纯直线路径）：

        FREE          Δhandle = 0.800000   手柄生效 ✓
        AUTO_CLAMPED  Δhandle = 0.000000   ★ 手柄被吞掉 → 看起来"完全没反应"
        ALIGNED       Δhandle = 0.800000   手柄生效

    多点旋转同样受害：AUTO_CLAMPED 下手柄只跟着 co 平移（Δ=1.0），
    而正确值应是 1.8 —— **形状也是错的**。

    这与 Blender 原生的语义一致：在 Graph Editor 里显式变换一个手柄，
    它就会变成 FREE（因为用户接管了它）。
    """
    prev = {}
    for frame, axis_map in frames.items():
        for axis, fc in axis_map.items():
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            prev[(frame, axis)] = (str(kp.handle_left_type), str(kp.handle_right_type))
            hl = kp.handle_left.copy()
            hr = kp.handle_right.copy()
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
            kp.handle_left = hl            # 转类型时 AUTO 系会重算坐标 → 写回原值
            kp.handle_right = hr
            # ★★ 2026-09-17 修复：登记「这是**插件转的** FREE」并持久化。
            #
            #    漏了这一步的后果（用户实测复现）：
            #      「选中关键帧 → 缩放使两侧手柄缩到关键帧点 → 插件长出空心圆
            #        → 拖一侧空心圆拉出手柄 → 再拖另一侧 → 两根手柄对不上」
            #    因为 `confirm()` 不恢复类型（只有 `cancel()` 恢复），两侧就此停在
            #    **未登记**的 FREE ⇒ `_link_mode` 判成"用户手动 FREE" ⇒ 对侧不联动。
            #    实测：漏登记的路径 3D 共线偏差 **0.6899**；补上登记后 **1.19e-07**。
            #
            #    键不含 axis ⇒ 多轴重复调用幂等（`mark_owned_free` 走 set + 去重写）。
            mark_owned_free(kp, 'left')
            mark_owned_free(kp, 'right')
            # ★ 方案 A：体感类型 = **LINK**（不是 FREE！）
            #   转原始 FREE 只是"为了写得进坐标"（实现细节）；
            #   体感上插件接管后**要继续联动对侧** —— 这正是上一轮
            #   「两根手柄对不上」的根因：漏登记 ⇒ 判成"用户手动 FREE" ⇒ 不联动。
            mark_feel(kp, 'left', 'LINK')
            mark_feel(kp, 'right', 'LINK')
    return prev


def prepare_handles_for_drag(action, obj, endpoints, bone_name=None,
                             link_opposite=True):
    """★ 拖动手柄前的【类型接管】——按 Blender **原生语义**，两条路径共用。

    ▎原生依据（官方手册原文，F-Curve Properties → Left/Right Handle Type）
        · Automatic / Auto Clamped：「These handles **convert to Align handles
          when moved**.」
        · Vector：「Vector handles **convert to Free handles when moved**.」
        · 「If you want to change an automatic handle's position, **just drag it**;
           you don't need to manually change its type first.」

    ▎为什么必须做（2026-09-16 实测，`_probe4.py`）
        默认工程的手柄是 **AUTO_CLAMPED**（`keyframe_insert` 的默认），
        它的坐标由 Blender 公式**导出**，不接管的话：

        | 场景 | 对侧共线偏差 | 对侧臂长 |
        |---|---:|---:|
        | 默认 AUTO_CLAMPED（不接管） | 0.184 → **0.832** ✗ | 1.33333 → **1.16667**（被重算） |
        | 两侧 ALIGNED（本函数接管后） | **0.0 全程** ✓ | **1.33333 守恒** ✓ |

        ⇒ 用户看到的第一步"**跳**" = 对侧被 Blender 重算导致臂长突变；
          "拖动后不对齐" = 对侧永远按 AUTO_CLAMPED 公式走，与插件要的共线无关。

    ▎两条规则
        · **被拖侧**：`AUTO/AUTO_CLAMPED → ALIGNED`、`VECTOR → FREE`（原生）
        · **对侧**（`link_opposite=True`）：`AUTO/AUTO_CLAMPED → ALIGNED`
          —— 不接管的话 Blender 会重算它，就**永远无法共线**。
          ALIGNED 的语义本就是「handles remain on a straight line」，
          两侧都转正是"保持一条直线"的实现。

    ▎不动的类型
        · `ALIGNED` / `FREE`：本来就写得进去（共线语义要保留 / 自由手柄独立）
        · **对侧的 `VECTOR`**：那是用户明确设的「贴相邻关键帧」语义，
          与共线是两回事（保留 agent 的 E 组契约）。
          被拖侧自己若是 VECTOR 则按原生转 FREE。

    ⚠️ 幂等：已是目标类型就跳过 → 可以每次 MOUSEMOVE 调，代价可忽略。

    ⚠️ **故意不调 `fc.update()`**：调用方在这之前已经把 `frame_kf_map` 里的
       keyframe **引用缓存**了，update 会让引用陈旧 → 后续写入落到错的轴上
       （实测：拖 (0,3,0) 变成 axis1 动 2.51、axis2 动 3.0）。

    ------------------------------------------------------------------
    ▎为什么**必须**接管（`_gap5.py` 实测，默认工程，鼠标直接拖手柄）

        | 拖拽侧手柄类型 | 被拖侧位移（期望 3.0） |
        |---|---:|
        | FREE          | 3.0000 ✓ |
        | ALIGNED       | 3.0000 ✓ |
        | AUTO_CLAMPED  | **0.0000 ✗** ← 新建关键帧的默认类型 |
        | VECTOR        | **0.0000 ✗** |

        ⇒ **默认场景下用户拖手柄完全没反应**。根因：派生类型的手柄坐标由
          Blender 公式**导出**，`fc.update()` 会把外部写入覆盖掉。

    ▎为什么**两侧都要**接管（5×5 类型矩阵实测）

        只接管被拖侧时，**对侧是派生类型**同样会让被拖侧写不进去：
            拖侧 ALIGNED + 对侧 VECTOR        → 位移只剩 **0.048**/3.0
            拖侧 ALIGNED + 对侧 AUTO_CLAMPED  → 位移只剩 **0.012**/3.0
        原因：ALIGNED 是「与对侧共线」的约束，对侧被 Blender 重算后会把
              被拖侧一起带走。
        全类型矩阵接管后：**25/25 组合位移精确 3.0000**。

    :return: 改前的类型 {(frame, axis): (lt, rt)}，交给 `restore_converted_types` 还原
    """
    prev = {}
    curves = _position_curves(action, obj, bone_name)
    if not curves:
        return prev
    for (frame, side) in (endpoints or []):
        f = float(frame)
        s = str(side)
        opp = 'right' if s == 'left' else 'left'
        plan = [(s, False)]
        if link_opposite:
            plan.append((opp, True))        # 第二个元素：是不是"对侧"
        for fc in curves:
            kp = keyframe_at(fc, f)
            if kp is None:
                continue
            for (sd, is_opp) in plan:
                attr = 'handle_left_type' if sd == 'left' else 'handle_right_type'
                cur = str(getattr(kp, attr))
                if is_opp and cur == 'VECTOR':
                    continue                # 对侧 VECTOR = 用户显式语义，保留
                new_t = _DRAG_TO_TYPE.get(cur)
                if new_t is None:
                    continue                # ALIGNED / FREE 保持
                key = (f, fc.array_index)
                if key not in prev:
                    prev[key] = (str(kp.handle_left_type), str(kp.handle_right_type))
                h = kp.handle_left.copy() if sd == 'left' else kp.handle_right.copy()
                setattr(kp, attr, new_t)
                # 转类型时 Blender 可能重算坐标 → 原样写回（"转类型不动手柄"）
                if sd == 'left':
                    kp.handle_left = h
                else:
                    kp.handle_right = h
    # ⚠️ 故意不 update()（见 docstring）
    return prev


# ⛔ **已废弃 / 死代码**（2026-09-16 code review 确认）：
#    全仓扫描（含 tests）引用数 = **0**。它已被 `prepare_handles_for_drag` 取代 ——
#    后者按 Blender 原生语义接管**两侧**，而本函数只接管被拖侧，于是
#    "对侧是派生类型"时被拖侧仍会被 Blender 重算（实测位移只剩 0.048 / 0.012）。
#
#    其有价值的实测经验已搬进 `prepare_handles_for_drag` 的 docstring
#    （5×5 类型矩阵结论、"故意不调 fc.update()" 的坑）。
#
#    ⚠️ **不要调用本函数**。留着只为留档；下次清理时可整块删除。
def prepare_drag_side_free(action, obj, endpoints, bone_name=None):
    """⛔ 已废弃（见上方说明）。把【被拖那一侧】的手柄转成 FREE（保留坐标）。

    为什么要做 —— 实测（`_gap5.py`，默认工程，鼠标直接拖手柄）：

        | 拖拽侧手柄类型 | 被拖侧位移（期望 3.0） |
        |---|---|
        | FREE          | 3.0000 ✓ |
        | ALIGNED       | 3.0000 ✓ |
        | AUTO_CLAMPED  | **0.0000 ✗** ← 新建关键帧的默认类型 |
        | VECTOR        | **0.0000 ✗** |

    ⇒ **默认场景下用户拖手柄完全没反应**。

    根因：派生类型（AUTO / AUTO_CLAMPED / VECTOR）的手柄坐标由 Blender 公式
    **导出**，`fc.update()` 会把外部写入覆盖掉。老代码在写入后立刻把类型
    "恢复"回原类型，紧接着就 `update()` → 拖拽被抹平。

    与原生一致：在 Graph Editor 里手动变换一个手柄，它就归用户管（转 FREE）。

    ⚠️ 只转【被拖侧】：对侧必须保持原类型，否则它的原生语义
       （VECTOR 贴 co / ALIGNED 共线 / AUTO 交 Blender）会丢 —— 实测踩过
       （`apply_endpoint_transform` 的 E 组，两侧都转会丢掉对侧 VECTOR 语义）。

    ⚠️ 幂等：已经是 FREE 的直接跳过 → 可以每次 MOUSEMOVE 调，代价可忽略。

    ⚠️⚠️ 这里**故意不调 `fc.update()`**（2026-09-16 实测踩坑）：
        调用方（`interaction.apply_handle_point_offset` / `_apply_one_handle_offset`）
        在这之前已经把 `frame_kf_map` 里的 keyframe **引用缓存下来了**；
        `fc.update()` 会让那些引用**陈旧失效** → 后续写入落到错的地方。
        实测现象：拖 (0,3,0) 却变成 axis1 动 2.51、axis2 动 3.0（总位移 3.91）。
        （与 agent 实测揭发的"缓存 BezTriple 返回陈旧数据"是同一个坑。）
        类型转换本身是立即生效的；坐标写回保证"转类型不动手柄"，
        真正的重算交给调用方收尾时那次 `fc.update()`。

    :return: 改前的类型 {(frame, axis): (lt, rt)}（需要还原时交给
             `restore_converted_types` 写回）
    """
    prev = {}
    curves = _position_curves(action, obj, bone_name)
    if not curves:
        return prev
    for (frame, side) in (endpoints or []):
        f = float(frame)
        s = str(side)
        attr = 'handle_left_type' if s == 'left' else 'handle_right_type'
        for fc in curves:
            kp = keyframe_at(fc, f)
            if kp is None:
                continue
            cur = str(getattr(kp, attr))
            if cur == 'FREE':
                continue
            # ⚠️⚠️ 转 FREE 的判据（2026-09-16 实测，5×5 类型矩阵）：
            #
            #   ① 被拖侧本身是**派生类型**（AUTO / AUTO_CLAMPED / VECTOR）
            #      → 坐标由 Blender 公式导出，写入会被 `fc.update()` 覆盖。
            #
            #   ② **对侧**是派生类型时，被拖侧同样会被覆盖
            #      （实测：拖侧 ALIGNED、对侧 VECTOR → 位移只有 0.048/3.0；
            #        对侧 AUTO_CLAMPED → 0.012/3.0）。原因是 ALIGNED 是"与对侧共线"
            #        的约束，对侧被 Blender 重算后，Blender 会连被拖侧一起重算。
            #
            # ALIGNED / FREE 组合（对侧也不是派生类型）**不转** ——
            # 它们本来就写得进去，且 ALIGNED 的共线语义要保留。
            opp_attr = 'handle_right_type' if s == 'left' else 'handle_left_type'
            if cur not in _DERIVED_TYPES and str(getattr(kp, opp_attr)) not in _DERIVED_TYPES:
                continue
            prev[(f, fc.array_index)] = (str(kp.handle_left_type),
                                         str(kp.handle_right_type))
            h = (kp.handle_left.copy() if s == 'left' else kp.handle_right.copy())
            setattr(kp, attr, 'FREE')
            # ⚠️ 转类型时 AUTO 系会重算坐标 → 把原坐标写回，保证"转类型不动手柄"
            if s == 'left':
                kp.handle_left = h
            else:
                kp.handle_right = h
    # ⚠️ 故意不 update()（见 docstring 的实测说明）
    return prev


def restore_handle_types(action, obj, frames, prev, bone_name=None):
    """把 `make_handles_editable` 记下的类型写回去（取消时用）。"""
    if not prev:
        return
    for frame, axis_map in frames.items():
        for axis, fc in axis_map.items():
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            t = prev.get((frame, axis))
            if not t:
                continue
            hl = kp.handle_left.copy()
            hr = kp.handle_right.copy()
            kp.handle_left_type = t[0]
            kp.handle_right_type = t[1]
            kp.handle_left = hl
            kp.handle_right = hr
            # ★ 2026-09-17 配套：类型被**恢复**了 ⇒ 取消登记，
            #   免得陈旧条目让"用户手动 FREE"被误判成"插件接管"（误联动）。
            unmark_owned_free(kp, 'left')
            unmark_owned_free(kp, 'right')


def restore_positions(action, obj, snapshot, bone_name=None):
    """把 snapshot 里的值写回（每次现取 keyframe，避免「钝」对象）。"""
    curves = _position_curves(action, obj, bone_name)
    by_axis = {}
    for fc in curves:
        by_axis[fc.array_index] = fc

    for frame, per_axis in snapshot.items():
        for axis, vals in per_axis.items():
            fc = by_axis.get(axis)
            if fc is None:
                continue
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            kp.co = (kp.co[0], vals['co'])
            # ★ 时间分量一并还原（缺了它，P2 加权改过的 dt 会残留）
            hlt_t = vals.get('hl_t', kp.handle_left[0])
            hrt_t = vals.get('hr_t', kp.handle_right[0])
            kp.handle_left = (hlt_t, vals['hl'])
            kp.handle_right = (hrt_t, vals['hr'])
    for fc in curves:
        fc.update()


# ---------------------------------------------------------------------------
# 约束（锁轴 / 锁平面 / 精度）
# ---------------------------------------------------------------------------

def apply_axis_lock(offset, axis_lock=None, plane_lock=None):
    """对世界空间偏移施加约束。

    axis_lock : 'X' / 'Y' / 'Z'   —— 只保留该轴分量（单轴）
    plane_lock: ('X','Y') 等       —— 只保留该平面的两个分量
    """
    v = mathutils.Vector(offset)
    if plane_lock:
        keep = {AXIS_INDEX[a] for a in plane_lock if a in AXIS_INDEX}
        for i in range(3):
            if i not in keep:
                v[i] = 0.0
        return v
    if axis_lock and axis_lock in AXIS_INDEX:
        keep = AXIS_INDEX[axis_lock]
        for i in range(3):
            if i != keep:
                v[i] = 0.0
        return v
    return v


def cycle_axis_lock(current_axis, current_plane, pressed_axis):
    """连按同轴循环朝向：无 → 单轴 → (X/Y 再次) → 平面 → 回单轴 ……

    简化实现（够用）：
        未锁定      + 按 X  → 锁 X
        已锁 X      + 按 X  → 解锁（回自由）
        已锁 X      + 按 Y  → 锁 Y
        未锁定      + Shift+X → 锁 YZ 平面（即排除 X）
    """
    if current_axis == pressed_axis:
        return None, None              # 再按同一轴 → 解锁
    return pressed_axis, None


# ---------------------------------------------------------------------------
# 平移
# ---------------------------------------------------------------------------

def world_offset_to_local(offset, parent_matrix):
    """世界空间偏移 → 关键帧所在的父级空间偏移。"""
    return parent_matrix.to_3x3().inverted() @ mathutils.Vector(offset)


def is_safe(offset):
    return all(abs(c) < SAFE_LIMIT for c in offset)


# ---------------------------------------------------------------------------
# 写入 vs 绘制：两套限制
# ---------------------------------------------------------------------------

# 写入用上限：只挡 NaN / Inf 和荒谬溢出。
WRITE_LIMIT = 1e12

# ★ P2 加权手柄：对侧手柄时间长度的缩放系数 k 的保护范围
# ⚠️ 2026-09-16（第十轮）加权已**停用** → 这两个常量目前**只被已停用的
#    `_apply_weight` 使用**（全仓唯一引用点在其函数体内）。
#    跟着它一起留着：将来若把加权做成开关，直接复用。
#   实测：拖拽量很小时 k 会很大（(0.5,0,0) 时 k=6.53）
_K_MIN = 1e-3
_K_MAX = 1e3

# 最近一次写入被拒的原因（供状态栏提示 —— 不静默）
last_skip_reason = None

# ★ 最近一次 `apply_endpoint_transform` 为写入而临时改过的类型映射
#   {(frame, axis): (hl_type, hr_type)}
#   调用方在"取消/结束"时必须用它恢复（否则 AUTO/AUTO_CLAMPED/VECTOR 会被永久改成 FREE）
last_converted_types = {}

# ★★ 拖动期间的【手柄时间分量原始值】{(frame, axis): (hl_t, hr_t)}
#
# 由 `snapshot_endpoints` 在**拖动开始**时整体重置并采集（那里是唯一的采集点，
# 不能在每次 MOUSEMOVE 调用的 `prepare_handles_for_drag` 里重采 —— 会把中途
# 漂移固化成"原值"）。`_seal_opposite_handle` 读它把对侧 dt 写回。
#
# 用途：拖动过程中我们（以及 Blender 的 ALIGNED）会经由若干次 `fc.update()`
#       把对侧 dt 改掉；收尾时用它**写回原值**，保证用户的速度分布一个数不动。
#
# ⚠️ 已知两点（2026-09-16 code review 记录，尚未处理）：
#   1. **键不含 action 身份**（只有 frame + axis）。同一会话里另一个 action
#      的同名帧会撞键。目前靠"`snapshot_endpoints` 每次拖动开始必重置"兜住，
#      但若某条路径调了 `_seal_opposite_handle` 而没先 `snapshot_endpoints`，
#      理论上会写错值。修法：键里加 `act.as_pointer()`，或直接把这个 dict
#      挂进 `session.endpoint_snapshot` 与它同生共死。
#   2. **"用完即清"没有实现** —— `_seal_opposite_handle` 读完后并不清空，
#      只有下一次 `snapshot_endpoints` 才会重置。所以它是"活到下次拖动开始"。
_drag_dt_origin = {}


def _drag_dt_key(frame, axis):
    return (round(float(frame), 4), int(axis))


def _seal_opposite_handle(curves, frame, side):
    """把【对侧】手柄「封口」：① 类型转 FREE  ② 时间分量写回拖动前的值。

    ⚠️⚠️ 为什么必须做（2026-09-16 实测，`_probeZ.py`）—— 这是用户第十轮反馈的根因：

        对侧若保持 **ALIGNED**，那么**任何一次后续 `fc.update()`**（下一次重绘、
        下一次操作、拖别的关键帧……）都会让 Blender 按它的 "(t,v) 平面共线"
        规则**重算对侧手柄**。而那个约束与插件要的 **3D 值空间共线不等价**：

            实测（对侧 ALIGNED，拖完后再来一次 update）：
                3D 点线距   1.452e-07  →  **0.2697**   ← 3D 形状**破相**
                对侧 dt     13.0       →  **11.07**    ← 速度分布被改
                对侧臂长     1.33333    →   1.33333

            实测（对侧 FREE，同样条件）：
                3D 点线距   1.452e-07  →  1.452e-07  ← 稳定
                对侧 dt     13.0       →  **13.0**     ← 稳定

        ⇒ 转 FREE 后 Blender 不再去动它 → 3D 形状稳定、速度分布稳定。
          用户拍板「一切以 3D 视图体验优先，Graph Editor 不需要共线」，
          所以这个取舍正是要的。

    ⚠️ 调用时机：只在 `_link_mode` 返回 **'link'** 时走到这里
       （`maintain_linked_handle` 里 `mode == 'free'` 会提前 return）。

       因此会被封口的对侧类型是：**ALIGNED / AUTO / AUTO_CLAMPED /
       插件冻的或接管的 FREE** —— 它们都会被转成 FREE。

       （⚠️ 早先这里写"对侧 AUTO* 不碰"是**错的**：`_link_mode` 对 AUTO*
       返回 'link'（原生语义 "convert to Align when moved"），所以 AUTO_CLAMPED
       对侧**确实会被接管成 FREE**。这是有意行为 —— 不接管的话 Blender 会按
       它自己的规则重算对侧，3D 形状与 dt 都不稳定。）

       唯一**不会**被封口的是：用户手动设的 FREE、以及 VECTOR
       （`mode` 分别是 'free' / 'vector'，在 `maintain_linked_handle` 里就分流了）。
    """
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        attr = 'handle_left_type' if side == 'left' else 'handle_right_type'
        hattr = 'handle_left' if side == 'left' else 'handle_right'
        # ① 时间分量写回原值
        k = _drag_dt_key(frame, fc.array_index)
        if k in _drag_dt_origin:
            hl_t, hr_t = _drag_dt_origin[k]
            t0 = hl_t if side == 'left' else hr_t
            v = getattr(kp, hattr)[1]
            setattr(kp, hattr, (float(t0), float(v)))
        # ② 类型转 FREE（Blender 之后不再重算它）
        if str(getattr(kp, attr)) != 'FREE':
            h = getattr(kp, hattr).copy()
            setattr(kp, attr, 'FREE')
            setattr(kp, hattr, h)      # 转类型时可能重算 → 原样写回
        # ③ 登记为「插件接管的 FREE」→ 后续仍按 'link' 联动，**并持久化**
        #    （否则同一次拖动里的下一次调用读到 FREE 就不联动了，实测偏差 0.88；
        #      不持久化则重启 Blender 后体感类型丢失）
        mark_owned_free(kp, side)
        # ★ 方案 A：体感类型 = LINK（封口后仍要联动，这才是权威语义）
        mark_feel(kp, side, 'LINK')


def take_converted_types():
    """取出并清空"临时转换的类型映射"（调用方收尾时用）。"""
    global last_converted_types
    out = dict(last_converted_types)
    last_converted_types = {}
    return out


def _reset_skip():
    global last_skip_reason
    last_skip_reason = None


def is_writable(v):
    """写入用的合法性检查。

    ⚠️ 与 `is_safe` 的区别（agent 实测发现的缺陷）：

      · `is_safe` 用 `SAFE_LIMIT = 1e6`，那是**绘制**用的（防 GPU 驱动崩溃）。
      · 原先写入也用它 → **缩放 1e7 倍时会静默跳过**：
        实测 `factor = 1e7` 但点间距纹丝不动，用户以为"没反应"，且毫无提示。

    数据合法性 与 绘制安全性 应该分开：
      写入允许大坐标（用户确实可能想要），绘制时再裁剪。
    """
    try:
        return all(math.isfinite(c) and abs(c) < WRITE_LIMIT for c in v)
    except Exception as _e:
        # ⚠️ 绝不静默：这里曾把 `NameError: name 'math' is not defined`
        #    悄悄转成"数值不安全"，导致所有变换失效且无从排查（实测踩过）。
        print("RealTimeMotionPath: is_writable 异常 -> %r" % (_e,))
        return False


def apply_translation(action, obj, snapshot, local_delta, bone_name=None,
                      only_handles=False):
    """把 snapshot 的原始位置 + local_delta 应用到场景。

    ⚠️ 每次都从 snapshot 重新算（而不是累加），避免浮点累积误差，
       也让「取消」只需 restore 一次。
    """
    dx, dy, dz = local_delta[0], local_delta[1], local_delta[2]

    def fn(_frame, v):
        return mathutils.Vector((v[0] + dx, v[1] + dy, v[2] + dz))

    return apply_point_transform(action, obj, snapshot, fn, bone_name,
                                 only_handles=only_handles)


def pose_of(snapshot, frame):
    """从 snapshot 取出该帧的【三轴值】组成的向量（缺的轴补 0）。"""
    v = [0.0, 0.0, 0.0]
    for axis, vals in snapshot.get(frame, {}).items():
        if 0 <= axis <= 2:
            v[axis] = vals['co']
    return mathutils.Vector(v)


# ---------------------------------------------------------------------------
# 统一的点群变换（G/R/S 共用）
# ---------------------------------------------------------------------------

def _point_from(snapshot, frame, key):
    """把某帧的某个顶点（'co' / 'hl' / 'hr'）组装成**完整三维点**。

    ⚠️ 必须用三个轴的值一起组装。只取单轴（如 (0, y, 0)）会丢掉其它轴信息，
       旋转/缩放的结果就不是刚体变换（实测：|p| 从 5 变成 6.12）。
    """
    v = [0.0, 0.0, 0.0]
    for axis, vals in snapshot.get(frame, {}).items():
        if 0 <= axis <= 2 and key in vals:
            v[axis] = vals[key]
    return mathutils.Vector(v)


def collect_endpoints(action, obj, endpoints, bone_name=None):
    """手柄端点列表 [(frame, side), ...] -> {frame: {axis: fcurve}}。

    与 `collect_selected_frames` 的区别：那是"关键帧点"，这是"手柄端点"。
    原生曲线编辑里两者是**各自独立**的可选中/可变换对象。
    """
    out = {}
    if not endpoints:
        return out
    curves = _position_curves(action, obj, bone_name)
    for (frame, _side) in endpoints:
        per_axis = {}
        for fc in curves:
            if keyframe_at(fc, frame) is not None:
                per_axis[fc.array_index] = fc
        if per_axis:
            out[float(frame)] = per_axis
    return out


def snapshot_endpoints(action, obj, endpoints, bone_name=None):
    """记录端点相关的三个值（co 也记，但变换时不动 co）。

    ★★ 本函数是【拖动开始】的那个时刻 —— 因此它同时负责把
       `_drag_dt_origin`（手柄时间分量的原值）刷新成当前值。
       收尾的 `_seal_opposite_handle` 依赖它把对侧 dt 写回。

    ⚠️ 采集点必须在这里（**拖动开始**），不能在每次 MOUSEMOVE 调用的
       `prepare_handles_for_drag` 里 —— 那里重采会把中途的漂移固化成"原值"。
       同一语义只留一个来源（这是踩过的坑）。
    """
    global _drag_dt_origin
    _drag_dt_origin = {}          # 新一次拖动 → 重新采集
    snap = {}
    for (frame, side) in endpoints:
        per_axis = {}
        for fc in _position_curves(action, obj, bone_name):
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            per_axis[fc.array_index] = {
                'co': float(kp.co[1]),
                'hl': float(kp.handle_left[1]),
                'hr': float(kp.handle_right[1]),
                # ★ 时间分量也要记（对侧的 dt 会在拖动途中被改 —— 不记就还原不了）
                'hl_t': float(kp.handle_left[0]),
                'hr_t': float(kp.handle_right[0]),
                'hlt': str(kp.handle_left_type),
                'hrt': str(kp.handle_right_type),
            }
            _drag_dt_origin[_drag_dt_key(frame, fc.array_index)] = (
                float(kp.handle_left[0]), float(kp.handle_right[0]))
        if per_axis:
            snap[float(frame)] = per_axis
    return snap


def _read_handle_point(curves, frame, side):
    """读某帧某一侧手柄的【三维点】（= 三个轴的值分量）。"""
    v = [0.0, 0.0, 0.0]
    got = False
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        h = kp.handle_left if side == 'left' else kp.handle_right
        v[fc.array_index] = float(h[1])
        got = True
    return mathutils.Vector(v) if got else None


def _set_handle_point(curves, frame, side, vec):
    """把某帧某一侧手柄写成给出的【三维点】（时间分量保持不变）。"""
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        if side == 'left':
            kp.handle_left = (kp.handle_left[0], float(vec[fc.array_index]))
        else:
            kp.handle_right = (kp.handle_right[0], float(vec[fc.array_index]))


def _kp_of(curves, frame):
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is not None:
            return kp
    return None


def _scale_handle_time(curves, snapshot, frame, side, scale):
    """把某帧某一侧手柄的【时间分量】按 scale 缩放（绕关键帧帧号）。

    ★ 端点模式 S 缩放【保速】用（用户 2026-09-17）：
      速度 = |dv / dt|；`_set_handle_point` 只写值分量 ⇒ 速度 ×scale。
      让 dt 也 ×scale ⇒ 速度不变（= 在「值-时间」平面上等比缩放）。

    ⚠️ 基准时间必须从 **snapshot** 读（进模态那一刻的原始值）——
       模态里鼠标每动一次就 _apply 一次，从 kp（当前值）读会**累乘 k^n**。
    """
    vals = (snapshot or {}).get(float(frame)) or (snapshot or {}).get(frame) or {}
    co_t = float(frame)
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        _v = vals.get(fc.array_index) or {}
        if side == 'left':
            t0 = float(_v.get('hl_t', kp.handle_left[0]))
            kp.handle_left = (co_t - (co_t - t0) * float(scale), float(kp.handle_left[1]))
        else:
            t0 = float(_v.get('hr_t', kp.handle_right[0]))
            kp.handle_right = (co_t + (t0 - co_t) * float(scale), float(kp.handle_right[1]))


def maintain_linked_handle(curves, frame, moved_side, co_p, moved_p,
                           opp_len=None, weighted=True, zero_eps=_ARM_EPS):
    """移动一个手柄端点后，按【原生曲线编辑】的语义维护对侧手柄。

    | 对侧类型 | 原生行为 | 本实现 |
    |---|---|---|
    | `ALIGNED` | 绕 co **旋转**保持共线，**长度不变** | 加权时改为"长度按比例伸缩"（见下） |
    | `AUTO` / `AUTO_CLAMPED` | Blender 按公式重算 | 不干预（交给 Blender） |
    | `VECTOR` | 对侧贴到控制点（值方向） | 同左 |
    | `FREE` | 完全独立，不动 | 同左 |

    ⚠️ 这修的是用户实测的两个问题（2026-09-16）：
      · 「手柄本来是 aligned 对齐的，G 移动后变得有折角了」
      · 「S 旋转选中的端点，旋转的却是对向的端点」
    旧实现直接把手柄转 FREE 后**平移**，既丢掉了共线、又动了不该动的那一侧。

    ---------------------------------------------------------------------
    ★★ P2 轻量解（2026-09-16 实测 + 业界对照）—— **已停用，见文末 ⚠️**

    只写"值分量"能保证 3D 共线，但 **(t,v) 平面会出折角**（实测最大 13.36°，
    因为 Blender 的重排按各轴自己的 `dt` 走）。

    （当时的）解法：**让对侧手柄的时间长度按同一个比例 k 缩放**
    （= Maya 的 "Weighted Tangents"）：

        k = L_opp / |moved3 − co3|
        对每个轴 A：dtR_A = dtL_A × k

    数学（已独立验算）：设 λ=1/(1+k)，则
      · (t,v) 共线要求 `co_v = hl_v + λ(hr_v − hl_v)`
      · 3D 共线要求   `hr3 = co3 − (L_opp/|d3|)·d3`
      · 两者相等 ⟺ `k = L_opp/|d3|`  ✓ 自洽

    实测（点到直线距离，避开 acos 噪声）：
      | 拖拽量 | k | 3D 点线距 | (t,v) 最大折角 |
      | (1,0,0) | 3.2642 | 0.000e+00 | 0.000001° |
      | (0.5,0,0) | 6.5284 | 0.000e+00 | 0.000000° |
      | (3,0,0) | 1.0881 | 0.000e+00 | 0.000002° |
      | (3,3,3) | 0.6282 | 0.000e+00 | 0.000001° |

    ⚠️ 上面这套"同时共线"的做法**已于 2026-09-16（第十轮）停用** ——
       用户拍板：**一切以 3D 视图手柄体验优先，Graph Editor 里不需要共线**。

       停用理由（实测，`_probeX.py`，速度编辑后拖手柄）：
         · 对 3D 体验**零收益** —— 带/不带加权的 3D 点线距是
           `7.262321574669722e-08`，**逐位相同到小数点后 15 位**。
           ⇒ 3D 共线**纯由值分量决定**，跟 dt 毫无关系。
         · 代价却是**把用户调好的速度分布整个抹掉** ——
           对侧 dt 13.0 → 1.76（改掉 86%），左右速度比 0.3333 → 1.0（变匀速）。

       现在的行为：**只写值分量** → 3D 共线 ✓ + 臂长守恒 ✓ + 速度分布一个数不动 ✓。
       代价只落在 "Graph Editor 里那三个点不共线" —— 而那正是用户不要的约束。

    :param weighted: ⚠️ **已不生效**（保留形参只为兼容调用方）。
                     原语义：False = 只转方向、长度锁死；True = 附带加权改 dt。
    """
    kp = _kp_of(curves, frame)
    if kp is None:
        return
    opp_side = 'right' if moved_side == 'left' else 'left'
    # ★★ 2026-09-16：联动判据收敛到 `_link_mode`（唯一来源）。
    #    关键变化：**插件自己冻的 FREE**（速度编辑）现在也走 'link' ——
    #    以前这里只看类型、见 FREE 就 return，导致"模态操作时对侧不联动"。
    mode = _link_mode(kp, moved_side)
    if mode == 'free':
        return                                  # 用户手动设的 FREE：原生语义，完全不动
    # ⚠️ 不要再写 `in ('free', 'auto')`：`_link_mode` 没有 'auto' 返回值
    #    （Automatic 系已归入 'link'），那个分支恒不成立。
    if mode == 'vector':
        _set_handle_point(curves, frame, opp_side, co_p)
        return
    # 'link'：对侧绕 co 旋转（ALIGNED，以及插件冻的 FREE）
    if opp_len is None:
        opp_p = _read_handle_point(curves, frame, opp_side)
        if opp_p is None:
            return
        opp_len = (opp_p - co_p).length
    d = moved_p - co_p
    if d.length < _ARM_EPS or opp_len < zero_eps:
        return
    _set_handle_point(curves, frame, opp_side, co_p + (-d.normalized()) * opp_len)

    # ★★ 封口：对侧转 FREE + dt 写回原值（详见 `_seal_opposite_handle`）。
    #    不封口的话，Blender 下次 `fc.update()` 会按它的 (t,v) 共线规则重算对侧
    #    → 3D 形状破相（1.45e-07 → 0.2697）+ 速度分布被改（dt 13.0 → 11.07）。
    _seal_opposite_handle(curves, frame, opp_side)

    # ★★★ 2026-09-16（第十轮）**停用加权** —— 用户拍板：一切以 3D 视图体验优先，
    #      Graph Editor 里**不需要**共线。
    #
    #      这里原本会调 `_apply_weight`，改掉对侧手柄的**时间分量 dt**
    #      来换取 "(t,v) 平面也共线"。实测（`_probeX.py` 速度编辑后拖手柄）：
    #
    #        | 指标 | 现状(带加权) | 停用加权(当前) |
    #        |---|---:|---:|
    #        | 3D 点线距 | 7.262321574669722e-08 | **7.262321574669722e-08** ← 逐位相同 |
    #        | 对侧三维臂长 | 1.333334 | 1.333334 ← 逐位相同 |
    #        | 对侧 dt（= 速度分布） | 13.0 → **1.76** ❌ 被改掉 86% | 13.0 → **13.0** ✅ 不动 |
    #        | 左右速度比 | 0.3333 → **1.0** ❌ 被抹成匀速 | 0.3333 → 0.1354 ✅ 保留 |
    #
    #      ⇒ 关键结论：**3D 共线完全由【值分量】决定，与 dt 无关**（两方案 3D 距离
    #        逐位相同，到小数点后 15 位）。所以改 dt 对 3D 体验是**零收益**，
    #        代价却是把用户精心调好的**速度分布整个抹掉**。
    #
    #      ⇒ 停用后：3D 视图手柄照样共线、照样跟手、臂长照样守恒；
    #        速度分布一个数都不动。代价只落在"Graph Editor 里那三个点不共线"
    #        —— 而那正是用户明确不要的约束。
    #
    #      ⚠️ `_apply_weight` 函数体**保留不删**（见其 docstring 的停用说明）：
    #         将来若要做"保速度分布 / 保 Graph Editor 共线"的开关，它现成可用。
    #      ⚠️ `weighted` 形参保留（调用方仍在传），但现在**不再生效**。
    _ = weighted


def _apply_weight(curves, frame, side, k, src_side=None):
    """⛔ **已停用**（2026-09-16 第十轮）—— 保留函数体，供将来做开关时复用。

    ▎为什么停用
        用户拍板：**一切以 3D 视图手柄体验优先，Graph Editor 里不需要共线**。

        本函数改的是对侧手柄的**时间分量 dt**，只为了让 "(t,v) 平面也共线"。
        实测（`_probeX.py`，速度编辑后拖手柄）：

          3D 点线距      带加权 7.262321574669722e-08
                          停用    7.262321574669722e-08   ← **逐位相同**
          对侧 dt        带加权 13.0 → 1.76（被改掉 86%）
                          停用    13.0 → 13.0（不动）
          左右速度比      带加权 0.3333 → 1.0（抹成匀速）
                          停用    0.3333 → 0.1354（保留）

        ⇒ 改 dt 对 3D 体验**零收益**（3D 共线纯由值分量决定），
          却把用户调好的**速度分布整个抹掉**。故停用。
        ⇒ 现在唯一的调用点已注释掉（见 `maintain_linked_handle`）。

    ▎如果将来要恢复
        在 `maintain_linked_handle` 末尾重新调用即可；建议做成偏好开关
        （"保速度分布 / 保 Graph Editor 共线"二选一），而不是写死。

    ---
    原说明：把某侧手柄的**时间分量**设成 `dt_src × k`（保持值分量不变）。

        dt_new = dt_src × k        （dt = 手柄时间 − co 时间；左为负、右为正）

    ⚠️⚠️ `k` 必须作用在【被拖侧】的 dt 上，不是对侧自己的 dt。
        写成 `dt_new = dt_old × k`（dt_old = 对侧自己的）是**错的** ——
        数学要求的是 `dtR = dtL × k`（见 maintain_linked_handle 的推导）。
        （实测踩过：用错基准时 (t,v) 折角 sin ≈ 1.1e-02，用对基准后降到 1e-6 级。）

    ⚠️ 边界保护（实测发现的两条，见计划书 §3.4）：

      ① `k` 在拖拽量趋零时会爆炸 → 夹到 [_K_MIN, _K_MAX]
      ② `dt_new` 过大时右手柄时间会**越过相邻关键帧**
         （实测 `hr_t` 达 61.35，而下一关键帧在 40）→ 夹到「不超过相邻关键帧」
    """
    if k is None or not math.isfinite(k) or k <= 0.0:
        return
    k = max(_K_MIN, min(_K_MAX, k))
    if src_side is None:
        src_side = 'left' if side == 'right' else 'right'
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        co_t = float(kp.co[0])
        # ★ 基准 = 被拖侧的 dt【长度】（不是对侧自己的、也不是带符号的值）
        #    ⚠️ 符号必须重设：左侧 dt 为负、右侧为正，而 k 是【长度比】(正数)。
        #       写成 `dt_new = dt_src * k`（带符号）会把右侧也弄成负的 —— 实测踩过。
        h_src = kp.handle_left if src_side == 'left' else kp.handle_right
        dt_src_len = abs(float(h_src[0]) - co_t)

        # ⚠️⚠️ dt 可分辨下限（2026-09-16）：
        #     速度编辑能把 dt 压到 ~1e-3 帧（甚至更低）。此时"比例 k"已无意义，
        #     而且缩放出来的 dt 会一起塌到 0 → 手柄在 (t,v) 平面里被挤成竖线。
        #     此时**只保方向、不动时间分量**（宁可 (t,v) 有折角，也不要数值塌陷）。
        if dt_src_len < DT_EPS:
            continue

        h = kp.handle_left if side == 'left' else kp.handle_right
        dt_new = dt_src_len * k
        if side == 'left':
            dt_new = -dt_new                      # 左侧为负（时间在 co 之前）

        # 相邻关键帧的时间（用于夹取，防跨帧）
        prev_t = next_t = None
        for other in fc.keyframe_points:
            ot = float(other.co[0])
            if ot < co_t - 1e-6:
                prev_t = ot if prev_t is None else max(prev_t, ot)
            elif ot > co_t + 1e-6:
                next_t = ot if next_t is None else min(next_t, ot)

        if side == 'left' and prev_t is not None:
            dt_new = max(dt_new, (prev_t - co_t))      # 不越过上一个关键帧
        if side == 'right' and next_t is not None:
            dt_new = min(dt_new, (next_t - co_t))      # 不越过下一个关键帧
        # 方向保护 + 可分辨下限：左侧 ≤ -DT_EPS，右侧 ≥ +DT_EPS
        # （原来是 ±1e-6，低于 Blender 的 dt 分辨率 → 手柄会塌成竖线）
        if side == 'left':
            dt_new = min(dt_new, -DT_EPS)
        else:
            dt_new = max(dt_new, DT_EPS)

        if side == 'left':
            kp.handle_left = (co_t + dt_new, float(h[1]))
        else:
            kp.handle_right = (co_t + dt_new, float(h[1]))


def _read_co_point(curves, frame):
    """读某帧控制点的【三维点】（= 三个轴的值分量）。"""
    v = [0.0, 0.0, 0.0]
    got = False
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        v[fc.array_index] = float(kp.co[1])
        got = True
    return mathutils.Vector(v) if got else None


def finish_linked_handle(action, obj, snapshot, frame, moved_side,
                         bone_name=None, weighted=True, zero_eps=_ARM_EPS):
    """★ P2.1（2026-09-16）：鼠标【直接拖手柄】路径的加权收尾。

    ------------------------------------------------------------------
    为什么需要它：插件里手柄有**两条写入路径**

      · 端点模态（选中端点按 G/R/S）→ `apply_endpoint_transform`　**已接加权**
      · 鼠标直接拖手柄（点小圆点 / 拖手柄线）→ 老代码 `update_linked_handle`
        只逐轴按 (t,v) 斜率写对侧的**值分量**，**没有加权**

    实测（`_gap2.py`；关键帧不共线 + 各轴手柄时间比例 λ 不同）：
        初始状态        3D 点线距 5.237
        老鼠标路径      3D 点线距 4.457   ← 几乎没修，用户看到的折角还在
        加权路径        3D 点线距 0.0000  ← 完全共线
    ⇒ 这条路在 λ 不一致时**修不动 3D 折角**（这就是覆盖缺口）。

    ------------------------------------------------------------------
    本函数在**老逻辑跑完之后**调用（此时 `fc.update()` 已执行、类型已恢复），
    把对侧手柄改成：
        ① 3D 方向 = 被拖侧的反向 → 消除 3D 折角
        ② 3D 长度 = 拖拽前的原始长度（取自 snapshot）→ 原生 ALIGNED「只旋转不缩放」
        ③ ~~时间分量按 k 缩放 → 消除 (t,v) 折角（复用 `_apply_weight`）~~
           ⚠️ 已于 2026-09-16（第十轮）**停用** —— 用户拍板 3D 视图优先、
              Graph Editor 不需要共线；且改 dt 会把**速度分布抹掉**而对 3D 零收益。
              详见 `_apply_weight` 的 docstring。

    ⚠️ 现在这个函数 **只做 ① ②** → 3D 共线 + 臂长守恒 + 速度分布一个数不动。

    ⚠️ 必须写在 `fc.update()` **之后**：Blender 的 ALIGNED 会在 update 时按它
       自己的 (t,v) 规则重算对侧，写在前面的值会被覆盖
       （与 `apply_endpoint_transform` 是同一个坑，2026-09-16 实测）。

    ⚠️ 只处理对侧是 `ALIGNED` 的情况：FREE 按原生语义不动、VECTOR 贴 co、
       AUTO/AUTO_CLAMPED 交给 Blender 重算 —— 与 `maintain_linked_handle` 一致。

    :param snapshot: `snapshot_endpoints()` 的结果（拖拽**开始时**记录）
    """
    curves = _position_curves(action, obj, bone_name)
    if not curves:
        return False
    f = float(frame)
    kp = _kp_of(curves, f)
    if kp is None:
        return False
    side = str(moved_side)
    opp_side = 'right' if side == 'left' else 'left'
    # ★★ 2026-09-16：改用【统一判据】`_link_mode`。
    #    以前这里写死 `opp_type != 'ALIGNED' → return`，于是
    #    **插件自己冻的 FREE**（速度编辑）在这条路上不联动，
    #    而端点模态路径同样不联动 → 用户看到"只能作用于一端 + 之后再拖跳变"。
    if _link_mode(kp, side) != 'link':
        return False
    co_p = _read_co_point(curves, f)
    moved_p = _read_handle_point(curves, f, side)
    if co_p is None or moved_p is None:
        return False
    # ⚠️ 对侧原始长度取自 snapshot：update() 之后 Blender 已按 (t,v) 规则改过它，
    #    读实时值是错的（长度会每帧漂移）。
    opp0 = _point_from(snapshot, f, 'hr' if opp_side == 'right' else 'hl')
    if opp0.length < _ARM_EPS:
        return False
    opp_len = (opp0 - co_p).length
    # ★★ 2026-09-17：闸门口径改为「视觉零」（由调用方按屏幕像素换算传入 `zero_eps`）。
    #    旧值 `_ARM_EPS`(1e-9 世界) 与空心圆判据（屏幕 6px）差 6 个数量级：
    #    用户把两侧都缩到关键帧点（长度 ~1e-3）时空心圆出现、一拖却触发封口
    #    ⇒ 对侧 ALIGNED 被永久改成 FREE（用户实测反馈）。
    #    对侧在【视觉上】本来就是零长度 ⇒ 没有共线形状要保护 ⇒ 不该封口、更不该改类型。
    if opp_len < zero_eps:
        return False
    maintain_linked_handle(curves, f, side, co_p, moved_p,
                           opp_len=opp_len, weighted=weighted,
                           zero_eps=zero_eps)
    return True


def restore_converted_types(action, obj, converted, bone_name=None):
    """把 `apply_endpoint_transform` 临时转成 FREE 的类型写回去（取消/结束时）。

    ⚠️ D1 的配套：端点模式为了让派生类型（AUTO/AUTO_CLAMPED/VECTOR）可写，
       会把它们临时转 FREE；不恢复的话用户的手柄类型就被永久改了。

    ★ 2026-09-17 配套：恢复类型时同时 `unmark_owned_free` ——
      否则"封口时登记、取消后类型已恢复"的陈旧条目会让
      用户手动设的 FREE 被误判成插件接管（误联动）。
    """
    if not converted:
        return
    curves = _position_curves(action, obj, bone_name)
    for (frame, axis), (lt, rt) in converted.items():
        fc = None
        for c in curves:
            if c.array_index == axis:
                fc = c
                break
        if fc is None:
            continue
        kp = keyframe_at(fc, float(frame))
        if kp is None:
            continue
        hl = kp.handle_left.copy()
        hr = kp.handle_right.copy()
        kp.handle_left_type = lt
        kp.handle_right_type = rt
        kp.handle_left = hl
        kp.handle_right = hr
        # ★ 2026-09-17 配套：类型恢复了 ⇒ 取消登记（防陈旧条目误联动）
        unmark_owned_free(kp, 'left')
        unmark_owned_free(kp, 'right')
    for fc in curves:
        fc.update()


def reapply_snapshot_handles(action, obj, snapshot, endpoints, bone_name=None):
    """把快照里的手柄值【在 update 之后】再写回去。

    ⚠️ 用途：取消/还原时（2026-09-16 实测）
       Blender 的 ALIGNED 约束会在 `fc.update()` 时按 (t,v) 规则重算对侧手柄，
       把 `restore_positions()` 刚写好的原始值改掉（实测偏差 0.0224）。
       所以还原后要再写一遍、且不再 update —— 与 apply 路径同一个技巧。
    """
    curves = _position_curves(action, obj, bone_name)
    if not curves or not endpoints:
        return False
    for fc in curves:
        fc.update()
    for (frame, side) in endpoints:
        f = float(frame)
        side = str(side)
        _set_handle_point(curves, f, side,
                          _point_from(snapshot, f, 'hl' if side == 'left' else 'hr'))
        opp = 'right' if side == 'left' else 'left'
        _set_handle_point(curves, f, opp,
                          _point_from(snapshot, f, 'hl' if opp == 'left' else 'hr'))
    return True


def apply_endpoint_transform(action, obj, snapshot, fn, endpoints, bone_name=None,
                             linked=True, weighted=True, zero_eps=_ARM_EPS,
                             time_scale=None):
    """只变换【选中的那些手柄端点】，并维护对侧手柄。

    ⚠️ 与 `apply_point_transform(only_handles=True)` 的关键区别：

      · 旧实现：对每一帧把 **hl 和 hr 都** 变换一遍
        → 用户旋转/移动一个端点，**对侧那个也跟着动**
        → 用户实测："S 旋转选中的端点，旋转的确实对向的端点" ❌

      · 本实现：只动 `endpoints` 里列出的 (frame, side)，
        其余（含对侧）按 `maintain_linked_handle` 的原生语义处理 ✅

    :param endpoints: [(frame, side), ...]
    """
    curves = _position_curves(action, obj, bone_name)
    if not curves or not endpoints:
        return False
    _reset_skip()

    # ★★ D1 修复（agent 实测）：派生/锁定类型下写入会被 Blender 吞掉。
    #
    # 实测（端点拖拽 1.0 单位后的位移比）：
    #     FREE     1.0000 ✓   ALIGNED 1.0000 ✓
    #     AUTO     0.0000 ✗   AUTO_CLAMPED 0.0000 ✗   VECTOR 0.0000 ✗
    #     ⇒ 默认工程（keyframe_insert 给的就是 AUTO_CLAMPED）**端点完全拖不动**
    #
    # 修法：**只对派生类型**临时转 FREE（`ALIGNED`/`FREE` 保持原样 ——
    #       它们本来就写得进去，且 ALIGNED 还要保留共线语义）。
    #       调用方通过返回的 `converted` 恢复（见 apply_endpoint_transform 的收尾）。
    global last_converted_types
    # ★★ 2026-09-16：改用两条路径共用的 `prepare_handles_for_drag`
    #    （按 Blender 原生语义：AUTO* → ALIGNED、VECTOR → FREE；**两侧都接管**）。
    #    旧实现只转【被拖侧】、且一律转 FREE，于是：
    #      · 对侧 AUTO_CLAMPED 被 Blender 重算 → 臂长突变（用户看到"跳"）
    #      · 对侧永远按 AUTO_CLAMPED 公式走 → 与插件要的共线无关（永久折角，dev 0.832）
    #    保留的契约：对侧 VECTOR 仍**不转**（用户显式"贴相邻关键帧"语义，E 组测试）。
    converted = prepare_handles_for_drag(action, obj, endpoints, bone_name,
                                         link_opposite=bool(linked))
    last_converted_types = dict(converted)   # 供调用方恢复
    for fc in curves:
        fc.update()

    for (frame, side) in endpoints:
        f = float(frame)
        side = str(side)
        co_p = _point_from(snapshot, f, 'co')
        hp = _point_from(snapshot, f, 'hl' if side == 'left' else 'hr')
        new_h = fn(f, hp)
        if new_h is None:
            continue
        if not is_writable(new_h):
            global last_skip_reason
            last_skip_reason = "数值超出可写入范围"
            continue
        _set_handle_point(curves, f, side, new_h)
    # ⚠️ 顺序关键（2026-09-16 实测）：先 update，再维护对侧。
    #    Blender 的 ALIGNED 约束是「(t,v) 平面共线」，会在 fc.update() 时
    #    把对侧手柄按它的规则**重算**（覆盖我们写的值）。
    #    而插件 3D 视图显示的是「值空间方向」——两者数学上不等价。
    #    所以对侧的修正必须写在 update **之后**，否则会被 Blender 覆盖。
    for fc in curves:
        fc.update()

    # ★★ D2 修复（agent 实测）：update 之后再写一遍【被拖侧】。
    #
    # 实测：**左手柄是 ALIGNED、右手柄非 FREE 时，`fc.update()` 会按左手柄
    #        重算右手柄的值** → 拖右端点的写入被覆盖（位移只生效 0.1258/1.0）。
    #       （5 组对照实测归纳，未追到 Blender 源码级规则。）
    # 修法：把被拖侧的值在 update 之后补写一次（对侧在下面维护，最后生效）。
    for (frame, side) in endpoints:
        f = float(frame)
        hp = _point_from(snapshot, f, 'hl' if str(side) == 'left' else 'hr')
        moved_p = fn(f, hp)
        if moved_p is None:
            continue
        _set_handle_point(curves, f, str(side), moved_p)

    # ★★ 端点模式 S 缩放【保速】（用户 2026-09-17）：
    #    `_set_handle_point` 只写【值分量】⇒ 速度 ×scale（实测 0.170833 → 0.25625）。
    #    这里把【时间分量】也 ×time_scale ⇒ 速度不变。
    #    ⚠️ 只在该端点【本来就有长度】(|dv_base| > eps) 时才缩：
    #       dv=0 的端点"保速"平凡成立（速度本来就是 0），再缩 dt 只会把
    #       曲线压平 —— 无意义副作用（用户拍板的语义是"速度不变"）。
    #    ⚠️ 基准时间从 snapshot 读（反复 _apply 不累乘）。
    if time_scale is not None:
        for (frame, side) in endpoints:
            f = float(frame)
            _sd = str(side)
            _co0 = _point_from(snapshot, f, 'co')
            _hp0 = _point_from(snapshot, f, 'hl' if _sd == 'left' else 'hr')
            if (_hp0 - _co0).length <= _ARM_EPS:
                continue                      # 无长度 ⇒ 无速度可保，别动 dt
            _scale_handle_time(curves, snapshot, f, _sd, time_scale)

    if linked:
        for (frame, side) in endpoints:
            f = float(frame)
            side = str(side)
            co_p = _point_from(snapshot, f, 'co')
            hp = _point_from(snapshot, f, 'hl' if side == 'left' else 'hr')
            moved_p = fn(f, hp)
            if moved_p is None:
                continue
            # ⚠️ 对侧的【原始长度】必须取自快照：
            #    update() 之后 Blender 已按 ALIGNED 改过它，读实时值是错的
            opp0 = _point_from(snapshot, f, 'hr' if side == 'left' else 'hl')
            opp_len = (opp0 - co_p).length
            # ★★ 2026-09-17：与 `finish_linked_handle` 用【同一个】「视觉零」口径。
            #    这里原本**没传** zero_eps ⇒ 沿用 `_ARM_EPS`(1e-9 世界)，
            #    与空心圆判据（屏幕 6px）差 6 个数量级 ⇒ 端点模态（G/R/S）
            #    路径下，用户把两侧缩到关键帧点后一拖，对侧 ALIGNED 被封口成 FREE。
            #    （鼠标直接拖手柄走 `finish_linked_handle`，那条上一轮已修，漏了本条。）
            maintain_linked_handle(curves, f, side, co_p, moved_p,
                                   opp_len=opp_len, weighted=weighted,
                                   zero_eps=zero_eps)
    return True


def apply_point_transform(action, obj, snapshot, fn, bone_name=None,
                          only_handles=False, time_scale=None):
    """把 snapshot 的每个路径点**及其两侧手柄**按 `fn(frame, vec) -> vec` 变换后写回。

    G/R/S 只是换了不同的 `fn`：
        G（平移）：v + delta
        R（旋转）：pivot + R·(v - pivot)
        S（缩放）：pivot + k·(v - pivot)

    ⚠️⚠️ **关键**：co、handle_left、handle_right 是**三个独立的点**，
       必须**各自**经过 fn 变换 —— 不能只变换 co、再把手柄平移同样的量。

       之前正是"变换 co + 平移手柄"，后果：
         · 单点旋转时 co 不变、手柄也不动 → **完全没反应**（用户反馈）
         · 多点旋转时手柄只平移不旋转 → **手柄方向不对**、形状被拉歪

       改成各自变换后，语义与 Blender 原生曲线编辑一致：
        **pivot 取选中点的中位点时，单个点旋转 = 它的手柄绕它自己转**
       （co 不动、手柄转 → 切线方向变 → 路径形状变）。这正是用户要的。

    ⚠️ 每次都从 snapshot 重算（不累加）：
        · 避免浮点累积误差
        · 「取消」只需 restore 一次
        · 模态里反复 update 也不会漂移

    `time_scale`（默认 None = 时间分量不动，即历史行为）：
        非 None 时，手柄的**时间分量**（dt）也 ×time_scale，用来**保速**。
        速度 = |dv / dt|；只缩 dv 不缩 dt ⇒ 速度 ×k。dt 同比例 ⇒ 速度不变。
        **只由 ScaleSession 的「单点缩放」传入**（见 modal_edit.ScaleSession._apply）：
            · 单点缩放时支点就是该点自己 ⇒ co 不动、手柄绕它缩
              ⇒ 手柄连「长度」带「时间跨度」等比缩，形状相似 ⇒ 速度恒定
            · 多点缩放时支点是中位点，各点位移不同 ⇒ 不缩 dt（保持原行为）
        端点模式（only_handles）不走这里（走 apply_endpoint_transform），不受影响。
    """
    curves = _position_curves(action, obj, bone_name)
    by_axis = {fc.array_index: fc for fc in curves}
    _reset_skip()

    for frame, per_axis in snapshot.items():
        # ★ 先组装【三个完整三维点】，再各自变换
        co_p = _point_from(snapshot, frame, 'co')
        hl_p = _point_from(snapshot, frame, 'hl')
        hr_p = _point_from(snapshot, frame, 'hr')
        new_co = fn(frame, co_p)
        new_hl = fn(frame, hl_p)
        new_hr = fn(frame, hr_p)
        if new_co is None or new_hl is None or new_hr is None:
            continue
        if not (is_writable(new_co) and is_writable(new_hl) and is_writable(new_hr)):
            # ⚠️ 不静默：记下原因，让状态栏能提示（见 is_writable 的 docstring）
            global last_skip_reason
            last_skip_reason = "数值超出可写入范围（移动/缩放幅度太大）"
            continue
        for axis, vals in per_axis.items():
            fc = by_axis.get(axis)
            if fc is None:
                continue
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            _co_t = float(kp.co[0])
            if not only_handles:
                kp.co = (_co_t, new_co[axis])
            if time_scale is None:
                kp.handle_left = (kp.handle_left[0], new_hl[axis])
                kp.handle_right = (kp.handle_right[0], new_hr[axis])
            else:
                # ★★ 保速：手柄的【时间分量】也 ×time_scale（用户 2026-09-17 拍板）
                #   速度 = |dv / dt|。只缩值分量(dv)、不缩 dt ⇒ 速度 ×k。
                #   让 dt 同比例 ⇒ 速度不变（= 在「值-时间」平面上等比缩放，形状相似）。
                #
                #   ⚠️ 时间分量必须从 **snapshot** 读，不能从 kp 读 ——
                #      模态里鼠标每动一次就 _apply 一次，从 kp 读会**累乘**（k^n）。
                #      snapshot 存的是进模态那一刻的原始值（见 snapshot_positions）。
                _hl_t0 = float(vals.get('hl_t', kp.handle_left[0]))
                _hr_t0 = float(vals.get('hr_t', kp.handle_right[0]))
                kp.handle_left = (_co_t - (_co_t - _hl_t0) * time_scale, new_hl[axis])
                kp.handle_right = (_co_t + (_hr_t0 - _co_t) * time_scale, new_hr[axis])
    for fc in curves:
        fc.update()
    return True


def rotation_fn(pivot, axis, angle):
    """绕 axis 轴、过 pivot、转 angle 弧度的变换函数（右手系）。"""
    axis = mathutils.Vector(axis)
    if axis.length < 1e-12:
        return None
    axis.normalize()
    rot = mathutils.Matrix.Rotation(angle, 3, axis)
    piv = mathutils.Vector(pivot)

    def fn(_frame, v):
        return piv + rot @ (v - piv)

    return fn


def scale_fn(pivot, factor):
    """以 pivot 为中心、按 factor 缩放的变换函数。"""
    piv = mathutils.Vector(pivot)

    def fn(_frame, v):
        return piv + (v - piv) * factor

    return fn


def scale_fn_masked(pivot, factor, mask):
    """同上，但只在 mask 为 1 的轴上缩放（0 = 该轴保持原样）。"""
    piv = mathutils.Vector(pivot)
    mx, my, mz = mask

    def fn(_frame, v):
        d = v - piv
        return mathutils.Vector((piv.x + d.x * (factor if mx else 1.0),
                                 piv.y + d.y * (factor if my else 1.0),
                                 piv.z + d.z * (factor if mz else 1.0)))

    return fn


# ===========================================================================
# 同比例手柄缩放（Handle Scale / UNIFORM）
#
# 用户拍板语义（2026-09-17）：拖 3D 手柄时，**手柄变长/变短，但关键帧处的
# 速度不变** —— 等价于 Graph Editor 里「以各自中心 + S 缩放」。
#
#   手柄(3D 视图里那根线) = (dv_x, dv_y, dv_z)     ← 值分量，插件只画这个
#   关键帧处速度           = |(dv_a / dt_a)|        ← 每轴：值分量 / 时间分量
#   同比例（dv、dt 同乘 k）⇒ 速度 = (k·|dv|)/(k·dt) = 原速度 ⇒ **不变** ✓
#
# ⚠️ 为什么 k 必须是「值分量 3D 模长比」而不是「逐轴的 dv_a新/dv_a旧」：
#    逐轴 k_a 在某个轴被拖到**过零**时会变负 / 除零 ⇒ dt 被钳到极小 ⇒ 速度爆炸
#    ⇒ 手柄"飞走 / 缩成一点锁死"（2026-09-17 实测踩坑，那条路已废弃）。
#    整体 k 对所有轴相同 ⇒ 手柄方向 ∝ dv 不变 ⇒ **始终与路径相切** ✓
#    且各轴 dt 相同时，**任意方向**拖动都精确保速（原型+真机双重验证）。
# ===========================================================================

UNIFORM_LEN_EPS = 1e-6      # |dv_base| 低于此值 ⇒ "缩放"无定义（手柄为零长）
UNIFORM_DT_FLOOR = 1e-4     # 时间分量下限（帧），避免 dt → 0 使手柄不可抓

# ★★★ 2026-09-17（用户实测 bug）：**基线手柄太短 ⇒ 不启用同比例**。
#
#   同比例系数 k = |dv_new| / |dv_base| ⇒ **基线越短 k 越大**
#   ⇒ `dt = dt_base · k`（见 scale_handle_uniform）**爆掉**。
#
#   实测（从磁盘干净状态模拟"拖出端点手柄、松手、再拖"）：
#       L0 = 0.0242 → 拖到 3.96 → k = 164.6 → **dt = 1646.3**
#       L0 = 0.05   → 拖到 3.96 → k =  80.2 → **dt =  802.0**
#   用户实测到的 **dt = 1634.574** 正是同一条路（L0 ≈ 0.024）。
#
#   dt 过大（> 段跨度 span）后贝塞尔在该段饱和 ⇒ **拖手柄路径几乎不动**
#   （用户："没有预期交互"），且手柄方向与路径偏离 10°+（"不相切"），
#   并且**永久锁死**（基线 dt 已巨大，k 的语义失效）。
#
#   ⇒ 基线短于此值就退回"只写 dv、dt 不变"（与"端点第一次拖出"的既定行为
#     一致：**极短手柄的"保速"没有意义** —— 它本来就是个刚长出来的柄）。
UNIFORM_LEN_MIN = 1.0

# ★ 安全上限（仅防病态值，**不是**手感限制）
#
# 2026-09-17 用户拍板：**取消拉长上限** —— 手柄线要一直跟手变长（纯交互需求）。
#
# 为什么放开是安全的（实测依据，见 .docs / 提交说明）：
#   · dt > span 后曲线【完全饱和】—— 扫 dt/span 从 0.33 到 1.67：
#     曲线峰值 / 速度剖面 / 关键帧速度在 dt=span 之后**一模一样，一位不变**。
#     再拖更长只是"手柄线变长"，对动画本身零影响。
#   · 插件**本来就允许** s = dt/span 越界 —— `td.read_s` 不钳制，
#     `s_to_d` 注释实测记录「Graph Editor 里拖手柄 → s=7.69」。
#   ⇒ UNIFORM 模式的 k_max 是人为加的，比 Blender 的实际边界更保守。
#
# 下面这个值只是防"极端值把数值搞坏"，用户正常拖动到不了（要拖 200 倍）。
UNIFORM_K_SAFETY = 200.0


def handle_scale_k(dv_base, dv_new, dt_base, span):
    """【唯一实现】算同比例缩放的系数 k。两条拖拽路径共用。

    参数（都是**相对 keyframe.co 的偏移**）：
        dv_base : 按下时各轴的值分量   (dv_x, dv_y, dv_z)  —— **序列**
        dv_new  : 拖动后各轴的值分量                      —— **序列**
        dt_base : 按下时各轴的时间分量                     —— **序列**
        span    : ⚠️ **已废弃、不再使用**（只为兼容历史签名而保留）。
                  2026-09-17 用户拍板取消了"拉长上限"，k_max 已改成常量
                  `UNIFORM_K_SAFETY`（见下）。保留形参是为了不动已有的
                  位置传参调用点。

    返回 `(k, k_raw, k_max)`；当 |dv_base| ≈ 0 时返回 None（缩放无定义）。

    ★ 上限**钳在 k 上**，不是钳 dt —— 钳 dt 会破坏同比例 ⇒ 速度就变了。
    ★★ 2026-09-18（盲审 S3）：**本 docstring 原来写着
       `k_max = span / max|dt_base|`，那是已被推翻的旧行为** ——
       实现里 k_max 是常量 `UNIFORM_K_SAFETY`（用户 2026-09-17 拍板
       "取消拉长上限"：dt > span 后曲线完全饱和，拖更长只让手柄线变长、
       对动画零影响，而用户要"手柄一直跟手变长"）。
       文档与实现冲突会误导后来者，故在此更正。

    ⚠️ 接口约定（盲审 S4）：本函数收**序列**（内部 `list()` 后逐元素处理），
       而相邻的 `scale_handle_uniform` 收**标量**（`float()`）。
       两者名字相近但口径不同 —— 调用时别混。
       真正的批量逻辑在调用方（`interaction._apply_one_handle_offset`）的循环里。
    """
    dv_base = list(dv_base or ())
    dv_new = list(dv_new or ())
    dt_base = list(dt_base or ())
    if not dv_base or not dv_new:
        return None
    L0 = math.sqrt(sum(float(v) * float(v) for v in dv_base))
    # ★★★ 2026-09-17：基线太短 ⇒ 退回"不同比例"（详见 UNIFORM_LEN_MIN 的说明）。
    #    这同时覆盖了原来的 `L0 <= UNIFORM_LEN_EPS`（零长）情形 ——
    #    零长是 L0=0，必然 ≤ UNIFORM_LEN_MIN。
    if L0 <= UNIFORM_LEN_MIN:
        return None
    L1 = math.sqrt(sum(float(v) * float(v) for v in dv_new))
    k_raw = L1 / L0
    dt_max = max((abs(float(v)) for v in dt_base), default=0.0)
    # ★★ 2026-09-17 用户拍板：**取消拉长上限**（原为 span/max|dt_base|）。
    #    原因：那是**交互限制**，不是数学必需 —— dt > span 后曲线完全饱和，
    #    拖更长只让手柄线变长、对动画零影响。用户明确要"手柄一直跟手变长"。
    k_max = UNIFORM_K_SAFETY
    k = min(k_raw, k_max)
    # 保底：dt 不得小于可分辨下限（否则手柄缩成一点、再也抓不回来）
    if dt_max > UNIFORM_LEN_EPS:
        k = max(k, UNIFORM_DT_FLOOR / dt_max)
    return (k, k_raw, k_max)


def scale_handle_uniform(keyframe, side, dv_base_a, dt_base_a,
                         dv_new_a, k, k_raw, span):
    """【唯一实现】把同比例缩放写进一条曲线的 keyframe。

    · 值分量：`dv = dv_new · (k / k_raw)`
        未触上限时 k == k_raw ⇒ dv = dv_new（鼠标直接控制，自由拖动）
        触上限时  k <  k_raw ⇒ 按 k/k_raw **等比缩回**（保方向、保速度）
    · 时间分量：`dt = dt_base · k`
        ★ 2026-09-17：**不再钳到 span** —— 用户要手柄一直跟手变长；
          dt > span 时曲线饱和（形状不再变），所以放开是安全的。
          只保留 [UNIFORM_DT_FLOOR, +∞) 的下限，避免手柄缩成一点抓不回来。

    ⚠️ 参数都是**相对 co 的偏移**（不是绝对坐标）—— 调用方从按下时的
       `_session.handle_start_values` 取基线，绝不用"当前值"，否则会
       重复缩放导致指数增长（2026-09-17「手柄飞走」的根因）。

    参数口径（⚠️ 盲审 S4：本函数收**标量**，别和上方的 `handle_scale_k` 混）：
        dv_base_a / dt_base_a / dv_new_a : **单个轴**的分量（float）
        k / k_raw                        : 来自 `handle_scale_k`
        span                             : ⚠️ **已废弃、不再使用**
                                           （2026-09-17 取消 dt ≤ span 钳制）

    返回 `(dv_written, dt_written)`，供测试断言。
    """
    ratio = (float(k) / float(k_raw)) if k_raw > 1e-12 else 1.0
    dv = float(dv_new_a) * ratio
    dt = float(dt_base_a) * float(k)
    # ★★ 2026-09-17：**去掉了 `dt ≤ span` 的钳制**（原来在这里）。
    #    它只钳 dt 不钳 dv ⇒ 会破坏同比例 ⇒ 速度就变了（实测 0.17 → 0.64）。
    #    dt > span 是安全的：曲线在超出后完全饱和，形状/速度剖面都不再变。
    if abs(dt) < UNIFORM_DT_FLOOR:
        dt = math.copysign(UNIFORM_DT_FLOOR, dt if dt != 0.0 else 1.0)
    co_t = float(keyframe.co[0])
    co_v = float(keyframe.co[1])
    if side == 'left':
        keyframe.handle_left = (co_t + dt, co_v + dv)
    else:
        keyframe.handle_right = (co_t + dt, co_v + dv)
    return (dv, dt)
