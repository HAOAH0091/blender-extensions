# -*- coding: utf-8 -*-
"""关键验证：改 handle[0] 后，【轨迹的几何形状】会不会变？

直线路径下，轨迹永远是那条直线（显然不变）。
但曲线路径下呢？—— 这决定方案是否真的满足"不改路径形状"的约束。

度量：轨迹 = 逐帧位置点集。用「改后采样点到原轨迹折线的最近距离」的最大值。
"""
import sys, os, json, types, importlib
HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)                       # ⚠️ 必须包上下文：cache.py 有相对导入
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    _pkg = types.ModuleType(PKG)
    _pkg.__path__ = [ADDON_DIR]
    _pkg.__package__ = PKG
    sys.modules[PKG] = _pkg

import bpy, mathutils
td = importlib.import_module(PKG + ".time_domain")


def setup(locations, frames):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, frames[-1]
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = "TestObj"
    for f, loc in zip(frames, locations):
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    act = o.animation_data.action
    for fc in td._collect_position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()
    return o, act


def make_uniform(o, act):
    """所有段设为共线（匀速）基线"""
    for fc in td._collect_position_curves(act, o, None):
        pts = list(fc.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0 = k0.co[0], k0.co[1]
            t1, v1 = k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()


def trajectory(o, act, n=400):
    """密集采样轨迹点（帧 -> 3D 位置）"""
    by = {}
    for fc in td._collect_position_curves(act, o, None):
        by[fc.array_index] = fc
    if len(by) < 3:
        return []
    f0 = by[0].keyframe_points[0].co[0]
    f1 = by[0].keyframe_points[-1].co[0]
    pts = []
    for i in range(n):
        f = f0 + (f1 - f0) * i / (n - 1)
        pts.append(mathutils.Vector((by[0].evaluate(f), by[1].evaluate(f), by[2].evaluate(f))))
    return pts


def point_to_polyline_dist(p, poly):
    best = 1e18
    for i in range(len(poly) - 1):
        a, b = poly[i], poly[i + 1]
        ab = b - a
        L2 = ab.length_squared
        if L2 < 1e-18:
            d = (p - a).length
        else:
            t = max(0.0, min(1.0, (p - a).dot(ab) / L2))
            d = (p - (a + ab * t)).length
        if d < best:
            best = d
    return best


def hausdorff_like(A, B):
    """A 中每个点到折线 B 的最近距离，取最大（单向）"""
    return max(point_to_polyline_dist(p, B) for p in A)


res = {}
FRAMES = [1, 14, 27, 40]

CASES = {
    "straight":     [(0, 0, 0), (4, 0, 0), (8, 0, 0), (12, 0, 0)],
    "curved_2d":    [(0, 0, 0), (4, 3, 0), (8, -2, 0), (12, 1, 0)],
    "curved_3d":    [(0, 0, 0), (4, 3, 1), (8, -2, 4), (12, 1, -1)],
}

for name, locs in CASES.items():
    o, act = setup(locs, FRAMES)
    make_uniform(o, act)
    base = trajectory(o, act, 400)

    # 改 f14 右侧（三轴同步）
    kf_map, span = td.resolve_target(act, o, 14, 'right')
    td.write_s(kf_map, 'right', 0.02, span)   # 最疏
    for fc in td._collect_position_curves(act, o, None):
        fc.update()
    after = trajectory(o, act, 400)

    d_forward = hausdorff_like(after, base)
    d_backward = hausdorff_like(base, after)

    # 同时：关键帧位置是否不动
    kf_ok = True
    for fc in td._collect_position_curves(act, o, None):
        for kp in fc.keyframe_points:
            for f, loc in zip(FRAMES, locs):
                if abs(kp.co[0] - f) < 0.5:
                    if abs(kp.co[1] - loc[fc.array_index]) > 1e-6:
                        kf_ok = False

    res[name] = {
        "trajectory_dev_forward": round(d_forward, 8),
        "trajectory_dev_backward": round(d_backward, 8),
        "keyframes_unmoved": kf_ok,
    }

json.dump(res, open(os.path.join(HERE, "_shape.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("WROTE_SHAPE_JSON")
