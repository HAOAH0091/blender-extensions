# -*- coding: utf-8 -*-
"""同比例手柄缩放（Handle Scale / UNIFORM）回归。

用户拍板语义（2026-09-17）
--------------------------
拖 3D 手柄时：**手柄变长/变短，而关键帧处的速度不变**
（= Graph Editor 里「以各自中心 + S 缩放」的等价物）。

    手柄(3D) = (dv_x, dv_y, dv_z)      ← 值分量，插件只画这个
    关键帧处速度 = |(dv_a / dt_a)|       ← 每轴：值分量 / 时间分量
    同比例（dv、dt 同乘 k）⇒ 速度 = (k·|dv|)/(k·dt) = 原速度 ⇒ 不变 ✓

⚠️ k 必须用「值分量 3D 模长比」（**整体 k**），不是逐轴的 dv_a新/dv_a旧：
   逐轴 k_a 在某个轴被拖到过零时会变负 / 除零 ⇒ dt 被钳到极小 ⇒ 速度爆炸
   ⇒ 手柄「飞走 / 缩成一点锁死」（2026-09-17 实测踩坑，那条路已废弃）。
   整体 k 对所有轴相同 ⇒ 手柄方向 ∝ dv 不变 ⇒ **始终与路径相切** ✓

本测试钉住的坑（按踩坑时间序）
------------------------------
 1. **发散**：写入必须用「按下时的基线」做绝对定位；用"当前值 × k"会每帧再乘一次
    ⇒ dt 指数增长（10→10.5→11.55→13.28→15.94→19.92→25.9）⇒ 手柄飞走。
    ⇒ A3 用**连续 12 次 MOUSEMOVE** 钉住（只测单次是"测试台骗自己"）。
 2. **上限**：dt > span 会让贝塞尔在时间轴上折返（曲线倒退、速度出现奇点）。
    ⇒ 上限必须钳在 **k** 上（钳 dt 会破坏同比例 ⇒ 速度就变了）。
 3. **退化**：|dv_base| ≈ 0 时"缩放"无定义 ⇒ 必须退化为原行为，不得除零爆炸。
 4. **端点段**：span=None（首帧 left / 末帧 right）⇒ 不做时间缩放。

配套原型（交互与几何保真验证）：
  IDES/workspace/_rtmp_handle_scale_proto.html
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import (transform_domain as xf, time_domain as td,
                                interaction as it)
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_handle_scale_result.json")
steps = []
FR = 25.0
SPAN_R = 30.0

# 建关键帧用的位置（1/25/55），中间帧非极值 ⇒ dv 三轴都非零
KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


# 轻量 shim：把真实方法挂上去，走**真实函数体**（bpy Operator 不能直接实例化）
class Shim(object):
    pass


for _m in ("prepare_handles_for_edit", "update_linked_handle",
           "finish_linked_handle", "_apply_one_handle_offset"):
    setattr(Shim, _m, getattr(it.RTMP_OT_PathPointDrag, _m))
Shim.apply_handle_point_offset = it.RTMP_OT_PathPointDrag.apply_handle_point_offset
shim = Shim()


def prefs():
    return bpy.context.preferences.addons["RealTimeMotionPath"].preferences


def build(name="_HS"):
    sc = bpy.context.scene
    pr = bpy.data.objects.get(name)
    if pr:
        bpy.data.objects.remove(pr, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    pr = bpy.context.active_object
    pr.name = name
    for f, loc in KFS:
        sc.frame_set(f)
        pr.location = loc
        pr.keyframe_insert("location", frame=f)
    sc.frame_set(int(FR))
    bpy.context.view_layer.objects.active = pr
    return pr, pr.animation_data.action


def kfmap(act, pr, frame=FR):
    km = {}
    for fc in xf._position_curves(act, pr, None):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - frame) < 1e-3:
                km[fc.array_index] = kp
                break
    return km


def read(act, pr, frame=FR):
    """读该帧右侧手柄的 (dt 各轴, 3D 手柄长, 关键帧处速度)。"""
    km = kfmap(act, pr, frame)
    dv = [float(km[a].handle_right[1] - km[a].co[1]) for a in sorted(km)]
    dt = [float(km[a].handle_right[0] - km[a].co[0]) for a in sorted(km)]
    L = math.sqrt(sum(v * v for v in dv))
    T = [(dv[a] / dt[a] if abs(dt[a]) > 1e-9 else 0.0) for a in range(len(dt))]
    spd = math.sqrt(sum(v * v for v in T))
    # 相切：手柄方向 ∝ dv，路径切线 ∝ dv/dt
    lt = math.sqrt(sum(v * v for v in T))
    if L > 1e-9 and lt > 1e-9:
        dot = sum(dv[i] * T[i] for i in range(len(dv))) / (L * lt)
        ang = math.degrees(math.acos(max(-1.0, min(1.0, dot))))
        ang = min(ang, 180.0 - ang)
    else:
        ang = 0.0
    return {"dv": dv, "dt": dt, "len": L, "speed": spd, "tangent": ang,
            "types": [km[a].handle_right_type for a in sorted(km)]}


def opp_len_dt(act, pr, frame=FR):
    km = kfmap(act, pr, frame)
    dv = [float(km[a].handle_left[1] - km[a].co[1]) for a in sorted(km)]
    dt = [float(km[a].co[0] - km[a].handle_left[0]) for a in sorted(km)]
    L = math.sqrt(sum(v * v for v in dv))
    T = [(dv[a] / dt[a] if abs(dt[a]) > 1e-9 else 0.0) for a in range(len(dt))]
    return L, math.sqrt(sum(v * v for v in T))


def run(mode, steps_n=12, delta=0.15, use_path1=False, target_frame=FR,
        target_side='right', radial=False):
    prefs().handle_scale_mode = mode
    pr, act = build()
    _session.handle_start_values.clear()
    _session.active_frame_number = target_frame
    _session.active_handle_direction = target_side
    hp = {'frame': target_frame, 'side': target_side}
    # ★★ 基准必须在【拖动之前】读 —— 拖动之后读到的已经是改过的值
    #    （这正是首版测试写成 0.185954 的原因：拿"CLASSIC 改过后"的值当基准）
    pre = read(act, pr, target_frame)
    # 径向：偏移沿 dv₀ 的方向（⇒ dv 与 dv₀ 保持同向 ⇒ 严格同比例）
    if radial:
        _l = math.sqrt(sum(v * v for v in pre["dv"])) or 1.0
        _dir = [v / _l for v in pre["dv"]]
    else:
        _dir = [1.0, 0.4, 0.2]
    seq = []
    for i in range(1, steps_n + 1):
        off = mathutils.Vector((delta * i * _dir[0], delta * i * _dir[1],
                               delta * i * _dir[2]))
        if use_path1:
            shim._apply_one_handle_offset(
                pr, act, target_frame, target_side, off, 1.0, None,
                mathutils.Matrix.Identity(3), context=bpy.context)
        else:
            shim.apply_handle_point_offset(bpy.context, off, hp)
        seq.append(read(act, pr, target_frame))
    res = {"pre": pre, "seq": seq, "act": act, "pr": pr, "hp": hp}
    return res


def cleanup(pr):
    # ⚠️ 容错：下一个 run() 会 remove 同名对象 ⇒ 旧引用可能已失效
    try:
        if pr and pr.name in bpy.data.objects:
            bpy.data.objects.remove(pr, do_unlink=True)
    except Exception:
        pass


def main():
    p = prefs()
    base_mode = getattr(p, "handle_scale_mode", None)

    # ---------- B 组：静态契约 ----------
    # ★ 2026-09-17 用户拍板：默认改成 UNIFORM（拖手柄变长/变短、关键帧处速度不变）
    step("B1 偏好字段 handle_scale_mode 存在，默认 UNIFORM",
         base_mode == 'UNIFORM', "实际=%r" % (base_mode,))
    step("B2 transform_domain 有唯一实现 handle_scale_k / scale_handle_uniform",
         hasattr(xf, "handle_scale_k") and hasattr(xf, "scale_handle_uniform"))
    step("B3 interaction 有唯一预演 _uniform_plan / 写入 _write_uniform",
         hasattr(it, "_uniform_plan") and hasattr(it, "_write_uniform"))
    _enum_ok, _detail = True, ""
    try:
        for _v in ('UNIFORM', 'CLASSIC'):
            p.handle_scale_mode = _v
            if p.handle_scale_mode != _v:
                _enum_ok, _detail = False, "设 %s 读回 %s" % (_v, p.handle_scale_mode)
    except Exception as _e:                                  # noqa: BLE001
        _enum_ok, _detail = False, repr(_e)[:120]
    step("B4 枚举可用：UNIFORM / CLASSIC 都能设且读回", _enum_ok, _detail)

    try:
        # ---------- A 组：行为 ----------
        # 基准：从 CLASSIC 起步取"原始速度"
        r0 = run('CLASSIC', steps_n=1, delta=0.15)
        base_speed = r0["pre"]["speed"]          # ★ 拖动【前】的原始速度
        base_len = r0["pre"]["len"]
        cleanup(r0["pr"])

        # A1/A2：UNIFORM 下单次拖动 —— 速度不变、手柄变长
        rU = run('UNIFORM', steps_n=1, delta=0.15)
        s1 = rU["seq"][0]
        step("A1 ★★★ 同比例：关键帧处速度【不变】",
             abs(s1["speed"] - base_speed) < 1e-4,
             "原始=%.6f 拖后=%.6f" % (base_speed, s1["speed"]))
        step("A2 同比例：手柄确实变长（跟手）",
             s1["len"] > base_len * 1.001,
             "原始=%.4f 拖后=%.4f" % (base_len, s1["len"]))
        cleanup(rU["pr"])

        # A3：★ 连续 12 次不得发散（上一版"飞走"的真实场景）
        _n3, _d3 = 12, 0.15                 # ⚠️ 别写成 run() 的参数名（作用域不同）
        rC = run('UNIFORM', steps_n=_n3, delta=_d3)
        dts = [s["dt"][0] for s in rC["seq"]]
        spds = [s["speed"] for s in rC["seq"]]
        # ★★★ 判据必须比对【解析期望值】，不能只查"比值恒定 / 单调有界"：
        #    · 只查"单调 + 有界" ⇒ 会被**上限钳制**骗过（发散到 span 被钳住后
        #      仍然"单调且有界"）。
        #    · 只查"dt/|dv| 恒定" ⇒ 会被**自洽的错误**骗过：若 k 与 dv 基于同一个
        #      （错误的）dv_new，比值恒等于 dt0/|dv0|，看起来完全正常，而真正的
        #      危害是**累积放大**（手柄越拖越长、不跟手）。
        #    ⇒ 直接算：dv_期望 = dv0 + 鼠标累积位移；dt_期望 = dt0 · |dv_期望|/|dv0|
        _dv0, _dt0 = rC["pre"]["dv"], rC["pre"]["dt"]
        _l0 = math.sqrt(sum(v * v for v in _dv0))
        _off_last = [_d3 * _n3, _d3 * _n3 * 0.4, _d3 * _n3 * 0.2]
        _dv_exp = [_dv0[a] + _off_last[a] for a in range(len(_dv0))]
        _k_exp = (math.sqrt(sum(v * v for v in _dv_exp)) / _l0) if _l0 > 1e-9 else 1.0
        _dt_exp = _dt0[0] * _k_exp
        _dv_now = rC["seq"][-1]["dv"]
        _dv_dev = max(abs(_dv_now[a] - _dv_exp[a]) for a in range(len(_dv_exp)))
        step("A3 ★★★ 连续 12 次 MOUSEMOVE：跟手（|dv| 不被累积放大）+ 同比例 + 不发散",
             _dv_dev < 1e-3 and abs(dts[-1] - _dt_exp) < 1e-2
             and dts[-1] <= SPAN_R + 1e-3,
             "dv 偏差=%.2e | dt 实测=%.4f 期望=%.4f" % (_dv_dev, dts[-1], _dt_exp))
        step("A4 ★★ 连续拖动全程：速度始终不变",
             all(abs(s - base_speed) < 1e-4 for s in spds),
             "速度首尾=%.6f/%.6f" % (spds[0], spds[-1]))
        step("A5 ★★ 全程与路径相切（手柄方向 ∝ dv）",
             all(s["tangent"] < 0.5 for s in rC["seq"]),
             "最大夹角=%.3f°" % max(s["tangent"] for s in rC["seq"]))
        L0, S0 = opp_len_dt(rC["act"], rC["pr"])
        step("A6 对侧联动后速度也不变（不只是被拖侧）",
             abs(S0 - base_speed) < 1e-3, "对侧速度=%.6f" % S0)
        cleanup(rC["pr"])

        # A7/A8：★ 2026-09-17 用户拍板【取消拉长上限】——
        #   手柄线要一直跟手变长（纯交互需求）；dt 允许超过 span。
        #   安全性依据：dt > span 后曲线**饱和**（A15 用实测曲线钉住）。
        rM = run('UNIFORM', steps_n=30, delta=0.5)
        dtsM = [s["dt"][0] for s in rM["seq"]]
        step("A7 ★★★ 长拖：手柄一直跟手（dt 单调增、不被 span 卡住）",
             all(dtsM[i] <= dtsM[i + 1] + 1e-6 for i in range(len(dtsM) - 1))
             and dtsM[-1] > SPAN_R * 1.5,
             "dt=%s span=%.1f" % ([round(d, 2) for d in dtsM[::6]], SPAN_R))
        step("A8 ★★★ 长拖全程：速度仍不变（保速，且不因放开上限而破）",
             all(abs(s["speed"] - base_speed) < 1e-4 for s in rM["seq"]),
             "速度集合=%s" % sorted(set(round(s["speed"], 6) for s in rM["seq"]))[:3])
        cleanup(rM["pr"])

        # A15：★★★ 放开上限的【安全性依据】（2026-09-17 用户拍板取消上限）
        #   · 纯径向拖动（偏移 ∝ dv₀ 方向）⇒ 曲线**完全饱和**：
        #     dt 从 1.4×span 涨到 9×span，曲线值一位不变（实测变化量 0.000000000）
        #   · 斜向拖动（真实场景）⇒ 变化量**递减收敛**（0.142→0.043→0.024→0.015），有界
        #   ⇒ 结论：拖更长只是"手柄线变长"，曲线不会发散/爆掉。
        def _curve(r):
            return [round(fc.evaluate(40.0), 6)
                    for fc in xf._position_curves(r["act"], r["pr"], None)]

        def _maxdt(r):
            return max(abs(v) for v in r["seq"][-1]["dt"])

        # ⚠️ 每次 run() 都用同一个对象名 ⇒ 必须【先取值、再 cleanup】，否则引用失效
        _r3 = run('UNIFORM', steps_n=3, delta=1.8, radial=True)
        _c3, _dt3 = _curve(_r3), _maxdt(_r3)
        cleanup(_r3["pr"])
        _r10 = run('UNIFORM', steps_n=10, delta=1.8, radial=True)
        _c10, _dt10 = _curve(_r10), _maxdt(_r10)
        cleanup(_r10["pr"])
        step("A15a ★★★ 径向拖：dt 远超 span（%.1f→%.1f）⇒ 曲线完全饱和"
             % (_dt3, _dt10),
             _dt3 > SPAN_R and _dt10 > SPAN_R * 3
             and all(abs(a - b) < 1e-9 for a, b in zip(_c3, _c10)),
             "曲线 %s / %s" % (_c3, _c10))

        # 斜向：变化量递减收敛（不发散）
        _seq_cv = []
        for _n in (12, 18, 30):
            _rr = run('UNIFORM', steps_n=_n, delta=0.5)
            _seq_cv.append(_curve(_rr))
            cleanup(_rr["pr"])
        _d1 = max(abs(a - b) for a, b in zip(_seq_cv[0], _seq_cv[1]))
        _d2 = max(abs(a - b) for a, b in zip(_seq_cv[1], _seq_cv[2]))
        step("A15b ★★ 斜向拖：曲线变化量收敛（不发散）",
             _d2 <= _d1 + 1e-6,
             "变化量 %.4f → %.4f（递减）" % (_d1, _d2))

        # A9：CLASSIC 对照 —— 必须【会】改速度（证明两模式真的不同）
        rClassic = run('CLASSIC', steps_n=12, delta=0.15)
        cSpd = rClassic["seq"][-1]["speed"]
        step("A9 对照：CLASSIC 拖手柄【会】改变关键帧处速度",
             abs(cSpd - base_speed) > 1e-3,
             "基准=%.6f 经典拖后=%.6f" % (base_speed, cSpd))
        cleanup(rClassic["pr"])

        # A10：多端点路径（_apply_one_handle_offset）同样成立
        rP1 = run('UNIFORM', steps_n=8, delta=0.2, use_path1=True)
        _sp = [s["speed"] for s in rP1["seq"]]
        step("A10 ★★ 多端点路径（_apply_one_handle_offset）速度也不变",
             all(abs(s - base_speed) < 1e-4 for s in _sp),
             "首尾=%.6f/%.6f" % (_sp[0], _sp[-1]))
        cleanup(rP1["pr"])

        # A11：端点段（span=None）—— ★ 注意：这一条与"取消拉长上限"无关，
        #       它测的是【span 拿不到时】不做时间缩放（退化为原行为）。
        #       端点手柄若能拿到 span（内侧），走的是 UNIFORM 正常路径。
        rE = run('UNIFORM', steps_n=3, delta=0.3, target_frame=1.0,
                 target_side='right')
        kmE = kfmap(rE["act"], rE["pr"], 1.0)
        dtE = [float(kmE[a].handle_right[0] - kmE[a].co[0]) for a in sorted(kmE)]
        step("A11 端点段（span=None）：时间分量保持原值",
             all(abs(v - 8.0) < 1e-3 for v in dtE),
             "dt=%s（应为 8.0）" % [round(v, 3) for v in dtE])
        cleanup(rE["pr"])

        # A12：退化 —— |dv_base| ≈ 0 不得除零爆炸
        rZ = run('UNIFORM', steps_n=4, delta=0.3)
        kmZ = kfmap(rZ["act"], rZ["pr"])
        for a in sorted(kmZ):
            kmZ[a].handle_right = (kmZ[a].co[0] + 10.0, kmZ[a].co[1])  # dv = 0
        for fc in xf._position_curves(rZ["act"], rZ["pr"], None):
            fc.update()
        _session.handle_start_values.clear()
        _session.active_frame_number = FR
        _session.active_handle_direction = 'right'
        okZ, detZ = True, []
        for i in range(1, 5):
            try:
                shim.apply_handle_point_offset(
                    bpy.context,
                    mathutils.Vector((0.3 * i, 0.12 * i, 0.06 * i)),
                    {'frame': FR, 'side': 'right'})
            except Exception as e:                       # noqa: BLE001
                okZ, detZ = False, repr(e)[:120]
                break
            _r = read(rZ["act"], rZ["pr"])
            detZ.append(round(_r["dt"][0], 3))
            if not all(math.isfinite(v) for v in _r["dt"]):
                okZ = False
        step("A12 退化：|dv_base|≈0 不除零、不爆炸（有限且单调）",
             okZ and all(math.isfinite(v) for v in detZ),
             "dt=%s %s" % (detZ, detZ if not okZ else ""))
        cleanup(rZ["pr"])

        # A13：静态契约 —— ★ 拉长上限已取消（2026-09-17 用户拍板）
        #      原为 k_max = span/max|dt_base|；现在 k = min(k_raw, UNIFORM_K_SAFETY)
        _ks = xf.handle_scale_k([1.7, 0.0, 0.0], [8.5, 0.0, 0.0],
                                [10.0, 10.0, 10.0], 30.0)
        step("A13 静态契约：取消拉长上限 ⇒ k = k_raw（不再被 span 钳）",
             _ks is not None and abs(_ks[0] - 5.0) < 1e-6
             and abs(_ks[1] - 5.0) < 1e-6,
             "k_raw=%.4f k=%.4f k_max=%.1f" % (_ks[1], _ks[0], _ks[2])
             if _ks else "None")
        _ks0 = xf.handle_scale_k([0.0, 0.0, 0.0], [1.0, 0.0, 0.0],
                                 [10.0, 10.0, 10.0], 30.0)
        step("A14 静态契约：|dv_base|≈0 ⇒ 返回 None（退化，不除零）",
             _ks0 is None, "返回=%r" % (_ks0,))

    except Exception:
        step("EXCEPTION", False, traceback.format_exc()[-600:])
    finally:
        try:
            p.handle_scale_mode = 'UNIFORM'           # 复位到默认值，别污染后续测试
        except Exception:
            pass
        flush()


main()
print("[handle_scale] %s | total=%d fails=%d"
      % ("ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
         len(steps), sum(1 for s in steps if not s["ok"])))
for s in steps:
    if not s["ok"]:
        print("  FAIL:", s["name"], "|", s["detail"][:200])
