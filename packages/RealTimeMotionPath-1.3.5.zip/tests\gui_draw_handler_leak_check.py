# -*- coding: utf-8 -*-
"""绘制回调泄漏回归 —— 用户 2026-09-17 实测"开关插件开关后绘制残留"。

症状
----
    红色运动路径上出现**黑色长直线残留**（旧回调用旧数据又画一遍），
    且关掉开关也消不掉。

真因（已诊断出确凿数据）
------------------------
`unregister()` **只撤了 overlay，漏了运动路径的绘制回调**
（`drawing.detach_render_callback()` 没被调用）。

    draw_handler 一旦注册，句柄**只存**在 `_session.render_callback_id` 里。
    不 detach ⇒ 回调仍在 C 层注册表里运行，且闭包引用着**旧模块**
    ⇒ GC 也收不走 ⇒ 新模块再注册一个
    ⇒ **两个回调同时绘制** ⇒ 残留。

诊断时的实测数据（用户当前会话）：
    3 个 MotionPathSession 存活，其中 **2 个**持有非 None 的 render_callback_id

修法（三层）
------------
 ① `unregister()` 里补 `detach_render_callback()`（**主修**）
 ② `detach_render_callback()` 对失效句柄容错（`try/except`，不中断卸载）
 ③ `purge_stale_draw_handlers()` 兜底：扫 GC 找出插件会话/覆盖层对象，
    移除它们**还持有**的 handler —— 兜住"绕过 unregister 的强制重载"
    （register 时"先清后建" + unregister 时也清）

本测试
------
A 组：purge 的语义（清孤儿 / 不动当前 / 幂等 / 返回值）
B 组：detach 的健壮性（置空 / 重复调用 no-op / 失效句柄不抛）
C 组：静态契约（unregister 与 register 都接上了）
D 组：端到端 —— 真实 unregister→register 后，存活 handler 数守恒
E 组：bug 注入（关掉 detach / 关掉 purge）必须被抓
"""
import os
import sys
import gc
import json
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
ADDONS = os.path.dirname(REPO)
sys.path.insert(0, ADDONS)
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")

import RealTimeMotionPath as rt
from RealTimeMotionPath import drawing as dw, state as st

OUT = os.path.join(HERE, "_draw_leak_result.json")
steps = []

# 防止"孤儿"被 GC 回收（要模拟"还在注册表里活着"的情形）
_KEEPALIVE = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


# 插件对象上"存放绘制句柄"的槽位（Overlay 两个 + Session 一个）
HANDLE_SLOTS = ("_h_view", "_h_pixel", "render_callback_id")


def live_slots():
    """扫出所有"插件对象仍持有非 None 绘制句柄"的 (对象, 槽位名)。

    ★ 每次现扫、不缓存 —— 与 `purge_stale_draw_handlers` 同口径
      （句柄会随 attach/detach 变化，缓存就会骗人）。
    """
    found = []
    for o in gc.get_objects():
        try:
            t = type(o)
            if not str(getattr(t, "__module__", "")).startswith("RealTimeMotionPath"):
                continue
            for slot in HANDLE_SLOTS:
                if getattr(o, slot, None) is not None:
                    found.append((o, slot))
        except Exception:
            continue
    return found


def count_live():
    """插件对象持有的"活的"绘制句柄总数（每次现扫，不缓存）。"""
    return len(live_slots())


def make_orphan():
    """造一个"孤儿会话"：注册一个真 handler，把句柄塞进它，并让它留在内存里。

    这就是泄漏现场的最小复现 —— 对象还活着（被注册表闭包/keepalive 引用），
    但已不在 `_session` 引用链上 ⇒ 正常代码找不到它。
    """
    sess = st.MotionPathSession()
    sess.render_callback_id = bpy.types.SpaceView3D.draw_handler_add(
        (lambda: None), (), 'WINDOW', 'POST_VIEW')
    _KEEPALIVE.append(sess)
    return sess


# ================================================================ A 组
try:
    cur = st._session

    # 先确保当前处于"干净"起点：清掉历史遗留
    dw.purge_stale_draw_handlers(keep_session=cur)
    base_n = count_live()
    step("A0 起点：无孤儿（只有当前会话）", base_n <= 1,
         "存活句柄数 = %d" % base_n)

    # A1：孤儿能被清掉
    orph = make_orphan()
    n_with = count_live()
    rm, fa = dw.purge_stale_draw_handlers(keep_session=cur)
    n_after = count_live()
    step("A1 ★★★ 孤儿回调被清理",
         n_with == base_n + 1 and n_after == base_n and len(rm) >= 1,
         "注册孤儿后 %d → 清理后 %d（removed=%d failed=%d）"
         % (n_with, n_after, len(rm), len(fa)))
    step("A2 孤儿的句柄字段被置空（不留死句柄）",
         orph.render_callback_id is None,
         "orphan.render_callback_id = %r（原为 %r）"
         % (orph.render_callback_id, rm[0] if rm else None))

    # A3：不动 keep_session
    cur2 = st._session
    keep_h = cur2.render_callback_id
    cur2.render_callback_id = bpy.types.SpaceView3D.draw_handler_add(
        (lambda: None), (), 'WINDOW', 'POST_VIEW')
    keep_h2 = cur2.render_callback_id
    rm2, _ = dw.purge_stale_draw_handlers(keep_session=cur2)
    step("A4 ★ 指定的 keep_session 不被清",
         cur2.render_callback_id is keep_h2,
         "keep 的句柄 %s（purge 前 %s）"
         % ("保留" if cur2.render_callback_id is keep_h2 else "★被误删",
            "无" if keep_h is None else "有"))
    # 收尾：把这个临时句柄也清掉
    try:
        bpy.types.SpaceView3D.draw_handler_remove(cur2.render_callback_id, 'WINDOW')
    except Exception:
        pass
    cur2.render_callback_id = None

    # A5：幂等（连续 purge 不炸、第二次 removed 为空）
    rm3, _ = dw.purge_stale_draw_handlers(keep_session=cur)
    rm4, _ = dw.purge_stale_draw_handlers(keep_session=cur)
    step("A5 ★ 幂等：重复 purge 不抛、第二次无孤儿可清",
         len(rm4) == 0, "第 2 次 removed=%d" % len(rm4))

    # A6：返回值形状
    step("A6 返回 (removed, failed) 两个列表",
         isinstance(rm3, list) and isinstance(fa, list),
         "类型 %s / %s" % (type(rm3).__name__, type(fa).__name__))

    # ============================================================ B 组
    # B1：失效句柄不炸（先移除，再让 detach 拿着死句柄走一遍）
    h = bpy.types.SpaceView3D.draw_handler_add((lambda: None), (), 'WINDOW', 'POST_VIEW')
    bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
    cur.render_callback_id = h            # 故意塞一个已失效的
    try:
        dw.detach_render_callback()
        ok_b1 = cur.render_callback_id is None
        err_b1 = ""
    except Exception as e:
        ok_b1, err_b1 = False, str(e)[:90]
    step("B1 ★★ detach 对失效句柄容错（不抛）且字段被清空",
         ok_b1, err_b1 or "callback_id=%r" % cur.render_callback_id)

    # B2：重复 detach 是 no-op
    try:
        dw.detach_render_callback()
        dw.detach_render_callback()
        ok_b2 = cur.render_callback_id is None
        err_b2 = ""
    except Exception as e:
        ok_b2, err_b2 = False, str(e)[:90]
    step("B2 重复 detach 是 no-op（不抛）", ok_b2, err_b2 or "ok")

    # B3：正常 detach 真能移除
    h3 = bpy.types.SpaceView3D.draw_handler_add((lambda: None), (), 'WINDOW', 'POST_VIEW')
    cur.render_callback_id = h3
    n_before = count_live()
    dw.detach_render_callback()
    step("B3 detach 真的把回调从句柄表移除",
         count_live() == n_before - 1 and cur.render_callback_id is None,
         "%d → %d" % (n_before, count_live()))

    # ============================================================ C 组
    src_init = open(os.path.join(REPO, "__init__.py"), encoding="utf-8").read()
    i_ureg = src_init.find("def unregister()")
    i_reg = src_init.find("def register()")
    ureg_src = src_init[i_ureg:i_reg if i_reg > i_ureg else len(src_init)]
    reg_src = src_init[i_reg:i_ureg] if i_reg < i_ureg else src_init[i_reg:]
    step("C1 ★★ unregister() 里调了 detach_render_callback（原来的漏点）",
         "detach_render_callback()" in ureg_src,
         "找到" if "detach_render_callback()" in ureg_src else "★缺失")
    step("C2 ★ unregister() 里也有 purge 兜底",
         "purge_stale_draw_handlers()" in ureg_src)
    step("C3 ★ register() 里先清后建（purge）",
         "purge_stale_draw_handlers()" in reg_src)

    # ============================================================ F 组
    # `bpy.app.handlers` 的同源泄漏（2026-09-17 顺藤摸瓜抓到）
    #
    #   实测 `depsgraph_update_post` 里叠了 **3 个** `on_depsgraph_update`
    #   （全是本插件的，其中旧模块那个还在读已删除的 WindowManager 属性
    #     ⇒ 每次 depsgraph 更新抛 AttributeError）。
    #   根因：注册判据比**函数对象身份**，跨模块重载必失效 ⇒ 叠积。
    def dg_count():
        return sum(1 for h in bpy.app.handlers.depsgraph_update_post
                   if str(getattr(h, "__module__", "")).startswith("RealTimeMotionPath"))

    def fake_plugin_handler(*a, **k):
        pass

    # 冒充"别的插件"的 handler（module 改成第三方）
    fake_plugin_handler.__module__ = "some_other_addon.core"

    try:
        step("F0 起点：depsgraph 里无本插件 handler", dg_count() == 0,
             "实际 = %d" % dg_count())

        # F1：能清掉本插件的
        # 造一个"带正确 __module__ 的插件函数"，模拟跨模块重载后的旧 handler
        def _mk_plugin_handler():
            def on_depsgraph_update(*a, **k):
                pass
            on_depsgraph_update.__module__ = "RealTimeMotionPath.interaction"
            return on_depsgraph_update
        h1 = _mk_plugin_handler()
        h2 = _mk_plugin_handler()
        bpy.app.handlers.depsgraph_update_post.append(h1)
        bpy.app.handlers.depsgraph_update_post.append(h2)
        n_with = dg_count()
        rmh = st.purge_stale_app_handlers()
        step("F1 ★★★ 插件自己的 app handler 被清理（清掉 2 个）",
             n_with == 2 and dg_count() == 0 and len(rmh) >= 2,
             "清前 %d → 清后 %d（removed=%s）" % (n_with, dg_count(), rmh))

        # F2：★ 不能误伤别的插件
        bpy.app.handlers.depsgraph_update_post.append(fake_plugin_handler)
        h3 = _mk_plugin_handler()
        bpy.app.handlers.depsgraph_update_post.append(h3)
        st.purge_stale_app_handlers()
        survived = fake_plugin_handler in bpy.app.handlers.depsgraph_update_post
        step("F2 ★★ 不误伤【别的插件】的 handler（判据按包名）",
             survived and dg_count() == 0,
             "第三方 handler 存活=%s，本插件残留=%d" % (survived, dg_count()))
        # 收尾：清掉冒充的第三方
        if fake_plugin_handler in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(fake_plugin_handler)

        # F3：幂等 + 返回列表
        rm3 = st.purge_stale_app_handlers()
        rm4 = st.purge_stale_app_handlers()
        step("F3 幂等：重复 purge 不抛、第二次为空",
             isinstance(rm3, list) and isinstance(rm4, list) and len(rm4) == 0,
             "第 2 次 = %s" % rm4)

        # F4：非 list 属性不被误当 handler 列表处理（bpy.app.handlers.persistent 是函数）
        try:
            st.purge_stale_app_handlers()
            ok_f4 = callable(bpy.app.handlers.persistent)
            err_f4 = ""
        except Exception as e:
            ok_f4, err_f4 = False, str(e)[:90]
        step("F4 跳过非列表属性（如 handlers.persistent 是函数）", ok_f4, err_f4 or "ok")

        # F5：静态契约 —— 注册判据已从"函数身份"改为"先清后建"
        src_it2 = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
        has_old = ("if on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post"
                   in src_it2)
        has_new = "purge_stale_app_handlers()" in src_it2
        step("F5 ★★ interaction.py 已改为先清后建（旧的函数身份判重已移除）",
             has_new and not has_old,
             "新写法=%s 旧写法残留=%s" % (has_new, has_old))

        # F6：__init__ 两端都接上
        step("F6 ★ unregister() 与 register() 都调 purge_stale_app_handlers",
             "purge_stale_app_handlers()" in ureg_src
             and "purge_stale_app_handlers()" in reg_src,
             "unregister=%s register=%s"
             % ("purge_stale_app_handlers()" in ureg_src,
                "purge_stale_app_handlers()" in reg_src))
    except Exception:
        step("F 组 EXCEPTION", False, traceback.format_exc()[-500:])

    # ============================================================ D 组
    # 端到端：真实 unregister → register，存活句柄数必须守恒
    dw.purge_stale_draw_handlers(keep_session=st._session)
    # 模拟"路径显示开着"：给当前会话注册一个回调
    st._session.render_callback_id = bpy.types.SpaceView3D.draw_handler_add(
        (lambda: None), (), 'WINDOW', 'POST_VIEW')
    before = count_live()
    try:
        rt.unregister()
        mid = count_live()
        rt.register()
        after = count_live()
        err = ""
    except Exception as e:
        before = mid = after = -1
        err = traceback.format_exc()[-300:]
    step("D1 ★★★ 真实 unregister 后回调被撤净（0 个残留）",
         mid == 0, "unregister 后存活句柄 = %d %s" % (mid, err[:120]))
    step("D2 ★★ register 后不叠积（先清后建：仍是 0，未另行注册）",
         after == 0, "register 后存活句柄 = %d" % after)
    # 收尾：把当前会话的回调补上（恢复到"路径显示开着"的合理状态）
    dw.purge_stale_draw_handlers(keep_session=st._session)

    # ============================================================ E 组
    INJ = []

    def _mk_no_detach():
        """I1：detach 变 no-op ⇒ 只靠 purge 兜底也应清干净（验证兜底真的有效）。"""
        _o = dw.detach_render_callback

        def do():
            dw.detach_render_callback = lambda: None

        def undo():
            dw.detach_render_callback = _o
        return do, undo, "I1 detach 失效（只靠 purge 兜底）"

    def _mk_no_both():
        """I2：detach **与** purge 都失效 ⇒ 必须残留。

        ⚠️ 首版只 patch 了 purge，结果 detach 仍把回调撤干净 ⇒ 残留 0
           ⇒ 注入"抓不住"。**注入必须把要验证的那一层彻底切断**：
           这里要证明的是"测试确实在度量泄漏"，所以两层都得关掉。
        """
        _d = dw.detach_render_callback
        _p = dw.purge_stale_draw_handlers

        def do():
            dw.detach_render_callback = lambda: None
            dw.purge_stale_draw_handlers = lambda *a, **k: ([], [])

        def undo():
            dw.detach_render_callback = _d
            dw.purge_stale_draw_handlers = _p
        return do, undo, "I2 detach 与 purge 都失效 ⇒ 必然残留"

    def _scenario():
        """注册一个"当前会话持有的回调"，然后走真实 unregister；返回残留句柄数。"""
        dw.purge_stale_draw_handlers(keep_session=st._session)
        st._session.render_callback_id = bpy.types.SpaceView3D.draw_handler_add(
            (lambda: None), (), 'WINDOW', 'POST_VIEW')
        _KEEPALIVE.append(st._session)
        try:
            # unregister 内部 import 的是"当前模块属性"，monkeypatch 生效
            rt.unregister()
        finally:
            pass
        return count_live()

    base_res = _scenario()
    step("E0 基线：未注入时 unregister 后 0 残留", base_res == 0,
         "残留 = %d" % base_res)
    try:
        rt.register()
    except Exception:
        pass

    for mk, expect_leak in ((_mk_no_detach, False), (_mk_no_both, True)):
        do, undo, label = mk()
        try:
            do()
            n = _scenario()
        except Exception as e:
            n = -1
            label += "（异常 %s）" % str(e)[:60]
        finally:
            undo()
            try:
                rt.register()
            except Exception:
                pass
        if expect_leak:
            caught = n > 0
            step("★ %s ⇒ 测试能抓到残留" % label, caught,
                 "残留 = %d（>0 表示测试确实在度量泄漏）" % n)
        else:
            # detach 挂了但 purge 兜住 ⇒ 不应泄漏
            step("★ %s ⇒ purge 兜底清干净（不残留）" % label, n == 0,
                 "残留 = %d" % n)
        INJ.append((label, n))

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-800:])

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
