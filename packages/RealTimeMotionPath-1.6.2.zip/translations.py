import bpy

# 翻译表说明
# ---------------------------------------------------------------------------
# 代码里所有界面字符串统一用「英文原文」，中文靠本表提供。
# 若日后修改了代码中的 name=/description=/bl_label= 等文字，
# 请同步更新下面对应的 key —— 否则中文界面会回退成英文原文。
#
# key 写法 ("*", "English") 表示无上下文（iface 层）翻译。
# ---------------------------------------------------------------------------

translations_dict = {
    "zh_HANS": {
        # --- Add-on Info ---
        ("*", "RealTimeMotionPath"): "实时运动路径",
        ("*", "Display and edit motion paths in real time in the 3D Viewport, with direct handle editing and Graph Editor sync"): "在 3D 视口中实时显示和编辑运动路径，支持直接手柄编辑和图形编辑器同步",

        # --- Operators ---
        ("*", "Auto Update Motion Paths"): "自动更新运动路径",
        ("*", "Real time update motion paths"): "实时更新运动路径",
        ("*", "Set Handle Type"): "设置手柄类型",
        ("*", "Toggle Direct Manipulation"): "切换直接操控模式",
        ("*", "Enable/Disable Motion Path Editing"): "启用/禁用运动路径编辑",
        ("*", "Enable Direct Path Editing"): "启用直接路径编辑",
        ("*", "Disable Direct Path Editing"): "已禁用直接路径编辑",
        ("*", "Direct Motion Path Manipulation"): "直接操控运动路径",
        ("*", "Move Motion Path Points"): "移动运动路径点",
        ("*", "Move Motion Path Handle"): "移动运动路径手柄",
        ("*", "Adjust Motion Path Speed"): "调整运动路径速度",
        # ★★ 2026-09-18 语义升级：双击速度三角 ⇒ 切换【一体 / 分离】
        #    （旧的四条"复制对侧值"文案已随之下线，见下方 git 历史）
        ("*", "Handles split - you can now adjust each side on its own"):
            "两个三角已分离，现在可以单独调整任意一侧",
        # ★★ 2026-09-30（B 语义）：双击锁定的目标是**同步三角值 s**（"一体"），
        #    **不再追求 GE 手柄共线** ⇒ 文案不能再写"已共线"（那是误导）。
        #    共线那件事交给弹窗里的校正（它会明确告知会改变路径形状）。
        ("*", "Handles locked together - in/out speeds are now equal"):
            "两个三角已锁定为一体 —— 进出速度已一致",
        # ★★ 2026-09-30（修 P1-1）：对侧被钳到 S_HARD_MAX ⇒ 目标【没能】达成，必须说实话
        ("*", "Handles locked together - opposite handle hit its limit, speeds NOT fully equal (%.2fx apart)"):
            "两个三角已锁定为一体 —— 但对侧手柄已到极限，速度未能完全一致（仍差 %.2f 倍）",
        ("*", "Handles locked together (no opposite handle to match)"):
            "两个三角已锁定为一体（对侧无可同步的三角）",
        ("*", "Handles locked together (cannot read a speed value)"):
            "两个三角已锁定为一体（读不出速度值）",
        ("*", "Handles locked together"): "两个三角已锁定为一体",
        ("*", "Lock Handles Together"): "锁定三角手柄为一体",
        ("*", "Split Handles"): "分离三角手柄",
        ("*", "View3D not found, cannot run operator"): "未找到3D视图，无法运行操作",
        ("*", "Toggle Custom Path"): "切换自定义路径显示",
        ("*", "Enable/Disable Custom Motion Path Drawing"): "启用/禁用自定义运动路径绘制",
        ("*", "Enabled Motion Path, but no 3D View found for interaction."): "已启用运动路径，但未找到可交互的3D视图。",
        ("*", "Motion Path Context Menu"): "运动路径上下文菜单",

        # --- Properties & Settings ---
        ("*", "Motion Path Settings"): "运动路径设置",
        ("*", "Performance"): "性能",
        ("*", "Update Mode"): "更新模式",
        ("*", "Interaction FPS"): "交互帧率上限",
        ("*", "Auto Update FPS"): "自动更新频率",

        # Style Settings
        ("*", "Style Settings"): "样式设置",
        ("*", "Path Width"): "路径宽度",
        ("*", "Path Color"): "路径颜色",
        ("*", "Show Frame Points"): "显示帧点",
        ("*", "Frame Point Size"): "帧点大小",
        ("*", "Frame Point Color"): "帧点颜色",

        # Keyframes
        ("*", "Keyframes"): "关键帧",
        ("*", "Keyframe Size"): "关键帧大小",
        ("*", "Keyframe Color"): "关键帧颜色",
        ("*", "Selected Keyframe Color"): "选中关键帧颜色",

        # Handles
        ("*", "Handles"): "手柄",
        ("*", "Handle Line Width"): "手柄线宽",
        ("*", "Handle Line Color"): "手柄线颜色",
        ("*", "Selected Handle Line Color"): "选中的手柄线颜色",
        ("*", "Handle Endpoint Size"): "手柄端点大小",
        ("*", "Handle Endpoint Color"): "手柄端点颜色",
        ("*", "Selected Handle Endpoint Color"): "选中的手柄端点颜色",

        # Origin Indicator
        ("*", "Origin Indicator"): "原点指示器",
        ("*", "Show Origin Indicator"): "显示原点指示器",
        ("*", "Origin Style"): "原点样式",
        ("*", "Origin Size"): "原点大小",
        ("*", "Origin Color"): "原点颜色",
        ("*", "Origin Inner Color"): "原点内圈颜色",
        ("*", "Ring"): "圆环",
        ("*", "Hollow circle ring"): "空心圆环",
        ("*", "Dot"): "圆点",
        ("*", "Filled circle dot"): "实心圆点",
        ("*", "Ring+Dot"): "圆环+圆点",
        ("*", "Ring with center dot (like Blender origin)"): "带中心点的圆环（类似 Blender 原点）",

        # --- WindowManager Properties ---
        ("*", "Enable Motion Path"): "启用运动路径",
        ("*", "Enable custom motion path drawing"): "启用自定义运动路径绘制",
        ("*", "Direct Edit Active"): "直接编辑已激活",
        ("*", "Enable real-time direct editing of motion path control points"): "启用对运动路径控制点的实时直接编辑",
        ("*", "Auto Update Active"): "自动更新已激活",
        # ⚠️ 2026-09-17：`Max FPS Limit` 的词条已删除 —— 该属性名随
        #    性能设置迁到 AddonPreferences 而改名为 `Interaction FPS`
        #    （名字直接对齐已有的 "Interaction FPS" 词条），旧名成了僵尸词条。
        ("*", "Addon preferences unavailable"): "插件偏好设置不可用",
        ("*", "Limit the frame rate of interaction and redrawing to save power"): "限制交互与重绘的帧率以节省电量",
        ("*", "Choose how the motion path updates"): "选择运动路径的更新方式",
        ("*", "Smart (Event)"): "智能 (事件驱动)",
        ("*", "Update only when relevant data changes (Zero idle power)"): "仅在相关数据变化时更新 (零空闲功耗)",
        ("*", "Timer (Polling)"): "计时器 (轮询)",
        ("*", "Update periodically (Stable but higher power)"): "定期更新 (稳定但功耗较高)",
        ("*", "Frequency of checks in Timer mode (Hz)"): "计时器模式下的检查频率 (Hz)",

        ("*", "Keyframe Handle Type"): "关键帧手柄类型",
        ("*", "Handle type used when editing keyframes on the motion path"): "在运动路径上编辑关键帧时使用的手柄类型",
        ("*", "Free"): "自由 (Free)",
        ("*", "Handles can be adjusted independently"): "手柄可以独立调整",
        ("*", "Aligned"): "对齐 (Aligned)",
        ("*", "Handles are aligned to maintain smoothness"): "手柄对齐以保持平滑",
        ("*", "Vector"): "矢量 (Vector)",
        ("*", "Creates linear interpolation"): "创建线性插值",
        ("*", "Auto"): "自动 (Auto)",
        ("*", "Automatic smooth handles"): "自动平滑手柄",
        ("*", "Auto Clamped"): "自动钳位 (Auto Clamped)",
        ("*", "Automatic handles with clamped values"): "具有钳位值的自动手柄",

        # ★ 2026-09-17（方案 A）：右键菜单顶部的【体感手柄类型】只读标签
        ("*", "Feel: %s"): "体感: %s",
        ("*", "Feel: (mixed / original)"): "体感: (混合 / 原始类型)",

        ("*", "Snap to Grid"): "吸附到网格",
        ("*", "Snap handles to grid while dragging"): "拖拽时将手柄吸附到网格",
        ("*", "Snap Step"): "吸附步长",
        ("*", "Grid step size for handle snapping"): "手柄吸附的网格步长",
        ("*", "Handle Scale"): "手柄缩放",
        ("*", "Visual scale multiplier for handle display in viewport"): "视口中手柄显示的视觉缩放倍数",

        # --- Add-on Preferences ---
        ("*", "Restore Defaults"): "恢复默认值",
        ("*", "Reset to Default"): "重置为默认",
        ("*", "Reset all motion path settings to default values"): "将所有运动路径设置重置为默认值",

        # --- 手柄拖拽模式（2026-09-17 文案改写）---
        # ★ 命名原则：直接说出【它保住了什么 + 代价是什么】。
        #   拖手柄改的是手柄长度 |dv|，而时间跨度 dt 只有一个位置可站
        #   ⇒ 速度 与 三角疏密 数学上只能保住一个：
        #        速度 = |dv| ÷ dt   ；三角 s = dt ÷ span
        ("*", "Path Handle Mode"): "路径手柄模式",
        # 按钮名（短，popover 窄）
        ("*", "Change Speed"): "改速度",
        ("*", "Keep Speed"): "保速度",
        # ★ 按钮的【悬停说明】：只描述功能效果，一句话说清（不解释原因、不写"适合…"）
        ("*", "Drag changes the speed only; the speed distribution stays"):
            "拖手柄只改快慢；速度分布保持不变",
        ("*", "Drag changes the shape only; speed stays, the speed distribution follows"):
            "拖手柄只改形状；快慢不变，速度分布跟着变",
        ("*", "What a handle drag keeps: speed or speed distribution"):
            "拖手柄时保住哪个：快慢 或 速度分布",
        # ★ 盲审 S1（2026-09-18）：插件按整数帧建模，非整数帧关键帧会被合并掉。
        #   明确提示（原先完全静默）。
        ("*", "Subframe keyframes are not supported"):
            "不支持非整数帧的关键帧（已被合并）：",

        # ★ 盲审 R7（2026-09-18）：i18n 自测原先只扫 4 个文件 ⇒ 这两条
        #   `modal_edit.py` 里的 bl_label **从未被发现漏翻**。
        #   （改扫全目录后暴露出来。）
        ("*", "RTMP Modal Edit"): "运动路径 · 模态编辑",
        ("*", "RTMP Keyboard Transform"): "运动路径 · 键盘变换",

        # --- 调试日志（2026-09-17）---
        ("*", "Debug"): "调试",
        ("*", "Debug Log"): "调试日志",
        ("*", "Open Debug Log"): "打开调试日志",
        ("*", "Clear Debug Log"): "清空调试日志",
        ("*", "Log:"): "日志：",
        ("*", "Open"): "打开",
        ("*", "Clear"): "清空",
        # ★★ 2026-09-27（3b）：删掉原来的 3 条 **identity 词条**（原文 == 译文）。
        #
        #   它们的作用只是让 `regression.py:t_i18n` 看到"这个 key 在表里"
        #   就判定"已翻译" —— 而**词条存在 ≠ 有翻译**：
        #   英文界面下那三条 tooltip 照样显示中文，检查却报"0 漏翻"。
        #   这就是"分子被 identity 映射注水"（分母另有 58 条裸中文进不了检查，
        #   见 tests/i18n_gate.py）。
        #
        #   现在原文已改成英文（见 ui.py），下面是**真翻译**。
        ("*", "Open the folder that contains the debug log"): "打开调试日志所在的文件夹",
        ("*", "Clear the debug log file"): "清空调试日志文件",
        # ★★ 2026-10-08：描述补了「默认开启 + 8MB 轮转」——key 随之更新
        #    （改英文原文就必须同步改 key，否则这里变成死键、中文界面回退成英文）
        ("*", "Write the interaction trace to a JSONL log for troubleshooting (on by default; rotates at 8MB)"):
            "把交互过程写入 JSONL 日志，便于排查交互问题（默认开启；文件满 8MB 自动轮转）",
        ("*", "debug_log unavailable"): "调试日志不可用",

        # ★★ 2026-09-27（3b）：`modal_edit.py` 的界面文案。
        #   该模块此前 **50 处中文硬编码**（状态栏 / 警告 / 模式描述），
        #   一处 `iface_()` 都没有 ⇒ 英文界面下全是中文；
        #   而 `regression.py:t_i18n` 的采集口径看不见它们（分母漏了）。
        #   现在原文已改英文（本表由脚本按"英文 → 原中文"自动生成，不会漏翻）。
        ("*", " [%d selected] "): "  [多选 %d 个]  ",
        ("*", " [%s axis]"): "  [%s 轴]",
        ("*", " [%s plane]"): "  [%s 平面]",
        ("*", " [input %s]"): "   [输入 %s]",
        ("*", " [precision x0.1]"): "  [精度 ×0.1]",
        ("*", " [precision x1/30]"): "  [精度 ×1/30]",
        ("*", "%s | D: %.4f  (X: %.4f  Y: %.4f  Z: %.4f)%s%s%s   |  X/Y/Z axis lock · "): "%s | D: %.4f  (X: %.4f  Y: %.4f  Z: %.4f)%s%s%s   |  X/Y/Z 锁轴 · Shift+X/Y/Z 锁平面 · 数字输入 · Shift 精度 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "%s | Move mouse · LMB/Enter confirm · RMB/ESC cancel"): "%s | 移动鼠标 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "Adjust sample density distribution (line 2)"): "调整采样点疏密分布（第二条线）",
        ("*", "Cannot resolve mouse world position"): "无法解析鼠标世界位置",
        ("*", "Cannot resolve pivot"): "无法解析 pivot",
        ("*", "Cannot resolve target world position"): "无法解析目标的世界位置",
        ("*", "Drag out = sparser · drag in = denser"): "往外拖放大(变疏) · 往里拖缩小(变密)",
        ("*", "Drag up/down to adjust"): "上下拖调整",
        ("*", "Endpoint segment has no neighbouring keyframe"): "端点段没有相邻关键帧，无法调整",
        ("*", "Mode '%s' is not implemented yet"): "模式 '%s' 尚未实现（骨架已就绪）",
        ("*", "Move"): "移动",
        ("*", "Move path points (line 1)"): "移动路径点（第一条线）",
        ("*", "No keyframe near the cursor"): "鼠标附近没有关键帧",
        ("*", "No path point or handle selected"): "没有选中的路径点或端点",
        ("*", "No path point or handle selected - click one first, then press %s (Shift+click for multi-select)"): "没有选中的路径点或端点 —— 先点一下再按 %s（Shift+点击可多选）",
        ("*", "Rotate"): "旋转",
        ("*", "Rotate %.2f°%s%s   |  Move mouse · X/Y/Z axis lock · numeric input (deg) · Shift precision · LMB/Enter confirm · RMB/ESC cancel"): "旋转 %.2f°%s%s   |  移动鼠标 · X/Y/Z 锁轴 · 数字输入(度) · Shift 精度 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "Rotate selected points (line 1)"): "旋转路径点群（第一条线）",
        ("*", "Rotate | Move mouse · LMB/Enter confirm · RMB/ESC cancel"): "旋转 | 移动鼠标 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "Sample %s%s | Keyframe %s %s | s=%.3f  %.2fx of uniform   |  %s · Shift precision · LMB/Enter confirm · RMB/ESC cancel"): "采样点%s%s | 关键帧 %s %s | s=%.3f  相对匀速 %.2fx   |  %s · Shift 精度 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "Sample Density"): "采样点疏密",
        ("*", "Sample density%s | %s · Shift precision · LMB/Enter confirm · RMB/ESC cancel"): "采样点疏密%s | %s · Shift 精度 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "Scale"): "缩放",
        ("*", "Scale %.4f×%s%s%s   |  Move mouse · X/Y/Z axis limit · numeric input (factor) · Shift precision · LMB/Enter confirm · RMB/ESC cancel"): "缩放 %.4f×%s%s%s   |  移动鼠标 · X/Y/Z 限制轴 · 数字输入(倍) · Shift 精度 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "Scale selected points (line 1)"): "缩放速度（第一条线；现有拖拽已具备）",
        ("*", "Scale | Move mouse · LMB/Enter confirm · RMB/ESC cancel"): "缩放 | 移动鼠标 · 左键/回车 确认 · 右键/ESC 取消",
        ("*", "left"): "左段",
        ("*", "right"): "右段",

        # ★ 2026-09-27（3b）：模态进入失败的两条提示（原先硬编码中文、
        #   且两个 operator 各写一份）。现在抽成 `modal_edit` 的模块常量 +
        #   `_iface()` 统一入口。
        ("*", "Please use this in a 3D View"): "请在 3D 视图中使用",
        ("*", "No editable location animation (select an object with animation)"):
            "没有可编辑的位移动画（请选中一个有动画的物体）",
        # ★ 写入被拒时的原因（会拼进状态栏）
        ("*", "Value out of writable range"): "数值超出可写入范围",
        ("*", "Value out of writable range (move/scale too large)"):
            "数值超出可写入范围（移动/缩放幅度太大）",
        ("*", "Endpoint segment has no neighbouring keyframe - cannot adjust"):
            "端点段无相邻关键帧，不可调",

        # --- 运动路径校正（2026-09-30，命名方案 D）---
        # ⚠️ 这些来自 spec_check.py / spec_ui.py —— 会显示在控制台 / 状态栏 / 弹窗，
        #    用户看得见 ⇒ 必须走翻译（i18n_gate 抓的正是它）。
        ("*", "Motion Path Correction"): "运动路径校正",
        ("*", "Correct Handles"): "校正手柄",
        ("*", "Check Handles"): "检查手柄",
        ("*", "Found %d handle problem(s)"): "发现 %d 处手柄问题",

        ("*", "Handles already follow the path"): "手柄已经贴合路径",
        ("*", "Handles follow the path - nothing to fix"): "手柄已贴合路径 —— 没有需要修复的",
        ("*", "Handles now follow the path"): "手柄已贴合路径",
        ("*", "Check Motion Path Handles"): "检查运动路径手柄",
        ("*", "Check whether the handles follow the path (read-only, changes nothing)"):
            "检查手柄是否贴合路径（纯读取，不修改任何数据）",
        ("*", "No animated object selected"): "没有选中带动画的对象",
        ("*", "Check failed (see console)"): "检查失败（详见控制台）",
        ("*", "Correction failed (see console)"): "校正失败（详见控制台）",
        # ★★ 2026-09-30（修 P1-2）：某个修正阶段**内部异常** ⇒ 那一项没做，必须点名
        ("*", "Correction failed for: %s (see console)"):
            "校正失败（这几项没做：%s，详见控制台）",
        # ★★ 2026-09-30（修 P1-3）：顺手冻结了几个手柄 —— 有副作用，用户应该知道
        ("*", "(froze %d handle(s) to keep the shape)"):
            "（为保住形状，顺手冻结了 %d 个手柄）",
        ("*", "Revert failed (see console)"): "还原失败（详见控制台）",
        ("*", "Frame %g has no %s keyframe - the handle is missing one component and dragging writes incompletely"):
            "第 %g 帧缺 %s 轴的关键帧 —— 该帧手柄少一个分量，拖拽写入也不完整",
        ("*", "Frame %g %s handle is off the path by %.2f deg (the three axes use time spans %s)"):
            "第 %g 帧%s手柄与路径不贴合，偏离 %.2f°（三轴时间跨度 %s）",
        ("*", "Frame %g: the 3D handle is bent by %.2f deg, so the path turns a corner here"):
            "第 %g 帧：3D 手柄折了 %.2f°，路径在这里拐了个弯",
        ("*", "left"): "左",
        ("*", "right"): "右",
        ("*", "Handle is off the path (not tangent)"): "手柄与路径不贴合",
        ("*", "An axis has no keyframe here (handle misses a component)"):
            "某轴在此帧缺关键帧（手柄少一个分量）",
        ("*", "3D handle is bent (the path turns a corner here)"):
            "3D 手柄折了（路径在此拐弯）",

        # --- 校正弹窗（2026-09-30）---
        ("*", "Review the handle problems and choose which ones to correct (you can undo afterwards)"):
            "查看手柄问题，勾选要校正的项（之后可以撤销）",
        ("*", "Revert Last Correction"): "还原上次校正",
        ("*", "Undo the last correction by restoring the saved snapshot"):
            "用保存的快照还原上一次校正",
        ("*", "Do Not Ask Again"): "本次不再提示",
        ("*", "Stop showing this prompt for this object in this session (nothing is modified)"):
            "本会话内不再对此对象弹出此提示（不修改任何数据）",
        ("*", "Frame %g"): "第 %g 帧",
        ("*", "... and %d more"): "…… 另有 %d 处",
        ("*", "Off by %.2f deg (time spans %s)"): "偏离 %.2f°（时间跨度 %s）",
        ("*", "Missing axis: %s"): "缺 %s 轴",
        ("*", "Bent by %.2f deg - the path turns a corner here"):
            "折了 %.2f° —— 路径在此拐弯",
        ("*", "Optional:"): "可选：",
        ("*", "(aligns the Graph Editor keyframe handles)"):
            "（对齐的是 Graph Editor 里的关键帧手柄）",
        ("*", "Force-align keyframe in/out speeds"): "强制对齐关键帧进出速度",
        ("*", "Align the left and right handles of every keyframe in the Graph Editor (Free-feel ones included) so the in/out speed does not jump; changes the path shape"):
            "把 Graph Editor 里每个关键帧的左右手柄对齐（含体感=自由的手柄），让进出速度不突变；会改变路径形状",
        ("*", "Pressing OK will:"): "点「确定」会做这些：",
        ("*", "Make the handles lie along the path"): "让手柄贴着路径走",
        ("*", "Fill in any missing axis keyframes"): "补上缺失的关键帧",
        ("*", "Switch handle types to Free (positions do not move)"):
            "把派生类型手柄转为「自由」（位置不变）",
        ("*", "Free-feel handles are left untouched"): "体感=自由的手柄不动它",
        ("*", "For your information (not errors):"): "仅供参考（不是错误）：",
        ("*", "Make handles follow the path"): "让手柄贴合路径",
        ("*", "Give the three axes one shared time span so the handle lies along the path; changes the path shape by about 3%"):
            "让三轴共用同一个时间跨度，手柄就会沿着路径走；路径形状会改动约 3%",
        ("*", "Add missing keyframes"): "补上缺失的关键帧",
        ("*", "Fill in the missing axis keyframes; does not change the existing path"):
            "补上缺失轴的关键帧；不会改动现有轨迹",
        ("*", "Handle types are switched to Free automatically"): "手柄类型会自动转为「自由」",
        ("*", "(positions do not move)"): "（手柄位置不变）",
        ("*", "Nothing selected"): "没有勾选任何校正项",
        ("*", "Nothing to revert"): "没有可还原的校正",
        ("*", "%d issue(s) remain"): "还剩 %d 处不贴合",
        ("*", "Reverted"): "已还原",
        ("*", "Will not ask again for this object"): "本会话不再提示此对象",
        ("*", "Correct Motion Path Handles"): "校正运动路径手柄",
        ("*", "Revert Motion Path Correction"): "还原运动路径校正",
    }
}


def register(module_name):
    # Try to unregister first to avoid "cache already contains some data" warning on reload
    try:
        bpy.app.translations.unregister(module_name)
    except Exception:
        pass

    try:
        bpy.app.translations.register(module_name, translations_dict)
    except Exception as e:
        print(f"Warning: Could not register translations for {module_name}: {e}")


def unregister(module_name):
    try:
        bpy.app.translations.unregister(module_name)
    except Exception:
        pass
