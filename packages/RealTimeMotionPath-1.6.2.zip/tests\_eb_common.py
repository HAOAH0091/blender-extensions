# -*- coding: utf-8 -*-
"""Phase 1 极限边界测试的【共享地基】—— 不变量检查器 + 场景构造 + 判定工具。

给谁用：`tests/gui_eb_*.py` 各组的测试文件都 `import _eb_common as E`。
设计目标：让每个 worker 只关心"造什么场景、断言什么"，不用重复写脚手架。

⚠️ 本模块**只读产品代码**，不修改任何产品行为。

## 用法骨架

    import _eb_common as E
    steps = []
    def step(n, ok, d=""): steps.append((n, bool(ok), str(d)))
    try:
        o, act = E.build_object("T", E.KEYS_3)
        v = E.invariants(act, o)            # 违规列表；空 = 没破规范
        step("A1 不变量保持", not v, "; ".join(v))
    except Exception:
        step("FATAL", False, E.tb())
    E.flush(LOG, steps)

## 不变量（每个用例后都应该调 `invariants`）

  1. 同侧三轴 dt 必须相等（插件自己定义的规范）
  2. 全部手柄坐标必须是有限数（无 NaN / Inf）
  3. dt 不得为负、不得超过段长（曲线有效性）
  4. 四张内存表与 action 上的 custom property 必须一致（无幽灵条目）
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)

import bpy  # noqa: E402

try:
    import RealTimeMotionPath as RTMP                       # noqa: E402
    from RealTimeMotionPath import transform_domain as xf    # noqa: E402
    from RealTimeMotionPath import time_domain as td         # noqa: E402
    from RealTimeMotionPath import interaction as it         # noqa: E402
    from RealTimeMotionPath import spec_check as sc          # noqa: E402
    from RealTimeMotionPath import handles as hd             # noqa: E402
    from RealTimeMotionPath import state as st               # noqa: E402
except Exception:
    RTMP = xf = td = it = sc = hd = st = None

# ---- 常用关键帧布局 --------------------------------------------------------

KEYS_3 = ((0, (0.0, 0.0, 0.0)), (90, (1.0, 2.56, 0.4)), (117, (3.0, 6.0, 1.2)))
KEYS_2 = ((0, (0.0, 0.0, 0.0)), (90, (1.0, 2.56, 0.4)))
KEYS_5 = ((0, (0, 0, 0)), (30, (0.4, 0.9, 0.2)), (60, (1.1, 1.4, 0.6)),
          (90, (2.0, 2.0, 1.0)), (120, (2.4, 3.6, 1.9)))
FRAME = 90.0


# ---- 基础工具 --------------------------------------------------------------

def tb(limit=1200):
    """当前异常的 traceback 文本（截断）。"""
    return traceback.format_exc()[-limit:]


def clear_scene(prefix=None):
    """删掉场景里的网格对象（默认全删）。返回删掉的数量。"""
    n = 0
    for o in list(bpy.data.objects):
        if prefix and not o.name.startswith(prefix):
            continue
        try:
            bpy.data.objects.remove(o, do_unlink=True)
            n += 1
        except Exception:
            pass
    return n


def curves_of(o):
    """{array_index: fcurve}（按对象当前 action / 骨骼名）。"""
    return {c.array_index: c for c in xf._position_curves(o.animation_data.action, o, None)}


def build_object(name, keys=KEYS_3, htype=None, free_all=False, bone=False):
    """建一个带 location 关键帧的对象（默认 AUTO_CLAMPED 手柄）。

    :param keys: ((frame, (x,y,z)), ...)
    :param htype: 强制所有关键帧的手柄类型（如 'FREE'）
    :param free_all: 等价于 htype='FREE'
    :param bone: True = 建 armature + 姿态骨骼，返回 (arm_obj, action)
    :return: (obj, action)
    """
    if bone:
        arm = bpy.data.objects.get(name)
        if arm:
            bpy.data.objects.remove(arm, do_unlink=True)
        bpy.ops.object.armature_add(location=(0, 0, 0))
        arm = bpy.context.view_layer.objects.active
        arm.name = name
        try:
            bpy.ops.object.mode_set(mode='POSE')
        except Exception:
            pass
        pb = arm.pose.bones[0]
        for f, v in keys:
            bpy.context.scene.frame_set(int(f))
            pb.location = v
            pb.keyframe_insert("location", frame=int(f))
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        return arm, arm.animation_data.action

    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.view_layer.objects.active
    o.name = name
    for f, v in keys:
        bpy.context.scene.frame_set(int(f))
        o.location = v
        o.keyframe_insert("location", frame=int(f))
    bpy.context.scene.frame_set(int(keys[0][0]))
    act = o.animation_data.action
    ht = 'FREE' if free_all else htype
    if ht:
        for fc in curves_of(o).values():
            for kp in fc.keyframe_points:
                kp.handle_left_type = ht
                kp.handle_right_type = ht
            fc.update()
    return o, act


def set_handles(o, frame, side, dt=None, dv=None, span=None):
    """把某帧某一侧手柄写成指定 `dt` / `dv`（FREE 防重算）。"""
    for fc in curves_of(o).values():
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - frame) >= 1e-3:
                continue
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
            if side == 'left':
                t = float(kp.co[0]) - (dt if dt is not None else abs(float(kp.co[0]) - float(kp.handle_left[0])))
                v = float(kp.co[1]) - (dv if dv is not None else abs(float(kp.co[1]) - float(kp.handle_left[1])))
                kp.handle_left = (t, v)
            else:
                t = float(kp.co[0]) + (dt if dt is not None else abs(float(kp.handle_right[0]) - float(kp.co[0])))
                v = float(kp.co[1]) + (dv if dv is not None else abs(float(kp.handle_right[1]) - float(kp.co[1])))
                kp.handle_right = (t, v)
    for fc in curves_of(o).values():
        fc.update()


# ---- 不变量检查器（所有组都调它）-------------------------------------------

def handles_snapshot(action, obj, bone_name=None):
    """全部手柄的坐标快照 {(ax, frame, side): (t, v)}。"""
    snap = {}
    for fc in xf._position_curves(action, obj, bone_name):
        for kp in fc.keyframe_points:
            f = round(float(kp.co[0]), 4)
            snap[(fc.array_index, f, 'left')] = (float(kp.handle_left[0]), float(kp.handle_left[1]))
            snap[(fc.array_index, f, 'right')] = (float(kp.handle_right[0]), float(kp.handle_right[1]))
    return snap


def invariants(action, obj, bone_name=None, dt_tol=1e-6):
    """返回**违规列表**（空列表 = 全部不变量都成立）。

    1. 同侧三轴 dt 相等
    2. 坐标有限（无 NaN / Inf）
    3. dt 非负、不超过段长
    4. 内存表与 custom property 一致
    """
    bad = []
    if action is None:
        return ["action 为 None"]
    try:
        fcs = {fc.array_index: fc for fc in xf._position_curves(action, obj, bone_name)}
    except Exception:
        return ["取曲线失败: " + tb(300)]

    # 1 + 2 + 3
    by_frame = {}
    for ax, fc in fcs.items():
        pts = sorted(fc.keyframe_points, key=lambda k: float(k.co[0]))
        for i, kp in enumerate(pts):
            f = round(float(kp.co[0]), 4)
            for side, h in (('left', kp.handle_left), ('right', kp.handle_right)):
                t, v = float(h[0]), float(h[1])
                if not (math.isfinite(t) and math.isfinite(v)):
                    bad.append("非有限数 ax=%d f=%g %s = (%r, %r)" % (ax, f, side, t, v))
                    continue
                dt = abs(t - float(kp.co[0]))
                if dt < -1e-9:
                    bad.append("dt 为负 ax=%d f=%g %s dt=%r" % (ax, f, side, dt))
                # 段长
                if side == 'left' and i > 0:
                    span = float(kp.co[0]) - float(pts[i - 1].co[0])
                elif side == 'right' and i < len(pts) - 1:
                    span = float(pts[i + 1].co[0]) - float(kp.co[0])
                else:
                    span = None
                if span and span > 1e-9 and dt > span + 1e-4:
                    bad.append("dt 超过段长 ax=%d f=%g %s dt=%.4f span=%.4f" % (ax, f, side, dt, span))
                by_frame.setdefault((f, side), []).append(dt)

    for (f, side), dts in sorted(by_frame.items()):
        if len(dts) > 1 and (max(dts) - min(dts)) > dt_tol:
            bad.append("★ 同侧三轴 dt 不一致 f=%g %s: %s (跨度 %.2e)"
                       % (f, side, [round(x, 6) for x in dts], max(dts) - min(dts)))

    # 4 表 vs property
    try:
        nm = str(action.name)
        for prop, cache in ((xf._FEEL_PROP, xf._FEEL), (xf._TRILOCK_PROP, xf._TRILOCK),
                            (xf._OWNED_PROP, xf._plugin_owned_free)):
            raw = action.get(prop)
            has_cache = any(k[0] == nm for k in cache)
            if raw and not has_cache:
                bad.append("幽灵: %s 有 property 但内存表无条目" % prop)
    except Exception:
        pass
    return bad


# ---- 判定 / 输出 -----------------------------------------------------------

SUSPECT_KEYS = ("NaN", "Inf", "非有限", "不一致", "幽灵", "半写", "静默")


def flush(log_path, steps):
    """写结果 JSON（含 suspect 分级）。"""
    fails = [s for s in steps if not s[1]]
    suspects = [s for s in fails if any(k in s[0] for k in SUSPECT_KEYS)]
    data = {
        "total": len(steps),
        "fails": len(fails),
        "suspects": len(suspects),
        "result": "ALL PASS" if not fails else "HAS FAILURES",
        "steps": [{"name": n, "ok": ok, "detail": d} for n, ok, d in steps],
    }
    with open(log_path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())
    print("=" * 74)
    for n, ok, d in steps:
        print("[%s] %s  %s" % ("PASS" if ok else "FAIL", n, ("<- " + d) if d else ""))
    print("总计 %d 项 | PASS %d | FAIL %d | SUSPECT %d | %s"
          % (len(steps), len(steps) - len(fails), len(fails), len(suspects), data["result"]))
    return data
