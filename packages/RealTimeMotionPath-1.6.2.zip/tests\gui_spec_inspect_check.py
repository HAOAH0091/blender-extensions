# -*- coding: utf-8 -*-
"""运动路径校正 —— 回归测试（检测 + 微调 + 契约 + 注入 + 集成）。

背景（用户报障 → 讨论 → 设计定稿）
-----------------------------------
用户手动微调过 Graph Editor 之后，3D 视图里的手柄会**跟路径对不上**
（拖起来手感不对、方向不贴）。设计定稿见 `spec_check.py` docstring，
本文件守护它们。

★★★ 用户 2026-09-30 拍板的三条设计修正（最值钱的断言就在这几条上）
------------------------------------------------------------------
【修正一】折角**不是**违规，只是提示
    实测：折角 29.6° 时两侧手柄**仍然完全相切**（0.05° / 0.28°）。
    折角只跟【值分量】有关，相切只跟【时间分量】有关 —— 两件事独立。
    ⇒ 折角进 `report["hints"]`，不进 issues、不参与修复。
    ⇒ 守护断言：A4 / A21 / A22 / C7 / C8 / I10

【修正二】切向必须用「直线夹角 + 解析切向」
    用户报障：完全合规时**左侧**手柄算出 **179.92°** 偏离。
    根因：左侧手柄指向关键帧的"过去"，方向天然与前进方向相反。
    ⇒ 守护断言：A20 / A20b / I9

【修正三】手柄类型（④）与对齐锁定（⑤）不再单独报错，改成**自动前置**
    用户原话：「blender 默认追加关键帧的手柄类型就是 auto clamped，
    所以基本每次都会跳弹窗。是不是 GE 手柄类型相关的判断可以直接跳过？」
    ⇒ 守护断言：A7 / A8 / B3 / E6

★ 最值钱的几条断言（用户亲自提问）
----------------------------------
    A14 三角控制柄【单边调速】后 ⇒ **0 条 issue**（不误判）
    A16 单边调速后【左右 dt 不同】⇒ 不报（判据不跨侧）
    A20 ★★ 左侧切向参照正确（不再 179.92°）
    A21 ★★ 折角不破坏相切（决定性实验，独立实现做对照）
"""
import os
import sys
import json
import math
import inspect
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf
from RealTimeMotionPath import time_domain as td
from RealTimeMotionPath import drawing as dw
from RealTimeMotionPath import spec_check as sc
from RealTimeMotionPath import state as st
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_spec_check_result.json")
MID = 25.0
TOL = 1e-6

steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:420]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


# ---------------------------------------------------------------------------
# 场景工具
# ---------------------------------------------------------------------------
def curves(o):
    return {c.array_index: c for c in
            xf._position_curves(o.animation_data.action, o, None)}


def build(name):
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 3.0))):
        bpy.context.scene.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    bpy.context.scene.frame_set(1)
    for fc in curves(o).values():
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()
    return o, o.animation_data.action


def kp_at(o, frame, ax):
    for kp in curves(o)[ax].keyframe_points:
        if abs(kp.co[0] - frame) < 1e-3:
            return kp


def set_sym(o, frame, dv, dt, types=None, feel=None):
    """把左右手柄设成对称（左侧取负 = 正确镜像）。

    :param types: 手柄类型（'FREE' / 'ALIGNED' / 'AUTO_CLAMPED' / ...）
    :param feel:  登记体感（'LINK' / 'FREE' / 'VECTOR'）
                  —— 折角提示只在体感 'link' 时出现（E2）
    """
    for ax, fc in curves(o).items():
        kp = kp_at(o, frame, ax)
        if kp is None:
            continue
        kp.handle_right = (float(kp.co[0]) + dt, float(kp.co[1]) + dv[ax])
        kp.handle_left = (float(kp.co[0]) - dt, float(kp.co[1]) - dv[ax])
        if types:
            kp.handle_left_type = types
            kp.handle_right_type = types
    for fc in curves(o).values():
        fc.update()
    if feel:
        for ax in (0, 1, 2):
            kp = kp_at(o, frame, ax)
            if kp is None:
                continue
            xf.mark_feel(kp, 'left', feel)
            xf.mark_feel(kp, 'right', feel)


def kinds(report):
    return sorted(i["kind"] for i in report["issues"])


def hints(report):
    return sorted(i["kind"] for i in report["hints"])


def snapshot(o):
    """逐位快照（供"纯读"与"零变化"断言）。"""
    s = {}
    for ax, fc in curves(o).items():
        for kp in fc.keyframe_points:
            s[(ax, round(float(kp.co[0]), 4))] = (
                float(kp.co[1]), float(kp.handle_left[0]), float(kp.handle_left[1]),
                float(kp.handle_right[0]), float(kp.handle_right[1]),
                str(kp.handle_left_type), str(kp.handle_right_type))
    return s


def mk_dt(delta_y, tag="DT"):
    """造一个「只有 Y 轴 dt 不同」的场景，返回 detect 的 issues kinds。"""
    o, a = build("_SC_%s_%s" % (tag, delta_y))
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + delta_y, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    return kinds(sc.detect(a, o, None))


DV = {0: 1.0, 1: 0.5, 2: 0.25}
DT = 8.0


# ---------------------------------------------------------------------------
# 「真实相切」参照实现（独立于产品代码，供 A21 做对照）
# ---------------------------------------------------------------------------
def _p(o, t):
    cs = curves(o)
    return [float(cs[a].evaluate(t)) if a in cs else 0.0 for a in (0, 1, 2)]


def _sub(u, v):
    return [u[i] - v[i] for i in range(3)]


def _unit(v):
    n = math.sqrt(sum(x * x for x in v))
    return ([x / n for x in v] if n > 1e-12 else None)


def _path_corner(o, frame=MID, eps=0.05):
    """路径在该关键帧处的**真实转角**（度）—— 独立实现，不用产品公式。

    ★★ 这才是"看起来不相切"的根源：**3D 手柄折了 ⟺ 路径在那里拐角**。
      实测：用户工程 帧 90 —— 3D 手柄折了 12.42°，路径转角 12.46°。
    """
    tin = _unit(_sub(_p(o, frame), _p(o, frame - eps)))
    tout = _unit(_sub(_p(o, frame + eps), _p(o, frame)))
    if tin is None or tout is None:
        return None
    nu = math.sqrt(sum(x * x for x in tin))
    nv = math.sqrt(sum(x * x for x in tout))
    d = sum(tin[i] * tout[i] for i in range(3)) / (nu * nv)
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def _line_ang(u, v):
    nu = math.sqrt(sum(x * x for x in u))
    nv = math.sqrt(sum(x * x for x in v))
    if nu < 1e-12 or nv < 1e-12:
        return None
    d = sum(u[i] * v[i] for i in range(3)) / (nu * nv)
    a = math.degrees(math.acos(max(-1.0, min(1.0, d))))
    return min(a, 180.0 - a)


def real_tangency(o, frame=MID, eps=0.05):
    """用**真实路径的弦方向**判断两侧手柄是否相切（独立实现，不用产品公式）。

    返回 (左侧 vs 进入切向, 右侧 vs 离开切向) —— 都是【直线夹角】。
    """
    dv_l = []
    dv_r = []
    for ax in (0, 1, 2):
        kp = kp_at(o, frame, ax)
        dv_l.append(float(kp.handle_left[1] - kp.co[1]))
        dv_r.append(float(kp.handle_right[1] - kp.co[1]))
    tan_in = _unit(_sub(_p(o, frame), _p(o, frame - eps)))
    tan_out = _unit(_sub(_p(o, frame + eps), _p(o, frame)))
    aL = _line_ang([-x for x in dv_l], tan_in) if tan_in else None
    aR = _line_ang(dv_r, tan_out) if tan_out else None
    return aL, aR


# ===========================================================================
# A 组：检测器
# ===========================================================================
try:
    # ---- A1 合规 ⇒ 0 issue 0 hint ----
    o, a = build("_SC_A1")
    set_sym(o, MID, DV, DT)
    r = sc.detect(a, o, None)
    step("A1 完全合规 ⇒ 0 issue 且 0 hint", len(r["issues"]) == 0 and len(r["hints"]) == 0,
         "issues=%s hints=%s" % (kinds(r), hints(r)))

    # ---- A2 三轴 dt 8/14/6 ----
    o, a = build("_SC_A2")
    set_sym(o, MID, DV, DT)
    for ax, fc in curves(o).items():
        kp = kp_at(o, MID, ax)
        d = {0: 8.0, 1: 14.0, 2: 6.0}[ax]
        kp.handle_right = (float(kp.co[0]) + d, float(kp.handle_right[1]))
        fc.update()
    r = sc.detect(a, o, None)
    mm = [i for i in r["issues"] if i["kind"] == "dt_mismatch"]
    ang = mm[0]["metrics"]["angle_deg"] if mm else -1
    step("A2 三轴 dt 8/14/6 ⇒ 报 dt_mismatch（夹角 > 5°）",
         len(mm) == 1 and ang > 5.0, "kind=%s 夹角=%.2f°" % (kinds(r), ang))

    # ---- A3 只改 Y 轴 dt（8→14）----
    o, a = build("_SC_A3")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    mm = [i for i in r["issues"] if i["kind"] == "dt_mismatch"]
    ang = mm[0]["metrics"]["angle_deg"] if mm else -1
    step("A3 只改 Y 轴 dt（8→14）⇒ 报 dt_mismatch（夹角 ≈10.4°）",
         len(mm) == 1 and 8.0 < ang < 13.0, "夹角=%.4f°" % ang)

    # ---- A4 ★ 折角 ⇒ hint，不是 issue ----
    o, a = build("_SC_A4")
    set_sym(o, MID, DV, DT, feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    hb = [i for i in r["issues"] if i["kind"] == "handle_bend"]
    fold = hb[0]["metrics"]["fold_deg"] if hb else -1
    step("A4 ★★ 3D 手柄折了 ⇒ 报 handle_bend（**真问题**，会参与校正）",
         kinds(r) == ["handle_bend"] and 25.0 < fold < 35.0,
         "issues=%s 折了=%.4f°" % (kinds(r), fold))

    # ---- A5 体感 FREE + 折角 ⇒ 连 hint 都不报（E2）----
    o, a = build("_SC_A5")
    set_sym(o, MID, DV, DT, feel='FREE')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    step("A5 ★★ 体感=FREE 且 3D 手柄折了 ⇒ **不报**"
         "（用户口径：「除非路径手柄已经被用户提前设置成自由」）",
         len(r["issues"]) == 0 and len(r["hints"]) == 0,
         "issues=%s hints=%s" % (kinds(r), hints(r)))

    # ---- A6 缺 Z 轴中间帧 ----
    o, a = build("_SC_A6")
    set_sym(o, MID, DV, DT)
    fcz = curves(o)[2]
    for kp in [k for k in fcz.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
        fcz.keyframe_points.remove(kp)
    fcz.update()
    r = sc.detect(a, o, None)
    step("A6 缺 Z 轴中间帧 ⇒ 只报 missing_axis（E3 缺轴降级）",
         kinds(r) == ["missing_axis"], "kinds=%s" % kinds(r))

    # ---- A7 ★ 派生类型 ⇒ 不再单独报（改为自动前置）----
    for htype in ('AUTO_CLAMPED', 'VECTOR', 'AUTO'):
        o, a = build("_SC_A7_" + htype)
        set_sym(o, MID, DV, DT, types=htype)
        r = sc.detect(a, o, None)
        step("A7 ★ 类型=%s ⇒ **不报**（手柄类型改为自动前置，不再打扰用户）" % htype,
             "derived_type" not in kinds(r) and len(r["issues"]) == 0,
             "issues=%s hints=%s" % (kinds(r), hints(r)))

    # ---- A8 ★ ALIGNED + 三轴 dt 不等 ⇒ 只报 dt_mismatch ----
    o, a = build("_SC_A8")
    set_sym(o, MID, DV, DT, types='ALIGNED')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    step("A8 ★ ALIGNED + 三轴 dt 不等 ⇒ 报 dt_mismatch（不再有 aligned_unsynced）",
         "dt_mismatch" in kinds(r) and "aligned_unsynced" not in kinds(r),
         "kinds=%s" % kinds(r))

    # ---- A9 手柄过短 ⇒ 不报 ----
    o, a = build("_SC_A9")
    set_sym(o, MID, {0: 0.5, 1: 0.0, 2: 0.0}, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.co[1]))
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    step("A9 手柄过短（|dv| <= UNIFORM_LEN_MIN）⇒ 不报（与保速闸门同口径）",
         len(r["issues"]) == 0, "kinds=%s" % kinds(r))

    # ---- A10 端点段 ⇒ 不报 ----
    o, a = build("_SC_A10")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, 1.0, 1)
    kp.handle_left = (float(kp.co[0]) - 14.0, float(kp.handle_left[1]))
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    step("A10 端点段（首帧左）⇒ 不报（外侧手柄不画不抓）",
         len(r["issues"]) == 0, "kinds=%s" % kinds(r))

    # ---- A11 单关键帧 / 空输入 ----
    o, a = build("_SC_A11")
    for ax in (0, 1, 2):
        for _ in range(8):
            _fc = curves(o)[ax]
            _doomed = [k for k in _fc.keyframe_points if abs(k.co[0] - MID) > 1e-3]
            if not _doomed:
                break
            curves(o)[ax].keyframe_points.remove(_doomed[0])
        curves(o)[ax].update()
    r1 = sc.detect(a, o, None)
    r2 = sc.detect(None, None, None)
    step("A11 单关键帧 / None 输入 ⇒ 不崩且 0 条",
         r1["issues"] == [] and r2["issues"] == [],
         "single=%s none=%s" % (kinds(r1), kinds(r2)))

    # ---- A13 性能 ----
    o, a = build("_SC_A13")
    set_sym(o, MID, DV, DT)
    for i in range(300):
        f = 1.0 + i * 0.18
        bpy.context.scene.frame_set(int(f))
        o.location = (float(i) * 0.01, math.sin(i * 0.1) * 0.5, float(i) * 0.02)
        o.keyframe_insert("location", frame=f)
    r = sc.detect(a, o, None)
    step("A13 性能：900+ 关键帧 < 200ms", r["elapsed_ms"] < 200.0,
         "frames=%d elapsed=%.1fms" % (r["checked_frames"], r["elapsed_ms"]))
except Exception:
    step("EXCEPTION A", False, traceback.format_exc()[-700:])


# ===========================================================================
# A14~A19：合法状态豁免 + 阈值
# ===========================================================================
try:
    # ---- A14 ★★ 三角控制柄单边调速后 ⇒ 0 条 ----
    o, a = build("_SC_A14")
    set_sym(o, MID, DV, DT)
    r0 = sc.detect(a, o, None)
    td.apply_pixel_drag(a, o, MID, 'right', 45.0, bone_name=None)
    r1 = sc.detect(a, o, None)
    step("A14 ★★ 三角控制柄单边调速后 ⇒ **0 条 issue**（不误判为不贴合）",
         len(r0["issues"]) == 0 and len(r1["issues"]) == 0,
         "调整前=%s 调整后=%s" % (kinds(r0), kinds(r1)))

    dts = []
    for ax in (0, 1, 2):
        kp = kp_at(o, MID, ax)
        dts.append(abs(float(kp.handle_right[0] - kp.co[0])))
    step("A14b 三角调速后三轴 dt 仍相等（write_s 三轴同步）",
         max(dts) - min(dts) < 1e-6, "dt=%s" % [round(v, 6) for v in dts])

    # ---- A15 ★★ 三角调速 + 另一侧手动破坏 ⇒ 只报该报的 ----
    o, a = build("_SC_A15")
    set_sym(o, MID, DV, DT)
    td.apply_pixel_drag(a, o, MID, 'right', 45.0, bone_name=None)
    r_legit = sc.detect(a, o, None)
    kp = kp_at(o, MID, 1)
    kp.handle_left = (float(kp.handle_left[0]), float(kp.co[1]) - 1.6)
    for fc in curves(o).values():
        fc.update()
    r_bad = sc.detect(a, o, None)
    step("A15 ★★ 合法三角调整 + 另一侧手动破坏 ⇒ 报 handle_bend（不报 dt）",
         len(r_legit["issues"]) == 0 and kinds(r_bad) == ["handle_bend"],
         "合法时 issues=%s；破坏后 issues=%s"
         % (kinds(r_legit), kinds(r_bad)))

    # ---- A16 ★★ 单边调速后左右 dt 不同 ⇒ 不报（判据不跨侧）----
    o, a = build("_SC_A16")
    set_sym(o, MID, DV, DT)
    td.apply_pixel_drag(a, o, MID, 'right', 45.0, bone_name=None)
    dtr = abs(float(kp_at(o, MID, 0).handle_right[0] - kp_at(o, MID, 0).co[0]))
    dtl = abs(float(kp_at(o, MID, 0).handle_left[0] - kp_at(o, MID, 0).co[0]))
    r = sc.detect(a, o, None)
    step("A16 ★★ 单边调速后【左右 dt 不同】⇒ 不报 dt_mismatch（判据不跨侧）",
         abs(dtr - dtl) > 1e-6 and "dt_mismatch" not in kinds(r),
         "右 dt=%.4f 左 dt=%.4f ⇒ issues=%s" % (dtr, dtl, kinds(r)))

    # ---- A17 ★ 三角调速 + 某轴缺关键帧 ⇒ 只报 missing_axis ----
    o, a = build("_SC_A17")
    set_sym(o, MID, DV, DT)
    td.apply_pixel_drag(a, o, MID, 'right', 45.0, bone_name=None)
    fcz = curves(o)[2]
    for kp in [k for k in fcz.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
        fcz.keyframe_points.remove(kp)
    fcz.update()
    r = sc.detect(a, o, None)
    step("A17 ★ 三角调速 + 某轴缺关键帧 ⇒ 只报 missing_axis（缺轴降级）",
         kinds(r) == ["missing_axis"], "kinds=%s" % kinds(r))

    # ---- A18 ★ 阈值标定（解析切向，零误差）----
    k_in = mk_dt(8.16, "A18IN")      # 2%  ⇒ 解析 0.45°
    k_out = mk_dt(8.4, "A18OUT")     # 5%  ⇒ 解析 1.08°
    step("A18 ★ 阈值标定：dt 差 2% 不报、5% 报（证明阈值真的在起作用）",
         "dt_mismatch" not in k_in and "dt_mismatch" in k_out,
         "2%%→%s  5%%→%s" % (k_in, k_out))

    # ---- A19 ★ 合规场景零假角（解析切向没有差分误差）----
    o19, a19 = build("_SC_A19")
    set_sym(o19, MID, DV, DT)
    r19 = sc.detect(a19, o19, None)
    step("A19 ★ 完全合规 ⇒ 0 条（解析切向零误差，不再有差分假角）",
         len(r19["issues"]) == 0, "issues=%s" % kinds(r19))
except Exception:
    step("EXCEPTION A14-A19", False, traceback.format_exc()[-700:])


# ===========================================================================
# A20~A22：★ 三条设计修正的守护断言
# ===========================================================================
try:
    # ---- A20 ★★ 左侧切向参照正确（不再是 179.92°）----
    o, a = build("_SC_A20")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_left = (float(kp.co[0]) - 14.0, float(kp.handle_left[1]))
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    mm = [i for i in r["issues"] if i["kind"] == "dt_mismatch"]
    ang = mm[0]["metrics"]["angle_deg"] if mm else -1
    side = mm[0]["side"] if mm else "-"
    step("A20 ★★ 只改【左侧】dt ⇒ 报正确角度 ≈10.4°（**不是** 179.92°）",
         len(mm) == 1 and side == "left" and 8.0 < ang < 13.0,
         "side=%s 角度=%.4f°（旧实现会报 179.92°）" % (side, ang))

    o2, a2 = build("_SC_A20b")
    set_sym(o2, MID, DV, DT)
    kp2 = kp_at(o2, MID, 1)
    kp2.handle_right = (float(kp2.co[0]) + 14.0, float(kp2.handle_right[1]))
    for fc in curves(o2).values():
        fc.update()
    r2 = sc.detect(a2, o2, None)
    mm2 = [i for i in r2["issues"] if i["kind"] == "dt_mismatch"]
    ang2 = mm2[0]["metrics"]["angle_deg"] if mm2 else -1
    step("A20b ★ 左右对称：改右侧得同一角度（直线夹角一视同仁）",
         len(mm2) == 1 and abs(ang - ang2) < 1e-6,
         "左=%.4f° 右=%.4f°" % (ang, ang2))

    # ---- A21 ★★ 折角不破坏相切（决定性实验，独立实现做对照）----
    o, a = build("_SC_A21")
    set_sym(o, MID, DV, DT, feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    hb = [i for i in r["issues"] if i["kind"] == "handle_bend"]
    fold = hb[0]["metrics"]["fold_deg"] if hb else -1
    aL, aR = real_tangency(o)
    c = _path_corner(o)
    # ★★ 用户 2026-09-30 澄清后的正确认识：
    #    · "每侧手柄 vs 它那侧路径" 仍然相切（0.05° / 0.28°）—— 那是**速度大小**的事
    #    · 但 3D 手柄【线段】折了 ⇒ **路径在那一点拐角** —— 这才是"看起来不相切"
    step("A21 ★★ 3D 手柄折了 29.6° ⇒ 两侧各自仍相切（<1°），"
         "但**路径拐角 ≈ 折角** —— 所以必须校正",
         fold > 25.0 and aL is not None and aR is not None
         and aL < 1.0 and aR < 1.0
         and c is not None and abs(c - fold) < 1.5,
         "折了=%.3f°  路径转角=%.3f°  左vs进入=%.3f°  右vs离开=%.3f°"
         % (fold, c if c is not None else -1,
            aL if aL is not None else -1, aR if aR is not None else -1))

    o, a = build("_SC_A21b")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    aL2, aR2 = real_tangency(o)
    step("A21b ★ 对照：dt 不等**才**破坏相切（右侧偏离 > 5°）",
         aR2 is not None and aR2 > 5.0 and aL2 is not None and aL2 < 1.0,
         "左侧=%.3f°  右侧=%.3f°" % (aL2 if aL2 is not None else -1,
                                      aR2 if aR2 is not None else -1))

    # ---- A22 ★ hints 不触发弹窗（has_issues 只看 issues）----
    o, a = build("_SC_A22")
    set_sym(o, MID, DV, DT, feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    step("A22 ★★ 3D 手柄折了 ⇒ has_issues()=True ⇒ 会弹窗要求校正",
         len(r["issues"]) > 0 and sc.has_issues(r),
         "issues=%s has_issues=%s" % (kinds(r), sc.has_issues(r)))
except Exception:
    step("EXCEPTION A20-A22", False, traceback.format_exc()[-700:])


# ===========================================================================
# B 组：微调器
# ===========================================================================
def _paths(o, n=200):
    cs = curves(o)
    return [[float(cs[a].evaluate(1.0 + i * 54.0 / (n - 1.0))) if a in cs else 0.0
             for a in (0, 1, 2)] for i in range(n)]


def _hausdorff(A, B):
    m = 0.0
    for p in A:
        m = max(m, min(math.sqrt(sum((p[j] - q[j]) ** 2 for j in range(3)))
                       for q in B))
    return m


def _bend(o, frame=MID):
    """3D 手柄左右两半的夹角（度）。"""
    vl = [float(kp_at(o, frame, ax).handle_left[1] - kp_at(o, frame, ax).co[1])
          for ax in (0, 1, 2)]
    vr = [float(kp_at(o, frame, ax).handle_right[1] - kp_at(o, frame, ax).co[1])
          for ax in (0, 1, 2)]
    u1, u2 = _unit(vl), _unit([-x for x in vr])
    if u1 is None or u2 is None:
        return None
    d = sum(u1[i] * u2[i] for i in range(3))
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def _ge_fold(o, frame=MID, ax=1):
    """**GE 折角**（度）—— 该轴曲线在 (时间,值) 平面里左右手柄的夹角。

    ★★ 这才是用户说的"GE 里的关键帧手柄折角"（不是 3D 手柄折角）。
    独立实现，不用产品公式。
    """
    k = kp_at(o, frame, ax)
    dtl = float(k.handle_left[0] - k.co[0])
    dvl = float(k.handle_left[1] - k.co[1])
    dtr = float(k.handle_right[0] - k.co[0])
    dvr = float(k.handle_right[1] - k.co[1])
    nu = math.hypot(dtl, dvl)
    nv = math.hypot(-dtr, -dvr)
    if nu < 1e-12 or nv < 1e-12:
        return None
    d = (dtl * (-dtr) + dvl * (-dvr)) / (nu * nv)
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def _speeds(o, frame=MID, side='right'):
    """该侧三轴的**速度**（dv/dt，带符号）。"""
    out = []
    for ax in (0, 1, 2):
        k = kp_at(o, frame, ax)
        h = k.handle_left if side == 'left' else k.handle_right
        dt = float(h[0] - k.co[0])
        dv = float(h[1] - k.co[1])
        out.append(dv / dt if abs(dt) > 1e-9 else 0.0)
    return out


def _side_dts_at(o, frame, side):
    """该帧该侧三轴的 dt（绝对值）。"""
    out = []
    for ax in (0, 1, 2):
        k = kp_at(o, frame, ax)
        h = k.handle_left if side == 'left' else k.handle_right
        out.append(abs(float(h[0]) - float(k.co[0])))
    return out


def _side_dts(o, side, frame=MID):
    return _side_dts_at(o, frame, side)


def _side_off(o, side, frame=MID):
    """该侧手柄 vs 该侧路径切向的夹角（度）—— 独立实现。"""
    dv, dt = [], []
    for ax in (0, 1, 2):
        k = kp_at(o, frame, ax)
        h = k.handle_left if side == 'left' else k.handle_right
        dv.append(float(h[1] - k.co[1]))
        dt.append(float(h[0] - k.co[0]))
    if any(abs(x) < 1e-9 for x in dt):
        return None
    rate = [dv[i] / dt[i] for i in range(3)]
    u1, u2 = _unit(dv), _unit(rate)
    if u1 is None or u2 is None:
        return None
    d = sum(u1[i] * u2[i] for i in range(3))
    a = math.degrees(math.acos(max(-1.0, min(1.0, d))))
    return min(a, 180.0 - a)


def _handle_lens(o, frame=MID):
    out = []
    for side in ('left', 'right'):
        s = 0.0
        for ax in (0, 1, 2):
            kp = kp_at(o, frame, ax)
            h = kp.handle_left if side == 'left' else kp.handle_right
            s += (float(h[1] - kp.co[1])) ** 2
        out.append(math.sqrt(s))
    return out


try:
    # ---- B1 ③ 补轴：形状偏差 = 0 ----
    o, a = build("_FX_B1")
    set_sym(o, MID, DV, DT)
    fcz = curves(o)[2]
    for kp in [k for k in fcz.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
        fcz.keyframe_points.remove(kp)
    fcz.update()
    p_before = _paths(o)
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None, kinds=["missing_axis"])
    r2 = sc.detect(a, o, None)
    step("B1 ③ 补轴后该帧三轴齐全 + 无 missing_axis",
         len([1 for ax in (0, 1, 2) if kp_at(o, MID, ax)]) == 3
         and "missing_axis" not in kinds(r2),
         "kinds=%s" % kinds(r2))
    # ★★★ 2026-09-30（Phase 1 · D-5）：**阈值改了，理由如下**（不是为了让测试变绿）。
    #
    #   旧阈值 1e-5 是在「补轴只插关键帧、不管 dt」的年代定的（实测 7e-7）。
    #   但那样补出来的关键帧，Blender 给的时间分量与同侧老轴**对不上**
    #   （实测 dt：新轴 10.44/11.93 vs 老轴 8.0/8.0）⇒
    #     · `detect` 判「手柄贴合路径」用的就是「同侧三轴 dt 相等」，
    #       该侧实测偏离 **13.7°**（手柄肉眼可见地折了）；
    #     · 而 `detect` 又**不报**它（|dv| 落在它的「短手柄跳过」盲区附近），
    #       于是后续阶段只能靠 `fix_handle_bend` 去「掰直」——
    #       实测旧路径（关掉「补轴后立刻统一 dt」）总形变 **0.0886**。
    #   ⇒ D-5 的修法：补完轴**当场**把同侧三轴 dt 统一（并同比例缩放值分量保速），
    #     总形变降到 **0.0138**（比旧路径好 **6.4 倍**），且残留 issue = 0、偏离 0.00°。
    #   ⇒ 阈值取 0.05（路径长 7.99 的 **0.6%**）：足够抓住「补轴把路径改坏」的真回归，
    #     又容得下「为了满足插件自己的 dt 规范」必须付的那点代价。
    _haus = _hausdorff(p_before, _paths(o))
    step("B1b ③ 补轴不改动现有轨迹（阈值随 D-5 调整：< 0.6% 路径长）",
         _haus < 0.05,
         "haus=%.9f（路径长 %.4f）｜ 旧版 1e-5 阈值对应「补轴不管 dt」，"
         "但那样会留下 13.7° 的手柄偏离，且后续阶段形变 0.0886（是现在的 6.4 倍）"
         % (_haus, sum(math.dist(p_before[i], p_before[i + 1])
                        for i in range(len(p_before) - 1))))

    # ---- B2 ★ 冻结：坐标逐位不变 ----
    o, a = build("_FX_B2")
    set_sym(o, MID, DV, DT, types='AUTO_CLAMPED')
    s0 = snapshot(o)
    for ax in (0, 1, 2):
        sc._freeze_keyframe(kp_at(o, MID, ax))
    for fc in curves(o).values():
        fc.update()
    s1 = snapshot(o)
    step("B2 ★ 冻结成 FREE 后**坐标逐位不变**（只改类型）",
         all(s0[k][:5] == s1[k][:5] for k in s0 if k in s1) and s0.keys() == s1.keys(),
         "逐位一致=%s" % all(s0[k][:5] == s1[k][:5] for k in s0 if k in s1))
    step("B2b 类型确实变成 FREE 且体感被保住（转 FREE 后插件联动仍生效）",
         all(v[5] == 'FREE' and v[6] == 'FREE' for v in s1.values())
         and xf._link_mode(kp_at(o, MID, 0), 'right') == 'link',
         "types=%s link_mode=%s"
         % (sorted(set(v[5] for v in s1.values())),
            xf._link_mode(kp_at(o, MID, 0), 'right')))

    # ---- B2d ★★ 只转一侧 ⇒ 另一侧被重算吞掉 ----
    o, a = build("_FX_B2d")
    set_sym(o, MID, DV, DT, types='AUTO_CLAMPED')
    s_before = snapshot(o)
    for ax in (0, 1, 2):
        kp = kp_at(o, MID, ax)
        hl = kp.handle_left.copy()
        kp.handle_left_type = 'FREE'
        kp.handle_left = hl
    for fc in curves(o).values():
        fc.update()
    s_after = snapshot(o)
    hurt = [k for k in s_before if k in s_after
            and s_before[k][3:5] != s_after[k][3:5]]
    step("B2d ★★ 只转一侧 ⇒ 另一侧被重算吞掉（证明「必须两侧一起转」）",
         len(hurt) > 0,
         "被吞的右侧手柄 %d 处（例：%s  %s → %s）"
         % (len(hurt), hurt[0] if hurt else "-",
            s_before.get(hurt[0], ())[3:5] if hurt else "-",
            s_after.get(hurt[0], ())[3:5] if hurt else "-"))

    # ---- B3 ★ ALIGNED 下写 dt 不被反噬（自动冻结）----
    o, a = build("_FX_B3")
    set_sym(o, MID, DV, DT, types='ALIGNED')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    res, sn = sc.apply_fix(a, o, r, None, kinds=["dt_mismatch"])
    dts = [abs(float(kp_at(o, MID, ax).handle_right[0] - kp_at(o, MID, ax).co[0]))
           for ax in (0, 1, 2)]
    tset = set()
    for ax in (0, 1, 2):
        tset.add(str(kp_at(o, MID, ax).handle_left_type))
        tset.add(str(kp_at(o, MID, ax).handle_right_type))
    step("B3 ★ ALIGNED 下统一 dt ⇒ 三轴 dt 相等 + **自动冻结为 FREE**（不被反噬）",
         max(dts) - min(dts) < 1e-6 and tset == {'FREE'} and res.get("frozen", 0) > 0,
         "dt=%s types=%s frozen=%s"
         % ([round(v, 4) for v in dts], sorted(tset), res.get("frozen")))
    step("B3b 统一 dt 后 dt_mismatch 消失（handle_bend 是另一项，另修）",
         "dt_mismatch" not in kinds(sc.detect(a, o, None)),
         "issues=%s" % kinds(sc.detect(a, o, None)))

    # ---- B4 ① 统一 dt ----
    o, a = build("_FX_B4")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    p0 = _paths(o)
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None, kinds=["dt_mismatch"])
    dts = [abs(float(kp_at(o, MID, ax).handle_right[0] - kp_at(o, MID, ax).co[0]))
           for ax in (0, 1, 2)]
    step("B4 ① 统一 dt 后三轴 dt 相等 + 复检无 dt_mismatch",
         max(dts) - min(dts) < 1e-6
         and "dt_mismatch" not in kinds(sc.detect(a, o, None)),
         "dt=%s" % [round(v, 4) for v in dts])
    haus = _hausdorff(p0, _paths(o))
    step("B4b ① 形状偏差落在预期范围（0.1 ~ 0.4，实测约 0.23）",
         0.1 < haus < 0.4, "haus=%.4f" % haus)

    # ---- B4c ★ 统一 dt **不动手柄长度** ----
    o, a = build("_FX_B4c")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    lens0 = _handle_lens(o)
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None, kinds=["dt_mismatch"])
    lens1 = _handle_lens(o)
    step("B4c ★ 统一 dt **只动时间分量**，两侧手柄长度逐位不变",
         abs(lens0[0] - lens1[0]) < 1e-9 and abs(lens0[1] - lens1[1]) < 1e-9,
         "长度 %.6f/%.6f → %.6f/%.6f"
         % (lens0[0], lens0[1], lens1[0], lens1[1]))

    # ---- B7 幂等 ----
    o, a = build("_FX_B7")
    set_sym(o, MID, DV, DT, types='AUTO_CLAMPED')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None)
    r2 = sc.detect(a, o, None)
    step("B7 ★ 幂等：全量校正后复检 **0 issue**", len(r2["issues"]) == 0,
         "kinds=%s" % kinds(r2))

    # ---- B8 还原 ----
    o, a = build("_FX_B8")
    set_sym(o, MID, DV, DT, types='AUTO_CLAMPED')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    s0 = snapshot(o)
    r = sc.detect(a, o, None)
    result, snap = sc.apply_fix(a, o, r, None)
    sc.revert_fix(a, o, snap, None)
    s1 = snapshot(o)
    step("B8 ★ 还原：revert 后与校正前**逐位一致**（含类型）", s0 == s1,
         "差异键=%s" % [k for k in set(s0) | set(s1) if s0.get(k) != s1.get(k)][:4])

    # ---- B8b 还原会删掉补出来的关键帧 ----
    o, a = build("_FX_B8b")
    set_sym(o, MID, DV, DT)
    fcz = curves(o)[2]
    for kp in [k for k in fcz.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
        fcz.keyframe_points.remove(kp)
    fcz.update()
    n0 = len(snapshot(o))
    r = sc.detect(a, o, None)
    result, snap = sc.apply_fix(a, o, r, None, kinds=["missing_axis"])
    n1 = len(snapshot(o))
    sc.revert_fix(a, o, snap, None)
    n2 = len(snapshot(o))
    step("B8b ★ 还原会**删掉补出来的关键帧**（n0 == n2 < n1）",
         n0 == n2 and n1 > n0, "补轴前=%d 补轴后=%d 还原后=%d" % (n0, n1, n2))

    # ---- B9 ★ 校正不碰合法状态 ----
    o, a = build("_FX_B9")
    set_sym(o, MID, DV, DT)
    td.apply_pixel_drag(a, o, MID, 'right', 45.0, bone_name=None)
    legit_snap = snapshot(o)
    kp = kp_at(o, 55.0, 1)
    kp.handle_right = (float(kp.co[0]) + 20.0, float(kp.co[1]) + 1.2)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None)
    after = snapshot(o)
    mid_keys = [k for k in legit_snap if k[1] == MID]
    step("B9 ★★ 校正**不碰合法状态**：三角调速过的第 25 帧逐位不变",
         all(legit_snap[k] == after.get(k) for k in mid_keys),
         "第25帧键数=%d 全部一致=%s"
         % (len(mid_keys), all(legit_snap[k] == after.get(k) for k in mid_keys)))

    # ---- B10 ★★ 补轴 + 统一 dt 一起做 ----
    o, a = build("_FX_B10")
    set_sym(o, MID, DV, DT)
    fcz = curves(o)[2]
    for kp in [k for k in fcz.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
        fcz.keyframe_points.remove(kp)
    fcz.update()
    r = sc.detect(a, o, None)
    step("B10a 前置：缺轴场景确实报了 missing_axis",
         "missing_axis" in kinds(r), "kinds=%s" % kinds(r))
    sc.apply_fix(a, o, r, None, kinds=["missing_axis", "dt_mismatch"])
    r2 = sc.detect(a, o, None)
    step("B10b ★★ 补轴 + 统一 dt 一起做 ⇒ 这两类都消失（一次点确定就干净）",
         "missing_axis" not in kinds(r2) and "dt_mismatch" not in kinds(r2),
         "issues=%s hints=%s" % (kinds(r2), hints(r2)))
    dts = [abs(float(kp_at(o, MID, ax).handle_right[0] - kp_at(o, MID, ax).co[0]))
           for ax in (0, 1, 2)]
    step("B10c ★ 补出来的新帧也参与了三轴 dt 统一（不残留 Blender 默认值）",
         max(dts) - min(dts) < 1e-6, "dt=%s" % [round(v, 4) for v in dts])
    step("B10d ★ 补出来的新帧类型被冻结为 FREE（不是 ALIGNED 默认值）",
         all(str(kp_at(o, MID, ax).handle_right_type) == 'FREE'
             for ax in (0, 1, 2)),
         "types=%s" % [str(kp_at(o, MID, ax).handle_right_type) for ax in (0, 1, 2)])

    # ---- B11 ★ 默认勾选（= 弹窗点确定）⇒ 0 issue，只留 hints ----
    o, a = build("_FX_B11")
    set_sym(o, MID, DV, DT, types='AUTO_CLAMPED', feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    fcz = curves(o)[2]
    for kp in [k for k in fcz.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
        fcz.keyframe_points.remove(kp)
    fcz.update()
    r = sc.detect(a, o, None)
    _before = kinds(r)
    sc.apply_fix(a, o, r, None)     # kinds=None ⇒ DEFAULT_APPLY
    r2 = sc.detect(a, o, None)
    step("B11 ★★ 默认勾选（= 弹窗点「确定」）⇒ 0 issue（折角只留 hint）",
         len(r2["issues"]) == 0,
         "校正前=%s  校正后 issues=%s hints=%s" % (_before, kinds(r2), hints(r2)))
    # ---- B12 ★★ 强制对齐（可选平滑项）----
    #   用户口径：「勾选了只是强制把每个关键帧的进出速度对齐」
    o, a = build("_FX_B12")
    set_sym(o, MID, DV, DT, feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    step("B12a 3D 手柄折了 ⇒ 报 handle_bend（真问题）",
         kinds(r) == ["handle_bend"], "issues=%s" % kinds(r))
    c0 = _path_corner(o)
    L0 = _handle_lens(o)
    step("B12b ★ 折角 ⇒ 路径**确实有拐角**（> 5°，这就是用户看到的「折角」）",
         c0 is not None and c0 > 5.0, "路径转角=%.2f°" % (c0 if c0 is not None else -1))

    res, sn = sc.apply_fix(a, o, r, None, kinds=["handle_bend"])
    c1 = _path_corner(o)
    L1 = _handle_lens(o)
    step("B12c ★★ 对齐左右方向 ⇒ 路径拐角 → 0（进入方向 = 离开方向）",
         c1 is not None and c1 < 1.0,
         "%.2f° → %.2f°" % (c0 if c0 is not None else -1,
                            c1 if c1 is not None else -1))
    # ⚠️ 容差 1e-5：Blender 手柄坐标存 float32，精确到 1e-9 是做不到的
    step("B12d ★ 对齐左右方向 ⇒ 两侧手柄长度**不变**（只转方向，不改长度）",
         abs(L0[0] - L1[0]) < 1e-5 and abs(L0[1] - L1[1]) < 1e-5,
         "%.6f/%.6f → %.6f/%.6f" % (L0[0], L0[1], L1[0], L1[1]))
    r2 = sc.detect(a, o, None)
    step("B12e ★ 对齐后复检：0 条",
         len(r2["issues"]) == 0 and len(r2["hints"]) == 0,
         "issues=%s hints=%s" % (kinds(r2), hints(r2)))

    # ★★ 默认校正（不传 kinds）⇒ 拐角也消掉 —— 证明"默认就是要做"
    o, a = build("_FX_B12f")
    set_sym(o, MID, DV, DT, feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None)          # kinds=None ⇒ DEFAULT_APPLY（三项全做）
    c2 = _path_corner(o)
    r2b = sc.detect(a, o, None)
    step("B12f ★★ 默认校正（不传 kinds）⇒ 路径拐角 → 0 且复检 0 条"
         " —— 证明「默认就是要保证」",
         c2 is not None and c2 < 1.0 and len(r2b["issues"]) == 0,
         "路径转角=%.2f° issues=%s" % (c2 if c2 is not None else -1, kinds(r2b)))

    # ★★ E2 例外：体感 = 自由 ⇒ 不碰
    o, a = build("_FX_B12g")
    set_sym(o, MID, DV, DT, feel='FREE')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    s_free0 = snapshot(o)
    r = sc.detect(a, o, None)
    res_free, sn_free = sc.apply_fix(a, o, r, None)
    step("B12g ★★ E2 例外：体感=自由 ⇒ **不报也不改**"
         "（用户口径：「除非路径手柄已经被用户提前设置成自由」）",
         len(r["issues"]) == 0 and res_free["applied"].get("handle_bend", 0) == 0
         and s_free0 == snapshot(o),
         "issues=%s applied=%s" % (kinds(r), res_free["applied"]))

    # dt + bend 一起 ⇒ 既相切又无拐角
    o, a = build("_FX_B12h2")
    set_sym(o, MID, DV, DT, feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None, kinds=["dt_mismatch", "handle_bend"])
    c3 = _path_corner(o)
    r3 = sc.detect(a, o, None)
    step("B12h ★ dt + 对齐一起 ⇒ 路径**既相切又无拐角**",
         c3 is not None and c3 < 1.0 and len(r3["issues"]) == 0,
         "拐角=%.2f° issues=%s" % (c3 if c3 is not None else -1, kinds(r3)))

    # 还原
    o, a = build("_FX_B12h")
    set_sym(o, MID, DV, DT, feel='LINK')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    s0 = snapshot(o)
    r = sc.detect(a, o, None)
    result, snap = sc.apply_fix(a, o, r, None, kinds=["handle_bend"])
    sc.revert_fix(a, o, snap, None)
    step("B12i ★ 对齐后还原 ⇒ 逐位一致",
         s0 == snapshot(o),
         "差异键=%s" % [k for k in set(s0) | set(snapshot(o))
                        if s0.get(k) != snapshot(o).get(k)][:4])
    # ---- B13 ★★ 可选项「强制对齐全部 GE 手柄」（force_align）----
    #
    #  ★ 用户 2026-09-30 追加：
    #    「让用户可以选择是否把强制把 GE 的关键帧手柄都对齐，
    #      **当然这个对齐同时也要注意 dt 要一致**」
    #
    #  ★★ 核心：勾上后连**体感=自由**的手柄也一起规范，
    #     而且必须**同时统一 dt** —— 否则"直了却不贴路径"。

    # B13a：体感=自由 + 3D 手柄折了 ⇒ 默认**不修**（E2）
    o, a = build("_FX_B13a")
    set_sym(o, MID, DV, DT, feel='FREE')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    s0 = snapshot(o)
    r = sc.detect(a, o, None)
    res_d, _sn = sc.apply_fix(a, o, r, None)      # 默认（不含 force_align）
    step("B13a ★★ 体感=自由 + 折了 ⇒ **默认不修**（E2）",
         len(r["issues"]) == 0 and s0 == snapshot(o),
         "issues=%s 未改动=%s" % (kinds(r), s0 == snapshot(o)))

    # B13b：同一个场景，勾上 force_align ⇒ 折了 → 0
    b0 = _bend(o)
    res_f, _sn2 = sc.apply_fix(a, o, r, None, kinds=["force_align"])
    b1 = _bend(o)
    step("B13b ★★ 勾上 force_align ⇒ 体感=自由的手柄也被对齐（折了 → 0）",
         b0 is not None and b0 > 5.0 and b1 is not None and b1 < 1.0
         and res_f["applied"].get("force_align", 0) >= 1,
         "折了 %.2f° → %.2f°  applied=%s"
         % (b0 if b0 is not None else -1, b1 if b1 is not None else -1,
            res_f["applied"]))

    # B13c ★★ 用户特别提醒："这个对齐同时也要注意 dt 要一致"
    #   构造：体感=自由 + 右 Y 轴 dt 离群（三轴不等）+ 折了
    o, a = build("_FX_B13c")
    set_sym(o, MID, DV, DT, feel='FREE')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    dt0 = _side_dts(o, 'right')
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None, kinds=["force_align"])
    dt1 = _side_dts(o, 'right')
    spread1 = max(dt1) - min(dt1) if dt1 else -1
    step("B13c ★★ force_align **同时统一 dt**（勾上后同侧三轴 dt 相等）"
         " —— 用户特别提醒过",
         dt0 and (max(dt0) - min(dt0)) > 1.0 and dt1 and spread1 < 1e-6,
         "右 dt %s → %s（跨度 %.6f）"
         % ([round(x, 4) for x in dt0], [round(x, 4) for x in dt1], spread1))

    # B13d：force_align 之后该侧**贴住路径**（dt 均匀 + 方向对齐）
    off = _side_off(o, 'right')
    c = _path_corner(o)
    step("B13d ★★ force_align 后：右侧贴住路径（<1°）且路径无拐角（<1°）",
         off is not None and off < 1.0 and c is not None and c < 1.0,
         "右偏离=%.3f°  路径转角=%.3f°"
         % (off if off is not None else -1, c if c is not None else -1))

    # B13e ★ 最小干预：已经合规的帧**连手柄类型都不动**（不冻结）
    o, a = build("_FX_B13e")
    set_sym(o, MID, DV, DT, feel='LINK')
    for fc in curves(o).values():
        for k in fc.keyframe_points:
            k.handle_left_type = 'ALIGNED'
            k.handle_right_type = 'ALIGNED'
    for fc in curves(o).values():
        fc.update()
    types0 = {(ax, round(float(k.co[0]), 3)): (str(k.handle_left_type),
                                               str(k.handle_right_type))
              for ax, fc in curves(o).items() for k in fc.keyframe_points}
    r = sc.detect(a, o, None)
    res_e, _sn3 = sc.apply_fix(a, o, r, None, kinds=["force_align"])
    types1 = {(ax, round(float(k.co[0]), 3)): (str(k.handle_left_type),
                                               str(k.handle_right_type))
              for ax, fc in curves(o).items() for k in fc.keyframe_points}
    step("B13e ★ force_align 对**已经合规**的帧是空操作（不冻结类型）",
         res_e["applied"].get("force_align", 0) == 0 and types0 == types1,
         "applied=%s 类型未变=%s" % (res_e["applied"], types0 == types1))

    # B13f ★ 外侧手柄（首帧左）也被规范 —— 这正是 dt_mismatch/handle_bend 跳过的那种
    #
    #  ⚠️ 必须给它一个**真实的 dv**：首帧左侧手柄若 dv=0（退化），
    #     方向无从判断（`_side_is_off_path` 返回 None）⇒ 不该动它。
    #     真实工程里外侧手柄的 dv 是正常值（用户工程实测 [-112.5, -46.0, 31.6]）。
    o, a = build("_FX_B13f")
    set_sym(o, MID, DV, DT, feel='LINK')
    for ax in (0, 1, 2):                        # 首帧左：dv 正常，dt 三轴不等
        k0 = kp_at(o, 1.0, ax)
        dt_a = (8.0, 2.0, 8.0)[ax]
        k0.handle_left = (float(k0.co[0]) - dt_a, float(k0.co[1]) - DV[ax])
        k0.handle_right = (float(k0.co[0]) + 8.0, float(k0.co[1]) + DV[ax])
    for fc in curves(o).values():
        fc.update()
    left0 = _side_dts_at(o, 1.0, 'left')
    r = sc.detect(a, o, None)
    res_g, _sn4 = sc.apply_fix(a, o, r, None, kinds=["force_align"])
    left1 = _side_dts_at(o, 1.0, 'left')
    step("B13f ★ 首帧**外侧手柄**也被规范（force_align 覆盖 ②③ 跳过的那种）",
         left0 and (max(left0) - min(left0)) > 0.5
         and left1 and (max(left1) - min(left1)) < 1e-6,
         "首帧左 dt %s → %s"
         % ([round(x, 4) for x in left0], [round(x, 4) for x in left1]))

    # B13g ★ 默认（不勾）时外侧手柄**不动**
    o, a = build("_FX_B13g")
    set_sym(o, MID, DV, DT, feel='LINK')
    for ax in (0, 1, 2):
        k0 = kp_at(o, 1.0, ax)
        dt_a = (8.0, 2.0, 8.0)[ax]
        k0.handle_left = (float(k0.co[0]) - dt_a, float(k0.co[1]) - DV[ax])
        k0.handle_right = (float(k0.co[0]) + 8.0, float(k0.co[1]) + DV[ax])
    for fc in curves(o).values():
        fc.update()
    s_g0 = snapshot(o)
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None)                  # 默认
    step("B13g ★ 默认（不勾 force_align）⇒ 外侧手柄**不动**",
         s_g0 == snapshot(o), "未改动=%s" % (s_g0 == snapshot(o)))

    # B13i ★★ **GE 手柄共线**（这才是"强制对齐关键帧进出速度"的真正目标）
    o, a = build("_FX_B13i")
    set_sym(o, MID, DV, DT, feel='FREE')
    #  造出真实的"GE 折角"：左右 dt 不等 + 左右长度比例不匹配
    for ax in (0, 1, 2):
        k = kp_at(o, MID, ax)
        k.handle_right = (float(k.co[0]) + 10.0, float(k.co[1]) + DV[ax] * 2.0)
        k.handle_left = (float(k.co[0]) - 4.0, float(k.co[1]) - DV[ax] * 1.0)
    for fc in curves(o).values():
        fc.update()
    g0 = [_ge_fold(o, MID, ax) for ax in (0, 1, 2)]
    r = sc.detect(a, o, None)
    sc.apply_fix(a, o, r, None, kinds=["force_align"])
    g1 = [_ge_fold(o, MID, ax) for ax in (0, 1, 2)]
    #  ⚠️ 阈值 0.01°（不是 1e-6）：手柄坐标存 float32，逐位相等做不到。
    step("B13i ★★ force_align ⇒ **GE 手柄共线**（逐轴折角 → 0）",
         all(x is not None and x > 0.3 for x in g0)
         and all(x is not None and x < 0.01 for x in g1),
         "GE 折角 %s → %s"
         % ([round(x, 3) for x in g0], ["%.2e" % x for x in g1]))

    # B13j ★★ 字面意义：**进出速度相等**
    sl = _speeds(o, MID, 'left')
    sr = _speeds(o, MID, 'right')
    step("B13j ★★ force_align ⇒ 进出**速度**逐轴相等（vL == vR）",
         all(abs(sl[i] - sr[i]) < 1e-4 for i in range(3))
         and all(abs(x) > 1e-6 for x in sl),
         "vL=%s  vR=%s" % ([round(x, 5) for x in sl], [round(x, 5) for x in sr]))

    # B13k ★ 速度方向没被翻转（踩过的符号坑）
    step("B13k ★ 速度方向**没被翻转**（符号坑）—— vL/vR 与原方向同号",
         all(x > 0 for x in sl) and all(x > 0 for x in sr),
         "vL=%s vR=%s" % ([round(x, 5) for x in sl], [round(x, 5) for x in sr]))

    # B13l ★ 仍然与路径相切（同侧三轴 dt 相等）
    dtl = _side_dts_at(o, MID, 'left')
    dtr = _side_dts_at(o, MID, 'right')
    step("B13l ★ force_align 后同侧三轴 dt 仍相等 ⇒ **仍与路径相切**",
         (max(dtl) - min(dtl)) < 1e-6 and (max(dtr) - min(dtr)) < 1e-6,
         "dtL=%s dtR=%s" % ([round(x, 3) for x in dtl], [round(x, 3) for x in dtr]))

    # B13h ★ 可还原
    o, a = build("_FX_B13h")
    set_sym(o, MID, DV, DT, feel='FREE')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    s_h0 = snapshot(o)
    r = sc.detect(a, o, None)
    _r, sn_h = sc.apply_fix(a, o, r, None, kinds=["force_align"])
    sc.revert_fix(a, o, sn_h, None)
    step("B13h ★ force_align 后还原 ⇒ 逐位一致",
         s_h0 == snapshot(o),
         "差异键=%s" % [k for k in set(s_h0) | set(snapshot(o))
                        if s_h0.get(k) != snapshot(o).get(k)][:4])
except Exception:
    step("EXCEPTION B", False, traceback.format_exc()[-700:])


# ===========================================================================
# C 组：契约
# ===========================================================================
try:
    step("C1a MIN_HANDLE_LEN 是 xf.UNIFORM_LEN_MIN 的引用（不是第二份定义）",
         sc.MIN_HANDLE_LEN == xf.UNIFORM_LEN_MIN,
         "sc=%.6f xf=%.6f" % (sc.MIN_HANDLE_LEN, xf.UNIFORM_LEN_MIN))
    step("C1b 外侧判据复用 drawing._endpoint_is_hidden_side",
         "drawing._endpoint_is_hidden_side" in inspect.getsource(sc), "ok")
    step("C1c 联动判据复用 xf._link_mode（不自己写体感映射）",
         "xf._link_mode" in inspect.getsource(sc), "ok")
    _det_src = inspect.getsource(sc.detect)
    step("C1d ★ 检测器不写体感（detect 源码里没有 mark_feel）",
         "mark_feel" not in _det_src,
         "detect 里 mark_feel 出现次数=%d" % _det_src.count("mark_feel"))

    o, a = build("_SC_C2")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    b0 = snapshot(o)
    r = sc.detect(a, o, None)
    b1 = snapshot(o)
    step("C2 ★ 检测器**纯读**：跑一遍前后所有 fcurve 逐位不变",
         b0 == b1 and len(r["issues"]) > 0,
         "逐位一致=%s（且确实检出了 %d 条）" % (b0 == b1, len(r["issues"])))

    step("C3 ★ 阈值 = 1.0°；**不再有** TANGENT_EPS（解析切向零误差）",
         sc.ANGLE_EPS_DEG == 1.0 and not hasattr(sc, "TANGENT_EPS"),
         "ANGLE_EPS_DEG=%r has_TANGENT_EPS=%s"
         % (sc.ANGLE_EPS_DEG, hasattr(sc, "TANGENT_EPS")))

    _ui_src = inspect.getsource(__import__("RealTimeMotionPath.spec_ui",
                                           fromlist=["x"]))
    step("C4 界面文案全部走 iface_()（i18n_gate 过）",
         "iface_" in _ui_src, "ok")

    step("C5 detect / has_issues / summarize / KIND_LABEL / apply_fix / revert_fix 都在",
         all(hasattr(sc, n) for n in ("detect", "has_issues", "summarize",
                                      "KIND_LABEL", "apply_fix", "revert_fix")),
         "KIND_LABEL 项数=%d" % len(sc.KIND_LABEL))

    o, a = build("_SC_C6")
    set_sym(o, MID, DV, DT)
    for ax in (1, 2):
        fc = curves(o)[ax]
        for kp in [k for k in fc.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
            fc.keyframe_points.remove(kp)
        fc.update()
    ok = True
    try:
        r = sc.detect(a, o, None)
    except Exception:
        ok = False
    step("C6 ★ 只留一个轴有手柄 ⇒ 检测器不抛异常（缺轴守卫）", ok,
         "kinds=%s" % (kinds(r) if ok else "EXC"))

    # ★★ 用户 2026-09-30 最终口径：「这个本来就是要保证的，不是选不选的问题，
    #    本来就是要校正这个，除非路径手柄已经被用户提前设置成自由」
    #    ⇒ 三项全部默认做；没有"可选"项。
    step("C7 ★★ 三项**默认做** + 一项**可选**（force_align 默认 False）",
         hasattr(sc, "fix_handle_bend") and hasattr(sc, "fix_force_align")
         and set(sc.DEFAULT_APPLY.keys()) == {"missing_axis", "dt_mismatch",
                                              "handle_bend", "force_align"}
         and sc.DEFAULT_APPLY["missing_axis"] is True
         and sc.DEFAULT_APPLY["dt_mismatch"] is True
         and sc.DEFAULT_APPLY["handle_bend"] is True
         and sc.DEFAULT_APPLY["force_align"] is False
         and list(sc.FIX_ORDER) == ["missing_axis", "dt_mismatch",
                                    "handle_bend", "force_align"],
         "DEFAULT_APPLY=%s FIX_ORDER=%s" % (sorted(sc.DEFAULT_APPLY), list(sc.FIX_ORDER)))
    step("C7b ★ 3D 手柄折了在 issues 里（真问题）；旧名 not_collinear 已不存在",
         "handle_bend" in sc.KIND_LABEL and "not_collinear" not in sc.KIND_LABEL,
         "KIND_LABEL=%s" % sorted(sc.KIND_LABEL))

    # ⚠️ bpy.props 定义的属性**不在 Python 类的 dir() 里**（Blender 元类把它们
    #    搬进了 bl_rna）⇒ 必须查 bl_rna.properties。
    # ⚠️ 取属性的**正确姿势**（实测踩了三次）：
    #    · `bpy.types.RTMP_OT_SpecFix` 在 background 下**取不到**（AttributeError）
    #    · `Class.bl_rna.properties` 只列**基类** operator 的属性，
    #      自定义的 do_* **不在里面**（Blender 对 operator 属性是惰性展开的）
    #    · `dir(Class)` 也看不到（bpy.props 被元类从 __dict__ 搬走了）
    #    ⇒ 唯一可靠的是 `__annotations__`（= 源码里声明的那些）。
    _sui_mod = __import__("RealTimeMotionPath.spec_ui", fromlist=["x"])
    _props = list(getattr(_sui_mod.RTMP_OT_SpecFix, "__annotations__", {}).keys())
    _fix_props = [p for p in _props if p.startswith("do_")]
    step("C8 ★★ 弹窗只有 2 个勾选项：可选对齐 + 本次不再提示",
         set(_fix_props) == {"do_force_align", "do_ignore"},
         "do_* 属性=%s" % sorted(_fix_props))
    step("C8b ★ 弹窗**没有**共线策略属性（策略不暴露给用户，内部固定 bisect）",
         not any("strategy" in p for p in _props)
         and sc.COLLINEAR_DEFAULT == 'bisect',
         "COLLINEAR_DEFAULT=%s" % sc.COLLINEAR_DEFAULT)
except Exception:
    step("EXCEPTION C", False, traceback.format_exc()[-700:])


# ===========================================================================
# E 组：集成（触发链路 / 无静默改写 / 忽略表）
# ===========================================================================
try:
    from RealTimeMotionPath import spec_ui as sui

    o, a = build("_E1")
    set_sym(o, MID, DV, DT)
    r = sc.detect(a, o, None)
    step("E1 合规场景：检测 0 条 ⇒ 调用方不会弹窗",
         len(r["issues"]) == 0 and not sc.has_issues(r), "kinds=%s" % kinds(r))

    _session.spec_ignored = set()
    o2, a2 = build("_E2")
    set_sym(o2, MID, DV, DT)
    sui.mark_ignored(o2, a2, None)
    same = sui.is_ignored(o2, a2, None)
    o3, a3 = build("_E2b")
    set_sym(o3, MID, DV, DT)
    other = sui.is_ignored(o3, a3, None)
    step("E2 ★ 忽略表：同对象生效、**换对象自动失效**（不会永久失明）",
         same and not other, "同对象=%s 换对象=%s" % (same, other))
    _session.spec_ignored = set()

    _src = inspect.getsource(__import__("RealTimeMotionPath.interaction",
                                        fromlist=["x"]).update_custom_path_active)
    _lines = [l.strip() for l in _src.splitlines()]
    _first_level_ensure = False
    _in_guarded = 0
    for i, l in enumerate(_lines):
        if "ensure_location_keyframes" not in l:
            continue
        _ctx = "\n".join(_lines[max(0, i - 6):i])
        if "is_ignored" in _ctx or "not _checked" in _ctx:
            _in_guarded += 1
        elif not l.startswith("#"):
            _first_level_ensure = True
    step("E3 ★★ 开关路径的入口**不再无条件静默补轴**（补轴只出现在两个有条件分支）",
         "check_and_maybe_popup" in _src and not _first_level_ensure
         and _in_guarded >= 2,
         "含检查调用=%s  无守卫的补轴=%s  有守卫的补轴=%d"
         % ("check_and_maybe_popup" in _src, _first_level_ensure, _in_guarded))

    step("E4 兜底：检查异常时保留旧行为（_checked 标记 + 回退补轴）",
         "_checked" in _src and "if not _checked" in _src,
         "含 _checked 兜底=%s" % ("if not _checked" in _src))

    step("E5 四个 operator 齐备（inspect / fix / revert / ignore）",
         all(hasattr(bpy.ops.rtmp, n) for n in
             ("spec_inspect", "spec_fix", "spec_revert", "spec_ignore")),
         "齐备")

    _ui_src2 = inspect.getsource(__import__("RealTimeMotionPath.spec_ui",
                                            fromlist=["x"]))
    # ★★ 用户口径「根本不用选，默认就是要」⇒ 校正项不再有勾选项
    _exe2 = inspect.getsource(__import__("RealTimeMotionPath.spec_ui",
                                          fromlist=["x"]).RTMP_OT_SpecFix.execute)
    step("E6 ★★ 弹窗**不再有校正项勾选项**：execute 传 kinds=None（三项全做）",
         "do_dt" not in _ui_src2 and "do_missing" not in _ui_src2
         and "do_align" not in _ui_src2
         and "kinds = None" in _exe2,
         "无 do_* 校正项=%s  kinds=None=%s"
         % (not any(k in _ui_src2 for k in ("do_dt", "do_missing", "do_align")),
            "kinds = None" in _exe2))

    o7, a7 = build("_E7")
    set_sym(o7, MID, DV, DT)
    ok7 = True
    try:
        sc.detect(a7, o7, None)
    except Exception:
        ok7 = False
    step("E7 检测器不依赖 bpy.context（可在 headless 下运行）", ok7, "ok=%s" % ok7)

    # ---- E8 ★★ 只有折角提示时，弹窗也必须能开（否则「强制对齐」够不到）----
    #
    #  ★ 用户实测抓到的真实问题：
    #    他的工程 issues = 0（只有折角提示）⇒ 旧的 invoke 直接 CANCELLED
    #    ⇒ 报「手柄已经贴合路径」⇒ 弹窗打不开 ⇒ **可选项够不到**。
    _inv_src = inspect.getsource(__import__("RealTimeMotionPath.spec_ui",
                                            fromlist=["x"]).RTMP_OT_SpecFix.invoke)
    step("E8 ★★ invoke 在「有 issues **或** hints」时都开弹窗"
         "（hints 目前恒空，但保留该判定以防将来有纯信息项）",
         "hints" in _inv_src, "invoke 含 hints 判定=%s" % ("hints" in _inv_src))

    _exe_src = inspect.getsource(__import__("RealTimeMotionPath.spec_ui",
                                            fromlist=["x"]).RTMP_OT_SpecFix.execute)
    step("E8b ★★ execute **不再**要求「必须有 issues」"
         "（handle_bend 直接遍历 action，不依赖报告）",
         "Handles already follow the path" not in _exe_src,
         "execute 里无 issues 守卫=%s" % ("Handles already follow the path" not in _exe_src))

    _drw_src = inspect.getsource(__import__("RealTimeMotionPath.spec_ui",
                                            fromlist=["x"]).RTMP_OT_SpecFix.draw)
    step("E8c ★ draw 在没有 issues 时也给出说明行（不留空白弹窗）",
         "Handles follow the path - nothing to fix" in _drw_src,
         "含空问题说明=%s" % ("Handles follow the path - nothing to fix" in _drw_src))
except Exception:
    step("EXCEPTION E", False, traceback.format_exc()[-700:])


# ===========================================================================
# D 组：bug 注入（证明测试有区分度）
# ===========================================================================
def _check_A1():
    o, a = build("_INJ_A1")
    set_sym(o, MID, DV, DT)
    return len(sc.detect(a, o, None)["issues"]) == 0


def _check_A3():
    o, a = build("_INJ_A3")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
    for fc in curves(o).values():
        fc.update()
    return "dt_mismatch" in kinds(sc.detect(a, o, None))


def _check_A14():
    o, a = build("_INJ_A14")
    set_sym(o, MID, DV, DT)
    td.apply_pixel_drag(a, o, MID, 'right', 45.0, bone_name=None)
    return len(sc.detect(a, o, None)["issues"]) == 0


def _check_A5():
    o, a = build("_INJ_A5")
    set_sym(o, MID, DV, DT, feel='FREE')
    kp = kp_at(o, MID, 1)
    kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
    for fc in curves(o).values():
        fc.update()
    return len(sc.detect(a, o, None)["issues"]) == 0


def _check_A20():
    """左侧 dt 不等 ⇒ 角度必须是 ~10.4°（不是 179.9°）。"""
    o, a = build("_INJ_A20")
    set_sym(o, MID, DV, DT)
    kp = kp_at(o, MID, 1)
    kp.handle_left = (float(kp.co[0]) - 14.0, float(kp.handle_left[1]))
    for fc in curves(o).values():
        fc.update()
    mm = [i for i in sc.detect(a, o, None)["issues"] if i["kind"] == "dt_mismatch"]
    return bool(mm) and mm[0]["side"] == "left" and mm[0]["metrics"]["angle_deg"] < 20.0


def _check_C7():
    return (hasattr(sc, "fix_handle_bend")
            and sc.DEFAULT_APPLY["missing_axis"] is True
            and sc.DEFAULT_APPLY["dt_mismatch"] is True
            and sc.DEFAULT_APPLY["handle_bend"] is True
            and sc.DEFAULT_APPLY["force_align"] is False
            and set(sc.DEFAULT_APPLY.keys()) == {"missing_axis", "dt_mismatch",
                                                 "handle_bend", "force_align"})


def _check_C2():
    o, a = build("_INJ_C2")
    set_sym(o, MID, DV, DT)
    b0 = snapshot(o)
    sc.detect(a, o, None)
    return b0 == snapshot(o)


try:
    base = (_check_A1(), _check_A3(), _check_A14(), _check_A5(),
            _check_A20(), _check_C7(), _check_C2())
    step("D0 注入前基线：七个检查未注入时全 True", all(base),
         "A1/A3/A14/A5/A20/C7/C2 = %s" % (base,))

    # ---- I2 阈值改成 0 ----
    _o_eps = sc.ANGLE_EPS_DEG
    sc.ANGLE_EPS_DEG = 0.0
    try:
        caught = "dt_mismatch" in mk_dt(8.16, "I2")
    finally:
        sc.ANGLE_EPS_DEG = _o_eps
    step("★ I2 阈值改成 0（任何抖动都报）⇒ 微小抖动被误报 ⇒ 测试抓住",
         caught, "2%% 抖动被报=%s" % caught)

    # ---- I3 阈值改成 90° ----
    sc.ANGLE_EPS_DEG = 90.0
    try:
        caught = not _check_A3()
    finally:
        sc.ANGLE_EPS_DEG = _o_eps
    step("★ I3 阈值改成 90°（什么都抓不到）⇒ A3 抓不住 ⇒ 测试抓住",
         caught, "A3 变红=%s" % caught)

    # ---- I7 ★★ 判据改成"跨侧比较" ----
    #
    #  ⚠️ 注入点必须是 `_side_is_off_path`（**唯一的判据入口**）：
    #     旧版本注入 `_dt_spread` 已经失效 —— 判据重构后 spread 只用于**显示**，
    #     不再参与触发（I7 变红正是抓到这件事）。
    #
    #  A14 与 I7 的分工：
    #     · A14 守"判据本身没被改成跨侧比较"（三角调速后必须 0 条）
    #     · I7  守"detect 确实走这个入口"（绕过它 I7 就抓不住）
    _o_seam = sc._side_is_off_path
    sc._side_is_off_path = lambda dv_vec, dt_vec: 99.0
    try:
        caught = not _check_A14()
    finally:
        sc._side_is_off_path = _o_seam
    step("★★ I7 判据入口被替换成「一律判为偏离」⇒ 三角调速被误判 ⇒ 测试抓住（A14）",
         caught, "A14 变红=%s" % caught)

    # ---- I8 ★★ 折角提示去掉 _link_mode 守卫 ----
    _o_link = sc.xf._link_mode
    sc.xf._link_mode = lambda kp, moved_side: 'link'
    try:
        caught = not _check_A5()
    finally:
        sc.xf._link_mode = _o_link
    step("★★ I8 去掉 _link_mode 守卫（无条件要求共线）⇒ 体感 FREE 被误报 ⇒ 测试抓住（A5）",
         caught, "A5 变红=%s" % caught)

    # ---- I9 ★★ 把「直线夹角」改回「方向夹角」 ----
    _o_line = sc._line_angle_deg
    sc._line_angle_deg = sc._angle_deg          # 退回"方向夹角"
    try:
        caught = not _check_A20()
    finally:
        sc._line_angle_deg = _o_line
    step("★★ I9 把「直线夹角」改回「方向夹角」⇒ 左侧算出 ~180° ⇒ 测试抓住（A20）",
         caught, "A20 变红=%s（这就是用户报障的那个 bug）" % caught)

    # ---- I10 ★★ 把「3D 手柄折了」改成默认不做 ----
    #   用户口径：「这个本来就是要保证的，不是选不选的问题」⇒ 默认必须做。
    _o_da = dict(sc.DEFAULT_APPLY)
    sc.DEFAULT_APPLY["handle_bend"] = False
    try:
        caught = not _check_C7()
    finally:
        sc.DEFAULT_APPLY.clear()
        sc.DEFAULT_APPLY.update(_o_da)
    step("★★ I10 把「3D 手柄折了」改成默认不做 ⇒ 测试抓住（C7，守住「默认就做」）",
         caught, "C7 变红=%s" % caught)

    # ---- I11 ★★ 把 force_align 改成默认勾选 ----
    #   它是**唯一**的可选项，默认必须是 False（用户要"可选"）。
    _o_da2 = dict(sc.DEFAULT_APPLY)
    sc.DEFAULT_APPLY["force_align"] = True
    try:
        caught2 = not _check_C7()
    finally:
        sc.DEFAULT_APPLY.clear()
        sc.DEFAULT_APPLY.update(_o_da2)
    step("★★ I11 把 force_align 改成默认勾选 ⇒ 测试抓住（C7，守住「可选」）",
         caught2, "C7 变红=%s" % caught2)

    # ---- I4 ★ 只转一侧 ----
    _o_fsp = sc._freeze_side_preserving

    def _one_side_only(kp, side, feel_value=None):
        try:
            hl = kp.handle_left.copy()
            hr = kp.handle_right.copy()
            if side == 'left':
                kp.handle_left_type = 'FREE'
                kp.handle_left = hl
            else:
                kp.handle_right_type = 'FREE'
                kp.handle_right = hr
        except Exception:
            pass
        return True
    sc._freeze_side_preserving = _one_side_only
    try:
        o, a = build("_INJ_I4")
        set_sym(o, MID, DV, DT, types='AUTO_CLAMPED')
        s0 = snapshot(o)
        for ax in (0, 1, 2):
            sc._freeze_side_preserving(kp_at(o, MID, ax), 'left')
        for fc in curves(o).values():
            fc.update()
        s1 = snapshot(o)
        caught = not all(s0[k][:5] == s1[k][:5] for k in s0 if k in s1)
    finally:
        sc._freeze_side_preserving = _o_fsp
    step("★★ I4 「只转一侧」（另一侧仍派生 ⇒ 被重算吞掉）⇒ 测试抓住（B2）",
         caught, "B2 变红=%s" % caught)

    # ---- I5 ★ 统一 dt 时"写同一个 s" ----
    _o_fixdt = sc.fix_unify_dt

    def _wrong_unify(action, obj, report, bone_name=None, snap=None):
        spans = {}
        for ax, fc in sc._axis_curves(action, obj, bone_name).items():
            spans[ax] = 1.0 + ax * 0.5
        for it in (report or {}).get("issues", []):
            if it.get("kind") != "dt_mismatch":
                continue
            frame, side = float(it["frame"]), it.get("side")
            for ax, fc in sc._axis_curves(action, obj, bone_name).items():
                kp = xf.keyframe_at(fc, frame)
                if kp is None:
                    continue
                d = 8.0 * spans.get(ax, 1.0)     # ← 各轴不同
                if side == 'right':
                    kp.handle_right = (float(kp.co[0]) + d, float(kp.handle_right[1]))
                else:
                    kp.handle_left = (float(kp.co[0]) - d, float(kp.handle_left[1]))
                fc.update()
        return []
    sc.fix_unify_dt = _wrong_unify
    try:
        o, a = build("_INJ_I5")
        set_sym(o, MID, DV, DT)
        kp = kp_at(o, MID, 1)
        kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
        for fc in curves(o).values():
            fc.update()
        r = sc.detect(a, o, None)
        sc.apply_fix(a, o, r, None, kinds=["dt_mismatch"])
        dts = [abs(float(kp_at(o, MID, ax).handle_right[0] - kp_at(o, MID, ax).co[0]))
               for ax in (0, 1, 2)]
        caught = (max(dts) - min(dts)) > 1e-6
    finally:
        sc.fix_unify_dt = _o_fixdt
    step("★ I5 统一 dt 时「写同一个 s」（各轴 span 不同 ⇒ dt 仍不等）⇒ 测试抓住（B4）",
         caught, "B4 变红=%s（dt 极差=%.4f）" % (caught, max(dts) - min(dts)))
except Exception:
    step("EXCEPTION D", False, traceback.format_exc()[-700:])


# ===========================================================================
flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 78)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 78)
print("spec/correction (A detect + B fix + C contract + D inject + E integration)"
      " | total=%d | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
