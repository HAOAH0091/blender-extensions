"""RTMP 变换数据层（第一条线：G 移动 / R 旋转 / S 缩放）

与 time_domain 的分工
---------------------
    time_domain   → 改 handle[0]（时间分量），**不动路径形状**（第二条线）
    transform_domain → 改 keyframe 位置（值分量），**改路径形状**（第一条线）

这是两条独立的线，语义不同，互不干涉。

G 的语义（用户确认，见 设计存档 §11）
-----------------------------------
    移动**选中的路径点**（关键帧控制点），跟随鼠标（屏幕空间 → 世界空间）。
    X/Y/Z 锁轴；Shift+X/Y/Z 锁平面；连按同轴循环朝向；Shift 精度 ×1/10；数字输入。

为什么每个轴要连 handle 一起移动
------------------------------
关键帧的 `co` / `handle_left` / `handle_right` 共同定义曲线形状。
只移 `co` 会让手柄"留在原地"，曲线被拉伸变形；三者同步平移才是"整点搬家"。
（这正是插件现有 `apply_point_offset` 的做法，本模块保持一致。）
"""

import math

import mathutils

# 帧号匹配容差：**全仓唯一定义在 `state`**（2026-09-29 收敛，原先本模块硬编码 1e-3）
from .state import FRAME_EPS, warn_once

# 轴索引
AXIS_INDEX = {'X': 0, 'Y': 1, 'Z': 2}

SAFE_LIMIT = 1000000.0
PRECISION_FACTOR = 0.1      # Shift 精度：原生是 ×1/10

# 手柄的【派生类型】：坐标由 Blender 按公式**导出**，不接受外部写入
# （`fc.update()` 会覆盖它）。拖动时必须先接管。
_DERIVED_TYPES = ('AUTO', 'AUTO_CLAMPED', 'VECTOR')

# ★★ 拖动手柄时，Blender **原生**会把类型转成什么（官方手册原文）：
#
#   · Automatic / Auto Clamped：
#       "These handles **convert to Align handles when moved**."
#   · Vector：
#       "Vector handles **convert to Free handles when moved**."
#   · 并且："If you want to change an automatic handle's position, **just drag it**;
#            you don't need to manually change its type first."
#
#   （来源：Manual → F-Curve Properties → Left/Right Handle Type；
#     以及 Curve Structure → Bézier → Handle Types）
#
# ⚠️⚠️ 这条推翻了早先的实现：以前一律转 **FREE**，于是
#     · 拖完手柄类型变 FREE（原生是 ALIGNED）
#     · **对侧**仍是 AUTO_CLAMPED → 被 Blender 重算 → 永久不共线
#
#   AUTO / AUTO_CLAMPED → ALIGNED，语义恰好就是「handles remain on a straight line」
#   —— 用户在 3D 视图里期望的"两根手柄一条直线"，本来就是 ALIGNED 的定义。
_DRAG_TO_TYPE = {'AUTO': 'ALIGNED', 'AUTO_CLAMPED': 'ALIGNED', 'VECTOR': 'FREE'}

# dt（手柄时间分量离 co 的距离）的【可分辨下限】。
# 实测 Blender 数据层对 dt 的分辨率约为 1e-3 帧（见设计存档）；低于它：
#   · 时间分量已无意义（和 co 同一帧）
#   · 任何 `dv / dt` 形式的斜率计算都会**数值爆炸**
# 所以所有依赖 dt 的运算都要先过这个下限。
DT_EPS = 1e-3

# 手柄【三维长度】的可分辨下限（拖拽量的分母，趋零时方向无定义）
_ARM_EPS = 1e-9


# ★★ 插件「接管为 FREE」的手柄登记：{(action_ptr, frame, axis, side)}
#
# 场景：拖手柄收尾时，为避免 Blender 的 ALIGNED 在**后续任何一次 `fc.update()`**
#       里把它按 "(t,v) 平面共线" 重算（那会破坏 3D 形状 + 改 dt），
#       我们把对侧**转成 FREE**（见 `_seal_opposite_handle`）。
#
# 但这带来一个新问题：FREE 在 `_link_mode` 里默认是「用户手动设的，不联动」——
#       于是**同一次拖动里的下一次调用**（模态是每帧调的）就再也不联动了
#       （实测：D 组共线偏差 0.88）。
#
# 所以必须区分「**插件接管**的 FREE」与「**用户手动**的 FREE」：
#   前者继续联动，后者按原生语义完全不动。
#
# ★ 持久化（2026-09-17）：登记会同步写进 action 的 custom property
#    `act["rtmp_owned_free"]`，打开文件时【惰性恢复】——
#    重启 Blender 后「体感类型」不丢（否则全部退化成"用户手动 FREE"，
#    用户看到的就是"拖一侧手柄、对侧不联动"）。
#    用户原话："让插件能够根据工程记录，以免重启 blender 后丢失手柄的体感类型。"
_plugin_owned_free = set()      # {(action_name, frame, side)}
_owned_warmed = set()           # 已从 custom property 恢复过登记的 action 名
# ★★ 2026-09-19：对账源（同 `_TRILOCK_SRC`）—— 撤销/重做天然被感知，不依赖 handler。
_OWNED_SRC = {}

_OWNED_PROP = "rtmp_owned_free"     # action 上的 custom property 名


def _own_key(kp, side):
    """给「某个手柄」算一个稳定标识（用于 `_plugin_owned_free`）。

    ★ 键 = `(action 名, 帧号, 侧)` —— 用 action **名**而不是 `as_pointer()`。

    ⚠️ 为什么不能用内存地址（2026-09-17 改）：
       · 文件重载后指针失效 ⇒ 登记全废（那正是"体感类型丢失"的原因）
       · 指针还可能被**复用**（action 释放后新 action 拿到同一地址）
         ⇒ 陈旧登记误伤新 action（`待决项_手柄联动.md` ①）
       action 名在文件内唯一、且**跨会话稳定**（存在 .blend 里），
       既解决持久化，又顺手消掉指针复用隐患。

    ⚠️ `Keyframe.id_data` 直接就是 **Action**（不是 F-Curve）——
       实测踩过：写成 `kp.id_data.id_data` 会抛 AttributeError 被吞掉，
       登记永远失败 → 封口后的下一次调用仍读成"用户 FREE"，不联动（D 组偏差 0.88）。

    ⚠️ 粒度到 (action, 帧, 侧, owner)，**不带 axis** —— 封口本来就是三轴一起做的。
    ★★★ 2026-09-30（D-1/D-2）：加了第 4 段 owner。
       以前只有前三段 ⇒ 一个角色 action 里所有骨骼共用它 ⇒ 同帧同侧撞键：
       实测给 BoneB 调 `mark_owned_free` 之后，BoneA 的手柄被算成「插件接管」。
       ⚠️ owner 由 `owner_of_keyframe(kp)` **现算**（扫活数据，永远是对的）。
       ⚠️ 上面那句「Python API 没有从 Keyframe 反查 F-Curve 的入口」对 **axis**
          仍然成立；对 **owner** 现在有了绕法（见 `owner_of_keyframe` 的说明）。
    """
    try:
        act = kp.id_data                     # ← 直接就是 Action
        return (str(act.name), round(float(kp.co[0]), 4), str(side),
                owner_of_keyframe(kp))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 持久化读写（action 的 custom property）
# ---------------------------------------------------------------------------

def _owned_token(frame, side, owner=""):
    """登记项在 custom property 里的字符串形式（**3 段**：帧号|侧|owner）。"""
    return "%s|%s|%s" % (("%.4f" % float(frame)), str(side), str(owner or ""))


def _owned_parse(tok):
    # '14.0000|left|BoneA@OBArm' → (14.0, 'left', 'BoneA@OBArm')，畸形返回 None。
    # ⚠️ **只认 3 段**。2 段是旧格式（没署名）—— 用户拍板不做向下兼容 ⇒ 忽略。
    try:
        parts = str(tok).split("|")
        if len(parts) != 3:
            return None
        return (round(float(parts[0]), 4), str(parts[1]), str(parts[2]))
    except Exception:
        warn_once("transform_domain._owned_parse")
        return None


def owned_free_tokens(act):
    """读 action 上持久化的登记项（字符串列表）。拿不到就返回空列表。"""
    try:
        v = act.get(_OWNED_PROP)
    except Exception:
        return []
    if not v:
        return []
    try:
        return [str(x) for x in v]
    except Exception:
        try:
            return [str(v)]
        except Exception:
            return []


def _write_owned_tokens(act, tokens):
    try:
        act[_OWNED_PROP] = sorted(set(str(t) for t in tokens))
        return True
    except Exception:
        return False


def _owned_sync(act):
    """★★ 让「插件接管的 FREE 登记」与 action 的 custom property **对账**。

    机理同 `_trilock_sync`（property 是唯一真相，缓存只是派生）：
      Blender 撤销 / 重做会改 property、碰不到 Python 变量 ⇒
      "只 warm 一次"会让缓存永久失真。
    """
    if act is None:
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    if not nm:
        return
    try:
        act.get(_OWNED_PROP)             # ★ 读不了 ⇒ 保持缓存不动（理由见 _trilock_sync）
    except Exception:
        return
    # ★★ D-4 僵尸词条：必须在**快路径之前**清 —— 否则快路径会让僵尸永远留着
    #    （实测：`mark_*_at` 刚写完，property 与对账源一致 ⇒ 快路径命中 ⇒
    #      删帧后查询照样读回旧值）。
    if prune_zombie_tokens(act, nm, _plugin_owned_free, _owned_parse, owned_free_tokens, _write_owned_tokens):
        _OWNED_SRC[nm] = tuple(owned_free_tokens(act))
        return
    raw = tuple(owned_free_tokens(act))
    # 快路径：property 没变 **且** 缓存条目还在（第二重判据，理由见 `_cache_has_entries`）
    if _OWNED_SRC.get(nm) == raw and (not raw or _cache_has_entries(_plugin_owned_free, nm)):
        return
    for k in [k for k in list(_plugin_owned_free) if k[0] == nm]:
        _plugin_owned_free.discard(k)
    frames = action_frames(act)          # ★ 僵尸词条自查（见 action_frames 的说明）
    kept = []
    dropped = False
    for tok in raw:
        p = _owned_parse(tok)
        if p is None:
            continue                 # ★ 旧格式（没署名）⇒ 忽略（不做向下兼容）
        frame, side, owner = p
        if frames is not None and round(float(frame), 4) not in frames:
            dropped = True           # ★ 指向已删关键帧 ⇒ 僵尸
            continue
        kept.append(str(tok))
        _plugin_owned_free.add((nm, round(float(frame), 4), str(side), str(owner)))
    if dropped:
        try:
            _write_owned_tokens(act, kept)
            raw = tuple(owned_free_tokens(act))
        except Exception:
            pass
    _OWNED_SRC[nm] = raw
    _owned_warmed.add(nm)


def warm_owned_free(act):
    """（兼容名）把既有登记同步进内存镜像 —— 语义见 `_owned_sync`。"""
    _owned_sync(act)


def mark_owned_free(kp, side):
    """★ 登记「这根 FREE 是**插件接管**的」⇒ 后续继续联动。**并持久化到 action。**

    所有"插件自己把类型转成 FREE"的地方都应调用本函数
    （封口、关键帧模态的临时转换……），否则那根手柄会被当成"用户手动 FREE"，
    用户看到的体感就是「拖一侧、对侧不联动」。
    """
    k = _own_key(kp, side)
    if not k:
        return False
    _plugin_owned_free.add(k)
    try:
        act = kp.id_data
        toks = []
        for t in owned_free_tokens(act):
            p = _owned_parse(t)
            if p is None:
                continue                     # ★ 旧格式 ⇒ 顺手清掉
            if (p[0], p[1], p[2]) == (k[1], k[2], k[3]):
                continue                     # 同一个格子 ⇒ 用新的替换
            toks.append(str(t))
        toks.append(_owned_token(k[1], k[2], k[3]))
        _write_owned_tokens(act, toks)
        _OWNED_SRC[str(act.name)] = tuple(owned_free_tokens(act))   # ★ 同步对账源
    except Exception:
        pass
    # ★ 2026-09-17（方案 A）：同步记录【体感类型 = LINK】—— 这才是权威数据。
    #   （旧表保留是为兼容测试与旧工程；新代码的联动判据只看体感表。）
    #
    # ★★★ 2026-09-30 修 D-3（Phase 1 极限边界测试抓到，FAIL/中）：
    #    **已记录的体感不覆盖** —— 与 `freeze_handle_side` / `mark_frozen` /
    #    `spec_check._freeze_keyframe` 三处口径统一（那三处早有守卫，只有这里没有）。
    #    旧行为**无条件**写 LINK ⇒ 用户显式设的「不动(FREE)」被**静默抹掉**：
    #      实测：mark_feel(kp,'left','FREE') ⇒ feel_type='FREE', _link_mode='free'
    #            过一遍 make_handles_editable（关键帧模态 G/R/S 的真实入口）
    #            ⇒ feel_type='LINK', _link_mode='link'  ← 用户的选择没了
    #    后果：进一次模态，本该不动的手柄开始跟着对侧动，且**无任何提示**。
    try:
        if feel_type(kp, side) is None:
            mark_feel(kp, side, 'LINK')
    except Exception:
        pass
    return True


def unmark_owned_free(kp, side):
    """取消登记（类型被**恢复**成原值时调用，防陈旧条目）。

    ★ 2026-09-17（方案 A）：同时清掉【体感记录】⇒ 该手柄回到"透传原始类型"。
    """
    k = _own_key(kp, side)
    if not k:
        return False
    _plugin_owned_free.discard(k)
    try:
        act = kp.id_data
        toks = []
        for t in owned_free_tokens(act):
            p = _owned_parse(t)
            if p is None:
                continue                     # ★ 旧格式 ⇒ 顺手清掉
            if (p[0], p[1], p[2]) == (k[1], k[2], k[3]):
                continue                     # 就是这个格子 ⇒ 删掉
            toks.append(str(t))
        _write_owned_tokens(act, toks)
        _OWNED_SRC[str(act.name)] = tuple(owned_free_tokens(act))   # ★ 同步对账源
    except Exception:
        pass
    # ★ 方案 A：同步清掉体感记录（回到透传）
    try:
        unmark_feel(kp, side)
    except Exception:
        pass
    return True


def clear_owned_free(act=None):
    """清空登记（`act=None` 时全清）。供将来"重置"类功能使用。"""
    if act is None:
        _plugin_owned_free.clear()
        _owned_warmed.clear()
        _OWNED_SRC.clear()              # ★ 对账源一起清
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    for k in [k for k in _plugin_owned_free if k[0] == nm]:
        _plugin_owned_free.discard(k)
    _owned_warmed.discard(nm)
    _OWNED_SRC.pop(nm, None)
    try:
        if _OWNED_PROP in act:
            del act[_OWNED_PROP]
    except Exception:
        pass


def _is_plugin_owned_free(kp, side):
    k = _own_key(kp, side)
    if not k:
        return False
    # ★★ 每次查询前对账（撤销/重做改的是 property）—— 不依赖任何 handler。
    try:
        _owned_sync(kp.id_data)
    except Exception:
        pass
    if k in _plugin_owned_free:
        return True
    # ★ 退「未知」桶（与 `_feel_lookup` 同口径）——
    #   拿不到 owner 的路径（外部手写的 token）写在那里；按老语义（全局）读。
    return (k[0], k[1], k[2], "") in _plugin_owned_free


def _is_plugin_frozen(kp):
    """这个 FREE 手柄是【插件自己冻的】吗（速度编辑 `freeze_keyframe_pair`）？

    ⚠️⚠️ 这个判据是 2026-09-16 用户两个反馈的**同一个根因**：

      速度编辑会把被编辑关键帧（及其邻居）的**两侧手柄转成 FREE**，
      并登记到 `time_domain` 的冻结表。

      · 端点模态路径（`maintain_linked_handle`）**只看类型** → 见 FREE 就 return
        → **模态操作时对侧完全不联动**（用户：「只能作用于一端手柄」）
      · 鼠标路径（老 `update_linked_handle`）有 `is_frozen` 例外 → 联动
        → 于是「操作完再操作」时对侧突然补上 → **跳变**

      两条路径对"插件冻的 FREE"判断不一致 → 行为不一致 → 用户看到跳变。

      修法：把判据收敛到**这一个函数**，两条路径共用。
    """
    try:
        from . import time_domain as td
        # ★★★ 2026-09-30（D-1/D-2）：带上 owner —— 冻结表也按「哪根骨骼」分开记，
        #    否则一个角色 action 里同帧的其它骨骼会把这条判据带歪。
        #    owner 用 `owner_of_keyframe` 现算（与写入侧同一套拼装）。
        return bool(td.is_frozen(kp.id_data, kp.co[0],
                                 owner=owner_of_keyframe(kp)))
    except Exception:
        return False


# ===========================================================================
# ★★★ 2026-09-30（Phase 1 · D-1 / D-2）—— 账本里的「这根手柄是**谁的**」
#
#   ▎病根
#     四张账本（体感 / 三角锁定 / 接管 / 冻结）的键原本只有
#     (action 名, 帧号, 侧) —— **没写「是谁的」**。
#     而一个角色 action 里装着**一整套骨架**的所有曲线：
#     帧 90 上，大臂和小臂的左手柄**同帧同侧** ⇒ 两条记录挤进同一个格子。
#
#     打个比方：这是一栋楼**共用一个信箱**（键只有「几楼」，没有「哪一户」）。
#       301 的信被塞进 302 的箱子，两人都觉得自己没收到。
#     实测：给大臂设「联动」、再给小臂设「不动」⇒ 大臂读回来变成了「不动」。
#
#   ▎owner 是什么
#     owner = 骨骼名 + 「@」 + slot 的 identifier
#       · 物体级曲线（不是骨骼）⇒ 骨骼名部分为空，如 @OBMyCube
#       · 拿不到某一段 ⇒ 那一段为空（**降级成「未知」，不是错位**）
#     slot 用 identifier（Blender **自己**就是用它把 slot 匹配到 ID 的，语义正确）；
#     实测存盘重开后逐位一致。
#
#   ▎怎么拿到它（**硬约束**）
#     bpy.types.Keyframe **没有**指回 F-Curve 的入口 ——
#     官方文档把它全部属性列完了（co/handle/interpolation/...），没有任何 parent 指针；
#     实测 dir(kp) 里也没有，kp.id_data 返回的是 **Action**。
#     ⇒ 只能**自己扫**：遍历该 action 的全部 channelbag 的全部 fcurve，
#       用 as_pointer() 认身份把这一帧找出来，再从
#         · fc.data_path（pose.bones["BoneA"].location）取骨骼名
#         · 它所在 channelbag 的 slot.identifier 取 slot
#
#     ⚠️ as_pointer() 只是**当场认身份**（同一份内存的两个包装对象），
#        **绝不**把它当持久键 —— 指针会被复用，当键会串到别的骨骼身上
#        （本项目 2026-09-17 已经因为「拿指针当键」栽过一次，见 _own_key 的注释）。
#        这里**每次都重新扫活数据** ⇒ 永远是对的，只是慢一点：
#        实测 20 根骨骼 / 1860 个关键帧的骨架 = **0.077 ms**。
#
#   ▎兼容性：**不做向下兼容**（用户 2026-10-01 拍板）
#     旧工程里那批「没署名」的 token 会被**直接忽略**（不是报错），
#     并在下一次写入时顺手清掉。代价：老工程里那些体感/冻结/接管记录会失效，
#     相关手柄退化成「用户手动 FREE」（拖一侧、对侧不跟）。这是**有意的取舍**。
# ===========================================================================

_OWNER_SEP = "@"


def _owner_esc(s):
    # owner 段的转义 —— 骨骼名 / slot 名是**用户可改的**，不能赌它不含分隔符。
    return (str(s).replace("%", "%25").replace("|", "%7C")
            .replace(_OWNER_SEP, "%40"))


def _owner_unesc(s):
    # 逆序还原（先把 %40 还原成 @ 会与分隔符打架 ⇒ 顺序必须与转义相反）。
    return (str(s).replace("%40", _OWNER_SEP).replace("%7C", "|")
            .replace("%25", "%"))


def owner_str(bone_name=None, slot=None):
    # (骨骼名, slot) → owner 段。两段都空 ⇒ 返回空串（= 「未知」）。
    # ⚠️ 空串是**合法的 owner**（表示「没查到」），不要把它当成「没有 owner」：
    #    token 里那一段**永远存在**，只是内容可能是空的。
    b = _owner_esc(bone_name or "")
    s = _owner_esc(slot or "")
    if not b and not s:
        return ""
    return "%s%s%s" % (b, _OWNER_SEP, s)


def owner_parts(owner):
    # owner 段 → (骨骼名, slot)；畸形/空 ⇒ ("", "")。
    try:
        t = str(owner or "")
        if _OWNER_SEP not in t:
            return ("", "")
        b, _, s = t.partition(_OWNER_SEP)
        return (_owner_unesc(b), _owner_unesc(s))
    except Exception:
        return ("", "")


def _bone_of_path(dp):
    # pose.bones["BoneA"].location → BoneA；物体级曲线 → 空串。
    # ⚠️ 不用正则：骨骼名里可能有引号/反斜杠，正则容易在奇怪的名字上失手；
    #    固定前缀 + 找 "] 更稳。
    try:
        s = str(dp)
        i = s.find("pose.bones[\"")
        if i < 0:
            return ""
        j = s.find("\"]", i + 12)
        if j < 0:
            return ""
        return s[i + 12:j]
    except Exception:
        return ""


def _slot_id_of(bag):
    # channelbag 的 slot identifier（拿不到 ⇒ 空串）。
    try:
        return str(bag.slot.identifier)
    except Exception:
        return ""


def _iter_action_bags(act):
    # 该 action 的**全部** channelbag（含所有 slot）。
    # ⚠️ 用 yield 而不是返回 list：调用方常常找到目标就 break。
    try:
        for lay in act.layers:
            for st in lay.strips:
                for bag in st.channelbags:
                    yield bag
    except Exception:
        return


def action_frames(action):
    # 该 action 里**现存**的关键帧帧号集合（僵尸词条自查用，四张账本共用）。
    #
    # ★★ 为什么需要它（D-4「僵尸词条」）：
    #   账本按 (action, owner, 帧, 侧) 记状态，而关键帧可以被用户在 Graph Editor
    #   里**删掉** —— 记录就成了**僵尸**：内存表与 property 两边一致
    #   （双向对账**查不出来**），但都指向一个**不存在的帧**。
    #   后果：同一个帧号**重新插**一个关键帧时，旧设置会**静默套上去**。
    #   ⇒ 对账时顺手把僵尸丢掉（并写回 property，让它彻底消失）。
    #
    # ⚠️ 扫不了（鸭子类型假对象 / 非 Action）⇒ 返回 **None**，
    #    调用方据此**跳过**僵尸判定 —— 宁可留着，也不误杀。
    try:
        action.layers                    # ★ 先确认这**真的**是个 Action
    except Exception:
        # 鸭子类型的假对象（测试用来模拟"同名异实例"）读不到 layers ——
        # 此时**不能**返回空集：那会把所有记录都当成僵尸误杀。⇒ None = 别做判定。
        return None
    out = set()
    try:
        for bag in _iter_action_bags(action):
            for fc in bag.fcurves:
                for k in fc.keyframe_points:
                    out.add(round(float(k.co[0]), 4))
    except Exception:
        return None
    return out


def prune_zombie_tokens(act, nm, table, parse_fn, tokens_fn, write_fn):
    # 把指向**已删关键帧**的记录从内存表 + property 里清掉（四张账本共用一份实现）。
    #
    # ⚠️⚠️ 必须在各 `*_sync` 的**快路径之前**调用：
    #   快路径（"property 没变 ⇒ 直接 return"）会让僵尸**永远留在表里** ——
    #   实测就是卡在这儿：`mark_feel_at` 刚写完，property 与对账源一致 ⇒
    #   快路径命中 ⇒ 删帧后查询照样读回 'FREE'（D8 第一条红）。
    #
    # :return: True = 清过（调用方把对账源更新一下即可）
    frames = action_frames(act)
    if frames is None:
        return False
    dead = [k for k in list(table)
            if k[0] == nm and round(float(k[1]), 4) not in frames]
    if not dead:
        return False
    for k in dead:
        try:
            if hasattr(table, "discard"):
                table.discard(k)
            else:
                table.pop(k, None)
        except Exception:
            pass
    kept = []
    for t in tokens_fn(act):
        p = parse_fn(t)
        if p is None:
            continue
        try:
            if round(float(p[0]), 4) not in frames:
                continue
        except Exception:
            pass
        kept.append(str(t))
    try:
        write_fn(act, kept)
    except Exception:
        pass
    return True


def owner_of_curve(fc, bag=None):
    # 从 F-Curve 取 owner —— 骨骼名来自 data_path，slot 来自它所在的 channelbag。
    # bag 已知时直接传（省一次扫描）；不知道就自己找（O(曲线数)，很便宜）。
    bone = _bone_of_path(getattr(fc, "data_path", ""))
    if bag is None:
        try:
            ptr = fc.as_pointer()
            for b in _iter_action_bags(fc.id_data):
                for f2 in b.fcurves:
                    if f2.as_pointer() == ptr:
                        bag = b
                        break
                if bag is not None:
                    break
        except Exception:
            bag = None
    return owner_str(bone, _slot_id_of(bag) if bag is not None else "")


def _resolve_owner(owner=None, bone_name=None, slot=None):
    # 把「调用方给的 owner」归一化 —— **唯一入口**。
    #
    # 两种给法都收：
    #   · owner=<已拼好的字符串>（最稳：直接来自 `owner_of_curve` / `owner_of_keyframe`）
    #   · bone_name=/slot=<零件>（方便手上正好有这两样）
    # ⚠️ 无论哪种，最终都过 `owner_str` 那**同一套拼装**（转义也只有那一处），
    #    否则同一根手柄会被算出两个 owner，写进去的记录查不回来。
    if owner is not None:
        return str(owner)
    return owner_str(bone_name, slot)


def owner_of_object(obj, bone_name=None):
    # 从**对象**算 owner（slot 取对象绑的 action_slot 的 identifier）。
    #
    # ⚠️ 只在"手上只有对象、没有曲线"时用；**有曲线时优先 `owner_of_curve`** ——
    #    那才是"这条曲线到底住在哪个 channelbag"的权威答案。
    #    两者在正常情况下结果一致（插件就是按 obj 的 slot 收集曲线的）。
    slot = ""
    try:
        slot = str(obj.animation_data.action_slot.identifier)
    except Exception:
        slot = ""
    return owner_str(bone_name, slot)


def owner_of_keyframe(kp):
    # 关键帧 → owner（**唯一来源**，四张账本都调它）。
    #
    # ⚠️ 为什么没有 bone_name 参数：
    #    一旦允许调用方「传一半」（只给骨骼名、slot 自己扫），
    #    同一根手柄就可能被算出**两个不同的 owner** —— 写进去的记录查不回来。
    #    ⇒ 这里**不接受任何提示**，永远按同一套规则从活数据里算。
    #    （需要「从对象/曲线算」的场合走 owner_of_curve / owner_str，
    #      它们与这里用的是**同一套拼装**，所以结果一致。）
    #
    # ⚠️ 扫不到（假对象 / 关键帧已「钝」）⇒ 返回空串（未知），
    #    退化成「全楼共用信箱」的老行为 —— **宁可退化，不可错位**。
    try:
        act = kp.id_data
    except Exception:
        return ""
    try:
        ptr = kp.as_pointer()
    except Exception:
        return ""
    try:
        for bag in _iter_action_bags(act):
            for fc in bag.fcurves:
                try:
                    for k in fc.keyframe_points:
                        if k.as_pointer() == ptr:
                            return owner_of_curve(fc, bag)
                except Exception:
                    continue
    except Exception:
        return ""
    return ""


# ===========================================================================
# ★★★ 体感手柄类型（2026-09-17，用户拍板方案 A）
#
#   背景：以前「体感手柄类型」**不是一份独立数据** —— 它每次都由
#   「原始手柄类型 + 两张登记表」**现算**出来。后果：
#     · 重启 Blender 就丢（登记表在内存里）
#     · 用户在 Graph Editor 改原始类型，体感就跟着变（被牵着走）
#     · 代码里到处 `if 冻过 or 接管过`，只能猜
#
#   方案 A（用户选）：**体感绝对权威**。
#     · 体感类型**独立存**在本表里（权威）
#     · 原始手柄类型**降级成实现细节** —— 为了不让 Blender 重算偷改形状/速度，
#       按需把它写成 FREE（实测：ALIGNED 会被重算，手柄变化 6.54；FREE 是 0.0）
#     · 联动决策**只看体感**，不看原始类型
#
#   语义（`None` = **未记录 ⇒ 透传**）：
#     · 记录 'LINK'    → 联动（原始类型用 ALIGNED；含"插件冻的/接管的 FREE"）
#     · 记录 'CLAMPED' → 联动（原始类型用 AUTO_CLAMPED —— 多一层**钳制防过冲**）
#     · 记录 'VECTOR'  → 贴到控制点（**不在菜单里**，仅为兼容存量数据保留）
#     · 记录 'FREE'    → 不动（用户手动设的）
#     · **没记录**      → 体感 = 原始类型（透传，插件没碰过的关键帧别管）
#
#   ★ 2026-09-17 追加 'CLAMPED'：用户要求右键菜单把 Vector 换成 Auto Clamped。
#     实测（tests/_vecal_probe）：
#       · AUTO_CLAMPED 与 ALIGNED 的**联动行为完全相同**（都 → link）
#       · 区别在**曲线钳制**：只移动关键帧后手柄变化量 AUTO_CLAMPED **0.51**
#         vs ALIGNED **4.60** —— Auto Clamped 会钳制、防过冲
#     ⇒ 两者都归"联动"，但原始类型不同 ⇒ 体感取值分开记，菜单高亮才能 1:1。
#
#   ⚠️ 键 `(action 名, 帧号, 侧)`：与原来两张表同粒度。
#      action 名跨会话稳定（不是内存地址），所以能持久化。
# ===========================================================================

_FEEL = {}                      # {(action_name, frame, side, owner): 'LINK'|'VECTOR'|'FREE'}
_feel_warmed = set()            # 已从 custom property 恢复过的 action 名
# ★★ 2026-09-19：对账源（同 `_TRILOCK_SRC`）—— 撤销/重做天然被感知，不依赖 handler。
_FEEL_SRC = {}

_FEEL_PROP = "rtmp_feel"        # action 上的 custom property 名


def _feel_key_of(action, frame, side, owner=""):
    # ★★【唯一的】体感表键 —— (action 名, 帧号, 侧, owner)。
    #
    # ⚠️ 必须是**唯一来源**（mark / unmark / query 都调它）：
    #    各写一份时，只改其中一处的 bug 注入**行为测试抓不到**
    #    （同进程内恰好都「能跑」，跨会话才暴露）。见 `_frozen_key` 的教训。
    # ⚠️ 用 action **名**（跨会话稳定）而不是 as_pointer()（重载即失效）。
    # ★★★ 2026-09-30（D-1 / D-2）：**加了第 4 段 owner** ——
    #    以前只有前三段，导致「大臂的设置被小臂改掉」（同帧同侧挤一个格子）。
    try:
        return (str(action.name), round(float(frame), 4), str(side),
                str(owner or ""))
    except Exception:
        return None


def _feel_key(kp, side):
    # 从关键帧取体感表键（**委托给唯一来源** `_feel_key_of`）。
    #
    # ⚠️ `Keyframe.id_data` 直接就是 **Action**（不是 F-Curve）——
    #    写成 `kp.id_data.id_data` 会抛 AttributeError 被吞掉。
    # ★★ owner 由 `owner_of_keyframe(kp)` **现算**（扫活数据，永远是对的）。
    try:
        return _feel_key_of(kp.id_data, kp.co[0], side, owner_of_keyframe(kp))
    except Exception:
        return None


def _feel_token(frame, side, value, owner=""):
    return "%s|%s|%s|%s" % (("%.4f" % float(frame)), str(side), str(value),
                            str(owner or ""))


def _feel_parse(tok):
    # '14.0000|left|LINK|BoneA@OBArm' → (14.0, 'left', 'LINK', 'BoneA@OBArm')。
    #
    # ⚠️ **只认 4 段**。3 段是旧格式（没署名）—— 用户 2026-10-01 拍板
    #    **不做向下兼容** ⇒ 直接返回 None，该条被忽略（不是报错），
    #    并在下一次写入时顺手清掉（见 `_feel_tokens_for_write`）。
    try:
        parts = str(tok).split("|")
        if len(parts) != 4:
            return None
        return (round(float(parts[0]), 4), str(parts[1]), str(parts[2]),
                str(parts[3]))
    except Exception:
        warn_once("transform_domain._feel_parse")
        return None


def feel_tokens(act):
    """读 action 上持久化的体感记录（字符串列表）。"""
    try:
        v = act.get(_FEEL_PROP)
    except Exception:
        return []
    if not v:
        return []
    try:
        return [str(x) for x in v]
    except Exception:
        try:
            return [str(v)]
        except Exception:
            return []


def _write_feel_tokens(act, tokens):
    try:
        act[_FEEL_PROP] = sorted(set(str(t) for t in tokens))
        return True
    except Exception:
        return False


def warm_feel(act):
    """（兼容名）把既有体感记录同步进内存镜像 —— 语义见 `_feel_sync`。

    ⚠️ 2026-09-19 起**不再是"每个 action 只恢复一次"**：为感知撤销/重做，
       改成每次查询前对账（见 `_feel_sync`）。
    """
    _feel_sync(act)


def _feel_sync(act):
    """★★ 让「体感类型表」与 action 的 custom property **对账**。

    机理同 `_trilock_sync`：property 是唯一真相，缓存只是派生；
    撤销 / 重做改的是 property ⇒ 每次读之前对一次账就天然被感知。
    """
    if act is None:
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    if not nm:
        return
    try:
        act.get(_FEEL_PROP)              # ★ 读不了 ⇒ 保持缓存不动（理由见 _trilock_sync）
    except Exception:
        return
    # ★★ D-4 僵尸词条：必须在**快路径之前**清 —— 否则快路径会让僵尸永远留着
    #    （实测：`mark_*_at` 刚写完，property 与对账源一致 ⇒ 快路径命中 ⇒
    #      删帧后查询照样读回旧值）。
    if prune_zombie_tokens(act, nm, _FEEL, _feel_parse, feel_tokens, _write_feel_tokens):
        _FEEL_SRC[nm] = tuple(feel_tokens(act))
        return
    raw = tuple(feel_tokens(act))
    # 快路径：property 没变 **且** 缓存条目还在（第二重判据，理由见 `_cache_has_entries`）
    if _FEEL_SRC.get(nm) == raw and (not raw or _cache_has_entries(_FEEL, nm)):
        return
    for k in [k for k in list(_FEEL.keys()) if k[0] == nm]:
        _FEEL.pop(k, None)
    frames = action_frames(act)          # ★ 僵尸词条自查（见 action_frames 的说明）
    kept = []
    dropped = False
    for tok in raw:
        p = _feel_parse(tok)
        if p is None:
            continue                 # ★ 旧格式（没署名）⇒ 忽略（用户拍板不向下兼容）
        frame, side, value, owner = p
        if frames is not None and round(float(frame), 4) not in frames:
            dropped = True           # ★ 指向已删关键帧 ⇒ 僵尸，丢掉
            continue
        kept.append(str(tok))
        _FEEL[(nm, round(float(frame), 4), str(side), str(owner))] = \
            str(value).upper()
    if dropped:
        # 顺手把僵尸从 property 里清掉 —— 否则同帧重新插关键帧时它会**静默复活**。
        try:
            _write_feel_tokens(act, kept)
            raw = tuple(feel_tokens(act))
        except Exception:
            pass
    _FEEL_SRC[nm] = raw
    _feel_warmed.add(nm)


def _feel_tokens_for_write(act, key):
    # 给"写一条记录"用的**唯一** token 整理器（mark / unmark 共用）。
    #
    # 干三件事：
    #   ① 丢掉**解析不了的**（旧格式 / 畸形）—— 顺手把老工程的旧 token 清掉
    #   ② 丢掉**同一个格子**的旧值（由调用方 append 新值）
    #   ③ 其余原样保留
    #
    # ⚠️ 抽成一个函数是为了"口径唯一"：以前 mark / mark_at / unmark_at 各写一份
    #    列表推导，改键结构时三处都要改、极易漏（这次就是这么踩的）。
    out = []
    for t in feel_tokens(act):
        p = _feel_parse(t)
        if p is None:
            continue
        if (p[0], p[1], p[3]) == (key[1], key[2], key[3]):
            continue
        out.append(str(t))
    return out


def mark_feel(kp, side, value):
    """★★ 记录「这根手柄的**体感类型**」并持久化到 action。

    `value` 取 'LINK' / 'VECTOR' / 'FREE'。**所有插件自己改类型的地方都应调用**
    （封口、速度编辑冻结、关键帧模态转 FREE），否则那根手柄会被当成
    "用户手动 FREE"，用户看到的体感就是「拖一侧、对侧不联动」。
    """
    k = _feel_key(kp, side)
    if not k:
        return False
    value = str(value).upper()
    _FEEL[k] = value
    try:
        act = kp.id_data
        toks = _feel_tokens_for_write(act, k)
        toks.append(_feel_token(k[1], k[2], value, k[3]))
        _write_feel_tokens(act, toks)
        _FEEL_SRC[str(act.name)] = tuple(feel_tokens(act))          # ★ 同步对账源
    except Exception:
        pass
    return True


def mark_feel_at(action, frame, side, value, bone_name=None, slot=None,
                owner=None):
    # 按 (action, 帧号, 侧, owner) 直接记体感（**不需要 keyframe 对象**）。
    #
    # 供 `time_domain`（速度编辑冻结）这类只拿得到 (action, 帧号) 的调用方使用。
    #
    # ⚠️⚠️ 这种调用方**没有关键帧** ⇒ 拿不到 owner ⇒ 必须由调用方**显式传**。
    #    不传（bone_name=None 且 slot=None）⇒ owner 为空串 = 「未知」，
    #    退化成老行为（**宁可退化，不可错位**）。
    #    ⚠️ 传的时候必须用 `owner_str(bone_name, slot)` 那**同一套拼装** ——
    #       否则同一根手柄会被算出两个 owner，写进去的记录查不回来。
    #       最稳的传法是调用方自己调 `owner_of_curve(fc)` 或 `owner_str(...)`。
    k = _feel_key_of(action, frame, side, _resolve_owner(owner, bone_name, slot))
    if not k:
        return False
    value = str(value).upper()
    _FEEL[k] = value
    try:
        toks = _feel_tokens_for_write(action, k)
        toks.append(_feel_token(k[1], k[2], value, k[3]))
        _write_feel_tokens(action, toks)
        _FEEL_SRC[str(action.name)] = tuple(feel_tokens(action))     # ★ 同步对账源
    except Exception:
        pass
    return True


def unmark_feel_at(action, frame, side, bone_name=None, slot=None, owner=None):
    # 按 (action, 帧号, 侧, owner) 清体感记录（回到透传）。
    # ⚠️ owner 的说明同 `mark_feel_at`：**必须与写入时用同一套拼装**。
    k = _feel_key_of(action, frame, side, _resolve_owner(owner, bone_name, slot))
    if not k:
        return False
    _FEEL.pop(k, None)
    try:
        toks = _feel_tokens_for_write(action, k)
        _write_feel_tokens(action, toks)
        _FEEL_SRC[str(action.name)] = tuple(feel_tokens(action))     # ★ 同步对账源
    except Exception:
        pass
    return True


def unmark_feel(kp, side):
    # 清掉体感记录（**回到透传原始类型**）。类型被「恢复」时调用。
    # ★ owner 从 kp 现算 ⇒ 走 `_feel_key` 拿到的键直接用来删。
    k = _feel_key(kp, side)
    if not k:
        return False
    _FEEL.pop(k, None)
    try:
        act = kp.id_data
        toks = _feel_tokens_for_write(act, k)
        _write_feel_tokens(act, toks)
        _FEEL_SRC[str(act.name)] = tuple(feel_tokens(act))
    except Exception:
        pass
    return True


def clear_feel(action=None):
    """清体感记录（action=None 全清；带 action 时连 property 一起删）。"""
    if action is None:
        _FEEL.clear()
        _feel_warmed.clear()
        _FEEL_SRC.clear()                # ★ 对账源一起清
        return
    nm = getattr(action, "name", None)
    for k in [k for k in _FEEL if k[0] == nm]:
        _FEEL.pop(k, None)
    _feel_warmed.discard(nm)
    _FEEL_SRC.pop(nm, None)              # ★ 对账源一起清
    try:
        if _FEEL_PROP in action:
            del action[_FEEL_PROP]
    except Exception:
        pass


# ===========================================================================
# ★★ 三角「一体 / 分离」锁定状态（用户 2026-09-18 需求）
#
#   语义（用户原话 → 落点）：
#     · LOCKED（一体，**默认**）—— 同一关键帧的上下两个三角**联动**：
#         单击任一个 ⇒ **两个一起选中**；拖动 / 模态操作时两侧速度值恒等。
#     · SPLIT（分离）—— 两个三角各自独立，可单独选中、单独调整。
#
#   交互（见 `interaction.try_toggle_tri_lock_click`）：
#     双击 LOCKED 帧 → 分离（切成单边操作）
#     双击 SPLIT 帧  → 锁定，并**把对侧的值同步到被双击的这个三角**
#
#   ⚠️ 状态按**关键帧**独立（不是按三角），且随 action 持久化。
#   ⚠️ 只有**两个三角都存在的帧**（中间帧）才有"分离"的意义；
#      首帧（只有右段三角）/ 末帧（只有左段三角）永远视为一体。
#
#   实现完全照抄 `rtmp_feel` 那套经过验证的模式：
#     稳定键（action 名 + 帧号，不是内存地址）/ custom property /
#     惰性 warm / set+clear 对称 / clear 带 action 时连 property 一起删。
# ===========================================================================

_TRILOCK = {}                   # {(action_name, frame): False}  只记 SPLIT(=False)
_trilock_warmed = set()         # 已从 custom property 恢复过的 action 名
_TRILOCK_PROP = "rtmp_tri_lock"
# ★★ 2026-09-19：`{action 名: 该 action 的 property 原文}` —— 缓存是**从哪份
#    property 推出来的**。查询前拿它跟当前 property 对账 ⇒ 撤销 / 重做天然被感知。
#    见 `_trilock_sync` 的说明（不依赖任何 handler）。
_TRILOCK_SRC = {}


def _cache_has_entries(mem, name):
    """该 action 在内存表里还有条目吗？

    ★ 用于对账的**第二重**判据：只看"property 原文没变"不够 ——
      外部若单独清空了内存镜像（模拟重开文件 / 别的模块 reset），
      对账源还留着 ⇒ 会误判"缓存有效"，导致**永远不再恢复**。
    """
    try:
        for k in mem:
            if k[0] == name:
                return True
    except Exception:
        return False
    return False


def _trilock_key_of(action, frame, owner=""):
    # ★★【唯一的】三角锁定表键 —— (action 名, 帧号, owner)。
    #
    # ⚠️ 必须是**唯一来源**（set / clear / query 都调它）：
    #    各写一份时，只改其中一处的 bug 注入**行为测试抓不到**
    #    （同进程内恰好都「能跑」，跨会话才暴露）。见 `_feel_key_of` 的教训。
    # ⚠️ 用 action **名**（跨会话稳定）而不是 as_pointer()（重载即失效）。
    # ★★★ 2026-09-30（D-1/D-2）：**加了第 3 段 owner** ——
    #    三角锁定也是"某个关键帧的状态"，而一个角色 action 里所有骨骼共用它
    #    ⇒ 同帧必然撞键（大臂的双击锁定会改到小臂身上）。
    try:
        return (str(action.name), round(float(frame), 4), str(owner or ""))
    except Exception:
        return None


def _trilock_token(frame, locked, owner=""):
    return "%s|%s|%s" % (("%.4f" % float(frame)),
                          "LOCKED" if locked else "SPLIT", str(owner or ""))


def _trilock_parse(tok):
    # '14.0000|SPLIT|BoneA@OBArm' → (14.0, False, 'BoneA@OBArm')，畸形返回 None。
    # ⚠️ **只认 3 段**。2 段是旧格式（没署名）—— 用户拍板不做向下兼容 ⇒ 忽略。
    try:
        parts = str(tok).split("|")
        if len(parts) != 3:
            return None
        return (round(float(parts[0]), 4), str(parts[1]).upper() == "LOCKED",
                str(parts[2]))
    except Exception:
        warn_once("transform_domain._trilock_parse")
        return None


def trilock_tokens(act):
    """读 action 上持久化的锁定记录（字符串列表）。"""
    try:
        v = act.get(_TRILOCK_PROP)
    except Exception:
        return []
    if not v:
        return []
    try:
        return [str(x) for x in v]
    except Exception:
        try:
            return [str(v)]
        except Exception:
            return []


def _write_trilock_tokens(act, tokens):
    try:
        act[_TRILOCK_PROP] = sorted(set(str(t) for t in tokens))
        return True
    except Exception:
        return False


def _trilock_sync(act):
    """★★ 让内存镜像与 action 上的 custom property **对账**（property 是唯一真相）。

    为什么必须**每次**对账，而不是"恢复一次就完事"：
      Blender 的**全局撤销 / 重做**会改 custom property，但**碰不到 Python
      模块变量**（机理见 `undo_guard.py`）。只 warm 一次 ⇒ 撤销后缓存永久失真
      ⇒ 用户看到「Ctrl+Z 撤销不了锁定状态」（2026-09-19 用户实机反馈）。

    ⚠️ 先试过"挂 `undo_post` 清缓存"（v1.3.6 / v1.3.7）——**不够**：
       只要钩子没挂在场（加载时序 / 被别的清理逻辑扫掉 / 第三方插件），
       缓存就永久失真。**实测**：用户现场会话里 `undo_post` 列表是**空的**，
       修复"看着装上了、实际没生效"。
    ⇒ 改成**主动对账**：读之前比一次 property 原文，不一致就重建。
       不依赖任何 handler，撤销 / 重做**天然**被感知。

    代价：每次查询多读一次 custom property（短字符串列表，很便宜）；
         内容没变时只做一次 tuple 比较（快路径）。
    """
    if act is None:
        return
    try:
        nm = str(act.name)
    except Exception:
        return
    if not nm:
        return
    # ★ 先探一次：**读不了** property（鸭子类型假对象 / 非 Action）时保持缓存不动。
    #   否则会把"读不到"误当成"property 为空"⇒ 清掉别的同名 action 的缓存
    #   （实测被 `gui_frozen_link_check` U13 抓到）。
    try:
        act.get(_TRILOCK_PROP)
    except Exception:
        return
    # ★★ D-4 僵尸词条：必须在**快路径之前**清 —— 否则快路径会让僵尸永远留着
    #    （实测：`mark_*_at` 刚写完，property 与对账源一致 ⇒ 快路径命中 ⇒
    #      删帧后查询照样读回旧值）。
    if prune_zombie_tokens(act, nm, _TRILOCK, _trilock_parse, trilock_tokens, _write_trilock_tokens):
        _TRILOCK_SRC[nm] = tuple(trilock_tokens(act))
        return
    raw = tuple(trilock_tokens(act))
    # 快路径：property 没变 **且** 缓存条目还在。
    # ⚠️ 后半句必需：外部若只清空内存镜像（模拟"重开文件" / 别处重置），
    #    `_TRILOCK_SRC` 还留着 ⇒ 只看 SRC 会误判"缓存有效"，永远不再恢复
    #    （实测被 3 个既有测试抓到：`gui_tri_lock_check` E1/E3、
    #      `gui_frozen_link_check` T3/T5/T13、`gui_endpoint_hollow_check` S6）。
    if _TRILOCK_SRC.get(nm) == raw and (not raw or _cache_has_entries(_TRILOCK, nm)):
        return
    # 变了（首次 / 撤销 / 重做 / 外部改写）⇒ 该 action 的条目**全部重建**
    for k in [k for k in list(_TRILOCK.keys()) if k[0] == nm]:
        _TRILOCK.pop(k, None)
    frames = action_frames(act)          # ★ 僵尸词条自查（见 action_frames 的说明）
    kept = []
    dropped = False
    for tok in raw:
        p = _trilock_parse(tok)
        if p is None:
            continue                 # ★ 旧格式（没署名）⇒ 忽略（不做向下兼容）
        frame, locked, owner = p
        if frames is not None and round(float(frame), 4) not in frames:
            dropped = True           # ★ 指向已删关键帧 ⇒ 僵尸
            continue
        kept.append(str(tok))
        _TRILOCK[(nm, frame, owner)] = bool(locked)
    if dropped:
        try:
            _write_trilock_tokens(act, kept)
            raw = tuple(trilock_tokens(act))
        except Exception:
            pass
    _TRILOCK_SRC[nm] = raw
    _trilock_warmed.add(nm)




def _trilock_lookup(nm, frame, owner):
    # 查三角锁定表：**先精确、再退「未知」桶**（与 `_feel_lookup` 同口径）。
    # 理由见 `_feel_lookup`：拿不到 owner 的路径写进「未知」桶，
    # 若只认精确 owner，那些记录就永远读不回来 ⇒ 按老语义（全局）读。
    try:
        fr = round(float(frame), 4)
    except Exception:
        return None
    v = _TRILOCK.get((nm, fr, str(owner or "")))
    if v is not None:
        return v
    return _TRILOCK.get((nm, fr, ""))


def is_tri_locked(action, frame, bone_name=None, slot=None, owner=None):
    # ★★【唯一的】三角锁定查询。True = 一体（默认），False = 分离。
    #
    # ⚠️ **未记录 ⇒ True**（默认一体）——这是需求里「默认情况下两个三角是一体的」。
    #
    # ★★★ 2026-09-30（D-1/D-2）—— 读写不对称，与 `feel_type_at` 同一套规矩：
    #   · 指名（传了 owner / bone_name / slot）⇒ 先精确、再退「未知」桶
    #   · 裸调（什么都不传）⇒ **通配**：同 (action, 帧) 任一条命中就返回
    #     为什么：裸调是老代码与测试的既有用法，不通配的话它们**全部**读成
    #     「未记录 ⇒ True」—— 等于把「分离」状态全丢掉。
    _wild = (owner is None and bone_name is None and slot is None)
    # ★★ 每次查询前**对账**（property 是唯一真相）——
    #    撤销 / 重做改的是 property，一对账就被感知，**不依赖任何 handler**。
    try:
        _trilock_sync(action)
    except Exception:
        pass
    try:
        nm = str(action.name)
        fr = round(float(frame), 4)
    except Exception:
        return True
    if not _wild:
        k = _trilock_key_of(action, frame, _resolve_owner(owner, bone_name, slot))
        if not k:
            return True
        v = _trilock_lookup(k[0], k[1], k[2])
        return True if v is None else bool(v)
    hits = [(str(kk[2]) if len(kk) > 2 else "", v)
            for kk, v in _TRILOCK.items()
            if kk[0] == nm and kk[1] == fr]
    if not hits:
        return True
    hits.sort(key=lambda x: (x[0] != "", x[0]))
    return bool(hits[0][1])


def set_tri_locked(action, frame, locked, bone_name=None, slot=None, owner=None):
    # 写锁定状态并持久化。
    #
    # `locked=True` ⇒ 把该帧的记录**删掉**（回到默认「一体」，词条与行为都干净）。
    # `locked=False` ⇒ 记一条 SPLIT。
    #
    # ★★★ 2026-09-30（D-1/D-2）：多了 owner（这是**哪根骨骼**的关键帧）。
    #   ⚠️ 调用方最好传 `owner=xf.owner_of_curve(fc)` 或 `owner_of_object(obj, bone)` ——
    #      与账本查询侧**同一套拼装**，否则写进去的记录查不回来。
    #      不传 ⇒ 落「未知」桶（**宁可退化，不可错位**）。
    k = _trilock_key_of(action, frame, _resolve_owner(owner, bone_name, slot))
    if not k:
        return False
    locked = bool(locked)
    if locked:
        _TRILOCK.pop(k, None)
    else:
        _TRILOCK[k] = False
    try:
        toks = []
        for t in trilock_tokens(action):
            p = _trilock_parse(t)
            if p is None:
                continue                     # ★ 旧格式 ⇒ 顺手清掉
            if (p[0], p[2]) == (k[1], k[2]):
                continue                     # 同一个格子 ⇒ 用新的替换
            toks.append(str(t))
        if not locked:
            toks.append(_trilock_token(k[1], locked, k[2]))
        _write_trilock_tokens(action, toks)
        # ★ 写入后同步「对账源」，避免下一次查询白重建一次
        _TRILOCK_SRC[str(action.name)] = tuple(trilock_tokens(action))
    except Exception:
        warn_once("transform_domain.set_tri_locked")
        pass
    return True


def clear_tri_lock(action=None):
    """清锁定记录（action=None 全清；带 action 时连 property 一起删）。"""
    if action is None:
        _TRILOCK.clear()
        _trilock_warmed.clear()
        _TRILOCK_SRC.clear()          # ★ 对账源一起清（否则下次查询会误判"没变"）
        return
    nm = getattr(action, "name", None)
    for k in [k for k in _TRILOCK if k[0] == nm]:
        _TRILOCK.pop(k, None)
    _trilock_warmed.discard(nm)
    _TRILOCK_SRC.pop(nm, None)
    try:
        if _TRILOCK_PROP in action:
            del action[_TRILOCK_PROP]
    except Exception:
        pass


def _feel_lookup(nm, frame, side, owner):
    # 查体感表：**先精确、再退「未知」桶**（唯一入口）。
    #
    # ★ 为什么要退「未知」桶（2026-09-30 · D-1/D-2）：
    #   有些入口（`*_at` 系列）**拿不到关键帧** ⇒ 算不出 owner ⇒ 写进「未知」桶。
    #   若查询只认精确 owner，那些记录就**永远读不回来**（= 写了等于没写）——
    #   实测 D1b：`mark_frozen` 兜底写的 LINK 被读成 None。
    #   ⇒ 「未知」桶按**老语义（全局）**读，也就是「退化成今天的行为」，
    #     正好落实那条原则：**宁可退化，不可错位**。
    #
    # ⚠️ 它**不是**向下兼容老工程（用户 2026-10-01 拍板不做）——
    #   老工程的 token 是 3 段，在**解析阶段**就被丢掉了，压根进不了这个桶；
    #   这个桶只会被「拿不到 owner 的活代码路径」填。
    try:
        fr = round(float(frame), 4)
    except Exception:
        return None
    sd = str(side)
    v = _FEEL.get((nm, fr, sd, str(owner or "")))
    if v is not None:
        return v
    return _FEEL.get((nm, fr, sd, ""))


def feel_type(kp, side):
    """★★【唯一的】体感类型查询。

    返回：'LINK' / 'VECTOR' / 'FREE'，或 **None = 未记录（透传原始类型）**。

    ★ 方案 A 的核心入口：**联动决策只看这里**，不看原始手柄类型。
    """
    k = _feel_key(kp, side)
    if not k:
        return None
    # ★★ 每次查询前对账（撤销/重做改的是 property）—— 不依赖任何 handler。
    try:
        _feel_sync(kp.id_data)
    except Exception:
        pass
    # ★ 走 `_feel_lookup`：先精确 owner、再退「未知」桶（见那个函数的说明）
    return _feel_lookup(k[0], k[1], k[2], k[3])


def effective_feel(kp, side):
    """体感类型 + 透传：未记录时返回**原始手柄类型**（用户没碰过的别管）。

    返回 Blender 的原始类型字符串（'FREE'/'ALIGNED'/'AUTO'/'AUTO_CLAMPED'/'VECTOR'）。
    """
    v = feel_type(kp, side)
    if v is not None:
        return v
    try:
        return str(kp.handle_left_type if str(side) == 'left'
                   else kp.handle_right_type)
    except Exception:
        return 'ALIGNED'


def orig_type_for_feel(value):
    """体感类型 ⇒ 要写的**原始手柄类型**（实现细节）。

    ★ 方案 A：原始类型只为"不让 Blender 乱动"服务：
        'LINK'    → 'ALIGNED'      （原生"保持一条直线"，会被 Blender 维护）
        'CLAMPED' → 'AUTO_CLAMPED' （同上 + 钳制防过冲）
        'VECTOR'  → 'VECTOR'       （贴到控制点）
        'FREE'    → 'FREE'         （定住，Blender 绝不动）
    """
    return {'LINK': 'ALIGNED', 'CLAMPED': 'AUTO_CLAMPED',
            'VECTOR': 'VECTOR'}.get(str(value).upper(), 'FREE')


def feel_for_orig_type(t):
    """原始手柄类型 ⇒ 该登记的**体感**。

    ⚠️ 2026-09-30（Review 修正文档）：**不是** `orig_type_for_feel` 的严格逆 ——
        `orig_type_for_feel('FREE') = 'FREE'`，而本函数 `feel_for_orig_type('FREE') = None`。
        这个**不对称是故意的**（FREE = 用户手动要的自由 ⇒ **不登记**）。
        别写"往返相等"的断言。

    ★★【唯一实现】—— `spec_check._feel_for_orig_type` 委托到这里（别写两份）。

    为什么要这一步：转成 FREE 之后，`_link_mode` 对"未记录 + 原始 FREE"
    会返回 'free' ⇒ 插件的手柄联动**不再生效**（用户会感觉"拖一侧另一侧不跟了"）。
    所以**转类型之前**必须先登记体感。

    ⚠️⚠️ 原始是 FREE 时返回 **None**（= **不登记**）：
        那是"用户手动要的自由"，不是插件接管 ——
        登记成 LINK 会把用户的 FREE 冲掉（2026-09-30 用户报障的根因之一）。
    """
    t = str(t)
    if t == 'VECTOR':
        return 'VECTOR'
    if t in ('AUTO', 'AUTO_CLAMPED', 'ALIGNED'):
        return 'LINK'
    return None


def feel_type_at(action, frame, side, bone_name=None, slot=None, owner=None):
    # 按 (action, 帧号, 侧, owner) 查体感记录（**不需要 keyframe 对象**）。
    #
    # 与 `mark_feel_at` / `unmark_feel_at` 配对，供 `time_domain` 这类
    # 只拿得到 (action, 帧号) 的调用方使用。
    #
    # ⚠️ owner 的说明同 `mark_feel_at`：**查询与写入必须用同一套拼装**，
    #    否则写进去的记录查不回来（读成 None = 「未记录」）。
    #
    # 返回 'LINK' / 'VECTOR' / 'FREE'，或 **None = 未记录（透传原始类型）**。
    #
    # ★★★ 2026-09-30（D-1/D-2）—— **读写不对称**，这是刻意定的规矩：
    #
    #   ┌ 写（mark_feel_at）: 不知道是谁 ⇒ 落「未知」桶（owner = 空串）
    #   └ 读（本函数）      : **不指名 ⇒ 谁的无所谓（通配）**
    #
    #   为什么读要通配：裸调（feel_type_at(act, 帧, 侧)，不说找谁）是
    #   **老代码与测试的既有用法**。要是读也必须指名道姓，
    #   那些调用**全部**会读成 None（= 「没记录」）—— 等于把老功能关掉。
    #   实测踩到：D4 报「轮0 切回A feel=None」（本该 'FREE'）。
    #
    #   打个比方：前台收快递。没写门牌的先放待认领区；
    #     老员工问「90 帧有快递吗？」（不指名）⇒ 答「有」；
    #     新员工问「大臂的快递呢？」⇒ 精确查「大臂」。
    #
    #   ⚠️ 通配**只能用在查询**上。写侧那句「已有记录就不覆盖用户选择」的守卫
    #      （见 time_domain.mark_frozen）**必须用精确 owner**，
    #      否则会变成「别的骨骼有记录 ⇒ 我就不写了」—— bug 换个方向又犯一遍。
    _wild = (owner is None and bone_name is None and slot is None)
    try:
        if _wild:
            k = None
        else:
            k = _feel_key_of(action, frame, side,
                             _resolve_owner(owner, bone_name, slot))
    except Exception:
        return None
    if not _wild and not k:
        return None
    # ★ 每次查询前对账（撤销/重做改的是 property）—— 与 feel_type 同款
    try:
        _feel_sync(action)
    except Exception:
        pass
    if not _wild:
        return _feel_lookup(k[0], k[1], k[2], k[3])
    # ---- 通配读：同 (action, 帧, 侧) 里任一条命中就返回 ----
    # ⚠️ 多条命中时必须给出**确定的**答案（否则同一查询两次结果不同）：
    #    优先「未知」桶那条（老数据/兜底那条），否则取 owner 字典序最小的。
    try:
        nm = str(action.name)
        fr = round(float(frame), 4)
        sd = str(side)
    except Exception:
        return None
    hits = [(str(kk[3]) if len(kk) > 3 else "", v)
            for kk, v in _FEEL.items()
            if kk[0] == nm and kk[1] == fr and kk[2] == sd]
    if not hits:
        return None
    hits.sort(key=lambda x: (x[0] != "", x[0]))
    return hits[0][1]


def _link_mode(kp, moved_side):
    """【唯一的】联动判据：被拖侧动了之后，对侧该怎么处理？

    返回（**只有这三个**）：
        'link'   —— 对侧绕 co 旋转保持共线
        'vector' —— 对侧贴到控制点
        'free'   —— 完全不动

    ★★ 2026-09-17（方案 A）：判据**只看体感手柄类型**，不再看原始类型 +
       两张登记表的组合。映射关系（保证与改造前**行为一致**）：

        体感 'LINK'   ← 原来的 ALIGNED / AUTO* / 插件冻的 FREE / 插件接管的 FREE
        体感 'VECTOR' ← 原来的 VECTOR
        体感 'FREE'   ← 原来的"用户手动设的 FREE"
        未记录        → 透传原始类型（新关键帧：插件没碰过就不管）

    原有两条关键语义仍然成立：
      · Automatic 系手柄「convert to Align handles when moved」→ 归入 'link'
      · "插件冻的 FREE"必须继续联动，否则端点模态不联动、鼠标路径却联动 → 跳变
    """
    opp = 'right' if str(moved_side) == 'left' else 'left'

    # ① 体感表有记录 → 按体感走（权威）
    try:
        v = feel_type(kp, opp)
    except Exception:
        v = None
    if v == 'VECTOR':
        return 'vector'
    if v == 'FREE':
        return 'free'
    if v in ('LINK', 'CLAMPED'):
        # 'LINK'（Aligned）与 'CLAMPED'（Auto Clamped）的**联动行为相同**，
        # 区别只在原始类型（Auto Clamped 多一层钳制）⇒ 联动判据都归 'link'。
        return 'link'

    # ② 未记录 → 透传原始类型（保持与改造前完全一致的判定）
    t = str(kp.handle_left_type if opp == 'left' else kp.handle_right_type)
    if t == 'VECTOR':
        return 'vector'
    if t in ('AUTO', 'AUTO_CLAMPED'):
        return 'link'
    if t == 'FREE':
        # ⚠️ 未记录但原始是 FREE —— 兼容旧工程的存量数据：
        #    仍查一次旧登记表（老 .blend 里只有 rtmp_owned_free / rtmp_frozen）。
        try:
            if _is_plugin_frozen(kp) or _is_plugin_owned_free(kp, opp):
                return 'link'
        except Exception:
            warn_once("transform_domain._link_mode")
            pass
        return 'free'
    return 'link'


# ---------------------------------------------------------------------------
# 收集选中的关键帧
# ---------------------------------------------------------------------------

_collect_all = None
_is_pos = None
try:
    from .cache import (collect_animation_curves as _collect_all,
                        is_position_animation as _is_pos)
except Exception:
    try:
        from cache import (collect_animation_curves as _collect_all,
                           is_position_animation as _is_pos)
    except Exception:
        pass


def _position_curves(action, obj, bone_name=None):
    if _collect_all is None or _is_pos is None:
        return []
    try:
        return [fc for fc in _collect_all(action, obj) if _is_pos(fc, bone_name)]
    except Exception:
        warn_once("transform_domain._position_curves")
        return []


def collect_selected_frames(action, obj, bone_name=None):
    """返回 {frame: {axis: fcurve}} —— 有任一轴控制点被选中的帧。

    ⚠️ 只返回【fcurve】，不返回 keyframe 对象：keyframe 包装对象用过一次会「钝」
       （见 blender-addon-dev skill），所以每次操作用的时候现取。
    """
    out = {}
    for fc in _position_curves(action, obj, bone_name):
        for kp in fc.keyframe_points:
            if kp.select_control_point:
                out.setdefault(round(float(kp.co[0]), 4), {})[fc.array_index] = fc
                # ⚠️ 这里【不能 break】：同一条 fcurve 上可以有多个被选中的关键帧，
                #    提前 break 会导致"多选时只有第一个点跟着动"（实测抓到的 bug）。
    return out


def keyframe_at(fcurve, frame):
    """按【最近匹配】找关键帧（容差 1e-3）。

    ⚠️ 容差必须远小于常见帧距。**关键帧可以只相隔 0.4 帧**（agent 实测发现），
       原来用 `< 0.5` 时，帧距 < 0.5 的相邻关键帧会被同一个 frame 匹配到
       → 写入**错的**关键帧 → 用户看到"操作完全没反应"
       （实测：帧距 0.4 时 R 无效果，帧距 0.6 时正常）。

       `collect_selected_frames` 用的 key 是 `round(co[0], 4)`（精确帧号），
       所以这里用 1e-3 的精确容差即可，既能正确匹配、又能区分相邻关键帧。
    """
    best = None
    best_d = FRAME_EPS
    for kp in fcurve.keyframe_points:
        d = abs(kp.co[0] - frame)
        if d < best_d:
            best_d = d
            best = kp
    return best


def snapshot_positions(action, obj, frames, bone_name=None):
    """记录这些帧的 co / handle 的【值分量】+ 手柄【类型】。

    返回 {frame: {axis: {'co': v, 'hl': v, 'hr': v, 'hlt': t, 'hrt': t}}}

    `hlt` / `hrt` 用来在【取消】时恢复手柄类型（见 make_handles_editable）。
    """
    snap = {}
    for frame, axis_map in frames.items():
        per_axis = {}
        for axis, fc in axis_map.items():
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            per_axis[axis] = {
                'co': float(kp.co[1]),
                'hl': float(kp.handle_left[1]),
                'hr': float(kp.handle_right[1]),
                # ★ 时间分量也要记（P2 加权会改对侧的 dt —— 不记就还原不了）
                'hl_t': float(kp.handle_left[0]),
                'hr_t': float(kp.handle_right[0]),
                'hlt': str(kp.handle_left_type),
                'hrt': str(kp.handle_right_type),
            }
        snap[frame] = per_axis
    return snap


def make_handles_editable(action, obj, frames, bone_name=None):
    """把选中关键帧的两侧手柄转成 FREE（**保留坐标**），返回改前的类型以便恢复。

    ⚠️⚠️ 为什么必须做（2026-09-16 实测，见 tests 里的假说验证）

    Blender 新建关键帧的默认手柄类型是 **AUTO_CLAMPED** —— 派生类型，
    手柄坐标由 Blender 的公式**导出**，**不接受外部写入**（`fc.update()` 会覆盖）。

    实测（单点旋转 30°，纯直线路径）：

        FREE          Δhandle = 0.800000   手柄生效 ✓
        AUTO_CLAMPED  Δhandle = 0.000000   ★ 手柄被吞掉 → 看起来"完全没反应"
        ALIGNED       Δhandle = 0.800000   手柄生效

    多点旋转同样受害：AUTO_CLAMPED 下手柄只跟着 co 平移（Δ=1.0），
    而正确值应是 1.8 —— **形状也是错的**。

    这与 Blender 原生的语义一致：在 Graph Editor 里显式变换一个手柄，
    它就会变成 FREE（因为用户接管了它）。
    """
    prev = {}
    for frame, axis_map in frames.items():
        for axis, fc in axis_map.items():
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            prev[(frame, axis)] = (str(kp.handle_left_type), str(kp.handle_right_type))
            hl = kp.handle_left.copy()
            hr = kp.handle_right.copy()
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
            kp.handle_left = hl            # 转类型时 AUTO 系会重算坐标 → 写回原值
            kp.handle_right = hr
            # ★★ 2026-09-17 修复：登记「这是**插件转的** FREE」并持久化。
            #
            #    漏了这一步的后果（用户实测复现）：
            #      「选中关键帧 → 缩放使两侧手柄缩到关键帧点 → 插件长出空心圆
            #        → 拖一侧空心圆拉出手柄 → 再拖另一侧 → 两根手柄对不上」
            #    因为 `confirm()` 不恢复类型（只有 `cancel()` 恢复），两侧就此停在
            #    **未登记**的 FREE ⇒ `_link_mode` 判成"用户手动 FREE" ⇒ 对侧不联动。
            #    实测：漏登记的路径 3D 共线偏差 **0.6899**；补上登记后 **1.19e-07**。
            #
            #    键不含 axis ⇒ 多轴重复调用幂等（`mark_owned_free` 走 set + 去重写）。
            mark_owned_free(kp, 'left')
            mark_owned_free(kp, 'right')
            # ★ 方案 A：体感类型 = **LINK**（不是 FREE！）
            #   转原始 FREE 只是"为了写得进坐标"（实现细节）；
            #   体感上插件接管后**要继续联动对侧** —— 这正是上一轮
            #   「两根手柄对不上」的根因：漏登记 ⇒ 判成"用户手动 FREE" ⇒ 不联动。
            #
            # ★★★ 2026-09-30 修 D-3（Phase 1 极限测试抓到，FAIL/中）——
            #     这里**原先还有两行** `mark_feel(kp, 'left'/'right', 'LINK')`，
            #     是**无条件**写的。它把上面 `mark_owned_free` 里那道守卫
            #     「已记录的不覆盖用户的选择」**整个架空了** ——
            #     实测：`mark_feel(kp,'left','FREE')`（用户显式设"不动"）之后
            #     过一遍本函数（= 进一次 G/R/S 关键帧模态的真实入口）：
            #         feel_left  FREE → **LINK**，拖右侧时左侧从"不动"变成"跟着动"
            #     ⇒ 用户的选择被**静默抹掉**，且**没有任何提示**。
            #
            #     ⚠️ Batch 1 只给 `mark_owned_free` 补了守卫，**没发现这两行**
            #        ⇒ 那条修复当时**完全无效**（门口装了防盗门、后门大开着）。
            #     ⇒ 按"同一语义只留一个来源"删掉这两行：
            #        "接管时写 LINK" 这件事**只有** `mark_owned_free` 一处负责，
            #        它内部是**带守卫**的（未记录才写）—— 2026-09-17 那条修复不受影响
            #        （新关键帧的 feel 本来就是 None ⇒ 照样登记成 LINK）。
    return prev


def prepare_handles_for_drag(action, obj, endpoints, bone_name=None,
                             link_opposite=True):
    """★ 拖动手柄前的【类型接管】——按 Blender **原生语义**，两条路径共用。

    ▎原生依据（官方手册原文，F-Curve Properties → Left/Right Handle Type）
        · Automatic / Auto Clamped：「These handles **convert to Align handles
          when moved**.」
        · Vector：「Vector handles **convert to Free handles when moved**.」
        · 「If you want to change an automatic handle's position, **just drag it**;
           you don't need to manually change its type first.」

    ▎为什么必须做（2026-09-16 实测，`_probe4.py`）
        默认工程的手柄是 **AUTO_CLAMPED**（`keyframe_insert` 的默认），
        它的坐标由 Blender 公式**导出**，不接管的话：

        | 场景 | 对侧共线偏差 | 对侧臂长 |
        |---|---:|---:|
        | 默认 AUTO_CLAMPED（不接管） | 0.184 → **0.832** ✗ | 1.33333 → **1.16667**（被重算） |
        | 两侧 ALIGNED（本函数接管后） | **0.0 全程** ✓ | **1.33333 守恒** ✓ |

        ⇒ 用户看到的第一步"**跳**" = 对侧被 Blender 重算导致臂长突变；
          "拖动后不对齐" = 对侧永远按 AUTO_CLAMPED 公式走，与插件要的共线无关。

    ▎两条规则
        · **被拖侧**：`AUTO/AUTO_CLAMPED → ALIGNED`、`VECTOR → FREE`（原生）
        · **对侧**（`link_opposite=True`）：`AUTO/AUTO_CLAMPED → ALIGNED`
          —— 不接管的话 Blender 会重算它，就**永远无法共线**。
          ALIGNED 的语义本就是「handles remain on a straight line」，
          两侧都转正是"保持一条直线"的实现。

    ▎不动的类型
        · `ALIGNED` / `FREE`：本来就写得进去（共线语义要保留 / 自由手柄独立）
        · **对侧的 `VECTOR`**：那是用户明确设的「贴相邻关键帧」语义，
          与共线是两回事（保留 agent 的 E 组契约）。
          被拖侧自己若是 VECTOR 则按原生转 FREE。

    ⚠️ 幂等：已是目标类型就跳过 → 可以每次 MOUSEMOVE 调，代价可忽略。

    ⚠️ **故意不调 `fc.update()`**：调用方在这之前已经把 `frame_kf_map` 里的
       keyframe **引用缓存**了，update 会让引用陈旧 → 后续写入落到错的轴上
       （实测：拖 (0,3,0) 变成 axis1 动 2.51、axis2 动 3.0）。

    ------------------------------------------------------------------
    ▎为什么**必须**接管（`_gap5.py` 实测，默认工程，鼠标直接拖手柄）

        | 拖拽侧手柄类型 | 被拖侧位移（期望 3.0） |
        |---|---:|
        | FREE          | 3.0000 ✓ |
        | ALIGNED       | 3.0000 ✓ |
        | AUTO_CLAMPED  | **0.0000 ✗** ← 新建关键帧的默认类型 |
        | VECTOR        | **0.0000 ✗** |

        ⇒ **默认场景下用户拖手柄完全没反应**。根因：派生类型的手柄坐标由
          Blender 公式**导出**，`fc.update()` 会把外部写入覆盖掉。

    ▎为什么**两侧都要**接管（5×5 类型矩阵实测）

        只接管被拖侧时，**对侧是派生类型**同样会让被拖侧写不进去：
            拖侧 ALIGNED + 对侧 VECTOR        → 位移只剩 **0.048**/3.0
            拖侧 ALIGNED + 对侧 AUTO_CLAMPED  → 位移只剩 **0.012**/3.0
        原因：ALIGNED 是「与对侧共线」的约束，对侧被 Blender 重算后会把
              被拖侧一起带走。
        全类型矩阵接管后：**25/25 组合位移精确 3.0000**。

    :return: 改前的类型 {(frame, axis): (lt, rt)}，交给 `restore_converted_types` 还原
    """
    prev = {}
    curves = _position_curves(action, obj, bone_name)
    if not curves:
        return prev
    for (frame, side) in (endpoints or []):
        f = float(frame)
        s = str(side)
        opp = 'right' if s == 'left' else 'left'
        plan = [(s, False)]
        if link_opposite:
            plan.append((opp, True))        # 第二个元素：是不是"对侧"
        for fc in curves:
            kp = keyframe_at(fc, f)
            if kp is None:
                continue
            for (sd, is_opp) in plan:
                attr = 'handle_left_type' if sd == 'left' else 'handle_right_type'
                cur = str(getattr(kp, attr))
                if is_opp and cur == 'VECTOR':
                    continue                # 对侧 VECTOR = 用户显式语义，保留
                new_t = _DRAG_TO_TYPE.get(cur)
                if new_t is None:
                    continue                # ALIGNED / FREE 保持
                key = (f, fc.array_index)
                if key not in prev:
                    prev[key] = (str(kp.handle_left_type), str(kp.handle_right_type))
                h = kp.handle_left.copy() if sd == 'left' else kp.handle_right.copy()
                setattr(kp, attr, new_t)
                # 转类型时 Blender 可能重算坐标 → 原样写回（"转类型不动手柄"）
                if sd == 'left':
                    kp.handle_left = h
                else:
                    kp.handle_right = h
    # ⚠️ 故意不 update()（见 docstring）
    return prev




def restore_handle_types(action, obj, frames, prev, bone_name=None):
    """把 `make_handles_editable` 记下的类型写回去（取消时用）。"""
    if not prev:
        return
    for frame, axis_map in frames.items():
        for axis, fc in axis_map.items():
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            t = prev.get((frame, axis))
            if not t:
                continue
            hl = kp.handle_left.copy()
            hr = kp.handle_right.copy()
            kp.handle_left_type = t[0]
            kp.handle_right_type = t[1]
            kp.handle_left = hl
            kp.handle_right = hr
            # ★ 2026-09-17 配套：类型被**恢复**了 ⇒ 取消登记，
            #   免得陈旧条目让"用户手动 FREE"被误判成"插件接管"（误联动）。
            unmark_owned_free(kp, 'left')
            unmark_owned_free(kp, 'right')


def restore_positions(action, obj, snapshot, bone_name=None):
    """把 snapshot 里的值写回（每次现取 keyframe，避免「钝」对象）。"""
    curves = _position_curves(action, obj, bone_name)
    by_axis = {}
    for fc in curves:
        by_axis[fc.array_index] = fc

    for frame, per_axis in snapshot.items():
        for axis, vals in per_axis.items():
            fc = by_axis.get(axis)
            if fc is None:
                continue
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            kp.co = (kp.co[0], vals['co'])
            # ★ 时间分量一并还原（缺了它，P2 加权改过的 dt 会残留）
            hlt_t = vals.get('hl_t', kp.handle_left[0])
            hrt_t = vals.get('hr_t', kp.handle_right[0])
            kp.handle_left = (hlt_t, vals['hl'])
            kp.handle_right = (hrt_t, vals['hr'])
    for fc in curves:
        fc.update()


# ---------------------------------------------------------------------------
# 约束（锁轴 / 锁平面 / 精度）
# ---------------------------------------------------------------------------

def apply_axis_lock(offset, axis_lock=None, plane_lock=None):
    """对世界空间偏移施加约束。

    axis_lock : 'X' / 'Y' / 'Z'   —— 只保留该轴分量（单轴）
    plane_lock: ('X','Y') 等       —— 只保留该平面的两个分量
    """
    v = mathutils.Vector(offset)
    if plane_lock:
        keep = {AXIS_INDEX[a] for a in plane_lock if a in AXIS_INDEX}
        for i in range(3):
            if i not in keep:
                v[i] = 0.0
        return v
    if axis_lock and axis_lock in AXIS_INDEX:
        keep = AXIS_INDEX[axis_lock]
        for i in range(3):
            if i != keep:
                v[i] = 0.0
        return v
    return v




# ---------------------------------------------------------------------------
# 平移
# ---------------------------------------------------------------------------

def world_offset_to_local(offset, parent_matrix):
    """世界空间偏移 → 关键帧所在的父级空间偏移。"""
    return parent_matrix.to_3x3().inverted() @ mathutils.Vector(offset)


def is_safe(offset):
    return all(abs(c) < SAFE_LIMIT for c in offset)


# ---------------------------------------------------------------------------
# 写入 vs 绘制：两套限制
# ---------------------------------------------------------------------------

# 写入用上限：只挡 NaN / Inf 和荒谬溢出。
WRITE_LIMIT = 1e12

# ★ P2 加权手柄：对侧手柄时间长度的缩放系数 k 的保护范围
# ⚠️ 2026-09-16（第十轮）加权已**停用** → 这两个常量目前**只被已停用的
#    `_apply_weight` 使用**（全仓唯一引用点在其函数体内）。
#    跟着它一起留着：将来若把加权做成开关，直接复用。
#   实测：拖拽量很小时 k 会很大（(0.5,0,0) 时 k=6.53）
_K_MIN = 1e-3
_K_MAX = 1e3

# 最近一次写入被拒的原因（供状态栏提示 —— 不静默）
last_skip_reason = None

# ★ 最近一次 `apply_endpoint_transform` 为写入而临时改过的类型映射
#   {(frame, axis): (hl_type, hr_type)}
#   调用方在"取消/结束"时必须用它恢复（否则 AUTO/AUTO_CLAMPED/VECTOR 会被永久改成 FREE）
last_converted_types = {}

# ★★ 拖动期间的【手柄时间分量原始值】{(frame, axis): (hl_t, hr_t)}
#
# 由 `snapshot_endpoints` 在**拖动开始**时整体重置并采集（那里是唯一的采集点，
# 不能在每次 MOUSEMOVE 调用的 `prepare_handles_for_drag` 里重采 —— 会把中途
# 漂移固化成"原值"）。`_seal_opposite_handle` 读它把对侧 dt 写回。
#
# 用途：拖动过程中我们（以及 Blender 的 ALIGNED）会经由若干次 `fc.update()`
#       把对侧 dt 改掉；收尾时用它**写回原值**，保证用户的速度分布一个数不动。
#
# ⚠️ 已知两点（2026-09-16 code review 记录，尚未处理）：
#   1. **键不含 action 身份**（只有 frame + axis）。同一会话里另一个 action
#      的同名帧会撞键。目前靠"`snapshot_endpoints` 每次拖动开始必重置"兜住，
#      但若某条路径调了 `_seal_opposite_handle` 而没先 `snapshot_endpoints`，
#      理论上会写错值。修法：键里加 `act.as_pointer()`，或直接把这个 dict
#      挂进 `session.endpoint_snapshot` 与它同生共死。
#   2. **"用完即清"没有实现** —— `_seal_opposite_handle` 读完后并不清空，
#      只有下一次 `snapshot_endpoints` 才会重置。所以它是"活到下次拖动开始"。
_drag_dt_origin = {}


def _drag_dt_key(frame, axis):
    return (round(float(frame), 4), int(axis))


def _seal_opposite_handle(curves, frame, side):
    """把【对侧】手柄「封口」：① 类型转 FREE  ② 时间分量写回拖动前的值。

    ⚠️⚠️ 为什么必须做（2026-09-16 实测，`_probeZ.py`）—— 这是用户第十轮反馈的根因：

        对侧若保持 **ALIGNED**，那么**任何一次后续 `fc.update()`**（下一次重绘、
        下一次操作、拖别的关键帧……）都会让 Blender 按它的 "(t,v) 平面共线"
        规则**重算对侧手柄**。而那个约束与插件要的 **3D 值空间共线不等价**：

            实测（对侧 ALIGNED，拖完后再来一次 update）：
                3D 点线距   1.452e-07  →  **0.2697**   ← 3D 形状**破相**
                对侧 dt     13.0       →  **11.07**    ← 速度分布被改
                对侧臂长     1.33333    →   1.33333

            实测（对侧 FREE，同样条件）：
                3D 点线距   1.452e-07  →  1.452e-07  ← 稳定
                对侧 dt     13.0       →  **13.0**     ← 稳定

        ⇒ 转 FREE 后 Blender 不再去动它 → 3D 形状稳定、速度分布稳定。
          用户拍板「一切以 3D 视图体验优先，Graph Editor 不需要共线」，
          所以这个取舍正是要的。

    ⚠️ 调用时机：只在 `_link_mode` 返回 **'link'** 时走到这里
       （`maintain_linked_handle` 里 `mode == 'free'` 会提前 return）。

       因此会被封口的对侧类型是：**ALIGNED / AUTO / AUTO_CLAMPED /
       插件冻的或接管的 FREE** —— 它们都会被转成 FREE。

       （⚠️ 早先这里写"对侧 AUTO* 不碰"是**错的**：`_link_mode` 对 AUTO*
       返回 'link'（原生语义 "convert to Align when moved"），所以 AUTO_CLAMPED
       对侧**确实会被接管成 FREE**。这是有意行为 —— 不接管的话 Blender 会按
       它自己的规则重算对侧，3D 形状与 dt 都不稳定。）

       唯一**不会**被封口的是：用户手动设的 FREE、以及 VECTOR
       （`mode` 分别是 'free' / 'vector'，在 `maintain_linked_handle` 里就分流了）。
    """
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        attr = 'handle_left_type' if side == 'left' else 'handle_right_type'
        hattr = 'handle_left' if side == 'left' else 'handle_right'
        # ① 时间分量写回原值
        k = _drag_dt_key(frame, fc.array_index)
        if k in _drag_dt_origin:
            hl_t, hr_t = _drag_dt_origin[k]
            t0 = hl_t if side == 'left' else hr_t
            v = getattr(kp, hattr)[1]
            setattr(kp, hattr, (float(t0), float(v)))
        # ② 类型转 FREE（Blender 之后不再重算它）
        if str(getattr(kp, attr)) != 'FREE':
            h = getattr(kp, hattr).copy()
            setattr(kp, attr, 'FREE')
            setattr(kp, hattr, h)      # 转类型时可能重算 → 原样写回
        # ③ 登记为「插件接管的 FREE」→ 后续仍按 'link' 联动，**并持久化**
        #    （否则同一次拖动里的下一次调用读到 FREE 就不联动了，实测偏差 0.88；
        #      不持久化则重启 Blender 后体感类型丢失）
        mark_owned_free(kp, side)
        # ★ 方案 A：体感类型 = LINK（封口后仍要联动，这才是权威语义）
        mark_feel(kp, side, 'LINK')


def take_converted_types():
    """取出并清空"临时转换的类型映射"（调用方收尾时用）。"""
    global last_converted_types
    out = dict(last_converted_types)
    last_converted_types = {}
    return out


def _reset_skip():
    global last_skip_reason
    last_skip_reason = None


def is_writable(v):
    """写入用的合法性检查。

    ⚠️ 与 `is_safe` 的区别（agent 实测发现的缺陷）：

      · `is_safe` 用 `SAFE_LIMIT = 1e6`，那是**绘制**用的（防 GPU 驱动崩溃）。
      · 原先写入也用它 → **缩放 1e7 倍时会静默跳过**：
        实测 `factor = 1e7` 但点间距纹丝不动，用户以为"没反应"，且毫无提示。

    数据合法性 与 绘制安全性 应该分开：
      写入允许大坐标（用户确实可能想要），绘制时再裁剪。
    """
    try:
        return all(math.isfinite(c) and abs(c) < WRITE_LIMIT for c in v)
    except Exception as _e:
        # ⚠️ 绝不静默：这里曾把 `NameError: name 'math' is not defined`
        #    悄悄转成"数值不安全"，导致所有变换失效且无从排查（实测踩过）。
        print("RealTimeMotionPath: is_writable 异常 -> %r" % (_e,))
        return False


def apply_translation(action, obj, snapshot, local_delta, bone_name=None,
                      only_handles=False):
    """把 snapshot 的原始位置 + local_delta 应用到场景。

    ⚠️ 每次都从 snapshot 重新算（而不是累加），避免浮点累积误差，
       也让「取消」只需 restore 一次。
    """
    dx, dy, dz = local_delta[0], local_delta[1], local_delta[2]

    def fn(_frame, v):
        return mathutils.Vector((v[0] + dx, v[1] + dy, v[2] + dz))

    return apply_point_transform(action, obj, snapshot, fn, bone_name,
                                 only_handles=only_handles)




# ---------------------------------------------------------------------------
# 统一的点群变换（G/R/S 共用）
# ---------------------------------------------------------------------------

def _point_from(snapshot, frame, key):
    """把某帧的某个顶点（'co' / 'hl' / 'hr'）组装成**完整三维点**。

    ⚠️ 必须用三个轴的值一起组装。只取单轴（如 (0, y, 0)）会丢掉其它轴信息，
       旋转/缩放的结果就不是刚体变换（实测：|p| 从 5 变成 6.12）。
    """
    v = [0.0, 0.0, 0.0]
    for axis, vals in snapshot.get(frame, {}).items():
        if 0 <= axis <= 2 and key in vals:
            v[axis] = vals[key]
    return mathutils.Vector(v)




def snapshot_endpoints(action, obj, endpoints, bone_name=None):
    """记录端点相关的三个值（co 也记，但变换时不动 co）。

    ★★ 本函数是【拖动开始】的那个时刻 —— 因此它同时负责把
       `_drag_dt_origin`（手柄时间分量的原值）刷新成当前值。
       收尾的 `_seal_opposite_handle` 依赖它把对侧 dt 写回。

    ⚠️ 采集点必须在这里（**拖动开始**），不能在每次 MOUSEMOVE 调用的
       `prepare_handles_for_drag` 里 —— 那里重采会把中途的漂移固化成"原值"。
       同一语义只留一个来源（这是踩过的坑）。
    """
    global _drag_dt_origin
    _drag_dt_origin = {}          # 新一次拖动 → 重新采集
    snap = {}
    for (frame, side) in endpoints:
        per_axis = {}
        for fc in _position_curves(action, obj, bone_name):
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            per_axis[fc.array_index] = {
                'co': float(kp.co[1]),
                'hl': float(kp.handle_left[1]),
                'hr': float(kp.handle_right[1]),
                # ★ 时间分量也要记（对侧的 dt 会在拖动途中被改 —— 不记就还原不了）
                'hl_t': float(kp.handle_left[0]),
                'hr_t': float(kp.handle_right[0]),
                'hlt': str(kp.handle_left_type),
                'hrt': str(kp.handle_right_type),
            }
            _drag_dt_origin[_drag_dt_key(frame, fc.array_index)] = (
                float(kp.handle_left[0]), float(kp.handle_right[0]))
        if per_axis:
            snap[float(frame)] = per_axis
    return snap


def _read_handle_point(curves, frame, side):
    """读某帧某一侧手柄的【三维点】（= 三个轴的值分量）。"""
    v = [0.0, 0.0, 0.0]
    got = False
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        h = kp.handle_left if side == 'left' else kp.handle_right
        v[fc.array_index] = float(h[1])
        got = True
    return mathutils.Vector(v) if got else None


def _set_handle_point(curves, frame, side, vec):
    """把某帧某一侧手柄写成给出的【三维点】（时间分量保持不变）。"""
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        if side == 'left':
            kp.handle_left = (kp.handle_left[0], float(vec[fc.array_index]))
        else:
            kp.handle_right = (kp.handle_right[0], float(vec[fc.array_index]))


def _kp_of(curves, frame):
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is not None:
            return kp
    return None


def _scale_handle_time(curves, snapshot, frame, side, scale):
    """把某帧某一侧手柄的【时间分量】按 scale 缩放（绕关键帧帧号）。

    ★ 端点模式 S 缩放【保速】用（用户 2026-09-17）：
      速度 = |dv / dt|；`_set_handle_point` 只写值分量 ⇒ 速度 ×scale。
      让 dt 也 ×scale ⇒ 速度不变（= 在「值-时间」平面上等比缩放）。

    ⚠️ 基准时间必须从 **snapshot** 读（进模态那一刻的原始值）——
       模态里鼠标每动一次就 _apply 一次，从 kp（当前值）读会**累乘 k^n**。
    """
    vals = (snapshot or {}).get(float(frame)) or (snapshot or {}).get(frame) or {}
    co_t = float(frame)
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        _v = vals.get(fc.array_index) or {}
        if side == 'left':
            t0 = float(_v.get('hl_t', kp.handle_left[0]))
            kp.handle_left = (co_t - (co_t - t0) * float(scale), float(kp.handle_left[1]))
        else:
            t0 = float(_v.get('hr_t', kp.handle_right[0]))
            kp.handle_right = (co_t + (t0 - co_t) * float(scale), float(kp.handle_right[1]))


def maintain_linked_handle(curves, frame, moved_side, co_p, moved_p,
                           opp_len=None, weighted=True, zero_eps=_ARM_EPS):
    """移动一个手柄端点后，按【原生曲线编辑】的语义维护对侧手柄。

    | 对侧类型 | 原生行为 | 本实现 |
    |---|---|---|
    | `ALIGNED` | 绕 co **旋转**保持共线，**长度不变** | 加权时改为"长度按比例伸缩"（见下） |
    | `AUTO` / `AUTO_CLAMPED` | Blender 按公式重算 | 不干预（交给 Blender） |
    | `VECTOR` | 对侧贴到控制点（值方向） | 同左 |
    | `FREE` | 完全独立，不动 | 同左 |

    ⚠️ 这修的是用户实测的两个问题（2026-09-16）：
      · 「手柄本来是 aligned 对齐的，G 移动后变得有折角了」
      · 「S 旋转选中的端点，旋转的却是对向的端点」
    旧实现直接把手柄转 FREE 后**平移**，既丢掉了共线、又动了不该动的那一侧。

    ---------------------------------------------------------------------
    ★★ P2 轻量解（2026-09-16 实测 + 业界对照）—— **已停用，见文末 ⚠️**

    只写"值分量"能保证 3D 共线，但 **(t,v) 平面会出折角**（实测最大 13.36°，
    因为 Blender 的重排按各轴自己的 `dt` 走）。

    （当时的）解法：**让对侧手柄的时间长度按同一个比例 k 缩放**
    （= Maya 的 "Weighted Tangents"）：

        k = L_opp / |moved3 − co3|
        对每个轴 A：dtR_A = dtL_A × k

    数学（已独立验算）：设 λ=1/(1+k)，则
      · (t,v) 共线要求 `co_v = hl_v + λ(hr_v − hl_v)`
      · 3D 共线要求   `hr3 = co3 − (L_opp/|d3|)·d3`
      · 两者相等 ⟺ `k = L_opp/|d3|`  ✓ 自洽

    实测（点到直线距离，避开 acos 噪声）：
      | 拖拽量 | k | 3D 点线距 | (t,v) 最大折角 |
      | (1,0,0) | 3.2642 | 0.000e+00 | 0.000001° |
      | (0.5,0,0) | 6.5284 | 0.000e+00 | 0.000000° |
      | (3,0,0) | 1.0881 | 0.000e+00 | 0.000002° |
      | (3,3,3) | 0.6282 | 0.000e+00 | 0.000001° |

    ⚠️ 上面这套"同时共线"的做法**已于 2026-09-16（第十轮）停用** ——
       用户拍板：**一切以 3D 视图手柄体验优先，Graph Editor 里不需要共线**。

       停用理由（实测，`_probeX.py`，速度编辑后拖手柄）：
         · 对 3D 体验**零收益** —— 带/不带加权的 3D 点线距是
           `7.262321574669722e-08`，**逐位相同到小数点后 15 位**。
           ⇒ 3D 共线**纯由值分量决定**，跟 dt 毫无关系。
         · 代价却是**把用户调好的速度分布整个抹掉** ——
           对侧 dt 13.0 → 1.76（改掉 86%），左右速度比 0.3333 → 1.0（变匀速）。

       现在的行为：**只写值分量** → 3D 共线 ✓ + 臂长守恒 ✓ + 速度分布一个数不动 ✓。
       代价只落在 "Graph Editor 里那三个点不共线" —— 而那正是用户不要的约束。

    :param weighted: ⚠️ **已不生效**（保留形参只为兼容调用方）。
                     原语义：False = 只转方向、长度锁死；True = 附带加权改 dt。
    """
    kp = _kp_of(curves, frame)
    if kp is None:
        return
    opp_side = 'right' if moved_side == 'left' else 'left'
    # ★★ 2026-09-16：联动判据收敛到 `_link_mode`（唯一来源）。
    #    关键变化：**插件自己冻的 FREE**（速度编辑）现在也走 'link' ——
    #    以前这里只看类型、见 FREE 就 return，导致"模态操作时对侧不联动"。
    mode = _link_mode(kp, moved_side)
    if mode == 'free':
        return                                  # 用户手动设的 FREE：原生语义，完全不动
    # ⚠️ 不要再写 `in ('free', 'auto')`：`_link_mode` 没有 'auto' 返回值
    #    （Automatic 系已归入 'link'），那个分支恒不成立。
    if mode == 'vector':
        _set_handle_point(curves, frame, opp_side, co_p)
        return
    # 'link'：对侧绕 co 旋转（ALIGNED，以及插件冻的 FREE）
    if opp_len is None:
        opp_p = _read_handle_point(curves, frame, opp_side)
        if opp_p is None:
            return
        opp_len = (opp_p - co_p).length
    d = moved_p - co_p
    if d.length < _ARM_EPS or opp_len < zero_eps:
        return
    _set_handle_point(curves, frame, opp_side, co_p + (-d.normalized()) * opp_len)

    # ★★ 封口：对侧转 FREE + dt 写回原值（详见 `_seal_opposite_handle`）。
    #    不封口的话，Blender 下次 `fc.update()` 会按它的 (t,v) 共线规则重算对侧
    #    → 3D 形状破相（1.45e-07 → 0.2697）+ 速度分布被改（dt 13.0 → 11.07）。
    _seal_opposite_handle(curves, frame, opp_side)

    # ★★★ 2026-09-16（第十轮）**停用加权** —— 用户拍板：一切以 3D 视图体验优先，
    #      Graph Editor 里**不需要**共线。
    #
    #      这里原本会调 `_apply_weight`，改掉对侧手柄的**时间分量 dt**
    #      来换取 "(t,v) 平面也共线"。实测（`_probeX.py` 速度编辑后拖手柄）：
    #
    #        | 指标 | 现状(带加权) | 停用加权(当前) |
    #        |---|---:|---:|
    #        | 3D 点线距 | 7.262321574669722e-08 | **7.262321574669722e-08** ← 逐位相同 |
    #        | 对侧三维臂长 | 1.333334 | 1.333334 ← 逐位相同 |
    #        | 对侧 dt（= 速度分布） | 13.0 → **1.76** ❌ 被改掉 86% | 13.0 → **13.0** ✅ 不动 |
    #        | 左右速度比 | 0.3333 → **1.0** ❌ 被抹成匀速 | 0.3333 → 0.1354 ✅ 保留 |
    #
    #      ⇒ 关键结论：**3D 共线完全由【值分量】决定，与 dt 无关**（两方案 3D 距离
    #        逐位相同，到小数点后 15 位）。所以改 dt 对 3D 体验是**零收益**，
    #        代价却是把用户精心调好的**速度分布整个抹掉**。
    #
    #      ⇒ 停用后：3D 视图手柄照样共线、照样跟手、臂长照样守恒；
    #        速度分布一个数都不动。代价只落在"Graph Editor 里那三个点不共线"
    #        —— 而那正是用户明确不要的约束。
    #
    #      ⚠️ `_apply_weight` 函数体**保留不删**（见其 docstring 的停用说明）：
    #         将来若要做"保速度分布 / 保 Graph Editor 共线"的开关，它现成可用。
    #      ⚠️ `weighted` 形参保留（调用方仍在传），但现在**不再生效**。
    _ = weighted


def _apply_weight(curves, frame, side, k, src_side=None):
    """⛔ **已停用**（2026-09-16 第十轮）—— 保留函数体，供将来做开关时复用。

    ▎为什么停用
        用户拍板：**一切以 3D 视图手柄体验优先，Graph Editor 里不需要共线**。

        本函数改的是对侧手柄的**时间分量 dt**，只为了让 "(t,v) 平面也共线"。
        实测（`_probeX.py`，速度编辑后拖手柄）：

          3D 点线距      带加权 7.262321574669722e-08
                          停用    7.262321574669722e-08   ← **逐位相同**
          对侧 dt        带加权 13.0 → 1.76（被改掉 86%）
                          停用    13.0 → 13.0（不动）
          左右速度比      带加权 0.3333 → 1.0（抹成匀速）
                          停用    0.3333 → 0.1354（保留）

        ⇒ 改 dt 对 3D 体验**零收益**（3D 共线纯由值分量决定），
          却把用户调好的**速度分布整个抹掉**。故停用。
        ⇒ 现在唯一的调用点已注释掉（见 `maintain_linked_handle`）。

    ▎如果将来要恢复
        在 `maintain_linked_handle` 末尾重新调用即可；建议做成偏好开关
        （"保速度分布 / 保 Graph Editor 共线"二选一），而不是写死。

    ---
    原说明：把某侧手柄的**时间分量**设成 `dt_src × k`（保持值分量不变）。

        dt_new = dt_src × k        （dt = 手柄时间 − co 时间；左为负、右为正）

    ⚠️⚠️ `k` 必须作用在【被拖侧】的 dt 上，不是对侧自己的 dt。
        写成 `dt_new = dt_old × k`（dt_old = 对侧自己的）是**错的** ——
        数学要求的是 `dtR = dtL × k`（见 maintain_linked_handle 的推导）。
        （实测踩过：用错基准时 (t,v) 折角 sin ≈ 1.1e-02，用对基准后降到 1e-6 级。）

    ⚠️ 边界保护（实测发现的两条，见计划书 §3.4）：

      ① `k` 在拖拽量趋零时会爆炸 → 夹到 [_K_MIN, _K_MAX]
      ② `dt_new` 过大时右手柄时间会**越过相邻关键帧**
         （实测 `hr_t` 达 61.35，而下一关键帧在 40）→ 夹到「不超过相邻关键帧」
    """
    if k is None or not math.isfinite(k) or k <= 0.0:
        return
    k = max(_K_MIN, min(_K_MAX, k))
    if src_side is None:
        src_side = 'left' if side == 'right' else 'right'
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        co_t = float(kp.co[0])
        # ★ 基准 = 被拖侧的 dt【长度】（不是对侧自己的、也不是带符号的值）
        #    ⚠️ 符号必须重设：左侧 dt 为负、右侧为正，而 k 是【长度比】(正数)。
        #       写成 `dt_new = dt_src * k`（带符号）会把右侧也弄成负的 —— 实测踩过。
        h_src = kp.handle_left if src_side == 'left' else kp.handle_right
        dt_src_len = abs(float(h_src[0]) - co_t)

        # ⚠️⚠️ dt 可分辨下限（2026-09-16）：
        #     速度编辑能把 dt 压到 ~1e-3 帧（甚至更低）。此时"比例 k"已无意义，
        #     而且缩放出来的 dt 会一起塌到 0 → 手柄在 (t,v) 平面里被挤成竖线。
        #     此时**只保方向、不动时间分量**（宁可 (t,v) 有折角，也不要数值塌陷）。
        if dt_src_len < DT_EPS:
            continue

        h = kp.handle_left if side == 'left' else kp.handle_right
        dt_new = dt_src_len * k
        if side == 'left':
            dt_new = -dt_new                      # 左侧为负（时间在 co 之前）

        # 相邻关键帧的时间（用于夹取，防跨帧）
        prev_t = next_t = None
        for other in fc.keyframe_points:
            ot = float(other.co[0])
            if ot < co_t - 1e-6:
                prev_t = ot if prev_t is None else max(prev_t, ot)
            elif ot > co_t + 1e-6:
                next_t = ot if next_t is None else min(next_t, ot)

        if side == 'left' and prev_t is not None:
            dt_new = max(dt_new, (prev_t - co_t))      # 不越过上一个关键帧
        if side == 'right' and next_t is not None:
            dt_new = min(dt_new, (next_t - co_t))      # 不越过下一个关键帧
        # 方向保护 + 可分辨下限：左侧 ≤ -DT_EPS，右侧 ≥ +DT_EPS
        # （原来是 ±1e-6，低于 Blender 的 dt 分辨率 → 手柄会塌成竖线）
        if side == 'left':
            dt_new = min(dt_new, -DT_EPS)
        else:
            dt_new = max(dt_new, DT_EPS)

        if side == 'left':
            kp.handle_left = (co_t + dt_new, float(h[1]))
        else:
            kp.handle_right = (co_t + dt_new, float(h[1]))


def _read_co_point(curves, frame):
    """读某帧控制点的【三维点】（= 三个轴的值分量）。"""
    v = [0.0, 0.0, 0.0]
    got = False
    for fc in curves:
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        v[fc.array_index] = float(kp.co[1])
        got = True
    return mathutils.Vector(v) if got else None


def finish_linked_handle(action, obj, snapshot, frame, moved_side,
                         bone_name=None, weighted=True, zero_eps=_ARM_EPS):
    """★ P2.1（2026-09-16）：鼠标【直接拖手柄】路径的加权收尾。

    ------------------------------------------------------------------
    为什么需要它：插件里手柄有**两条写入路径**

      · 端点模态（选中端点按 G/R/S）→ `apply_endpoint_transform`　**已接加权**
      · 鼠标直接拖手柄（点小圆点 / 拖手柄线）→ 老代码 `update_linked_handle`
        只逐轴按 (t,v) 斜率写对侧的**值分量**，**没有加权**

    实测（`_gap2.py`；关键帧不共线 + 各轴手柄时间比例 λ 不同）：
        初始状态        3D 点线距 5.237
        老鼠标路径      3D 点线距 4.457   ← 几乎没修，用户看到的折角还在
        加权路径        3D 点线距 0.0000  ← 完全共线
    ⇒ 这条路在 λ 不一致时**修不动 3D 折角**（这就是覆盖缺口）。

    ------------------------------------------------------------------
    本函数在**老逻辑跑完之后**调用（此时 `fc.update()` 已执行、类型已恢复），
    把对侧手柄改成：
        ① 3D 方向 = 被拖侧的反向 → 消除 3D 折角
        ② 3D 长度 = 拖拽前的原始长度（取自 snapshot）→ 原生 ALIGNED「只旋转不缩放」
        ③ ~~时间分量按 k 缩放 → 消除 (t,v) 折角（复用 `_apply_weight`）~~
           ⚠️ 已于 2026-09-16（第十轮）**停用** —— 用户拍板 3D 视图优先、
              Graph Editor 不需要共线；且改 dt 会把**速度分布抹掉**而对 3D 零收益。
              详见 `_apply_weight` 的 docstring。

    ⚠️ 现在这个函数 **只做 ① ②** → 3D 共线 + 臂长守恒 + 速度分布一个数不动。

    ⚠️ 必须写在 `fc.update()` **之后**：Blender 的 ALIGNED 会在 update 时按它
       自己的 (t,v) 规则重算对侧，写在前面的值会被覆盖
       （与 `apply_endpoint_transform` 是同一个坑，2026-09-16 实测）。

    ⚠️ 只处理对侧是 `ALIGNED` 的情况：FREE 按原生语义不动、VECTOR 贴 co、
       AUTO/AUTO_CLAMPED 交给 Blender 重算 —— 与 `maintain_linked_handle` 一致。

    :param snapshot: `snapshot_endpoints()` 的结果（拖拽**开始时**记录）
    """
    curves = _position_curves(action, obj, bone_name)
    if not curves:
        return False
    f = float(frame)
    kp = _kp_of(curves, f)
    if kp is None:
        return False
    side = str(moved_side)
    opp_side = 'right' if side == 'left' else 'left'
    # ★★ 2026-09-16：改用【统一判据】`_link_mode`。
    #    以前这里写死 `opp_type != 'ALIGNED' → return`，于是
    #    **插件自己冻的 FREE**（速度编辑）在这条路上不联动，
    #    而端点模态路径同样不联动 → 用户看到"只能作用于一端 + 之后再拖跳变"。
    if _link_mode(kp, side) != 'link':
        return False
    co_p = _read_co_point(curves, f)
    moved_p = _read_handle_point(curves, f, side)
    if co_p is None or moved_p is None:
        return False
    # ⚠️ 对侧原始长度取自 snapshot：update() 之后 Blender 已按 (t,v) 规则改过它，
    #    读实时值是错的（长度会每帧漂移）。
    opp0 = _point_from(snapshot, f, 'hr' if opp_side == 'right' else 'hl')
    if opp0.length < _ARM_EPS:
        return False
    opp_len = (opp0 - co_p).length
    # ★★ 2026-09-17：闸门口径改为「视觉零」（由调用方按屏幕像素换算传入 `zero_eps`）。
    #    旧值 `_ARM_EPS`(1e-9 世界) 与空心圆判据（屏幕 6px）差 6 个数量级：
    #    用户把两侧都缩到关键帧点（长度 ~1e-3）时空心圆出现、一拖却触发封口
    #    ⇒ 对侧 ALIGNED 被永久改成 FREE（用户实测反馈）。
    #    对侧在【视觉上】本来就是零长度 ⇒ 没有共线形状要保护 ⇒ 不该封口、更不该改类型。
    if opp_len < zero_eps:
        return False
    maintain_linked_handle(curves, f, side, co_p, moved_p,
                           opp_len=opp_len, weighted=weighted,
                           zero_eps=zero_eps)
    return True


def restore_converted_types(action, obj, converted, bone_name=None):
    """把 `apply_endpoint_transform` 临时转成 FREE 的类型写回去（取消/结束时）。

    ⚠️ D1 的配套：端点模式为了让派生类型（AUTO/AUTO_CLAMPED/VECTOR）可写，
       会把它们临时转 FREE；不恢复的话用户的手柄类型就被永久改了。

    ★ 2026-09-17 配套：恢复类型时同时 `unmark_owned_free` ——
      否则"封口时登记、取消后类型已恢复"的陈旧条目会让
      用户手动设的 FREE 被误判成插件接管（误联动）。
    """
    if not converted:
        return
    curves = _position_curves(action, obj, bone_name)
    for (frame, axis), (lt, rt) in converted.items():
        fc = None
        for c in curves:
            if c.array_index == axis:
                fc = c
                break
        if fc is None:
            continue
        kp = keyframe_at(fc, float(frame))
        if kp is None:
            continue
        hl = kp.handle_left.copy()
        hr = kp.handle_right.copy()
        kp.handle_left_type = lt
        kp.handle_right_type = rt
        kp.handle_left = hl
        kp.handle_right = hr
        # ★ 2026-09-17 配套：类型恢复了 ⇒ 取消登记（防陈旧条目误联动）
        unmark_owned_free(kp, 'left')
        unmark_owned_free(kp, 'right')
    for fc in curves:
        fc.update()


def reapply_snapshot_handles(action, obj, snapshot, endpoints, bone_name=None):
    """把快照里的手柄值【在 update 之后】再写回去。

    ⚠️ 用途：取消/还原时（2026-09-16 实测）
       Blender 的 ALIGNED 约束会在 `fc.update()` 时按 (t,v) 规则重算对侧手柄，
       把 `restore_positions()` 刚写好的原始值改掉（实测偏差 0.0224）。
       所以还原后要再写一遍、且不再 update —— 与 apply 路径同一个技巧。
    """
    curves = _position_curves(action, obj, bone_name)
    if not curves or not endpoints:
        return False
    for fc in curves:
        fc.update()
    for (frame, side) in endpoints:
        f = float(frame)
        side = str(side)
        _set_handle_point(curves, f, side,
                          _point_from(snapshot, f, 'hl' if side == 'left' else 'hr'))
        opp = 'right' if side == 'left' else 'left'
        _set_handle_point(curves, f, opp,
                          _point_from(snapshot, f, 'hl' if opp == 'left' else 'hr'))
    return True



# ===========================================================================
# 端点模态（选中手柄端点 → 按 G/R/S）的【保速】★ 2026-09-29
#
# 用户报障：「选中端点按 G 拖动，保速模式失效 —— 关键帧的速度值被改、
#            采样点疏密也跟着变」。
#
# 根因**不是保速算错了，而是这条路根本没接上保速**：
#   · 鼠标直接拖手柄  → `edit_geometry._uniform_plan` 读开关、算 k、
#                       `dt = dt_base·k` ⇒ 速度不变 ✓
#   · 端点模态 G/R/S  → `apply_endpoint_transform` 只写【值分量】，
#                       时间分量一动不动 ⇒ 速度 = |dv/dt| 的分母不变、分子变
#                       ⇒ 速度必然改变 ✗
#
# 打个比方：同一面墙上两个水龙头，都出冷水，其中一个另外接了热水管。
#   直接拖手柄      = 走接热水管那个（能保速）；
#   选中端点按 G    = 走只有冷水管那个 —— **龙头没坏，是热水管从来没铺过去**。
#
# 所以修法是**接管子，不是另装一台热水器**：
#   统一的 k 仍由 `handle_scale_k` 算、写入仍由 `scale_handle_uniform` 干，
#   这里只补两件这条路**独有**的事：
#
#     ① 基线从**模态自己的 snapshot** 取。
#        绝不能碰鼠标拖拽专用的 `_session.handle_start_values` ——
#        那是"按下那一刻"的全局状态，模态里可能残留着上一次拖拽的陈旧值；
#        用它就是当年实测过的「手柄飞走」那个坑。
#        （好消息：snapshot 里 co / hl / hr / hl_t / hr_t 全都记了，够用。）
#
#     ② 逐端点【各算各的 k】。
#        G 是平移：所有端点走同一个位移 δ，可每个端点原本的长度不同 ——
#            端点 A：dv 10 → 12  ⇒ k = 1.20
#            端点 B：dv  2 →  4  ⇒ k = 2.00     （同一个 δ = +2）
#        用一个标量 k 去缩所有端点 ⇒ 必有一个端点的速度被改坏。
#        （S 缩放像"全家福整体放大"，一个倍数够用；
#          G 平移像"每人各往前走一步"，矮个子长高比例大、高个子比例小
#          ⇒ 必须各算各的。）
# ===========================================================================

def endpoint_uniform_plan(snapshot, endpoints, fn, action=None, obj=None,
                          bone_name=None, span_gate=True):
    """【唯一预演】给每个选中的手柄端点各算一个同比例系数 k（端点模态保速）。

    谁在用：选中【手柄端点】后按 G / R / S —— 三条模态共用这一份。
        · 值分量速度 = |dv / dt|（dv = 手柄值分量离 co 的偏移）
        · dt 同比例缩 ⇒ 速度不变（数学论证见 `scale_handle_uniform` 上方）

    与鼠标拖拽那条路（`edit_geometry._uniform_plan`）的关系：
        数学**同源** —— 都调 `handle_scale_k`，谁都不自己再实现一份。
        差别只有两点（都是有原因的，不是重复造轮子）：
          · 基线来源：这里从 `snapshot`（进模态那一刻）读；
            鼠标路径从 `_session.handle_start_values`（按下那一刻）读。
          · 粒度：这里**逐端点**算 k（平移时各端点长度不同）；
            鼠标路径一次只动一个端点 ⇒ 一个 k 就够。

    :param snapshot : `snapshot_endpoints()` 的结果
    :param endpoints: [(frame, side), ...] 选中的端点
    :param fn       : 本次变换 v -> v'（G: v+delta；R: 绕支点转；S: 绕支点缩）
    :param span_gate: True 时沿用鼠标拖拽的**同一个闸门** ——
                      **端点段不做时间缩放**（第一帧的左侧 / 最后一帧的右侧，
                      外侧没有相邻关键帧那一侧）。两条路同口径，
                      免得同一个操作在两种入口下给出不同结果。

    返回 {(frame, side): (k, k_raw, {ax: dv_new}, {ax: dv_base},
                          {ax: dt_base}, span)}

    ⚠️ 该端点算不出 k（基线手柄太短 / 落在端点段 / 值越界）⇒ **不在返回值里**
       ⇒ 调用方退回"只写值分量"的历史行为。
       这是**刻意**的：与鼠标路径同口径，不自作聪明 ——
       "极短手柄的保速没有意义"（它本来就是个刚长出来的柄）。
    """
    plan = {}
    for (frame, side) in (endpoints or ()):
        try:
            f = float(frame)
            sd = str(side)
        except Exception:
            continue
        vals = (snapshot or {}).get(f) or (snapshot or {}).get(frame) or {}
        if not vals:
            continue
        co_p = _point_from(snapshot, f, 'co')
        hp0 = _point_from(snapshot, f, 'hl' if sd == 'left' else 'hr')
        if co_p is None or hp0 is None:
            continue
        new_h = fn(f, hp0)
        if new_h is None or not is_writable(new_h):
            continue
        span = None
        if span_gate:
            try:
                from . import time_domain as _td
                _kfm, span = _td.resolve_target(action, obj, f, sd, bone_name)
            except Exception:
                warn_once("transform_domain.endpoint_uniform_plan")
                span = None
            if not span:
                continue          # 端点段：与鼠标拖拽同口径，不缩 dt
        axes = [ax for ax in sorted(vals) if isinstance(ax, int)]
        dv_base, dv_new, dt_base = {}, {}, {}
        for ax in axes:
            v = vals.get(ax) or {}
            tk = 'hl_t' if sd == 'left' else 'hr_t'
            dv_base[ax] = float(hp0[ax]) - float(co_p[ax])
            dv_new[ax] = float(new_h[ax]) - float(co_p[ax])
            # ⚠️ dt 带符号：左侧手柄的时间在 co **之前**（负数），右侧在后（正数）
            #    —— `scale_handle_uniform` 正是靠这个符号写 `co_t + dt`。
            dt_base[ax] = float(v.get(tk, f)) - f
        seq = [a for a in axes if a in dv_base]
        if not seq:
            continue
        ks = handle_scale_k([dv_base[a] for a in seq],
                            [dv_new[a] for a in seq],
                            [dt_base[a] for a in seq], span)
        if ks is None:
            continue              # 基线太短 / 手柄零长 ⇒ 不保速（同鼠标路径）
        plan[(f, sd)] = (ks[0], ks[1], dv_new, dv_base, dt_base, span)
    return plan


def write_endpoint_uniform(curves, frame, side, dv_base, dt_base, dv_new,
                           k, k_raw, span):
    """【唯一写入】把某个端点的同比例缩放写进各轴。

    每个轴调一次 `scale_handle_uniform`（它收**标量** —— 见其接口约定），
    所以这里只做"逐轴派发"，数学仍然只有一份。

    返回实际写进去的 [(axis, dv, dt), ...]，供测试断言。
    """
    out = []
    for fc in curves:
        ax = fc.array_index
        if ax not in dv_new:
            continue
        kp = keyframe_at(fc, frame)
        if kp is None:
            continue
        dv, dt = scale_handle_uniform(kp, side, dv_base[ax], dt_base[ax],
                                      dv_new[ax], k, k_raw, span)
        out.append((ax, dv, dt))
    return out


def apply_endpoint_transform(action, obj, snapshot, fn, endpoints, bone_name=None,
                             linked=True, weighted=True, zero_eps=_ARM_EPS,
                             time_scale=None, uniform=False):
    """只变换【选中的那些手柄端点】，并维护对侧手柄。

    ⚠️ 与 `apply_point_transform(only_handles=True)` 的关键区别：

      · 旧实现：对每一帧把 **hl 和 hr 都** 变换一遍
        → 用户旋转/移动一个端点，**对侧那个也跟着动**
        → 用户实测："S 旋转选中的端点，旋转的确实对向的端点" ❌

      · 本实现：只动 `endpoints` 里列出的 (frame, side)，
        其余（含对侧）按 `maintain_linked_handle` 的原生语义处理 ✅

    :param endpoints: [(frame, side), ...]
    """
    curves = _position_curves(action, obj, bone_name)
    if not curves or not endpoints:
        return False
    _reset_skip()

    # ★★ D1 修复（agent 实测）：派生/锁定类型下写入会被 Blender 吞掉。
    #
    # 实测（端点拖拽 1.0 单位后的位移比）：
    #     FREE     1.0000 ✓   ALIGNED 1.0000 ✓
    #     AUTO     0.0000 ✗   AUTO_CLAMPED 0.0000 ✗   VECTOR 0.0000 ✗
    #     ⇒ 默认工程（keyframe_insert 给的就是 AUTO_CLAMPED）**端点完全拖不动**
    #
    # 修法：**只对派生类型**临时转 FREE（`ALIGNED`/`FREE` 保持原样 ——
    #       它们本来就写得进去，且 ALIGNED 还要保留共线语义）。
    #       调用方通过返回的 `converted` 恢复（见 apply_endpoint_transform 的收尾）。
    global last_converted_types
    # ★★ 2026-09-16：改用两条路径共用的 `prepare_handles_for_drag`
    #    （按 Blender 原生语义：AUTO* → ALIGNED、VECTOR → FREE；**两侧都接管**）。
    #    旧实现只转【被拖侧】、且一律转 FREE，于是：
    #      · 对侧 AUTO_CLAMPED 被 Blender 重算 → 臂长突变（用户看到"跳"）
    #      · 对侧永远按 AUTO_CLAMPED 公式走 → 与插件要的共线无关（永久折角，dev 0.832）
    #    保留的契约：对侧 VECTOR 仍**不转**（用户显式"贴相邻关键帧"语义，E 组测试）。
    converted = prepare_handles_for_drag(action, obj, endpoints, bone_name,
                                         link_opposite=bool(linked))
    last_converted_types = dict(converted)   # 供调用方恢复
    for fc in curves:
        fc.update()

    for (frame, side) in endpoints:
        f = float(frame)
        side = str(side)
        co_p = _point_from(snapshot, f, 'co')
        hp = _point_from(snapshot, f, 'hl' if side == 'left' else 'hr')
        new_h = fn(f, hp)
        if new_h is None:
            continue
        if not is_writable(new_h):
            global last_skip_reason
            last_skip_reason = "Value out of writable range"
            continue
        _set_handle_point(curves, f, side, new_h)
    # ⚠️ 顺序关键（2026-09-16 实测）：先 update，再维护对侧。
    #    Blender 的 ALIGNED 约束是「(t,v) 平面共线」，会在 fc.update() 时
    #    把对侧手柄按它的规则**重算**（覆盖我们写的值）。
    #    而插件 3D 视图显示的是「值空间方向」——两者数学上不等价。
    #    所以对侧的修正必须写在 update **之后**，否则会被 Blender 覆盖。
    for fc in curves:
        fc.update()

    # ★★ D2 修复（agent 实测）：update 之后再写一遍【被拖侧】。
    #
    # 实测：**左手柄是 ALIGNED、右手柄非 FREE 时，`fc.update()` 会按左手柄
    #        重算右手柄的值** → 拖右端点的写入被覆盖（位移只生效 0.1258/1.0）。
    #       （5 组对照实测归纳，未追到 Blender 源码级规则。）
    # 修法：把被拖侧的值在 update 之后补写一次（对侧在下面维护，最后生效）。
    for (frame, side) in endpoints:
        f = float(frame)
        hp = _point_from(snapshot, f, 'hl' if str(side) == 'left' else 'hr')
        moved_p = fn(f, hp)
        if moved_p is None:
            continue
        _set_handle_point(curves, f, str(side), moved_p)

    # ★★ 端点模态【保速】—— G / R / S 共用这一份（2026-09-29 修用户报障）
    #
    #     `uniform=True`：**逐端点各算各的 k**（见 `endpoint_uniform_plan`），
    #        然后把时间分量 dt 按同一个 k 缩 ⇒ 每个端点的速度都保持不变。
    #        值分量仍由 `scale_handle_uniform` 写（它顺带把超限的 k 折回
    #        `k/k_raw`，与鼠标拖拽完全同一套口径）。
    #
    #     `time_scale`：**遗留的标量通路**（历史上只有 S 的单端点用过它）。
    #        端点模态现在统一走 uniform ⇒ 它只为兼容旧调用点保留，
    #        不再有新代码传它。
    #
    #     ⚠️ 顺序铁律（照抄本函数既有顺序，别调换）：
    #        写值分量 → fc.update() → 补写值分量 → **这里的同比例写入**
    #        → 维护对侧手柄
    #        理由见上面「顺序关键」那段：Blender 的 ALIGNED 是**(t,v) 平面共线**，
    #        会在 fc.update() 时按它自己的规则重算手柄 —— 写在 update 之前的
    #        会被无声覆盖。而这里的写入之后**不再有 update**，所以能留住。
    if uniform:
        _plan = endpoint_uniform_plan(snapshot, endpoints, fn, action, obj,
                                      bone_name)
        for (_f, _sd), (_k, _kraw, _dvn, _dvb, _dtb, _sp) in _plan.items():
            write_endpoint_uniform(curves, _f, _sd, _dvb, _dtb, _dvn,
                                   _k, _kraw, _sp)
    elif time_scale is not None:
        # ⚠️ 以下 = **遗留的标量通路**（用户 2026-09-17 那版，端点模态已不再走它）：
        #    `_set_handle_point` 只写【值分量】⇒ 速度 ×scale
        #    （实测 0.170833 → 0.25625）；这里把【时间分量】也 ×time_scale ⇒ 速度不变。
        #    只在该端点**视觉上本来就有长度**时才缩 ——
        #    dv=0 的端点"保速"平凡成立（速度本来就是 0），
        #    再缩 dt 只会把曲线压平（无意义的副作用）。
        #    ⚠️ 基准时间从 snapshot 读（反复 _apply 不累乘）。
        for (frame, side) in endpoints:
            f = float(frame)
            _sd = str(side)
            _co0 = _point_from(snapshot, f, 'co')
            _hp0 = _point_from(snapshot, f, 'hl' if _sd == 'left' else 'hr')
            # ★★ 2026-09-29：判据统一为「视觉零」(`zero_eps`)，与
            #    `finish_linked_handle` / `maintain_linked_handle` 同口径。
            #    旧值 `_ARM_EPS`(1e-9 世界) 会把"屏幕上看不见、数学上非零"的端点
            #    判成"有长度" ⇒ 照样缩 dt 把曲线压平 —— 正是上面这条注释
            #    想避免的副作用。（上一轮修了另两处，漏了本条。）
            if (_hp0 - _co0).length <= zero_eps:
                continue                      # 视觉上无长度 ⇒ 无速度可保，别动 dt
            _scale_handle_time(curves, snapshot, f, _sd, time_scale)

    if linked:
        for (frame, side) in endpoints:
            f = float(frame)
            side = str(side)
            co_p = _point_from(snapshot, f, 'co')
            hp = _point_from(snapshot, f, 'hl' if side == 'left' else 'hr')
            moved_p = fn(f, hp)
            if moved_p is None:
                continue
            # ⚠️ 对侧的【原始长度】必须取自快照：
            #    update() 之后 Blender 已按 ALIGNED 改过它，读实时值是错的
            opp0 = _point_from(snapshot, f, 'hr' if side == 'left' else 'hl')
            opp_len = (opp0 - co_p).length
            # ★★ 2026-09-17：与 `finish_linked_handle` 用【同一个】「视觉零」口径。
            #    这里原本**没传** zero_eps ⇒ 沿用 `_ARM_EPS`(1e-9 世界)，
            #    与空心圆判据（屏幕 6px）差 6 个数量级 ⇒ 端点模态（G/R/S）
            #    路径下，用户把两侧缩到关键帧点后一拖，对侧 ALIGNED 被封口成 FREE。
            #    （鼠标直接拖手柄走 `finish_linked_handle`，那条上一轮已修，漏了本条。）
            maintain_linked_handle(curves, f, side, co_p, moved_p,
                                   opp_len=opp_len, weighted=weighted,
                                   zero_eps=zero_eps)
    return True


def apply_point_transform(action, obj, snapshot, fn, bone_name=None,
                          only_handles=False, time_scale=None):
    """把 snapshot 的每个路径点**及其两侧手柄**按 `fn(frame, vec) -> vec` 变换后写回。

    G/R/S 只是换了不同的 `fn`：
        G（平移）：v + delta
        R（旋转）：pivot + R·(v - pivot)
        S（缩放）：pivot + k·(v - pivot)

    ⚠️⚠️ **关键**：co、handle_left、handle_right 是**三个独立的点**，
       必须**各自**经过 fn 变换 —— 不能只变换 co、再把手柄平移同样的量。

       之前正是"变换 co + 平移手柄"，后果：
         · 单点旋转时 co 不变、手柄也不动 → **完全没反应**（用户反馈）
         · 多点旋转时手柄只平移不旋转 → **手柄方向不对**、形状被拉歪

       改成各自变换后，语义与 Blender 原生曲线编辑一致：
        **pivot 取选中点的中位点时，单个点旋转 = 它的手柄绕它自己转**
       （co 不动、手柄转 → 切线方向变 → 路径形状变）。这正是用户要的。

    ⚠️ 每次都从 snapshot 重算（不累加）：
        · 避免浮点累积误差
        · 「取消」只需 restore 一次
        · 模态里反复 update 也不会漂移

    `time_scale`（默认 None = 时间分量不动，即历史行为）：
        非 None 时，手柄的**时间分量**（dt）也 ×time_scale，用来**保速**。
        速度 = |dv / dt|；只缩 dv 不缩 dt ⇒ 速度 ×k。dt 同比例 ⇒ 速度不变。
        **只由 ScaleSession 的「单点缩放」传入**（见 modal_edit.ScaleSession._apply）：
            · 单点缩放时支点就是该点自己 ⇒ co 不动、手柄绕它缩
              ⇒ 手柄连「长度」带「时间跨度」等比缩，形状相似 ⇒ 速度恒定
            · 多点缩放时支点是中位点，各点位移不同 ⇒ 不缩 dt（保持原行为）
        端点模式（only_handles）不走这里（走 apply_endpoint_transform），不受影响。
    """
    curves = _position_curves(action, obj, bone_name)
    by_axis = {fc.array_index: fc for fc in curves}
    _reset_skip()

    for frame, per_axis in snapshot.items():
        # ★ 先组装【三个完整三维点】，再各自变换
        co_p = _point_from(snapshot, frame, 'co')
        hl_p = _point_from(snapshot, frame, 'hl')
        hr_p = _point_from(snapshot, frame, 'hr')
        new_co = fn(frame, co_p)
        new_hl = fn(frame, hl_p)
        new_hr = fn(frame, hr_p)
        if new_co is None or new_hl is None or new_hr is None:
            continue
        if not (is_writable(new_co) and is_writable(new_hl) and is_writable(new_hr)):
            # ⚠️ 不静默：记下原因，让状态栏能提示（见 is_writable 的 docstring）
            global last_skip_reason
            last_skip_reason = "Value out of writable range (move/scale too large)"
            continue
        for axis, vals in per_axis.items():
            fc = by_axis.get(axis)
            if fc is None:
                continue
            kp = keyframe_at(fc, frame)
            if kp is None:
                continue
            _co_t = float(kp.co[0])
            if not only_handles:
                kp.co = (_co_t, new_co[axis])
            if time_scale is None:
                kp.handle_left = (kp.handle_left[0], new_hl[axis])
                kp.handle_right = (kp.handle_right[0], new_hr[axis])
            else:
                # ★★ 保速：手柄的【时间分量】也 ×time_scale（用户 2026-09-17 拍板）
                #   速度 = |dv / dt|。只缩值分量(dv)、不缩 dt ⇒ 速度 ×k。
                #   让 dt 同比例 ⇒ 速度不变（= 在「值-时间」平面上等比缩放，形状相似）。
                #
                #   ⚠️ 时间分量必须从 **snapshot** 读，不能从 kp 读 ——
                #      模态里鼠标每动一次就 _apply 一次，从 kp 读会**累乘**（k^n）。
                #      snapshot 存的是进模态那一刻的原始值（见 snapshot_positions）。
                _hl_t0 = float(vals.get('hl_t', kp.handle_left[0]))
                _hr_t0 = float(vals.get('hr_t', kp.handle_right[0]))
                kp.handle_left = (_co_t - (_co_t - _hl_t0) * time_scale, new_hl[axis])
                kp.handle_right = (_co_t + (_hr_t0 - _co_t) * time_scale, new_hr[axis])
    for fc in curves:
        fc.update()
    return True


def rotation_fn(pivot, axis, angle):
    """绕 axis 轴、过 pivot、转 angle 弧度的变换函数（右手系）。"""
    axis = mathutils.Vector(axis)
    if axis.length < 1e-12:
        return None
    axis.normalize()
    rot = mathutils.Matrix.Rotation(angle, 3, axis)
    piv = mathutils.Vector(pivot)

    def fn(_frame, v):
        return piv + rot @ (v - piv)

    return fn


def scale_fn(pivot, factor):
    """以 pivot 为中心、按 factor 缩放的变换函数。"""
    piv = mathutils.Vector(pivot)

    def fn(_frame, v):
        return piv + (v - piv) * factor

    return fn


def scale_fn_masked(pivot, factor, mask):
    """同上，但只在 mask 为 1 的轴上缩放（0 = 该轴保持原样）。"""
    piv = mathutils.Vector(pivot)
    mx, my, mz = mask

    def fn(_frame, v):
        d = v - piv
        return mathutils.Vector((piv.x + d.x * (factor if mx else 1.0),
                                 piv.y + d.y * (factor if my else 1.0),
                                 piv.z + d.z * (factor if mz else 1.0)))

    return fn


# ===========================================================================
# 同比例手柄缩放（Handle Scale / UNIFORM）
#
# 用户拍板语义（2026-09-17）：拖 3D 手柄时，**手柄变长/变短，但关键帧处的
# 速度不变** —— 等价于 Graph Editor 里「以各自中心 + S 缩放」。
#
#   手柄(3D 视图里那根线) = (dv_x, dv_y, dv_z)     ← 值分量，插件只画这个
#   关键帧处速度           = |(dv_a / dt_a)|        ← 每轴：值分量 / 时间分量
#   同比例（dv、dt 同乘 k）⇒ 速度 = (k·|dv|)/(k·dt) = 原速度 ⇒ **不变** ✓
#
# ⚠️ 为什么 k 必须是「值分量 3D 模长比」而不是「逐轴的 dv_a新/dv_a旧」：
#    逐轴 k_a 在某个轴被拖到**过零**时会变负 / 除零 ⇒ dt 被钳到极小 ⇒ 速度爆炸
#    ⇒ 手柄"飞走 / 缩成一点锁死"（2026-09-17 实测踩坑，那条路已废弃）。
#    整体 k 对所有轴相同 ⇒ 手柄方向 ∝ dv 不变 ⇒ **始终与路径相切** ✓
#    且各轴 dt 相同时，**任意方向**拖动都精确保速（原型+真机双重验证）。
# ===========================================================================

UNIFORM_LEN_EPS = 1e-6      # |dv_base| 低于此值 ⇒ "缩放"无定义（手柄为零长）
UNIFORM_DT_FLOOR = 1e-4     # 时间分量下限（帧），避免 dt → 0 使手柄不可抓

# ★★★ 2026-09-17（用户实测 bug）：**基线手柄太短 ⇒ 不启用同比例**。
#
#   同比例系数 k = |dv_new| / |dv_base| ⇒ **基线越短 k 越大**
#   ⇒ `dt = dt_base · k`（见 scale_handle_uniform）**爆掉**。
#
#   实测（从磁盘干净状态模拟"拖出端点手柄、松手、再拖"）：
#       L0 = 0.0242 → 拖到 3.96 → k = 164.6 → **dt = 1646.3**
#       L0 = 0.05   → 拖到 3.96 → k =  80.2 → **dt =  802.0**
#   用户实测到的 **dt = 1634.574** 正是同一条路（L0 ≈ 0.024）。
#
#   dt 过大（> 段跨度 span）后贝塞尔在该段饱和 ⇒ **拖手柄路径几乎不动**
#   （用户："没有预期交互"），且手柄方向与路径偏离 10°+（"不相切"），
#   并且**永久锁死**（基线 dt 已巨大，k 的语义失效）。
#
#   ⇒ 基线短于此值就退回"只写 dv、dt 不变"（与"端点第一次拖出"的既定行为
#     一致：**极短手柄的"保速"没有意义** —— 它本来就是个刚长出来的柄）。
UNIFORM_LEN_MIN = 1.0

# ★ 安全上限（仅防病态值，**不是**手感限制）
#
# 2026-09-17 用户拍板：**取消拉长上限** —— 手柄线要一直跟手变长（纯交互需求）。
#
# 为什么放开是安全的（实测依据，见 .docs / 提交说明）：
#   · dt > span 后曲线【完全饱和】—— 扫 dt/span 从 0.33 到 1.67：
#     曲线峰值 / 速度剖面 / 关键帧速度在 dt=span 之后**一模一样，一位不变**。
#     再拖更长只是"手柄线变长"，对动画本身零影响。
#   · 插件**本来就允许** s = dt/span 越界 —— `td.read_s` 不钳制，
#     `s_to_d` 注释实测记录「Graph Editor 里拖手柄 → s=7.69」。
#   ⇒ UNIFORM 模式的 k_max 是人为加的，比 Blender 的实际边界更保守。
#
# 下面这个值只是防"极端值把数值搞坏"，用户正常拖动到不了（要拖 200 倍）。
UNIFORM_K_SAFETY = 200.0


def handle_scale_k(dv_base, dv_new, dt_base, span, len_min=None):
    """【唯一实现】算同比例缩放的系数 k。两条拖拽路径共用。

    参数（都是**相对 keyframe.co 的偏移**）：
        dv_base : 按下时各轴的值分量   (dv_x, dv_y, dv_z)  —— **序列**
        dv_new  : 拖动后各轴的值分量                      —— **序列**
        dt_base : 按下时各轴的时间分量                     —— **序列**
        span    : ⚠️ **已废弃、不再使用**（只为兼容历史签名而保留）。
                  2026-09-17 用户拍板取消了"拉长上限"，k_max 已改成常量
                  `UNIFORM_K_SAFETY`（见下）。保留形参是为了不动已有的
                  位置传参调用点。
        len_min : 保速闸门的世界/**局部**长度阈值（可选）。基线 |dv_base|
                  ≤ 此值 ⇒ 判"手柄太短、比例无定义" ⇒ 返回 None。
                  ★★★ 2026-10-02：调用方（鼠标拖拽路径 `edit_geometry._uniform_plan`）
                  改传**屏幕口径**的换算值 —— 与绘制侧 `handle_is_zero_length`
                  同一把尺子（屏幕 6px）。理由见 `UNIFORM_LEN_MIN` 上方。
                  **未传**（端点模态 / 拿不到视图 / 旧调用点）⇒ 退回
                  `UNIFORM_LEN_MIN`，行为与旧版一致。

    返回 `(k, k_raw, k_max)`；当 |dv_base| ≈ 0 时返回 None（缩放无定义）。

    ★ 上限**钳在 k 上**，不是钳 dt —— 钳 dt 会破坏同比例 ⇒ 速度就变了。
    ★★ 2026-09-18（盲审 S3）：**本 docstring 原来写着
       `k_max = span / max|dt_base|`，那是已被推翻的旧行为** ——
       实现里 k_max 是常量 `UNIFORM_K_SAFETY`（用户 2026-09-17 拍板
       "取消拉长上限"：dt > span 后曲线完全饱和，拖更长只让手柄线变长、
       对动画零影响，而用户要"手柄一直跟手变长"）。
       文档与实现冲突会误导后来者，故在此更正。

    ⚠️ 接口约定（盲审 S4）：本函数收**序列**（内部 `list()` 后逐元素处理），
       而相邻的 `scale_handle_uniform` 收**标量**（`float()`）。
       两者名字相近但口径不同 —— 调用时别混。
       真正的批量逻辑在调用方（`interaction._apply_one_handle_offset`）的循环里。
    """
    dv_base = list(dv_base or ())
    dv_new = list(dv_new or ())
    dt_base = list(dt_base or ())
    if not dv_base or not dv_new:
        return None
    L0 = math.sqrt(sum(float(v) * float(v) for v in dv_base))
    # ★★★ 2026-09-17：基线太短 ⇒ 退回"不同比例"（详见 UNIFORM_LEN_MIN 的说明）。
    #    这同时覆盖了原来的 `L0 <= UNIFORM_LEN_EPS`（零长）情形 ——
    #    零长是 L0=0，必然 ≤ 阈值。
    #
    # ★★★ 2026-10-02（用户报障）：阈值改成**可注入**，鼠标路径传「屏幕口径」。
    #
    #   报障：「手柄缩到 0 出现抓取环，拖出来后再拖，速度会被改」。
    #   根因：本闸门原用【世界长度 1.0】（实测 1 世界单位 ≈ 49px），
    #         而**抓取环**用的是【屏幕 6px】判据 ⇒
    #         闸门关门范围比抓取环宽约 **8 倍** ⇒
    #         「屏幕上 24px、看得清清楚楚」的手柄，拖它照样不保速。
    #   修法：调用方传与抓取环**同一把尺子**（`drawing.local_eps_for_screen`）
    #         换算出的阈值。⚠️ 两者口径一旦漂移，就会出现
    #         「看得见手柄却锁方向 / 保不了速」的缝。
    #   ⚠️ 未传（端点模态 / 拿不到视图 / 旧调用点）⇒ 沿用 `UNIFORM_LEN_MIN`，
    #      行为与旧版**逐位一致**。
    _len_thr = UNIFORM_LEN_MIN if len_min is None else float(len_min)
    if L0 <= _len_thr:
        return None
    L1 = math.sqrt(sum(float(v) * float(v) for v in dv_new))
    k_raw = L1 / L0
    dt_max = max((abs(float(v)) for v in dt_base), default=0.0)
    # ★★ 2026-09-17 用户拍板：**取消拉长上限**（原为 span/max|dt_base|）。
    #    原因：那是**交互限制**，不是数学必需 —— dt > span 后曲线完全饱和，
    #    拖更长只让手柄线变长、对动画零影响。用户明确要"手柄一直跟手变长"。
    k_max = UNIFORM_K_SAFETY
    k = min(k_raw, k_max)
    # 保底：dt 不得小于可分辨下限（否则手柄缩成一点、再也抓不回来）
    if dt_max > UNIFORM_LEN_EPS:
        k = max(k, UNIFORM_DT_FLOOR / dt_max)
    return (k, k_raw, k_max)


def scale_handle_uniform(keyframe, side, dv_base_a, dt_base_a,
                         dv_new_a, k, k_raw, span):
    """【唯一实现】把同比例缩放写进一条曲线的 keyframe。

    · 值分量：`dv = dv_new · (k / k_raw)`
        未触上限时 k == k_raw ⇒ dv = dv_new（鼠标直接控制，自由拖动）
        触上限时  k <  k_raw ⇒ 按 k/k_raw **等比缩回**（保方向、保速度）
    · 时间分量：`dt = dt_base · k`
        ★ 2026-09-17：**不再钳到 span** —— 用户要手柄一直跟手变长；
          dt > span 时曲线饱和（形状不再变），所以放开是安全的。
          只保留 [UNIFORM_DT_FLOOR, +∞) 的下限，避免手柄缩成一点抓不回来。

    ⚠️ 参数都是**相对 co 的偏移**（不是绝对坐标）—— 调用方从按下时的
       `_session.handle_start_values` 取基线，绝不用"当前值"，否则会
       重复缩放导致指数增长（2026-09-17「手柄飞走」的根因）。

    参数口径（⚠️ 盲审 S4：本函数收**标量**，别和上方的 `handle_scale_k` 混）：
        dv_base_a / dt_base_a / dv_new_a : **单个轴**的分量（float）
        k / k_raw                        : 来自 `handle_scale_k`
        span                             : ⚠️ **已废弃、不再使用**
                                           （2026-09-17 取消 dt ≤ span 钳制）

    返回 `(dv_written, dt_written)`，供测试断言。
    """
    ratio = (float(k) / float(k_raw)) if k_raw > 1e-12 else 1.0
    dv = float(dv_new_a) * ratio
    dt = float(dt_base_a) * float(k)
    # ★★ 2026-09-17：**去掉了 `dt ≤ span` 的钳制**（原来在这里）。
    #    它只钳 dt 不钳 dv ⇒ 会破坏同比例 ⇒ 速度就变了（实测 0.17 → 0.64）。
    #    dt > span 是安全的：曲线在超出后完全饱和，形状/速度剖面都不再变。
    if abs(dt) < UNIFORM_DT_FLOOR:
        # ★★ 2026-09-30 修 A-3（Phase 1 极限测试抓到，SUSPECT/低）：
        #    `dt_base == 0` 时旧代码拿 `+1.0` 当符号 ⇒ **左侧也得到正 dt**
        #    （手柄落到关键帧**右侧**）✗。随后任何 `fc.update()` 会被 Blender 的
        #    最小时间间距规则翻回左侧 —— 但**端点模态写完不再 update**
        #    ⇒ 错误会留存到下一次 update（用户把左手柄精确拖到关键帧时间上时触发）。
        #    ⇒ 改成**按侧取符号**：left ⇒ 负，right ⇒ 正。
        _sign = -1.0 if side == 'left' else 1.0
        dt = math.copysign(UNIFORM_DT_FLOOR, dt if dt != 0.0 else _sign)
    co_t = float(keyframe.co[0])
    co_v = float(keyframe.co[1])
    if side == 'left':
        keyframe.handle_left = (co_t + dt, co_v + dv)
    else:
        keyframe.handle_right = (co_t + dt, co_v + dv)
    return (dv, dt)
