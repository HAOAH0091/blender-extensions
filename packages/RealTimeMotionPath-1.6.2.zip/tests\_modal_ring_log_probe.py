# -*- coding: utf-8 -*-
"""探针：2026-10-09 新增的两组调试日志落点是否有效。

覆盖（用户 2026-10-09 要求补的两条）：
    C. 模态会话生命周期 —— `modal.begin` / `modal.end` / `modal.cancel`
    D. 抓取环数据喂入   —— `ring.feed`

为什么这么测
------------
- C 可**行为验证**：两个 modal Operator 的 invoke/_finish/cancel 是普通方法，
  用「未绑定方法 + 假 self」即可直接驱动（headless 下 `bpy.ops` 调不动 modal，
  但方法本身能调）⇒ 真写日志文件、真读回校验。
- D 只能**源码断言**：`ring.feed` 落在 `drawing.render_path_overlay()` 里，
  而该函数首行就 `if not context.space_data ...: return` —— headless 必早退，
  集成路径在无 GUI 下不可达。故改为断言「落点存在 + 带节流」。
  （真机验证需要用户在 GUI 里开一次插件 —— 与 debug_log 机制本身的定位一致。）

用法
----
    blender --background --factory-startup --python tests/_modal_ring_log_probe.py
"""
import ast
import json
import os
import sys
import tempfile

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)

import bpy                                            # noqa: E402

import importlib                                      # noqa: E402

dl = importlib.import_module(PKG_NAME + ".debug_log")
me = importlib.import_module(PKG_NAME + ".modal_edit")

steps = []


def step(name, ok, detail=""):
    steps.append({"name": name, "ok": bool(ok), "detail": str(detail)})


class _Evt:
    mouse_region_x = 10
    mouse_region_y = 20


class _FakeSelf:
    """假 self：只提供 invoke/_finish/cancel 会碰到的最小接口。

    ⚠️ `report` 故意不给 —— invoke 在**记录 dbg 之后**才调用它，
      抛错不影响我们校验日志（反倒验证了「dbg 在早退路径最前」）。
    """
    mode = "SPEED"
    _session = None

    def _set_status(self, *a, **k):
        pass

    def _redraw(self, *a, **k):
        pass


def main():
    logp = os.path.join(tempfile.mkdtemp(), "probe.jsonl")
    os.environ["RTMP_DEBUG_LOG"] = "1"
    dl.set_enabled(True, path=logp)

    ctx = bpy.context
    for cls, cname in ((me.RTMP_OT_ModalEdit, "ModalEdit"),
                       (me.RTMP_OT_KeyboardTransform, "KeyboardTransform")):
        s = _FakeSelf()
        for meth, args in (("invoke", (ctx, _Evt())),
                           ("_finish", (ctx, "CANCELLED")),
                           ("cancel", (ctx,))):
            try:
                getattr(cls, meth)(s, *args)
            except Exception:                              # noqa: BLE001
                pass          # 假 self 缺 report 等 —— 只要 dbg 已先执行即可

    dl.set_enabled(False)

    recs = []
    if os.path.exists(logp):
        with open(logp, "r", encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if ln:
                    try:
                        recs.append(json.loads(ln))
                    except Exception:                      # noqa: BLE001
                        pass
    events = [r.get("ev") for r in recs]

    # ---- C：三个事件都要出现，且两个类都有 ----
    for ev in ("modal.begin", "modal.end", "modal.cancel"):
        step("C: event %s written" % ev, ev in events, "events=%s" % events)
    for cname in ("ModalEdit", "KeyboardTransform"):
        got = sorted(set(r["ev"] for r in recs if r.get("cls") == cname))
        step("C: cls=%s has all three" % cname,
             got == ["modal.begin", "modal.cancel", "modal.end"], "got=%s" % got)

    # begin 的失败路径要带 why（headless 下 area=None ⇒ not_view3d）
    begins = [r for r in recs if r.get("ev") == "modal.begin"]
    step("C: begin carries ok/why",
         bool(begins) and all(("ok" in r and "why" in r) for r in begins),
         "begins=%s" % begins[:2])
    step("C: headless maps to why=not_view3d",
         any(r.get("why") == "not_view3d" for r in begins))

    # ---- D：ring.feed 落点存在 + 带节流（源码断言，headless 不可达）----
    dwtxt = open(os.path.join(PLUGIN_DIR, "drawing.py"), encoding="utf-8").read()
    tree = ast.parse(dwtxt)

    def _in_render_path_overlay(node):
        return node.lineno and any(
            isinstance(f, ast.FunctionDef) and f.name == "render_path_overlay"
            and f.lineno <= node.lineno <= (f.end_lineno or f.lineno)
            for f in ast.walk(tree))

    feed_calls = [n for n in ast.walk(tree)
                  if isinstance(n, ast.Call)
                  and isinstance(n.func, ast.Name) and n.func.id == "dbg"
                  and n.args and isinstance(n.args[0], ast.Constant)
                  and n.args[0].value == "ring.feed"]
    step("D: dbg('ring.feed') exists in render_path_overlay",
         len(feed_calls) == 1 and _in_render_path_overlay(feed_calls[0]),
         "count=%d" % len(feed_calls))
    step("D: ring.feed carries n=",
         bool(feed_calls) and any(k.arg == "n" for k in feed_calls[0].keywords))
    step("D: feed is throttled by signature (_ring_feed_state)",
         "_ring_feed_state" in dwtxt and "_feed_sig" in dwtxt)

    # ---- 汇总 ----
    passed = sum(1 for s in steps if s["ok"])
    print("=" * 70)
    for s in steps:
        print("[%s] %-52s %s" % ("PASS" if s["ok"] else "FAIL", s["name"], s["detail"][:70]))
    print("-" * 70)
    print("SELFTEST_RESULT %d/%d" % (passed, len(steps)))
    return 0 if passed == len(steps) else 1


if __name__ == "__main__":
    sys.exit(main())
