# RTMP 用户契约清单（验收基准）

> **"功能不变"的操作化定义就是这 15 条。** 任何改动前后逐条走一遍，行为一致才算没坏。
> 唯一例外：标 **【本轮兑现】** 的条目 —— 它们**今天就已经违反了你对用户的承诺**，
> 修它们是把实际行为拉回契约，不是改变需求。

---

## 怎么用

```
① 改动前：走一遍，记录现状（多数是 ✅，少数是 ❌/⚠️）
② 改动后：再走一遍，逐条对比
③ 自动化：blender --background --factory-startup --python tests\run_all.py
④ 快照  ：blender --background --factory-startup --python tests\_snapshot_recorder.py
           与 tests\_snapshot_baseline.json 逐位 diff（差异必须为空，或明确说明是有意的）
```

**判断标准**：契约变了 ⇒ 要么改回去，要么在提交信息里写清"这是有意的，因为 X"，并更新基线。

---

## 一、看得见

### C1 开关显示：反复开关不劣化 【本轮兑现】
1. 点 🎯 打开 → 看到红色路径 + 黄点 + 白点
2. 再点关闭 → 路径消失
3. **反复开关 10 次**，最后打开
- **期望**：路径的浓淡/粗细与第一次打开时**完全一致**
- **现状**：❌ 每次开关泄漏一个绘制回调 ⇒ 越开关越浓、越卡
- 自动化：`gui_draw_handler_leak_check.py`（**注意它的度量口径有盲区，见下**）

> ⚠️ 现有 `gui_draw_handler_leak_check.py` 数的是"插件对象上非 None 的句柄数"，
> 而真实泄漏是"**Python 侧句柄丢了、C 侧还挂着**" —— 尺子照不到。
> 修完 C1 后应把它的度量改成**行为计数**（把回调依赖的模块全局换成计数桩，
> 触发一次重绘，断言计数不再增长）。

### C2 路径位置正确
| 场景 | 期望 |
|---|---|
| 无父级物体 | 与 F-Curve 求值一致 |
| 有父级物体 | 含 `matrix_parent_inverse` |
| 骨骼 / 子骨骼 | head 的世界位置 |
| 挂在骨骼上的物体 | 含骨长平移 |
- 自动化：`regression.py`（t_core / t_obj_no_parent / t_obj_static_parent / t_bone / t_bone_child / t_bone_parented_object / t_axis_backfill）—— **实测误差 0.00e+00**

### C3 多对象 / 多骨骼同时显示
- 选中多个有动画的对象（或骨骼）→ 路径同时出现，可编辑其中任意一个
- 自动化：`regression.py:t_multi_slot`

---

## 二、点得中

### C4 选中操作
| 操作 | 期望 |
|---|---|
| 点黄点 | 选中（变红 + 发光） |
| Shift + 点 | 加选；**松开 Shift 后选中保持** |
| Ctrl + 点 | 区间选择 |
| 点空白 | 清除所有选中 |
- 自动化：`gui_click_select_check.py`

> ⚠️ **本轮实测发现的脆弱点**：关键帧/手柄的命中依赖 `cached_positions` 与
> `path_point_sequence`，而这两份缓存的**唯一生产者是 `cache.refresh_position_store()`**
> （真实使用中由自动刷新守护进程负责）。缓存不在时，点击会**静默地全部落空**
> （modal 一路返回 `PASS_THROUGH`，用户看到"点不中任何东西"，控制台无提示）。
> 录制台第一版就踩到了这个坑（S4/S5 全是 PASS_THROUGH）。
> ⇒ 修 C4 相关代码时，要保证"缓存缺失"是可观测的，而不是静默降级。

### C5 命中优先级（不互相抢）
| 想点 | 期望 |
|---|---|
| 关键帧点 | 不被三角抢（有 14px 保护半径） |
| 手柄端点 | 能点中；长度为零时改点空心圆抓取点 |
| 三角 | 本体（含靠里那部分）整块可点 |
- 自动化：`gui_tri_kf_misclick_check.py`、`gui_endpoint_outer_hit_check.py`、`gui_endpoint_hollow_check.py`

---

## 三、拖得动

### C6 拖关键帧
- 点黄点 → 拖 → 位置变；多选后拖任意一个，全部一起动
- **按下瞬间不跳变**
- 自动化：`gui_drag_baseline_check.py`、`gui_interaction_v2_check.py`

### C7 拖手柄 【本轮兑现】
| 操作 | 期望 |
|---|---|
| 拖手柄端点 | 形状变；**按下瞬间纹丝不动** |
| 拖手柄线 | 改该帧速度方向 |
| 端点手柄 | 第一次拖出时方向自动贴住路径 |
| 手柄缩到屏幕上看不见（≤6px） | **不该触发"封口"把对侧改成 FREE** |
- **现状**：⚠️ 有父级缩放的物体上会重现误封口
- 自动化：`gui_mouse_drag_weight_check.py`、`gui_endpoint_tangent_check.py`、`gui_endpoint_hollow_check.py`

### C8 保速度模式（默认）
- 拖中间帧手柄 / 单点 S 缩放 / 端点 S 缩放 → **关键帧处速度不变**
- 端点手柄第一次拖出时不保速（从 0 起步），之后保速
- 自动化：`gui_point_scale_keepspeed_check.py`

### C9 改速度模式
- 拖手柄 → 速度分布（三角）不变
- 自动化：`gui_backspace_reset_check.py`

### C10 拖三角
| 操作 | 期望 |
|---|---|
| 拖三角 | 该侧疏密变；往上拖 = 更疏（对上三角） |
| 默认（一体） | 两个三角一起选中，两侧**各加减同一增量、差异保留** |
| 分离后 | 只影响被点的那一侧 |
- 自动化：`gui_speed_handle_check.py`、`gui_tri_lock_check.py`

### C11 双击三角
- 一体 → 分离（三角变空心）；再双击 → 锁回一体，并**让 GE 两根手柄共线**
- 自动化：`gui_ge_align_check.py`、`gui_tri_lock_check.py`

### C12 G/R/S 模态 【本轮兑现】
| 项 | 期望 |
|---|---|
| 数值 | 拖动时状态栏实时显示 |
| 锁轴 | X/Y/Z 单轴、Shift+X/Y/Z 平面 |
| 数字输入 | 敲数字精确输入；Backspace 两段重置 |
| Shift | 精度 ×0.1（R 是 ×1/30） |
| 退出 | 左键/回车确认；右键/ESC 取消并还原 |
| **姿态模式** | **选中骨骼按 G/R/S 也应可用** |
- **现状**：❌ 姿态模式下按 G/R/S **完全没反应**（原生键被抑制、插件又找不到骨骼曲线）
- 自动化：`test_status_text.py`、`gui_numeric_check.py`、`gui_transform_check.py`、`gui_native_semantics_check.py`

### C13 撤销 【本轮兑现】
- 拖拽一步一撤；双击锁定/分离可撤销；Ctrl+Shift+Z 重做
- **只单击选中、没拖动 → 不该产生一步空 undo**
- **现状**：⚠️ 单击也推一步
- 自动化：`gui_undo_lock_check.py`、`gui_tri_lock_check.py`

---

## 四、不帮倒忙

### C14 状态持久化
- 一体/分离、体感手柄类型**存进工程**；重启 Blender 后不丢
- 自动化：`_feel_persist_probe.py`、`_frozen_persist_probe.py`（**双进程验证**：进程 1 保存、进程 2 打开）

### C15 性能
- 250 帧对象刷新 < 50ms（实测 1.26ms）
- 大幅快速拖手柄时显卡占用不飙升（帧率节流）
- 自动化：`regression.py:t_perf`、`gui_speed_throttle_check.py`

---

## 五、本轮已知会"变"的地方（预期内，不是回归）

| 契约 | 从 | 到 |
|---|---|---|
| C1 | 越开关越浓 | 始终一致 |
| C7 | 有父级缩放时误封口 | 不再误封口 |
| C12 | 英文界面下状态栏是中文 | 英文界面下是英文 |
| C12 | 姿态模式 G/R/S 没反应 | 可用 |
| C13 | 单击选中产生空 undo 步 | 不产生 |
| 控制台 | 中文 `print` 前缀 | 按需改英文 |

---

## 六、明确不做的事

- 不改保速/疏密的数学语义、不改默认值、不改 UI 布局
- 不新增用户可见功能（骨骼模态属于**兑现既有承诺**）
- 不在"全量门禁 + 快照录像机"就绪之前动结构重构
