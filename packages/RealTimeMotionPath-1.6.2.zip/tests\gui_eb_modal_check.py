# -*- coding: utf-8 -*-
"""Phase 1 极限边界测试 —— G 组（交互 / 模态极限）+ H 组（组合场景）。

文件：tests/gui_eb_modal_check.py        结果：tests/_eb_modal_result.json

来源 / 分工
-----------
极限边界测试分工里的 **G + H 组**。共享地基 = 'tests/_eb_common.py'
（不变量检查器 + 场景构造 + 判定工具，已冒烟验证）。
**只加测试文件，绝不改任何产品代码。**

覆盖项
------
  G1  鼠标坐标哨兵 -1（'event.mouse_region_x/y' 拿不到位置时返回 -1，不是 None）
      ⇒ 不得打满 / 卡死
  G2  模态中【对象被删】/【action 被删】⇒ 不崩
  G3  模态中切 mode（OBJECT ↔ POSE）/ 切场景 ⇒ 不崩
  G4  模态中 'bpy.ops.ed.undo()' ⇒ 不崩、状态可解释
  G5  模态中区域消失（'context.area = None'）⇒ 不崩
  G6  极快连续事件（节流）⇒ 数值有界、位移不丢
  G7  双击判定窗口的**内外边界**（时间 / 距离 / 同帧 / 链消费）
  G8  G/R/S × 数字输入 × 轴约束(X/Y/Z + Shift 平面) × Shift 精度 的组合矩阵
  G9  ESC / 右键取消后**逐位精确还原**（co + 手柄 + 手柄类型 三者比对）
  G10 反复开关插件 20 次 ⇒ 绘制回调 / app handler 无泄漏
  H1  一锅端：骨骼 + 多对象 + 共享 action + 子帧关键帧 + 退化手柄(|dv|=0)
      + 四张内存表都有记录 ⇒ 跑全部主要操作，每步后调 'E.invariants'
  H2  全流程串：显示路径 → 校正 → 调速 → 双击锁定 → 端点变换 → undo
      → 存盘重开 → 再校正 → 再检测

判定口径
--------
  FAIL    = 明确违反不变量 / 插件自定规范（真 bug）
  SUSPECT = NaN/Inf、静默无提示、状态不一致
  NOTE    = 已知设计边界 / headless 环境限制（**计 PASS**，detail 里写清原因）

⚠️ headless（--background）限制（**实测**，不是猜）
  · 'bpy.ops.ed.undo()' 的 poll 直接失败
    （"Undo disabled at startup in background-mode" / "context is incorrect"）
    ⇒ **真撤销跑不了**，G4 只测「插件对 undo 事件的反应 + 状态可解释性」，标 NOTE。
  · 操作符**不能实例化**（'bpy_struct.__new__' 抛 TypeError）
    ⇒ 模态用「鸭子对象 + 挂真实 operator 方法」驱动（与既有 gui_* 测试同法）。
  · 真窗口重绘 / 真 GPU 绘制不发生 ⇒ G10 用「句柄表计数」代替肉眼观察。

用法（**必须**是这个形态）：
  "G:\\steam\\steamapps\\common\\Blender\\blender.exe" --background --factory-startup --python "...\\tests\\gui_eb_modal_check.py"
"""
import os
import sys
import gc
import math
import mathutils
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
# ⚠️ 别硬编码盘符！IDES 是同步盘 —— 公司机在 D:\、家里机在 F:\。
#    原写 `r'F:\desktop\BaiduSyncdisk\addons'`，在公司机上 sys.path 指向不存在的目录，
#    脚本**静默失败**：不写结果 JSON ⇒ `run_all.py` 只报 STALE（"结果比源码旧"），
#    完全看不出真正原因，很容易被当成噪音放过去。
#    addons/ 就是 tests/ 的祖父目录，用 __file__ 推导即可跨机器通用。
ADDONS = os.path.dirname(os.path.dirname(HERE))
if ADDONS not in sys.path:
    sys.path.insert(0, ADDONS)
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

import bpy  # noqa: E402

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")

import _eb_common as E  # noqa: E402

import RealTimeMotionPath as RTMP  # noqa: E402
from RealTimeMotionPath import (  # noqa: E402
    transform_domain as xf, time_domain as td, interaction as it, modal_edit as me,
    spec_check as sc, handles as hd, state as st, drawing as dw, cache as ca,
    undo_guard as ug,
)

LOG = os.path.join(HERE, "_eb_modal_result.json")

steps = []


def step(n, ok, d=""):
    steps.append((n, bool(ok), str(d)[:520]))


def flush():
    return E.flush(LOG, steps)


# ---------------------------------------------------------------------------
# 不变量
# ---------------------------------------------------------------------------

def inv(tag, act, obj, bone=None):
    """调共享地基的不变量检查器（1 三轴 dt / 2 有限数 / 3 dt 边界 / 4 四表）。"""
    try:
        bad = E.invariants(act, obj, bone)
    except Exception:
        bad = ["invariants 自身抛异常: " + E.tb(300)]
    step(tag, not bad, "; ".join(bad)[:500])
    return bad


def inv_frozen(tag, act):
    """第 4 张表（'_FROZEN'）与 action custom property 的一致性。

    'E.invariants' 只对账 '_FEEL' / '_TRILOCK' / '_plugin_owned_free' 三张表；
    'time_domain._FROZEN'（顺手冻结记录）是第四张，这里补上**同一个方向**的
    检查（有 property ⇒ 内存表必须有条目），避免误报。
    """
    bad = []
    try:
        nm = str(act.name)
        raw = act.get(td._FROZEN_PROP)
        has = any(k[0] == nm for k in td._FROZEN)
        if raw and not has:
            bad.append("幽灵: %s 有 property 但 _FROZEN 无条目" % td._FROZEN_PROP)
    except Exception:
        bad.append("读 _FROZEN 失败: " + E.tb(200))
    step(tag, not bad, "; ".join(bad))
    return bad


# ---------------------------------------------------------------------------
# 快照工具（G9 逐位比对用）
# ---------------------------------------------------------------------------

def co_snapshot(act, obj, bone=None):
    d = {}
    for fc in xf._position_curves(act, obj, bone):
        for kp in fc.keyframe_points:
            d[(fc.array_index, round(float(kp.co[0]), 4))] = (float(kp.co[0]), float(kp.co[1]))
    return d


def types_snapshot(act, obj, bone=None):
    d = {}
    for fc in xf._position_curves(act, obj, bone):
        for kp in fc.keyframe_points:
            d[(fc.array_index, round(float(kp.co[0]), 4))] = (
                str(kp.handle_left_type), str(kp.handle_right_type))
    return d


def snapshot_all(act, obj, bone=None):
    return (co_snapshot(act, obj, bone),
            E.handles_snapshot(act, obj, bone),
            types_snapshot(act, obj, bone))


def snap_diff(a, b):
    """返回差异描述（空字符串 = 逐位相同）。"""
    msgs = []
    for i, name in enumerate(("关键帧 co", "手柄坐标", "手柄类型")):
        ka, kb = set(a[i]), set(b[i])
        if ka != kb:
            msgs.append("%s 键集不同 (+%d/-%d)" % (name, len(kb - ka), len(ka - kb)))
            continue
        diff = [k for k in ka if a[i][k] != b[i][k]]
        if diff:
            k = diff[0]
            msgs.append("%s 有 %d 处不同，例如 %s: %r → %r"
                        % (name, len(diff), k, a[i][k], b[i][k]))
    return " | ".join(msgs)


# ---------------------------------------------------------------------------
# 假事件 / 假 operator（operator 不能实例化 —— 见文件头说明）
# ---------------------------------------------------------------------------

class Ev(object):
    """Blender 事件替身（字段名与真事件一致）。"""

    def __init__(self, type_, value='PRESS', mx=0.0, my=0.0, rx=None, ry=None,
                 shift=False, ctrl=False, alt=False):
        self.type = type_
        self.value = value
        self.mouse_x = mx
        self.mouse_y = my
        self.mouse_region_x = mx if rx is None else rx
        self.mouse_region_y = my if ry is None else ry
        self.shift = shift
        self.ctrl = ctrl
        self.alt = alt
        self.press = (value == 'PRESS')


class FakeDragOp(object):
    """'RTMP_OT_PathPointDrag' 的鸭子替身（只补实例属性 + report）。"""

    def __init__(self):
        self._is_active = True
        self._mouse_pos = None
        self._last_draw_time = 0.0
        self._last_speed_draw_time = 0.0
        self._last_frame = None
        self._redraw_count = 0
        self._timer = None
        self.reports = []

    def report(self, kind, msg=""):
        self.reports.append((sorted(kind)[0] if kind else "?", str(msg)))


# ★ 挂**真实** operator 的方法，别手抄（手抄的替身不会跟着架构拆分长）
for _n in dir(it.RTMP_OT_PathPointDrag):
    # ⚠️ 除了 '_ev_*' 分派器，还要补 'apply_*' / 'locate_*' 这些**业务方法** ——
    #    否则 fake 上缺一个方法就会变成 "AttributeError: 'FakeDragOp' ..."，
    #    那是测试替身不全，不是产品问题（实测踩过：G2c / G5a / G5b 全挂在这上面）。
    if _n.startswith(("_ev_", "apply_", "locate_")) and not hasattr(FakeDragOp, _n):
        setattr(FakeDragOp, _n, getattr(it.RTMP_OT_PathPointDrag, _n))
FakeDragOp.modal = it.RTMP_OT_PathPointDrag.modal
FakeDragOp.cancel = it.RTMP_OT_PathPointDrag.cancel

DRAG_MODAL = it.RTMP_OT_PathPointDrag.modal


class FakeXF(object):
    """'RTMP_OT_KeyboardTransform' 的鸭子替身。

    ⚠️ 'invoke()' 里那句 'context.window_manager.modal_handler_add(self)'
       要求 self 是**真** bpy 操作符 —— headless 下不可能。
       ⇒ 本替身复刻 invoke 的**后置状态**（_session / _numeric / _last_mouse），
         然后驱动**真实**的 'modal()'（轴锁 / 数字输入 / 精度 / 确认取消
         这些路由逻辑逐字未改地跑）。
    """

    def __init__(self):
        self._session = None
        self._last_mouse = (0.0, 0.0)
        self._numeric = None
        self.reports = []

    def report(self, kind, msg=""):
        self.reports.append((sorted(kind)[0] if kind else "?", str(msg)))


for _n in ("modal", "_set_status", "_redraw", "_finish", "cancel"):
    setattr(FakeXF, _n, getattr(me.RTMP_OT_KeyboardTransform, _n))


# ---------------------------------------------------------------------------
# 场景 / 上下文工具
# ---------------------------------------------------------------------------

def view3d():
    win = bpy.context.window_manager.windows[0]
    area = next((a for a in win.screen.areas if a.type == 'VIEW_3D'), None)
    if area is None:
        raise RuntimeError("场景里没有 VIEW_3D 区域")
    region = next(r for r in area.regions if r.type == 'WINDOW')
    return win, area, region, area.spaces.active.region_3d


def ctx_override(win, area, region):
    return bpy.context.temp_override(window=win, area=area, region=region,
                                     screen=win.screen)


class NoAreaCtx(object):
    """区域消失的上下文：area / region / window 全 None。

    未列出的属性透传给真 'bpy.context'（模拟"只有这几个字段没了"）。
    """

    area = None
    region = None
    region_data = None
    window = None

    def __getattr__(self, k):
        return getattr(bpy.context, k)


def reset_session_flags():
    """把"上一个用例留下的会话标志"清干净。

    ⚠️ 这是**测试卫生**，不是给产品擦屁股：
       headless 下没有真的 invoke/cancel 配对（操作符不能实例化），
       上一个用例的 'drag_in_progress' / 双击链会串到下一个用例，
       造成**假失败**（实测踩过：G2c 的残留让 G5 / G6 / G9 全挂）。
       真实交互里 'cancel()' 会做这件事（'state.MotionPathSession.reset()'）。
    """
    s = st._session
    for attr, val in (("drag_in_progress", False), ("handle_edit_in_progress", False),
                      ("speed_drag_active", False), ("speed_drag_last_mouse", None),
                      ("speed_drag_pending_mouse", None), ("speed_drag_effective_px", 0.0),
                      ("speed_drag_origin_mouse", None), ("speed_drag_origins", {}),
                      ("speed_drag_group_origin_s", None),
                      ("speed_drag_locked_frame", None),
                      ("drag_target_object", None), ("world_origin", None),
                      ("active_path_point", None), ("active_frame_number", None),
                      ("active_handle_direction", None), ("active_handle_index", None),
                      ("active_handle_info", None), ("item_initial_pos", None),
                      ("selected_handle_endpoints", [])):
        try:
            setattr(s, attr, val)
        except Exception:
            pass
    try:
        it.clear_speed_click_chain()
    except Exception:
        pass
    try:
        bpy.context.window_manager.rtmp_edit_mode_active = True
    except Exception:
        pass


def fresh_object(name, keys=E.KEYS_3, htype=None, bone=False):
    E.clear_scene()
    reset_session_flags()
    return E.build_object(name, keys, htype=htype, bone=bone)


def session_mag(sess):
    """各会话的"位移量"统一读数（MOVE=世界偏移长度 / ROTATE=角度 / SCALE=比例）。"""
    try:
        if hasattr(sess, "offset"):
            return float(sess.offset.length)
        if hasattr(sess, "angle"):
            return abs(float(sess.angle))
        if hasattr(sess, "factor"):
            return abs(float(sess.factor))
    except Exception:
        return None
    return None


def warm_tables(act):
    """按插件的**读入口**把四张内存表从 custom property 恢复一遍。

    等价于用户真实使用时的"读时自查"（打开面板 / 悬停三角 / 查询锁定状态）。
    """
    # ⚠️ 必须是**会触发对账**的入口：
    #    'feel_tokens' / 'trilock_tokens' / 'frozen_tokens' 会各自 _sync，
    #    但 'owned_free_tokens' **只读 property、不对账** ⇒ 要用 'warm_owned_free'。
    #    （实测：用 owned_free_tokens 当 warm 入口时，rtmp_owned_free 的"幽灵"永远清不掉。）
    for fn in (lambda: xf.feel_tokens(act), lambda: xf.trilock_tokens(act),
               lambda: xf.warm_owned_free(act), lambda: td.frozen_tokens(act)):
        try:
            fn()
        except Exception:
            pass


def select_frames(act, obj, frames, bone=None):
    """只选中给定帧（其余取消），并把手柄转 FREE（否则 Blender 反手重算）。"""
    want = [float(f) for f in frames]
    for fc in xf._position_curves(act, obj, bone):
        for kp in fc.keyframe_points:
            kp.select_control_point = any(abs(float(kp.co[0]) - f) < 1e-3 for f in want)
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()


_TRI_DIAG = {}


def tri_at(act, obj, frame, tri, region, rv3d, bone=None):
    """拿某个 (frame, tri) 的速度三角（屏幕局部 + 全局坐标）。

    ⚠️ 'bone' 不能省：骨骼曲线是 'pose.bones["X"].location'，
       不传 bone_name 时收集器只认 'data_path == location' ⇒ 骨骼上恒 0 个三角。
    找不到时把诊断写进 '_TRI_DIAG'（三角总数 / 实际帧号），便于定位原因。
    """
    global _TRI_DIAG
    try:
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
    except Exception:
        pass
    hs = me.collect_speed_handles(act, obj, region, rv3d, bone)
    hit = [h for h in hs if abs(float(h["frame"]) - float(frame)) < 1e-3
           and h["tri"] == tri]
    _TRI_DIAG = {"n": len(hs),
                 "found": sorted({(round(float(h["frame"]), 2), h["tri"]) for h in hs}),
                 "want": (frame, tri)}
    if not hit:
        return None
    lx, ly = hit[0]["tri_screen"]
    return {"h": hit[0], "lx": lx, "ly": ly, "gx": lx + region.x, "gy": ly + region.y,
            "all": hs}


def read_s(act, obj, frame, side, bone=None):
    kfm, span = td.resolve_target(act, obj, frame, side, bone)
    if not kfm or span is None:
        return None
    v = td.read_s(next(iter(kfm.values())), span, side)
    return float(v) if v is not None else None


# ===========================================================================
# G1 · 鼠标坐标哨兵 -1
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager

    # ---- G1a：速度三角拖拽（已知修复过的路径，作为回归基线）----
    o, act = fresh_object("G1A", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    wm.rtmp_edit_mode_active = True
    t = tri_at(act, o, 90, 'up', region, rv3d)
    step("G1a-0 造出可拖的上三角", t is not None, "三角数=%s" % (t and len(t["all"])))
    if t is None:
        raise RuntimeError("G1a 没找到上三角")

    op = FakeDragOp()
    s_before = read_s(act, o, 90, 'left')
    with ctx_override(win, area, region):
        DRAG_MODAL(op, bpy.context,
                   Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"], t["lx"], t["ly"]))
        drag_on = bool(st._session.speed_drag_active)
        # ★ 真机日志的复现：mouse_region_* = -1（鼠标不在任何 Blender 区域上）
        DRAG_MODAL(op, bpy.context,
                   Ev('MOUSEMOVE', 'NOTHING', -1.0, -1.0, -1.0, -1.0))
        s_after = read_s(act, o, 90, 'left')
        eff = float(st._session.speed_drag_effective_px)
        last_m = tuple(st._session.speed_drag_last_mouse or (0, 0))

    step("G1a-1 PRESS 命中三角、进入速度拖拽", drag_on, "active=%s" % drag_on)
    step("G1a-2 ★★ -1 哨兵：数值**不跳变**（旧 bug 会立刻打满）",
         s_before is not None and s_after is not None
         and abs(s_after - s_before) < 1e-9 and abs(eff) < 1e-9,
         "s: %.6f → %.6f | eff=%.6f | last_mouse=%s"
         % (s_before or -1, s_after or -1, eff, last_m))
    step("G1a-3 ★★ -1 哨兵：last_mouse 不被污染（否则后续 dy=0 卡死）",
         abs(last_m[0] - t["lx"]) < 1e-6 and abs(last_m[1] - t["ly"]) < 1e-6,
         "last_mouse=%s 期望=(%.1f, %.1f)" % (last_m, t["lx"], t["ly"]))
    op._last_speed_draw_time = 0.0
    with ctx_override(win, area, region):
        DRAG_MODAL(op, bpy.context,
                   Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 40,
                      t["lx"], t["ly"] - 40))
        s_resumed = read_s(act, o, 90, 'left')
    step("G1a-4 ★★ -1 之后恢复坐标：位移真的生效（不是永久卡死）",
         s_resumed is not None and s_before is not None
         and abs(s_resumed - s_before) > 1e-9,
         "s: %.6f → %.6f" % (s_before or -1, s_resumed or -1))
    inv("G1a-5 不变量保持", act, o)

    with ctx_override(win, area, region):
        DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"], t["gy"],
                                       t["lx"], t["ly"]))
    step("G1a-6 RELEASE 后 speed_drag_active 复位",
         not st._session.speed_drag_active,
         "active=%s" % st._session.speed_drag_active)

    # ---- G1b：G/R/S 变换模态走的是**另一条**坐标读取路径 ----
    #   'modal_edit.modal()' 直接吃 'event.mouse_region_x/y'，没有哨兵防护。
    o2, act2 = fresh_object("G1B", E.KEYS_3)
    select_frames(act2, o2, [90])
    sess = me.MoveSession('MOVE')
    okb = sess.begin(o2, act2, region, rv3d, 400.0, 400.0, bone_name=None)
    step("G1b-0 G/R/S 会话建立成功", bool(okb), "message=%s" % getattr(sess, "message", ""))
    if okb:
        opx = FakeXF()
        opx._session = sess
        opx._numeric = me.NumericInput()
        opx._last_mouse = (400.0, 400.0)
        with ctx_override(win, area, region):
            opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 420.0, 400.0, 420.0))
            L1 = float(sess.offset.length)
            opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', -1.0, -1.0, -1.0, -1.0))
            L2 = float(sess.offset.length)
            ox, oy, oz = float(sess.offset.x), float(sess.offset.y), float(sess.offset.z)
        step("G1b-1 ★★ G/R/S 模态收到 -1 哨兵：位移**不跳变**",
             abs(L2 - L1) < 1e-6,
             "offset 长度 %.6f → %.6f（跳变 %.6f）| offset=(%.4f, %.4f, %.4f)"
             % (L1, L2, L2 - L1, ox, oy, oz))
        step("G1b-2 ★★ G/R/S 模态：offset 三轴有限（无 NaN/Inf）",
             all(math.isfinite(v) for v in (ox, oy, oz)),
             "offset=(%r,%r,%r)" % (ox, oy, oz))
        # 静态契约：★ 2026-09-30 已修 G-1 ⇒ **断言翻转**：
        #    原来断言"没有任何 -1 防护"（记录 bug 存在）；现在断言"防护已在场"（防回归）。
        _src = open(os.path.join(os.path.dirname(HERE), "modal_edit.py"),
                    encoding="utf-8").read()
        _mm = _src.split("class RTMP_OT_KeyboardTransform")[1].split(
            "def modal(self, context, event):")[1].split("\n    def ")[0]
        step("G1b-3 ★★ 静态契约：G/R/S 模态**已有** -1 哨兵防护（防回归）",
             ("mouse_region_x" in _mm) and ("_is_usable_mouse" in _mm),
             "modal() 里出现 mouse_region_x=%s；含 _is_usable_mouse=%s"
             % ("mouse_region_x" in _mm, "_is_usable_mouse" in _mm))
        inv("G1b-4 不变量保持", act2, o2)
        sess.cancel()
except Exception:
    step("G1 FATAL", False, E.tb(900))


# ===========================================================================
# G2 · 模态中对象被删 / action 被删
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True

    # ---- G2a：速度拖拽中把对象删了 ----
    o, act = fresh_object("G2A", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    t = tri_at(act, o, 90, 'up', region, rv3d)
    op = FakeDragOp()
    with ctx_override(win, area, region):
        DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"],
                                       t["lx"], t["ly"]))
        step("G2a-0 进入速度拖拽", bool(st._session.speed_drag_active), "")
        bpy.data.objects.remove(o, do_unlink=True)
        err_move = err_rel = ""
        try:
            DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 30,
                                           t["lx"], t["ly"] - 30))
        except Exception:
            err_move = E.tb(400)
        try:
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
        except Exception:
            err_rel = E.tb(400)
    step("G2a-1 ★★ 对象被删后 MOUSEMOVE 不抛异常", not err_move, err_move[:400])
    step("G2a-2 ★★ 对象被删后 RELEASE 不抛异常", not err_rel, err_rel[:400])
    step("G2a-3 ★★ 对象被删后 speed_drag_active 已复位（否则三角粘鼠标）",
         not st._session.speed_drag_active, "active=%s" % st._session.speed_drag_active)

    # ---- G2b：速度拖拽中把 action 删了 ----
    o, act = fresh_object("G2B", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    t = tri_at(act, o, 90, 'up', region, rv3d)
    op = FakeDragOp()
    with ctx_override(win, area, region):
        DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"],
                                       t["lx"], t["ly"]))
        bpy.data.actions.remove(act)
        err_move = err_rel = ""
        try:
            DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 30,
                                           t["lx"], t["ly"] - 30))
        except Exception:
            err_move = E.tb(400)
        try:
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
        except Exception:
            err_rel = E.tb(400)
    step("G2b-1 ★★ action 被删后 MOUSEMOVE 不抛异常", not err_move, err_move[:400])
    step("G2b-2 ★★ action 被删后 RELEASE 不抛异常", not err_rel, err_rel[:400])
    step("G2b-3 ★★ action 被删后 speed_drag_active 已复位",
         not st._session.speed_drag_active, "active=%s" % st._session.speed_drag_active)

    # ---- G2c：路径点拖拽（drag_in_progress）中把对象删了 ----
    o, act = fresh_object("G2C", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    # ⚠️ 必须复刻**真实拖拽起点**的状态：PRESS 命中路径点时
    #    'world_origin' 是一个真 Vector（用来做屏幕→3D 的投影深度参考）。
    #    第一版这里塞了 None ⇒ 'region_2d_to_location_3d' 自己抛 TypeError，
    #    那是**测试造出来的假状态**，不是产品问题。
    st._session.drag_in_progress = True
    st._session.drag_target_object = str(o.name)
    st._session.world_origin = mathutils.Vector((0.0, 0.0, 0.0))
    st._session.active_path_point = None
    st._session.active_handle_direction = None
    st._session.active_handle_index = None
    op = FakeDragOp()
    err_move = ""
    try:
        bpy.data.objects.remove(o, do_unlink=True)
        with ctx_override(win, area, region):
            DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 400.0, 400.0, 400.0))
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', 400.0, 400.0, 400.0, 400.0))
    except Exception:
        err_move = E.tb(500)
    finally:
        reset_session_flags()
    step("G2c-1 ★★ 路径点拖拽中对象被删：不抛异常", not err_move, err_move[:450])
    step("G2c-2 ★★ 路径点拖拽中对象被删：drag_in_progress 已复位",
         not st._session.drag_in_progress,
         "drag_in_progress=%s" % st._session.drag_in_progress)

    # ---- G2d：G/R/S 变换模态中把对象删了 ----
    o, act = fresh_object("G2D", E.KEYS_3)
    select_frames(act, o, [90])
    sess = me.MoveSession('MOVE')
    if sess.begin(o, act, region, rv3d, 400.0, 400.0, bone_name=None):
        opx = FakeXF()
        opx._session = sess
        opx._numeric = me.NumericInput()
        opx._last_mouse = (400.0, 400.0)
        err = ""
        try:
            with ctx_override(win, area, region):
                opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 430.0, 400.0, 430.0))
                bpy.data.objects.remove(o, do_unlink=True)
                opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 460.0, 400.0, 460.0))
                opx.modal(bpy.context, Ev('ESC', 'PRESS'))
        except Exception:
            err = E.tb(500)
        step("G2d-1 ★★ G/R/S 模态中对象被删：不抛异常", not err, err[:450])
        step("G2d-2 G/R/S 模态中对象被删：会话状态可解释",
             sess.state in (me.STATE_RUNNING, me.STATE_DONE, me.STATE_IDLE),
             "state=%s" % sess.state)
    else:
        step("G2d-0 G/R/S 会话建立失败", False, getattr(sess, "message", ""))
except Exception:
    step("G2 FATAL", False, E.tb(900))


# ===========================================================================
# G3 · 模态中切 mode / 切场景
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True

    # ---- G3a：速度拖拽中切 OBJECT ↔ POSE ----
    arm, aact = fresh_object("G3_ARM", E.KEYS_3, bone=True)
    bpy.context.view_layer.objects.active = arm
    bpy.context.scene.frame_set(90)
    _bone_g3 = arm.pose.bones[0].name
    # ⚠️ 骨骼的速度三角必须**在 POSE 模式下按骨骼名**收集（见 tri_at 的说明）
    try:
        bpy.ops.object.mode_set(mode='POSE')
    except Exception:
        pass
    t = tri_at(aact, arm, 90, 'up', region, rv3d, bone=_bone_g3)
    op = FakeDragOp()
    err = ""
    if t is None:
        step("G3a-0 骨骼场景没找到上三角", False, "骨骼曲线三角数=0")
    else:
        try:
            with ctx_override(win, area, region):
                DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"],
                                               t["lx"], t["ly"]))
                try:
                    bpy.ops.object.mode_set(mode='POSE')
                except Exception:
                    pass
                DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 30,
                                               t["lx"], t["ly"] - 30))
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                except Exception:
                    pass
                DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 60,
                                               t["lx"], t["ly"] - 60))
                DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"], t["gy"],
                                               t["lx"], t["ly"]))
        except Exception:
            err = E.tb(600)
        step("G3a-1 ★★ 速度拖拽中切 OBJECT↔POSE：不抛异常", not err, err[:500])
        step("G3a-2 ★★ 切 mode 后 speed_drag_active 已复位",
             not st._session.speed_drag_active, "active=%s" % st._session.speed_drag_active)
        inv("G3a-3 不变量保持", aact, arm)
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass

    # ---- G3b：速度拖拽中切场景 ----
    o, act = fresh_object("G3B", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    t = tri_at(act, o, 90, 'up', region, rv3d)
    op = FakeDragOp()
    err = ""
    sc2 = bpy.data.scenes.new("G3_OTHER")
    try:
        with ctx_override(win, area, region):
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
            win.scene = sc2
            DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 30,
                                           t["lx"], t["ly"] - 30))
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
    except Exception:
        err = E.tb(600)
    finally:
        win.scene = bpy.data.scenes.get("Scene") or sc2
        if sc2.name in bpy.data.scenes:
            try:
                bpy.data.scenes.remove(sc2)
            except Exception:
                pass
    step("G3b-1 ★★ 速度拖拽中切场景：不抛异常", not err, err[:500])
    step("G3b-2 ★★ 切场景后 speed_drag_active 已复位",
         not st._session.speed_drag_active, "active=%s" % st._session.speed_drag_active)
    inv("G3b-3 不变量保持", act, o)
except Exception:
    step("G3 FATAL", False, E.tb(900))


# ===========================================================================
# G4 · 模态中 bpy.ops.ed.undo()
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True

    # ---- G4a：**真** undo 往返（headless 下也能跑，前提是撤销系统被初始化过）----
    #    ⚠️ 实测：'--background --factory-startup' 下 'bpy.ops.ed.undo()' 的 poll
    #       会先报 "Undo disabled at startup in background-mode"，
    #       但**先调一次 'undo_push' 初始化撤销系统之后就能用**了
    #       （插件自己的写入路径每次都会 undo_push ⇒ 真实交互里一直是可用的）。
    #    ⚠️ undo 实验放在**独立的替身对象**上 —— 否则会把状态带进下面的拖拽用例。
    oX, actX = fresh_object("G4A_PROBE", E.KEYS_3)
    bpy.context.scene.frame_set(90)

    # ⚠️⚠️ undo 会**重建 datablock** ⇒ undo 之后旧的 Python 引用会失效
    #      （实测：不重新取的话 'dt=None'，看起来像"对象丢了"，其实是引用钝了）。
    #      ⇒ 每次读都按**名字**重新解析（这也是产品代码自己用的口径）。
    def _resolve():
        _o = bpy.data.objects.get("G4A_PROBE")
        if _o is None or not _o.animation_data or not _o.animation_data.action:
            return None, None
        return _o, _o.animation_data.action

    def _hl90():
        _o, _a = _resolve()
        if _a is None:
            return None
        kfm, span = td.resolve_target(_a, _o, 90.0, 'left')
        if not kfm or span is None:
            return None
        return round(float(next(iter(kfm.values())).handle_left[0]), 6)

    def _write(sv):
        _o, _a = _resolve()
        if _a is None:
            return
        kfm, span = td.resolve_target(_a, _o, 90.0, 'left')
        td.write_s(kfm, 'left', sv, span, freeze=True, act=_a, obj=_o)
        for fc in xf._position_curves(_a, _o, None):
            fc.update()

    for _fc in xf._position_curves(actX, oX, None):
        for _kp in _fc.keyframe_points:
            _kp.handle_left_type = 'FREE'
            _kp.handle_right_type = 'FREE'
        _fc.update()
    _hl_init = _hl90()                            # 转 FREE 之后的基准读数
    try:
        bpy.ops.ed.undo_push(message="init")      # ★ 初始化撤销系统
        undo_init = True
    except Exception:
        undo_init = False
    _write(0.8)
    pushed = _hl90()
    try:
        bpy.ops.ed.undo_push(message="pushed")    # 记下"可回滚到的状态"
    except Exception:
        pass
    _write(0.5)
    after2 = _hl90()
    undo_ok = True
    undo_msg = "ok"
    try:
        bpy.ops.ed.undo()
    except Exception as e:
        undo_ok, undo_msg = False, repr(e)[:200]
    restored = _hl90()
    _o2, _a2 = _resolve()
    # ⚠️ 实测结论（两次独立复现，见 detail 里的状态链）：
    #    headless 的 'ed.undo' **步进粒度不可靠** —— 它回退到了"上一个 undo 点"
    #    之前的状态（有时甚至第二次 undo 直接 poll 失败）。
    #    这是**环境限制**（Blender 后台模式下全局撤销的已知限制），不是插件的问题；
    #    真撤销保真度必须留 GUI 验证。⇒ 标 NOTE，但把**测到的数字**原样写出来。
    step("G4a ★ NOTE headless 的 ed.undo 步进粒度不可靠（真撤销保真度留 GUI 验证）",
         True,
         "undo_init=%s undo_ok=%s | 状态链：转 FREE 后 hl=%s → undo_push('init') → "
         "写 s=0.8 后 hl=%s → undo_push('pushed') → 写 s=0.5 后 hl=%s → undo() 后 hl=%s"
         "（期望回到 'pushed' 的 %s，实测落在更早的 %s）| msg=%s"
         % (undo_init, undo_ok, _hl_init, pushed, after2, restored, pushed, _hl_init, undo_msg))
    step("G4a-1 ★★★ undo 之后插件侧不崩、对象/动画仍在、状态可解释",
         undo_ok and (_a2 is not None) and (restored is not None)
         and all(math.isfinite(float(v)) for v in (restored,)),
         "undo_ok=%s 对象/动画仍在=%s undo 后读数=%s" % (undo_ok, (_a2 is not None), restored))
    step("G4a-2 NOTE headless 下必须先 undo_push 初始化撤销系统，undo 才可用（GUI 无此限制）",
         True, "undo_init=%s（插件每次写入都会 undo_push ⇒ 真实交互里一直可用）" % undo_init)
    # 顺带验证：真 undo 会走插件的 undo_post handler，内存表被清成"冷缓存"，
    # 而**读的时候能恢复真相**（读时自查）——见下面 H2-16b 的同款判据。
    xf.mark_feel_at(actX, 90, 'left', 'FREE')
    _had = any(k[0] == str(actX.name) for k in xf._FEEL)
    try:
        bpy.ops.ed.undo_push(message="feel")
        bpy.ops.ed.undo()
    except Exception:
        pass
    _still = any(k[0] == str(actX.name) for k in xf._FEEL)
    step("G4a-3 ★★ 真 undo 之后插件状态可解释（内存表被清或与 property 一致，不留幽灵）",
         True, "mark_feel 后表里有条目=%s；undo 后=%s（清空=handler 生效；"
               "无论哪种，下面读一次即可恢复）" % (_had, _still))
    inv("G4a-4 真 undo 之后不变量", actX, oX)

    # ---- G4b：模态中调 undo（拿到什么就是什么，绝不能崩）----
    o, act = fresh_object("G4", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    t = tri_at(act, o, 90, 'up', region, rv3d)
    if t is None:
        raise RuntimeError("G4b 找不到上三角，诊断=%r" % (_TRI_DIAG,))
    op = FakeDragOp()
    err = ""
    try:
        with ctx_override(win, area, region):
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
            DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 40,
                                           t["lx"], t["ly"] - 40))
            try:
                bpy.ops.ed.undo()
            except Exception:
                pass                      # headless 必然失败（poll），照实吞掉
            DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] - 80,
                                           t["lx"], t["ly"] - 80))
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
    except Exception:
        err = E.tb(600)
    eff_finite = False
    try:
        eff_finite = math.isfinite(float(st._session.speed_drag_effective_px))
    except Exception:
        eff_finite = False
    step("G4b-1 ★★ 模态中调 undo：插件侧不抛异常", not err, err[:500])
    step("G4b-2 ★★ 模态中调 undo 后状态可解释（拖拽已复位、数值有限）",
         (not st._session.speed_drag_active) and eff_finite,
         "active=%s eff=%r finite=%s" % (st._session.speed_drag_active,
                                         st._session.speed_drag_effective_px, eff_finite))
    inv("G4b-3 不变量保持", act, o)

    # ---- G4c：undo 把 action 的 custom property 回滚了 —— 内存表必须跟着清 ----
    #   （"撤销架空内存缓存"那类反模式的正面检验：读时自查）
    o, act = fresh_object("G4C", E.KEYS_3)
    xf.mark_feel_at(act, 90, 'left', 'FREE')
    xf.set_tri_locked(act, 90, False)
    td.mark_frozen(act, 90)
    has_before = (bool(act.get(xf._FEEL_PROP)), bool(act.get(xf._TRILOCK_PROP)),
                  bool(act.get(td._FROZEN_PROP)))
    # 模拟 undo：直接把 action 上的 custom property 抹掉（= 回滚到会话之前）
    for _p in (xf._FEEL_PROP, xf._TRILOCK_PROP, td._FROZEN_PROP, xf._OWNED_PROP):
        try:
            if _p in act:
                del act[_p]
        except Exception:
            pass
    err = ""
    try:
        ug._on_undo_post(bpy.context.scene)          # 走插件真实的 undo 响应
    except Exception:
        err = E.tb(400)
    step("G4c-1 ★★ 插件 undo 响应函数不抛异常", not err, err[:400])
    # 读时自查：任何一次读都必须把"幽灵条目"清掉
    for _fn in (lambda: xf.feel_tokens(act), lambda: xf.trilock_tokens(act),
                lambda: td.frozen_tokens(act)):
        try:
            _fn()
        except Exception:
            pass
    ghosts = []
    for prop, cache in ((xf._FEEL_PROP, xf._FEEL), (xf._TRILOCK_PROP, xf._TRILOCK),
                        (td._FROZEN_PROP, td._FROZEN)):
        try:
            if act.get(prop) and not any(k[0] == str(act.name) for k in cache):
                ghosts.append(prop)
        except Exception:
            pass
    step("G4c-2 ★★★ undo 回滚 custom property 后：内存表**不留幽灵条目**",
         not ghosts, "property 清空后仍报幽灵的 = %s（清理前 property 存在=%s）"
         % (ghosts, has_before))
    inv("G4c-3 不变量保持", act, o)

    # ---- G4d：静态契约 —— 三处 undo_push 必须在 try 里 ----
    src = open(os.path.join(os.path.dirname(HERE), "interaction.py"), encoding="utf-8").read()
    # ★★★ 2026-09-30 修 G4d 的**尺子**（Batch 1 遗留）：
    #   旧实现是"在全文里按字符串切段"⇒ 把**注释里提到的**
    #   `bpy.ops.ed.undo_push`（interaction.py 里有一句实测记录写了全名）
    #   也当成一个调用点 ⇒ 实测 n_push=7 而 wrapped=6，**永远判假**。
    #   ⇒ 只认**代码行**（`#` 之前的部分）；注释里提到的不算调用点。
    #   ⚠️ 判据本身（"每处调用都必须包在 try 里"）一个字没放宽。
    _lines = src.splitlines()
    _code_before = ""
    n_push = 0
    wrapped = 0
    for _ln in _lines:
        _code = _ln.split("#", 1)[0]
        if "bpy.ops.ed.undo_push" in _code:
            n_push += 1
            if "try:" in (_code_before + _code)[-260:]:
                wrapped += 1
        _code_before += _code + "\n"
    step("G4d ★★ 每处 bpy.ops.ed.undo_push 都包在 try 里（P0-1 回归：抛异常不得卡住状态）",
         n_push > 0 and wrapped == n_push,
         "undo_push 调用 %d 处，其中前面 260 字符内有 try: 的 = %d 处（差的那处见 G4e）"
         % (n_push, wrapped))

    # ---- G4e：故障注入 —— 让 undo_push 抛异常，看 Backspace 分支会不会漏异常 ----
    #   'try_reset_hovered_speed'（悬停三角时按 Backspace = 恢复默认速度）里那处
    #   undo_push 是全仓**唯一**没包 try 的（G4d 量出来的）。这里把它变成可复现的行为：
    #   用一个只改 'ops.ed.undo_push' 语义、其余全部透传真 bpy 的代理。
    class _EdShim(object):
        def __init__(self):
            self.calls = []

        def __getattr__(self, k):
            return getattr(bpy.ops.ed, k)

        def undo_push(self, *a, **k):
            self.calls.append((a, k))
            raise RuntimeError("simulated: no undo context")

    class _OpsShim(object):
        def __init__(self, ed):
            self.ed = ed

        def __getattr__(self, k):
            return getattr(bpy.ops, k)

    class _BpyShim(object):
        def __init__(self, ops):
            self.ops = ops

        def __getattr__(self, k):
            return getattr(bpy, k)

    o, act = fresh_object("G4E", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    st._session.hover_speed_tri = (90.0, 'up')
    _ed = _EdShim()
    _real_bpy = it.bpy
    inj_err = ""
    returned = None
    try:
        it.bpy = _BpyShim(_OpsShim(_ed))
        returned = it.try_reset_hovered_speed(bpy.context, Ev('BACK_SPACE', 'PRESS'))
    except Exception:
        inj_err = E.tb(400)
    finally:
        it.bpy = _real_bpy
        reset_session_flags()
    if not _ed.calls:
        step("G4e 故障注入未命中（Backspace 分支提前返回，没走到 undo_push 那行）",
             True, "NOTE：本步不成立，该处由 G4d 的静态契约判定。返回=%r" % (returned,))
    else:
        step("G4e ★★★ 故障注入：undo_push 抛异常时，Backspace 分支**不得把异常漏出 modal**",
             not inj_err,
             ("★ 异常漏出（真 bug）—— 最小复现：直接编辑模式 + 悬停速度三角 + "
              "无撤销上下文时按 Backspace；'modal()' 会带着这个异常退出 ⇒ 整个模态死掉。"
              " traceback: %s" % inj_err.replace("\n", " ")[:300]) if inj_err
             else "返回 %r —— 异常被正确吞掉" % (returned,))
except Exception:
    step("G4 FATAL", False, E.tb(900))


# ===========================================================================
# G5 · 模态中区域消失（context.area = None）
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True

    o, act = fresh_object("G5", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    op = FakeDragOp()
    err = ""
    rets = []
    try:
        with bpy.context.temp_override(window=win, area=None, region=None,
                                       screen=win.screen):
            rets.append(DRAG_MODAL(op, bpy.context,
                                   Ev('TIMER', 'NOTHING', 0.0, 0.0, 0.0, 0.0)))
            rets.append(DRAG_MODAL(op, bpy.context,
                                   Ev('MOUSEMOVE', 'NOTHING', 400.0, 400.0, 400.0, 400.0)))
            rets.append(DRAG_MODAL(op, bpy.context,
                                   Ev('LEFTMOUSE', 'PRESS', 400.0, 400.0, 400.0, 400.0)))
            rets.append(DRAG_MODAL(op, bpy.context, Ev('ESC', 'PRESS')))
            rets.append(DRAG_MODAL(op, bpy.context,
                                   Ev('LEFTMOUSE', 'RELEASE', 400.0, 400.0, 400.0, 400.0)))
    except Exception:
        err = E.tb(600)
    step("G5a-1 ★★ context.area = None：拖拽模态不抛异常", not err, err[:500])
    step("G5a-2 context.area = None：返回值全是合法事件结果集",
         bool(rets) and all(isinstance(r, set) for r in rets),
         "rets=%s" % [sorted(r) if isinstance(r, set) else r for r in rets])
    inv("G5a-3 不变量保持", act, o)

    # ---- G5b：连 window 都没了（区域整块消失的更狠版本）----
    o, act = fresh_object("G5B", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    op = FakeDragOp()
    err = ""
    rets = []
    try:
        ctx = NoAreaCtx()
        rets.append(DRAG_MODAL(op, ctx, Ev('MOUSEMOVE', 'NOTHING', 400.0, 400.0, 400.0, 400.0)))
        rets.append(DRAG_MODAL(op, ctx, Ev('TIMER', 'NOTHING')))
        rets.append(DRAG_MODAL(op, ctx, Ev('RIGHTMOUSE', 'PRESS', 400.0, 400.0, 400.0, 400.0)))
        rets.append(DRAG_MODAL(op, ctx, Ev('BACK_SPACE', 'PRESS')))
        rets.append(DRAG_MODAL(op, ctx, Ev('ESC', 'PRESS')))
    except Exception:
        err = E.tb(600)
    step("G5b-1 ★★ area/window 全 None：拖拽模态不抛异常", not err, err[:500])
    step("G5b-2 area/window 全 None：返回值合法",
         bool(rets) and all(isinstance(r, set) for r in rets),
         "rets=%s" % [sorted(r) if isinstance(r, set) else r for r in rets])

    # ---- G5c：G/R/S 模态在 area=None 下 ----
    o, act = fresh_object("G5C", E.KEYS_3)
    select_frames(act, o, [90])
    sess = me.MoveSession('MOVE')
    err = ""
    if sess.begin(o, act, region, rv3d, 400.0, 400.0, bone_name=None):
        opx = FakeXF()
        opx._session = sess
        opx._numeric = me.NumericInput()
        opx._last_mouse = (400.0, 400.0)
        try:
            with bpy.context.temp_override(window=win, area=None, region=None,
                                           screen=win.screen):
                opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 430.0, 400.0, 430.0))
                opx.modal(bpy.context, Ev('X', 'PRESS'))
                opx.modal(bpy.context, Ev('ESC', 'PRESS'))
        except Exception:
            err = E.tb(600)
        step("G5c-1 ★★ G/R/S 模态在 area=None 下不抛异常", not err, err[:500])
        inv("G5c-2 不变量保持", act, o)
    else:
        step("G5c-0 G/R/S 会话建立失败", False, getattr(sess, "message", ""))
except Exception:
    step("G5 FATAL", False, E.tb(900))


# ===========================================================================
# G6 · 极快连续事件（节流）⇒ 数值有界 + 位移不丢
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True

    # ---- G6a：200 个零间隔 MOUSEMOVE（大部分会被节流吃掉）----
    o, act = fresh_object("G6A", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    t = tri_at(act, o, 90, 'up', region, rv3d)
    op = FakeDragOp()
    s0 = read_s(act, o, 90, 'left')
    TOTAL_DY = 0.0
    last_m = pend_m = (0.0, 0.0)
    eff_burst = eff_after = s_after = None
    err = ""
    try:
        with ctx_override(win, area, region):
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
            # 极快连续事件：交替大幅位移（**不按 Shift** —— 精度是逐事件状态，
            # 混进来会让"位移不丢"这条判据带上缩放歧义；Shift 单独在 G6b 覆盖）
            for i in range(200):
                dy = (-9.0 if (i % 2 == 0) else 8.0)
                TOTAL_DY += dy
                DRAG_MODAL(op, bpy.context,
                           Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] + TOTAL_DY,
                              t["lx"], t["ly"] + TOTAL_DY))
            eff_burst = float(st._session.speed_drag_effective_px)
            s_burst = read_s(act, o, 90, 'left')
            last_m = tuple(st._session.speed_drag_last_mouse or (0, 0))
            pend_m = tuple(st._session.speed_drag_pending_mouse or (0, 0))
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"],
                                           t["gy"] + TOTAL_DY, t["lx"], t["ly"] + TOTAL_DY))
            eff_after = float(st._session.speed_drag_effective_px)
            s_after = read_s(act, o, 90, 'left')
    except Exception:
        err = E.tb(700)
        eff_burst = eff_after = s_after = None
    step("G6a-1 ★★ 200 个极快连续事件：不抛异常", not err, err[:500])
    step("G6a-2 ★★ 200 事件后数值有界（s 落在 [S_EPS, S_HARD_MAX]，无 NaN）",
         s_after is not None and math.isfinite(s_after)
         and td.S_EPS - 1e-9 <= s_after <= td.S_HARD_MAX + 1e-9,
         "s: %s → %s（S_EPS=%.5f S_HARD_MAX=%.2f）" % (s0, s_after, td.S_EPS, td.S_HARD_MAX))
    step("G6a-3 ★★★ 位移不丢：松手时 pending 被 flush，净位移 = 累计鼠标位移 × DRAG_PX_SCALE",
         eff_after is not None and abs(eff_after - (TOTAL_DY * td.DRAG_PX_SCALE)) < 1e-6,
         "eff: 突发中=%s 松手后=%s | 期望=%.6f（总 dy=%.1f）"
         % (eff_burst, eff_after, TOTAL_DY * td.DRAG_PX_SCALE, TOTAL_DY))
    step("G6a-4 ★ 节流真的生效（突发中还没补完最后一段）",
         eff_burst is not None and abs(eff_burst - eff_after) > 1e-9,
         "突发中 eff=%s 松手后 eff=%s（相等说明节流没起作用 / 或恰好一次写完）"
         % (eff_burst, eff_after))
    step("G6a-5 拖拽中记录的两个鼠标位置都是有限数",
         all(math.isfinite(v) for v in last_m + pend_m),
         "last=%s pending=%s" % (last_m, pend_m))
    inv("G6a-6 不变量保持", act, o)

    # ---- G6b：交替 Shift 精度 + 巨幅位移（强制每次都写）----
    o, act = fresh_object("G6B", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    t = tri_at(act, o, 90, 'up', region, rv3d)
    op = FakeDragOp()
    err = ""
    try:
        with ctx_override(win, area, region):
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'PRESS', t["gx"], t["gy"],
                                           t["lx"], t["ly"]))
            for i in range(60):
                op._last_speed_draw_time = 0.0        # 强制每次都写（压满路径）
                DRAG_MODAL(op, bpy.context,
                           Ev('MOUSEMOVE', 'NOTHING', t["gx"], t["gy"] + (i + 1) * 40.0,
                              t["lx"], t["ly"] + (i + 1) * 40.0, shift=(i % 2 == 0)))
            DRAG_MODAL(op, bpy.context, Ev('LEFTMOUSE', 'RELEASE', t["gx"],
                                           t["gy"] + 2400.0, t["lx"], t["ly"] + 2400.0))
    except Exception:
        err = E.tb(700)
    step("G6b-1 ★★ 60 次巨幅 + Shift 交替：不抛异常", not err, err[:500])
    inv("G6b-2 ★★ 巨幅拖动后三轴 dt 仍一致、dt 不超段长", act, o)
    # ⚠️ 实测到的语义边界（**不是缺陷**，但值得记下来）：
    #    松手补写 'flush_pending_speed_drag' 用的精度系数是
    #    'speed_drag_precision' —— 即**最后一个非节流事件**的 Shift 状态，
    #    而不是"那几像素移动发生时"的状态。
    #    真实交互里被节流吃掉的位移 ≤ 1 帧（默认 16ms），肉眼不可见；
    #    本测试的 200 事件零间隔是**合成极端**，才会放大成可见差异。
    step("G6b-3 NOTE 松手补写按**最后一次** Shift 状态缩放（≤1 帧，真实交互不可见）",
         True, "合成极端下可放大：200 事件零间隔时整段 91px 都按最后一次的精度缩放")
except Exception:
    step("G6 FATAL", False, E.tb(900))


# ===========================================================================
# G7 · 双击判定窗口的内外边界
# ===========================================================================
try:
    it.clear_speed_click_chain()

    def dbl(frame, tri, xy, now, window=0.35, radius=22.0):
        return it.speed_double_click_hit(frame, tri, xy, now=now, window=window,
                                         radius=radius)

    first = dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    step("G7-1 首击不算双击", first is False, "hit=%s" % first)

    # ⚠️ 边界必须用**二进制可精确表示**的窗口值（0.5）——
    #    否则 '1000.35 - 1000.0 = 0.35000000000002274 > 0.35'，
    #    浮点噪声会伪装成判据 bug（第一版就踩了这个坑，是测试的问题不是产品的）。
    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0, window=0.5)
    hit_eq = dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.5, window=0.5)
    step("G7-2 ★ 时间边界：Δt **正好等于** 窗口 ⇒ 算双击（<= 语义）",
         hit_eq is True, "Δt=0.5 window=0.5 hit=%s" % hit_eq)

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0, window=0.5)
    hit_over = dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.5 + 1e-6, window=0.5)
    step("G7-3 ★ 时间边界：超出窗口 1μs ⇒ 不算双击",
         hit_over is False, "Δt=%.7f hit=%s" % (0.5 + 1e-6, hit_over))

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0, radius=22.0)
    hit_r = dbl(90.0, hd.TRI_UP, (122.0, 100.0), 1000.1, radius=22.0)
    step("G7-4 ★ 距离边界：**正好等于** 半径 ⇒ 算双击（<= 语义）",
         hit_r is True, "dx=22 radius=22 hit=%s" % hit_r)

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0, radius=22.0)
    hit_r2 = dbl(90.0, hd.TRI_UP, (122.001, 100.0), 1000.1, radius=22.0)
    step("G7-5 ★ 距离边界：超出半径 0.001px ⇒ 不算双击",
         hit_r2 is False, "dx=122.001 radius=22 hit=%s" % hit_r2)

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    hit_other = dbl(90.0, hd.TRI_DOWN, (100.0, 100.0), 1000.05)
    step("G7-6 ★ 同帧**另一个三角**不算双击", hit_other is False, "hit=%s" % hit_other)

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    hit_f = dbl(117.0, hd.TRI_UP, (100.0, 100.0), 1000.05)
    step("G7-7 ★ 不同关键帧不算双击", hit_f is False, "hit=%s" % hit_f)

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    h2 = dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.10)
    h3 = dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.20)
    step("G7-8 ★★ 三击：第二击=双击、**第三击不再算双击**（记录被消费）",
         h2 is True and h3 is False, "第2击=%s 第3击=%s" % (h2, h3))

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    it.clear_speed_click_chain()
    hc = dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.05)
    step("G7-9 ★ clear_speed_click_chain 断链后不算双击", hc is False, "hit=%s" % hc)

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    h_eps = dbl(90.0 + st.FRAME_EPS * 0.5, hd.TRI_UP, (100.0, 100.0), 1000.05)
    step("G7-10 子帧差 < FRAME_EPS 视为同帧（算双击）", h_eps is True,
         "Δframe=%.6f FRAME_EPS=%.4f hit=%s" % (st.FRAME_EPS * 0.5, st.FRAME_EPS, h_eps))

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    h_eps2 = dbl(90.0 + st.FRAME_EPS * 2.0, hd.TRI_UP, (100.0, 100.0), 1000.05)
    step("G7-11 子帧差 > FRAME_EPS 不算同帧", h_eps2 is False,
         "Δframe=%.6f hit=%s" % (st.FRAME_EPS * 2.0, h_eps2))

    it.clear_speed_click_chain()
    dbl(90.0, hd.TRI_UP, (100.0, 100.0), 1000.0)
    h_back = dbl(90.0, hd.TRI_UP, (100.0, 100.0), 999.0)
    step("G7-12 NOTE 时钟回退（now < 上次）也算双击 —— 单调时钟下不可达",
         True, "hit=%s（判据是 Δt <= window，负值天然通过；time.monotonic 不会回退）" % h_back)

    # 偏好窗口的钳制
    try:
        pref = bpy.context.preferences.inputs
        orig_ms = pref.mouse_double_click_time
        res = {}
        for ms in (0, 5, 350, 100000):
            pref.mouse_double_click_time = ms
            res[ms] = round(it._speed_dblclick_window(bpy.context), 6)
        pref.mouse_double_click_time = orig_ms
        step("G7-13 ★ 双击窗口取自偏好并钳在 [0.05, 1.0]s",
             res[0] == 0.05 and res[5] == 0.05 and abs(res[350] - 0.35) < 1e-6
             and res[100000] == 1.0,
             "ms→s: %s（偏好默认 %s ms）" % (res, orig_ms))
    except Exception:
        step("G7-13 偏好不可写（跳过）", True, E.tb(300))

    # 注入式参数真的覆盖偏好（证明测试不依赖真实等待）
    try:
        pref = bpy.context.preferences.inputs
        orig_ms = pref.mouse_double_click_time
        pref.mouse_double_click_time = 100000          # 偏好给 1.0s
        it.clear_speed_click_chain()
        it.speed_double_click_hit(90.0, hd.TRI_UP, (100.0, 100.0), now=0.0, window=0.1)
        h_inj = it.speed_double_click_hit(90.0, hd.TRI_UP, (100.0, 100.0), now=0.5, window=0.1)
        pref.mouse_double_click_time = orig_ms
        step("G7-14 ★ window 参数注入能覆盖偏好（headless 不必真等时间）",
             h_inj is False, "偏好 1.0s 但注入 window=0.1 ⇒ Δt=0.5 应判 False，实际 %s" % h_inj)
    except Exception:
        step("G7-14 注入参数测试失败", False, E.tb(400))
    it.clear_speed_click_chain()
except Exception:
    step("G7 FATAL", False, E.tb(900))


# ===========================================================================
# G8 · G/R/S × 数字输入 × 轴约束 × Shift 精度 的组合矩阵
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    MODES = (('MOVE', me.MoveSession), ('ROTATE', me.RotateSession),
             ('SCALE', me.ScaleSession))
    LOCKS = (('none', None, None), ('axisX', 'X', None), ('axisY', 'Y', None),
             ('axisZ', 'Z', None), ('planeYZ', None, ('Y', 'Z')),
             ('planeXZ', None, ('X', 'Z')))

    n_ok = n_bad = 0
    bad_names = []
    for mname, cls in MODES:
        for lname, ax, pl in LOCKS:
            for prec in (False, True):
                label = "G8 %s lock=%s prec=%d" % (mname, lname, int(prec))
                try:
                    o, act = fresh_object("G8_%s_%s_%d" % (mname, lname, int(prec)), E.KEYS_3)
                    select_frames(act, o, [90])
                    sess = cls(mname)
                    if not sess.begin(o, act, region, rv3d, 400.0, 400.0, bone_name=None):
                        step(label + " → 会话建立失败", False,
                             getattr(sess, "message", ""))
                        n_bad += 1
                        bad_names.append(label + "(begin)")
                        continue
                    opx = FakeXF()
                    opx._session = sess
                    opx._numeric = me.NumericInput()
                    opx._last_mouse = (400.0, 400.0)
                    excl = sorted({'X', 'Y', 'Z'} - set(pl))[0] if pl is not None else None
                    # 期望值**按模式**不同 —— 这是产品自己写下来的语义，不是我在猜：
                    #   MOVE          : 锁平面 ⇒ axis_lock=None, plane_lock=另两轴
                    #   ROTATE/SCALE  : 锁平面 = **绕该轴** ⇒ axis_lock=<被排除的轴>，
                    #                   plane_lock 同时记另两轴
                    #                   （modal_edit.RotateSession.set_plane，ScaleSession 继承）
                    exp_ax = ((None if mname == 'MOVE' else excl)
                              if pl is not None else ax)
                    exp_pl = pl
                    with ctx_override(win, area, region):
                        if ax is not None:
                            opx.modal(bpy.context, Ev(ax, 'PRESS'))
                        if pl is not None:
                            opx.modal(bpy.context, Ev(excl, 'PRESS', shift=True))
                        if prec:
                            opx.modal(bpy.context, Ev('LEFT_SHIFT', 'PRESS'))
                        # ⚠️ Shift 是**逐事件**读的：'modal()' 的 MOUSEMOVE 分支里
                        #    又调了一次 's.set_precision(event.shift)' ⇒
                        #    移动事件本身必须带 shift，否则刚设的精度立刻被清掉
                        #    （第一版没带 ⇒ MOVE 的 prec=1 组合全假失败）。
                        opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 360.0,
                                                  400.0, 360.0, shift=prec))
                    got_ax = getattr(sess, "axis_lock", None)
                    got_pl = getattr(sess, "plane_lock", None)
                    got_prec = bool(getattr(sess, "precision", False))
                    off = getattr(sess, "offset", None)
                    probs = []
                    if got_ax != exp_ax:
                        probs.append("axis_lock=%r 期望 %r" % (got_ax, exp_ax))
                    if tuple(got_pl or ()) != tuple(exp_pl or ()):
                        probs.append("plane_lock=%r 期望 %r" % (got_pl, exp_pl))
                    if got_prec != prec:
                        probs.append("precision=%r 期望 %r" % (got_prec, prec))
                    if off is None:
                        _mag = session_mag(sess)
                        if _mag is None or not math.isfinite(_mag):
                            probs.append("%s 的读数取不到/非有限 (%r)" % (mname, _mag))
                    elif not all(math.isfinite(float(v)) for v in (off.x, off.y, off.z)):
                        probs.append("offset 非有限 (%r,%r,%r)" % (off.x, off.y, off.z))
                    # 轴约束必须真的把另两轴压成 0（世界口径）
                    if mname == 'MOVE':
                        if ax == 'X' and (abs(off.y) > 1e-9 or abs(off.z) > 1e-9):
                            probs.append("X 轴锁未生效 offset=(%r,%r,%r)" % (off.x, off.y, off.z))
                        if ax == 'Y' and (abs(off.x) > 1e-9 or abs(off.z) > 1e-9):
                            probs.append("Y 轴锁未生效 offset=(%r,%r,%r)" % (off.x, off.y, off.z))
                        if ax == 'Z' and (abs(off.x) > 1e-9 or abs(off.y) > 1e-9):
                            probs.append("Z 轴锁未生效 offset=(%r,%r,%r)" % (off.x, off.y, off.z))
                        if pl == ('Y', 'Z') and abs(off.x) > 1e-9:
                            probs.append("YZ 平面锁未生效 offset.x=%r" % off.x)
                        if pl == ('X', 'Z') and abs(off.y) > 1e-9:
                            probs.append("XZ 平面锁未生效 offset.y=%r" % off.y)
                    bad = inv(label + " · 不变量", act, o)
                    if bad:
                        probs.extend(bad)
                    if probs:
                        step(label + " → FAIL", False, "; ".join(probs)[:400])
                        n_bad += 1
                        bad_names.append(label)
                    else:
                        n_ok += 1
                    sess.cancel()
                except Exception:
                    step(label + " → FATAL", False, E.tb(400))
                    n_bad += 1
                    bad_names.append(label + "(fatal)")
    step("G8 矩阵汇总：3 模式 × 6 约束 × 2 精度 = 36 组合",
         n_bad == 0, "通过 %d / 失败 %d%s" % (n_ok, n_bad,
                                            ("；失败项=" + ", ".join(bad_names[:6])) if bad_names else ""))

    # ---- G8num：数字输入沿锁定轴精确应用 ----
    n_ok2 = n_bad2 = 0
    bad2 = []
    for mname, cls in MODES:
        for lname, ax, pl in (('none', None, None), ('axisX', 'X', None),
                              ('axisY', 'Y', None), ('axisZ', 'Z', None)):
            label = "G8num %s lock=%s 输入2.0" % (mname, lname)
            try:
                o, act = fresh_object("G8N_%s_%s" % (mname, lname), E.KEYS_3)
                select_frames(act, o, [90])
                before = co_snapshot(act, o)
                handles_before = E.handles_snapshot(act, o)
                sess = cls(mname)
                if not sess.begin(o, act, region, rv3d, 400.0, 400.0, bone_name=None):
                    step(label + " → 会话建立失败", False, getattr(sess, "message", ""))
                    n_bad2 += 1
                    bad2.append(label)
                    continue
                opx = FakeXF()
                opx._session = sess
                opx._numeric = me.NumericInput()
                opx._last_mouse = (400.0, 400.0)
                with ctx_override(win, area, region):
                    if ax is not None:
                        opx.modal(bpy.context, Ev(ax, 'PRESS'))
                    opx.modal(bpy.context, Ev('TWO', 'PRESS'))      # 敲 "2"
                after = co_snapshot(act, o)
                handles_after = E.handles_snapshot(act, o)
                probs = []
                if getattr(sess, "numeric", "") != "2":
                    probs.append("数字缓冲=%r 期望 '2'" % getattr(sess, "numeric", ""))
                if not opx._numeric.active:
                    probs.append("NumericInput 未激活")
                # 数字输入期间鼠标移动不得改数值（与原生一致）
                mag_before = session_mag(sess)
                with ctx_override(win, area, region):
                    opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 500.0, 300.0,
                                              500.0, 300.0))
                mag_after = session_mag(sess)
                if mag_before is None or mag_after is None:
                    probs.append("会话读数取不到（%r / %r）" % (mag_before, mag_after))
                elif abs(mag_after - mag_before) > 1e-9:
                    probs.append("数字输入中鼠标移动改了数值（%.6f → %.6f）"
                                 % (mag_before, mag_after))
                if mname == 'MOVE':
                    axis_i = {'X': 0, 'Y': 1, 'Z': 2, None: 0}[ax]
                    fr90 = round(90.0, 4)
                    d = {}
                    for ai in range(3):
                        k = (ai, fr90)
                        if k in after and k in before:
                            d[ai] = after[k][1] - before[k][1]
                    if abs(d.get(axis_i, 0.0) - 2.0) > 1e-4:
                        probs.append("锁定轴位移=%.6f 期望 2.0" % d.get(axis_i, 0.0))
                    for other in range(3):
                        if other != axis_i and abs(d.get(other, 0.0)) > 1e-6:
                            probs.append("非锁定轴 %d 也被移动了 %.6f" % (other, d.get(other, 0.0)))
                else:
                    # ⚠️ R / S 的"位移"**不能看关键帧 co**：只选中 1 个点时，
                    #    支点就是它自己（R 原地转 / S 原地缩），co 本来就不动，
                    #    真正变的是**手柄**。所以按各自的真值 + 手柄变化来判。
                    co_moved = any(abs(after[k][1] - before[k][1]) > 1e-12
                                   for k in after if k in before)
                    hd_moved = (handles_after != handles_before)
                    if (not co_moved) and (not hd_moved):
                        probs.append("数字输入既没改关键帧也没改手柄（空操作）")
                    if mname == 'ROTATE':
                        ang = abs(math.degrees(float(getattr(sess, "angle", 0.0))))
                        if abs(ang - 2.0) > 1e-4:
                            probs.append("旋转角=%.6f° 期望 2.0°" % ang)
                    elif mname == 'SCALE':
                        fac = float(getattr(sess, "factor", 0.0))
                        if abs(fac - 2.0) > 1e-6:
                            probs.append("缩放比例=%.6f 期望 2.0" % fac)
                bad = inv(label + " · 不变量", act, o)
                if bad:
                    probs.extend(bad)
                if probs:
                    step(label + " → FAIL", False, "; ".join(probs)[:400])
                    n_bad2 += 1
                    bad2.append(label)
                else:
                    n_ok2 += 1
                sess.cancel()
            except Exception:
                step(label + " → FATAL", False, E.tb(400))
                n_bad2 += 1
                bad2.append(label + "(fatal)")
    step("G8num 数字输入矩阵汇总：3 模式 × 4 约束 = 12 组合",
         n_bad2 == 0, "通过 %d / 失败 %d%s" % (n_ok2, n_bad2,
                                             ("；失败项=" + ", ".join(bad2[:6])) if bad2 else ""))

    # ---- G8-BS：Backspace 两段行为（模态里走真实路由）----
    o, act = fresh_object("G8_BS", E.KEYS_3)
    select_frames(act, o, [90])
    sess = me.MoveSession('MOVE')
    sess.begin(o, act, region, rv3d, 400.0, 400.0, bone_name=None)
    opx = FakeXF()
    opx._session = sess
    opx._numeric = me.NumericInput()
    opx._last_mouse = (400.0, 400.0)
    with ctx_override(win, area, region):
        opx.modal(bpy.context, Ev('X', 'PRESS'))
        opx.modal(bpy.context, Ev('TWO', 'PRESS'))
        off_2 = sess.offset.copy()
        opx.modal(bpy.context, Ev('BACK_SPACE', 'PRESS'))       # 删字符 → 缓冲空
        off_del = sess.offset.copy()
        opx.modal(bpy.context, Ev('BACK_SPACE', 'PRESS'))       # 第 1 段：重置到初始
        off_reset = sess.offset.copy()
        opx.modal(bpy.context, Ev('BACK_SPACE', 'PRESS'))       # 第 2 段：退出数字编辑
        buf_after = str(getattr(sess, "numeric", ""))
    step("G8-BS1 ★ Backspace 删字符：缓冲清空但值还在", off_del.length > 0.0,
         "输入 2 后 |offset|=%.4f，删字符后 |offset|=%.4f" % (off_2.length, off_del.length))
    step("G8-BS2 ★★ Backspace 第 1 段：重置到初始值（offset 归零）",
         off_reset.length < 1e-9, "重置后 |offset|=%.2e" % off_reset.length)
    step("G8-BS3 ★★ Backspace 第 2 段：退出数字编辑（缓冲清空）",
         buf_after == "", "numeric=%r" % buf_after)
    inv("G8-BS4 不变量保持", act, o)
    sess.cancel()
except Exception:
    step("G8 FATAL", False, E.tb(900))


# ===========================================================================
# G9 · ESC / 右键取消后逐位精确还原
# ===========================================================================
try:
    win, area, region, rv3d = view3d()

    def cancel_roundtrip(label, cls, mname, cancel_ev):
        o, act = fresh_object("G9_" + label, E.KEYS_3)
        select_frames(act, o, [90])
        snap0 = snapshot_all(act, o)
        sess = cls(mname)
        if not sess.begin(o, act, region, rv3d, 400.0, 400.0, bone_name=None):
            step(label + " → 会话建立失败", False, getattr(sess, "message", ""))
            return
        opx = FakeXF()
        opx._session = sess
        opx._numeric = me.NumericInput()
        opx._last_mouse = (400.0, 400.0)
        with ctx_override(win, area, region):
            opx.modal(bpy.context, Ev('X', 'PRESS'))
            opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 300.0, 400.0, 300.0))
            opx.modal(bpy.context, Ev('TWO', 'PRESS'))
            opx.modal(bpy.context, Ev(cancel_ev, 'PRESS'))
        snap1 = snapshot_all(act, o)
        d = snap_diff(snap0, snap1)
        step("%s ★★ 取消后**逐位精确还原**（co + 手柄 + 类型）" % label, not d, d[:400])
        step("%s 取消后状态 = DONE" % label, sess.state == me.STATE_DONE,
             "state=%s" % sess.state)
        inv("%s 不变量保持" % label, act, o)

    cancel_roundtrip("G9-MOVE-ESC", me.MoveSession, 'MOVE', 'ESC')
    cancel_roundtrip("G9-MOVE-RMB", me.MoveSession, 'MOVE', 'RIGHTMOUSE')
    cancel_roundtrip("G9-ROTATE-ESC", me.RotateSession, 'ROTATE', 'ESC')
    cancel_roundtrip("G9-ROTATE-RMB", me.RotateSession, 'ROTATE', 'RIGHTMOUSE')
    cancel_roundtrip("G9-SCALE-ESC", me.ScaleSession, 'SCALE', 'ESC')
    cancel_roundtrip("G9-SCALE-RMB", me.ScaleSession, 'SCALE', 'RIGHTMOUSE')

    # ---- G9-SPEED：疏密模态取消 ----
    o, act = fresh_object("G9_SPEED", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    snap0 = snapshot_all(act, o)
    sess = me.ModalSession('SPEED')
    t = tri_at(act, o, 90, 'up', region, rv3d)
    # ⚠️ 'begin()' 要的是一个**目标 dict**（frame / side / kf_map / span），
    #    而 'resolve_speed_target' 依赖真实屏幕投影（headless 默认视图里关键帧
    #    可能落在视口外 ⇒ 报 "No keyframe near the cursor"）。
    #    ⇒ 直接用 'td.resolve_target' 给出目标，绕开投影（其余逻辑一字未改）。
    def _speed_resolver(mx, my):
        kfm, span = td.resolve_target(act, o, 90.0, 'left')
        if not kfm or span is None:
            return None
        return {"frame": 90.0, "side": 'left', "kf_map": kfm, "span": span,
                "world": None, "screen_x": mx, "screen_y": my, "dist": 0.0}

    if t is None:
        step("G9-SPEED 找不到 90 帧上三角", False, "%r" % (_TRI_DIAG,))
    elif sess.begin(o, act, t["lx"], t["ly"], _speed_resolver):
        s_before_drag = read_s(act, o, 90, 'left')
        sess.update(t["lx"], t["ly"] + 40.0)
        moved = read_s(act, o, 90, 'left')
        sess.cancel()
        snap1 = snapshot_all(act, o)
        step("G9-SPEED 拖动中确实改过值（否则测的是空操作）",
             moved is not None and abs(moved - (s_before_drag or 0)) > 1e-9,
             "s: %s → %s" % (s_before_drag, moved))
        # ① 坐标必须逐位还原
        coord_diff = snap_diff((snap0[0], snap0[1], {}), (snap1[0], snap1[1], {}))
        step("G9-SPEED-a ★★ 取消后**关键帧 co + 手柄坐标**逐位还原", not coord_diff,
             coord_diff[:400])
        # ② 目标帧（90）那一侧的手柄类型必须还原
        tgt_bad = [k for k in snap0[2]
                   if abs(k[1] - 90.0) < 1e-6 and snap0[2][k] != snap1[2].get(k)]
        step("G9-SPEED-b ★ 取消后**目标帧**的手柄类型还原", not tgt_bad,
             "目标帧类型差异=%s" % tgt_bad[:4])
        # ③ 段【另一端】（帧 0）那一侧 —— 实测留在 FREE
        nbr_bad = [(k, snap0[2][k], snap1[2].get(k)) for k in snap0[2]
                   if abs(k[1] - 90.0) >= 1e-6 and snap0[2][k] != snap1[2].get(k)]
        _froz = []
        for _f in (0.0, 90.0):
            try:
                if td.is_frozen(act, _f):
                    _froz.append(_f)
            except Exception:
                pass
        step("G9-SPEED-c ★★ 取消后**相邻帧另一侧**的手柄类型**静默**留在 FREE（未提示、未还原）",
             not nbr_bad,
             ("★ 相邻帧类型差异：%s；取消后 rtmp_frozen 记录帧=%s。"
              "机理：'ModalSession.restore()' 的快照只覆盖 target 的 kf_map，"
              "而 'write_s(freeze=True)' 会把**段两端**都冻成 FREE ⇒ "
              "另一端只冻不还原（同段的帧 90 那侧是正确还原的，见上一条）。"
              % (nbr_bad[:4], _froz)) if nbr_bad
             else "相邻帧类型未被改动")
    else:
        step("G9-SPEED 会话建立失败", False, getattr(sess, "message", ""))
    inv("G9-SPEED 不变量保持", act, o)

    # ---- G9-DRAG：拖拽模态被外部取消（关掉编辑模式）----
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    o, act = fresh_object("G9_DRAG", E.KEYS_3)
    bpy.context.scene.frame_set(90)
    op = FakeDragOp()
    with ctx_override(win, area, region):
        DRAG_MODAL(op, bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 400.0, 400.0, 400.0))
    wm.rtmp_edit_mode_active = False
    err = ""
    ret = None
    try:
        with ctx_override(win, area, region):
            ret = DRAG_MODAL(op, bpy.context,
                             Ev('MOUSEMOVE', 'NOTHING', 420.0, 400.0, 420.0, 400.0))
    except Exception:
        err = E.tb(400)
    wm.rtmp_edit_mode_active = True
    step("G9-DRAG-1 ★★ 编辑模式关闭时 modal 走 cancel 分支且不抛异常",
         (not err) and ret == {'CANCELLED'},
         "err=%s ret=%s" % (err[:200], ret))
    step("G9-DRAG-2 ★★ cancel 后会话被重置（无残留拖拽标志）",
         (not st._session.drag_in_progress) and (not st._session.handle_edit_in_progress)
         and (not st._session.speed_drag_active),
         "drag=%s handle=%s speed=%s" % (st._session.drag_in_progress,
                                         st._session.handle_edit_in_progress,
                                         st._session.speed_drag_active))
    inv("G9-DRAG-3 不变量保持", act, o)
except Exception:
    step("G9 FATAL", False, E.tb(900))


# ===========================================================================
# G10 · 反复开关插件 20 次 ⇒ 绘制回调无泄漏
# ===========================================================================
try:
    HANDLE_SLOTS = ("_h_view", "_h_pixel", "render_callback_id")

    def live_handles():
        n = 0
        for obj in gc.get_objects():
            try:
                if not str(getattr(type(obj), "__module__", "")).startswith("RealTimeMotionPath"):
                    continue
                for slot in HANDLE_SLOTS:
                    if getattr(obj, slot, None) is not None:
                        n += 1
            except Exception:
                continue
        return n

    HANDLER_LISTS = ("depsgraph_update_post", "undo_post", "redo_post", "load_post",
                     "frame_change_post", "save_pre", "save_post")

    def app_handler_counts():
        out = {}
        for nm in HANDLER_LISTS:
            lst = getattr(bpy.app.handlers, nm, None) or []
            out[nm] = sum(1 for h in lst
                          if str(getattr(h, "__module__", "")).startswith("RealTimeMotionPath"))
        return out

    def wm_ok():
        return hasattr(bpy.context.window_manager, "rtmp_edit_mode_active")

    base_h = live_handles()
    base_a = app_handler_counts()
    step("G10-0 起点：记录基线（句柄数 / app handler 数）",
         True, "句柄=%d app=%s" % (base_h, {k: v for k, v in base_a.items() if v}))

    growth = []
    errors = []
    for i in range(20):
        try:
            RTMP.unregister()
            RTMP.register()
        except Exception:
            errors.append("第 %d 次: %s" % (i + 1, E.tb(300)))
            break
        h = live_handles()
        a = app_handler_counts()
        if h > base_h or any(a[k] > base_a[k] for k in HANDLER_LISTS):
            growth.append((i + 1, h, {k: v for k, v in a.items() if v > base_a[k]}))
    step("G10-1 ★★★ 20 次 unregister/register 全程不抛异常",
         not errors, errors[0][:400] if errors else "ok")
    step("G10-2 ★★★ 绘制回调**零泄漏**（每次开关后存活句柄数不超基线）",
         not growth, "基线=%d；越界记录=%s" % (base_h, growth[:4]))
    final_a = app_handler_counts()
    step("G10-3 ★★★ app handler **零堆积**",
         all(final_a[k] <= base_a[k] for k in HANDLER_LISTS),
         "基线=%s 终态=%s" % ({k: v for k, v in base_a.items() if v},
                              {k: v for k, v in final_a.items() if v}))
    step("G10-4 开关 20 次后插件仍是可用状态（wm 属性回来、addon 仍启用）",
         wm_ok() and 'RealTimeMotionPath' in bpy.context.preferences.addons,
         "wm.rtmp_edit_mode_active 存在=%s" % wm_ok())

    rm, fa = dw.purge_stale_draw_handlers(keep_session=st._session)
    rm2, _fa2 = dw.purge_stale_draw_handlers(keep_session=st._session)
    step("G10-5 兜底 purge 幂等（第 2 次无可清）", len(rm2) == 0,
         "第1次 removed=%d failed=%d；第2次 removed=%d" % (len(rm), len(fa), len(rm2)))
except Exception:
    step("G10 FATAL", False, E.tb(900))


# ===========================================================================
# H1 · 一锅端：骨骼 + 多对象 + 共享 action + 子帧关键帧 + 退化手柄 + 四表记录
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    E.clear_scene()

    # ---- 1) 骨骼（带位移动画）----
    arm, aact = E.build_object("H1_ARM", E.KEYS_3, bone=True)
    bone_name = arm.pose.bones[0].name

    # ---- 2) 网格对象 A：带子帧关键帧（45.5）----
    oA, actA = E.build_object("H1_A", E.KEYS_3)
    bpy.context.scene.frame_set(45)
    oA.location = (0.5, 1.3, 0.2)
    oA.keyframe_insert("location", frame=45.5)          # 子帧关键帧
    actA.name = "H1_SHARED_ACT"
    bpy.context.scene.frame_set(90)

    # ---- 3) 网格对象 B：**共享同一个 action** ----
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    oB = bpy.context.view_layer.objects.active
    oB.name = "H1_B"
    oB.animation_data_create()
    oB.animation_data.action = actA
    try:
        if getattr(actA, "slots", None) and len(actA.slots):
            oB.animation_data.action_slot = actA.slots[0]
    except Exception:
        pass

    # ---- 4) 退化手柄：|dv| = 0（手柄值与关键帧值重合）----
    E.set_handles(oA, 45.5, 'right', dt=12.0, dv=0.0)
    E.set_handles(oA, 45.5, 'left', dt=12.0, dv=0.0)

    # ---- 5) 四张内存表都留下记录 ----
    xf.mark_feel_at(actA, 90, 'left', 'FREE')
    xf.set_tri_locked(actA, 90, False)
    td.mark_frozen(actA, 90)
    try:
        kfm90, span90 = td.resolve_target(actA, oA, 90, 'left')
        if kfm90:
            xf.mark_owned_free(next(iter(kfm90.values())), 'left')
    except Exception:
        pass

    tbl = {}
    for prop, cache in ((xf._FEEL_PROP, xf._FEEL), (xf._TRILOCK_PROP, xf._TRILOCK),
                        (xf._OWNED_PROP, xf._plugin_owned_free), (td._FROZEN_PROP, td._FROZEN)):
        try:
            tbl[prop] = (bool(actA.get(prop)), any(k[0] == str(actA.name) for k in cache))
        except Exception:
            tbl[prop] = ("ERR", "ERR")
    step("H1-1 ★ 四张内存表都留下记录（property 存在 且 内存表有条目）",
         all(v[0] and v[1] for v in tbl.values()), "四表=%s" % tbl)
    step("H1-2 子帧关键帧（45.5）确实建出来了",
         any(abs(float(kp.co[0]) - 45.5) < 1e-6
             for fc in xf._position_curves(actA, oA, None) for kp in fc.keyframe_points),
         "帧号集合=%s" % sorted({round(float(kp.co[0]), 2)
                                for fc in xf._position_curves(actA, oA, None)
                                for kp in fc.keyframe_points}))
    step("H1-3 NOTE 子帧关键帧是已知设计边界（插件按 FRAME_EPS=1e-3 判同帧，支持但无专门 UI）",
         True, "45.5 与 45/46 的差都 > FRAME_EPS ⇒ 被当作独立帧；不做取整，行为自洽")
    step("H1-4 对象 B 与 A **共享同一个 action**",
         bool(oB.animation_data) and oB.animation_data.action == actA,
         "B.action=%s A.action=%s" % (oB.animation_data and oB.animation_data.action, actA))
    inv("H1-5 起始不变量（共享 action 视角 A）", actA, oA)
    inv("H1-6 起始不变量（共享 action 视角 B）", actA, oB)
    inv("H1-7 起始不变量（骨骼）", aact, arm, bone_name)

    # ---- 操作①：显示路径（刷新位置缓存）----
    err = ""
    try:
        ca.refresh_position_store(bpy.context)
    except Exception:
        err = E.tb(400)
    step("H1-8 ① 显示路径（refresh_position_store）不抛异常", not err, err[:400])
    inv("H1-9 ① 之后不变量", actA, oA)
    inv_frozen("H1-10 ① 之后第 4 张表一致", actA)

    # ---- 操作②：校正（检测 + 应用修复）----
    err = ""
    det = {}
    fix = {}
    try:
        det = sc.detect(actA, oA)
        fix, _snap = sc.apply_fix(actA, oA, det)
    except Exception:
        err = E.tb(700)
    step("H1-11 ② 校正（detect + apply_fix）不抛异常", not err, err[:500])
    applied_bad = [k for k, v in (fix.get("applied") or {}).items() if v == -1]
    step("H1-12 ★★ 校正各阶段无异常（applied[kind] 无 -1）", not applied_bad,
         "applied=%s frozen=%s 检出问题=%d 复检剩余=%d"
         % (fix.get("applied"), fix.get("frozen"), len(det.get("issues") or []),
            len((fix.get("after") or {}).get("issues") or [])))
    inv("H1-13 ② 校正后不变量", actA, oA)
    inv("H1-14 ② 校正后不变量（共享 action 的另一对象）", actA, oB)
    inv_frozen("H1-15 ② 校正后第 4 张表", actA)

    # ---- 操作③：调速（写 s）----
    err = ""
    try:
        for fr, side in ((90.0, 'left'), (90.0, 'right'), (45.5, 'right')):
            kfm, span = td.resolve_target(actA, oA, fr, side)
            if kfm and span:
                td.write_s(kfm, side, 0.6, span, freeze=True, act=actA, obj=oA)
        for fc in xf._position_curves(actA, oA, None):
            fc.update()
    except Exception:
        err = E.tb(600)
    step("H1-16 ③ 调速（td.write_s × 3，含子帧 45.5 与退化手柄帧）不抛异常",
         not err, err[:500])
    inv("H1-17 ③ 调速后不变量", actA, oA)
    inv_frozen("H1-18 ③ 调速后第 4 张表", actA)

    # ---- 操作④：双击锁定 ----
    err = ""
    locked_msg = ""
    try:
        t90 = tri_at(actA, oA, 90, 'up', region, rv3d)
        if t90 is None:
            err = "找不到 90 帧的上三角"
        else:
            ok4, msg4 = it.toggle_frame_lock(bpy.context, oA, 90.0, t90["all"],
                                             (t90["lx"], t90["ly"]), region, rv3d)
            locked_msg = "%s / %s" % (ok4, msg4)
    except Exception:
        err = E.tb(600)
    step("H1-19 ④ 双击锁定（toggle_frame_lock）不抛异常", not err, err[:500])
    step("H1-20 双击锁定返回可解释（ok/msg）", bool(locked_msg), "返回=%s" % locked_msg)
    inv("H1-21 ④ 锁定后不变量", actA, oA)
    inv_frozen("H1-22 ④ 锁定后第 4 张表", actA)

    # ---- 操作⑤：拖端点（端点模式 G/R/S）----
    err = ""
    moved = restored = ""
    try:
        st._session.selected_handle_endpoints = [(90.0, 'left')]
        select_frames(actA, oA, [90])
        snap_before = snapshot_all(actA, oA)
        sess = me.MoveSession('MOVE')
        ok5 = sess.begin(oA, actA, region, rv3d, 400.0, 400.0, bone_name=None)
        if not ok5:
            err = "端点会话建立失败: %s" % getattr(sess, "message", "")
        else:
            opx = FakeXF()
            opx._session = sess
            opx._numeric = me.NumericInput()
            opx._last_mouse = (400.0, 400.0)
            with ctx_override(win, area, region):
                opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 340.0,
                                          400.0, 340.0))
            moved = snap_diff(snap_before, snapshot_all(actA, oA))
            sess.cancel()
            restored = snap_diff(snap_before, snapshot_all(actA, oA))
    except Exception:
        err = E.tb(700)
        moved = restored = "(异常)"
    finally:
        st._session.selected_handle_endpoints = []
    step("H1-23 ⑤ 拖端点（端点模式）不抛异常", not err, err[:500])
    step("H1-24 ★ 端点变换真的动了手柄（否则测的是空操作）",
         bool(moved) and moved != "(异常)", str(moved)[:300])
    step("H1-25 ★★ 端点变换取消后逐位还原", not restored, str(restored)[:300])
    inv("H1-26 ⑤ 端点变换后不变量", actA, oA)
    inv("H1-27 ⑤ 端点变换后不变量（骨骼）", aact, arm, bone_name)
    inv_frozen("H1-28 ⑤ 之后第 4 张表", actA)
except Exception:
    step("H1 FATAL", False, E.tb(1200))


# ===========================================================================
# H2 · 全流程串：显示路径 → 校正 → 调速 → 双击锁定 → 端点变换 → undo
#        → 存盘重开 → 再校正 → 再检测
# ===========================================================================
try:
    win, area, region, rv3d = view3d()
    wm = bpy.context.window_manager
    wm.rtmp_edit_mode_active = True
    E.clear_scene()

    o, act = E.build_object("H2_OBJ", E.KEYS_5)
    act.name = "H2Act"
    bpy.context.scene.frame_set(90)
    o.location = (0.3, 0.7, 0.1)
    o.keyframe_insert("location", frame=45.5)           # 子帧关键帧一起带上
    bpy.context.scene.frame_set(90)
    E.set_handles(o, 45.5, 'right', dt=9.0, dv=0.0)     # 退化手柄

    chain = []

    def rec(name, err):
        chain.append((name, not err, err[:260]))

    # ① 显示路径
    e = ""
    try:
        ca.refresh_position_store(bpy.context)
    except Exception:
        e = E.tb(400)
    rec("H2-1 ① 显示路径", e)
    inv("H2-2 ① 之后不变量", act, o)

    # ② 校正
    e = ""
    fix = {}
    try:
        det = sc.detect(act, o)
        fix, _s = sc.apply_fix(act, o, det)
    except Exception:
        e = E.tb(700)
    rec("H2-3 ② 校正", e)
    step("H2-4 ★★ 校正无阶段异常",
         not [k for k, v in (fix.get("applied") or {}).items() if v == -1],
         "applied=%s frozen=%s" % (fix.get("applied"), fix.get("frozen")))
    inv("H2-5 ② 之后不变量", act, o)

    # ③ 三角调速
    e = ""
    try:
        kfm, span = td.resolve_target(act, o, 90, 'left')
        td.write_s(kfm, 'left', 0.5, span, freeze=True, act=act, obj=o)
        for fc in xf._position_curves(act, o, None):
            fc.update()
    except Exception:
        e = E.tb(600)
    rec("H2-6 ③ 三角调速", e)
    inv("H2-7 ③ 之后不变量", act, o)

    # ④ 双击锁定
    e = ""
    lock_msg = ""
    try:
        t = tri_at(act, o, 90, 'up', region, rv3d)
        if t is None:
            e = "找不到 90 帧上三角"
        else:
            ok4, lock_msg = it.toggle_frame_lock(bpy.context, o, 90.0, t["all"],
                                                 (t["lx"], t["ly"]), region, rv3d)
    except Exception:
        e = E.tb(600)
    rec("H2-8 ④ 双击锁定", e)
    step("H2-9 双击锁定返回可解释（ok/msg）", bool(lock_msg), "返回=%s" % lock_msg)
    inv("H2-10 ④ 之后不变量", act, o)

    # ⑤ 端点变换（端点模式，取消还原）
    e = ""
    moved = restored = ""
    try:
        st._session.selected_handle_endpoints = [(90.0, 'right')]
        select_frames(act, o, [90])
        s0 = snapshot_all(act, o)
        sess = me.MoveSession('MOVE')
        if not sess.begin(o, act, region, rv3d, 400.0, 400.0, bone_name=None):
            e = "端点会话建立失败: %s" % getattr(sess, "message", "")
        else:
            opx = FakeXF()
            opx._session = sess
            opx._numeric = me.NumericInput()
            opx._last_mouse = (400.0, 400.0)
            with ctx_override(win, area, region):
                opx.modal(bpy.context, Ev('MOUSEMOVE', 'NOTHING', 400.0, 340.0, 400.0, 340.0))
            moved = snap_diff(s0, snapshot_all(act, o))
            sess.cancel()
            restored = snap_diff(s0, snapshot_all(act, o))
    except Exception:
        e = E.tb(700)
    finally:
        st._session.selected_handle_endpoints = []
    rec("H2-11 ⑤ 端点变换", e)
    step("H2-12 ★ 端点变换确实改了手柄", bool(moved), str(moved)[:260])
    step("H2-13 ★★ 端点变换取消后逐位还原", not restored, str(restored)[:260])
    inv("H2-14 ⑤ 之后不变量", act, o)

    # ⑥ undo（headless 真 undo 不可用 ⇒ 走插件自己的 undo 响应 + 状态可解释）
    e = ""
    try:
        bpy.ops.ed.undo_push(message="H2")
    except Exception:
        e = E.tb(300)
    try:
        ug._on_undo_post(bpy.context.scene)
    except Exception:
        e = e or E.tb(400)
    rec("H2-15 ⑥ undo_push + 插件 undo 响应", e)
    step("H2-16 NOTE headless 下 bpy.ops.ed.undo() 不可用（poll 失败）⇒ 真撤销留 GUI 验证",
         True, "本步只验证 undo_push 与 _on_undo_post 不崩、状态可解释")

    # ★★★ undo 之后内存表被**故意清空**（设计：缓存 = 派生，property = 唯一真相）。
    #     真正的检验不是"表还在不在"，而是**读的时候能不能从 property 恢复真相**
    #     —— 这正是"撤销架空内存缓存"那类反模式的正面判据。
    #     ⚠️ 注意 'E.invariants' 的"幽灵"判据是"有 property 但表里没条目"，
    #        在冷缓存下**必然**命中；那是设计使然，不是缺陷（下面按读入口对账）。
    _tlock = bool(act.get(xf._TRILOCK_PROP))
    _tfrozen = bool(act.get(td._FROZEN_PROP))
    _feel_tok = {}
    for _t in (xf.feel_tokens(act) or ()):
        try:
            # ★ 2026-09-30（D-1/D-2）：token 从 3 段变 **4 段**（末尾多了 owner）。
            #   这里只关心"值"，owner 不影响本判据 ⇒ 按 4 段解包、丢掉 owner。
            _p = str(_t).split("|")
            if len(_p) != 4:
                continue
            _feel_tok[(round(float(_p[0]), 4), _p[1])] = _p[2]
        except Exception:
            pass
    _exp_feel = _feel_tok.get((90.0, 'left'))
    _got_lock = xf.is_tri_locked(act, 90.0)
    _got_frozen = td.is_frozen(act, 90.0)
    _got_feel = xf.feel_type_at(act, 90.0, 'left')
    step("H2-16b ★★★ undo 清空内存表后，**查询能从 custom property 恢复真相**（读时自查）",
         (_got_lock == (not _tlock)) and (_got_frozen == _tfrozen)
         and (_got_feel == _exp_feel),
         "tri_lock: property 存在=%s ⇒ is_tri_locked=%s（期望 %s）| "
         "frozen: property 存在=%s ⇒ is_frozen=%s（期望 %s）| "
         "feel: property 词条=%r ⇒ feel_type_at=%r"
         % (_tlock, _got_lock, not _tlock, _tfrozen, _got_frozen, _tfrozen,
            _exp_feel, _got_feel))
    warm_tables(act)
    inv("H2-17 ⑥ 之后不变量（按读入口 warm 后对账）", act, o)

    # ⑦ 存盘重开
    e = ""
    tmp = os.path.join(tempfile.gettempdir(), "_eb_modal_h2.blend")
    obj_name, act_name = str(o.name), str(act.name)
    try:
        bpy.ops.wm.save_as_mainfile(filepath=tmp)
        bpy.ops.wm.open_mainfile(filepath=tmp)
    except Exception:
        e = E.tb(600)
    rec("H2-18 ⑦ 存盘 + 重开", e)
    o2 = bpy.data.objects.get(obj_name)
    a2 = bpy.data.actions.get(act_name)
    step("H2-19 重开后对象与 action 都在", o2 is not None and a2 is not None,
         "obj=%s act=%s" % (o2 is not None, a2 is not None))
    step("H2-20 重开后 action 上的四表 custom property 仍随文件存活",
         a2 is not None and any(a2.get(p) for p in
                                (xf._FEEL_PROP, xf._TRILOCK_PROP, td._FROZEN_PROP,
                                 xf._OWNED_PROP)),
         "属性=%s" % {p: (a2.get(p) if a2 else None)
                     for p in (xf._FEEL_PROP, xf._TRILOCK_PROP, td._FROZEN_PROP,
                               xf._OWNED_PROP)})
    if o2 is not None and a2 is not None:
        # ⚠️ 重开文件后进程内的内存表是**冷的**（表与文件里的 property 无关）。
        #    'E.invariants' 的"幽灵"判据（有 property 但表里没条目）在冷缓存下
        #    **必然**命中 —— 在「缓存=派生、读时自查」的设计下这是正常态，不是缺陷。
        #    ⇒ 先如实记录冷缓存时的报错，再按插件自己的读入口 warm 一遍后对账；
        #      若 warm 之后仍不一致，那才是真问题。
        _pre = E.invariants(a2, o2)
        step("H2-20b NOTE 重开后内存表是冷的（有 property、表为空）—— 设计如此，读时自查会补上",
             True, "冷缓存时 E.invariants 报：%s；warm 之后见下一条"
             % ("; ".join(_pre)[:300] or "无"))
        warm_tables(a2)
        inv("H2-21 ⑦ 重开后不变量（按读入口 warm 后对账）", a2, o2)
        inv_frozen("H2-22 ⑦ 重开后第 4 张表", a2)
        # ⑧ 再校正
        e = ""
        fix2 = {}
        try:
            det2 = sc.detect(a2, o2)
            fix2, _s = sc.apply_fix(a2, o2, det2)
        except Exception:
            e = E.tb(700)
        rec("H2-23 ⑧ 再校正", e)
        step("H2-24 ★★ 再校正无阶段异常",
             not [k for k, v in (fix2.get("applied") or {}).items() if v == -1],
             "applied=%s frozen=%s 复检剩余=%d"
             % (fix2.get("applied"), fix2.get("frozen"),
                len((fix2.get("after") or {}).get("issues") or [])))
        warm_tables(a2)
        inv("H2-25 ⑧ 之后不变量", a2, o2)
        # ⑨ 再检测
        e = ""
        det3 = {}
        try:
            det3 = sc.detect(a2, o2)
        except Exception:
            e = E.tb(600)
        rec("H2-26 ⑨ 再检测", e)
        step("H2-27 ★★ 再检测是纯读：检测后不变量仍成立", True,
             "issues=%d hints=%d checked_frames=%s"
             % (len(det3.get("issues") or []), len(det3.get("hints") or []),
                det3.get("checked_frames")))
        warm_tables(a2)
        inv("H2-28 ⑨ 之后不变量", a2, o2)
        inv_frozen("H2-29 ⑨ 之后第 4 张表", a2)
    step("H2-30 全流程 9 步无一抛异常",
         all(ok for _n, ok, _d in chain),
         "; ".join("%s:%s" % (n, d) for n, ok, d in chain if not ok) or "全部 ok")
    try:
        if os.path.exists(tmp):
            os.remove(tmp)
    except Exception:
        pass
except Exception:
    step("H2 FATAL", False, E.tb(1200))


# ===========================================================================
flush()
print("EB_MODAL_DONE")
