# -*- coding: utf-8 -*-
"""C 组（曲线/动作结构极限）+ D 组（四张内存表 x 一致性）极限边界测试。

来源：Phase 1 极限边界测试分工。共享地基 = tests/_eb_common.py（已冒烟）。
本文件**只读产品代码**，不改任何产品文件。

## 覆盖项

D 组（四张内存表 = 插件的「账本」，property = 唯一真相，_xxx_sync = 对账窗口）
  D1  四表交叉矛盾（同帧四种记录互相打架）时谁说了算
  D2  undo / redo x 20 次后四表 vs 真实数据（含 headless 下真 undo 不可用的实测）
  D3  四表持久化：存盘 -> 另起进程读回（双进程，写系统临时目录）
  D4  多 action 来回切换是否串数据
  D5  共享 action 的两个对象（表键只含 action 名）是否串
  D6  action 改名后表是否失效 / 复用旧名是否继承
  D7  action.copy() 后表是否被误继承
  D8  指向已删关键帧的僵尸词条
  D9  undo_guard.clear_all_state_caches() 之后能否 warm 回来

C 组（动作结构极限）
  C1  多对象共享一个 action
  C2  一个对象多个 action slot
  C3  分层动作：多层 / 多 strip
  C4  action 无 slot / slot 不匹配
  C5  骨骼（POSE）x 边界
  C6  曲线挂 driver
  C7  库链接（linked）action 的写入路径
  C8  对象挂约束

## 判定口径（按任务书）
  FAIL    = 明确违反不变量 / 规范（真 bug）
  SUSPECT = NaN/Inf、静默无提示、状态不一致（可疑）
  NOTE    = 已知设计边界 => 计 PASS，但 detail 写清楚

## 不变量（每个用例操作后都调 E.invariants）
  1 同侧三轴 dt 相等  2 无 NaN/Inf  3 dt 非负且不超段长
  4 四张内存表与 action 的 custom property 一致

⚠️ 本文件额外加了【双向】对账检查 table_vs_prop()：地基里的 invariants
   只查「property 有、内存没有」（单向）。内存有、property 没有（幽灵留在
   内存里）同样是账本失真，必须一起查。

用法（必须这个形态）：
    blender --background --factory-startup --python tests/gui_eb_state_check.py
"""
import bpy
import os
import sys
import json
import math
import tempfile
import subprocess
import inspect

HERE = os.path.dirname(os.path.abspath(__file__))
# ⚠️ 别硬编码盘符（公司机 D:\ / 家里机 F:\）—— 写死会让脚本在另一台机器上静默失败，
#    门禁只报 STALE，看不出原因。见 gui_eb_modal_check.py 里的详细说明。
ADDONS = os.path.dirname(os.path.dirname(HERE))
if ADDONS not in sys.path:
    sys.path.insert(0, ADDONS)
if os.path.join(ADDONS, 'RealTimeMotionPath', 'tests') not in sys.path:
    sys.path.insert(0, os.path.join(ADDONS, 'RealTimeMotionPath', 'tests'))

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
import _eb_common as E                                    # noqa: E402
from RealTimeMotionPath import transform_domain as xf      # noqa: E402
from RealTimeMotionPath import time_domain as td           # noqa: E402
from RealTimeMotionPath import undo_guard as ug            # noqa: E402
from RealTimeMotionPath import cache as ca                 # noqa: E402

LOG = os.path.join(HERE, "_eb_state_result.json")
TMP = tempfile.gettempdir()
FRAME = 90.0

steps = []


def step(n, ok, d=""):
    steps.append((n, bool(ok), str(d)[:600]))


# ===========================================================================
# 工具区
# ===========================================================================

def reset_tables():
    """只清【内存镜像】（不带 action 参数 => 不删 property）。

    ⚠️ 这是隔离手段，不是"重置用户数据"：property 一个字都不动，
    所以下一步的惰性 warm 照样能读回来（D9 正是在测这件事）。
    """
    for fn in (xf.clear_tri_lock, xf.clear_feel, xf.clear_owned_free, td.clear_frozen):
        try:
            fn()
        except Exception:
            pass


def fresh(name, keys=E.KEYS_3, **kw):
    """干净的场景 + 干净的内存表 + 一个带 location 关键帧的对象。"""
    E.clear_scene()
    reset_tables()
    return E.build_object(name, keys, **kw)


def kp_at(o, act, frame=FRAME, bone=None, axis=0):
    for fc in xf._position_curves(act, o, bone):
        if fc.array_index == axis:
            return xf.keyframe_at(fc, frame)
    return None


def kp_map(o, act, frame=FRAME, bone=None):
    """{axis: fcurve} —— 同 collect_selected_frames 的形状（喂 make_handles_editable）。"""
    return {fc.array_index: fc for fc in xf._position_curves(act, o, bone)}


def dts_of(o, act, frame=FRAME, side='right', bone=None):
    """★ 现取【新鲜】关键帧再测 dt。

    ⚠️ keyframe 包装对象用过一次会「钝」（见 blender-addon-dev skill）——
       拿着 write_s 之前收集的 kfm 去测写后的值，会读到陈旧数字，
       把「其实没写进去」和「写进去了但被 Blender 重算」搞混。
    """
    out = {}
    for fc in xf._position_curves(act, o, bone):
        kp = xf.keyframe_at(fc, frame)
        if kp is None:
            continue
        h = kp.handle_left if side == 'left' else kp.handle_right
        out[fc.array_index] = abs(float(h[0]) - float(kp.co[0]))
    return out


def _parse(tokens, n):
    """property 词条 -> 元组集合。畸形词条记成 MALFORMED 以便暴露。"""
    out = set()
    for t in tokens:
        p = str(t).split("|")
        if len(p) != n:
            out.add(("MALFORMED", str(t)))
            continue
        try:
            out.add((round(float(p[0]), 4),) + tuple(str(x) for x in p[1:]))
        except Exception:
            out.add(("MALFORMED", str(t)))
    return out


def _mem(table, nm, kind):
    """内存表 -> 元组集合（与 _parse 同口径）。"""
    out = set()
    for k in list(table):
        if k[0] != nm:
            continue
        if kind == "feel":
            # ★ 2026-09-30（D-1/D-2）：键多了第 4 段 owner（骨骼名@slot）。
            #   对账必须**带上 owner 比** —— 同一 (帧, 侧) 有多条是**对的**
            #   （不同骨骼各一条），以前"只允许一条"才是 bug。
            out.add((round(float(k[1]), 4), str(k[2]), str(table[k]).upper(),
                     str(k[3]) if len(k) > 3 else ""))
        elif kind == "owned":
            # ★ 2026-09-30（D-1/D-2）：键多了第 4 段 owner。
            out.add((round(float(k[1]), 4), str(k[2]),
                     str(k[3]) if len(k) > 3 else ""))
        elif kind == "trilock":
            # ★ 2026-09-30（D-1/D-2）：键多了第 3 段 owner（与 feel 同理）。
            out.add((round(float(k[1]), 4), "LOCKED" if table[k] else "SPLIT",
                     str(k[2]) if len(k) > 2 else ""))
        else:
            # ★ 2026-09-30（D-1/D-2）：冻结表键多了第 3 段 owner。
            out.add((round(float(k[1]), 4), str(k[2]) if len(k) > 2 else ""))
    return out


def table_vs_prop(act):
    """★ 双向对账：四张内存表 vs action 的 custom property。

    先调各自的 _*_sync（那是对账入口，契约就是"读之前对一次账"），
    再比集合。返回不一致描述列表（空 = 账本干净）。
    """
    bad = []
    if act is None:
        return ["act 为 None"]
    nm = str(act.name)
    for fn in (xf._feel_sync, xf._trilock_sync, xf._owned_sync, td._frozen_sync):
        try:
            fn(act)
        except Exception:
            bad.append("sync 抛异常: " + E.tb(200))
    for label, table, prop, kind, n in (
            ("feel", xf._FEEL, xf._FEEL_PROP, "feel", 4),   # 4 段 = 多了 owner
            ("trilock", xf._TRILOCK, xf._TRILOCK_PROP, "trilock", 3),   # 3 段 = 多了 owner
            ("owned_free", xf._plugin_owned_free, xf._OWNED_PROP, "owned", 3),
            ("frozen", td._FROZEN, td._FROZEN_PROP, "frozen", 2)):
        try:
            raw = act.get(prop)
            prop_set = _parse(list(raw) if raw else [], n)
        except Exception:
            prop_set = set()
        mem_set = _mem(table, nm, kind)
        if mem_set != prop_set:
            bad.append("%s 内存多出=%s / property 多出=%s"
                       % (label, sorted(mem_set - prop_set), sorted(prop_set - mem_set)))
    return bad


def clean(act, obj, bone=None):
    """不变量 + 双向对账，一次拿齐。"""
    bad = []
    try:
        bad += E.invariants(act, obj, bone)
    except Exception:
        bad.append("invariants 抛异常: " + E.tb(200))
    bad += table_vs_prop(act)
    return bad


def props_of(act):
    out = {}
    for p in ("rtmp_feel", "rtmp_tri_lock", "rtmp_owned_free", "rtmp_frozen"):
        try:
            v = act.get(p)
            out[p] = sorted([str(x) for x in v]) if v else None
        except Exception:
            out[p] = "EXC"
    return out


def prop_snapshot(act):
    """四张 property 的原文快照（模拟 Blender 全局 undo 的整库回滚）。"""
    return {p: (list(act[p]) if p in act.keys() else None)
            for p in ("rtmp_feel", "rtmp_tri_lock", "rtmp_owned_free", "rtmp_frozen")}


def prop_restore(act, snap):
    """把四张 property 写回快照状态（= undo / redo 对 property 干的事）。"""
    for p, v in snap.items():
        try:
            if v is None:
                if p in act.keys():
                    del act[p]
            else:
                act[p] = list(v)
        except Exception:
            pass


# ===========================================================================
# D 组
# ===========================================================================

def case_D1():
    """D1 四表交叉矛盾：同一帧四种记录互相打架时谁说了算。"""
    try:
        # ---- D1a：用户显式 FREE vs 速度编辑冻结（2026-09-30 修复的正是这条）----
        o, act = fresh("EB_D1a")
        kp = kp_at(o, act)
        xf.mark_feel(kp, 'left', 'FREE')       # 用户：左侧手柄不动
        xf.mark_feel(kp, 'right', 'FREE')      # 用户：右侧手柄不动
        td.mark_frozen(act, FRAME)             # 速度编辑：这帧"该联动"
        left = xf.feel_type(kp, 'left')
        mode = xf._link_mode(kp, 'right')      # 拖右侧时，左侧怎么办
        bad = clean(act, o)
        step("D1a 冻结不覆盖用户显式 FREE（口径：已记录不覆盖）",
             left == 'FREE' and td.is_frozen(act, FRAME) is True,
             "feel_left=%s frozen=%s（冻结表说'联动'、体感表说'不动'，看谁赢）"
             % (left, td.is_frozen(act, FRAME)))
        step("D1a 矛盾解决口径 = 体感权威（_link_mode 走 'free'）",
             mode == 'free',
             "_link_mode(拖右看左)=%r；不变量+双向对账=%s" % (mode, bad or "干净"))
        step("D1a 矛盾态下不变量与账本仍然干净", not bad, "; ".join(bad) or "无违规")

        # ---- D1b：四张表同帧全写，最后写 feel=FREE ----
        o, act = fresh("EB_D1b")
        kp = kp_at(o, act)
        xf.set_tri_locked(act, FRAME, False)   # 三角分离
        td.mark_frozen(act, FRAME)             # 冻结（会把未记录的体感兜底写成 LINK）
        xf.mark_owned_free(kp, 'left')         # 插件接管（无条件写 LINK）
        xf.mark_feel(kp, 'left', 'FREE')       # 最后用户改主意：不动
        L = xf.feel_type(kp, 'left')
        R = xf.feel_type(kp, 'right')
        mL = xf._link_mode(kp, 'left')         # 拖左看右
        mR = xf._link_mode(kp, 'right')        # 拖右看左
        bad = clean(act, o)
        step("D1b 同帧四表共存：不崩、行为可解释（体感=最后写入者）",
             L == 'FREE' and R == 'LINK' and mL == 'link' and mR == 'free',
             "feel L=%s R=%s | _link_mode 拖左看右=%s 拖右看左=%s | 三角锁定=%s"
             % (L, R, mL, mR, xf.is_tri_locked(act, FRAME)))
        step("D1b 三角锁定与体感互不干扰（两个正交维度）",
             xf.is_tri_locked(act, FRAME) is False and not bad,
             "trilock=%s（分离）| 账本=%s" % (xf.is_tri_locked(act, FRAME), bad or "干净"))

        # ---- D1c：口径不一致 —— mark_owned_free 会静默覆盖用户显式 FREE ----
        o, act = fresh("EB_D1c")
        kp = kp_at(o, act)
        xf.mark_feel(kp, 'left', 'FREE')       # 用户显式：左侧不动
        before = xf.feel_type(kp, 'left')
        mode_before = xf._link_mode(kp, 'right')   # 拖右侧时，左侧该不该动
        # 模拟【关键帧模态】进入（modal_edit 会调 make_handles_editable）
        xf.make_handles_editable(act, o, {FRAME: kp_map(o, act)})
        after = xf.feel_type(kp, 'left')
        mode_after = xf._link_mode(kp, 'right')
        bad = clean(act, o)
        src_freeze = inspect.getsource(td.freeze_handle_side)
        src_owned = inspect.getsource(xf.mark_owned_free)
        step("D1c ★★ 关键帧模态不得静默抹掉用户显式 FREE（口径应与 freeze 一致）",
             after == before,
             "进模态前 feel_left=%s，进模态后=%s（freeze_handle_side 有 'is None' 守卫=%s；"
             "mark_owned_free 无条件写 LINK=%s）| 账本=%s"
             % (before, after, "is None" in src_freeze or "None" in src_freeze,
                "mark_feel(kp, side, 'LINK')" in src_owned, bad or "干净"))
        step("D1c ★★★ 关键帧模态的静默改写会真的改行为：拖右柄时左柄从不动变成跟着动",
             mode_after == mode_before,
             "拖右侧时左侧的联动模式：进模态前=%r（不动），进模态后=%r（跟着动）"
             % (mode_before, mode_after))
    except Exception:
        step("FATAL D1", False, E.tb())


def case_D2():
    """D2 undo / redo x 20 次后四表 vs 真实数据。"""
    # ---- D2-0：headless 下真 undo 到底能不能跑（先实测再下结论）----
    try:
        bpy.ops.mesh.primitive_cube_add()
        probe_o = bpy.context.view_layer.objects.active
        probe_o.location = (1.0, 0.0, 0.0)
        bpy.ops.ed.undo_push(message="eb_probe")
        probe_o.location = (2.0, 0.0, 0.0)
        try:
            bpy.ops.ed.undo()
            undo_ok = True
            err = ""
        except Exception as exc:
            undo_ok = False
            err = repr(exc)[:120]
        real_undo = bool(undo_ok and abs(probe_o.location[0] - 1.0) < 1e-6)
        step("D2-0 NOTE headless 下 bpy.ops.ed.undo() 不可用（实测）=> 改测其等效机理",
             True,
             "undo() 调用=%s err=%s；调用后 location.x=%.3f（期望回滚到 1.0）。"
             "⇒ --background 无 window，undo/redo 的 poll 恒 False（wm.window_new 也 poll 失败）。"
             "因此本用例用【整库快照回滚 property + 触发 undo_post 钩子】复刻 undo 的等效机理。"
             % ("成功" if undo_ok else "抛异常", err or "-", probe_o.location[0]))
    except Exception:
        step("FATAL D2-0", False, E.tb())

    # ---- D2a：20 轮 undo/redo（property 级复刻 + 真钩子）----
    try:
        o, act = fresh("EB_D2")
        kp = kp_at(o, act)
        # 两个"状态"：0 = 用户不动；1 = 联动 + 三角分离 + 冻结
        # ★ 2026-09-30（D-1/D-2）：token 变 4 段（末尾多了 owner）。
        #   这里**故意把 owner 留空** = 「不知道是谁」桶 —— 正是要模拟
        #   「外部改了 property / 老路径写的记录」，看读侧能不能感知到。
        state0 = {"rtmp_feel": ["%.4f|left|FREE|" % FRAME, "%.4f|right|FREE|" % FRAME],
                  "rtmp_tri_lock": None, "rtmp_owned_free": None, "rtmp_frozen": None}
        state1 = {"rtmp_feel": ["%.4f|left|LINK|" % FRAME, "%.4f|right|LINK|" % FRAME],
                  "rtmp_tri_lock": ["%.4f|SPLIT|" % FRAME],   # 3 段（D-1/D-2）
                  "rtmp_owned_free": ["%.4f|left|" % FRAME],    # 3 段（D-1/D-2）
                  "rtmp_frozen": ["%.4f|" % FRAME]}             # 2 段（D-1/D-2）
        prop_restore(act, state0)
        ug.clear_all_state_caches()
        bad_rounds = []
        for i in range(20):
            # --- redo：走到 state1 ---
            prop_restore(act, state1)
            ug._on_redo_post(bpy.context.scene)
            f1 = xf.feel_type_at(act, FRAME, 'left')
            t1 = xf.is_tri_locked(act, FRAME)
            z1 = td.is_frozen(act, FRAME)
            o1 = xf._is_plugin_owned_free(kp, 'left')
            b1 = clean(act, o)
            if not (f1 == 'LINK' and t1 is False and z1 is True and o1 is True and not b1):
                bad_rounds.append("redo#%d feel=%s tri=%s frozen=%s owned=%s %s"
                                  % (i, f1, t1, z1, o1, b1))
            # --- undo：退回 state0 ---
            prop_restore(act, state0)
            ug._on_undo_post(bpy.context.scene)
            f0 = xf.feel_type_at(act, FRAME, 'left')
            t0 = xf.is_tri_locked(act, FRAME)
            z0 = td.is_frozen(act, FRAME)
            b0 = clean(act, o)
            if not (f0 == 'FREE' and t0 is True and z0 is False and not b0):
                bad_rounds.append("undo#%d feel=%s tri=%s frozen=%s %s"
                                  % (i, f0, t0, z0, b0))
        step("D2a ★★ 20 轮 undo/redo 后四表查询与真实 property 始终一致",
             not bad_rounds,
             "20 轮 x (redo+undo) 全对；异常轮次=%s" % (bad_rounds[:4] or "无"))
    except Exception:
        step("FATAL D2a", False, E.tb())

    # ---- D2b：钩子不在场时也必须兜住（对账 vs 钩子，v1.3.8 的核心承诺）----
    try:
        o, act = fresh("EB_D2b")
        kp = kp_at(o, act)
        xf.mark_feel_at(act, FRAME, 'left', 'FREE')
        ug.clear_all_state_caches()
        # 只改 property，【不】调任何钩子 —— 模拟 hook 被第三方插件扫掉
        act["rtmp_feel"] = ["%.4f|left|LINK|" % FRAME]      # 4 段：owner 留空 = 未知桶
        val = xf.feel_type_at(act, FRAME, 'left')
        bad = clean(act, o)
        step("D2b ★★★ 钩子不在场时，读侧对账仍能感知 property 变化",
             val == 'LINK' and not bad,
             "property 改成 LINK、未触发任何钩子 => 查询=%s（期望 LINK）| 账本=%s"
             % (val, bad or "干净"))
    except Exception:
        step("FATAL D2b", False, E.tb())

    # ---- D2c：undo 之后属性被整条删除（删除关键帧后撤销链）----
    try:
        o, act = fresh("EB_D2c")
        xf.mark_feel_at(act, FRAME, 'left', 'FREE')
        ug.clear_all_state_caches()
        del act["rtmp_feel"]                 # undo 回到"从未记录过"的状态
        ug._on_undo_post(bpy.context.scene)
        val = xf.feel_type_at(act, FRAME, 'left')
        bad = clean(act, o)
        step("D2c ★ property 整条消失 => 表必须回到「未记录」(透传)，不留幽灵",
             val is None and not bad,
             "查询=%r（期望 None）| 账本=%s" % (val, bad or "干净"))
    except Exception:
        step("FATAL D2c", False, E.tb())


CHILD_SRC = '''# -*- coding: utf-8 -*-
import bpy, sys, json
ADDONS = r"@ADDONS@"
sys.path.insert(0, ADDONS)
sys.path.insert(0, ADDONS + r"\\RealTimeMotionPath\\tests")
bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
bpy.ops.wm.open_mainfile(filepath=r"@BLEND@")
from RealTimeMotionPath import transform_domain as xf
from RealTimeMotionPath import time_domain as td
R = {}
# ★ 必须先测：新进程的内存表是不是空的（证明数据来自 property，不是内存残留）
R["mem_at_import"] = [len(xf._FEEL), len(xf._TRILOCK), len(xf._plugin_owned_free), len(td._FROZEN)]
act = bpy.data.actions.get("@ACT@")
R["act_found"] = act is not None
if act is not None:
    R["props"] = {}
    for p in ("rtmp_feel", "rtmp_tri_lock", "rtmp_owned_free", "rtmp_frozen"):
        v = act.get(p)
        R["props"][p] = sorted([str(x) for x in v]) if v else None
    R["feel_left"] = xf.feel_type_at(act, @FRAME@, "left")
    R["feel_right"] = xf.feel_type_at(act, @FRAME@, "right")
    R["trilock"] = xf.is_tri_locked(act, @FRAME@)
    R["frozen"] = td.is_frozen(act, @FRAME@)
    R["mem_after_query"] = [len(xf._FEEL), len(xf._TRILOCK),
                            len(xf._plugin_owned_free), len(td._FROZEN)]
    R["mem_feel"] = sorted([str(k) for k in xf._FEEL])
    R["mem_frozen"] = sorted([str(k) for k in td._FROZEN])
print("CHILD_BEGIN")
print(json.dumps(R, ensure_ascii=False, default=str))
print("CHILD_END")
'''


def case_D3():
    """D3 四表持久化：存盘 -> 另起进程读回。"""
    blend = os.path.join(TMP, "_eb_state_persist.blend")
    child = os.path.join(TMP, "_eb_state_child.py")
    actname = "EB_D3_Action"
    try:
        o, act = fresh("EB_D3")
        act.name = actname
        kp = kp_at(o, act)
        xf.set_tri_locked(act, FRAME, False)
        xf.mark_owned_free(kp, 'left')      # ⚠️ 这个会无条件写 feel=LINK，必须先做
        xf.mark_feel(kp, 'left', 'FREE')    # 再覆盖成用户要的 FREE
        xf.mark_feel(kp, 'right', 'LINK')
        td.mark_frozen(act, FRAME)
        written = props_of(act)
        step("D3 前提：四张 property 都已写入（memory 与 property 一致）",
             written["rtmp_feel"] and written["rtmp_tri_lock"]
             and written["rtmp_owned_free"] and written["rtmp_frozen"],
             json.dumps(written, ensure_ascii=False))
        bpy.ops.wm.save_as_mainfile(filepath=blend)
        step("D3 前提：存盘到系统临时目录（不写仓库）",
             os.path.isfile(blend), blend)

        src = (CHILD_SRC.replace("@ADDONS@", ADDONS)
                        .replace("@BLEND@", blend)
                        .replace("@ACT@", actname)
                        .replace("@FRAME@", repr(float(FRAME))))
        with open(child, "w", encoding="utf-8") as fh:
            fh.write(src)

        exe = bpy.app.binary_path
        proc = subprocess.run([exe, "--background", "--factory-startup", "--python", child],
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              timeout=240)
        out = proc.stdout.decode("utf-8", "replace")
        data = None
        if "CHILD_BEGIN" in out and "CHILD_END" in out:
            blob = out.split("CHILD_BEGIN", 1)[1].split("CHILD_END", 1)[0]
            try:
                data = json.loads(blob.strip())
            except Exception:
                data = None
        step("D3 子进程跑通并返回 JSON", data is not None,
             ("rc=%s " % proc.returncode) + (out[-260:] if data is None else "ok"))
        if data is None:
            return
        step("D3 ★ 新进程内存表为空（数据确实来自 property，不是内存残留）",
             data.get("mem_at_import") == [0, 0, 0, 0],
             "mem_at_import=%s" % (data.get("mem_at_import"),))
        step("D3 ★★ 四张 property 随 .blend 持久化且逐条一致",
             data.get("act_found") and data.get("props") == written,
             "读回=%s | 写前=%s" % (json.dumps(data.get("props"), ensure_ascii=False),
                                   json.dumps(written, ensure_ascii=False)))
        step("D3 ★★★ 惰性恢复：重启后体感/锁定/冻结全部读回正确",
             data.get("feel_left") == 'FREE' and data.get("feel_right") == 'LINK'
             and data.get("trilock") is False and data.get("frozen") is True,
             "feel L=%s R=%s trilock=%s frozen=%s"
             % (data.get("feel_left"), data.get("feel_right"),
                data.get("trilock"), data.get("frozen")))
        step("D3 恢复后内存表内容与 property 对齐（无多无少）",
             len(data.get("mem_feel") or []) == 2
             and len(data.get("mem_frozen") or []) == 1,
             "mem_feel=%s mem_frozen=%s"
             % (data.get("mem_feel"), data.get("mem_frozen")))
    except Exception:
        step("FATAL D3", False, E.tb())


def case_D4():
    """D4 多 action 来回切换是否串数据。"""
    try:
        E.clear_scene()
        reset_tables()
        oa, actA = E.build_object("EB_D4A", E.KEYS_3)
        actA.name = "EB_D4_ActA"
        ob, actB = E.build_object("EB_D4B", E.KEYS_3)
        actB.name = "EB_D4_ActB"
        kpA = kp_at(oa, actA)
        kpB = kp_at(ob, actB)
        xf.mark_feel(kpA, 'left', 'FREE')
        xf.mark_feel(kpB, 'left', 'LINK')
        xf.set_tri_locked(actA, FRAME, False)
        td.mark_frozen(actB, FRAME)
        # 让 objA 在两个 action 之间来回切
        oa.animation_data.action = actB
        oa.animation_data.action = actA
        bad = []
        for i in range(10):
            oa.animation_data.action = actA
            if xf.feel_type_at(actA, FRAME, 'left') != 'FREE':
                bad.append("轮%d 切回A feel=%s" % (i, xf.feel_type_at(actA, FRAME, 'left')))
            if xf.is_tri_locked(actA, FRAME) is not False:
                bad.append("轮%d 切回A trilock=%s" % (i, xf.is_tri_locked(actA, FRAME)))
            if td.is_frozen(actA, FRAME) is not False:
                bad.append("轮%d A 被 B 的冻结串了" % i)
            oa.animation_data.action = actB
            if xf.feel_type_at(actB, FRAME, 'left') != 'LINK':
                bad.append("轮%d 切到B feel=%s" % (i, xf.feel_type_at(actB, FRAME, 'left')))
            if td.is_frozen(actB, FRAME) is not True:
                bad.append("轮%d 切到B frozen=%s" % (i, td.is_frozen(actB, FRAME)))
            if xf.is_tri_locked(actB, FRAME) is not True:
                bad.append("轮%d B 被 A 的锁定串了" % i)
        oa.animation_data.action = actA
        bad += clean(actA, oa) + clean(actB, ob)
        step("D4 ★★ 10 轮 action 切换：两个 action 的账本互不串",
             not bad, "; ".join(bad[:6]) or "无串扰")
        ta = sorted(str(x) for x in (actA.get("rtmp_feel") or []))
        tb = sorted(str(x) for x in (actB.get("rtmp_feel") or []))
        step("D4 ★ 切换后两边的 property 各自保持原值（左侧体感不互相污染）",
             # ★ 2026-09-30（D-1/D-2）：token 多了 owner 段 ⇒ 按**前缀**比，不再比整串
         #   （owner 是「谁的手柄」，与"两边互不污染"这条断言无关）
         len(ta) == 1 and ta[0].startswith("%.4f|left|FREE|" % FRAME)
         and any(t.startswith("%.4f|left|LINK|" % FRAME) for t in tb),
             "A=%s B=%s（B 的对侧 LINK 是 mark_frozen 顺手补的，属已知行为）" % (ta, tb))
        step("D4 切换后曲线收集仍按对象各自的 action",
             len(xf._position_curves(actA, oa, None)) == 3
             and len(xf._position_curves(actB, ob, None)) == 3,
             "A=%d B=%d" % (len(xf._position_curves(actA, oa, None)),
                            len(xf._position_curves(actB, ob, None))))
    except Exception:
        step("FATAL D4", False, E.tb())


def case_D5():
    """D5 共享 action 的两个对象（表键只含 action 名）=> 是否串。"""
    try:
        # ---- D5a：单 slot 共享（两个对象读同一份曲线）----
        o1, act = fresh("EB_D5a")
        act.name = "EB_D5_Act"
        bpy.ops.mesh.primitive_cube_add()
        o2 = bpy.context.view_layer.objects.active
        o2.name = "EB_D5b"
        o2.animation_data_create()
        o2.animation_data.action = act
        slot2 = getattr(o2.animation_data.action_slot, "identifier", None)
        n1 = len(xf._position_curves(act, o1, None))
        n2 = len(xf._position_curves(act, o2, None))
        kp1 = kp_at(o1, act)
        xf.mark_feel(kp1, 'left', 'FREE')
        same = xf.feel_type_at(act, FRAME, 'left')
        bad = clean(act, o1) + clean(act, o2)
        step("D5a 单 slot 共享：两对象曲线数一致，账本按 action 共享（设计如此）",
             n1 == n2 == 3 and same == 'FREE' and not bad,
             "曲线 o1=%d o2=%d；o2.action_slot=%r；feel=%s；账本=%s"
             % (n1, n2, slot2, same, bad or "干净"))
        step("D5a NOTE o2 未绑定 slot 时插件仍按 slots[0] 读曲线（与 Blender 自身求值口径可能不同）",
             True,
             "o2.animation_data.action_slot=%r（Blender 视为未绑定），"
             "而 _position_curves(act, o2)=%d 条 —— 插件用 slots[0] 兜底。" % (slot2, n2))

        # ---- D5b：两个 slot、同帧都有关键帧 => 表键撞车 ----
        o1, act = fresh("EB_D5c")
        act.name = "EB_D5_Slots"
        bpy.ops.mesh.primitive_cube_add()
        o2 = bpy.context.view_layer.objects.active
        o2.name = "EB_D5d"
        o2.animation_data_create()
        o2.animation_data.action = act
        sB = act.slots.new(id_type='OBJECT', name="EB_SlotB")
        o2.animation_data.action_slot = sB
        cb = act.layers[0].strips[0].channelbag(sB, ensure=True)
        fcB = cb.fcurves.new("location", index=0)
        for f, v in ((0.0, 0.0), (FRAME, 5.0), (117.0, 9.0)):
            fcB.keyframe_points.insert(f, v)
        fcB.update()
        kpA = kp_at(o1, act)                     # slot A 的关键帧
        kpB = kp_at(o2, act)                     # slot B 的关键帧（同帧）
        ok_setup = kpA is not None and kpB is not None
        xf.mark_feel(kpA, 'left', 'LINK')
        a_before = xf.feel_type(kpA, 'left')
        xf.mark_feel(kpB, 'left', 'FREE')        # 对 slot B 设"不动"
        a_after = xf.feel_type(kpA, 'left')      # slot A 应仍是 LINK
        prop = sorted(act.get("rtmp_feel") or [])
        bad = clean(act, o1)
        step("D5b ★★★ 两个 slot 同帧的关键帧，账本必须分开记（键缺 slot 会串）",
             ok_setup and a_after == 'LINK',
             "构造成功=%s；slot A 记 LINK 后=%s，对 slot B 记 FREE 后 slot A 读回=%s"
             "（期望 LINK，实际串成 %s）；property=%s"
             % (ok_setup, a_before, a_after, a_after, prop))
        step("D5b ★★ 同帧两条记录必须都留在 property 里（不能只剩最后一条）",
             len(prop) >= 2,
             "rtmp_feel=%s（期望 >=2 条：A 一条、B 一条）" % prop)
        step("D5b 串扰未破坏不变量/账本（账本是「一致地错」）", not bad, "; ".join(bad) or "干净")
    except Exception:
        step("FATAL D5", False, E.tb())


def case_D6():
    """D6 action 改名后表是否失效 / 复用旧名是否继承。"""
    try:
        o, act = fresh("EB_D6")
        old = act.name
        kp = kp_at(o, act)
        xf.mark_feel(kp, 'left', 'FREE')
        xf.set_tri_locked(act, FRAME, False)
        td.mark_frozen(act, FRAME)
        act.name = "EB_D6_RENAMED"
        v1 = xf.feel_type_at(act, FRAME, 'left')
        v2 = xf.is_tri_locked(act, FRAME)
        v3 = td.is_frozen(act, FRAME)
        bad = clean(act, o)
        step("D6 ★ 改名后三条查询仍正确（键用名字 => 靠 property 重建）",
             v1 == 'FREE' and v2 is False and v3 is True and not bad,
             "改名后 feel=%s trilock=%s frozen=%s | 账本=%s"
             % (v1, v2, v3, bad or "干净"))
        stale = sorted([str(k) for k in xf._FEEL if k[0] == old])
        step("D6 NOTE 旧名条目留在内存表里（惰性清理，非即时）",
             True,
             "旧名 %r 的内存条目=%s（改名瞬间不清；等有同名 action 来查询时才被重建清掉）"
             % (old, stale))
        newact = bpy.data.actions.new(old)       # 复用旧名
        v4 = xf.feel_type_at(newact, FRAME, 'left')
        step("D6 ★★ 复用旧名不继承旧记录（新 action 必须读成「未记录」）",
             v4 is None,
             "复用名 %r 的新 action 查询=%r（期望 None）" % (old, v4))
        step("D6 复用后旧名残留条目被清掉（对账生效）",
             not [k for k in xf._FEEL if k[0] == old],
             "旧名剩余内存条目=%s" % sorted([str(k) for k in xf._FEEL if k[0] == old]))
    except Exception:
        step("FATAL D6", False, E.tb())


def case_D7():
    """D7 action.copy() 后表是否被误继承。"""
    try:
        o, act = fresh("EB_D7")
        act.name = "EB_D7_Act"
        kp = kp_at(o, act)
        xf.mark_feel(kp, 'left', 'FREE')
        xf.set_tri_locked(act, FRAME, False)
        td.mark_frozen(act, FRAME)
        cp = act.copy()
        cp.name = "EB_D7_Copy"
        inherited = props_of(cp)
        step("D7 NOTE action.copy() 会连 rtmp_* property 一起复制（Blender 语义）",
             True,
             "副本 property=%s（关键帧也一起复制了，所以记录与几何自洽）"
             % json.dumps(inherited, ensure_ascii=False))
        v1 = xf.feel_type_at(cp, FRAME, 'left')
        v2 = xf.is_tri_locked(cp, FRAME)
        v3 = td.is_frozen(cp, FRAME)
        step("D7 副本的账本自洽（读回来 = 复制过去的值，且与自身 property 一致）",
             v1 == 'FREE' and v2 is False and v3 is True
             and not clean(cp, o),
             "副本 feel=%s trilock=%s frozen=%s | 账本=%s"
             % (v1, v2, v3, clean(cp, o) or "干净"))
        # 改副本不得影响原件（反向也一样）
        xf.mark_feel_at(cp, FRAME, 'left', 'LINK')
        xf.set_tri_locked(cp, FRAME, True)
        td.unmark_frozen(cp, FRAME)
        orig_v = (xf.feel_type_at(act, FRAME, 'left'), xf.is_tri_locked(act, FRAME),
                  td.is_frozen(act, FRAME))
        step("D7 ★★ 改副本不影响原件（键含 action 名，两边独立）",
             orig_v == ('FREE', False, True) and not clean(act, o) and not clean(cp, o),
             "改副本后原件=(feel=%s, trilock=%s, frozen=%s)（期望 FREE/False/True）"
             % orig_v)
    except Exception:
        step("FATAL D7", False, E.tb())


def case_D8():
    """D8 表里有指向已删关键帧的僵尸词条时的行为。"""
    try:
        o, act = fresh("EB_D8")
        act.name = "EB_D8_Act"
        xf.mark_feel_at(act, FRAME, 'left', 'FREE')
        xf.set_tri_locked(act, FRAME, False)
        td.mark_frozen(act, FRAME)
        for fc in xf._position_curves(act, o, None):
            for kp in list(fc.keyframe_points):
                if abs(float(kp.co[0]) - FRAME) < 1e-3:
                    fc.keyframe_points.remove(kp)
            fc.update()
        frames_now = sorted({round(float(kp.co[0]), 4)
                             for fc in xf._position_curves(act, o, None)
                             for kp in fc.keyframe_points})
        prop_after = props_of(act)
        zombie = xf.feel_type_at(act, FRAME, 'left')
        bad = clean(act, o)
        step("D8 ★★ 静默残留：关键帧被删后，指向它的记录必须失效",
             zombie is None,
             "剩余帧=%s；删帧后 feel_type_at(%g)=%r（期望 None）；property=%s"
             % (frames_now, FRAME, zombie, json.dumps(prop_after, ensure_ascii=False)))
        step("D8 ★ 僵尸词条未随删帧清理（静默残留，且账本自洽 => 不会被对账发现）",
             not bad,
             "账本检查=%s（说明「内存 vs property」是一致的，但两者都指向一个不存在的帧）"
             % (bad or "干净"))
        # 再插一个同帧关键帧 => 旧记录会不会自动套上去
        kp_new = None
        for fc in xf._position_curves(act, o, None):
            kp_new = fc.keyframe_points.insert(FRAME, 1.0)
            fc.update()
            break
        kp_new = kp_at(o, act)
        v = xf.feel_type(kp_new, 'left') if kp_new is not None else None
        step("D8 ★★ 静默继承：同帧重新插关键帧时，旧记录自动套上去",
             v is None,
             "重新插入 f=%g 的新关键帧（手柄类型=%s）后 feel=%r（期望 None）"
             % (FRAME, getattr(kp_new, 'handle_left_type', '?'), v))
    except Exception:
        step("FATAL D8", False, E.tb())


def case_D9():
    """D9 undo_guard.clear_all_state_caches() 之后表能否 warm 回来。"""
    try:
        o, act = fresh("EB_D9")
        act.name = "EB_D9_Act"
        kp = kp_at(o, act)
        xf.set_tri_locked(act, FRAME, False)
        xf.mark_owned_free(kp, 'left')      # ⚠️ 无条件写 feel=LINK，先做
        xf.mark_feel(kp, 'left', 'FREE')    # 再覆盖成用户要的 FREE
        xf.mark_feel(kp, 'right', 'LINK')
        td.mark_frozen(act, FRAME)
        before = props_of(act)
        cleared = ug.clear_all_state_caches()
        mem_empty = (len(xf._FEEL) == 0 and len(xf._TRILOCK) == 0
                     and len(xf._plugin_owned_free) == 0 and len(td._FROZEN) == 0)
        step("D9 clear_all_state_caches 清空四张内存表（property 一个字不动）",
             mem_empty and cleared == ["tri_lock", "feel", "owned_free", "frozen"],
             "cleared=%s mem=(%d,%d,%d,%d)" % (cleared, len(xf._FEEL), len(xf._TRILOCK),
                                               len(xf._plugin_owned_free), len(td._FROZEN)))
        step("D9 清缓存不丢数据：property 与清之前逐条相同",
             props_of(act) == before, json.dumps(props_of(act), ensure_ascii=False))
        v = (xf.feel_type_at(act, FRAME, 'left'), xf.feel_type_at(act, FRAME, 'right'),
             xf.is_tri_locked(act, FRAME), td.is_frozen(act, FRAME),
             xf._is_plugin_owned_free(kp, 'left'))
        bad = clean(act, o)
        step("D9 ★★★ 惰性 warm 回来：五条查询全部恢复且账本干净",
             v == ('FREE', 'LINK', False, True, True) and not bad,
             "warm 后 (feelL, feelR, trilock, frozen, owned)=(%s) | 账本=%s"
             % (", ".join(str(x) for x in v), bad or "干净"))
    except Exception:
        step("FATAL D9", False, E.tb())


# ===========================================================================
# C 组
# ===========================================================================

def case_C1():
    """C1 多对象共享一个 action。"""
    try:
        o1, act = fresh("EB_C1a")
        act.name = "EB_C1_Act"
        bpy.ops.mesh.primitive_cube_add()
        o2 = bpy.context.view_layer.objects.active
        o2.name = "EB_C1b"
        o2.animation_data_create()
        o2.animation_data.action = act
        kfm, span = td.resolve_target(act, o2, FRAME, 'right')
        step("C1 共享后第二个对象也能解析到三轴目标与段长",
             sorted(kfm.keys()) == [0, 1, 2] and span == 27.0,
             "axes=%s span=%s slot=%r" % (sorted(kfm.keys()), span,
                                          getattr(o2.animation_data.action_slot, "identifier", None)))
        w = td.write_s(kfm, 'right', 0.5, span, freeze=True, act=act, obj=o2)
        for ax, kp in kfm.items():
            fc = td.fcurve_of(act, o2, ax, None)
            if fc:
                fc.update()
        d1 = dts_of(o2, act)
        d2 = dts_of(o1, act)
        dt1 = sorted(d1.values())
        dt2 = sorted(d2.values())
        bad = clean(act, o1) + clean(act, o2)
        step("C1 ★ 通过 o2 写入后，o1 看到的同一份曲线同步变化（共享即同一份数据）",
             w == 0.5 and dt1 == dt2 and abs(dt1[0] - dt1[-1]) < 1e-9,
             "write_s=%s 通过 o2 的 dt=%s / 通过 o1 的 dt=%s | 不变量=%s"
             % (w, [round(x, 4) for x in dt1], [round(x, 4) for x in dt2], bad or "干净"))
        step("C1 共享场景下 freeze 登记只按 (action, 帧)，两个对象看到同一条登记（设计如此）",
             td.is_frozen(act, FRAME) is True,
             "is_frozen(act, %g)=%s" % (FRAME, td.is_frozen(act, FRAME)))
    except Exception:
        step("FATAL C1", False, E.tb())


def case_C2():
    """C2 一个对象多个 action slot。"""
    try:
        o1, act = fresh("EB_C2a")
        act.name = "EB_C2_Act"
        base = len(xf._position_curves(act, o1, None))
        sB = act.slots.new(id_type='OBJECT', name="EB_C2_SlotB")
        o1.animation_data.action_slot = sB
        n_empty = len(xf._position_curves(act, o1, None))
        cb = act.layers[0].strips[0].channelbag(sB, ensure=True)
        fcB = cb.fcurves.new("location", index=2)
        for f, v in ((0.0, 0.0), (FRAME, 4.0), (117.0, 8.0)):
            fcB.keyframe_points.insert(f, v)
        fcB.update()
        n_b = sorted(c.array_index for c in xf._position_curves(act, o1, None))
        o1.animation_data.action_slot = act.slots[0]
        n_a = sorted(c.array_index for c in xf._position_curves(act, o1, None))
        step("C2 ★★ 曲线收集严格按对象的 action_slot 分流（slot 之间不串几何）",
             base == 3 and n_empty == 0 and n_b == [2] and n_a == [0, 1, 2],
             "slotA=%d 条；切到空 slotB=%d 条；slotB 加 1 条后=%s；切回 slotA=%s"
             % (base, n_empty, n_b, n_a))
        o1.animation_data.action_slot = sB
        kfm, span = td.resolve_target(act, o1, FRAME, 'right')
        step("C2 单轴 slot 的 resolve_target 只拿到 1 个轴（三轴同步在此天然不成立）",
             sorted(kfm.keys()) == [2],
             "axes=%s span=%s（单轴 slot 是合法数据；插件只写它有的轴）"
             % (sorted(kfm.keys()), span))
        bad = clean(act, o1)
        step("C2 slot 切换后不变量/账本干净", not bad, "; ".join(bad) or "干净")
        o1.animation_data.action_slot = act.slots[0]
    except Exception:
        step("FATAL C2", False, E.tb())


def case_C3():
    """C3 分层动作：多层 / 多 strip。"""
    try:
        o, act = fresh("EB_C3")
        act.name = "EB_C3_Act"
        R = {}
        try:
            act.layers.new("Layer2")
            R["layer2"] = "ok"
        except Exception as exc:
            R["layer2"] = "REFUSED: " + str(exc).strip()[:70]
        try:
            act.layers[0].strips.new(type='KEYFRAME')
            R["strip2"] = "ok"
        except Exception as exc:
            R["strip2"] = "REFUSED: " + str(exc).strip()[:70]
        step("C3 NOTE Blender 5.2 结构上限：一个 action 只能 1 layer / 1 layer 只能 1 strip",
             R["layer2"] != "ok" and R["strip2"] != "ok",
             "layers.new -> %s | strips.new -> %s" % (R["layer2"], R["strip2"]))
        n = len(xf._position_curves(act, o, None))
        kfm, span = td.resolve_target(act, o, FRAME, 'right')
        bad = clean(act, o)
        step("C3 单层单 strip 下（cache 写死 layers[0].strips[0]）收集与解析正常",
             n == 3 and len(kfm) == 3 and span == 27.0 and not bad,
             "layers=%d strips=%d 曲线=%d axes=%s span=%s 账本=%s"
             % (len(act.layers), len(act.layers[0].strips), n, sorted(kfm.keys()),
                span, bad or "干净"))
    except Exception:
        step("FATAL C3", False, E.tb())


def case_C4():
    """C4 action 无 slot / slot 不匹配。"""
    try:
        o, act = fresh("EB_C4")
        empty = bpy.data.actions.new("EB_C4_Empty")
        step("C4 空 action（无 slot）=> 曲线收集 0 条、不抛异常",
             len(empty.slots) == 0 and xf._position_curves(empty, o, None) == [],
             "slots=%d curves=%d" % (len(empty.slots), len(xf._position_curves(empty, o, None))))
        kfm, span = td.resolve_target(empty, o, FRAME, 'right')
        res = td.apply_pixel_drag(empty, o, FRAME, 'right', 40.0)
        step("C4 ★ 空 action 的编辑入口必须【明确失败】（ok=False + 有提示文案）",
             kfm == {} and span is None and res.get("ok") is False and res.get("message"),
             "resolve=(%s, %s) apply_pixel_drag=%s" % (kfm, span,
                                                       {k: res[k] for k in ('ok', 's', 'message')}))
        # slot 不匹配：o 的 slot 属于另一个 action
        o2, act2 = fresh("EB_C4b")
        kfm2, span2 = td.resolve_target(act, o2, FRAME, 'right')
        step("C4 slot 不匹配（对象绑的是别的 action）时按被查 action 的 slots[0] 兜底，不崩",
             len(kfm2) == 3 and span2 == 27.0,
             "用 act 查 o2：axes=%s span=%s" % (sorted(kfm2.keys()), span2))
        n_act_none = len(xf._position_curves(None, o, None))
        n_obj_none = len(xf._position_curves(act, None, None))
        r_act_none = td.resolve_target(None, o, FRAME, 'right')
        step("C4 action=None / obj=None 的边界都不抛异常，且返回口径可解释",
             n_act_none == 0 and r_act_none == ({}, None),
             "action=None 曲线=%d resolve=%s；obj=None 曲线=%d"
             "（物体级 location 曲线不依赖 obj 也能取到，属实测口径）"
             % (n_act_none, r_act_none, n_obj_none))
    except Exception:
        step("FATAL C4", False, E.tb())


def case_C5():
    """C5 骨骼（POSE）x 边界。"""
    try:
        E.clear_scene()
        reset_tables()
        # 双骨骼骨架，两根骨骼在【同一帧】都有关键帧
        bpy.ops.object.armature_add(location=(0, 0, 0))
        arm = bpy.context.view_layer.objects.active
        arm.name = "EB_C5_Arm"
        bpy.ops.object.mode_set(mode='EDIT')
        eb = arm.data.edit_bones
        eb[0].name = "EB_BoneA"
        b2 = eb.new("EB_BoneB")
        b2.head = (0.0, 0.0, 2.0)
        b2.tail = (0.0, 0.0, 3.0)
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='POSE')
        pa = arm.pose.bones["EB_BoneA"]
        pb = arm.pose.bones["EB_BoneB"]
        for f, v in ((0, (0.0, 0.0, 0.0)), (90, (1.0, 2.0, 0.5)), (117, (2.0, 3.0, 1.0))):
            bpy.context.scene.frame_set(int(f))
            pa.location = v
            pa.keyframe_insert("location", frame=int(f))
            pb.location = (v[0] * 2.0, v[1], v[2])
            pb.keyframe_insert("location", frame=int(f))
        bpy.ops.object.mode_set(mode='OBJECT')
        act = arm.animation_data.action
        act.name = "EB_C5_Act"
        nA = len(xf._position_curves(act, arm, "EB_BoneA"))
        nB = len(xf._position_curves(act, arm, "EB_BoneB"))
        nN = len(xf._position_curves(act, arm, None))
        step("C5 ★ 曲线按骨骼名分流：bone_name 不给就一条都拿不到（不是全给）",
             nA == 3 and nB == 3 and nN == 0,
             "BoneA=%d BoneB=%d bone_name=None=%d（pose action 共 6 条曲线）" % (nA, nB, nN))
        kfm, span = td.resolve_target(act, arm, FRAME, 'right', bone_name="EB_BoneA")
        kfmN, spanN = td.resolve_target(act, arm, FRAME, 'right', bone_name=None)
        step("C5 骨骼路径的 resolve_target 正常；bone_name=None 时明确返回空（不崩）",
             sorted(kfm.keys()) == [0, 1, 2] and span == 27.0 and kfmN == {} and spanN is None,
             "BoneA axes=%s span=%s | None=(%s, %s)"
             % (sorted(kfm.keys()), span, kfmN, spanN))
        kpA = kp_at(arm, act, FRAME, "EB_BoneA")
        kpB = kp_at(arm, act, FRAME, "EB_BoneB")
        ok_setup = kpA is not None and kpB is not None
        xf.mark_feel(kpA, 'left', 'LINK')
        a_before = xf.feel_type(kpA, 'left')
        xf.mark_feel(kpB, 'left', 'FREE')
        a_after = xf.feel_type(kpA, 'left')
        xf.mark_owned_free(kpB, 'left')
        ownA = xf._is_plugin_owned_free(kpA, 'left')
        prop = sorted(act.get("rtmp_feel") or [])
        step("C5 ★★★ 两根骨骼同帧的账本必须分开（键缺骨骼名 => 串到别的骨头身上）",
             ok_setup and a_after == 'LINK',
             "构造成功=%s；BoneA 记 LINK 后=%s，给 BoneB 记 FREE 后 BoneA 读回=%s"
             "（期望 LINK，实际串成 %s）；property=%s"
             % (ok_setup, a_before, a_after, a_after, prop))
        step("C5 ★★ 骨骼 B 的接管登记不得让骨骼 A 的手柄变成「插件接管」",
             ownA is False,
             "对 BoneB 调 mark_owned_free 后，BoneA 的 _is_plugin_owned_free=%s（期望 False）"
             % ownA)
        bad = clean(act, arm, "EB_BoneA") + clean(act, arm, "EB_BoneB")
        step("C5 串扰下不变量与账本仍「一致地错」（对账查不出来）",
             not bad, "; ".join(bad) or "干净")
    except Exception:
        step("FATAL C5", False, E.tb())


def case_C6():
    """C6 曲线挂 driver。"""
    try:
        o, act = fresh("EB_C6")
        act.name = "EB_C6_Act"
        before = sorted(c.array_index for c in xf._position_curves(act, o, None))
        drv = o.driver_add("location", 0)
        after = sorted(c.array_index for c in xf._position_curves(act, o, None))
        n_drv = len(o.animation_data.drivers)
        kfm, span = td.resolve_target(act, o, FRAME, 'right')
        w = td.write_s(kfm, 'right', 0.5, span, freeze=False)
        for fc in xf._position_curves(act, o, None):
            fc.update()
        dd = dts_of(o, act)
        dt = sorted(dd.values())
        bad = clean(act, o)
        step("C6 挂 driver 后曲线收集/解析/写入都不受影响，不变量成立",
             before == after == [0, 1, 2] and len(kfm) == 3 and w == 0.5
             and (max(dt) - min(dt)) < 1e-9 and not bad,
             "axes=%s->%s driver 条数=%d write_s=%s 现取 dt(按轴)=%s 不变量=%s"
             % (before, after, n_drv, w,
                {k: round(v, 4) for k, v in sorted(dd.items())}, bad or "干净"))
        step("C6 NOTE driver 落在 ad.drivers（不是 action 的 channelbag），插件看不到它",
             type(drv).__name__ == 'FCurve' and n_drv == 1,
             "driver_add 返回 %s；ad.drivers=%d。action 里 location[0] 仍是普通关键帧曲线"
             "（%d 个关键帧）=> 被驱动的那一轴，插件改的是「Blender 求值时不看」的那份。"
             % (type(drv).__name__, n_drv, len([c for c in xf._position_curves(act, o, None)
                                                if c.array_index == 0][0].keyframe_points)))
    except Exception:
        step("FATAL C6", False, E.tb())


def case_C8():
    """C8 对象挂约束（路径 vs 约束）。"""
    try:
        o, act = fresh("EB_C8")
        act.name = "EB_C8_Act"
        bpy.ops.mesh.primitive_cube_add()
        tgt = bpy.context.view_layer.objects.active
        tgt.name = "EB_C8_Target"
        tgt.location = (10.0, 10.0, 10.0)
        con = o.constraints.new('COPY_LOCATION')
        con.target = tgt
        bpy.context.view_layer.update()
        world = tuple(round(float(v), 4) for v in o.matrix_world.translation)
        local = tuple(round(float(kp.co[1]), 4) for kp in
                      [xf.keyframe_at(fc, FRAME) for fc in xf._position_curves(act, o, None)
                       if xf.keyframe_at(fc, FRAME) is not None])
        kfm, span = td.resolve_target(act, o, FRAME, 'right')
        w = td.write_s(kfm, 'right', 0.5, span, freeze=True, act=act, obj=o)
        for fc in xf._position_curves(act, o, None):
            fc.update()
        bad = clean(act, o)
        step("C8 挂约束后曲线访问 / 解析 / 写入照常，不变量成立",
             len(kfm) == 3 and w == 0.5 and not bad,
             "axes=%s span=%s write_s=%s 约束=%s 账本=%s"
             % (sorted(kfm.keys()), span, w, con.type, bad or "干净"))
        step("C8 NOTE 约束生效后物体世界位置 ≠ 关键帧局部值（路径画的是关键帧那份）",
             True,
             "f=%g 关键帧局部值=%s；约束求值后 matrix_world.translation=%s。"
             "插件路径用【父级矩阵 x 局部值】画（不含自身 transform/约束），"
             "所以约束驱动的位移不会体现在路径上（与原生运动路径同口径）。"
             % (FRAME, local, world))
        step("C8 约束对象上 mark_feel 落账正常、账本干净",
             (xf.mark_feel_at(act, FRAME, 'left', 'FREE'),
              xf.feel_type_at(act, FRAME, 'left') == 'FREE',
              not clean(act, o)) == (True, True, True),
             "feel=%s" % xf.feel_type_at(act, FRAME, 'left'))
    except Exception:
        step("FATAL C8", False, E.tb())


def case_C7():
    """C7 库链接（linked）action 的写入路径（放最后：会 open_mainfile 换掉整个场景）。"""
    src = os.path.join(TMP, "_eb_state_lib.blend")
    local = os.path.join(TMP, "_eb_state_lib_local.blend")
    try:
        # ① 造一个源库文件（含一个带 rtmp_feel 的 action）
        E.clear_scene()
        reset_tables()
        o0, act0 = E.build_object("EB_C7_Src", E.KEYS_3)
        act0.name = "EB_C7_LibAction"
        act0["rtmp_feel"] = ["%.4f|left|LINK|" % FRAME]     # 4 段（D-1/D-2）
        bpy.ops.wm.save_as_mainfile(filepath=src)
        step("C7 前提：造出源库 .blend（系统临时目录）", os.path.isfile(src), src)

        bpy.ops.wm.read_factory_settings(use_empty=True)
        bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
        reset_tables()
        with bpy.data.libraries.load(src, link=True) as (df, dt):
            names = list(df.actions)
            dt.actions = ["EB_C7_LibAction"]
        act = bpy.data.actions.get("EB_C7_LibAction")
        step("C7 前提：action 确实来自库链接（library 非空）",
             act is not None and bool(getattr(act, "library", None)),
             "df.actions=%s library=%s" % (names,
                                           getattr(getattr(act, "library", None), "filepath", None)))
        if act is None:
            return
        bpy.ops.mesh.primitive_cube_add()
        o = bpy.context.view_layer.objects.active
        o.name = "EB_C7_User"
        o.animation_data_create()
        o.animation_data.action = act
        if o.animation_data.action_slot is None and len(act.slots):
            o.animation_data.action_slot = act.slots[0]
        n = len(xf._position_curves(act, o, None))

        # ② 写入路径：会不会明确失败？还是静默？
        writes = {}
        try:
            act["rtmp_feel"] = ["%.4f|left|FREE|" % FRAME]      # 4 段（D-1/D-2）
            writes["prop"] = "in-memory OK -> %s" % sorted(act.get("rtmp_feel") or [])
        except Exception as exc:
            writes["prop"] = "EXC " + repr(exc)[:90]
        kfm, span = td.resolve_target(act, o, FRAME, 'right')
        try:
            writes["write_s"] = td.write_s(kfm, 'right', 0.5, span, freeze=True, act=act, obj=o)
        except Exception as exc:
            writes["write_s"] = "EXC " + repr(exc)[:90]
        res = td.apply_pixel_drag(act, o, FRAME, 'right', 40.0)
        writes["apply_pixel_drag"] = {k: res[k] for k in ('ok', 's', 'message')}
        step("C7 ★ 库链接 action 的写入：实测 Blender 5.2 允许内存改写（不抛异常）",
             n == 3 and writes["write_s"] == 0.5,
             "曲线=%d；property 写=%s；write_s=%s；apply_pixel_drag=%s"
             % (n, writes["prop"], writes["write_s"],
                json.dumps(writes["apply_pixel_drag"], ensure_ascii=False)))
        v_in = xf.feel_type_at(act, FRAME, 'left')
        bad = clean(act, o)
        step("C7 库链接写入后账本自洽（内存 vs property 一致）",
             v_in == 'FREE' and not bad,
             "feel=%s 账本=%s" % (v_in, bad or "干净"))

        # ③ 存本地 + 重开：库数据从源文件重读 => 改写被静默丢弃
        bpy.ops.wm.save_as_mainfile(filepath=local)
        bpy.ops.wm.open_mainfile(filepath=local)
        act2 = bpy.data.actions.get("EB_C7_LibAction")
        prop2 = sorted([str(x) for x in (act2.get("rtmp_feel") or [])]) if act2 else None
        v_out = xf.feel_type_at(act2, FRAME, 'left') if act2 else None
        o2 = bpy.data.objects.get("EB_C7_User")
        bad2 = clean(act2, o2) if (act2 and o2) else ["对象/action 丢失"]
        step("C7 NOTE 库链接 action 的改写不落盘：重开后 property 回到源库的值",
             v_out == 'LINK',
             "重开后 rtmp_feel=%s（写过的 FREE 没了，回到源库的 LINK）；查询=%s；账本=%s"
             % (prop2, v_out, bad2 or "干净"))
        step("C7 ★★ 重开后内存表按回退后的 property 重建（不留旧 FREE 幽灵）",
             not bad2 and v_out == 'LINK',
             "账本=%s；feel 查询=%s（期望 LINK）" % (bad2 or "干净", v_out))
    except Exception:
        step("FATAL C7", False, E.tb())


# ===========================================================================
# 主流程
# ===========================================================================

for fn in (case_D1, case_D2, case_D3, case_D4, case_D5, case_D6, case_D7, case_D8,
           case_D9, case_C1, case_C2, case_C3, case_C4, case_C5, case_C6, case_C8,
           case_C7):
    try:
        fn()
    except Exception:
        step("FATAL " + fn.__name__, False, E.tb())

try:
    data = E.flush(LOG, steps)
except Exception:
    print("FLUSH FAILED: " + E.tb())
    raise


# ---------------------------------------------------------------------------
# 显式分级：地基的 suspects 只按【用例名里的关键词】猜，口径太糙。
# 这里给死判定：违反不变量/规范的算 FAIL，静默/状态不一致的算 SUSPECT。
# ---------------------------------------------------------------------------
_SEV_RULES = (
    ("关键帧模态", "FAIL"),     # 静默抹掉用户显式设置（口径违反插件自己的规范）
    ("串", "FAIL"),            # 表键撞车 => 跨对象/跨骨骼/跨 slot 污染
    ("slot", "FAIL"),
    ("骨骼", "FAIL"),
    ("静默", "SUSPECT"),
    ("僵尸", "SUSPECT"),
    ("幽灵", "SUSPECT"),
)


def _severity(name):
    for key, sev in _SEV_RULES:
        if key in name:
            return sev
    return "FAIL"


try:
    with open(LOG, encoding="utf-8") as fh:
        data = json.load(fh)
    tally = {"FAIL": 0, "SUSPECT": 0}
    for s in data["steps"]:
        if not s["ok"]:
            s["severity"] = _severity(s["name"])
            tally[s["severity"]] += 1
    data["severity_summary"] = tally
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())
    print("显式分级：FAIL(真 bug)=%d  SUSPECT(可疑)=%d" % (tally["FAIL"], tally["SUSPECT"]))
except Exception:
    print("分级追加失败: " + E.tb(300))

print("EB_STATE_DONE")
