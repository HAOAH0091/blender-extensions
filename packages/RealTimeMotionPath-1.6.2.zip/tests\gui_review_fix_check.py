# -*- coding: utf-8 -*-
"""Phase 0 Review 修复的回归测试（2026-09-30）。

来源：`tests/REVIEW_FINDINGS.md`。五条修复各钉一条：

  P1-1  双击锁定被钳制（`clamped`）时，文案必须**带上真实倍数**（不能再说"已一致"）
  P1-2  spec 校正的**阶段异常**（`applied[kind] == -1`）必须报 ERROR
  P1-3  `frozen`（顺手冻结的手柄数）必须提示用户
  P2-1  `write_s` 写入中途失败必须**回滚**（不留"半写" ⇒ 三轴 dt 仍一致）
  P2-3  `feel_for_orig_type` 文档不得再声称"与 `orig_type_for_feel` 互逆"

用法：blender --background --factory-startup --python tests/gui_review_fix_check.py
"""
import bpy, os, sys, json, inspect, traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_rf_result.json")
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})
def flush():
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps), "fails": sum(1 for s in steps if not s["ok"]),
                   "result": "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES",
                   "steps": steps}, fh, ensure_ascii=False, indent=1)
        fh.flush(); os.fsync(fh.fileno())

try:
    import RealTimeMotionPath as RTMP
    from RealTimeMotionPath import transform_domain as xf
    from RealTimeMotionPath import time_domain as td
    from RealTimeMotionPath import interaction as it
    from RealTimeMotionPath import handles as hd
    from RealTimeMotionPath import spec_ui as su
    from RealTimeMotionPath import spec_check as sc
    from bpy.app.translations import pgettext_iface as iface_
    try:
        bpy.context.preferences.view.language = 'zh_HANS'
    except Exception:
        pass

    def curves(o):
        return {c.array_index: c for c in xf._position_curves(o.animation_data.action, o, None)}

    def vv(o, act, sd, fr=90):
        kfm, span = td.resolve_target(act, o, fr, sd)
        mags, dvs = [], []
        for ax, kp in kfm.items():
            h = kp.handle_left if sd == 'left' else kp.handle_right
            mags.append(abs(float(h[0]) - float(kp.co[0])))
            dvs.append(float(h[1]) - float(kp.co[1]))
        dt = sorted(mags)[len(mags) // 2]
        n = sum(x * x for x in dvs) ** 0.5
        return dt, n, (n / dt if dt > 1e-9 else 0.0), span

    def build(name, dvL=1.0, dvR=10.0, sL=0.5, sR=0.5):
        o = bpy.data.objects.get(name)
        if o:
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        o = bpy.context.view_layer.objects.active
        o.name = name
        for f, v in ((0, (0, 0, 0)), (90, (1.0, 2.56, 0.4)), (117, (3.0, 6.0, 1.2))):
            bpy.context.scene.frame_set(int(f))
            o.location = v
            o.keyframe_insert("location", frame=int(f))
        bpy.context.scene.frame_set(90)
        act = o.animation_data.action
        for fc in curves(o).values():
            for kp in fc.keyframe_points:
                if abs(float(kp.co[0]) - 90) < 1e-3:
                    kp.handle_left_type = 'FREE'
                    kp.handle_right_type = 'FREE'
                    kp.handle_left = (kp.co[0] - 90.0 * sL, kp.co[1] - dvL)
                    kp.handle_right = (kp.co[0] + 27.0 * sR, kp.co[1] + dvR)
            fc.update()
        return o, act

    # ---------------- A 组：P1-1 钳制文案 ----------------
    o, act = build("_RF_A")
    try:
        xf.set_tri_locked(act, 90, False)
    except Exception:
        pass
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_UP, None)
    info = info or {}
    _, _, vL2, _ = vv(o, act, 'left')
    _, _, vR2, _ = vv(o, act, 'right')
    ratio = max(vL2, vR2) / max(1e-12, min(vL2, vR2))
    step("A1 ★ 构造出 clamped 场景（dv/span 两侧严重不等 ⇒ 对侧被钳到 S_HARD_MAX）",
         ok and info.get("clamped") is True,
         "clamped=%s ratio=%.2f 需要 s=%.4f" % (info.get("clamped"), ratio,
                                                (info.get("dt") or [0, 0])[1] and 0 or 0))
    KEY = ("Handles locked together - opposite handle hit its limit, "
           "speeds NOT fully equal (%.2fx apart)")
    msg = iface_(KEY) % ratio
    step("A2 ★★★ 钳制文案**带上真实倍数**（旧文案无条件说「已一致」⇒ 说谎）",
         ("%.2f" % ratio) in msg and ratio > 1.5,
         "文案=%s" % msg)
    src_it = inspect.getsource(it.toggle_frame_lock)
    step("A3 ★ 源码里 clamped 分支确实存在（防回归：别改回无条件文案）",
         "clamped" in src_it and "hit its limit" in src_it,
         "clamped 出现 %d 次" % src_it.count("clamped"))

    # ---------------- B 组：P1-2 / P1-3 UI 必须显示 ----------------
    src_ui = inspect.getsource(su.RTMP_OT_SpecFix.execute)
    step("B1 ★★ spec_ui 读 `applied`（阶段异常 -1 必须报 ERROR）",
         "applied" in src_ui and "-1" in src_ui,
         "applied=%d 次, 有 -1 判定=%s" % (src_ui.count("applied"), "-1" in src_ui))
    step("B2 ★★ spec_ui 读 `frozen`（顺手冻结的手柄数必须提示）",
         "frozen" in src_ui,
         "frozen=%d 次" % src_ui.count("frozen"))

    # 行为验证：打桩 apply_fix，捕获 report
    _orig = sc.apply_fix
    _reports = []
    try:
        sc.apply_fix = lambda *a, **k: ({"applied": {"handle_bend": -1}, "frozen": 3,
                                         "after": {"issues": []}}, None)
        # ⚠️ `bpy_struct` 不能直接实例化（`object.__new__` / `cls()` 都抛
        #    "not safe / expected a single argument"）⇒ 用**假 self** 直接调
        #    `execute` 本体：它只用到 `_report / do_force_align / do_ignore / report`
        #    四个属性，传个鸭子对象即可（比 source 级断言强，能真跑分支）。
        class _FakeOp(object):
            _report = {"issues": [{"kind": "handle_bend", "frame": 90}]}
            do_force_align = False
            do_ignore = False
            reports = []

            def report(self, kind, m):
                self.reports.append((sorted(kind)[0], m))

        fake = _FakeOp()
        o2, act2 = build("_RF_B")
        bpy.context.view_layer.objects.active = o2
        try:
            su.RTMP_OT_SpecFix.execute(fake, bpy.context)
        except Exception as exc:
            _reports.append(("EXC", repr(exc)))
        _reports.extend(fake.reports)
    finally:
        sc.apply_fix = _orig
    _txt = " | ".join("%s:%s" % (k, m) for k, m in _reports)
    step("B3 ★★★ 阶段异常时报 **ERROR**（不能报「已修好」）",
         any(k == "ERROR" for k, _ in _reports),
         "reports=%s" % _txt[:220])
    step("B4 ★★★ frozen>0 时**有提示**",
         any("froze" in str(m) or "冻结" in str(m) for _, m in _reports),
         "reports=%s" % _txt[:220])

    # ---------------- C 组：P2-1 写入回滚 ----------------
    o3, act3 = build("_RF_C")
    kfm, span = td.resolve_target(act3, o3, 90, 'right')
    before = sorted(abs(float(kp.handle_right[0]) - float(kp.co[0])) for kp in kfm.values())

    class _Bad(object):
        """第 2 个轴：赋值必抛（模拟只读的库链接 action）。"""
        def __init__(self, kp):
            self._kp = kp
            self.co = kp.co
        @property
        def handle_right(self):
            return self._kp.handle_right
        @handle_right.setter
        def handle_right(self, v):
            raise RuntimeError("simulated read-only")
        @property
        def handle_left(self):
            return self._kp.handle_left
        @handle_left.setter
        def handle_left(self, v):
            self._kp.handle_left = v

    bad_map = {}
    for i, (ax, kp) in enumerate(sorted(kfm.items())):
        bad_map[ax] = _Bad(kp) if i == 1 else kp
    w = td.write_s(bad_map, 'right', 0.9, span, freeze=False)
    for fc in curves(o3).values():
        fc.update()
    after = sorted(abs(float(kp.handle_right[0]) - float(kp.co[0])) for kp in kfm.values())
    step("C1 ★★ write_s 中途失败返回 None（按「未写」处理）", w is None, "返回=%r" % (w,))
    step("C2 ★★★ 已写的轴被**回滚**（不留半写）",
         all(abs(a - b) < 1e-6 for a, b in zip(after, before)),
         "写前=%s 写后=%s" % ([round(x, 4) for x in before], [round(x, 4) for x in after]))
    step("C3 ★★★ 回滚后**三轴 dt 仍一致**（规范未破）",
         abs(after[0] - after[-1]) < 1e-6,
         "dt 跨度=%.2e" % (max(after) - min(after)))

    # ---------------- D 组：P2-3 文档准确性 ----------------
    doc = xf.feel_for_orig_type.__doc__ or ""
    step("D1 ★ 文档不再声称「与 orig_type_for_feel 互逆」",
         "互逆" not in doc or "不是" in doc,
         doc.strip().split("\n")[0][:70])
    step("D2 ★ 仍说明 FREE 返回 None 是故意的",
         "None" in doc and "故意" in doc,
         "含 None=%s 含 故意=%s" % ("None" in doc, "故意" in doc))

except Exception:
    step("FATAL", False, traceback.format_exc()[-1200:])

flush()
print("REVIEW_FIX_DONE")
