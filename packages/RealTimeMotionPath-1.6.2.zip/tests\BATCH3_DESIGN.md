# Batch 3 设计书 —— 四张账本表的键加「骨骼名 + slot」

> 对应发现清单 **D-1【高】**（键不含骨骼名）与 **D-2【高】**（键不含 slot）。
> 生成：2026-10-01 ｜ 前置：Batch 2 已提交（`9b022dc`）。
> **本文档只做设计，尚未动产品代码** —— 用户要求「先设计 token 与旧文件兼容方案再动手」。

---

## 0. 三十秒速览

- **问题**：四张持久化账本的键是 `(action 名, 帧号, 侧)`，**没有「这根手柄属于谁」**。
  一个角色 action 里所有骨骼的曲线**共用一个 action** ⇒ 同帧同侧**必然撞键**。
- **硬约束**：Blender 的 `Keyframe` **没有**指回 F-Curve 的入口（实测 + 官方 API 文档双向确认）。
  所以「这根手柄是谁的」只能**由调用方告诉账本**，或者**自己反查**。
- **选型结论**：走「**显式传递**」（调用方把 bone_name / slot 传下去），不走反查。
  理由见 §3（反查要么 O(N) 拖慢拖拽、要么缓存失效会**静默写错账**）。
- **兼容策略**：token 加一段；**旧 token 仍能解析**，语义 = 「对所有 owner 生效」（= 今天的行为）。
  查询**先精确匹配、再回退到旧 token** ⇒ 老工程零迁移、行为不变；
  一旦某个 owner 显式写了，就把那条旧 token **收编**（迁移），避免继续外溢。
- **工作量**：产品代码 ~30 个调用点 + 4 套 token/parse/sync + 2 个测试改写 + 全量回归。

---

## 1. 为什么要做（用户会怎么撞上）

### D-1 · 多骨骼同帧同侧互相串

角色动画里，**一个 action 装着一整套骨架的所有曲线**。
帧 90 上，`BoneA`（大臂）与 `BoneB`（小臂）的左手柄**在同一帧、同一侧** ——
而账本的键是 `(action, 90, 'left')` ⇒ 两条记录**压成一条**。

实测（父 agent 已独立复现）：

    xf.mark_feel(kpA, 'left', 'LINK')     # 大臂：要联动
    xf.mark_feel(kpB, 'left', 'FREE')     # 小臂：用户显式设"不动"
    xf.feel_type(kpA, 'left')   ⇒  'FREE'   ← 期望 'LINK'
    act["rtmp_feel"]            ⇒  ['90.0000|left|FREE']   ← 只剩 1 条

用户视角：**我给大臂设的「不动」被小臂悄悄改掉了**，而且没有任何提示。
更糟的是 `_link_mode` 据此给出**错的联动决策** ⇒ 本该不动的手柄开始跟着动。

打个比方：这是**一栋楼共用一个信箱**（键只有"几楼"，没有"哪一户"）。
  301 的信被塞进 302 的箱子，两人都觉得自己没收到。

### D-2 · 共享 action 的两个 slot 互相串

同一个 action 可以被多个对象绑定，各绑**不同的 slot**（Blender 4.4+ 的 layered action）。
两个 slot 在**同一帧**都有关键帧 ⇒ 又是同一个键。
实测（worker B D5b）：slot A 记 LINK → slot B 记 FREE ⇒ A 读回 FREE，property 只剩 1 条。

### 已经做对的部分（别重复造）

**曲线按骨骼名 / slot 分流早就做对了**：`xf._position_curves(act, obj, bone_name)`
内部走 `cache.collect_animation_curves`，正确解析 `obj.animation_data.action_slot`。
⇒ **只有账本没跟上**。这次要补的就是账本。

---

## 2. 硬约束：Keyframe 反查不到 F-Curve（双向实测确认）

### 2.1 官方 API 文档（本机捆绑，Blender 5.2.2）

`bpy.types.Keyframe` 的全部属性：`amplitude / back / co / co_ui / easing /
handle_left / handle_left_type / handle_right / handle_right_type / interpolation /
period / select_* / type` —— **没有任何 parent / fcurve / group 指针**。
（`kp.id_data` 返回的是 **Action**，不是 F-Curve。）

### 2.2 实测（本次会话跑的探针）

    kp.id_data 类型                    ⇒ 'Action'
    dir(kp) 里含 curve/parent 的成员   ⇒ []（空）
    迭代全部 slot 的 fcurve 可行吗     ⇒ 可行：
        for lay in act.layers: for st in lay.strips: for b in st.channelbags: b.fcurves
    ActionChannelbag 的属性            ⇒ ['fcurves', 'slot', 'slot_handle']
    ActionSlot 的属性                  ⇒ identifier / name_display / handle / target_id_type

### 2.3 slot 身份用什么（实测：存盘重开稳定）

    slot.identifier    'OBSLOTPROBE' / 'OBSlotB'      ← 存盘重开后**逐位一致** ✓
    slot.name_display  'SLOTPROBE'   / 'SlotB'        ← 同上 ✓
    slot.handle        929201142     / 929201143      ← 同上 ✓（但不建议用）

⇒ **用 `identifier`**：它是 Blender **自己**用来把 slot 匹配到 ID 的字段（语义正确），
  而且是字符串、可读、日志/属性里一眼能看懂。`handle` 是内部整数，不做承诺。

---

## 3. 选型：显式传递 vs 自己反查

| | **A · 显式传递**（选它） | **B · 自己反查** |
|---|---|---|
| 做法 | `mark_feel(kp, side, value, bone_name=..., slot=...)`，调用方把 owner 传下去 | `_owner_of(kp)` 扫 action 全部 fcurve，用 `as_pointer()` 找到含这个 kp 的那条，读 `data_path` 拿骨骼名、读 `channelbag.slot` 拿 slot |
| 查找成本 | **O(1)** | **O(总关键帧数)**，或需要缓存 |
| 是否拖慢交互 | 否 | **是**：`_link_mode` 在 `edit_geometry.py:874` 的**鼠标拖拽路径**上，每次 MOUSEMOVE 都调 |
| 缓存失效风险 | 无 | **有**：指针会被复用 ⇒ 缓存命中可能给出**别的 owner** ⇒ **静默写错账**（比现在的"串"更难查） |
| 漏改的后果 | 漏传 owner ⇒ 退化成今天的行为（**可见、可查**） | 反查失败 ⇒ 同样退化，但失败是静默的 |
| 改动面 | ~30 个产品调用点（机械） | 4 个 key 函数 + 一个缓存层 |

**为什么反查的缓存很危险**（值得单独说清）：

  反查的本质是「用内存指针当身份」。而 Blender 的指针**会被复用**：
  删掉一个关键帧、再插一个，新关键帧可能拿到**同一个地址**。
  于是缓存里那条"这个地址属于 BoneA"就变成了**错误事实**，
  而账本会照着它把 BoneB 的设置写到 BoneA 头上 —— **错得更隐蔽**。
  （本项目 2026-09-17 已经因为"用 `as_pointer()` 当键"栽过一次，见 `_own_key` 的注释。）

⇒ **选 A**。它符合本项目已经写进代码的一条铁律：
  「同一语义的判据只能有一份，且必须**显式**流动，不靠隐式反查」。

---

## 4. token 格式设计（四张表）

### 4.1 owner 段怎么表示

    owner = "<bone>@<slot>"
      · 物体级曲线（不是骨骼）  ⇒ bone = ""        ⇒ 例如 "@OBMyCube"
      · 没有 slot 信息（兜底）  ⇒ slot = ""        ⇒ 例如 "BoneA@"
      · 两者都没有（旧路径）    ⇒ owner 段**整段省略**（3 段 token）= 旧格式

用 `@` 分隔而不是 `|`：`|` 是 token 的字段分隔符，owner 内部再用 `|` 会打架；
`@` 在骨骼名里不会出现（Blender 骨骼名允许 `|`？—— 设计上**统一做一次转义**，见 §4.4）。

### 4.2 四张表的新旧 token 对照

| 表 | 旧 token | 新 token | 键 |
|---|---|---|---|
| `rtmp_feel` | `90.0000\|left\|LINK` | `90.0000\|left\|LINK\|BoneA@OBMyCube` | `(action, frame, side, owner)` |
| `rtmp_tri_lock` | `90.0000\|SPLIT` | `90.0000\|SPLIT\|BoneA@OBMyCube` | `(action, frame, owner)` |
| `rtmp_owned_free` | `90.0000\|left` | `90.0000\|left\|BoneA@OBMyCube` | `(action, frame, side, owner)` |
| `rtmp_frozen` | `90.0000` | `90.0000\|BoneA@OBMyCube` | `(action, frame, owner)` |

⚠️ **最后一段是"可选的第 N 段"**：解析按「前 N-1 段照旧、最后一段存在就是 owner」处理。
  这样**旧 token 天然合法**（少一段 ⇒ owner = None）。

### 4.3 查询语义（兼容的核心）

    lookup(键 K = (action, frame, side, owner)):
        if K in 表:                       return 表[K]        # ① 精确命中
        if (action, frame, side, None) in 表:                  # ② 回退：旧 token / 无 owner
            return 表[(action, frame, side, None)]
        return None                                            # ③ 未记录

⇒ **老工程的行为一个字节不变**（旧条目对所有 owner 生效，正是今天的样子）。
⇒ 一旦某个 owner 显式写过，那条记录就是"有主"的，别人不会再撞上。

### 4.4 转义（骨骼名 / slot 名里出现分隔符）

骨骼名是用户可改的，理论上可以含 `|` 或 `@`。**不能**赌它不会。
⇒ owner 段做一次**可逆转义**：

    %  →  %25        |  →  %7C        @  →  %40

（只对 owner 段做；帧号/侧/值段是插件自己生成的，不含这些字符。）
解析时逆序还原。**旧 token 没有 owner 段 ⇒ 不走转义**，零影响。

---

## 5. 旧文件兼容方案（三级，逐级收窄）

| 级别 | 场景 | 行为 |
|---|---|---|
| **① 解析** | 打开老 .blend，property 里全是旧 token | 少一段 ⇒ `owner=None` ⇒ 正常进内存表，**不报错、不丢条目** |
| **② 查询** | 用户接着操作，某根手柄问"我的体感是什么" | 精确匹配失败 ⇒ **回退到 owner=None 那条** ⇒ 老工程表现与今天完全一致 |
| **③ 写入迁移** | 用户显式改了某个 owner 的状态 | 写新 token；同时**删掉同 `(frame, side)` 的 owner=None 那条**（收编） |

### ③ 为什么要收编（这一步必须写进文档，因为它**改变行为**）

  老工程里那条 `90.0000|left|LINK` 是**全局**的（所有骨骼都读到它）。
  现在 BoneA 显式写了 FREE：
    · 若不收编 ⇒ BoneA 读到自己那条 FREE ✓，但 BoneB 仍读到旧的全局 LINK ——
      看起来"没问题"，可一旦用户把 BoneA 的改回去，BoneB 又变回 LINK，**鬼影**；
    · 收编 ⇒ 那条全局记录被"第一个动它的人"认领，语义从此变成"按 owner 记"，
      **干净、可预测**。

  ⚠️ 代价：**BoneB 会失去那条继承来的设置**（回到"未记录 ⇒ 透传原始类型"）。
     这是**一次性**的、且只影响"用户已经动过其中一根骨骼"的那一帧。
     必须在 Change Log 与 README_DEV 里写明。

### ④ 反向兼容（新文件在老插件里打开）

  不在承诺范围内（插件不保证降级可用）。但**不会崩**：老代码的 `_feel_parse`
  见到 4 段会返回 None ⇒ 该条被跳过（**丢设置但不报错**）。
  如要更稳，可在写新 token 的同时**保留**一条旧 token 作为"降级镜像"——
  **不建议**：两份真相 = 迟早漂移（本项目铁律）。

---

## 6. 调用链清单（谁把 owner 传下去）

产品代码里的调用点（**不含 tests/**，实测统计）：

    mark_feel 11 · mark_feel_at 7 · unmark_feel_at 4 · unmark_feel 2
    feel_type 7 · feel_type_at 2 · _feel_key_of 5 · _feel_key 4
    _link_mode 7
    mark_owned_free 9 · unmark_owned_free 5 · _is_plugin_owned_free 2 · _own_key 4
    _trilock_key_of 3 · is_tri_locked 5 · set_tri_locked 3
    _frozen_key 4 · mark_frozen 4 · unmark_frozen 1 · is_frozen 2

### 6.1 owner 在这些地方**拿得到**（逐条核对过）

| 调用方 | owner 来源 |
|---|---|
| `xf.make_handles_editable(action, obj, frames, bone_name)` | 形参 `bone_name` + `obj.animation_data.action_slot.identifier` |
| `spec_check._freeze_keyframe` / `fix_missing_axes` / `fix_unify_dt` / `fix_handle_bend` / `_freeze_side_preserving` | 都有 `bone_name` 形参 |
| `td.freeze_keyframe_pair` / `write_s` / `freeze_handle_side` | 前两者有 `bone_name`；`freeze_handle_side` 需要**新增**一个参数 |
| `interaction` / `modal_edit` | 两条路都经 `_bone_name_of(context, obj)` 拿到骨骼名 |
| `edit_geometry._link_mode` 调用点 | 该函数已有 `bone_name` 形参 |
| `spec_check.detect` | 有 `bone_name` 形参 |
| 绘制/手柄记录（`handles.collect_handles`） | 记录里**本来就带 `bone_name` 字段** |

### 6.2 两个**必须新增参数**的地方（最容易被漏）

1. `td.freeze_handle_side(keyframe, side)` —— 今天只收 keyframe，**拿不到骨骼名**。
   它被 `freeze_keyframe_pair`（有 bone_name）与 `write_s`（有 bone_name）调用 ⇒ 加一个可选参数即可。
2. `td.mark_frozen(action, frame)` / `unmark_frozen` / `is_frozen(action, frame)` ——
   同上，加可选 `bone_name=None, slot=None`。

### 6.3 兜底规则（**关键**：漏传不许崩、不许静默写错）

    owner=None ⇒ 退化成"全局"语义（= 今天的行为）。

这是**刻意的**：漏改一个调用点的后果是"那一条还是老样子"，
而不是"写到一个不存在的 owner 上"。**宁可退化，不可错位。**

---

## 7. 测试侧要改什么

### 7.1 必须改写（它们断言的是"新契约"）

| 测试 | 现状 | 改成 |
|---|---|---|
| `gui_eb_state_check.py` **C5** ×2 | `xf.mark_feel(kpA, 'left', 'LINK')` 不带 owner | 带上 `bone_name="EB_BoneA"` / `"EB_BoneB"`，断言两根骨骼**互不干扰** |
| `gui_eb_state_check.py` **D5b** ×2 | `mark_feel(kpA/kpB, ...)` 不带 slot | 带上各自 slot 的 `identifier`，断言 property 里**两条都在** |

⚠️ 这两条测试**今天调的是裸 API**（不带 owner）—— 也就是说，
  在"显式传递"方案下，它们**必须**跟着改成传 owner，否则测的还是旧语义。
  这不是"改测试迁就代码"：测的正是"调用方显式告诉账本这根手柄是谁的"这条新契约。

### 7.2 不需要改（约 200 个测试调用点）

因为 owner 是**可选参数**、默认 None ⇒ 全部走"全局"回退 ⇒ 行为与今天一致。
（这也正是 §6.3 那条兜底规则的价值：**测试面不用动**，回归才有意义。）

### 7.3 新增断言（防回归，建议）

- **C5d**：两根骨骼各自写不同值 → 读回各自的值 + property 里有 **2 条**
- **D5c**：两个 slot 各自写不同值 → 读回各自的值 + property 里有 **2 条**
- **兼容 1**：手工往 property 里塞**旧 token** → 查询能回退读到（老工程不失效）
- **兼容 2**：旧 token + 显式写某个 owner → 旧 token 被**收编**（property 里不再有全局那条）
- **转义**：骨骼名含 `|` / `@` / `%` → 往返一致（写进去读回来是同一个名字）
- **持久化**：`_feel_persist_probe.py` / `_frozen_persist_probe.py` 的双进程用例**带上 owner** 再跑一遍

---

## 8. 验证计划（做完必须全跑）

    # ① 基础
    blender --background --factory-startup --python tests\regression.py     # 16/0
    python tests\i18n_gate.py                                               # 通过

    # ② 账本四表全家族（**Batch 3 的主战场**）
    gui_eb_state_check.py        # C5 / D5b 转绿
    gui_frozen_link_check.py     # 65/0（体感 + 冻结）
    gui_tri_lock_check.py        # 48/0（三角锁定）
    gui_undo_lock_check.py       # undo × 锁定/接管
    gui_endpoint_hollow_check.py # 端点空心圆（大量用接管表）
    gui_bone_speed_check.py      # 骨骼路径
    _feel_persist_probe.py / _frozen_persist_probe.py   # 双进程持久化

    # ③ 受牵连（都读 `_link_mode` / `feel_type`）
    gui_eb_spec_check.py / gui_eb_numeric_check.py / gui_eb_modal_check.py
    gui_spec_inspect_check.py / gui_review_fix_check.py / gui_peraxis_align_check.py
    gui_dblclick_copy_speed_check.py / gui_ge_align_check.py

    # ④ 全量门禁
    python tests\run_all.py

**判据**：既有断言不许转红（C5/D5b 那 4 条是**转绿**）。

---

## 9. 风险与回退

| 风险 | 概率 | 缓解 |
|---|---|---|
| 漏传某个调用点 ⇒ 那一条退化成全局 | 中 | §6.3 兜底 = 退化而非错位；§8 的 ② 组专抓 |
| 收编旧 token 改变老工程行为 | **确定发生**（一次性） | 写进 Change Log / README_DEV；只影响"用户已动过其中一根骨骼"的那一帧 |
| 转义写错 ⇒ 名字读不回 | 低 | 单测：含 `\|` `@` `%` 的名字往返 |
| 四张表改动互相牵连 | 中 | 四套改动**逐个提交**（feel → trilock → owned → frozen），每套跑一遍 §8 的 ② 组 |
| 反查诱惑（后人加回缓存） | 低 | 本文档 §3 + 代码注释写明"指针会被复用，别用它当身份" |

**回退**：四张表互相独立，任一套出问题可单独 `git revert` 那一个提交；
且旧 token 一直可读 ⇒ **不存在"数据打不开"的最坏情况**。

---

## 10. 需要拍板的点

1. **是否接受 §5③ 的"收编"语义**（老工程里那条全局记录会被第一个动它的 owner 认领，
   其他 owner 因此回到"未记录"）。替代方案是**不收编**（全局那条永远保留）——
   代价是出现"鬼影"：用户把 A 改回去，B 又突然变回旧值。
2. **是否分四个提交**（推荐）还是一个大提交。
3. C5 / D5b 两条测试改成传 owner —— 确认这是"新契约"而不是"迁就代码"。

---

## 11. 附：本次会话实测到的原始数据（供复核）

    # Keyframe 无父指针（官方文档）
    bpy.types.Keyframe 属性 = amplitude/back/co/co_ui/easing/handle_left/
        handle_left_type/handle_right/handle_right_type/interpolation/period/
        select_control_point/select_left_handle/select_right_handle/type

    # 实测
    kp.id_data 类型                  ⇒ Action
    ActionChannelbag 属性            ⇒ fcurves / slot / slot_handle
    ActionSlot 属性                  ⇒ identifier / name_display / handle / target_id_type
    迭代全部 channelbag 的 fcurve    ⇒ 可行（实测 4 条）
    slot.identifier 存盘重开         ⇒ 逐位一致（'OBSLOTPROBE' / 'OBSlotB'）
    slot.handle     存盘重开         ⇒ 逐位一致（929201142 / 929201143）
---

## 12. 【实测补充 · 2026-10-01】动手第一刀之后学到的三件事

> 体感表那一刀已经写出来了（分支 `phase1-batch3-wip`，提交 `8c02773`），
> 但**没有合进 main** —— 它把 `gui_eb_state_check` 从 6 FAIL 打到 **24 FAIL**。
> 下面是实测结论，下一轮直接照这个改，别重走。

### 12.1 ✅ 好消息：「自动反查」这条路走得通，而且**测试调用点几乎不用改**

实测探针（单骨骼对象）：

    owner_of_keyframe(kp)   ⇒ '@OBOWNPROBE'          ← 反查成功
    owner_of_curve(fc)      ⇒ '@OBOWNPROBE'
    写入后的 property        ⇒ ['90.0000|left|LINK|@OBOWNPROBE']
    feel_type(kp, 'left')   ⇒ 'LINK'                 ← 读回来对

⇒ `mark_feel(kp, ...)` / `feel_type(kp, ...)` 这类**拿得到关键帧**的入口
  可以自己把 owner 算出来 ⇒ **不需要改任何调用点**（约 200 个测试调用点白赚）。
  C5 / D5b 那两组的核心断言（两根骨骼 / 两个 slot 互不干扰）因此**不用改测试**就转绿。

### 12.2 ⚠️ 坏消息：`*_at` 系列（**没有关键帧**的入口）裸调会退化

`mark_feel_at` / `unmark_feel_at` / `feel_type_at` 拿不到关键帧 ⇒ 算不出 owner。
调用方不传 ⇒ owner = 空串 = 「未知」⇒ 与"已解析出 owner"的记录**并存两条**：

    实测 mem_feel = [('EB_D3_Action', 90.0, 'left', ''),
                     ('EB_D3_Action', 90.0, 'left', '@OBEB_D3'), ...]

行为上没错（查询按解析出的 owner 读，读到的是对的那条），但：

  ① 留下一条**没人会读**的垃圾记录；
  ② **测试直接调 `mark_frozen(act, FRAME)`**（28 处）会造出这种垃圾；
  ③ `feel_type_at(act, FRAME, 'left')` **裸调**（读侧）⇒ owner 也是空串
     ⇒ 读不到那条已解析的记录 ⇒ **返回 None**。
     实测被 D4 抓到：`轮0 切回A feel=None`（期望 'FREE'）。

#### ⇒ 必须先定死 `*_at` 的**读/写不对称语义**（下一轮第一件事）

| | 没传 owner 时 | 理由 |
|---|---|---|
| **写**（`mark_*_at`） | 写进「未知」桶（owner = 空串） | 写必须有地方落；空串就是"不知道是谁" |
| **读**（`*_at` 查询） | **不限 owner（通配）**：同 (action, 帧, 侧) 里任一条命中就返回 | 裸调的老语义就是"这一帧有没有记录"；否则**每一个裸调读都返回 None** |

⚠️ 通配读**只能用在查询**上。`mark_frozen` 里那句
「已登记的体感不覆盖用户的选择」的守卫**必须用精确 owner**，
否则会变成"别的骨骼有记录 ⇒ 我就不写了"（把 bug 换个方向犯）。

### 12.3 ⚠️ 测试自己的「账本校验器」要跟着改（这才是 24 条 FAIL 的主因）

`gui_eb_state_check.py` 里有一套**独立**的 `table_vs_prop()`（双向对账），
它**自己解析 token**（按 3 段）。4 段 token 一进来它就报 `MALFORMED`：

    实测 property 多出=[('MALFORMED', '9...')]

要改的（都在 `gui_eb_state_check.py`）：

| 位置 | 现状 | 改成 |
|---|---|---|
| `table_vs_prop()` 的 token 解析 | 3 段 | 4 段；并且**按 owner 分组**比较（同一 (帧,侧) 允许多条） |
| D1a / D1b | 断言"表里条目 = property 条目" | 同上（多 owner ⇒ 多条） |
| D2a / D2b | 手工往 property 塞 token | 塞**4 段**（带 owner），否则按设计被忽略 |
| D3（子进程探针） | 写/读 3 段 | 4 段；`len(mem_feel) == 2` 的期望要按 owner 数重算 |
| D4 | `feel_type_at(act, 帧, 'left')` 裸调 | 依赖 §12.2 的**通配读**；或显式传 owner |
| D8（僵尸词条） | 同上 | 同上 |

**判断口径没变**（两根骨骼 / 两个 slot 必须分开），改的只是"token 长什么样"。

### 12.4 已经验证过的部分（`main` 上是绿的，可作基线）

分支 `phase1-batch3-wip` 上跑过：

    regression              16/0 ✓
    gui_eb_spec_check       77/0 ✓
    gui_eb_numeric_check    47/0 ✓
    gui_eb_state_check      67/24 ✗（全部集中在 D1/D2/D3/D4 —— 见 §12.3）

⇒ 说明**体感表本身的改造是对的**（既有功能没被碰坏），
  卡住的是"测试侧还没跟上新格式" + "`*_at` 裸调语义未定"。