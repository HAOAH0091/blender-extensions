# -*- coding: utf-8 -*-
"""真机探针 v2：双击锁定三角 → GE 手柄对齐（真实 region/rv3d + 真实三角位置）。

核心判据（用户报"有动作但不符合预期"，最可能是「命中错侧」）：
  拿 X 三角自己的屏幕位置去 `_triangle_under_cursor`，**必须命中 X 自己**。
  命不中 ⇒ `tri_clicked` 退化成 `tris[0]` ⇒ 对齐到错误的侧 ⇒ 症状吻合。
"""
import sys, os, json, traceback, importlib

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)
import bpy

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})

def main():
    try:
        import addon_utils
        addon_utils.enable(PKG_NAME, default_set=True, persistent=True)
        it = importlib.import_module(PKG_NAME + ".interaction")
        hd = importlib.import_module(PKG_NAME + ".handles")
        cache = importlib.import_module(PKG_NAME + ".cache")

        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        ob = bpy.context.view_layer.objects.active
        ob.name = "PROBE"
        for f, loc in [(1, (0, 0, 0)), (25, (3.0, 3.0, 0.0)), (55, (6.0, 0.0, 0.0))]:
            ob.location = loc
            ob.keyframe_insert("location", frame=f)
        bpy.context.scene.frame_set(25)
        act = ob.animation_data.action

        area = next((a for a in bpy.context.screen.areas if a.type == 'VIEW_3D'), None)
        sp = next((s for s in area.spaces if s.type == 'VIEW_3D'), None)
        rv3d = sp.region_3d
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        ctx = dict(bpy.context.copy())
        ctx.update(area=area, region=region, space_data=sp, region_data=rv3d)

        with bpy.context.temp_override(**ctx):
            center = (region.width / 2.0, region.height / 2.0)
            s_handles = it._update_speed_hover(bpy.context, ob, region, rv3d, center)
            handles = s_handles or []
            step("真实 handles 已算出（modal 走同一函数）", len(handles) > 0,
                 "个数=%d 类型=%s" % (len(handles), type(s_handles).__name__))
            if not handles:
                raise RuntimeError("no handles")

            # ---- ★ 核心判据：每个三角自己能否被命中 ----
            bad = []
            detail = []
            for h in handles:
                ts = h.get('tri_screen')
                if ts is None:
                    detail.append("f=%s %s: tri_screen=None" % (h.get('frame'), h.get('tri')))
                    continue
                got = it._triangle_under_cursor(handles, (float(ts[0]), float(ts[1])))
                ok = got is not None and got.get('tri') == h.get('tri') \
                     and abs(float(got.get('frame')) - float(h.get('frame'))) < 1e-3
                ksd = None
                if h.get('kf_screen') is not None:
                    ksd = hd.dist2(h['kf_screen'], ts) ** 0.5
                if not ok:
                    bad.append((h.get('frame'), h.get('tri'),
                                got.get('tri') if got else None, ksd))
                detail.append("f=%.0f %-4s 命中=%-5s 三角→关键帧距=%s"
                              % (h.get('frame'), h.get('tri'),
                                 (got.get('tri') if got else "None"),
                                 ("%.1fpx" % ksd) if ksd is not None else "?"))
            step("★★ 每个三角都能被「自己」命中（tri_clicked 正确的前提）",
                 not bad, " | ".join(detail[:6]))
            if bad:
                step("   未命中明细（帧, 该三角, 实际命中, 到关键帧距离）", False,
                     json.dumps(bad, ensure_ascii=False))

            # ---- 双击：分离 → 锁回一体 ----
            tgt = None
            for h in handles:
                if abs(float(h.get('frame', -1)) - 25.0) < 1e-3:
                    tgt = h
                    break
            tgt = tgt or handles[0]
            fr = float(tgt['frame'])
            tri = tgt['tri']
            pos = tgt.get('tri_screen')
            step("选中用于双击的三角", pos is not None, "f=%.0f tri=%s pos=%s" % (fr, tri, pos))

            def _handles_of(side):
                out = {}
                for fc in cache.collect_animation_curves(act, ob):
                    for kp in fc.keyframe_points:
                        if abs(float(kp.co[0]) - fr) < 1e-3:
                            out[fc.array_index] = (kp.handle_left if side == 'left'
                                                   else kp.handle_right)
                return out

            def _dts():
                o = {}
                for fc in cache.collect_animation_curves(act, ob):
                    for kp in fc.keyframe_points:
                        if abs(float(kp.co[0]) - fr) < 1e-3:
                            o[fc.array_index] = (abs(float(kp.co[0]) - float(kp.handle_left[0])),
                                                 abs(float(kp.handle_right[0]) - float(kp.co[0])))
                return o

            before = _dts()
            ok1, m1 = it.toggle_frame_lock(bpy.context, ob, fr, handles, pos, region, rv3d)
            step("① 双击 → 分离", ok1, str(m1)[:60])
            step("   分离态 is_frame_locked=False", not it.is_frame_locked(ob, fr), "")
            ok2, m2 = it.toggle_frame_lock(bpy.context, ob, fr, handles, pos, region, rv3d)
            step("② 双击 → 锁回一体", ok2, str(m2)[:90])
            step("   一体态 is_frame_locked=True", it.is_frame_locked(ob, fr), "")

            after = _dts()
            cross = {}
            for fc in cache.collect_animation_curves(act, ob):
                for kp in fc.keyframe_points:
                    if abs(float(kp.co[0]) - fr) < 1e-3:
                        A = float(kp.co[1]) - float(kp.handle_left[1])
                        B = float(kp.handle_right[1]) - float(kp.co[1])
                        cross[fc.array_index] = abs(
                            A * (float(kp.handle_right[0]) - float(kp.co[0]))
                            - B * (float(kp.co[0]) - float(kp.handle_left[0])))
            step("★★ 锁定后 GE 手柄共线（叉积≈0）", all(v < 1e-3 for v in cross.values()),
                 "cross=%s" % {k: "%.2e" % v for k, v in cross.items()})
            side = hd.SIDE_BY_TRI.get(tri)
            keep_ok = True
            for k in before:
                if k in after:
                    idx = 0 if side == 'left' else 1
                    if abs(before[k][idx] - after[k][idx]) > 1e-9:
                        keep_ok = False
            step("★ 被双击侧 dt 保持不变（保疏密）", keep_ok,
                 "侧=%s before=%s after=%s" % (side,
                     {k: ("%.4f" % v[0 if side == 'left' else 1]) for k, v in list(before.items())[:3]},
                     {k: ("%.4f" % v[0 if side == 'left' else 1]) for k, v in list(after.items())[:3]}))
    except Exception:
        step("EXCEPTION", False, traceback.format_exc())

    fails = [s for s in steps if not s["ok"]]
    print("=" * 74)
    for s in steps:
        print("[%s] %s  %s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                              ("<- " + s["detail"]) if s["detail"] else ""))
    print("断言 %d / 失败 %d" % (len(steps), len(fails)))
    print("=== GUI2_RESULT " + json.dumps({"fails": len(fails), "total": len(steps)}) + " ===")
    sys.stdout.flush()
    return None

bpy.app.timers.register(main, first_interval=2.0)
bpy.app.timers.register(lambda: (bpy.ops.wm.quit_blender(), None)[1], first_interval=25.0)
