# -*- coding: utf-8 -*-
"""RTMP 直接编辑的【几何与命中】层 —— 从 `interaction.py` 抽出的纯计算。

## 为什么单独成模块

`interaction.py` 的 `RTMP_OT_PathPointDrag` 曾是一个 ~1590 行的上帝类，
里面混着三种性质完全不同的东西：

    ① 纯计算 —— 命中检测（鼠标下是什么）、手柄数学（偏移 / 切向 / 缩放）
    ② 事件编排 —— 「按下 → 判断 → 设置状态 → 重绘」
    ③ 生命周期 —— invoke / modal / cancel

①「能搬」：它只依赖 state / cache / drawing 与 bpy，不碰任何实例状态。
② ③「不该搬」：它们读改操作符自己的实例属性（`self._...`），
   天生属于操作符 —— 硬搬出去等于把内聚的东西拆散。

本模块只装 ①。② ③ 留在 `interaction.py`。

## 依赖方向（重要）

    本模块 → state / cache / drawing / time_domain / transform_domain
    （上述模块【都不】反向 import interaction ⇒ 无循环导入）

`_session` 用 `from .state import _session` **是安全的**：它是模块级单例
**对象**，from-import 拿到的是同一个对象的引用（不是值拷贝）。
本模块对它**只读**，从不重新赋值 —— 这一点由 `tests/test_session_attrs.py` 守住。

（注：`state._cache_update_lock` 那种**不可变 bool** 的 from-import 才是陷阱，
  改的是副本；本项目已踩过并在 cache.py 有明确注释。两者别混。）

## 与操作符的关系

`interaction.RTMP_OT_PathPointDrag` 里保留了**同名转发方法**，
因此类内调用点与 tests/ 里的既有调用**一个字都不用改**。
"""
import math

import bpy
import mathutils
from bpy_extras import view3d_utils

from . import time_domain as td
from . import transform_domain as xf
# ⚠️ 2026-09-29：不再 import `get_addon_prefs` —— 读偏好的唯一实现
#    已上移到 `state.uniform_handle_mode`（见下方 `_uniform_mode` 别名）。
from .state import (FRAME_EPS, HANDLE_SELECT_RADIUS, SAFE_LIMIT, _session,
                    uniform_handle_mode, warn_once)
from .cache import (collect_animation_curves, frame_has_keyframe,
                    is_position_animation, resolve_parent_transform)
from .drawing import (_endpoint_is_hidden_side, compute_handle_display_factors,
                      handle_is_zero_length, local_eps_for_screen, _view_ctx)

# ===========================================================================
# A. 命中检测：拾取鼠标下的目标
# ===========================================================================
def _hit_sampled_point(context, region, rv3d, mouse_pos):
    """在所有【采样点】里找离鼠标最近、且在选中半径内的那个。

    返回 (world_pos, frame, bone) 或 None。

    ⚠️ 必要性：`cached_positions` 只缓存关键帧；而插件画的是每帧一个采样点。
       不补这一层，绝大多数画出来的点都点不中（实测 40 个点里只有 4 个能点）。
    """
    try:
        frame_start = context.scene.frame_start
    except Exception:
        warn_once("edit_geometry._hit_sampled_point")
        return None
    obj = context.active_object
    best = None
    try:
        for (pname, pbone), pts in _session.path_point_sequence.items():
            draw_obj = bpy.data.objects.get(pname)
            if draw_obj is None:
                continue
            # POSE 模式下只考虑可交互的骨骼
            if pbone is not None:
                if obj is None or obj.mode != 'POSE':
                    continue
                if pbone not in set(_session.cached_positions.get(pname, {}).keys()):
                    continue
            else:
                if obj is not None and obj.name != pname:
                    continue
            try:
                pm = resolve_parent_transform(draw_obj, pbone)
            except Exception:
                warn_once("edit_geometry._hit_sampled_point")
                continue
            for i, local_pos in enumerate(pts):
                world_pos = pm @ local_pos
                sp = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                if sp is None:
                    continue
                dist = (mouse_pos - sp).length
                if dist < HANDLE_SELECT_RADIUS and (best is None or dist < best[0]):
                    best = (dist, world_pos, float(frame_start + i), pbone, pname)
    except Exception:
        warn_once("edit_geometry._hit_sampled_point")
        return None
    if best is None:
        return None
    _session.drag_target_object = best[4]
    return best[1], best[2], best[3]


def locate_handle_under_cursor(context, event, region=None, rv3d=None, local_mouse_pos=None):
    if not region or not rv3d:
        if not context.space_data or context.space_data.type != 'VIEW_3D':
             return None, None, None, None, None
        region = context.region
        rv3d = context.space_data.region_3d
    
    if local_mouse_pos:
        mouse_pos = mathutils.Vector(local_mouse_pos)
    else:
        mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))

    obj = context.active_object
    
    if not obj:
        return None, None, None, None, None
    
    def check_handles_at_frame(bone_name, frame_num, point_3d, parent_matrix, check_action, check_obj=None):
        if not frame_has_keyframe(collect_animation_curves(check_action, check_obj), frame_num, bone_name):
            return None
        
        frame_kf_map = {}
        for fcurve in collect_animation_curves(check_action, check_obj):
            if is_position_animation(fcurve, bone_name):
                for keyframe in fcurve.keyframe_points:
                    if abs(keyframe.co[0] - frame_num) < FRAME_EPS:
                        frame_kf_map[fcurve.array_index] = keyframe
                        break
        
        if not frame_kf_map:
            return None
        
        # ★ 2026-09-18（盲审 S2）：算出"本帧是不是首/末关键帧"，供外侧守卫用。
        #   与绘制侧同一口径：在所有位移曲线里取 min/max 帧号。
        #   单关键帧时首=末 ⇒ 两侧都是外侧（与 drawing 的 H 组测试一致）。
        _all_frames = [kp.co[0] for _fc in collect_animation_curves(check_action, check_obj)
                       if is_position_animation(_fc, bone_name)
                       for kp in _fc.keyframe_points]
        _f_lo = min(_all_frames) if _all_frames else None
        _f_hi = max(_all_frames) if _all_frames else None
        is_first = (_f_lo is not None and abs(frame_num - _f_lo) < FRAME_EPS)
        is_last = (_f_hi is not None and abs(frame_num - _f_hi) < FRAME_EPS)

        factors_left, factors_right = compute_handle_display_factors(frame_kf_map)
        
        handle_vector_left = mathutils.Vector((0.0, 0.0, 0.0))
        handle_vector_right = mathutils.Vector((0.0, 0.0, 0.0))
        
        for array_index, keyframe in frame_kf_map.items():
            factor_l = factors_left.get(array_index, 1.0)
            factor_r = factors_right.get(array_index, 1.0)
            
            diff = (keyframe.handle_left[1] - keyframe.co[1]) * factor_l
            handle_vector_left[array_index] = diff
            diff = (keyframe.handle_right[1] - keyframe.co[1]) * factor_r
            handle_vector_right[array_index] = diff
        
        rotation_matrix = parent_matrix.to_3x3()
        world_vector_left = rotation_matrix @ handle_vector_left
        world_vector_right = rotation_matrix @ handle_vector_right
        
        global_scale = context.window_manager.rtmp_handle_scale
        
        # ⚠️ 守卫与绘制侧共用【唯一】判据 `drawing.handle_is_zero_length`
        #    （**屏幕像素**口径，见其 docstring）——**严格互补**：
        #    绘制侧判「空心态」的那一侧，这里【不做】几何命中，
        #    改由 `get_handle_at_cursor` 按「空心圆抓取点」的偏移位置去命中。
        #    本处【不再】自带第二份判据（世界长度 1e-4 / 别的阈值都不行）——
        #    两边判据一旦漂移，就会出现"几何拾取不认、空心态也不认"的缝 ⇒ 误触。
        # ★★ 2026-09-18（盲审 S2）：**外侧手柄必须不命中** —— 与绘制侧严格对称。
        #   绘制侧 `drawing.py:739` 对「首帧 left / 末帧 right」是
        #   `continue`（不画手柄线、不登记抓取点），其注释原文写着
        #   「拖了也没效果」；而这里原先**没有任何对应守卫** ⇒ 用户能点到
        #   一根**看不见的线**、拖了还不动（体验断档）。
        #
        #   ※ 盲审原文称"拖动会改变动画"，实测**不成立**：
        #     `tests/gui_endpoint_hollow_check.py:11` 记载
        #     「外侧手柄不参与任何曲线段，值分量/时间分量对曲线影响
        #       都是 0.00000000」⇒ 拖了曲线不会变，只是**白拖**。
        #     所以本条是"体验/对称性"修复，不是"数据被改坏"的修复。
        #
        #   ⚠️ 判据必须**复用** `drawing._endpoint_is_hidden_side`（唯一来源），
        #     不能在这里重写一份 —— 两边判据一旦漂移就会出现"缝"。
        if not _endpoint_is_hidden_side(is_first, is_last, 'left'):
            if not handle_is_zero_length(context, point_3d, world_vector_left,
                                         global_scale, region, rv3d):
                handle_left_pos = point_3d + (world_vector_left * global_scale)
                screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_left_pos)
                if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                    return 'left', handle_left_pos

        if not _endpoint_is_hidden_side(is_first, is_last, 'right'):
            if not handle_is_zero_length(context, point_3d, world_vector_right,
                                         global_scale, region, rv3d):
                handle_right_pos = point_3d + (world_vector_right * global_scale)
                screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_right_pos)
                if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                    return 'right', handle_right_pos
        
        return None

    if obj.mode == 'POSE':
        if not obj.animation_data or not obj.animation_data.action:
            return None, None, None, None, None
        action = obj.animation_data.action
        obj_cache = _session.cached_positions.get(obj.name, {})
        
        bones_to_check = list(context.selected_pose_bones or [])
        active_bone = context.active_pose_bone
        if active_bone and active_bone not in bones_to_check:
            bones_to_check.append(active_bone)
            
        for bone in bones_to_check:
            bone_name = bone.name
            if bone_name not in obj_cache:
                continue
            
            parent_matrix = resolve_parent_transform(obj, bone)
            
            for frame_num, cache_data in obj_cache[bone_name].items():
                point_3d = parent_matrix @ cache_data['position']
                
                result = check_handles_at_frame(bone_name, frame_num, point_3d, parent_matrix, action, obj)
                if result:
                    side, handle_pos = result
                    return side, handle_pos, frame_num, point_3d, bone
        
        return None, None, None, None, None
        
    else:
        for cache_obj_name, cache_obj_data in _session.cached_positions.items():
            draw_obj = bpy.data.objects.get(cache_obj_name)
            if not draw_obj or None not in cache_obj_data:
                continue
            draw_action = draw_obj.animation_data.action if draw_obj.animation_data else None
            if not draw_action:
                continue
            parent_matrix = resolve_parent_transform(draw_obj)
            for frame_num, cache_data in cache_obj_data[None].items():
                point_3d = parent_matrix @ cache_data['position']
                result = check_handles_at_frame(None, frame_num, point_3d, parent_matrix, draw_action, draw_obj)
                if result:
                    side, handle_pos = result
                    _session.drag_target_object = draw_obj.name
                    return side, handle_pos, frame_num, point_3d, None
    
    return None, None, None, None, None


def locate_point_under_cursor(context, event, region=None, rv3d=None, local_mouse_pos=None):
    if not region or not rv3d:
        if not context.space_data or context.space_data.type != 'VIEW_3D':
            return None, None, None
        region = context.region
        rv3d = context.space_data.region_3d

    if local_mouse_pos:
        mouse_pos = mathutils.Vector(local_mouse_pos)
    else:
        mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
        
    obj = context.active_object
    
    if not obj:
        return None, None, None
    
    obj_cache = _session.cached_positions.get(obj.name, {})
    
    if obj.mode == 'POSE':
        bones_to_check = list(context.selected_pose_bones or [])
        active_bone = context.active_pose_bone
        if active_bone and active_bone not in bones_to_check:
            bones_to_check.append(active_bone)
        
        for bone in bones_to_check:
            if bone.name not in obj_cache:
                continue
            
            parent_matrix = resolve_parent_transform(obj, bone)
            
            for frame_num, cache_data in obj_cache[bone.name].items():
                local_pos = cache_data['position']
                world_pos = parent_matrix @ local_pos
                
                screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                    return world_pos, frame_num, bone

        # ⚠️ 同上：cached_positions 只含关键帧；补上对全部采样点的命中检测
        hit = _hit_sampled_point(context, region, rv3d, mouse_pos)
        if hit is not None:
            return hit

        return None, None, None
    else:
        for cache_obj_name, cache_obj_data in _session.cached_positions.items():
            draw_obj = bpy.data.objects.get(cache_obj_name)
            if not draw_obj or None not in cache_obj_data:
                continue
            parent_matrix = resolve_parent_transform(draw_obj)
            for frame_num, cache_data in cache_obj_data[None].items():
                local_pos = cache_data['position']
                world_pos = parent_matrix @ local_pos
                screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                    _session.drag_target_object = draw_obj.name
                    return world_pos, frame_num, None

        # ⚠️ 上面的 cached_positions 只含【关键帧】的缓存。
        #    但插件在视口里画的是【每帧一个采样点】（path_point_sequence）。
        #    实测：`cached_positions` 帧号 = [1,14,27,40]，而画出来 40 个点
        #    → 36 个点【点不中】（既不选中也不能拖），
        #      用户反馈的"R/S 没反应"正是点到了这些点。
        #    这里补上对【全部采样点】的命中检测。
        hit = _hit_sampled_point(context, region, rv3d, mouse_pos)
        if hit is not None:
            return hit

    return None, None, None


# ===========================================================================
# B. 手柄数学：偏移 / 切向 / 同比例缩放
# ===========================================================================
# ---------------------------------------------------------------------------
# (t,v) 平面直线外推的【安全值域上限】
#
# `update_linked_handle` 是兼容层，走的是老算法：`slope = dv / dt` 然后沿直线
# 把对侧手柄外推到 `dt_opp` 处。**dt 在分母上**，所以速度编辑把 dt 压小之后
# 外推会失控（实测炸到 -5766）。
#
# 两道保护：dt ≤ `xf.DT_EPS` 放弃；外推结果偏离 co 超过本上限也放弃。
# 放弃不是丢功能 —— 紧随其后的 `xf.finish_linked_handle` 会走三维通路
# （方向 + 臂长，全程不除 dt）把对侧摆正。
_MAX_TV_EXTRAP = 100.0


def _is_endpoint_inner_handle(action, obj, frame, side, bone_name=None):
    """判断 (frame, side) 是不是**端点处的内侧手柄**。

    内侧 = 朝曲线内部那一侧（**首帧的 right / 末帧的 left**）——
    用户拖"端点手柄"拖的就是这一侧（外侧朝外、没有曲线，拖它没意义）。

    ⚠️ **不能**用 `td.resolve_target` 的 `span is None` 判断 —— 实测
       f55 的**左手柄**（内侧）返回 `span = 30.0`（有段），
       `span is None` 对应的是**朝外**那一侧，正好相反（2026-09-17 踩坑：
       我第一版就是这么写的，结果修复完全没生效）。
    """
    try:
        frames = sorted({float(k.co[0])
                         for fc in collect_animation_curves(action, obj)
                         if is_position_animation(fc, bone_name)
                         for k in fc.keyframe_points})
        if not frames:
            return False
        f = float(frame)
        e = FRAME_EPS
        if abs(f - frames[0]) < e and side == 'right':
            return True
        if abs(f - frames[-1]) < e and side == 'left':
            return True
        return False
    except Exception:
        warn_once("edit_geometry._is_endpoint_inner_handle")
        return False


def _path_tangent_unit(action, obj, frame, side, bone_name=None):
    """求路径在 `frame` 处的**单位切向**（朝该侧手柄伸出的方向）。

    · side='right' → 朝时间【更晚】的方向（曲线前进方向）
    · side='left'  → 朝时间【更早】的方向（来路）

    用途：**零长手柄拖出时把方向锁到切线**（见 `_apply_one_handle_offset`
    里 `_dir_lock` 的说明）。用户 2026-09-17 实测：零长端点手柄拖出来
    方向 = 纯鼠标方向 ⇒ 与路径不相切、且朝不同方向拖结果完全不同（难复现）。

    ⚠️ 必须用**曲线微分**（`fc.evaluate` 求值后作差），**不能**用"相邻关键帧
       的弦方向" —— 实测弦方向与真实切向差 **17.11°**（用户会看到明显折角）。

    ★★ **自适应步长（2026-09-17 实测踩坑，必须这样写）**：
       端点处曲线常"减速到停"（该侧手柄 dv ≈ 0，例如 AUTO_CLAMPED 的缓出）
       ⇒ 位移 ∝ eps² 量级**极小**。实测 f55：
           eps=0.001 → |位移| 1e-6 ；eps=0.01 → 2e-6   ← **纯浮点噪声**
           eps=0.05  → 9.9e-5 ；eps=0.5  → 9.9e-3 ；eps=1.0 → 3.9e-2
       固定用 0.01 ⇒ 方向**随机**（实测与真值差 19.5°！）；0.05~5.0 之间
       彼此差 < 1°。⇒ 从够**小**的步长开始试，**取第一个位移已脱离噪声的**，
       得到的才是**视觉上的真实走向**（实测与曲线采样 f52→f55 差 < 0.5°）。

    任何异常 / 取不到几何 ⇒ 返回 None（调用方退回原行为，不崩）。
    """
    try:
        curves = {}
        for fc in collect_animation_curves(action, obj):
            if is_position_animation(fc, bone_name):
                curves[fc.array_index] = fc
        if len(curves) < 3:
            return None
        f = float(frame)
        sign = (1.0 if side == 'right' else -1.0)

        def _delta(eps):
            v = []
            for ax in (0, 1, 2):
                fc = curves.get(ax)
                if fc is None:
                    return None, 0.0
                v.append(float(fc.evaluate(f + sign * eps))
                         - float(fc.evaluate(f)))
            n = math.sqrt(sum(x * x for x in v))
            return v, n

        # 用最大步长估"宏观尺度" ⇒ 定"脱离噪声"的阈值（相对判据，适配任意场景尺度）
        _vmax, _nmax = _delta(5.0)
        if _vmax is None:
            return None
        tol = max(_nmax * 1e-3, 1e-9)

        for eps in (0.05, 0.1, 0.5, 1.0, 2.0, 5.0):
            v, n = _delta(eps)
            if v is None:
                return None
            if n >= tol:
                return [x / n for x in v]
        return None
    except Exception:
        warn_once("edit_geometry._path_tangent_unit")
        return None


# ★★ 2026-09-29：「手柄拖动模式」偏好的读取**唯一实现**已上移到
#    `state.uniform_handle_mode`。
#
#    为什么（用户报障「选中端点按 G 保速失效」的根因就是它）：
#      这个开关原先**全仓只有这一处**读，而 `modal_edit`（G/R/S 模态）
#      一次都没读过 ⇒ 模态那条路根本不知道有"保速"这回事。
#      修复要**收敛到一个来源**，不能两条路各读一份（那会把同一个错误再犯一次）。
#
#    这里保留同名别名 —— 本模块、`interaction.py` 的既有调用点，
#    以及 tests 的 from-import 全都一个字不用改。
_uniform_mode = uniform_handle_mode


def _handle_zero_local_len(context, obj, bone_name=None, ref_local=None):
    """「视觉零」（屏幕 6px）⇒ F-Curve **局部**长度阈值 —— 保速闸门与方向锁共用。

    ★★★ 2026-10-02（用户报障）：保速闸门原来用【世界长度 1.0】
    （实测 1 世界单位 ≈ 49px），而抓取环用的是【屏幕 6px】判据
    ⇒ 闸门关门范围比抓取环宽约 **8 倍** ⇒
    「屏幕上 24px、看得清清楚楚」的手柄，拖它照样不保速
    （用户报障：「手柄缩到 0 出现抓取环，拖出来后再拖，速度会被改」）。

    本函数把闸门换成与 `drawing.handle_is_zero_length()`（抓取环**唯一**判据）
    **同一把尺子**：都经 `drawing.local_eps_for_screen` 把屏幕像素换算成局部长度
    （含父级缩放 ps 与 `rtmp_handle_scale` 的换算 —— 少一项就差 ps·gs 倍，
     正是 2026-09-27 修过的那条缝）。

    ⚠️ 拿不到 3D 视图（后台 / 无 region）⇒ 返回 None：
       调用方退回 `xf.UNIFORM_LEN_MIN`（旧口径），**行为与旧版逐位一致**。
       ⇒ headless 测试不受影响，也不改变无视图环境的语义。

    ⚠️ 本函数是保速闸门 + 方向锁的**唯一阈值来源** ——
       两者口径一旦漂移，就会出现「看得见手柄却锁方向 / 保不了速」的缝。

    :param ref_local: 关键帧在**局部值空间**的位置（三轴 co 组成的向量，可空）。
    """
    try:
        region, rv3d = _view_ctx(context)
        if region is None or rv3d is None:
            return None
        if obj is None:
            return None
        bone = None
        if bone_name and obj.mode == 'POSE' and obj.pose:
            bone = obj.pose.bones.get(bone_name)
        pm = resolve_parent_transform(obj, bone)
        if ref_local is not None:
            ref = pm @ mathutils.Vector(ref_local)
        else:
            ref = pm.translation.copy()
        gs = 1.0
        try:
            gs = float(context.window_manager.rtmp_handle_scale)
        except Exception:
            gs = 1.0
        return local_eps_for_screen(context, ref, pm, gs,
                                    region=region, rv3d=rv3d)
    except Exception:
        warn_once("edit_geometry._handle_zero_local_len")
        return None


def _uniform_plan(context, action, obj, frame, side, bone_name, factors,
                  total_offset_local_scaled, frame_kf_map):
    """【唯一实现】同比例模式的**预演**（只读，必须在任何写入之前调用）。

    做两件事：
      ① 补齐 `handle_start_values` 基线（多端点拖拽时其他端点可能没预先记录）
      ② 算出整体 k 与各轴的 dv_new

    返回 `(k, k_raw, {ax: dv_new}, span)`；未启用 / 端点段 / 手柄零长 → None。

    ⚠️ 基线一律取 `_session.handle_start_values`（**按下时**的值）。
       若改用"当前值"，每次 MOUSEMOVE 都会在已改过的值上再改一次
       ⇒ 指数增长 ⇒ 手柄飞走（2026-09-17 实测踩过的坑）。
    ⚠️ `span` 用现成的 `td.resolve_target`（别再手写一份段长计算）。
    """
    if not _uniform_mode(context):
        return None
    # ① 补齐基线
    for _ax, _kp in frame_kf_map.items():
        if _session.handle_start_values.get((frame, _ax)) is None:
            _h = _kp.handle_left if side == 'left' else _kp.handle_right
            _session.handle_start_values[(frame, _ax)] = (float(_h[0]), float(_h[1]))
    # ② span（端点段返回 None ⇒ 不做时间缩放）
    try:
        _kf2, span = td.resolve_target(action, obj, frame, side, bone_name)
    except Exception:
        span = None
    if not span:
        return None
    # ★★★ 2026-10-02：保速闸门改「屏幕口径」—— 与抓取环同一把尺子。
    #    屏幕 6px 以上（= 抓取环消失、手柄看得见）就该保速；
    #    旧的世界 1.0（≈49px）把"不保速"的范围放大了约 8 倍。
    _ref_local = None
    if all(_a in frame_kf_map for _a in (0, 1, 2)):
        _ref_local = (float(frame_kf_map[0].co[1]), float(frame_kf_map[1].co[1]),
                      float(frame_kf_map[2].co[1]))
    _len_min = _handle_zero_local_len(context, obj, bone_name, _ref_local)
    dv_base, dv_new, dt_base = {}, {}, {}
    for ax, kp in frame_kf_map.items():
        init = _session.handle_start_values.get((frame, ax))
        if init is None:
            continue
        fac = (factors.get(ax, 1.0) if factors else 1.0) or 1.0
        dv0 = float(init[1]) - float(kp.co[1])
        dv_base[ax] = dv0
        dv_new[ax] = dv0 + float(total_offset_local_scaled[ax]) / float(fac)
        dt_base[ax] = float(init[0]) - float(kp.co[0])
    if not dv_base:
        return None
    axes = sorted(dv_base)
    ks = xf.handle_scale_k([dv_base[a] for a in axes],
                           [dv_new[a] for a in axes],
                           [dt_base[a] for a in axes], span,
                           len_min=_len_min)
    if ks is None:
        return None
    return (ks[0], ks[1], dv_new, span)


def _write_uniform(keyframe, side, init, dv_new_a, k, k_raw, span):
    """【唯一实现】把同比例缩放写进**一个轴**。返回 (dv, dt)。"""
    dv_b = float(init[1]) - float(keyframe.co[1])
    dt_b = float(init[0]) - float(keyframe.co[0])
    return xf.scale_handle_uniform(keyframe, side, dv_b, dt_b,
                                   dv_new_a, k, k_raw, span)


def apply_handle_point_offset(context, total_offset_world, handle_point):
    if not all(math.isfinite(c) and abs(c) < SAFE_LIMIT for c in total_offset_world):
        return

    obj = _get_drag_obj(context)
    if not obj or not obj.animation_data or not obj.animation_data.action:
        return
    
    action = obj.animation_data.action
    frame = handle_point['frame']
    side = handle_point['side']
    bone_name = handle_point.get('bone_name')
    bone = (obj.pose.bones.get(bone_name) if (bone_name and obj.mode == 'POSE' and obj.pose) else None)
    global_scale = context.window_manager.rtmp_handle_scale
    
    parent_matrix = resolve_parent_transform(obj, bone)
    rotation_matrix = parent_matrix.to_3x3()
    
    total_offset_local = rotation_matrix.inverted() @ total_offset_world
    total_offset_local_scaled = total_offset_local / global_scale
    
    frame_kf_map = {}
    for fcurve in collect_animation_curves(action, obj):
        if not is_position_animation(fcurve, bone_name):
            continue
        for keyframe in fcurve.keyframe_points:
            if abs(keyframe.co[0] - frame) < FRAME_EPS:
                frame_kf_map[fcurve.array_index] = keyframe
                break
    
    # ★★ 修复（2026-09-16，P1）：**先记录原类型，再 prepare**。
    #
    # 旧顺序：prepare_handles_for_edit() 先把 VECTOR 改成 FREE（永久），
    #         然后循环里才读 handle_left_type 当"原类型"
    #         → 读到的已是 FREE → 结束时"恢复"成 FREE
    #         → **VECTOR 类型被永久破坏**（实测确认）。
    #
    # 实测基线（修复前，拖手柄后的类型）：
    #     AUTO_CLAMPED / AUTO / ALIGNED / FREE → 类型不变 ✓
    #     VECTOR                              → ★被改成 FREE
    # ★★ 同上：按原生语义接管类型（两侧都接管）。
    xf.prepare_handles_for_drag(action, obj, [(frame, side)], bone_name)

    # ★ P1：用 prepare 返回的【原类型】
    original_types = prepare_handles_for_edit(frame_kf_map) or {}

    factors_left, factors_right = compute_handle_display_factors(frame_kf_map)

    # ★ 同比例模式：预演（只读）—— 必须在下面任何写入之前
    _uni = _uniform_plan(context, action, obj, frame, side, bone_name,
                         (factors_left if side == 'left' else factors_right),
                         total_offset_local_scaled, frame_kf_map)

    # ★★★ 2026-09-17 用户实测：「拖尾部端点的手柄出来时，手柄不会和路径
    #      相切，也没有和路径有预期交互」——**零长端点手柄拖出 ⇒ 方向锁切线**。
    #
    #   实测（磁盘干净起点、只改拖动方向，该处来路方向 [-0.91,-0.087,0.406]）：
    #       沿 +X 拖 → 手柄 [1,0,0]     与来路夹角 **155.4°**
    #       沿 +Y 拖 → 手柄 [0,1,0]     夹角 **95.0°**
    #       沿 +Z 拖 → 手柄 [0,0,1]     夹角 **66.0°**
    #       斜 X+Y   → 手柄 [.707,.707,0] 夹角 **134.8°**
    #   ⇒ 零长手柄的基线是 0 ⇒ 同比例"无定义" ⇒ 走退化分支（只写鼠标位移）
    #     ⇒ **手柄方向 = 纯鼠标拖动方向**。碰巧沿切线拖时才看着正常
    #     ⇒ 用户"有时对有时不对、难复现"。
    #
    #   修法：方向 = 该点**路径切线**（端点内侧朝曲线内部），长度 = 鼠标位移长度
    #   ⇒ 拖出来**一定相切**，长度仍然跟手。
    #   ⚠️ 只在「端点内侧（span is None）+ 基线零长」时生效：
    #      一旦有了长度就走同比例（正常路径）；中间帧手柄正常不为零长，不受影响。
    _dir_lock = None
    _dir_lock_len = 0.0
    if _uni is None and _is_endpoint_inner_handle(
            action, obj, frame, side, bone_name):
        _base3 = []
        for _ax in (0, 1, 2):
            _kfx = frame_kf_map.get(_ax)
            if _kfx is None:
                _base3 = []
                break
            _iv = _session.handle_start_values.get((frame, _ax))
            _bv = (float(_iv[1]) if _iv is not None
                   else float(_kfx.handle_left[1] if side == 'left'
                              else _kfx.handle_right[1]))
            _base3.append(_bv - float(_kfx.co[1]))
        # 基线短到"同比例无意义"（与 handle_scale_k 的阈值同口径）
        # ★★★ 2026-10-02：方向锁与保速闸门**必须同口径**（否则漂移出缝）——
        #    阈值的唯一来源是 `_handle_zero_local_len`（屏幕 6px，与抓取环同尺）。
        _thr3 = _handle_zero_local_len(
            context, obj, bone_name,
            (float(frame_kf_map[0].co[1]), float(frame_kf_map[1].co[1]),
             float(frame_kf_map[2].co[1]))
            if all(_a in frame_kf_map for _a in (0, 1, 2)) else None)
        if _thr3 is None:
            _thr3 = xf.UNIFORM_LEN_MIN          # 拿不到视图 ⇒ 旧口径（同旧版）
        if _base3 and math.sqrt(sum(x * x for x in _base3)) <= _thr3:
            _dir_lock = _path_tangent_unit(action, obj, frame, side, bone_name)
            if _dir_lock is not None:
                _dir_lock_len = mathutils.Vector(
                    total_offset_local_scaled).length

    for array_index, keyframe in frame_kf_map.items():
        # ★ 用【prepare 之前】记录的类型（不是当场读）
        original_left_type, original_right_type = original_types.get(
            array_index, ('FREE', 'FREE'))
        
        # ⛔ 已删除（2026-09-16 code review）：这里原来有一份手写的
        #    `AUTO* → ALIGNED` 转换，但它**永远不可达** —— 上面 1317 行的
        #    `xf.prepare_handles_for_drag` 已经按原生语义把 AUTO* 转掉了，
        #    而 `original_types` 正是在那之后记录的，不可能再含 AUTO*。
        #    实测：注释掉这段后全套 649 用例零差异。
        #    （类型接管请统一走 `xf.prepare_handles_for_drag`，别再手写第二份。）

        initial_val = _session.handle_start_values.get((frame, array_index))
        if initial_val is None:
            # ★ 多端点拖拽：其他端点没有预先记录基线 → 惰性记录（此时尚未被改）
            _h = keyframe.handle_left if side == 'left' else keyframe.handle_right
            _session.handle_start_values[(frame, array_index)] = (
                float(_h[0]), float(_h[1]))
            initial_val = _session.handle_start_values[(frame, array_index)]
        
        initial_pos_2d = mathutils.Vector(initial_val)
        
        factor = ((factors_left if side == 'left' else factors_right)
                  .get(array_index, 1.0))
        delta_val = total_offset_local_scaled[array_index] / factor

        if _uni is not None:
            # ★★ 同比例模式：值分量 + 时间分量一起按 k 缩放 ⇒ 关键帧处速度不变
            _k, _kraw, _dvmap, _span = _uni
            _write_uniform(keyframe, side, initial_val,
                           _dvmap.get(array_index,
                                      (initial_pos_2d[1] - keyframe.co[1]) + delta_val),
                           _k, _kraw, _span)
        elif _dir_lock is not None:
            # ★★ 零长端点手柄：方向锁**切线**、长度跟鼠标
            #    （见 `_dir_lock` 的说明；这条路径是**拖端点空心圆**的入口）
            _nv = float(keyframe.co[1]) + _dir_lock[array_index] * _dir_lock_len
            if side == 'left':
                if hasattr(keyframe, 'handle_left'):
                    keyframe.handle_left[1] = _nv
            else:
                if hasattr(keyframe, 'handle_right'):
                    keyframe.handle_right[1] = _nv
        elif side == 'left':
            if hasattr(keyframe, 'handle_left'):
                keyframe.handle_left[0] = initial_pos_2d[0]
                keyframe.handle_left[1] = initial_pos_2d[1] + delta_val
        else:
            if hasattr(keyframe, 'handle_right'):
                keyframe.handle_right[0] = initial_pos_2d[0]
                keyframe.handle_right[1] = initial_pos_2d[1] + delta_val
        
        temp_handle_vector_local = mathutils.Vector((0.0, 0.0, 0.0))
        if side == 'left':
            temp_handle_vector_local[array_index] = keyframe.co[1] - keyframe.handle_left[1]
        else:
            temp_handle_vector_local[array_index] = keyframe.handle_right[1] - keyframe.co[1]

        update_linked_handle(keyframe, side, temp_handle_vector_local, array_index)
        
        # ★★ P1：恢复【全部】类型，不再只处理 {'VECTOR','FREE'}。
        #    （旧写法漏了 AUTO 系与 ALIGNED —— 虽然实测它们恰好没被改坏，
        #      但那是"因为 prepare/临时改类型恰好没影响它们"，不是设计保证。
        #      现在无条件写回，语义明确、不依赖巧合。）
        keyframe.handle_left_type = original_left_type
        keyframe.handle_right_type = original_right_type
    
    for fcurve in collect_animation_curves(action, obj):
        if is_position_animation(fcurve, bone_name):
            fcurve.update()

    # ★★ P2.1（2026-09-16）：加权收尾（同上，数学在 xf.finish_linked_handle）。
    #    ⚠️ 必须在上面那句 fc.update() 【之后】。
    finish_linked_handle(action, obj, frame, side, bone_name, context=context)


def _apply_one_handle_offset(obj, action, frame, side,
                             total_offset_local_scaled, global_scale,
                             bone_name, rotation_matrix, context=None):
    """把位移应用到一个端点（内部实现，供多端点循环调用）。"""
    # ★★ 按 Blender【原生语义】接管手柄类型（见 xf.prepare_handles_for_drag）：
    #      AUTO / AUTO_CLAMPED → ALIGNED   （手册："convert to Align when moved"）
    #      VECTOR              → FREE      （手册："convert to Free when moved"）
    #      **两侧都接管** —— 只转被拖侧的话，对侧 AUTO_CLAMPED 会被 Blender
    #      重算：臂长突变（用户看到"跳"）+ 永久不共线（实测 dev 0.832）。
    #    不接管则更糟：默认工程下拖手柄位移 = 0.0000（完全没反应）。
    xf.prepare_handles_for_drag(action, obj, [(frame, side)], bone_name)

    frame_kf_map = {}
    for fcurve in collect_animation_curves(action, obj):
        if not is_position_animation(fcurve, bone_name):
            continue
        for keyframe in fcurve.keyframe_points:
            if abs(keyframe.co[0] - frame) < FRAME_EPS:
                frame_kf_map[fcurve.array_index] = keyframe
                break
    
    # ★ P1：用 prepare 返回的【原类型】（它内部会把 VECTOR 临时改成 FREE）
    prev_types = prepare_handles_for_edit(frame_kf_map) or {}

    factors_left, factors_right = compute_handle_display_factors(frame_kf_map)

    # ★ 同比例模式：预演（只读）—— 必须在下面任何写入之前
    _uni = _uniform_plan(context, action, obj, frame, side, bone_name,
                         (factors_left if side == 'left' else factors_right),
                         total_offset_local_scaled, frame_kf_map)

    # ★★★ 2026-09-17 用户实测：「拖尾部端点的手柄出来时，手柄不会和路径
    #      相切，也没有和路径有预期交互」——**零长端点手柄拖出 ⇒ 方向锁切线**。
    #
    #   实测（磁盘干净起点、只改拖动方向，该处来路方向 [-0.91,-0.087,0.406]）：
    #       沿 +X 拖 → 手柄 [1,0,0]     与来路夹角 **155.4°**
    #       沿 +Y 拖 → 手柄 [0,1,0]     夹角 **95.0°**
    #       沿 +Z 拖 → 手柄 [0,0,1]     夹角 **66.0°**
    #       斜 X+Y   → 手柄 [.707,.707,0] 夹角 **134.8°**
    #   ⇒ 零长手柄的基线是 0 ⇒ 同比例"无定义" ⇒ 走退化分支（只写鼠标位移）
    #     ⇒ **手柄方向 = 纯鼠标拖动方向**。碰巧沿切线拖时才看着正常
    #     ⇒ 用户"有时对有时不对、难复现"。
    #
    #   修法：方向 = 该点**路径切线**（端点内侧朝曲线内部），长度 = 鼠标位移长度
    #   ⇒ 拖出来**一定相切**，长度仍然跟手。
    #   ⚠️ 只在「端点内侧（span is None）+ 基线零长」时生效：
    #      一旦有了长度就走同比例（正常路径）；中间帧手柄正常不为零长，不受影响。
    _dir_lock = None
    _dir_lock_len = 0.0
    if _uni is None and _is_endpoint_inner_handle(
            action, obj, frame, side, bone_name):
        _base3 = []
        for _ax in (0, 1, 2):
            _kfx = frame_kf_map.get(_ax)
            if _kfx is None:
                _base3 = []
                break
            _iv = _session.handle_start_values.get((frame, _ax))
            _bv = (float(_iv[1]) if _iv is not None
                   else float(_kfx.handle_left[1] if side == 'left'
                              else _kfx.handle_right[1]))
            _base3.append(_bv - float(_kfx.co[1]))
        # 基线短到"同比例无意义"（与 handle_scale_k 的阈值同口径）
        # ★★★ 2026-10-02：方向锁与保速闸门**必须同口径**（否则漂移出缝）——
        #    阈值的唯一来源是 `_handle_zero_local_len`（屏幕 6px，与抓取环同尺）。
        _thr3 = _handle_zero_local_len(
            context, obj, bone_name,
            (float(frame_kf_map[0].co[1]), float(frame_kf_map[1].co[1]),
             float(frame_kf_map[2].co[1]))
            if all(_a in frame_kf_map for _a in (0, 1, 2)) else None)
        if _thr3 is None:
            _thr3 = xf.UNIFORM_LEN_MIN          # 拿不到视图 ⇒ 旧口径（同旧版）
        if _base3 and math.sqrt(sum(x * x for x in _base3)) <= _thr3:
            _dir_lock = _path_tangent_unit(action, obj, frame, side, bone_name)
            if _dir_lock is not None:
                _dir_lock_len = mathutils.Vector(
                    total_offset_local_scaled).length

    for array_index, keyframe in frame_kf_map.items():
        original_left_type, original_right_type = prev_types.get(
            array_index, ('FREE', 'FREE'))
        
        initial_val = _session.handle_start_values.get((frame, array_index))
        if initial_val is None:
            # ★ 多端点拖拽：其他端点没有预先记录基线 → 惰性记录（此时尚未被改）
            _h = keyframe.handle_left if side == 'left' else keyframe.handle_right
            _session.handle_start_values[(frame, array_index)] = (
                float(_h[0]), float(_h[1]))
            initial_val = _session.handle_start_values[(frame, array_index)]
        
        initial_pos_2d = mathutils.Vector(initial_val)
        
        if side == 'left':
            factor = factors_left.get(array_index, 1.0)
        else:
            factor = factors_right.get(array_index, 1.0)
        delta_val = total_offset_local_scaled[array_index] / factor

        if _uni is not None:
            # ★★ 同比例模式：值分量 + 时间分量一起按 k 缩放 ⇒ 关键帧处速度不变
            _k, _kraw, _dvmap, _span = _uni
            _write_uniform(keyframe, side, initial_val,
                           _dvmap.get(array_index,
                                      (initial_pos_2d[1] - keyframe.co[1]) + delta_val),
                           _k, _kraw, _span)
        elif _dir_lock is not None:
            # ★★ 零长端点手柄：方向锁**切线**、长度跟鼠标（见上方 _dir_lock 说明）。
            #    基准用 keyframe.co（手柄从关键帧点长出来），不用 initial_pos_2d
            #    —— 后者的值分量在"零长"时才是 ≈ co，用 co 语义更干净。
            _nv = float(keyframe.co[1]) + _dir_lock[array_index] * _dir_lock_len
            if side == 'left':
                keyframe.handle_left[1] = _nv
            else:
                keyframe.handle_right[1] = _nv
        elif side == 'left':
            keyframe.handle_left[1] = initial_pos_2d[1] + delta_val
        else:
            keyframe.handle_right[1] = initial_pos_2d[1] + delta_val
        
        temp_handle_vector_local = mathutils.Vector((0.0, 0.0, 0.0))
        if side == 'left':
            temp_handle_vector_local[array_index] = keyframe.co[1] - keyframe.handle_left[1]
        else:
            temp_handle_vector_local[array_index] = keyframe.handle_right[1] - keyframe.co[1]
        
        update_linked_handle(keyframe, side, temp_handle_vector_local, array_index)
        
        keyframe.handle_left_type = original_left_type
        keyframe.handle_right_type = original_right_type
    
    for fcurve in collect_animation_curves(action, obj):
        if is_position_animation(fcurve, bone_name):
            fcurve.update()

    # ★★ P2.1（2026-09-16）：加权收尾。
    #    老逻辑 update_linked_handle 只逐轴按 (t,v) 斜率写对侧的【值分量】、没有加权，
    #    实测在各轴手柄时间比例 λ 不同时 3D 折角**修不动**（5.237 → 4.457）。
    #    ⚠️ 必须在上面那句 fc.update() 【之后】：update 会让 Blender 按它自己的
    #       (t,v) 规则重算对侧，写在前面会被覆盖。
    finish_linked_handle(action, obj, frame, side, bone_name, context=context)


# ===========================================================================
# C. 联动收尾与快照
# ===========================================================================
def _get_drag_obj(context):
    global _session
    if _session.drag_target_object:
        try:
            obj = bpy.data.objects.get(_session.drag_target_object)
            if obj:
                return obj
        except Exception:
            warn_once("edit_geometry._get_drag_obj")
            pass
    return context.active_object


def prepare_handles_for_edit(frame_kf_map):
    # ★★ P1 修复（2026-09-16）：改成【返回原类型】，让调用方在结束时写回。
    #
    # 旧实现只改不存 → 调用方读 `handle_left_type` 当"原类型"时读到的已是 FREE
    # → 结束时"恢复"成 FREE → **VECTOR 类型被永久破坏**（实测确认）。
    #
    # 返回 {array_index: (hl_type, hr_type)}，供调用方恢复。
    #
    # ⚠️ 现状（2026-09-16 code review 记录）：
    #    1. 下面那个 `两侧都是 VECTOR → 都转 FREE` 的分支**已不可达** ——
    #       两个调用点（1147/1317 附近）都在 `xf.prepare_handles_for_drag`
    #       **之后**，那时 VECTOR 早已被按原生语义转成 FREE。
    #       保留它只作防御（万一将来有路径不先调 prepare_handles_for_drag）。
    #    2. 因此它返回的"原类型"其实是**转换后**的类型；调用方那两处
    #       "写回原类型"等于把同一个值写回去（no-op）。
    #    3. 类型接管的**唯一入口**是 `xf.prepare_handles_for_drag`；
    #       本函数今后只当"读取当前类型"用，不要再往这里加类型规则。
    prev = {}
    for array_index, keyframe in frame_kf_map.items():
        prev[array_index] = (str(keyframe.handle_left_type),
                             str(keyframe.handle_right_type))
        if (keyframe.handle_left_type == 'VECTOR' and 
            keyframe.handle_right_type == 'VECTOR'):
            
            original_left = keyframe.handle_left.copy()
            original_right = keyframe.handle_right.copy()
            
            keyframe.handle_left_type = 'FREE'
            keyframe.handle_right_type = 'FREE'
            
            keyframe.handle_left = original_left
            keyframe.handle_right = original_right
    return prev


def update_linked_handle(keyframe, moved_handle_side, handle_vector_local, array_index):
    # ★★ 2026-09-16 重构：判据收敛到 `xf._link_mode`（**【唯一】定义**，两条路径共用）。
    #
    #  旧实现在这里**手写了一份判断**（both_free + is_frozen 两段拼起来），
    #  与端点模态路径 `xf.maintain_linked_handle` 的判据**语义不一致**：
    #
    #    · 端点模态：对侧是 FREE → return（不联动）
    #    · 鼠标路径：两侧都 FREE 且【已登记】→ 联动
    #    ⇒ 同一个关键帧（速度编辑过的），模态操作时对侧**不动**、
    #      鼠标拖拽时对侧**动** → 用户看到「只能作用于一端 + 之后再拖跳变」。
    #
    #  `_link_mode` 已统一包含（**只有三个返回值，没有 'auto'**）：
    #     ALIGNED / AUTO* / 插件冻的或接管的 FREE → 'link'（绕 co 旋转保持共线）
    #     用户手动 FREE                            → 'free'（完全独立，绝不动）
    #     VECTOR                                   → 'vector'（对侧贴到控制点）
    mode = xf._link_mode(keyframe, moved_handle_side)

    if mode == 'free':
        return

    if mode == 'vector':
        if moved_handle_side == 'left':
            keyframe.handle_right[1] = keyframe.co[1]
        else:
            keyframe.handle_left[1] = keyframe.co[1]
        return

    # mode == 'link'（ALIGNED，或插件自己冻的 FREE）
    co = mathutils.Vector(keyframe.co)

    if moved_handle_side == 'left':
        handle_active = mathutils.Vector(keyframe.handle_left)
        handle_opposite = mathutils.Vector(keyframe.handle_right)
        target_handle_attr = 'handle_right'
    else:
        handle_active = mathutils.Vector(keyframe.handle_right)
        handle_opposite = mathutils.Vector(keyframe.handle_left)
        target_handle_attr = 'handle_left'

    dx_active = handle_active.x - co.x       # = dt（时间分量）
    dy_active = handle_active.y - co.y
    dx_opposite = handle_opposite.x - co.x

    # ⚠️⚠️ 两道数值保护（2026-09-16 实测踩坑）——
    #     这里是 `slope = dv / dt`，**dt 在分母上**，而且外推还要再乘对侧 dt。
    #     **速度编辑能把 dt 压到 ~1e-3 帧**（旧阈值 0.0001 拦不住 0.001）：
    #
    #         实测：拖被速度编辑过的一侧 → 斜率 = dv/0.001 = 上千
    #               → 对侧沿 (t,v) 直线外推 → 手柄炸到 (-5766, -8652)
    #
    #     ① dt 低于可分辨下限 → 斜率**无定义**，直接放弃
    #     ② 外推结果超出安全值域 → 配置病态，直接放弃
    #     两种放弃都**不是丢功能**：紧随其后的 `xf.finish_linked_handle`
    #     会走三维通路（方向 + 臂长，全程不除 dt）把对侧摆正。
    if abs(dx_active) <= xf.DT_EPS:
        return
    slope = dy_active / dx_active
    new_y_opposite = co.y + (slope * dx_opposite)
    if (not math.isfinite(new_y_opposite)
            or abs(new_y_opposite - co.y) > _MAX_TV_EXTRAP):
        return

    if target_handle_attr == 'handle_right':
        keyframe.handle_right[1] = new_y_opposite
    else:
        keyframe.handle_left[1] = new_y_opposite


def resolve_handle_anchor_pos(context, handle_point):
    global _session
    obj = _get_drag_obj(context)
    frame = handle_point['frame']
    bone_name = handle_point.get('bone_name')
    
    if not obj:
        return mathutils.Vector((0, 0, 0))
    
    obj_cache = _session.cached_positions.get(obj.name, {})
    cache_key = bone_name if bone_name else None
    sub_cache = obj_cache.get(cache_key, {})
    cache_data = sub_cache.get(frame)
    if cache_data:
        return cache_data['position']
    
    return mathutils.Vector((0, 0, 0))


def record_endpoint_snapshot(action, obj, frame_num, handle_side, bone_name):
    """★ P2.1（2026-09-16）：记录被拖端点（含多选）的【三点快照】。

    用途：加权收尾要取"对侧手柄的**原始** 3D 长度"。
    ⚠️ 必须在任何写入**之前**记录 —— `fc.update()` 之后 Blender 会按它自己的
       (t,v) 规则把对侧长度改掉，那时再读就是错的（会每帧漂移）。
    """
    try:
        eps = [(float(frame_num), str(handle_side))]
        for (ef, es) in (getattr(_session, "selected_handle_endpoints", None) or []):
            pair = (float(ef), str(es))
            if pair not in eps:
                eps.append(pair)
        _session.endpoint_snapshot = xf.snapshot_endpoints(action, obj, eps, bone_name)
    except Exception as exc:
        # ⚠️ 不静默：出错就降级为"无快照"（加权收尾会自己跳过），但要把原因打出来
        _session.endpoint_snapshot = {}
        print("[RTMP] record_endpoint_snapshot failed:", exc)


def record_handle_baseline(context, frame_num, selected_bone_name, handle_side):
    global _session
    _session.handle_start_values = {}
    # ⚠️ 一并清掉旧快照：若下面提前 return（frame_kf_map 为空），
    #    残留的上一轮快照会让加权收尾取到**错的**对侧原始长度。
    _session.endpoint_snapshot = {}
    
    obj = _get_drag_obj(context)
    if not obj or not obj.animation_data or not obj.animation_data.action:
        return
    
    action = obj.animation_data.action
    fcurves = collect_animation_curves(action, obj)
    
    frame_kf_map = {}
    for i, fcurve in enumerate(fcurves):
        if is_position_animation(fcurve, selected_bone_name):
            for kp in fcurve.keyframe_points:
                if abs(kp.co[0] - frame_num) < 0.001:
                    array_index = fcurve.array_index
                    frame_kf_map[array_index] = kp
                    break
    
    if not frame_kf_map:
        return
    
    for array_index, kp in frame_kf_map.items():
        if handle_side == 'left':
            _session.handle_start_values[(frame_num, array_index)] = (kp.handle_left[0], kp.handle_left[1])
        else:
            _session.handle_start_values[(frame_num, array_index)] = (kp.handle_right[0], kp.handle_right[1])

    # ★★ P2.1（2026-09-16）：再记一份【三点快照】（必须在拖拽写入之前）
    record_endpoint_snapshot(action, obj, frame_num, handle_side,
                                  selected_bone_name)


def finish_linked_handle(action, obj, frame, side, bone_name,
                         context=None, zero_eps=None):
    """★ P2.1（2026-09-16）：鼠标拖手柄路径的**三维收尾**。

    数学在 `xf.finish_linked_handle`（复用 `maintain_linked_handle`）。
    老逻辑 `update_linked_handle` 只逐轴按 (t,v) 斜率写对侧的**值分量**，
    实测在各轴手柄时间比例 λ 不同时 3D 折角**修不动**：
        初始 5.237 → 拖后 4.457（三维通路是 0.0000）。

    ⚠️ 2026-09-16（第十轮）起，收尾**只摆三维方向 + 臂长，不再改对侧 dt**
       —— 用户拍板 3D 视图优先、Graph Editor 不需要共线，
       改 dt 会把速度分布抹掉（对 3D 零收益）。见 `xf._apply_weight` 的 docstring。
    """
    try:
        snap = getattr(_session, "endpoint_snapshot", None) or {}
        # ★★ 2026-09-17：把「视觉零」的【世界】阈值换算好传下去。
        #    封口闸门（`xf._ARM_EPS = 1e-9` 世界）与空心圆判据（屏幕 6px）
        #    原本差 6 个数量级 ⇒ 用户把两侧缩到关键帧点后一拖，
        #    对侧 ALIGNED 就被封口成 FREE（实测反馈）。
        #    现在两处共用同一语义：屏幕上 ≤ 6px 就算零。
        if zero_eps is None and context is not None:
            try:
                # ⚠️⚠️ 2026-09-27（3c）：两处口径修正，缺一不可 ——
                #
                #  ① 参考点必须是**世界坐标**：
                #     `cached_positions[...]["position"]` 是**局部空间**的
                #     （README_DEV 明说"独立于父级的本地空间"），
                #     直接喂给 `world_eps_for_screen(…, point_3d_world)`
                #     会让像素密度取错 ⇒ 阈值偏。
                #  ② 换算结果必须落到**局部口径**：
                #     闸门比的是 F-Curve 值分量的长度（局部、不含 gs/ps），
                #     而绘制判零比的是世界长度 ⇒ 两者差 ps·gs 倍。
                #     详见 `drawing.local_eps_for_screen` 的说明。
                ref = None
                _pm = None
                if obj is not None:
                    _bone = None
                    if bone_name and obj.mode == 'POSE' \
                            and bone_name in obj.pose.bones:
                        _bone = obj.pose.bones[bone_name]
                    _pm = resolve_parent_transform(obj, _bone)
                    _c = _session.cached_positions.get(obj.name)
                    if _c:
                        for _bkey, _fr in _c.items():
                            _e = _fr.get(int(round(frame)))
                            if _e and _e.get("position") is not None:
                                ref = _pm @ _e["position"]      # 局部 -> 世界
                                break
                if ref is None:
                    ref = getattr(_session, "world_origin", None)
                if ref is None and obj is not None:
                    # ★★ 2026-09-27（3c）：兜底用**物体原点**（总能拿到）。
                    #
                    # ⚠️⚠️ 绝不能在这里退回 `_ARM_EPS`(1e-9) ——
                    #    那等于**静默恢复** 2026-09-17 修掉的那个 bug：
                    #    视觉零被判成"有长度" ⇒ 触发封口 ⇒ 对侧 ALIGNED
                    #    被永久改成 FREE。
                    #    （既有报告《分析_交互层代码质量》B12 早就点过这个模式：
                    #      "兜底 None 会重新引入那个 bug"。
                    #      实测：`cached_positions` 为空时正是这条路径。）
                    try:
                        ref = obj.matrix_world.translation.copy()
                    except Exception:
                        ref = None
                if ref is not None:
                    _gs = 1.0
                    try:
                        _gs = float(context.window_manager.rtmp_handle_scale)
                    except Exception:
                        _gs = 1.0
                    zero_eps = local_eps_for_screen(context, ref, _pm, _gs)
            except Exception:
                zero_eps = None
        if zero_eps is None:
            return xf.finish_linked_handle(action, obj, snap, frame, side, bone_name)
        return xf.finish_linked_handle(action, obj, snap, frame, side, bone_name,
                                       zero_eps=zero_eps)
    except Exception as exc:
        print("[RTMP] finish_linked_handle failed:", exc)
        return False
