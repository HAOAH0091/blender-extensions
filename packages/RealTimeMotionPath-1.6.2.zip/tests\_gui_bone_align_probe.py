# -*- coding: utf-8 -*-
"""真机探针 v3：骨骼（姿态模式）场景下，双击三角能否正确对齐。

假设：`toggle_frame_lock` 只取 hit['frame']/hit['tri']，**丢了 hit['bone_name']**；
     `_align_opposite_speed` → `td.resolve_target(act, obj, frame, side)` 因此
     用 bone_name=None ⇒ 只匹配【对象级】location 曲线（骨骼曲线路径是
     `pose.bones["X"].location`，匹配不上）⇒ 取不到 tm 或取错目标。
"""
import sys, os, json, traceback, importlib

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)
import bpy

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})

def main():
    try:
        import addon_utils
        addon_utils.enable(PKG_NAME, default_set=True, persistent=True)
        it = importlib.import_module(PKG_NAME + ".interaction")
        hd = importlib.import_module(PKG_NAME + ".handles")
        cache = importlib.import_module(PKG_NAME + ".cache")
        td = importlib.import_module(PKG_NAME + ".time_domain")

        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.object.armature_add(location=(0, 0, 0))
        arm = bpy.context.view_layer.objects.active
        arm.name = "ARMP"
        bpy.ops.object.mode_set(mode='EDIT')
        eb = arm.data.edit_bones
        b2 = eb.new("Bone2")
        b2.head = (2.0, 0.0, 0.0); b2.tail = (3.0, 0.0, 0.0)
        names = [b.name for b in eb]
        bpy.ops.object.mode_set(mode='POSE')
        # 两根骨骼各打 location 关键帧
        for f, dx in [(1, 0.0), (25, 1.5), (55, 3.0)]:
            for nm in names:
                pb = arm.pose.bones[nm]
                pb.location = (dx, 0.0, 0.0)
                pb.keyframe_insert("location", frame=f)
        bpy.context.scene.frame_set(25)
        act = arm.animation_data.action
        step("场景：骨骼 armature + 2 根骨骼 + location 关键帧", len(names) >= 2, "骨骼=%s" % names)

        # 骨骼场景下的曲线路径长什么样
        paths = sorted({fc.data_path for fc in cache.collect_animation_curves(act, arm)})
        step("  action 里的曲线路径（确认是 pose.bones[...]）",
             any("pose.bones" in p for p in paths), json.dumps(paths, ensure_ascii=False)[:160])

        # ★ 核心：resolve_target 带/不带 bone_name 的差别
        k_all, span_all = td.resolve_target(act, arm, 25.0, 'left')
        k_b0, span_b0 = td.resolve_target(act, arm, 25.0, 'left', names[0])
        k_b1, span_b1 = td.resolve_target(act, arm, 25.0, 'left', names[1])
        step("★ resolve_target(bone_name=None) 能取到 kf_map 吗（对齐就靠它）",
             bool(k_all) and span_all is not None,
             "kf_map=%d span=%s" % (len(k_all), span_all))
        step("  resolve_target(带 Bone1) 能取到吗", bool(k_b0) and span_b0 is not None,
             "kf_map=%d span=%s" % (len(k_b0), span_b0))
        step("  resolve_target(带 Bone2) 能取到吗", bool(k_b1) and span_b1 is not None,
             "kf_map=%d span=%s" % (len(k_b1), span_b1))

        # ---- 真机上下文：三角算得出来吗 ----
        area = next((a for a in bpy.context.screen.areas if a.type == 'VIEW_3D'), None)
        sp = next((s for s in area.spaces if s.type == 'VIEW_3D'), None)
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        rv3d = sp.region_3d
        ctx = dict(bpy.context.copy())
        ctx.update(area=area, region=region, space_data=sp, region_data=rv3d)
        with bpy.context.temp_override(**ctx):
            handles = it._update_speed_hover(bpy.context, arm, region, rv3d,
                                             (region.width / 2.0, region.height / 2.0)) or []
            step("★ 骨骼场景下能看到速度三角吗（看得到才有得双击）", len(handles) > 0,
                 "三角数=%d，样本=%s" % (len(handles),
                     [(h.get('frame'), h.get('tri'), h.get('bone_name')) for h in handles[:4]]))
            if handles:
                h0 = handles[0]
                step("  handle 记录里带 bone_name 吗",
                     h0.get('bone_name') is not None, "bone_name=%r" % h0.get('bone_name'))
                ts = h0.get('tri_screen')
                if ts:
                    got = it._triangle_under_cursor(handles, (float(ts[0]), float(ts[1])))
                    step("  三角能被自己命中", got is not None,
                         "得到=%s" % (got.get('tri') if got else None))
                    # 双击
                    ok1, m1 = it.toggle_frame_lock(bpy.context, arm, float(h0['frame']),
                                                   handles, (float(ts[0]), float(ts[1])), region, rv3d)
                    step("  ① 双击 → 分离", ok1, str(m1)[:60])
                    ok2, m2 = it.toggle_frame_lock(bpy.context, arm, float(h0['frame']),
                                                   handles, (float(ts[0]), float(ts[1])), region, rv3d)
                    step("★★ ② 双击 → 锁回一体 + 对齐（骨骼场景）", ok2, str(m2)[:110])
                    # 共线检查（按骨骼）
                    for nm in names:
                        cross = []
                        for fc in cache.collect_animation_curves(act, arm):
                            if fc.data_path != 'pose.bones["%s"].location' % nm:
                                continue
                            for kp in fc.keyframe_points:
                                if abs(float(kp.co[0]) - float(h0['frame'])) < 1e-3:
                                    A = float(kp.co[1]) - float(kp.handle_left[1])
                                    B = float(kp.handle_right[1]) - float(kp.co[1])
                                    cross.append(abs(A * (float(kp.handle_right[0]) - float(kp.co[0]))
                                                     - B * (float(kp.co[0]) - float(kp.handle_left[0]))))
                        step("  ★ %s 的 GE 手柄是否共线" % nm,
                             bool(cross) and all(v < 1e-3 for v in cross),
                             "cross=%s" % ["%.2e" % v for v in cross[:3]])
    except Exception:
        step("EXCEPTION", False, traceback.format_exc())

    fails = [s for s in steps if not s["ok"]]
    print("=" * 74)
    for s in steps:
        print("[%s] %s  %s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                              ("<- " + s["detail"]) if s["detail"] else ""))
    print("断言 %d / 失败 %d" % (len(steps), len(fails)))
    print("=== GUI3_RESULT " + json.dumps({"fails": len(fails), "total": len(steps)}) + " ===")
    sys.stdout.flush()
    return None

bpy.app.timers.register(main, first_interval=2.0)
bpy.app.timers.register(lambda: (bpy.ops.wm.quit_blender(), None)[1], first_interval=30.0)
