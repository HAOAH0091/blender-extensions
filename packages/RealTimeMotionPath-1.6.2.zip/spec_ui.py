# -*- coding: utf-8 -*-
"""运动路径校正 —— 界面层（弹窗 / 还原 / 不再提示）。

命名（用户 2026-09-30 选定方案 D）
----------------------------------
    弹窗标题 = 「运动路径校正」
    按钮     = 「校正手柄」
    问题用词 = 「手柄与路径不贴合」

为什么不用「规范」这个词
------------------------
「规范」是站在插件角度说的 —— 用户看到会想"什么规范？谁定的？我违反了会怎样？"。
而这个功能的**真实目的**是：**让你在 3D 视图里拖手柄时，操作不走形**。
「校正 / 不贴合」是用户能直接理解的：**手柄和路径对不上**。

分层
----
    spec_check.py —— 纯数据（检测 + 微调）
    spec_ui.py    —— 界面（本文件）
    ui.py         —— 只留一个入口按钮

弹窗为什么必须用 timer 延迟
---------------------------
`invoke_props_dialog` 会开启一个**模态弹窗**。它**不能**从
`draw` 回调 / 属性 update 回调里直接调 —— 那些时机 Blender 正处在
绘制或属性写回的过程中，直接开模态会崩或者静默失败。

所以统一走 `bpy.app.timers.register(..., first_interval=0.15)`：
把"开弹窗"这件事推迟到主循环的下一个空档，那时 context 是干净的。
"""
import bpy

from bpy.app.translations import pgettext_iface as iface_

from . import spec_check as sc
from .state import _session, warn_once


# ---------------------------------------------------------------------------
# 「本次不再提示」表
# ---------------------------------------------------------------------------

def _ignore_key(obj, action, bone_name):
    return "%s|%s|%s" % (getattr(obj, "name", ""),
                         getattr(action, "name", ""),
                         bone_name or "")


def is_ignored(obj, action, bone_name=None):
    try:
        return _ignore_key(obj, action, bone_name) in (_session.spec_ignored or set())
    except Exception:
        return False


def mark_ignored(obj, action, bone_name=None):
    try:
        if _session.spec_ignored is None:
            _session.spec_ignored = set()
        _session.spec_ignored.add(_ignore_key(obj, action, bone_name))
    except Exception:
        warn_once("spec_ui.mark_ignored")


# ---------------------------------------------------------------------------
# 延迟开弹窗
# ---------------------------------------------------------------------------

def _deferred_popup(report):
    """把弹窗推迟到主循环（**不能在 draw / update 回调里直接开模态**）。"""
    def _fire():
        try:
            bpy.ops.rtmp.spec_fix('INVOKE_DEFAULT')
        except Exception:
            warn_once("spec_ui._deferred_popup")
        return None          # None = 不再重复
    try:
        bpy.app.timers.register(_fire, first_interval=0.15)
    except Exception:
        warn_once("spec_ui._deferred_popup.register")


def check_and_maybe_popup(context, obj=None, action=None, bone_name=None):
    """检查 + 有问题则延迟弹窗。**检测部分纯读**。

    返回 report（供调用方判断）。
    """
    try:
        obj = obj or context.active_object
        if obj is None or not getattr(obj, "animation_data", None):
            return None
        action = action or obj.animation_data.action
        if action is None:
            return None
        report = sc.detect(action, obj, bone_name)
        try:
            _session.spec_last_report = report
        except Exception:
            pass
        if not report.get("issues"):
            return report
        if is_ignored(obj, action, bone_name):
            return report
        _deferred_popup(report)
        return report
    except Exception:
        warn_once("spec_ui.check_and_maybe_popup")
        return None


# ---------------------------------------------------------------------------
# 弹窗内容
# ---------------------------------------------------------------------------

def _severity_icon(sev):
    return {'functional': 'ERROR',
            'prerequisite': 'INFO',
            'cosmetic': 'QUESTION',
            'info': 'INFO'}.get(sev, 'INFO')


def _metric_line(it):
    """把一条 issue 的**实测数字**拼成一行（供弹窗展示）。

    ⚠️ 每行必须带数字（角度 / 跨度 / 轴名），不能只写"有问题"——
       用户要靠这些数字判断"值不值得修"。
    """
    m = it.get("metrics") or {}
    k = it.get("kind")
    try:
        if k == "dt_mismatch":
            return iface_("Off by %.2f deg (time spans %s)") % (
                m.get("angle_deg", 0.0),
                " / ".join("%g" % v for v in (m.get("dt") or [])))
        if k == "missing_axis":
            ax = m.get("missing_axes") or []
            return iface_("Missing axis: %s") % "/".join(
                "XYZ"[a] for a in ax if 0 <= a <= 2)
        if k == "handle_bend":
            return iface_("Bent by %.2f deg - the path turns a corner here") % (
                m.get("fold_deg", 0.0))
    except Exception:
        warn_once("spec_ui._metric_line")
    return ""


def _draw_list(layout, items, bucket_icon):
    for it in items:
        col = layout.column(align=True)
        head = col.row()
        head.label(text=iface_("Frame %g") % it["frame"], icon=bucket_icon)
        head.label(text=iface_(sc.KIND_LABEL.get(it["kind"], it["kind"])))
        line = _metric_line(it)
        if line:
            sub = col.row()
            sub.label(text=line)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class RTMP_OT_SpecFix(bpy.types.Operator):
    """运动路径校正：列出问题、让用户勾选要修哪些。"""

    bl_idname = "rtmp.spec_fix"
    bl_label = "Motion Path Correction"
    bl_description = "Review the handle problems and choose which ones to correct (you can undo afterwards)"

    # ---- 只有一个勾选项 ----
    # ★★ 校正项**不再让用户选**（用户 2026-09-30 最终口径：
    #     「这个本来就是要保证的，不是选不选的问题，本来就是要校正这个，
    #       除非路径手柄已经被用户提前设置成自由」）
    #    ⇒ 点「确定」= 全部校正都做；不想要就点「取消」。
    #    ⚠️ description 必须写成**单行**字符串：
    #       i18n 覆盖检查按源码正则采集，**多行拼接只会取到第一行** ⇒ 翻译表对不上。
    # ★ 名称口径（用户 2026-09-30 确认）：
    #   「虽然我的表述是『强制对齐全部 GE 手柄』，
    #     但是你说实现时的表述可以是『强制对齐关键帧进出速度』」
    #   ⇒ 面向用户的标签用「进出速度」，因为它说清了"对齐的是什么"。
    #
    # ★ 描述口径（用户 2026-09-30 追加）：
    #   「这个描述需要变一下，这里需要**明确告知用户操作的是 Graph Editor 里的
    #     关键帧手柄**，以保证**进出速度不突变**」
    #   ⇒ 必须点明「Graph Editor 里的关键帧手柄」+「进出速度不突变」，
    #     否则用户会以为动的是 3D 视图的手柄（那是另一件事）。
    do_force_align: bpy.props.BoolProperty(
        name="Force-align keyframe in/out speeds",
        description="Align the left and right handles of every keyframe in the Graph Editor (Free-feel ones included) so the in/out speed does not jump; changes the path shape",
        default=sc.DEFAULT_APPLY["force_align"])
    do_ignore: bpy.props.BoolProperty(
        name="Do Not Ask Again",
        description="Stop showing this prompt for this object in this session (nothing is modified)",
        default=False)

    # 由调用方注入（不走属性系统，避免大 dict 被当成可序列化属性）
    _report = None

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(obj and getattr(obj, "animation_data", None)
                    and obj.animation_data.action)

    def invoke(self, context, event):
        obj = context.active_object
        report = None
        try:
            report = _session.spec_last_report
        except Exception:
            report = None
        if not report or not (report.get("issues") or report.get("hints")):
            try:
                report = sc.detect(obj.animation_data.action, obj, None)
            except Exception:
                report = None
        # ★★ 有 issues **或** hints 都要开弹窗（2026-09-30 用户实测抓到）：
        #    用户工程只有"折角"提示（issues = 0）⇒ 旧逻辑直接 CANCELLED
        #    ⇒ 「强制对齐 GE 手柄」这个**可选项根本够不到**，
        #      而这恰恰是需要它的场景（折角 ⟹ 路径拐角）。
        if not report or not (report.get("issues") or report.get("hints")):
            self.report({'INFO'}, iface_("Handles already follow the path"))
            return {'CANCELLED'}
        self._report = report
        return context.window_manager.invoke_props_dialog(
            self, width=540, title=iface_("Motion Path Correction"))

    def draw(self, context):
        layout = self.layout
        report = self._report or {}
        issues = report.get("issues") or []
        hints = report.get("hints") or []

        # ---- 需要处理的问题 ----
        box = layout.box()
        if issues:
            box.label(text=iface_("Found %d handle problem(s)") % len(issues),
                      icon='ERROR')
            _draw_list(box, issues[:10], 'ERROR')
            if len(issues) > 10:
                box.label(text=iface_("... and %d more") % (len(issues) - 10))
        else:
            # 只有折角提示时（issues = 0）：说清楚"没毛病"，别让用户以为弹窗是空的
            box.label(text=iface_("Handles follow the path - nothing to fix"),
                      icon='CHECKMARK')

        # ---- 仅供参考（不影响 3D 操作）----
        if hints:
            hbox = layout.box()
            hbox.label(text=iface_("For your information (not errors):"),
                       icon='INFO')
            _draw_list(hbox, hints[:5], 'INFO')

        # ---- 校正内容说明（**不是勾选项**，是"点确定就一定会做"的事）----
        info = layout.box()
        info.label(text=iface_("Pressing OK will:"), icon='INFO')
        info.label(text=iface_("Make the handles lie along the path"))
        info.label(text=iface_("Fill in any missing axis keyframes"))
        info.label(text=iface_("Switch handle types to Free (positions do not move)"))
        info.label(text=iface_("Free-feel handles are left untouched"))

        # ---- ★ 唯一的可选项（默认不勾）----
        opt = layout.box()
        opt.label(text=iface_("Optional:"), icon='INFO')
        opt.prop(self, "do_force_align")
        # ⚠️ 明说动的是 **Graph Editor 里的手柄**（不是 3D 视图的手柄）
        opt.label(text=iface_("(aligns the Graph Editor keyframe handles)"))

        layout.separator()
        layout.prop(self, "do_ignore")

        # ---- 还原入口 ----
        if getattr(_session, "spec_last_snapshot", None):
            layout.separator()
            # ⚠️ 必须显式传 text=iface_(...)：
            #    operator 的 bl_label **不**走 iface_ 那条翻译路径
            #    （实测：弹窗里显示成英文 "Revert Last Correction"）。
            layout.operator("rtmp.spec_revert",
                            text=iface_("Revert Last Correction"),
                            icon='LOOP_BACK')

    def execute(self, context):
        obj = context.active_object
        if obj is None or not getattr(obj, "animation_data", None):
            return {'CANCELLED'}
        action = obj.animation_data.action
        if action is None:
            return {'CANCELLED'}

        # ★ 校正项不再由用户勾选 ⇒ 传 None = 用 DEFAULT_APPLY（三项全做）
        #   唯一例外：勾了「强制对齐全部 GE 手柄」⇒ 把 force_align 也加进去
        #   （DEFAULT_APPLY 里它是 False，所以用 keys() 全取即可）
        kinds = None
        if self.do_force_align:
            kinds = list(sc.DEFAULT_APPLY.keys())

        report = self._report
        if not report or not report.get("issues"):
            try:
                report = sc.detect(action, obj, None)
            except Exception:
                return {'CANCELLED'}
        # ⚠️ 不再要求"必须有 issues" ——
        #    `align_handles` 是**可选平滑项**，它直接遍历 action 的所有关键帧，
        #    不依赖报告内容 ⇒ 只有折角提示时也必须能执行（否则够不到）。
        #    其余两条（补轴 / 统一 dt）走报告，没有 issues 时自然是空操作。
        try:
            result, snap = sc.apply_fix(action, obj, report, None, kinds=kinds)
        except Exception as exc:
            print("RealTimeMotionPath: spec_fix failed -> %r" % (exc,))
            self.report({'ERROR'}, iface_("Correction failed (see console)"))
            return {'CANCELLED'}

        # 存快照（供「还原上次校正」）+ 推 undo
        try:
            _session.spec_last_snapshot = snap
        except Exception:
            pass
        try:
            bpy.ops.ed.undo_push(message=iface_("Correct Motion Path Handles"))
        except Exception:
            warn_once("spec_ui.RTMP_OT_SpecFix.undo")
            pass            # 后台/无撤销上下文时忽略（不影响写入本身）

        # 用户勾了「不再提示」⇒ 记进忽略表（键含 obj/action ⇒ 换了自动失效）
        if self.do_ignore:
            mark_ignored(obj, action, None)

        # ★★ 2026-09-30 修 P1-2 / P1-3（Review 发现）：
        #    这两条结果**以前被算出来却从不显示** ——
        #      · `applied[kind] == -1` ⇒ 那个修正阶段**内部抛异常、根本没跑**；
        #      · `frozen` ⇒ 顺手把手柄冻成 FREE 的数量（**有副作用**）。
        #    `spec_check` 里的注释白纸黑字写着「供结果提示：**用户应该知道这件事发生了**」，
        #    但本函数以前只读 `after` ⇒ 两句话都没说出口。
        #    后果：某个阶段静默失败 / 手柄被冻，用户把"行为变了"当成 bug。
        _applied = result.get("applied") or {}
        _failed = sorted(k for k, v in _applied.items() if v == -1)
        try:
            _frozen = int(result.get("frozen") or 0)
        except Exception:
            _frozen = 0
        left = len(((result.get("after") or {}).get("issues")) or [])

        if _failed:
            # 阶段内部异常 ⇒ 那一项**没做**，必须报错（不能报"已修好"）
            self.report({'ERROR'}, iface_("Correction failed for: %s (see console)")
                        % ", ".join(_failed))
        elif left:
            self.report({'WARNING'}, iface_("%d issue(s) remain") % left)
        else:
            self.report({'INFO'}, iface_("Handles now follow the path"))
        if _frozen:
            # 副作用提示（保形状必需的冻结）—— 用户应该知道
            self.report({'INFO'}, iface_("(froze %d handle(s) to keep the shape)")
                        % _frozen)
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class RTMP_OT_SpecRevert(bpy.types.Operator):
    """还原上一次校正（把快照写回去，含删掉补出来的关键帧）。"""

    bl_idname = "rtmp.spec_revert"
    bl_label = "Revert Last Correction"
    bl_description = "Undo the last correction by restoring the saved snapshot"

    @classmethod
    def poll(cls, context):
        return bool(getattr(_session, "spec_last_snapshot", None))

    def execute(self, context):
        obj = context.active_object
        snap = getattr(_session, "spec_last_snapshot", None)
        if obj is None or not snap:
            self.report({'INFO'}, iface_("Nothing to revert"))
            return {'CANCELLED'}
        action = obj.animation_data.action if obj.animation_data else None
        if action is None:
            return {'CANCELLED'}
        try:
            sc.revert_fix(action, obj, snap, None)
        except Exception as exc:
            print("RealTimeMotionPath: spec_revert failed -> %r" % (exc,))
            self.report({'ERROR'}, iface_("Revert failed (see console)"))
            return {'CANCELLED'}
        _session.spec_last_snapshot = None
        try:
            bpy.ops.ed.undo_push(message=iface_("Revert Motion Path Correction"))
        except Exception:
            pass
        try:
            _session.spec_last_report = sc.detect(action, obj, None)
        except Exception:
            pass
        self.report({'INFO'}, iface_("Reverted"))
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class RTMP_OT_SpecIgnore(bpy.types.Operator):
    """「本次不再提示」：把这个对象加进忽略表，**不改任何数据**。

    键含 obj|action|bone ⇒ 换对象 / 换动画后自动失效（不会永久失明）。
    """

    bl_idname = "rtmp.spec_ignore"
    bl_label = "Do Not Ask Again"
    bl_description = "Stop showing this prompt for this object in this session (nothing is modified)"

    def execute(self, context):
        obj = context.active_object
        if obj is None or not getattr(obj, "animation_data", None):
            return {'CANCELLED'}
        action = obj.animation_data.action
        if action is None:
            return {'CANCELLED'}
        mark_ignored(obj, action, None)
        self.report({'INFO'}, iface_("Will not ask again for this object"))
        return {'FINISHED'}


classes = (
    RTMP_OT_SpecFix,
    RTMP_OT_SpecRevert,
    RTMP_OT_SpecIgnore,
)
