# Phase 0 · 代码 Review 发现清单

> 范围：本会话改动过的文件（必做）+ 全仓机械扫描（R1 到 R7 七维度）。
> 结论：**无 P0**（未发现崩溃 / 数据损坏）；**3 条 P1**（静默错误 / 用户被误导）；**3 条 P2**。
> 日期：2026-09-30
>
> ## ★ 状态：P1-1 / P1-2 / P1-3 + P2-1 / P2-3 **已修并验证**
>
> 回归测试 `tests/gui_review_fix_check.py`（**12 条断言，全绿**）。
> 下面的 **P1-4 已撤回**（我判错了，见该条说明）。

---

## 摘要

| # | 严重度 | 一句话 | 位置 |
|---|---|---|---|
| **P1-1** | **P1** | ✅**已修** 双击锁定目标被钳制后**落空**，状态栏仍报「进出速度已一致」（实测差 16.67 倍） | `interaction.py:756` |
| **P1-2** | **P1** | ✅**已修** spec 校正的阶段异常（`applied[kind] = -1`）**用户完全看不到** | `spec_ui.py:329` |
| **P1-3** | **P1** | ✅**已修** `frozen` 统计了却从不显示（注释明写"用户应该知道"） | `spec_ui.py:352` |
| ~~P1-4~~ | ~~P1~~ | ❌**已撤回（我判错了）** 见下方专节 | — |
| P2-1 | P2 | ✅**已修** `write_s` 写入循环无逐轴保护 ⇒ 中途失败留下"半写" | `time_domain.py:700` |
| P2-2 | P2 | ⏸ 待你定口径 "手柄太短"**三套阈值**（`1e-6` / `1e-12` / `1.0`） | 全仓 |
| P2-3 | P2 | ✅**已修** `feel_for_orig_type` 文档说"互逆"，实际 FREE 不互逆 | `transform_domain.py:813` |
| P2-4 | P2 | ⏸ 待你定口径 31 处内联 eps（`1e-9` x16 / `1e-12` x14）无命名常量 | 全仓 |
| P3-1 | 信息 | `apply_fix` 每种修正只跑一遍、无收敛循环 ⇒ 不保证幂等 | `spec_check.py:1248` |

---

## P1-1 · 双击锁定：目标落空却报"已一致"（★ 实测确认）

### 现象

`_align_opposite_speed` 算出对侧需要的新 `dt` 后，如果 `dt/span > S_HARD_MAX (1.0)`，
`write_s` 会**钳到 1.0**。此时对侧的实际速度 `dv/span != v_target` ⇒ **"两侧速度相等"这个目标落空**。

代码只把 `clamped` 放进 `info`（`interaction.py:515`），
而调用方 `toggle_frame_lock` 的文案（`:756-760`）**不看 `clamped`**，
无条件说「Handles locked together - **in/out speeds are now equal**」⇒ **对用户说谎**。

### 实测（`--background` 独立进程）

    构造：dv/span 两侧相差 33.33 倍（手工设手柄，复刻你工程里 1.763 vs 2.820 的形态）

    锁定前   |v| 左=0.03849  右=1.28300   ;  被双击侧=左 ⇒ v_target=0.03849
    对侧需要的 s = 16.6667   →   被钳到 S_HARD_MAX = 1.0
    clamped=True
    锁定后   |v| 左=0.03849  右=0.64150
    ★ 目标达成? NO  两侧速度差 16.67 倍
    ★ 状态栏说：「两个三角已锁定为一体 —— 进出速度已一致」

### 触发条件（很容易碰到）

    required_s = s_被双击侧 x (dv_对侧/span_对侧) / (dv_本侧/span_本侧) > 1.0

- **比例运动**（`dv/span` 两侧相等，如自动手柄 + 各轴同步）⇒ `required_s = s_被双击侧 <= 1` ⇒ **不会触发**
- **非比例运动**（真实工程常态）⇒ 只要 `dv/span` 两侧不等就会被放大
- **你的工程实测**：`dv/span` 左 1.763 / 右 2.820（差 1.6 倍）
  ⇒ **`s_被双击侧 > 0.625` 就会触发**（而 s 的常用范围到 1.0）

### 建议修法（二选一）

1. **提示**（最小改动）：`clamped` 为真时换一句文案，明说"对侧已到极限，速度**未能**完全一致（差 N 倍）"
2. **拒绝**：`clamped` 为真时**不写**，直接返回失败 + 原因，让用户先手动调对侧

> 推荐 1 + 2 组合：先尝试；钳制发生时**不写**并明确告知（避免"看起来改了其实没改"）。

---

## P1-2 · spec 校正的阶段异常用户看不到

`spec_check.apply_fix` 对每个阶段 `try/except`，出错时 `result["applied"][kind] = -1`，
只调 `warn_once`（写控制台）：
`
    except Exception:
        warn_once("spec_check.apply_fix." + kind)
        result["applied"][kind] = -1        # -1 = 出错
`

而 `spec_ui.RTMP_OT_SpecFix.execute` 拿到 `result` 后**只读了 `result["after"]`**（`:329`），
**从未读 `applied`**（全仓 grep：`applied` 只出现在 `spec_check` 自身与测试里）。

### 后果

某个修正阶段抛异常 ⇒ 那一项**没做**，但 `after` 只统计"还剩几条 issue"，
如果异常恰好发生在"本来就没 issue"的项上（如 `force_align`），`after` 仍为空 ⇒
用户看到「Handles now follow the path」**而实际上有一项根本没跑**。

### 建议修法

`execute` 里检查 `any(v == -1 for v in result["applied"].values())` ⇒ 用 `report({'ERROR'}, ...)` 告知。

---

## P1-3 · `frozen` 统计了却不显示

`spec_check.py:1268` 的注释白纸黑字：

> 统计"顺手冻结了几个手柄"（**供结果提示：用户应该知道这件事发生了**）

但 `spec_ui` **从不读 `result["frozen"]`**（grep 确认：只有 `spec_check` 自身和测试读它）。

### 为什么重要

校正会把手柄**转成 FREE**（副作用）—— 这会影响后续"拖一侧另一侧是否联动"的体验。
用户不知道这件事发生了，就会把"行为变了"当成 bug（这正是 2026-09-16 那两轮反馈的根源）。

### 建议修法

`frozen > 0` 时在状态栏补一句：「（顺手冻结了 N 个手柄 —— 这是保形状必需的）」。

---

## ~~P1-4~~ · ❌ 已撤回 —— 我判错了（保留记录以免重犯）

> **结论：这不是 bug。** 实测验证（`--background` 独立进程）：

    1) action A 设 feel=FREE（property = ['90.0000|left|FREE', ...])
    2) A 改名为 RENAMED_A  ⇒ A 的 feel_type 仍 = FREE ✓
    3) 新 action 恰好用 A 的旧名字，且没有该 property
    4) 新 action 的 feel_type = (None, None)   ← 期望值 ✓ 没串
    5) 新 action 的 link_mode = ('link','link') ✓
    6) 内存表里旧名字的残留条目 = []            ← 已被对账清掉 ✓

**我错在哪**：把 `act.get(_FEEL_PROP)` 当成了"读不到就抛异常"。
真实 Blender Action 上 `act.get(不存在的 key)` **返回 None，不抛异常** ⇒
那条早退分支**只对"鸭子类型假对象"触发**（注释里写得很清楚，我没读透）✗。
⇒ 于是 `raw = ()` ⇒ 快路径失配 ⇒ **清掉该名字的旧条目并重建** ✓ 链路是对的。

**教训**：判定"某个 `except` 分支会被触发"之前，**先实测那个操作到底抛不抛异常**。
`act.get()` / `obj.get()` 这类 API 的"缺失返回值"是 **None 而不是异常**，
这是 bpy 的通用约定 —— 凭直觉推断会得出完全相反的结论。

---

## （原 P1-4 记录，已作废）action 改名 + 名字复用 ⇒ 四表串数据

四张内存表的键都含 **action 名**：`(action_name, frame, side)`。

`_feel_sync` 的流程：

    1. nm = str(act.name)
    2. act.get(_FEEL_PROP)   ← 读不到就 return（**保留缓存不动**）
    3. 快路径：_FEEL_SRC.get(nm) == raw 且缓存有条目 ⇒ return
    4. 否则：清掉 k[0] == nm 的条目，从 property 重建

### 链路

- **action A 改名** ⇒ A 的旧名条目**留在 `_FEEL` 里**（清理循环只删新名）✗
- 之后某个 **新 action 恰好用了 A 的旧名**，且**没有 `rtmp_feel` property**（新 action 常态）
  ⇒ 第 2 步 `act.get(_FEEL_PROP)` 抛异常 ⇒ **提前 return** ⇒ 沿用 A 的**陈旧**体感记录 ✗✗

⇒ 新 action 的关键帧会"继承"另一个 action 的体感 / 冻结 / 锁定状态。

### 建议修法

- 清缓存时按 **action 对象身份**（`id()` / 弱引用）而不是名字；或
- 第 2 步失败时**也清掉**该名字的缓存（而不是保留）
- 更彻底：键里带 `act.as_pointer()`，名字只作显示

---

## P2-1 · `write_s` 写入循环无逐轴保护

`time_domain.py:700-705`：
`
    for ax, kp in kf_map.items():
        if side == 'left':
            kp.handle_left = (kp.co[0] - dt, kp.handle_left[1])
        else:
            kp.handle_right = (kp.co[0] + dt, kp.handle_right[1])
`
没有 `try/except`。若某一轴的赋值抛异常（**库链接 action** 是只读的），
已经写过的轴**不会回滚** ⇒ 留下"半写"状态：**三轴 dt 不一致**（正是插件自己定义的规范违反），
且异常向上传播。

### 建议

- 写前检查 action 是否可写（`act.library is None` / `act.is_editable`）
- 或写入包 try，失败时**回滚已写的轴**并返回 None

---

## P2-2 / P2-4 · 阈值口径漂移

"手柄长度视为零"这个语义有**三套**阈值：

| 值 | 位置 | 用途 |
|---|---|---|
| `UNIFORM_LEN_EPS = 1e-6` | `transform_domain.py:2315` | `scale_handle_uniform` 跳过 |
| 内联 `1e-12` | `interaction.py:490` 等 14 处 | 退化判定 |
| `UNIFORM_LEN_MIN = 1.0` | `transform_domain.py:2334`（`spec_check.MIN_HANDLE_LEN` 引用它） | 折角检查跳过 |

全仓 **31 处内联 eps**（`1e-9` x16、`1e-12` x14、`1e-4` x2、`1e-6` x4），
其中 `1e-9` / `1e-12` **没有命名常量**。

### 建议

- 抽 `ZERO_EPS` / `DEGENERATE_EPS` 两个命名常量，替换内联
- 给三套阈值各写一句"为什么是这个量级"，避免以后误合并

---

## P2-3 · 映射函数文档不准

`transform_domain.feel_for_orig_type` 的 docstring 写「与 `orig_type_for_feel` **互逆**」，
但：

    orig_type_for_feel('FREE') = 'FREE'
    feel_for_orig_type('FREE') = None      ← 不是 'FREE'

这个**不对称是故意的**（FREE ⇒ 不登记 = 尊重用户手动设的自由），
但"互逆"的说法会让后来者写出错误的往返断言。

### 建议

改文档为「**单向映射**：FREE 故意返回 None（不登记）」，并注明原因。

---

## P3-1 · `apply_fix` 不保证幂等（信息，非缺陷）

`spec_check.py:1248` 的循环对每个 kind **只跑一遍**，没有"检测到收敛为止"的循环。
各阶段之间会重跑 `detect` 喂给下一阶段（这是 09-30 GUI 验收抓到的真实缺陷的修法），
但**后面的阶段仍可能引入新的前面类问题** ⇒ 修完不一定 0 issue。

好在 `result["after"]` 会复检，`spec_ui` 也会提示「N issue(s) remain」⇒ **不静默** ✓
（Phase 1 的 E5 会断言"修完是否幂等"，把实际残留量测出来）。

---

## 没问题的部分（已核实）

| 维度 | 结论 |
|---|---|
| **R4 除零/开方** | 7 处 `sqrt` + 3 处 `** 0.5` **都有守卫**（`if L0 <= UNIFORM_LEN_MIN: return None` / `if length < 1e-6: return`）✓ |
| **R6 i18n** | 门禁 153/153、裸中文 0 ✓ |
| **R7 性能** | 49 处 `.update()` 都在**有界循环**里（关键帧数量级），非热点 ✓ |
| **R7 全局状态** | 17 个模块级可变全局 = 四表 + 各自的 `_warmed` / `_SRC` 镜像，是**已设计好的架构** ✓ |
| **表键含 action 名** | 对"共享 action 的两个对象"是**正确**的（手柄本来就属于 action）✓ |

---

## 已执行（用户选 D：修全部 P1 + 2 条 P2）

| 项 | 改动 | 验证 |
|---|---|---|
| **P1-1** | `interaction.py` 文案加 `clamped` 分支，带上**真实倍数** | `gui_review_fix_check` A1/A2/A3 |
| **P1-2** | `spec_ui.py` 检查 `applied[kind] == -1` ⇒ 报 ERROR | B1/B3 |
| **P1-3** | `spec_ui.py` `frozen > 0` ⇒ 补一句提示 | B2/B4 |
| **P2-1** | `time_domain.write_s` 逐轴保护 + **逆序回滚** | C1/C2/C3 |
| **P2-3** | `transform_domain.feel_for_orig_type` 文档改正 | D1/D2 |

**实测验证**：

    P1-1  实际差 16.67 倍
          新文案 -> 两个三角已锁定为一体 —— 但对侧手柄已到极限，速度未能完全一致（仍差 16.67 倍）
          旧文案 -> 两个三角已锁定为一体 —— 进出速度已一致          ← 说谎
    P2-1  write_s 返回 None；轴0 已回滚；三轴 dt 跨度 0.00e+00（规范未破）

**遗留待你定口径（P2-2 / P2-4）**：

    "手柄太短"这个语义现在有三套阈值（1e-6 / 1e-12 / 1.0），
    且全仓 31 处内联 eps（1e-9 x16、1e-12 x14）没有命名常量。
    ⇒ 合并/命名需要你先定"哪些语义共用一个量级"，我不擅自合并（怕改变既有行为）。

**踩到的一个 i18n 坑**（顺手记下）：
隐式字符串拼接（两段相邻字面量）会让 i18n 扫描器**只取到第一段** ⇒ 词条对不上。
新文案必须写成**一行**。
