# -*- coding: utf-8 -*-
"""选中【手柄端点】后按 G / R / S —— 【保速】回归。

用户报障（2026-09-29）
----------------------
    "保速模式下点击 3D 视图手柄的端点拖拽是正常的，
     但选中端点按 G 进入模态后拖动，保速会失效 ——
     关键帧的速度值被改，采样点稀疏程度也变了。"

根因：**不是保速算错了，是这条路根本没接上保速**
------------------------------------------------
    · 鼠标直接拖手柄 → `edit_geometry._uniform_plan`（读偏好 + 算 k +
      `dt = dt_base·k`）⇒ 速度不变 ✓
    · 端点模态 G/R/S → `apply_endpoint_transform` 只写【值分量】，
      dt 一动不动 ⇒ 速度 = |dv/dt| 的分母不变、分子变 ⇒ 速度必变 ✗

    检索实证：全仓只有 `edit_geometry` 一处读 `handle_scale_mode`，
    整个 `modal_edit`（G/R/S 模态 2476 行）**零匹配**。

修法（用户 2026-09-29 拍板）
----------------------------
    · G/R/S 端点模式统一走 `transform_domain.endpoint_uniform_plan` +
      `write_endpoint_uniform`；数学仍是 `handle_scale_k` /
      `scale_handle_uniform` **那一份**（同一语义不写第二处）。
    · **逐端点各算各的 k** —— G 是平移，所有端点走同一个 δ，
      但各端点原本的长度不同（矮个子长高比例大、高个子比例小）。
    · 偏好闸门收敛到 `state.uniform_handle_mode()`（唯一读取点），
      两条路读到**必然是同一个开关**。
    · 端点段（首帧左 / 末帧右）沿用鼠标拖拽的同一个闸门 ⇒ 不保速（同口径）。

覆盖
----
    A 组：场景前提 + 路由 + 静态契约（唯一来源）
    B 组：★★ 修复后断言（G/R/S 各自保速、逐端点 k 各不同、与鼠标通路数值一致）
    C 组：边界（基线过短 / 端点段 / 反复 _apply 不累乘 / ESC 还原 / 偏好闸门）
    D 组：★★ bug 注入（旧行为必须被抓住，否则这测试没有区分度）
"""
import os
import sys
import json
import math
import inspect
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy
import mathutils

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf
from RealTimeMotionPath import modal_edit as me
from RealTimeMotionPath import edit_geometry as eg
from RealTimeMotionPath import state as st

OUT = os.path.join(HERE, "_move_endpoint_result.json")
PREF_KEY = "RealTimeMotionPath"

steps = []


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:400]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


# ---------------------------------------------------------------------------
# 场景
# ---------------------------------------------------------------------------
KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))
MID = 25.0
LAST = 55.0
FIRST = 1.0
TOL = 1e-6


def prefs():
    return bpy.context.preferences.addons[PREF_KEY].preferences


def set_pref(mode):
    try:
        prefs().handle_scale_mode = mode
    except Exception:
        pass


def build(name):
    """建 3 关键帧对象，全 FREE（排除 AUTO_CLAMPED 重算干扰 ⇒ 控制变量）。"""
    sc = bpy.context.scene
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in KFS:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(int(KFS[0][0]))
    a = o.animation_data.action
    for c in xf._position_curves(a, o, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        c.update()
    return o, a


def curves(o):
    return {c.array_index: c for c in
            xf._position_curves(o.animation_data.action, o, None)}


def kf(o, frame, axis):
    for k in curves(o)[axis].keyframe_points:
        if abs(k.co[0] - frame) < 1e-3:
            return k


def set_handle(o, frame, side, dt, dv):
    """把某帧某一侧手柄设成 (dt, dv)。

    dt：时间跨度（帧，带符号 —— 左侧为负，与 Blender 的约定一致）
    dv：三维值偏移（相对 co）
    """
    for ax in (0, 1, 2):
        k = kf(o, frame, ax)
        t = float(k.co[0]) + float(dt)
        v = float(k.co[1]) + float(dv[ax])
        if side == 'left':
            k.handle_left = (t, v)
        else:
            k.handle_right = (t, v)


def speeds(o, endpoints):
    """{(frame, side): 速度}。速度 = |dv/dt|，**逐轴算再三维合成**。

    （每轴 F-Curve 的手柄各有自己的时间分量 ⇒ 必须先逐轴除，再合成模长。）
    """
    out = {}
    for (frame, side) in endpoints:
        v = []
        for ax in (0, 1, 2):
            k = kf(o, frame, ax)
            h = k.handle_right if side == 'right' else k.handle_left
            dv = float(h[1]) - float(k.co[1])
            dt = (float(h[0]) - float(k.co[0])) if side == 'right' \
                else (float(k.co[0]) - float(h[0]))
            v.append(dv / dt if abs(dt) > 1e-9 else 0.0)
        out[(float(frame), side)] = math.sqrt(sum(x * x for x in v))
    return out


def dts(o, frame, side):
    """该端点的三维时间跨度（带符号）。"""
    t = []
    for ax in (0, 1, 2):
        k = kf(o, frame, ax)
        h = k.handle_right if side == 'right' else k.handle_left
        t.append(round(float(h[0]) - float(k.co[0]), 6))
    return tuple(t)


def handles(o, frame, side):
    """该端点的 (时间, 值) 逐轴，供"两条路逐位一致"的对比。"""
    out = []
    for ax in (0, 1, 2):
        k = kf(o, frame, ax)
        h = k.handle_right if side == 'right' else k.handle_left
        out.append((round(float(h[0]), 6), round(float(h[1]), 6)))
    return tuple(out)


# ---------------------------------------------------------------------------
# 会话构造（照抄真实调用链：session → _apply_xf → transform_domain）
# ---------------------------------------------------------------------------
def _mk_session(o, a, eps):
    """造一个"选中端点"的会话（不依赖 region/rv3d —— headless 没有视图）。"""
    s = me.MoveSession('MOVE')
    s.obj, s.act, s.bone_name = o, a, None
    s.endpoints = [(float(f), sd) for (f, sd) in eps]
    s.only_handles = True
    s.snapshot = xf.snapshot_endpoints(a, o, s.endpoints, None)
    s.context = bpy.context
    return s


def do_move(o, a, eps, delta, times=1):
    """G：移动端点（delta = 局部位移）。"""
    s = _mk_session(o, a, eps)
    r = None
    for _ in range(times):
        r = me._apply_xf(s, delta=mathutils.Vector(delta))
    return s, r


def do_rotate(o, a, eps, angle_deg, pivot=None, times=1):
    """R：绕支点旋转端点。pivot 缺省 = 各端点所在帧 co 的中位点。"""
    s = me.RotateSession('ROTATE')
    s.obj, s.act, s.bone_name = o, a, None
    s.endpoints = [(float(f), sd) for (f, sd) in eps]
    s.only_handles = True
    s.snapshot = xf.snapshot_endpoints(a, o, s.endpoints, None)
    s.context = bpy.context
    s.parent_matrix = mathutils.Matrix.Identity(4)
    s.axis_lock = None
    s.plane_lock = None
    s.axis_local = mathutils.Vector((0.0, 0.0, 1.0))
    if pivot is None:
        acc = mathutils.Vector((0.0, 0.0, 0.0))
        for (f, _sd) in s.endpoints:
            acc += mathutils.Vector([float(kf(o, f, ax).co[1]) for ax in (0, 1, 2)])
        pivot = acc / len(s.endpoints)
    s.pivot_local = mathutils.Vector(pivot)
    s._set_angle_raw(math.radians(float(angle_deg)))
    r = None
    for _ in range(times):
        r = s._apply()
    return s, r


def do_scale(o, a, eps, factor, pivot=None, times=1):
    """S：绕支点缩放端点。pivot 缺省 = 各端点所在帧 co 的中位点。"""
    s = me.ScaleSession('SCALE')
    s.obj, s.act, s.bone_name = o, a, None
    s.endpoints = [(float(f), sd) for (f, sd) in eps]
    s.only_handles = True
    s.snapshot = xf.snapshot_endpoints(a, o, s.endpoints, None)
    s.context = bpy.context
    s.parent_matrix = mathutils.Matrix.Identity(4)
    s.axis_lock = None
    s.plane_lock = None
    if pivot is None:
        acc = mathutils.Vector((0.0, 0.0, 0.0))
        for (f, _sd) in s.endpoints:
            acc += mathutils.Vector([float(kf(o, f, ax).co[1]) for ax in (0, 1, 2)])
        pivot = acc / len(s.endpoints)
    s.pivot_local = mathutils.Vector(pivot)
    s.factor = float(factor)
    r = None
    for _ in range(times):
        r = s._apply()
    return s, r


# 基线（用 set_handle 精确控制，让两个端点的 dv 长度**明显不同**）
#   MID  右：dv = (3.0, 1.0, 0.5) → |dv| = 3.2016  ，dt = +8
#   LAST 左：dv = (-2.0, 0.0, 0.0) → |dv| = 2.0000 ，dt = -10
BT_MID_R = (3.0, 1.0, 0.5)
BT_LAST_L = (-2.0, 0.0, 0.0)
DT_MID_R = 8.0
DT_LAST_L = -10.0


def prep(name):
    o, a = build(name)
    set_handle(o, MID, 'right', DT_MID_R, BT_MID_R)
    set_handle(o, LAST, 'left', DT_LAST_L, BT_LAST_L)
    set_pref('UNIFORM')
    return o, a


# ===========================================================================
# A 组：场景前提 / 路由 / 静态契约
# ===========================================================================
try:
    o, a = build("_ME_A")
    set_handle(o, MID, 'right', DT_MID_R, BT_MID_R)
    L0 = math.sqrt(sum(v * v for v in BT_MID_R))
    step("A1 场景前提：端点 dv_base 长度 %.4f > UNIFORM_LEN_MIN(%.1f) ⇒ 保速有定义"
         % (L0, xf.UNIFORM_LEN_MIN), L0 > xf.UNIFORM_LEN_MIN, "L0=%.6f" % L0)

    # A2：真实路由 —— 选中端点后 _transform_targets 必须判成"端点模式"
    st._session.selected_handle_endpoints = [(MID, 'right')]
    _fr, _eps, _oh = me._transform_targets(o, a, None)
    st._session.clear_endpoints()
    step("A2 ★ 路由：选中端点后 _transform_targets ⇒ only_handles=True（G 真的进端点模式）",
         bool(_oh) and len(_eps) == 1, "frames=%s eps=%s only=%s" % (_fr, _eps, _oh))

    # A3：静态契约
    _s1 = inspect.signature(xf.apply_endpoint_transform).parameters
    step("A3a apply_endpoint_transform 有 uniform 参数", "uniform" in _s1,
         "参数=%s" % (list(_s1.keys()),))
    step("A3b endpoint_uniform_plan / write_endpoint_uniform 唯一实现存在",
         hasattr(xf, "endpoint_uniform_plan") and hasattr(xf, "write_endpoint_uniform"))
    _s2 = inspect.signature(me._apply_xf).parameters
    step("A3c _apply_xf 有 uniform 参数（G/R/S 统一派发）", "uniform" in _s2,
         "参数=%s" % (list(_s2.keys()),))

    # A4：★ 偏好读取收敛到唯一来源
    step("A4a state.uniform_handle_mode 存在（唯一读取点）",
         hasattr(st, "uniform_handle_mode"))
    step("A4b edit_geometry._uniform_mode 与它**是同一个对象**（不是第二份实现）",
         getattr(eg, "_uniform_mode", None) is st.uniform_handle_mode,
         "eg=%r st=%r" % (getattr(eg, "_uniform_mode", None), st.uniform_handle_mode))
    _m_src = inspect.getsource(me)
    step("A4c modal_edit 不再自己读 handle_scale_mode（防第三条读取路径）",
         "handle_scale_mode" not in _m_src,
         "出现次数=%d" % _m_src.count("handle_scale_mode"))
    _e_src = inspect.getsource(eg)
    step("A4d edit_geometry 里不再有第二份读偏好的实现（只剩别名）",
         _e_src.count("handle_scale_mode") == 0,
         "出现次数=%d" % _e_src.count("handle_scale_mode"))
except Exception:
    step("EXCEPTION A", False, traceback.format_exc()[-700:])


# ===========================================================================
# B 组：修复后断言
# ===========================================================================
def _check_B1():
    """G 单端点：速度必须不变。"""
    o, a = prep("_B1")
    eps = [(MID, 'right')]
    v0 = speeds(o, eps)
    do_move(o, a, eps, (1.0, 0.0, 0.0))
    v1 = speeds(o, eps)
    return abs(v1[(MID, 'right')] - v0[(MID, 'right')]) < TOL


def _check_B3():
    """G 跨帧多端点：每端**各自**保速（逐端点 k 的核心意义）。"""
    o, a = prep("_B3")
    eps = [(MID, 'right'), (LAST, 'left')]
    v0 = speeds(o, eps)
    do_move(o, a, eps, (1.0, 0.0, 0.0))
    v1 = speeds(o, eps)
    return (abs(v1[(MID, 'right')] - v0[(MID, 'right')]) < TOL
            and abs(v1[(LAST, 'left')] - v0[(LAST, 'left')]) < TOL)


def _check_C3():
    """反复 _apply 不累乘（基准时间从 snapshot 读）。"""
    o, a = prep("_C3")
    eps = [(MID, 'right')]
    v0 = speeds(o, eps)
    do_move(o, a, eps, (1.0, 0.0, 0.0), times=5)
    return abs(speeds(o, eps)[(MID, 'right')] - v0[(MID, 'right')]) < TOL


def _check_D3():
    """S 端点单点：速度必须不变（原行为，数值应与 factor 等价）。"""
    o, a = prep("_D3")
    eps = [(MID, 'right')]
    co = mathutils.Vector([float(kf(o, MID, ax).co[1]) for ax in (0, 1, 2)])
    v0 = speeds(o, eps)
    do_scale(o, a, eps, 1.5, pivot=co)
    return abs(speeds(o, eps)[(MID, 'right')] - v0[(MID, 'right')]) < TOL


try:
    # ---- B1：G 单端点保速 + 数值核对 ----
    o, a = prep("_ME_B1")
    eps = [(MID, 'right')]
    v0 = speeds(o, eps)[(MID, 'right')]
    d0 = dts(o, MID, 'right')
    do_move(o, a, eps, (1.0, 0.0, 0.0))
    v1 = speeds(o, eps)[(MID, 'right')]
    d1 = dts(o, MID, 'right')
    kb = math.sqrt(sum(v * v for v in BT_MID_R))
    kn = math.sqrt(sum(v * v for v in (BT_MID_R[0] + 1.0, BT_MID_R[1], BT_MID_R[2])))
    k_expect = kn / kb
    step("B1 ★★ G 单端点移动后【速度不变】", abs(v1 - v0) < TOL,
         "%.6f → %.6f" % (v0, v1))
    step("B2 ★ G 单端点：dt 按 k 缩（k = |dv_new|/|dv_base| = %.6f）" % k_expect,
         all(abs(d1[i] - d0[i] * k_expect) < 1e-4 for i in (0, 1, 2)),
         "dt %s → %s（期望 %s）" % (d0, d1,
                                    tuple(round(x * k_expect, 6) for x in d0)))
    step("B2b ★ 值分量跟手：dv 未被折回时 = dv_base + delta",
         abs((float(kf(o, MID, 0).handle_right[1]) - float(kf(o, MID, 0).co[1]))
             - (BT_MID_R[0] + 1.0)) < 1e-5,
         "dv_x=%.6f" % (float(kf(o, MID, 0).handle_right[1])
                        - float(kf(o, MID, 0).co[1])))

    # ---- B3/B4：G 跨帧多端点，各算各的 k ----
    o, a = prep("_ME_B3")
    eps = [(MID, 'right'), (LAST, 'left')]
    v0 = speeds(o, eps)
    d0m, d0l = dts(o, MID, 'right'), dts(o, LAST, 'left')
    do_move(o, a, eps, (1.0, 0.0, 0.0))
    v1 = speeds(o, eps)
    d1m, d1l = dts(o, MID, 'right'), dts(o, LAST, 'left')
    km = d1m[0] / d0m[0]
    kl = d1l[0] / d0l[0]
    step("B3 ★★ G 跨帧多端点：两端**各自**保速（各自速度都不变）",
         abs(v1[(MID, 'right')] - v0[(MID, 'right')]) < TOL
         and abs(v1[(LAST, 'left')] - v0[(LAST, 'left')]) < TOL,
         "mid %.6f→%.6f | last %.6f→%.6f"
         % (v0[(MID, 'right')], v1[(MID, 'right')],
            v0[(LAST, 'left')], v1[(LAST, 'left')]))
    step("B4 ★★ 逐端点 k 各不同（同一个 δ，但两端比例差 %.1f%%，证明不是共用标量）"
         % (abs(km - kl) / max(km, kl) * 100.0),
         abs(km - kl) > 1e-3, "k_mid=%.6f k_last=%.6f" % (km, kl))

    # ---- B5：R 单端点（k 应为 1 —— 旋转不改变手柄长度）----
    o, a = prep("_ME_B5")
    eps = [(MID, 'right')]
    co = mathutils.Vector([float(kf(o, MID, ax).co[1]) for ax in (0, 1, 2)])
    v0 = speeds(o, eps)[(MID, 'right')]
    d0 = dts(o, MID, 'right')
    do_rotate(o, a, eps, 30.0, pivot=co)
    v1 = speeds(o, eps)[(MID, 'right')]
    step("B5 ★★ R 单端点旋转后速度不变（绕自身 co 转 ⇒ 长度不变 ⇒ k=1）",
         abs(v1 - v0) < TOL, "%.6f → %.6f dt %s → %s" % (v0, v1, d0, dts(o, MID, 'right')))

    # ---- B6：R 跨帧多端点（支点=中位点 ⇒ 长度会变 ⇒ 必须靠 k 保速）----
    o, a = prep("_ME_B6")
    eps = [(MID, 'right'), (LAST, 'left')]
    v0 = speeds(o, eps)
    d0m = dts(o, MID, 'right')
    do_rotate(o, a, eps, 25.0)
    v1 = speeds(o, eps)
    d1m = dts(o, MID, 'right')
    step("B6 ★★ R 跨帧多端点：两支点绕中位点转 ⇒ 长度变了，但速度不变",
         abs(v1[(MID, 'right')] - v0[(MID, 'right')]) < TOL
         and abs(v1[(LAST, 'left')] - v0[(LAST, 'left')]) < TOL,
         "mid %.6f→%.6f dt %s→%s | last %.6f→%.6f"
         % (v0[(MID, 'right')], v1[(MID, 'right')], d0m, d1m,
            v0[(LAST, 'left')], v1[(LAST, 'left')]))

    # ---- B7：S 端点单点（原行为，且数值与 factor 等价）----
    o, a = prep("_ME_B7")
    eps = [(MID, 'right')]
    co = mathutils.Vector([float(kf(o, MID, ax).co[1]) for ax in (0, 1, 2)])
    v0 = speeds(o, eps)[(MID, 'right')]
    d0 = dts(o, MID, 'right')
    do_scale(o, a, eps, 1.5, pivot=co)
    v1 = speeds(o, eps)[(MID, 'right')]
    d1 = dts(o, MID, 'right')
    step("B7 ★★ S 端点单点缩放：速度不变（= 原来的行为，逐端点 k 恰等于 factor）",
         abs(v1 - v0) < TOL, "%.6f → %.6f" % (v0, v1))
    step("B7b S 端点单点：dt × 1.5（与 factor 一致）",
         all(abs(d1[i] - d0[i] * 1.5) < 1e-4 for i in (0, 1, 2)),
         "dt %s → %s" % (d0, d1))

    # ---- B8：S 端点跨帧多点（新行为：各自保速）----
    o, a = prep("_ME_B8")
    eps = [(MID, 'right'), (LAST, 'left')]
    v0 = speeds(o, eps)
    do_scale(o, a, eps, 1.5)
    v1 = speeds(o, eps)
    step("B8 ★★ S 端点跨帧多点缩放：两端各自保速（2026-09-29 新行为）",
         abs(v1[(MID, 'right')] - v0[(MID, 'right')]) < TOL
         and abs(v1[(LAST, 'left')] - v0[(LAST, 'left')]) < TOL,
         "mid %.6f→%.6f | last %.6f→%.6f"
         % (v0[(MID, 'right')], v1[(MID, 'right')],
            v0[(LAST, 'left')], v1[(LAST, 'left')]))

    # ---- B9：与鼠标直接拖手柄【逐位一致】----
    off = mathutils.Vector((1.0, 0.0, 0.0))
    o_m, a_m = prep("_ME_B9m")
    do_move(o_m, a_m, [(MID, 'right')], off)
    got_m = handles(o_m, MID, 'right')

    o_a, a_a = prep("_ME_B9a")
    st._session.handle_start_values.clear()
    _gs0 = float(bpy.context.window_manager.rtmp_handle_scale)
    bpy.context.window_manager.rtmp_handle_scale = 1.0
    eg.apply_handle_point_offset(bpy.context, off,
                                 {'frame': MID, 'side': 'right', 'bone_name': None})
    bpy.context.window_manager.rtmp_handle_scale = _gs0
    got_a = handles(o_a, MID, 'right')
    ok9 = all(abs(got_m[i][j] - got_a[i][j]) < 1e-5
              for i in range(3) for j in (0, 1))
    step("B9 ★★ 与鼠标直接拖手柄【逐位一致】（同位移同结果 ⇒ 两条路口径统一）",
         ok9, "modal=%s | mouse=%s" % (got_m, got_a))
except Exception:
    step("EXCEPTION B", False, traceback.format_exc()[-700:])


# ===========================================================================
# C 组：边界
# ===========================================================================
try:
    # C1：基线太短 ⇒ 不保速（与鼠标路径同口径）
    o, a = build("_ME_C1")
    set_handle(o, MID, 'right', DT_MID_R, (0.5, 0.0, 0.0))
    set_pref('UNIFORM')
    eps = [(MID, 'right')]
    d0 = dts(o, MID, 'right')
    v0 = speeds(o, eps)[(MID, 'right')]
    do_move(o, a, eps, (1.0, 0.0, 0.0))
    step("C1 基线过短（|dv|=0.5 ≤ UNIFORM_LEN_MIN）⇒ 不缩 dt（退回历史行为）",
         dts(o, MID, 'right') == d0 and abs(speeds(o, eps)[(MID, 'right')] - v0) > 1e-6,
         "dt %s → %s（应不变）速度 %.6f → %.6f（会变，符合预期）"
         % (d0, dts(o, MID, 'right'), v0, speeds(o, eps)[(MID, 'right')]))

    # C2：端点段（首帧左侧无相邻关键帧）⇒ 与鼠标拖拽同口径，不缩 dt
    o, a = prep("_ME_C2")
    set_handle(o, FIRST, 'left', -6.0, (-2.0, 0.0, 0.0))
    eps = [(FIRST, 'left')]
    d0 = dts(o, FIRST, 'left')
    v0 = speeds(o, eps)[(FIRST, 'left')]
    do_move(o, a, eps, (0.5, 0.0, 0.0))
    step("C2 端点段（首帧左）⇒ 沿用鼠标拖拽的闸门：不缩 dt",
         dts(o, FIRST, 'left') == d0,
         "dt %s → %s 速度 %.6f → %.6f" % (d0, dts(o, FIRST, 'left'), v0,
                                          speeds(o, eps)[(FIRST, 'left')]))

    # C3：反复 _apply 不累乘
    o, a = prep("_ME_C3")
    eps = [(MID, 'right')]
    v0 = speeds(o, eps)[(MID, 'right')]
    d0 = dts(o, MID, 'right')
    do_move(o, a, eps, (1.0, 0.0, 0.0), times=5)
    v1 = speeds(o, eps)[(MID, 'right')]
    d1 = dts(o, MID, 'right')
    kb = math.sqrt(sum(v * v for v in BT_MID_R))
    kn = math.sqrt(sum(v * v for v in (BT_MID_R[0] + 1.0, BT_MID_R[1], BT_MID_R[2])))
    step("C3 ★★ 反复 _apply 5 次不累乘（基准时间一律从 snapshot 读）",
         abs(v1 - v0) < TOL
         and all(abs(d1[i] - d0[i] * kn / kb) < 1e-4 for i in (0, 1, 2)),
         "5 次后 速度=%.6f dt=%s" % (v1, d1))

    # C4：ESC（restore）⇒ dt / 速度回到原值
    o, a = prep("_ME_C4")
    eps = [(MID, 'right')]
    v0 = speeds(o, eps)[(MID, 'right')]
    d0 = dts(o, MID, 'right')
    s, _r = do_move(o, a, eps, (1.0, 0.0, 0.0))
    s.restore()
    step("C4 ★ ESC 取消后 dt / 速度完整还原（restore_positions 含时间分量）",
         abs(speeds(o, eps)[(MID, 'right')] - v0) < TOL
         and dts(o, MID, 'right') == d0,
         "速度 %.6f → %.6f | dt %s → %s"
         % (v0, speeds(o, eps)[(MID, 'right')], d0, dts(o, MID, 'right')))

    # C5：偏好 = CLASSIC（改速度）⇒ 端点模式也不缩 dt
    o, a = prep("_ME_C5")
    set_pref('CLASSIC')
    eps = [(MID, 'right')]
    d0 = dts(o, MID, 'right')
    v0 = speeds(o, eps)[(MID, 'right')]
    do_move(o, a, eps, (1.0, 0.0, 0.0))
    ok5 = (dts(o, MID, 'right') == d0
           and abs(speeds(o, eps)[(MID, 'right')] - v0) > 1e-6)
    set_pref('UNIFORM')
    step("C5 ★ 偏好 = 「改速度(CLASSIC)」时端点模式同样不缩 dt（听同一个开关）",
         ok5, "dt %s → %s 速度 %.6f → %.6f"
         % (d0, dts(o, MID, 'right'), v0, speeds(o, eps)[(MID, 'right')]))

    # C6：偏好读不到 ⇒ 保守 False（**不能**因为读不到就悄悄开始缩 dt）
    #     ⚠️ 必须把 `state.get_addon_prefs` 打瘸才有意义 ——
    #        只传一个假 context 是测不出来的：函数会退回 `bpy.context`
    #        照样读到偏好（这条路是刻意留的，headless / handler 里都要能用）。
    _orig_gap = st.get_addon_prefs

    def _boom(_ctx):
        raise RuntimeError("no prefs (test)")

    st.get_addon_prefs = _boom
    try:
        _got6 = st.uniform_handle_mode(bpy.context)
    finally:
        st.get_addon_prefs = _orig_gap
    step("C6 偏好读不到 ⇒ uniform_handle_mode 保守返回 False（不静默改成缩 dt）",
         _got6 is False, "返回 %r" % (_got6,))
    step("C7 默认偏好 = UNIFORM（保速），与 ui 的注册默认值一致",
         st.uniform_handle_mode(bpy.context) is True,
         "mode=%r" % prefs().handle_scale_mode)
except Exception:
    step("EXCEPTION C", False, traceback.format_exc()[-700:])


# ===========================================================================
# D 组：bug 注入（一个抓不到 bug 的测试比没有测试更危险）
# ===========================================================================
INJ = []


def _mk_uniform_off():
    """I1：端点模式退回旧行为（不缩 dt）⇒ B1 必须抓住。"""
    _orig = me._apply_xf

    def do():
        def bad(session, fn=None, delta=None, only_handles=None, time_scale=None,
                uniform=None):
            return _orig(session, fn=fn, delta=delta, only_handles=only_handles,
                         time_scale=time_scale, uniform=False)
        me._apply_xf = bad

    def undo():
        me._apply_xf = _orig
    return do, undo, "I1 ★ 端点模式退回旧行为（只写值分量、不动 dt）"


def _mk_shared_scalar_k():
    """I2：多端点共用一个标量 k（取第一个端点的）⇒ B3 必须抓住。

    这正是"修复时偷懒"最可能写出的版本 —— 也是文档 §7.1 专门警告的那种。
    """
    _orig = xf.endpoint_uniform_plan

    def do():
        def bad(snapshot, endpoints, fn, action=None, obj=None, bone_name=None,
                span_gate=True):
            plan = _orig(snapshot, endpoints, fn, action, obj, bone_name, span_gate)
            if len(plan) > 1:
                first = list(plan.values())[0]
                k, kraw = first[0], first[1]
                out = {}
                for key, item in plan.items():
                    out[key] = (k, kraw, item[2], item[3], item[4], item[5])
                return out
            return plan
        xf.endpoint_uniform_plan = bad

    def undo():
        xf.endpoint_uniform_plan = _orig
    return do, undo, "I2 ★ 多端点共用标量 k（不逐端点算）"


def _mk_dt_from_current():
    """I3：dt 基线从"当前值"读（而非 snapshot）⇒ C3 必须抓住（k^n 累乘）。"""
    _orig = xf.endpoint_uniform_plan

    def do():
        def bad(snapshot, endpoints, fn, action=None, obj=None, bone_name=None,
                span_gate=True):
            # 把 snapshot 里的时间分量改成"当前 kp 的值"，模拟从 kp 读
            cs = xf._position_curves(action, obj, bone_name)
            for frame, per_axis in (snapshot or {}).items():
                for ax, vals in per_axis.items():
                    for c in cs:
                        if c.array_index != ax:
                            continue
                        kp = xf.keyframe_at(c, float(frame))
                        if kp is None:
                            continue
                        vals['hl_t'] = float(kp.handle_left[0])
                        vals['hr_t'] = float(kp.handle_right[0])
            return _orig(snapshot, endpoints, fn, action, obj, bone_name, span_gate)
        xf.endpoint_uniform_plan = bad

    def undo():
        xf.endpoint_uniform_plan = _orig
    return do, undo, "I3 ★ dt 基线从当前值读（模态里累乘 k^n）"


try:
    n_ok = sum(1 for c in (_check_B1, _check_B3, _check_C3, _check_D3) if c())
    step("D0 注入前基线：四个检查未注入时全 True", n_ok == 4,
         "B1/B3/C3/S单点 = %d/4" % n_ok)

    for mk, checker, label in (
            (_mk_uniform_off, _check_B1, "I1 端点模式不缩 dt ⇒ G 保速失效"),
            (_mk_shared_scalar_k, _check_B3, "I2 多端点共用标量 k ⇒ 有一端速度被改坏"),
            (_mk_dt_from_current, _check_C3, "I3 dt 从当前值读 ⇒ 反复 _apply 累乘"),
    ):
        do, undo, desc = mk()
        try:
            do()
            caught = not checker()
        except Exception:
            caught = True
        finally:
            undo()
        step("★ %s ⇒ 测试抓住" % label, caught, desc)
except Exception:
    step("EXCEPTION D", False, traceback.format_exc()[-700:])


# ===========================================================================
flush()
print("=" * 72)
print("move-endpoint keepspeed | total=%d fails=%d | %s"
      % (len(steps), sum(1 for s in steps if not s["ok"]),
         "ALL PASS" if all(s["ok"] for s in steps) else "HAS FAILURES"))
for s in steps:
    if not s["ok"]:
        print("FAIL %s | %s" % (s["name"], s["detail"]))
print("=" * 72)
