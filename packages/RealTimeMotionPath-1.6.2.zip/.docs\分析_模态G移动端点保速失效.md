# 分析：模态 G 移动手柄端点时「保速」失效

> **状态**：✅ **已修复**（2026-09-29 第二轮 · 见 `Change Log.md`「端点模态保速（G/R/S）」）
> **记录时间**：2026-09-29 22:05（v1.4.0 发版当天）
> **分析基准**：commit `3e3ffc0`（v1.4.0）· 工作区干净 · 无未提交改动
> **触发来源**：用户报障
> **结论置信度**：高（不是推断 —— 作者自己在三处注释里写明了"G 不参与这个机制"，且有全仓检索实证）

---

## 零、TL;DR（一句话结论）

**「保速」这个功能从诞生起就只接了「鼠标直接拖拽」一条路。**

那个「改速度 / 保速度」的开关（`handle_scale_mode`），**全仓只有 `edit_geometry.py:439` 一处读它** ——
而整个 `modal_edit.py`（G / R / S 模态模块，2476 行）**一次都没有引用过它**。

所以按 G 进入模态时，**MoveSession 根本不知道"保速模式"存在**。
它走的是一条"只改值分量（手柄长度）、不动时间分量"的纯平移通路 ⇒ 速度必然改变。

> 打个比方：家里有两个水龙头，都出冷水，其中一个还接了热水管。
> 你**直接拖手柄** —— 走的是接了热水管那个龙头，能出热水（保速）✓
> 你**选中端点按 G** —— 走的是只有冷水管那个龙头。它也能出水（能拖动），
> 但**根本就没铺那根热水管**。
> 不是水龙头坏了，是**管路从来没接过去**。

---

## 一、现象（用户原话）

> 保速模式下，用户点击 3D 视图手柄的端点拖拽时是**正常的**，
> 但是用户选中端点点击 **G** 进入模态模式后拖动的话，**保速模式会失效**，
> 关键帧的速度值会被改变，**采样点稀疏程度会变**。

拆成两条通路：

| 通路 | 操作方式 | 保速 | 用户感受 |
|---|---|---|---|
| **A** | 鼠标**直接拖拽** 3D 视图里的手柄端点 | ✅ 正常 | 拖动手柄，关键帧速度不变 |
| **B** | **选中端点** → 按 **G** → 拖动 | ❌ 失效 | 关键帧速度被改，曲线疏密变了 |

---

## 二、证据链（三条注释 + 一条检索实证）

### 2.1 作者自己的三句话，直接印证

| # | 位置 | 原话 |
|---|---|---|
| ① | `modal_edit.py:448` | `` `time_scale`：手柄时间分量（dt）的缩放因子（None = 不动，历史行为）。``<br>`` 仅 S 的单点缩放传入，用来**保速**（见 apply_point_transform）。 `` |
| ② | `transform_domain.py:1996` | `` **只由 ScaleSession 的「单点缩放」传入**（见 modal_edit.ScaleSession._apply） `` |
| ③ | `modal_edit.py:1266` | `` ⚠️ 用 getattr 取到局部变量：MoveSession（G）**不参与这个机制**，不会有该属性 `` |

③ 是**最致命的一句** —— 它写在 `MoveSession.restore()` 里，
说明作者在设计时**明确知道**「G 不参与保速这套机制」，并且把它当成了**既定事实**写进注释。

### 2.2 检索实证：那个开关只被一个人读

```
$ grep -rn "handle_scale_mode" --include=*.py

ui.py:120                handle_scale_mode: bpy.props.EnumProperty(...)   ← 定义
ui.py:250 / 251          row.prop_enum(prefs, "handle_scale_mode", ...)   ← UI 按钮
ui.py:352                prefs.property_unset("handle_scale_mode")        ← 重置
edit_geometry.py:439     return getattr(prefs, 'handle_scale_mode', 'UNIFORM') == 'UNIFORM'
                         ↑ ★ 全仓唯一的功能性读取点（鼠标拖拽专用）
modal_edit.py            （零匹配）
```

**产品代码（不含 tests）里，只有 `edit_geometry.py:439` 一处读这个偏好。**

而 `_uniform_mode()` 是**鼠标拖拽通路的内部函数**：

```python
# edit_geometry.py:435-442
def _uniform_mode(context):
    """偏好：是否启用同比例缩放模式。拿不到偏好时保守返回 False（= 原行为）。"""
    try:
        prefs = get_addon_prefs(context)
        return getattr(prefs, 'handle_scale_mode', 'UNIFORM') == 'UNIFORM'
    except Exception:
        warn_once("edit_geometry._uniform_mode")
        return False
```

⇒ **「保速」是鼠标拖拽通路的私有行为，模态通路从未接入。** 这就是根因。

---

## 三、背景：先搞清「保速」到底是什么（不然看不懂两条路的差异）

### 3.1 手柄有**两个尺寸**，你只看得到其中一个

```
3D 视图里画的那根手柄线  = 手柄的【值分量】(dv)
                           → 眼睛能看到，鼠标能拖

Graph Editor 里手柄的水平跨度 = 手柄的【时间分量】(dt)
                           → ★ 3D 视图里完全看不见、鼠标碰不到

关键帧处的速度 = |dv / dt|   ← 长度 ÷ 时间跨度
```

### 3.2 保速就一句话：**你长我也长**

```
k·dv / k·dt = dv / dt   ⇒ 速度不变 ✓
```

想保速 ⇒ dv 和 dt **同乘一个 k**。

这一点在代码里有权威定义，写在 `transform_domain.py:2090-2105` 的块注释里：

```
# 手柄(3D 视图里那根线) = (dv_x, dv_y, dv_z)     ← 值分量，插件只画这个
# 关键帧处速度           = |(dv_a / dt_a)|        ← 每轴：值分量 / 时间分量
# 同比例（dv、dt 同乘 k）⇒ 速度 = (k·|dv|)/(k·dt) = 原速度 ⇒ **不变** ✓
#
# ⚠️ 为什么 k 必须是「值分量 3D 模长比」而不是「逐轴的 dv_a新/dv_a旧」：
#    逐轴 k_a 在某个轴被拖到**过零**时会变负 / 除零 ⇒ dt 被钳到极小 ⇒ 速度爆炸
#    ⇒ 手柄"飞走 / 缩成一点锁死"（2026-09-17 实测踩坑，那条路已废弃）。
#    整体 k 对所有轴相同 ⇒ 手柄方向 ∝ dv 不变 ⇒ **始终与路径相切** ✓
```

> 打个比方：手柄是根橡皮筋，**长度**你看得见（3D 视图里的线），
> **时间跨度**是它的"内在弹性"（只在 Graph Editor 里露脸）。
> 速度 = 长度 ÷ 弹性。
> 你把橡皮筋拉长一倍，如果**弹性也跟着变一倍**，速度就不变（保速）；
> 只拉长、弹性不动，速度就翻倍（改速度）。

---

## 四、通路 A（正常）：鼠标直接拖拽端点

### 4.1 完整调用链

```
[1] apply_handle_point_offset(context, total_offset_world, handle_point)
      edit_geometry.py:503
      └─ 换算：世界位移 → 局部值空间，并【除以 handle_scale】
           total_offset_local        = rotation_matrix.inverted() @ total_offset_world
           total_offset_local_scaled = total_offset_local / global_scale     ← :521-522

[2] _uniform_plan(context, action, obj, frame, side, bone_name, factors,
                  total_offset_local_scaled, frame_kf_map)
      edit_geometry.py:445   ← ★★ 保速的"预演"（只读，必须在任何写入之前调）
      ├─ _uniform_mode(context)                    :460  ← ★ 读 handle_scale_mode
      │     └─ _uniform_mode()                     :435  ← 全仓唯一读取点
      ├─ ① 补齐基线 handle_start_values
      ├─ ② span = td.resolve_target(...)           :469   （端点段返回 None ⇒ 退出）
      ├─ ③ dv_base / dv_new / dt_base 三序列
      └─ ks = xf.handle_scale_k(dv_base, dv_new, dt_base, span)      :487
              └─ transform_domain.py:2144          ← ★ 唯一 k 实现
      ⇒ 返回 (k, k_raw, dv_new, span)

[3] _write_uniform(keyframe, side, init, dv_new_a, k, k_raw, span)
      edit_geometry.py:495
      └─ xf.scale_handle_uniform(keyframe, side, dv_b, dt_b,
                                 dv_new_a, k, k_raw, span)
              └─ transform_domain.py:2196
                   ratio = k / k_raw                              :2220
                   dv = dv_new_a * ratio      ← 长度：跟鼠标走（跟手）  :2221
                   dt = dt_base  * k          ← ★★★ 时间跨度同比例缩    :2222
                   ...
                   keyframe.handle_right = (co_t + dt, co_v + dv)       :2233
```

### 4.2 关键就一行

```python
# transform_domain.py:2221-2222
dv = float(dv_new_a) * ratio      # 值分量：鼠标直接控制（未触上限时 ratio=1 ⇒ 完全跟手）
dt = float(dt_base_a) * float(k)  # ★★★ 时间分量：同比例缩 —— 这一行就是「保速」
```

**`dt = dt_base * k` 这行就是全部的秘密。** 通路 B 缺的就是它。

---

## 五、通路 B（失效）：选中端点按 G

### 5.1 完整调用链

```
[1] RTMP_OT_KeyboardTransform.invoke()          modal_edit.py:2113
      ├─ sel = _selected_speed_handle()          :2134  → 没选中三角 ⇒ 不走 SPEED 分支
      └─ sess = MoveSession(self.mode)           :2166
           sess.begin(obj, act, region, rv3d, mx, my,
                      bone_name=_pose_bone_name(context))            :2172

[2] MoveSession.begin()                          modal_edit.py:1111
      ├─ self.frames, self.endpoints, self.only_handles
      │     = _transform_targets(obj, act, bone_name)                :1137
      │        └─ modal_edit.py:380
      │             eps = _session.selected_handle_endpoints
      │             if eps:
      │                 return {}, eps, True      ← ★ 确实认出了"你在操作端点"
      │                                              only_handles = True ✓
      ├─ if self.only_handles:
      │     self.snapshot = xf.snapshot_endpoints(...)               :1145
      │        └─ transform_domain.py:1389
      │             每个轴记：co / hl / hr / hl_t / hr_t / hlt / hrt   :1409-1418
      │             ↑ ★ 时间分量 hl_t / hr_t 都记了（这是好消息，见 §9）
      └─ pivot = _target_pivot(...)                                  :1150

[3] MoveSession.update(mouse_x, mouse_y)         modal_edit.py:1174
      ├─ 增量法累积位移：accum / offset（含精度、轴约束）  :1205-1209
      ├─ local = xf.world_offset_to_local(offset, self.parent_matrix) :1211
      │     └─ transform_domain.py:1200   ← ⚠️ 注意：不含 handle_scale 换算（见 §11.1）
      └─ return _apply_xf(self, delta=local)                          :1212
              ↑ ★★★ 只传了 delta，没有时间分量相关的任何参数

[4] _apply_xf(session, fn=None, delta=None, only_handles=None, time_scale=None)
      modal_edit.py:445
      ├─ only = True（端点模式）
      ├─ def _fn(_f, v):
      │       return fn(_f, v) if fn is not None else (v + delta)     :467-468
      │       ↑ ★ 纯平移
      └─ ok = xf.apply_endpoint_transform(
                 session.act, session.obj, session.snapshot, _fn, eps,
                 session.bone_name,
                 zero_eps=_zero_eps_for_session(session),
                 time_scale=time_scale)          :470-472
              ↑ ★★★ time_scale 形参默认 None，调用方没传 ⇒ None

[5] apply_endpoint_transform(action, obj, snapshot, fn, endpoints, bone_name=None,
                             linked=True, weighted=True, zero_eps=_ARM_EPS,
                             time_scale=None)
      transform_domain.py:1843
      ├─ prepare_handles_for_drag(...)                                 :1881
      ├─ for fc in curves: fc.update()                                 :1905-1906
      ├─ for (frame, side) in endpoints:
      │     new_h = fn(f, hp)                                          :1892
      │     _set_handle_point(curves, f, side, moved_p)                :1920
      │        └─ transform_domain.py:1440
      │             """把某帧某一侧手柄写成给出的【三维点】（时间分量保持不变）。"""
      │             ↑ ★★★ 只写值分量！dt 一个字节都没碰
      │
      ├─ if time_scale is not None:                                    :1929
      │     for (frame, side) in endpoints:                            :1930
      │         if (_hp0 - _co0).length <= zero_eps: continue          :1940
      │         _scale_handle_time(curves, snapshot, f, _sd, time_scale)  :1942
      │     ↑ ★★★ 整整 14 行保速代码（1922-1942）
      │           因为 time_scale is None ⇒ **全部跳过**
      │
      └─ if linked: maintain_linked_handle(...)   ← 维护对侧手柄         :1944-1964
```

### 5.2 失效的直接原因

```
dv（值分量）→ 跟着 delta 变了    ✓
dt（时间分量）→ 一动不动          ✗  ← 因为 time_scale is None，整段跳过
────────────────────────────────────────
速度 = |dv / dt| ⇒ 分母不变、分子变了 ⇒ 速度必然改变
     ⇒ 关键帧速度值变 + 曲线疏密变（与用户描述完全吻合）
```

> 比喻：`apply_endpoint_transform` 这个函数其实**身体里已经装好**了保速的器官
> （1922-1942 那 14 行）。但它靠一个开关（`time_scale is not None`）来启动。
> G 这条路过来的时候**没带那个开关**，器官就安静躺着不动。

---

## 六、两条通路对照表（一眼看清差在哪）

| 环节 | 通路 A：鼠标直接拖拽 | 通路 B：选中端点按 G |
|---|---|---|
| 入口 | `apply_handle_point_offset` `edit_geometry.py:503` | `MoveSession.update` `modal_edit.py:1174` |
| 读 `handle_scale_mode`？ | ✅ `_uniform_mode()` `edit_geometry.py:439` | ❌ **从不读** |
| 基线来源 | `_session.handle_start_values`（按下时快照） | `session.snapshot`（进模态时快照） |
| 值分量 dv 写入 | ✅ 跟手 | ✅ 跟手（`v + delta`） |
| 时间分量 dt 写入 | ✅ **`dt = dt_base * k`** | ❌ **不动**（`_set_handle_point` 只写值分量） |
| k 的计算 | `handle_scale_k`（三轴合模长比） | **无 k** |
| `time_scale` 实参 | — （走另一套 `_uniform_plan`/`_write_uniform`） | `None`（`modal_edit.py:472`） |
| 保速段是否执行 | ✅ 执行 | ❌ `transform_domain.py:1929` 整段跳过 |
| **结果** | **速度不变 ✓** | **速度被改 ✗** |

---

## 七、修复的真正难点：**k 不能是一个标量**

表面上看来很简单：`_apply_xf` 已经有 `time_scale` 形参了，MoveSession 传一下不就完了？

**不行。** 坑在这里：

### 7.1 `time_scale` 是**标量**，而 G 需要**逐端点各算各的 k**

```
time_scale 是会话级的一个数（所有端点共用）
    ↑ 这在 S 缩放里够用 —— 因为 S 的支点是【该点自己】⇒ 所有端点等比 ⇒ 一个 k 管全部
```

但 **G 是平移**：所有端点走**同一个位移量 δ**，可是每个端点**原本的长度不同**：

```
端点 A：dv_base = 10  →  dv_new = 12   ⇒  k = 12/10 = 1.20
端点 B：dv_base =  2  →  dv_new =  4   ⇒  k =  4/2  = 2.00
           ↑ 同一个 δ = +2，但两边的"长高比例"差了 67%
```

⇒ 用一个标量 k 去缩**所有**端点的 dt，**必然有一个端点的速度被改坏**。
（甚至更糟：把某个端点的 dt 缩到极小 ⇒ 手柄缩成一点、曲线变得极尖。）

> 比喻：S 缩放像"全家福整体放大" —— 一个倍数就够。
> G 移动像"每人各往前走一步" —— 同样的步长，但矮个子长高比例大、高个子长高比例小
> ⇒ **必须各算各的比例**。

### 7.2 好消息：现成的轮子正好合适

`handle_scale_k`（`transform_domain.py:2144`）**本来就是为「多轴一起算」设计的**：

```python
def handle_scale_k(dv_base, dv_new, dt_base, span):
    """【唯一实现】算同比例缩放的系数 k。两条拖拽路径共用。
    ...
    ⚠️ 接口约定（盲审 S4）：本函数收**序列**（内部 list() 后逐元素处理），
       而相邻的 scale_handle_uniform 收**标量**（float()）。
    """
```

它收**序列**（三轴的 dv_base / dv_new / dt_base），算**三轴值分量合模长比**，返回一个总 k。
**G 移动正好是"三轴同时变"，形状完全对得上。**

### 7.3 而且它已经内建了所有边界保护（全是当年实测踩坑后拍板的）

| 常量 | 值 | 位置 | 作用 |
|---|---|---|---|
| `UNIFORM_LEN_EPS` | `1e-6` | `transform_domain.py:2107` | `\|dv_base\|` 低于此值 ⇒ "缩放"无定义（手柄零长） |
| `UNIFORM_DT_FLOOR` | `1e-4` | `:2108` | dt 下限（帧），防 dt→0 让手柄不可抓 |
| `UNIFORM_LEN_MIN` | `1.0` | `:2126` | ★★ 基线手柄太短 ⇒ **不启用同比例** |
| `UNIFORM_K_SAFETY` | `200.0` | `:2141` | k 上限（仅防病态值，**不是**手感限制） |

`UNIFORM_LEN_MIN` 的来历，注释里留着血泪实测记录（`:2110-2125`）：

```
#   ★★★ 2026-09-17（用户实测 bug）：**基线手柄太短 ⇒ 不启用同比例**。
#   实测（从磁盘干净状态模拟"拖出端点手柄、松手、再拖"）：
#       L0 = 0.0242 → 拖到 3.96 → k = 164.6 → **dt = 1646.3**
#       L0 = 0.05   → 拖到 3.96 → k =  80.2 → **dt =  802.0**
#   用户实测到的 **dt = 1634.574** 正是同一条路（L0 ≈ 0.024）。
#   dt 过大（> 段跨度 span）后贝塞尔在该段饱和 ⇒ **拖手柄路径几乎不动**
#   （用户："没有预期交互"），且手柄方向与路径偏离 10°+（"不相切"），
#   并且**永久锁死**（基线 dt 已巨大，k 的语义失效）。
```

⇒ **直接复用这套实现 = 免费继承全部这些保护。** 自己另写一份，等于把这些坑重新踩一遍。

---

## 八、推荐修法

### 8.1 方向（一句话）

**让 G 的端点模式复用 `handle_scale_k` / `scale_handle_uniform`，绝不另写一份保速。**

这正是工程铁律「**同一语义必须收敛到唯一来源；修法是收敛，不是补第二处 —— 补第二处 = 制造第三处**」。

本次 bug 的**根因本身就是"两条路各写一份逻辑导致漂移"**（一条读了偏好、一条没读）。
如果修复时再给 G 手写一套保速数学，就是把同一个错误犯第二次。

### 8.2 流程（在 `MoveSession` 端点模式下）

```
1. 闸门：_uniform_mode(context)  ← 与鼠标拖拽读【同一个】偏好
        （注意：这是 edit_geometry 的函数，考虑搬到中立位置或从 modal_edit 引用，
          别在 modal_edit 里再写一个读偏好的版本 —— 那又是一处第二份）

2. 对每个端点 (frame, side)【各自】算 k：
     从 snapshot 取基线：
         init   = (hl_t, hl)   或 (hr_t, hr)     ← 按下那一刻的 (时间, 值)
         co     = snapshot 里的 co
         dv_base[ax] = init[ax][1] - co[ax]
         dt_base[ax] = init[ax][0] - co[ax][0]
     dv_new[ax] = dv_base[ax] + delta_local[ax]     ← delta 用本次 §5.1[3] 那个 local
     ks = handle_scale_k(dv_base, dv_new, dt_base, span)
     ks 为 None ⇒ 该端点退回"只写 dv"（与通路 A 同口径，别自作聪明）

3. 写入（逐轴逐 curve）：
     _write_uniform(keyframe, side, init, dv_new_a, k, k_raw, span)
        ⇒ 内部 dt = dt_base * k  ← 保速在这里发生

4. 顺序铁律（照抄 apply_endpoint_transform）：
     fc.update() → 写值分量 → 缩 dt → 维护对侧(linked)
     ↑ 不能颠倒，原因见 transform_domain.py:1900-1904
```

### 8.3 需要重点核对的四个技术点

| # | 点 | 说明 |
|---|---|---|
| ① | **基线来源** | 必须用 `session.snapshot`，**绝不能用** `_session.handle_start_values`（见 §9 约束①） |
| ② | **逐端点各自 k** | 不能共用一个标量（见 §7.1） |
| ③ | **每次 update 从 snapshot 重算** | 防 `k^n` 累乘（见 §9 约束②） |
| ④ | **写入顺序** | dt 缩放在 `fc.update()` 之后、对侧维护之前（见 §9 约束③） |

---

## 九、三条硬约束（不遵守就会踩回老坑）

### ① 基线必须来自模态自己的 `snapshot`，**绝对不能用** `_session.handle_start_values`

`handle_start_values` 是**鼠标拖拽专用的全局状态**。`edit_geometry.py:455-457` 明确要求它取"按下时的值"：

```
⚠️ 基线一律取 `_session.handle_start_values`（**按下时**的值）。
   若改用"当前值"，每次 MOUSEMOVE 都会在已改过的值上再改一次
   ⇒ 指数增长 ⇒ 手柄飞走（2026-09-17 实测踩过的坑）。
```

模态路径下这个字段**可能残留着上一次拖拽的陈旧值** ⇒ 就是「手柄飞走」那个坑。

**而模态有自己的 snapshot，且字段齐全** —— `transform_domain.py:1409-1418`：

```python
per_axis[fc.array_index] = {
    'co': float(kp.co[1]),
    'hl': float(kp.handle_left[1]),
    'hr': float(kp.handle_right[1]),
    # ★ 时间分量也要记（对侧的 dt 会在拖动途中被改 —— 不记就还原不了）
    'hl_t': float(kp.handle_left[0]),
    'hr_t': float(kp.handle_right[0]),
    'hlt': str(kp.handle_left_type),
    'hrt': str(kp.handle_right_type),
}
```

`co` / `hl` / `hr` / `hl_t` / `hr_t` **全都有** ⇒ 算 k 需要的基线全部现成 ✓

### ② 每次 update 都要从 snapshot 重算（防 `k^n` 累乘）

模态里鼠标**每动一次就 `_apply` 一次**。如果从当前值读基线，就会在上一次已缩过的 dt 上再缩一次
⇒ `k^n` 指数增长。

代码里两处专门警告过：

- `transform_domain.py:1467-1468`（`_scale_handle_time` 的 docstring）：
  ```
  ⚠️ 基准时间必须从 **snapshot** 读（进模态那一刻的原始值）——
     模态里鼠标每动一次就 _apply 一次，从 kp（当前值）读会**累乘 k^n**。
  ```
- `transform_domain.py:2039-2041`（`apply_point_transform` 里）：
  ```
  ⚠️ 时间分量必须从 **snapshot** 读，不能从 kp 读 ——
     模态里鼠标每动一次就 _apply 一次，从 kp 读会**累乘**（k^n）。
  ```

### ③ 写入顺序必须照抄：`fc.update()` → 写值 → 缩 dt → 维护对侧

`transform_domain.py:1900-1904` 记录了原因：

```
⚠️ 顺序关键（2026-09-16 实测）：先 update，再维护对侧。
   Blender 的 ALIGNED 约束是「(t,v) 平面共线」，会在 fc.update() 时
   把对侧手柄按它的规则**重算**（覆盖我们写的值）。
   所以对侧的修正必须写在 update **之后**，否则会被 Blender 覆盖。
```

现成实现里的顺序是：`prepare_handles_for_drag` → `update()` → 写值分量(1887-1920)
→ **缩 dt(1929-1942)** → 维护对侧(1944-1964)。**照抄即可。**

### ✅ 附带确认的好消息：取消（ESC）不会污染数据

`restore_positions`（`transform_domain.py:1143`）**会连时间分量一起还原**：

```python
# transform_domain.py:1158-1163
kp.co = (kp.co[0], vals['co'])
# ★ 时间分量一并还原（缺了它，P2 加权改过的 dt 会残留）
hlt_t = vals.get('hl_t', kp.handle_left[0])
hrt_t = vals.get('hr_t', kp.handle_right[0])
kp.handle_left = (hlt_t, vals['hl'])
kp.handle_right = (hrt_t, vals['hr'])
```

⇒ 修复后按 **ESC 取消，dt 会被恢复干净**，不需要额外补还原逻辑 ✓

---

## 十、顺带查出的两个「次生观察」（与本次 bug 相关，但不是它）

### 10.1 ⚠️ `handle_scale` 口径：两条通路的"跟手"分母不一致

| 通路 | 位移换算 | 是否除以 `rtmp_handle_scale` |
|---|---|---|
| A 鼠标直接拖拽 | `edit_geometry.py:521-522` | ✅ **除**（`total_offset_local_scaled = total_offset_local / global_scale`） |
| B 模态 G | `modal_edit.py:1211` → `xf.world_offset_to_local` | ❌ **不除**（`transform_domain.py:1200` 内不含 gs） |

`rtmp_handle_scale` 是**手柄线的视觉放大系数**（`drawing.py:657` 注释：「与用户视觉一致；天然随 `rtmp_handle_scale` 自适应」）。

⇒ 当 `handle_scale ≠ 1` 时，**G 移动端点的"屏幕上走多远 ↔ 值变多少"的比例与直接拖拽不同**。
默认值是 1.0，所以平时看不出来；一旦用户调过这个（或将来加"手柄整体放大"开关），差异就显形。

**对本次修复的影响**：算 k 用的 `dv_new` 必须与**实际写进去的 dv 同一口径**
（即用同一个 `delta`）。只要这一点自洽，保速的数学就成立。

**但**：是否要借这次一并把 gs 口径统一（让 G 也"视觉跟手"），是一个**独立决策点**（见 §11 决策 ④）。

### 10.2 ⚠️ `span` 参数：对 k 已废弃，却仍是「是否保速」的闸门

`handle_scale_k` 的 docstring 明说（`transform_domain.py:2151-2154`）：

```
span    : ⚠️ **已废弃、不再使用**（只为兼容历史签名而保留）。
          2026-09-17 用户拍板取消了"拉长上限"，k_max 已改成常量
          `UNIFORM_K_SAFETY`（见下）。保留形参是为了不动已有的
          位置传参调用点。
```

**但** `_uniform_plan` 里它仍然是**提前退出的条件**（`edit_geometry.py:468-473`）：

```python
# ② span（端点段返回 None ⇒ 不做时间缩放）
try:
    _kf2, span = td.resolve_target(action, obj, frame, side, bone_name)
except Exception:
    span = None
if not span:
    return None        # ★ 端点段 ⇒ 整个保速被跳过
```

⇒ 语义上有点夹生：**k 的计算不需要 span，但"要不要保速"由 span 决定**。
具体表现：**端点段（第一帧的左段 / 最后一帧的右段）不做时间缩放**。

**对本次修复的决策**：G 要不要沿用这个闸门？
- 沿用 ⇒ 与通路 A **完全同口径**（推荐，符合"唯一来源"铁律）
- 不沿用 ⇒ 引入两路行为差异，又是一次"各写一份"

---

## 十一、四个待拍板决策点

### 决策 ① 锁轴（X/Y/Z）时 k 算不准，接受吗？

`handle_scale_k` 算的是**三轴值分量合模长比**。按 G 后再按 X 锁定 ⇒ 只有 X 的 dv 变，
但 L0 / L1 里含 Y / Z 的原始分量 ⇒ **k 会偏小**（保速不精确）。

| 选项 | 说明 | 代价 |
|---|---|---|
| **(a) 沿用合模长**（建议） | 与通路 A 完全同口径 | 锁轴时略有偏差 |
| (b) 只对被移动的轴算 k | 更精确 | **引入第二份实现** ⇒ 以后两处必然漂移 |

**建议 (a)**。理由：本次 bug 的根因就是"两条路各写一份"，不能再制造第二份。

### 决策 ② R 旋转端点要不要一起修？

R 有**完全相同**的问题（dt 不变、dv 变 ⇒ 速度变）。
但「旋转手柄」的语义**本来就是改切线方向**，硬套保速可能与用户意图相反。

**建议本轮只修 G**，R 单独确认。（用户只报了 G。）

### 决策 ③ 修复后 G 与直接拖拽会「变成同一个操作」，认不认可？

修完后：

| | 值分量 dv | 时间分量 dt |
|---|---|---|
| A 直接拖拽 | 跟鼠标 | 按 k 缩 |
| B G（修复后） | 跟鼠标 | 按 k 缩 |

**两者在数学上完全等价。** G 的额外价值只剩：**轴约束（X/Y/Z）、精度（Shift）、数字输入** ——
以及「**先点选、再移动**」这个操作优势（不需要鼠标精确抓到手柄，对手抖更友好）。

⇒ 语义上，G 从"更自由的拖拽"收敛为"**直接拖拽 + 约束**"。
**这个语义收敛我认为是对的**（一致性比"多一种拖法"值钱），但要用户确认。

### 决策 ④ 是否顺带统一 `handle_scale`（gs）口径？（见 §10.1）

- 只修保速 ⇒ 改动面最小，但 gs≠1 时两路跟手程度仍不同
- 一并统一 ⇒ 更一致，但要动 `MoveSession.update` 的位移换算，**影响面更大**（连带精度/轴约束/数字输入）

**建议本轮不动**，单独记一条待办。

---

## 十二、测试缺口（这个 bug 为什么活到今天）

### 12.1 现有覆盖面的实测结果

| 测试文件 | 覆盖内容 | 覆盖「G 移动端点保速」？ |
|---|---|---|
| `tests/gui_handle_scale_check.py` | 鼠标拖拽保速（含长拖、上限） | ❌ |
| `tests/gui_point_scale_keepspeed_check.py` | S 缩放保速（含端点模式 B 组、注入对照 I4） | ❌（只有 S） |
| `tests/gui_endpoint_hollow_check.py` | 端点空心圆抓取点 | ❌ |
| `tests/gui_endpoint_tangent_check.py` | 端点切向 | ❌ |
| `tests/test_modal_state_machine.py` | 会话状态机 | ❌ |
| `tests/gui_peraxis_align_check.py` | 双击锁定的逐轴对齐 | ❌ |

**「G / R / S 端点模式」的保速，一条断言都没有。**

### 12.2 缺口为什么存在（结构性原因）

整个测试体系覆盖的是**已经想到的通路**：

- 鼠标拖拽 → `gui_handle_scale_check` ✓
- S 缩放 → `gui_point_scale_keepspeed_check` ✓
- 端点抓取 → `gui_endpoint_hollow_check` ✓

**而「G 移动端点」正好卡在两边的缝里**：它是"模态 + 端点"的交叉，两个测试族都以为自己不负责。

> 技能里那句话在这儿应验了：*"最容易骗过你的，恰恰是你自己写的测试。"*
> 门禁有 1263 条断言，但它们测的都是**已经想到的通路**。
> 这条没人想到 ⇒ **1263 条全绿也照样漏。**

### 12.3 修复时必须一起补的测试

新增 `tests/gui_move_endpoint_keepspeed_check.py`，结构照抄 `gui_point_scale_keepspeed_check.py`
（它那个 **I4「端点模式不传 time_scale ⇒ 必须 FAIL」的注入对照**就是现成模板，见该文件 477-490 行）。

**必须包含 bug 注入验证**（工程铁律：*一个抓不到 bug 的测试比没有测试更危险*）：

```
A 组：场景前提      —— 造一个两端点、dv_base 长度不同的场景
B 组：★ 注入验证    —— 故意用旧行为（time_scale=None）跑一遍，断言「速度变了」⇒ 证明测试有区分度
C 组：修复后断言    —— 速度不变 / dv 跟手 / 多端点各自 k 正确 / 值分量与直接拖拽一致
D 组：边界          —— 基线过短(L0 ≤ UNIFORM_LEN_MIN)退回不保速 / 端点段 / 取消后 dt 还原
```

---

## 十三、验证计划（若要做实机钉死）

用户要求「先不动手」，所以**本次仅分析，未做实测**。

以下为**建议的**验证步骤（按工程铁律：结论尽量按**真实调用路径**验证，不要只调中间函数）：

1. **只读探针**（独立 headless Blender，**不碰用户工程**）
   `blender --background --factory-startup --python tests\_probe_move_endpoint.py`
   - 造场景：一个物体 + 3 个关键帧，X/Y 轴值不同（复刻"三轴不同比例"）
   - 手动选中端点：设 `state._session.selected_handle_endpoints = [(f, 'right')]`
   - `MoveSession().begin(...)` → 反复 `update(mx, my)` 模拟拖动
   - **读数是关键**：每次 update 后读 `fc.keyframe_points[].handle_*[0]/[1]`，
     算出「速度 = dv/dt」与进模态前对比
   - 预期（修复前）：**dt 完全不变、dv 变了 ⇒ 速度变了** ← 复现 bug
   - ⚠️ 注意后台限制：`--background` 下 `bpy.app.timers` 不触发、无 window/screen/area
     （`_target_pivot` / `region_2d_to_location_3d` 需要 region/rv3d ⇒ 可能要用假上下文，
     参考 `tests/_snapshot_recorder.py` 的 `FakeCtx` 做法）

2. **对照实验**：同一场景走通路 A（`apply_handle_point_offset`），
   验证"直接拖拽保速正常" ⇒ 两条通路差异被钉死成数字证据

3. **数字录入文档**，作为将来 `gui_move_endpoint_keepspeed_check.py` 的基线

4. **改代码 → 重跑**：确认速度不变 + 值分量与通路 A 逐位一致

---

## 十四、附录

### 附录 A：相关常量一览

| 常量 | 值 | 位置 |
|---|---|---|
| `UNIFORM_LEN_EPS` | `1e-6` | `transform_domain.py:2107` |
| `UNIFORM_DT_FLOOR` | `1e-4` | `transform_domain.py:2108` |
| `UNIFORM_LEN_MIN` | `1.0` | `transform_domain.py:2126` |
| `UNIFORM_K_SAFETY` | `200.0` | `transform_domain.py:2141` |
| `_ARM_EPS` | `1e-9`（世界，已逐步被"视觉零"取代） | `transform_domain.py` |

### 附录 B：本次分析涉及的关键函数索引

| 函数 | 位置 | 作用 |
|---|---|---|
| `_uniform_mode` | `edit_geometry.py:435` | **全仓唯一读 `handle_scale_mode`** |
| `_uniform_plan` | `edit_geometry.py:445` | 保速预演（只读） |
| `_write_uniform` | `edit_geometry.py:495` | 写入同比例（单轴） |
| `apply_handle_point_offset` | `edit_geometry.py:503` | 通路 A 入口 |
| `handle_scale_k` | `transform_domain.py:2144` | **k 的唯一实现**（收序列） |
| `scale_handle_uniform` | `transform_domain.py:2196` | **dt 缩放的唯一实现**（收标量） |
| `apply_endpoint_transform` | `transform_domain.py:1843` | 端点变换（含保速段 1929-1942） |
| `apply_point_transform` | `transform_domain.py:1968` | 关键帧点变换 |
| `_scale_handle_time` | `transform_domain.py:1460` | 只缩时间分量 |
| `_set_handle_point` | `transform_domain.py:1440` | **只写值分量**（dt 不变的元凶） |
| `snapshot_endpoints` | `transform_domain.py:1389` | 端点快照（含 `hl_t`/`hr_t`） |
| `restore_positions` | `transform_domain.py:1143` | 还原（含时间分量 ✓） |
| `world_offset_to_local` | `transform_domain.py:1200` | 世界→局部（**不含 gs**） |
| `MoveSession` | `modal_edit.py:1065` | 通路 B 载体 |
| `_apply_xf` | `modal_edit.py:445` | G/R/S 统一派发 |
| `_transform_targets` | `modal_edit.py:380` | 决定"端点 or 关键帧点" |
| `ScaleSession` | `modal_edit.py:1762` | S（唯一传 `time_scale` 的会话） |

### 附录 C：本次分析的检索命令（可复现）

```bash
# ① 保速相关关键词分布
grep -rn "保速\|keep_speed\|preserve_speed\|scale_handle" --include=*.py .

# ② 那个开关被谁读（★ 关键证据）
grep -rn "handle_scale_mode" --include=*.py .

# ③ 时间分量参数被谁传
grep -rn "time_scale" --include=*.py .

# ④ 裸访问（附带发现，与待办清单口径核对）
grep -rn "wm\.rtmp_" --include=*.py .
```

### 附录 D：一处路径线索（顺带修正）

`tests/gui_handle_scale_check.py:29` 的注释里提到原型文件路径：

```
IDES/workspace/_rtmp_handle_scale_proto.html
```

⇒ `workspace/` 目录**不在 `addons/RealTimeMotionPath/` 下**，而在 `IDES\` 体系里
（与 `README_DEV.md:263` 提到的 `workspace/_rerun_all.py` 是同一处）。
本机 `F:\desktop\BaiduSyncdisk\addons\` 下确实没有 `workspace\` ——
之前"找不到 `_rerun_all.py`"的疑问，**答案在这里**。

---

## 十五、结论一句话（给未来的自己）

> **不是保速算错了，是保速这条路根本没修到"按 G 移动端点"这一站。**
> 修复的正确姿势是**把 G 接进现有的同比例实现**（`handle_scale_k` + `scale_handle_uniform`），
> 让它和鼠标拖拽走**同一条路** ——
> 而不是给 G 另写一套保速数学（那等于把"两条路各写一份"这个根因再犯一次）。
>
> 同时必须补测试，否则下次还会从同样的缝里漏过去。

---

*本文档为过程记录，位于 `.docs/`（已被 `.gitignore` 排除，不进版本库）。*
*分析期间未修改任何产品代码。*

---

## 十六、落地记录（2026-09-29 第二轮）

| 本文档的建议 | 落地情况 |
|---|---|
| 复用 `handle_scale_k` / `scale_handle_uniform`，不另写保速 | ✅ 新增 `endpoint_uniform_plan` + `write_endpoint_uniform`，数学仍只有那一份 |
| 基线取模态 `snapshot`，禁用 `handle_start_values` | ✅ |
| **逐端点各算各的 k**（§7.1） | ✅（测试 B4 断言两端 k 不同） |
| 每次 update 从 snapshot 重算（防 k^n） | ✅（测试 C3 + 注入 I3 钉住） |
| 写入顺序照抄（update → 写值 → 缩 dt → 对侧） | ✅ |
| 决策①（锁轴时沿用三轴合模长 k） | ✅ 沿用 |
| 决策②（R 要不要一起修） | ✅ **用户拍板：R / S 一起修** |
| 决策③（G 收敛为"拖拽 + 约束"） | ✅ 用户认可；新增断言「与鼠标拖拽**逐位一致**」把它钉死 |
| 决策④（`handle_scale` 口径统一，§10.1） | ⏳ **未做** —— 本轮不动，仍是独立待办 |
| §10.2 的 `span` 闸门 | ✅ 沿用（端点段不保速，两条路同口径） |
| §12.3 补新测试 + bug 注入 | ✅ `tests/gui_move_endpoint_keepspeed_check.py`（31 条，含 3 条注入） |

### 与本文档不同的两点（落地时实测修正）

**1. 偏好读取点上移到 `state.uniform_handle_mode`**

本文档建议"搬到中立位置或从 modal_edit 引用"。落地选了 `state` —— 它已有
`get_addon_prefs`，且"谁都依赖它、它不反向依赖任何模块"，是天然的中立层。
`edit_geometry._uniform_mode` 变成它的**别名**（`is` 判定为同一个对象）⇒
全仓读偏好**只有一份实现**，两条路读到的必然是同一个开关。

**2. uniform 通路的"短手柄"判据由「视觉零」换成 `UNIFORM_LEN_MIN`**

端点模态现在与鼠标拖拽**完全同口径**：|dv| ≤ 1.0 一律不保速。
⚠️ 这**包含 S 单端点** —— 它原来走的是"只要视觉上非零就缩 dt"那条路，
所以这是一处**行为变化**：极短手柄的 S 缩放不再保速。

代价与收益都写清楚了：收益是两条路不再存在第二种口径（本轮 bug 的根因就是
"两条路各一套"）；代价是"短手柄"的边界从屏幕 6px 退到了 1 个世界单位
（默认视图下约 49px）。测试 B3b 把这条边界钉成了断言。

