# -*- coding: utf-8 -*-
"""生成「折角 / 相切」对照演示工程（只读验证用，不动任何用户工程）。

运行（独立 headless 进程，不碰 GUI 实例）：
    blender --background --factory-startup --python 生成脚本.py

产出：折角演示.blend —— 5 个对象，每个一个对照场景：
    A 规范状态        ：左右共线 + 三轴时间跨度相等 ⇒ 3D 手柄一条直线、与路径相切
    B 违反②只改长度    ：右侧 Y 轴【值分量】+1 → +3 ⇒ 3D 出现折角
    C 正常操作只改速度 ：右侧 Y 轴【时间分量】8 → 20（值分量不动）⇒ 3D 不折角
    D 违反⑤对齐型反噬  ：类型 ALIGNED + 只改 Y 轴时间分量 ⇒ Blender 反手改掉值分量 ⇒ 折角
    E 违反③缺轴        ：删掉 Z 轴中间帧的关键帧 ⇒ 该帧手柄少一个分量

⚠️ 本脚本只写 .blend，不改插件源码、不碰任何已有工程。
"""
import os
import sys
import math
import json

import bpy
import mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_BLEND = os.path.join(HERE, "折角演示.blend")
OUT_JSON = os.path.join(HERE, "折角演示_实测数字.json")

# ---- 清场（factory-startup 本来就是空的，保险起见）----
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

KFS = ((1, 0.0), (25, 3.0), (55, 6.0))     # 帧 → X 轴值
Y_PROFILE = {1: 0.0, 25: 2.0, 55: 0.0}
Z_PROFILE = {1: 0.0, 25: 0.6, 55: 0.0}
MID = 25.0

# 中间帧 25 的基准手柄（左右严格反向共线；三轴时间跨度都是 8）
BASE_DV = {0: 1.0, 1: 0.5, 2: 0.25}
BASE_DT = 8.0

SCENES = [
    # (对象名, Y 偏移, 说明, 场景编号)
    ("A_规范_共线且三轴同步", 0.0, "规范状态：左右共线 + 三轴时间跨度相等"),
    ("B_违反②_只改长度", 5.0, "只把右侧 Y 轴的【值分量】从 0.5 改成 1.5"),
    ("C_正常操作_只改速度", 10.0, "只把右侧 Y 轴的【时间分量】从 8 改成 20"),
    ("D_违反⑤_对齐型被反噬", 15.0, "类型=对齐 + 只改 Y 轴时间分量 ⇒ Blender 改掉值分量"),
    ("E_违反③_缺轴", 20.0, "删掉 Z 轴中间帧关键帧 ⇒ 手柄少一个分量"),
]


def curves(o):
    """取 location 的三条 F-Curve。

    ⚠️ Blender 4.4+ 是【分层动作】：`action.fcurves` **不存在**（不是空，是 AttributeError），
       必须走 action → layers → strips → channelbag(slot) → fcurves。
       slot 要按对象自己的 `animation_data.action_slot` 取（别写死 slots[0]）。
    """
    act = o.animation_data.action
    fcs = []
    try:
        fcs = list(act.fcurves)
    except Exception:
        fcs = []
    if not fcs:
        try:
            ad = o.animation_data
            slot = getattr(ad, "action_slot", None)
            if slot is None and act.slots:
                slot = act.slots[0]
            for layer in act.layers:
                for strip in layer.strips:
                    bag = strip.channelbag(slot, ensure=False)
                    if bag is None:
                        continue
                    fcs.extend(list(bag.fcurves))
        except Exception:
            pass
    out = {}
    for fc in fcs:
        if fc.data_path == 'location':
            out[fc.array_index] = fc
    return out


def kp_at(o, frame, ax):
    for kp in curves(o)[ax].keyframe_points:
        if abs(kp.co[0] - frame) < 1e-3:
            return kp
    return None


def set_handle(o, frame, side, dt, dv_by_axis):
    for ax, fc in curves(o).items():
        kp = kp_at(o, frame, ax)
        if kp is None:
            continue
        t = float(kp.co[0]) + (dt if side == 'right' else -dt)
        v = float(kp.co[1]) + dv_by_axis[ax]
        if side == 'right':
            kp.handle_right = (t, v)
        else:
            kp.handle_left = (t, v)
    for fc in curves(o).values():
        fc.update()


def read_handle(o, frame, side):
    dv, dt = {}, {}
    for ax, fc in curves(o).items():
        kp = kp_at(o, frame, ax)
        if kp is None:
            continue
        h = kp.handle_right if side == 'right' else kp.handle_left
        dv[ax] = float(h[1]) - float(kp.co[1])
        dt[ax] = float(h[0]) - float(kp.co[0])
    return dv, dt


def fold_deg(o, frame=MID):
    dl, _ = read_handle(o, frame, 'left')
    dr, _ = read_handle(o, frame, 'right')
    u = [dl.get(a, 0.0) for a in (0, 1, 2)]
    v = [-dr.get(a, 0.0) for a in (0, 1, 2)]
    lu = math.sqrt(sum(x * x for x in u))
    lv = math.sqrt(sum(x * x for x in v))
    if lu < 1e-12 or lv < 1e-12:
        return None
    d = sum(u[i] * v[i] for i in range(3)) / (lu * lv)
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def tangent_deg(o, frame=MID, side='right'):
    """手柄方向 与 路径切线 的夹角（相切 ⇒ 0）。"""
    dv, dt = read_handle(o, frame, side)
    tan = [dv.get(a, 0.0) / dt[a] if abs(dt.get(a, 0.0)) > 1e-12 else 0.0
           for a in (0, 1, 2)]
    u = [dv.get(a, 0.0) for a in (0, 1, 2)]
    lu = math.sqrt(sum(x * x for x in u))
    lv = math.sqrt(sum(x * x for x in tan))
    if lu < 1e-12 or lv < 1e-12:
        return None
    d = sum(u[i] * tan[i] for i in range(3)) / (lu * lv)
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def build(name, y_off):
    """建对象 + 3 个关键帧（X/Y/Z 三轴都有），全 FREE，并设好基准手柄。"""
    me = bpy.data.meshes.new(name + "_mesh")
    me.from_pydata([(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1)], [], [(0, 1, 2), (0, 1, 3)])
    me.update()
    o = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(o)

    for f, xv in KFS:
        bpy.context.scene.frame_set(f)
        o.location = (xv, Y_PROFILE[f] + y_off, Z_PROFILE[f])
        o.keyframe_insert("location", frame=f)

    for fc in curves(o).values():
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()

    # 基准手柄：左右严格反向共线，三轴时间跨度都是 8
    set_handle(o, MID, 'left', BASE_DT, {a: -BASE_DV[a] for a in BASE_DV})
    set_handle(o, MID, 'right', BASE_DT, dict(BASE_DV))
    return o


report = []
built = {}
for name, y_off, desc in SCENES:
    built[name] = build(name, y_off)

# ---- A：规范状态（什么都不用改）----

# ---- B：只改右侧 Y 轴的【值分量】（长度）----
oB = built["B_违反②_只改长度"]
kp = kp_at(oB, MID, 1)
kp.handle_right = (float(kp.handle_right[0]), float(kp.co[1]) + 1.5)
for fc in curves(oB).values():
    fc.update()

# ---- C：只改右侧 Y 轴的【时间分量】（速度）----
oC = built["C_正常操作_只改速度"]
kp = kp_at(oC, MID, 1)
kp.handle_right = (float(kp.co[0]) + 20.0, float(kp.handle_right[1]))
for fc in curves(oC).values():
    fc.update()

# ---- D：类型=对齐，然后只改 Y 轴的时间分量（触发 Blender 反噬）----
oD = built["D_违反⑤_对齐型被反噬"]
_d_fold_after_type = None
for ax, fc in curves(oD).items():
    kp = kp_at(oD, MID, ax)
    kp.handle_left_type = 'ALIGNED'
    kp.handle_right_type = 'ALIGNED'
for fc in curves(oD).values():
    fc.update()
_d_fold_after_type = round(fold_deg(oD) or 0.0, 4)
_d_dv_after_type = {str(a): round(read_handle(oD, MID, 'right')[0].get(a, 0.0), 4) for a in (0, 1, 2)}
# 只改 Y 轴【时间跨度】8 → 14（长度一点没动）
kp = kp_at(oD, MID, 1)
kp.handle_right = (float(kp.co[0]) + 14.0, float(kp.handle_right[1]))
for fc in curves(oD).values():
    fc.update()

# ---- E：删掉 Z 轴中间帧的关键帧 ----
oE = built["E_违反③_缺轴"]
fcZ = curves(oE)[2]
for kp in [k for k in fcZ.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
    fcZ.keyframe_points.remove(kp)
fcZ.update()

# ---- 汇总实测数字 ----
for name, y_off, desc in SCENES:
    o = built[name]
    dl, dtl = read_handle(o, MID, 'left')
    dr, dtr = read_handle(o, MID, 'right')
    report.append({
        "对象": name,
        "说明": desc,
        "折角(度)": round(fold_deg(o) or 0.0, 4),
        "右侧手柄与路径切线夹角(度)": round(tangent_deg(o, MID, 'right') or 0.0, 4),
        "左 dv": {str(a): round(dl.get(a, 0.0), 4) for a in (0, 1, 2)},
        "右 dv": {str(a): round(dr.get(a, 0.0), 4) for a in (0, 1, 2)},
        "左 dt": {str(a): round(dtl.get(a, 0.0), 4) for a in (0, 1, 2)},
        "右 dt": {str(a): round(dtr.get(a, 0.0), 4) for a in (0, 1, 2)},
        "右类型": str(kp_at(o, MID, 1).handle_right_type) if kp_at(o, MID, 1) else "?",
        "中间帧有手柄的轴": sorted(dl.keys()),
        "备注": ("设成 ALIGNED 后折角=%.4f°、右 dv=%s；再改 Y 轴时间跨度 8→14 ⇒ 折角 %.4f°"
                 % (_d_fold_after_type, _d_dv_after_type, round(fold_deg(oD) or 0.0, 4))
                 if name.startswith("D_") else ""),
    })

# ---- 场景与视图设置 ----
sc = bpy.context.scene
sc.frame_start = 1
sc.frame_end = 55
sc.frame_set(25)
sc.render.engine = 'BLENDER_WORKBENCH'

# ---- 把说明写进 .blend 的 Text 数据块（打开就能看）----
txt = bpy.data.texts.new("★ 怎么看这个文件")
txt.write("\n".join([
    "RealTimeMotionPath —— 「折角 / 相切」对照演示",
    "",
    "用法：",
    "  1) 点 3D 视图标题栏上的 🎯 图标，打开运动路径显示",
    "  2) 按 Home（或 View → Frame All）把 5 个对象都框进视野",
    "  3) 逐个选中对象，看它的运动路径 + 手柄；同时开 Graph Editor 对照",
    "  4) 当前帧已经停在 25（中间帧），那正是手柄出现差异的地方",
    "",
    "5 个场景：",
    "  A_规范_共线且三轴同步   左右一条直线、与路径相切（期望的样子）",
    "  B_违反②_只改长度        右侧 Y 轴手柄【长度】被拉长 ⇒ 3D 出现折角",
    "  C_正常操作_只改速度     右侧 Y 轴手柄【时间跨度】被拉长 ⇒ 3D 不折角",
    "                          （但 Graph Editor 里能看到右手柄点错位了）",
    "  D_违反⑤_对齐型被反噬    类型=对齐 + 只改时间跨度 ⇒ Blender 反手改掉长度 ⇒ 折角",
    "  E_违反③_缺轴            Z 轴在 25 帧没有关键帧 ⇒ 该帧手柄少一个分量",
    "",
    "数字见同目录的：折角演示_实测数字.json",
    "",
    "⚠️ 本文件由 headless 脚本生成，不含任何用户工程数据。",
]))

# ---- 保存 ----
bpy.ops.wm.save_as_mainfile(filepath=OUT_BLEND)
with open(OUT_JSON, "w", encoding="utf-8") as fh:
    json.dump(report, fh, ensure_ascii=False, indent=1)

print("=" * 92)
print("%-26s %10s %14s %-26s %-22s" % ("对象", "折角(°)", "相切角(°)", "右 dv (长度)", "右 dt (时间跨度)"))
print("-" * 92)
for r in report:
    print("%-26s %10.4f %14.4f %-26s %-22s" % (
        r["对象"], r["折角(度)"], r["右侧手柄与路径切线夹角(度)"],
        str([r["右 dv"][a] for a in ("0", "1", "2")]),
        str([r["右 dt"][a] for a in ("0", "1", "2")])))
print("=" * 92)
print("已保存:", OUT_BLEND)
print("数字  :", OUT_JSON)
