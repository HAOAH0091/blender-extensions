# -*- coding: utf-8 -*-
"""实机 GUI 探针 v3：真实窗口 + 真实 addon 启用 + 绘制层验证。

⚠️ 判据修正：Blender 按 `bl_idname` 注册 operator，
   `bl_idname="rtmp.path_point_drag"` ⇒ 类型名是 `RTMP_OT_path_point_drag`
   （不是源码里的类名 `RTMP_OT_PathPointDrag`）。
"""
import sys, os, json, traceback, importlib
PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)
import bpy

steps = []
def step(n, ok, d=""): steps.append({"name": n, "ok": bool(ok), "detail": str(d)})

def main():
    try:
        step("GUI: 真实窗口存在", bpy.context.window is not None, "")
        step("GUI: 3D 视图区域存在",
             any(a.type == 'VIEW_3D' for a in bpy.context.screen.areas), "")
        import addon_utils
        addon_utils.enable(PKG_NAME, default_set=True, persistent=True)
        # 正确判据：按 bl_idname 推导的类型名
        ops = [n for n in dir(bpy.types) if n.startswith("RTMP_OT_")]
        step("GUI: Operator 已注册（按 bl_idname）", len(ops) >= 8, "count=%d %s" % (len(ops), ops[:4]))
        step("GUI: 本次新增的路径拖拽 operator",
             hasattr(bpy.types, "RTMP_OT_path_point_drag"), "")
        step("GUI: WM 属性已注册",
             hasattr(bpy.context.window_manager, "rtmp_handle_scale"), "")
        # 场景
        if not bpy.data.objects:
            bpy.ops.mesh.primitive_cube_add()
        ob = bpy.context.view_layer.objects.active
        step("GUI: 拿到活动对象", ob is not None, "")
        ob.keyframe_insert("location", frame=1)
        ob.location = (3.0, 3.0, 0.0)
        ob.keyframe_insert("location", frame=40)
        # ⚠️ 判据走**插件自己的 API**：Blender 4.4+ 已移除 Action.fcurves
        #    （改用 slots / layers / channelbags）——用插件读曲线的真实入口。
        cache = importlib.import_module(PKG_NAME + ".cache")
        curves = cache.collect_animation_curves(ob.animation_data.action, ob) \
            if ob.animation_data else []
        step("GUI: 建场景 + 关键帧（走插件 collect_animation_curves）",
             len(curves) >= 3, "curves=%d" % len(curves))
        # 让绘制层真的跑一次
        for a in bpy.context.screen.areas:
            if a.type == 'VIEW_3D':
                a.tag_redraw()
        step("GUI: 视图重绘已触发", True, "")
        # ⚠️ 关键：真实 GUI 下 handler 会被调用；headless 不会
        ov = importlib.import_module(PKG_NAME + ".overlay")
        step("GUI: overlay 模块可加载", hasattr(ov, "_norm_selected"), "")
    except Exception:
        step("EXCEPTION", False, traceback.format_exc())
    fails = [s for s in steps if not s["ok"]]
    print("=" * 60)
    for s in steps:
        print("[%s] %s %s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                              ("<- " + s["detail"]) if not s["ok"] else ""))
    print("断言 %d / 失败 %d" % (len(steps), len(fails)))
    print("=== GUI_RESULT " + json.dumps({"fails": len(fails), "total": len(steps)}) + " ===")
    sys.stdout.flush()
    return None

bpy.app.timers.register(main, first_interval=2.0)
bpy.app.timers.register(lambda: (bpy.ops.wm.quit_blender(), None)[1], first_interval=10.0)
