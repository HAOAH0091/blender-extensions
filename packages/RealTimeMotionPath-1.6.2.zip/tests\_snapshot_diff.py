# -*- coding: utf-8 -*-
"""快照结构化比对 —— 判断"改动前后行为是否一致"。

为什么不能直接文本 diff（实测踩到）
-----------------------------------
`_snapshot_recorder.py` 输出的是 JSON。第一版比对直接用 `Compare-Object` 做
**逐行文本比对** —— 结果给 `_session` 新增一个字段（`speed_drag_wrote`）之后，
**后面所有行都错位一行**，于是报出 15,714 行"差异"，而真正的行为差异是 **0**。
⇒ 文本比对对"字段增减"完全无能，必须按 **JSON 路径** 结构化比对。

三类输出（含义完全不同）
------------------------
1. **值差异**（`value`）—— 同一路径上两个值不同 ⇒ **这才是真正的行为变化**。
   必须为空；若非空，要么改回去，要么明确说明"这是有意的"并更新基线。
2. **仅在 A 有**（`only_a`）—— 改动后**少了**这个字段/条目 ⇒ 要查是不是被删掉了。
3. **仅在 B 有**（`only_b`）—— 改动后**多了** ⇒ 通常是新增状态字段（预期内），
   但也要确认它不影响行为。

用法
----
    python tests\\_snapshot_diff.py before after
    python tests\\_snapshot_diff.py before after --max 40
"""
import json
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))


def load(tag):
    p = os.path.join(HERE, "_snapshot_%s.json" % tag)
    if not os.path.exists(p):
        raise SystemExit("找不到快照: %s（先跑 _snapshot_recorder.py --tag %s）" % (p, tag))
    with open(p, "r", encoding="utf-8") as fh:
        return json.load(fh)


def walk(a, b, path, out):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            sub = "%s/%s" % (path, k)
            if k not in a:
                out["only_b"].append(sub)
            elif k not in b:
                out["only_a"].append(sub)
            else:
                walk(a[k], b[k], sub, out)
        return
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out["value"].append(("%s (长度)" % path, "%d 项" % len(a), "%d 项" % len(b)))
            return
        for i, (x, y) in enumerate(zip(a, b)):
            walk(x, y, "%s[%d]" % (path, i), out)
        return
    if a != b:
        out["value"].append((path, a, b))


def main():
    argv = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(argv) < 2:
        print(__doc__)
        return 2
    tag_a, tag_b = argv[0], argv[1]
    max_show = 25
    if "--max" in sys.argv:
        max_show = int(sys.argv[sys.argv.index("--max") + 1])

    A, B = load(tag_a), load(tag_b)
    out = {"value": [], "only_a": [], "only_b": []}
    walk(A, B, "", out)

    # 顶层元信息（不算被测行为）：
    #   tag / blender 版本 / 环境 / **录像机挂了哪些方法**
    #   ⚠️ 最后一项尤其重要：拆分 `modal()` 之后，替身会多挂几个 `_ev_*` 方法，
    #      那是**工具信息**不是行为 —— 不排除的话，每次重构都会假报"行为有变化"
    #      （实测：拆 583 行 modal 时它报了 1 处"值差异"，全是这个）。
    META = ("/tag", "/blender", "/gpu", "/draw_ran", "/unserializable",
            "/mounted_methods", "/step_count")
    for key in ("value",):
        out[key] = [v for v in out[key] if not v[0].startswith(META)]
    for key in ("only_a", "only_b"):
        out[key] = [p for p in out[key] if not p.startswith(META)]

    print("=" * 78)
    print("快照结构化比对: %s  →  %s" % (tag_a, tag_b))
    print("=" * 78)

    print("\n【1】值差异（真正的行为变化）: %d 处" % len(out["value"]))
    for p, x, y in out["value"][:max_show]:
        print("   %s\n       %s  ->  %s" % (p, x, y))
    if len(out["value"]) > max_show:
        print("   ... 还有 %d 处" % (len(out["value"]) - max_show))

    # 字段增减按"字段名"聚合（路径里带下标，逐个列会很吵）
    def field_names(paths):
        names = {}
        for p in paths:
            leaf = p.rstrip("]").split("[")[0].rsplit("/", 1)[-1]
            names[leaf] = names.get(leaf, 0) + 1
        return names

    fa, fb = field_names(out["only_a"]), field_names(out["only_b"])
    print("\n【2】改动后【少了】的字段: %d 个路径" % len(out["only_a"]))
    for k, v in sorted(fa.items()):
        print("   - %s  (×%d)" % (k, v))
    print("\n【3】改动后【多了】的字段: %d 个路径" % len(out["only_b"]))
    for k, v in sorted(fb.items()):
        print("   + %s  (×%d)" % (k, v))

    print("\n" + "=" * 78)
    if out["value"]:
        print("结论: 存在 %d 处**值差异** ⇒ 行为有变化（需逐条确认是否预期）"
              % len(out["value"]))
        return 1
    print("结论: 值差异 0 处 ⇒ **行为一致**"
          + ("（仅字段集合有增减，见上）" if (fa or fb) else "（字段集合也一致）"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
