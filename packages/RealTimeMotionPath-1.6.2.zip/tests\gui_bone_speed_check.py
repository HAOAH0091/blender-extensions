# -*- coding: utf-8 -*-
"""回归测试：姿态模式（骨骼）下速度三角链路必须传 bone_name。

背景（2026-09-29 用户报障 + 真机实测确证）：
    速度三角这条子路径**整条链都没传 `bone_name`** ⇒
    `td._collect_position_curves(act, obj, None)` 里
    `cache.is_position_animation(fc, None)` 只认 `data_path == 'location'`，
    而骨骼曲线是 `pose.bones["X"].location` ⇒ **全被排除** ⇒
    「姿态模式下速度三角一个都不出现」。

    ⚠️ 这**不是**骨骼支持没做：鼠标拖拽 / 键盘模态那几处本来就正确传了
      `_session.active_bone_identifier`；`modal_edit._pose_bone_name` 也早是
      权威口径；`keyframe_screens`（2026-09-27 3e）也已传。**只有速度三角链漏了**。

    另一个放大器：`_all_speed_handles` 的宽 `except` **静默返回 []** ⇒
    完全无报错、无日志 ⇒ 无从排查。本测试同时守住「不再静默」。

跑法（后台即可）：
    blender --background --factory-startup --python tests/gui_bone_speed_check.py
"""
import sys, os, json, traceback, importlib
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)
import bpy

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})

FR = 25.0

def main():
    try:
        import addon_utils
        addon_utils.enable(PKG_NAME, default_set=True, persistent=False)
        it = importlib.import_module(PKG_NAME + ".interaction")
        md = importlib.import_module(PKG_NAME + ".modal_edit")
        td = importlib.import_module(PKG_NAME + ".time_domain")
        cache = importlib.import_module(PKG_NAME + ".cache")
        hd = importlib.import_module(PKG_NAME + ".handles")

        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.object.armature_add(location=(0, 0, 0))
        arm = bpy.context.view_layer.objects.active
        arm.name = "ARMT"
        bpy.ops.object.mode_set(mode='EDIT')
        eb = arm.data.edit_bones
        b2 = eb.new("Bone2")
        b2.head = (2.0, 0.0, 0.0); b2.tail = (3.0, 0.0, 0.0)
        names = [b.name for b in eb]
        bpy.ops.object.mode_set(mode='POSE')
        for f, d in [(1, (0, 0, 0)), (25, (1.5, 1.0, 0.0)), (55, (3.0, 0.0, 0.0))]:
            for nm in names:
                pb = arm.pose.bones[nm]
                pb.location = d
                pb.keyframe_insert("location", frame=f)
        bpy.context.scene.frame_set(25)
        act = arm.animation_data.action
        BONE = names[0]

        step("A1 场景：armature + 2 骨骼 + location 关键帧",
             len(names) >= 2, "骨骼=%s mode=%s" % (names, arm.mode))

        # ---- A 组：曲线路径确认 + 核心对照 ----
        paths = sorted({fc.data_path for fc in cache.collect_animation_curves(act, arm)})
        step("A2 曲线路径是 pose.bones[...]（不是裸 'location'）",
             any("pose.bones" in p for p in paths), json.dumps(paths, ensure_ascii=False)[:150])

        n_none = len(md._keyframes_of(act, arm, None))
        n_bone = len(md._keyframes_of(act, arm, BONE))
        step("A3 ★★ 核心对照：不带骨骼名 = 0 个关键帧（= 用户看到的\"无三角\"），"
             "带骨骼名 = 3 个",
             n_none == 0 and n_bone == 3,
             "不带=%d（应 0）/ 带 '%s'=%d（应 3）" % (n_none, BONE, n_bone))

        # ---- B 组：resolve_target / 写入链路（显式传骨骼名）----
        km_none, sp_none = td.resolve_target(act, arm, FR, 'left')
        km_bone, sp_bone = td.resolve_target(act, arm, FR, 'left', BONE)
        step("B1 ★ resolve_target 不带骨骼名取不到（= 对齐会 no_source）",
             (not km_none) or sp_none is None, "kf_map=%s span=%s" % (bool(km_none), sp_none))
        step("B2 ★ resolve_target 带骨骼名取到 3 轴",
             bool(km_bone) and len(km_bone) == 3 and sp_bone is not None,
             "轴=%s span=%s" % (sorted(km_bone.keys()) if km_bone else None, sp_bone))

        # ---- C 组：对齐能否真正写进【骨骼】曲线 ----
        def slopes(bone):
            out = {}
            for fc in cache.collect_animation_curves(act, arm):
                if fc.data_path != 'pose.bones["%s"].location' % bone:
                    continue
                for kp in fc.keyframe_points:
                    if abs(float(kp.co[0]) - FR) < 1e-3:
                        A = float(kp.co[1]) - float(kp.handle_left[1])
                        B = float(kp.handle_right[1]) - float(kp.co[1])
                        dL = abs(float(kp.co[0]) - float(kp.handle_left[0]))
                        dR = abs(float(kp.handle_right[0]) - float(kp.co[0]))
                        out[fc.array_index] = {
                            "slopeL": A / dL if dL > 1e-12 else None,
                            "slopeR": B / dR if dR > 1e-12 else None,
                            "A": A, "B": B}
            return out

        # 先给骨骼做一层"两侧不等"的手柄（制造需要对齐的状态）
        for fc in cache.collect_animation_curves(act, arm):
            if fc.data_path != 'pose.bones["%s"].location' % BONE:
                continue
            for kp in fc.keyframe_points:
                if abs(float(kp.co[0]) - FR) < 1e-3:
                    kp.handle_left_type = 'FREE'
                    kp.handle_right_type = 'FREE'
                    kp.handle_left = (17.0, float(kp.co[1]) - 2.0)
                    kp.handle_right = (33.0, float(kp.co[1]) + 1.0)
            fc.update()
        before = slopes(BONE)
        step("C1 制造出\"两侧不等\"的骨骼手柄", True,
             json.dumps({k: {"L": round(v["slopeL"], 4) if v["slopeL"] is not None else None,
                             "R": round(v["slopeR"], 4) if v["slopeR"] is not None else None}
                         for k, v in sorted(before.items())}, ensure_ascii=False))

        v0 = {k: (v["A"], v["B"]) for k, v in before.items()}

        # ★ 不传骨骼名 ⇒ 应在函数内**自动回退**取到（`_bone_name_of`）
        #   这是设计要点：既有调用点一个字不用改也能在骨骼场景工作。
        ok_auto, info_auto, why_auto = it._align_opposite_speed(bpy.context, arm, FR,
                                                                hd.TRI_UP, None)
        step("C2 ★ 不传骨骼名 ⇒ 函数内自动回退取到（既有调用点零改动）",
             ok_auto, "ok=%s reason=%s bone_name_of=%r"
             % (ok_auto, why_auto, it._bone_name_of(bpy.context, arm)))

        # ★ 但若**回退也取不到**（非 POSE / 无活动骨骼）⇒ 必须失败，
        #   而不是"静默写到错误的曲线上去"。用打桩模拟取不到的情形。
        _orig = it._bone_name_of
        try:
            it._bone_name_of = lambda *a, **k: None
            ok_none, info_none, why_none = it._align_opposite_speed(bpy.context, arm, FR,
                                                                    hd.TRI_UP, None)
        finally:
            it._bone_name_of = _orig
        step("C2b ★ 回退也取不到 ⇒ 明确失败（不是静默写错地方）",
             (not ok_none) and why_none in ("no_source", "no_opposite"),
             "ok=%s reason=%s" % (ok_none, why_none))

        # ★ 传骨骼名 → 成功且三轴共线
        ok_yes, info_yes, why_yes = it._align_opposite_speed(bpy.context, arm, FR,
                                                             hd.TRI_UP, BONE)
        step("C3 ★★★ 传骨骼名 ⇒ 对齐成功", ok_yes,
             "ok=%s reason=%s info=%s" % (ok_yes, why_yes,
                 json.dumps(info_yes, ensure_ascii=False, default=str)[:150] if info_yes else None))
        after = slopes(BONE)
        # ★★ 2026-09-30 口径变更（B 语义）：
        #    双击锁定 = **同步三角值 s**（"一体"），**不再追求 GE 手柄共线**。
        #    所以这里断言的从"三轴共线"改成"**三轴 dt 一致**"（规范要求）。
        #    GE 共线那件事交给弹窗里的校正（它会明确告知会改变路径形状）。
        # ⚠️ 必须按【骨骼】过滤 fcurve —— 本测试建了 2 根骨骼（Bone/Bone2），
        #    不过滤会把两根骨骼的 dt 混在一起（第一版就这样，跨度假失败 4.67）。
        _dtR = [abs(float(kp.handle_right[0]) - float(kp.co[0]))
                for fc in cache.collect_animation_curves(act, arm)
                if fc.data_path == 'pose.bones["%s"].location' % BONE
                for kp in fc.keyframe_points if abs(float(kp.co[0]) - FR) < 1e-3]
        _spread = (max(_dtR) - min(_dtR)) if _dtR else -1
        step("C4 ★★★ 锁定后骨骼曲线**三轴 dt 完全一致**（真的写进 pose.bones 了）",
             _dtR and _spread < 1e-6,
             "dtR=%s 跨度=%.2e（共线={%s} —— 本版不保证，属设计）"
             % ([round(x, 4) for x in _dtR], _spread,
                ", ".join("%d:%s" % (ax, (after[ax]["slopeL"] is not None
                                          and after[ax]["slopeR"] is not None
                                          and abs(after[ax]["slopeL"] - after[ax]["slopeR"]) < 1e-6))
                          for ax in sorted(after))))
        step("C5 ★ 保形状：值分量 A/B 一个没变",
             all(abs(v0[ax][0] - after[ax]["A"]) < 1e-9 and
                 abs(v0[ax][1] - after[ax]["B"]) < 1e-9 for ax in after),
             "before=%s after=%s" % ({k: (round(v[0], 4), round(v[1], 4)) for k, v in sorted(v0.items())},
                                     {k: (round(after[k]["A"], 4), round(after[k]["B"], 4)) for k in sorted(after)}))
    except Exception:
        step("EXCEPTION", False, traceback.format_exc()[-1200:])

    print("=" * 74)
    for s in steps:
        print("[%s] %s  %s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                              ("<- " + s["detail"]) if s["detail"] else ""))
    fails = sum(1 for s in steps if not s["ok"])
    print("总计 %d 项 | PASS %d | FAIL %d | %s"
          % (len(steps), len(steps) - fails, fails, "ALL PASS" if not fails else "HAS FAILURES"))
    OUT = os.path.join(PLUGIN_DIR, "tests", "_bone_speed_result.json")
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"total": len(steps), "fails": fails, "steps": steps}, f,
                  ensure_ascii=False, indent=1)
    print("RESULT:", "PASS" if not fails else "FAIL")
    sys.stdout.flush()

if __name__ == "__main__":
    main()
