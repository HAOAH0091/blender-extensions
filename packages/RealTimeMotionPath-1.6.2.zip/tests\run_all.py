# -*- coding: utf-8 -*-
"""RTMP 全量测试门禁 —— 把 50 份散落的结果 JSON 收成一道闸门。

存在意义（为什么需要它）
------------------------
`run_tests.bat` 只跑 `regression.py` 的 14 条断言，而 `tests/` 里有 **1,223 条**。
其余 56 个脚本没有任何入口调度，其中 31 个还用 `os._exit(0)` 强退 —— **退出码恒 0**。
于是"红了 N 天没人管"不是疏忽，是**机制缺位**。

本脚本不改那 31 个脚本（它们已经在写 `_*_result.json` 了），
而是**直接读结果文件**判定 —— 这是成本最低、也最可靠的接法。

判定规则
--------
| 情况 | 判定 | 退出码 |
|---|---|---|
| 任一文件 `fails > 0` | **FAIL** | 1 |
| 某文件 `total` **少于**基线（= FATAL 提前中断的典型指纹） | **SUSPECT** | 1 |
| 某文件 `total` 多于基线（新增用例） | INFO | 0 |
| 基线里有、本次没产出（未跑） | INFO | 0 |
| 基线里没有、本次新产出 | INFO | 0 |

用法
----
    python tests\\run_all.py                  # 判定（有 FAIL/SUSPECT 则 exit 1）
    python tests\\run_all.py --update-baseline # 把当前步数写为新基线
    python tests\\run_all.py --list            # 只列清单，不判定

⚠️ 本脚本**只读**结果 JSON，不启动 Blender、不改任何产品代码。
"""
import json
import os
import sys

# ⚠️ 必须重设 stdout 编码 —— 中文 Windows 下 Python 默认走 GBK，
#    打印 `⇒` 这类字符会直接抛 UnicodeEncodeError 把整个门禁搞崩。
#    （本项目其它测试脚本都有这一句，本脚本第一版漏了，实测踩到。）
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
BASELINE = os.path.join(HERE, "_runall_baseline.json")

# 不是"测试结果"的 JSON（快照 / 基线自身）
# ★ 2026-09-27（复盘）：`_e2e_result.json` 是**孤儿** ——
#   全仓没有任何脚本写它（实测最后修改时间 2026-09-18，比本次会话早 10 天），
#   留着会让门禁一直报 STALE。确认无用后可删文件。
_EXCLUDE = ("_runall_baseline.json", "_e2e_result.json")
_EXCLUDE_PREFIX = ("_snapshot_",)


def _is_result_file(name):
    if not (name.startswith("_") and name.endswith(".json")):
        return False
    if name in _EXCLUDE:
        return False
    for p in _EXCLUDE_PREFIX:
        if name.startswith(p):
            return False
    return True


def _newest_source_mtime():
    """产品源码（**不含 tests/**）里最新的修改时间。

    ★★ 2026-09-27（复盘）：**陈旧结果检查**的基准 —— 这是本门禁自己的一个漏洞。

    本门禁读的是各脚本写下的 `_*_result.json`。如果某个脚本在产品代码改动后
    **没有被重跑**，门禁就会拿**旧结果**充当"通过"。

    实测踩到：i18n 把状态栏文案统一改成英文后，`gui_numeric_check.py` 里
    三条断言（`"[输入 2.5]" in txt`）已经失败，但 `_num_result.json`
    还是改动前的（fails=0）⇒ **门禁报"全部通过"，这条真回归被藏了一段时间**，
    最后是靠"给测试脚本加退出码"才顺带发现的。

    ⇒ 判据：结果文件的 mtime < 最新产品源码的 mtime ⇒ **STALE（不可信）**，
      不许它冒充 PASS。
    """
    root_dir = os.path.dirname(HERE)
    newest = 0.0
    for root, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d not in ("tests", "__pycache__", ".git")]
        for f in files:
            if f.endswith(".py"):
                try:
                    newest = max(newest, os.path.getmtime(os.path.join(root, f)))
                except OSError:
                    pass
    return newest


def parse_result(path):
    """把一个结果 JSON 解析成 (total, fails, note)。

    兼容项目里实际存在的几种格式：
      · {total, fails, result, steps|rows}
      · {rows: [{status|ok, ...}]}（无 total 时按行数推）
      · 无 PASS/FAIL 概念的文件（如 _shape.json）→ note 说明，total=None
    """
    try:
        with open(path, "r", encoding="utf-8") as fh:
            j = json.load(fh)
    except Exception as exc:
        return None, None, "解析失败: %r" % (exc,), 0

    if not isinstance(j, dict):
        return None, None, "顶层不是对象", 0

    rows = j.get("rows")
    if rows is None:
        rows = j.get("steps")

    total = j.get("total")
    fails = j.get("fails")

    if total is None and isinstance(rows, list):
        total = len(rows)

    if fails is None and isinstance(rows, list):
        n = 0
        for r in rows:
            if not isinstance(r, dict):
                continue
            if r.get("ok") is False:
                n += 1
            elif str(r.get("status", "")).upper() in ("FAIL", "FAILED"):
                n += 1
        fails = n

    # ★★ 2026-09-30（Phase 1）：支持结果里自带的 `suspects` 字段。
    #    "可疑"（NaN/Inf、静默无提示、状态不一致）与"明确失败"分级不同：
    #    两者都让门禁红，但报告里分开列，便于定位根因。
    suspects = j.get("suspects")
    if suspects is None:
        suspects = 0
    try:
        suspects = int(suspects)
    except Exception:
        suspects = 0

    if total is None:
        return None, None, "无 total/rows（非 PASS-FAIL 型结果）", 0
    if fails is None:
        fails = 0
    return int(total), int(fails), "", suspects


def failed_rows(path, limit=8):
    """列出失败项的名字，便于直接定位。"""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            j = json.load(fh)
    except Exception:
        return []
    rows = j.get("rows") or j.get("steps") or []
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        bad = (r.get("ok") is False) or (str(r.get("status", "")).upper() in ("FAIL", "FAILED"))
        if bad:
            detail = str(r.get("detail", "") or r.get("name", ""))
            out.append("%s || %s" % (r.get("name", "?"), detail[:110].replace("\n", " ")))
    return out[:limit]


def main():
    argv = sys.argv[1:]
    if "--list" in argv:
        list_only = True
    else:
        list_only = False
    update = "--update-baseline" in argv

    files = sorted(f for f in os.listdir(HERE) if _is_result_file(f))
    if not files:
        print("没有找到任何结果 JSON —— 先跑一遍测试脚本。")
        return 1

    baseline = {}
    if os.path.exists(BASELINE):
        try:
            with open(BASELINE, "r", encoding="utf-8") as fh:
                baseline = json.load(fh).get("totals", {})
        except Exception:
            baseline = {}

    rows = []
    cur_totals = {}
    n_fail = n_suspect = n_note = n_stale = 0
    sum_total = sum_fails = 0

    # ★★ 陈旧结果检查（详见 `_newest_source_mtime` 的说明）：
    #   结果文件比最新产品源码还旧 ⇒ 它代表的是**改动前的代码**，不可信。
    _newest_src = _newest_source_mtime()
    stale_files = set()
    for f in files:
        try:
            if os.path.getmtime(os.path.join(HERE, f)) < _newest_src:
                stale_files.add(f)
        except OSError:
            pass

    for f in files:
        path = os.path.join(HERE, f)
        total, fails, note, suspects = parse_result(path)
        cur_totals[f] = total
        if total is None:
            n_note += 1
            rows.append(("NOTE", f, "-", "-", note))
            continue
        sum_total += total
        sum_fails += fails
        base = baseline.get(f)
        status = "PASS"
        extra = ""
        if f in stale_files:
            status = "STALE"
            n_stale += 1
            extra = "结果比最新产品源码旧 ⇒ 不可信（该脚本没在产品代码改动后重跑）"
        # ⚠️ 顺序：**先判 FAIL 再判 SUSPECT** —— 一个文件可能两者都有，
        #    先判 suspects 会把有真失败的文件夹成"可疑"，把 FAIL 藏起来（实测踩过）。
        if fails > 0:
            status = "FAIL"
            n_fail += 1
            if suspects > 0:
                extra = "另有 suspects=%d（可疑项，见结果 JSON 的 steps）" % suspects
        elif suspects > 0:
            # ★ 结果里自带 `suspects`（可疑：NaN/Inf、静默无提示、状态不一致）
            status = "SUSPECT"
            n_suspect += 1
            extra = "自带 suspects=%d（可疑项，见结果 JSON 的 steps）" % suspects
        elif base is not None and total < int(base):
            status = "SUSPECT"
            n_suspect += 1
            extra = "步数 %d < 基线 %d（疑似 FATAL 提前中断）" % (total, base)
        elif base is None:
            extra = "（新文件，未入基线）"
        elif total > int(base):
            extra = "步数 %d > 基线 %d（新增用例）" % (total, base)
        rows.append((status, f, total, fails, extra))

    if list_only:
        for st, f, t, fl, ex in rows:
            print("[%-7s] %-32s total=%-5s fails=%-3s %s" % (st, f, t, fl, ex))
        return 0

    width = max(len(r[1]) for r in rows)
    print("=" * 78)
    print("RTMP 全量测试门禁")
    print("=" * 78)
    for st, f, t, fl, ex in rows:
        mark = {"PASS": "  ok  ", "FAIL": " FAIL ", "SUSPECT": "SUSPECT",
                "STALE": " STALE ", "NOTE": " note "}[st]
        print("[%s] %-*s total=%-5s fails=%-4s %s" % (mark, width, f, t, fl, ex))

    print("-" * 78)
    print("文件 %d 个（其中无 PASS/FAIL 概念 %d 个）｜断言合计 %d ｜失败合计 %d"
          % (len(rows), n_note, sum_total, sum_fails))

    if n_fail:
        print("")
        print("### 失败明细 ###")
        for st, f, t, fl, ex in rows:
            if st == "FAIL":
                print("· %s（%s 条失败）" % (f, fl))
                for line in failed_rows(os.path.join(HERE, f)):
                    print("    " + line)

    if update:
        with open(BASELINE, "w", encoding="utf-8") as fh:
            json.dump({"totals": cur_totals,
                       "note": "run_all.py 的步数基线（total < 基线 ⇒ SUSPECT）"},
                      fh, ensure_ascii=False, indent=1, sort_keys=True)
        print("")
        print("已更新基线: %s" % BASELINE)
        return 0

    if not baseline:
        print("")
        print("⚠️ 尚无基线文件 —— 本次结果可作为基线。")
        print("   确认这些数字合理后执行: python tests\\run_all.py --update-baseline")

    if n_stale:
        print("")
        print("### ⚠️ 陈旧结果（不能算通过）###")
        print("以下结果文件比最新产品源码【旧】—— 说明对应脚本在产品代码改动后"
              "没有被重跑，")
        print("它们代表的是**改动前的代码**：")
        for f in sorted(stale_files)[:15]:
            print("    " + f)
        if len(stale_files) > 15:
            print("    … 还有 %d 个" % (len(stale_files) - 15))
        print("  ⇒ 重跑这些脚本之后，本门禁的结论才有意义。")

    print("")
    if n_fail or n_suspect or n_stale:
        print("结果: FAIL %d / SUSPECT %d / STALE %d 个文件 ⇒ 退出码 1"
              % (n_fail, n_suspect, n_stale))
        return 1
    print("结果: 全部通过（且所有结果都晚于最新产品源码）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
