# -*- coding: utf-8 -*-
"""RTMP 调试日志 —— **正式机制**（不是用完即删的临时钩子）。

## 为什么需要它

交互类问题（手感不对 / 数值跳变 / 拖不动 / 偶发失效）在 headless 里**复现不出来**：
- 用假事件模拟，往往因缺字段而与真机行为不符；
- 纯读代码推演，容易连推三轮全错。

这类问题的正确解法是：**加日志 → 让用户真机操作一次 → 读日志定案**。
（2026-09-17 的「拖三角打满卡死」就是这么定位的：日志显示鼠标坐标是 `-1` 哨兵值。）

本模块把那次"临时钩子"沉淀成**长期可用的机制**，以后遇到同类问题直接开开关即可。

## 用法

```python
from .debug_log import dbg, set_enabled, read_tail, clear

dbg("drag.begin", frame=25.0, side='left', mode='UNIFORM',
    offset_world=[1.0, 0.0, 0.0])
```

- 未启用时 `dbg()` 是**零成本空操作**（只做一次布尔判断）。

- ★★ **默认开启**（2026-10-08，用户要求）。
  理由：本机制存在的意义就是「出问题时能查」，而交互类问题**只在复现那一刻才有日志**——
  默认关闭等于「等你想起要开，现场已经过去了」。
  代价有上限：单文件 8MB 自动轮转（保留一个 `.1` 备份），最多约 16MB。
  （用户原话：「如果有，默认开启吧」。）

- 关闭 / 强制开关的方式（三条）：
  1. 偏好设置里关掉「Debug Log」（`debug_log_enabled` / UI 面板 `rtmp_debug_log`）
  2. 环境变量 `RTMP_DEBUG_LOG=0`（假值：`0` / `false` / `no` / `off`，大小写无关）
     或 `RTMP_DEBUG_LOG=1` 强制开；**只要设了这个变量，就按它走**
  3. Python 里 `set_enabled(False)` / `set_enabled(True)`

- **优先级**：方式 1 / 3（显式设定）> 环境变量 > 默认（开）。
  显式设定过就压倒环境变量（便于测试与强制关闭）。

## 日志位置

`<Blender 配置目录>/rtmp_debug/rtmp-YYYYMMDD.jsonl`（跨平台、可写；见 `default_path()`）。

⚠️ 日志**不会自动清理**。排查完请调 `clear()` 或直接删文件（偏好设置里有按钮）。
"""
import json
import os
import threading
import time

try:
    import bpy
except Exception:                                    # 允许在 Blender 外被 import（测试用）
    bpy = None

__all__ = ["dbg", "set_enabled", "is_enabled", "default_path", "read_tail", "clear",
           "log_path", "MAX_BYTES", "apply_prefs_default"]

# 单文件上限（超过就轮转），防止长期误开把磁盘写满
MAX_BYTES = 8 * 1024 * 1024

_lock = threading.Lock()
_enabled = False         # 只在 _explicit=True 时有意义（否则看环境变量 / 默认值）
_explicit = False        # set_enabled() 是否被显式调用过（显式设定优先于环境变量）
_path = None
_rotated = False

# ★★ 2026-10-08（用户要求）：**默认开启**。
#    机制的意义是"出问题时能查"，而交互类问题只在复现那一刻才有日志 ——
#    默认关闭等于"等你想起要开，现场已经过去了"。
#    （此前默认关闭；代价有上限：8MB 轮转 + 一个 .1 备份。）
_DEFAULT_ENABLED = True

# ★★ 2026-09-29：环境变量启用方式此前只写在 docstring 里、代码并未实现（#6）。
#    现补齐。每进程直接读（os.environ.get 是纳秒级 dict 查找，不构成开销）。
_ENV_NAME = "RTMP_DEBUG_LOG"
_ENV_TRUE = ("1", "true", "yes", "on")


def _env_is_set():
    """环境变量 `RTMP_DEBUG_LOG` 是否**被设过**。

    ⚠️ 必须区分"没设"和"设成假值"：默认开启之后，
    `RTMP_DEBUG_LOG=0` 是**显式要求关闭**（测试与批处理脚本要用），
    不能跟"没设 → 吃默认（开）"混为一谈。
    """
    try:
        return _ENV_NAME in os.environ
    except Exception:
        return False


def _env_requested():
    """环境变量 `RTMP_DEBUG_LOG` 是否为真值（1 / true / yes / on，大小写无关）。"""
    try:
        v = os.environ.get(_ENV_NAME, "")
    except Exception:
        return False
    return str(v).strip().lower() in _ENV_TRUE


def default_path():
    """默认日志路径：`<用户配置目录>/rtmp_debug/rtmp-YYYYMMDD.jsonl`。

    取不到 bpy 时退回系统临时目录（测试/独立脚本用）。
    """
    day = time.strftime("%Y%m%d")
    base = None
    if bpy is not None:
        for kind in ("CONFIG", "SCRIPTS", "TEMP"):
            try:
                base = bpy.utils.user_resource(kind)
                if base:
                    break
            except Exception:
                continue
    if not base:
        import tempfile
        base = tempfile.gettempdir()
    return os.path.join(base, "rtmp_debug", "rtmp-%s.jsonl" % day)


def apply_prefs_default(on):
    """注册时用**偏好设置里的值**覆盖「默认」。

    ⚠️ 刻意**不设 `_explicit`** —— 它不是"用户当场显式设定"，而是"这个用户平时要什么"。
    这样环境变量仍能强制覆盖（测试/批处理要这个能力）。

    为什么必须做这件事：`update=_sync_debug_log` 回调**只在值变化时**触发。
    若启动时偏好里就是 False（用户关过），从来没有"变化"发生 ⇒ 模块侧 `_explicit`
    仍是 False ⇒ 模块按自己的默认（开）走 ⇒ **UI 显示没勾、日志却在记**
    （说到做不到，最坏的一类不一致）。
    """
    global _DEFAULT_ENABLED
    _DEFAULT_ENABLED = bool(on)
    return _DEFAULT_ENABLED


def set_enabled(on, path=None):
    """开关调试日志（可同时指定路径）。返回当前是否启用。

    ★ 显式调用后会**压倒**环境变量 `RTMP_DEBUG_LOG`（便于测试与用户强制关闭）。
    """
    global _enabled, _explicit, _path, _rotated
    with _lock:
        _enabled = bool(on)
        _explicit = True
        if path:
            _path = path
        elif _enabled and not _path:
            _path = default_path()
        _rotated = False
    return _enabled


def is_enabled():
    """当前是否启用。

    优先级（三条，逐级回退）：
      1. **显式设定** —— UI 开关 / `set_enabled()` 调过，就按它（用户说了算）
      2. **环境变量** —— `RTMP_DEBUG_LOG` 只要设过就按它（真→开，假→关）
      3. **默认** —— `_DEFAULT_ENABLED`（当前为开）
    """
    if _explicit:
        return _enabled
    if not _env_is_set():
        return _DEFAULT_ENABLED
    return _env_requested()


def log_path():
    """当前日志文件路径（未启用时返回默认路径，便于 UI 展示）。"""
    return _path or default_path()


def _rotate_if_needed():
    """超过 MAX_BYTES 就轮转一次（保留 .1 备份），避免无限增长。"""
    global _rotated
    if _rotated:
        return
    try:
        if _path and os.path.exists(_path) and os.path.getsize(_path) > MAX_BYTES:
            bak = _path + ".1"
            try:
                if os.path.exists(bak):
                    os.remove(bak)
                os.replace(_path, bak)
            except Exception:
                pass
            _rotated = True
    except Exception:
        pass


def dbg(event, **data):
    """写一条结构化调试记录（未启用时是空操作）。

    event : 事件名（建议用 `域.动作`，如 `drag.begin` / `uniform.clamp`）
    data  : 任意可 JSON 序列化的键值（不可序列化的会被 repr 成字符串）
    """
    if not is_enabled():
        return
    try:
        rec = {"t": round(time.time(), 4), "ev": str(event)}
        for k, v in data.items():
            try:
                json.dumps(v)                       # 先探一次
                rec[k] = v
            except Exception:
                rec[k] = repr(v)
        line = json.dumps(rec, ensure_ascii=False)
        with _lock:
            _rotate_if_needed()
            if not _path:
                globals()["_path"] = default_path()
            d = os.path.dirname(_path)
            if d and not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            with open(_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        # 日志失败绝不能影响插件功能
        pass


def read_tail(n=200):
    """读最近 n 条记录（解析失败的原始行以 `{"raw": ...}` 返回）。"""
    p = log_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()[-n:]
    except Exception:
        return []
    out = []
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        try:
            out.append(json.loads(ln))
        except Exception:
            out.append({"raw": ln})
    return out


def clear():
    """清空日志文件（保留文件本身）。"""
    p = log_path()
    try:
        if os.path.exists(p):
            os.remove(p)
        return True
    except Exception:
        return False
