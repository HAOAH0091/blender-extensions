# -*- coding: utf-8 -*-
"""探针：overlay._norm_selected 对 set 输入的真实行为。

背景（2026-09-29 review）：该函数签名 `isinstance(selected, (list, set, tuple))`
声明接受 set，但紧接着 `first = selected[0]` —— set 不支持下标 ⇒ 必抛 TypeError。
当前所有调用点都传 list，所以这颗雷从没被踩到。

本探针走真实入口（直接 import overlay 调函数），验证：
  ① set of (frame, tri)   → 现在应抛 TypeError（bug 实证）
  ② list of (frame, tri)  → 正常（对照组，确认探针本身有效）
  ③ 单个 (frame, tri)      → 正常（对照组）

用法：
  blender --background --factory-startup --python tests/_norm_selected_probe.py
  （需先把插件目录加入 sys.path；见下方 BOOTSTRAP）
"""
import os
import sys
import json

# overlay.py 用相对导入（from . import handles），必须按包导入：
# 把插件【父目录】加进 sys.path，再 import RealTimeMotionPath.overlay
PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../RealTimeMotionPath
PKG_PARENT = os.path.dirname(PLUGIN_DIR)                                   # .../addons
PKG_NAME = os.path.basename(PLUGIN_DIR)                                    # RealTimeMotionPath
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)

steps = []


def step(name, ok, detail=""):
    steps.append({"name": name, "ok": bool(ok), "detail": str(detail)})


import importlib
overlay = importlib.import_module(PKG_NAME + ".overlay")
fn = overlay._norm_selected

# ---- ② 对照组：list of (frame, tri) ----
try:
    r = fn([(14.0, "left"), (20.0, "right")])
    step("对照 list 多选 → {(14.0,'left'),(20.0,'right')}",
         r == {(14.0, "left"), (20.0, "right")}, repr(r))
except Exception as e:
    step("对照 list 多选", False, "%s: %s" % (type(e).__name__, e))

# ---- ③ 对照组：单个 (frame, tri) ----
try:
    r = fn((14.0, "left"))
    step("对照 单个 (frame,tri) → {(14.0,'left')}", r == {(14.0, "left")}, repr(r))
except Exception as e:
    step("对照 单个 (frame,tri)", False, "%s: %s" % (type(e).__name__, e))

# ---- ① 目标：set of (frame, tri) ----
try:
    r = fn({(14.0, "left"), (20.0, "right")})
    step("★ set 多选 → {(14.0,'left'),(20.0,'right')}",
         r == {(14.0, "left"), (20.0, "right")}, repr(r))
except Exception as e:
    step("★ set 多选", False, "%s: %s" % (type(e).__name__, e))

# ---- ④ 空 set ----
try:
    r = fn(set())
    step("空 set → set()", r == set(), repr(r))
except Exception as e:
    step("空 set", False, "%s: %s" % (type(e).__name__, e))

# ---- ⑤ None ----
try:
    r = fn(None)
    step("None → set()", r == set(), repr(r))
except Exception as e:
    step("None", False, "%s: %s" % (type(e).__name__, e))

fails = [s for s in steps if not s["ok"]]
print("\n" + "=" * 72)
print("_norm_selected 探针")
print("=" * 72)
for s in steps:
    print("  [%s] %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                           ("   ← " + s["detail"]) if s["detail"] and not s["ok"] else ""))
print("-" * 72)
print("断言 %d / 失败 %d" % (len(steps), len(fails)))

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_norm_selected_result.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump({"steps": steps, "fails": len(fails), "total": len(steps)}, f,
              ensure_ascii=False, indent=2)
print("结果 → %s" % out)
sys.stdout.flush()          # os._exit 不 flush，必须先手动刷
sys.stderr.flush()
os._exit(1 if fails else 0)
