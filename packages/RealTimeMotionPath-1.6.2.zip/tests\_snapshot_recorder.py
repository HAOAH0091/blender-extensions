# -*- coding: utf-8 -*-
"""状态快照录像机 —— 重构/改动前后的"逐位比对"基准。

用途（为什么需要它）
--------------------
本项目的架构债（546 行 modal、39 个无主状态字段）一直没还，根本原因是
**改完无法证明"没坏"**：一键回归只覆盖 14 条断言，交互层完全没网。

本脚本把"用户操作"录成可复现的事件序列，每走一步就把
【modal 的返回值 + `_session` 的全部字段】dump 成 JSON。
改动前后各跑一次、逐位 diff —— 差异为空才算"功能没变"。

    # 录基线（改动前）
    blender --background --factory-startup --python tests\\_snapshot_recorder.py

    # 改动后
    blender --background --factory-startup --python tests\\_snapshot_recorder.py -- --tag after

    # 比对
    python tests\\_snapshot_diff.py baseline after      # （diff 工具另见）

确定性（关键设计）
------------------
交互层里有三处"按真实时间"的分支：速度拖拽节流、普通拖拽节流、双击判定窗口。
它们会让"同一序列在不同时刻跑出不同结果"，那样比对就毫无意义。
⇒ 这里把 `interaction.time` 换成**受控假时钟**，时间只在"我们让它走"时前进：

    · 每个事件之前 advance(1.0s) —— 大于任何节流窗口 ⇒ 节流永不生效
      （保证每次 MOUSEMOVE 都被完整处理，行为最"满"）
    · 双击场景里 advance(0.1s) —— 落在双击窗口内 ⇒ 双击成立

于是整份快照**完全确定**：同样的输入，永远得到同样的输出。

只读声明
--------
本脚本不改动任何产品代码、不保存 .blend、不写项目目录以外的文件。
输出落在 `tests/_snapshot_<tag>.json`（已被 .gitignore 的 `/tests/_*.json` 覆盖）。
"""
import bpy
import json
import mathutils
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 输出名：`-- --tag after` 可指定（默认 baseline）
_argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
TAG = "baseline"
if "--tag" in _argv:
    TAG = _argv[_argv.index("--tag") + 1]
OUT = os.path.join(HERE, "_snapshot_%s.json" % TAG)

# 这些字段不进快照：
#   · render_callback_id 是 C 侧资源句柄（不可序列化，且不是"会话状态"）
#   · 时间戳类字段随真实时钟漂移，不是行为
_SKIP_FIELDS = {"render_callback_id"}
_CLOCK_FIELDS = {"t"}          # speed_click_info 里的时间戳


# ---------------------------------------------------------------------------
# 确定性假时钟
# ---------------------------------------------------------------------------

class FakeClock:
    """受控时钟：只有显式 advance() 才前进。

    `interaction.py` 里 `import time` 之后用的 `time.time()` /
    `time.monotonic()` 全部落到这里。
    """

    def __init__(self, t0=1000.0):
        self.t = float(t0)

    def advance(self, dt):
        self.t += float(dt)

    def time(self):
        return self.t

    def monotonic(self):
        return self.t

    def perf_counter(self):
        return self.t

    def strftime(self, *a, **k):
        return "19700101"

    def sleep(self, *a, **k):
        return None


_CLOCK = FakeClock()


# ---------------------------------------------------------------------------
# JSON 化（保证确定性：set 排序、浮点定长、深度上限）
# ---------------------------------------------------------------------------

def jsonable(v, depth=0):
    if depth > 6:
        return "<deep>"
    if v is None or isinstance(v, (bool, int, str)):
        return v
    if isinstance(v, float):
        return round(v, 9)
    if isinstance(v, dict):
        items = sorted(v.items(), key=lambda kv: str(kv[0]))
        return {str(k): jsonable(x, depth + 1) for k, x in items}
    if isinstance(v, (list, tuple)):
        return [jsonable(x, depth + 1) for x in v]
    if isinstance(v, (set, frozenset)):
        return sorted((jsonable(x, depth + 1) for x in v), key=repr)
    if isinstance(v, mathutils.Vector):
        return [round(float(x), 9) for x in v]
    if isinstance(v, mathutils.Matrix):
        return [[round(float(x), 9) for x in row] for row in v]
    try:                                   # 其它可迭代（Vector 子类等）
        return [jsonable(x, depth + 1) for x in v]
    except Exception:
        return "<%s>" % type(v).__name__


def dump_session(session):
    """快照 `_session` 的全部字段。"""
    out = {}
    for k, v in sorted(vars(session).items()):
        if k in _SKIP_FIELDS:
            out[k] = "<skipped>"
            continue
        out[k] = jsonable(v)
    return out


# ---------------------------------------------------------------------------
# 场景搭建（复刻 tests/gui_real_path_check.py 的台子）
# ---------------------------------------------------------------------------

sc = bpy.context.scene
sc.frame_start, sc.frame_end = 1, 40
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
obj = bpy.context.view_layer.objects.active
obj.name = "TestObj"
KFS = [(1, (0.0, 0.0, 0.0)), (14, (4.0, 0.0, 0.0)),
       (27, (8.0, 0.0, 0.0)), (40, (12.0, 0.0, 0.0))]
for f, loc in KFS:
    sc.frame_set(f)
    obj.location = loc
    obj.keyframe_insert("location", frame=f)
act = obj.animation_data.action

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")

import RealTimeMotionPath as RTMP
from RealTimeMotionPath import interaction as inter
from RealTimeMotionPath import transform_domain as xf
from RealTimeMotionPath import handles as hd
from RealTimeMotionPath import modal_edit as me
from RealTimeMotionPath import drawing as dw
from RealTimeMotionPath import cache as rcache
from RealTimeMotionPath import overlay as ovmod
from RealTimeMotionPath.state import _session

# ★★ 换掉时间源 —— 必须在任何事件之前
inter.time = _CLOCK

# 匀速基线 + 全 FREE（让手柄有确定长度、三角有确定 s）
for fc in xf._position_curves(act, obj, None):
    for kp in fc.keyframe_points:
        kp.handle_left_type = 'FREE'
        kp.handle_right_type = 'FREE'
    pts = list(fc.keyframe_points)
    for i in range(len(pts) - 1):
        k0, k1 = pts[i], pts[i + 1]
        t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
        k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
        k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
    fc.update()

wm = bpy.context.window_manager
wm.rtmp_path_display_enabled = True
wm.rtmp_edit_mode_active = True
win = wm.windows[0]
area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
region = next(r for r in area.regions if r.type == 'WINDOW')
rv3d = area.spaces.active.region_3d
rv3d.view_location = mathutils.Vector((6, 0, 0))
rv3d.view_distance = 20.0
rv3d.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
bpy.context.view_layer.update()


class FakeEvent:
    """鸭子类型事件。

    ⚠️ 全局坐标（mouse_x/y，`find_region_under_mouse` 用）与
       region 局部坐标（mouse_region_x/y，拖拽增量用）**必须能分别指定** ——
       两者混用正是历史上"拖三角打满卡死"的根因，录制台要能如实复现。
    """

    def __init__(self, t, v='PRESS', mx=0.0, my=0.0, rx=None, ry=None,
                 shift=False, ctrl=False, alt=False):
        self.type = t
        self.value = v
        self.mouse_x = mx
        self.mouse_y = my
        self.mouse_region_x = mx if rx is None else rx
        self.mouse_region_y = my if ry is None else ry
        self.shift = shift
        self.ctrl = ctrl
        self.alt = alt


class FakeOp:
    """operator 替身：只带真实存在的实例属性 + report()。

    ★★★ 关键设计：**方法从真实 operator 类自动挂载**，不手抄一份。

    为什么（本轮实测踩到，值得写下来）：
      · `tests/gui_real_path_check.py` 的替身缺 `report()` ⇒ ④ 一直崩
      · 本录制台第一版缺 `locate_handle_under_cursor()` ⇒
        **"点关键帧"与"点手柄"两条主路径从来没跑通过**（静默退化成 EXC）
      ⇒ 手抄的替身一定会随产品代码漂移，而且**漂移是静默的**。
        直接借用真实类的方法，modal 里新增任何 `self.xxx` 调用都不会再让夹具失效。
    """

    def __init__(self):
        # 与真实类 `RTMP_OT_PathPointDrag.__init__` 的字段保持一致
        self._timer = None
        self._mouse_pos = None
        self._is_active = True
        self._redraw_count = 0
        self._last_frame = None
        self._last_draw_time = 0.0
        self._last_speed_draw_time = 0.0

    def report(self, *a, **k):
        pass


# 把真实 operator 类的全部方法挂到替身上（跳过 dunder；已定义的 report 不覆盖）
_mounted = []
for _name in dir(inter.RTMP_OT_PathPointDrag):
    if _name.startswith("__"):
        continue
    try:
        _attr = getattr(inter.RTMP_OT_PathPointDrag, _name)
    except Exception:
        continue
    if callable(_attr) and not hasattr(FakeOp, _name):
        setattr(FakeOp, _name, _attr)
        _mounted.append(_name)


class FakeCtx:
    pass


ctx = FakeCtx()
ctx.window = win
ctx.window_manager = wm
ctx.area = area
ctx.region = region
ctx.region_data = rv3d
ctx.screen = win.screen
ctx.active_object = obj
ctx.scene = sc
ctx.mode = 'OBJECT'
# ⚠️ 关键帧 / 采样点的命中走 `cached_positions` 与 `path_point_sequence`，
#    而这两份缓存的唯一生产者是 `cache.refresh_position_store()`。
#    真实使用中它由自动刷新守护进程负责；录制台必须自己建一次，
#    否则「点关键帧」「点手柄」会静默地什么都命中不了（全是 PASS_THROUGH）。
ctx.selected_objects = [obj]
ctx.selected_pose_bones = None
ctx.active_pose_bone = None

# 覆盖层（invoke 会做的事）
over = ovmod.get_overlay()
over.stop()
over.start(session=None)
_session.clear_speed_handle()

# 先跑一次绘制 —— 填 `handle_control_points`（端点拾取依赖它）。
# 拿不到 GPU 时跳过：本录制不依赖绘制结果，只依赖"绘制跑过"这件事。
_GPU_OK = False
try:
    import gpu
    gpu.init()
    _GPU_OK = True
except Exception:
    _GPU_OK = False

DRAW_RAN = False
if _GPU_OK:
    try:
        with bpy.context.temp_override(window=win, area=area, region=region,
                                       screen=win.screen):
            dw.render_path_overlay()
        DRAW_RAN = True
    except Exception:
        DRAW_RAN = False


# ---------------------------------------------------------------------------
# 位置：三角 / 关键帧 / 手柄端点
# ---------------------------------------------------------------------------

def tri_pos(frame, tri):
    """三角的 (全局 x, 全局 y)。"""
    recs = me.collect_speed_handles(act, obj, region, rv3d)
    hit = [r for r in recs if r['frame'] == float(frame) and r['tri'] == tri]
    if not hit:
        return None
    lx, ly = hit[0]['tri_screen']
    return (region.x + lx, region.y + ly)


def kf_pos(frame):
    """关键帧点的 (全局 x, 全局 y)。"""
    scr = me.keyframe_screens(act, obj, region, rv3d)
    got = scr.get(float(frame))
    if got is None:
        return None
    return (region.x + got[0], region.y + got[1])


def handle_pos(frame, side):
    """手柄端点的 (全局 x, 全局 y)。"""
    from bpy_extras import view3d_utils
    w = me.handle_endpoint_world_pos(act, obj, float(frame), side, None)
    if w is None:
        return None
    p = view3d_utils.location_3d_to_region_2d(region, rv3d, w)
    if p is None:
        return None
    return (region.x + p[0], region.y + p[1])


# ---------------------------------------------------------------------------
# 录制
# ---------------------------------------------------------------------------

Modal = inter.RTMP_OT_PathPointDrag.modal
op = FakeOp()
SCENARIOS = {}
_seq = [0]


def reset_world():
    """把场景恢复到"匀速基线 + 全 FREE + 无选中"，供每个场景从同一起点开跑。"""
    for fc in xf._position_curves(act, obj, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
            kp.select_control_point = False
        pts = list(fc.keyframe_points)
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()
    _session.clear_speed_handle()
    _session.clear_endpoints()
    _session.reset()
    _session.handle_control_points = []
    op.__init__()                      # 重置 operator 实例（含节流时钟）
    inter.clear_speed_click_chain()
    _CLOCK.t = 1000.0
    # ★ 重建位置缓存（关键帧/采样点命中的前提；真实使用中由守护进程负责）
    try:
        rcache.refresh_position_store(bpy.context)
    except Exception as exc:
        print("refresh_position_store failed:", repr(exc))
    if DRAW_RAN:
        try:
            with bpy.context.temp_override(window=win, area=area, region=region,
                                           screen=win.screen):
                dw.render_path_overlay()
        except Exception:
            pass


def norm_ret(r):
    """规范化 operator 返回值。

    ⚠️ Blender 的 modal 返回的是 **set**（如 `{'RUNNING_MODAL'}`）——
       而 set 的迭代顺序由哈希决定，**跨进程不保证一致**。
       直接 dump 会让快照无法逐位比对（同一个返回值序列化成不同字符串）。
       ⇒ 排序成列表。
    """
    if isinstance(r, (set, frozenset)):
        return sorted(str(x) for x in r)
    return str(r)


def rec(scenario, label, event_desc, ret, extra=None):
    """记一步：modal 返回值 + 全量 session 状态 + F-Curve 关键数值。"""
    _seq[0] += 1
    step = {
        "i": _seq[0],
        "event": event_desc,
        "returned": norm_ret(ret),
        "state": dump_session(_session),
    }
    # 曲线侧的独立读数（快照不能只看内存，还要看数据真被写成什么）
    curves = {}
    for fc in xf._position_curves(act, obj, None):
        vals = []
        for kp in fc.keyframe_points:
            vals.append([round(float(kp.co[0]), 6), round(float(kp.co[1]), 9),
                         round(float(kp.handle_left[0]), 6), round(float(kp.handle_left[1]), 9),
                         round(float(kp.handle_right[0]), 6), round(float(kp.handle_right[1]), 9),
                         str(kp.handle_left_type), str(kp.handle_right_type)])
        curves["idx%d" % fc.array_index] = vals
    step["curves"] = curves
    if extra:
        step["extra"] = jsonable(extra)
    SCENARIOS.setdefault(scenario, []).append(step)
    return ret


def fire(scenario, ev, desc, dt=1.0):
    """发一个事件（先推进假时钟，保证节流分支确定）。

    `ev` 是 make_ev() 产出的 8 元组：(type, value, mx, my, rx, ry, shift, ctrl)
    """
    _CLOCK.advance(dt)
    t, v, mx, my, rx, ry, sh, ct = ev
    e = FakeEvent(t, v, mx, my, rx, ry, sh, ct)
    try:
        r = Modal(op, ctx, e)
    except Exception as exc:
        r = "EXC:%s:%s" % (type(exc).__name__, exc)
    return rec(scenario, desc, "%s %s @(%s,%s)" % (t, v, mx, my), r)


def local(p):
    """全局鼠标坐标 -> region 局部（FakeEvent 的 mouse_region_*）。"""
    return (p[0] - region.x, p[1] - region.y)


def make_ev(type_, value, pos, local_pos=None, **kw):
    lp = local_pos if local_pos is not None else local(pos)
    return (type_, value, pos[0], pos[1], lp[0], lp[1],
            kw.get('shift', False), kw.get('ctrl', False))


# ---------------- S1 三角：按下 → 拖两次 → 松手 ----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_DOWN)
    fire("S1_tri_drag_down", make_ev('LEFTMOUSE', 'PRESS', P), "三角按下")
    fire("S1_tri_drag_down", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 60)), "下拖 60px")
    fire("S1_tri_drag_down", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 100)), "再下拖 40px")
    fire("S1_tri_drag_down", make_ev('LEFTMOUSE', 'RELEASE', (P[0], P[1] - 100)), "松手")
except Exception as exc:
    SCENARIOS.setdefault("S1_tri_drag_down", []).append({"FATAL": repr(exc)})

# ---------------- S2 三角：单击选中 → 点空白取消 ----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_UP)
    fire("S2_tri_select_then_blank", make_ev('LEFTMOUSE', 'PRESS', P), "三角按下")
    fire("S2_tri_select_then_blank", make_ev('LEFTMOUSE', 'RELEASE', P), "松手")
    BLANK = (region.x + 20, region.y + 20)
    fire("S2_tri_select_then_blank", make_ev('LEFTMOUSE', 'PRESS', BLANK), "点空白")
    fire("S2_tri_select_then_blank", make_ev('LEFTMOUSE', 'RELEASE', BLANK), "松手")
except Exception as exc:
    SCENARIOS.setdefault("S2_tri_select_then_blank", []).append({"FATAL": repr(exc)})

# ---------------- S3 三角：双击（一体 ↔ 分离） ----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_UP)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'PRESS', P), "第 1 次按下", dt=1.0)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'RELEASE', P), "第 1 次松手", dt=0.1)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'PRESS', P), "第 2 次按下（双击）", dt=0.1)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'RELEASE', P), "第 2 次松手", dt=0.1)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'PRESS', P), "第 3 次按下", dt=1.0)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'RELEASE', P), "第 3 次松手", dt=0.1)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'PRESS', P), "第 4 次按下（再双击）", dt=0.1)
    fire("S3_tri_double_click", make_ev('LEFTMOUSE', 'RELEASE', P), "第 4 次松手", dt=0.1)
except Exception as exc:
    SCENARIOS.setdefault("S3_tri_double_click", []).append({"FATAL": repr(exc)})

# ---------------- S4 关键帧：按下 → 拖 → 松手 ----------------
try:
    reset_world()
    K = kf_pos(14)
    if K is None:
        SCENARIOS.setdefault("S4_kf_drag", []).append({"SKIP": "no keyframe screen pos"})
    else:
        fire("S4_kf_drag", make_ev('LEFTMOUSE', 'PRESS', K), "关键帧按下")
        fire("S4_kf_drag", make_ev('MOUSEMOVE', 'NOTHING', (K[0] + 40, K[1] + 30)), "拖动")
        fire("S4_kf_drag", make_ev('MOUSEMOVE', 'NOTHING', (K[0] + 80, K[1] + 60)), "继续拖")
        fire("S4_kf_drag", make_ev('LEFTMOUSE', 'RELEASE', (K[0] + 80, K[1] + 60)), "松手")
except Exception as exc:
    SCENARIOS.setdefault("S4_kf_drag", []).append({"FATAL": repr(exc)})

# ---------------- S5 手柄端点：按下 → 拖 → 松手 ----------------
try:
    reset_world()
    K = kf_pos(14)
    H = handle_pos(14, 'right')
    if K is None or H is None:
        SCENARIOS.setdefault("S5_handle_drag", []).append(
            {"SKIP": "kf=%s handle=%s" % (K, H)})
    else:
        fire("S5_handle_drag", make_ev('LEFTMOUSE', 'PRESS', H), "手柄端点按下")
        fire("S5_handle_drag", make_ev('MOUSEMOVE', 'NOTHING', (H[0] + 50, H[1] - 40)), "拖动")
        fire("S5_handle_drag", make_ev('MOUSEMOVE', 'NOTHING', (H[0] + 90, H[1] - 70)), "继续拖")
        fire("S5_handle_drag", make_ev('LEFTMOUSE', 'RELEASE', (H[0] + 90, H[1] - 70)), "松手")
except Exception as exc:
    SCENARIOS.setdefault("S5_handle_drag", []).append({"FATAL": repr(exc)})

# ---------------- S6 悬停：扫过三角 ----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_DOWN)
    for i, dy in enumerate((0, -10, -20, 10)):
        fire("S6_hover_sweep", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] + dy)),
             "悬停 #%d" % i)
except Exception as exc:
    SCENARIOS.setdefault("S6_hover_sweep", []).append({"FATAL": repr(exc)})

# ---------------- S7 连续两次拖动（测基准是否漂移） ----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_DOWN)
    for n in range(2):
        fire("S7_drag_twice", make_ev('LEFTMOUSE', 'PRESS', P), "第%d次按下" % (n + 1))
        fire("S7_drag_twice", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 30)), "第%d次拖" % (n + 1))
        fire("S7_drag_twice", make_ev('LEFTMOUSE', 'RELEASE', (P[0], P[1] - 30)), "第%d次松手" % (n + 1))
except Exception as exc:
    SCENARIOS.setdefault("S7_drag_twice", []).append({"FATAL": repr(exc)})

# ===========================================================================
# 以下 S8~S19：为「546 行 modal 拆分」准备的分支覆盖
#   （前 7 个场景只够保护小改；拆结构时必须让**每条分支**都有快照盯着）
# ===========================================================================

# ---------------- S8 Shift 多选两个三角 ----------------
try:
    reset_world()
    P1 = tri_pos(14, hd.TRI_UP)
    P2 = tri_pos(27, hd.TRI_DOWN)
    fire("S8_shift_multiselect", make_ev('LEFTMOUSE', 'PRESS', P1), "点第 1 个三角")
    fire("S8_shift_multiselect", make_ev('LEFTMOUSE', 'RELEASE', P1), "松手")
    fire("S8_shift_multiselect", make_ev('LEFTMOUSE', 'PRESS', P2, shift=True), "Shift 点第 2 个")
    fire("S8_shift_multiselect", make_ev('LEFTMOUSE', 'RELEASE', P2, shift=True), "松手")
except Exception as exc:
    SCENARIOS.setdefault("S8_shift_multiselect", []).append({"FATAL": repr(exc)})

# ---------------- S9 Ctrl 区间选择关键帧 ----------------
try:
    reset_world()
    K1 = kf_pos(1)
    K3 = kf_pos(27)
    if K1 and K3:
        fire("S9_ctrl_range_select", make_ev('LEFTMOUSE', 'PRESS', K1), "点首帧")
        fire("S9_ctrl_range_select", make_ev('LEFTMOUSE', 'RELEASE', K1), "松手")
        fire("S9_ctrl_range_select", make_ev('LEFTMOUSE', 'PRESS', K3, ctrl=True),
             "Ctrl 点末帧（区间选择）")
        fire("S9_ctrl_range_select", make_ev('LEFTMOUSE', 'RELEASE', K3, ctrl=True), "松手")
    else:
        SCENARIOS.setdefault("S9_ctrl_range_select", []).append({"SKIP": "no kf pos"})
except Exception as exc:
    SCENARIOS.setdefault("S9_ctrl_range_select", []).append({"FATAL": repr(exc)})

# ---------------- S10 Shift 精度模式拖三角（eff 减半）----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_DOWN)
    fire("S10_shift_precision_drag", make_ev('LEFTMOUSE', 'PRESS', P), "三角按下")
    fire("S10_shift_precision_drag", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 60), shift=True),
         "Shift 下拖 60px（精度 ×0.1）")
    fire("S10_shift_precision_drag", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 120), shift=True),
         "继续拖（仍精度）")
    fire("S10_shift_precision_drag", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 180)),
         "松开 Shift 再拖（恢复 ×1.0）")
    fire("S10_shift_precision_drag", make_ev('LEFTMOUSE', 'RELEASE', (P[0], P[1] - 180)), "松手")
except Exception as exc:
    SCENARIOS.setdefault("S10_shift_precision_drag", []).append({"FATAL": repr(exc)})

# ---------------- S11 BACK_SPACE：悬停三角上按退格恢复默认 ----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_DOWN)
    fire("S11_backspace_reset", make_ev('LEFTMOUSE', 'PRESS', P), "三角按下")
    fire("S11_backspace_reset", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 60)), "拖 60px")
    fire("S11_backspace_reset", make_ev('LEFTMOUSE', 'RELEASE', (P[0], P[1] - 60)), "松手")
    fire("S11_backspace_reset", make_ev('MOUSEMOVE', 'NOTHING', P), "悬停回三角上")
    fire("S11_backspace_reset", make_ev('BACK_SPACE', 'PRESS', P), "按退格（恢复默认速度）")
except Exception as exc:
    SCENARIOS.setdefault("S11_backspace_reset", []).append({"FATAL": repr(exc)})

# ---------------- S12 拖【手柄线】而不是端点 ----------------
try:
    reset_world()
    K = kf_pos(14)
    H = handle_pos(14, 'right')
    if K and H:
        mid = ((K[0] + H[0]) / 2.0, (K[1] + H[1]) / 2.0)     # 手柄线的中点
        fire("S12_handle_line_drag", make_ev('LEFTMOUSE', 'PRESS', mid), "按在手柄线中点上")
        fire("S12_handle_line_drag", make_ev('MOUSEMOVE', 'NOTHING', (mid[0], mid[1] - 50)), "拖动")
        fire("S12_handle_line_drag", make_ev('MOUSEMOVE', 'NOTHING', (mid[0], mid[1] - 90)), "继续拖")
        fire("S12_handle_line_drag", make_ev('LEFTMOUSE', 'RELEASE', (mid[0], mid[1] - 90)), "松手")
    else:
        SCENARIOS.setdefault("S12_handle_line_drag", []).append({"SKIP": "no pos"})
except Exception as exc:
    SCENARIOS.setdefault("S12_handle_line_drag", []).append({"FATAL": repr(exc)})

# ---------------- S13 RIGHTMOUSE PRESS ----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_UP)
    fire("S13_rightmouse", make_ev('LEFTMOUSE', 'PRESS', P), "先选中三角")
    fire("S13_rightmouse", make_ev('LEFTMOUSE', 'RELEASE', P), "松手")
    fire("S13_rightmouse", make_ev('RIGHTMOUSE', 'PRESS', P), "右键按下")
    fire("S13_rightmouse", make_ev('RIGHTMOUSE', 'RELEASE', P), "右键松开")
except Exception as exc:
    SCENARIOS.setdefault("S13_rightmouse", []).append({"FATAL": repr(exc)})

# ---------------- S14 ESC + TIMER ----------------
try:
    reset_world()
    fire("S14_esc_timer", make_ev('TIMER', 'NOTHING', (region.x + 100, region.y + 100)), "TIMER 事件")
    fire("S14_esc_timer", make_ev('ESC', 'PRESS', (region.x + 100, region.y + 100)), "ESC 按下")
    fire("S14_esc_timer", make_ev('TIMER', 'NOTHING', (region.x + 100, region.y + 100)), "TIMER 再来")
except Exception as exc:
    SCENARIOS.setdefault("S14_esc_timer", []).append({"FATAL": repr(exc)})

# ---------------- S15 点空白清除选中 ----------------
try:
    reset_world()
    K = kf_pos(14)
    BLANK = (region.x + 30, region.y + 30)
    if K:
        fire("S15_blank_clear", make_ev('LEFTMOUSE', 'PRESS', K), "点关键帧选中")
        fire("S15_blank_clear", make_ev('LEFTMOUSE', 'RELEASE', K), "松手")
        fire("S15_blank_clear", make_ev('LEFTMOUSE', 'PRESS', BLANK), "点空白")
        fire("S15_blank_clear", make_ev('LEFTMOUSE', 'RELEASE', BLANK), "松手")
    else:
        SCENARIOS.setdefault("S15_blank_clear", []).append({"SKIP": "no kf"})
except Exception as exc:
    SCENARIOS.setdefault("S15_blank_clear", []).append({"FATAL": repr(exc)})

# ---------------- S16 一体锁定时点一个三角（两个都选中）----------------
try:
    reset_world()
    P = tri_pos(14, hd.TRI_DOWN)
    fire("S16_locked_pair_click", make_ev('LEFTMOUSE', 'PRESS', P), "点下三角（默认一体）")
    fire("S16_locked_pair_click", make_ev('LEFTMOUSE', 'RELEASE', P), "松手")
    fire("S16_locked_pair_click", make_ev('MOUSEMOVE', 'NOTHING', (P[0], P[1] - 40)), "再拖（两侧一起）")
    fire("S16_locked_pair_click", make_ev('LEFTMOUSE', 'RELEASE', (P[0], P[1] - 40)), "松手")
except Exception as exc:
    SCENARIOS.setdefault("S16_locked_pair_click", []).append({"FATAL": repr(exc)})

# ---------------- S17 已选中关键帧后再拖（选中态拖动）----------------
try:
    reset_world()
    K = kf_pos(14)
    if K:
        fire("S17_selected_kf_drag", make_ev('LEFTMOUSE', 'PRESS', K), "点关键帧")
        fire("S17_selected_kf_drag", make_ev('LEFTMOUSE', 'RELEASE', K), "松手（保持选中）")
        fire("S17_selected_kf_drag", make_ev('LEFTMOUSE', 'PRESS', K), "再次按下（已选中）")
        fire("S17_selected_kf_drag", make_ev('MOUSEMOVE', 'NOTHING', (K[0] + 30, K[1] + 20)), "拖动")
        fire("S17_selected_kf_drag", make_ev('LEFTMOUSE', 'RELEASE', (K[0] + 30, K[1] + 20)), "松手")
    else:
        SCENARIOS.setdefault("S17_selected_kf_drag", []).append({"SKIP": "no kf"})
except Exception as exc:
    SCENARIOS.setdefault("S17_selected_kf_drag", []).append({"FATAL": repr(exc)})

# ---------------- S18 多选关键帧后拖动（多个一起动）----------------
try:
    reset_world()
    K1 = kf_pos(14)
    K2 = kf_pos(27)
    if K1 and K2:
        fire("S18_multiselect_drag", make_ev('LEFTMOUSE', 'PRESS', K1), "点第 1 个")
        fire("S18_multiselect_drag", make_ev('LEFTMOUSE', 'RELEASE', K1), "松手")
        fire("S18_multiselect_drag", make_ev('LEFTMOUSE', 'PRESS', K2, shift=True), "Shift 点第 2 个")
        fire("S18_multiselect_drag", make_ev('LEFTMOUSE', 'RELEASE', K2, shift=True), "松手")
        fire("S18_multiselect_drag", make_ev('LEFTMOUSE', 'PRESS', K1), "拖第 1 个")
        fire("S18_multiselect_drag", make_ev('MOUSEMOVE', 'NOTHING', (K1[0] + 40, K1[1] - 30)), "拖动")
        fire("S18_multiselect_drag", make_ev('LEFTMOUSE', 'RELEASE', (K1[0] + 40, K1[1] - 30)), "松手")
    else:
        SCENARIOS.setdefault("S18_multiselect_drag", []).append({"SKIP": "no kf"})
except Exception as exc:
    SCENARIOS.setdefault("S18_multiselect_drag", []).append({"FATAL": repr(exc)})

# ---------------- S19 手柄长度为零（空心圆抓取点）----------------
try:
    reset_world()
    # 把 frame=14 两侧手柄的值分量压成 0 ⇒ 视觉零 ⇒ 走"空心圆抓取点"分支
    for fc in xf._position_curves(act, obj, None):
        kp = xf.keyframe_at(fc, 14.0)
        if kp is None:
            continue
        kp.handle_left_type = 'FREE'
        kp.handle_right_type = 'FREE'
        kp.handle_left = (kp.co[0] - 13.0 / 3.0, kp.co[1])
        kp.handle_right = (kp.co[0] + 13.0 / 3.0, kp.co[1])
    for fc in xf._position_curves(act, obj, None):
        fc.update()
    if DRAW_RAN:
        try:
            with bpy.context.temp_override(window=win, area=area, region=region,
                                           screen=win.screen):
                dw.render_path_overlay()
        except Exception:
            pass
    K = kf_pos(14)
    if K:
        # ⚠️⚠️ 必须先**选中关键帧** —— 端点拾取点只在"关键帧被选中"时才会被
        #    登记（`drawing.render_keyframe_control_handles` 的登记条件含
        #    `is_selected_keyframe`）。不先选中 ⇒ `handle_control_points` 里
        #    没有这个端点 ⇒ 点抓取点必然 PASS_THROUGH（第一版就栽在这）。
        fire("S19_endpoint_zero", make_ev('LEFTMOUSE', 'PRESS', K), "先选中关键帧")
        fire("S19_endpoint_zero", make_ev('LEFTMOUSE', 'RELEASE', K), "松手")
        if DRAW_RAN:
            try:
                with bpy.context.temp_override(window=win, area=area, region=region,
                                               screen=win.screen):
                    dw.render_path_overlay()
            except Exception:
                pass
        # 抓取点在关键帧【屏幕水平偏移】处（ENDPOINT_PICK_OFFSET_PX = 32）
        PICK = (K[0] + 32.0, K[1])
        fire("S19_endpoint_zero", make_ev('MOUSEMOVE', 'NOTHING', PICK), "悬停到空心圆抓取点")
        fire("S19_endpoint_zero", make_ev('LEFTMOUSE', 'PRESS', PICK), "按抓取点")
        fire("S19_endpoint_zero", make_ev('MOUSEMOVE', 'NOTHING', (PICK[0] + 40, PICK[1] - 40)), "拖出来")
        fire("S19_endpoint_zero", make_ev('LEFTMOUSE', 'RELEASE', (PICK[0] + 40, PICK[1] - 40)), "松手")
    else:
        SCENARIOS.setdefault("S19_endpoint_zero", []).append({"SKIP": "no kf"})
except Exception as exc:
    SCENARIOS.setdefault("S19_endpoint_zero", []).append({"FATAL": repr(exc)})

# ---------------------------------------------------------------------------
# 落盘
# ---------------------------------------------------------------------------

payload = {
    "tag": TAG,
    "blender": bpy.app.version_string,
    "gpu_ok": _GPU_OK,
    "draw_ran": DRAW_RAN,
    "mounted_methods": sorted(_mounted),
    "scenarios": {k: SCENARIOS[k] for k in sorted(SCENARIOS)},
    "step_count": sum(len(v) for v in SCENARIOS.values()),
}

# ---- 落盘前自检：把"没被 jsonable 收干净"的类型逐个暴露出来 ----
# （别让 json.dump 崩在最后一步 —— 那样整轮录制白跑，还看不出是谁漏的）
_bad = []
for _sname, _steps in payload["scenarios"].items():
    for _st in _steps:
        for _k, _v in _st.items():
            try:
                json.dumps(_v, ensure_ascii=False)
            except TypeError as _e:
                _bad.append("%s/step%s/%s -> %s" % (_sname, _st.get("i"), _k, _e))
# ⚠️ 也写进 payload：`os._exit(0)` 不刷新 stdout 缓冲，只靠 print 会丢
payload["unserializable"] = _bad

with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(payload, fh, ensure_ascii=False, indent=1, sort_keys=True,
              default=lambda o: "<%s>" % type(o).__name__)

# ⚠️ 必须 flush 再 _exit —— os._exit() 跳过所有缓冲刷新，
#    否则这行 print 永远看不到（本项目其它测试的 "XXX_DONE" 标记同病）。
print("SNAPSHOT_WROTE %s steps=%d gpu=%s draw=%s unjsonable=%d"
      % (OUT, payload["step_count"], _GPU_OK, DRAW_RAN, len(_bad)))
if _bad:
    for _b in _bad[:12]:
        print("   " + _b)
sys.stdout.flush()
os._exit(0)
