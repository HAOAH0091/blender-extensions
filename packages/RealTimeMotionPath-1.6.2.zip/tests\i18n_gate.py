# -*- coding: utf-8 -*-
"""i18n 门禁（真·全量版）—— 抓「代码里的中文裸字面量」。

为什么需要它（这是本项目第 5 轮审查的头号发现之一）
--------------------------------------------------
`regression.py:t_i18n` 报"覆盖 116/116、0 漏翻 0 僵尸"，看着满分，**但分母是假的**：
它的采集只认四种形态 ——
    `(name|description)="…"` ／ `bl_(label|description)="…"` ／
    `iface_("…")` ／ 枚举三元组
而 `modal_edit.py` 里**50 处**中文状态栏 / 警告是**普通赋值**：

    self.message = "需要在 3D 视图中使用"

这些字符串**根本不进 `code` 集合** ⇒ 不可能出现在"漏翻"里。
⇒ 2026-09-18 那次修的是"文件列表不全"（4 个 → 13 个），
  这次暴露的是"**字符串形态不全**" —— 同一类问题的第二次发作。

本判据**不依赖任何 pattern**：用 AST 扫全部源码的字符串常量，
凡含 CJK 即违规。这正是项目自己的约定（`translations.py:5`：
"代码里所有界面字符串统一用英文原文，中文靠本表提供"）。

放行规则（三条，都是"不是界面字符串"的情形）
--------------------------------------------
1. **docstring** —— 注释，不是字符串
2. **裸字符串表达式** —— 单独成句的字符串常量（作者的"变量说明"写法），
   等价于注释（如 `cache.py` 的 `FRAME_INT_EPS` 说明块）
3. **`print(...)` 里的字符串** —— 控制台日志，面向开发者

判据的自证（为什么要写这一段）
------------------------------
一个"零容忍"判据如果不先自证不误伤，第二次就会因为误报被注释掉。
本判据做过**反事实检验**：把全部违规字符串替换成 ASCII 后重新扫描，
违规数必须归零。
（第一版替换脚本按行做子串替换，被两类情况骗过：`"移动"` 是
 `"移动路径点（…）"` 的前缀；以及跨行拼接的长字符串。
 改为"按长度降序 + 逐条完整替换"后确认：**判据本身零误报**。）

用法
----
    python tests\\i18n_gate.py            # 列清单；有违规则 exit 1
    python tests\\i18n_gate.py --count    # 只报数量

改完 58 条之后，把 `cjk_violations()` 接进 `regression.py:t_i18n` 即可
（一行：`check("i18n 无中文裸字面量", not cjk_violations(), ...)`）。
"""
import ast
import os
import re
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
CJK = re.compile(r"[\u4e00-\u9fff]")


def _source_files():
    return sorted(f for f in os.listdir(ADDON_DIR)
                  if f.endswith(".py") and f != "translations.py")


def cjk_violations():
    """返回 ["<文件>:<行号> <字符串前 50 字>", ...]，空列表 = 通过。"""
    out = []
    for fname in _source_files():
        path = os.path.join(ADDON_DIR, fname)
        try:
            with open(path, encoding="utf-8") as fh:
                src = fh.read()
            tree = ast.parse(src)
        except Exception:
            continue

        skip = set()
        # ① docstring
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.ClassDef,
                                 ast.FunctionDef, ast.AsyncFunctionDef)):
                body = getattr(node, "body", None)
                if body and isinstance(body[0], ast.Expr) \
                        and isinstance(body[0].value, ast.Constant) \
                        and isinstance(body[0].value.value, str):
                    skip.add(body[0].value.lineno)
        # ② 裸字符串表达式（变量说明，等于注释）
        for node in ast.walk(tree):
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) \
                    and isinstance(node.value.value, str):
                skip.add(node.value.lineno)
        # ③ print(...) 里的字符串（控制台日志）
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "print":
                for a in ast.walk(node):
                    if isinstance(a, ast.Constant) and isinstance(a.value, str):
                        skip.add(a.lineno)

        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str) \
                    and node.lineno not in skip and CJK.search(node.value):
                txt = node.value.replace("\n", " ")[:50]
                out.append("%s:%d %s" % (fname, node.lineno, txt))
    return sorted(out)


def main():
    argv = sys.argv[1:]
    viol = cjk_violations()
    if "--count" in argv:
        print("CJK_VIOLATIONS %d" % len(viol))
        return 1 if viol else 0

    if not viol:
        print("i18n 门禁通过：源码里没有中文裸字面量。")
        return 0

    by_mod = {}
    for v in viol:
        by_mod.setdefault(v.split(":")[0], []).append(v)
    print("=" * 78)
    print("i18n 门禁：发现 %d 处中文裸字面量（应为 0）" % len(viol))
    print("=" * 78)
    for m in sorted(by_mod, key=lambda k: -len(by_mod[k])):
        print("\n---- %s (%d) ----" % (m, len(by_mod[m])))
        for v in by_mod[m]:
            print("  " + v)
    print("")
    print("说明：这些字符串会直接出现在用户眼前（状态栏 / 警告 / 菜单描述），")
    print("      非中文界面下它们仍是中文。修法 = 改英文原文 + 在")
    print("      translations.py 补真翻译（**不要**加 identity 词条刷绿）。")
    return 1


if __name__ == "__main__":
    sys.exit(main())
