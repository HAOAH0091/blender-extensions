# 抓取环改走「三角那条路」—— 修掉抖动 + 选不中/误触

> 你的判断是对的：**"和三角一样"就是正解**。
> 三角 = 每帧现算 + **纯正向投影** + 在 **2D 屏幕层**画；
> 抓取环 = 反投影成世界坐标 + 在 **3D 层**画。把环搬到三角那条路上，两个症状一起消失。

---

## 0. 目标与成功标准

**目标**：抓取环的**位置定义**从"世界坐标（反投影得来）"改成"**屏幕像素坐标（现算）**"，
与三角完全同源。

**成功标准（可量化，全部要实测）**：

| # | 判据 | 现状 | 目标 |
|---|---|---|---|
| S1 | 环心到关键帧的**屏幕偏移** | 实测约 20~45px 飘（往返误差 ~10px） | **恒 = 32px，误差 ≤ 0.5px** |
| S2 | 拖动关键帧时环的**跟随误差** | 会飘（非线性） | 每帧 ≤ 0.5px，且**单调无回跳** |
| S3 | 沿"关键帧→环"逐像素扫描 | 有重叠/死区 | **0 个死区、0 个双命中** |
| S4 | 双视口下点击 | 用错视口的坐标 ⇒ 常常落空 | 在哪个视口点，就用哪个视口的坐标 |
| S5 | 画与拾取同源 | 两套算法 | 两边调**同一个函数**（静态契约） |

---

## 1. 根因（已实测，不是推测）

1. **位置算法不同源**
   - 三角：`overlay._fresh_kf_world`（每帧从 action 现取）→ `location_3d_to_region_2d`（**一次正向投影**）→ 2D 偏移 → 屏幕像素里画。
   - 环：`drawing._world_at_screen_offset` = 正投 → 加 32px → `region_2d_to_location_3d`（**反投影**）→ 世界点 → 当 3D 线画。
   - **实测这趟往返不闭合**：视口正中心往返一趟差 **10 像素**（`(841.11,496.22)` vs `(831.00,493.50)`）。

2. **由此产生两个症状**
   - **抖动**：拖关键帧时 `point_3d` 每帧在变 → 往返误差跟着变 → 环的世界坐标相对"纯 2D 的 32px"游走。
   - **选不中/误触**：实际屏幕偏移 ≠ 32px ⇒ 关键帧盘(20) 与环盘(12) 要么**重叠**（误触）要么**留死区**（选不中），且随视角/距离变 ⇒ "很多时候"。

3. **附带发现（同一根因）**：`handle_control_points` 里的 `position` 是**世界坐标**，
   而环的世界坐标是**用某个视口的屏幕偏移反推出来的** ⇒ **多视口时，另一个视口里环的位置是错的**
   （你的会话里就有 2 个 3D 视口）。

---

## 2. 设计：唯一真相 = 屏幕坐标

新增一个**唯一的**屏幕坐标函数，画和拾取都调它：

```python
# overlay.py（或 drawing.py，看谁更合适；计划取 overlay —— 三角的邻居）
def endpoint_ring_screen_pos(rec, region, rv3d):
    """抓取环在屏幕上的圆心（像素）。返回 None 表示算不出来。

    ★ 唯一真相：绘制与拾取都必须调它（与 `handle_is_zero_length` 同一条规矩）。
    """
    wp = _fresh_kf_world(rec)                      # 每帧现取，和三角一模一样
    if wp is None:
        return None
    s = view3d_utils.location_3d_to_region_2d(region, rv3d, wp)
    if s is None:
        return None
    off = float(rec.get('off_px') or 0.0)          # 左 −32 / 右 +32
    return (s[0] + off, s[1])
```

- **绘制**：`overlay._draw_2d` 里用 `POST_PIXEL` 直接画圆（像素坐标，无投影）。
- **拾取**：`get_handle_at_cursor` 里用**鼠标所在视口**的 region 现算同一个点。

---

## 3. 改动清单（按子系统）

### 3.1 `drawing.py`
- **`render_keyframe_marker` 空心态分支（~786-805）**：
  - 删掉 `pick_pos = _world_at_screen_offset(...)` 与 `ring = _ring_world_points(...)` + `collector.add_line(...)`。
  - 改成登记**身份 + 像素偏移**，不带世界坐标：
    `{'hollow': True, 'frame':…, 'side':…, 'bone_name':…, 'obj_name':…, 'off_px': _endpoint_offset_px(side)}`
  - `num_added` / 后续"跳过 hollow 不画实心点"的逻辑**保持不变**。
- **删除死代码**：`_world_at_screen_offset`、`_ring_world_points`（改完后全仓无调用者；已确认只有 786/803 两个调用点）。
- **`handle_is_zero_length`**：**保持不动**（它仍是"要不要走空心态"的唯一判据）。

### 3.2 `overlay.py`
- **新增 2D 圆环原语** `draw_circle_2d(cx, cy, radius_px, color, width=2.0)`：
  在 `POST_PIXEL` 下用 `LINE_LOOP` + 单位矩阵 MVP（照 `draw_triangle_2d` 的写法）。
  ⚠️ 段数沿用 `drawing.ENDPOINT_RING_SEGMENTS`(18) 以免视觉变化。
- **`set_handles(...)` 增参 `hollow=None`**（默认 `None` ⇒ 老调用点零改动）：
  存 `self._hollow_records`。
- **`_draw_2d`**：在画三角之后，遍历 `_hollow_records`，
  用 `endpoint_ring_screen_pos(rec, region, rv3d)` 求圆心 → `draw_circle_2d(...)`。
  ⚠️ 颜色沿用 `styles.handle_line_color`（用户当前是纯黑），半径 `ENDPOINT_RING_RADIUS_PX`(6)。
- **`stop()` / `set_handles` 清空**：一并清 `_hollow_records`。

### 3.3 `interaction.py`
- **`get_handle_at_cursor`**：
  - 对 `hollow` 记录：**不再读 `position`**，改用 `endpoint_ring_screen_pos(rec, region, rv3d)` 现算（region = 鼠标所在视口）。
  - 对普通记录：维持现状（世界坐标 + 传入 region 投影）—— 它本来就是 region-scoped 的。
  - **归一化距离仲裁保持不变**（上一轮已做，K1/K2 有牙）。
  - 记录缺少 `obj_name` / 取不到世界坐标时：**跳过**该候选（不崩、不误命中）。
- **`_ev_leftmouse` 的跨类型仲裁**：保持不变（关键帧 vs 手柄）。

### 3.4 数据形状变更（`_session.handle_control_points`）
| 字段 | 改前 | 改后 |
|---|---|---|
| `position` | 所有记录都有（hollow 是反投影来的世界点） | **普通记录照旧**；hollow 记录**不再保证有** |
| `off_px` | 无 | hollow 记录新增（左 −32 / 右 +32） |

⚠️ **消费方核查（已做）**：
- `edit_geometry.resolve_handle_anchor_pos` 用的是 `frame` + `bone_name` + 缓存，**不读 `position`** ✓ 安全。
- `interaction.py:1526`（`active_handle_index`）只用下标 ✓ 安全。
- `get_handle_at_cursor` 是唯一读 `position` 的地方 ⇒ 一并改 ✓。

### 3.5 测试迁移
- `gui_endpoint_hollow_check` 的 **S3b / S3c** 针对 `_ring_world_points`，该函数要删 ⇒ **这两条要重写成新契约**（见 §6 T1/T5）。

---

## 4. 数据流（改前 → 改后）

**改前**
```
3D 收集(render_keyframe_marker) ── 反投影 ──▶ 世界点 ──┬─▶ 3D 画线(POST_VIEW)
                                                    └─▶ handle_control_points.position ──▶ 拾取
2D 覆盖层(overlay._draw_2d) ── 现算+正投 ──▶ 三角（另一条路，和环无关）
```

**改后**
```
3D 收集 ──▶ handle_control_points(hollow: 身份+off_px)     ← 只登记，不算位置
                      │
        endpoint_ring_screen_pos(rec, region, rv3d)          ← 唯一真相
                      ├─▶ 2D 画环(POST_PIXEL)
                      └─▶ 拾取(用鼠标所在 region)
2D 覆盖层 ── 现算+正投 ──▶ 三角（与环同一个 _fresh_kf_world，口径一致）
```

---

## 5. 边界与失败模式

| 情况 | 处理 |
|---|---|
| 拿不到 region / rv3d（后台、无视图） | 返回 None ⇒ **不画、不可拾取**（与三角同款降级；旧代码此时退化成"环落在关键帧上"，是最坏的一种降级） |
| `_fresh_kf_world` 取不到（对象被删 / action 没了） | 跳过该条；不崩 |
| 对象不可见 / 集合被禁用 | 与三角一致：`_fresh_kf_world` 仍能取到就照画（沿用现有行为，不新增判断） |
| 两个 3D 视口 | **天然解决**：绘制与拾取都用各自 region 现算 |
| 视口在绘制途中被 resize | 每帧现算 ⇒ 下一帧自愈 |
| 非选中关键帧 | 行为不变（端点仍只在 `is_selected_keyframe` 分支收集）——**本计划不改这条**（见 §10） |
| headless（无 GPU / 无 region） | `_draw_2d` 早退；拾取返回 None；测试用 `temp_override` 造 region 后走同一套代码 |

---

## 6. 测试（全部要**先证明有牙**）

> 方法：每条新测试都先跑一次"旧实现"，确认它**红**，再上改动确认**绿**。

| # | 用例 | 放在哪 | 判据 |
|---|---|---|---|
| **T1** | 环心的屏幕偏移 = 32px | `gui_endpoint_hollow_check` | 3 个不同视角下 `|实测 − 32| ≤ 0.5px` |
| **T2** | **双视口 region-scoped** | 同上 | 用视口A的region能命中、用视口B的region**不能** |
| **T3** | 拖关键帧时环的跟随 | 同上 | 沿路径移 8 步，每步 `|环心 − (投影(关键帧)+off)| ≤ 0.5px`，且位移**单调无回跳** |
| **T4** | 逐像素扫描 | 同上 | 0 死区、0 双命中（0→32px 每像素恰好归属一个目标） |
| **T5** | 画与拾取**同源**（静态契约） | 同上 | `overlay` 与 `interaction` 都出现 `endpoint_ring_screen_pos`；且 `_ring_world_points` / `_world_at_screen_offset` 已不存在 |
| **T6** | 降级不崩 | 同上 | 无 region 时绘制/拾取都返回空且不抛异常 |

**回归**（必须全绿）：
`regression` · `gui_endpoint_hollow_check` · `gui_eb_modal_check` · `gui_tri_kf_misclick_check` ·
`gui_endpoint_outer_hit_check` · `gui_endpoint_modal_check` · `gui_drag_baseline_check` · `gui_eb_spec_check` · `gui_eb_numeric_check`

**GUI 实测**（必须做，不再只靠 headless）：
真窗口里 ① 点关键帧不误触 ② 点环能抓住 ③ 拖关键帧时环**不抖**（肉眼 + 录屏看帧间位移）。

---

## 7. 验收标准

1. S1~S5 五条全部达标（§0 表）。
2. T1~T6 全绿，且**每条都有"旧实现下是红的"记录**。
3. 回归套件全绿。
4. GUI 实测三条通过（附截图/数字）。
5. 视觉**不退化**：环的颜色、半径、段数、离关键帧的距离与现在**一致**。

---

## 8. 假设与风险

**假设**
- A1：`modal_edit.keyframe_world_pos` 返回的点 = 旧代码里作为 `point_3d` 的那个点 ⇒ 环的视觉位置不变。（T1 会验证）
- A2：`POST_PIXEL` 覆盖层每帧都跑（三角已依赖这一点）✓
- A3：`set_handles` 加默认参数不会影响现有 3 个调用点 ✓

**风险与缓解**
- R1：`set_handles` 是**跨模块接口**（interaction×2 / modal_edit×1）⇒ 加**默认参数**，老调用点零改动；改完跑全部相关套件。
- R2：2D 层画的环**不再有 3D 深度**⇒ 会被关键帧点/手柄**遮挡关系**改变（2D 永远在最上层）。
  ⇒ 这是**与三角一致的既有行为**（三角也在最上层），可接受；若不接受，退回 3D 层但保留"现算屏幕坐标"（T1/T3 仍成立，只是仍有深度）。
- R3：`_hollow_records` 需要与 `handle_control_points` **同帧同源**（都由 3D 收集写）
  ⇒ 在同一个函数里一起登记，禁止别处再写。

---

## 9. 提交与回滚

- **一刀一个提交**（便于单独回退）：
  1. `overlay`：新增 `draw_circle_2d` + `set_handles(hollow=...)` + `_draw_2d` 画环
  2. `drawing`：空心态改为登记身份+off_px；删两个死函数
  3. `interaction`：拾取改为现算
  4. `tests`：S3b/S3c 重写为 T1~T6
  5. `docs`：Change Log + `tests/PHASE1_HANDOFF.md` 补记
- **回滚**：任一提交可单独 `git revert`；1~3 必须**成组**回退（它们是一次改动的三面）。

---

## 10. 明确**不做**（本轮）

1. **阈值迟滞**（进入空心 ≤6px / 退出 >9px）：能再消掉"边界附近环闪"，
   但它引入**跨模块状态**（绘制与拾取必须读到同一份），风险高于本轮收益 ⇒ **单独立项**。
2. **4 个拾取函数收敛成 1 个仲裁点**（三角 vs 手柄、路径点 vs 手柄等仍无仲裁）：
   改动面大，且**当前症状的主因不是它** ⇒ 本轮不碰，留待后续。
3. **"端点只对已选中的关键帧存在"** 这条语义：本轮不动（它是有意设计）。

---

## 11. 执行顺序

1. 先写 T1~T4（**当前实现下应当红**）→ 留证据
2. 改 `overlay`（提交 1）
3. 改 `drawing`（提交 2）
4. 改 `interaction`（提交 3）→ T1~T4 应转绿
5. 重写 S3b/S3c + 加 T5/T6（提交 4）
6. 跑全套回归 + **开 GUI 实测**（截图 + 帧间位移数字）
7. 补文档（提交 5）
