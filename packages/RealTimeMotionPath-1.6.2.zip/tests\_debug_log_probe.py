# -*- coding: utf-8 -*-
"""探针：debug_log 的启用方式与优先级是否真的生效。

历史：
- 2026-09-29 review：模块 docstring 承诺「启用方式（任一）」共 3 条，
  但环境变量 `RTMP_DEBUG_LOG` 那条**代码里从未实现**（全仓 environ 0 命中）。
  本探针验证修复后三条都成立，且优先级正确。
- 2026-10-08：**默认改为「开」**（用户要求）。相应地把 ① 的期望值反转、
  ⑧ 改成"显式关闭"路径，并补 ⑨⑩ 两条新语义。

用法：
  blender --background --factory-startup --python tests/_debug_log_probe.py
"""
import os
import sys
import json
import importlib

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)

dl = importlib.import_module(PKG_NAME + ".debug_log")

steps = []


def step(name, ok, detail=""):
    steps.append({"name": name, "ok": bool(ok), "detail": str(detail)})


def reset(env=None):
    """把模块状态清回**出厂初始态**：_explicit=False、_DEFAULT_ENABLED=True。

    ⚠️ 2026-10-08 起 `_DEFAULT_ENABLED` 也是被测状态的一部分，
       所以 reset 必须把它一并还原，否则用例之间会互相污染。
    """
    dl._explicit = False
    dl._enabled = False
    dl._DEFAULT_ENABLED = True
    dl._path = None
    if env is None:
        os.environ.pop("RTMP_DEBUG_LOG", None)
    else:
        os.environ["RTMP_DEBUG_LOG"] = env


# ---- ① 什么都不做 → 开（2026-10-08 起的新默认）----
reset()
step("★ 默认（无环境变量、未显式设）→ is_enabled()=True",
     dl.is_enabled() is True, repr(dl.is_enabled()))

# ---- ② 环境变量 RTMP_DEBUG_LOG=1 → 开 ----
reset("1")
step("环境变量 =1 → is_enabled()=True",
     dl.is_enabled() is True, repr(dl.is_enabled()))

# ---- ③ 真值变体 ----
for v in ("true", "TRUE", "yes", "On", " on "):
    reset(v)
    step("环境变量 %r → True" % v, dl.is_enabled() is True, repr(dl.is_enabled()))

# ---- ④ 假值 = 显式要求关闭（默认开启后这条语义变重要了）----
for v in ("", "0", "false", "no", "off", "banana"):
    reset(v)
    step("★ 环境变量 %r → False（设了就是显式关）" % v,
         dl.is_enabled() is False, repr(dl.is_enabled()))

# ---- ⑤ 显式 set_enabled(False) 压倒环境变量 ----
reset("1")
dl.set_enabled(False)
step("环境变量=1 但 set_enabled(False) → False（显式优先）",
     dl.is_enabled() is False, repr(dl.is_enabled()))

# ---- ⑥ 显式 set_enabled(True) 无环境变量 → 开 ----
reset()
dl.set_enabled(True)
step("显式 set_enabled(True) → True", dl.is_enabled() is True, repr(dl.is_enabled()))

# ---- ⑦ 端到端：环境变量开启时 dbg 真的落盘 ----
reset("1")
tmp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_dbg_probe_tmp.jsonl")
if os.path.exists(tmp):
    os.remove(tmp)
dl._path = tmp                      # 只指定路径，不改变 _explicit（模拟环境变量启用）
dl.dbg("probe.event", frame=25.0, side="left")
step("环境变量开启 → dbg 真的写了文件",
     os.path.exists(tmp) and os.path.getsize(tmp) > 0,
     "exists=%s size=%s" % (os.path.exists(tmp), os.path.getsize(tmp) if os.path.exists(tmp) else 0))
if os.path.exists(tmp):
    try:
        rec = json.loads(open(tmp, encoding="utf-8").read().strip().splitlines()[0])
        step("落盘记录内容正确（ev/frame/side）",
             rec.get("ev") == "probe.event" and rec.get("frame") == 25.0 and rec.get("side") == "left",
             repr(rec))
    except Exception as e:
        step("落盘记录内容正确", False, "%s: %s" % (type(e).__name__, e))
    os.remove(tmp)

# ---- ⑧ 显式关闭时 dbg 是空操作（不建文件）----
# ⚠️ 默认已改为「开」，所以这里必须**显式关**，否则测的就不是"关闭路径"了
reset()
dl.set_enabled(False)
tmp2 = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_dbg_probe_tmp2.jsonl")
if os.path.exists(tmp2):
    os.remove(tmp2)
dl._path = tmp2
dl.dbg("should.not.write")
step("★ 显式关闭时 dbg 不写文件（零成本空操作）",
     not os.path.exists(tmp2), "exists=%s" % os.path.exists(tmp2))

# ---- ⑨ 注册时同步：偏好里的值应成为「默认」，但不设 _explicit ----
# 场景：用户把 UI 开关关掉了。注册时必须让模块也关着 ——
# 否则「UI 显示没勾、日志却在记」（update 回调只在值变化时触发，兜不住启动态）。
reset()
dl.apply_prefs_default(False)
step("★ apply_prefs_default(False) → 默认变关（用户真关过就真关）",
     dl.is_enabled() is False, repr(dl.is_enabled()))
step("★ apply_prefs_default 不设 _explicit（环境变量仍能覆盖）",
     dl._explicit is False, repr(dl._explicit))
reset()
dl.apply_prefs_default(True)
step("apply_prefs_default(True) → 默认开",
     dl.is_enabled() is True, repr(dl.is_enabled()))

# ---- ⑩ 环境变量能覆盖 apply_prefs_default（测试/批处理要的能力）----
reset()
dl.apply_prefs_default(False)
os.environ["RTMP_DEBUG_LOG"] = "1"
step("★ apply_prefs_default(False) 后环境变量 =1 仍能强制开",
     dl.is_enabled() is True, repr(dl.is_enabled()))
os.environ["RTMP_DEBUG_LOG"] = "0"
dl.apply_prefs_default(True)
step("★ apply_prefs_default(True) 后环境变量 =0 仍能强制关",
     dl.is_enabled() is False, repr(dl.is_enabled()))

reset()

fails = [s for s in steps if not s["ok"]]
print("\n" + "=" * 72)
print("debug_log 启用方式探针")
print("=" * 72)
for s in steps:
    print("  [%s] %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                           ("   ← " + s["detail"]) if s["detail"] and not s["ok"] else ""))
print("-" * 72)
print("断言 %d / 失败 %d" % (len(steps), len(fails)))

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_debug_log_result.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump({"steps": steps, "fails": len(fails), "total": len(steps)}, f,
              ensure_ascii=False, indent=2)
print("结果 → %s" % out)
sys.stdout.flush()
sys.stderr.flush()
os._exit(1 if fails else 0)
