"""批量重跑 RTMP 测试脚本，刷新结果 JSON（改过产品源码后必须重跑，否则门禁报 STALE）。

    python _batch_rerun.py <blender.exe> [--only a.py,b.py]

只跑「产出结果 JSON」的脚本；跳过纯库/入口脚本。
每个脚本单独超时，失败不中断（记录后继续）。
"""
import json
import os
import subprocess
import sys
import time

CWD = os.path.dirname(os.path.abspath(__file__))          # tests/
ROOT = os.path.dirname(CWD)
T = CWD

# 不跑的：门禁本尊、公共库、模板、临时探针
SKIP = {
    "run_all.py", "_eb_common.py", "_sub_template.py",
    "_probe_iset.py", "_probe_prefs.py", "_tmp_diag_sync.py",
    "_tmp_verify_sync.py", "fixture.py", "make_fixture.py",
}

def _clean(s):
    """剥掉参数外面的引号。

    ⚠️ Windows cmd 下 `python x.py "D:\\path"` 传进来的字符串**带着引号**
    （`'"D:\\path"'`），os.path.exists 会判成"不存在"，报错还看不出是引号问题。
    """
    return (s or "").strip().strip('"').strip("'")


# 探测顺序 = **优先用户实际在用的那套**。
#
# ⚠️⚠️ 这里踩过一个代价不小的坑（2026-10-08）：
#   最初把 `D:\program\blender-*` 排在最前，于是"自动探测"选中了 5.0，
#   而用户实际用的是 Steam 那份 **5.2.2**。结果 3 个用 `gpu.init()` 的测试
#   （5.1+ 才有该 API）在 5.0 上崩掉，我据此得出「本机没有 5.1/5.2」
#   「那 3 个测试本机跑不了」的错误结论 —— 其实本机有 5.2，用它跑全绿。
#   ⇒ 教训：**别让脚本替你在多个版本里"随便挑一个"**。挑错版本 = 用错的环境
#     验证，得到的"失败"是假的，而且很容易被当成真问题去查（我查了好几轮）。
#   ⇒ 现在：Steam 那份排最前（用户的日常环境），并且被选中时打印出来。
_BLENDER_PATTERNS = [
    r"C:\Program Files (x86)\Steam\steamapps\common\Blender\blender.exe",
    r"C:\Program Files\Steam\steamapps\common\Blender\blender.exe",
    r"D:\SteamLibrary\steamapps\common\Blender\blender.exe",
    r"E:\SteamLibrary\steamapps\common\Blender\blender.exe",
    r"C:\Program Files\Blender Foundation\Blender*\blender.exe",
    r"D:\program\blender-*\*\blender.exe",
    r"D:\program\blender-*\blender.exe",
]


def _find_blender():
    """按常见安装位置找 blender.exe（优先用户日常在用的那份）。"""
    import glob
    for p in _BLENDER_PATTERNS:
        hits = sorted(glob.glob(p))
        if hits:
            return hits[-1]
    return None


def _list_all_blenders():
    """列出找到的所有 blender.exe，便于察觉"跑的不是你以为的那个版本"。"""
    import glob
    out = []
    for p in _BLENDER_PATTERNS:
        out.extend(sorted(glob.glob(p)))
    return sorted(set(out))


blender = _clean(sys.argv[1]) if len(sys.argv) > 1 else ""
if not blender or not os.path.exists(blender):
    auto = _find_blender()
    if auto:
        print("### 未收到有效路径，自动探测到: %s" % auto)
        blender = auto
    else:
        print("用法: python _batch_rerun.py <blender.exe>")
        print("      （收到的是: %r）" % (sys.argv[1] if len(sys.argv) > 1 else None))
        for p in _list_all_blenders():
            print("      找到: %s" % p)
        sys.exit(2)


def _blender_version(exe):
    """取实际运行的 Blender 版本 —— 必须打出来，否则"跑的是哪个版本"全靠脑补。"""
    try:
        r = subprocess.run([exe, "--version"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=60)
        return ((r.stdout or "").strip().splitlines() or ["?"])[0]
    except Exception as e:                       # noqa: BLE001
        return "取版本失败: %s" % e


# ★ 测试跑的时候把调试日志**关掉**（RTMP_DEBUG_LOG=0）。
#
# 为什么：日志默认开启后，每次 headless 测试都会往**用户真实的**
# `<config>/rtmp_debug/` 里写几十~几百条记录（`--factory-startup` 不改变
# `bpy.utils.user_resource("CONFIG")` 的指向）。
# 后果：用户真出问题、打开日志准备发给我们时，里面全是测试噪音 ——
# 那这条日志就白记了（与"默认开启"的初衷正好相反）。
#
# 注意：`_debug_log_probe.py` 自己显式指定 `dl._path`，不受影响，
# 它验的是"日志机制本身对不对"；而这里关掉的是"业务运行时的落盘"。
_TEST_ENV = dict(os.environ)
_TEST_ENV["RTMP_DEBUG_LOG"] = "0"

_all = _list_all_blenders()
if len(_all) > 1:
    print("### 本机找到 %d 个 Blender（本次只用最上面那个；跑错版本会得到假的'失败'）："
          % len(_all))
    for p in _all:
        mark = "  ← 本次使用" if p == blender else ""
        print("      %s%s" % (p, mark))
print("### 使用: %s" % _blender_version(blender))
print()

only = None
if "--only" in sys.argv:
    only = set(sys.argv[sys.argv.index("--only") + 1].split(","))

scripts = []
for f in sorted(os.listdir(T)):
    if not f.endswith(".py") or f in SKIP:
        continue
    # ⚠️ 前缀别漏：本项目有 4 类测试脚本（`_` / `gui_` / `test_` / `i18n_gate`）。
    #    2026-10-08 第一次写时漏了 `test_`，结果 9 个脚本没跑、门禁一直报 STALE，
    #    而 STALE 只是"可疑"不是"失败"—— 很容易被当成噪音放过去。
    if (f.startswith("_") or f.startswith("gui_") or f.startswith("test_")
            or f.startswith("regression") or f.startswith("i18n_gate")):
        scripts.append(f)
if only:
    scripts = [s for s in scripts if s in only]

print("### 将重跑 %d 个脚本" % len(scripts))
results = []
t_all = time.time()

for i, s in enumerate(scripts, 1):
    sp = os.path.join(T, s)
    t0 = time.time()
    rc = None
    err = ""
    try:
        r = subprocess.run([blender, "--background", "--factory-startup", "--python", sp],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", cwd=ROOT, timeout=300, env=_TEST_ENV)
        rc = r.returncode
        if rc != 0:
            tail = ((r.stdout or "") + (r.stderr or "")).strip().splitlines()
            err = " | ".join(tail[-2:])[:160]
    except subprocess.TimeoutExpired:
        err = "TIMEOUT(300s)"
    dt = time.time() - t0
    results.append({"script": s, "rc": rc, "sec": round(dt, 1), "err": err})
    print("[%3d/%3d] %-42s rc=%-5s %5.1fs %s" % (i, len(scripts), s, rc, dt, err))
    sys.stdout.flush()

print("\n### 汇总（总耗时 %.0fs）" % (time.time() - t_all))
bad = [r for r in results if r["rc"] != 0]
print("  跑完 %d 个，非零退出 %d 个" % (len(results), len(bad)))
for r in bad:
    print("    rc=%s  %s  %s" % (r["rc"], r["script"], r["err"]))

out = os.path.join(T, "_batch_rerun_log.json")
with open(out, "w", encoding="utf-8") as fh:
    json.dump(results, fh, ensure_ascii=False, indent=1)
print("  明细 → %s" % out)
