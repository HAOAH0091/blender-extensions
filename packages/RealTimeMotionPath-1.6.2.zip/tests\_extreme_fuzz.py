# -*- coding: utf-8 -*-
"""I 组：随机化 fuzz（极限边界）—— tests/_extreme_fuzz.py

来源 / 定位
-----------
建在 tests/_eb_common.py（Phase 1 共享地基）之上的 **I 组**测试：
用固定随机种子的 fuzz，在**极端的**关键帧布局 / 手柄类型 / 参数组合下
反复调用产品的七条"会真的改动画数据"的写路径，每轮都过一遍共享不变量
检查器，把任何违规连同**最小复现**一起落进 _eb_fuzz_result.json。

覆盖的七个产品入口
------------------
    td.write_s                  把 s 写到该帧三轴（改时间分量）
    td.apply_pixel_drag         屏幕像素 -> s（三角拖拽的数据层）
    it._align_opposite_speed    双击锁定：把对侧速度统一成被双击侧
    sc.apply_fix                规范检查的自动微调（补轴/统一 dt/拉直/共线）
    xf.scale_handle_uniform     端点手柄等比缩放（唯一实现，**单轴中间函数**）
    xf.write_endpoint_uniform   逐轴派发 scale_handle_uniform（真实三轴路径）
    xf.set_tri_locked           三角一体 / 分离锁定

每轮流程
--------
    造对象（独立名 _FZ_%04d）-> 随机关键帧布局 -> 随机手柄类型 + dt/dv
    -> 基线不变量检查 -> 随机 1~5 个操作，**每个操作后都查一次**
    -> 收尾 fc.update() 再查一次（抓"写进去被 Blender 重算掉"这一类）
    -> 删对象 / 删 action（下一轮不互相污染）

⚠️ 四条"别骗自己"的设计（都是第一版踩过的坑）
------------------------------------------------
  ① **按签名去重，不按整串**：每轮维护"已见过的签名"（把数字与坐标元组
     一并抹掉），某个阶段只记签名没见过的违规。否则一个早期引入的坏值
     会在后面每个阶段重复计数，把"1 个根因"放大成"8 条发现"；
     更要命的是归因会漂到后面无辜的阶段（float32 舍入让 1e-4 变 0.001001，
     整串比较就当成"新发现"，于是单轴函数的锅记到了 post_update 头上）。
  ② **基线取自真实快照**：xf.scale_handle_uniform / xf.write_endpoint_uniform
     的 dv_base / dt_base 不是随便摇的 —— 真实调用方
     （edit_geometry._uniform_plan / transform_domain.endpoint_uniform_plan）
     都是从"按下时的三点快照"取 handle - co。喂随机基线等于让产品
     去背它没干的锅（第一版把"三轴 dt 不一致"记到 xf 头上，其实是
     测试自己喂了三组不相等的基线）。
  ③ **k / k_raw 不是独立变量，必须走产品的 handle_scale_k**：
     真实路径里 k_raw = |dv_new| / |dv_base|、k = min(k_raw, 200)。
     第一版把两者各自随机摇，摇出了 ratio = k/k_raw ≈ 1e14 这种
     真实到不了的比例，写出 handle = 1e20，再由 Blender 的 ALIGNED 重算
     爆成 inf/nan —— 于是"非有限数"被当成了产品缺陷。
     现在的数学边界：dv = dv_new · (k/k_raw) ≤ 200 · |dv_base|，到不了 inf。
  ④ **可达性是"本轮粘性"的**：坏值往往在**后面某次 fc.update()** 才爆掉，
     按"观察到的阶段"判可达性会把锅甩给无辜的那一步 ——
     所以本轮只要跑过任何一个"真实路径不可达"的操作，之后的发现一律
     标 reachable=False，单独归类。

★ 自检（I1）：内置 bug 注入，证明这个 fuzz **真的抓得到**它该抓的违规
---------------------------------------------------------------------
    对照组：原样跑 60 轮            => 必须 0 条 FAIL
    注入组：让 td.write_s 故意把一轴 dt 写歪半段
                                    => 必须抓到「同侧三轴 dt 不一致」的 FAIL
    注入只在**内存里** monkey-patch，绝不改产品文件。
    一个抓不到 bug 的测试比没有测试更危险 —— 这一步就是防它。

判定口径
--------
    FAIL    明确违反不变量（三轴 dt 不一致 / NaN·Inf / 幽灵条目），
            且**在真实调用路径上可达**
    NOTE    已知设计边界 / 真实路径不可达（本轮记为 PASS，detail 里写清楚）：
            · dt > 段长：scale_handle_uniform 2026-09-17 用户拍板
              "取消拉长上限，手柄一直跟手变长" => 该函数**刻意**不钳 dt
            · 派生手柄类型（ALIGNED / AUTO_CLAMPED / VECTOR）下
              Blender 自己按 (t,v) 共线重算 => 三轴 dt 被它写散 / dt 被拉过段长
            · 单轴中间函数被单独调用 => 只动一个轴，三轴必然不等
            · k > UNIFORM_K_SAFETY=200 的参数 => 真实调用方到不了（缺上界守卫）
    SUSPECT 其它（异常、可疑状态）

用法
----
    blender --background --factory-startup --python tests/_extreme_fuzz.py
    blender --background --factory-startup --python tests/_extreme_fuzz.py -- --seed 1234 --rounds 500

结果
----
    tests/_eb_fuzz_result.json
      ├─ steps / fails / suspects ...  共享地基 E.flush 的固定 schema
      ├─ selfcheck                     bug 注入自检的结论
      └─ fuzz                          每类违规计数 + findings + **最小复现代码**
           · repro       = FAIL 类的最小复现（可直接粘贴运行）
           · repro_note  = NOTE 类的最小复现（同上，供人工判断边界是否合理）
"""
import os
import re
import sys
import json
import time
import random
import traceback

# ⚠️ 别硬编码盘符（公司机 D:\ / 家里机 F:\）—— 写死会让脚本在另一台机器上静默失败，
#    门禁只报 STALE，看不出原因。见 gui_eb_modal_check.py 里的详细说明。
_HERE = os.path.dirname(os.path.abspath(__file__))
ADDONS = os.path.dirname(os.path.dirname(_HERE))
sys.path.insert(0, ADDONS)
sys.path.insert(0, _HERE)

import bpy
bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
import _eb_common as E

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, "_eb_fuzz_result.json")

# ---- 命令行（-- --seed 1234 --rounds 500）----------------------------------
SEED = 20260930
ROUNDS = 500
TIME_BUDGET = 250.0          # 秒；超了就提前收，并在结果里注明实际轮数

_argv = list(sys.argv)
if "--" in _argv:
    _rest = _argv[_argv.index("--") + 1:]
    _i = 0
    while _i < len(_rest):
        if _rest[_i] == "--seed" and _i + 1 < len(_rest):
            SEED = int(_rest[_i + 1]); _i += 2; continue
        if _rest[_i] == "--rounds" and _i + 1 < len(_rest):
            ROUNDS = int(_rest[_i + 1]); _i += 2; continue
        _i += 1

steps = []
def step(n, ok, d=""):
    steps.append((str(n), bool(ok), str(d)))


# ===========================================================================
# 随机素材池
# ===========================================================================

FRAME_POOL = [0.0, 1.0, -1.0, -30.0, 0.4, 2.5, 14.4, 33.33, 90.0, 117.0,
              -0.5, 1000.0, -1000.0, 100000.0, -100000.0, 1e-3]
VAL_POOL = [0.0, 1e-9, -1e-9, 1e-4, -1e-4, 0.5, -0.5, 2.56, -3.7,
            1e3, -1e3, 1e6, -1e6, 1e5, -1e5]

DT_POOL = [0.0, 1e-9, 1e-3, 0.5, 5.0, 90.0, 1e4, -1e-9, -1.0, -1e5]
DV_POOL = [0.0, 1e-9, -1e-9, 0.5, -0.5, 10.0, -10.0, 1e6, -1e6]

# 手柄类型权重：FREE 给一半，保证有一半轮次能做**干净的**归因
HTYPE_CHOICES = ['FREE', 'FREE', 'FREE', 'FREE', 'FREE',
                 'ALIGNED', 'ALIGNED', 'AUTO_CLAMPED', 'AUTO_CLAMPED', 'VECTOR']

# ★ bug 注入开关 —— 只在**内存里** monkey-patch 行为，绝不改产品文件。
#   用途：证明这个 fuzz 真的抓得到它该抓的违规（见 selfcheck）。
INJECT = {"on": False}
# 自检时强制所有轮次用 FREE 手柄，排除"派生类型被 Blender 重算"这条已知边界，
# 让归因干净到"就是写坏了"。
FORCE_HTYPE = None

# 真实调用路径的 k 上界（transform_domain.UNIFORM_K_SAFETY）
K_SAFETY = 200.0
# 大部分轮次用**可达**的 k，少数轮次故意越界（用来暴露"缺上界守卫"）
K_POOL = [0.0, 1e-9, 1e-3, 0.5, 1.0, 5.0, 200.0, 200.0,
          1e6, 1e25, 1e35, 1e35]
KRAW_POOL = [0.0, 1e-12, 1e-9, 1e-3, 1.0, 10.0, 1e6]
DVNEW_POOL = [0.0, 1e-9, 1e-3, 1.0, 10.0, 1e6, 1e20]

SIG_RE = re.compile(r"[-+]?\d+\.?\d*(?:e[-+]?\d+)?")
VAL_TUPLE_RE = re.compile(r"= \([^)]*\)")

def sig_of(text):
    """把违规文本里的数字抹掉，得到"同类"签名（用于归并根因）。

    ⚠️ 括号里的**坐标元组**也要一并抹掉：非有限数会写成
       (nan, nan) / (inf, nan) / (inf, -inf) / (inf, inf)，
       它们全是"同一个根因（值爆掉）在不同轴上的表现"，
       不抹掉就会被拆成 4 个类别、还把归因漂到后面无辜的阶段。
    """
    s = VAL_TUPLE_RE.sub("= (X)", str(text))
    return SIG_RE.sub("N", s).strip()


def rand_frames(rng):
    n = rng.randint(1, 8)
    pool = list(FRAME_POOL)
    rng.shuffle(pool)
    picked = set()
    for v in pool:
        if len(picked) >= n:
            break
        picked.add(float(v))
    guard = 0
    while len(picked) < n and guard < 40:
        guard += 1
        picked.add(round(rng.uniform(-2000.0, 2000.0), 4))
    return sorted(picked)


def rand_vals(rng, n):
    return [[float(rng.choice(VAL_POOL)) for _ in range(n)] for _ax in range(3)]


# ===========================================================================
# 场景构造 / 拆除
# ===========================================================================

def make_obj(name, frames, vals):
    """用共享地基造对象，再把 location 三条曲线换成**任意帧号 / 值**的布局。

    ⚠️ 为什么要自己换：E.build_object 走 scene.frame_set(int(f)) + keyframe_insert，
       帧号被 int() 截断 => 造不出小数帧 / 负帧。这里改用
       fc.keyframe_points.insert(frame=<float>) 直接建点（API 文档写明
       frame / value 都取 [-inf, inf]）。
    """
    o, act = E.build_object(name, keys=((0, (0.0, 0.0, 0.0)),))
    try:
        act.name = str(name) + "_act"
    except Exception:
        pass
    for ax, fc in sorted(E.curves_of(o).items()):
        fc.keyframe_points.clear()
        row = vals[ax] if ax < len(vals) else vals[0]
        for i, f in enumerate(frames):
            fc.keyframe_points.insert(frame=float(f), value=float(row[i]),
                                      options={'FAST'})
        fc.keyframe_points.sort()
        try:
            fc.keyframe_points.deduplicate()
        except Exception:
            pass
        fc.update()
    return o, act


def kill_obj(o, act):
    mesh = None
    try:
        mesh = o.data
    except Exception:
        mesh = None
    try:
        if o is not None:
            bpy.data.objects.remove(o, do_unlink=True)
    except Exception:
        pass
    try:
        if act is not None:
            bpy.data.actions.remove(act)
    except Exception:
        pass
    try:
        if mesh is not None and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    except Exception:
        pass


def kp_at(fc, frame):
    for kp in fc.keyframe_points:
        if abs(float(kp.co[0]) - float(frame)) < 1e-3:
            return kp
    return None


def handle_of(kp, side):
    return kp.handle_left if side == 'left' else kp.handle_right


_FRAME_IN_TEXT = re.compile(r"f=([-+0-9.eE]+)")


def frames_in(viol):
    """从违规文本里抠出它说的是哪几帧（"f=90"）。"""
    out = []
    for m in _FRAME_IN_TEXT.findall(str(viol)):
        try:
            out.append(float(m))
        except Exception:
            pass
    return out


def types_at(o, frames):
    """违规帧上**手柄的实际类型**集合 —— 分级要的是证据，不是猜。

    只要有派生类型（ALIGNED / AUTO / AUTO_CLAMPED / VECTOR）在场，
    Blender 就会在 fc.update() 时按自己的公式重算手柄坐标，
    那类违规属于已知设计边界（插件自己的 docstring 也写明了）。
    """
    got = set()
    try:
        for fc in E.curves_of(o).values():
            for kp in fc.keyframe_points:
                f = round(float(kp.co[0]), 4)
                if any(abs(f - float(x)) < 1e-3 for x in frames):
                    got.add(str(kp.handle_left_type))
                    got.add(str(kp.handle_right_type))
    except Exception:
        pass
    return sorted(got)


def _fresh(cur, seen_sig):
    """只挑"签名没见过"的违规，并把当前全部签名登记进 seen_sig。

    ⚠️ 必须按**签名**（抹掉数字）去重，不能按整串：
       同一根因在后续阶段数值会因 float32 舍入微变（1e-4 -> 0.001001），
       整串比较会把它当成"新发现"再记一次 —— 于是归因从真正的凶手
       （单轴中间函数）漂到 post_update，分级也跟着错判成 FAIL。
    """
    out = []
    for v in cur:
        s = sig_of(v)
        if s in seen_sig:
            continue
        seen_sig.add(s)
        out.append(v)
    return out


def setup_handles(rng, o, act, htype, frame, side, dt, dv):
    """① 全部 FREE 并写随机 dt/dv ② 再按概率切成随机（派生）类型。"""
    for fc in E.curves_of(o).values():
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()
    E.set_handles(o, float(frame), side, dt=dt, dv=dv)
    if htype != 'FREE':
        for fc in E.curves_of(o).values():
            for kp in fc.keyframe_points:
                kp.handle_left_type = htype
                kp.handle_right_type = htype
            fc.update()



# ===========================================================================
# 七个被测操作 —— 返回 (名字, 参数字典, 返回值, 真实路径可达?)
# ===========================================================================

def op_write_s(rng, o, act, frames):
    frame = float(rng.choice(frames))
    side = rng.choice(('left', 'right'))
    s = float(rng.choice([0.0, -1.0, 1e-12, 1e-5, 0.05, 1.0 / 3.0,
                          0.9, 1.0, 2.0, 1e6]))
    freeze = bool(rng.random() < 0.5)
    kfm, span = E.td.resolve_target(act, o, frame, side)
    r = E.td.write_s(kfm, side, s, span, freeze=freeze, act=act, obj=o)
    if INJECT["on"] and r is not None and kfm:
        # ★ bug 注入：把最后一个轴的 dt 故意写歪半段 ——
        #   "同侧三轴 dt 不一致"的典型成因，产品真出这个 bug 时也该被抓到。
        try:
            _kp = kfm.get(2) or kfm[sorted(kfm)[-1]]
            _d = 0.5 * float(span) if span else 0.5
            if side == 'left':
                _kp.handle_left = (float(_kp.co[0]) - _d, float(_kp.handle_left[1]))
            else:
                _kp.handle_right = (float(_kp.co[0]) + _d, float(_kp.handle_right[1]))
        except Exception:
            pass
    return ("td.write_s",
            {"frame": frame, "side": side, "s": s, "freeze": freeze}, r, True)


def op_pixel_drag(rng, o, act, frames):
    frame = float(rng.choice(frames))
    side = rng.choice(('left', 'right'))
    px = float(rng.choice([0.0, 1e-9, -1e-9, 1.0, -1.0, 30.0, -30.0,
                           1e4, -1e4, 1e9, -1e9]))
    r = E.td.apply_pixel_drag(act, o, frame, side, px)
    return ("td.apply_pixel_drag", {"frame": frame, "side": side, "px": px},
            r, True)


def op_align(rng, o, act, frames):
    frame = float(rng.choice(frames))
    tri = rng.choice([E.hd.TRI_UP, E.hd.TRI_DOWN])
    ok, info, reason = E.it._align_opposite_speed(bpy.context, o, frame, tri, None)
    return ("it._align_opposite_speed", {"frame": frame, "tri": tri},
            {"ok": ok, "reason": reason}, True)


def op_apply_fix(rng, o, act, frames):
    kinds = rng.choice([
        None,
        ["missing_axis"],
        ["dt_mismatch"],
        ["handle_bend"],
        ["force_align"],
        ["missing_axis", "dt_mismatch", "handle_bend", "force_align"],
    ])
    try:
        rep = E.sc.detect(act, o)
    except Exception:
        rep = {"issues": []}
    res, _snap = E.sc.apply_fix(act, o, rep, kinds=kinds)
    return ("sc.apply_fix", {"kinds": kinds},
            dict(res.get("applied") or {}), True)


def _k_pair(dv_base, dv_new, dt_base, span, rng):
    """算 (k, k_raw, reachable) —— 优先走**产品自己的** handle_scale_k。

    ⚠️⚠️ 为什么必须这样（第一版的惨痛教训）
    ------------------------------------
    handle_scale_k 里 k_raw = |dv_new| / |dv_base|、k = min(k_raw, 200)，
    这两个**不是独立变量**。第一版把 k / k_raw 各自随机摇，摇出了真实路径
    永远到不了的比例（ratio = k/k_raw 能到 1e14）：
        k=0.0 / k_raw=1e-12 / dv_new=1e20
        => scale_handle_uniform 写出 handle 值 1e20
        => 下一次 fc.update() 里 Blender 的 ALIGNED 共线重算把它算成 inf/nan
    于是"手柄坐标非有限"被记成了产品缺陷 —— 其实是**测试自己喂了假数据**。

    真实路径的数学边界（可由 k = min(k_raw, 200) 推出）：
        dv = dv_new · (k/k_raw) ≤ 200 · |dv_base|
    即"新手柄长度 ≤ 200 倍基线长度"，数学上到不了 float32 的 inf。

    仍然保留 25% 的**故意越界**轮次（k 推到 1e25/1e35），用来暴露
    "函数本身没有上界守卫"这件事，但这类发现一律标 reachable=False，
    不跟真实可达的混在一起。
    """
    ks = None
    try:
        ks = E.xf.handle_scale_k(list(dv_base), list(dv_new), list(dt_base), span)
    except Exception:
        ks = None
    if ks is not None:
        if rng.random() >= 0.25:
            return (float(ks[0]), float(ks[1]), True)
        return (float(rng.choice([1e6, 1e25, 1e35])), float(ks[1]), False)
    # 产品自己会跳过这次写入（基线太短 / 手柄零长）⇒ 真实路径不可达；
    # 这里仍然跑一遍，只为暴露"缺守卫"。
    return (float(rng.choice(K_POOL)), float(rng.choice(KRAW_POOL)), False)


def op_scale_uniform(rng, o, act, frames):
    """单轴中间函数：基线取自真实快照，k/k_raw 由产品的 handle_scale_k 算。"""
    curves = sorted(E.curves_of(o).items())
    if not curves:
        return None
    ax, fc = rng.choice(curves)
    frame = float(rng.choice(frames))
    kp = kp_at(fc, frame)
    if kp is None:
        return None
    side = rng.choice(('left', 'right'))
    h = handle_of(kp, side)
    dv_base = float(h[1]) - float(kp.co[1])          # ← 真实快照口径
    dt_base = float(h[0]) - float(kp.co[0])          # ← 真实快照口径（带符号）
    dv_new = float(rng.choice(DVNEW_POOL))
    _kfm, span = E.td.resolve_target(act, o, frame, side)
    span = float(span) if span else 0.0
    pair = _k_pair([dv_base], [dv_new], [dt_base], span, rng)
    k, k_raw, reach = pair
    r = E.xf.scale_handle_uniform(kp, side, dv_base, dt_base, dv_new,
                                  k, k_raw, span)
    return ("xf.scale_handle_uniform",
            {"ax": int(ax), "frame": frame, "side": side, "dv_new": dv_new,
             "k": k, "k_raw": k_raw, "span": span,
             "dv_base": dv_base, "dt_base": dt_base}, r, reach)


def op_write_endpoint_uniform(rng, o, act, frames):
    """真实三轴路径：三轴同一 k，基线**取自真实快照**。"""
    curves = list(E.curves_of(o).values())
    if not curves:
        return None
    frame = float(rng.choice(frames))
    side = rng.choice(('left', 'right'))
    dv_base, dt_base, dv_new = {}, {}, {}
    for fc in curves:
        ax = int(fc.array_index)
        kp = kp_at(fc, frame)
        if kp is None:
            continue
        h = handle_of(kp, side)
        dv_base[ax] = float(h[1]) - float(kp.co[1])
        dt_base[ax] = float(h[0]) - float(kp.co[0])
        dv_new[ax] = float(rng.choice(DVNEW_POOL))
    if not dv_new:
        return None
    _kfm, span = E.td.resolve_target(act, o, frame, side)
    span = float(span) if span else 0.0
    seq = sorted(dv_new)
    k, k_raw, reach = _k_pair([dv_base[a] for a in seq],
                              [dv_new[a] for a in seq],
                              [dt_base[a] for a in seq], span, rng)
    r = E.xf.write_endpoint_uniform(curves, frame, side, dv_base, dt_base,
                                    dv_new, k, k_raw, span)
    return ("xf.write_endpoint_uniform",
            {"frame": frame, "side": side, "dv_new": dv_new, "k": k,
             "k_raw": k_raw, "span": span,
             "dv_base": dv_base, "dt_base": dt_base}, r, reach)


def op_set_tri_locked(rng, o, act, frames):
    frame = float(rng.choice(frames))
    locked = bool(rng.random() < 0.5)
    r = E.xf.set_tri_locked(act, frame, locked)
    return ("xf.set_tri_locked", {"frame": frame, "locked": locked}, r, True)


OPS = [op_write_s, op_write_s, op_pixel_drag, op_align,
       op_scale_uniform, op_write_endpoint_uniform, op_write_endpoint_uniform,
       op_set_tri_locked, op_apply_fix]



# ===========================================================================
# 违规分级
# ===========================================================================

def classify(viol, stage, htype, reachable, types):
    """(verdict, 理由)。verdict 取 'FAIL' / 'NOTE' / 'SUSPECT'。

    `types` = 违规帧上手柄的**实际类型**（证据，不靠 htype 猜）：
    只要有派生类型在场，Blender 就会在 fc.update() 时按自己的公式重算手柄。
    """
    v = str(viol)
    derived = [t for t in (types or []) if t != 'FREE']
    ev = ("| 证据: 该帧手柄实际类型=%s" % (list(types),)) if types else ""
    if ("非有限" in v) or ("NaN" in v) or ("Inf" in v):
        if reachable:
            return ("FAIL", "手柄坐标出现 NaN/Inf —— 明确违反不变量 2 " + ev)
        return ("NOTE", "NaN/Inf 只在真实路径**不可达**的参数下出现"
                        "（k > UNIFORM_K_SAFETY=200，真实调用方 handle_scale_k 会钳住）"
                        "—— 属函数缺上界守卫，建议加固 " + ev)
    if "幽灵" in v:
        return ("FAIL", "内存表与 custom property 不一致 —— 明确违反不变量 4 " + ev)
    if "dt 为负" in v:
        return ("FAIL", "dt 为负 —— 明确违反不变量 3 " + ev)
    if "同侧三轴 dt 不一致" in v:
        if stage == "xf.scale_handle_uniform":
            return ("NOTE", "单轴中间函数被单独调用 —— 只动一个轴，三轴 dt 必然不等；"
                            "真实路径是 xf.write_endpoint_uniform（三轴一起写） " + ev)
        if derived:
            return ("NOTE", "该帧手柄是派生类型 %s，Blender 在 fc.update() 时按自己的"
                            " (t,v) 共线公式重算 => 三轴 dt 被它写散（已知设计边界） " % derived + ev)
        if not reachable:
            return ("NOTE", "只在真实路径不可达的参数下出现（k > UNIFORM_K_SAFETY=200） " + ev)
        return ("FAIL", "同侧三轴 dt 必须相等（插件自定规范）—— 明确违反不变量 1 " + ev)
    if "dt 超过段长" in v:
        if stage in ("xf.scale_handle_uniform", "xf.write_endpoint_uniform"):
            return ("NOTE", "scale_handle_uniform 2026-09-17 用户拍板"
                            "「取消拉长上限，手柄一直跟手变长」=> 刻意不钳 dt（已知设计边界） " + ev)
        if derived:
            return ("NOTE", "该帧手柄是派生类型 %s，Blender 在 fc.update() 时按公式重算"
                            " => dt 被拉过段长（已知设计边界） " % derived + ev)
        if stage == "setup":
            return ("NOTE", "本轮造场景时故意写入了超过段长的手柄 dt（测试素材，非产品行为） " + ev)
        if not reachable:
            return ("NOTE", "只在真实路径不可达的参数下出现（k > UNIFORM_K_SAFETY=200） " + ev)
        return ("FAIL", "dt 超过段长 —— 明确违反不变量 3 " + ev)
    if v.startswith("EXC:"):
        return ("SUSPECT", "被测入口抛异常（产品用宽 except 兜住时本应静默；这里直接暴露）")
    return ("SUSPECT", "未归类的违规 " + ev)



# ===========================================================================
# 最小复现生成
# ===========================================================================

REPRO_HEAD = r'''# -*- coding: utf-8 -*-
# 【最小复现】由 tests/_extreme_fuzz.py 自动生成   种子=%(seed)d  轮号=%(round)d
# 跑法：blender --background --factory-startup --python <本文件>
import sys
# 路径由生成时**实际跑的那台机器**插值进来（见 build_repro 传入的 "addons"）——
# 这样生成的复现脚本在哪台机器上都能跑，不会带着写死的盘符。
ADDONS = r"%(addons)s"
sys.path.insert(0, ADDONS)
sys.path.insert(0, ADDONS + r"\RealTimeMotionPath\tests")
import bpy
bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
import _eb_common as E
from RealTimeMotionPath import (time_domain as td, interaction as it,
                                spec_check as sc, transform_domain as xf,
                                handles as hd)

FRAMES = %(frames)r
VALS = %(vals)r
HTYPE = %(htype)r
SETUP = %(setup)r

def make_obj(name, frames, vals):
    o, act = E.build_object(name, keys=((0, (0.0, 0.0, 0.0)),))
    act.name = name + "_act"
    for ax, fc in sorted(E.curves_of(o).items()):
        fc.keyframe_points.clear()
        for i, f in enumerate(frames):
            fc.keyframe_points.insert(frame=float(f), value=float(vals[ax][i]),
                                      options={'FAST'})
        fc.keyframe_points.sort()
        fc.update()
    return o, act

o, act = make_obj("_FZ_REPRO", FRAMES, VALS)
for fc in E.curves_of(o).values():
    for kp in fc.keyframe_points:
        kp.handle_left_type = 'FREE'
        kp.handle_right_type = 'FREE'
    fc.update()
E.set_handles(o, SETUP["frame"], SETUP["side"], dt=SETUP["dt"], dv=SETUP["dv"])
if HTYPE != 'FREE':
    for fc in E.curves_of(o).values():
        for kp in fc.keyframe_points:
            kp.handle_left_type = HTYPE
            kp.handle_right_type = HTYPE
        fc.update()
print("基线不变量:", E.invariants(act, o))
'''

_REPRO_TAIL = ('for _f in E.curves_of(o).values():\n'
               '    _f.update()\n'
               'print("不变量:", E.invariants(act, o))')

REPRO_OPS = {
    "td.write_s":
        'kfm, sp = td.resolve_target(act, o, %(frame)r, %(side)r)\n'
        'print("write_s ->", td.write_s(kfm, %(side)r, %(s)r, sp, freeze=%(freeze)r, act=act, obj=o))',
    "td.apply_pixel_drag":
        'print("apply_pixel_drag ->", td.apply_pixel_drag(act, o, %(frame)r, %(side)r, %(px)r))',
    "it._align_opposite_speed":
        'print("align ->", it._align_opposite_speed(bpy.context, o, %(frame)r, %(tri)r, None))',
    "sc.apply_fix":
        '_rep = sc.detect(act, o)\n'
        'print("apply_fix ->", sc.apply_fix(act, o, _rep, kinds=%(kinds)r)[0].get("applied"))',
    "xf.scale_handle_uniform":
        '_fc = E.curves_of(o)[%(ax)d]\n'
        '_kp = [k for k in _fc.keyframe_points if abs(float(k.co[0]) - %(frame)r) < 1e-3][0]\n'
        '_h = _kp.handle_left if %(side)r == "left" else _kp.handle_right\n'
        '_dv_base = float(_h[1]) - float(_kp.co[1])\n'
        '_dt_base = float(_h[0]) - float(_kp.co[0])\n'
        'print("scale ->", xf.scale_handle_uniform(_kp, %(side)r, _dv_base, _dt_base, %(dv_new)r, %(k)r, %(k_raw)r, %(span)r))',
    "xf.write_endpoint_uniform":
        '_curves = list(E.curves_of(o).values())\n'
        '_dvb, _dtb, _dvn = {}, {}, %(dv_new)r\n'
        'for _f in _curves:\n'
        '    _a = int(_f.array_index)\n'
        '    _c = [k for k in _f.keyframe_points if abs(float(k.co[0]) - %(frame)r) < 1e-3]\n'
        '    if not _c:\n'
        '        continue\n'
        '    _k2 = _c[0]\n'
        '    _h = _k2.handle_left if %(side)r == "left" else _k2.handle_right\n'
        '    _dtb[_a] = float(_h[0]) - float(_k2.co[0])\n'
        '    _dvb[_a] = float(_h[1]) - float(_k2.co[1])\n'
        'print("weu ->", xf.write_endpoint_uniform(_curves, %(frame)r, %(side)r, _dvb, _dtb, _dvn, %(k)r, %(k_raw)r, %(span)r))',
    "xf.set_tri_locked":
        'print("set_tri_locked ->", xf.set_tri_locked(act, %(frame)r, %(locked)r))',
}


def build_repro(rec):
    """把一轮的参数 dump 成可直接粘贴运行的代码。"""
    try:
        parts = [REPRO_HEAD % {"seed": rec["seed"], "round": rec["round"],
                               "frames": rec["frames"], "vals": rec["vals"],
                               "htype": rec["htype"], "setup": rec["setup"],
                               # 把「当前这台机器的真实插件路径」写进生成的复现脚本
                               "addons": ADDONS}]
        for name, params in rec["ops"]:
            tpl = REPRO_OPS.get(name)
            if tpl is None:
                parts.append("# (无模板) %s %r" % (name, params))
                continue
            parts.append(tpl % params)
            parts.append(_REPRO_TAIL)
        parts.append('print("最终不变量:", E.invariants(act, o))')
        return "\n".join(parts)
    except Exception:
        return "# 复现生成失败: %s" % traceback.format_exc()[-400:]



# ===========================================================================
# 主循环
# ===========================================================================

def _record(categories, findings, rec, stage, viol, verdict, reason, reachable):
    # ⚠️ frames / vals / setup 必须一起带上 —— build_repro 要用它们重放整轮。
    #    （第一版漏了，结果 repro 全成了 "复现生成失败: KeyError: 'frames'"，
    #      交付出去的"最小复现"是一段废码。）
    entry = {"round": rec["round"], "seed": rec["seed"], "stage": stage,
             "htype": rec["htype"], "verdict": verdict, "reason": reason,
             "reachable": bool(reachable), "viol": str(viol),
             "frames": rec["frames"], "vals": rec["vals"],
             "setup": rec["setup"], "ops": rec["ops"]}
    findings.append(entry)
    key = sig_of(viol) + (" ||真实路径可达" if reachable else " ||仅超范围参数")
    info = categories.get(key)
    if info is None:
        categories[key] = {"count": 1, "verdict": verdict, "reason": reason,
                           "reachable": bool(reachable), "first": entry}
    else:
        info["count"] += 1
        if verdict == "FAIL" and info["verdict"] != "FAIL":
            info["verdict"] = "FAIL"
            info["reason"] = reason
            info["first"] = entry


def run_fuzz(seed, rounds, prefix, time_budget):
    """跑 rounds 轮 fuzz，返回汇总 dict（**不写任何文件**）。"""
    t0 = time.time()
    rng = random.Random(seed)
    findings = []
    categories = {}
    baseline_hits = 0
    rounds_done = 0
    exc_rounds = 0

    for rnd in range(rounds):
        if time.time() - t0 > time_budget:
            break
        rounds_done += 1
        name = prefix % rnd
        o = act = None
        rec = {"seed": seed, "round": rnd, "frames": [], "vals": [],
               "htype": "FREE", "setup": {}, "ops": []}
        try:
            frames = rand_frames(rng)
            vals = rand_vals(rng, len(frames))
            rec["frames"] = frames
            rec["vals"] = vals
            o, act = make_obj(name, frames, vals)
            htype = FORCE_HTYPE or rng.choice(HTYPE_CHOICES)
            side = rng.choice(('left', 'right'))
            sframe = float(rng.choice(frames))
            dt = float(rng.choice(DT_POOL))
            dv = float(rng.choice(DV_POOL))
            rec["htype"] = htype
            rec["setup"] = {"frame": sframe, "side": side, "dt": dt, "dv": dv}
            setup_handles(rng, o, act, htype, sframe, side, dt, dv)

            # ---- 基线 ----
            seen_sig = set()
            try:
                cur = list(E.invariants(act, o))
            except Exception:
                cur = ["EXC: " + E.tb(300)]
            baseline_hits += len(cur)
            for v in _fresh(cur, seen_sig):
                verdict, reason = classify(v, "setup", htype, True,
                                           types_at(o, frames_in(v)))
                _record(categories, findings, rec, "setup", v, verdict, reason, True)

            # ---- 随机 1~5 个操作，**只记签名没见过的违规** ----
            #
            # ⚠️ 可达性是**本轮粘性**的：只要本轮跑过任何一个"真实路径不可达"
            #    的操作，之后观察到的违规就不能算在真实路径头上 ——
            #    因为坏值会在**后面某次 fc.update()** 才爆成 inf/nan，
            #    按"观察到的阶段"判可达性会把锅甩给无辜的那一步。
            round_reach = True
            nops = rng.randint(1, 5)
            for _k in range(nops):
                fn = rng.choice(OPS)
                oname = getattr(fn, "__name__", "?")
                reach = True
                try:
                    got = fn(rng, o, act, frames)
                    if got is None:
                        continue
                    oname, params, _res, reach = got
                    rec["ops"].append([oname, params])
                    cur = list(E.invariants(act, o))
                except Exception:
                    cur = ["EXC: " + E.tb(300)]
                    exc_rounds += 1
                eff = bool(reach) and round_reach
                round_reach = eff
                for v in _fresh(cur, seen_sig):
                    verdict, reason = classify(v, oname, htype, eff,
                                               types_at(o, frames_in(v)))
                    _record(categories, findings, rec, oname, v, verdict,
                            reason, eff)

            # ---- 收尾 update：抓"写进去被 Blender 重算掉" ----
            for fc in E.curves_of(o).values():
                try:
                    fc.update()
                except Exception:
                    pass
            cur = list(E.invariants(act, o))
            for v in _fresh(cur, seen_sig):
                verdict, reason = classify(v, "post_update", htype, round_reach,
                                           types_at(o, frames_in(v)))
                _record(categories, findings, rec, "post_update", v, verdict,
                        reason, round_reach)

        except Exception:
            exc_rounds += 1
            _record(categories, findings, rec, "round", "EXC: " + E.tb(300),
                    "SUSPECT", "单轮脚手架异常", True)
        finally:
            kill_obj(o, act)

        if (rnd + 1) % 100 == 0:
            print("[fuzz%s] 已跑 %d 轮  用时 %.1fs  发现 %d 条"
                  % ("/注入" if INJECT["on"] else "", rnd + 1,
                     time.time() - t0, len(findings)))

    return {"seed": seed, "rounds_requested": rounds,
            "rounds_done": rounds_done,
            "elapsed_s": round(time.time() - t0, 2),
            "exc_rounds": exc_rounds,
            "baseline_violations": baseline_hits,
            "findings": findings, "categories": categories}


def selfcheck():
    """★★ bug 注入自检 —— 证明这个 fuzz **真的抓得到**它该抓的违规。

    一个抓不到 bug 的测试比没有测试更危险。做法（全程只在**内存里**
    monkey-patch，绝不改产品文件）：
        对照组：原样跑 60 轮  => 必须 0 条 FAIL（否则是测试台自己在制造违规）
        注入组：让 td.write_s 故意把一轴的 dt 写歪半段
                => 必须抓到「同侧三轴 dt 不一致」的 FAIL

    自检期间强制 FORCE_HTYPE='FREE'，把"派生类型被 Blender 重算"这条
    已知边界排除掉，归因才干净。
    """
    global FORCE_HTYPE
    FORCE_HTYPE = 'FREE'
    try:
        INJECT["on"] = False
        clean = run_fuzz(777, 60, "_SCC_%04d", 60.0)
        INJECT["on"] = True
        bad = run_fuzz(778, 60, "_SCB_%04d", 60.0)
    finally:
        INJECT["on"] = False
        FORCE_HTYPE = None
    clean_fails = [f for f in clean["findings"] if f["verdict"] == "FAIL"]
    bad_fails = [f for f in bad["findings"] if f["verdict"] == "FAIL"]
    caught = [f for f in bad_fails if "同侧三轴 dt 不一致" in f["viol"]]
    return (len(clean_fails) == 0 and len(caught) > 0,
            "对照组(不注入) FAIL=%d 条；注入组 FAIL=%d 条，"
            "其中「同侧三轴 dt 不一致」%d 条"
            % (len(clean_fails), len(bad_fails), len(caught)))


def main():
    if E.td is None or E.xf is None or E.it is None or E.sc is None or E.hd is None:
        step("I0 产品模块导入", False, "E.td/xf/it/sc/hd 有 None —— 插件未加载")
        E.flush(LOG, steps)
        return

    # ---- I1：自检（bug 注入）------------------------------------------------
    try:
        sc_ok, sc_detail = selfcheck()
    except Exception:
        sc_ok, sc_detail = False, "自检本身抛异常: " + E.tb(400)
    step("I1 ★★★ bug 注入自检：故意写歪一轴 dt 必须被抓到、不注入必须 0 违规",
         sc_ok, sc_detail)

    # ---- I2：正式 fuzz ------------------------------------------------------
    res = run_fuzz(SEED, ROUNDS, "_FZ_%04d", TIME_BUDGET)
    findings = res["findings"]
    categories = res["categories"]
    fails = [f for f in findings if f["verdict"] == "FAIL"]
    notes = [f for f in findings if f["verdict"] == "NOTE"]
    susp = [f for f in findings if f["verdict"] == "SUSPECT"]

    step("I2 fuzz 跑完 %d 轮（种子 %d，用时 %.1fs）"
         % (res["rounds_done"], SEED, res["elapsed_s"]),
         res["rounds_done"] > 0,
         "请求 %d 轮 / 实跑 %d 轮 / 提前收尾=%s / 单轮异常 %d"
         % (ROUNDS, res["rounds_done"], res["rounds_done"] < ROUNDS,
            res["exc_rounds"]))

    step("I3 ★★★ 产品操作未引入任何 FAIL 级违规（整份 ok = 违规数 == 0）",
         len(fails) == 0,
         "FAIL %d 条 / NOTE %d 条 / SUSPECT %d 条；基线(造场景)违规 %d 条"
         % (len(fails), len(notes), len(susp), res["baseline_violations"]))

    order = sorted(categories.items(),
                   key=lambda kv: ({"FAIL": 0, "SUSPECT": 1, "NOTE": 2}[kv[1]["verdict"]],
                                   -kv[1]["count"]))
    idx = 4
    for key, info in order:
        v = info["verdict"]
        ex = info["first"]
        detail = ("出现 %d 次 | 首次: 轮%d 阶段=%s htype=%s 可达=%s | 原文: %s | %s"
                  % (info["count"], ex["round"], ex["stage"], ex["htype"],
                     ex["reachable"], ex["viol"][:200], info["reason"]))
        step("I%d [%s] %s" % (idx, v, key[:130]), (v != "FAIL"), detail)
        idx += 1

    E.flush(LOG, steps)

    # ---- 追加 fuzz 细节（E.flush 的 schema 之外）---------------------------
    try:
        with open(LOG, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        data = {}
    data["selfcheck"] = {"ok": bool(sc_ok), "detail": sc_detail}
    data["fuzz"] = {
        "seed": SEED,
        "rounds_requested": ROUNDS,
        "rounds_done": res["rounds_done"],
        "elapsed_s": res["elapsed_s"],
        "early_stop": res["rounds_done"] < ROUNDS,
        "time_budget_s": TIME_BUDGET,
        "exc_rounds": res["exc_rounds"],
        "baseline_violations": res["baseline_violations"],
        "fail_count": len(fails),
        "note_count": len(notes),
        "suspect_count": len(susp),
        "k_safety": K_SAFETY,
        "categories": {
            key: {"count": i["count"], "verdict": i["verdict"],
                  "reason": i["reason"], "reachable": i["reachable"],
                  "first_round": i["first"]["round"],
                  "first_stage": i["first"]["stage"],
                  "first_htype": i["first"]["htype"],
                  "example_violation": i["first"]["viol"]}
            for key, i in categories.items()},
        "findings": findings[:400],
        "findings_truncated": max(0, len(findings) - 400),
        "repro": {key: build_repro(i["first"]) for key, i in categories.items()
                  if i["verdict"] == "FAIL"},
        "repro_note": {key: build_repro(i["first"]) for key, i in categories.items()
                       if i["verdict"] == "NOTE"},
    }
    with open(LOG, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1)
        fh.flush()
        os.fsync(fh.fileno())

    print("=" * 74)
    print("fuzz 细节已写入: %s" % LOG)
    print("FAIL=%d NOTE=%d SUSPECT=%d" % (len(fails), len(notes), len(susp)))
    for f in fails[:12]:
        print("  [FAIL] 轮%d 阶段=%s htype=%s :: %s"
              % (f["round"], f["stage"], f["htype"], f["viol"][:160]))


try:
    main()
except Exception:
    step("FATAL", False, E.tb())
    E.flush(LOG, steps)

print("EXTREME_FUZZ_DONE")
