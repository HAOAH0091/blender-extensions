# -*- coding: utf-8 -*-
"""保速闸门 = 抓取环同一把尺子（屏幕 6px）—— 用户报障 2026-10-02。

用户报告
--------
> 「把 3D 视图关键帧手柄缩放至 0 出现抓取环，用户点击拖拉抓取环，拉出手柄后，
>   会发现手柄的路径手柄模式似乎变成了'改速度'不是'保速度'，
>   拖动手柄会导致关键帧处的速度改变」

根因（实测）
------------
    抓取环出现：判据 = 【屏幕 6px】（`drawing.handle_is_zero_length`）
    保速闸门  ：判据 = 【世界长度 1.0】（实测 1 世界单位 ≈ 49px）
    ⇒ 闸门关门范围比抓取环宽约 **8 倍**
    ⇒ 一个「屏幕上 24px、看得清清楚楚」的手柄（0.5 世界单位）拖它照样不保速。

修法
----
`edit_geometry._uniform_plan` 改传 `len_min = _handle_zero_local_len(...)`
—— 与抓取环**同源**（都经 `drawing.local_eps_for_screen` 换算屏幕像素→局部长度）。
方向锁（`_dir_lock` 阈值）一并换到同一来源。

⚠️ 拿不到 3D 视图（headless / 无 region）⇒ 返回 None ⇒ 退回 `xf.UNIFORM_LEN_MIN`
   （旧口径），**行为与旧版逐位一致** —— 本文件的 C2 就是钉这条。

本测试的"分级"（对齐 skill 的 §0 铁律 3：测试必须做 bug 注入）
--------------------------------------------------------------
A 组：`handle_scale_k` 的 len_min 参数（含默认向后兼容）
B 组：`_handle_zero_local_len` 的退化 / 换算行为
C 组：`_uniform_plan` 端到端（打桩阈值 ⇒ 短手柄保速）
D 组：**bug 注入** —— 把阈值退回旧口径 1.0 ⇒ C1 的条件必须 FAIL（证明测试有区分度）
E 组：静态契约（闸门与方向锁**同源**）
"""
import os
import sys
import math
import json
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
for _p in (PARENT, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import bpy
import mathutils
import _eb_common as E

from RealTimeMotionPath import edit_geometry as eg
from RealTimeMotionPath import transform_domain as xf
from RealTimeMotionPath import state as st
import RealTimeMotionPath as _R

# headless 下 `import` 不会自动 register；缺 `window_manager.rtmp_handle_scale`
# 时 `apply_handle_point_offset` 会抛（它要读全局缩放）。
if not hasattr(bpy.types.WindowManager, "rtmp_handle_scale"):
    try:
        _R.register()
    except Exception:
        pass

LOG = os.path.join(HERE, "_short_handle_keepspeed_result.json")
steps = []


def step(n, ok, d=""):
    steps.append((n, bool(ok), str(d)))


def vec_stats(obj, frame):
    """(三轴值分量模长, 平均 dt)。

    ⚠️ 保速的 k 是按**三轴向量模**算的（`handle_scale_k` 收的就是三轴序列），
       所以"速度守恒"必须用模长判 —— 拿单轴算会得出错误结论。
    """
    L2, dts = 0.0, []
    for fc in E.curves_of(obj).values():
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - frame) < 1e-3:
                h = kp.handle_right
                L2 += (float(h[1]) - float(kp.co[1])) ** 2
                dts.append(abs(float(h[0]) - float(kp.co[0])))
    return math.sqrt(L2), (sum(dts) / len(dts) if dts else None)


def kfm_of(obj, frame):
    return {fc.array_index: kp
            for fc in E.curves_of(obj).values()
            for kp in fc.keyframe_points
            if abs(float(kp.co[0]) - frame) < 1e-3}


def plan_on(obj, act, frame, side, offset):
    """问 `_uniform_plan` 本次拖动是否启用保速（返回非 None = 保速）。"""
    kfm = kfm_of(obj, frame)
    fac_l, fac_r = eg.compute_handle_display_factors(kfm)
    try:
        st._session.drag_target_object = obj.name
    except Exception:
        pass
    st._session.handle_start_values.clear()
    return eg._uniform_plan(bpy.context, act, obj, float(frame), side, None,
                            (fac_l if side == 'left' else fac_r),
                            mathutils.Vector(offset), kfm)


_ORIG = {}          # 打桩备份


def stub(name, value):
    _ORIG.setdefault(name, getattr(eg, name))
    setattr(eg, name, value)


def unstub_all():
    for k, v in _ORIG.items():
        setattr(eg, k, v)
    _ORIG.clear()


try:
    # ── A · handle_scale_k 的 len_min 参数 ────────────────────────────
    ks = xf.handle_scale_k([0.5, 0, 0], [1.0, 0, 0], [8, 8, 8], 25)
    step("A1 默认（不传 len_min）：|dv|=0.5 ⇒ None —— 旧行为逐位不变（向后兼容）",
         ks is None, repr(ks))

    ks2 = xf.handle_scale_k([0.5, 0, 0], [1.0, 0, 0], [8, 8, 8], 25, len_min=0.12)
    step("A2 注入 len_min=0.12（屏幕 6px 口径）：|dv|=0.5 ⇒ 保速启用（k 非 None）",
         ks2 is not None,
         "" if ks2 is None else "k=%.4f k_raw=%.4f" % (ks2[0], ks2[1]))

    ks3 = xf.handle_scale_k([0.0, 0, 0], [1.0, 0, 0], [8, 8, 8], 25, len_min=1e-9)
    step("A3 真零长 |dv|=0 ⇒ 即使注入极小阈值仍 None（比例数学上无定义）",
         ks3 is None, repr(ks3))

    ks4 = xf.handle_scale_k([0.12, 0, 0], [0.24, 0, 0], [8, 8, 8], 25, len_min=0.12)
    step("A4 边界 L0 == len_min ⇒ None（`<=` 语义，沿用旧口径的等号行为）",
         ks4 is None, repr(ks4))

    ks5 = xf.handle_scale_k([2.0, 0, 0], [4.0, 0, 0], [8, 8, 8], 25)
    step("A5 |dv|=2.0 ⇒ 默认即保速（改动不误伤长手柄）", ks5 is not None, repr(ks5))

    # ── B · _handle_zero_local_len（屏幕口径的唯一换算入口）────────────
    r_b1 = eg._handle_zero_local_len(bpy.context, None, None, None)
    step("B1 headless（无视图）⇒ None ⇒ 调用方退回 UNIFORM_LEN_MIN（旧行为）",
         r_b1 is None, repr(r_b1))

    o_b, a_b = E.build_object("_SK_B2", E.KEYS_3)
    stub("_view_ctx", lambda ctx: (object(), object()))
    stub("local_eps_for_screen", lambda *a, **k: 0.12)
    r_b2 = eg._handle_zero_local_len(bpy.context, o_b, None, (0.0, 0.0, 0.0))
    step("B2 有视图 ⇒ 返回 local_eps_for_screen 的换算值（0.12）",
         abs((r_b2 if r_b2 is not None else -1) - 0.12) < 1e-12, repr(r_b2))

    # ── C · _uniform_plan 端到端（短手柄 0.5）────────────────────────
    stub("_uniform_mode", lambda ctx=None: True)
    o_c, a_c = E.build_object("_SK_C", E.KEYS_3)
    E.set_handles(o_c, 0.0, 'right', dt=8.0, dv=0.5)     # 短手柄：屏幕 ≈24px

    # C1：有视图 + 屏幕口径阈值 0.12 ⇒ 0.5 > 0.12 ⇒ 保速
    stub("_handle_zero_local_len", lambda *a, **k: 0.12)
    p_c1 = plan_on(o_c, a_c, 0.0, 'right', (0.0, 0.5, 0.0))
    step("C1 ★ 短手柄 0.5 + 屏幕口径阈值 0.12 ⇒ **保速启用**（修的就是这条）",
         p_c1 is not None, "plan=%s" % ("None" if p_c1 is None else "ok"))

    # C1b：真拖一次（走完整写入路径 —— `_uniform_plan` 只是只读预演，不写）
    o_cb, a_cb = E.build_object("_SK_CB", E.KEYS_3)
    E.set_handles(o_cb, 0.0, 'right', dt=8.0, dv=0.5)
    L0, dt0 = vec_stats(o_cb, 0.0)
    st._session.drag_target_object = o_cb.name
    st._session.handle_start_values.clear()
    eg.apply_handle_point_offset(
        bpy.context, mathutils.Vector((0.0, 1.0, 0.0)),
        {"frame": 0.0, "side": "right", "bone_name": None, "obj_name": o_cb.name})
    L1, dt1 = vec_stats(o_cb, 0.0)
    # 保速 = dt 跟着「值分量伸长的倍数」一起缩 ⇒ |dv|/dt 守恒。
    # 不保速（旧行为）时 dt 恒为 8.0 不动 ⇒ 斜率被拉大。
    _s0 = (L0 / dt0) if (dt0 and L0) else -1.0
    _s1 = (L1 / dt1) if (dt1 and L1) else -1.0
    step("C1b ★ 真拖一次：|dv| %.4f→%.4f，dt %.4f→%.4f（保速=速度守恒）"
         % (L0, L1, dt0 or -1, dt1 or -1),
         dt1 is not None and dt1 > (dt0 or 0) + 1e-6
         and abs(_s1 - _s0) < 1e-3,
         "斜率 %.5f -> %.5f（dt 不动的话会是 %.5f）"
         % (_s0, _s1, (L1 / dt0) if dt0 else -1))

    # C2：拿不到视图（阈值 None）⇒ 退回旧口径 1.0 ⇒ 短手柄 0.5 不保速
    o_c2, a_c2 = E.build_object("_SK_C2", E.KEYS_3)
    E.set_handles(o_c2, 0.0, 'right', dt=8.0, dv=0.5)
    stub("_handle_zero_local_len", lambda *a, **k: None)
    p_c2 = plan_on(o_c2, a_c2, 0.0, 'right', (0.0, 0.5, 0.0))
    step("C2 ★ 无视图（阈值 None）⇒ 退回 UNIFORM_LEN_MIN ⇒ 短手柄不保速（旧行为）",
         p_c2 is None, "plan=%s" % ("None" if p_c2 is None else "ok"))

    # C3：长手柄 2.0 ⇒ 无论哪种阈值都保速（不误伤）
    o_c3, a_c3 = E.build_object("_SK_C3", E.KEYS_3)
    E.set_handles(o_c3, 0.0, 'right', dt=8.0, dv=2.0)
    stub("_handle_zero_local_len", lambda *a, **k: 0.12)
    p_c3 = plan_on(o_c3, a_c3, 0.0, 'right', (0.0, 1.0, 0.0))
    step("C3 长手柄 2.0 ⇒ 保速（屏幕口径不误伤长手柄）", p_c3 is not None, repr(p_c3))

    # ── D · bug 注入：阈值退回旧口径 1.0 ⇒ C1 的条件必须 FAIL ─────────
    o_d, a_d = E.build_object("_SK_D", E.KEYS_3)
    E.set_handles(o_d, 0.0, 'right', dt=8.0, dv=0.5)
    stub("_handle_zero_local_len", lambda *a, **k: xf.UNIFORM_LEN_MIN)   # ← 注入"旧口径"
    p_d1 = plan_on(o_d, a_d, 0.0, 'right', (0.0, 0.5, 0.0))
    step("★ D1 bug 注入：阈值退回旧口径 1.0 ⇒ 短手柄**不保速**（= 拦住，证明 C1 有区分度）",
         p_d1 is None, "plan=%s（期望 None）" % ("None" if p_d1 is None else "ok"))

    # ── E · 静态契约：闸门与方向锁同源 ───────────────────────────────
    src_eg = open(os.path.join(REPO, "edit_geometry.py"), encoding="utf-8").read()
    src_xf = open(os.path.join(REPO, "transform_domain.py"), encoding="utf-8").read()

    step("E1 静态：`_uniform_plan` 把 `_handle_zero_local_len` 的结果传给 handle_scale_k",
         "_handle_zero_local_len(context, obj, bone_name, _ref_local)" in src_eg
         and "len_min=_len_min" in src_eg)
    step("E2 ★ 静态：方向锁（两处）与闸门**同源**（都用 `_thr3`），无裸 UNIFORM_LEN_MIN 比较",
         src_eg.count("<= _thr3:") == 2
         and "<= xf.UNIFORM_LEN_MIN:" not in src_eg)
    step("E3 静态：`handle_scale_k` 签名含 len_min（默认 None ⇒ 向后兼容）",
         "def handle_scale_k(dv_base, dv_new, dt_base, span, len_min=None):" in src_xf)
    step("E4 静态：闸门用 `_len_thr`（=`UNIFORM_LEN_MIN if len_min is None else len_min`）",
         "_len_thr = UNIFORM_LEN_MIN if len_min is None else float(len_min)" in src_xf
         and "if L0 <= _len_thr:" in src_xf)

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-1200:])
finally:
    unstub_all()
    try:
        st._session.handle_start_values.clear()
    except Exception:
        pass
    for _n in ("_SK_B2", "_SK_C", "_SK_CB", "_SK_C2", "_SK_C3", "_SK_D"):
        try:
            _x = bpy.data.objects.get(_n)
            if _x:
                bpy.data.objects.remove(_x, do_unlink=True)
        except Exception:
            pass

E.flush(LOG, steps)
_fails = [s for s in steps if not s[1]]
sys.exit(1 if _fails else 0)
