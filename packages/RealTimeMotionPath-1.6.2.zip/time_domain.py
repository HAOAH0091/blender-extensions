"""RTMP 时间域编辑（第二条线：速度手柄 / 采样点疏密）

设计目标
--------
在不改变「运动路径形状」与「关键帧帧号」的前提下，调整采样点的疏密分布。

原理
----
F-Curve 每个关键帧只有 4 个可动数字：

    co[0]   帧号      → 约束②封死（不改帧号）
    co[1]   值        → 约束①封死（改它会改路径形状）
    handle[0] 时间分量 → ★ 唯一自由度
    handle[1] 值分量   → 改它 = 改形状，封死

因此调速与分布调整，只能写 handle[0]。

交互模型（C 模式，2026-09-15 定稿）
-----------------------------------
    倒三角钉在关键帧上，上下拖
      离路径越远 = 该侧越疏（采样点被拉散）
      离路径越近 = 该侧越密
      停在 CV_MID 高度 = 1.00x 匀速

实测常量（Blender 5.2.1，纯直线路径）
-------------------------------------
    s = 1/3   严格匀速（手柄共线）
    s = 1.0   手柄拉到相邻关键帧（最密）
    s = 0.02  几乎无缓动（最快 / 最疏）
    段平均疏密锁死：帧距之和恒等于段弧长
"""

import math

import bpy

# 帧号匹配容差：**全仓唯一定义在 `state`**（2026-09-29 收敛，原先本模块硬编码 1e-3）
from .state import FRAME_EPS, warn_once

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# ⚠️ 用户 2026-09-15：「速度手柄不需要设置极值限制」。
#    因此这里【不再】把 s 钳在 [0.02, 1.0]：
#      · 稀疏方向用【指数衰减】—— 永不触底（收益递减，但没有硬墙）
#      · 密集方向线性延伸 —— d >= 0 天然给出 s 上界（约 1.026）
#    S_MIN / S_MAX 仅作为「旧的参考值」保留，供映射曲线经过这两个点。
S_MIN = 0.02          # 参考点（旧的最疏值），不再作为硬限制
S_MAX = 1.0           # 参考点（手柄抵达相邻关键帧），不再作为硬限制
S_LIN = 1.0 / 3.0     # 匀速（手柄值分量共线的位置）

CV_MID = 40.0         # 屏幕上，匀速基准距关键帧的像素距离
CV_NEAR = 14.0        # 参考：最密
CV_FAR = 70.0         # 参考：最疏

# ⚠️ 双向都用【线性】映射（用户 2026-09-15 第二轮反馈：
#    「极值的设置似乎解除了上限，下限还没解除」）。
#    之前稀疏方向用指数衰减 → 实际上在 d≈300 处【触底卡住】，看起来就是"下限还在"。
#    现在两个方向都是线性，响应速率恒定、可预测。
#
# ⚠️ 这两个速率是【几何】映射：d 与 s 的对应关系（d 的锚点 CV_NEAR/CV_FAR 不能动）。
#    —— 想让鼠标"拖得更远才打满"，**不要改这里**（会破坏 d 的几何意义，
#       实测把 s=1.0 的 d 变成负数 → 三角跑到视口外）。
#    改 `DRAG_PX_SCALE`（鼠标像素 → d 的缩放）才对。
_SPARSE_RATE = (S_LIN - S_MIN) / (CV_FAR - CV_MID)   # 变疏方向：每像素 s 减多少
_DENSE_RATE = (S_MAX - S_LIN) / (CV_MID - CV_NEAR)   # 变密方向：每像素 s 加多少

# ★ 2026-09-17 手感调慢（用户实测反馈「拖动动不了 / 数值直接拉满」）：
#   实测原手感太陡：拖 30px 就到参考下界、50px 到真·下限。
#   视口高约 1000px ⇒ 3% 就打满全程，之后继续拖【毫无变化】（到底了）
#   ⇒ 用户感觉"拖不动"。
#   修法：鼠标像素 → d 乘一个 <1 的系数，等效"拖更远才打满全程"。
#     全程 d 跨度 = CV_FAR - CV_NEAR = 56px（几何）
#     想让它耗 DRAG_FULL_PX 个鼠标像素 ⇒ 系数 = 56 / DRAG_FULL_PX
DRAG_FULL_PX = 135.0     # ★ 用户拍板：拖满全程需要的鼠标像素（120~150 区间取值）
DRAG_PX_SCALE = (CV_FAR - CV_NEAR) / DRAG_FULL_PX

# 只防止 dt 变成 0（手柄落到关键帧上），不是"限制手感"
S_EPS = 1e-5
# s 的【几何】上限 = 1.0，即 dt ≤ 段长。
#
# ⚠️ 这不是"手感限制"，是【曲线有效性】的边界（用户 2026-09-16 实测反馈）：
#    设 k = dt/段长，贝塞尔时间分量 f(t) 的导数在 t=0.5 处 ∝ (1-k)。
#      k = 1 → f'(0.5)=0（驻点，仍单调，手柄正好抵达相邻关键帧的时刻）
#      k > 1 → f'(0.5)<0 → f(t) 【非单调】→ 时间上"折返"
#              → 同一段轨迹被走两遍，画出的路径出现回折/打结
#    实测：k=1.36 时出现 43 个折返采样；k=2.0 时 169 个。
#    所以 s=1.0 就是"拉到头"的理论极值（用户自己的描述也是如此：
#    「变色胀满路径就是速度拉伸至理论上几乎不会变化的极限」）。
S_HARD_MAX = 1.0

# 手柄类型中「坐标由 Blender 导出、不接受外部写入」的那些
DERIVED_HANDLE_TYPES = {'AUTO', 'AUTO_CLAMPED'}


# ---------------------------------------------------------------------------
# 纯数学（无 bpy 依赖，可直接单元测试）
# ---------------------------------------------------------------------------

def clamp01(v):
    return 0.0 if v < 0.0 else (1.0 if v > 1.0 else v)


def d_to_s(d):
    """屏幕垂直距离 d（像素） -> s。

    **双向线性、无手感限制**（用户 2026-09-15 两轮反馈后定稿）：
      · d >= CV_MID（更疏）：s 每像素线性下降，直到 S_EPS（dt>0 的物理下限）
      · d <  CV_MID（更密）：s 每像素线性上升，可以越过 S_MAX（即 d 可以为负）
    d 本身【不再被钳到 >= 0】，所以"拖过关键帧还能继续变密"。
    """
    if d is None:
        return S_LIN
    if d >= CV_MID:
        s = S_LIN - (d - CV_MID) * _SPARSE_RATE
    else:
        s = S_LIN + (CV_MID - d) * _DENSE_RATE
    return max(S_EPS, min(s, S_HARD_MAX))


def s_to_d(s):
    """s -> 屏幕垂直距离 d（d_to_s 的逆）—— **带钳制**，用于【绘制】。

    ⚠️⚠️ 别用它当**拖拽起点**！钳制会丢掉"超出范围"的信息：
      · Graph Editor 里拖手柄可以让 s = dt/span 超出 [S_EPS, 1.0]
        （实测：手柄拖过相邻关键帧 → s=7.69；贴到关键帧 → s=0.0008）
      · 钳制后 d 会钉在边界（-34.25 / 104.47）
      · 拿它当拖拽起点 ⇒ 增量叠加在错基线上 ⇒ **一动就"打满"或"完全不动"**
        （2026-09-17 用户实测报告）
    ⇒ 拖拽起点请用 `s_to_d_unclamped`（保持可逆），或直接用 s。
    """
    if s is None:
        return CV_MID
    s = max(S_EPS, min(float(s), S_HARD_MAX))
    if s <= S_LIN:
        return CV_MID + (S_LIN - s) / _SPARSE_RATE
    return CV_MID - (s - S_LIN) / _DENSE_RATE


def s_to_d_unclamped(s):
    """s -> d，**不钳制**（`d_to_s` 到这个 d 能还原同一个 s）。

    ★★★ 2026-09-17：**给【拖拽起点】用**（修「先动 GE 手柄 → 拖三角打满/卡死」）。

    病根：Graph Editor 里拖手柄会让 s = dt/span **超出** [S_EPS, S_HARD_MAX]
      （实测：手柄拖过相邻关键帧 → s=7.69；贴到关键帧 → s=0.0008）。
      而 `s_to_d` 会把 s 钳制回范围 ⇒ d 被钉在边界。
      旧的拖拽起点直接取那个**钳制后的 d** ⇒ 增量叠加在错基线上：
        · 往更极端方向拖 → d 仍被钳 → 三角/数值纹丝不动（"拖不动"）
        · 往回拖 → d 突然进入有效区 → 数值猛跳（"打满"）
      （G 模态用固定基准 CV_MID，不读这个 d，所以不受影响 —— 与用户观察一致。）

    本函数不做钳制 ⇒ d 忠实反映 s（可能跑出 [CV_NEAR, CV_FAR]），
    「起点 + 增量」因此连续、可逆。配合 `d_to_s` 使用即可。
    """
    if s is None:
        return CV_MID
    s = float(s)
    if s <= S_LIN:
        return CV_MID + (S_LIN - s) / _SPARSE_RATE
    return CV_MID - (s - S_LIN) / _DENSE_RATE


def group_drag_s(s_base, signed_px):
    """⚠️ **已废弃**（2026-09-19 语义变更）—— 保留仅为兼容，产品已不再调用。

    旧语义：一体拖动 = 两侧写**同一个 s**（用户 2026-09-18 拍板"一个旋钮"）。
    新语义（用户 2026-09-19 拍板）：一体 = 两侧**各加减同一增量**、差异保留
      ⇒ 产品改为「每侧各自的 unclamped d + 同一 signed_px」，见
        `interaction._apply_speed_from_drag` 与 `modal_edit.SpeedDragModal.apply`。
    用户原话：「一体化锁定的定义应该是可以同时做增量调整，不是改变稀疏数值为相同」。

    ---- 以下为旧说明（历史）----
    2026-09-18：**「一体」拖动**时的共用 s —— 两侧写同一个值。

    用户拍板（乙方案）：一体 = 一个旋钮，两边速度**始终相同**、同向变。

    为什么不能沿用"各边从自己的 d0 起算"：
      两侧的 span 不同 ⇒ 同一个像素位移落在数据上得到**不同的 s** ⇒
      左边变快、右边变慢（"旋钮"变成"剪刀"）。

    做法：像素位移先还原成 s 空间的等价位移（几何映射与 span 无关），
          加在**共用的基准 s** 上 ⇒ 两边写同一个 s。

    ⚠️ 用 `s_to_d_unclamped`（不钳制）—— 起点 s 可能超出 [S_EPS, S_HARD_MAX]
       （用户在 Graph Editor 里拖过手柄），钳制会让"一动就跳"。
    """
    if s_base is None:
        return None
    return d_to_s(s_to_d_unclamped(float(s_base)) + float(signed_px))


def extremeness(s):
    """0..1：离匀速有多远（用于路径段高亮的"胀满"程度）。

    0   = 匀速（1.00x），高亮长度 0
    1   = 到达理论极值，高亮胀满整段
    """
    if s is None:
        return 0.0
    if s <= S_LIN:                       # 变疏方向：s -> S_EPS
        t = (S_LIN - s) / (S_LIN - S_EPS)
    else:                                # 变密方向：s -> S_HARD_MAX(=1.0)
        t = (s - S_LIN) / max(S_HARD_MAX - S_LIN, 1e-9)
    return clamp01(t)


def pixels_to_s(px_offset):
    """从匀速基准起算的像素偏移 -> s（正 = 向下 = 更疏）"""
    return d_to_s(CV_MID + px_offset)




# ---------------------------------------------------------------------------
# 关键帧收集（复用插件既有工具）
# ---------------------------------------------------------------------------

_collect_all = None
_is_pos = None

try:
    from .cache import (collect_animation_curves as _collect_all,
                        is_position_animation as _is_pos)
except Exception:      # 独立导入（非包上下文）时退化
    try:
        from cache import (collect_animation_curves as _collect_all,
                           is_position_animation as _is_pos)
    except Exception:
        _collect_all = None
        _is_pos = None


def _collect_position_curves(action, obj, bone_name=None):
    """收集物体/骨骼的位移 F-Curve。

    ⚠️ 必须用插件自己的 `cache.collect_animation_curves` —— 它内部走
       `_resolve_slot()` 正确解析 action slot。**不要自己写
       `action.slots[0]` 那种退化扫描**：Blender 5.x 的 layered action 下
       slot 解析错误会拿到"另一条曲线"，表现为「写进去了但求值不变」的
       诡异 bug（已亲身踩过）。
    """
    if _collect_all is not None and _is_pos is not None:
        try:
            return [fc for fc in _collect_all(action, obj) if _is_pos(fc, bone_name)]
        except Exception:
            warn_once("time_domain._collect_position_curves")
            pass
    return []


def collect_frame_keyframes(action, obj, frame, bone_name=None):
    """收集某一帧上，各位移轴的关键帧 -> {array_index: keyframe}"""
    out = {}
    for fc in _collect_position_curves(action, obj, bone_name):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - frame) < FRAME_EPS:
                out[fc.array_index] = kp
                break
    return out


def fcurve_of(action, obj, array_index, bone_name=None):
    for fc in _collect_position_curves(action, obj, bone_name):
        if fc.array_index == array_index:
            return fc
    return None


def segment_span(fcurve, keyframe, side):
    """该侧手柄所在的段长（帧数）。left = 上一关键帧→当前；right = 当前→下一关键帧。
    端点段（首帧的 left / 末帧的 right）返回 None。"""
    pts = list(fcurve.keyframe_points)
    idx = None
    for i, kp in enumerate(pts):
        if kp is keyframe or abs(kp.co[0] - keyframe.co[0]) < 1e-9:
            idx = i
            break
    if idx is None:
        return None
    if side == 'left':
        if idx == 0:
            return None
        return float(keyframe.co[0] - pts[idx - 1].co[0])
    if idx >= len(pts) - 1:
        return None
    return float(pts[idx + 1].co[0] - keyframe.co[0])


# ---------------------------------------------------------------------------
# 读写 s
# ---------------------------------------------------------------------------

def read_s(keyframe, span, side):
    """读该侧当前的 s = dt / 段长"""
    if not span or span <= 1e-9:
        return None
    if side == 'left':
        dt = abs(keyframe.co[0] - keyframe.handle_left[0])
    else:
        dt = abs(keyframe.handle_right[0] - keyframe.co[0])
    return dt / span


# ---------------------------------------------------------------------------
# 「被速度编辑冻结过」的关键帧登记表
#
# 用途：这些关键帧的两侧都是 FREE。而插件的手柄联动
#       （`RTMP_OT_PathPointDrag.update_linked_handle`）在"两侧都 FREE"时会直接
#       早退 —— 于是用户在 3D 视图里拖手柄不再联动，反馈为"交互变得很奇怪"。
#       登记后，联动对【插件自己冻结的】关键帧继续生效。
#
# 键：(action 名, 帧号) —— action 名在同文件内唯一；帧号取整。
#
# ★★ 2026-09-17：**持久化**（用户拍板）。
#
#   与 `transform_domain._plugin_owned_free`（手柄接管名单）同类：
#   两者记的都是「插件的意图」，只活在内存里 ⇒ 重开 .blend 就丢。
#   后果：速度编辑过的关键帧重开文件后退化成"用户手动 FREE"
#   （`_link_mode` 判 'free'）⇒ 拖一侧手柄、对侧不联动。
#
#   修法照抄 owned_free 那套（已验证过的模式）：
#     · 登记同时写进 `act["rtmp_frozen"]`（action 的 custom property）
#     · 读的时候惰性恢复一次（`warm_frozen`）—— 不挂 handler，
#       天然覆盖"刚打开文件 / 新建 / 复制 action"
#   ⚠️ 键本来就是 `(action 名, 帧号)`（不是内存地址），所以**不用改键**。
# ---------------------------------------------------------------------------
_FROZEN = {}
_frozen_warmed = set()          # 已从 custom property 恢复过登记的 action 名
# ★★ 2026-09-19：对账源（同 `transform_domain._TRILOCK_SRC`）——
#    撤销/重做改的是 custom property，每次读之前对一次账就天然被感知，不依赖 handler。
_FROZEN_SRC = {}


def _td_cache_has_entries(name):
    """该 action 在冻结内存表里还有条目吗？（对账的第二重判据，见 `_frozen_sync`）"""
    try:
        for k in _FROZEN:
            if k[0] == name:
                return True
    except Exception:
        return False
    return False

_FROZEN_PROP = "rtmp_frozen"    # action 上的 custom property 名


# ---------------------------------------------------------------------------
# 持久化读写（action 的 custom property）
# ---------------------------------------------------------------------------

def _frozen_token(frame, owner=""):
    """登记项在 custom property 里的字符串形式。

    ★ 2026-09-27（3f）：从 `"%d" % int(round(...))` 改成 `"%.4f"` ——
      与同仓另外三张表的量化口径对齐（`_feel_key_of` / `_own_key` /
      `_trilock_key_of` 都是 `round(frame, 4)`）。

    ⚠️ 原先的整数帧会**撞键**：14.2 与 14.4 都写成 "14" ⇒
      · 两个不同关键帧共享一条登记 ⇒ mark/unmark 对**不同对象**不再对称
      · 而 `mark_frozen` 会把 `_frozen_key` 算出的帧号**转手喂给体感表**
        （`mark_feel_at(action, k[1], ...)`）⇒ 给 14.4 写的记录落在 14.0 头上，
        反过来会**覆盖掉用户在 14.0 手动设的「不动(FREE)」**。
    """
    # ★★★ 2026-09-30（D-1/D-2）：token 从 **1 段**变 **2 段**（末尾多了 owner）。
    #   一个角色 action 里所有骨骼共用它 ⇒ 同帧必然撞键：
    #   实测给 BoneB 冻结之后，BoneA 同帧也被算成「被冻过」。
    #   ⚠️ 只认 2 段；1 段是旧格式（没署名）—— 用户拍板不做向下兼容 ⇒ 忽略。
    return "%.4f|%s" % (float(frame), str(owner or ""))


def _frozen_parse(tok):
    # '14.0000|BoneA@OBArm' → (14.0, 'BoneA@OBArm')，畸形返回 None。
    # ⚠️ 兼容 1 段旧格式？**不**（用户 2026-10-01 拍板不做向下兼容）——
    #   1 段的返回 None ⇒ 被忽略，并在下一次写入时顺手清掉。
    try:
        parts = str(tok).split("|")
        if len(parts) != 2:
            return None
        return (round(float(parts[0]), 4), str(parts[1]))
    except Exception:
        warn_once("time_domain._frozen_parse")
        return None


def frozen_tokens(act):
    """读 action 上持久化的登记项（字符串列表）。拿不到就返回空列表。"""
    try:
        v = act.get(_FROZEN_PROP)
    except Exception:
        return []
    if not v:
        return []
    try:
        return [str(x) for x in v]
    except Exception:
        try:
            return [str(v)]
        except Exception:
            return []


def _write_frozen_tokens(act, tokens):
    try:
        act[_FROZEN_PROP] = sorted(set(str(t) for t in tokens))
        return True
    except Exception:
        return False


def _frozen_sync(act):
    """★★ 让「冻结登记表」与 action 的 custom property **对账**。

    机理同 `transform_domain._trilock_sync`：property 是唯一真相，缓存只是派生；
    撤销 / 重做改的是 property ⇒ 每次读之前对一次账就天然被感知。
    """
    if act is None:
        return
    try:
        nm = getattr(act, "name", None)
    except Exception:
        return
    if not nm:
        return
    try:
        act.get(_FROZEN_PROP)            # ★ 读不了 ⇒ 保持缓存不动（理由见 `_trilock_sync`）
    except Exception:
        return
    # ★★ D-4 僵尸词条：必须在**快路径之前**清（理由见 transform_domain.prune_zombie_tokens）
    try:
        from . import transform_domain as _xf
        _pruned = _xf.prune_zombie_tokens(act, nm, _FROZEN, _frozen_parse,
                                          frozen_tokens, _write_frozen_tokens)
    except Exception:
        _pruned = False
    if _pruned:
        _FROZEN_SRC[nm] = tuple(frozen_tokens(act))
        return
    raw = tuple(frozen_tokens(act))
    # 快路径：property 没变 **且** 缓存条目还在。
    # ⚠️ 第二重判据必需：外部只清空内存镜像时（模拟"重开文件"），
    #    对账源还留着 ⇒ 只看 SRC 会误判"缓存有效"，永远不再恢复。
    if _FROZEN_SRC.get(nm) == raw and (not raw or _td_cache_has_entries(nm)):
        return
    for k in [k for k in list(_FROZEN.keys()) if k[0] == nm]:
        _FROZEN.pop(k, None)
    # ★ 僵尸词条自查（D-4）：指向**已删关键帧**的记录要在对账时丢掉，
    #   否则同帧重新插关键帧时它会静默复活。判据与另外三张表共用同一份实现。
    try:
        from . import transform_domain as _xf
        frames = _xf.action_frames(act)
    except Exception:
        frames = None
    kept = []
    dropped = False
    for tok in raw:
        p = _frozen_parse(tok)
        if p is None:
            continue                 # ★ 旧格式（没署名）⇒ 忽略（不做向下兼容）
        frame, owner = p
        if frames is not None and round(float(frame), 4) not in frames:
            dropped = True           # ★ 指向已删关键帧 ⇒ 僵尸
            continue
        kept.append(str(tok))
        _FROZEN[(nm, frame, owner)] = True
    if dropped:
        try:
            _write_frozen_tokens(act, kept)
            raw = tuple(frozen_tokens(act))
        except Exception:
            pass
    _FROZEN_SRC[nm] = raw
    _frozen_warmed.add(nm)


def warm_frozen(act):
    """（兼容名）把既有登记同步进内存镜像 —— 语义见 `_frozen_sync`。"""
    _frozen_sync(act)


def _frozen_key(action, frame, owner=""):
    """★★【唯一的】冻结表键 —— `(action 名, 帧号)`。

    ⚠️ 必须是**唯一来源**：`mark_frozen` / `unmark_frozen` / `is_frozen` 三处
       都要用它。实测教训（2026-09-17，bug 注入）：
       三处各写一份键的计算时，只改其中一处的注入**行为测试抓不到**
       （mark 存地址键、is 查名字键 → 恰好都"能跑"，只有跨会话才暴露）。
       与 `transform_domain._own_key` 同一条规矩：同一语义的判据只能有一份。

    ⚠️ 用 action **名**而不是 `as_pointer()`：名存在 .blend 里、跨会话稳定；
       内存地址重载即失效，还可能被复用误伤新 action。

    ★ 2026-09-27（3f）：帧号口径从 `int(round(...))` 改成 `round(..., 4)`，
      与同仓另外三张表一致（见 `_frozen_token` 的说明：整数帧会撞键、
      并会把子帧帧号串到整数帧头上）。
    """
    # ★★★ 2026-09-30（D-1/D-2）：**加了第 3 段 owner**（哪根骨骼/哪个 slot）。
    #   以前只有前两段 ⇒ 一个角色 action 里所有骨骼共用它 ⇒ 同帧必然撞键。
    return (getattr(action, "name", None), round(float(frame), 4),
            str(owner or ""))


def mark_frozen(action, frame, owner=None, supersede=False):
    # 登记「这个关键帧被插件的速度编辑冻过」⇒ 后续继续联动。**并持久化到 action。**
    #
    # ★ 2026-09-17（方案 A）：同时把**两侧**的【体感类型】记成 'LINK'
    #   —— 速度编辑冻的是「要联动」，这正是体感表要表达的权威语义。
    #
    # ★★★ 2026-09-30（D-1/D-2）：多了 `owner`（这根手柄是谁的）。
    #   ⚠️ 本函数**没有关键帧对象** ⇒ owner 只能由调用方给。
    #      调用方必须用 `xf.owner_of_curve(fc)` / `owner_of_keyframe(kp)` 算 ——
    #      那是**同一套拼装**，否则写进去的记录查不回来（读成「未记录」）。
    try:
        k = _frozen_key(action, frame, owner)
    except Exception:
        return False
    _FROZEN[k] = True
    try:
        toks = []
        for t in frozen_tokens(action):
            p = _frozen_parse(t)
            if p is None:
                continue                     # ★ 旧格式 ⇒ 顺手清掉
            if (p[0], p[1]) == (k[1], k[2]):
                continue                     # 同一个格子 ⇒ 用新的替换
            toks.append(str(t))
        toks.append(_frozen_token(k[1], k[2]))
        _write_frozen_tokens(action, toks)
        _FROZEN_SRC[str(action.name)] = tuple(frozen_tokens(action))   # ★ 同步对账源
    except Exception:
        pass
    # ★ 方案 A：体感记录（两侧都是"要联动"）—— 只按 (action, 帧号, 侧)，不需要 kp
    #
    # ★★ 2026-09-30 修复（用户报「FREE 体感一用三角控制柄就被切回对齐」）：
    #    **已登记的体感不覆盖** —— 用户主动设的 FREE 必须保留。
    #    （冻结只是"防 Blender 重算"，不该顺手改用户的选择。）
    #    ⚠️ 与 `spec_check._freeze_keyframe` 同口径。
    #    未记录时才写 LINK：那是"原始类型是 ALIGNED/AUTO ⇒ 保持联动"的语义，
    #    由 `freeze_handle_side` 在转类型前已经登记好；这里只兜底。
    try:
        from . import transform_domain as _xf
        for _side in ('left', 'right'):
            if (not supersede
                    and _xf.feel_type_at(action, k[1], _side, owner=owner) is not None):
                continue                    # ★ 用户已选过 ⇒ 不动
            # ★★ 2026-10-02（用户实测的边界 bug）：`supersede=True` 时**强制改写**。
            #    用在「该侧手柄的长度**视觉为零**」（屏幕上出现空心环）时 ——
            #    此时旧的『用户手动 FREE』已被新指令取代：长度已经是 0，
            #    那条"手动设定的长度"不存在了。
            #    ⚠️ 判据由调用方给出（`write_s` → `value_len_is_visual_zero`），
            #       **必须**是「值分量视觉为零」，不能是「时间分量比例到下限」
            #       —— 三角拉满同样会让时间分量到下限，但长度毫发无损。
            #    ⚠️ 不这么做的话：调过手柄的那一侧体感仍是 'FREE'，
            #       而 `_link_mode` **只看对侧** ⇒ 拖另一侧的抓取环时对侧不联动
            #       ⇒ 用户看到"只能拉出其中一侧"（实测复现）。
            _xf.mark_feel_at(action, k[1], _side, 'LINK', owner=owner)
    except Exception:
        warn_once("time_domain.mark_frozen.feel")
    return True


def unmark_frozen(action, frame, owner=None):
    # 取消登记（该关键帧不再被冻时调用，防陈旧条目）。
    #
    # ★ 方案 A：同时清掉体感记录 ⇒ 该帧两侧回到「透传原始类型」。
    # ★★★ 2026-09-30（D-1/D-2）：`owner` 说明同 `mark_frozen`。
    try:
        k = _frozen_key(action, frame, owner)
    except Exception:
        return False
    _FROZEN.pop(k, None)
    try:
        toks = []
        for t in frozen_tokens(action):
            p = _frozen_parse(t)
            if p is None:
                continue                     # ★ 旧格式 ⇒ 顺手清掉
            if (p[0], p[1]) == (k[1], k[2]):
                continue                     # 就是这个格子 ⇒ 删掉
            toks.append(str(t))
        _write_frozen_tokens(action, toks)
        _FROZEN_SRC[str(action.name)] = tuple(frozen_tokens(action))   # ★ 同步对账源
    except Exception:
        pass
    try:
        from . import transform_domain as _xf
        _xf.unmark_feel_at(action, k[1], 'left', owner=owner)
        _xf.unmark_feel_at(action, k[1], 'right', owner=owner)
    except Exception:
        pass
    return True


def is_frozen(action, frame, bone_name=None, slot=None, owner=None):
    # ★★★ 2026-09-30（D-1/D-2）—— 读写不对称，与 `xf.is_tri_locked` 同一套规矩：
    #   · 指名 ⇒ 先精确、再退「未知」桶（拿不到 owner 的路径写在那里，按老语义读）
    #   · 裸调 ⇒ **通配**：同 (action, 帧) 任一条命中就返回
    #     为什么：裸调是老代码与测试的既有用法，不通配的话它们**全部**读成 False
    #     （= 「没冻过」）⇒ 联动行为会悄悄变。
    _wild = (owner is None and bone_name is None and slot is None)
    # ★★ 每次查询前对账（撤销/重做改的是 property）—— 不依赖任何 handler。
    try:
        _frozen_sync(action)
    except Exception:
        pass
    try:
        nm = str(getattr(action, "name", None))
        fr = round(float(frame), 4)
    except Exception:
        return False
    if not _wild:
        from . import transform_domain as _xf
        # ⚠️ 必须走 `_frozen_key`（**唯一来源**）—— T11b 静态契约钉的就是这个：
        #    mark / unmark / is_frozen 三处各写一份键 = 同一语义两份判据
        #    （本项目 2026-09-17 实测漏抓过）。
        k = _frozen_key(action, frame, _xf._resolve_owner(owner, bone_name, slot))
        if not k:
            return False
        if _FROZEN.get(k):
            return True
        # ★ 退「未知」桶（与 `xf._feel_lookup` 同口径）——按老语义（全局）读。
        return bool(_FROZEN.get((k[0], k[1], "")))
    hits = [(str(kk[2]) if len(kk) > 2 else "", v)
            for kk, v in _FROZEN.items()
            if kk[0] == nm and kk[1] == fr]
    if not hits:
        return False
    hits.sort(key=lambda x: (x[0] != "", x[0]))
    return bool(hits[0][1])


def clear_frozen(action=None):
    """清登记（action=None 时全清）。"""
    if action is None:
        _FROZEN.clear()
        _frozen_warmed.clear()
        _FROZEN_SRC.clear()              # ★ 对账源一起清
        return
    nm = getattr(action, "name", None)
    for k in [k for k in _FROZEN if k[0] == nm]:
        _FROZEN.pop(k, None)
    _frozen_warmed.discard(nm)
    _FROZEN_SRC.pop(nm, None)
    try:
        if _FROZEN_PROP in action:
            del action[_FROZEN_PROP]
    except Exception:
        pass
    # ★ 方案 A：该 action 的体感记录也一并清掉（回透传）
    try:
        from . import transform_domain as _xf
        _xf.clear_feel(action)
    except Exception:
        pass


def freeze_handle_side(keyframe, side):
    """只把【被编辑的那一侧】转成 FREE，并保持坐标不变。

    ⚠️ 为什么只冻一侧（用户 2026-09-15 第二轮反馈后定稿）

      实测（tests/_hdtype2.py）：
        保持 FREE   → dt 精确 1.9500，handle[1] 未被改，形状 ≈ 不变
        恢复 ALIGNED → dt 偏成 2.366（-21%），handle[1] 被改（5.60→4.87），
                       路径偏差 0.278（是 FREE 的 4.3 倍）

      原因：ALIGNED 要求 handle_left、co、handle_right **三点共线**；
      改【时间分量】必然破坏共线 → Blender 只能去改【值分量】来恢复
      → 值分量一变，路径形状就变了。所以"改了时间分量还想保持 ALIGNED"
      数学上不可能两全 → 被编辑侧必须是 FREE。

      但【没必要把另一侧也冻掉】：
      插件的手柄联动 `update_linked_handle` 只在"两侧都 FREE"时才跳过，
      只冻一侧 → 另一侧保持原类型 → 联动照常工作，
      这就是"速度编辑后 3D 视图交互变得很奇怪"的修复点。
    """
    # ★★ 2026-09-30 修复（用户报「FREE 体感一用三角控制柄就被切回对齐」）：
    #    转类型【之前】必须先把【体感】定下来 —— 否则原类型丢了，事后无法还原，
    #    而 `mark_frozen` 会**无条件**写成 LINK，把用户主动设的 FREE 冲掉。
    #
    #    ⚠️ 口径与 `spec_check._freeze_keyframe` 完全一致：
    #       「未记录时才写；已记录的不覆盖用户的选择」
    #       （那个函数早就做对了，本函数漏了 —— 同一插件两条路径口径不一致。）
    try:
        from . import transform_domain as _xf
        if _xf.feel_type(keyframe, side) is None:
            _orig = str(keyframe.handle_left_type if side == 'left'
                        else keyframe.handle_right_type)
            _feel = _xf.feel_for_orig_type(_orig)
            if _feel is not None:
                _xf.mark_feel(keyframe, side, _feel)
    except Exception:
        warn_once("time_domain.freeze_handle_side.feel")
    if side == 'left':
        hl = keyframe.handle_left.copy()
        keyframe.handle_left_type = 'FREE'
        keyframe.handle_left = hl
    else:
        hr = keyframe.handle_right.copy()
        keyframe.handle_right_type = 'FREE'
        keyframe.handle_right = hr
    return keyframe


def neighbor_frame(act, obj, frame, side, bone_name=None):
    """该段【另一端】的关键帧帧号（端点段返回 None）。"""
    if act is None or obj is None:
        return None
    try:
        from . import transform_domain as xf
    except Exception:
        return None
    try:
        fr = sorted({round(float(kp.co[0]), 4)
                     for fc in xf._position_curves(act, obj, bone_name)
                     for kp in fc.keyframe_points})
    except Exception:
        warn_once("time_domain.neighbor_frame")
        return None
    f = round(float(frame), 4)
    if f not in fr:
        return None
    i = fr.index(f)
    if side == 'right':
        return fr[i + 1] if i + 1 < len(fr) else None
    return fr[i - 1] if i - 1 >= 0 else None


def freeze_keyframe_pair(act, obj, frame, side, bone_name=None, supersede=False):
    """冻结【被编辑关键帧】+【该段另一端邻居】的【两侧】手柄。

    ⚠️ 为什么要冻这么多（2026-09-16 实测确定，见 tests/_shp4.py）：

      编辑 f14 右段时，只冻 f14 → 形状仍变（f27 的 AUTO_CLAMPED 被 Blender 重算）；
      冻 {f14, f27} → 形状变化 = 0.000000000（完全不变）。

      原因：AUTO / AUTO_CLAMPED 是【派生类型】，Blender 会在曲线变化后重算它们，
      而重算会改掉手柄的【值分量】—— 值分量是 3D 形状的唯一决定因素，
      所以对侧那一段就被拉变形了（正是用户报的「拉下方三角，左边路径变形」）。
      同理，被编辑关键帧自己若保持 ALIGNED，其【对侧】手柄也会被重算。

      ⇒ 唯一稳定做法：把涉及的两个关键帧的**两侧**都转成 FREE。
    """
    if act is None or obj is None:
        return
    targets = [frame]
    nb = neighbor_frame(act, obj, frame, side, bone_name)
    if nb is not None:
        targets.append(nb)
    try:
        from . import transform_domain as xf
        curves = xf._position_curves(act, obj, bone_name)
    except Exception:
        warn_once("time_domain.freeze_keyframe_pair")
        return
    # ★★★ 2026-09-30（D-1/D-2）：owner 从**曲线本身**算 ——
    #    `owner_of_curve` 与账本查询侧的 `owner_of_keyframe` 用的是**同一套拼装**
    #    （骨骼名来自 data_path、slot 来自它所在的 channelbag）⇒ 写读必然一致。
    #    ⚠️ 别改成"从 obj 猜"：那是另一条推导路径，迟早与曲线侧漂移。
    _owner = ""
    try:
        if curves:
            _owner = xf.owner_of_curve(curves[0])
    except Exception:
        _owner = ""
    for fc in curves:
        for kp in fc.keyframe_points:
            f = round(float(kp.co[0]), 4)
            # ⚠️ 容差 1e-3（不是 0.5）—— 帧号是 float32，误差约 1e-6；
            #    而关键帧可以只相隔 0.4 帧，用 0.5 会误匹配相邻关键帧
            if any(abs(f - round(float(t), 4)) < FRAME_EPS for t in targets):
                freeze_handle_side(kp, 'left')
                freeze_handle_side(kp, 'right')
    # 登记：让插件的手柄联动对这些关键帧继续生效
    # ★ 2026-10-02：`supersede` **只作用于被编辑帧**（`frame`）——
    #   邻居只是被顺手冻的，它的体感不该被改写。
    for _i, t in enumerate(targets):
        mark_frozen(act, t, owner=_owner,
                    supersede=bool(supersede and _i == 0))


def value_len_is_visual_zero(obj, bone_name, kf_map, side):
    """该侧手柄的【值分量】长度是否「视觉为零」= 屏幕上该出现空心抓取环。

    ★★★ 2026-10-02（用户实测的边界 bug）：`supersede` 的判据**必须**用值分量，
        不能用 `s`（时间分量比例）。

    ▎为什么（实测）
       · `write_s` 写的是 **handle[0]（时间分量）**；
       · 而「手柄有多长 / 空心环出不出来」看的是 **handle[1]（值分量）**
         （绘制侧 `drawing` 组装的世界向量只由值分量构成，dt 完全不参与）。
       · 三角拉满（疏）会把 s 压到下限 `S_EPS`，但值分量**一点没变** ——
         实测：`d=120` 时 s→S_EPS、dt=0.001，而对手柄值分量**仍是 0.85**。
       ⇒ 旧判据 `s == S_EPS` 会把「三角拉满」**误判成**「手柄被缩成零长」，
         于是把用户手动设的『不动(FREE)』**静默覆盖成 LINK**（联动被打开）
         ⇒ 用户报「三角拉满后再拖手柄 = 改速度」（对侧跟着动，速度分布被改）。

    ▎口径（与空心环同源）
       与 `drawing.handle_is_zero_length`（绘制侧**唯一**判据）走同一套换算：
       都经 `drawing.local_eps_for_screen` 把「屏幕 6px」换算成**局部**长度
       （含父级缩放 ps 与 `rtmp_handle_scale` gs —— 少一项就差 ps·gs 倍）。
       拿不到视图时退化为 `HANDLE_ZERO_EPS`（与绘制侧同一个退化口径）。
    """
    try:
        if not kf_map or obj is None:
            return False
        import mathutils as _mu
        v = [0.0, 0.0, 0.0]
        co = [0.0, 0.0, 0.0]
        for ax, kp in kf_map.items():
            try:
                i = int(ax)
            except Exception:
                continue
            if not (0 <= i <= 2):
                continue
            h = kp.handle_left if side == 'left' else kp.handle_right
            v[i] = float(h[1]) - float(kp.co[1])
            co[i] = float(kp.co[1])
        vlen = math.sqrt(sum(c * c for c in v))

        from .cache import resolve_parent_transform
        from . import drawing as _dr
        bone = None
        if bone_name and obj.mode == 'POSE' and obj.pose:
            bone = obj.pose.bones.get(bone_name)
        pm = resolve_parent_transform(obj, bone)
        gs = 1.0
        try:
            gs = float(bpy.context.window_manager.rtmp_handle_scale)
        except Exception:
            gs = 1.0
        region, rv3d = _dr._view_ctx(bpy.context)
        thr = _dr.local_eps_for_screen(bpy.context, pm @ _mu.Vector(co), pm, gs,
                                       region=region, rv3d=rv3d)
        return vlen <= float(thr)
    except Exception:
        warn_once("time_domain.value_len_is_visual_zero")
        return False


def write_s(kf_map, side, s, span, freeze=True, act=None, obj=None, bone_name=None):
    """把 s 写到该帧的【所有轴】（三轴同步），并（默认）把手柄转成 FREE。

    返回真实写入的 s（可能因端点 / 无 span 而未写）。
    """
    if not span or span <= 1e-9 or not kf_map or s is None:
        return None
    # 手感上不限制；只保证 dt 落在 (0, 段长] —— 上界是"曲线有效性"边界，见 S_HARD_MAX
    s = max(S_EPS, min(float(s), S_HARD_MAX))
    dt = s * span
    if freeze:
        # ★ 被编辑关键帧的【两侧】必须冻 —— kf_map 里就有，无条件做。
        #   （只冻"被编辑的那一侧"会导致：对侧若是 ALIGNED，Blender 会重算它
        #     → 改掉值分量 → 对侧那一段变形。实测 Δ=0.267。）
        for _ax, _kp in kf_map.items():
            freeze_handle_side(_kp, 'left')
            freeze_handle_side(_kp, 'right')
        # ★ 邻居关键帧也必须冻（它可能是 AUTO/AUTO_CLAMPED，同样会被重算）
        #   需要 act/obj 才能定位；调用方没传时跳过（降级但不报错）。
        try:
            _f0 = round(float(next(iter(kf_map.values())).co[0]), 4)
        except Exception:
            _f0 = None
        # ★★★ 2026-10-02（第二个边界 bug，用户实测）：判据是
        #    「该侧手柄的**值分量**是否视觉为零」，**不是** `s`。
        #
        #    来历：本行原为 `_at_floor = abs(s - S_EPS) <= 1e-12`，
        #    理由写着"s 被夹到下限 = 用户把长度拖到了最小 ⇒ 产生空心态"。
        #    但 `write_s` 写的是**时间分量**，而空心环看的是**值分量** ——
        #    **三角拉满（疏）同样会把 s 压到 S_EPS，而值分量一点没变**
        #    （实测 `d=120`：s→S_EPS、dt=0.001，值分量仍是 0.85）。
        #    ⇒ 旧判据把「三角拉满」误判成「手柄缩成零长」，
        #      把用户手动设的『不动(FREE)』**静默覆盖成 LINK**（联动被打开）
        #      ⇒ 用户报「三角拉满后再拖手柄 = 改速度」（对侧跟着动）。
        #
        #    修法：换成与**空心环同源**的「值分量视觉为零」判据。
        #    原意图（S 缩到 0 之后那条过期的 『用户 FREE』该被取代）**完整保留**
        #    —— 那正是值分量真的为零的情形。
        _supersede = value_len_is_visual_zero(obj, bone_name, kf_map, side)
        if _f0 is not None and act is not None and obj is not None:
            freeze_keyframe_pair(act, obj, _f0, side, bone_name,
                                 supersede=_supersede)
        elif _f0 is not None:
            # 至少登记一下（联动体验需要），即使不知道邻居
            try:
                _any = next(iter(kf_map.values()))
                _ow = ""
                try:
                    from . import transform_domain as _xf2
                    _ow = _xf2.owner_of_keyframe(_any)   # ★ 同一套拼装（D-1/D-2）
                except Exception:
                    _ow = ""
                mark_frozen(getattr(_any, "id_data", None), _f0, owner=_ow,
                            supersede=_supersede)
            except Exception:
                warn_once("time_domain.write_s")
                pass
    # ★★ 2026-09-30 修 P2-1（Review 发现）：
    #    逐轴赋值**没有保护**。若某一轴抛异常（**库链接 action** 是只读的，
    #    `kp.handle_left = ...` 会 raise），已经写过的轴**不会回滚**
    #    ⇒ 留下"半写"状态：**三轴 dt 不一致** —— 正是插件自己定义的规范违反，
    #      而且异常会一路向上传播。
    #    ⇒ 写成功的轴记下来；失败时**逆序回滚**，并返回 None（调用方按"未写"处理）。
    _done = []
    try:
        for ax, kp in kf_map.items():
            _ = ax
            _old = (kp.handle_left.copy() if side == 'left'
                    else kp.handle_right.copy())
            if side == 'left':
                kp.handle_left = (kp.co[0] - dt, kp.handle_left[1])
            else:
                kp.handle_right = (kp.co[0] + dt, kp.handle_right[1])
            _done.append((kp, side, _old))
    except Exception:
        warn_once("time_domain.write_s.write")
        for _kp, _sd, _old in reversed(_done):
            try:
                if _sd == 'left':
                    _kp.handle_left = _old
                else:
                    _kp.handle_right = _old
            except Exception:
                pass
        return None
    return s


# ---------------------------------------------------------------------------
# 便于外部使用的组合入口
# ---------------------------------------------------------------------------

def resolve_target(action, obj, frame, side, bone_name=None):
    """给定帧与侧，返回 (kf_map, span)。span 为 None 表示端点段不可编辑。

    ★★ 2026-09-30（Phase 1 极限测试 · A-1）：span 改成**逐轴**算。
    （`kf_map` 保持原样三轴照写 —— 为什么，见下面那段"改过一版又改回来"。）

    ▎旧行为错在哪

      旧代码只拿 `kf_map` 里的**第一根轴**算 span，`write_s` 再把这个 span
      套到**所有轴**上。三轴关键帧布局不一致时（某一轴在这一侧是**端点段** ——
      也就是它没有下一个关键帧），就写坏了：

          实测：X/Y 有 {0, 90, 117}，Z 只有 {0, 90}
                resolve_target(90, 'right')        ⇒ span = 27.0（来自 X 轴）
                Z 自己的 segment_span(90, 'right') ⇒ **None**（Z 没有右邻）
                write_s(kf_map, 'right', 0.5, 27.0) ⇒ Z 也被写 dt = 13.5  ✗

      Z 那一侧**根本没有"段"**，给它写 dt 就是"给一个不存在的时间跨度定长度"：
      手柄被甩到曲线末尾之外（Graph Editor 里能直接看到一根伸出去的柄）。
      而不变量检查器**看不见**它 —— 端点侧 span=None 会直接跳过检查
      （这就是发现清单 A-1 记的"盲区"）。

    ▎修法：span **逐轴算**；代表值取"有段的那根轴"里**轴号最小**的一根

      ⚠️⚠️ 但 `kf_map` **原样返回**（三轴照写）。这一点我改过一版又**改回来了**，
         记下来免得后人再走一遍 —— 有实测数据，不是口味问题：

         一开始按"把没有段的那根轴摘掉"改（= 端点轴不写 dt）。结果**当场破了
         插件自己的另一条规范**：`write_s` 只写有段的轴 ⇒ 该帧同侧三轴 dt 不再相等
         ⇒ 实测 `E.invariants` 报 `★ 同侧三轴 dt 不一致 f=90 right: [13.5, 13.5, 9.0]`。

         而且这**不只是"测试尺子挑刺"**：`detect` 判"手柄贴合路径"用的就是
         `dv ∝ dv/dt`（等价于"同侧三轴 dt 相等"）。在 |dv| > MIN_HANDLE_LEN(1.0)
         的数据上 detect 会**当场报 dt_mismatch** —— 用户刚拖完疏密三角，插件就告诉他
         "手柄偏离路径"。那是**用户可见的回归**，不是内部整洁问题。

         对照：插件自己的修复路径 `fix_unify_dt` 也是**三轴一起写**
         ⇒ "该帧同侧三轴 dt 相等"就是本插件的既定口径，
         `resolve_target` 不该在入口处把它拆开。

         ⇒ 真正该修的是"**代表值怎么取**"：
             · 旧：`next(iter(kf_map.keys()))` —— 依赖曲线收集顺序（隐式假设）
             · 新：有段的轴里取**轴号最小**的一根 ⇒ 同一输入永远同一答案
           另外顺手修好一个旧毛病：**第一根轴是端点、别的轴有段**时，
           旧代码会返回 None 把整次编辑拒掉（明明可以调）；现在能调了。

      ⚠️ 三轴**全都是**端点段时（首帧朝外 / 末帧朝外）⇒ 原样返回、span=None，
         与旧行为完全一致（调用方本来就是靠 `span is None` 拒绝的），
         UI 上"端点不可编辑"的既有表现一个字节都不变。
    """
    kf_map = collect_frame_keyframes(action, obj, frame, bone_name)
    if not kf_map:
        return {}, None
    spans = {}
    for ax, kp in kf_map.items():
        fc = fcurve_of(action, obj, ax, bone_name)
        spans[ax] = segment_span(fc, kp, side) if fc is not None else None
    usable = [ax for ax in sorted(spans) if spans[ax]]
    if not usable:
        # 三轴都是端点段（朝外那一侧）⇒ 与旧行为一致：原样返回，由调用方拒绝
        return kf_map, None
    # ⚠️ 代表值取**最小轴号**那一根（不再用 `next(iter(kf_map.keys()))` ——
    #    那依赖曲线收集顺序，是一处**隐式假设**：换机器/换 Blender 版本就可能变）。
    #    合规数据里各轴 span 本来就相等，取谁都一样；取最小轴号只为"同一输入同一答案"。
    return kf_map, spans[usable[0]]


def apply_pixel_drag(action, obj, frame, side, px_offset, bone_name=None,
                     facing='down_is_sparse'):
    """按【屏幕像素偏移】调整该侧疏密。

    px_offset 约定：正值 = 往下拖（远离路径）。
    facing='down_is_sparse' 时，往下 = 更疏（C 模式定稿语义）。

    返回 dict：{ok, s, span, ratio, message}
    """
    kf_map, span = resolve_target(action, obj, frame, side, bone_name)
    if not kf_map or span is None:
        return {"ok": False, "s": None, "span": None, "ratio": None,
                "message": "Endpoint segment has no neighbouring keyframe - cannot adjust"}

    sign = 1.0 if facing == 'down_is_sparse' else -1.0
    s = pixels_to_s(sign * px_offset)
    # ★ 2026-09-29：只补 bone_name（**不动** act/obj —— 那会改变邻居冻结行为）
    written = write_s(kf_map, side, s, span, bone_name=bone_name)
    for ax, kp in kf_map.items():
        fc = fcurve_of(action, obj, ax, bone_name)
        if fc:
            fc.update()
    return {"ok": True, "s": written, "span": span,
            "ratio": (S_LIN / written) if written else None,
            "message": ""}
