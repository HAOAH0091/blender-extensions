# Phase 1 交接书 —— Batch 2 / Batch 3 继续修

> **给下一轮的我**：这是极限边界测试（Phase 1）的完整交接。
> 用户要求：**全部修掉，且不要影响插件正常功能**。分 3 批，Batch 1 已完成并验证。
> 生成：2026-09-30 ｜ 仓库：`F:\desktop\BaiduSyncdisk\addons\RealTimeMotionPath`

---

## 0. 三十秒速览

- **测试批次已完成**：9 组 / 68 文件 / 1823 断言（5 个 sub 团队并行产出）
- **发现 13 条缺陷**：Batch 1 修了 6 条 ✅ ｜ **剩 7 条待修**（本文档主体）
- **完整发现清单**：`tests/EXTREME_FINDINGS.md`（每条含最小复现 / 根因 / 严重度）
- **Phase 0 的 Review 报告**：`tests/REVIEW_FINDINGS.md`（已修的 3 条 P1 + 2 条 P2）
- **跑全量门禁**：`python tests\run_all.py`（Python 用 `C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe`）
- **跑单个测试**：`blender.exe --background --factory-startup --python tests\<文件>.py`
- Blender 路径：`G:\steam\steamapps\common\Blender\blender.exe`

**铁律（用户强调）**：改动**不得影响插件正常功能** ⇒ 每批改完必须跑
`regression.py` + `i18n_gate.py` + 下表列出的受影响测试，全绿才算完成。

---

## 1. Batch 1 已完成（**不要重做**）

| 项 | 修复 | 验证 |
|---|---|---|
| **D-3** | `transform_domain.mark_owned_free` 加「已记录不覆盖」守卫（与 `freeze_handle_side` / `mark_frozen` / `spec_check._freeze_keyframe` 三处口径统一） | state 组 D1c FAIL→PASS |
| **G-1** | `modal_edit.py` G/R/S 的 MOUSEMOVE 分支补 `-1` 哨兵防护（调 `interaction._is_usable_mouse`） | modal 组 G1b-1 FAIL→PASS |
| **G-2** | `interaction.py:274` 的 `undo_push` 补 try（6 处里唯一没包的） | modal 组 G4e FAIL→PASS |
| **D-6** | `interaction._align_opposite_speed` 的 `clamped` 补**下界**判定（`< td.S_EPS`） | spec 组 F1c / F1c-2 FAIL→PASS |
| **A-2** | `state.MAX_HANDLE_SCALE` 100.0 → 10.0（与 `__init__.py` 属性 `max` 同源） | 纯口径（无使用者） |
| **A-3** | `transform_domain.scale_handle_uniform` 在 `dt_base==0` 时**按侧取符号**（left ⇒ 负） | 已改 |

另外**翻转**了 `tests/gui_eb_modal_check.py` 的 **G1b-3**：
它原本断言「modal 没有 -1 防护」（记录 bug），现在断言「防护在场」（防回归）。

**提交**：`aab8070`（Batch 1）→ `0d52c96`（清理误提交的日志 + .gitignore 补规则）

---

## 2. ★ Batch 2 待修（4 条，算法改动）

### D-5【高】补轴（`missing_axis`）破坏「同侧三轴 dt 一致」，而 `apply_fix` 复检报 0 处

- **最小复现 A（整条轴缺失）**：只插 X 轴关键帧
  `o.keyframe_insert("location", index=0, frame=f)`（f=0/90/117，值同 `E.KEYS_3`）

      report = sc.detect(act, o)             # 3 条 missing_axis（Y/Z 整条曲线不存在）
      res, _ = sc.apply_fix(act, o, report)  # 默认三项
      res["after"]["issues"]                 # ⇒ []  插件说「修好了」
      E.invariants(act, o)                   # ⇒ 5 条违规：
          dt 超过段长 ax=1 f=90 right dt=30.0 span=27.0（s=1.111 > S_HARD_MAX）
          dt 超过段长 ax=2 f=90 right dt=30.0 span=27.0
          同侧三轴 dt 不一致 f=0  left/right: [30.0, 1.0, 1.0]
          同侧三轴 dt 不一致 f=90 right:     [9.0, 30.0, 30.0]

- **最小复现 B（单帧缺轴，更常见）**：`E.KEYS_3` 对象上删掉 Y 轴帧 90 的关键帧 → `apply_fix`
  ⇒ 残留 `同侧三轴 dt 不一致 f=90 right: [9.0, 12.68, 9.0]`
- **根因链**：
  1. `fix_missing_axes` 用 `keyframe_points.insert()` 造的关键帧是 **ALIGNED 派生手柄**，
     时间分量由 Blender 按「朝邻居点的向量」算（实测 26.02 / 12.68，而同侧 X/Z 是 30 / 9）
  2. `_freeze_keyframe` **原样保住了**这个 dt
  3. 后续 `dt_mismatch` 阶段只处理 `detect` 报出来的项，而
     **`detect` 在 `|dv| <= MIN_HANDLE_LEN(1.0)` 时整侧跳过**（`spec_check.py:480`）——
     复现 B 该侧 `|dv|=0.59`；复现 A 补出来的轴是平曲线、`dv=0`，角度判据恒 0
  4. ⇒ `spec_check.py:1233-1238` 注释里「每阶段重跑 detect 就能兜住」的假设**不成立**
- **建议修法**（worker C 给的）：补轴后**立刻按同侧中位数统一新关键帧的 dt**（不依赖下一阶段 detect）；
  或在 `detect` 里加一条**与 `|dv| 无关**的「同侧 dt 极差」判据
- **受影响测试**：`gui_eb_spec_check.py`（E2 系列 8 条 + E5b + E2-full）

### D-7【中高】180 度折角 ⇒ `bisect` / `length_weighted` 把手柄长度清成 0

- **最小复现**：帧 90 左右手柄都写 `dv=(1.0, 0.5, 0.25)`（**同向** ⇒ fold=180°），体感登记 LINK

      sc.fix_handle_bend(act, o, report, None, None, strategy='bisect')   # 默认策略
      ⇒ 两侧 dv 全变 (0,0,0)，手柄长度 1.1456 → 0.0
      ⇒ sc.detect 复检 issues=[]（**静默**，零长手柄被长度闸门跳过 ⇒ 永远看不见）
      ⇒ 路径形变 0.51
      （right_only / left_only 同场景正常：长度守恒、fold→0）

- **根因**：`spec_check._target_dirs`（`:612-615`）的 bisect 取 `ul - ur`，**同向时为 0**；
  `length_weighted` 在两侧等长时也是 0。零向量经 `_as_unit` 归一化仍返回 0 方向 ⇒ `_set_side_dv` 写成 dv=0
- **建议修法**：`_target_dirs` 加**退化保护** —— `ul` 与 `ur` 夹角近 180° 时回退到 `right_only`（或长度加权），
  别让零向量 / 噪声向量进入 `_set_side_dv`
- **受影响测试**：`gui_eb_spec_check.py`（E3b bisect / E3b length_weighted / E5d）

### D-8【中】近 180 度时 `bisect` 的方向完全由浮点噪声决定

- **最小复现**：左手 `dv=(1.0,0.5,0.25)`、右手 `dv=(0.98,0.49,0.245)`（单位向量只差约 1e-7）
  ⇒ bisect 后手柄被**转向 90.00°**（长度守恒），路径形变 0.72
- **根因**：与 D-7 同源（退化未保护）
- **建议修法**：与 D-7 一起做（夹角阈值 + 回退策略）
- **受影响测试**：`gui_eb_spec_check.py`（E3c）

### A-1【中低】`resolve_target` 的 span 只取自**第一根轴** ⇒ 端点轴也被写 dt

- **最小复现**：X/Y 轴关键帧 `{0,90,117}`、Z 轴只有 `{0,90}`

      td.resolve_target(act, obj, 90, 'right')   ⇒ span=27.0（来自 X 轴）
      Z 轴自己的 td.segment_span(Z, 90, 'right') ⇒ None（**端点段**）
      td.write_s(kf_map, 'right', 0.5, 27.0)     ⇒ **Z 轴也被写 dt=13.5**  ✗
      不变量检查：无违规（**盲区**：端点侧 span=None 直接跳过）

- **附带**：`td.neighbor_frame` 用的是**跨轴帧号并集**（=117），与逐轴 `segment_span`（None）
  是同一个「邻居」的**两套定义** ⇒ 口径漂移
- **建议修法**：`resolve_target` 逐轴取 span；或写入时逐轴判断「该轴这一侧是否端点段」
- **受影响测试**：`gui_eb_numeric_check.py`（B7）

---

## 3. ★ Batch 3 待修（3 条，**结构性，风险最高**）

### D-1【高】四张内存表的键**不含骨骼名** ⇒ 多骨骼同帧同侧互相串

- **最小复现**（**父 agent 已独立跑过**）：

      E.build_object(bone=True) → 加第二根骨骼 BoneB，同帧 90 各插关键帧
      xf.mark_feel(kpA, 'left', 'LINK')     # BoneA
      xf.mark_feel(kpB, 'left', 'FREE')     # BoneB
      xf.feel_type(kpA, 'left')   ⇒  'FREE'   ← 期望 'LINK'  ✗
      act["rtmp_feel"]            ⇒  ['90.0000|left|FREE']   ← 只剩 1 条

- **根因**：四张表的键构造函数都不含骨骼名 ——
  `transform_domain._feel_key_of` / `_trilock_key_of` / `_own_key` / `time_domain._frozen_key`
- **影响**：角色动画里「多骨骼同帧同侧」是**常态** ⇒ 手臂 A 设的「不动」被手臂 B 悄悄改掉，
  `_link_mode` 于是给出**错的联动决策**（本该不动的手柄开始跟着动）
- **注意**：曲线按骨骼名分流**已经做对了**（`xf._position_curves(act, obj, bone_name)`），**账本没跟上**。
  docstring 说「Python API 没有从 Keyframe 反查 F-Curve 的入口」—— 这对 **axis** 成立，
  但 **bone_name 在调用方是拿得到的**（`td.freeze_keyframe_pair` 就带 `bone_name`，只是没往下传）
- **⚠️ 风险**：这是四张**持久化**表的身份标识改动 ⇒ 必须同时处理
  ① token 格式（`act["rtmp_feel"]` 等字符串）② 旧文件兼容（老 token 没有骨骼段）
  ③ 所有 `mark_*` / `*_sync` / 查询入口 ④ `undo_guard.clear_all`
- **受影响测试**：`gui_eb_state_check.py`（C5 两条）、以及**所有**体感 / 冻结 / 接管 / 三角锁定相关测试
  （`gui_frozen_link_check` / `gui_tri_lock_check` / `gui_bone_speed_check` / `gui_feel_persist_probe` …）

### D-2【高】四张表的键**不含 slot** ⇒ 共享 action 的两个 slot 互相串

- 与 D-1 **同源**，建议**一起做**
- **最小复现**（worker B D5b）：slot A 记 LINK → slot B 记 FREE ⇒ A 读回 FREE，property 只剩 1 条
- **受影响测试**：`gui_eb_state_check.py`（D5b 两条）

### G-3【中·SUSPECT】疏密模态 ESC/右键取消后，段**另一端**的手柄类型静默留在 FREE

- **最小复现**：`me.ModalSession('SPEED')` 对 (frame=90, side='left') → `sess.update()` 改值 → `sess.cancel()`
- **实际**：co 与手柄坐标**逐位还原** ✓、目标帧那一侧类型也还原 ✓；
  但**相邻帧 0 那一侧**（段另一端）三轴 `AUTO_CLAMPED → FREE`，且 `rtmp_frozen` 记着 `[0.0, 90.0]`
- **机理**：`ModalSession.restore()`（`modal_edit.py:1040`）的快照只覆盖 `self.target["kf_map"]`，
  而 `write_s(freeze=True)` 会把**段两端**都冻成 FREE ⇒ **另一端只冻不还原**
- **建议修法**：快照把「该段另一端」的手柄类型也纳进来（或取消时按 `rtmp_frozen` 回滚）
- **受影响测试**：`gui_eb_modal_check.py`（G9-SPEED-c）

### 另外 2 条待办的"测试侧"

- `gui_eb_modal_check.py` **G4d**：静态计数测试（6 处 `undo_push` 有几处包了 try）—— Batch 1 已把第 6 处包上，
  但这个测试的启发式（"前面 260 字符内有 try:"）可能仍判假 ⇒ 复查后修正它
- `gui_eb_spec_check.py` 的 14 条：随 D-5 / D-7 / D-8 一起转绿

---

## 4. ★★ 不变量检查器的**校准**（做 Batch 2/3 前必读）

`tests/_eb_common.py` 的 `invariants()` 有**三条会误报**的判据，
不校准的话你会反复误判（fuzz worker 与 modal worker 都踩过）：

| 判据 | 问题 | 校准 |
|---|---|---|
| **dt ≤ 段长** | `xf.write_endpoint_uniform` 用**真实可达**的 k（≤200）写出 `dt=26.67 / span=0.4` | `scale_handle_uniform` 的 docstring 写明「**2026-09-17 用户拍板：取消拉长上限**，手柄一直跟手变长」⇒ 该判据**只适用于 `td.write_s` 系**（它是唯一钳 `s <= S_HARD_MAX` 的） |
| **同侧三轴 dt 相等** | 手柄是 **ALIGNED** 时任何 `fc.update()` 都会按 (t,v) 共线把它写散（实测跨度 3.84e-2） | **插件自己就会造出 ALIGNED**（`xf._DRAG_TO_TYPE`：AUTO/AUTO_CLAMPED → ALIGNED）⇒ 断言要**按手柄类型分流** |
| **幽灵条目**（有 property 但表里没条目） | 重开 .blend 后进程内四表是**冷的**（property 还在）⇒ **必然假阳性** | 这是「缓存=派生、读时自查」的正常态，**不是缺陷**；真检验是「undo 清空表后能否从 property 恢复真相」（见 `gui_eb_modal_check.py` H2-16b，全过） |

⚠️ warm 入口必须是**会触发对账**的函数 —— `owned_free_tokens` 只读 property 不对账，要用 `xf.warm_owned_free`

---

## 5. 验证清单（每批改完都要跑）

    # ① 基础回归
    blender --background --factory-startup --python tests\regression.py       # 期望 PASS 16 / FAIL 0
    python tests\i18n_gate.py                                                 # 期望通过

    # ② 全量门禁（68 文件）
    python tests\run_all.py

    # ③ 受影响测试（按改动挑）
    tests\gui_review_fix_check.py          # 12/0
    tests\gui_frozen_link_check.py         # 65/0（体感相关改动必跑）
    tests\gui_tri_lock_check.py            # 三角锁定
    tests\gui_dblclick_copy_speed_check.py
    tests\gui_bone_speed_check.py          # 骨骼（D-1 必跑）
    tests\gui_move_endpoint_keepspeed_check.py / gui_point_scale_keepspeed_check.py / gui_handle_scale_check.py
    tests\gui_eb_state_check.py / gui_eb_modal_check.py / gui_eb_spec_check.py / gui_eb_numeric_check.py

**判据**：既有测试**不许转红**（新增断言转绿才是修好了）。

---

## 6. 建议的批次顺序

1. **Batch 2**（先做，风险中等）：**D-7 + D-8 一起**（同源，`_target_dirs` 退化保护）
   → **D-5**（补轴后立刻统一 dt）
   → **A-1**（逐轴 span）
   → 每改一条跑一次受影响测试
2. **Batch 3**（最后做，风险最高）：**D-1 + D-2 一起**（表键加 `bone_name` + slot）
   ⚠️ 这条**必须**先设计 token 格式与**旧文件兼容**方案，再动手；
   动完跑**全部**体感/冻结/接管/锁定相关测试
3. 收尾：**G-3**（取消还原邻帧）+ 修 **G4d** 静态测试 + 更新 `EXTREME_FINDINGS.md` 的"已修"状态 + Change Log

---

## 7. 关键文件地图

| 文件 | 作用 |
|---|---|
| `tests/EXTREME_FINDINGS.md` | **发现清单**（13 条，含最小复现 / 根因 / 严重度） |
| `tests/REVIEW_FINDINGS.md` | Phase 0 Review 报告（已修的 3 P1 + 2 P2） |
| `tests/_eb_common.py` | 共享地基：`invariants()` / `build_object()` / `set_handles()` / `flush()` |
| `tests/gui_eb_*.py` | 9 组极限测试（A+B / C+D / E+F / G+H） |
| `tests/_extreme_fuzz.py` | 随机化 fuzz（`-- --seed N --rounds N`） |
| `tests/run_all.py` | 全量门禁（支持 `suspects` 分级） |
| `Change Log.md` | 开发历史（每批改完按既有 splice 脚本模式追加） |
| `README_DEV.md` | 铁律与踩坑（新增教训写这里） |

**四张内存表**（都在 action 的 custom property 上）：
`xf._FEEL`/`rtmp_feel` · `xf._TRILOCK`/`rtmp_tri_lock` ·
`xf._plugin_owned_free`/`rtmp_owned_free` · `td._FROZEN`/`rtmp_frozen`

---

## 8. 新会话开场白（直接复制）

> 继续 RealTimeMotionPath 的 Phase 1 修复。先读 `tests/PHASE1_HANDOFF.md` 和
> `tests/EXTREME_FINDINGS.md`，然后按交接书做 Batch 2（D-7/D-8 → D-5 → A-1），
> 每改一条跑受影响测试 + `regression.py` + `i18n_gate.py`，确认不影响正常功能再进下一条。
> Batch 2 完成后接着做 Batch 3（D-1/D-2 表键加骨骼名与 slot —— 先设计 token 与旧文件兼容方案再动手）。
> 铁律：改动不得影响插件正常功能；发现清单里标"已由父 agent 独立复现"的可直接采信，
> 标"worker 报告未复现"的先复现再改。
