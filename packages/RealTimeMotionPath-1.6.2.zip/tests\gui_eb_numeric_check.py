# -*- coding: utf-8 -*-
"""A 组（数值极限）+ B 组（关键帧几何极限）—— 极限边界测试。

来源：Phase 1 极限边界测试任务书（worker: gui_eb_numeric_check）。
地基：tests/_eb_common.py（不变量检查器 + 场景构造），本文件不改任何产品代码。

用法：blender --background --factory-startup --python tests/gui_eb_numeric_check.py
"""
import os
import re
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
ADDONS = os.path.dirname(REPO)
LOG = os.path.join(HERE, "_eb_num_result.json")
for _p in (ADDONS, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import bpy  # noqa: E402

try:
    bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
except Exception:
    pass

import _eb_common as E  # noqa: E402
import mathutils  # noqa: E402

try:
    from RealTimeMotionPath import cache as ca
except Exception:
    ca = None

xf, td, it, sc, hd, st = E.xf, E.td, E.it, E.sc, E.hd, E.st

steps = []


def step(n, ok, d=""):
    steps.append((n, bool(ok), str(d)))


# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------

def src(name):
    """读产品源码（只读，仅用于静态契约审计）。"""
    with open(os.path.join(REPO, name), "r", encoding="utf-8") as fh:
        return fh.read()


def dt_at(o, frame, side, tol=1e-3):
    """现取某帧某一侧的三轴 dt 列表（每次重新取 keyframe 包装对象，防「钝」）。"""
    out = []
    for ax, fc in sorted(E.curves_of(o).items()):
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - frame) < tol:
                h = kp.handle_left if side == 'left' else kp.handle_right
                out.append(float(h[0]) - float(kp.co[0]))
                break
    return out


def signed_dt_at(o, frame, side, tol=1e-3):
    """{axis: 带符号 dt}。左负右正才是「手柄在自己那一边」。"""
    out = {}
    for ax, fc in sorted(E.curves_of(o).items()):
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - frame) < tol:
                h = kp.handle_left if side == 'left' else kp.handle_right
                out[ax] = float(h[0]) - float(kp.co[0])
                break
    return out


def vals_at(o, frame, tol=1e-3):
    """{axis: 值分量}。"""
    out = {}
    for ax, fc in sorted(E.curves_of(o).items()):
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - frame) < tol:
                out[ax] = float(kp.co[1])
                break
    return out


def chk_inv(name, act, o, extra=""):
    """每个用例后都调：不变量违规即 FAIL。"""
    try:
        v = E.invariants(act, o)
    except Exception:
        step(name, False, "invariants 自身抛异常: " + E.tb(400))
        return False
    ok = not v
    step(name, ok, ("; ".join(v) if v else "不变量全部成立") + ((" | " + extra) if extra else ""))
    return ok


def upd(o):
    for fc in E.curves_of(o).values():
        fc.update()


def insert_all(o, frame, value):
    """在三轴上同帧插关键帧（绕过 E.build_object 的 int() 截断）。"""
    for ax, fc in E.curves_of(o).items():
        fc.keyframe_points.insert(float(frame), float(value), options={'FAST'})
        fc.update()


def frames_of(o):
    fc = E.curves_of(o)[0]
    return [float(k.co[0]) for k in fc.keyframe_points]


# ===========================================================================
# A0 · 靶子常量现状（先钉住被测边界值本身）
# ===========================================================================
try:
    EXPECT = [
        ("td.S_HARD_MAX", td.S_HARD_MAX, 1.0),
        ("td.S_EPS", td.S_EPS, 1e-5),
        ("xf.UNIFORM_DT_FLOOR", xf.UNIFORM_DT_FLOOR, 1e-4),
        ("xf.UNIFORM_LEN_MIN", xf.UNIFORM_LEN_MIN, 1.0),
        ("xf.UNIFORM_LEN_EPS", xf.UNIFORM_LEN_EPS, 1e-6),
        ("xf.UNIFORM_K_SAFETY", xf.UNIFORM_K_SAFETY, 200.0),
        ("st.HANDLE_ZERO_EPS", st.HANDLE_ZERO_EPS, 1e-4),
        ("st.MIN_HANDLE_SCALE", st.MIN_HANDLE_SCALE, 0.1),
        # ★ 2026-09-30（Batch 1 · A-2）：旧值 100.0 与属性 `max=10.0` 不一致，
        #   已统一成 10.0（A7a 钉的就是属性实际能取到的上界）。
        #   本表是"靶子常量"清单，产品常量改了它必须跟着改 ——
        #   Batch 1 漏了这一处，导致 A0 一直红着（本次补上）。
        ("st.MAX_HANDLE_SCALE", st.MAX_HANDLE_SCALE, 10.0),
        ("xf.WRITE_LIMIT", xf.WRITE_LIMIT, 1e12),
        ("xf.SAFE_LIMIT", xf.SAFE_LIMIT, 1e6),
        ("xf.DT_EPS", xf.DT_EPS, 1e-3),
        ("st.FRAME_EPS", st.FRAME_EPS, 1e-3),
        ("ca.FRAME_INT_EPS", getattr(ca, "FRAME_INT_EPS", None), 1e-4),
    ]
    bad = ["%s=%r(期望 %r)" % (n, got, want) for n, got, want in EXPECT if got != want]
    step("A0 靶子常量与任务书一致", not bad,
         "; ".join(bad) if bad else "14 个常量全部一致")
except Exception:
    step("A0 FATAL", False, E.tb())

# ===========================================================================
# A1 · s 越界钳制
# ===========================================================================
try:
    o, act = E.build_object("_EB_A1", E.KEYS_3, free_all=True)
    rows, ok_all = [], True
    for s_in in (1.0, 1.0000001, 1.5, 1e9, float("inf")):
        kfm, span = td.resolve_target(act, o, 90, 'right')
        w = td.write_s(kfm, 'right', s_in, span, freeze=False)
        upd(o)
        dts = dt_at(o, 90.0, 'right')
        good = (w == td.S_HARD_MAX) and bool(span) and len(dts) == 3 and \
            all(abs(d - span) < 1e-3 for d in dts)
        ok_all = ok_all and good
        rows.append("s=%g->w=%s dt=%s" % (s_in, w, [round(d, 4) for d in dts]))
        v = E.invariants(act, o)
        if v:
            ok_all = False
            rows.append("INV:" + ";".join(v))
    step("A1a ★ 上溢 s(1.0/1+1e-7/1.5/1e9/inf) 一律钳到 S_HARD_MAX，dt=段长且不超段",
         ok_all, " | ".join(rows))
except Exception:
    step("A1a FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_A1b", E.KEYS_3, free_all=True)
    rows, ok_all = [], True
    for s_in in (-5.0, 0.0, 1e-9, float("nan")):
        kfm, span = td.resolve_target(act, o, 90, 'right')
        w = td.write_s(kfm, 'right', s_in, span, freeze=False)
        upd(o)
        dts = dt_at(o, 90.0, 'right')
        good = (w == td.S_EPS) and len(dts) == 3 and all(d > 0.0 for d in dts)
        ok_all = ok_all and good
        rows.append("s=%g->w=%s dt=%s" % (s_in, w, ["%.3e" % d for d in dts]))
        v = E.invariants(act, o)
        if v:
            ok_all = False
            rows.append("INV:" + ";".join(v))
    step("A1b ★ 下溢 s(-5/0/1e-9/nan) 一律钳到 S_EPS，dt>0（手柄不落到关键帧上）",
         ok_all, " | ".join(rows))
except Exception:
    step("A1b FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_A1c", E.KEYS_3, free_all=True)
    r = td.apply_pixel_drag(act, o, 90, 'right', -1e6)
    r2 = td.apply_pixel_drag(act, o, 90, 'right', 1e6)
    msg_empty = (str(r.get("message") or "") == "" and str(r2.get("message") or "") == "")
    step("A1c NOTE 钳制只在 write_s 返回值里可见，没有用户可见文案",
         msg_empty,
         "拖爆 -> s=%s msg=%r / s=%s msg=%r（口径：write_s 返回值即提示渠道，故计 PASS；"
         "另：双击对齐那条路 interaction.py:515 自己算了 clamped 标志会提示，拖拽这条路没有）"
         % (r.get("s"), r.get("message"), r2.get("s"), r2.get("message")))
except Exception:
    step("A1c FATAL", False, E.tb())

# ===========================================================================
# A2 · dt 落到 UNIFORM_DT_FLOOR 附近
# ===========================================================================
try:
    # 保底闸门是 dt_max > UNIFORM_LEN_EPS(1e-6)，不是 > UNIFORM_DT_FLOOR(1e-4)：
    #   1e-5 > 1e-6 ⇒ 生效，k = max(k_raw, floor/dt_base) ⇒ dt 正好落在 floor
    #   1e-7 <= 1e-6 ⇒ 闸门跳过，k 保持 k_raw（最终 dt 由 scale_handle_uniform 兜底抬到 floor）
    ks_hi = xf.handle_scale_k([2.0, 0, 0], [4.0, 0, 0], [1e-5, 1e-5, 1e-5], 27.0)
    ks_lo = xf.handle_scale_k([2.0, 0, 0], [4.0, 0, 0], [1e-7, 1e-7, 1e-7], 27.0)
    dt_hi = ks_hi[0] * 1e-5 if ks_hi else None
    ok = (ks_hi is not None and abs(dt_hi - xf.UNIFORM_DT_FLOOR) < 1e-15
          and ks_lo is not None and abs(ks_lo[0] - ks_lo[1]) < 1e-12)
    step("A2a ★ handle_scale_k 的 k 保底闸门在 dt_base=UNIFORM_LEN_EPS(1e-6)：1e-5 ⇒ dt 正好=floor；1e-7 ⇒ 不保底（下游兜底）",
         ok, "dt_base=1e-5 -> k=%r dt=%.3e（floor=%g）；dt_base=1e-7 -> k=%r（=k_raw=%r，闸门跳过）"
         % (ks_hi and ks_hi[0], dt_hi or 0, xf.UNIFORM_DT_FLOOR,
            ks_lo and ks_lo[0], ks_lo and ks_lo[1]))
except Exception:
    step("A2a FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_A2b", E.KEYS_3, free_all=True)
    rows, ok_all = [], True
    for dt_b in (0.0, 1e-9, 5e-5, 2e-4):
        kfm, span = td.resolve_target(act, o, 90, 'right')
        for ax, kp in sorted(kfm.items()):
            xf.scale_handle_uniform(kp, 'right', 1.0, dt_b, 2.0, 1.0, 1.0, span)
        upd(o)
        dts = dt_at(o, 90.0, 'right')
        good = len(dts) == 3 and all(abs(d) >= xf.UNIFORM_DT_FLOOR - 1e-12 for d in dts) \
            and all(d != 0.0 for d in dts) and all(d > 0 for d in dts)
        ok_all = ok_all and good
        rows.append("dt_base=%g -> dt=%s" % (dt_b, ["%.3e" % d for d in dts]))
        v = E.invariants(act, o)
        if v:
            ok_all = False
            rows.append("INV:" + ";".join(v))
    step("A2b ★ scale_handle_uniform：dt 永不为 0，低于 UNIFORM_DT_FLOOR 一律抬到 floor",
         ok_all, " | ".join(rows))
except Exception:
    step("A2b FATAL", False, E.tb())

try:
    # 实测：写完 dt=1e-4 后 fc.update() 会把手柄时间顶到 ~1.007e-3（帧 90 处约 10 倍），
    # 写 dt=9（正常长度）时 update 不动它。⇒ 真正生效的下限是 Blender 的，不是 UNIFORM_DT_FLOOR。
    o, act = E.build_object("_EB_A2c", E.KEYS_3, free_all=True)
    kfm, span = td.resolve_target(act, o, 90, 'right')
    wrote = []
    for ax, kp in sorted(kfm.items()):
        wrote.append(xf.scale_handle_uniform(kp, 'right', 1.0, 0.0, 2.0, 1.0, 1.0, span))
    before = dt_at(o, 90.0, 'right')
    upd(o)
    after = dt_at(o, 90.0, 'right')
    step("A2c NOTE UNIFORM_DT_FLOOR(1e-4) 写进去后会被 fc.update() 顶开到 ~1.007e-3（真正生效的下限是 Blender 的）",
         True, "写前 dt=%s（write 返回 %s）-> update 后 dt=%s（帧 90 处 float32 ulp=%.2e）"
         % (["%.3e" % d for d in before], ["%.3e" % b for a, b in wrote],
            ["%.3e" % d for d in after], 90.0 * 2.0 ** -23))
except Exception:
    step("A2c FATAL", False, E.tb())

# ===========================================================================
# A3 · |dv| 分界（UNIFORM_LEN_MIN = 1.0）
# ===========================================================================
try:
    r = {}
    for L in (0.999, 1.0, 1.001, 1.0000001):
        r[L] = xf.handle_scale_k([L, 0, 0], [2 * L, 0, 0], [9.0, 9.0, 9.0], 27.0)
    ok = (r[0.999] is None and r[1.0] is None and r[1.001] is not None
          and r[1.0000001] is not None
          and abs(r[1.001][0] - 2.0) < 1e-9 and abs(r[1.001][1] - 2.0) < 1e-9
          and r[1.001][2] == xf.UNIFORM_K_SAFETY)
    step("A3 ★ |dv_base| 分界：0.999/1.0 → None（不保速），1.001 → k=k_raw=L1/L0",
         ok, "0.999=%r 1.0=%r 1.001=%r 1.0000001=%r（边界含等号）"
         % (r[0.999], r[1.0], r[1.001], r[1.0000001]))
except Exception:
    step("A3 FATAL", False, E.tb())

# ===========================================================================
# A4 · |dv| = 0（零长手柄）+ 左侧 dt_base==0 的符号
# ===========================================================================
try:
    k0 = xf.handle_scale_k([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], [9.0, 9.0, 9.0], 27.0)
    o, act = E.build_object("_EB_A4a", E.KEYS_3, free_all=True)
    kfm, span = td.resolve_target(act, o, 90, 'right')
    res = []
    for ax, kp in sorted(kfm.items()):
        res.append(xf.scale_handle_uniform(kp, 'right', 0.0, 9.0, 5.0, 1.0, 0.0, span))
    upd(o)
    finite = all(math.isfinite(x) for pair in res for x in pair)
    step("A4a ★ 零长基线：handle_scale_k 返回 None；scale_handle_uniform k_raw=0 时 ratio=1 不除零",
         k0 is None and finite and all(abs(p[0] - 5.0) < 1e-6 for p in res),
         "k=%r 返回=%s" % (k0, [[round(a, 6), round(b, 6)] for a, b in res]))
    chk_inv("A4a-inv 不变量", act, o)
except Exception:
    step("A4a FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_A4b", E.KEYS_3, free_all=True)
    kfm, span = td.resolve_target(act, o, 90, 'left')
    res = []
    for ax, kp in sorted(kfm.items()):
        res.append(xf.scale_handle_uniform(kp, 'left', 1.5, 0.0, 3.0, 2.0, 2.0, span))
    upd(o)
    sd = signed_dt_at(o, 90.0, 'left')
    inv_ok = not E.invariants(act, o)
    good = bool(sd) and all(v < 0 for v in sd.values())
    step("A4b NOTE 左侧 dt_base==0：返回值 dt=+1e-4 符号与侧不匹配，落点靠 Blender 的 fc.update() 纠回左侧",
         good,
         "返回 dt=%s（左侧应为负）；fc.update() 后实际带符号 dt=%s（已被 Blender 翻回左侧，"
         "幅度也被放大到 ~1e-3）；不变量 abs 口径看不出来=%s ⇒ 最终状态合规，但【返回值不可信】"
         "（端点模态写完不 update，错误会短暂留存）"
         % ([round(b, 8) for a, b in res], {k: "%.6e" % v for k, v in sd.items()}, inv_ok))
    chk_inv("A4b-inv 不变量", act, o)
except Exception:
    step("A4b FATAL", False, E.tb())

# ===========================================================================
# A5 · 值分量量级
# ===========================================================================
try:
    wtab = {}
    for tag, v in (("1e6", 1e6), ("1e9", 1e9), ("1e11", 1e11), ("1e12", 1e12),
                   ("1e13", 1e13), ("-1e13", -1e13), ("nan", float("nan")),
                   ("inf", float("inf"))):
        wtab[tag] = (xf.is_writable([v, 0.0, 0.0]), xf.is_safe([v, 0.0, 0.0]))
    ok = (wtab["1e6"][0] and wtab["1e9"][0] and wtab["1e11"][0]
          and not wtab["1e12"][0] and not wtab["1e13"][0] and not wtab["-1e13"][0]
          and not wtab["nan"][0] and not wtab["inf"][0])
    step("A5a ★ is_writable：<1e12 可写（含 1e11），>=1e12 / nan / inf 一律拒", ok,
         "; ".join("%s:w=%s,safe=%s" % (k, a, b) for k, (a, b) in wtab.items()))
    step("A5b NOTE is_safe(SAFE_LIMIT=1e6) 是绘制口径：1e6 已判不安全（严格小于）",
         (not wtab["1e6"][1]) and wtab["1e6"][0],
         "1e6 -> is_safe=%s / is_writable=%s（写入比绘制宽 6 个数量级，是刻意设计）"
         % (wtab["1e6"][1], wtab["1e6"][0]))
except Exception:
    step("A5a FATAL", False, E.tb())

try:
    rows, ok_all = [], True
    for delta, tag, want in ((1e6, "1e6", True), (1e9, "1e9", True),
                             (1e11, "1e11", True), (1e13, "1e13", False),
                             (-1e13, "m1e13", False)):
        o, act = E.build_object("_EB_A5_%s" % tag, E.KEYS_3, free_all=True)
        base = vals_at(o, 90.0)
        snap = xf.snapshot_positions(act, o, {90.0: {ax: fc for ax, fc in E.curves_of(o).items()}})
        r = xf.apply_translation(act, o, snap, (delta, 0.0, 0.0))
        upd(o)
        after = vals_at(o, 90.0)
        moved = abs(after[0] - base[0]) > 1e-6
        reason = xf.last_skip_reason
        xf._reset_skip()
        good = (moved == want) and (bool(reason) == (not want))
        ok_all = ok_all and good
        rows.append("dx=%g 期望写入=%s 实际位移=%s reason=%r" % (delta, want, moved, reason))
        v = E.invariants(act, o)
        if v:
            ok_all = False
            rows.append("INV:" + ";".join(v))
    step("A5c ★ 真实路径 apply_translation：1e6/1e9/1e11 写得进；1e13 被拒且 last_skip_reason 有内容（不静默）",
         ok_all, " | ".join(rows))
except Exception:
    step("A5c FATAL", False, E.tb())

# ===========================================================================
# A6 · 缩放倍率越界折回
# ===========================================================================
try:
    rows, ok_all = [], True
    for L in (1e-3, 0.1, 100.0, 1e4):
        t = xf.handle_scale_k([2.0, 0, 0], [2.0 * L, 0, 0], [9.0, 9.0, 9.0], 27.0)
        k, k_raw, k_max = t
        ratio = k / k_raw
        dv_written = (2.0 * L) * ratio
        good = (k <= k_max + 1e-12) and (dv_written > 0) and \
               (abs(ratio - 1.0) < 1e-9 if L <= 100.0 else abs(k - k_max) < 1e-9)
        ok_all = ok_all and good
        rows.append("倍率%g -> k=%.6g k_raw=%.6g ratio=%.6g dv_w=%.6g" % (L, k, k_raw, ratio, dv_written))
    step("A6a ★ 倍率 1e-3/0.1/100 原样通过；1e4 被 UNIFORM_K_SAFETY(200) 折回、方向不变",
         ok_all, " | ".join(rows))
except Exception:
    step("A6a FATAL", False, E.tb())

try:
    rows, ok_all = [], True
    for fac in (1e-3, 0.1, 100.0, 1e4, 1e13):
        o, act = E.build_object("_EB_A6_%s" % ("%g" % fac).replace("-", "m"), E.KEYS_3, free_all=True)
        snap = xf.snapshot_positions(act, o, {90.0: {ax: fc for ax, fc in E.curves_of(o).items()}})
        fn = xf.scale_fn(mathutils.Vector((1.0, 2.56, 0.4)), fac)
        r = xf.apply_point_transform(act, o, snap, fn)
        upd(o)
        reason = xf.last_skip_reason
        xf._reset_skip()
        want_skip = (fac >= 1e13)
        good = (bool(reason) == want_skip) and bool(r)
        ok_all = ok_all and good
        rows.append("factor=%g -> r=%s reason=%r" % (fac, r, reason))
        v = E.invariants(act, o)
        if v:
            ok_all = False
            rows.append("INV:" + ";".join(v))
    step("A6b ★ 真实路径缩放 1e-3~1e4 全部生效、无 NaN；1e13 被拒且有原因", ok_all, " | ".join(rows))
except Exception:
    step("A6b FATAL", False, E.tb())

# ===========================================================================
# A7 · rtmp_handle_scale 边界 + MIN/MAX_HANDLE_SCALE 审计
# ===========================================================================
try:
    wm = bpy.context.window_manager
    got = {}
    for v in (0.0, -5.0, 0.05, 0.1, 1.0, 10.0, 100.0, 1e9):
        wm.rtmp_handle_scale = v
        got[v] = float(wm.rtmp_handle_scale)
    wm.rtmp_handle_scale = 1.0
    ok = (abs(got[0.0] - st.MIN_HANDLE_SCALE) < 1e-6
          and abs(got[-5.0] - st.MIN_HANDLE_SCALE) < 1e-6
          and abs(got[0.05] - st.MIN_HANDLE_SCALE) < 1e-6
          and got[100.0] == 10.0 and got[1e9] == 10.0 and got[10.0] == 10.0)
    step("A7a ★ rtmp_handle_scale 边界：0/负/0.05 夹到 0.1；10/100/1e9 夹到 10.0",
         ok, "; ".join("%g->%.6g" % (k, v) for k, v in got.items()))
except Exception:
    step("A7a FATAL", False, E.tb())

try:
    src_init = src("__init__.py")
    m = re.search(r"rtmp_handle_scale\s*=\s*bpy\.props\.FloatProperty\((.*?)\)", src_init, re.S)
    blk = m.group(1) if m else ""
    pm = re.search(r"min\s*=\s*([0-9.]+)", blk)
    px = re.search(r"max\s*=\s*([0-9.]+)", blk)
    pmin = float(pm.group(1)) if pm else None
    pmax = float(px.group(1)) if px else None
    step("A7b ★★ st.MAX_HANDLE_SCALE(100.0) 与属性实际上限 max=10.0 不一致（潜在陷阱/死常量）",
         (pmax == st.MAX_HANDLE_SCALE and pmin == st.MIN_HANDLE_SCALE),
         "属性 min/max = %r/%r，st.MIN/MAX_HANDLE_SCALE = %r/%r"
         % (pmin, pmax, st.MIN_HANDLE_SCALE, st.MAX_HANDLE_SCALE))
except Exception:
    step("A7b FATAL", False, E.tb())

try:
    users = []
    for fn in ("drawing.py", "interaction.py", "edit_geometry.py", "modal_edit.py",
               "overlay.py", "state.py", "transform_domain.py", "time_domain.py"):
        try:
            txt = src(fn)
        except Exception:
            continue
        for i, line in enumerate(txt.splitlines(), 1):
            s = line.strip()
            if "MIN_HANDLE_SCALE" in s or "MAX_HANDLE_SCALE" in s:
                if s.startswith("from ") or s.startswith("import "):
                    continue
                users.append("%s:%d %s" % (fn, i, s[:80]))
    step("A7c NOTE MIN/MAX_HANDLE_SCALE 全仓无使用者（只被 drawing.py import 进来当摆设）",
         True, "非 import 引用点=%d %s" % (len(users), users[:4]))
except Exception:
    step("A7c FATAL", False, E.tb())

# ===========================================================================
# A8 · eps 语义审计
# ===========================================================================
FILES = ["state.py", "transform_domain.py", "time_domain.py", "cache.py",
         "interaction.py", "edit_geometry.py", "modal_edit.py", "spec_check.py",
         "drawing.py", "handles.py", "overlay.py", "ui.py", "spec_ui.py",
         "undo_guard.py", "debug_log.py"]

try:
    defs = {}
    for fn in FILES:
        try:
            txt = src(fn)
        except Exception:
            continue
        for mm in re.finditer(r"^([A-Za-z_][A-Za-z0-9_]*EPS[A-Za-z0-9_]*)\s*=\s*([0-9.eE+-]+)",
                              txt, re.M):
            defs.setdefault(mm.group(1), []).append(fn)
    dup = {k: v for k, v in defs.items() if len(v) > 1}
    step("A8a ★ 每个 eps 常量全仓唯一定义（不允许多份同义判据）", not dup,
         "; ".join("%s -> %s" % (k, v) for k, v in dup.items()) if dup
         else "唯一性 OK：" + ", ".join(sorted(defs)))
except Exception:
    step("A8a FATAL", False, E.tb())

try:
    WRONG = ("DT_EPS", "S_EPS", "FRAME_INT_EPS", "HANDLE_ZERO_EPS", "_ARM_EPS")
    hits = []
    for fn in FILES:
        try:
            txt = src(fn)
        except Exception:
            continue
        for i, line in enumerate(txt.splitlines(), 1):
            s = line.strip()
            if s.startswith("#") or "co[0]" not in s:
                continue
            for w in WRONG:
                if w in s:
                    hits.append("%s:%d %s" % (fn, i, s[:90]))
    step("A8b ★ 帧号匹配（co[0] 比较）只准用 FRAME_EPS，不得混用 dt/s/子帧 eps",
         not hits, "; ".join(hits) if hits else "全仓帧匹配只用 state.FRAME_EPS")
except Exception:
    step("A8b FATAL", False, E.tb())

try:
    same = (xf.DT_EPS == st.FRAME_EPS)
    step("A8c NOTE DT_EPS(1e-3, dt 可分辨下限) 与 FRAME_EPS(1e-3, 帧号匹配) 数值相同但语义不同",
         True,
         ("两者都= %r；数值撞车容易被人互换（A8b 已静态锁住不得互换）" % xf.DT_EPS)
         if same else "两者数值不同：DT_EPS=%r FRAME_EPS=%r" % (xf.DT_EPS, st.FRAME_EPS))
except Exception:
    step("A8c FATAL", False, E.tb())

# ===========================================================================
# B1 · 帧距 0.4 / 0.6 / 1e-3 / 0
# ===========================================================================
try:
    o, act = E.build_object("_EB_B1", ((0, (0, 0, 0)), (10, (1, 0, 0)), (20, (2, 0, 0))),
                            free_all=True)
    insert_all(o, 10.4, 1.7)
    insert_all(o, 10.6, 1.9)
    fr = frames_of(o)

    def kfa(f):
        kp = xf.keyframe_at(E.curves_of(o)[0], f)
        return None if kp is None else round(float(kp.co[0]), 4)

    got = {f: kfa(f) for f in (10.0, 10.2, 10.4, 10.5, 10.6, 10.7)}
    ok = (len(fr) == 5 and got[10.0] == 10.0 and got[10.4] == 10.4 and got[10.6] == 10.6
          and got[10.2] is None and got[10.5] is None and got[10.7] is None)
    step("B1a ★ 帧距 0.4 / 0.6：keyframe_at 精确命中各自的关键帧（不再被 0.5 容差吞掉）",
         ok, "帧表=%s 命中=%s" % (fr, got))
    chk_inv("B1a-inv 不变量", act, o)
except Exception:
    step("B1a FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_B1b", ((0, (0, 0, 0)), (10, (1, 0, 0)), (20, (2, 0, 0))),
                            free_all=True)
    insert_all(o, 10.001, 1.5)
    fr = frames_of(o)
    kp = xf.keyframe_at(E.curves_of(o)[0], 10.001)
    hit = None if kp is None else float(kp.co[0])
    step("B1b NOTE 帧距 1e-3：Blender 的 insert 直接把 10.001 并进 10.0（连关键帧都建不出来）",
         True, "插入 10.001 后帧表=%s；keyframe_at(10.001)=%r（子帧本就不支持，见 B2）"
         % (fr, hit))
    chk_inv("B1b-inv 不变量", act, o)
except Exception:
    step("B1b FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_B1c", ((0, (0, 0, 0)), (10, (1, 0, 0)), (20, (2, 0, 0))),
                            free_all=True)
    n0 = len(frames_of(o))
    insert_all(o, 10.0, 99.0)
    fr = frames_of(o)
    v10 = vals_at(o, 10.0)[0]
    step("B1c NOTE 帧距 0（重合关键帧）：Blender 用「替换」而非「新增」⇒ 同一曲线不可能有重合点",
         (len(fr) == n0 and abs(v10 - 99.0) < 1e-6),
         "插入前 %d 个 -> 插入后 %s 个；帧 10 的值=%r" % (n0, len(fr), v10))
    chk_inv("B1c-inv 不变量", act, o)
except Exception:
    step("B1c FATAL", False, E.tb())

# ===========================================================================
# B2 · 子帧关键帧（NOTE 口径）
# ===========================================================================
try:
    o, act = E.build_object("_EB_B2", ((0, (0, 0, 0)), (10, (1, 0, 0)), (20, (2, 0, 0))),
                            free_all=True)
    insert_all(o, 10.4, 1.7)
    insert_all(o, 10.6, 1.9)
    cnt, ex = (0, [])
    if ca is not None:
        cnt, ex = ca.detect_subframe_keyframes(bpy.context)
    kfm, span = td.resolve_target(act, o, 10.4, 'right')
    w = td.write_s(kfm, 'right', 0.5, span)          # 产品口径：freeze 默认 True
    upd(o)
    dts = dt_at(o, 10.4, 'right')
    ok = (cnt == 2 and len(ex) == 2 and span is not None and w == 0.5 and len(dts) == 3)
    step("B2 ★ 子帧关键帧：cache 检测到并给出提示（不静默），产品口径(freeze=True)写入不崩",
         ok, "detect=(%d, %s) span=%s write_s=%s dt=%s（NOTE：插件按整数帧建模，"
             "不支持子帧关键帧是既定口径）" % (cnt, ex, span, w, ["%.4f" % d for d in dts]))
    chk_inv("B2-inv 不变量", act, o)
except Exception:
    step("B2 FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_B2b", ((0, (0, 0, 0)), (10, (1, 0, 0)), (20, (2, 0, 0))),
                            free_all=True)
    insert_all(o, 10.4, 1.7)     # 新插入的关键帧手柄类型是 ALIGNED（活的）
    insert_all(o, 10.6, 1.9)
    kfm, span = td.resolve_target(act, o, 10.4, 'right')
    w = td.write_s(kfm, 'right', 0.5, span, freeze=False)
    upd(o)
    dts = dt_at(o, 10.4, 'right')
    v = E.invariants(act, o)
    step("B2b NOTE freeze=False + ALIGNED 手柄：fc.update() 只把【一根轴】的手柄时间拉走 ⇒ 三轴 dt 不一致",
         True,
         "write_s=%s dt=%s；不变量=%s（ALIGNED 是「活的」，Blender 按各轴值分量重算时间分量；"
         "产品所有 write_s 调用点都用默认 freeze=True，故这条只在显式传 freeze=False 时出现）"
         % (w, ["%.6f" % d for d in dts], v or "无"))
except Exception:
    step("B2b FATAL", False, E.tb())

# ===========================================================================
# B3 · 单关键帧
# ===========================================================================
try:
    o, act = E.build_object("_EB_B3", ((30, (1.0, 2.0, 3.0)),), free_all=True)
    kfl, sl = td.resolve_target(act, o, 30, 'left')
    kfr, sr = td.resolve_target(act, o, 30, 'right')
    wl = td.write_s(kfl, 'left', 0.5, sl, freeze=False)
    pd = td.apply_pixel_drag(act, o, 30, 'right', 100.0)
    step("B3 ★ 单关键帧：两侧都无段（span=None），write_s 返回 None，pixel_drag 明确报 ok=False",
         (sl is None and sr is None and wl is None and pd.get("ok") is False
          and bool(pd.get("message"))),
         "span L/R=%r/%r write_s=%r pixel_drag.ok=%s msg=%r"
         % (sl, sr, wl, pd.get("ok"), pd.get("message")))
    chk_inv("B3-inv 不变量", act, o)
except Exception:
    step("B3 FATAL", False, E.tb())

# ===========================================================================
# B4 · 两关键帧
# ===========================================================================
try:
    o, act = E.build_object("_EB_B4", ((0, (0, 0, 0)), (90, (1.0, 2.56, 0.4))), free_all=True)
    r0r = td.resolve_target(act, o, 0, 'right')[1]
    r0l = td.resolve_target(act, o, 0, 'left')[1]
    r90l = td.resolve_target(act, o, 90, 'left')[1]
    r90r = td.resolve_target(act, o, 90, 'right')[1]
    kfm, span = td.resolve_target(act, o, 0, 'right')
    w = td.write_s(kfm, 'right', 1.0, span, freeze=False)
    upd(o)
    dts = dt_at(o, 0.0, 'right')
    step("B4 ★ 两关键帧：内侧两侧都有段(90.0)，外侧两侧皆端点(None)，写满 s=1.0 不越界",
         (r0r == 90.0 and r0l is None and r90l == 90.0 and r90r is None
          and w == 1.0 and all(abs(d - 90.0) < 1e-3 for d in dts)),
         "span 0R/0L/90L/90R=%r/%r/%r/%r dt=%s" % (r0r, r0l, r90l, r90r,
                                                   [round(d, 4) for d in dts]))
    chk_inv("B4-inv 不变量", act, o)
except Exception:
    step("B4 FATAL", False, E.tb())

# ===========================================================================
# B5 · 极密（每帧一个 × 100 帧）
# ===========================================================================
try:
    dense = tuple((f, (f * 0.01, 0.0, 0.0)) for f in range(101))
    o, act = E.build_object("_EB_B5", dense, free_all=True)
    n = len(frames_of(o))
    kfm, span = td.resolve_target(act, o, 50, 'right')
    w = td.write_s(kfm, 'right', 0.5, span, freeze=False)
    upd(o)
    dts = dt_at(o, 50.0, 'right')
    step("B5 ★ 极密 101 帧：段长=1.0，s=0.5 ⇒ dt=0.5，全部三轴一致",
         (n == 101 and span == 1.0 and w == 0.5 and len(dts) == 3
          and all(abs(d - 0.5) < 1e-3 for d in dts)),
         "关键帧数=%d span=%s write_s=%s dt=%s" % (n, span, w, [round(d, 4) for d in dts]))
    chk_inv("B5-inv 不变量", act, o)
except Exception:
    step("B5 FATAL", False, E.tb())

# ===========================================================================
# B6 · 极疏（跨度 10000 帧）
# ===========================================================================
try:
    o, act = E.build_object("_EB_B6", ((0, (0, 0, 0)), (10000, (1.0, 2.0, 3.0))), free_all=True)
    kfm, span = td.resolve_target(act, o, 0, 'right')
    w = td.write_s(kfm, 'right', 1.0, span, freeze=False)
    upd(o)
    dts = dt_at(o, 0.0, 'right')
    step("B6 ★ 极疏 跨度 10000 帧：s=1.0 ⇒ dt=10000，不越段、无 NaN",
         (span == 10000.0 and w == 1.0 and len(dts) == 3
          and all(abs(d - 10000.0) < 1e-2 for d in dts)),
         "span=%s write_s=%s dt=%s" % (span, w, [round(d, 3) for d in dts]))
    chk_inv("B6-inv 不变量", act, o)
except Exception:
    step("B6 FATAL", False, E.tb())

# ===========================================================================
# B7 · 三轴关键帧数量不同
# ===========================================================================
try:
    o, act = E.build_object("_EB_B7", E.KEYS_3, free_all=True)
    fcs = E.curves_of(o)
    fcs[2].keyframe_points.remove(fcs[2].keyframe_points[2])   # Z 去掉 117
    fcs[2].update()
    fcs[1].keyframe_points.remove(fcs[1].keyframe_points[1])   # Y 去掉 90
    fcs[1].update()
    counts = {ax: len(fc.keyframe_points) for ax, fc in E.curves_of(o).items()}
    # ★★★ 2026-09-30 处理 A-1（Phase 1 极限测试抓到）—— **只修了一半，另一半有意不修**：
    #
    #   ① 真缺陷（已修）：`span` 取的是 `next(iter(kf_map.keys()))` ——
    #      **依赖曲线收集顺序**的隐式假设；而且"第一根轴是端点、别的轴有段"时
    #      会把整次编辑误拒。现在改成：逐轴算 span，代表值取有段的轴里轴号最小的那根。
    #
    #   ② 发现清单建议的修法（"端点轴就别写 dt 了"）**实测会把插件自己弄坏**，
    #      所以**没有采纳** —— 证据（本条下方断言会当场验证）：
    #        Z 在 90 这一侧没有右邻（span=None），但若因此**不写** Z，
    #        该帧同侧三轴 dt 就变成 [13.5, 13.5, 9.0] ⇒ **破了插件自己的规范**
    #        "同侧三轴 dt 相等"（`E.invariants` 当场报，见 B7-inv）。
    #        而且 `detect` 判"手柄贴合路径"用的正是 `dv ∝ dv/dt`：
    #        |dv| > 1.0 的数据上它**会当场报 dt_mismatch** ——
    #        用户刚拖完疏密三角就被说"手柄偏离路径"，那是用户可见的回归。
    #        插件自己的修复路径 `fix_unify_dt` 也是三轴一起写 ⇒ 口径本就如此。
    #      ⇒ 本条原先硬编码 `False`（记录 bug），现翻转为**防回归**断言：
    #        钉住"三轴都要写、dt 必须相等"，同时把逐轴 span 的事实写进 detail。
    z_dt_before = signed_dt_at(o, 90.0, 'right').get(2)
    kfm, span = td.resolve_target(act, o, 90, 'right')
    w = td.write_s(kfm, 'right', 0.5, span, freeze=False)
    upd(o)
    sd = signed_dt_at(o, 90.0, 'right')
    z_neighbor = td.neighbor_frame(act, o, 90, 'right')
    span_per_axis = {}
    for ax, fc in E.curves_of(o).items():
        kps = [k for k in fc.keyframe_points if abs(float(k.co[0]) - 90.0) < 1e-3]
        span_per_axis[ax] = td.segment_span(fc, kps[0], 'right') if kps else None
    step("B7 ★★ span 逐轴算且**确定**（不再看 dict 顺序）；三轴照写 ⇒ 同侧 dt 仍相等",
         sorted(kfm.keys()) == [0, 2]
         and span is not None and abs(span - 27.0) < 1e-9
         and w is not None and abs(w - 0.5) < 1e-9
         and abs(abs(sd.get(0, 0.0)) - 13.5) < 1e-3
         and abs(abs(sd.get(2, 0.0)) - 13.5) < 1e-3,
         "各轴关键帧数=%s；resolve_target(90,R) 覆盖轴=%s span=%s write_s=%s 各轴 dt=%s；"
         "逐轴 segment_span(90,R)=%s（Z 无右邻 ⇒ None，但仍写 dt —— 不写就破「同侧三轴 dt 相等」）；"
         "Z 轴 dt 写入前=%r 写入后=%r；"
         "neighbor_frame 走【跨轴帧号并集】=%r —— 它是**冻结用**的候选邻居，"
         "与 segment_span 的「可调段」是两回事（口径不同是有意的，见该函数 docstring）"
         % (counts, sorted(kfm.keys()), span, w,
            {k: round(v, 4) for k, v in sd.items()},
            {k: (None if v is None else round(v, 6)) for k, v in span_per_axis.items()},
            z_dt_before, sd.get(2), z_neighbor))
    chk_inv("B7-inv 不变量（dt 口径查不出，端点侧 span=None 直接跳过检查）", act, o)
except Exception:
    step("B7 FATAL", False, E.tb())

# ===========================================================================
# B8 · 帧 0 / 负帧 / 帧 1e6
# ===========================================================================
try:
    o, act = E.build_object("_EB_B8a", ((0, (0, 0, 0)), (10, (1, 0, 0))), free_all=True)
    insert_all(o, -5.0, -1.0)
    kfm, span = td.resolve_target(act, o, 0, 'left')
    w = td.write_s(kfm, 'left', 0.5, span, freeze=False)
    upd(o)
    dts = dt_at(o, 0.0, 'left')
    bpy.context.scene.frame_set(-5)
    fneg = int(bpy.context.scene.frame_current)
    step("B8a ★ 帧 0 与负帧(-5)：段长=5.0，写入正常，scene.frame_set(-5) 可达",
         (span == 5.0 and w == 0.5 and fneg == -5
          and all(abs(abs(d) - 2.5) < 1e-3 for d in dts)),
         "span=%s write_s=%s dt=%s frame_current=%d" % (span, w, [round(d, 4) for d in dts], fneg))
    chk_inv("B8a-inv 不变量", act, o)
except Exception:
    step("B8a FATAL", False, E.tb())

try:
    bpy.context.scene.frame_start = -5
    fs = int(bpy.context.scene.frame_start)
    step("B8b NOTE scene.frame_start 硬下限 0：设 -5 被静默钳到 %d（关键帧本身仍可为负）" % fs,
         fs == 0, "frame_start=%d" % fs)
except Exception:
    step("B8b FATAL", False, E.tb())

try:
    o, act = E.build_object("_EB_B8c", ((0, (0, 0, 0)), (1000000, (1.0, 2.0, 3.0))), free_all=True)
    kfm, span = td.resolve_target(act, o, 0, 'right')
    w = td.write_s(kfm, 'right', 1.0, span, freeze=False)
    upd(o)
    dts = dt_at(o, 0.0, 'right')
    step("B8c ★ 帧 1e6：跨度 1e6，s=1.0 ⇒ dt=1e6，无 NaN、不越段",
         (span == 1000000.0 and w == 1.0 and len(dts) == 3
          and all(abs(d - 1000000.0) < 1.0 for d in dts)),
         "span=%s write_s=%s dt=%s" % (span, w, [round(d, 2) for d in dts]))
    chk_inv("B8c-inv 不变量", act, o)
except Exception:
    step("B8c FATAL", False, E.tb())

# ===========================================================================
# 收尾
# ===========================================================================
try:
    E.flush(LOG, steps)
except Exception:
    print("FLUSH_FAILED " + E.tb())
print("EB_NUMERIC_DONE")
