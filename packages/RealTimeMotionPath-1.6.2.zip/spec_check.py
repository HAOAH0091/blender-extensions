# -*- coding: utf-8 -*-
"""RTMP 手柄「贴合检查」—— 纯检测层 + 微调层。

这个模块回答一个用户问题
------------------------
    我的动画，能不能让 3D 视图里的手柄正常地画出来、正常地拖？

判据散在好几处（保速闸门 / 联动判据 / 绘制零长判据）。本模块**不重新实现任何一条**，
只把它们**组合起来**。

分层（重要）
------------
    spec_check（本模块）  →  检测（detect）+ 微调（fix_*）
        ↓ 只调用既有 API
    transform_domain（手柄数学 / 联动判据 / 快照）
    cache           （曲线收集 / 求值）
    drawing         （外侧手柄判据）

★★★ 2026-09-30 用户拍板的设计修正（重要，别改回去）
----------------------------------------------------

★★★ 术语：有【两个完全不同的"折角"】，别混（2026-09-30 用户澄清 + 实测）
--------------------------------------------------------------------------
    ┌────────────────┬──────────────────────────────────┬──────────────────┐
    │                │ 判据                             │ 影响 3D？        │
    ├────────────────┼──────────────────────────────────┼──────────────────┤
    │ **GE 折角**    │ 每条曲线内，左右手柄在           │ ❌ **不影响**    │
    │                │ (时间, 值) 平面里不共线          │                  │
    │                │ = 速度【大小】突变（该轴）       │                  │
    ├────────────────┼──────────────────────────────────┼──────────────────┤
    │ **3D 手柄折角**│ 3D 空间里 dvL 与 dvR 不平行      │ ✅ 手柄线折了    │
    │                │ = 速度【方向】突变               │    + 路径拐角    │
    └────────────────┴──────────────────────────────────┴──────────────────┘

    用户原话：「你是不是误会我说的折角是 3d 视图路径手柄的折角，
              我说的是 GE 里的关键帧手柄的折角」—— 是的，之前混了。

    实测（用户工程 帧 90）——**两个数字差得远，证实是两回事**：
        GE 折角  = X 0.16° / Y 3.78° / Z 0.00°     ← 很小
        3D 折角  = 12.42°                          ← 手柄真的折了
        路径拐角 = 12.46°                          ← 对应 3D 折角

    用户自己的观察也印证：
        「用三角控制柄只调一侧速度 → GE 左右手柄出现折角，
          但 3D 视图的手柄还是直线」
      ⇒ 三角改的是**时间跨度（速度大小）**，方向没变 ⇒ GE 折了、3D 没折 ✓

    ⇒ 本模块**只报 3D 折角**（`handle_bend`）；**GE 折角不报**（不影响 3D）。

【追加】"强制对齐全部 GE 手柄" = **唯一一个可选项**（默认不勾）
    用户 2026-09-30：
        「需要追加一个勾选项，就是让用户可以选择是否把强制把 GE 的关键帧手柄都对齐，
          **当然这个对齐同时也要注意 dt 要一致**」

    ⇒ `force_align`：勾上后连**体感=自由**的手柄、**首末帧外侧手柄**也一起规范：
        · 对齐左右方向（dv 共线）
        · **同时统一每侧三轴的 dt** —— 否则"直了却不贴路径"
      （只对齐方向、不管 dt，会得到一条"直但不沿路径"的手柄 —— 用户特意提醒过。）

【修正一】3D 手柄折了 = **必须校正**（不是可选项）
    用户 2026-09-30 最终口径：
        「这个本来就是要保证的，不是选不选的问题，本来就是要校正这个，
          **除非路径手柄已经被用户提前设置成自由**」

    ⇒ `handle_bend` 是 **issues**（默认勾选修复）；
      **唯一例外**：体感 = 自由（`_link_mode() != 'link'`）时不动 —— 那是用户要的。

    —— 以下是推导过程（保留，说明为什么"3D 折角"必须修）——

    用户更早的口径（在澄清术语之前）：
    用户 2026-09-30 最终口径（两次澄清后）：
        「折角本身不是问题，**错误的折角**才是真问题；
          正确的折角不影响 3D 路径手柄与路径相切。
          我们的目标是**通过修改 GE 数据规范化数据来让 3D 视图手柄相切**。」
        「强制对齐 GE 手柄可以作为**可选项**供用户勾选，
          但不勾选也不影响路径校正功能；
          勾选了只是**强制把每个关键帧的进出速度对齐**。」

    ⇒ 两条判据分开：

        【必须修的】让 3D 手柄相切 —— `dt_mismatch` / `missing_axis`
        【可选的】把每个关键帧的进出方向对齐 —— `align_handles`（默认不勾）

    实测（用真实路径稠密采样的进入/离开切向做对照）：

        | 场景                     | 折角      | 左侧 vs 进入切向 | 右侧 vs 离开切向 |
        |--------------------------|-----------|------------------|------------------|
        | 全合规                   | 0.000°    | 0.050°           | 0.383°           |
        | **只有折角**（右Y长度↑） | **29.627°** | 0.050°         | **0.283°**       |
        | **只有 dt 不等**（右Y↑） | 0.000°    | 0.050°           | **10.509°**      |
        | **只有折角**（左Y长度↑） | **29.627°** | **0.091°**     | 0.383°           |

    ⇒ **折角 29.6° 时两侧手柄仍然完全相切**（0.05° / 0.28°）。
    ⇒ 「折角」和「相切」是**互相独立**的两件事：

        折角 ⟺ 左右 dv 不反向平行   （只跟【值分量】有关）
        相切 ⟺ 同侧三轴 dt 相等     （跟【时间分量】有关）

    ⚠️ 但折角有一个**可见后果**必须说清楚（2026-09-30 用户工程实测）：
        折角 ⟹ **路径在那一帧有拐角**。
        实测：帧 90 折角 59.95° ⟺ 路径转角 59.57° —— 两者是同一个东西的两种看法。
        （比喻：枕木歪了，铁轨在那里就拐了个弯。）
        ⇒ 想让路径转得顺，需要勾选 `align_handles`；但**它不是"正确性"问题**。

    比喻：铁轨上两根枕木。
        · 折角   = 两根枕木**没对齐**（一根歪了）→ 铁轨拐弯
        · 不相切 = 每根枕木**和铁轨的夹角不对**（斜着横跨）→ 这才是"错"
      一根枕木歪了，不代表它和铁轨的夹角不对 —— **两件事互不相干**。

    所以折角只进 `report["hints"]`（灰色提示），**不进 issues**；
    但它是 `align_handles` 这个**可选修复**的输入。

【修正二】切向必须用「直线夹角 + 解析切向」，不能有前向/后向之分
    用户报障（其实是本模块的 bug）：完全合规时，**左侧**手柄算出 **179.92°** 偏离。

    根因：3D 手柄画在关键帧的【过去】那侧 ⇒ 它的方向天然与"前进方向"**相反**。
          拿【前向】切向去比它，必然得到 ~180°。

    实测对照（只改左侧 Y 轴 dt，真实偏离 10.4°）：
        左侧 dv vs 前向切向 = 179.9197°   ← 错
        左侧 dv vs 反向前向 =   0.0803°   ← 对

    ⇒ 现在用 `_line_angle_deg`（**直线**夹角，180° 也算 0°）—— 左右两侧一视同仁。

    同时把"数值差分切向"换成**解析切向** `(dv/dt)`：
        · 数学上它就是路径切向（曲线由手柄定义）
        · **没有差分误差** ⇒ 原来那套"阈值必须与差分步长联合标定"的麻烦**整体消失**
          （旧实现里 eps=0.05 自带 0.383° 假角，曾把 dt 差 1% 误报成违规）

【修正三】手柄类型（④）与对齐锁定（⑤）不再单独报错，改成**自动前置**
    用户原话：
        「blender 默认追加关键帧的手柄类型就是 auto clamped，所以基本每次都会跳弹窗。
          是不是 GE 手柄类型相关的判断可以直接跳过，直接应用规范化微调即可？」

    成立，因为：**所有微调本来都会把碰到的关键帧转成 FREE**。
    ⇒ 不再把 ④⑤ 当"问题"报给用户；任何一次微调都会**先冻结再写**。

    ⚠️ 但有一件事**不能跳过**：转 FREE 前必须**判断原始类型**，据此登记**体感**。
       转 FREE 后插件的"拖一侧另一侧跟着动"靠体感表判断；
       不登记就会被当成"用户手动设的自由" ⇒ **联动失效**（用户会立刻发现手感变了）。
       比喻：FREE 是"这扇门现在归你管了"；但**归谁管**和**原来归谁管**是两件事 ——
             原来归"自动门"管的，转过来仍按自动门的规矩联动。

【修正四】只冻结**被碰到**的关键帧
    "规整整个 GE"听起来痛快，但冻结无关手柄的唯一后果是**丢掉 Blender 的自动平滑**，
    没有任何好处 ⇒ 只动该动的。
"""
import math

from . import transform_domain as xf
from . import drawing
from .state import FRAME_EPS, warn_once


# ===========================================================================
# 阈值 —— **唯一来源**（别在别处再写第二份）
# ===========================================================================

# 角度判据：小于它就算"贴合"。
#
# ★ 现在用的是**解析切向**（`dv/dt`），没有数值差分误差 ⇒ 这个阈值**纯是手感选择**，
#   不再是"噪声地板"。（旧实现必须留出 12 倍余量给差分假角。）
#
# 标定（测试路径，dv=[1,0.5,0.25]）：
#     dt 差 0%  → 0.00°      差 2%  → 0.45°
#     差 5%     → 1.08°      差 25% → 4.90°      差 75% → 10.36°
# ⇒ 1.0° 相当于"dt 差 5% 才报"：滤掉用户手调的正常抖动，抓得住真违规。
ANGLE_EPS_DEG = 1.0

# 手柄「太短就不判」的下限 —— **引用** transform_domain 的定义，不重定义。
# 理由：与保速闸门同口径 —— 极短手柄的方向由浮点噪声主导，判它没意义。
MIN_HANDLE_LEN = xf.UNIFORM_LEN_MIN

# 时间分量小于它就无法算切向（除零）。这种情况跳过该侧检查。
DT_MIN = 1e-6


# ===========================================================================
# 小工具（纯函数，不碰 bpy）
# ===========================================================================

def _T(s):
    """界面文案走翻译（与项目其它模块同口径：英文原文 + translations.py 提供中文）。"""
    try:
        from bpy.app.translations import pgettext_iface as _iface
        return _iface(s)
    except Exception:
        return s


def _side_en(side):
    return "left" if str(side) == 'left' else "right"


def _norm(v):
    return math.sqrt(sum(x * x for x in v))


def _angle_deg(u, v):
    """两个三维向量的**方向**夹角（度）。任一为零向量 ⇒ None。"""
    nu, nv = _norm(u), _norm(v)
    if nu < 1e-12 or nv < 1e-12:
        return None
    d = sum(u[i] * v[i] for i in range(3)) / (nu * nv)
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def _line_angle_deg(u, v):
    """两个方向的**直线**夹角（度）：180° 也算 0°（同一条直线）。

    ★★ 为什么必须用直线夹角（踩过的坑）：
        3D 手柄画成一条**线段**（关键帧两侧各半），路径切线也是一条**直线**。
        而左侧手柄的方向天然与"前进方向"**相反**（它指向关键帧的"过去"），
        用**方向**夹角去比，完全合规时也会得到 ~180°。

        实测（完全合规）：左侧 dv vs 前向切向 = 179.9197°，右侧 = 0.0803°。
        ⇒ 左侧被算成"偏离 179.92°"，弹窗会显示一个荒谬的数字。

    用直线夹角后，左右两侧**一视同仁**，不需要任何"前向/后向"分支。
    """
    a = _angle_deg(u, v)
    if a is None:
        return None
    return min(a, 180.0 - a)


def _dt_spread(dt_abs):
    """同侧三轴 dt 的极差。

    ★★ E1 的落地点：**只在同一侧的三轴内部比较，绝不跨侧。**

        「左右 dt 不同」正是「单边调速」的定义 —— 那是插件的正常用法，
        不是违规（实测：三角调速后 右 dt=0.001 / 左 dt=8.0，完全合法）。

    ⚠️ 抽成独立函数是为了让它**成为唯一的判据入口**：
       测试的 bug 注入会替换它来验证"这条判据真的被用到了"（见 I7）。
    """
    if not dt_abs:
        return 0.0
    return max(dt_abs) - min(dt_abs)


def _side_is_off_path(dv_vec, dt_vec):
    """该侧手柄偏离路径的角度（度）；None = 判不了（dt 太小）。

    ★★ E1 的落地点：**判据只用【本侧】的 dv 与 dt**（同一侧的三轴内部比较），
       绝不把对侧的 dt 拉进来比。

       「左右 dt 不同」正是「单边调速」的定义 —— 那是插件的正常用法，不是违规
       （实测：三角调速后 右 dt=0.001 / 左 dt=8.0，完全合法）。

    ⚠️ 抽成独立函数是为了让它成为**唯一的判据入口**：
       测试的 bug 注入会替换它来验证"这条判据真的被用到了"（见 I7）。
       而"判据本身有没有被改成跨侧比较"由 A14 守（三角调速后必须 0 条）。
    """
    rate = _tangent_rate(dv_vec, dt_vec)
    if rate is None:
        return None
    return _line_angle_deg(dv_vec, rate)


def _tangent_rate(dv_vec, dt_vec):
    """路径切向 ∝ **(dv/dt)**（逐轴相除）。

    ★ 为什么这是"解析切向"而不是近似：
        曲线在关键帧处的走向**就是由该侧手柄定义的**。
        手柄在 (时间, 值) 平面上的偏移是 `(dt, dv)` ⇒ 该侧的 `d值/d时间 = dv/dt`。
        路径参数就是时间 ⇒ 这就是路径切向。

    ★ 相比"数值差分切向"的好处：
        · 零误差（差分有割线误差，旧实现 eps=0.05 自带 0.383° 假角）
        · 不需要 `TANGENT_EPS`，也就不需要"阈值与步长联合标定"那套复杂度

    ⚠️ 缺轴时**不能**用它：手柄只有 2 个分量，切向也只有 2 个 ⇒ 两边"一起缺"会自洽
       ⇒ 量不出偏差。所以缺轴的帧必须先被 E3 拦掉（只报 missing_axis，不做本项检查）。

    返回长度 3 的列表；任一轴 dt 太小 ⇒ None（无法定义切向）。
    """
    out = []
    for i in range(3):
        d = dt_vec[i]
        if abs(d) < DT_MIN:
            return None
        out.append(dv_vec[i] / d)
    return out


# ===========================================================================
# 数据收集
# ===========================================================================

def _axis_curves(action, obj, bone_name=None):
    """{array_index: fcurve} —— 位置曲线（既有唯一入口）。"""
    out = {}
    for fc in xf._position_curves(action, obj, bone_name):
        try:
            out[int(fc.array_index)] = fc
        except Exception:
            continue
    return out


def _frames_of(curves):
    """三轴关键帧帧号的**并集**（排序）。

    ⚠️ 用并集而不是交集：某轴缺关键帧的帧也要被检查到（那正是规范③）。
    """
    frames = set()
    for fc in curves.values():
        try:
            for kp in fc.keyframe_points:
                frames.add(round(float(kp.co[0]), 4))
        except Exception:
            warn_once("spec_check._frames_of")
            continue
    return sorted(frames)


def _frame_map(curves, frame):
    """{axis: keyframe} —— 该帧三轴各自的关键帧（缺的轴不出现）。"""
    out = {}
    for ax, fc in curves.items():
        kp = xf.keyframe_at(fc, frame)
        if kp is not None:
            out[ax] = kp
    return out


def _ge_fold_deg(dv_l, dt_l, dv_r, dt_r):
    """**GE 折角**（度）—— 该轴曲线在 (时间, 值) 平面里左右手柄的夹角。

    ★★ 这就是用户说的"GE 里的关键帧手柄折角"（不是 3D 手柄折角）。

    共线 ⟺ 0° ⟺ 进出**速度**相等（dvL/dtL == dvR/dtR）。

    ⚠️ 别和 `_angle_deg(dvL, -dvR)` 混（那是 **3D 手柄折角**）：
        实测用户工程 帧 90 —— 3D 折了 12.42°，GE 折角却只有 X 0.16° / Y 3.78° / Z 0.00°。
    """
    try:
        u = [float(dt_l), float(dv_l)]
        v = [-float(dt_r), -float(dv_r)]
        nu = math.hypot(u[0], u[1])
        nv = math.hypot(v[0], v[1])
        if nu < 1e-12 or nv < 1e-12:
            return None
        d = (u[0] * v[0] + u[1] * v[1]) / (nu * nv)
        return math.degrees(math.acos(max(-1.0, min(1.0, d))))
    except Exception:
        return None


def _side_vec(kp_map, side):
    """该侧手柄的 (dv 三轴, dt 三轴)。

    dv = 值分量相对 co 的偏移（3D 视图里画的**就是它**）
    dt = 时间分量相对 co 的偏移（**带符号**：左侧为负、右侧为正）
    """
    dv, dt = {}, {}
    for ax, kp in kp_map.items():
        try:
            if side == 'left':
                dv[ax] = float(kp.handle_left[1]) - float(kp.co[1])
                dt[ax] = float(kp.handle_left[0]) - float(kp.co[0])
            else:
                dv[ax] = float(kp.handle_right[1]) - float(kp.co[1])
                dt[ax] = float(kp.handle_right[0]) - float(kp.co[0])
        except Exception:
            continue
    return dv, dt


def _is_hidden_side(frame, side, first_frame, last_frame):
    """外侧手柄（首帧左 / 末帧右）—— 绘制与交互都跳过，本模块也不检查。

    ⚠️ 复用 `drawing._endpoint_is_hidden_side`（唯一判据），不自己判。
    """
    try:
        return bool(drawing._endpoint_is_hidden_side(
            abs(float(frame) - float(first_frame)) < FRAME_EPS,
            abs(float(frame) - float(last_frame)) < FRAME_EPS,
            side))
    except Exception:
        warn_once("spec_check._is_hidden_side")
        return False


# ===========================================================================
# 主检测
# ===========================================================================

def detect(action, obj, bone_name=None):
    """检查一个 action 的 3D 手柄能否正常显示与拖拽。

    返回 Report dict：
        {
          "obj_name", "action_name", "bone_name",
          "issues": [Issue, ...],     # 需要用户决定是否修的
          "hints":  [Issue, ...],     # 仅供参考（不影响 3D 操作）
          "checked_frames": int,
          "elapsed_ms": float,
        }

    Issue = {
        "kind", "frame", "side", "axes", "severity", "detail", "metrics"
    }

    ⚠️ **纯读**：不写任何数据（测试 C2 会逐位比对前后 fcurve）。
    """
    import time as _time
    t0 = _time.perf_counter()

    report = {
        "obj_name": getattr(obj, "name", None),
        "action_name": getattr(action, "name", None),
        "bone_name": bone_name,
        "issues": [],
        "hints": [],
        "checked_frames": 0,
        "elapsed_ms": 0.0,
    }
    if action is None or obj is None:
        return report

    try:
        curves = _axis_curves(action, obj, bone_name)
        if not curves:
            return report

        frames = _frames_of(curves)
        if not frames:
            return report
        report["checked_frames"] = len(frames)
        first_frame, last_frame = frames[0], frames[-1]

        seen = set()          # 去重：同一 (kind, frame, side)

        def _add(bucket, kind, frame, side, axes, severity, detail, metrics=None):
            key = (kind, round(float(frame), 4), side)
            if key in seen:
                return
            seen.add(key)
            report[bucket].append({
                "kind": kind,
                "frame": float(frame),
                "side": side,
                "axes": sorted(axes),
                "severity": severity,
                "detail": detail,
                "metrics": metrics or {},
            })

        for frame in frames:
            kp_map = _frame_map(curves, frame)

            # ---------- 规范③：三轴帧号集合是否一致 ----------
            #  ★ E3：缺轴 ⇒ **只报缺轴**，跳过该帧其余检查
            #     （缺轴时切向只有 2 个分量，与手柄"一起缺"会自洽 ⇒ 硬判必然量不出偏差）
            missing_axes = [a for a in (0, 1, 2) if a not in kp_map]
            if missing_axes:
                _add("issues", "missing_axis", frame, None, missing_axes, "functional",
                     _T("Frame %g has no %s keyframe - the handle is missing one "
                        "component and dragging writes incompletely")
                     % (frame, "/".join("XYZ"[a] for a in missing_axes)),
                     {"missing_axes": missing_axes})
                continue

            for side in ('left', 'right'):
                # 外侧手柄：绘制与交互都跳过 ⇒ 不检查
                if _is_hidden_side(frame, side, first_frame, last_frame):
                    continue

                dv, dt = _side_vec(kp_map, side)
                if not dv or not dt:
                    continue
                dv_vec = [dv.get(a, 0.0) for a in (0, 1, 2)]
                dt_vec = [dt.get(a, 0.0) for a in (0, 1, 2)]
                dt_abs = [abs(x) for x in dt_vec]

                # 手柄太短 ⇒ 方向由浮点噪声主导，判它没意义（与保速闸门同口径）
                if _norm(dv_vec) <= MIN_HANDLE_LEN:
                    continue

                # ---------- 规范①：手柄是否与路径贴合 ----------
                #  ★ 判据 = 手柄方向 vs **解析切向** 的**直线**夹角
                #    （直线夹角 ⇒ 左右一视同仁；解析切向 ⇒ 零误差）
                ang = _side_is_off_path(dv_vec, dt_vec)
                if ang is not None and ang > ANGLE_EPS_DEG:
                    _add("issues", "dt_mismatch", frame, side, [0, 1, 2], "cosmetic",
                         _T("Frame %g %s handle is off the path by %.2f deg "
                            "(the three axes use time spans %s)")
                         % (frame, _side_en(side), ang,
                            " / ".join("%g" % v for v in dt_abs)),
                         {"dt": dt_abs, "angle_deg": round(ang, 4),
                          "spread": _dt_spread(dt_abs)})

            # ---------- 3D 手柄折了（= 路径拐角）----------
            #  ★★ 这是**真问题**，必须校正（用户口径：「本来就是要保证的」）。
            #     3D 手柄在视口里画成【一条线段】：(co - dvL) ──●── (co + dvR)。
            #     这条线要"贴着路径"，前提是【路径在那里光滑】；
            #     折了 ⇒ 路径拐角 ⇒ 只能贴住一半 ⇒ 看起来就是"不相切"。
            #
            #  ⚠️ 唯一例外（E2）：体感 = 自由时**不报也不修** ——
            #     那是用户主动要的"左右各调各的"（用户口径：
            #     「除非路径手柄已经被用户提前设置成自由」）。
            dv_l, _ = _side_vec(kp_map, 'left')
            dv_r, _ = _side_vec(kp_map, 'right')
            vl = [dv_l.get(a, 0.0) for a in (0, 1, 2)]
            vr = [dv_r.get(a, 0.0) for a in (0, 1, 2)]
            if _norm(vl) > MIN_HANDLE_LEN and _norm(vr) > MIN_HANDLE_LEN:
                try:
                    # ⚠️ 复用全仓唯一的联动判据（别自己写体感映射）
                    mode = xf._link_mode(kp_map[0], 'right')
                except Exception:
                    warn_once("spec_check.detect._link_mode")
                    mode = None
                if mode == 'link':
                    fold = _angle_deg(vl, [-x for x in vr])
                    if fold is not None and fold > ANGLE_EPS_DEG:
                        _add("issues", "handle_bend", frame, None, [0, 1, 2], "cosmetic",
                             _T("Frame %g: the 3D handle is bent by %.2f deg, so the "
                                "path turns a corner here")
                             % (frame, fold),
                             {"fold_deg": round(fold, 4)})
    except Exception:
        warn_once("spec_check.detect")
    finally:
        report["elapsed_ms"] = round((_time.perf_counter() - t0) * 1000.0, 3)

    return report


# ===========================================================================
# 便捷查询（供 UI 用）
# ===========================================================================

def has_issues(report):
    """有没有**需要用户决定**的问题（hints 不算）。"""
    return bool(report and report.get("issues"))


def summarize(report):
    """按 kind 统计，供按钮文案（"发现 N 处不贴合"）。"""
    out = {}
    for it in (report or {}).get("issues", []):
        out[it["kind"]] = out.get(it["kind"], 0) + 1
    return out


# 供 UI 显示的短标签（英文原文；中文由 translations.py 提供）
KIND_LABEL = {
    "dt_mismatch": "Handle is off the path (not tangent)",
    "missing_axis": "An axis has no keyframe here (handle misses a component)",
    "handle_bend": "3D handle is bent (the path turns a corner here)",
}


# ===========================================================================
# 微调器（**会写数据**）
#
# 统一原则（每一条都必须遵守，否则会踩项目历史上踩过的坑）
# ----------------------------------------------------------
#   1. **写入前先冻结成 FREE**（保坐标）—— 否则 Blender 会反手改掉手柄长度
#      （实测：ALIGNED 下改 dt 会被反噬，折角 14.41°）。
#   2. 写入后 `fc.update()`。
#   3. **每次写前重新取关键帧对象** —— 缓存下来的包装对象用过一次就「钝」了。
#   4. 写前存快照（`snapshot_for_fix`），供一键还原。
#   5. undo 由**调用方**推（这里只负责改数据）—— 便于测试单独调用。
# ===========================================================================

# ---------------------------------------------------------------------------
# 强制对齐（**可选的平滑项**，不是"正确性"修复）
#
# 用户 2026-09-30 口径：
#     「强制对齐 GE 手柄可以作为**可选项**供用户勾选，
#       但不勾选也不影响路径校正功能；
#       勾选了只是**强制把每个关键帧的进出速度对齐**。」
#
# 效果：把每个关键帧的左右手柄方向对齐成**一条直线**（保留各自长度）。
#       ⇒ 路径在那一帧不再拐角（进入方向 = 离开方向）。
# ⚠️ 代价：**会改变路径形状**（方向变了），所以默认**不勾选**。
# ---------------------------------------------------------------------------

# 共线化策略（实测对路径形状的影响，测试路径长 6.6）
COLLINEAR_STRATEGIES = ('right_only', 'left_only', 'bisect', 'length_weighted')
COLLINEAR_DEFAULT = 'bisect'      # 角平分：单段最大变形最小（0.131 < 0.242/0.259/0.143）

# ★★ 2026-09-30（Phase 1 极限测试 · D-7 / D-8）：bisect / length_weighted 的
#    **退化角**（度）—— 两侧手柄方向的夹角小于它，就认为"两侧指向同一个地方"。
#
#    打个比方：bisect 干的事是"给两个人的分歧取中间点"。
#      · 两个人朝**相反**方向站（fold=0，正常情况）⇒ 中间点清清楚楚。
#      · 两个人朝**同一个**方向站（fold=180，路径在这一点**掉头**）⇒
#        "中间点"根本不存在 —— 怎么取都是自己说了算，不是数据说了算。
#        数学上 `ul - ur` 在夹角→0 时**极限就是垂直方向**：
#        实测两侧只差 1e-7 度（纯浮点噪声）时，两根手柄被**凭空扭 90°**
#        ⇒ 路径形状由"第 15 位小数"决定（D-8：形变 0.72）。
#      · 夹角**正好** 0（D-7 的复现）时 `ul - ur = 0` ⇒ 归一化仍是零向量
#        ⇒ 两侧 dv 被写成 0 ⇒ **手柄长度清零**（1.1456 → 0.0），
#        而 detect 又因"零长手柄跳过"看不见它 ⇒ **静默毁掉路径**。
#
#    ⇒ 阈值取插件自己的"算不算折角"门槛 `ANGLE_EPS_DEG`（1°）：
#      低于 1° 的差别在**视觉上就是同一个方向**（与本模块其它判据同口径，
#      不另立一个新数字 —— 同一语义只留一个来源）。
COLLINEAR_PARALLEL_DEG = ANGLE_EPS_DEG


def _as_unit(v):
    n = _norm(v)
    if n < 1e-12:
        return [0.0, 0.0, 0.0], 0.0
    return [x / n for x in v], n


def _target_dirs(dv_l, dv_r, strategy):
    """按策略算出左右手柄的**目标单位方向**（两者必须反向）。

    返回 (unit_left, unit_right)。

    ★★ 2026-09-30（Phase 1 · D-7 / D-8）：**退化保护**（本函数唯一的"兜底"）。

        只有 `bisect` 与 `length_weighted` 会退化 —— 它们算的是"中间值"：
            bisect           : m = ul - ur                （角平分）
            length_weighted  : m = (1-w)·ul + w·(-ur)     （按长度加权）

        `ul` 与 `ur` **同向**时（路径在该帧掉头，fold=180）：
            bisect           ⇒ m = 0        ⇒ 零向量
            length_weighted  ⇒ 两侧等长时 m = 0 ⇒ 零向量
        零向量经 `_as_unit` 归一化**仍然返回零方向**（它不抛异常、不报错），
        调用方 `_set_side_dv` 于是老老实实把 dv 写成 0
        ⇒ **手柄长度清零**，而 detect 又因"零长手柄跳过"看不见 ⇒ 静默。

        只差一点点（近同向）时更阴：m 是个噪声级的小向量，它的**方向**
        完全由浮点尾数决定 ⇒ 手柄被扭 90°（见 `COLLINEAR_PARALLEL_DEG`）。

        ⚠️ 为什么只兜 `bisect` / `length_weighted`，**不动** `right_only` /
           `left_only`：后两者本来就不算"中间值"，而是明确"以某一侧为准"
           （right_only ⇒ t = ul；left_only ⇒ t = -ur），
           `ul`/`ur` 只要非零就**永远有定义**，不存在退化。
           给它们套兜底反而会把 left_only 的语义偷换成 right_only。

        ⚠️ 兜底取 `t = ul`（即 right_only 的做法：**保左边、翻右边**）：
           退化时"怎么取都同样好"（最小二乘目标在夹角→0 时是**平的**），
           所以这里只需要"确定、可复现、不放大噪声"，不需要"更优"。
    """
    ul, ll = _as_unit(dv_l)
    ur, lr = _as_unit(dv_r)
    if ll < 1e-12 or lr < 1e-12:
        return ul, ur
    if strategy in ('bisect', 'length_weighted'):
        _par = _angle_deg(ul, ur)
        if _par is None or _par < COLLINEAR_PARALLEL_DEG:
            return ul, [-x for x in ul]
    if strategy == 'right_only':
        t = ul                          # 以左侧为准 ⇒ 只转右侧
    elif strategy == 'left_only':
        t = [-x for x in ur]            # 以右侧为准 ⇒ 只转左侧
    elif strategy == 'length_weighted':
        w = ll / (ll + lr)              # 长的一侧少转
        m = [(1.0 - w) * ul[i] + w * (-ur[i]) for i in range(3)]
        t, _n = _as_unit(m)
    else:                               # 'bisect'（默认）：角平分
        m = [ul[i] - ur[i] for i in range(3)]
        t, _n = _as_unit(m)
    return t, [-x for x in t]


def _set_side_dv(kp_map, side, dv_target):
    """把某侧三轴的**值分量**写成指定目标（**不动时间分量**）。"""
    for ax, kp in kp_map.items():
        if ax not in dv_target:
            continue
        h = kp.handle_right if side == 'right' else kp.handle_left
        t = float(h[0])                       # 时间分量原样保留
        v = float(kp.co[1]) + float(dv_target[ax])
        if side == 'right':
            kp.handle_right = (t, v)
        else:
            kp.handle_left = (t, v)


def _feel_for_orig_type(t):
    """原始手柄类型 ⇒ 该登记的**体感**（与 `xf.orig_type_for_feel` 互逆）。

    为什么要这一步：转成 FREE 之后，`_link_mode` 对"未记录 + 原始 FREE"
    会返回 'free' ⇒ 插件的手柄联动**不再生效**（用户会感觉"拖一侧另一侧不跟了"）。
    所以转类型前必须先登记体感 —— 既有 `make_handles_editable` 的同款做法。

    原始是 FREE 时返回 None（**不登记**）：那是"用户手动要的自由"，不是插件接管。

    ⚠️ 2026-09-30：**唯一实现已搬到 `xf.feel_for_orig_type`**（因为 `time_domain`
       也要用它，不该从本模块反向 import）。这里只做委托，别写两份。
    """
    return xf.feel_for_orig_type(t)


def _freeze_keyframe(kp, sides=('left', 'right')):
    """把该关键帧的**两侧手柄一起**转成 FREE，坐标一个数都不动。

    ⚠️⚠️ 为什么必须【两侧一起】转（2026-09-30 实测踩到的坑，很隐蔽）：

        只转一侧时，另一侧**仍然是派生类型**；紧接着调用 `fc.update()`，
        Blender 会把"仍然派生"的那一侧**重算掉** —— 你刚保住的坐标就丢了。

        实测（只转左侧）：
            右侧 hr_v  4.708333  →  4.125000   ✗ 被吞
            右侧 hr_v  1.341667  →  1.125000   ✗ 被吞
        （数值看着"很整齐"，正因为它变成了 Blender 按公式算的值。）

        这正是既有 `make_handles_editable` 同时设置
        `handle_left_type` 与 `handle_right_type` 的原因。

    :param sides: 只对指定侧做体感登记；**类型两侧都转**（防重算）
    """
    changed = False
    try:
        hl = kp.handle_left.copy()
        hr = kp.handle_right.copy()
    except Exception:
        return False
    # ① 保体感（未记录时才写；已记录的不覆盖用户的选择）
    for side in sides:
        try:
            if xf.feel_type(kp, side) is not None:
                continue
            orig = str(kp.handle_left_type if side == 'left'
                       else kp.handle_right_type)
            feel = _feel_for_orig_type(orig)
            if feel is not None:
                xf.mark_feel(kp, side, feel)
        except Exception:
            warn_once("spec_check._freeze_keyframe.feel")
    # ② 两侧一起转类型 + 写回坐标（顺序不能反）
    try:
        if str(kp.handle_left_type) != 'FREE' or str(kp.handle_right_type) != 'FREE':
            changed = True
        kp.handle_left_type = 'FREE'
        kp.handle_right_type = 'FREE'
        kp.handle_left = hl
        kp.handle_right = hr
    except Exception:
        warn_once("spec_check._freeze_keyframe")
        return False
    return changed


def _freeze_side_preserving(kp, side, feel_value=None):
    """薄包装：实际冻结**两侧**（见 `_freeze_keyframe` 的说明）。

    `feel_value` 参数保留但不再使用 —— 体感现在按**各侧原始类型**分别推导
    （比"整帧套一个值"更准：左右两侧的原始类型理论上可以不同）。
    """
    return _freeze_keyframe(kp, sides=(side, 'left' if side == 'right' else 'right'))


# ===========================================================================
# 快照（供一键还原）
# ===========================================================================

def snapshot_for_fix(action, obj, bone_name=None):
    """把**整条曲线**的状态存下来（含时间分量与类型），供 `revert_fix` 还原。

    为什么不复用 `xf.snapshot_positions`：
        那个 API 只记**指定帧**、且不含"补出来的关键帧"信息。
        微调会新增关键帧，还原时必须知道**该删哪些** ⇒ 需要整条曲线快照。
    """
    snap = {"curves": {}, "frames_added": [], "feel": {}}
    for ax, fc in _axis_curves(action, obj, bone_name).items():
        per = {}
        try:
            for kp in fc.keyframe_points:
                f = round(float(kp.co[0]), 4)
                per[f] = {
                    'co_t': float(kp.co[0]), 'co_v': float(kp.co[1]),
                    'hl_t': float(kp.handle_left[0]), 'hl_v': float(kp.handle_left[1]),
                    'hr_t': float(kp.handle_right[0]), 'hr_v': float(kp.handle_right[1]),
                    'hlt': str(kp.handle_left_type), 'hrt': str(kp.handle_right_type),
                }
        except Exception:
            warn_once("spec_check.snapshot_for_fix")
        snap["curves"][ax] = per
    return snap


def revert_fix(action, obj, snap, bone_name=None):
    """把 `snapshot_for_fix` 的结果写回（含**删掉补出来的关键帧**）。

    返回还原的关键帧数。
    """
    if not snap:
        return 0
    n = 0
    for ax in list((snap.get("curves") or {}).keys()):
        per = (snap.get("curves") or {}).get(ax) or {}
        # ① 删掉"补出来的"关键帧（快照里没有的帧）
        try:
            doomed = []
            _fc = _axis_curves(action, obj, bone_name).get(ax)
            if _fc is not None:
                for kp in _fc.keyframe_points:
                    f = round(float(kp.co[0]), 4)
                    if f not in per:
                        doomed.append(f)
            for f in doomed:
                # ⚠️ 每次重新取 fcurve（包装对象删一次就钝了）
                for _ in range(4):
                    _fc = _axis_curves(action, obj, bone_name).get(ax)
                    if _fc is None:
                        break
                    _kp = None
                    for k in _fc.keyframe_points:
                        if abs(float(k.co[0]) - f) < FRAME_EPS:
                            _kp = k
                            break
                    if _kp is None:
                        break
                    _fc.keyframe_points.remove(_kp)
                n += 1
        except Exception:
            warn_once("spec_check.revert_fix.remove")
        # ② 写回原有帧的数值 + 类型
        try:
            for f, vals in per.items():
                for _ in range(3):
                    _fc = _axis_curves(action, obj, bone_name).get(ax)
                    if _fc is None:
                        break
                    _kp = xf.keyframe_at(_fc, f)
                    if _kp is None:
                        break
                    try:
                        _kp.co = (vals['co_t'], vals['co_v'])
                        # ⚠️ 先设类型再写坐标：设类型可能触发 Blender 重算
                        _kp.handle_left_type = vals['hlt']
                        _kp.handle_right_type = vals['hrt']
                        _kp.handle_left = (vals['hl_t'], vals['hl_v'])
                        _kp.handle_right = (vals['hr_t'], vals['hr_v'])
                        break
                    except Exception:
                        continue
        except Exception:
            warn_once("spec_check.revert_fix.write")
    for fc in _axis_curves(action, obj, bone_name).values():
        try:
            fc.update()
        except Exception:
            pass
    return n


# ===========================================================================
# 各条微调
# ===========================================================================

# ---------------------------------------------------------------------------
# dt 的读写小工具（**唯一来源**，别在别处再写一份）
# ---------------------------------------------------------------------------

def _side_dt(kp, side):
    """该关键帧某一侧手柄的 dt **绝对值**（时间分量离 co 的距离）。"""
    h = kp.handle_left if side == 'left' else kp.handle_right
    return abs(float(h[0]) - float(kp.co[0]))


def _rescale_side_dt(kp, side, dt_new):
    """把某一侧手柄的 dt 换成 `dt_new`，并**同比例缩放值分量**（保速 ⇒ 保切向）。

    ★★ 为什么必须连值分量一起缩放（2026-09-30 · D-5 收尾实测，**别改回只动 dt**）：

      手柄在 (时间, 值) 平面上的位置是 `(co_t + dt, co_v + dv)`。
      只改 dt、不动 dv ⇒ **速度 `dv/dt` 变了**，两个后果：

        ① **手柄方向不再等于路径切向** —— 而"手柄贴合路径"正是本插件要保证的规范
           （`detect` 判的 `dv ∝ dv/dt`，等价于"同侧三轴 dt 相等"）；
           ⇒ 那等于"为了满足规范，先把规范想表达的东西破坏掉"，本末倒置。
        ② **曲线形状被改**：实测 haus 距离 0.184（约 3%）——
           而 `fix_missing_axes` 的 docstring 承诺"补轴不改动现有轨迹"，
           直接把 `gui_spec_inspect_check.py` 的 B1b 断言打红（实测踩到）。

      同比例缩放 dv ⇒ 速度**逐位不变** ⇒ 切向不变；
      而且在"补出来的点落在原曲线上"（各轴值共线）这种最常见的情形下，
      手柄始终落在同一条直线上 ⇒ **形状逐位不变** ✓。

      这正是 `transform_domain.scale_handle_uniform` 那条路"保速"的同一条道理 ——
      同一个物理量（速度），全仓只留一套算法。

    :return: True = 写了；False = 没写（dt 旧值是 0，缩放比无从定义 ⇒ 退化，放弃）
    """
    h = kp.handle_left if side == 'left' else kp.handle_right
    dt_old = abs(float(h[0]) - float(kp.co[0]))
    dv_old = float(h[1]) - float(kp.co[1])
    if dt_old <= 1e-12:
        return False
    dv_new = dv_old * (float(dt_new) / dt_old)
    if side == 'left':
        kp.handle_left = (float(kp.co[0]) - float(dt_new),
                          float(kp.co[1]) + dv_new)
    else:
        kp.handle_right = (float(kp.co[0]) + float(dt_new),
                           float(kp.co[1]) + dv_new)
    return True


def _median_dt(values):
    """一组 dt 的**中位数**（取上中位；空集 ⇒ None）。

    ★ 为什么抽成函数：`fix_unify_dt` 与 `_unify_filled_dt` 都要用它。
      "中位数"是这两处的**同一个口径**，各写一份迟早漂移
      （本项目历史上"同一语义两套实现"已经栽过好几次）。

    ⚠️ 为什么用中位数而不是均值：抗离群。三轴是 (8, 8, 30) 时均值 15.3
       会把两条**好的**也拖歪；中位数 8 只动那条离群的。
    """
    vals = sorted(float(v) for v in (values or ()) if v is not None)
    if not vals:
        return None
    return vals[len(vals) // 2]


# ★★★ 2026-09-30（D-5 收尾）—— 这里**曾经**有一对 `_curve_handle_snapshot` /
#     `_restore_curve_handles`（"插入关键帧后把邻居手柄摆回原样"），已**删除**。
#     记下来是为了别让后人再走一遍这条弯路：
#
#     ▎现象：`fc.keyframe_points.insert(f, v)` 会连带改写同一条曲线上**其它**关键帧
#       的手柄（哪怕它们是 FREE）。实测：Y 曲线 [0, 117]，往中间插 90 之后 ——
#           Y@117 左手柄 (103.5, 5.5) → (112.577, 5.836)，dt 13.5 → 4.423。
#       看着像"用户的设置被悄悄抹掉"，于是当时写了"拍快照 + 插完还原"。
#
#     ▎为什么删掉：**还原会把曲线改坏，方向搞反了。**
#       贝塞尔曲线段 P0,P1,P2,P3 在中间插一个关键帧、且**要求曲线逐位不变**时，
#       数学上唯一的做法是 de Casteljau 分割 —— 而分割**必然要改写两侧邻居的
#       控制点**（P1→A、P2→C）。Blender 的 insert 做的正是这件事。
#       ⇒ 邻居手柄坐标的变化**不是副作用，是保形状的必要条件**。
#       把它还原回去 ⇒ 新关键帧的手柄与邻居不再匹配 ⇒ **曲线反而被改坏**。
#
#     ▎实测证据（两条断言，方向相反，删掉还原后同时满足）：
#       · `gui_spec_inspect_check.py` B1b「补轴不改动现有轨迹」：
#          不还原 ⇒ haus = **7e-7**（原样）  还原 ⇒ haus = **0.095**（1.4% 形变）✗
#       · `gui_eb_spec_check.py` E2 miss / miss+hand：
#          还原才不触发 `newinv` 的"数字变了就算新账"误报（那是**测试尺子**的问题，
#          已改 `newinv`：按"判据 + 帧 + 侧/轴"认身份，不再比数字 —— 见该函数注释）。
#
#     ▎一句话：**"不改动现有轨迹"指的是曲线（形状），不是手柄坐标的数值表示。**
#       插点保形状 ⇒ 邻居坐标必变；这是同一个事实的两面。

def _unify_filled_dt(action, obj, frame, filled_axes, bone_name=None):
    """补轴后**当场**把该帧【同侧三轴】的 dt 统一到"老轴"的值。

    ★★★ 2026-09-30（Phase 1 极限测试 · D-5 的**唯一**修法）

    ▎为什么必须在这里做，而不是指望后面的 `fix_unify_dt` 兜住

      补轴是**新造关键帧**。Blender 给新关键帧配的是**派生手柄**，
      时间分量由它按"到邻居的 1/3 距离"算出来（实测 30.0 / 26.03 / 12.68），
      与同侧老轴的 30.0 / 9.0 **对不上** ⇒ 一补轴就破了插件自己的规范
      「同侧三轴 dt 相等」（这条规范就是"手柄贴合路径"的等价说法）。

      而"后面还有 `fix_unify_dt`"这个假设**不成立**，因为：
        · `detect` 只报它**看得见**的项；它在 `|dv| <= MIN_HANDLE_LEN(1.0)` 时
          **整侧跳过**（手柄太短时方向由浮点噪声主导，判它没有意义）；
        · 补出来的轴**恰好常落在这个盲区里**：
            复现 B（删掉 Y 轴帧 90）该侧 |dv| = 0.59 ⇒ 被跳过；
            复现 A（整条轴缺失）补出来的是**平曲线**（dv=0）⇒ 恒被跳过。
        · ⇒ `apply_fix` 复检报 `issues=[]`（插件说"修好了"），
          而插件自己的不变量**已经破了** —— 用户看到一条"三轴手柄长短不一"
          的曲线，却说不出哪里不对（这就是"静默"）。

      打个比方：补轴 = 给缺了一条腿的凳子配一条新腿。
        `detect` 是个**只在腿明显歪了才吭声**的验收员；
        新配的腿恰好只歪一点点（落在它的容差里）⇒ 它不吭声，
        凳子却已经在晃了。所以**配腿的时候就当场量好尺寸**，
        不能指望事后有人来扶 —— 本函数就是那把尺子。

    ▎目标值为什么取"**老轴**的中位数"，而不是三轴一起的中位数

      · 老轴的 dt 是**原动画本来就有**的，是要**保住**的东西；
        新轴的 dt 是 Blender 随手给的 ⇒ 该改的是**新轴**。
      · 若连三轴一起取中位数：复现 A 里 [30, 1, 1] 的中位数是 **1**，
        会把**老轴**从 30 拖到 1 —— 白白改掉一段本来正确的轨迹，
        直接违背 `fix_missing_axes` docstring 的承诺「补轴不会改动现有轨迹」。
      · 老轴之间**自己就不一致**时（真 dt_mismatch）：取它们的中位数，
        并把三轴一起写成它 —— 否则"三轴相等"这条根本无法成立。
        这与 `fix_unify_dt` 的口径一致（同一个 `_median_dt`）。

    ▎写的时候**连值分量一起缩放**（不是只动 dt）

      ⇒ 走 `_rescale_side_dt`：速度 `dv/dt` 逐位不变 ⇒ 切向不变 ⇒
        "补出来的点落在原曲线上"时形状逐位不变。
      ⚠️ 这一点是**实测逼出来的**：第一版只改 dt，结果
         `gui_spec_inspect_check.py` 的 B1b（"补轴不改动现有轨迹"）
         从 haus 7e-7 变成 **0.184**（约 3% 形变）—— 等于把补轴自己的承诺打脸。
         详见 `_rescale_side_dt` 的长注释。

    :param filled_axes: 这一帧**刚补出来**的轴；其余轴视为"老轴"
    :return: [(frame, side, dt_target), ...]（供测试/日志观察）
    """
    done = []
    try:
        filled = set(int(a) for a in (filled_axes or []))
    except Exception:
        filled = set()
    kept = [a for a in (0, 1, 2) if a not in filled]
    if not kept:
        return done                     # 没有"老轴"可参照 ⇒ 不动（理论上不可达）
    try:
        cs = _axis_curves(action, obj, bone_name)
    except Exception:
        warn_once("spec_check._unify_filled_dt")
        return done
    if not cs:
        return done
    # ① 先把这一帧三轴都冻成 FREE（幂等；补轴时已经冻过，这里只是保证）
    for ax in (0, 1, 2):
        fc = cs.get(ax)
        if fc is None:
            continue
        kp = xf.keyframe_at(fc, frame)
        if kp is not None:
            _freeze_keyframe(kp)
    for fc in cs.values():
        fc.update()
    # ② 逐侧：目标 = 老轴 dt 的中位数；然后三轴一起写成它
    for side in ('left', 'right'):
        target = _median_dt([_side_dt(xf.keyframe_at(cs[a], frame), side)
                             for a in kept
                             if cs.get(a) is not None
                             and xf.keyframe_at(cs[a], frame) is not None])
        if target is None or target <= 1e-12:
            continue
        # ⚠️ 重新取 kp —— 包装对象用过一次就"钝"了（本项目反复踩的坑）
        cs2 = _axis_curves(action, obj, bone_name)
        wrote = False
        for ax in (0, 1, 2):
            fc = cs2.get(ax)
            if fc is None:
                continue
            kp = xf.keyframe_at(fc, frame)
            if kp is None:
                continue
            if abs(_side_dt(kp, side) - target) <= 1e-9:
                continue
            # ⚠️ 连值分量一起缩放（保速 ⇒ 保切向 ⇒ 保形状），详见 `_rescale_side_dt`
            if _rescale_side_dt(kp, side, target):
                fc.update()
                wrote = True
        if wrote:
            done.append((float(frame), side, float(target)))
    return done


def fix_missing_axes(action, obj, report, bone_name=None, snap=None):
    """规范③：补缺失的关键帧（值 = 曲线求值 ⇒ 补的点落在原曲线上）。

    ⚠️ 代价说明（必须写进弹窗）：
       插入关键帧走的是 Blender 的**保形状插入**（贝塞尔 de Casteljau 分割）——
       它顺带会改写两侧邻居的手柄坐标，但那**正是曲线不变的必要条件**，
       实测形状偏差 ≈ **7e-7**（逐位级）。
       但**补不回"删除前"的那条曲线** —— 信息在删除那一刻就丢了。
       所以这是"功能修复"（让手柄/路径点能重新显示与编辑），不是"还原动画"。

    ★★ 2026-09-30（Phase 1 · D-5）：补完之后**立刻**调 `_unify_filled_dt`，
       把该帧同侧三轴的 dt 统一到"老轴"的值。
       原因见那个函数的长注释：新关键帧带的是 Blender 派生手柄，
       它的 dt 与老轴对不上（实测 10.44/11.93 vs 8.0/8.0）；
       而后面负责兜底的 `detect` 有"短手柄整侧跳过"的盲区，兜不住 ⇒
       会静默留下一份"复检说没事、规范其实破了"的曲线。

    ⚠️⚠️ 上面"形状偏差 ≈ 7e-7"因此有**一处例外**（实测数据，别当成回归）：
       · 统一 dt 这一步**会带来一点形状变化**：实测 haus **0.0138**
         （路径长 7.99 ⇒ 约 **0.17%**）。
       · 不统一的话，那根手柄**偏离路径 13.7°**（肉眼可见地折），
         而 `detect` 报不出来 ⇒ 只能等后续 `fix_handle_bend` 去掰直，
         实测那条路的总形变是 **0.0886**（是现在的 **6.4 倍**）。
       ⇒ 两害相权，**当场统一**更省（而且残留 issue 归零）。
       · 老轴之间**自己**就不一致时（真 dt_mismatch）：取它们的中位数，
         三轴一起写成它 —— 这是"三轴相等"能成立的唯一办法，
         与 `fix_unify_dt` 同口径（同一个 `_median_dt`）。
    """
    added = []
    for it in (report or {}).get("issues", []):
        if it.get("kind") != "missing_axis":
            continue
        frame = float(it["frame"])
        for ax in it.get("axes") or []:
            try:
                cs = _axis_curves(action, obj, bone_name)
                fc = cs.get(ax)
                if fc is None:
                    # 该轴完全没有曲线 ⇒ 新建（照抄既有 ensure_location_keyframes 的做法）
                    from .cache import get_writable_fcurves
                    coll = get_writable_fcurves(action, obj)
                    if coll is None:
                        continue
                    dp = ('pose.bones["%s"].location' % bone_name) if bone_name else 'location'
                    fc = coll.new(data_path=dp, index=ax)
                    val = _fallback_value(obj, bone_name, ax)
                else:
                    val = float(fc.evaluate(frame))     # ★ 补的点落在原曲线上
                # ⚠️ `insert` 会**连带改写同曲线邻居关键帧的手柄** —— 这是 Blender
                #    在贝塞尔曲线上"插点且保形状"的**必要条件**（de Casteljau 分割），
                #    **不要**去还原它，否则曲线反而被改坏（实测 haus 7e-7 → 0.095）。
                #    详见本节上方那段"曾经有一对 snapshot/restore"的说明。
                fc.keyframe_points.insert(frame, val)
                fc.update()
                # ★ 新建的关键帧默认是 ALIGNED（派生类型）——
                #   它的时间分量由 Blender 算（实测 dt 三轴不等）。
                #   立刻冻结成 FREE 并保住体感，否则后面"统一 dt"要再绕一圈。
                try:
                    _cs = _axis_curves(action, obj, bone_name)
                    for _ax, _fc in _cs.items():
                        _kp = xf.keyframe_at(_fc, frame)
                        if _kp is not None:
                            _freeze_keyframe(_kp)
                    for _fc in _cs.values():
                        _fc.update()
                except Exception:
                    warn_once("spec_check.fix_missing_axes.freeze")
                added.append((frame, ax))
            except Exception:
                warn_once("spec_check.fix_missing_axes")
                continue
        # ★★★ D-5：这一帧补完之后**当场**把同侧三轴的 dt 统一。
        #    为什么不能留给后面的 `fix_unify_dt`：`detect` 在 |dv| <= 1.0 时
        #    整侧跳过，而补出来的轴常常正好落在这个盲区（平曲线 dv=0）⇒
        #    复检报 issues=[] 但插件自己的"同侧三轴 dt 相等"已经破了。
        #    详见 `_unify_filled_dt` 的 docstring（含凳子配腿的比方）。
        _unify_filled_dt(action, obj, frame, it.get("axes") or [], bone_name)
    if snap is not None:
        snap.setdefault("frames_added", []).extend(added)
    return added


def _fallback_value(obj, bone_name, axis):
    """该轴完全没有曲线时，取物体/骨骼的当前值当初始值（既有做法同款）。"""
    try:
        if bone_name:
            return float(obj.pose.bones[bone_name].location[axis])
        return float(obj.location[axis])
    except Exception:
        return 0.0


def fix_unify_dt(action, obj, report, bone_name=None, snap=None):
    """规范①：把同侧三轴的 dt 统一成**中位数**（只动时间分量，不动长度）。

    ⚠️⚠️ 为什么不能调 `td.write_s`（重要，实测踩过）：
        write_s 写的是**同一个 s**，而各轴的 span 不同
        ⇒ `dt_a = s * span_a` **各不相同** ⇒ 修不了"三轴 dt 不等"。
        必须逐轴直接写同一个 **dt 绝对值**。

    ⚠️ 代价：路径形状会变（实测偏差 ≈ 0.23，测试路径长 6.6 ⇒ 约 3%）。
       这是**数学必然**：让手柄方向与路径切向平行，只能让三轴时间跨度相等。

    ⚠️ 为什么取**中位数**：抗离群。若三轴是 (8, 8, 30)，均值 15.3 会把两条好的
       也拖歪；中位数 8 只动那一条离群的。

    返回 [(frame, side, dt_target), ...]
    """
    done = []
    for it in (report or {}).get("issues", []):
        if it.get("kind") != "dt_mismatch":
            continue
        frame, side = float(it["frame"]), it.get("side")
        dts = (it.get("metrics") or {}).get("dt") or []
        if not dts:
            continue
        target = _median_dt([abs(v) for v in dts])              # 中位数（唯一来源）
        if target is None:
            continue
        try:
            cs = _axis_curves(action, obj, bone_name)
            # ① 先冻结（保坐标），否则 Blender 会反噬
            for ax in (0, 1, 2):
                fc = cs.get(ax)
                if fc is None:
                    continue
                kp = xf.keyframe_at(fc, frame)
                if kp is not None:
                    _freeze_side_preserving(kp, side)
            for fc in cs.values():
                fc.update()
            # ② 逐轴写同一个 dt（⚠️ 重新取 kp —— 包装对象用过就钝）
            for ax in (0, 1, 2):
                fc = _axis_curves(action, obj, bone_name).get(ax)
                if fc is None:
                    continue
                kp = xf.keyframe_at(fc, frame)
                if kp is None:
                    continue
                if side == 'right':
                    kp.handle_right = (float(kp.co[0]) + target,
                                       float(kp.handle_right[1]))
                else:
                    kp.handle_left = (float(kp.co[0]) - target,
                                      float(kp.handle_left[1]))
                fc.update()
            done.append((frame, side, target))
        except Exception:
            warn_once("spec_check.fix_unify_dt")
            continue
    return done


def fix_force_align(action, obj, report, bone_name=None, snap=None,
                    strategy=COLLINEAR_DEFAULT):
    """【可选】把**所有** GE 关键帧手柄对齐**共线**（含体感=自由、含外侧手柄）。

    ★★ 用户 2026-09-30 澄清（重要 —— 我一开始理解错了）：
        「实际勾选后点击确定的话 GE 的关键帧手柄**还是折角的**，是不是搞错了什么，
          强制对齐关键帧进出速度的意思其实就是**强制把所有 GE 的关键帧手柄对齐共线**」
        「**对齐共线的原则是取中间值**」

    ⇒ 目标是 **GE 共线**，不是"3D 手柄共线"。两者是**不同的条件**：

        3D 手柄共线  ⟺ `dvL ∥ dvR`                    （只比值分量）
        **GE 手柄共线** ⟺ 逐轴 `dvLx/dtLx == dvRx/dtRx`  （进出【速度】相等）

    ★★ 关键洞察：**这两件事 + 相切可以同时满足**，而且只有一种写法：

        令 `v*` = 进出共同的速度（方向取角平分、大小取平均 —— 用户：「取中间值」）
           `dvL = -v* × D_L`      `dvR = +v* × D_R`      （D = 统一后的时间跨度）

        ⇒ 逐轴 dvLx/dtLx = -v*x = dvRx/dtRx   ⇒ **GE 共线** ✓
        ⇒ dvL ∥ dvR                            ⇒ **3D 手柄成直线** ✓
        ⇒ 同侧三轴 dt 相等（D_L / D_R）        ⇒ **与路径相切** ✓

    ⚠️ 代价：**手柄长度会变**（因为比例被 dt 定死了：|dvR|/|dvL| = D_R/D_L）。
        这是"GE 共线 + 保持相切"的数学必然，没有别的选择。

    ★ 与 `fix_handle_bend` 的区别：
        ┌────────────────┬──────────────────────┬────────────────────────┐
        │                │ `fix_handle_bend`  │ `fix_force_align`    │
        ├────────────────┼──────────────────────┼────────────────────────┤
        │ 处理哪些手柄   │ 只处理**体感=对齐**的│ **全部**（含自由、外侧）│
        │ 目标           │ 3D 手柄成直线        │ **GE 手柄共线**        │
        │ 默认           │ ✅ 做                │ ⬜ **不勾**（可选）    │
        └────────────────┴──────────────────────┴────────────────────────┘

    ⚠️ 最小干预：某帧**逐轴都已经共线**（GE 折角全 < ANGLE_EPS_DEG）⇒
        **整帧跳过**，连手柄类型都不冻结（避免无意义的 ALIGNED → FREE 翻转）。

    返回 [(frame, strategy)]。
    """
    done = []
    try:
        curves = _axis_curves(action, obj, bone_name)
        frames = _frames_of(curves)
    except Exception:
        warn_once("spec_check.fix_force_align")
        return done
    if not frames:
        return done

    for frame in frames:
        try:
            kp_map = _frame_map(curves, frame)
            if len(kp_map) < 3:
                continue                      # 缺轴的帧不管（交给 missing_axis）
            dv_l, dt_l = _side_vec(kp_map, 'left')
            dv_r, dt_r = _side_vec(kp_map, 'right')
            # ---- 先判断这一帧要不要动（最小干预）：逐轴 GE 折角 ----
            folds = []
            for ax in (0, 1, 2):
                if ax not in dv_l or ax not in dv_r:
                    folds.append(None)
                    continue
                folds.append(_ge_fold_deg(dv_l[ax], dt_l[ax], dv_r[ax], dt_r[ax]))
            if folds and all(f is not None and f <= ANGLE_EPS_DEG for f in folds):
                continue                      # 逐轴都已共线 ⇒ 整帧跳过（不冻结）
            # ---- ① 冻结（保坐标）—— 否则派生类型会被 Blender 重算 ----
            for kp in kp_map.values():
                _freeze_keyframe(kp)
            for fc in curves.values():
                fc.update()
            # ---- ② 统一每侧三轴的 dt（中位数，抗离群）----
            cs2 = _axis_curves(action, obj, bone_name)
            km2 = {}
            for ax in (0, 1, 2):
                fc = cs2.get(ax)
                if fc is None:
                    continue
                kp = xf.keyframe_at(fc, frame)
                if kp is not None:
                    km2[ax] = kp
            span = {}
            for side in ('left', 'right'):
                mags = []
                for ax, kp in km2.items():
                    h = kp.handle_left if side == 'left' else kp.handle_right
                    d = abs(float(h[0]) - float(kp.co[0]))
                    if d >= DT_MIN:
                        mags.append(d)
                if not mags:
                    span[side] = None
                    continue
                target = sorted(mags)[len(mags) // 2]
                span[side] = target
                for ax, kp in km2.items():
                    h = kp.handle_left if side == 'left' else kp.handle_right
                    val = float(h[1])
                    t = (float(kp.co[0]) - target if side == 'left'
                         else float(kp.co[0]) + target)
                    if side == 'left':
                        kp.handle_left = (t, val)
                    else:
                        kp.handle_right = (t, val)
            for fc in cs2.values():
                fc.update()
            if not span.get('left') or not span.get('right'):
                continue
            D_L, D_R = span['left'], span['right']
            # ---- ③ 读统一 dt 后的 dv，算两侧【速度】----
            cs3 = _axis_curves(action, obj, bone_name)
            km3 = {}
            for ax in (0, 1, 2):
                fc = cs3.get(ax)
                if fc is None:
                    continue
                kp = xf.keyframe_at(fc, frame)
                if kp is not None:
                    km3[ax] = kp
            if len(km3) < 3:
                continue
            dvl, _a = _side_vec(km3, 'left')
            dvr, _b = _side_vec(km3, 'right')
            vl = [dvl.get(a, 0.0) for a in (0, 1, 2)]      # 左手柄的值分量（向后）
            vr = [dvr.get(a, 0.0) for a in (0, 1, 2)]      # 右手柄的值分量（向前）
            # 该侧【速度】= dv / dt；左手柄 dt 为负 ⇒ 速度向前
            speed_l = [vl[i] / (-D_L) for i in range(3)]
            speed_r = [vr[i] / D_R for i in range(3)]
            n_l, n_r = _norm(speed_l), _norm(speed_r)
            if n_l < 1e-12 or n_r < 1e-12:
                continue                      # 退化手柄（dv=0）⇒ 判不了，跳过
            # ★★ 取中间值（用户口径：「对齐共线的原则是取中间值」）：
            #    方向 = 两侧**速度**方向的角平分（各转一半）
            #    大小 = 两侧**速度**大小的平均
            #
            # ⚠️⚠️ 符号坑（实测踩过，速度会被整体反向翻转）：
            #    `_target_dirs(a, b)` 算的是 `unit(a) 与 unit(-b)` 的角平分，
            #    返回 `(t, -t)`。
            #    两侧的【速度】都是**向前**的（不是反向）——
            #    所以必须传 `(speed_r, -speed_l)`：
            #        ul = unit(speed_r)  = 向前
            #        ur = unit(-speed_l) = 向后
            #        m  = 向前 - 向后     = 2×向前   ⇒ t = **向前** ✓
            #    若误传 `(speed_l, -speed_r)`，算出来是"向前与向后"的角平分
            #    ⇒ 方向随机、甚至反向（路径会在关键帧处掉头）。
            u_fwd, u_back = _target_dirs(speed_r, [-x for x in speed_l], strategy)
            sp = 0.5 * (n_l + n_r)
            # 右手柄向前（dvR > 0），左手柄向后（dvL < 0）—— 与 Blender 的惯例一致
            _set_side_dv(km3, 'left', {a: u_back[a] * (sp * D_L) for a in (0, 1, 2)})
            _set_side_dv(km3, 'right', {a: u_fwd[a] * (sp * D_R) for a in (0, 1, 2)})
            for fc in cs3.values():
                fc.update()
            done.append((frame, strategy))
        except Exception:
            warn_once("spec_check.fix_force_align.loop")
            continue
    return done


def fix_handle_bend(action, obj, report, bone_name=None, snap=None,
                    strategy=COLLINEAR_DEFAULT):
    """【必须校正】把每个关键帧的左右手柄方向对齐成一条直线（保留各自长度）。

    ★★ 为什么这是"必须"而不是"可选"（用户 2026-09-30 最终口径）：
        「这个本来就是要保证的，不是选不选的问题，本来就是要校正这个，
          **除非路径手柄已经被用户提前设置成自由**」

    3D 手柄在视口里画成【一条线段】：(co - dvL) ──●── (co + dvR)。
    这条线要"贴着路径"，前提是【路径在那里光滑】；
    折了 ⇒ 路径拐角 ⇒ 只能贴住一半 ⇒ 看起来就是"不相切"。

    ★ 与 `fix_unify_dt` 的分工：
        · `fix_unify_dt`    让手柄**与它那一侧的路径**相切（同侧三轴 dt 相等）
        · `fix_handle_bend` 让**整条手柄线**贴着路径（左右方向平行 ⇒ 路径不拐角）

    ★★ 唯一的例外（E2）：体感 = 自由时**跳过** ——
        那是用户主动要的"左右各调各的"，不该去动。

    ⚠️ 为什么遍历**所有**关键帧，而不只遍历 `report["issues"]`：
        用户口径是「本来就是要保证的」⇒ 整个动画都要规范。

    ⚠️ 只改**值分量**（dv），**时间分量（dt）原样保留** ——
       所以这一步**不会**破坏"相切"（相切由 dt 决定）。

    ⚠️ 代价：**会改变路径形状**（方向变了）。实测四策略（路径长 6.6）：
        right_only 0.242 / left_only 0.259 / **bisect 0.131（默认，最小）** / length_weighted 0.143

    返回 [(frame, strategy), ...]
    """
    done = []
    try:
        curves = _axis_curves(action, obj, bone_name)
        frames = _frames_of(curves)
    except Exception:
        warn_once("spec_check.fix_align_handles")
        return done
    if not frames:
        return done
    first_frame, last_frame = frames[0], frames[-1]

    for frame in frames:
        try:
            kp_map = _frame_map(curves, frame)
            if len(kp_map) < 3:
                continue                      # 缺轴的帧不管（由 missing_axis 那条处理）
            # 两侧都要够长才谈得上"对齐"
            dv_l, _ = _side_vec(kp_map, 'left')
            dv_r, _ = _side_vec(kp_map, 'right')
            vl = [dv_l.get(a, 0.0) for a in (0, 1, 2)]
            vr = [dv_r.get(a, 0.0) for a in (0, 1, 2)]
            ln_l, ln_r = _norm(vl), _norm(vr)
            if ln_l <= MIN_HANDLE_LEN or ln_r <= MIN_HANDLE_LEN:
                continue
            fold = _angle_deg(vl, [-x for x in vr])
            if fold is None or fold <= ANGLE_EPS_DEG:
                continue                      # 本来就基本一条直线 ⇒ 不动（避免浮点抖动）
            # ★★ E2 例外：体感 = 自由 ⇒ 用户主动要"左右各调各的"，**不碰**
            #    （用户口径：「除非路径手柄已经被用户提前设置成自由」）
            try:
                if xf._link_mode(kp_map[0], 'right') != 'link':
                    continue
            except Exception:
                warn_once("spec_check.fix_handle_bend.link_mode")
                continue
            # ① 先冻结（保坐标）—— 否则派生类型会被 Blender 重算
            for kp in kp_map.values():
                _freeze_keyframe(kp)
            for fc in curves.values():
                fc.update()
            # ② 算目标方向并写入（⚠️ 重新取 kp —— 包装对象用过就钝）
            tl, tr = _target_dirs(vl, vr, strategy)
            cs2 = _axis_curves(action, obj, bone_name)
            km2 = {}
            for ax in (0, 1, 2):
                fc = cs2.get(ax)
                if fc is None:
                    continue
                kp = xf.keyframe_at(fc, frame)
                if kp is not None:
                    km2[ax] = kp
            _set_side_dv(km2, 'left', {a: tl[a] * ln_l for a in (0, 1, 2)})
            _set_side_dv(km2, 'right', {a: tr[a] * ln_r for a in (0, 1, 2)})
            for fc in cs2.values():
                fc.update()
            done.append((frame, strategy))
        except Exception:
            warn_once("spec_check.fix_align_handles.loop")
            continue
    return done


# ---------------------------------------------------------------------------
# 统一入口
# ---------------------------------------------------------------------------

# 三项**全都默认做**（用户 2026-09-30 最终口径：
#     「这个本来就是要保证的，不是选不选的问题」）
#
#   missing_axis  ③ 补缺失关键帧（不动现有轨迹）
#   dt_mismatch   ① 统一三轴时间跨度（手柄贴住它那一侧的路径；形状约 3%）
#   handle_bend   ② 对齐左右方向（整条手柄线贴住路径；路径不再拐角）
#
# ⚠️ 手柄类型（④）与对齐锁定（⑤）是**自动前置**（转 FREE 保坐标），不在这里。
#
# ★ 弹窗里**不再有勾选项** —— 只报告 + 确定/取消。
#   `kinds` 参数保留（供测试与将来用）。
DEFAULT_APPLY = {
    "missing_axis": True,
    "dt_mismatch": True,
    "handle_bend": True,
    # ★ 唯一一个**可选**项（默认不勾）—— 用户 2026-09-30 追加：
    #   「让用户可以选择是否把强制把 GE 的关键帧手柄都对齐，
    #     当然这个对齐同时也要注意 dt 要一致」
    #   勾上 ⇒ 连**体感=自由**的手柄、**首末帧的外侧手柄**也一起规范
    #          （对齐方向 + 统一三轴 dt）。
    "force_align": False,
}

# ⚠️ 顺序不能换：
#    ① 先补轴（不改轨迹）
#    ② 再统一 dt（让每侧手柄贴住自己那侧的路径）
#    ③ 最后对齐左右方向（整条手柄线成一条直线 ⇒ 路径不拐角）
#    ③ 必须在 ② 之后 —— dt 均匀后"手柄方向"才等于"速度方向"，对齐才有意义。
#    ④ force_align 放最后：它是"把剩下没管到的（体感=自由 / 外侧）也一起规范"，
#       必须在 ②③ 处理完 LINK 手柄之后跑，否则重复劳动。
FIX_ORDER = ("missing_axis", "dt_mismatch", "handle_bend", "force_align")


def _type_map(action, obj, bone_name=None):
    """{(axis, frame): (left_type, right_type)} —— 用于统计"冻结了几个手柄"。"""
    m = {}
    for ax, fc in _axis_curves(action, obj, bone_name).items():
        try:
            for kp in fc.keyframe_points:
                m[(ax, round(float(kp.co[0]), 4))] = (
                    str(kp.handle_left_type), str(kp.handle_right_type))
        except Exception:
            continue
    return m


def apply_fix(action, obj, report, bone_name=None, kinds=None):
    """按顺序执行选中的微调，返回 (result_dict, snapshot)。

    ⚠️ **顺序不能换**：
        补轴（不改轨迹）→ 统一 dt
        两者内部都会**先冻结成 FREE 再写** —— 否则 Blender 会反手改掉手柄长度。

    ★ 每个阶段之间**重新检测**（2026-09-30 GUI 验收抓到的真实缺陷）：
        补轴时新建的关键帧，Blender 给的是**默认类型 ALIGNED**，
        时间分量也是 Blender 自动算的（实测 dt = ±10.44 / 11.93，三轴不等）。
        而"统一 dt"只处理**报告里列出的**帧 —— 补出来的新帧不在旧报告里
        ⇒ 没人管它 ⇒ 修完复检仍有问题（GUI 真机实测"还剩 2 处"）。
        ⇒ 解法：每个阶段结束后重跑 detect，把**新产生的问题**喂给下一阶段。

    :param kinds: 要应用哪些（None = 用 DEFAULT_APPLY 的默认勾选）
    """
    sel = set(kinds) if kinds is not None else {
        k for k, v in DEFAULT_APPLY.items() if v}
    snap = snapshot_for_fix(action, obj, bone_name)
    types_before = _type_map(action, obj, bone_name)
    result = {"snapshot": snap, "applied": {}}

    for kind in FIX_ORDER:
        if kind not in sel:
            continue
        try:
            cur = detect(action, obj, bone_name)     # ← 用最新状态
            if kind == "missing_axis":
                got = fix_missing_axes(action, obj, cur, bone_name, snap)
            elif kind == "dt_mismatch":
                got = fix_unify_dt(action, obj, cur, bone_name, snap)
            elif kind == "handle_bend":
                got = fix_handle_bend(action, obj, cur, bone_name, snap)
            elif kind == "force_align":
                got = fix_force_align(action, obj, cur, bone_name, snap)
            else:
                continue
            result["applied"][kind] = len(got)
        except Exception:
            warn_once("spec_check.apply_fix." + kind)
            result["applied"][kind] = -1        # -1 = 出错

    # 统计"顺手冻结了几个手柄"（供结果提示：用户应该知道这件事发生了）
    try:
        types_after = _type_map(action, obj, bone_name)
        frozen = sum(1 for k, v in types_after.items()
                     if v == ('FREE', 'FREE') and types_before.get(k) != v)
        result["frozen"] = frozen
    except Exception:
        result["frozen"] = 0

    # 复检（供 UI 显示"修完还剩几项"）
    try:
        result["after"] = detect(action, obj, bone_name)
    except Exception:
        result["after"] = None
    return result, snap
