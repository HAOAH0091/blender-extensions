# -*- coding: utf-8 -*-
"""「三角拉满（疏）后拖手柄 = 改速度」—— 用户报障 2026-10-02（第二个边界 bug）。

用户报告
--------
> 「把关键帧点的三角都拉满（橙色）后，再拖动手柄会变成改速度模式」

根因（实测）
------------
    `write_s` 写的是 **handle[0]（时间分量）**；
    而「手柄有多长 / 空心环出不出来」看的是 **handle[1]（值分量）**。
    `e0c98fb` 加的判据 `_at_floor = (s == S_EPS)` 把两者混为一谈：

        三角拉满（疏）  ⇒ s 被压到下限 S_EPS   ← 命中判据
                         ⇒ 但值分量**一点没变**（实测 0.85）
        手柄缩成零长    ⇒ 值分量 → 0            ← 这才是真判据

    ⇒ 拉满三角被误判成"手柄零长" ⇒ `supersede=True`
      ⇒ 用户手动设的『不动(FREE)』被**静默覆盖成 LINK**（联动被打开）
      ⇒ 拖手柄时对侧跟着动 ⇒ 速度分布被改。

修法
----
`_supersede` 改成 `value_len_is_visual_zero(...)` —— 与**空心环同源**的
「值分量视觉为零」判据（同走 `drawing.local_eps_for_screen`）。

本测试的分级（对齐 skill §0 铁律 3：测试必须做 bug 注入）
--------------------------------------------------------
A 组：三角拉满 ⇒ **不得** supersede（用户报的这个）
B 组：值分量真的为零 ⇒ **必须** supersede（保住 e0c98fb 的原意）
C 组：阈值扫描（值分量 0 / 极小 / 正常 / 很大）
D 组：**bug 注入** —— 判据退回旧口径 `s == S_EPS` ⇒ A 组必须 FAIL（区分度）
E 组：静态契约（判据用的是值分量，不是 s）
"""
import os
import sys
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
PARENT = os.path.dirname(REPO)
for _p in (PARENT, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import bpy
import _eb_common as E

from RealTimeMotionPath import transform_domain as xf
from RealTimeMotionPath import time_domain as td
from RealTimeMotionPath import state as st
from RealTimeMotionPath import interaction as it
import RealTimeMotionPath as _R

if not hasattr(bpy.types.WindowManager, "rtmp_handle_scale"):
    try:
        _R.register()
    except Exception:
        pass

LOG = os.path.join(HERE, "_tri_sparse_keepspeed_result.json")
steps = []


def step(n, ok, d=""):
    steps.append((n, bool(ok), str(d)))


# ── 打桩：拦 freeze_keyframe_pair，记下每次的 supersede ──────────────
_FCALLS = []
_ORIG_FKP = td.freeze_keyframe_pair


def _spy_fkp(act, obj, frame, side, bone_name=None, supersede=False):
    _FCALLS.append(bool(supersede))
    return _ORIG_FKP(act, obj, frame, side, bone_name, supersede)


class _Prefs:
    handle_scale_mode = "UNIFORM"


_ORIG_PREFS = st.get_addon_prefs
st.get_addon_prefs = lambda ctx=None: _Prefs()

FR = E.FRAME          # = 90.0，E.KEYS_3 的中间关键帧（两侧都有邻居）


def fresh(name="_TRI"):
    o, a = E.build_object(name, E.KEYS_3)
    st._session.drag_target_object = o.name
    return o, a


def dv_len(o, fr, side):
    v = 0.0
    for fc in E.curves_of(o).values():
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - fr) < 1e-3:
                h = kp.handle_right if side == 'right' else kp.handle_left
                v += (float(h[1]) - float(kp.co[1])) ** 2
    return math.sqrt(v)


def dt_of(o, fr, side):
    out = []
    for fc in E.curves_of(o).values():
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - fr) < 1e-3:
                h = kp.handle_right if side == 'right' else kp.handle_left
                out.append(round(float(h[0]) - float(kp.co[0]), 10))
    return out


def set_dv(o, fr, side, dv):
    """把某帧某侧手柄的【值分量】设成 dv（所有轴），时间分量给 8。

    ⚠️ 时间分量的**方向**必须分侧：右手柄 = co+8，左手柄 = co−8。
       两边都写 +8 会让左手柄跨到关键帧右边 ⇒ 手柄交叉 ⇒ `fc.update()`
       重算 ⇒ 值分量被改掉（我第一版就踩了这个，B0 前置因此失败）。
    """
    for fc in E.curves_of(o).values():
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - fr) < 1e-3:
                h = kp.handle_right if side == 'right' else kp.handle_left
                # ⚠️ **两侧**都要转 FREE：只转被写侧的话，另一侧仍是 AUTO_CLAMPED，
                #    `fc.update()` 会把它连累重算 ⇒ 被写侧的值分量被改掉
                #    （实测：ax0 想写 1.0 得到 1.2667）。同 `_eb_common.set_handles`。
                kp.handle_left_type = 'FREE'
                kp.handle_right_type = 'FREE'
                h[0] = float(kp.co[0]) + (8.0 if side == 'right' else -8.0)
                h[1] = float(kp.co[1]) + dv
                fc.update()


def feel_at(o, fr, side, owner=None):
    try:
        return xf.feel_type_at(o.animation_data.action, fr, side, owner=owner)
    except Exception:
        return None


try:
    # ══════ A · 三角拉满 ⇒ 不得 supersede ══════════════════════════════
    td.freeze_keyframe_pair = _spy_fkp
    o, a = fresh("_TRI_A")
    xf.mark_feel_at(a, FR, 'left', 'FREE', owner="")
    xf.mark_feel_at(a, FR, 'right', 'FREE', owner="")
    dv0 = dv_len(o, FR, 'right')
    _FCALLS.clear()
    it._apply_speed_d(bpy.context, o, FR, 'right', 300.0)
    dv1 = dv_len(o, FR, 'right')
    dt1 = dt_of(o, FR, 'right')
    step("A0 前置：拉满前手柄值分量 = %.4f（非零）" % dv0, dv0 > 1e-3, "dv=%.6f" % dv0)
    step("A1 拉满三角确实把时间分量压到极小（s→S_EPS，前置条件成立）",
         len(dt1) == 3 and all(d < 0.01 for d in dt1), "dt=%s" % dt1)
    step("A2 ★ 拉满三角后手柄【值分量一点没变】（= 没产生空心态）",
         abs(dv1 - dv0) < 1e-6, "%.6f -> %.6f" % (dv0, dv1))
    step("A3 ★★ 拉满三角 **不得** 触发 supersede（用户报的这个 bug）",
         (True not in _FCALLS),
         "fkp 调用 %s（supersede 值）" % _FCALLS)
    step("A4 ★ 用户手动设的『不动(FREE)』未被改写",
         feel_at(o, FR, 'left') == 'FREE' and feel_at(o, FR, 'right') == 'FREE',
         "left=%s right=%s" % (feel_at(o, FR, 'left'), feel_at(o, FR, 'right')))

    # 长按更极端的疏度也一样
    o2, a2 = fresh("_TRI_A2")
    xf.mark_feel_at(a2, FR, 'left', 'FREE', owner="")
    _FCALLS.clear()
    it._apply_speed_d(bpy.context, o2, FR, 'right', 1000.0)
    step("A5 极端疏（d=1000）同样不触发 supersede", (True not in _FCALLS),
         "supersede 调用=%s" % _FCALLS)

    # ══════ B · 值分量真的为零 ⇒ 必须 supersede（保住 e0c98fb 原意）══
    o3, a3 = fresh("_TRI_B")
    xf.mark_feel_at(a3, FR, 'left', 'FREE', owner="")
    set_dv(o3, FR, 'right', 0.0)          # 两侧都成零长（S 缩到 0 的效果）
    set_dv(o3, FR, 'left', 0.0)
    step("B0 前置：值分量已为零", dv_len(o3, FR, 'right') < 1e-9,
         "dv=%.3g" % dv_len(o3, FR, 'right'))
    _FCALLS.clear()
    it._apply_speed_d(bpy.context, o3, FR, 'right', 300.0)
    step("B1 ★ 值分量视觉为零时 **必须** supersede（e0c98fb 的原意保住）",
         True in _FCALLS, "fkp 调用 %s" % _FCALLS)

    # ══════ C · 阈值扫描 ══════════════════════════════════════════════
    # 仿真实的「S 缩到 0」：把【手柄值分量向量】整体按 factor 缩放（不是逐轴设同一个数）
    def scale_dv(oo, fr, side, factor):
        for fc in E.curves_of(oo).values():
            for kp in fc.keyframe_points:
                if abs(float(kp.co[0]) - fr) < 1e-3:
                    h = kp.handle_right if side == 'right' else kp.handle_left
                    kp.handle_left_type = 'FREE'
                    kp.handle_right_type = 'FREE'
                    h[0] = float(kp.co[0]) + (8.0 if side == 'right' else -8.0)
                    h[1] = float(kp.co[1]) + (float(h[1]) - float(kp.co[1])) * factor
                    fc.update()

    rows, bad = [], []
    # (标签, 值分量向量缩放倍数, 期望判定)  —— 判据比的是**向量长度**
    for label, fac, expect in [("缩到 0（真零长）", 0.0, True),
                               ("S缩0残留 1e-4×", 1e-4, True),
                               ("缩到 1e-2×", 1e-2, False),
                               ("原样 1×", 1.0, False),
                               ("放大 10×", 10.0, False)]:
        oo, _aa = fresh("_TRI_C")
        scale_dv(oo, FR, 'right', fac)
        vec = dv_len(oo, FR, 'right')
        kfm = td.collect_frame_keyframes(_aa, oo, FR)
        got = td.value_len_is_visual_zero(oo, None, kfm, 'right')
        rows.append("%s(矢量长%.2e)->%s/期望%s" % (label, vec, got, expect))
        if bool(got) != expect:
            bad.append(label)
    # 无视图时退化口径 = HANDLE_ZERO_EPS（1e-4）：1e-4× 落进门内、1e-2× 落在门外
    step("C1 阈值扫描（HEADLESS 退化口径 1e-4）：值分量矢量缩到≤1e-4 判「视觉为零」，1e-2 及以上不判",
         not bad, " | ".join(rows))

    # ══════ D · bug 注入：判据退回旧口径 ⇒ A 必须 FAIL ════════════════
    o4, a4 = fresh("_TRI_D")
    set_dv(o4, FR, 'right', 0.85)         # 正常手柄
    _orig_vz = td.value_len_is_visual_zero
    td.value_len_is_visual_zero = (
        lambda obj, bone, kfm, side: abs(300.0 * 0 + td.S_EPS - td.S_EPS) <= 1e-12)  # ← 旧口径：恒 True
    _FCALLS.clear()
    it._apply_speed_d(bpy.context, o4, FR, 'right', 300.0)
    injected_supersede = (True in _FCALLS)
    td.value_len_is_visual_zero = _orig_vz
    step("★ D1 bug 注入（判据退回 `s==S_EPS`）⇒ 正常手柄也被判成零长 ⇒ supersede 触发"
         "（= 拦住，证明 A3 有区分度）",
         injected_supersede, "注入后 supersede 调用=%s（期望 True）" % _FCALLS)

    # 注入后 A3 的条件会失败 —— 显式断言这条
    step("★ D2 用旧判据跑 A 的场景 ⇒ A3 的条件**不成立**（FAIL）",
         injected_supersede is True,
         "旧判据下 supersede=%s，A3 会红" % injected_supersede)

    # ══════ E · 静态契约 ══════════════════════════════════════════════
    src_td = open(os.path.join(REPO, "time_domain.py"), encoding="utf-8").read()
    step("E1 静态：判据用值分量（`value_len_is_visual_zero`），原型是 `handle[1] - co[1]`",
         "def value_len_is_visual_zero(" in src_td
         and "float(h[1]) - float(kp.co[1])" in src_td)
    step("E2 静态：`write_s` 里 `_supersede` 来自该函数（不再用 `s == S_EPS`）",
         "_supersede = value_len_is_visual_zero(" in src_td
         and src_td.count("supersede=_supersede") == 2)
    step("E3 静态：`_at_floor` 只剩注释里的历史记录（不再是活代码）",
         all(l.strip().startswith("#") for l in src_td.splitlines() if "_at_floor" in l))
    step("E4 静态：口径与空心环同源（走 `local_eps_for_screen`）",
         "local_eps_for_screen" in src_td)

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-1200:])
finally:
    td.freeze_keyframe_pair = _ORIG_FKP
    st.get_addon_prefs = _ORIG_PREFS
    try:
        st._session.handle_start_values.clear()
    except Exception:
        pass
    for _n in ("_TRI_A", "_TRI_A2", "_TRI_B", "_TRI_D", "_TRI_CC"):
        try:
            _x = bpy.data.objects.get(_n)
            if _x:
                bpy.data.objects.remove(_x, do_unlink=True)
        except Exception:
            pass
    for _o in list(bpy.data.objects):
        if _o.name.startswith("_TRI_C"):
            try:
                bpy.data.objects.remove(_o, do_unlink=True)
            except Exception:
                pass

E.flush(LOG, steps)
sys.exit(1 if any(not s[1] for s in steps) else 0)
