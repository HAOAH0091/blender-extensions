# Phase 1 · 极限边界测试 —— 发现报告

> 生成：2026-09-30 ｜ 5 个 sub 团队并行产出
> 地基：`tests/_eb_common.py`（共享不变量检查器，含注入自检）｜ 门禁已扩展支持 `suspects` 分级
---

## 〇、【2026-10-01 更新】修复状态 —— **13 条全部修完，相关测试全绿**

| 批次 | 条目 | 状态 |
|---|---|---|
| Batch 1 `aab8070` | D-3 / G-1 / G-2 / D-6 / A-2 / A-3 | ⚠️ 见下方注 1 |
| Batch 2 `9b022dc` | **D-7 / D-8**（180° 折角清零）· **D-5**（补轴破坏三轴 dt）· **A-1**（span 逐轴确定性） | ✅ |
| Batch 2 补 | **D-3 真修**（Batch 1 那道守卫被两行无条件 `mark_feel` 架空，当时**没生效**） | ✅ |
| Batch 3 `0c10608` `23a159e` `63930b3` | **D-1 / D-2**：四张账本表的键加「骨骼名 + slot」 | ✅ |
| 收尾 · **D-4** | 僵尸词条：指向已删关键帧的记录在对账时清掉（含 property） | ✅ |
| 收尾 · **G-3** | 疏密模态取消后，段**另一端**的手柄类型也还原 | ✅ |
| 收尾 · **G4d** | 修**尺子**：静态计数不再把注释里提到的 `undo_push` 当调用点 | ✅ |

**注 1 —— Batch 1 的 D-3 当时没生效**：
`mark_owned_free` 里加的守卫，被 `make_handles_editable` 里两行**无条件**
`mark_feel(kp, side, 'LINK')` 完全架空（门口装了防盗门、后门大开着）。
Batch 1 的提交信息说 D1c 转绿，实测**一直是红的**（而且数字对不上：
它说剩 6 条，实际 8 条里就含 D1c 那两条）。已在 Batch 2 里真修。

**注 2 —— A-1 没有按本清单的建议改（建议本身有害，已实测）**：
建议的「端点轴就别写 dt」会把该帧同侧三轴 dt 写散，而 `detect` 判「手柄贴合路径」
用的正是 `dv ∝ dv/dt` ⇒ 在 `|dv| > MIN_HANDLE_LEN(1.0)` 的数据上它会**当场报
dt_mismatch**（用户刚拖完疏密三角，插件就说他「手柄偏离路径」）——**用户可见的回归**。
⇒ 只修了真缺陷：`span` 取值的**隐式顺序依赖**（`next(iter(kf_map.keys()))`）。
详见 `BATCH3_DESIGN.md` §12 与 `time_domain.resolve_target` 的代码注释。

**验证（2026-10-01）**：

    regression 16/0 ✓   i18n 门禁 ✓
    gui_eb_state_check 67/0 ✓      gui_eb_spec_check 77/0 ✓
    gui_eb_numeric_check 47/0 ✓    gui_eb_modal_check 209/0 ✓
    gui_spec_inspect_check 99/0 ✓  gui_frozen_link_check 65/0 ✓
    gui_tri_lock_check 48/0 ✓      gui_undo_lock_check 26/0 ✓
    gui_endpoint_hollow_check ALL PASS ✓   gui_review_fix_check 12/0 ✓

> ⚠️ 下面各条的正文是**当时的原始记录**（最小复现 / 根因），保留不改 ——
>    修复状态看上面这张表。

## 一、总览

| 组 | 文件 | 断言 | FAIL | 备注 |
|---|---|---|---|---|
| A+B 数值/几何 | `gui_eb_numeric_check.py` | 47 | 2 | 另有 2 条 SUSPECT |
| C+D 结构/四表 | `gui_eb_state_check.py` | 67 | 8 | 另有 4 条 SUSPECT |
| E+F 校正/双击 | `gui_eb_spec_check.py` | 74 | 17 | |
| G+H 模态/组合 | `gui_eb_modal_check.py` | 193 | 64 | 含大量测试台够不着的假失败，见 §4 |
| I fuzz | `_extreme_fuzz.py` | 15 | 0 | 500 轮无违规 |
| 合计 | | 1804（全仓） | 91 | 门禁 exit 1（**符合预期**） |

**本批次是「找 bug」而不是「验证已知行为」** ⇒ 门禁红是**正确结果**。

---

## 二、已由父 agent 独立复现的缺陷

### D-1【高】四张内存表的键不含骨骼名 ⇒ 多骨骼同帧同侧互相串

- 位置：`transform_domain._feel_key_of` / `_trilock_key_of` / `_own_key` / `td._frozen_key`
- 最小复现（父 agent 独立跑过）：

      build_object(bone=True) → 加第二根骨骼 BoneB，同帧 90 各插关键帧
      xf.mark_feel(kpA, 'left', 'LINK')     # BoneA
      xf.mark_feel(kpB, 'left', 'FREE')     # BoneB
      xf.feel_type(kpA, 'left')   ⇒  'FREE'   ← 期望 'LINK'
      act["rtmp_feel"]            ⇒  ['90.0000|left|FREE']   ← 只剩 1 条

- 影响：角色动画里「多骨骼同帧同侧」是**常态** ⇒ 手臂 A 设的「不动」被手臂 B 悄悄改掉，
  `_link_mode` 于是给出**错的联动决策**。
- 根因：曲线按骨骼名分流已经做对了，**账本没跟上**。docstring 说「Python API 没有从 Keyframe
  反查 F-Curve 的入口」—— 这对 **axis** 成立，但 **bone_name 在调用方是拿得到的**
  （`td.freeze_keyframe_pair` 就带 `bone_name`，只是没往下传）。

### D-2【高】四张表的键不含 slot ⇒ 共享 action 的两个 slot 互相串

- 最小复现（worker B D5b，同 D-1 机理）：slot A 记 LINK → slot B 记 FREE ⇒ A 读回 FREE，property 只剩 1 条
- 影响：共享 action 的两个对象各绑不同 slot 时，联动模式互相覆盖

### D-3【中】关键帧模态静默抹掉用户显式设的「不动(FREE)」

- 位置：`transform_domain.mark_owned_free` → `make_handles_editable`（真实入口 `modal_edit.py:1558`）
- 最小复现（父 agent 独立跑过）：

      xf.mark_feel(kp, 'left', 'FREE')     ⇒ feel_type='FREE', _link_mode(right)='free'
      xf.make_handles_editable(act, obj, {90.0: {ax: fc}})
      ⇒ feel_type='LINK',  _link_mode(right)='link'
      act["rtmp_feel"] ⇒ ['90.0000|left|LINK', '90.0000|right|LINK']

- 对照（口径不一致）：`freeze_handle_side` / `mark_frozen` / `spec_check._freeze_keyframe`
  三处都有「已记录不覆盖用户的选择」守卫，**只有 `mark_owned_free` 没有**
- ⚠️ **这正是 Phase 0 我修的 P1-3 —— 但只修了 3 处里的 2 处，漏了这条**

### A-1【中低】`resolve_target` 的 span 只取自第一根轴 ⇒ 端点轴也被写 dt

- 最小复现（父 agent 独立跑过）：X/Y 轴关键帧 {0,90,117}、Z 轴只有 {0,90}

      td.resolve_target(act, obj, 90, 'right')  ⇒ span=27.0（来自 X 轴）
      Z 轴自己的 td.segment_span(Z, 90, 'right') ⇒ None（端点段）
      td.write_s(kf_map, 'right', 0.5, 27.0)    ⇒ Z 轴也被写 dt=13.5
      不变量检查：无违规（盲区：端点侧 span=None 直接跳过）

- 附带：`td.neighbor_frame` 用**跨轴帧号并集**（=117），与逐轴 `segment_span`（None）
  是同一个「邻居」的两套定义 ⇒ 口径漂移

### F-1【低】`clamped` 只查上界、没查 `S_EPS` 下界

- 最小复现（父 agent 独立跑过）：对侧所需 s < `S_EPS(1e-5)` ⇒ 被钳到 S_EPS，
  但 `info["clamped"]==False` ⇒ 文案仍说「已一致」（实测残差仅 0.03%）
- 修法：`clamped = (s_req > S_HARD_MAX) or (s_req < S_EPS)`

---

## 三、Worker 报告但父 agent 未独立复现的（需复查）

| # | 发现 | 组 | 备注 |
|---|---|---|---|
| E3b | 180 度折角 ⇒ `fix_handle_bend` 把手柄长度**清零**（1.1456 → 0.0000），复检还说 `issues=[]` | E | 父 agent 用「同向 dv」构造**没复现** ⇒ 需要 worker 的原始构造 |
| A-3 | `scale_handle_uniform` 在 `side='left'` 且 `dt_base==0` 时返回**正** dt（符号错） | A | 父 agent 探针传参错误，未复现 |
| A-2 | `st.MAX_HANDLE_SCALE=100` 与属性 `max=10` 不一致，且两常量全仓无使用者 | A | 静态事实，可信 |
| E5b | 整条轴缺失 → 全量修：复检说「没事」，但插件自己的不变量被破坏（`dt=[9.0, 12.68, 9.0]`） | E | 与 Phase 0 的幂等性议题同族，**值得优先复查** |
| D-4 | 僵尸词条：删帧后记录不失效，重插同帧静默继承旧设置 | D | 双向对账查不出（两边一致指向不存在的帧） |

---

## 四、G/H 组（模态 + 组合）—— 209 项 / 205 PASS / **4 FAIL** / 1 SUSPECT

> ⚠️ **修正**：本报告早前读到的是该 worker 的**旧版结果**（64 条失败，混着大量「测试台够不着」的假失败）。
> worker 收尾时已把测试收敛到可稳定复现的形态 ⇒ **真实数字是 4 条失败**（连跑 3 次逐位一致）。

### G-1【高】G/R/S 变换模态不拒收鼠标哨兵 `-1` ⇒ 拖拽中跳变 **9.17** 个世界单位

- **最小复现**（已固化在 G1b）：选中 90 帧 → `MoveSession('MOVE').begin(...)` →
  先喂正常 `MOUSEMOVE(400,420)`（offset 长度 0.334733）→ 再喂 `mouse_region_x/y = -1`
  ⇒ offset 长度变 **9.504138**（跳变 **9.169406**）
- **期望**：`-1` 是「鼠标不在任何 Blender 区域上」的哨兵值，应**跳过本次移动** ——
  插件自己在 `interaction.py:1207` 的 docstring 里把这条写成了规范
  （「拿到 -1 这类哨兵值时跳过本次，**宁可不动也不跳变**」）
- **实际**：`modal_edit.py:2250-2259` 的 `RTMP_OT_KeyboardTransform.modal` 直接
  `s.update(event.mouse_region_x, event.mouse_region_y)`，**全无哨兵防护**
- **★ 根因是「修了一条、漏了另一条」**：同一个 bug 在**速度三角拖拽**那条路上早已修过
  （`interaction._is_usable_mouse` 就是收敛后的唯一判据），变换模态**没调用它** ✗
- **修复方向**：modal 的 MOUSEMOVE 分支改用 `interaction._is_usable_mouse`，无效就 return（不要更新 last_mouse）

### G-2【中】`interaction.py:274` 的 `undo_push` 没包 try ⇒ 异常从 modal 漏出，**整个模态死掉**

- **最小复现**（G4e，故障注入）：把 `interaction.bpy` 换成让 `ops.ed.undo_push` 抛异常的代理 →
  调 `it.try_reset_hovered_speed(...)` ⇒ 异常**漏出**，traceback 落在 `interaction.py:274`
- **静态证据**（G4d）：`undo_push` 调用 **6 处**，前面 260 字符内有 `try:` 的只有 **5 处** ✗
- **期望**：与同文件另外 5 处一致（注释明写「后台/无撤销上下文时忽略」），异常应被吞掉、返回 False
- **后果**：异常从 `modal()` 抛出 ⇒ Blender 报 Python 错误并终止该 modal ⇒ **「直接编辑模式」整体失效**
- 触发条件是「没有撤销上下文」（正常 GUI 下一般能成功），但这正是 P0-1 那次修复的**同类回归型不一致** ✓

### G-3【中·SUSPECT】疏密模态 ESC/右键取消后，段**另一端**的手柄类型静默留在 FREE

- **最小复现**（G9-SPEED）：`ModalSession('SPEED')` 对 (frame=90, side='left') 改值 → `cancel()`
- **实际**：关键帧 co 与手柄坐标**逐位还原** ✓、目标帧那一侧的类型也还原 ✓；
  但**相邻帧 0 那一侧**（段另一端）三个轴 `AUTO_CLAMPED → FREE`，且 `rtmp_frozen` 记着 `[0.0, 90.0]`
- **机理**：`ModalSession.restore()`（`modal_edit.py:1040`）的快照只覆盖 `self.target["kf_map"]`，
  而 `write_s(freeze=True)` 会把**段两端**都冻成 FREE ⇒ **另一端只冻不还原** ✗
- **严重度中·可疑**：「顺手冻结」本身是设计内的（会记进 `rtmp_frozen`/`rtmp_feel`，可被 UI 还原），
  但**取消**时它是静默、未提示、跨会话持久的副作用（用户在 Graph Editor 里会看到手柄类型永久变了）

### 值得记的 NOTE（都计 PASS）

- `ed.undo` 在 headless 下**步进粒度不可靠**（实测状态链 60 → push → 18 → push → 45 → undo 落在 60，
  即回退到**两个** undo 点之前；第二次 undo 还会 poll 失败）⇒ **真撤销保真度必须留 GUI 验证**
- `flush_pending_speed_drag` 用的是**最后一个非节流事件**的 Shift 精度状态，不是「那几像素移动发生时」的状态
  （真实交互里被节流吃掉的位移 ≤1 帧，不可见）
- 双击判据是 `Δt <= window`（时钟回退也天然算双击；`time.monotonic` 不会回退，不可达）
- **重开 .blend 后进程内四表是冷的**（文件里 property 还在）⇒ `E.invariants` 的「幽灵」判据**必然假阳性** ✗
  ⇒ 这是「缓存=派生、读时自查」的正常态，**不是缺陷**；真检验是「undo 清空内存表后能否从 property 恢复真相」（H2-16b 全过 ✓）

### 关键通过项（挑重点）

- `G1a` 速度三角拖拽的 `-1` 哨兵防护**有效** ✓（s 不变、last_mouse 不被污染）
- `G2` 对象/action 被删、拖拽中删对象、G/R/S 中删对象 —— 全不抛、标志正确复位（无「粘鼠标」）✓
- `G5` `context.area=None` 与 area/window 全 None —— 两种模态都不抛 ✓
- `G6a` 200 个零间隔事件后 s 有界；**位移不丢**：松手后 eff = 总 dy × DRAG_PX_SCALE，逐位一致 ✓
- `G7` 双击窗口边界（正好等于 ⇒ 命中；超 1μs ⇒ 不命中）、偏好钳在 [0.05,1.0]s —— 14 项全过 ✓
- `G8` 3 模式 × 6 约束 × 2 精度 = **36 组合全过**；数字输入 12 组合全过 ✓
- `G9` MOVE/ROTATE/SCALE × ESC/右键 = 6 组取消，**co + 手柄坐标 + 手柄类型逐位还原** ✓
- `G10` `unregister/register` 连做 20 次 —— 绘制句柄零泄漏、app handler 零堆积 ✓
- `H1` 一锅端（骨骼 + 两网格共享 action + 子帧 + 退化手柄 + 四表有记录）**每步后不变量全过**（28 项）✓
- `H2` 9 步全流程（显示→校正→调速→锁定→端点→undo→存盘重开→再校正→再检测）无一抛异常 ✓

---

## 五、已确认**健康**的（避免以后重查）

- `is_writable` 边界严格在 1e12，拒绝时 `last_skip_reason` **一定有文案**（不静默）
- `handle_scale_k` 的 `|dv_base|` 分界含等号；`UNIFORM_K_SAFETY=200` 折回且**保方向**
- `keyframe_at` 容差 1e-3 能分辨 0.4 帧间距；Blender 本身不允许小于 1e-3 帧距与重合关键帧
- 单/两关键帧、101 帧极密、10000 帧极疏、帧 0/负帧/帧 1e6 **全部无 NaN、不越段、不崩**
- 8 个 eps 常量各自**全仓唯一定义**；帧号匹配全仓只用 `state.FRAME_EPS`（已用静态契约锁住）
- `action.copy()` / 改名 / 复用旧名 / 多 action 切换 / `clear_all → warm` 行为**正确**
- 四表**双进程持久化**逐条一致、warm 回来正确
- 库链接 action 在 5.2 允许内存改写（Blender 语义，非插件 bug）；存盘重开按 property 重建、**无幽灵**
- Blender 5.2 硬限制：一个 action 只能 1 layer / 1 strip ⇒ `cache` 写死 `layers[0].strips[0]` 目前安全

---

## 六、fuzz（I 组）

500 轮随机（关键帧布局 / 手柄类型 / 操作序列全随机）+ 每轮跑不变量 ⇒ **0 违规**
⇒ 说明「单点随机操作」不容易破规范 —— 破规范的是 §2 那些**结构性**问题。

---

## 七、建议的修复优先级

| 优先级 | 项 | 理由 |
|---|---|---|
| **P1** | **D-1 / D-2**（表键加 bone_name + slot） | 多骨骼是常态 ⇒ 用户天天撞；且会让联动决策出错 |
| **P1** | **D-3**（`mark_owned_free` 加守卫） | Phase 0 漏掉的第三处；改动 3 行；与既有三处口径统一 |
| **P2** | **A-1**（`resolve_target` 逐轴 span） | 跨轴布局不同才触发；但会写坏端点轴 |
| **P2** | **E5b**（复检说没事但不变量破了） | 先复查，可能只是「复检口径不含某条不变量」 |
| **P3** | **F-1**（`clamped` 补下界） | 残差小；一行修 |
| **P3** | A-2 / A-3 / D-4 | 低风险或需先复查 |

**按计划，Phase 1 不改产品代码 —— 以上全部待你拍板。**

---

## 八、【补充】E/F 组 worker 的精确复现（父 agent 未能复现的两条现在有了）

### E5b 升级为 D-5【高】补轴（missing_axis）破坏「同侧三轴 dt 一致」，而 `apply_fix` 复检报 0 处

- **最小复现 A（整条轴缺失，最惨）**：只插 X 轴关键帧（`keyframe_insert("location", index=0, frame=f)`）

      report = sc.detect(act, o)             # 3 条 missing_axis（Y/Z 整条曲线都不存在）
      res, _ = sc.apply_fix(act, o, report)  # 默认三项
      res["after"]["issues"]                 # ⇒ []  插件说「修好了」
      E.invariants(act, o)                   # ⇒ 5 条违规：
          dt 超过段长 ax=1 f=90 right dt=30.0 span=27.0（s=1.111 > S_HARD_MAX）
          dt 超过段长 ax=2 f=90 right dt=30.0 span=27.0
          同侧三轴 dt 不一致 f=0  left/right: [30.0, 1.0, 1.0]
          同侧三轴 dt 不一致 f=90 right:     [9.0, 30.0, 30.0]

- **最小复现 B（单帧缺轴，更常见）**：`E.KEYS_3` 对象上删掉 Y 轴帧 90 的关键帧 → `apply_fix`
  ⇒ 残留 `同侧三轴 dt 不一致 f=90 right: [9.0, 12.68, 9.0]`
- **根因链**：`fix_missing_axes` 用 `keyframe_points.insert()` 造出的关键帧是 **ALIGNED 派生手柄**，
  时间分量由 Blender 按「朝邻居点的向量」算（实测 26.02 / 12.68，而同侧 X/Z 是 30 / 9），
  `_freeze_keyframe` 原样保住了它；后续 `dt_mismatch` 只处理 detect 报出来的项，
  而 **detect 在 `|dv| <= MIN_HANDLE_LEN(1.0)` 时整侧跳过**（`spec_check.py:480`）——
  复现 B 里该侧 `|dv|=0.59`；复现 A 里补出来的轴是平曲线、dv=0，角度判据恒 0。
  ⇒ `spec_check.py:1233-1238` 注释里「每阶段重跑 detect 就能兜住」的假设**不成立**。

### D-6【高】双击锁定的**下界**钳制未上报 ⇒ 文案说「速度已一致」而实际差 **51.5 倍**

- **最小复现**：关键帧 `(0,(0,0,0))` / `(10090,(1,2,0.5))` / `(10100,(2,3,1))`，帧 10090

      被双击侧 = 右段：dt=0.0015（Blender 抬到 0.00195），dv=1/轴  ⇒ v=886.81
      对侧     = 左段：span=10090，dt=10090（s=1.0），dv=1/轴
      it._align_opposite_speed(ctx, o, 10090, hd.TRI_DOWN, None)
      ⇒ 需要 s=1.94e-7 < S_EPS=1e-5 ⇒ write_s 钳到 S_EPS ⇒ 对侧速度只到 17.22
      ⇒ info["clamped"] = False（interaction.py:515 只判 > S_HARD_MAX 上界）
      ⇒ 真入口文案：「进出速度已一致」   而独立复算两侧仍差 51.50 倍

- **父 agent 早前测到 0.03% 残差、判为「低」** ⇒ 这个构造把它升到 **51.5 倍** ⇒ **严重度高** ✓
- **修法**：`clamped = (s_req > S_HARD_MAX) or (s_req < S_EPS)`，文案沿用 P1-1 的倍数写法

### D-7【中高】180 度折角（左右 dv 同向）⇒ `bisect` / `length_weighted` 把手柄长度清成 0

- **最小复现**（父 agent 之前用错构造，这是 worker 的原版）：

      帧 90 左右手柄都写 dv=(1.0, 0.5, 0.25)（同向 ⇒ fold=180°），体感登记 LINK
      sc.fix_handle_bend(act, o, report, None, None, strategy='bisect')
      ⇒ 两侧 dv 全变 (0,0,0)，手柄长度 1.1456 → 0.0；sc.detect 复检 issues=[]（**静默**）；路径形变 0.51
      right_only / left_only 同场景正常（长度守恒、fold→0）

- **根因**：`_target_dirs(spec_check.py:612-615)` 的 bisect 取 `ul - ur`，同向时为 **0**；
  length_weighted 在两侧等长时也是 0。零向量经 `_as_unit` 归一化仍返回 0 方向 ⇒ `_set_side_dv` 写成 dv=0。

### D-8【中】近 180 度时 bisect 的方向完全由浮点噪声决定

- 左手 dv=(1.0,0.5,0.25)、右手 dv=(0.98,0.49,0.245)（单位向量只差约 1e-7）
  ⇒ bisect 后手柄被**转向 90.00°**（长度守恒），路径形变 0.72
- 期望：方向不该由噪声决定（退化保护或选一侧）

---

## 九、【重要】本批次不变量检查器需要**校准**（fuzz worker 发现）

`_eb_common.invariants` 有**两条会误报**的判据，后续 worker 会在这里反复误判：

| 不变量 | 问题 | 校准建议 |
|---|---|---|
| **3. dt 不超过段长** | `xf.write_endpoint_uniform` 用**真实可达**的 k（≤200）写出 `dt=26.67 / span=0.4`（81 轮命中） | `scale_handle_uniform` docstring 写明「2026-09-17 用户拍板：**取消拉长上限**，手柄一直跟手变长」⇒ 该判据**只适用于 `td.write_s` 系**（它是唯一钳 `s <= S_HARD_MAX` 的） |
| **1. 同侧三轴 dt 相等** | 手柄是 **ALIGNED** 时，任意一次 `fc.update()` 都会让 Blender 按 (t,v) 共线把三轴 dt 写散（实测跨度 3.84e-2，并伴随 dt 被拉过段长） | **插件自己就会造出 ALIGNED**（`xf._DRAG_TO_TYPE`：AUTO/AUTO_CLAMPED → ALIGNED）⇒ 断言要**按手柄类型分流** |

⚠️ 这条校准**不改变任何已确认的缺陷**（D-1 到 D-8 都是 FREE 手柄下的复现），
但会让后续批次的**误报率**降下来。

---

## 十、fuzz 的正面结论（5 个种子 × 500 轮）

`td.write_s` / `td.apply_pixel_drag` / `it._align_opposite_speed` / `sc.apply_fix` /
`xf.set_tri_locked` 在**真实可达参数**下**从未**引入不变量违规；
`xf.write_endpoint_uniform` 三轴路径也从未把三轴 dt 写散（除「dt>段长」那条口径）。

⇒ **破规范的是 §2/§8 那些结构性缺陷，不是单点随机操作。**


