# -*- coding: utf-8 -*-
"""导出「规范 before/after」可视化数据（headless 独立进程，不碰任何用户工程）。

对 5 条规范，各造两组数据：
    before = 违规状态（用户手动微调过 GE 之后的常见样子）
    after  = 按【微调方法】处理之后

导出内容（供 HTML 用 SVG 重绘 3D 视图 + Graph Editor）：
    · 路径采样点（3D 世界坐标）
    · 关键帧点（3D）
    · 每个关键帧左右手柄的端点（3D）
    · 三条 F-Curve 的 (t, v) 采样（画 GE 曲线）
    · GE 里每个关键帧的 co / handle_left / handle_right 控制点 (t, v)
    · 每个场景的度量：折角 / 相切角 / 形状偏差
"""
import os
import sys
import math
import json

import bpy
import mathutils

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "规范对比数据.json")

MID = 25.0
FRAMES = (1.0, 25.0, 55.0)
POS = {1.0: (0.0, 0.0, 0.0), 25.0: (3.0, 2.0, 0.6), 55.0: (6.0, 0.0, 3.0)}
# ⚠️ 末帧 Z 取 3.0（不是 0）—— 让 Z 轴在中间帧 25 处【有斜率】。
#    否则 25 帧是 Z 的极值点，切向的 Z 分量≈0 ⇒ "缺 Z 轴"这个违规量不出来（实测 0.33°）。
BASE_DV = {0: 1.0, 1: 0.5, 2: 0.25}
BASE_DT = 8.0
GE_T = [1.0 + i * 0.25 for i in range(217)]      # 1 → 55，步长 0.25
PATH_T = [1.0 + i * 0.25 for i in range(217)]


# ---------------------------------------------------------------- 基础工具
def curves(o):
    """取 location 的三条 F-Curve（Blender 4.4+ 分层动作，action.fcurves 不存在）。"""
    act = o.animation_data.action
    fcs = []
    try:
        fcs = list(act.fcurves)
    except Exception:
        fcs = []
    if not fcs:
        try:
            ad = o.animation_data
            slot = getattr(ad, "action_slot", None)
            if slot is None and act.slots:
                slot = act.slots[0]
            for layer in act.layers:
                for strip in layer.strips:
                    bag = strip.channelbag(slot, ensure=False)
                    if bag is None:
                        continue
                    fcs.extend(list(bag.fcurves))
        except Exception:
            pass
    return {fc.array_index: fc for fc in fcs if fc.data_path == 'location'}


def kp_at(o, frame, ax):
    fc = curves(o).get(ax)
    if fc is None:
        return None
    for kp in fc.keyframe_points:
        if abs(kp.co[0] - frame) < 1e-3:
            return kp
    return None


def build(name):
    me = bpy.data.meshes.new(name + "_mesh")
    me.from_pydata([(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1)], [], [(0, 1, 2), (0, 1, 3)])
    me.update()
    o = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(o)
    for f in FRAMES:
        bpy.context.scene.frame_set(int(f))
        o.location = POS[f]
        o.keyframe_insert("location", frame=f)
    for fc in curves(o).values():
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        fc.update()
    # 基准：左右严格反向共线，三轴时间跨度都 = 8
    set_side(o, MID, 'left', {0: -BASE_DV[0], 1: -BASE_DV[1], 2: -BASE_DV[2]},
             {0: -BASE_DT, 1: -BASE_DT, 2: -BASE_DT})
    set_side(o, MID, 'right', dict(BASE_DV),
             {0: BASE_DT, 1: BASE_DT, 2: BASE_DT})
    return o


def set_side(o, frame, side, dv_map, dt_map):
    """把某帧某一侧的三轴手柄设成指定 (值分量, 时间分量)。"""
    for ax, fc in curves(o).items():
        kp = kp_at(o, frame, ax)
        if kp is None:
            continue
        t = float(kp.co[0]) + dt_map.get(ax, BASE_DT if side == 'right' else -BASE_DT)
        v = float(kp.co[1]) + dv_map.get(ax, 0.0)
        if side == 'right':
            kp.handle_right = (t, v)
        else:
            kp.handle_left = (t, v)
    refresh(o)


def set_symmetric(o, frame, dv_map, dt_map):
    """把左右两侧都设成 dv_map 的对称形式（左侧取负）—— 模拟"用户在 GE 里对称地调"。"""
    set_side(o, frame, 'right', dict(dv_map), dict(dt_map))
    set_side(o, frame, 'left', {a: -v for a, v in dv_map.items()},
             {a: -v for a, v in dt_map.items()})


def set_types(o, frame, side, htype):
    for ax, fc in curves(o).items():
        kp = kp_at(o, frame, ax)
        if kp is None:
            continue
        if side in ('left', 'both'):
            kp.handle_left_type = htype
        if side in ('right', 'both'):
            kp.handle_right_type = htype
    refresh(o)


def refresh(o):
    for fc in curves(o).values():
        fc.update()


def read_side(o, frame, side):
    dv, dt = {}, {}
    for ax in (0, 1, 2):
        kp = kp_at(o, frame, ax)
        if kp is None:
            continue
        h = kp.handle_right if side == 'right' else kp.handle_left
        dv[ax] = float(h[1]) - float(kp.co[1])
        dt[ax] = float(h[0]) - float(kp.co[0])
    return dv, dt


def fold_deg(o, frame=MID):
    dl, _ = read_side(o, frame, 'left')
    dr, _ = read_side(o, frame, 'right')
    u = [dl.get(a, 0.0) for a in (0, 1, 2)]
    v = [-dr.get(a, 0.0) for a in (0, 1, 2)]
    lu = math.sqrt(sum(x * x for x in u)); lv = math.sqrt(sum(x * x for x in v))
    if lu < 1e-12 or lv < 1e-12:
        return 0.0
    d = sum(u[i] * v[i] for i in range(3)) / (lu * lv)
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def numeric_tangent(o, frame=MID, eps=0.05):
    """路径在该帧的真实切向 —— 用【曲线求值差分】算，不依赖手柄数据。

    ⚠️ 必须这样算（不能用手柄的 dv/dt）：缺轴时手柄只有两个分量，
       若切向也只用那两个分量算，两边"一起缺"就会自洽 ⇒ 量不出偏差。
    """
    cs = curves(o)
    v = []
    for a in (0, 1, 2):
        fc = cs.get(a)
        if fc is None:
            v.append(0.0)
            continue
        v.append(float(fc.evaluate(frame + eps)) - float(fc.evaluate(frame)))
    n = math.sqrt(sum(x * x for x in v))
    return [x / n for x in v] if n > 1e-12 else None


def tangent_deg(o, frame=MID, side='right'):
    """手柄方向 与 路径真实切向 的夹角（相切 ⇒ 0）。"""
    dv, _dt = read_side(o, frame, side)
    u = [dv.get(a, 0.0) for a in (0, 1, 2)]
    tan = numeric_tangent(o, frame)
    lu = math.sqrt(sum(x * x for x in u))
    if tan is None or lu < 1e-12:
        return 0.0
    d = sum(u[i] * tan[i] for i in range(3)) / lu
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def path_sample(o, frames):
    cs = curves(o)
    return [[float(cs[a].evaluate(f)) if a in cs else 0.0 for a in (0, 1, 2)] for f in frames]


def unit(v):
    n = math.sqrt(sum(x * x for x in v))
    return ([x / n for x in v] if n > 1e-12 else [0.0, 0.0, 0.0]), n


FR_LEFT = [1.0 + i * (24.0 / 199.0) for i in range(200)]
FR_RIGHT = [25.0 + i * (30.0 / 199.0) for i in range(200)]


def haus(A, B):
    m = 0.0
    for p in A:
        d = min((p[0]-q[0])**2 + (p[1]-q[1])**2 + (p[2]-q[2])**2 for q in B) ** 0.5
        m = max(m, d)
    return m


def export(o, ge_vscale=1.0):
    """把一个对象的状态导出成可绘制数据。

    `ge_vscale`：**只影响 GE 图的纵轴放大倍数**（把挤在一起的曲线拉开便于观察），
                   不改变任何数据；1.0 = 原始比例。
    """
    cs = curves(o)
    kfs = []
    handles = []
    for f in sorted(POS.keys()):
        pos = [float(cs[a].evaluate(f)) if a in cs else 0.0 for a in (0, 1, 2)]
        kfs.append({"frame": f, "pos": pos})
        for side in ('left', 'right'):
            dv, dt = read_side(o, f, side)
            if not dv:
                continue
            hp = [pos[a] + dv.get(a, 0.0) for a in (0, 1, 2)]
            handles.append({"frame": f, "side": side, "from": pos, "to": hp,
                            "dv": [round(dv.get(a, 0.0), 5) for a in (0, 1, 2)],
                            "dt": [round(dt.get(a, 0.0), 5) for a in (0, 1, 2)]})
    # GE 纵轴参考点 = 三轴关键帧值的中位数（放大时绕它展开，图形不会跑出画面）
    _allv = []
    for ax in (0, 1, 2):
        fc = cs.get(ax)
        if fc is None:
            continue
        _allv.extend(float(kp.co[1]) for kp in fc.keyframe_points)
    _ref = sorted(_allv)[len(_allv) // 2] if _allv else 0.0
    vs = float(ge_vscale)
    def _vf(v):
        return _ref + (float(v) - _ref) * vs

    ge = {"vscale": vs, "vref": round(_ref, 6)}
    for ax in (0, 1, 2):
        fc = cs.get(ax)
        if fc is None:
            continue
        pts = [[round(float(t), 4), round(_vf(fc.evaluate(t)), 6)] for t in GE_T]
        ent = {"samples": pts, "kfs": []}
        for kp in fc.keyframe_points:
            ent["kfs"].append({"co": [round(float(kp.co[0]), 4), round(_vf(kp.co[1]), 6)],
                               "hl": [round(float(kp.handle_left[0]), 4), round(_vf(kp.handle_left[1]), 6)],
                               "hr": [round(float(kp.handle_right[0]), 4), round(_vf(kp.handle_right[1]), 6)],
                               "lt": str(kp.handle_left_type), "rt": str(kp.handle_right_type)})
        ge[str(ax)] = ent
    mid = next((k for k in kfs if abs(k["frame"] - MID) < 1e-6), None)
    dvR, dtR = read_side(o, MID, 'right')
    return {
        "path": [[round(v, 6) for v in p] for p in path_sample(o, PATH_T)],
        "kfs": kfs,
        "handles": handles,
        "ge": ge,
        "fold": round(fold_deg(o), 4),
        "tan": round(tangent_deg(o, MID, 'right'), 4),
        "axes_at_mid": sorted(dvR.keys()),
        "mid_pos": [round(v, 6) for v in (mid["pos"] if mid else [0, 0, 0])],
        "mid_tangent": [round(v, 6) for v in (numeric_tangent(o, MID) or [0, 0, 0])],
        "mid_dv_r": [round(dvR.get(a, 0.0), 6) for a in (0, 1, 2)],
        "mid_dt_r": [round(dtR.get(a, 0.0), 6) for a in (0, 1, 2)],
        "mid_dv_l": [round(read_side(o, MID, 'left')[0].get(a, 0.0), 6) for a in (0, 1, 2)],
    }


# ---------------------------------------------------------------- 5 条规范
SPECS = []

# ============ 规范 ①：三轴时间跨度必须相等 ============
o = build("S1_before")
set_side(o, MID, 'right', dict(BASE_DV), {0: 8.0, 1: 14.0, 2: 6.0})   # 三轴各拖各的
before = export(o)
p_before = path_sample(o, PATH_T)
set_side(o, MID, 'right', dict(BASE_DV), {0: 8.0, 1: 8.0, 2: 8.0})    # 统一到中位数 8
after = export(o)
after["haus"] = round(haus(path_sample(o, PATH_T), p_before), 6)
SPECS.append({
    "id": "s1",
    "title": "规范 ①：同一帧同一侧，三轴的「时间跨度」必须相等",
    "why": "手柄方向 ∝ 三轴的长度；路径切线 ∝ 三轴（长度 ÷ 时间跨度）。要让两者平行，只能让三轴时间跨度相等。",
    "symptom": "手柄与路径【不相切】—— 看着像手柄「歪」在路径旁边。",
    "violation": "用户在 Graph Editor 里分别拖了三轴的手柄（或只拖了其中一轴），三轴时间跨度变成 8 / 14 / 6。",
    "fix": "把三轴的时间跨度统一成一个值（取中位数 8）。只动「时间」，不动「长度」。",
    "cost": "路径形状会变（实测偏差 0.1999 ≈ 路径长度的 3%）。这是数学必然：统一时间跨度就是统一各轴的时间映射。",
    "before": before, "after": after,
})

# ============ 规范 ②：左右手柄长度方向必须反向平行（仅"对齐"体感） ============
WANT2 = {0: 1.0, 1: 1.5, 2: 0.25}      # 用户在 GE 里把右侧 Y 手柄长度拉长了
DVL2 = {0: -1.0, 1: -0.5, 2: -0.25}

o = build("S2_before")
# ⚠️ 违规的关键是【左右不对称】：只动右侧，左侧保持原样
set_side(o, MID, 'right', dict(WANT2), {0: 8.0, 1: 8.0, 2: 8.0})
before = export(o)
pL0 = path_sample(o, FR_LEFT)
pR0 = path_sample(o, FR_RIGHT)
pA0 = path_sample(o, PATH_T)

_ul, _Ll = unit([DVL2[0], DVL2[1], DVL2[2]])
_ur, _Lr = unit([WANT2[0], WANT2[1], WANT2[2]])

# 四个候选的「目标单位方向」（= 左侧手柄要指的方向 t，右侧取 -t）
_m = [_ul[i] - _ur[i] for i in range(3)]
_w = _Ll / (_Ll + _Lr) if (_Ll + _Lr) > 1e-9 else 0.5
_mw = [(1 - _w) * _ul[i] + _w * (-_ur[i]) for i in range(3)]
CAND2 = [
    ("A 只动右侧（以较早的左侧为准）", _ul),
    ("B 只动左侧（以右侧为准）", [-x for x in _ur]),
    ("C 两侧各转一半（角平分）", unit(_m)[0]),
    ("D 按手柄长度加权（长的一侧少转）", unit(_mw)[0]),
]


def _rot_deg(a, b):
    na = math.sqrt(sum(x * x for x in a)); nb = math.sqrt(sum(x * x for x in b))
    if na < 1e-12 or nb < 1e-12:
        return 0.0
    d = sum(a[i] * b[i] for i in range(3)) / (na * nb)
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


STRATS = []
_after_state = None
for _label, _t in CAND2:
    _o = build("S2_" + str(abs(hash(_label)) % 99999))
    set_side(_o, MID, 'left', dict(DVL2), {0: -8.0, 1: -8.0, 2: -8.0})
    set_side(_o, MID, 'right', dict(WANT2), {0: 8.0, 1: 8.0, 2: 8.0})
    # 保持两侧【长度】不变，只把方向转到共线
    set_side(_o, MID, 'left', {a: _t[a] * _Ll for a in (0, 1, 2)}, {0: -8.0, 1: -8.0, 2: -8.0})
    set_side(_o, MID, 'right', {a: -_t[a] * _Lr for a in (0, 1, 2)}, {0: 8.0, 1: 8.0, 2: 8.0})
    _st = export(_o)
    STRATS.append({
        "name": _label,
        "fold": _st["fold"],
        "rot_l": round(_rot_deg(_ul, _t), 2),
        "rot_r": round(_rot_deg(_ur, [-x for x in _t]), 2),
        "d_left": round(haus(path_sample(_o, FR_LEFT), pL0), 5),
        "d_right": round(haus(path_sample(_o, FR_RIGHT), pR0), 5),
        "d_all": round(haus(path_sample(_o, PATH_T), pA0), 5),
    })
    if _label.startswith("C"):
        _after_state = _st

after = _after_state
after["haus"] = next(s["d_all"] for s in STRATS if s["name"].startswith("C"))
after["strategies"] = STRATS
SPECS.append({
    "id": "s2",
    "title": "规范 ②：左右手柄的「长度方向」必须反向平行（只在「对齐」体感下要求）",
    "why": "3D 视图里左右手柄连成一条直线 = 曲线在该帧平滑过渡。是否要求「一条直线」，取决于用户的体感设置。",
    "symptom": "3D 视图里手柄出现【折角】—— 左右两根手柄不在一条直线上。",
    "violation": "用户在 Graph Editor 里只把某一轴、某一侧的手柄长度拉长（值分量），左右长度比例不再对称。",
    "fix": "两侧手柄【长度都不动】，只把方向转到共线。方向取谁？下面四种策略实测对比 —— 默认选【C 两侧各转一半】，它把路径变形摊到两段上、总变形最小。",
    "cost": "会改变路径形状（动的是「长度」= 直接改动画数据）。所以这条默认【不勾选】，只在用户明确需要时做。",
    "before": before, "after": after,
})

# ============ 规范 ③：三轴关键帧帧号集合必须一致 ============
o = build("S3_before")
fcz = curves(o)[2]
for kp in [k for k in fcz.keyframe_points if abs(k.co[0] - MID) < 1e-3]:
    fcz.keyframe_points.remove(kp)
refresh(o)
before = export(o)
p_before = path_sample(o, PATH_T)
# 修法：补回缺失的关键帧，值 = 曲线求值（不动现有轨迹）
val = float(curves(o)[2].evaluate(MID))
curves(o)[2].keyframe_points.insert(MID, val)
refresh(o)
set_side(o, MID, 'left', {0: -1.0, 1: -0.5, 2: -0.25}, {0: -8.0, 1: -8.0, 2: -8.0})
set_side(o, MID, 'right', dict(BASE_DV), {0: 8.0, 1: 8.0, 2: 8.0})
after = export(o)
after["haus"] = round(haus(path_sample(o, PATH_T), p_before), 6)
SPECS.append({
    "id": "s3",
    "title": "规范 ③：三轴的关键帧帧号集合必须一致（不能某轴缺关键帧）",
    "why": "插件画手柄时要按帧号把三个轴的手柄拼成一个 3D 向量；缺一轴，那个分量只能记成 0。",
    "symptom": "该帧手柄【少一个分量】—— 方向偏掉、拖拽写入也不完整（实测偏 12.15°）。",
    "violation": "用户在 Graph Editor 里删掉了某一轴的关键帧（或三轴的帧号本来就错开）。",
    "fix": "在缺失的帧上补关键帧，值取【曲线求值】(该帧) —— 补的点正好落在原曲线上。",
    "cost": "0（相对「缺轴状态」而言）。⚠️ 但补不回删除前的曲线：信息在删除那一刻就丢了。所以定位是「功能修复」，不是「还原动画」。",
    "before": before, "after": after,
})

# ============ 规范 ④：手柄类型不能是「派生类型」 ============
WANT_R = {0: 1.0, 1: 1.5, 2: 0.25}          # 用户在 GE 里调好的样子（右侧）
WANT_L = {0: -1.0, 1: -1.5, 2: -0.25}        # 对称地调了左侧 ⇒ 左右仍共线
WANT_DT = {0: 8.0, 1: 12.0, 2: 8.0}          # 用户顺手把三轴时间跨度也调了

o = build("S4_before")
set_types(o, MID, 'both', 'AUTO_CLAMPED')
set_symmetric(o, MID, WANT_R, {0: 8.0, 1: 8.0, 2: 8.0})   # 用户对称地调好了（长度 1.5）
refresh(o)          # ← AUTO_CLAMPED 把"用户想要的"整段重算掉
before = export(o, ge_vscale=8.0)             # GE 纵轴放大 8 倍，方便看清手柄差异
p4_before = path_sample(o, PATH_T)

# ★ 实测：把类型从 AUTO_CLAMPED 转成 FREE，**坐标一个数都不动**
#   （做法照抄项目既有的 make_handles_editable：先 copy → 设类型 → 写回）
_snap_before_conv = {a: (tuple(kp_at(o, MID, a).handle_left),
                         tuple(kp_at(o, MID, a).handle_right)) for a in (0, 1, 2)}
set_types(o, MID, 'both', 'FREE')
for _ax in (0, 1, 2):
    _k = kp_at(o, MID, _ax)
    _k.handle_left = _snap_before_conv[_ax][0]
    _k.handle_right = _snap_before_conv[_ax][1]
refresh(o)
_conv_delta = 0.0
for _ax in (0, 1, 2):
    _k = kp_at(o, MID, _ax)
    _conv_delta = max(_conv_delta,
                      abs(float(_k.handle_left[0]) - _snap_before_conv[_ax][0][0]),
                      abs(float(_k.handle_left[1]) - _snap_before_conv[_ax][0][1]),
                      abs(float(_k.handle_right[0]) - _snap_before_conv[_ax][1][0]),
                      abs(float(_k.handle_right[1]) - _snap_before_conv[_ax][1][1]))

o2 = build("S4_after")
set_types(o2, MID, 'both', 'FREE')            # ① 先把类型转成「自由」（坐标不动）
set_symmetric(o2, MID, WANT_R, {0: 8.0, 1: 8.0, 2: 8.0})   # ② 用户重新调一次 ⇒ 这次保住了
refresh(o2)
after = export(o2, ge_vscale=8.0)
after["type_conv_delta"] = round(_conv_delta, 10)
after["haus"] = round(haus(path_sample(o2, PATH_T), p4_before), 6)
SPECS.append({
    "id": "s4",
    "title": "规范 ④：手柄类型不能是「派生类型」（自动 / 自动钳位 / 矢量）",
    "why": "派生类型（自动 / 自动钳位 / 矢量）的坐标由 Blender 按公式【导出】，不接受外部写入 —— 你写进去的值【当场就被覆盖】。实测：想写 (时间 8.0, 长度 1.0)，读回来是 (10.0, 1.71)，全是 Blender 算的。",
    "symptom": "「我明明在 Graph Editor 里调好了，切一下帧 / 点一下别处，手柄自己变回去了」—— 调好的长度被压回 Blender 算的值。⚠️ 注意：这一条不是「手柄位置画错了」，而是「你的编辑不生效」（看 before 图：手柄位置本身是合规的）。",
    "violation": "关键帧是新建时的默认类型（自动钳位），或者用户手动设成了自动 / 矢量。这类类型的坐标由 Blender【按公式导出】，你写的它不算数。",
    "fix": "把该手柄转成「自由」—— 只改类型，手柄坐标一个数都不动（实测最大变化 0.0000000000）。作用是「从此以后」你的调整不会再被 Blender 覆盖。",
    "cost": "0（不改任何数值）；代价是失去 Blender 的自动平滑。⚠️ 已经被覆盖掉的那次调整【恢复不了】，要重新调一次。",
    "before": before, "after": after,
})

# ============ 规范 ⑤：「对齐」体感下，改时间跨度会被 Blender 反噬 ============
o = build("S5_before")
set_types(o, MID, 'both', 'ALIGNED')
refresh(o)
set_side(o, MID, 'right', dict(BASE_DV), {0: 8.0, 1: 14.0, 2: 8.0})   # 只改 Y 轴时间跨度
refresh(o)          # ← ALIGNED 为了恢复共线，会反手改掉【长度】
before = export(o)

o2 = build("S5_after")
set_types(o2, MID, 'both', 'FREE')                       # ① 先转 FREE（别让 Blender 反噬）
set_symmetric(o2, MID, BASE_DV, {0: 8.0, 1: 8.0, 2: 8.0})  # ② 三轴时间跨度统一（修"不相切"）
refresh(o2)
after = export(o2)
after["haus"] = 0.0
SPECS.append({
    "id": "s5",
    "title": "规范 ⑤：「对齐」体感下，手柄的（时间, 长度）必须同步 —— 否则 Blender 会反手改你的长度",
    "why": "「对齐」的规则是三点共线。一旦时间跨度变了、共线被破坏，Blender 会【去改长度】来恢复共线。",
    "symptom": "改速度 → 手柄长度被偷改 → 3D 出现【折角】+ 路径形状真的变了。",
    "violation": "手柄类型是「对齐」，而用户在 Graph Editor 里单独拖了某一轴的时间跨度。",
    "fix": "把被编辑侧转成「自由」，再做时间跨度的调整。",
    "cost": "该侧失去「与对侧共线」的自动约束（体感从「对齐」变成「自由」）。这是二选一，不能两全。",
    "before": before, "after": after,
})

with open(OUT, "w", encoding="utf-8") as fh:
    json.dump({"specs": SPECS}, fh, ensure_ascii=False, indent=1)

print("=" * 100)
print("%-6s %-58s %10s %10s %12s" % ("id", "规范", "折角前", "折角后", "相切前→后"))
print("-" * 100)
for s in SPECS:
    print("%-6s %-58s %10.4f %10.4f   %.2f → %.2f" % (
        s["id"], s["title"][:56], s["before"]["fold"], s["after"]["fold"],
        s["before"]["tan"], s["after"]["tan"]))
print("=" * 100)
print("已写出:", OUT)
