# -*- coding: utf-8 -*-
"""回归测试：双击锁定 = **同步三角值 s**（B 语义），且**三轴 dt 必须一致**。

★★ 2026-09-30 语义定案（用户拍板）：
    用户口径：「三角控制柄双击锁定的功能目的其实根本只有一点，
              就是在**路径形状不变**和**对应 GE 各轴端点 dt 值相同**的前提下，
              让**关键点进出的速度是一致的**」
            「我说的是**速度值相同**，不是速度矢量相同」

  ⇒ "速度值" = **三角控制柄的值 `s`**（= dt / 段跨度），不是物理速度矢量 dv/dt。
    依据是插件自己的定义：「一体：两个三角**联动** —— 拖动**两边同值**」
    ⇒ "一体" ⟺ 两个三角的 s 相同。

历史三版（都在追不同的目标，本测试只认第三版）：
  · 09-18：按【主用轴】算一个 dt、三轴共用 ⇒ 只有主用轴共线
  · 09-29：**逐轴各算各的 dt** ⇒ 三轴全共线 ✓ 但**同侧三轴 dt 被写散** ✗
           （实测 dtL = [-8, -4, -16] ⇒ 打破"三轴 dt 一致"的规范，用户报障）
  · **09-30（现在）**：只同步 s，**一次 write_s 写三轴同一个 dt** ⇒ 规范 ✓
           代价：GE 手柄**不再保证共线**（那交给弹窗里的校正，它会告知改形状）

本测试的**区分度**由 B 组（注入验证）保证：故意用 09-29 那版算法
（逐轴各调一次 write_s）跑一遍，断言「三轴 dt 被写散」——
如果哪天有人把实现改回去，C 组会立刻失败。

跑法（后台即可，不需要真机 GUI）：
    blender --background --factory-startup --python tests/gui_peraxis_align_check.py
"""
import sys, os, json, traceback
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)
import bpy

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})

# ★ 用户 Suzanne f25 的真实手柄值（真机读回）—— 三轴 A/B 比例**互不相同**
REAL = {
    0: (-4.852765083312988, (17.0, -11.206832885742188), (35.0, 3.089820384979248)),
    1: (2.73264741897583, (17.0, -1.9671909809112549), (31.89328384399414, 4.570038795471191)),
    2: (13.08447265625, (17.0, 13.08447265625), (35.0, 13.08447265625)),
}
FR = 25.0

def main():
    try:
        import addon_utils, importlib
        addon_utils.enable(PKG_NAME, default_set=True, persistent=False)
        it = importlib.import_module(PKG_NAME + ".interaction")
        cache = importlib.import_module(PKG_NAME + ".cache")
        hd = importlib.import_module(PKG_NAME + ".handles")
        td = importlib.import_module(PKG_NAME + ".time_domain")

        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        ob = bpy.context.view_layer.objects.active
        ob.name = "_PERAXIS"
        for f in (1, 25, 55):
            ob.location = (0, 0, 0)
            ob.keyframe_insert("location", frame=f)
        act = ob.animation_data.action

        def reset():
            for fc in cache.collect_animation_curves(act, ob):
                for kp in fc.keyframe_points:
                    if abs(float(kp.co[0]) - FR) < 1e-3:
                        co, hl, hr = REAL[fc.array_index]
                        kp.co[1] = co
                        kp.handle_left = hl
                        kp.handle_right = hr
                        kp.handle_left_type = 'FREE'
                        kp.handle_right_type = 'FREE'
            for fc in cache.collect_animation_curves(act, ob):
                fc.update()

        def survey():
            d = {}
            for fc in cache.collect_animation_curves(act, ob):
                for kp in fc.keyframe_points:
                    if abs(float(kp.co[0]) - FR) < 1e-3:
                        A = float(kp.co[1]) - float(kp.handle_left[1])
                        B = float(kp.handle_right[1]) - float(kp.co[1])
                        dtL = abs(float(kp.co[0]) - float(kp.handle_left[0]))
                        dtR = abs(float(kp.handle_right[0]) - float(kp.co[0]))
                        d[fc.array_index] = {
                            "A": A, "B": B, "dtL": dtL, "dtR": dtR,
                            "slopeL": (A / dtL) if dtL > 1e-12 else None,
                            "slopeR": (B / dtR) if dtR > 1e-12 else None,
                        }
                        d[fc.array_index]["collinear"] = (
                            d[fc.array_index]["slopeL"] is not None
                            and d[fc.array_index]["slopeR"] is not None
                            and abs(d[fc.array_index]["slopeL"] - d[fc.array_index]["slopeR"]) < 1e-6)
            return d

        # ---------- A 组：场景前提（三轴比例确实不同） ----------
        reset()
        a = survey()
        ratios = {ax: (abs(a[ax]["B"] / a[ax]["A"]) if abs(a[ax]["A"]) > 1e-12 else None)
                  for ax in sorted(a)}
        step("A1 ★ 场景前提：三轴 |B/A| 互不相同（复刻用户文件）",
             len({round(v, 6) for v in ratios.values() if v is not None}) >= 2,
             "|B/A| = %s" % {k: (round(v, 4) if v is not None else None) for k, v in ratios.items()})
        step("A2 初始：X 共线 / Y 不共线（= 用户报障时的状态）",
             a[0]["collinear"] and not a[1]["collinear"],
             "X:%.6f/%.6f Y:%.6f/%.6f" % (a[0]["slopeL"], a[0]["slopeR"],
                                          a[1]["slopeL"], a[1]["slopeR"]))

        # ---------- B 组：注入验证 —— 09-29 那版（逐轴各调一次）会把 dt 写散 ----------
        reset()
        kf_s, span_s = td.resolve_target(act, ob, FR, 'left')
        kf_o, span_o = td.resolve_target(act, ob, FR, 'right')
        for ax in kf_o:
            kp_s = kf_s.get(ax)
            if kp_s is None:
                continue
            A = float(kp_s.co[1]) - float(kp_s.handle_left[1])
            B = float(kp_s.handle_right[1]) - float(kp_s.co[1])
            if abs(A) < 1e-12 or abs(B) < 1e-12:
                continue
            dt_ideal = abs(float(kp_s.co[0]) - float(kp_s.handle_left[0])) * abs(B) / abs(A)
            td.write_s({ax: kf_o[ax]}, 'right', dt_ideal / span_o, span_o, act=act, obj=ob)
        for fc in cache.collect_animation_curves(act, ob):
            fc.update()
        b = survey()
        _spread = max(b[ax]["dtR"] for ax in (0, 1)) - min(b[ax]["dtR"] for ax in (0, 1))
        step("B1 ★★ 注入验证：09-29 那版（逐轴各调一次 write_s）⇒ **三轴 dt 被写散**"
             "（复刻用户报障，证明本测试能区分实现）",
             _spread > 1.0, "X.dtR=%.4f Y.dtR=%.4f（跨度 %.4f）" % (b[0]["dtR"], b[1]["dtR"], _spread))
        step("B2 ★★ 那版下同侧三轴 dt 不相等 ⇒ **打破「三轴 dt 一致」的规范**",
             _spread > 1.0, "dtR 跨度=%.4f（规范要求 0）" % _spread)

        # ---------- C 组：本版实现 ⇒ 两侧 s 相同 + 三轴 dt 一致 ----------
        reset()
        v0 = {ax: (survey()[ax]["A"], survey()[ax]["B"]) for ax in REAL if ax in survey()}

        def svals():
            """两侧的三角值 s = dt / 段跨度（取三轴中位数）。"""
            out = {}
            for sd in ('left', 'right'):
                kfm, span = td.resolve_target(act, ob, FR, sd)
                if not kfm or not span:
                    out[sd] = None
                    continue
                mags = []
                for ax, kp in kfm.items():
                    h = kp.handle_left if sd == 'left' else kp.handle_right
                    d = abs(float(h[0]) - float(kp.co[0]))
                    if d > 1e-9:
                        mags.append(d)
                out[sd] = (sorted(mags)[len(mags) // 2] / span) if mags else None
            return out

        s0 = svals()
        ok, info, reason = it._align_opposite_speed(bpy.context, ob, FR, hd.TRI_UP)
        step("C1 调用 _align_opposite_speed（双击上三角）", ok, "reason=%s" % reason)
        c = survey()
        s1 = svals()

        def vvals():
            """两侧的**物理速度** |v| = |dv| / dt（dt 取三轴中位数）。

            ★★ 2026-09-30 用户拍板方案 ②：目标量是 `|v|`（速度的**大小**），
               不是 `s = dt/段长`（那是"归一化时间跨度/疏密"，另一个量）。
               两者只有在 `|dv|/段长` 恒定时才等价 —— 真实工程里不成立。
            """
            out = {}
            for sd in ('left', 'right'):
                kfm, span = td.resolve_target(act, ob, FR, sd)
                if not kfm:
                    out[sd] = None
                    continue
                mags, dvs = [], []
                for ax, kp in kfm.items():
                    h = kp.handle_left if sd == 'left' else kp.handle_right
                    mags.append(abs(float(h[0]) - float(kp.co[0])))
                    dvs.append(float(h[1]) - float(kp.co[1]))
                dt = sorted(mags)[len(mags) // 2]
                n = sum(x * x for x in dvs) ** 0.5
                out[sd] = (n / dt) if dt > 1e-9 else None
            return out

        # ★★★ 本版的核心：两侧**物理速度相等**
        v1 = vvals()
        step("C2 ★★★ 锁定后：**两侧物理速度 |v| 相等**（方案 ② 的核心 —— 进出速度一致）",
             # ⚠️ 手柄存的是 float32 ⇒ 不可能位级相等，用相对阈值
             v1['left'] is not None and v1['right'] is not None
             and abs(v1['left'] - v1['right']) < 1e-5,
             "|v|: %s → %s（目标 %.6f）"
             % ({k: (round(v, 6) if v else None) for k, v in s0.items()},
                {k: (round(v, 9) if v else None) for k, v in v1.items()},
                (info or {}).get('v_target', -1)))

        # ★★ 规范：三轴 dt 必须一致（这是 09-29 那版打破的东西）
        _sp_l = max(c[ax]["dtL"] for ax in (0, 1, 2)) - min(c[ax]["dtL"] for ax in (0, 1, 2))
        _sp_r = max(c[ax]["dtR"] for ax in (0, 1, 2)) - min(c[ax]["dtR"] for ax in (0, 1, 2))
        step("C3 ★★★ 锁定后：**三轴 dt 完全一致**（跨度 < 1e-6）—— 规范要求",
             _sp_l < 1e-6 and _sp_r < 1e-6,
             "dtL 跨度=%.2e dtR 跨度=%.2e" % (_sp_l, _sp_r))

        step("C4 ★ 保形状：三轴值分量 A/B 一个都没变（只动时间分量）",
             all(abs(v0[ax][0] - c[ax]["A"]) < 1e-9 and abs(v0[ax][1] - c[ax]["B"]) < 1e-9
                 for ax in c),
             "before=%s after=%s" % ({k: (round(v[0], 6), round(v[1], 6)) for k, v in sorted(v0.items())},
                                     {k: (round(c[k]["A"], 6), round(c[k]["B"], 6)) for k in sorted(c)}))
        # ⚠️ 方案 ② 下**两侧 dt 都要重算**（dt = |dv|/|v*|）——
        #    所以不能再断言"被双击侧不动"，改成断言"两侧都等于 |dv|/|v*|"
        # ★★★ 2026-09-30 最终定案：**以【被双击侧】为准**（命令语义，不是均值）。
        #     用户原话：「应该是看用户双击的是哪个三角控制柄，
        #              然后把对端也统一为同样的速度值才对，所以不是均值」
        #     本测试双击的是 TRI_UP = 'left' ⇒ left 一个数不动，right 重算成 |dvR|/|vL|
        #
        # ⚠️⚠️ `|dv|` 是**三轴的向量范数**（不是一个轴的值分量）——
        #     物理速度是 3D 速度的大小，所以 dt = |dv_3D| / |v*|。
        #     拿单轴的 |A| 去算会得到错的期望值（本测试第一版就踩了这个坑）。
        _vt = (info or {}).get('v_target')

        def _dvnorm(sd):
            kfm, _sp = td.resolve_target(act, ob, FR, sd)
            dvs = []
            for ax, kp in kfm.items():
                h = kp.handle_left if sd == 'left' else kp.handle_right
                dvs.append(float(h[1]) - float(kp.co[1]))
            return sum(x * x for x in dvs) ** 0.5

        _expR = (_dvnorm('right') / _vt) if _vt else None
        _dtL_unchanged = all(abs(c[ax]["dtL"] - a[ax]["dtL"]) < 1e-9 for ax in (0, 1, 2))
        step("C5 ★★★ 被双击侧（left）dt 一个数没动 + 对侧 = |dvR_3D| / |vL|（命令语义）",
             _vt and _dtL_unchanged
             and all(abs(c[ax]["dtR"] - _expR) < 1e-5 for ax in (0, 1, 2)),
             "|v*|=|vL|=%.6f |dvR_3D|=%.4f ⇒ dtR=%.4f(期望 %.4f)；dtL 未动=%s"
             % (_vt or -1, _dvnorm('right'), c[0]["dtR"], _expR or -1, _dtL_unchanged))
        step("C6 ★ Z 轴退化（值分量为 0）不影响「值」的读取（s 只由 dt 决定）",
             abs(c[2]["A"]) < 1e-12 and _sp_r < 1e-6,
             "Z: A=%.1e；dtR 三轴仍一致" % c[2]["A"])
        step("C7 ★ info 带 v_target / v_before / v_after（便于排查）",
             isinstance(info, dict) and "v_target" in info and "v_before" in info
             and "v_after" in info,
             json.dumps({k: (round(v, 4) if isinstance(v, float) else v)
                         for k, v in (info or {}).items()}, ensure_ascii=False)[:200])
        step("C8 ★ 数学事实：本版**不保证 GE 手柄共线**（那交给校正，会改形状）",
             True,
             "X 共线=%s Y 共线=%s（理想 dtR 相差 %.2f 倍，单一 s 不可能全共线）"
             % (c[0]["collinear"], c[1]["collinear"], 10.0 / 3.1276))
    except Exception:
        step("EXCEPTION", False, traceback.format_exc()[-1000:])

    print("=" * 74)
    for s in steps:
        print("[%s] %s  %s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                              ("<- " + s["detail"]) if s["detail"] else ""))
    fails = sum(1 for s in steps if not s["ok"])
    print("总计 %d 项 | PASS %d | FAIL %d | %s"
          % (len(steps), len(steps) - fails, fails, "ALL PASS" if not fails else "HAS FAILURES"))
    OUT = os.path.join(PLUGIN_DIR, "tests", "_peraxis_align_result.json")
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"total": len(steps), "fails": fails, "steps": steps}, f,
                  ensure_ascii=False, indent=1)
    print("RESULT:", "PASS" if not fails else "FAIL")
    sys.stdout.flush()

if __name__ == "__main__":
    main()
