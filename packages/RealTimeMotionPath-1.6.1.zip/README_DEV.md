# RealTimeMotionPath - 开发者文档

---

## ⚠️ 审查债进度清单（2026-09-27 起）

> **为什么放这里**：`.docs/` 里有 5 份审查报告（合计 280+ KB），但它们**不是施工单** ——
> 第 5 轮审查发现：四份报告写在 2026-09-26/27，而源码停在 09-19，
> 报告里那份"合计不到 20 行"的 P0 清单**一条都没落地**。
> ⇒ 这张清单放在最显眼处，**改一条划一条**。

### ✅ 已完成（2026-09-27 · 第 5 轮收口）

**用户能直接撞到的**
- [x] **draw_handler 泄漏**：`cancel()` 里 `detach` 必须排在 `reset()` **之前**
      （原先顺序反了 ⇒ detach 读到 None 直接 return ⇒ 每开关一次攒一个回调）
- [x] **姿态模式按 G/R/S 完全没反应**：模态补传 `bone_name`
      （原生键被抑制、插件又找不到骨骼曲线）—— 速度三角一并支持骨骼
- [x] **封口闸门口径**：新增 `drawing.local_eps_for_screen`（绘制/拾取/闸门三处共用）
      —— 父级带缩放时不再"屏幕看着是零长度、一拖却误封口"
- [x] **撤销栈空步**：单击选中三角（没拖）不再推 undo
- [x] **`undo_push` 三处**：复位提到 push **之前** + 包 try（防状态位永久残留 ⇒ "粘着鼠标走"）

**静默失效类**
- [x] 5 处 `wm.rtmp_*` 裸访问 → `getattr` 守卫（插件卸载后仍会被 modal/绘制走到）
- [x] 2 行**必然失败**的 `import transform_domain`（异常会穿透到菜单绘制 ⇒ 菜单项不渲染）
- [x] `_is_usable_mouse` 判据收敛（原先判据抄了两份、函数本体是零调用死代码）
- [x] `finish_linked_handle` 的 ref 兜底：不再静默退回 `_ARM_EPS`(1e-9)
- [x] `_frozen_key` 帧号口径与另三张登记表对齐（`round(,4)`；整数帧会撞键并串帧）

**测试与文案**
- [x] 3 条挂了 4 天的**假失败**判据 + 1 条 `or True` **恒真断言**
- [x] i18n：`ui` / `handles` / `transform_domain` / `time_domain` / `modal_edit` 的
      report 文案（违规 58 → **46**）；删掉 3 条 identity 假翻译词条
- [x] 僵尸判定口径修正（"抽成常量"的文案不再被误判为僵尸）
- [x] `gui_speed_throttle_check` 的静态契约：固定字符窗口 → 结构化窗口
      （加注释不再导致假失败）

**新增的"网"（这才是最值钱的）**
- [x] `tests/run_all.py` —— **1,224 条断言一键判定**（原先一键只跑 14 条）
- [x] `tests/CONTRACTS.md` —— 15 条用户契约卡（"功能不变"的操作化定义）
- [x] `tests/_snapshot_recorder.py` + `_snapshot_diff.py` —— 状态快照录像机与结构化比对
- [x] `tests/i18n_gate.py` —— 真·全量 i18n 门禁（AST 扫 CJK，已做反事实检验）
- [x] **实机测试**（独立 GUI 进程）：C1/C2/C4/C12 全过 + bug 注入对照
      （修复后 `detach_real=3/noop=0`；注入旧顺序 `real=0/noop=3`）

### ✅ 已完成（2026-09-27 · 第 5 轮收口 · 第二批）

- [x] **46 条 `modal_edit` 状态栏文案** → 英文 + 34 条真翻译
      ⇒ `i18n_gate` **58 → 0**；`regression` 新增第 16 条判据常驻
      （⚠️ 过程中踩了两个坑，都写进脚本注释了：AST 的 `col_offset` 是
      **UTF-8 字节偏移**不是字符偏移；docstring 必须排除，否则含"移动/旋转"
      字样的说明文字会被误改）
- [x] **录像机场景 7 → 19 个（34 → 89 步）**：覆盖 PRESS/RELEASE 的各子分支
      （Shift 多选 / Ctrl 区间选择 / Shift 精度 / BACK_SPACE 复位 / 拖手柄**线** /
      右键 / ESC+TIMER / 点空白清选 / 一体锁定点一个选两个 / 选中态拖动 /
      多选拖动 / 空心圆抓取点）
- [x] **★★ 架构：拆掉 583 行的 `modal()`** ⇒ 分派器 **36 行** + 5 个 `_ev_*` 方法
      （`_ev_mousemove` 130 / `_ev_rightmouse` 44 / `_ev_left_press` 286 /
      `_ev_left_release` 97 / `_ev_leftmouse` 8 行分派器）

      **做法**（不是盲拆）：先用 AST 对每个分支做**自由变量分析**（`loads - stores`），
      确认「需外部提供」的名字**全部是模块级全局**（`_session`/`td`/`FRAME_EPS`…）
      ⇒ 新方法在同一模块内同样可见、**不需要额外传参**；
      唯一有跨语句生命周期的局部量 `area_to_redraw` 在每个分支内各自赋值
      ⇒ 整体搬走、语义不变。逻辑**逐字未改**，只有缩进 12 → 8。

      **验证**：89 步快照逐位一致（**值差异 0 处**）+ regression 16/0 + 全量 1,224/0

- [x] `_snapshot_diff.py` 排除"工具元信息"（`mounted_methods` 等）——
      否则每次重构都会假报"行为有变化"

### ✅ 已完成（2026-09-27 · 第 5 轮收口 · 第三批：复盘 P0/P1）

**P0 隐患**
- [x] **`_cache_update_lock` 跨模块值拷贝** → 改成显式 `_state._cache_update_lock`。
      `from X import name` 对**不可变对象**（bool/int/str）拿到的是**值的副本**，
      于是 cache.py 里的 `global` + 赋值只改自己那份，`state._cache_update_lock`
      永远是 False ⇒ 将来谁在 state 里读到这个"重入锁"都会得到永久 False
      （**锁静默失效**）。`_session` 没这问题 —— 它是对象引用，副本指向同一对象。
- [x] **`speed_drag_normalized` 死字段**（写 2 次、全仓无读取点）→ 删除。
      它是"超范围 s 规范化"改写后的残留（该语义现在由"拖拽起点一律用
      unclamped d"实现，见 `speed_drag_origins` 的注释）。

**P1 工具链**
- [x] **5 个测试文件的硬编码绝对路径** → 改成 `dirname(__file__)` 推导
      （换机器 / 换目录不再跑不起来）
- [x] **27 个判据脚本的退出码**：`os._exit(0)` → `os._exit(1 if <有失败> else 0)`。
      通用钥匙是所有判据脚本共用的 `steps.append({"name":…, "ok":…})` 骨架
      ⇒ `any(not s["ok"] for s in steps)`，**不依赖各自的自定义变量名**。
      （前两版分别试过"固定变量名清单"和"`X += 1` 计数器"，全部落空 ——
        失败数是在 `flush()` 里**现算**的，压根不存在计数器变量。
        教训：**找共性要找真正的骨架，别猜命名习惯**。）
      探针类（`_*_probe.py`）只 dump 数据、不产出成败 ⇒ 保持原样。

**★★ 复盘最大收获：门禁自己的两个洞**

- [x] **`run_all.py` 加 STALE 检查**：结果文件比最新产品源码还旧 ⇒ 判为
      **不可信**，不许冒充 PASS。
      **踩到的实例**：i18n 把状态栏文案统一成英文后，`gui_numeric_check.py`
      里三条断言（`"[输入 2.5]" in txt`）**已经失败**，但 `_num_result.json`
      还是改动前的（fails=0）⇒ **门禁报"全部通过"，这条真回归被藏了一段时间**；
      最后是靠"给测试脚本补退出码 + 把 57 个脚本重跑一遍"才翻出来的。
      > 门禁读的是"体检报告" —— **报告必须是这次体检的**。
      > 三个月前的报告说"你很好"，没有任何意义。
- [x] **孤儿结果文件** `_e2e_result.json`（全仓没有任何脚本写它，
      mtime 停在 09-18）→ 加进 `_EXCLUDE`

**★★ 2026-10-08 补充：STALE 的正确读法是「有脚本没跑成功」，不是噪音**

本轮又撞上同一个坑，而且这次**真原因在别处**：
4 个结果文件一直 STALE，查下去才发现脚本里写死了

```python
ADDONS = r'F:\desktop\BaiduSyncdisk\addons'      # 家里机路径
```

IDES 是**同步盘**（公司机 `D:\` / 家里机 `F:\`）⇒ 在公司机上这行把 `sys.path`
指向不存在的目录 ⇒ 脚本**静默失败，但退出码仍是 0** ⇒ 不写结果 JSON。

⇒ 两条硬规矩：

1. **STALE 不许当噪音放过** —— 它等价于「这个脚本最近没跑成功」。
2. **测试脚本里绝不写盘符**，一律用 `__file__` 推导：
   `HERE = dirname(abspath(__file__))` → `ADDONS = dirname(dirname(HERE))`。
   （`_extreme_fuzz.py` 里那份**生成复现脚本的模板**同理：改为插值生成时的真实路径。）

**批量重跑工具**：`python tests/_batch_rerun.py`（自动探测 blender.exe；
可 `--only a.py,b.py` 只跑指定几个）。
⚠️ 脚本前缀有 4 类，**别漏**：`_` / `gui_` / `test_` / `i18n_gate`。
（第一次写时只放了前两类，9 个 `test_*` 脚本没跑，却毫无提示。）

**★★ 多版本机器上：先确认"跑的是哪个 Blender"**

2026-10-08 踩过一次（详见 `Change Log.md` 第十轮 ⑦）：
本机装了 5 个 Blender，自动化脚本"自动探测"静默选中了 **5.0**，
而用户日常用的是 **5.2.2**（Steam 那份）。3 个用 `gpu.init()` 的测试
（5.1+ 才有该 API）在 5.0 上崩掉，于是得出一串错误结论 ——
「本机没有 5.2」「这些测试本机跑不了」，还拿 `git stash` 前后对照"证明"
了它跟改动无关（**但两边都跑在错误版本上**）。

⇒ 两条：
1. `_batch_rerun.py` 已改为**优先 Steam 那份（用户日常环境）**，
   且每次跑都打印所有候选 + 实际使用的版本。**看输出里那行 `### 使用: ...`。**
2. 判断"某测试失败是因为版本"之前，**先跑 `blender --version` 实测**——
   扫到路径 ≠ 知道它是哪个版本。（我当时扫到了路径，却靠假设填了空白。）

**由此连带修掉的 9 个测试侧回归**（都是本次重构/改文案造成的，**产品行为没坏**）

| 类别 | 文件 | 修法 |
|---|---|---|
| 手抄替身缺 `_ev_*` | `gui_ge_align` / `gui_mouse_sentinel` / `gui_real_path` | 挂真实 operator 方法；**必须插在 import 之后**（插在类定义后曾报 `NameError: name 'inter' is not defined`） |
| 中文断言失效 | `gui_check` / `gui_endpoint_fix_check` / `test_modal_state_machine` / `gui_interaction_v2_check` | 改成**语义标记 + 双语兼容**（判"意图"，不判"某个中文词"） |
| 删字段残留 | `gui_interaction_v2_check` | 删掉对 `speed_drag_normalized` 的设置 |
| 静态契约按缩进切片 | `gui_speed_throttle_check` | 改成**与位置/缩进无关**的全文件判据（判据意图不变） |

### ✅ 已完成（2026-09-29 · 全面 review 后按发现修复）

> 起因：「从根本架构出发 + 抠细节」的全面 review，逐项验证后修复。
> **每条都有验证**（探针 / 回归 / 注入）。

**真 bug（2 条，均经 bug 注入验证：注入 → FAIL，恢复 → PASS）**

- [x] **`overlay._norm_selected` 对 `set` 输入必抛 `TypeError`**：
      签名声明接受 `set`，实现却写 `selected[0]`（set 不可下标）。
      没炸只因 3 个调用点恰好都传 list —— **埋着的雷**。
      改为先归一化成 list；探针 `tests/_norm_selected_probe.py`（5 断言）。
- [x] **`RTMP_DEBUG_LOG` 文档承诺但代码未实现**（全仓 `environ` 0 命中）：
      现已补齐（真值 `1/true/yes/on`，大小写无关）。
      优先级：显式 `set_enabled()` 压倒环境变量。
      探针 `tests/_debug_log_probe.py`（18 断言）。
      （注：另两种启用方式——偏好设置、Python 调用——**本来就是真的**。）

**闸门口径**

- [x] **`xf.apply_endpoint_transform` 的「保速」闸门漏用 `zero_eps`**：
      上一轮修了封口闸门（2 处），漏了同一函数里的保速闸门 ⇒
      屏幕上"看不见但数学上非零"的端点仍会被缩 dt 压平曲线。现统一为「视觉零」。

**死代码**

- [x] **删除 8 个零引用顶层函数**（AST 全仓扫描；源码 + 测试均 0 引用）：
      `_apply_speed_from_mouse` / `warm_tri_lock` / `prepare_drag_side_free`(79行) /
      `cycle_axis_lock` / `pose_of` / `collect_endpoints` / `render_facing_square`(49行) /
      `s_to_speed_ratio`。
      `prepare_drag_side_free` 的实测经验已确认在其继任者 `prepare_handles_for_drag`
      的 docstring 里（5×5 类型矩阵 + "故意不调 `fc.update()`"的坑）。

**唯一口径**

- [x] **帧号匹配容差收敛**：原先散落在 6 个模块（用 `interaction.FRAME_EPS`、
      硬编码 `1e-3`、还有一处 `1e-4` 混用）⇒ 现唯一定义在 **`state.FRAME_EPS`**。
      （`cache.FRAME_INT_EPS` = 1e-4 是**另一语义**——判"是否整数帧"，保留。）

**结构**

- [x] **4 个模态会话类抽公共基类 `_SessionBase`**：此前是平行类（只有 `ScaleSession`
      继承 `RotateSession`），协议全靠 duck typing ⇒ 加第 5 个会话时会漏实现方法。
      现基类写明"子类必须实现哪些"，并把 3 份**逐字重复**的 `confirm`/`cancel` 上提。

**文档**

- [x] `README.md` 版本 `1.1.0` → **`1.3.9`**（此前落后 8 个版本）。
- [x] `README_DEV.md` 模块结构补全 **7 个缺失模块**。

**验证手段**

- [x] **实机 GUI 测试跑通**（独立 GUI 进程，非 `--background`）：
      真实窗口 / 3D 视图 / Operator 注册 / WM 属性 / 场景+关键帧 / 视图重绘
      —— **9/9 PASS**。探针：`tests/_gui_live_probe.py`。
      ⚠️ 两个坑（值得记）：① Blender 按 `bl_idname` 注册 operator ⇒ 类型名是
      `RTMP_OT_path_point_drag`（**不是**源码类名 `RTMP_OT_PathPointDrag`）；
      ② `Action.fcurves` 在 4.4+ 已移除（改用 slots/layers/channelbags），
      要用插件自己的 `cache.collect_animation_curves`。


### ✅ 已修复（2026-09-29 · 用户报障：姿态模式下速度三角一个都不出现）

**症状**：在骨骼（姿态模式）下做位移动画后，**速度三角完全不出现** —— 无报错、无提示。

**根因**：速度三角这条子路径**整条链都没传 `bone_name`**。

`td._collect_position_curves(act, obj, None)` 里 `cache.is_position_animation(fc, None)`
只认 `data_path == 'location'`，而骨骼曲线是 `pose.bones["Bone"].location` ⇒ **全被排除**。
实测：不带骨骼名 = **0 个关键帧**；带 = **3 个**。

**⚠️ 这不是「骨骼支持没做」** —— 排查确认：

- `interaction.py` 里鼠标拖拽 / 键盘模态那 5 处**本来就正确传了** `_session.active_bone_identifier`
- `modal_edit._pose_bone_name` 早就是权威口径（docstring 明确写"口径与鼠标路径统一"）
- `keyframe_screens`（2026-09-27 3e 延伸）也已传
- **只有速度三角这条链漏了**

**放大器**：`_all_speed_handles` 的宽 `except` **静默返回 `[]`** ⇒ 无报错、无日志
⇒ 这个 bug 才拖了这么久。已改为**首次失败时打印 traceback**（只打一次，避免 mousemove 刷屏）。

**修法**：新增 `_bone_name_of(context, obj)` 作为这条链的**唯一口径**（内部即 `_pose_bone_name`），
补到 4 处：`_all_speed_handles` / `_apply_speed_d` / `_copy_speed_value` / `_align_opposite_speed`；
另补 `modal_edit._refresh_curves` 的 `fcurve_of` 与 `time_domain.apply_pixel_drag` 的 `write_s`。

**为什么既有调用点一个字都不用改**：这三个函数都加了 `bone_name=None` 参数，
**缺省时在函数内自动回退**取（实测生效）。只有"回退也取不到"（非 POSE / 无活动骨骼）才失败，
且是**明确返回 `no_source`**，不会静默写到别处。

**验证**（`tests/gui_bone_speed_check.py`，11 项）：

- A 组：曲线路径是 `pose.bones[...]`；**核心对照** —— 不带骨骼名 0 帧 / 带 3 帧
- B 组：`resolve_target` 不带取不到、带骨骼名取到 3 轴
- C 组：对齐能**真正写进骨骼曲线**且三轴共线、值分量一个没变；
  并守住"不传时自动回退生效"+"回退也取不到时明确失败"

另用真机探针（独立 GUI 进程）确证：修复后姿态模式下**出现 4 个三角**，且每个三角能被自己命中。

### ✅ 已完成（2026-09-29 · 全仓「静默吞异常」排查 → 43 处加留痕）

**起因**：修骨骼那个 bug 时发现 `_all_speed_handles` 的 `except: return []`
**吞掉了一切信息** ⇒ 功能整体消失却无报错、无日志、无从排查。
于是扫全仓量化了这类模式。

**扫描判据**（AST）：except 体是 `pass` / `continue` / `break` /
`return None` / `return []` / `return {}` / `return 0` / `return False`
⇒ 判定为「不留任何痕迹」。

**结果**：核心代码命中 **192 处**（不含 tests）。逐条按语义分档 ——

| 档位 | 数量 | 处理 |
|---|---|---|
| **核心数据路径** | **43** | 加 `warn_once()` 留痕 |
| 去重标记 / 事件循环 / 善后 | 87 | 低危，不动 |
| 绘制 / 注册 / 日志 / import 兜底 | 62 | **故意的，不动** |

**唯一判据**：*这个操作失败了，用户看得出来吗？*

- 看不出来（数据悄悄少 / 悄悄错）⇒ **留痕**
- 无所谓（恢复光标、写日志、每帧重画）⇒ **不动**

那 62 处不改的理由：绘制类每秒重画几十次（这帧画不出下帧还会试）、注册/注销幂等、
日志写不进去无所谓 —— **改成「出错就中断」反而更糟**。

**实现**：`state.py` 新增 `warn_once(tag)` / `reset_warned_tags()`：

- **只打印，不改控制流** ⇒ 调用方原有语句一个都不动（**行为零变化**）
- **每个 tag 只打一次**（模块级 set）—— 这类函数常在 mousemove 上每秒被调几十次
- tag = 「文件名.函数名」；traceback 自带精确行号，tag 不必带行

**落点**：`cache` / `time_domain` / `transform_domain` / `modal_edit` /
`interaction` / `edit_geometry` 各补 `warn_once` 导入（`state` 是底层，不会循环导入）。
`interaction._log_collect_failure`（上一条的临时版）已**统一**到 `warn_once`，不留两套机制。

**验证**：

- 全量 **67 个测试全过**（唯一非零 `_snapshot_diff.py` 是 CLI 工具的正常 rc=2）
- 门禁 **1263 断言 / 0 失败 / 无 STALE**
- 真加载验证：`bl_info version == (1,4,0)`；`warn_once` 实测「同一 tag 只打一次」
- 换行符保持（各文件原样：LF / CRLF 分别核对）

> ⚠️ **副作用（诚实记录）**：`_snapshot_recorder.py` 与 `gui_ge_align_check.py`
> 会打印 traceback —— 因为它们用**假上下文 `FakeCtx`**，缺 `preferences` /
> `selected_objects`，原本被静默吞掉，现在**暴露了**。测试本身 `rc=0` 全过。
> 这算「留痕按设计工作」，但也暴露了**测试台的假对象不完整**（待办）。

**顺带**：`workspace/_rerun_all.py` 去掉了硬编码路径（公司机 C 盘）——
改为自动查 Blender（`$RTMP_BLENDER` → PATH → 各盘符常见位置）+ 从 `IDES_HOME` 推导仓库，
**换机不再跑不起来**。

### ★★★ 2026-09-30 最终定案：双击锁定 = 让【两侧物理速度 |v| 相等】（方案 ②）

> ⚠️ 本节**推翻**下面的「同步三角值 s」一版 —— 用户实测后指出：
>   「实现是实现了，但是感觉进出的速度值似乎还是不一样？
>     你是怎么定义这个速度值的」
>   查实：`s = dt/段长` 是**归一化时间跨度（疏密）**，
>   **不是物理速度**。用户口径的"速度值" = `|v| = |dv|/dt`（速度的**大小**，不是矢量）。
>   用户工程实测：`s` 已相等（0.170953/0.170953），但 `|v|` = 10.3127 / 16.4927（**差 1.60 倍**）✓

**实现（★★ 最终版：以【被双击侧】为准 —— 命令语义，不是均值）**：

> 用户再次纠正：「回想一下双击锁定三角的功能，应该是看用户双击的是哪个三角控制柄，
>                然后把对端也统一为同样的速度值才对，**所以不是均值**」
> ⇒ 这是**命令**语义（我点谁，就以谁为准），不是**协商**语义。
>   也正好恢复插件原本记录的语义：「保持被双击侧的疏密 dt 不动」。

    v_target = |v_被双击侧|              # ★ 以被双击侧为准
    dt_对侧   = |dv_对侧_3D| / v_target   # 一个标量 ⇒ 三轴天然一致 ✓
    只写【对侧】一次 write_s（写三轴同一个 dt）⇒ 规范保住 ✓
    被双击侧**一个数都不动** ✓

**实测（两侧速度差 1.6× 时）**：

| 双击哪一侧 | v_target | 锁定后 | 被双击侧 dt | 形状偏移 |
|---|---|---|---|---|
| down（右） | 0.112790（右侧的） | dt 24.624 / 7.387，\|v\| 都 0.112790 ✓ | **没变** ✓ | 3.48% |
| up（左） | 0.180464（左侧的） | dt 15.390 / 4.617，\|v\| 都 0.180464 ✓ | **没变** ✓ | 3.59% |

⚠️ 与"均值"版的代价对比：均值版两侧各变一点 ⇒ 1.6× 时 2.22%；
   **命令版只有对侧变 ⇒ 3.5%**。用户明确选命令版（直觉优先）。

⚠️⚠️ `|dv|` 必须是**三轴的向量范数**，不是某一轴的值分量 ——
   物理速度是 3D 速度的大小。（本实现第一版拿单轴 |A| 算，测试 C5 当场抓到。）

**形状代价（实测，相对"调速后"的状态）**：

| 两侧速度差 | 路径最大偏移 |
|---|---|
| 1.2× | 0.66% |
| **1.6×（用户工程）** | **2.22%** |
| 2.0× | 4.00% |
| 3.0× | 9.00% |
| 5.0× | 19.75% |

⚠️ 这是 ② 的固有代价：两侧 dt 都要重算 ⇒ 形状必然变。
   **若两侧速度本来就相等 ⇒ ② 一个数都不写（实测 0.0000%）** ✓（最小干预）。

⚠️ ② 与"`s` 相等"**互斥**（除非 `|dv|/段长` 恒定）：② 之后 `s` 会不等。
   守：`gui_peraxis_align_check` C2（|v| 相等）/ C5（dt = |dv_3D|/|v*|）。

### （已被推翻）2026-09-30 中间版：双击锁定 = 同步「三角值 s」

用户口径（**这一版的唯一依据**）：
    「三角控制柄双击锁定的功能目的其实根本只有一点，就是在**路径形状不变**和
      **对应 GE 各轴端点 dt 值相同**的前提下，让**关键点进出的速度是一致的**」
    「我说的是**速度值相同**，不是速度矢量相同」

⇒ "速度值" = **三角控制柄的值 `s`**（= dt / 段跨度），**不是**物理速度矢量 dv/dt。
  依据是插件自己的定义：「一体：两个三角**联动** —— 拖动**两边同值**」。

**三版对照（都在追不同目标，别再改回去）**：

| 版本 | 做法 | 结果 |
|---|---|---|
| 09-18 | 按【主用轴】算一个 dt、三轴共用 | 只有主用轴共线 |
| 09-29 | **逐轴各算各的 dt** | 三轴全共线 ✓ 但**同侧三轴 dt 被写散** ✗ |
| **09-30** | 只同步 s，**一次 `write_s` 写三轴同一个 dt** | 规范 ✓ 形状 ✓；GE **不保证共线** |

⚠️ **本版明确不保证 GE 手柄共线**（三轴比例不同时数学上无解）。
   想要 GE 全共线 ⇒ 用弹窗里的可选「强制对齐关键帧进出速度」，它会改 dv、
   **明确告知会改变路径形状**。守：`gui_peraxis_align_check` 的 C8。

⚠️⚠️ **别把 `td.write_s` 改成"逐轴各调一次"** —— 那正是 09-29 那版的错，
   会把同侧三轴 dt 写散（实测 `[-8, -4, -16]`）。
   `write_s` 的语义本身就是「把 s 写到该帧的**所有轴**」⇒ 天然三轴同 dt ✓
   守：`gui_peraxis_align_check` 的 B1/B2/C3。

### ★★ 2026-09-30 修复：FREE 体感被三角控制柄冲掉

用户报障：「用户在 FREE 体感类型下一使用三角控制柄相关的功能，
          3D 手柄的体感类型就会自动切回对齐」。

**根因（两处叠加）**：
  · `time_domain.freeze_handle_side` 转类型**前没先保体感** ⇒ 原类型丢了
  · `time_domain.mark_frozen` **无条件**写 LINK ⇒ 冲掉用户主动设的 FREE
**对照**：`spec_check._freeze_keyframe` 早就做对了
（「未记录时才写；**已记录的不覆盖用户的选择**」）—— 同一插件两条路径口径不一致。

**修法**：转类型前先按原类型登记体感 + `mark_frozen` 不覆盖已登记；
抽出唯一实现 `xf.feel_for_orig_type`（raw → feel），`spec_check` 改为委托。
守：`gui_frozen_link_check` 的 X1 / X2。

### ✅ 已修复（2026-09-29 · 用户报障：双击锁定后 GE 手柄仍不对齐）

⚠️ **本节记录的是 09-29 那版的做法（逐轴各写各的 dt）—— 已在 09-30 被推翻**
   （它打破"三轴 dt 一致"的规范）。保留只为说明"为什么会有那一版"，**别照着改回去**。

**症状**：双击三角「锁回一体」后，Graph Editor 里**只有 X 轴**手柄共线，其余轴（实测 Y）不对齐。
用户描述「有动作但不符合预期」—— 因为状态确实切成了「一体」，但对侧手柄**写了却没动到位**。

**根因**（真机连上用户 Blender 读到实测数据后定位）：

`_align_opposite_speed` 只按【主用轴】(array_index 最小者，通常 X) 算**一个** dt，三轴共用。
其注释里的前提是「自动手柄下 A/B 三轴天然恒等」—— 那只在**三轴运动严格成比例**
（且手柄未被人工精修）时才为真。用户文件里 X 走 1 格、Y 走 2.56 格 ⇒ 三轴 A/B 并不相等：

```
X 需 dtR=10.00 才共线 → 写 10.00 ✓
Y 需 dtR= 3.13 才共线 → 也写 10.00 ✗（斜率 0.1837 vs 左侧 0.5875）
```

**修法**：改为**逐轴各算各的 dt**（每轴独立满足「两侧斜率绝对值相等」）；
退化轴（值分量为 0，手柄水平）单独跳过，不牵连其他轴。
值分量（A/B）依旧一律不碰 ⇒ **3D 路径形状不变**，只改采样点疏密。

**验证**（`tests/gui_peraxis_align_check.py`，11 项）：

- A 组：场景前提 —— 三轴 |B/A| 确实不同（复刻用户文件）
- B 组：**注入验证** —— 故意用旧算法跑一遍，断言「Y 仍不共线」
  ⇒ 证明本测试有区分度（谁改回主轴算法，C 组立刻红）
- C 组：修复后 X/Y 全共线、Y 的 dtR 从 10 变 3.1276、值分量一个没变、被双击侧 dtL 未动

**顺手记两条老坑**（本轮排查中再次踩到）：

- `Action.fcurves` 在 Blender 4.4+ 已移除 —— 读曲线要走 `cache.collect_animation_curves`。
- 后台（`--background`）模式下 `bpy.app.timers` **不会触发** ⇒ 探针脚本要直接执行，别挂 timer。

**上帝类拆分（第一层：纯计算层抽出）**

- [x] **`RTMP_OT_PathPointDrag` 拆出纯计算层 → 新模块 `edit_geometry.py`（967 行 / 18 个函数）**
      - 搬走的：命中检测（找手柄 / 找采样点，263 行）、手柄数学（偏移 / 切向 /
        同比例缩放，454 行）、联动收尾 + 快照（259 行）
      - 类：1590 → **约 620 行**；`interaction.py`：3334 → **2404 行**
      - **为什么不撞循环 import**：这 18 个函数的自由变量**全部**来自
        state / cache / drawing（AST 递归闭包算法验证），而这三个模块
        **不反向 import interaction**。
      - **怎么保住既有调用零改动**：类里留**同名转发方法**（10 个），
        模块级用 `from .edit_geometry import ...` 绑定同名 ⇒ 类内 15 处调用 +
        tests/ 里 39 处引用**一个字都不用改**。
      - ⚠️ **连带修复（拆分的隐藏代价，下次拆结构前先看这条）**：
        ① `gui_endpoint_tangent_check.py` 的**注入测试** patch 的是
           `it._path_tangent_unit` —— 函数搬家后**打不中**（新模块内部调用走的是
           `edit_geometry` 的名字）⇒ 注入点必须**跟随实现位置**（两处一起换）。
        ② `gui_endpoint_tangent_check.py` / `gui_endpoint_hollow_check.py` 的
           **静态源码判据**读的是 interaction.py，函数搬走后判据落空
           ⇒ 改成读「interaction.py + edit_geometry.py」拼接（**判据意图不变**）。
      - 验证：63 个测试全过（除 1 个 CLI 工具的 rc=2）+ 门禁 1241 断言 / 0 失败
        + **快照逐位比对「值差异 0 处」**（worktree 检出改前代码录基线，改后比对）
        ⇒ 行为完全一致。

**第二层（事件编排）为什么不做**

- `_ev_left_press` / `_ev_mousemove` 等约 620 行读改操作符**自己的实例属性**
  （`self._...`）—— 它们**天生属于操作符**，硬搬出去等于把内聚的东西拆散。
- 更关键：这个操作符的"5 种模式"（拖速度三角 / 端点 / 手柄 / 路径点 / 空白）
  是**鼠标按在哪决定的**，不是用户选的 ⇒ 拆成多个操作符 = 逼用户先声明意图，
  是**交互退化**。
  （G / R / S 那套**早就拆好了**：一个入口 + 多个会话类 `Move/Rotate/ScaleSession`。）

### ✅ 已修复（2026-10-02 · 用户报障：两个边界手感 bug —— 判据用错了「量」）

> 都发生在 v1.6.0 之后，都是「功能看起来正常、手感悄悄变了」类。
> 共同根因：**内部判据用错了量**。详见 `Change Log.md` 第九轮。

**① 短手柄拖拽不保速：保速闸门与抓取环用了两把尺子**

```
抓取环出现：屏幕 6px（`drawing.handle_is_zero_length`）
保速闸门  ：世界长度 ≤ 1.0（`handle_scale_k`）—— 实测 1 世界单位 ≈ 49px
⇒ 闸门关门范围宽约 8 倍 ⇒ 屏幕上 24px 的可见手柄，拖它照样不保速
```

- 修法：`edit_geometry._uniform_plan` 传 `len_min = _handle_zero_local_len(...)`
  （经 `drawing.local_eps_for_screen` 换算屏幕 6px → 局部长度，含 ps/gs）。
- `handle_scale_k(len_min=None)` **缺省仍是旧值** ⇒ 端点模态 / 旧调用点逐位不变。
- `_dir_lock` 方向锁与闸门**同一阈值来源**（口径漂移就是“缝”）。**方向锁逻辑未动**。
- 测试：`tests/gui_short_handle_keepspeed_check.py`（16 项，含 bug 注入）。

**② 三角拉满后再拖手柄 = 改速度：把「时间分量」当成了「长度」**

```
三角拉满（疏） ⇒ s 被压到 S_EPS（命中旧判据 `s == S_EPS`）
               ⇒ 但【值分量】一点没变（实测 d=120/300：仍 0.83）
⇒ 被误判成「手柄缩成零长」 ⇒ supersede=True
⇒ 用户手动设的『不动(FREE)』被静默覆盖成 LINK（联动打开）⇒ 对侧跟着动
```

- 修法：判据换成 `time_domain.value_len_is_visual_zero(...)` ——
  与空心环**同源**的「值分量视觉为零」。`e0c98fb` 的原意（真零长时才取代）**完整保留**。
- 测试：`tests/gui_tri_sparse_keepspeed_check.py`（15 项）。
  **撤销修复后 A3/A5 必红**（已实测）⇒ 有区分度。

**验证**：全量 78 脚本；非零 2 个均为**预先存在**（`_snapshot_diff.py` CLI 工具 rc=2；
`gui_endpoint_fix_check.py` rc=1 —— 第八轮删 `position` 字段后该 09-16 老测试没跟上，
`git stash` 对照确认与本次无关）。门禁 **1849 断言 / 1 失败** / 0 STALE。

**⚠️ 本轮未做**：
- 真机手感未验（headless 无 3D 视口 ⇒ 屏幕口径走退化分支）。需在 Blender 里实拖确认。

### ⬜ 待办

- [ ] `_ev_left_press`（286 行）还能再拆：三角命中 / 手柄命中 / 关键帧命中 /
      采样点 / 空白，五段逻辑各自独立（有快照兜底，可以放心拆）
- [ ] 39 个状态字段按**生命周期**分装（会话态 / 拖拽瞬时态 / 资源句柄）
- [ ] 四张登记表（`_plugin_owned_free` / `_FEEL` / `_TRILOCK` / `_FROZEN`）抽基类
      —— **先写"差异表"再抽**（它们有 4 处实质差异，硬抽会把差异藏起来）
- [ ] **快照的覆盖缺口**：状态栏文案（`sess.message` / `status_text()`）不在 dump 里
      ⇒ 文案类改动测不到（本次靠"值差异 0"间接确认它不影响状态）
- [ ] `render_path_overlay`（176 行）/ `apply_handle_point_offset`（165 行）拆分
- [ ] 6 处 `wm.rtmp_*` 裸访问补 `getattr` 守卫（cache / drawing / 刷新路径上）
- [ ] 关键路径的 `except: pass`（全仓 90 处）补 `debug_log` 记录
- [ ] `tests/gui_endpoint_fix_check.py` 失败（rc=1）：第八轮把抓取环搬 2D 层后，
      空心态条目不再登记 `position`，而该 09-16 老测试还在读它 ⇒ KeyError。
      修法已明：改用项目的 `handle_world_pos`。**预先存在**，不属第九轮范围。
- [ ] 三角拉满时时间分量到 1e-5 量级，“速度”数值可达数百（实测 679），
      float32 精度约 0.003% —— 量太小会丢精度（不影响已修的两处）。
- [ ] **手柄视觉放大系数（`rtmp_handle_scale`）两条路口径不一致** ——
      ★ 2026-09-29 用户拍板「**先记着，不动**」。
      鼠标拖手柄会**除以**它（`edit_geometry.py:521`），按 G 移端点**不除**
      （`modal_edit.py:1211`）⇒ 该系数 ≠ 1 时，"按 G 拖端点"在屏幕上跑得
      比鼠标快/慢 gs 倍（不跟手）。**不影响数据正确性，也不影响保速。**
      现在碰不到：它**没有任何 UI 入口**、默认恒为 1.0（只能从控制台改）。
      ⚠️ **触发条件**：哪天加"手柄整体放大"滑块时必须一起做 ——
      否则滑块一上线就立刻暴露（用户会报"按 G 手柄跑得比鼠标快"）。
      详情（含修法候选与验证清单）见 `.docs/待决项_手柄联动.md` ④。
- [x] 文档：`README.md` 补 9 月新增功能（`使用说明书.md` 已补）→ **2026-09-29 已补齐**（新增「速度三角（曲线疏密编辑）」一节 + 主要功能补一条）
- [x] `README_DEV.md` 本文件的"模块结构"一节还缺 7 个模块 → **2026-09-29 已补齐**

---

## 项目概述

RealTimeMotionPath 是一个 Blender 动画插件，用于在 3D 视口中实时显示和编辑物体/骨骼的运动路径。该插件支持直接在 3D 视图中拖拽关键帧、调整贝塞尔手柄，并与图形编辑器保持同步.

**兼容版本**: Blender 5.0+
**当前版本**: 1.3.9（⚠️ 2026-09-27 更正：本节此前写 1.1.0，已落后 8 个版本）
**作者**: HAOAH

---

## 项目结构

```
RealTimeMotionPath/
├── __init__.py              # 插件入口，注册类和属性
├── state.py                 # 全局状态管理（登记表 / 会话状态）
├── cache.py                 # 位置缓存和 F-Curve 读取
├── handles.py               # 速度手柄几何（关键帧上下的三角）
├── time_domain.py           # 时间域编辑（速度手柄 / 采样点疏密）
├── transform_domain.py      # 变换数据层（手柄类型接管 / 联动 / 端点变换）
├── spec_check.py            # ★ 手柄显示规范：检测 + 微调（纯数据层，无 UI）
├── spec_ui.py               # ★ 规范检查的界面层（弹窗 / 还原 / 不再提示）
├── drawing.py               # GPU 绘制逻辑
├── overlay.py               # 视口覆盖层（模态 / 手柄的视觉反馈）
├── interaction.py           # 用户交互处理（点击、拖拽等）
├── modal_edit.py            # 模态交互骨架（Modal/Move/Rotate/Scale 会话）
├── undo_guard.py            # 撤销 / 重做后让内存缓存失效
├── debug_log.py             # 调试日志（正式机制，交互类问题的定案手段）
├── ui.py                    # UI 界面（首选项、Header 菜单、规范检查入口）
├── translations.py          # 国际化翻译
├── Change Log.md            # 开发历史记录
├── README.md                # 用户文档
└── README_DEV.md            # 本文档
```

---

## 核心模块详解

### 1. `__init__.py` - 插件入口

**职责**:
- 定义 `bl_info` 元数据
- 注册/注销所有 Operator 和 Panel 类
- 定义 WindowManager 级别的属性
- 注册国际化翻译

**关键属性** (`bpy.types.WindowManager`):
- `rtmp_path_display_enabled` - 运动路径显示开关
- `rtmp_edit_mode_active` - 直接编辑模式开关
- `rtmp_auto_refresh_active` - 自动更新模式开关
- `rtmp_handle_type` - 默认手柄类型
- `rtmp_snap` - 手柄吸附开关
- `rtmp_handle_scale` - 手柄视觉缩放

- `rtmp_snap_step` - 吸附步长

**性能设置** (`RTMP_AddonPreferences`，存 userpref ⇒ 全局持久):
- `refresh_strategy` - 更新模式 ('SMART' | 'TIMER')
- `max_interaction_fps` - 交互帧率限制
- `poll_frequency` - 计时器模式更新频率

> ⚠️ 2026-09-17 迁移：这 3 项原为 `WindowManager` 属性
> （`rtmp_refresh_strategy` / `rtmp_max_interaction_fps` / `rtmp_poll_frequency`）。
> **WindowManager 上的属性不写入文件**（实测：设完保存、重开即回默认；
> RNA `is_runtime` 为 True）⇒ 用户"改完重启就丢"。
> 既然摆进"偏好设置"就要真持久化，故迁到 `AddonPreferences`。
> 读取统一走 `state.addon_pref(name, default)`（异常安全）。
> UI 位置：性能在**偏好设置**面板；**手柄拖拽模式**在 3D 视图 HEADER popover（与前者对调）。

**注册流程**:
1. 注册翻译
2. 注册所有类
3. 向 WindowManager 添加自定义属性
4. 向 VIEW3D_HT_header 添加绘制按钮

---

### 2. `state.py` - 全局状态管理

**核心类**: `MotionPathSession`

**状态字段**:
```python
class MotionPathSession:
    drag_in_progress                    # 是否正在拖拽关键帧
    mouse_origin                    # 拖拽起始鼠标位置
    world_origin                     # 拖拽起始 3D 位置
    item_initial_pos                 # 拖拽项目初始位置
    active_path_point                 # 选中的路径点
    active_frame_number               # 选中的帧号
    active_handle_direction            # 选中的手柄侧 ('left' | 'right')
    active_bone_identifier             # 选中的骨骼名称（字符串，避免 RNA 悬空引用)
    handle_control_points             # 手柄点列表 [{position, side, frame, obj_name, bone_name}, ...]
    active_handle_index                # 选中的手柄点索引
    active_handle_info                 # 选中的手柄数据
    handle_edit_in_progress             # 是否正在拖拽手柄
    drag_target_object                 # 正在拖拽的对象名称（字符串）
    cached_positions                   # 位置缓存 {obj_name: {cache_key: {frame: {'position': Vector}}}}
    handle_start_values                 # 手柄初始值（用于拖拽计算）
    render_callback_id                 # GPU 绘制回调句柄
    path_point_sequence                # 路径顶点 {(obj_name, bone_name_or_None): [Vector, ...]}
```

**重要设计决策**:
- **不保存 RNA 引用**: 所有对象/骨骼引用都使用名称字符串，避免悬空引用导致崩溃
- **原子锁**: `_cache_update_lock` 防止 `refresh_position_store` 递归调用

**常量**:
- `HANDLE_SELECT_RADIUS = 20` - 手柄点击检测半径（像素）；**也是关键帧/路径采样点的命中半径**
  （`locate_point_under_cursor`）。⇒ 它跟空心圆盘的大小关系决定了会不会「点关键帧被抢」。
- `HANDLE_HOLLOW_PICK_RADIUS = 12` - **空心圆抓取点的独立拾取半径**（< 20）。
  ⚠️ 必须比 20 小：空心圆盘与关键帧盘的圆心距 = `drawing.ENDPOINT_PICK_OFFSET_PX(32)`，
  两盘半径之和若 ≥ 32 就必然重叠 ⇒ 用户点关键帧盘内仍会被抢。
  实测（2026-09-17）：偏移 28px + 双 20px 盘 ⇒ 重叠区 `[8, 20]px`，关键帧安全区只剩中心 ±8px。
- `SAFE_LIMIT = 1000000.0` - 坐标安全限制，防止 GPU 崩溃
- `MIN_HANDLE_SCALE = 0.1` - 手柄最小缩放系数
- `MAX_HANDLE_SCALE = 100.0` - 手柄最大缩放系数
- `HANDLE_ZERO_SCREEN_PX = 6.0` - ★ **判定「手柄长度为 0」的阈值（屏幕像素）**。
  ⚠️ **口径是屏幕像素，不是世界长度** —— 实测（2026-09-17）：1 世界单位 ≈ 49px，
  `HANDLE_ZERO_EPS(1e-4)` 世界单位只有 **0.005px**，用户用手拖出来的"很短"
  （屏幕上还有 1~20px）**永远够不到** ⇒ 出现「短但不为零」的死区：
  既不画空心圆、抓取点又落回关键帧上（误触回归）。
  用户实测反馈："中间帧手柄缩小至关键帧点处后，空心圆有时会不出现"。
  取值 6px = 关键帧点半径 5px（`keyframe_point_size` 默认 10）+ 1px 余量。
- **唯一判据** = `drawing.handle_is_zero_length(context, point_3d, world_vec, global_scale)`
  （屏幕像素口径，随 `rtmp_handle_scale` 自适应）。两处共用、方向相反、严格互补：
  - `drawing.render_keyframe_control_handles`：`handle_is_zero_length(...)` ⇒ 画「空心圆抓取点」
  - `interaction.locate_handle_under_cursor`：`not handle_is_zero_length(...)` ⇒ 才做几何命中
  （**不要**再写第二份判据 —— 两边漂移会出现"两边都不认"的缝 ⇒ 抓取点落回关键帧 ⇒ 误触）
  ⚠️ **判据不限首末帧**（2026-09-17）：停顿/保持段的中间帧同样适用。
- `HANDLE_ZERO_EPS = 1e-4` - 世界长度阈值，现仅作 `handle_is_zero_length()` /
  `world_eps_for_screen()` 的**降级路径**（拿不到视图上下文时兜底），不再是主判据。
- `drawing.world_eps_for_screen(context, point_3d, px=None)` - 把**屏幕像素**阈值
  换算成该位置的**世界**长度阈值。★ 专供**纯数学层**使用：
  `transform_domain` 的封口闸门（`_ARM_EPS`）拿不到视图上下文，
  由 `interaction` 先换算好、经 `zero_eps` 形参传进去。
  ⚠️ 只有这样才能保证「手柄长度是否为零」在全插件是**同一个语义**——
  2026-09-17 的 bug 正是两处口径差 6 个数量级（屏幕 6px vs 世界 1e-9）：
  用户把两侧缩到关键帧点（长度 ~1e-3 世界 = 0.05px）时，空心圆出现、
  一拖却触发封口 ⇒ 对侧 ALIGNED 被改成 FREE。
- `transform_domain.finish_linked_handle(..., zero_eps=_ARM_EPS)` /
  `maintain_linked_handle(..., zero_eps=_ARM_EPS)` - 封口闸门，`zero_eps` 默认值
  保持向后兼容（不传 = 旧行为）；鼠标路径由 `interaction` 传换算后的「视觉零」值。

**「插件接管的手柄 FREE」登记表**（`transform_domain._plugin_owned_free`）

作用：区分「**插件**转的 FREE」（继续联动）与「**用户手动**设的 FREE」（按原生语义不动）
—— 见 `_link_mode`。**任何把类型改成 FREE 的地方都必须登记**，否则那根手柄会被当成
"用户手动 FREE"，用户看到的体感就是「拖一侧、对侧不联动」。

| 项 | 说明 |
|---|---|
| 键 | `(action **名**, 帧号, 侧)` —— **不用** `as_pointer()`（内存地址：重载失效、可能被复用误伤） |
| 存储 | 内存 set + **action 的 custom property** `act["rtmp_owned_free"]`（如 `["14.0000\|left"]`） |
| `mark_owned_free(kp, side)` | 登记 + 持久化。调用点：`_seal_opposite_handle`（封口）、`make_handles_editable`（关键帧模态转 FREE） |
| `unmark_owned_free(kp, side)` | 取消登记。调用点：`restore_handle_types` / `restore_converted_types`（类型被恢复时） |
| `warm_owned_free(act)` | 从 custom property **惰性**恢复（`_is_plugin_owned_free` 首次访问时调一次） |
| `clear_owned_free(act=None)` | 清登记（供"重置"类功能） |

⇒ **重启 Blender 后「体感类型」不丢**（登记随工程走）。
已知边界：用户手动把类型改回 AUTO/ALIGNED 后，类型判据天然挡住；但陈旧条目不会
自动清除（需要时调 `clear_owned_free`）。

**「被速度编辑冻结过」登记表**（`time_domain._FROZEN`，2026-09-17 持久化）

作用：与上面那张表**同类** —— 记「插件的意图」。速度编辑会把关键帧两侧手柄转成 FREE，
若不登记，`_link_mode` 会判成"用户手动 FREE" ⇒ 拖一侧、对侧不联动。

| 项 | 说明 |
|---|---|
| 键 | `(action **名**, 帧号)` —— 唯一来源是 `_frozen_key(action, frame)`（**三处共用**，不得各写一份） |
| 存储 | 内存 dict + **action 的 custom property** `act["rtmp_frozen"]`（如 `["14"]`） |
| `mark_frozen(action, frame)` | 登记 + 持久化。调用点：`freeze_keyframe_pair`、`write_s` |
| `unmark_frozen(action, frame)` | 取消登记（内存 + property 同步移除） |
| `warm_frozen(act)` | 从 custom property **惰性**恢复（`is_frozen` 首次访问时调一次，带 `_frozen_warmed` 防重读） |
| `clear_frozen(action=None)` | 清登记（`action=None` 全清；带 action 时连 property 一起删） |
| `is_frozen(action, frame)` | ★ 读侧**唯一入口**（`transform_domain._is_plugin_frozen` 与 `interaction` 都走它） |

⇒ **重启 Blender 后速度编辑的联动不丢**。

**★★★「体感手柄类型」**（`transform_domain._feel`，2026-09-17 方案 A）—— **这是权威数据**

口径（用户定）：**体感手柄类型** = 3D 视口里插件生成的手柄的类型；
**原始手柄类型** = Blender 原生字段（`handle_left_type` / `handle_right_type`）。

| 项 | 说明 |
|---|---|
| 语义 | `'LINK'`=联动 / `'VECTOR'`=贴控制点 / `'FREE'`=不动 / **`None`=未记录 ⇒ 透传原始类型** |
| 键 | `(action **名**, 帧号, 侧)` —— 唯一来源 `_feel_key_of(action, frame, side)` |
| 存储 | 内存 dict + **action 的 custom property** `act["rtmp_feel"]`（如 `["14.0000|left|LINK"]`） |
| `mark_feel(kp, side, v)` / `mark_feel_at(action, frame, side, v)` | 记录（后者供只有 action+帧号的调用方用） |
| `feel_type(kp, side)` | ★ **唯一的**体感查询入口（返回 `None` 表示透传） |
| `effective_feel(kp, side)` | 体感 + 透传（未记录时返回原始类型） |
| `warm_feel(act)` | 惰性恢复（`feel_type` 首次访问时调一次） |
| `clear_feel(action=None)` | 清记录；带 action 时连 property 一起删 |

**「体感绝对权威」（方案 A）**：

```
联动决策 → 只看体感（_link_mode 先查 feel_type）
原始类型 → 降级成【实现细节】：
            体感 LINK   ⇒ 写 'ALIGNED'（原生"保持一条直线"语义）
             体感 FREE/VECTOR ⇒ 写 'FREE'（★ 必须：ALIGNED 会被 Blender 重算偷改）
用户在 Graph Editor 改原始类型 ⇒ **体感不跟着变**（唯一的行为差异）
```

⚠️ **所有"插件改手柄类型"的地方都必须记体感**（封口 / 关键帧模态转 FREE /
速度编辑冻结），漏了就会被判成"用户手动 FREE" ⇒ 拖一侧、对侧不联动。
实测：漏登记路径 3D 共线偏差 **0.6899**；补上后 **1.19e-07**。

⚠️ 右键菜单（`RTMP_MT_context_menu`）顶部显示**当前体感类型**并高亮对应项——
因为 GE 面板显示的是**原始类型**，方案 A 下两者可能不一致。

⚠️ 为什么键必须是**唯一来源**：实测 bug 注入发现，`mark`/`unmark`/`is_frozen` 三处
各写一份键计算时，只把其中一处改成 `as_pointer()` **行为测试抓不到**（跨会话才暴露）。
收敛到 `_frozen_key` 后，同样的注入被 6 条断言抓住。

⚠️ 静态契约只扫 **return 语句**，不扫整段源码 —— docstring 里会写 `as_pointer` 作反例，
扫全段会误判失败（本轮与上一轮各栽过一次）。

- `interaction.get_handle_at_cursor`：对 `hollow` 点用 `HANDLE_HOLLOW_PICK_RADIUS`、
  对其余点用 `HANDLE_SELECT_RADIUS`。

---

### 3. `cache.py` - 缓存和 F-Curve 处理

**核心函数**:

#### `collect_animation_curves(action)`
从 Action 中提取 F-Curve 列表（兼容 Blender 5.0+ 的新动画系统）。

#### `compute_motion_positions(obj, action, frames, bone_name=None)`
从 F-Curve 计算指定帧的位置数据。
- **坐标系**: 独立于父级的本地空间（无父级 = 世界空间）
- **返回**: `{frame: {'position': Vector}}`

#### `refresh_position_store(context)`
构建位置缓存和路径顶点数据。
- **原子锁保护**: 使用 `_cache_update_lock` 防止递归
- **物体模式**: 遍历 `context.selected_objects`
- **姿态模式**: 遍历选中骨骼 + 活动骨骼
- **双缓存**:
  - `cached_positions`: 稀疏关键帧数据（用于交互）
  - `path_point_sequence`: 稠密路径线数据（用于绘制）

#### `resolve_parent_transform(obj, bone=None)`
计算父级变换矩阵。
- **物体模式**:
  - 无父级 → `Identity`
  - 有父级 → `parent.matrix_world @ obj.matrix_parent_inverse`
- **姿态模式**:
  - 根骨骼 → `obj.matrix_world @ bone.bone.matrix_local`
  - 子骨骼 → `obj.matrix_world @ bone.parent.matrix @ parent.bone.matrix_local.inverted() @ bone.bone.matrix_local`

---

### 4. `drawing.py` - GPU 绘制

**绘制流程**:
1. `attach_render_callback()` → 注册 `render_path_overlay` 回调
2. `render_path_overlay()` → 主绘制函数
3. 使用 `GPUBatch` 批量绘制，提升性能

**核心绘制元素**:
- 路径线（POLYLINE）
- 帧点（自定义抗锯齿着色器）
- 关键帧点（自定义抗锯齿着色器）
- 手柄线和端点
- 原点指示器

**自定义着色器**: `_get_circle_aa_shader()`
- 使用 quad + 片段着色器实现抗锯齿圆点
- `smoothstep()` 实现软边缘 alpha 混合
- 模块级缓存，避免重复创建

**手柄时间归一化**: `compute_handle_display_factors()`
- 解决 F-Curve 手柄时间长度不一致导致的 3D 视觉折角问题
- 计算缩放系数 `Factor = S / dt`（S 为平均持续时间）
- 绘制时正向缩放，交互时反向修正

---

### 5. `interaction.py` - 用户交互

**核心 Operator**:

#### `RTMP_OT_PathPointDrag`
Modal Operator，处理鼠标点击和拖拽。

**事件处理**:
- `LEFTMOUSE`: 命中检测 → 选中 → 拖拽
- `RIGHTMOUSE`: 右键菜单（设置手柄类型）
- `MOUSEMOVE`: 拖拽更新
- `ESC`/`RIGHTMOUSE` (未命中): 取消

**命中检测函数**:
- `locate_point_under_cursor()` - 检测关键帧点
- `locate_handle_under_cursor()` - 检测手柄线
- `get_handle_at_cursor()` - 检测手柄端点

**拖拽更新函数**:
- `apply_point_offset()` - 移动选中的关键帧
- `apply_handle_offset()` - 移动选中的手柄
- `apply_handle_point_offset()` - 移动单个手柄端点

#### `RTMP_OT_PathRefreshDaemon`
Modal Operator，负责自动更新缓存。

**检测内容**:
- 活动对象切换
- 选中对象集合变化
- 骨骼选择变化
- 关键帧值变化（计时器模式）

**智能更新 Handler**: `on_depsgraph_update()`
- 监听 `depsgraph_update_post`
- 区分「交互更新」（仅 OBJECT 更新）和「数据更新」（ACTION 更新）
- 交互时复用上一帧缓存，避免卡顿

---

### 6. `ui.py` - 用户界面

**类**:
- `RTMP_AddonPreferences` - 插件首选项面板
- `RTMP_PT_header_settings` - Header 设置弹出面板（含「立即检查」入口）
- `RTMP_MT_context_menu` - 右键上下文菜单
- `RTMP_OT_ToggleCustomDraw` - 开关 Operator
- `RTMP_OT_ResetPreferences` - 重置设置 Operator
- `RTMP_OT_SpecInspect` - 规范检查（**纯读**，有问题则开微调弹窗）

> 规范微调弹窗（`rtmp.spec_fix` / `rtmp.spec_revert` / `rtmp.spec_ignore`）
> 在独立模块 `spec_ui.py`，见下一节。

---

### 6b. `spec_check.py` / `spec_ui.py` - 运动路径校正

**分层（重要）**

`@
spec_check.py   纯数据：detect() 检测 + fix_*() 微调 + apply_fix() / revert_fix()
      ↓ 只调用既有 API，不自己实现第二份判据
transform_domain（手柄数学 / 联动判据 / 快照）
cache           （曲线收集）
drawing         （外侧手柄判据）
      ↓
spec_ui.py      界面：弹窗 / 还原 / 不再提示
ui.py           只留一个「检查手柄」按钮入口
`@

**检测结果分三桶**

| 桶 | 内容 | 是否弹窗 | 是否可修 |
|---|---|---|---|
| `issues` | `dt_mismatch`（手柄不贴它那侧路径）、`handle_bend`（3D 手柄折了）、`missing_axis`（缺关键帧） | ✅ | ✅ **默认全做** |
| （无桶） | `force_align`（强制对齐关键帧进出速度） | ❌ 不是"检测到的问题"，是**用户主动要的动作** | ⬜ **可选**（弹窗唯一勾选项，默认 False） |
| `hints` | （目前**恒空**，预留给将来的纯信息项） | ✅ 有 hints 也开弹窗 | — |
| （无桶） | 手柄类型 / 对齐锁定 | ❌ | ✅ **自动前置**（转 FREE 保坐标） |

⚠️ `invoke` 必须在「有 issues **或** hints」时都开弹窗 ——
   否则"只有折角"的工程（issues = 0）**够不到** `align_handles` 这个可选项
   （2026-09-30 用户实测抓到的真实问题）。守：E8 / E8b / E8c。

**★★★ 三条设计铁律（2026-09-30 用户拍板，别改回去）**

1. **★★ 有两个完全不同的"折角"，别混**

   | | **GE 折角** | **3D 手柄折了** |
   |---|---|---|
   | 判据 | 每条曲线内，左右手柄在 (时间,值) 平面不共线 | 3D 空间里 dvL 与 dvR 不平行 |
   | 本质 | 速度**大小**突变（该轴） | 速度**方向**突变 |
   | 影响 3D | ❌ **不影响** | ✅ 手柄线段折 + **路径拐角** |
   | 插件管吗 | **不管** | **必须校正** |

   用户工程 帧 90 实测（差得远，证实是两回事）：
       GE 折角 = X 0.16° / Y 3.78° / Z 0.00°
       3D 折了 = 12.42°      路径拐角 = 12.46°

   用户口径（最终）：
       「这个本来就是要保证的，**不是选不选的问题**，本来就是要校正这个，
         **除非路径手柄已经被用户提前设置成自由**」
       「根本不用选，默认就是要」

   ⇒ `handle_bend` 是 **issues**、**默认做**、**无勾选项**；
     唯一例外是 **E2**（体感 = 自由 ⇒ 不报也不修）。
   守：A4 / A5 / A21 / A22 / B12a-i / C7 / C8 / E6 / I10

2. **`force_align` 的目标是「GE 手柄共线」，不是「3D 手柄共线」**
   ★★ 用户 2026-09-30 纠正（我第一版理解错了）：
      「实际勾选后点击确定的话 GE 的关键帧手柄**还是折角的**，是不是搞错了什么，
        强制对齐关键帧进出速度的意思其实就是**强制把所有 GE 的关键帧手柄对齐共线**」
      「**对齐共线的原则是取中间值**」

   ⚠️⚠️ 两个条件**完全不同**，别混：

   | | 判据 | 谁管 |
   |---|---|---|
   | 3D 手柄成直线 | `dvL ∥ dvR`（只比值分量） | `handle_bend`（默认做） |
   | **GE 手柄共线** | 逐轴 `dvLx/dtLx == dvRx/dtRx`（进出**速度**相等） | `force_align`（可选） |

   实测用户工程 帧 90：3D 折了 12.42°，而 GE 折角是 X 13.4° / Y 3.5° / Z 21.9°。

   ★★ 关键洞察：**GE 共线 + 3D 直线 + 相切 可以同时满足，且只有一种写法**：

       令 v* = 共同速度（方向取两侧速度的**角平分**、大小取**平均** ——「取中间值」）
          dvL = -v* × D_L      dvR = +v* × D_R      （D = 统一后的时间跨度）
       ⇒ 逐轴 dvLx/dtLx = -v*x = dvRx/dtRx   ⇒ GE 共线 ✓
       ⇒ dvL ∥ dvR                            ⇒ 3D 手柄成直线 ✓
       ⇒ 同侧三轴 dt 相等                      ⇒ 与路径相切 ✓

   ⚠️ 代价：**手柄长度必变**（比例被 dt 定死：|dvR|/|dvL| = D_R/D_L）。数学必然。

   ⚠️⚠️ **符号坑（实测踩过，速度会被整体翻转、路径在关键帧掉头）**：
      `_target_dirs(a, b)` 算的是 `unit(a) 与 unit(-b)` 的角平分，返回 `(t, -t)`。
      两侧的**速度**都是**向前**的（不是反向）⇒ 必须传 `(speed_r, -speed_l)`：
         ul = unit(speed_r)  = 向前
         ur = unit(-speed_l) = 向后
         m  = 向前 - 向后     = 2×向前  ⇒ t = **向前** ✓
      守：B13k。

   ⚠️ 最小干预：某帧**逐轴 GE 折角都 < ANGLE_EPS_DEG** ⇒ 整帧跳过（不冻结类型）。守：B13e。
   ⚠️ 退化手柄（dv=0）⇒ 跳过。

   | | `fix_handle_bend` | `fix_force_align` |
   |---|---|---|
   | 处理哪些 | 只处理**体感=对齐**的 | **全部**（含体感=自由、含外侧手柄） |
   | 目标 | 3D 手柄成直线 | **GE 手柄共线** |
   | 默认 | ✅ 做 | ⬜ 不勾 |

   守：B13a-l / C7 / C8 / I11

3. **切向必须用「直线夹角 + 解析切向」**
   `_line_angle_deg(dv, dv/dt)` —— 180° 也算 0°。
   ⚠️ 左侧手柄指向关键帧的"过去"，方向天然与前进方向**相反**；
   用**方向**夹角去比，完全合规时也会得到 ~180°（实测 179.9197°，曾是真 bug）。
   ⚠️ 用**解析**切向 `dv/dt` 而不是数值差分 ⇒ 零误差，
   `TANGENT_EPS` 与"阈值联合标定"的复杂度**整体消失**。
   守：A20 / A20b / I9

4. **手柄类型（④）与对齐锁定（⑤）是自动前置，不是问题**
   用户原话：「blender 默认追加关键帧的手柄类型就是 auto clamped，
   所以基本每次都会跳弹窗」—— 成立，因为所有微调本来都会转 FREE。
   ⚠️ 但**保留**：转 FREE 前必须判断原始类型并登记**体感**
   （不登记 ⇒ `_link_mode` 返回 'free' ⇒ 插件联动失效）。
   ⚠️ 只冻结**被碰到**的关键帧（多冻只会丢掉 Blender 的自动平滑）。
   守：A7 / A8 / B3 / E6

**阈值**

| 常量 | 值 | 说明 |
|---|---|---|
| `ANGLE_EPS_DEG` | 1.0° | 解析切向零误差 ⇒ 纯手感选择（≈ dt 差 5%） |
| `MIN_HANDLE_LEN` | = `xf.UNIFORM_LEN_MIN` | 引用，不重定义 |
| `DT_MIN` | 1e-6 | 时间分量太小 ⇒ 跳过该侧 |

**微调的两条硬约束**

1. `_freeze_keyframe` **两侧一起转 FREE** ——
   只转一侧时另一侧仍派生，`fc.update()` 会把它的坐标重算掉（实测被吞）
2. `apply_fix` **每个阶段之间重新 detect** ——
   补轴新建的关键帧默认是 ALIGNED 且 dt 由 Blender 算，
   不在旧报告里 ⇒ 不重检测就会"修完还剩问题"（GUI 真机抓到的）

## 核心数据流

```
用户操作
   ↓
depsgraph_update_post 或 PathRefreshDaemon modal 检测
   ↓
refresh_position_store()
   ├─ 读取 F-Curve
   ├─ compute_motion_positions()
   └─ 填充 cached_positions 和 path_point_sequence
   ↓
render_path_overlay() 回调
   ├─ 从 cache 读取数据
   ├─ 乘以 resolve_parent_transform()
   └─ GPU 绘制
   ↓
用户点击/拖拽
   ↓
命中检测 → 操作 F-Curve → 触发 depsgraph 更新 → 循环
```

---

## 关键设计决策

### 1. 去 RNA 引用化
**问题**: 长期保存 Blender RNA 对象引用会导致悬空引用和崩溃。
**方案**: 所有对象/骨骼引用改为名称字符串，使用时通过 `bpy.data.objects.get(name)` 动态查找。
**位置**: `state.py` 全文件，`interaction.py` 的 `_get_drag_obj()`

### 2. Fast Path 统一
**问题**: Slow Path 使用 `frame_set()` 逐帧切换，性能差且干扰交互。
**方案**: 完全移除 Slow Path，统一从 F-Curve 读取数据。
**位置**: `cache.py` 的 `refresh_position_store()`

### 3. 智能交互避让
**问题**: 用户按 G 键移动物体时，路径计算会干扰交互。
**方案**: 在 `on_depsgraph_update()` 中检测「仅 OBJECT 更新，无 ACTION 更新」，判定为交互中，直接复用缓存。
**位置**: `interaction.py` 的 `on_depsgraph_update()`

### 4. 手柄时间归一化
**问题**: F-Curve 手柄时间长度不一致时，3D 手柄会出现折角。
**方案**: 计算缩放系数 `Factor = S / dt`，绘制时缩放手柄，交互时反向修正。
**位置**: `drawing.py` 的 `compute_handle_display_factors()`

---

## 代码约定

### 异常处理
- 使用 `except Exception:` 而非裸 `except:`，避免吞噬系统异常
- 绘制和缓存热路径添加异常防护，遇到失效数据跳过当前项

### 性能优化
- 绘制热路径使用 `GPUBatch` 批量绘制
- 预先构建 `{frame: {array_index: keyframe}}` 字典，避免 O(n×m) 复杂度
- 模块级缓存着色器和其他昂贵资源

### 国际化
- 所有用户可见字符串使用 `iface_()` 包裹
- 翻译字典键使用 `("*", "Original")` 通用上下文

---

## 扩展开发指南

### 添加新的绘制元素
1. 在 `drawing.py` 中添加绘制函数
2. 在 `render_path_overlay()` 中调用
3. 如需样式配置，在 `ui.py` 的 `RTMP_AddonPreferences` 中添加属性

### 添加新的交互功能
1. 在 `interaction.py` 的 `RTMP_OT_PathPointDrag.modal()` 中添加事件处理
2. 如需状态，在 `state.py` 的 `MotionPathSession` 中添加字段
3. 操作 F-Curve 后会自动触发更新，无需手动调用

### 添加新手柄类型
1. 在 `__init__.py` 的 `handle_mode_items` 中添加选项
2. 在 `interaction.py` 的 `apply_handle_mode()` 中添加处理逻辑
3. 在 `translations.py` 中添加翻译

---

## 调试建议

### 调试日志（`debug_log.py`，推荐）

交互类问题（手感 / 跳变 / 偶发失效）在 headless 里**复现不出来**。
这类问题的正确解法是：**加日志 → 让用户真机操作一次 → 读日志定案**。
（2026-09-17 的「拖三角打满卡死」就是这么定位的：日志显示鼠标坐标是 `-1` 哨兵值。）

```python
from .debug_log import dbg
dbg("drag.begin", frame=25.0, side='left', offset=[1.0, 0.0, 0.0])
```

- ★★ 2026-10-08 起**默认开启**（原来是关闭）。理由：机制的意义就是"出问题时能查"，
  而交互类问题**只在复现那一刻才有日志** —— 默认关闭等于"等你想起要开，现场已经过去了"。
- 关闭：偏好设置 → Debug → Debug Log 取消勾选；或环境变量 `RTMP_DEBUG_LOG=0`
- 优先级：**显式设定（UI / `set_enabled`）> 环境变量 > 默认（开）**
- 日志位置：`<用户配置目录>/rtmp_debug/rtmp-YYYYMMDD.jsonl`（偏好里可一键打开/清空）
- 超过 8MB 自动轮转（`.1` 备份），不影响功能（所有异常都被吞掉）
- 读取：`from .debug_log import read_tail; read_tail(200)`

#### ⚠️ 机制建了不等于接上了

2026-10-08 盘点发现：本机制 docstring 写全了、README 也列为推荐，
但**业务代码一次都没调用过**（17000 行里 `dbg(` 命中 0）——
等于形同虚设，真出问题时还是只能靠猜。

现已接上的日志点（**按调用频率定粒度，避免把日志淹掉**）：

| 事件 | 打在哪 | 频率 | 用途 |
|---|---|---|---|
| `press.enter` | `_ev_left_press` 入口 | 每次点击 | 鼠标位置 / 模式 / 选中集 |
| `press.hit` | 三角命中分支 | 命中时 | 判给了哪个三角（frame/tri/side） |
| `pick.handle` | `get_handle_at_cursor` | 每次按下 | 候选数 / 最近者的 score / 判给谁 |
| `speed.drag.begin` | `_apply_speed_from_drag` 首次调用 | 每次拖拽 | 拖的哪几个三角 / 是否一体态 |
| `speed.drag.end` | `_ev_left_release` | 每次松手 | **wrote / flushed**（拖了到底改没改） |
| `speed.apply.skip` | `_apply_speed_d` 失败路径 | 仅失败 | kf_map 空 / span 无 ⇒ 写入被放弃 |

> 三条粒度原则（新增日志点时照此办理）：
> ① 逐帧调用的（`_apply_speed_from_drag`）→ 只打**会话起止**；
> ② 逐帧 × 逐三角的（`_apply_speed_d`）→ 只打**失败路径**；
> ③ 每次点击/解析调一次的 → 直接打。

#### ⚠️ 测试必须关掉日志（`RTMP_DEBUG_LOG=0`）

日志默认开启后，**每次 headless 测试都会往用户真实的
`<config>/rtmp_debug/` 里写几十~几百条记录**
（`--factory-startup` **不改变** `bpy.utils.user_resource("CONFIG")` 的指向）。

后果：用户真出问题时打开日志准备发给我们，里面**全是测试噪音** ——
这条日志就白记了，与"默认开启"的初衷正好相反。
（2026-10-08 实测：跑了 76 个脚本后，用户的 5.2 日志里堆了 281 条、5.0 里 369 条，
全部来自测试。）

⇒ `tests/_batch_rerun.py` 已给所有子进程设 `RTMP_DEBUG_LOG=0`；
手动跑单个测试时也请照做：

```cmd
set RTMP_DEBUG_LOG=0
blender --background --factory-startup --python tests\xxx.py
```

`_debug_log_probe.py` **不受影响**（它自己显式指定 `dl._path`，验的是机制本身）。

### 启用调试打印
在关键位置添加 `print()` 语句，输出到 Blender 系统控制台。

### 检查缓存状态
```python
from RealTimeMotionPath.state import _session
print(_session.cached_positions.keys())
print(_session.path_point_sequence.keys())
```

### 验证坐标系
在 `render_path_overlay()` 中临时添加调试圆点，验证坐标转换是否正确。

### 常见问题排查
- **崩溃**: 检查是否有 RNA 引用长期保存
- **路径不更新**: 检查 `refresh_position_store()` 是否被调用
- **位置偏移**: 检查 `resolve_parent_transform()` 的计算
- **手柄异常**: 检查 `compute_handle_display_factors()` 的缩放系数

---

## 开发历史

详细的开发记录请参考 `Change Log.md`，包含：
- 功能演进过程
- Bug 修复的根因分析
- 性能优化细节
- 架构决策记录

---

## 联系方式

- 作者: HAOAH
- 问题反馈: 请通过 Blender 插件页面或 GitHub Issues 反馈
