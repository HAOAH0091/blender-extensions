import bpy
import mathutils
import math
import time
from bpy.app.handlers import persistent
from bpy_extras import view3d_utils
from bpy.app.translations import pgettext_iface as iface_
from .state import (_session, HANDLE_SELECT_RADIUS, HANDLE_HOLLOW_PICK_RADIUS,
               KEYFRAME_PICK_PRIORITY_RADIUS,
                     SAFE_LIMIT, HANDLE_ZERO_EPS, get_addon_prefs, addon_pref,
                     purge_stale_app_handlers, FRAME_EPS, warn_once)
from .cache import collect_animation_curves, get_writable_fcurves, is_position_animation, resolve_parent_transform, refresh_position_store, frame_has_keyframe
from .drawing import (compute_handle_display_factors, attach_render_callback,
                      detach_render_callback, handle_is_zero_length,
                      world_eps_for_screen, local_eps_for_screen,
                      _endpoint_is_hidden_side)
from . import handles as hd
from . import time_domain as td
from . import transform_domain as xf

# ★★ 2026-09-29：直接编辑的【纯计算层】已抽到独立模块 edit_geometry.py
#    （命中检测 / 手柄数学 / 联动收尾 / 快照）—— 见该模块 docstring 的成因说明。
#    这里用 from-import 绑定**同名**，让本文件既有的调用点零改动。
from . import edit_geometry as eg
from .edit_geometry import (
    _hit_sampled_point, _get_drag_obj, _is_endpoint_inner_handle,
    _path_tangent_unit, _uniform_mode, _uniform_plan, _write_uniform,
)

try:
    from . import modal_edit as _modal
except Exception:
    _modal = None

try:
    from . import overlay as _ov
except Exception as _e:
    print("RealTimeMotionPath: overlay 模块导入失败 -> %r" % (_e,))
    _ov = None


# 悬停：鼠标离关键帧多近才显示速度三角
SPEED_HOVER_RADIUS = 90.0
# 命中三角的半径
SPEED_TRI_PICK_RADIUS = 22.0

# ⚠️ 帧号匹配容差。
#
# 曾经到处用 `< 0.5`（"同帧"的直觉判断），但关键帧**可以只相隔 0.4 帧**
# （agent 实测：`keyframe_insert(frame=14.4)` 能建出独立关键帧）。
# 此时 `abs(14.4 - 14.0) = 0.4 < 0.5` → **误选/误改相邻的关键帧**
# → 用户看到"只选了一个点却动了两个"或"完全没反应"（实测复现）。
#
# 帧号匹配容差：**全仓唯一定义在 `state.FRAME_EPS`**（2026-09-29 收敛）。
# 上面那段"为什么不是 0.5"的实测结论也一并记在那里。
# （本模块从 `.state` 导入；不要再在别处新增第二份定义。）



# ---------------------------------------------------------------------------
# 速度手柄：悬停 / 命中 / 拖拽（供给 path_point_drag 使用）
# ---------------------------------------------------------------------------



def _position_keyframe_frames(action, obj, bone_name=None):
    """位移动画上所有关键帧的帧号（升序）。"""
    out = set()
    try:
        for fc in collect_animation_curves(action, obj):
            if is_position_animation(fc, bone_name):
                for kp in fc.keyframe_points:
                    out.add(float(kp.co[0]))
    except Exception:
        warn_once("interaction._position_keyframe_frames")
        pass
    return sorted(out)


def _nearest_keyframe_frame(action, obj, frame, bone_name=None):
    """离 frame 最近的关键帧帧号。

    ⚠️ 为什么需要它（用户 2026-09-15 实测反馈"R/S 没反应"）：
       插件画出来的路径点是【每帧一个采样点】（40 个），
       而"移动/旋转/缩放"实际作用的对象是【关键帧】（可能只有 4 个）。
       原来的代码是 `if abs(kp.co[0] - hit_frame) < FRAME_EPS` ——
       点中非关键帧的采样点 → 什么都不选中 → 按 R/S 自然"没反应"。
       实测：点 f7/f20 → 选中集合为空；点 f1/f14/f27 → 才选中。
       改成吸附到最近关键帧后，点哪里都能选中。
    """
    frames = _position_keyframe_frames(action, obj, bone_name)
    if not frames:
        return None
    return min(frames, key=lambda f: abs(f - float(frame)))


def _bone_name_of(context, obj=None):
    """★【唯一的】"速度三角这条路径该编辑哪根骨骼" —— 与鼠标拖拽路径同口径。

    ★ 2026-09-29 修复（用户报障：**姿态模式下速度三角一个都不出现**）：
      速度三角这条子路径此前**整条链都没传 `bone_name`** ⇒
      `td._collect_position_curves(act, obj, None)` 里
      `cache.is_position_animation(fc, None)` 只认 `data_path == 'location'`，
      而骨骼曲线是 `pose.bones["X"].location` ⇒ **全被排除** ⇒ 收集到 0 个三角。

      注意：**不是**骨骼支持没做 —— `interaction.py` 里鼠标拖拽/键盘模态那 5 处
      本来就正确传了 `_session.active_bone_identifier`；`modal_edit._pose_bone_name`
      也早就是权威口径（其 docstring 明确写"口径与鼠标路径统一"）。
      **漏的只是速度三角这条链**。

    非姿态模式 / 模块未就绪 ⇒ None（= 对象级，既有行为不变）。
    """
    if _modal is None:
        return None
    try:
        return _modal._pose_bone_name(context)
    except Exception:
        warn_once("interaction._bone_name_of")
        return None


def _all_speed_handles(context, obj, region, rv3d):
    """当前视图下所有可编辑的速度手柄（对象级 or 当前骨骼级）。"""
    if _modal is None or obj is None or not obj.animation_data or not obj.animation_data.action:
        return []
    bone_name = _bone_name_of(context, obj)
    try:
        return _modal.collect_speed_handles(obj.animation_data.action, obj, region, rv3d,
                                            bone_name)
    except Exception:
        # ★ 宽 except 必须留痕：静默返回 [] 会让"看不见三角"完全无从排查
        #   （本 bug 之所以拖到现在，正是因为这里吞掉了全部信息）
        warn_once("interaction._all_speed_handles")
        return []


def _update_speed_hover(context, obj, region, rv3d, mouse_pos):
    """刷新悬停状态 + 覆盖层显示内容。"""
    handles = _all_speed_handles(context, obj, region, rv3d)

    # 悬停：找最近的关键帧（任一三角所属）
    hover_frame = None
    if handles:
        kf_screens = {}
        for h in handles:
            kf_screens.setdefault(h['frame'], h['kf_screen'])
        hover_frame = hd.keyframe_hit(kf_screens, mouse_pos, SPEED_HOVER_RADIUS)

    _session.hover_frame = hover_frame

    # ★ 用户 2026-09-16：**精确**到哪一个三角。
    #   与"点击选中三角"共用**同一个** `_triangle_under_cursor`（含关键帧保护）
    #   ⇒ 「看到的 = 能抓的」，两处口径不会漂移。
    #   用途：光标停在三角上时按 Backspace = 恢复该三角的默认速度（匀速 1.00x）。
    #   ⚠️ 必须在这里（MOUSEMOVE 通路）刷新 —— 否则鼠标移开后本字段会残留旧值，
    #      按 Backspace 会误重置"上一次悬停过的三角"。
    _hit_tri = _triangle_under_cursor(handles, mouse_pos)
    _session.hover_speed_tri = ((_hit_tri['frame'], _hit_tri['tri'])
                                if _hit_tri is not None else None)

    # 要画哪些：悬停关键帧的所有三角 + **所有已选中的三角**（多选时都常显）
    sel_set = list(getattr(_session, "selected_speed_handles", None) or [])
    visible = []
    for h in handles:
        keep = (hover_frame is not None and h['frame'] == hover_frame)
        if _session.is_speed_handle_selected(h['frame'], h['tri']):
            keep = True
        if keep:
            visible.append(h)
    _session.hover_handles = visible

    if sel_set:
        # ★ 多选时**每个选中三角各自的路径段都高亮**（用户 2026-09-16）
        #   长度 = 该段离匀速的极端程度；颜色 = 方向（变疏橙 / 变密蓝）
        groups = []
        for (f_, t_) in sel_set:
            side_ = hd.SIDE_BY_TRI.get(t_)
            if side_ is None:
                continue
            rec_ = None
            for h in handles:
                if h['frame'] == f_ and h['tri'] == t_:
                    rec_ = h
                    break
            tval = rec_.get('extremeness', 0.0) if rec_ else 0.0
            dense = bool(rec_ and rec_.get('s') is not None and rec_['s'] > td.S_LIN)
            groups.append((f_, side_, tval, dense))
        _ov and _ov.set_segment_highlights(groups)
        _ov and _ov.get_overlay().set_handles(
            visible, list(sel_set), dragging=_session.speed_drag_active,
            split_frames=make_split_frames(obj, handles))
    else:
        _ov and _ov.clear_segment_highlight()
        _ov and _ov.get_overlay().set_handles(
            visible, [], dragging=_session.speed_drag_active,
            split_frames=make_split_frames(obj, handles))
    return handles


def _apply_speed_d(context, obj, frame, side, d, bone_name=None):
    """把 d（屏幕像素当量）写下去。d 越大 = 该侧越疏。**无硬限制**。

    ★ 2026-09-29：补 `bone_name` —— 姿态模式下速度三角整条链此前都没传
      （见 `_bone_name_of` 的说明）。缺省时按唯一口径现取。
    """
    if obj is None:
        return None
    act = obj.animation_data.action if obj.animation_data else None
    if act is None:
        return None
    if bone_name is None:
        bone_name = _bone_name_of(context, obj)
    kf_map, span = td.resolve_target(act, obj, frame, side, bone_name)
    if not kf_map or span is None:
        return None
    # d 不再钳到 >= 0：允许"拖过关键帧继续变密"（用户要求去掉极值限制）
    s = td.d_to_s(float(d))
    # 传 act/obj：write_s 需要它们来冻结【邻居关键帧】（否则对侧路径会变形）
    written = td.write_s(kf_map, side, s, span, act=act, obj=obj, bone_name=bone_name)
    for ax in kf_map:
        fc = td.fcurve_of(act, obj, ax, bone_name)
        if fc:
            fc.update()
    try:
        refresh_position_store(context)
    except Exception:
        warn_once("interaction._apply_speed_d")
        pass
    return written


def _reset_speed_handle_default(context, obj, frame, tri):
    """把一个速度三角恢复成【默认值】= 匀速 1.00x（s = td.S_LIN）。

    ★ 用户 2026-09-16：光标悬停在三角上时按 Backspace 触发。

    为什么"默认值"没有歧义（实测 `_s_default.py`，Blender 5.x）：
      `read_s()` = `|co[0] − handle[0]| / span`，而 Blender 默认手柄
      （AUTO_CLAMPED / FREE / VECTOR，**无论关键帧是否等距**）解析出来的
      这个比值**恒等于 1/3 = `td.S_LIN`**。
      ⇒ "恢复默认"与"恢复到未编辑过的状态"是同一个值，不存在二义性。

    返回 True 表示确实写入了。
    """
    side = hd.SIDE_BY_TRI.get(tri)
    if side is None:
        return False
    written = _apply_speed_d(context, obj, float(frame), side,
                             td.s_to_d(td.S_LIN))
    return written is not None


def try_reset_hovered_speed(context, event):
    """光标悬停在某个速度三角上时，按 Backspace 的处理（用户 2026-09-16）。

    返回 True = 已消费该按键（调用方应返回 RUNNING_MODAL）；
    返回 False = 不处理（调用方应 PASS_THROUGH，不影响原生 Backspace）。

    三条边界：
      ① 只认【精确命中】的三角（`_session.hover_speed_tri`，22px 命中，
         与点击选中共用同一判定 ⇒ 看到的 = 能抓的）。
      ② 拖拽中不响应（那是在连续写值，语义冲突）。
      ③ G/R/S（含数字输入）模态运行时本函数收不到事件 ——
         `RTMP_OT_KeyboardTransform.modal` 末尾统一 `return {'RUNNING_MODAL'}`。

    ⚠️ 抽成独立函数（而不是内联在 modal 里）是为了**可被 headless 测试直接调用**。
    """
    ht = getattr(_session, "hover_speed_tri", None)
    if ht is None or _session.speed_drag_active:
        return False
    obj = _get_drag_obj(context)
    if not _reset_speed_handle_default(context, obj, ht[0], ht[1]):
        return False
    # ★★ 2026-09-30 修 G-2（Phase 1 极限边界测试抓到，FAIL/中）：
    #    **本处是 6 处 `undo_push` 里唯一没包 try 的**（其余 5 处都有，
    #    注释明写"后台/无撤销上下文时忽略（不影响写入本身）"）。
    #    裸调用在没有撤销上下文时抛异常 ⇒ 异常从 `modal()` 漏出 ⇒
    #    Blender 报 Python 错误并终止该模态 ⇒ **"直接编辑模式"整体失效**。
    #    触发路径：悬停速度三角按 Backspace（恢复默认速度）。
    #    （实测：把 `bpy.ops.ed.undo_push` 换成抛异常的代理 ⇒ 异常落在本行）
    try:
        bpy.ops.ed.undo_push(message=iface_("Adjust Motion Path Speed"))
    except Exception:
        warn_once("interaction.try_reset_hovered_speed.undo")
        pass
    # 重算悬停记录：三角的 s/d 变了，覆盖层的倍数标签与高亮要跟着更新
    try:
        _reg, _sp, _lm, _ar = find_region_under_mouse(context, event)
        if _reg and _sp:
            _update_speed_hover(context, obj, _reg, _sp.region_3d, _lm)
        _a = _ar if _ar else getattr(context, "area", None)
        if _a is not None and _a.type == 'VIEW_3D':
            _a.tag_redraw()
    except Exception:
        warn_once("interaction.try_reset_hovered_speed")
        pass
    return True


# ---------------------------------------------------------------------------
# ★★ 双击三角 ⇒ 复制【同关键帧另一个三角】的速度值（用户 2026-09-17 需求）
#
#   每个关键帧有【两个】速度三角（见 handles.py）：
#       ▼ up   （在关键帧上方）→ 负责【左段】
#       ▲ down （在关键帧下方）→ 负责【右段】
#   需求原文：
#       "当用户双击三角手柄时，可以把当前双击的三角手柄所负责速度分布值
#        改为同关键帧的另外一个三角手柄相同的值"
#   ⇒ 双击 (frame, tri) ⇒ 该三角的值 := 同帧**相反那个**三角的值。
# ---------------------------------------------------------------------------

def _speed_dblclick_window(context):
    """双击判定的时间窗（秒）：取 Blender 偏好 `mouse_double_click_time`（ms）。"""
    try:
        ms = context.preferences.inputs.mouse_double_click_time
        return max(0.05, min(1.0, float(ms) / 1000.0))
    except Exception:
        return 0.35          # 偏好拿不到时的兜底（实测 Blender 默认 350ms）


def clear_speed_click_chain():
    """断掉"双击链"（下一次点击不会算作双击）。"""
    _session.speed_click_info = None


def speed_double_click_hit(frame, tri, mouse_xy, now=None, window=None,
                           radius=None):
    """纯逻辑：本次点击是否构成对**同一个三角**的双击；并维护"上次点击"记录。

    ★ 为什么不用 `event.value == 'DOUBLE_CLICK'`（2026-09-17 决定）：
      那个值由 Blender 事件系统按 keymap 生成，在**常驻 modal** 里能否收到
      **不确定**；而"双击"本身就是【时间 + 位置】两个**可测量**的量
      ⇒ 自己判：行为确定、可复现、且能被 headless 测试直接驱动（喂 now/window）。

    四个参数全可注入（now / window / radius）⇒ 测试不必真等时间过去。

    返回 True = 双击（并且**消费**掉记录 ⇒ 三击不会连触发）。
    """
    if now is None:
        now = time.monotonic()
    if window is None:
        window = _speed_dblclick_window(bpy.context)
    if radius is None:
        radius = SPEED_TRI_PICK_RADIUS
    prev = getattr(_session, "speed_click_info", None)
    hit = False
    if prev is not None:
        try:
            same_tri = (abs(float(prev.get('frame')) - float(frame)) < FRAME_EPS
                        and prev.get('tri') == tri)
            in_time = (float(now) - float(prev.get('t'))) <= float(window)
            dx = float(mouse_xy[0]) - float(prev['pos'][0])
            dy = float(mouse_xy[1]) - float(prev['pos'][1])
            near = (dx * dx + dy * dy) <= float(radius) ** 2
            hit = bool(same_tri and in_time and near)
        except Exception:
            hit = False
    if hit:
        _session.speed_click_info = None       # 消费掉（防三击再触发）
    else:
        _session.speed_click_info = {
            'frame': float(frame), 'tri': tri, 't': float(now),
            'pos': (float(mouse_xy[0]), float(mouse_xy[1]))}
    return hit


def _read_side_s(kf_map, span, side):
    """读某侧当前的 s —— 与 `modal_edit.collect_speed_handles` 用**同一口径**。

    ⚠️ `td.read_s` 收的是**单个关键帧对象**（不是 map）——
       各轴的时间分量由 `write_s` 统一写入、彼此相同，取任一个轴即可。
       （实测踩过：直接传 `kf_map` 会 `AttributeError: 'dict' object has no
         attribute 'handle_right'`。）
    """
    if not kf_map or span is None:
        return None
    try:
        return td.read_s(next(iter(kf_map.values())), span, side)
    except Exception:
        warn_once("interaction._read_side_s")
        return None


def _copy_speed_value(context, obj, frame, tri, bone_name=None):
    """把同关键帧【另一个三角】的速度分布值复制到本三角。

    复制的是**归一化值 `s`**（= 该侧 dt / span），不是像素量 `d` ——
    因为界面显示的倍数 = `S_LIN / s`，只与 `s` 有关
    ⇒ 复制 `s` 能让两边的**显示倍数完全一致**，与两侧 span 是否相等无关。
    （若复制 `d`，两侧 span 不同时倍数会不一样。）

    返回 `(ok, s_copied, reason)`：
      · ok=True  ⇒ 已写入；s_copied = 复制过来的 s
      · ok=False ⇒ reason 供状态栏提示
    """
    side = hd.SIDE_BY_TRI.get(tri)
    other_tri = hd.TRI_DOWN if tri == hd.TRI_UP else hd.TRI_UP
    other_side = hd.SIDE_BY_TRI.get(other_tri)
    if side is None or other_side is None:
        return (False, None, "unknown_tri")
    if obj is None or not obj.animation_data or not obj.animation_data.action:
        return (False, None, "no_action")
    act = obj.animation_data.action
    if bone_name is None:
        bone_name = _bone_name_of(context, obj)
    kf_map_o, span_o = td.resolve_target(act, obj, float(frame), other_side, bone_name)
    if not kf_map_o or span_o is None:
        # ⚠️ 对侧是【端点段】（首帧的左段 / 末帧的右段）⇒ 那个三角**根本不存在**
        #    （`handles.collect_handles` 不生成）⇒ 没有可复制的值。
        return (False, None, "no_opposite")
    s_other = _read_side_s(kf_map_o, span_o, other_side)
    if s_other is None:
        return (False, None, "read_failed")
    written = _apply_speed_d(context, obj, float(frame), side,
                             td.s_to_d(float(s_other)), bone_name)
    if written is None:
        return (False, None, "write_failed")
    return (True, float(s_other), None)


def _align_opposite_speed(context, obj, frame, tri, bone_name=None):
    """★ 双击锁定 ⇒ 把【对侧三角的值】同步成【被双击三角的值】（= "一体"语义）。

    ★★ 2026-09-30 语义重定义（用户拍板）：
        用户口径：「三角控制柄双击锁定的功能目的其实根本只有一点，
                  就是在**路径形状不变**和**对应 GE 各轴端点 dt 值相同**的前提下，
                  让**关键点进出的速度是一致的**」
                「我说的是**速度值相同**，不是速度矢量相同」

      ⇒ 这里的"速度值" = **三角控制柄的值 `s`**（= `dt / 段跨度`），
        **不是**物理速度矢量 `dv/dt`。
        依据是插件自己的定义：
            「一体（默认）：同一关键帧的两个三角**联动** —— 拖动**两边同值**」
        ⇒ "一体" ⟺ 两个三角的 `s` 相同。

    ⚠️ 与 09-18 / 09-29 两版的区别（那两版都在追"GE 手柄共线"）：
      · 09-18 版：按【主用轴】算**一个** dt、三轴共用
                  ⇒ 只有主用轴共线（三轴比例不同时其余轴白写）
      · 09-29 版：**逐轴各算各的 dt** ⇒ 三轴全共线 ✓
                  但**同侧三轴 dt 被写散** ✗（实测 dtL = [-8, -4, -16]）
                  ⇒ 打破"三轴 dt 一致"的规范，用户报障
      · **本版（09-30）**：只同步 `s`，**一次 write_s 写三轴同一个 dt** ⇒ 规范 ✓
                  代价：GE 手柄**不再保证共线** ——
                  那件事交给 `spec_check.fix_force_align`（GE 共线）/
                  `spec_check.fix_handle_bend`（3D 手柄拉直），
                  它们会**明确告知会改变路径形状**。

    ★ 为什么本版**天然满足"三轴 dt 一致"**：
        `td.write_s` 的语义就是「把 s 写到该帧的【所有轴】（三轴同步）」
        ⇒ **一次调用**写三轴同一个 dt ✓
        （09-29 那版错在**逐轴各调一次** `write_s`、每次传不同的 s）

    ★ 为什么本版**形状变化最小**：
        只改 `handle[0]`（时间分量），**值分量一律不碰**；
        且三轴按**同一比例**变化（实测路径最大偏移 0.177%，单轴变化是 1.445%）。

    返回 `(ok, info, reason)`：
      · ok=True  ⇒ info = {"s", "dt", "dt_src", "span_s", "span_o", "clamped"}
      · ok=False ⇒ reason 供状态栏提示
    """
    side = hd.SIDE_BY_TRI.get(tri)
    other_tri = hd.TRI_DOWN if tri == hd.TRI_UP else hd.TRI_UP
    other_side = hd.SIDE_BY_TRI.get(other_tri)
    if side is None or other_side is None:
        return (False, None, "unknown_tri")
    act = _action_of(obj)
    if act is None:
        return (False, None, "no_action")
    if bone_name is None:
        bone_name = _bone_name_of(context, obj)     # ★ 姿态模式（见 _bone_name_of）

    # 两侧都要（② 方案：让两侧【物理速度 |v| = |dv|/dt】相等 ⇒ 两侧 dt 都要重算）
    kf_map_s, span_s = td.resolve_target(act, obj, float(frame), side, bone_name)
    if not kf_map_s or not span_s or float(span_s) <= 1e-9:
        return (False, None, "no_source")
    kf_map_o, span_o = td.resolve_target(act, obj, float(frame), other_side, bone_name)
    if not kf_map_o or not span_o or float(span_o) <= 1e-9:
        return (False, None, "no_opposite")

    def _side_dt_dv(kf_map, sd):
        """该侧当前的 `(dt 中位数, |dv| 范数)`。

        ⚠️ `dt` 取**中位数**：三轴 dt 本应一致（插件维护的不变量），
           中位数只为防浮点噪声/异常数据。
        ⚠️ `|dv|` 取三轴的**向量范数** —— 它是**一个标量**，
           所以算出来的新 dt 天然三轴一致 ✓（规范保住）。
        """
        mags, dvs = [], []
        for _ax, _kp in kf_map.items():
            _h = _kp.handle_left if sd == 'left' else _kp.handle_right
            _d = abs(float(_h[0]) - float(_kp.co[0]))
            if _d > 1e-9:
                mags.append(_d)
            dvs.append(float(_h[1]) - float(_kp.co[1]))
        if not mags:
            return (None, None)
        return (sorted(mags)[len(mags) // 2], math.sqrt(sum(x * x for x in dvs)))

    dt_s, dv_s = _side_dt_dv(kf_map_s, side)
    dt_o, dv_o = _side_dt_dv(kf_map_o, other_side)
    if not dt_s or not dt_o or dv_s < 1e-12 or dv_o < 1e-12:
        # 手柄时间跨度为 0 / 值分量为 0 ⇒ 定不出速度
        return (False, None, "degenerate")
    v_s = dv_s / dt_s                       # 被双击侧的物理速度（标量）
    v_o = dv_o / dt_o
    # ★★★ 2026-09-30（用户定案）：**以【被双击侧】为准**，不是取均值。
    #
    #   用户原话：「回想一下双击锁定三角的功能，应该是看用户双击的是哪个三角控制柄，
    #             然后把对端也统一为同样的速度值才对，所以不是均值」
    #
    #   ⇒ 这是【命令】语义（我点谁，就以谁为准），不是【协商】语义。
    #     也正好恢复插件原本记录的语义：「保持被双击侧的疏密 dt 不动」。
    #   ⚠️ 代价：只有对侧 dt 变 ⇒ 变化倍数 = |v对侧| / |v本侧|，可能比"均值"大。
    #      （均值那版两侧各变一点、形变更小，但不符合"我点谁以谁为准"的直觉。）
    v_target = v_s
    if v_target < 1e-12:
        return (False, None, "degenerate")
    # 对侧 dt 反解：dt = |dv| / |v*| —— 一个标量 ⇒ 三轴天然一致 ✓
    dt_o_new = dv_o / v_target

    # ★★ **一次** `write_s`（写对侧【三轴同一个 dt】）⇒ 规范保住 ✓
    #    被双击侧**一个数都不动** ✓
    #    ⚠️⚠️ 绝不能改成"逐轴各调一次 write_s、每次传不同的 s" ——
    #       那是 2026-09-29 那版的错，会把同侧三轴 dt 写散（实测 [-8, -4, -16]），
    #       直接打破"三轴 dt 一致"的规范（用户报障）。
    # ★★★ 2026-09-30 修 D-6（Phase 1 极限测试抓到，FAIL/高）：
    #    旧代码**只判上界** `> S_HARD_MAX` ⇒ 需要 s **小于** `td.S_EPS` 时，
    #    `write_s` 会把它抬到 S_EPS（钳到下界），而 `clamped` 仍为 False ⇒
    #    状态栏照样说「进出速度已一致」—— 实测**两侧仍差 51.50 倍**（构造：
    #    被双击侧 dt=0.00195/span 极小、对侧 span=10090 ⇒ 需要 s=1.94e-7 < 1e-5）。
    #    ⇒ 上界或下界**任一被钳**都要如实上报（与 Phase 0 修的 P1-1 同一族的另一半）。
    _s_req = dt_o_new / float(span_o)
    clamped = (_s_req > td.S_HARD_MAX) or (_s_req < td.S_EPS)
    w_o = td.write_s(kf_map_o, other_side, dt_o_new / float(span_o), span_o,
                     act=act, obj=obj, bone_name=bone_name)
    if w_o is None:
        return (False, None, "write_failed")
    for ax in kf_map_o:
        fc = td.fcurve_of(act, obj, ax, bone_name)
        if fc:
            fc.update()
    try:
        refresh_position_store(context)
    except Exception:
        warn_once("interaction._align_opposite_speed")
        pass
    # 复读实际写进去的值（write_s 可能钳制到 S_HARD_MAX）
    dt_s_after, dv_s_after = _side_dt_dv(
        td.resolve_target(act, obj, float(frame), side, bone_name)[0], side)
    dt_o_after, dv_o_after = _side_dt_dv(
        td.resolve_target(act, obj, float(frame), other_side, bone_name)[0], other_side)
    return (True, {"v_target": float(v_target),
                   "v_source": "clicked",          # ★ 以被双击侧为准（不是均值）
                   "v_before": [float(v_s), float(v_o)],
                   "v_after": [(dv_s_after / dt_s_after) if dt_s_after else None,
                               (dv_o_after / dt_o_after) if dt_o_after else None],
                   "dt": [float(dt_s_after) if dt_s_after else None,
                          float(dt_o_after) if dt_o_after else None],
                   "s": [float(dt_s_after / float(span_s)) if dt_s_after else None,
                         float(dt_o_after / float(span_o)) if dt_o_after else None],
                   "clamped": clamped}, None)


# ---------------------------------------------------------------------------
# ★★ 2026-09-18：三角「一体 / 分离」的辅助（用户需求）
#
#   一体（默认）：同一关键帧的两个三角**联动** —— 单击选中两个、拖动两边同值。
#   分离        ：两个三角各自独立 —— 可单边选中、单边调整。
#
#   ⚠️ "该帧有哪些三角" 是**查询**来的（端点段不生成三角），不是假设出来的：
#      首帧只有 right 三角（左段无邻居）/ 末帧只有 left 三角。
# ---------------------------------------------------------------------------

def _action_of(obj):
    """取 obj 当前 action（没有就 None）。"""
    try:
        return obj.animation_data.action if obj and obj.animation_data else None
    except Exception:
        warn_once("interaction._action_of")
        return None


def _tris_present_for_frame(s_handles, frame):
    """该关键帧**实际存在**的三角列表（从已收集的手柄记录里查）。

    ⚠️ 必须按实际记录查 —— 端点上只有一个三角，硬写 [(up),(down)] 会
       选中一个**不存在**的三角，之后拖动对它写值必然失败（静默）。
    """
    out = []
    for h in (s_handles or []):
        try:
            if abs(float(h.get('frame')) - float(frame)) < FRAME_EPS:
                t = h.get('tri')
                if t is not None and t not in out:
                    out.append(t)
        except Exception:
            warn_once("interaction._tris_present_for_frame")
            continue
    # 稳定顺序：与 TRI_KINDS 一致（上 → 下）
    return [t for t in hd.TRI_KINDS if t in out]


def is_frame_locked(obj, frame):
    """该关键帧的三角是否处于「一体」（未记录 ⇒ True = 默认一体）。"""
    act = _action_of(obj)
    if act is None:
        return True
    try:
        return bool(xf.is_tri_locked(act, frame))
    except Exception:
        return True


def make_split_frames(obj, s_handles):
    """当前视图里**处于分离状态**的帧号集合（供覆盖层画空心三角）。

    只收"确实有两个三角"的帧 —— 端点上分离没有意义（本来就只有一个）。
    """
    act = _action_of(obj)
    if act is None:
        return set()
    frames = set()
    for h in (s_handles or []):
        try:
            frames.add(round(float(h.get('frame')), 4))
        except Exception:
            warn_once("interaction.make_split_frames")
            continue
    out = set()
    for f in frames:
        try:
            if xf.is_tri_locked(act, f):
                continue
        except Exception:
            warn_once("interaction.make_split_frames")
            continue
        if len(_tris_present_for_frame(s_handles, f)) >= 2:
            out.add(f)
    return out


def _triangle_under_cursor(s_handles, mouse_pos):
    """★★【唯一的】"鼠标下的三角" 查询 —— 带**关键帧点保护**。

    用户在 2026-09-18 反馈："关键帧点和三角控制柄容易误触，
    用户想选择关键帧点时容易误触选择三角控制器"。

    根因（实测，不是感觉）：三角的拾取盘半径 22 > 三角尖端离关键帧的 18.5
    ⇒ 拾取盘覆盖了 **[4, 18.5] 这段什么都没画的空白区**，
       用户瞄关键帧点往上偏一点点就被判成"点中三角"。

    判据：鼠标离该三角所属**关键帧点**的距离 < `KEYFRAME_PICK_PRIORITY_RADIUS`
          ⇒ 这个三角**不参与命中**（把机会让给关键帧）。

    ⚠️ **必须唯一**：点击 / 悬停 / 双击 / 恢复默认，四处都得走这里，
       否则会出现"看得见的状态与点得中的状态不一致"（历史上栽过）。
    """
    hit = hd.hit_test(s_handles, mouse_pos, SPEED_TRI_PICK_RADIUS)
    if hit is None:
        return None
    kf_screen = hit.get('kf_screen')
    if kf_screen is not None:
        # ⚠️ 用**闭区间**（<=）：半径上的点也算关键帧的地盘 —— 与 `hd.hit_test`
        #    内部的 `d2 <= r2` 保持同一口径，避免"刚好在边界上"行为不确定。
        if hd.dist2(kf_screen, mouse_pos) <= (KEYFRAME_PICK_PRIORITY_RADIUS ** 2):
            # 离关键帧点很近 ⇒ 用户想选的是**关键帧**，不是三角
            return None
    return hit


def apply_speed_click_selection(obj, s_handles, hit_tri, shift=False):
    """★ 单击（或 Shift+单击）一个三角 ⇒ 更新选中集。

    返回 `(一体化, 该帧实际存在的三角列表)`：
      · 一体化=True  ⇒ 这次点击把该帧的**两个三角都选中了**（拖动要用"一个旋钮"语义）
      · 一体化=False ⇒ 只选中单边（分离态 / Shift 多选 / 端点）

    语义（用户 2026-09-18）：
      · **一体（默认）**：单击任一个三角 ⇒ 两个一起选中（"两个三角是一体的"）
      · **分离**        ：只选被点的那个（用户要"只调整单边"）
      · Shift          ：多选累加/取消（保留 2026-09-16 语义，**不做**自动配对）

    ⚠️ 抽成模块级函数（不是内联在 modal 里）⇒ headless 测试能驱动**真入口**。
    """
    frame = hit_tri['frame']
    tris = _tris_present_for_frame(s_handles, frame)
    if shift:
        _session.toggle_speed_handle(frame, hit_tri['tri'])
        return (False, tris)
    locked = is_frame_locked(obj, frame) and len(tris) >= 2
    if locked:
        _session.set_locked_pair_speed_handle(frame, tris)
        return (True, tris)
    _session.set_single_speed_handle(frame, hit_tri['tri'])
    return (False, tris)


def toggle_frame_lock(context, obj, frame, s_handles, local_mouse_pos,
                      region=None, rv3d=None):
    """★ 双击一个三角 ⇒ **切换该帧的「一体 / 分离」**。返回 `(ok, message)`。

    语义（用户 2026-09-18）：
      · 当前是一体 → 切成**分离**（可单边操作）
      · 当前是分离 → **锁回一体**，并把**对侧的值同步到被双击的这个三角**
                     （= 旧的双击"复制值"行为，保留在锁定这一步）

    ⚠️ 两个三角必须都在才谈得上"切换"；端点上返回 `no_pair`。
    """
    act = _action_of(obj)
    if act is None:
        return (False, "no_action")
    tris = _tris_present_for_frame(s_handles, frame)
    if len(tris) < 2:
        # 首/末帧：只有一个三角 ⇒ 无所谓一体分离，保持原样（不报错、不写数据）
        return (False, "no_pair")

    locked_now = is_frame_locked(obj, frame)
    if locked_now:
        # 一体 → 分离
        try:
            xf.set_tri_locked(act, frame, False)
        except Exception:
            return (False, "write_failed")
        # ★★ 2026-09-19：补一个 undo 点 —— 与「分离 → 锁回一体」分支对称。
        #    缺它时，一次 Ctrl+Z 会【越过】这次分离：实测（真双击入口 + 真 undo）
        #      · 无 push ⇒ undo 退到了更早的状态，严重时连对象一起消失；
        #      · 有 push ⇒ undo 回到「一体」、redo 回到「分离」，完美往返。
        #    原因：锁定状态写在 action 的 custom property 上，属于**脚本级写入**；
        #    它不会自己形成 undo 步，必须显式推一个（作者在锁回一体分支已有先例）。
        try:
            bpy.ops.ed.undo_push(message=iface_("Split Handles"))
        except Exception:
            warn_once("interaction.toggle_frame_lock")
            pass          # 后台/无撤销上下文时忽略（不影响写入本身）
        # 分离后鼠标停在哪个三角，就只选那个（单边操作的起点）
        _session.set_single_speed_handle(frame, tris[0])
        try:
            if rv3d is not None and local_mouse_pos is not None:
                hit = _triangle_under_cursor(s_handles, local_mouse_pos)
                if hit is not None:
                    _session.set_single_speed_handle(hit['frame'], hit['tri'])
        except Exception:
            warn_once("interaction.toggle_frame_lock")
            pass
        msg = iface_("Handles split - you can now adjust each side on its own")
        return (True, msg)

    # 分离 → 锁回一体。
    # ★ 2026-09-18：这里的数据行为从「复制对侧疏密 s」改成「对齐 GE 手柄」——
    #   保持被双击侧的疏密不动，按公式算对侧的新疏密（共线 / 镜像）。
    hit = None
    try:
        hit = _triangle_under_cursor(s_handles, local_mouse_pos)
    except Exception:
        hit = None
    tri_clicked = hit['tri'] if hit is not None else tris[0]
    try:
        xf.set_tri_locked(act, frame, True)
    except Exception:
        return (False, "write_failed")

    # ★ 2026-09-29：把「被双击的那个三角所属骨骼」传下去（姿态模式必需）。
    #    hit 记录由 `collect_speed_handles` 写入，带 bone_name。
    hit_bone = hit.get('bone_name') if hit is not None else None
    ok, info, reason = _align_opposite_speed(context, obj, frame, tri_clicked, hit_bone)
    if ok:
        try:
            bpy.ops.ed.undo_push(message=iface_("Lock Handles Together"))
        except Exception:
            warn_once("interaction.toggle_frame_lock")
            pass          # 后台/无撤销上下文时忽略（不影响写入本身）
    # 锁定 → 两个三角一起选中（"一体"的视觉与行为）
    _session.set_locked_pair_speed_handle(frame, tris)
    if ok:
        # ⚠️ 2026-09-30：文案**不再说"GE 手柄已共线"** —— 本版只同步三角的"值"，
        #    GE 手柄**不保证共线**（那交给弹窗里的校正，它会告知改形状）。
        #    说"已共线"是误导（实测：三轴比例不同时仍有残余折角）。
        #
        # ★★ 2026-09-30 修 P1-1（Review 实测确认的真缺陷）：
        #    对侧需要的 dt 超过 S_HARD_MAX(1.0) 时会被 `write_s` **钳到 1.0**
        #    ⇒ 对侧实际速度 `dv/span` **达不到** v_target ⇒ **"两侧速度相等"落空**。
        #    旧文案无条件说"速度已一致" ⇒ **对用户说谎**。
        #    实测：dv/span 两侧差 33 倍时，锁定后仍差 **16.67 倍**，却报"已一致"。
        #
        #    触发条件（很容易碰到）：
        #      required_s = s_被双击侧 x (dv_对侧/span_对侧) / (dv_本侧/span_本侧) > 1
        #      真实工程里 dv/span 两侧通常不等（用户工程实测差 1.6 倍）
        #      ⇒ s_被双击侧 > 0.625 就会触发。
        if (info or {}).get("clamped"):
            _va = (info or {}).get("v_after") or [None, None]
            try:
                _a, _b = float(_va[0]), float(_va[1])
                _hi, _lo = max(_a, _b), min(_a, _b)
                _ratio = (_hi / _lo) if _lo > 1e-12 else float('inf')
            except Exception:
                _ratio = -1.0
            # ⚠️ 必须写成**一行**字符串：i18n 扫描器按字面量取 key，
            #    隐式拼接（两段相邻字符串）只会取到第一段 ⇒ 词条对不上（实测踩过）。
            msg = iface_("Handles locked together - opposite handle hit its limit, speeds NOT fully equal (%.2fx apart)") % _ratio
        else:
            msg = iface_("Handles locked together - in/out speeds are now equal")
    elif reason == "no_opposite":
        msg = iface_("Handles locked together (no opposite handle to match)")
    elif reason == "degenerate":
        msg = iface_("Handles locked together (cannot read a speed value)")
    else:
        msg = iface_("Handles locked together")
    return (True, msg)


def try_toggle_tri_lock_click(context, obj, s_handles, local_mouse_pos,
                              region=None, rv3d=None):
    """双击三角的处理入口。返回 `(consumed, message)`。

      · consumed=True ⇒ 调用方 `return {'RUNNING_MODAL'}`（不要顺势进入拖拽）
      · message 非空   ⇒ 调用方 `self.report({'INFO'}, message)`

    ★ 2026-09-18：语义从"双击=复制值"升级为"双击=**切换一体/分离**"。
      复制的效果被保留在"分离 → 锁回一体"那一步里（用户需求原话：
      "插件会把同关键帧的另一个三角控制柄的数值同步到双击的三角控制柄，
       并同时锁定三角控制柄"）。

    ⚠️ 抽成独立函数（与 `try_reset_hovered_speed` 同思路）⇒ 可被 headless 测试
       直接调用，不必模拟真 modal。
    """
    hit = _triangle_under_cursor(s_handles, local_mouse_pos)
    if hit is None:
        # 点到别处 ⇒ 断掉双击链（避免"隔一会儿点同一三角"被误判成双击）
        clear_speed_click_chain()
        return (False, None)
    frame, tri = hit['frame'], hit['tri']
    if not speed_double_click_hit(frame, tri, local_mouse_pos):
        return (False, None)

    # ---- 双击命中：切换锁定 ----
    ok, msg = toggle_frame_lock(context, obj, frame, s_handles, local_mouse_pos,
                                region, rv3d)
    if not ok and msg == "no_pair":
        # 端点上没有"一对"⇒ 不消费（让调用方按普通单击处理）
        clear_speed_click_chain()
        return (False, None)
    # 值 / 状态变了 ⇒ 悬停记录（倍数标签 / 段高亮）要跟着更新
    try:
        if region is not None and rv3d is not None:
            _update_speed_hover(context, obj, region, rv3d, local_mouse_pos)
        _a = getattr(context, "area", None)
        if _a is not None and _a.type == 'VIEW_3D':
            _a.tag_redraw()
    except Exception:
        warn_once("interaction.try_toggle_tri_lock_click")
        pass
    return (True, msg)


# 旧名保留（v1.3.2 及以前的测试/调用方用）—— 行为已升级为"切换锁定"。
try_copy_other_speed_click = try_toggle_tri_lock_click


def _apply_speed_from_drag(context, obj, mouse_pos):
    """按【相对拖拽量】更新疏密 —— **支持多选同时滑移**。

    用户 2026-09-16：
      · ① Shift+点击可多选三角，拖拽时**所有选中的三角一起滑移**
      · ③ 拖拽中按住 Shift = 精度模式（位移 ×0.1）

    每个三角按**自己的疏密方向**解释同一个鼠标位移：
      上三角（在关键帧上方）往上拖 = 远离关键帧 = 变疏
      下三角（在关键帧下方）往上拖 = 靠近关键帧 = 变密
    —— 即"鼠标往哪拖、三角就往哪动"，物理直觉一致。

    ⚠️ `mouse_pos` 必须【由调用方传入】（不能从 session 读）。
    """
    handles = list(getattr(_session, "selected_speed_handles", None) or [])
    if not handles:
        # 兼容：没有多选集合时退回单值字段
        f, t = _session.selected_speed_frame, _session.selected_speed_tri
        if f is not None and t is not None:
            handles = [(f, t)]
    if not handles or mouse_pos is None:
        return None

    # ---- ③ 增量累积的竖直位移（精度模式只影响【此后】的移动）----
    last = _session.speed_drag_last_mouse
    if last is None:
        # 第一次调用：只记起点，不产生位移
        _session.speed_drag_last_mouse = mouse_pos
        return None
    dy_raw = float(mouse_pos[1]) - float(last[1])
    _session.speed_drag_last_mouse = mouse_pos
    # 微小抖动（投影噪声）忽略，避免累积漂移
    if abs(dy_raw) > 1e-9:
        scale = xf.PRECISION_FACTOR if _session.speed_drag_precision else 1.0
        # ★ 2026-09-17（用户拍板 120~150px 打满全程）：鼠标像素 → d 再乘
        #   DRAG_PX_SCALE（<1），等效"拖更远才打满"，手感更可控。
        #   ⚠️ 缩放放在这里（像素→d），不动 time_domain 的几何映射
        #      （那两个速率决定 d↔s 的对应，改了会把三角画到视口外）。
        _session.speed_drag_effective_px += dy_raw * scale * td.DRAG_PX_SCALE
        # ★ 2026-09-27（3d）：标记"本次拖拽确实要写数据了"——
        #   松手时据此决定要不要推 undo（没写过就不推，避免空步）。
        _session.speed_drag_wrote = True

    eff = _session.speed_drag_effective_px
    # ⚠️ 2026-09-17 记录一次【未成立】的尝试：
    #   我曾在这里加"首次拖动时把超范围的 s 规范化写回"，以为是 GE 卡死的解药。
    #   bug 注入 3 组全部抓不住 ⇒ 回去推演才发现：
    #     · s 超范围时，往超限方向拖到 1.0 就不动 —— 那是**物理上限**（正确行为）
    #     · 规范化只是把 s 从 2.0 写回 1.0，**不改变"能动范围"**
    #   ⇒ 它是多余的，已回退。真正的根因是**拖拽速率太陡**（拖 30px 打满全程），
    #     修在 `td.DRAG_PX_SCALE`（135px 打满），不在这里。
    # ★★ 2026-09-18（用户拍板乙方案）：**「一体」拖动 = 一个旋钮**
    #
    #   选中集恰好是"同一个锁定帧的两个三角"时，两侧必须写**同一个 s**
    #   （一起变快 / 一起变慢），而不是各按自己的 d0 起算 ——
    #   后者因为两侧 span 不同，会让左边变快、右边变慢（手感变成"剪刀"）。
    #
    #   ⚠️ `eff` 是**净像素位移**（已经由每个三角各自的 DIR 换算过吗？没有 ——
    #      `eff` 是原始竖直位移）。一体时统一按"往上 = 更疏"约定一次方向，
    #      不能用各三角的 DIR（那会让两边一个变疏一个变密）。
    is_group = (_session.speed_drag_group_origin_s is not None
                and _session.speed_drag_locked_frame is not None)
    results = []
    for (frame, tri) in handles:
        side = hd.SIDE_BY_TRI.get(tri)
        if side is None:
            continue
        # ★ 起点 = **按下时记录的固定 d**（unclamped）。
        #   ⚠️⚠️ 不能每帧现读"当前值"：`eff` 是【累积】位移，
        #     "当前值 + 累积位移"会**双重累加** ⇒ 拖得越久加得越多 ⇒ 指数漂移
        #     （= 用户零容忍的"跳变"）。2026-09-19 实测抓到一次。
        d0 = _session.speed_drag_origins.get((frame, tri))
        if d0 is None:
            d0 = _session.speed_drag_origin_d
        if is_group:
            # ★★ 2026-09-19（用户拍板，语义修正）：
            #   **一体 = 两侧各加减【同一个增量】，差异保留**
            #   （推翻旧语义"一个旋钮 / 两侧始终同值"）。
            #
            #   用户原话：「双击锁定三角后拖动一体化的三角，三角的数值会被强行同步
            #   为相同数值；一体化锁定的定义应该是可以同时做增量调整，不是改变稀疏
            #   数值为相同」。
            #
            #   方向：统一取 UP（上=更疏）—— 不能用各三角自己的 DIR，
            #         否则两侧一个变疏一个变密；但**数值各按各自的起点** ⇒ 差异保留。
            delta_px = eff * hd.DIR_BY_TRI.get(hd.TRI_UP, 1.0)
        else:
            # 每个三角按【自己的疏密方向】解释同一个竖直位移
            delta_px = eff * hd.DIR_BY_TRI.get(tri, 1.0)
        results.append(_apply_speed_d(context, obj, frame, side, d0 + delta_px))
    return results[-1] if results else None


def flush_pending_speed_drag(context, obj):
    """★★★ 2026-09-18（性能修复配套）：把手柄拖拽**被节流跳过**的那段位移补写进去。

    ⚠️ 为什么必须有它（否则就是跳变）：
      节流会跳掉一部分 MOUSEMOVE。因为写值是**增量法**，跳过的位移会在
      **下一次**事件里被一并补上 —— 但"松手"之后就没有下一次了，
      最后 ≤1 帧（默认 16ms）的位移**会永久丢掉** ⇒ 松手瞬间画面与鼠标位置
      差一截（跳变）。所以 RELEASE 时必须强制补一次。

    做法：拿"上一次真正写入时的鼠标位置"与"当前鼠标位置"再算一次增量，
    `_apply_speed_from_drag` 内部是增量法 ⇒ 多余的位移是 0（幂等安全）。

    返回 True 表示**确实补了一次**（调用方据此决定要不要额外 tag_redraw）。
    """
    try:
        if not _session.speed_drag_active:
            return False
        last = _session.speed_drag_last_mouse
        cur = _session.speed_drag_pending_mouse
        if last is None or cur is None:
            return False
        # 位移为 0 ⇒ 无需补（避免无意义写入 + 多算一遍缓存）
        if abs(float(cur[1]) - float(last[1])) < 1e-9 \
                and abs(float(cur[0]) - float(last[0])) < 1e-9:
            return False
        _apply_speed_from_drag(context, obj, cur)
        return True
    except Exception:
        return False






@persistent
def on_depsgraph_update(scene, depsgraph):
    global _session
    
    if _session.drag_in_progress or _session.handle_edit_in_progress:
        return

    wm = bpy.context.window_manager
    # ★ 2026-09-17：更新模式已迁到插件偏好设置（AddonPreferences）——
    #   WindowManager 属性不写入文件（改完重启就丢），故换存储。
    if not wm.rtmp_path_display_enabled or addon_pref('refresh_strategy', 'SMART') != 'SMART':
        return

    is_object_updated = depsgraph.id_type_updated('OBJECT')
    is_action_updated = depsgraph.id_type_updated('ACTION')
    
    if is_object_updated or is_action_updated:
        if bpy.context.screen and bpy.context.screen.is_animation_playing:
            return

        try:
            has_relevant_objects = (bpy.context.active_object or bpy.context.selected_objects)
            if has_relevant_objects:
                is_interaction_update = is_object_updated and not is_action_updated
                
                if is_interaction_update:
                    return

                refresh_position_store(bpy.context)
                
                for window in wm.windows:
                    for area in window.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()
        except Exception as e:
            print(f"Error in smart update: {e}")


class RTMP_OT_PathRefreshDaemon(bpy.types.Operator):
    bl_idname = "rtmp.path_refresh_daemon"
    bl_label = "Auto Update Motion Paths"
    bl_description = "Real time update motion paths"
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    _last_keyframe_values = None
    _needs_update = False
    
    @classmethod
    def poll(cls, context):
        return True
    
    def invoke(self, context, event):
        wm = context.window_manager
        self._last_keyframe_values = self._collect_keyframe_snapshot(context)
        self._last_active_obj_name = context.active_object.name if context.active_object else None
        self._last_selected_obj_names = self._collect_selected_names(context)
        self._last_bone_selection = self._collect_bone_selection(context)
        self._needs_update = False
        
        # ★★ 2026-09-17：改成"先按包名清干净、再加当前的"。
        #    原来的 `if on_depsgraph_update not in bpy.app.handlers.xxx` 比的是
        #    **函数对象身份** —— 跨模块重载后那是**新对象**，与列表里残留的
        #    旧对象不相等 ⇒ 判重失效 ⇒ 每次重载再叠一个
        #    （实测 `depsgraph_update_post` 叠了 3 个；其中旧模块那个还在读
        #      已删除的 WindowManager 属性 ⇒ 每次 depsgraph 更新抛 AttributeError）。
        purge_stale_app_handlers()
        bpy.app.handlers.depsgraph_update_post.append(on_depsgraph_update)
            
        interval = 1.0 / max(1, addon_pref('poll_frequency', 10))
        self._timer = wm.event_timer_add(interval, window=context.window)
        
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
        wm = context.window_manager

        active_obj = context.active_object
        current_obj_name = active_obj.name if active_obj else None
        if current_obj_name != self._last_active_obj_name:
            self._last_active_obj_name = current_obj_name
            _session.active_path_point = None
            _session.active_frame_number = None
            _session.active_handle_direction = None
            _session.active_bone_identifier = None
            _session.active_handle_index = None
            _session.active_handle_info = None
            _session.drag_in_progress = False
            _session.handle_edit_in_progress = False
            _session.drag_target_object = None
            _session.clear_speed_handle()
            self._needs_update = True

        current_selected = self._collect_selected_names(context)
        if current_selected != self._last_selected_obj_names:
            self._last_selected_obj_names = current_selected
            self._needs_update = True

        current_bone_selection = self._collect_bone_selection(context)
        if current_bone_selection != self._last_bone_selection:
            self._last_bone_selection = current_bone_selection
            if current_bone_selection is None:
                _session.active_bone_identifier = None
            self._needs_update = True
        
        if addon_pref('refresh_strategy', 'SMART') == 'TIMER' and event.type == 'TIMER':
            current_values = self._collect_keyframe_snapshot(context)
            if current_values != self._last_keyframe_values:
                self._needs_update = True
                self._last_keyframe_values = current_values
                
        if self._needs_update:
            try:
                refresh_position_store(context)
            except Exception as e:
                print("Error updating position cache:", e)
            self._needs_update = False
            for window in wm.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
        
        if not wm.rtmp_auto_refresh_active:
            self.cancel(context)
            return {'CANCELLED'}
        
        return {'PASS_THROUGH'}
    
    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None
            
        if on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(on_depsgraph_update)
    
    def _collect_object_keyframes(self, obj):
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return []
        action = obj.animation_data.action
        values = []
        for fcurve in collect_animation_curves(action, obj):
            for keyframe in fcurve.keyframe_points:
                values.append((
                    keyframe.co[0], keyframe.co[1],
                    keyframe.handle_left[0], keyframe.handle_left[1],
                    keyframe.handle_right[0], keyframe.handle_right[1],
                    keyframe.select_control_point
                ))
        return values

    def _collect_keyframe_snapshot(self, context):
        all_values = []
        
        active_object = context.active_object
        if active_object and active_object.mode == 'POSE':
            all_values.extend(self._collect_object_keyframes(active_object))
        else:
            seen = set()
            for obj in (context.selected_objects or []):
                if obj.name in seen:
                    continue
                seen.add(obj.name)
                all_values.extend(self._collect_object_keyframes(obj))
                parent = obj.parent
                while parent:
                    if parent.name not in seen:
                        seen.add(parent.name)
                        all_values.extend(self._collect_object_keyframes(parent))
                    parent = parent.parent
            if active_object and active_object.name not in seen:
                all_values.extend(self._collect_object_keyframes(active_object))
            
        return tuple(all_values) if all_values else None
    
    def _collect_selected_names(self, context):
        return tuple(sorted(obj.name for obj in context.selected_objects)) if context.selected_objects else ()
    
    def _collect_bone_selection(self, context):
        active_object = context.active_object
        if not active_object or active_object.mode != 'POSE':
            return None
            
        active_bone_name = context.active_pose_bone.name if context.active_pose_bone else None
        selected_bone_names = tuple(sorted([b.name for b in context.selected_pose_bones])) if context.selected_pose_bones else ()
        
        return (active_bone_name, selected_bone_names)


class RTMP_OT_ChangeHandleMode(bpy.types.Operator):
    bl_idname = "rtmp.change_handle_mode"
    bl_label = "Set Handle Type"
    bl_options = {'REGISTER', 'UNDO'}
    
    handle_type: bpy.props.StringProperty()
    
    def execute(self, context):
        handle_type = self.handle_type
        if not handle_type:
            handle_type = context.window_manager.rtmp_handle_type
        apply_handle_mode(context, handle_type)
        refresh_position_store(context)
        return {'FINISHED'}


class RTMP_OT_ToggleEditMode(bpy.types.Operator):
    bl_idname = "rtmp.toggle_edit_mode"
    bl_label = "Toggle Direct Manipulation"
    bl_description = "Enable/Disable Motion Path Editing"
    
    def execute(self, context):
        global _session
        wm = context.window_manager
        
        # ⚠️ 2026-09-27：读用 getattr 守卫 —— 插件卸载后这个 WindowManager
        #    属性会被 `__init__.unregister()` 里的 `del` 摘掉，裸访问会抛
        #    AttributeError（既有报告 P0-2）。取不到 ⇒ 当作"未开启"。
        if not getattr(wm, "rtmp_edit_mode_active", False):
            wm.rtmp_edit_mode_active = True
            bpy.ops.rtmp.path_point_drag('INVOKE_DEFAULT')
            wm.rtmp_auto_refresh_active = True
            bpy.ops.rtmp.path_refresh_daemon('INVOKE_DEFAULT')
            # 注：G/R/S 的接管由 rtmp_edit_mode_active 的 update 回调负责
            #     （见 modal_edit.update_edit_mode_active），此处不必显式调用。
            self.report({'INFO'}, iface_("Enable Direct Path Editing"))
        else:
            wm.rtmp_edit_mode_active = False
            wm.rtmp_auto_refresh_active = False
            # 注：归还 G/R/S 同样由属性回调负责。
            if context.area:
                context.area.tag_redraw()
            self.report({'INFO'}, iface_("Disable Direct Path Editing"))
        
        return {'FINISHED'}


def _speed_drag_mouse_local(context, event):
    """★★★ 速度三角拖拽的鼠标坐标 —— 必须**与 PRESS 时的起点同源**。

    ★ 2026-09-17 修「拖三角时数值立刻打满 + 卡死」（真机日志定位）：

      PRESS 时起点来自 `find_region_under_mouse()`（3D 视图**局部**坐标，实测 600,800）。
      而旧代码的 MOUSEMOVE 用 `event.mouse_region_x/y` —— 它在
      **鼠标不在任何 Blender 区域上时返回 `-1`**！
        实测日志：mouse_region_* = [-1, -1]
        ⇒ dy_raw = -1 - 800 = -801 ⇒ eff = -332 ⇒ **s 立刻打满**
        ⇒ 之后 last_mouse 恒为 (-1,-1) ⇒ dy=0 ⇒ **继续拖也不动（卡死）**

    本函数：
      · 优先 `find_region_under_mouse`（与起点同一来源，最一致）
      · 拿不到就用「绝对坐标 − 按下时记住的 region 偏移」（鼠标拖出视图也连续）
      · 两者都无效 ⇒ 返回 None（**调用方必须跳过本次移动**）
      · **显式拒绝 `-1`** 这类哨兵值 / 区域外的坐标
    """
    # ★ 核心要求只有两条：
    #   ① 拒收 `-1` 哨兵值（**这就是"立刻打满 + 卡死"的真凶**）——
    #      鼠标不在任何 Blender 区域上时，`mouse_region_*` 就是 -1，
    #      而起点是几百的正常值 ⇒ 假位移 ⇒ 打满；之后恒为 -1 ⇒ dy=0 ⇒ 卡死。
    #   ② 与起点尽量同源。
    #
    # 顺序：先用 `event.mouse_region_*`（它就是"当前鼠标位置"，Blender 原生语义），
    #      无效再退回 `find_region_under_mouse`（3D 视图内时两者等价）。
    for _get in (
        lambda: (event.mouse_region_x, event.mouse_region_y),
        lambda: (lambda t: (t[2] if t[2] is not None else (None, None)))(
            find_region_under_mouse(context, event)),
    ):
        try:
            xy = _get()
            # ★★ 判据收敛到 `_is_usable_mouse`（唯一来源）——
            #    2026-09-27 之前这里内联了一份 `> -0.5` 检查，而
            #    `_is_usable_mouse` 因此成了**零调用死代码**。
            #    同一判据两份实现 ⇒ 改一处必然漂移（这正是本项目的头号架构病）。
            if _is_usable_mouse(xy):
                return (float(xy[0]), float(xy[1]))
        except Exception:
            continue
    return None


def _is_usable_mouse(xy):
    """鼠标坐标是否可用（拒绝 None 与 `-1` 哨兵值）。"""
    if xy is None:
        return False
    try:
        return float(xy[0]) > -0.5 and float(xy[1]) > -0.5
    except Exception:
        return False


def find_region_under_mouse(context, event):
    mouse_x = event.mouse_x
    mouse_y = event.mouse_y

    windows_to_check = [context.window] if context.window else []
    for win in context.window_manager.windows:
        if win not in windows_to_check:
            windows_to_check.append(win)
            
    for window in windows_to_check:
        screen = window.screen
        if not screen: continue
        
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
                
            if (area.x <= mouse_x < area.x + area.width and
                area.y <= mouse_y < area.y + area.height):
                
                for region in area.regions:
                    if region.type == 'WINDOW':
                        if (region.x <= mouse_x < region.x + region.width and
                            region.y <= mouse_y < region.y + region.height):
                            
                            local_x = mouse_x - region.x
                            local_y = mouse_y - region.y
                            space_data = area.spaces.active
                            return region, space_data, (local_x, local_y), area

    return None, None, None, None


# ---------------------------------------------------------------------------
# 同比例手柄缩放（UNIFORM）—— 用户拍板 2026-09-17
#
# 语义：拖 3D 手柄 ⇒ **手柄变长/变短，而关键帧处的速度不变**
#       （= Graph Editor 里「以各自中心 + S 缩放」的等价物）。
#
# 数学（唯一实现在 `transform_domain.scale_handle_uniform` / `handle_scale_k`）：
#     手柄(3D) = (dv_x, dv_y, dv_z)；关键帧处速度 = |(dv_a / dt_a)|
#     dv、dt 同乘 k ⇒ 速度 = (k·|dv|)/(k·dt) = 原速度 ⇒ 不变 ✓
#
# ⚠️ k 必须用「值分量 3D 模长比」（整体 k），**不是**逐轴的 dv_a新/dv_a旧：
#    逐轴 k_a 在某个轴被拖到过零时会变负 / 除零 ⇒ dt 被钳到极小 ⇒ 速度爆炸
#    ⇒ 手柄「飞走 / 缩成一点锁死」（2026-09-17 实测踩坑，那条路已废弃）。
#    整体 k 对所有轴相同 ⇒ 手柄方向 ∝ dv 不变 ⇒ **始终与路径相切** ✓
# ---------------------------------------------------------------------------





def _mouse_world_ref(region, rv3d, local_mouse_pos, ref_point):
    """把【鼠标按下位置】投影成 3D 点，作为拖拽的**位移基准**。

    深度参考用 `ref_point`（关键帧 / 手柄末端的位置）⇒ 落在"过 ref_point 且
    垂直于视线"的平面上，与 modal 里
        `new_3d_pos = region_2d_to_location_3d(region, rv3d, 鼠标当前, _session.world_origin)`
    用的是**同一个平面**（因为 world_origin 就在该平面上）。

    ★ 为什么必须用鼠标位置当基准（2026-09-17 用户实测 bug）：
        `total_offset = new_3d_pos - world_origin`
      若 world_origin 取【关键帧位置】，第一次移动时
        `total_offset ≈ 鼠标位置 - 关键帧位置 ≈ 手柄向量`
      而写入是 `手柄 = 基线 + total_offset` ⇒ **手柄跳到 2 倍长度**。
      跳幅 ≈ 手柄长度 ⇒ 端点（0 长度）看不出、越长的柄跳得越狠
      （用户实测最长的 f25 右手柄 |dv|=10.55 最明显）。

      基准换成鼠标位置后：鼠标不动时 `total_offset = 0` ⇒ 按下不跳 ✓
      ⇒ 之后恒等于鼠标位移量 ⇒ **相对拖动、严格跟手**。

    拿不到 region/rv3d（如后台/异常）⇒ 退回 `ref_point`（= 旧行为，安全兜底）。
    """
    try:
        if region is None or rv3d is None or local_mouse_pos is None:
            return ref_point
        return view3d_utils.region_2d_to_location_3d(
            region, rv3d, mathutils.Vector(local_mouse_pos), ref_point)
    except Exception:
        return ref_point








class RTMP_OT_PathPointDrag(bpy.types.Operator):
    bl_idname = "rtmp.path_point_drag"
    bl_label = "Direct Motion Path Manipulation"
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    _mouse_pos = None
    _is_active = False
    _redraw_count = 0
    _last_frame = None
    
    # ======================================================================
    # 1. 生命周期（进入 / 退出）
    # ======================================================================
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._timer = None
        self._mouse_pos = None
        self._is_active = False
        self._redraw_count = 0
        self._last_frame = None
        self._last_draw_time = 0.0
        # ★★ 2026-09-18（性能修复）：**速度手柄拖拽**的节流时钟。
        #
        #   为什么要单独一个（不能复用 `_last_draw_time`）：
        #     速度拖拽分支在帧率限制**之前**就 `return` 了（用户 2026-09-18
        #     报"大幅高频拖动手柄 GPU 利用率快速升高"）⇒
        #        鼠标动多快就重绘多少次（高刷鼠标几百 Hz），
        #        每次都要重画一整屏（实测 4K 视口 = 540 万像素，3.87ms/次）。
        #     ⇒ 这里给它**同样的节流**，但用独立时钟（避免与路径点拖拽互相干扰）。
        self._last_speed_draw_time = 0.0
    
    
    # ======================================================================
    # 2. 事件处理（modal 按事件类型分派到 _ev_*）
    # ======================================================================
    # ======================================================================
    # ★★ 2026-09-27（架构）：`modal()` 原本是一个 **583 行**的事件处理巨函数，
    #   现拆成「一个分派器 + 以下 _ev_* 方法」。
    #
    #   拆的依据（先分析再动手，不是盲拆）：
    #     · 对每个分支做自由变量分析（loads - stores）——「需外部提供」的名字
    #       **全部是模块级全局**（`_session` / `td` / `FRAME_EPS` …），
    #       新方法在同一模块内同样可见 ⇒ 抽取**不需要额外传参**。
    #     · 唯一有跨语句生命周期的局部量 `area_to_redraw`，在**每个分支内部**
    #       各自赋值（实测 8 处）⇒ 整体搬走，语义不变。
    #     · 逻辑**逐字未改**，只有缩进从 12 空格降到 8 空格。
    #
    #   ⚠️ 验证手段：89 步 / 19 场景的状态快照逐位比对（`tests/_snapshot_*`）——
    #      这是「拆分前后行为完全一致」的硬证据。
    # ======================================================================
    def _ev_mousemove(self, context, event):
        """MOUSEMOVE 分支（由 modal() 拆分而来，逻辑逐字未改）。"""
        # ⚠️⚠️ 2026-09-17 修「拖三角时数值立刻打满 + 卡死」（真机日志定位）：
        #   旧代码用 `event.mouse_region_x/y` 当鼠标坐标喂给拖拽。
        #   但**鼠标不在任何 Blender 区域上时，这两个字段是 `-1`**！
        #   实测日志（用户真机复现）：
        #       PRESS 起点 last_mouse = [600, 800]（3D 视图局部坐标）
        #       第一次 MOUSEMOVE 的 mouse_region_* = [-1, -1]
        #       ⇒ dy_raw = -1 - 800 = **-801** ⇒ eff = -332
        #       ⇒ **s 立刻顶到上限（打满）**
        #       之后 last_mouse 恒为 (-1,-1) ⇒ dy=0 ⇒ **继续拖也不动（卡死）**
        #   （"动过 GE 手柄后更容易出现"：那时 s 已在边界附近，一点假位移就撞满。）
        #   ⇒ 坐标必须**与起点同源**（都用 3D 视图局部坐标），且拿到 `-1`
        #     这类哨兵值/B 区域外的坐标时**跳过本次**，宁可不动也不跳变。
        _loc = _speed_drag_mouse_local(context, event)
        if _loc is not None:
            self._mouse_pos = _loc

        # ---- 速度手柄拖拽（优先于路径点拖拽：这是在调疏密）----
        if _session.speed_drag_active:
            # 相对拖拽：三角固定，用鼠标位移增量驱动（不依赖三角屏幕坐标）
            # ③ 拖拽中按住 Shift = 精度模式（×0.1，增量法不跳变）
            # ★★★ 2026-09-18（性能修复）：**帧率限制** —— 本分支此前绕过了它。
            #
            #   用户报"大幅高频拖动手柄时 GPU 利用率快速升高"。实测根因：
            #     这个分支在帧率限制**之前**就 `return` 了（旧代码这里没节流）
            #     ⇒ 鼠标动多快就重写 + 重绘多少次。高刷鼠标 125~1000Hz，
            #       而每次都要重画一整屏（实测 4K 视口 540 万像素、3.87ms/次）
            #     ⇒ GPU 被"逼着反复重画一整屏"。
            #
            #   ⚠️⚠️ **节流之所以安全（务必看懂，否则会引入跳变）**：
            #     `_apply_speed_from_drag` 是**增量法** —— 位移 = 本次鼠标 −
            #     上次鼠标，且**只有真正写入时才把 last_mouse 更新成本次鼠标**。
            #     ⇒ 被跳过的事件**不丢位移**：下一次事件算出的 delta 会自动
            #       把跳过那段的位移**一并带上**（累积）。
            #     ⇒ 松手时**必须强制补最后一次**（见 RELEASE 分支），
            #       否则最后 ≤1 帧（默认 16ms）的位移会丢 —— 那就是跳变
            #       （用户的零容忍底线）。
            #
            #   ⚠️ Shift 精度模式走同一节流：它作用在**增量**上
            #      （函数内 `dy_raw * scale`），跳过的增量下次照样补 ⇒ 手感不变。
            _sp_target = 1.0 / max(1, addon_pref('max_interaction_fps', 60))
            _sp_now = time.time()
            if _loc is not None:
                # ★ 无论是否节流，都记住"最新鼠标位置" —— 松手时要用它
                #   补上被跳过的最后一段位移（见 `flush_pending_speed_drag`）。
                _session.speed_drag_pending_mouse = _loc
            if (_sp_now - self._last_speed_draw_time) < _sp_target:
                # 本帧跳过：**不更新 last_mouse**（位移留给下次一并计入）
                return {'PASS_THROUGH'}
            self._last_speed_draw_time = _sp_now
            _session.speed_drag_precision = bool(getattr(event, "shift", False))
            area0 = None
            region0, space0, local0, area0 = find_region_under_mouse(context, event)
            obj0 = _get_drag_obj(context)
            # ★ 只有拿到有效坐标才更新（否则保持上一次，避免 -1 造成的假位移）
            if _loc is not None:
                _apply_speed_from_drag(context, obj0, _loc)
            if region0 and space0:
                _update_speed_hover(context, obj0, region0, space0.region_3d, local0)
            a = area0 if area0 else context.area
            if a and a.type == 'VIEW_3D':
                a.tag_redraw()
            return {'PASS_THROUGH'}

        target_interval = 1.0 / max(1, addon_pref('max_interaction_fps', 60))
        current_time = time.time()
        if (current_time - self._last_draw_time) < target_interval:
            return {'PASS_THROUGH'}
        self._last_draw_time = current_time
            
        region, space_data, local_mouse_pos, target_area = find_region_under_mouse(context, event)
        if not region or not space_data:
            return {'PASS_THROUGH'}

        rv3d = space_data.region_3d

        if _session.drag_in_progress:
            mouse_coord = mathutils.Vector(local_mouse_pos)
            new_3d_pos = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse_coord, _session.world_origin)

            if _session.active_handle_direction is None:
                offset = new_3d_pos - _session.world_origin
                self.apply_point_offset(context, offset)
                _session.world_origin = new_3d_pos
            else:
                total_offset = new_3d_pos - _session.world_origin
                self.apply_handle_offset(context, total_offset, _session.active_handle_direction)

            try:
                refresh_position_store(context)
            except Exception:
                pass

            area_to_redraw = target_area if target_area else context.area
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()
                    
        elif _session.handle_edit_in_progress and _session.active_handle_index is not None:
            mouse_coord = mathutils.Vector(local_mouse_pos)
                
            new_3d_pos = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse_coord, _session.world_origin)
            total_offset = new_3d_pos - _session.world_origin
                
            if _session.active_handle_info:
                handle_point = _session.active_handle_info
                self.apply_handle_point_offset(context, total_offset, handle_point)
            elif _session.active_handle_index is not None and _session.active_handle_index < len(_session.handle_control_points):
                handle_point = _session.handle_control_points[_session.active_handle_index]
                self.apply_handle_point_offset(context, total_offset, handle_point)
                
            try:
                refresh_position_store(context)
            except Exception:
                pass

            area_to_redraw = target_area if target_area else context.area
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()

        else:
            # 空闲移动：刷新速度手柄的【悬停】显示（平时三角不出现）
            if not _session.drag_in_progress and not _session.handle_edit_in_progress:
                obj_h = _get_drag_obj(context)
                _update_speed_hover(context, obj_h, region, rv3d, local_mouse_pos)
                area_to_redraw = target_area if target_area else context.area
                if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                    area_to_redraw.tag_redraw()

        return {'PASS_THROUGH'}
    def _ev_rightmouse(self, context, event):
        """RIGHTMOUSE 分支（由 modal() 拆分而来，逻辑逐字未改）。"""
        if event.value == 'PRESS':
            region, space_data, local_mouse_pos, target_area = find_region_under_mouse(context, event)
            if not region or not space_data:
                return {'PASS_THROUGH'}
            rv3d = space_data.region_3d

            hit_point, hit_frame, hit_bone = self.locate_point_under_cursor(context, event, region, rv3d, local_mouse_pos)
            if hit_frame is not None:
                _session.active_path_point = hit_point
                _session.active_frame_number = hit_frame
                    
                if context.mode == 'POSE':
                    _session.active_bone_identifier = hit_bone.name if hit_bone else None
                else:
                    _session.active_bone_identifier = None
                    
                obj = _get_drag_obj(context)
                if obj and obj.animation_data and obj.animation_data.action:
                    action = obj.animation_data.action
                    bone_name = _session.active_bone_identifier if context.mode == 'POSE' else None
                        
                    hit_keyframe_already_selected = is_keyframe_selected(action, bone_name, hit_frame, obj)
                        
                    if not hit_keyframe_already_selected:
                        for fc in collect_animation_curves(action, obj):
                            for kp in fc.keyframe_points:
                                kp.select_control_point = False
                        
                    for fc in collect_animation_curves(action, obj):
                        if is_position_animation(fc, bone_name):
                            for kp in fc.keyframe_points:
                                if abs(kp.co[0] - hit_frame) < FRAME_EPS:
                                    kp.select_control_point = True
                                    break
                    
                area_to_redraw = target_area if target_area else context.area
                if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                    area_to_redraw.tag_redraw()
                    
                bpy.ops.wm.call_menu(name="RTMP_MT_context_menu")
                return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}
    # ======================================================================
    # ★★ 2026-09-27（架构）：`_ev_leftmouse()` 原本是一个 **383 行**的事件处理巨函数，
    #   现拆成「一个分派器 + 以下 _ev_* 方法」。
    #
    #   拆的依据（先分析再动手，不是盲拆）：
    #     · 对每个分支做自由变量分析（loads - stores）——「需外部提供」的名字
    #       **全部是模块级全局**（`_session` / `td` / `FRAME_EPS` …），
    #       新方法在同一模块内同样可见 ⇒ 抽取**不需要额外传参**。
    #     · 唯一有跨语句生命周期的局部量 `area_to_redraw`，在**每个分支内部**
    #       各自赋值（实测 8 处）⇒ 整体搬走，语义不变。
    #     · 逻辑**逐字未改**，只有缩进从 12 空格降到 8 空格。
    #
    #   ⚠️ 验证手段：89 步 / 19 场景的状态快照逐位比对（`tests/_snapshot_*`）——
    #      这是「拆分前后行为完全一致」的硬证据。
    # ======================================================================
    def _ev_left_press(self, context, event):
        """PRESS 分支（由 modal() 拆分而来，逻辑逐字未改）。   （原分支末尾没有 return，已补 `return {'PASS_THROUGH'}` —— 与 fall-through 等价）"""
        region, space_data, local_mouse_pos, target_area = find_region_under_mouse(context, event)
        if not region or not space_data:
            return {'PASS_THROUGH'}
        rv3d = space_data.region_3d
        area_to_redraw = target_area if target_area else context.area

        # ---- ① 速度三角命中（优先级最高）----
        obj_s = _get_drag_obj(context)
        s_handles = _update_speed_hover(context, obj_s, region, rv3d, local_mouse_pos)
        hit_tri = _triangle_under_cursor(s_handles, local_mouse_pos)
        if hit_tri is not None:
            # ★★ 2026-09-18（用户需求）：**双击三角 ⇒ 切换「一体 / 分离」**
            #    （v1.3.2 的双击是"复制对侧值"；现在升级为切换锁定，
            #      复制保留在"分离 → 锁回一体"那一步 —— 见 `toggle_frame_lock`）
            #    必须放在"选中 + 启动拖拽"**之前** —— 双击要优先于单选的拖拽启动。
            #    （判定/执行都抽在 `try_toggle_tri_lock_click` 里，可 headless 测试。）
            _consumed, _msg = try_toggle_tri_lock_click(
                context, obj_s, s_handles, local_mouse_pos, region, rv3d)
            if _consumed:
                if _msg:
                    self.report({'INFO'}, _msg)
                # 双击是"一次性动作"，不要顺势进入拖拽
                _session.speed_drag_active = False
                _session.speed_drag_pending_mouse = None
                if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                    area_to_redraw.tag_redraw()
                return {'RUNNING_MODAL'}

            # ★ 用户 2026-09-16：Shift+点击 = 多选（累加/取消）
            # ★★ 2026-09-18（用户需求）：**一体**状态下单击任一个三角
            #   ⇒ 两个一起选中；分离态只选单边。逻辑抽在模块级函数里
            #   （`apply_speed_click_selection`）⇒ headless 能测到真入口。
            _hit_frame = hit_tri['frame']
            _locked_here, _tris_here = apply_speed_click_selection(
                obj_s, s_handles, hit_tri, shift=bool(event.shift))
            _session.speed_drag_active = True
            # ★ 2026-09-17：超范围的 s 规范化只在【首次真正拖动】时发生
            #   （见 `_apply_speed_from_drag`）—— 这样"纯点击"不改动画。
            # ⚠️ 2026-09-27（复盘 P0-2）：这里原有一个
            #   `_session.speed_drag_normalized = False` 标志，但全仓**已无任何
            #   读取点**（该语义现在由"起点一律用 unclamped d"实现，见下面几行的
            #   说明）⇒ 确认是功能改写后的残留，已删。
            #   保留这段注释是为了让后人知道"这个标志存在过、为什么消失"。
            _session.speed_drag_precision = False
            # 每个选中的三角各自记录按下时的 d（多选一起滑移用）
            # ★★ 2026-09-19：起点一律用 **unclamped** d（保持可逆）。
            #   ① `h['d']` 是钳制版（`s_to_d`）—— 当 s 越过
            #      [S_EPS, S_HARD_MAX]（用户在 GE 里拖过手柄）时会丢信息
            #      ⇒ "一动就打满 / 拖不动"（2026-09-17 用户实测报告）。
            #   ② 必须是**按下时的固定起点**：`eff` 是【累积】位移，
            #      若每帧现读"当前值"再加累积位移 ⇒ **双重累加** ⇒ 拖久了
            #      指数漂移（用户零容忍的"跳变"）。实测抓到一次。
            _session.speed_drag_origins = {
                (h['frame'], h['tri']): td.s_to_d_unclamped(h.get('s'))
                for h in s_handles
                if _session.is_speed_handle_selected(h['frame'], h['tri'])}
            _session.speed_drag_origin_d = td.s_to_d_unclamped(hit_tri.get('s'))

            # ★★ 2026-09-18（用户拍板乙方案）：**一体拖动 = 一个旋钮**
            #   记录"共用的 s 基准"；两侧 span 不同 ⇒ 必须用数据层的 s，
            #   否则同一个像素位移会让两边速度分道扬镳（见 `td.group_drag_s`）。
            #   基准取**被点击那个三角**的 s（用户抓哪个就以哪个为准）。
            if (not event.shift and _locked_here
                    and _session.is_locked_pair_selected(_hit_frame)):
                _s0 = hit_tri.get('s')
                _session.speed_drag_group_origin_s = (
                    float(_s0) if _s0 is not None else None)
                _session.speed_drag_locked_frame = _hit_frame
            else:
                _session.speed_drag_group_origin_s = None
                _session.speed_drag_locked_frame = None
            _session.speed_drag_origin_mouse = local_mouse_pos
            # ★★ 2026-09-17：记下**按下时 3D 视图 region 的偏移**，
            #   供 `_speed_drag_mouse_local` 在鼠标拖出视图时换算坐标
            #   （保证拖拽全程坐标连续、不跳变）。
            _session.speed_drag_region = (float(region.x), float(region.y))
            # 增量累积的重置（精度模式用它算"此后"的位移）
            _session.speed_drag_effective_px = 0.0
            _session.speed_drag_last_mouse = local_mouse_pos
            _session.speed_drag_pending_mouse = local_mouse_pos
            # ★ 2026-09-18：节流时钟清零 —— 让**第一次移动立刻生效**
            #   （否则要在原地等满一帧，按下瞬间会感觉"迟钝"）。
            self._last_speed_draw_time = 0.0
            # 三角拖拽期间，不要同时拖路径点
            _session.drag_in_progress = False
            _session.handle_edit_in_progress = False
            _session.active_path_point = None
            _session.active_frame_number = None
            _session.active_handle_index = None
            _session.active_handle_info = None
            _update_speed_hover(context, obj_s, region, rv3d, local_mouse_pos)
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()
            return {'RUNNING_MODAL'}

        # 点空白处：清掉三角选中态
        if hit_tri is None and _session.selected_speed_handles:
            _session.clear_speed_handle()

        if not event.shift:
            _session.active_handle_index = None
            _session.active_handle_info = None
            _session.active_path_point = None
            _session.active_frame_number = None
                
        handle_index, handle_point = get_handle_at_cursor(context, event, region, rv3d, local_mouse_pos)
        # ★★★ 2026-10-02 跨类型仲裁（同一次用户反馈）：手柄末端 vs **关键帧点**。
        #
        #   两者的拾取盘**会重叠** —— 手柄可见长度落在 6~20px 这一档时必然重叠
        #   （6px 是「算零长度」的门槛，20px 是 HANDLE_SELECT_RADIUS）。
        #   而这里原先的规矩是「**手柄先判、命中就吃掉**」
        #   ⇒ 用户想点关键帧点，结果选到了手柄（「错选」）。
        #
        #   ⇒ 两边都命中时按「距离 ÷ 该目标的半径」比，谁更接近正中心谁赢；
        #     关键帧赢就把 handle_index 置空，让下面的关键帧分支接手。
        if handle_index is not None:
            try:
                _kf_pos, _kf_frame, _kf_bone = self.locate_point_under_cursor(
                    context, event, region, rv3d, local_mouse_pos)
            except Exception:
                _kf_pos, _kf_frame, _kf_bone = None, None, None
            if _kf_frame is not None and _kf_pos is not None:
                _sp_kf = view3d_utils.location_3d_to_region_2d(region, rv3d, _kf_pos)
                # ⚠️ 必须走统一入口：hollow 记录**没有 `position`**（实测 KeyError 崩过）
                _sp_hd = handle_screen_pos(handle_point, region, rv3d)
                if _sp_kf is not None and _sp_hd is not None:
                    _mp = (mathutils.Vector(local_mouse_pos) if local_mouse_pos
                           else mathutils.Vector((event.mouse_region_x, event.mouse_region_y)))
                    _d_kf = (_mp - _sp_kf).length
                    _d_hd = (_mp - _sp_hd).length
                    _steal = handle_loses_to_keyframe(handle_point, _d_kf, _d_hd)
                    # ★ 判据抽在 `handle_loses_to_keyframe`（**唯一来源**，可单测）
                    if _steal:
                        handle_index, handle_point = None, None
        if handle_index is not None:
            # ★★ 用户 2026-09-16：端点可【单独选中】。
            #     原生曲线编辑里，控制点与手柄是各自独立的可变换对象；
            #     所以点端点时【不再】顺带选中关键帧点，
            #     否则 RGS 会作用到关键帧点而不是端点。
            hf = handle_point.get('frame')
            hs = handle_point.get('side')
            if hf is not None and hs is not None:
                if event.shift:
                    _session.toggle_endpoint(hf, hs)
                else:
                    _session.clear_endpoints()
                    _session.toggle_endpoint(hf, hs)
                # 端点选中 → 清掉关键帧点的选中（两者互斥，与原生一致）
                obj_e = _get_drag_obj(context)
                if obj_e and obj_e.animation_data and obj_e.animation_data.action:
                    for fc in collect_animation_curves(obj_e.animation_data.action, obj_e):
                        for kp in fc.keyframe_points:
                            kp.select_control_point = False
                _session.active_frame_number = None
                _session.active_path_point = None
            _session.active_handle_index = handle_index
            _session.active_handle_info = handle_point
            _session.handle_edit_in_progress = True
            # ★★ 位移基准 = 【鼠标按下位置的 3D 投影】，不是手柄末端。
            #    原来写的是 `handle_point['position']`（手柄末端）：虽然端点为
            #    0 长度时它≈关键帧、看不出问题，但语义上仍是"绝对参考"——
            #    鼠标没按在末端正中就会让第一次移动带上一个非零位移。
            #    统一成鼠标基准后，`total_offset` 恒等于**鼠标位移量** ⇒ 严格跟手。
            # ⚠️ 走统一入口：hollow 记录没有 `position` ⇒ 退回该关键帧的世界坐标
            #    （实测：直接读 `['position']` 会让点击整条路 KeyError 崩掉）
            _hp_world = handle_world_pos(handle_point)
            _session.world_origin = _mouse_world_ref(
                region, rv3d, local_mouse_pos, _hp_world)
            _session.item_initial_pos = _hp_world
            _session.mouse_origin = local_mouse_pos
                    
            hp_obj_name = handle_point.get('obj_name')
            _session.drag_target_object = hp_obj_name or None
                    
            self.record_handle_baseline(context, handle_point['frame'], handle_point.get('bone_name'), handle_point['side'])
                    
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()
            return {'RUNNING_MODAL'}

        # 没点中端点 → 清掉端点选中（Shift 时保留，便于累加）
        if not event.shift:
            _session.clear_endpoints()

        hit_side, hit_handle_pos, hit_frame, point_3d, hit_bone = self.locate_handle_under_cursor(context, event, region, rv3d, local_mouse_pos)
        if hit_frame is not None:
            _session.active_path_point = point_3d
            _session.active_frame_number = hit_frame
            _session.active_handle_direction = hit_side
            # ★★★ 2026-09-17（用户实测："拖出结尾帧手柄后，再拖上一个关键帧的
            #     右手柄会跳变，其他手柄没这情况"）——**真因在这里**。
            #
            #   `point_3d` 是【关键帧位置】（已核实 cached_positions 与之逐位一致），
            #   而 modal 里 `total_offset = new_3d_pos - world_origin`。
            #   于是第一次移动时：
            #       total_offset ≈ (鼠标位置 - 关键帧位置) ≈ 手柄向量
            #   而写入是 `手柄 = 基线 + total_offset`
            #       ⇒ 手柄 ≈ 2 × 手柄向量  ⇒ **跳到 2 倍长度**
            #
            #   ⇒ **跳幅 ≈ 手柄长度**：端点（0 长度）看不出；越长的柄跳得越狠
            #     （用户实测最长的 f25 右手柄 |dv|=10.55 跳得最明显）。
            #
            #   修法：基准取【鼠标按下位置的 3D 投影】（深度用关键帧位置所在的
            #   平面 ⇒ 与后续 `region_2d_to_location_3d(..., world_origin)` 同平面）。
            #   ⇒ `total_offset` 恒等于鼠标位移量 ⇒ 相对拖动、永不跳。
            _session.world_origin = _mouse_world_ref(
                region, rv3d, local_mouse_pos, point_3d)
            _session.item_initial_pos = hit_handle_pos
            _session.mouse_origin = local_mouse_pos
                    
            self.record_handle_baseline(context, hit_frame, hit_bone.name if hit_bone else None, hit_side)
                    
            if context.mode == 'POSE':
                _session.active_bone_identifier = hit_bone.name if hit_bone else None
            else:
                _session.active_bone_identifier = None
                    
            obj = _get_drag_obj(context)
            if obj and obj.animation_data and obj.animation_data.action:
                action = obj.animation_data.action
                bone_name = _session.active_bone_identifier if context.mode == 'POSE' else None
                        
                for fc in collect_animation_curves(action, obj):
                    if is_position_animation(fc, bone_name):
                        for kp in fc.keyframe_points:
                            if abs(kp.co[0] - hit_frame) < FRAME_EPS:
                                kp.select_control_point = True
                                break
                    
            _session.drag_in_progress = True
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()
            return {'RUNNING_MODAL'}
                
        hit_point, hit_frame, hit_bone = self.locate_point_under_cursor(context, event, region, rv3d, local_mouse_pos)
        if hit_frame is not None:
            _session.active_path_point = hit_point
            _session.active_frame_number = hit_frame
            _session.active_handle_direction = None  
            _session.world_origin = hit_point
            _session.item_initial_pos = hit_point
            _session.mouse_origin = local_mouse_pos
                    
            if context.mode == 'POSE':
                _session.active_bone_identifier = hit_bone.name if hit_bone else None
            else:
                _session.active_bone_identifier = None
                    
            obj = _get_drag_obj(context)
            if obj and obj.animation_data and obj.animation_data.action:
                action = obj.animation_data.action
                bone_name = _session.active_bone_identifier if context.mode == 'POSE' else None
                        
                hit_keyframe_already_selected = is_keyframe_selected(action, bone_name, hit_frame, obj)
                        
                if not hit_keyframe_already_selected and not event.shift and not event.ctrl:
                    for fc in collect_animation_curves(action, obj):
                        for kp in fc.keyframe_points:
                            kp.select_control_point = False
                        
                if event.ctrl:
                    kf_frame_set = []
                    for fc in collect_animation_curves(action, obj):
                        if is_position_animation(fc, bone_name):
                            for kp in fc.keyframe_points:
                                if kp.select_control_point:
                                    kf_frame_set.append(kp.co[0])
                    kf_frame_set.append(hit_frame)
                    if len(kf_frame_set) >= 2:
                        min_f = min(kf_frame_set)
                        max_f = max(kf_frame_set)
                        for fc in collect_animation_curves(action, obj):
                            if is_position_animation(fc, bone_name):
                                for kp in fc.keyframe_points:
                                    if min_f <= kp.co[0] <= max_f:
                                        kp.select_control_point = True
                else:
                    # ⚠️ 吸附到【最近的关键帧】：
                    #    路径点有 40 个（每帧一个），关键帧可能只有 4 个。
                    #    原来只在 hit_frame 恰好等于关键帧帧号时才选中
                    #    → 点其它采样点"什么都没选中" → 按 R/S 无反应（实测确认）。
                    pick_f = _nearest_keyframe_frame(action, obj, hit_frame, bone_name)
                    if pick_f is None:
                        pick_f = hit_frame
                    for fc in collect_animation_curves(action, obj):
                        if is_position_animation(fc, bone_name):
                            for kp in fc.keyframe_points:
                                if abs(kp.co[0] - pick_f) < FRAME_EPS:
                                    kp.select_control_point = True
                                    break
                    _session.active_frame_number = pick_f
                    
            _session.drag_in_progress = True
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()
            return {'RUNNING_MODAL'}
                
        if context.mode == 'POSE':
            obj = context.active_object
            if obj and obj.animation_data and obj.animation_data.action:
                action = obj.animation_data.action
                obj_cache = _session.cached_positions.get(obj.name, {})
                for bone_name in obj_cache.keys():
                    for fc in collect_animation_curves(action, obj):
                        if is_position_animation(fc, bone_name):
                            for kp in fc.keyframe_points:
                                kp.select_control_point = False
        else:
            for obj_name in _session.cached_positions.keys():
                obj = bpy.data.objects.get(obj_name)
                if obj and obj.animation_data and obj.animation_data.action:
                    action = obj.animation_data.action
                    for fc in collect_animation_curves(action, obj):
                        for kp in fc.keyframe_points:
                            kp.select_control_point = False
                
        if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
            area_to_redraw.tag_redraw()
        return {'PASS_THROUGH'}
    def _ev_left_release(self, context, event):
        """RELEASE 分支（由 modal() 拆分而来，逻辑逐字未改）。   （原分支末尾没有 return，已补 `return {'PASS_THROUGH'}` —— 与 fall-through 等价）"""
        # ---- 速度三角拖拽结束：提交，但【保留选中】（可继续拖 / 按 J 进模态）----
        if _session.speed_drag_active:
            # ★★★ 2026-09-18（性能修复配套）：**松手前补上被节流跳过的
            #   最后一段位移** —— 否则最后 ≤1 帧的位移会丢（= 跳变）。
            #   必须在 `speed_drag_active = False` **之前**做，
            #   因为补写函数靠这个标志判断"拖拽还在进行"。
            #
            # ★★★ 2026-09-27（既有报告 P0-1）：**复位提到 undo_push 之前，
            #   且 undo_push 包 try**。原顺序是"先 undo_push、后复位"，
            #   而 undo_push 裸调用无保护 —— 没有撤销上下文时它抛异常
            #   ⇒ 后面的复位语句**永远执行不到** ⇒ `speed_drag_active`
            #   永久 True ⇒ "三角粘着鼠标走"（用户报过的那类"甩不掉"）。
            #   （同文件 `toggle_frame_lock` 那两处早就有 try，这三处漏了。）
            #   ⚠️ 两条顺序要求同时成立：flush 在复位前、undo_push 在复位后。
            _wrote = bool(getattr(_session, "speed_drag_wrote", False))
            _flushed = flush_pending_speed_drag(context, _get_drag_obj(context))
            _session.speed_drag_active = False
            _session.speed_drag_pending_mouse = None
            _session.speed_drag_wrote = False
            # ★★★ 2026-09-27（3d）：**没有真正写入就不推 undo**。
            #   原先无条件推 ⇒ 只单击选中一个三角（手指根本没动）
            #   也会在撤销栈里留下一步"什么都没变"——
            #   用户按 Ctrl+Z 看到"撤销了一次但画面没反应"，
            #   而且它会把真正有用的那一步往后挤。
            #   ⚠️ `_flushed` 也要算进来：它可能补写了被节流跳过的位移。
            if _wrote or _flushed:
                try:
                    bpy.ops.ed.undo_push(message=iface_("Adjust Motion Path Speed"))
                except Exception:
                    pass
            try:
                refresh_position_store(context)
            except Exception:
                pass
            _, _, _, rel_area = find_region_under_mouse(context, event)
            a = rel_area if rel_area else context.area
            if a and a.type == 'VIEW_3D':
                a.tag_redraw()
            return {'RUNNING_MODAL'}

        if _session.drag_in_progress:
            # ★★★ 2026-09-27（既有报告 P0-1）：复位提到 undo_push **之前**，
            #   且 undo_push 包 try。原顺序下 undo_push 一旦抛异常，
            #   下面四行复位**全部执行不到** ⇒ `drag_in_progress` 永久 True
            #   ⇒ **路径点粘着鼠标走**（用户报过的那类"甩不掉"）。
            _session.drag_in_progress = False
            _session.active_handle_direction = None
            _session.item_initial_pos = None
            _session.drag_target_object = None
            try:
                bpy.ops.ed.undo_push(message=iface_("Move Motion Path Points"))
            except Exception:
                pass
            # ⚠️ 这里【不再】清 active_path_point / active_frame_number：
            #    用户要求路径点有"选中状态" —— 松开鼠标后仍保持选中，
            #    之后可以按 G/J 等进入模态继续操作。
                    
            try:
                refresh_position_store(context)
            except Exception:
                pass
                    
            _, _, _, release_area = find_region_under_mouse(context, event)
            area_to_redraw = release_area if release_area else context.area
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()
            return {'RUNNING_MODAL'}
        elif _session.handle_edit_in_progress:
            # ★★★ 2026-09-27（既有报告 P0-1）：同上 —— 复位在前、undo 包 try。
            #   原顺序下 undo_push 抛异常 ⇒ `handle_edit_in_progress`
            #   永久 True ⇒ **手柄粘着鼠标走**。
            _session.handle_edit_in_progress = False
            try:
                bpy.ops.ed.undo_push(message=iface_("Move Motion Path Handle"))
            except Exception:
                pass
            # ⚠️ 这里【不再】清 active_handle_index：
            #    用户要求手柄端点有"选中状态" —— 松开鼠标后保持选中，
            #    之后可以继续拖 / 进入模态操作。
            #    （原来清了它，导致高亮条件 handle_edit_in_progress 变 False，
            #     选中态立即消失，正是用户报告的"松开就取消选中"。）
            _session.item_initial_pos = None
            _session.drag_target_object = None
                    
            try:
                refresh_position_store(context)
            except Exception:
                pass
                    
            _, _, _, release_area = find_region_under_mouse(context, event)
            area_to_redraw = release_area if release_area else context.area
            if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                area_to_redraw.tag_redraw()
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}
    def _ev_leftmouse(self, context, event):
        """LEFTMOUSE 分支（由 modal() 拆分而来，逻辑逐字未改）。   （原分支末尾没有 return，已补 `return {'PASS_THROUGH'}` —— 与 fall-through 等价）"""
        if event.value == 'PRESS':
            return self._ev_left_press(context, event)
                    
        elif event.value == 'RELEASE':
            return self._ev_left_release(context, event)
        return {'PASS_THROUGH'}
    # ======================================================================
    # 3. 操作符入口（invoke / modal / cancel）
    # ======================================================================
    def modal(self, context, event):
        global _session

        wm = context.window_manager
        # ⚠️ 2026-09-27：getattr 守卫 —— 这个**常驻** modal 在插件卸载后
        #    仍可能收到下一个事件，而那时 `rtmp_edit_mode_active` 已被 `del`
        #    ⇒ 裸访问会从 modal 里抛 AttributeError。
        #    取不到 ⇒ 当作"已关闭" ⇒ 走 cancel 清理（这正是想要的行为）。
        if not getattr(wm, "rtmp_edit_mode_active", False) or not self._is_active:
            return self.cancel(context)
        
        if event.type == 'MOUSEMOVE':
            return self._ev_mousemove(context, event)
        
        elif event.type == 'RIGHTMOUSE':
            return self._ev_rightmouse(context, event)

        elif event.type == 'LEFTMOUSE':
            return self._ev_leftmouse(context, event)
        
        elif event.type == 'BACK_SPACE' and event.value == 'PRESS':
            # ★ 用户 2026-09-16：光标悬停在速度三角上时按 Backspace = 恢复该三角的默认速度。
            #   逻辑在 `try_reset_hovered_speed`（抽出来是为了可 headless 测试）。
            if try_reset_hovered_speed(context, event):
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        elif event.type == 'ESC':
            return {'PASS_THROUGH'}
        
        elif event.type == 'TIMER':
            if context.area and context.area.type == 'VIEW_3D':
                context.area.tag_redraw()
            return {'PASS_THROUGH'}
        
        return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        # context.area 在非区域上下文（timer 回调、后台运行、全局脚本）中为 None，
        # 直接访问 .type 会抛 AttributeError。与 cancel()/modal() 的写法保持一致。
        if context.area and context.area.type == 'VIEW_3D':
            refresh_position_store(context)
            self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
            context.window_manager.modal_handler_add(self)
            self._is_active = True
            attach_render_callback()
            # 覆盖层（速度手柄三角 + 轴约束线）；平时不显示任何手柄
            _session.clear_speed_handle()
            # 双击链也要清（否则上次会话残留的"上次点击"可能凑成一次假双击）
            clear_speed_click_chain()
            if _ov is not None:
                o = _ov.get_overlay()
                o.start(session=None)
                # ⚠️ 显式传 hollow=[]：这是「全清」语义，环也必须一起清
                #    （默认 None = 别动它 ⇒ 环会残留，code review 2026-10-02）
                o.set_handles([], None, dragging=False, hollow=[])
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, iface_("View3D not found, cannot run operator"))
            return {'CANCELLED'}

    def cancel(self, context):
        global _session
        
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        
        # ⚠️⚠️ 顺序关键（2026-09-27 修）：detach 必须在 reset 【之前】。
        #
        #   `_session.reset()` → `_initialize_defaults()` 会把
        #   `render_callback_id` 清成 None；而 `detach_render_callback()`
        #   正是靠这个字段找句柄 ⇒ 顺序反了它读到 None 就**直接 return**，
        #   C 侧注册表里的绘制回调纹丝不动。
        #
        #   后果：每开关一次「直接编辑模式」就攒一个回调；再打开时
        #   `attach_render_callback()` 见句柄是 None 又注册一个
        #   ⇒ N 个回调同时画同一份路径（越开关越浓、重绘耗时 ×N）。
        #
        #   这正是"开关插件开关后绘制残留"那条修复**没真正生效**的原因：
        #   `unregister()` 路径是对的（那里没先 reset），cancel 路径漏了。
        #   兜底的 `purge_stale_draw_handlers` 也救不回来 —— 它读的是同一个
        #   已被清空的字段。
        detach_render_callback()
        _session.reset()
        self._is_active = False
        # 撤掉覆盖层 draw handler（否则泄漏）
        if _ov is not None:
            _ov.get_overlay().stop()
        
        if context.area:
            context.area.tag_redraw()
        
        return {'CANCELLED'}
    
    # ======================================================================
    # 4. 变换应用（路径点 / 手柄偏移）
    # ======================================================================
    def apply_point_offset(self, context, offset):
        if not all(math.isfinite(c) and abs(c) < SAFE_LIMIT for c in offset):
            return

        obj = _get_drag_obj(context)
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        action = obj.animation_data.action
        bone_name = _session.active_bone_identifier if (obj and obj.mode == 'POSE') else None
        bone = (obj.pose.bones.get(bone_name) if (bone_name and obj.mode == 'POSE' and obj.pose) else None)
        
        parent_matrix = resolve_parent_transform(obj, bone)
        parent_rot_inv = parent_matrix.to_3x3().inverted()
        
        local_kf_delta = parent_rot_inv @ offset
        
        kf_frame_set = set()
        for fcurve in collect_animation_curves(action, obj):
            if 'location' not in fcurve.data_path:
                continue
            if bone_name and not is_position_animation(fcurve, bone_name):
                continue
            for kp in fcurve.keyframe_points:
                if kp.select_control_point:
                    kf_frame_set.add(int(kp.co[0]))
        
        for frame in kf_frame_set:
            for fcurve in collect_animation_curves(action, obj):
                if 'location' not in fcurve.data_path:
                    continue
                if bone_name and not is_position_animation(fcurve, bone_name):
                    continue
                
                axis = fcurve.array_index
                for kp in fcurve.keyframe_points:
                    if abs(kp.co[0] - frame) < FRAME_EPS:
                        kp.co[1] += local_kf_delta[axis]
                        kp.handle_left[1] += local_kf_delta[axis]
                        kp.handle_right[1] += local_kf_delta[axis]
                        break
        
        for fcurve in collect_animation_curves(action, obj):
            if 'location' in fcurve.data_path and (not bone_name or is_position_animation(fcurve, bone_name)):
                fcurve.update()
    
    def apply_handle_offset(self, context, total_offset_world, side):
        if not all(math.isfinite(c) and abs(c) < SAFE_LIMIT for c in total_offset_world):
            return

        obj = _get_drag_obj(context)
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        action = obj.animation_data.action
        frame = _session.active_frame_number
        global_scale = context.window_manager.rtmp_handle_scale
        bone_name = _session.active_bone_identifier if (obj and obj.mode == 'POSE') else None
        bone = (obj.pose.bones.get(bone_name) if (bone_name and obj.mode == 'POSE' and obj.pose) else None)
        
        parent_matrix = resolve_parent_transform(obj, bone)
        rotation_matrix = parent_matrix.to_3x3()
        
        total_offset_local = rotation_matrix.inverted() @ total_offset_world
        total_offset_local_scaled = total_offset_local / global_scale

        # ★ 多端点一起拖拽（用户 2026-09-16）
        #   之前只处理 `active_frame_number` 那一个端点；
        #   现在把同一个位移应用到【所有选中的端点】。
        eps_sel = list(getattr(_session, "selected_handle_endpoints", None) or [])
        targets = [(f, s) for (f, s) in eps_sel] if eps_sel else []
        if not targets and _session.active_frame_number is not None:
            targets = [(_session.active_frame_number,
                        _session.active_handle_direction or 'right')]

        for (tf, tside) in targets:
            self._apply_one_handle_offset(
                obj, action, tf, tside, total_offset_local_scaled,
                global_scale, bone_name, rotation_matrix, context=context)
        return


    
    # ======================================================================
    # 5. 手柄偏移收尾 + 快照
    # ======================================================================

    


    # ======================================================================
    # 6. 命中检测（拾取鼠标下的目标）
    # ======================================================================

    # ======================================================================
    # 转发层：以下方法的【实现】已搬到 edit_geometry.py（纯计算，不碰 self）
    #
    #   为什么保留同名转发：类内调用点 + tests/ 里 39 处既有调用**一个字都不用改**。
    #   它们是纯计算（不读任何 self._属性），所以只是换个地方住。
    # ======================================================================

    def _apply_one_handle_offset(self, obj, action, frame, side, total_offset_local_scaled, global_scale, bone_name, rotation_matrix, context=None):
        return eg._apply_one_handle_offset(obj, action, frame, side, total_offset_local_scaled, global_scale, bone_name, rotation_matrix, context)

    def apply_handle_point_offset(self, context, total_offset_world, handle_point):
        return eg.apply_handle_point_offset(context, total_offset_world, handle_point)

    def finish_linked_handle(self, action, obj, frame, side, bone_name, context=None, zero_eps=None):
        return eg.finish_linked_handle(action, obj, frame, side, bone_name, context, zero_eps)

    def locate_handle_under_cursor(self, context, event, region=None, rv3d=None, local_mouse_pos=None):
        return eg.locate_handle_under_cursor(context, event, region, rv3d, local_mouse_pos)

    def locate_point_under_cursor(self, context, event, region=None, rv3d=None, local_mouse_pos=None):
        return eg.locate_point_under_cursor(context, event, region, rv3d, local_mouse_pos)

    def prepare_handles_for_edit(self, frame_kf_map):
        return eg.prepare_handles_for_edit(frame_kf_map)

    def record_endpoint_snapshot(self, action, obj, frame_num, handle_side, bone_name):
        return eg.record_endpoint_snapshot(action, obj, frame_num, handle_side, bone_name)

    def record_handle_baseline(self, context, frame_num, selected_bone_name, handle_side):
        return eg.record_handle_baseline(context, frame_num, selected_bone_name, handle_side)

    def resolve_handle_anchor_pos(self, context, handle_point):
        return eg.resolve_handle_anchor_pos(context, handle_point)

    def update_linked_handle(self, keyframe, moved_handle_side, handle_vector_local, array_index):
        return eg.update_linked_handle(keyframe, moved_handle_side, handle_vector_local, array_index)


    


def handle_loses_to_keyframe(handle_point, d_kf, d_hd):
    """跨类型仲裁的**唯一判据**：这个手柄/抓取环该不该让给「关键帧侧」。

    ★★ 2026-10-02（用户：「有时还是很容易误触变成拖动关键帧」）：
       抓取环**只让给真正的关键帧**，而且要求"真的很近"。

       ⚠️ 为什么不能按"归一化距离谁小谁赢"：
          `locate_point_under_cursor` 命中的**不只是关键帧**，还包括
          **运动路径的采样点**（每帧一个）。端点附近这些点非常密
          （对象每帧几乎不动）⇒ 离鼠标常常比抓取环还近
          ⇒ 按距离比就把点击判给了"关键帧侧" ⇒ 变成拖关键帧/路径点。

       ⇒ 抓取环改用本仓库已有的那条规矩（`KEYFRAME_PICK_PRIORITY_RADIUS`，
         三角那边同款语义）：**离关键帧 14px 以内**才算"你要的是关键帧"，
         其余一律归抓取环 —— 它是抓手柄的**唯一入口**，
         而关键帧/路径点还有别的选法。

    :param d_kf: 鼠标到「关键帧侧命中点」的屏幕距离（像素）
    :param d_hd: 鼠标到该手柄/抓取环的屏幕距离（像素）
    """
    try:
        if handle_point.get('hollow'):
            # ★★★ 抓取环【永远不让位】。
            #
            #   为什么可以这么硬（2026-10-02 实测确认）：
            #     环心离自己的关键帧**恒为** `drawing.ENDPOINT_PICK_OFFSET_PX`(32px)
            #     （搬进 2D 层后偏移是精确的，实测 [32.0, 0.0]），
            #     而关键帧盘 20 + 环盘 12 = 32 ⇒ **两盘正好相切、永不重叠**。
            #     ⇒ 鼠标只要落在环盘里，就离关键帧 ≥20px，用户的意思**必然是环**。
            #
            #   ⚠️ 之前那版写的是 `d_kf <= 14 就让位`，**实测仍会误触**：
            #      `locate_point_under_cursor` 命中的**不只是关键帧**，
            #      还有**运动路径的采样点**（每帧一个）。采样点常常就压在鼠标底下
            #      ⇒ `d_kf ≈ 0` ⇒ 环被判让位 ⇒ 又变成拖关键帧/路径点。
            #
            #   ⚠️ 若将来 `ENDPOINT_PICK_OFFSET_PX` 被调小到 < 32，两盘就会重叠，
            #      这条"永不让位"必须重新评估（届时要拿**自己的关键帧**算距离，
            #      而不是拿 `locate_point_under_cursor` 的返回值）。
            return False
        # 普通手柄末端：维持"归一化距离"（大盘 vs 大盘，公平比）
        return (d_kf / float(HANDLE_SELECT_RADIUS)

                <= d_hd / float(HANDLE_SELECT_RADIUS))
    except Exception:
        return False


def handle_screen_pos(handle_point, region, rv3d):
    """手柄/抓取环在屏幕上的位置（像素）。**唯一入口** —— 两类记录都走它。

    ★★ 2026-10-02：抓取环（hollow）搬进 2D 层后**没有 `position`**（世界坐标），
       位置必须现算（`overlay.endpoint_ring_screen_pos`）。
       ⚠️ 直接写 `handle_point['position']` 会 **KeyError** ——
          实测踩过：`_ev_left_press` 的跨类型仲裁就这么把点击崩掉的。
       ⇒ 全仓读「手柄屏幕位置」**只准走这里**，别再各写一份。
    """
    try:
        if handle_point.get('hollow'):
            from . import overlay as _ov
            sp = _ov.endpoint_ring_screen_pos(handle_point, region, rv3d)
            return None if sp is None else mathutils.Vector(sp)
        return view3d_utils.location_3d_to_region_2d(
            region, rv3d, handle_point['position'])
    except Exception:
        return None


def handle_world_pos(handle_point):
    """手柄/抓取环对应的**世界坐标**（拖拽基准用）。

    ★ 2026-10-02：hollow 记录没有 `position` ⇒ 退回**该关键帧的世界坐标**
      （环本来就画在关键帧旁边 32px，语义上关键帧就是它的锚点）。
    """
    try:
        p = handle_point.get('position')
        if p is not None:
            return p
        if handle_point.get('hollow'):
            from . import overlay as _ov
            w = _ov._keyframe_world_now(handle_point)
            if w is not None:
                return w
            # ★ 兜底（code review 2026-10-02）：对象/action 已不在时退回**缓存**里的
            #   该帧位置 —— 与 `edit_geometry.resolve_handle_anchor_pos` 同源。
            #   ⚠️ 不能让本函数返回 None：旧代码读的 `position` **永远存在**，
            #      换成"可能 None"会让拖拽基准变成 None ⇒ 模态里崩。
            try:
                return _session.cached_positions[handle_point.get('obj_name')][None][handle_point.get('frame')]['position']
            except Exception:
                return None
        return None
    except Exception:
        return None


def get_handle_at_cursor(context, event, region=None, rv3d=None, local_mouse_pos=None):
    global _session
    
    if not region or not rv3d:
        if not context.space_data or context.space_data.type != 'VIEW_3D':
            return None, None
        region = context.region
        rv3d = context.space_data.region_3d

    if local_mouse_pos:
        mouse_pos = mathutils.Vector(local_mouse_pos)
    else:
        mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
    
    # ★★★ 2026-10-02（用户反馈「有时会选不中，或者错选」）：从「**谁先遍历到谁赢**」
    #   改成「**归一化距离**最近者胜」。
    #
    #   ▎旧写法的问题
    #       for i, hp in enumerate(_session.handle_control_points):
    #           if 距离 < 半径: return i, hp          ← 第一个命中就返回
    #       `handle_control_points` 的顺序 = **每帧重绘的收集顺序**
    #       （哪根骨骼先、哪一侧先、选中了几个端点……）
    #       ⇒ **同一个鼠标位置，选中数量一变，命中结果就变** ⇒ 用户感受就是「错选」。
    #
    #   ▎为什么用「距离 ÷ 半径」而不是「距离」
    #       抓取环的盘是 12px、手柄末端是 20px。只比距离 ⇒ 小盘永远抢不过大盘，
    #       用户瞄得再准也没用。除以半径 = 「谁更接近自己的正中心」，大小盘公平竞争。
    #   ▎平手（比值相同）时：**半径小的优先**（更精确的目标赢）。
    #
    #   ⚠️ 与 `edit_geometry.locate_point_under_cursor`（本来就是最近者胜）口径一致 ——
    #      不要再退回「先到先得」。
    #
    #   ⚠️ 空心圆抓取点仍用【更小】的独立半径（`state.HANDLE_HOLLOW_PICK_RADIUS`）：
    #      若它也吃 20px，则圆心距 = `drawing.ENDPOINT_PICK_OFFSET_PX`(32) < 20 + 20
    #      ⇒ 两盘必然重叠 ⇒ 点关键帧盘内会被手柄抢走（code review 2026-09-17 实测）。
    #      ★ 反过来也**不要**把偏移拉到 40 去「留缝」—— 那会在 [20, 28] 造出
    #        8px **死区**（两个盘都不认），正是本次要消灭的「选不中」。
    #        20 + 12 = 32 正好铺满，配合最近者胜 ⇒ 每个像素恰好归属一个目标 ✓
    # ★★★ 2026-10-02：抓取环的位置**现算**（与绘制同一个函数），不再读 `position`。
    #   旧做法读的是"反投影出来的世界坐标"，实测那趟往返不闭合（差 10 像素）
    #   ⇒ 画的和点的对不上 ⇒ 选不中/误触；多视口时还会串坐标。
    #   ⚠️ `endpoint_ring_screen_pos` 必须传**鼠标所在视口**的 region/rv3d。
    try:
        from . import overlay as _ov
    except Exception:
        _ov = None
    best = None
    for i, handle_point in enumerate(_session.handle_control_points):
        screen_pos = handle_screen_pos(handle_point, region, rv3d)
        if not screen_pos:
            continue
        radius = HANDLE_HOLLOW_PICK_RADIUS if handle_point.get('hollow') else HANDLE_SELECT_RADIUS
        dist = (mouse_pos - screen_pos).length
        if dist >= radius:
            continue
        score = dist / float(radius)
        key = (score, float(radius))
        if best is None or key < best[0]:
            best = (key, i, handle_point)
    if best is None:
        return None, None
    return best[1], best[2]


def is_keyframe_selected(action, bone_name, frame, obj=None):
    for fc in collect_animation_curves(action, obj):
        if is_position_animation(fc, bone_name):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < FRAME_EPS:
                    return kp.select_control_point
    return False


def _xf_mod():
    """惰性拿 transform_domain 模块（避免顶层循环导入）。

    ⚠️ 2026-09-27：删掉原来的 `except Exception: import transform_domain as xf`
       兜底 —— 那是**必然失败**的一行。本模块是包内模块（顶层
       `interaction.py:18` 已 `from . import transform_domain`），
       而 `import transform_domain`（无点）在 Blender 的包加载环境下找不到，
       只会再抛一次 ImportError。

       它的真实危害不是"多此一举"，而是：异常会穿透到**菜单绘制**
       （`ui.RTMP_MT_context_menu.draw` → `current_feel_label` → 这里）
       ⇒ `draw()` 中断 ⇒ **后面的菜单项全不渲染**
       （症状：菜单项数随数据变化 —— 这正是 2026-09-17 修过的那类 bug 的形态）。
    """
    from . import transform_domain as xf
    return xf


def current_feel_label(context):
    """返回选中关键帧的【体感手柄类型】标签（供右键菜单显示/高亮）。

    ★ 方案 A：体感类型是权威数据。返回：
        'LINK' / 'VECTOR' / 'FREE'  —— 选中帧体感一致时
        None                        —— 没选中 / 混合 / 未记录（透传原始类型）
    """
    # ⚠️ 2026-09-27：改用 `_xf_mod()`（唯一入口），不再抄第二份惰性导入 ——
    #    同一段"惰性拿模块"在本文件里写了两遍，其中一遍（无点 import）
    #    是必然失败的，而且失败会穿透到菜单绘制。
    xf = _xf_mod()
    seen = set()
    try:
        targets = _collect_handle_targets(context)
    except Exception:
        return None
    for obj, bone_name in targets:
        act = obj.animation_data.action if obj and obj.animation_data else None
        if act is None:
            continue
        for fc in xf._position_curves(act, obj, bone_name):
            for kp in fc.keyframe_points:
                if not kp.select_control_point:
                    continue
                # 两侧都取，看体感是否一致（未记录 ⇒ 透传原始类型）
                for side in ('left', 'right'):
                    v = xf.feel_type(kp, side)
                    if v is None:
                        v = str(kp.handle_left_type if side == 'left'
                                else kp.handle_right_type)
                        # 透传时把原生语义折成体感口径
                        v = {'ALIGNED': 'LINK', 'AUTO': 'LINK',
                             'AUTO_CLAMPED': 'CLAMPED'}.get(v, v)
                    seen.add(v)
    if len(seen) == 1:
        return seen.pop()
    return None


def _collect_handle_targets(context):
    """收集 (obj, bone_name) 目标 —— 与 `apply_handle_mode` 同一口径。"""
    targets = []
    if context.mode == 'POSE':
        obj = context.active_object
        if obj and obj.type == 'ARMATURE':
            for bone in (context.selected_pose_bones or []):
                targets.append((obj, bone.name))
    else:
        obj = context.active_object
        if obj and obj.animation_data and obj.animation_data.action:
            targets.append((obj, None))
    return targets


def apply_handle_mode(context, handle_type):
    """设置【体感手柄类型】（方案 A）。

    ★ 2026-09-17 改造：
      · `handle_type` 现在理解为**体感类型**（'LINK'/'FREE'/'VECTOR'/'AUTO'/'AUTO_CLAMPED'）
      · 体感**独立记录**（`mark_feel`）—— 权威
      · 原始手柄类型**按需**写（'FREE' 或原生值）—— 实现细节，别让 Blender 重算
    """
    targets = []

    if context.mode == 'POSE':
        obj = context.active_object
        if obj and obj.type == 'ARMATURE':
            selected_bones = list(context.selected_pose_bones or [])
            if selected_bones:
                for bone in selected_bones:
                    targets.append((obj, bone.name))
            elif context.active_pose_bone:
                targets.append((obj, context.active_pose_bone.name))
    else:
        selected_objects = list(context.selected_objects or [])
        if selected_objects:
            for obj in selected_objects:
                if obj.animation_data and obj.animation_data.action:
                    targets.append((obj, None))
        else:
            obj = context.active_object
            if obj and obj.animation_data and obj.animation_data.action:
                targets.append((obj, None))

    # ---- 口径换算（★ 方案 A） ----
    #   入参 handle_type 是**体感口径**：
    #     'LINK'  = 保持一条直线（对应原来的 Aligned / Auto / AutoClamped）
    #     'FREE'  = 不动
    #     'VECTOR'= 贴到控制点
    #     旧接口的 'ALIGNED'/'AUTO'/'AUTO_CLAMPED' 也接受，一律折成 'LINK'。
    _ht = str(handle_type or '').upper()
    if _ht == 'AUTO_CLAMPED':
        feel_value = 'CLAMPED'          # ★ 与 LINK 行为相同（联动），但原始类型不同
    elif _ht in ('ALIGNED', 'AUTO', 'LINK'):
        feel_value = 'LINK'
    elif _ht == 'VECTOR':
        feel_value = 'VECTOR'
    else:
        feel_value = 'FREE'

    # 原始手柄类型（实现细节）—— 唯一来源在 transform_domain.orig_type_for_feel
    try:
        orig_type = _xf_mod().orig_type_for_feel(feel_value)
    except Exception:
        orig_type = 'ALIGNED' if feel_value == 'LINK' else 'FREE'

    for obj, bone_name in targets:
        action = obj.animation_data.action
        for fcurve in collect_animation_curves(action, obj):
            if not is_position_animation(fcurve, bone_name):
                continue
            for keyframe in fcurve.keyframe_points:
                if keyframe.select_control_point:
                    # ---- ① 记录【体感类型】（权威） ----
                    try:
                        xf = _xf_mod()
                        for _side in ('left', 'right'):
                            xf.mark_feel(keyframe, _side, feel_value)
                    except Exception:
                        warn_once("interaction.apply_handle_mode")
                        pass

                    # ---- ② 原始手柄类型（按需写） ----
                    #   · 体感 LINK   → 写 'ALIGNED'（让原生共线保持，符合"对齐"语义）
                    #   · 体感 FREE   → 写 'FREE'（定住，Blender 不重算）
                    #   · 体感 VECTOR → 写 'VECTOR'
                    #   · AUTO 系     → 写原生 'AUTO_CLAMPED'
                    keyframe.handle_left_type = orig_type
                    keyframe.handle_right_type = orig_type

                    if feel_value in ('LINK', 'AUTO', 'AUTO_CLAMPED'):
                        vec = mathutils.Vector(keyframe.co) - mathutils.Vector(keyframe.handle_left)
                        len_right = (mathutils.Vector(keyframe.handle_right) - mathutils.Vector(keyframe.co)).length
                        if vec.length > 0.0001:
                            vec.normalize()
                            keyframe.handle_right = mathutils.Vector(keyframe.co) + vec * len_right
                    elif feel_value == 'VECTOR':
                        keyframe.handle_left[1] = keyframe.co[1]
                        keyframe.handle_right[1] = keyframe.co[1]
            fcurve.update()


def ensure_location_keyframes(context, obj):
    if not obj or not obj.animation_data or not obj.animation_data.action:
        return

    action = obj.animation_data.action
    
    targets = []
    if obj.mode == 'POSE':
        if context.selected_pose_bones:
            for bone in context.selected_pose_bones:
                 targets.append((f'pose.bones["{bone.name}"].location', bone.name))
    else:
        targets.append(('location', None))

    fcurves_collection = collect_animation_curves(action, obj)
    if isinstance(fcurves_collection, list) and not fcurves_collection:
        return

    for data_path_base, bone_name in targets:
        all_frames = set()
        frame_indices = {} 
        
        target_fcurves = []
        for fc in fcurves_collection:
            if fc.data_path == data_path_base:
                target_fcurves.append(fc)
                for kp in fc.keyframe_points:
                    frame = int(round(kp.co[0]))
                    all_frames.add(frame)
                    if frame not in frame_indices:
                        frame_indices[frame] = set()
                    frame_indices[frame].add(fc.array_index)
        
        if not target_fcurves:
            continue

        # 仅在确实需要新建曲线时才去取可写集合（惰性）
        writable_fcurves = None
        writable_checked = False

        sorted_frames = sorted(list(all_frames))
        
        modified = False
        
        for frame in sorted_frames:
            existing_indices = frame_indices.get(frame, set())
            missing_indices = {0, 1, 2} - existing_indices
            
            if missing_indices:
                for axis_index in missing_indices:
                    fc = next((f for f in target_fcurves if f.array_index == axis_index), None)
                    
                    if fc:
                        val = fc.evaluate(frame)
                        fc.keyframe_points.insert(frame, val)
                    else:
                        # collect_animation_curves() 返回的是 list 快照，没有 .new()；
                        # 新建曲线必须用可写集合 get_writable_fcurves()。
                        if not writable_checked:
                            writable_fcurves = get_writable_fcurves(action, obj)
                            writable_checked = True
                        try:
                            if writable_fcurves is not None:
                                fc = writable_fcurves.new(data_path=data_path_base, index=axis_index)
                                target_fcurves.append(fc)
                                
                                if bone_name:
                                    val = obj.pose.bones[bone_name].location[axis_index]
                                else:
                                    val = obj.location[axis_index]
                                    
                                fc.keyframe_points.insert(frame, val)
                            else:
                                print("RealTimeMotionPath: Cannot create new F-Curve (no writable collection)")
                        except Exception as e:
                            print(f"RealTimeMotionPath: Error creating fcurve for {data_path_base}[{axis_index}]: {e}")
                    
                    modified = True
        
        if modified:
             for fc in target_fcurves:
                 fc.update()


def update_custom_path_active(self, context):
    wm = context.window_manager
    if wm.rtmp_path_display_enabled:
        # ★★ 2026-09-30（Phase 3）：**零静默改写**。
        #
        # 原先这里直接调 `ensure_location_keyframes` —— 它会**静默**给缺失的轴
        # 补关键帧（实测：Z 轴 2 → 3 个关键帧，用户完全没被告知）。
        # 现在改为"先检查、把选择权交给用户"：
        #     · 符合规范          ⇒ 什么都不做（和以前一样安静）
        #     · 有问题（含缺轴）  ⇒ 延迟弹窗，用户勾选后才改
        #     · 用户点过"不再提示"⇒ 尊重，静默跳过
        #
        # ⚠️ 检查是**纯读**、微秒级 ⇒ 每次开都查，不做任何记忆/缓存。
        _checked = False
        try:
            from . import spec_ui as _sui
            _rep = _sui.check_and_maybe_popup(context)
            _checked = True
            # 用户已明确忽略该对象 ⇒ 退回"安静地补轴"（保持可用性）
            if _rep and _rep.get("issues"):
                _obj = context.active_object
                _act = _obj.animation_data.action if (
                    _obj and _obj.animation_data) else None
                if _act is not None and _sui.is_ignored(_obj, _act, None):
                    ensure_location_keyframes(context, _obj)
        except Exception as e:
            print(f"Motion Path Pro: Error checking spec: {e}")
        # 兜底：检查链路异常时保持旧行为（宁可静默补轴，也别让路径显示不出来）
        if not _checked:
            try:
                ensure_location_keyframes(context, context.active_object)
            except Exception as e:
                print(f"Motion Path Pro: Error ensuring keyframes: {e}")
        if not _find_and_start_motion_path_operators(context):
            print("Motion Path Pro: Enabled, but no 3D View found for interaction.")
    else:
        _stop_motion_path_operators(context)

    if context.area:
        context.area.tag_redraw()


def _find_and_start_motion_path_operators(context):
    wm = context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                if region:
                    with context.temp_override(window=window, area=area, region=region):
                        if not getattr(wm, "rtmp_edit_mode_active", False):
                            wm.rtmp_edit_mode_active = True
                            bpy.ops.rtmp.path_point_drag('INVOKE_DEFAULT')
                        if not getattr(wm, "rtmp_auto_refresh_active", False):
                            wm.rtmp_auto_refresh_active = True
                            bpy.ops.rtmp.path_refresh_daemon('INVOKE_DEFAULT')
                    return True
    return False


def _stop_motion_path_operators(context):
    wm = context.window_manager
    wm.rtmp_edit_mode_active = False
    wm.rtmp_auto_refresh_active = False
