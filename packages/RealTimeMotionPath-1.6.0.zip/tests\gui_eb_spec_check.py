# -*- coding: utf-8 -*-
"""E 组（spec 校正极限）+ F 组（双击锁定新语义极限）—— 极限边界测试。

来源
----
tests/_eb_common.py（共享地基，已冒烟）+ 产品模块源码实读
（spec_check / interaction._align_opposite_speed / time_domain.write_s /
transform_domain._link_mode）。所有断言口径都对着**产品自己的不变量**写，
不为了"让它过"而弱化。

覆盖
----
E 组 · spec 校正（spec_check）
    E1 检测器在退化数据上（全零 / 全同值 / 单轴 / 空 action / 单关键帧 / 子帧）
    E2 FIX_ORDER 的**子集交叉**（15 个非空子集全跑）
    E3 COLLINEAR_STRATEGIES 四种策略各自的极限（含 180 度折角的退化）
    E4 体感=自由时**不报也不修**（E2 例外）+ 反向对照
    E5 ★★ 幂等性：apply_fix 之后 after.issues 必须为空 **且不变量必须干净**
    E6 修正 x 端点段 / 首末帧
    E7 修正 x 骨骼
    E8 applied[kind] == -1 是否真能出现
F 组 · 双击锁定（以被双击侧为准）
    F1 两侧速度差 1000 倍 / 千分之一
    F2 被双击侧 |dv| = 0  => degenerate
    F3 被双击侧 dt = 0   => degenerate
    F4 端点段（无对侧）  => no_opposite
    F5 两侧段长 1 帧 vs 10000 帧
    F6 锁定 -> 解锁 -> 再锁定 的幂等性
    F7 锁定 x 体感 FREE / VECTOR
    F8 锁定后三轴 dt 仍一致
    F9 形状偏移有界（< 10%）
    F10 对侧被钳到 S_HARD_MAX 时目标落空（量化差多少倍）

判定口径
--------
    FAIL    明确违反不变量 / 规范（真 bug）
    SUSPECT NaN/Inf、静默无提示、状态不一致（可疑）
    NOTE    已知设计边界 => 计 PASS，detail 里写清楚

用法
----
    blender --background --factory-startup --python tests/gui_eb_spec_check.py
"""
import sys
import os
import re
import math
import json
import itertools
import inspect
import traceback

ADDONS = r'F:\desktop\BaiduSyncdisk\addons'
sys.path.insert(0, ADDONS)
sys.path.insert(0, ADDONS + r'\RealTimeMotionPath\tests')

import bpy  # noqa: E402

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")

import _eb_common as E  # noqa: E402
from RealTimeMotionPath import spec_check as sc      # noqa: E402
from RealTimeMotionPath import transform_domain as xf  # noqa: E402
from RealTimeMotionPath import time_domain as td     # noqa: E402
from RealTimeMotionPath import interaction as it     # noqa: E402
from RealTimeMotionPath import handles as hd         # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, "_eb_spec_result.json")

steps = []


def step(n, ok, d=""):
    steps.append((n, bool(ok), str(d)))


# ===========================================================================
# 工具 —— 为什么需要这几把"自己的尺子"
#
# E.set_handles 只能给【一侧三轴写同一个 dt / dv】。而本组的用例大量需要
# 「同侧三轴 dt 故意不等」「左右方向不平行」这类**逐轴不同**的数据，
# 所以这里补一个逐轴写入器。它不是重写地基，是地基没覆盖的那一格。
#
# 比喻：地基给的是"整排一起推的推子"，E 组要的是"每根手指单独掰"。
# ===========================================================================

_UID = [0]


def mk(name, keys=E.KEYS_3, htype=None, free_all=False, bone=False):
    """建对象 + **把 action 改成全局唯一名**。

    为什么要改名：插件的四张内存表（体感 / 三角锁 / 接管 / 冻结）都以
    **action 名**为键。同名 action 反复建会让上一轮的记录"串味"到这一轮
    （像几个同名的人共用一个储物柜），改名最省事也最干净。
    """
    _UID[0] += 1
    tag = "%s_%d" % (name, _UID[0])
    obj, act = E.build_object(tag, keys, htype=htype, free_all=free_all, bone=bone)
    try:
        act.name = "ACT_" + tag
    except Exception:
        pass
    return obj, act


def ax_curves(o, bone=None):
    """{轴: fcurve}（读对象当前 action）。"""
    act = o.animation_data.action
    return {int(c.array_index): c for c in xf._position_curves(act, o, bone)}


def kpmap(o, frame, bone=None):
    """{轴: 该帧关键帧}。

    注意：每次**重新取**。keyframe 包装对象用过一次就"钝"了（改了不生效），
    这是本项目历史上反复踩的坑，工具函数一律现取。
    """
    out = {}
    for fc in xf._position_curves(o.animation_data.action, o, bone):
        kp = xf.keyframe_at(fc, frame)
        if kp is not None:
            out[int(fc.array_index)] = kp
    return out


def set_side(o, frame, side, dts, dvs, feel=None, bone=None):
    """逐轴写某一侧手柄。

    :param dts: {轴: dt 绝对值}（>= 0）
    :param dvs: {轴: **带符号**的 dv}，即 handle[1] - co[1]

    符号约定必须记牢：handle_left = (co_t - dt, co_v + dv)、
                      handle_right = (co_t + dt, co_v + dv)
    左右都是"co 加 dv"，所以**同一个 dv 在左右两侧代表同一个值方向**
    （这正是 180 度折角的成因）。
    """
    km = kpmap(o, frame, bone)
    for ax, kp in km.items():
        kp.handle_left_type = 'FREE'
        kp.handle_right_type = 'FREE'
        d = float(dts.get(ax, 0.0))
        v = float(dvs.get(ax, 0.0))
        if side == 'left':
            kp.handle_left = (float(kp.co[0]) - d, float(kp.co[1]) + v)
        else:
            kp.handle_right = (float(kp.co[0]) + d, float(kp.co[1]) + v)
    for fc in xf._position_curves(o.animation_data.action, o, bone):
        fc.update()
    if feel:
        mark_feel(o, frame, feel, bone=bone)


def mark_feel(o, frame, value, sides=('left', 'right'), bone=None):
    """登记体感（插件的"这根手柄归谁管"记录）。

    注意：xf._link_mode(kp, 'right') 读的是**对侧（left）**的体感 ——
    想制造"体感=自由"，标 left；想制造"体感=对齐"，标 left 也够。
    两侧都标最省心。
    """
    for ax, kp in kpmap(o, frame, bone).items():
        for sd in sides:
            try:
                xf.mark_feel(kp, sd, value)
            except Exception:
                pass


def dv_of(o, frame, side, bone=None):
    out = {}
    for ax, kp in kpmap(o, frame, bone).items():
        h = kp.handle_left if side == 'left' else kp.handle_right
        out[ax] = float(h[1]) - float(kp.co[1])
    return out


def dv_norm(o, frame, side, bone=None):
    v = dv_of(o, frame, side, bone)
    return math.sqrt(sum(v.get(a, 0.0) ** 2 for a in (0, 1, 2)))


def dt_of(o, frame, side, bone=None):
    out = {}
    for ax, kp in kpmap(o, frame, bone).items():
        h = kp.handle_left if side == 'left' else kp.handle_right
        out[ax] = abs(float(h[0]) - float(kp.co[0]))
    return out


def dt_med(o, frame, side, bone=None):
    d = sorted(dt_of(o, frame, side, bone).values())
    return d[len(d) // 2] if d else None


def speed_of(o, frame, side, bone=None):
    """该侧**物理速度标量** |dv| / dt（独立复算，不用产品代码）。"""
    d = dt_med(o, frame, side, bone)
    if not d or d <= 1e-12:
        return None
    return dv_norm(o, frame, side, bone) / d


def sample_path(o, act, f0, f1, bone=None):
    """逐帧采样三轴位置 —— 独立尺子（只用 fcurve.evaluate，不碰产品逻辑）。"""
    cs = {int(c.array_index): c for c in xf._position_curves(act, o, bone)}
    pts = []
    for f in range(int(f0), int(f1) + 1):
        pts.append(tuple(float(cs[a].evaluate(f)) if a in cs else 0.0
                         for a in (0, 1, 2)))
    return pts


def path_len(pts):
    return sum(math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def max_dev(p, q):
    return max(math.dist(a, b) for a, b in zip(p, q))


def fake_handles(frame, kf=(500.0, 300.0)):
    """给 toggle_frame_lock 用的假手柄记录（复刻 collect_handles 的字段）。"""
    out = []
    for t in hd.TRI_KINDS:
        out.append({'frame': float(frame), 'tri': t, 'side': hd.SIDE_BY_TRI[t],
                    'span': None, 's': None, 'd': 0.0,
                    'kf_screen': kf, 'kf_world': (0.0, 0.0, 0.0), 'bone_name': None,
                    'tri_screen': hd.tri_center(kf, t, hd.TRI_FIXED_D)})
    return out


def tri_mouse(tri, kf=(500.0, 300.0)):
    """三角中心 —— 离关键帧 26px（> 关键帧保护半径 14px，< 拾取半径 22px）。"""
    return hd.tri_center(kf, tri, hd.TRI_FIXED_D)


def _inv_key(v):
    """把一条不变量违规压成"**身份键**"—— 判断"是不是同一笔旧账"用。

    ★★ 2026-09-30（D-5 收尾实测踩到，**别改回直接比字符串**）：

       违规文案里**带数值**。而"补轴"按 Blender 的**保形状插入**
       （贝塞尔 de Casteljau 分割）**必然**要改写邻居关键帧的手柄坐标 ——
       这不是副作用，是"在曲线上插一个点、还要求曲线逐位不变"的
       **数学必要条件**（详见 `spec_check.fix_missing_axes` 附近那段说明）。

       ⇒ 同一笔旧账的**数字**会变，字符串一比就成了"新违规"，
         其实是**旧账换了件衣服**。

       实测（E2 miss）：f=117 left 的三轴 dt 从 [27, 13.5, 6.75] 变成
         [27, 4.42, 6.75] —— 问题**还是那一个**（而且"补轴"本来就不负责
         修 dt_mismatch，那笔账是 before 里就有的），
         但旧尺子把它记成"新账"，会把一条真修复（D-5）判成红的。

    ⇒ 身份键 = (判据名 + 轴号, 帧号, 侧)。数字不进键。

       ⚠️ 帧号与侧**必须进键**：否则"同一个判据在**别的帧**新冒出来"会被漏掉
          ⇒ 那就成了把尺子调松，真正的回归会溜过去。
    """
    s = str(v)
    m = re.search(r"f=(-?[\d.]+)\s+(left|right)", s)
    if not m:
        return (s,)
    head = s.split("f=")[0]
    try:
        fr = round(float(m.group(1)), 4)
    except Exception:
        fr = m.group(1)
    return (head, fr, m.group(2))


def newinv(before, after):
    """after 里**新出现**的违规（before 已有的旧账不算新账）。

    ⚠️ 用"身份键"比，不用字符串 —— 理由见 `_inv_key`（数字会变，问题不会）。
    """
    old = {_inv_key(v) for v in before}
    return [v for v in after if _inv_key(v) not in old]


# ===========================================================================
# X0 · 尺子自检 —— 抓不到 bug 的测试比没有测试更危险
# ===========================================================================

try:
    o, act = mk("X0", E.KEYS_3)
    set_side(o, 90, 'left', {0: 30.0, 1: 15.0, 2: 8.0}, {0: -1.0, 1: -1.0, 2: -1.0}, feel='LINK')
    bad = E.invariants(act, o)
    step("X0 ★★ 尺子自检：故意把同侧三轴 dt 写散 => invariants 必须报出来",
         any("三轴 dt 不一致" in v for v in bad),
         "报出 %d 条：%s" % (len(bad), "; ".join(bad)[:160]))
    o2, act2 = mk("X0b", E.KEYS_3)
    clean = E.invariants(act2, o2)
    step("X0b ★ 尺子自检：干净数据必须报 0 条（防'恒报'的假尺子）",
         not clean, "报出 %d 条" % len(clean))
except Exception:
    step("FATAL-X0", False, E.tb())


# ===========================================================================
# E1 · 检测器在退化数据上
# ===========================================================================

try:
    o, act = mk("E1a", ((0, (0, 0, 0)), (90, (0, 0, 0)), (117, (0, 0, 0))))
    r = sc.detect(act, o)
    step("E1a 全零关键帧：detect 不炸、0 问题、不变量干净",
         not r["issues"] and not E.invariants(act, o),
         "issues=%d inv=%d frames=%d" % (len(r["issues"]), len(E.invariants(act, o)), r["checked_frames"]))

    o, act = mk("E1b", ((0, (1, 1, 1)), (90, (1, 1, 1)), (117, (1, 1, 1))))
    r = sc.detect(act, o)
    step("E1b 全同值（原地不动）：detect 不炸、0 问题、不变量干净",
         not r["issues"] and not E.invariants(act, o),
         "issues=%d inv=%d" % (len(r["issues"]), len(E.invariants(act, o))))

    o, act = mk("E1c", ((0, (0, 0, 0)),))
    r = sc.detect(act, o)
    step("E1c 单关键帧：两侧都是外侧 => 0 问题、不变量干净",
         not r["issues"] and not E.invariants(act, o),
         "issues=%d checked_frames=%d" % (len(r["issues"]), r["checked_frames"]))

    o, act = mk("E1d", E.KEYS_3)
    a2 = bpy.data.actions.new("E1_empty_act")
    r = sc.detect(a2, o)
    res, _ = sc.apply_fix(a2, o, r)
    step("E1d 空 action（一条曲线都没有）：detect/apply_fix 都不炸、applied 全 0",
         not r["issues"] and all(v == 0 for v in res["applied"].values()),
         "issues=%d applied=%s" % (len(r["issues"]), res["applied"]))

    rn = sc.detect(None, o)
    ro = sc.detect(act, None)
    step("E1e action=None / obj=None：返回空报告不抛异常",
         not rn["issues"] and not ro["issues"],
         "action=None->%d obj=None->%d" % (len(rn["issues"]), len(ro["issues"])))

    # 单轴对象：X 有曲线，Y/Z **整条曲线都不存在**
    _UID[0] += 1
    nm = "E1f_%d" % _UID[0]
    o = bpy.data.objects.get(nm)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.view_layer.objects.active
    o.name = nm
    for f, v in E.KEYS_3:
        bpy.context.scene.frame_set(int(f))
        o.location = v
        o.keyframe_insert("location", index=0, frame=int(f))
    act = o.animation_data.action
    act.name = "ACT_" + nm
    r = sc.detect(act, o)
    kinds = sorted({i["kind"] for i in r["issues"]})
    frames = sorted({i["frame"] for i in r["issues"]})
    step("E1f 单轴（Y/Z 整条曲线缺失）：每帧都报 missing_axis",
         kinds == ["missing_axis"] and frames == [0.0, 90.0, 117.0],
         "kinds=%s frames=%s" % (kinds, frames))

    o, act = mk("E1g", ((0.5, (0, 0, 0)), (90.25, (1, 2.56, 0.4)), (117.75, (3, 6, 1.2))))
    r = sc.detect(act, o)
    step("E1g 子帧关键帧（0.5 / 90.25 / 117.75）：不炸、不变量干净",
         not r["issues"] and not E.invariants(act, o),
         "issues=%d frames=%d（NOTE：子帧关键帧按设计可被检查）"
         % (len(r["issues"]), r["checked_frames"]))
except Exception:
    step("FATAL-E1", False, E.tb())


# ===========================================================================
# E2 · FIX_ORDER 子集交叉
#
# 判据（比"跑通没报错"强得多）：
#   1 applied 的键 == 所选子集（一个不多一个不少）
#   2 不变量**只减不增**（before 已有的旧账不算新账）
#   3 全量 apply（DEFAULT_APPLY）时：after.issues 必须空 **且**不变量必须干净
# ===========================================================================

def hostile(name):
    """一个同时带三种毛病的对象：missing_axis + dt_mismatch + handle_bend。"""
    o, act = mk(name, E.KEYS_3)
    # 末帧 117：左 dt 三轴不等（=> dt_mismatch）+ 左右方向不平行（=> handle_bend）
    set_side(o, 117, 'left', {0: 27.0, 1: 13.5, 2: 6.75}, {0: -1.0, 1: -0.5, 2: -0.25}, feel='LINK')
    set_side(o, 117, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 0.2, 2: 0.1}, feel='LINK')
    # 中帧 90：删掉 Y 轴关键帧（=> missing_axis）
    for _ in range(4):
        fc = ax_curves(o).get(1)
        if fc is None:
            break
        kp = xf.keyframe_at(fc, 90)
        if kp is None:
            break
        try:
            fc.keyframe_points.remove(kp)
        except Exception:
            break
    return o, act


try:
    o, act = hostile("E2_probe")
    r0 = sc.detect(act, o)
    step("E2-0 敌对样本（缺轴+dt不等+折角）构造成功",
         sorted({i["kind"] for i in r0["issues"]}) == ["dt_mismatch", "handle_bend", "missing_axis"],
         "kinds=%s frames=%s" % (sorted({i["kind"] for i in r0["issues"]}),
                                 sorted({i["frame"] for i in r0["issues"]})))

    subsets = []
    for rr in range(1, len(sc.FIX_ORDER) + 1):
        subsets.extend(itertools.combinations(sc.FIX_ORDER, rr))

    for sub in subsets:
        tag = "+".join(k[:4] for k in sub)
        try:
            o, act = hostile("E2_" + tag.replace("+", "_"))
            before = E.invariants(act, o)
            rep = sc.detect(act, o)
            res, snap = sc.apply_fix(act, o, rep, None, kinds=sub)
            after = E.invariants(act, o)
            new = newinv(before, after)
            keys_ok = set(res["applied"].keys()) == set(sub)
            no_err = all(v != -1 for v in res["applied"].values())
            step("E2 %-34s applied 键齐 + 不引入新违规" % tag,
                 keys_ok and no_err and not new,
                 "applied=%s keys_ok=%s 新违规=%d %s" % (res["applied"], keys_ok, len(new),
                                                        "; ".join(new)[:120]))
        except Exception:
            step("E2 %s" % tag, False, E.tb())

    # 全量（DEFAULT_APPLY）—— 插件的"一键修好"契约
    o, act = hostile("E2_full")
    before = E.invariants(act, o)
    res, snap = sc.apply_fix(act, o, sc.detect(act, o))
    after = E.invariants(act, o)
    aft_issues = [(i["kind"], i["frame"], i["side"]) for i in (res["after"] or {}).get("issues", [])]
    step("E2-full ★★ 全量 apply：after.issues 空 且 不变量干净",
         not aft_issues and not newinv(before, after),
         "after.issues=%s 新违规=%s" % (aft_issues, "; ".join(newinv(before, after))[:200]))
except Exception:
    step("FATAL-E2", False, E.tb())


# ===========================================================================
# E3 · COLLINEAR_STRATEGIES 四种策略的极限
#
# 先说清一个坑：apply_fix **没有 strategy 参数**，它永远走
# COLLINEAR_DEFAULT（bisect）。要逐策略对比必须**直接调** fix_handle_bend。
# ===========================================================================

try:
    # --- E3a 正常折角（16.6 度）四策略都应收敛 + 长度守恒 ---
    base_l = {0: -1.0, 1: -0.5, 2: -0.25}
    base_r = {0: 1.0, 1: 0.2, 2: 0.1}
    devs = {}
    for strat in sc.COLLINEAR_STRATEGIES:
        o, act = mk("E3a_" + strat, E.KEYS_3)
        set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, base_l, feel='LINK')
        set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, base_r, feel='LINK')
        ln_l0, ln_r0 = dv_norm(o, 90, 'left'), dv_norm(o, 90, 'right')
        p0 = sample_path(o, act, 0, 117)
        rep = sc.detect(act, o)
        got = sc.fix_handle_bend(act, o, rep, None, None, strategy=strat)
        vl = [dv_of(o, 90, 'left')[a] for a in (0, 1, 2)]
        vr = [dv_of(o, 90, 'right')[a] for a in (0, 1, 2)]
        fold = sc._angle_deg(vl, [-x for x in vr])
        ln_l1, ln_r1 = dv_norm(o, 90, 'left'), dv_norm(o, 90, 'right')
        p1 = sample_path(o, act, 0, 117)
        dev = max_dev(p0, p1)
        devs[strat] = dev
        step("E3a %-16s 折角->0 / 长度守恒 / 不变量干净" % strat,
             len(got) == 1 and fold is not None and fold <= sc.ANGLE_EPS_DEG
             and abs(ln_l1 - ln_l0) < 1e-3 and abs(ln_r1 - ln_r0) < 1e-3
             and not E.invariants(act, o),
             "fold=%.4f 长度 %.4f->%.4f / %.4f->%.4f 形变=%.4f 不变量=%d"
             % (fold if fold is not None else -1, ln_l0, ln_l1, ln_r0, ln_r1, dev,
                len(E.invariants(act, o))))

    step("E3a-order 四策略形变对比（文档称 bisect 最小：0.131 < 0.242/0.259/0.143）",
         True,
         "NOTE 实测 %s => 最小的是 %s"
         % (", ".join("%s=%.4f" % (k, v) for k, v in sorted(devs.items())),
            min(devs, key=devs.get)))

    # --- E3b 180 度折角（左右 dv 同向）：bisect / length_weighted 数学上退化 ---
    #   m = ul - ur = 0 => t = 0 => 两侧 dv 被写成 0（手柄长度清零）
    for strat in sc.COLLINEAR_STRATEGIES:
        o, act = mk("E3b_" + strat, E.KEYS_3)
        set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, {0: 1.0, 1: 0.5, 2: 0.25}, feel='LINK')
        set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 0.5, 2: 0.25}, feel='LINK')
        ln0 = dv_norm(o, 90, 'left')
        p0 = sample_path(o, act, 0, 117)
        rep = sc.detect(act, o)
        fold0 = sc._angle_deg([1.0, 0.5, 0.25], [-1.0, -0.5, -0.25])
        got = sc.fix_handle_bend(act, o, rep, None, None, strategy=strat)
        ln1 = dv_norm(o, 90, 'left')
        aft = [(i["kind"], i["frame"]) for i in sc.detect(act, o)["issues"]]
        p1 = sample_path(o, act, 0, 117)
        killed = ln1 < 1e-9
        step("E3b %-16s ★静默★ 180度折角：手柄长度必须保住（不能清零）" % strat,
             not killed,
             "静默：fold_before=%.1f 长度 %.4f->%.4f 复检 issues=%s 形变=%.4f"
             % (fold0, ln0, ln1, aft, max_dev(p0, p1)))

    # --- E3c 近 180 度（按比例复制，只差 float32 舍入）：bisect 方向由噪声主导 ---
    o, act = mk("E3c", E.KEYS_3)
    set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, {0: 1.0, 1: 0.5, 2: 0.25}, feel='LINK')
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 0.98, 1: 0.49, 2: 0.245}, feel='LINK')
    rep = sc.detect(act, o)
    fold0 = sc._angle_deg([1.0, 0.5, 0.25], [-0.98, -0.49, -0.245])
    p0 = sample_path(o, act, 0, 117)
    sc.fix_handle_bend(act, o, rep, None, None, strategy='bisect')
    dvl = [dv_of(o, 90, 'left')[a] for a in (0, 1, 2)]
    p1 = sample_path(o, act, 0, 117)
    u0 = [x / math.sqrt(1.0 + 0.25 + 0.0625) for x in (1.0, 0.5, 0.25)]
    u1 = [x / (math.sqrt(sum(y * y for y in dvl)) or 1.0) for x in dvl]
    turn = sc._angle_deg(u0, u1)
    step("E3c ★★静默★ 近180度折角 bisect：方向不该由浮点噪声决定（转角应约等于 0）",
         turn is not None and turn <= 5.0,
         "静默：fold_before=%.4f 手柄被转向 %.2f 度 形变=%.4f（长度守恒 %.4f）"
         % (fold0, turn if turn is not None else -1, max_dev(p0, p1), dv_norm(o, 90, 'left')))

    # --- E3d 函数级：_target_dirs 的退化输入 ---
    # ★★★ 2026-09-30 修 D-7 / D-8（Phase 1 极限测试抓到）：
    #    旧代码对"两侧同向"（fold=180）返回**零方向** ⇒ 调用方把 dv 写成 0
    #    ⇒ 手柄长度清零且静默。本条原先硬编码 `True`（只记录根因），
    #    现翻转为**防回归**断言：同向必须给出**确定的单位方向**。
    zl, zr = sc._target_dirs([0.0, 0.0, 0.0], [1.0, 0.0, 0.0], 'bisect')
    sl, sr = sc._target_dirs([1.0, 0.0, 0.0], [1.0, 0.0, 0.0], 'bisect')
    _nl = math.sqrt(sum(x * x for x in sl))
    _nr = math.sqrt(sum(x * x for x in sr))
    step("E3d ★ 函数级 _target_dirs：零向量仍原样返回（调用方有长度闸门）；"
         "**同向**输入必须给出确定的单位方向（D-7 退化保护在场）",
         all(abs(x) < 1e-12 for x in zl)
         and abs(_nl - 1.0) < 1e-9 and abs(_nr - 1.0) < 1e-9
         and all(abs(sl[i] + sr[i]) < 1e-12 for i in range(3)),
         "零向量->(%s) 同向->(%s) / 反向->(%s)：同向时按 right_only 兜底"
         "（保左边、翻右边），方向与浮点噪声无关；零向量那条路不变"
         "（fix_handle_bend 只在两侧长度 > MIN_HANDLE_LEN 时才调它）"
         % ([round(x, 3) for x in zl], [round(x, 3) for x in sl],
            [round(x, 3) for x in sr]))
except Exception:
    step("FATAL-E3", False, E.tb())


# ===========================================================================
# E4 · 体感=自由（_link_mode != 'link'）=> 不报也不修 + 反向对照
# ===========================================================================

def bend_obj(name, feel):
    """dt 已三轴一致（无 dt_mismatch），只有 16.6 度折角；体感按参数登记。"""
    o, act = mk(name, E.KEYS_3)
    set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, {0: -1.0, 1: -0.5, 2: -0.25}, feel=feel)
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 0.2, 2: 0.1}, feel=feel)
    return o, act


try:
    o, act = bend_obj("E4_link", 'LINK')
    kp = kpmap(o, 90)[0]
    mode_link = xf._link_mode(kp, 'right')
    r_link = sc.detect(act, o)
    step("E4-对照 体感=LINK => _link_mode=='link' 且 handle_bend 被报出（证明判据真的在起作用）",
         mode_link == 'link' and any(i["kind"] == "handle_bend" for i in r_link["issues"]),
         "mode=%s issues=%s" % (mode_link, [i["kind"] for i in r_link["issues"]]))

    o, act = bend_obj("E4_free", 'FREE')
    kp = kpmap(o, 90)[0]
    mode_free = xf._link_mode(kp, 'right')
    r_free = sc.detect(act, o)
    before = dv_of(o, 90, 'left'), dv_of(o, 90, 'right')
    res, snap = sc.apply_fix(act, o, r_free, None, kinds=("handle_bend",))
    after = dv_of(o, 90, 'left'), dv_of(o, 90, 'right')
    same = all(abs(before[i].get(a, 0.0) - after[i].get(a, 0.0)) < 1e-6
               for i in (0, 1) for a in (0, 1, 2))
    step("E4a ★★ 体感=FREE => 不报 handle_bend",
         mode_free != 'link' and not any(i["kind"] == "handle_bend" for i in r_free["issues"]),
         "mode=%s issues=%s" % (mode_free, [i["kind"] for i in r_free["issues"]]))
    step("E4b ★★ 体感=FREE => apply_fix(kinds=handle_bend) 一个数都不动",
         res["applied"].get("handle_bend") == 0 and same and not E.invariants(act, o),
         "applied=%s 数据未动=%s 不变量=%d" % (res["applied"], same, len(E.invariants(act, o))))

    o, act = bend_obj("E4_vec", 'VECTOR')
    kp = kpmap(o, 90)[0]
    mode_vec = xf._link_mode(kp, 'right')
    r_vec = sc.detect(act, o)
    step("E4c 体感=VECTOR => 同样不报（'vector' != 'link'）",
         mode_vec == 'vector' and not any(i["kind"] == "handle_bend" for i in r_vec["issues"]),
         "mode=%s issues=%s" % (mode_vec, [i["kind"] for i in r_vec["issues"]]))
except Exception:
    step("FATAL-E4", False, E.tb())


# ===========================================================================
# E5 · 幂等性 —— apply_fix 之后 after.issues 必须为空（★ 从没被断言过）
# ===========================================================================

try:
    # --- E5a 常规：dt 三轴不等 -> 全量修 -> 复检空 + 不变量干净 ---
    o, act = mk("E5a", E.KEYS_3)
    set_side(o, 90, 'left', {0: 30.0, 1: 15.0, 2: 8.0}, {0: -1.0, 1: -1.0, 2: -1.0}, feel='LINK')
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    res, snap = sc.apply_fix(act, o, sc.detect(act, o))
    aft = [(i["kind"], i["frame"], i["side"]) for i in (res["after"] or {}).get("issues", [])]
    step("E5a ★★ 常规 dt_mismatch：全量修完 after.issues 空 + 不变量干净",
         not aft and not E.invariants(act, o),
         "applied=%s after.issues=%s inv=%s" % (res["applied"], aft, E.invariants(act, o)))

    # --- E5b ★★★ 整条轴曲线缺失（单轴对象）-> 全量修 ---
    _UID[0] += 1
    nm = "E5b_%d" % _UID[0]
    o = bpy.data.objects.get(nm)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.view_layer.objects.active
    o.name = nm
    for f, v in E.KEYS_3:
        bpy.context.scene.frame_set(int(f))
        o.location = v
        o.keyframe_insert("location", index=0, frame=int(f))
    act = o.animation_data.action
    act.name = "ACT_" + nm
    before = E.invariants(act, o)
    res, snap = sc.apply_fix(act, o, sc.detect(act, o))
    after = E.invariants(act, o)
    aft = [(i["kind"], i["frame"], i["axes"]) for i in (res["after"] or {}).get("issues", [])]
    new = newinv(before, after)
    step("E5b ★★★ 整条轴缺失 -> 全量修：复检说'没事'，但插件自己的不变量被破坏",
         not aft and not new,
         "applied=%s after.issues=%s 新违规=%d：%s | dt左90=%s dt右90=%s"
         % (res["applied"], aft, len(new), "; ".join(new)[:220],
            {k: round(v, 3) for k, v in dt_of(o, 90, 'left').items()},
            {k: round(v, 3) for k, v in dt_of(o, 90, 'right').items()}))

    # --- E5c 连跑两次：第二次必须"无事可做"（严格幂等） ---
    o, act = mk("E5c", E.KEYS_3)
    set_side(o, 90, 'left', {0: 30.0, 1: 15.0, 2: 8.0}, {0: -1.0, 1: -1.0, 2: -1.0}, feel='LINK')
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    sc.apply_fix(act, o, sc.detect(act, o))
    s1 = E.handles_snapshot(act, o)
    res2, _ = sc.apply_fix(act, o, sc.detect(act, o))
    s2 = E.handles_snapshot(act, o)
    drift = max((abs(s1[k][0] - s2[k][0]) + abs(s1[k][1] - s2[k][1])) for k in s1) if s1 else 0.0
    step("E5c ★★ 第二次 apply_fix 无事可做（applied 全 0 且手柄零漂移）",
         all(v == 0 for v in res2["applied"].values()) and drift < 1e-6,
         "applied=%s 漂移=%.2e" % (res2["applied"], drift))

    # --- E5d 折角修完再跑一次（含 180 度折角的敌对样本） ---
    o, act = mk("E5d", E.KEYS_3)
    set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, {0: 1.0, 1: 0.5, 2: 0.25}, feel='LINK')
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 0.5, 2: 0.25}, feel='LINK')
    res, snap = sc.apply_fix(act, o, sc.detect(act, o))
    aft = [(i["kind"], i["frame"]) for i in (res["after"] or {}).get("issues", [])]
    ln = (dv_norm(o, 90, 'left'), dv_norm(o, 90, 'right'))
    step("E5d ★★静默★ 180度折角全量修：复检空，但手柄长度必须还在",
         not aft and min(ln) > 1e-9,
         "静默：applied=%s after.issues=%s 手柄长度=%s"
         % (res["applied"], aft, tuple(round(x, 6) for x in ln)))
except Exception:
    step("FATAL-E5", False, E.tb())


# ===========================================================================
# E6 · 修正 x 端点段 / 首末帧
# ===========================================================================

try:
    # --- E6a 只有两个关键帧（首末各只有一个"内侧"） ---
    o, act = mk("E6a", E.KEYS_2)
    set_side(o, 0, 'right', {0: 45.0, 1: 20.0, 2: 9.0}, {0: 2.0, 1: 1.0, 2: 0.5}, feel='LINK')
    set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, {0: -2.0, 1: -1.0, 2: -0.5}, feel='LINK')
    before = E.invariants(act, o)
    rep = sc.detect(act, o)
    res, snap = sc.apply_fix(act, o, rep)
    after = E.invariants(act, o)
    aft = [(i["kind"], i["frame"], i["side"]) for i in (res["after"] or {}).get("issues", [])]
    step("E6a ★ 两端点对象（2 关键帧）：全量修完复检空 + 不引入新违规",
         not aft and not newinv(before, after),
         "detect=%s applied=%s after=%s 新违规=%s"
         % ([(i["kind"], i["frame"], i["side"]) for i in rep["issues"]], res["applied"], aft,
            "; ".join(newinv(before, after))[:160]))

    # --- E6b force_align 连首末帧的**外侧**手柄也一起规范 ---
    o, act = mk("E6b", E.KEYS_2)
    set_side(o, 0, 'right', {0: 45.0, 1: 45.0, 2: 45.0}, {0: 2.0, 1: 1.0, 2: 0.5}, feel='LINK')
    set_side(o, 0, 'left', {0: 9.0, 1: 4.0, 2: 2.0}, {0: -0.5, 1: -0.25, 2: -0.1}, feel='LINK')
    set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, {0: -2.0, 1: -1.0, 2: -0.5}, feel='LINK')
    dl0 = dt_of(o, 0, 'left')
    rep = sc.detect(act, o)
    res, snap = sc.apply_fix(act, o, rep, None, kinds=("force_align",))
    dl1 = dt_of(o, 0, 'left')
    spread = max(dl1.values()) - min(dl1.values())
    step("E6b ★ force_align 把首帧**外侧**手柄的三轴 dt 也统一",
         res["applied"].get("force_align", 0) >= 1 and spread < 1e-4 and not E.invariants(act, o),
         "外侧 dt %s -> %s（极差 %.2e）applied=%s inv=%d"
         % ({k: round(v, 3) for k, v in dl0.items()}, {k: round(v, 3) for k, v in dl1.items()},
            spread, res["applied"], len(E.invariants(act, o))))

    # --- E6c 单关键帧：全量修什么都不该做 ---
    o, act = mk("E6c", ((0, (0, 0, 0)),))
    res, snap = sc.apply_fix(act, o, sc.detect(act, o))
    step("E6c 单关键帧：全量修 applied 全 0、不变量干净、不炸",
         all(v == 0 for v in res["applied"].values()) and not E.invariants(act, o),
         "applied=%s" % res["applied"])

    # --- E6d 段长只有 1 帧：dt 绝不能超过段长（曲线有效性边界） ---
    o, act = mk("E6d", ((0, (0, 0, 0)), (1, (1, 2.56, 0.4))))
    set_side(o, 0, 'right', {0: 0.9, 1: 0.3, 2: 0.1}, {0: 2.0, 1: 1.0, 2: 0.5}, feel='LINK')
    before = E.invariants(act, o)
    res, snap = sc.apply_fix(act, o, sc.detect(act, o))
    after = E.invariants(act, o)
    step("E6d 段长 1 帧：修完 dt 不超段长（不引入新违规）",
         not newinv(before, after),
         "applied=%s dt=%s 新违规=%s" % (res["applied"],
                                         {k: round(v, 4) for k, v in dt_of(o, 0, 'right').items()},
                                         "; ".join(newinv(before, after))[:160]))
except Exception:
    step("FATAL-E6", False, E.tb())


# ===========================================================================
# E7 · 修正 x 骨骼
# ===========================================================================

try:
    arm, act = mk("E7", E.KEYS_3, bone=True)
    bn = arm.pose.bones[0].name

    set_side(arm, 90, 'left', {0: 27.0, 1: 13.5, 2: 6.75}, {0: -1.0, 1: -0.5, 2: -0.25}, feel='LINK', bone=bn)
    set_side(arm, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 0.2, 2: 0.1}, feel='LINK', bone=bn)

    rep = sc.detect(act, arm, bn)
    kinds = sorted({i["kind"] for i in rep["issues"]})
    step("E7a 骨骼：detect(action, arm, bone_name) 能报出 dt_mismatch + handle_bend",
         kinds == ["dt_mismatch", "handle_bend"],
         "bone=%s kinds=%s frames=%s" % (bn, kinds, sorted({i["frame"] for i in rep["issues"]})))

    before = E.invariants(act, arm, bn)
    res, snap = sc.apply_fix(act, arm, rep, bn)
    after = E.invariants(act, arm, bn)
    aft = [(i["kind"], i["frame"], i["side"]) for i in (res["after"] or {}).get("issues", [])]
    step("E7b ★ 骨骼：全量修完复检空 + 不引入新违规",
         not aft and not newinv(before, after),
         "applied=%s after=%s 新违规=%s" % (res["applied"], aft, "; ".join(newinv(before, after))[:160]))

    rep_no = sc.detect(act, arm, None)
    step("E7c 骨骼不带 bone_name => 收不到曲线（0 问题）",
         not rep_no["issues"],
         "NOTE bone_name 是必需参数；issues=%d checked_frames=%d"
         % (len(rep_no["issues"]), rep_no["checked_frames"]))
except Exception:
    step("FATAL-E7", False, E.tb())


# ===========================================================================
# E8 · applied[kind] == -1 真的能出现吗
# ===========================================================================

try:
    src = None
    try:
        import inspect
        src = inspect.getsource(sc.apply_fix)
    except Exception:
        pass
    step("E8a 静态契约：apply_fix 里确有 '= -1' 的错误标记",
         bool(src) and "-1" in src and "applied" in src,
         "源码含 -1 = %s" % ("-1" in (src or "")))

    o, act = mk("E8b", E.KEYS_3)
    set_side(o, 90, 'left', {0: 30.0, 1: 15.0, 2: 8.0}, {0: -1.0, 1: -1.0, 2: -1.0}, feel='LINK')
    rep = sc.detect(act, o)
    _orig = sc.fix_unify_dt
    try:
        def _boom(*a, **k):
            raise RuntimeError("injected")
        sc.fix_unify_dt = _boom
        r_inj, _ = sc.apply_fix(act, o, rep, None, kinds=("dt_mismatch",))
    finally:
        sc.fix_unify_dt = _orig
    step("E8b ★ 注入异常 => applied['dt_mismatch'] == -1（错误路径真的接上了）",
         r_inj["applied"].get("dt_mismatch") == -1,
         "applied=%s" % r_inj["applied"])

    tried = {}
    class _Duck(object):
        name = "duck"
        animation_data = None
    try:
        r_d, _ = sc.apply_fix(act, _Duck(), rep, None)
        tried["duck_obj"] = r_d["applied"]
    except Exception:
        tried["duck_obj"] = "raised"
    try:
        r_n, _ = sc.apply_fix(act, o, None, None)
        tried["report_none"] = r_n["applied"]
    except Exception:
        tried["report_none"] = "raised"
    try:
        r_b, _ = sc.apply_fix(act, o, rep, "NoSuchBone")
        tried["bad_bone"] = r_b["applied"]
    except Exception:
        tried["bad_bone"] = "raised"
    got_minus = [k for k, v in tried.items() if isinstance(v, dict) and -1 in v.values()]
    step("E8c 自然构造（duck 对象 / report=None / 错骨骼名）都不会自然触发 -1",
         not got_minus,
         "NOTE 实测 %s => -1 目前只能靠'fix 函数整体抛异常'到达，属**兜底分支**" % tried)
except Exception:
    step("FATAL-E8", False, E.tb())


# ===========================================================================
# F 组 · 双击锁定（以被双击侧为准）
#
#   v_target = |v_被双击侧|；dt_对侧 = |dv_对侧|_3D / v_target；**只写对侧**。
# ===========================================================================

# --- F1 两侧速度差 1000 倍 / 千分之一 ---
try:
    # F1a 被双击侧快 1000 倍 => 对侧 dt 变极小（不钳制）=> 速度应精确相等
    o, act = mk("F1a", E.KEYS_3)
    set_side(o, 90, 'left', {0: 90.0, 1: 90.0, 2: 90.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'right', {0: 0.027, 1: 0.027, 2: 0.027}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    vs0, vo0 = speed_of(o, 90, 'right'), speed_of(o, 90, 'left')
    before = E.invariants(act, o)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    vs1, vo1 = speed_of(o, 90, 'right'), speed_of(o, 90, 'left')
    rel = abs(vs1 - vo1) / max(1e-12, vs1)
    step("F1a ★ 速度差 1000x（被双击侧更快）：对侧速度精确追上，clamped=False",
         ok and (info or {}).get("clamped") is False and rel < 1e-6 and not newinv(before, E.invariants(act, o)),
         "v 前 %.6g/%.6g -> 后 %.6g/%.6g 相对差=%.2e clamped=%s dt=%s"
         % (vs0, vo0, vs1, vo1, rel, (info or {}).get("clamped"),
            [round(x, 6) if x else x for x in (info or {}).get("dt", [])]))

    # F1b 对侧更快 1000 倍 + 对侧 |dv| 很大 => 对侧需要 s > 1 => 被钳到 S_HARD_MAX
    #   触发条件（源码注释）：s_被双击侧 x (dv_对侧/span_对侧) / (dv_本侧/span_本侧) > 1
    #   本构造：被双击侧 dt=27（s=1.0）、dv=1/轴 => v=0.06415
    #           对侧   dt=0.81（s=0.009）、dv=30/轴 => v=64.15（正好 1000 倍）
    #        => 需要 s = 9.0 => 被钳到 1.0，落差 9 倍
    o, act = mk("F1b", E.KEYS_3)
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'left', {0: 0.81, 1: 0.81, 2: 0.81}, {0: 30.0, 1: 30.0, 2: 30.0}, feel='LINK')
    vs0, vo0 = speed_of(o, 90, 'right'), speed_of(o, 90, 'left')
    need_s = (dv_norm(o, 90, 'left') / vs0) / 90.0
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    info = info or {}
    vs1, vo1 = speed_of(o, 90, 'right'), speed_of(o, 90, 'left')
    va = info.get("v_after") or [None, None]
    truth = (abs(float(va[0]) - vs1) < 1e-9 * max(1.0, vs1)
             and abs(float(va[1]) - vo1) < 1e-9 * max(1.0, vo1))
    gap1 = (max(vs1, vo1) / min(vs1, vo1)) if min(vs1, vo1) > 0 else float('inf')
    step("F1b ★★ 速度差 1000x（对侧更快）+ 对侧 dv 大 => 撞上界：clamped=True 且 v_after 如实",
         ok and info.get("clamped") is True and truth and gap1 > 1.5,
         "NOTE v 前 %.6g/%.6g（差 %.0fx）需要 s=%.3f（>1）=> 钳到 1.0；"
         "v 后 %.6g/%.6g => 仍差 %.2fx；v_after=%s 与独立复算一致=%s"
         % (vs0, vo0, (vo0 / vs0 if vs0 else -1), need_s, vs1, vo1, gap1,
            [round(x, 6) for x in va], truth))

    # F1c ★★★ 对侧段极长 => 所需 s 掉到 S_EPS 之下 => **下界**钳制没被上报
    #   构造：帧 10090，点右段（span=10）—— 被双击侧手柄极密（dt≈0.0015，
    #         Blender 的手柄最小时间间距见 F3a）
    #         对侧左段 span=10090、dt=10090（s=1.0）=> 需要 s = 1.9e-7 << S_EPS
    #   write_s 会把它钳到 S_EPS => 对侧速度达不到目标，
    #   而 clamped 只判【上界】(> S_HARD_MAX) => False => 调用方文案会说"已一致"
    KEYS_LONG = ((0, (0.0, 0.0, 0.0)), (10090, (1.0, 2.0, 0.5)), (10100, (2.0, 3.0, 1.0)))
    o, act = mk("F1c", KEYS_LONG)
    set_side(o, 10090, 'left', {0: 10090.0, 1: 10090.0, 2: 10090.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 10090, 'right', {0: 0.0015, 1: 0.0015, 2: 0.0015}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    vs0 = speed_of(o, 10090, 'right')
    need_s = (dv_norm(o, 10090, 'left') / vs0) / 10090.0
    before = E.invariants(act, o)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 10090, hd.TRI_DOWN, None)
    info = info or {}
    vs1, vo1 = speed_of(o, 10090, 'right'), speed_of(o, 10090, 'left')
    gap = (max(vs1, vo1) / min(vs1, vo1)) if min(vs1, vo1) > 0 else float('inf')
    step("F1c ★★★ 对侧所需 s < S_EPS（下界钳制）：clamped 必须如实（否则文案说谎）",
         info.get("clamped") is True,
         "静默：需要 s=%.3e（< S_EPS=%.0e）=> 被钳到 S_EPS；clamped=%s；"
         "两侧速度仍差 %.2fx（v=%.6g/%.6g）新违规=%s"
         % (need_s, td.S_EPS, info.get("clamped"), gap, vs1, vo1,
            "; ".join(newinv(before, E.invariants(act, o)))[:80]))

    # F1c-2 用户可见后果：真入口的文案说"速度已一致"时，速度必须真的一致
    xf.set_tri_locked(act, 10090, False)
    sh = fake_handles(10090)
    okk, msg = it.toggle_frame_lock(bpy.context, o, 10090, sh, tri_mouse(hd.TRI_DOWN), None, None)
    vs2, vo2 = speed_of(o, 10090, 'right'), speed_of(o, 10090, 'left')
    gap2 = (max(vs2, vo2) / min(vs2, vo2)) if min(vs2, vo2) > 0 else float('inf')
    claims_equal = "are now equal" in str(msg)
    step("F1c-2 ★★★ 用户可见：文案说'速度已一致'时，速度必须真的一致",
         not (claims_equal and gap2 > 1.000001),
         "静默：msg=%s | 实测两侧仍差 %.2fx（v=%.6g/%.6g）"
         % (msg, gap2, vs2, vo2))
except Exception:
    step("FATAL-F1", False, E.tb())


# --- F2 / F3 退化 ---
try:
    o, act = mk("F2", E.KEYS_3)
    set_side(o, 90, 'left', {0: 90.0, 1: 90.0, 2: 90.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 0.0, 1: 0.0, 2: 0.0}, feel='LINK')
    snap0 = E.handles_snapshot(act, o)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    snap1 = E.handles_snapshot(act, o)
    moved = any(abs(snap0[k][0] - snap1[k][0]) + abs(snap0[k][1] - snap1[k][1]) > 1e-9 for k in snap0)
    step("F2 ★ 被双击侧 |dv|=0 => reason=='degenerate' 且一个数都不写",
         ok is False and reason == "degenerate" and not moved and not E.invariants(act, o),
         "reason=%s 写入=%s" % (reason, moved))

    # F3 被双击侧 dt = 0：**Blender 层就构造不出来**（手柄有最小时间间距）
    #   实测：写 dt=0 / 1e-6 / 1e-4 / 2.7e-4 / 1e-3 一律被 fc.update() 抬到
    #         ~0.001007 帧（不改 update 时读回确实是 0）—— 这是 Blender 的手柄钳制，
    #         不是插件的问题。所以产品的 "dt 退化 => degenerate" 守卫在这条路径上
    #         是**到不了的兜底分支**。
    o, act = mk("F3", E.KEYS_3)
    set_side(o, 90, 'left', {0: 90.0, 1: 90.0, 2: 90.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'right', {0: 0.0, 1: 0.0, 2: 0.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    dt_read = dt_med(o, 90, 'right')
    step("F3a Blender 层：写 dt=0 会被 fc.update() 抬到约 0.001 帧 => dt=0 不可达",
         dt_read is not None and 1e-4 < dt_read < 1e-2,
         "NOTE 写 0 读回 %.9f 帧 => '被双击侧 dt=0' 在 Blender 里构造不出来" % (dt_read if dt_read else -1))

    try:
        src_align = inspect.getsource(it._align_opposite_speed)
    except Exception:
        src_align = ""
    step("F3b 静态契约：产品源码里 dt/dv 退化守卫存在（degenerate 分支）",
         "degenerate" in src_align and "not dt_s" in src_align and "dv_s < 1e-12" in src_align,
         "NOTE 守卫在源码里存在；但 dt==0 这一支到不了（见 F3a），"
         "dv==0 那一支可达（见 F2）")

    before = E.invariants(act, o)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    info = info or {}
    vs1, vo1 = speed_of(o, 90, 'right'), speed_of(o, 90, 'left')
    gapF3 = (max(vs1, vo1) / min(vs1, vo1)) if min(vs1, vo1) > 0 else float('inf')
    step("F3c 用 Blender 能给的最小 dt：要么精确追上、要么如实上报，且不变量干净",
         ok and (gapF3 < 1.000001 or info.get("clamped") is True)
         and not newinv(before, E.invariants(act, o)),
         "dt=%.9f v=%.6g/%.6g 差=%.4fx clamped=%s"
         % (dt_read or -1, vs1, vo1, gapF3, info.get("clamped")))
except Exception:
    step("FATAL-F2F3", False, E.tb())


# --- F4 端点段（无对侧） ---
try:
    o, act = mk("F4", E.KEYS_2)
    r_up = it._align_opposite_speed(bpy.context, o, 0, hd.TRI_UP, None)
    r_dn = it._align_opposite_speed(bpy.context, o, 0, hd.TRI_DOWN, None)
    step("F4a ★ 首帧 + 下三角（本侧有段、对侧无段）=> reason=='no_opposite'",
         r_dn[0] is False and r_dn[2] == "no_opposite",
         "TRI_DOWN->%s" % (r_dn[2],))
    step("F4b 首帧 + 上三角（本侧自己就是端点段）=> reason=='no_source'",
         r_up[0] is False and r_up[2] in ("no_source", "no_opposite"),
         "NOTE TRI_UP->%s（产品对'本侧无段'和'对侧无段'分了两个 reason，都是拒绝）" % (r_up[2],))
    o, act = mk("F4c", E.KEYS_3)
    r_end = it._align_opposite_speed(bpy.context, o, 117, hd.TRI_DOWN, None)
    step("F4c 末帧 + 下三角 => 拒绝且不写数据",
         r_end[0] is False and r_end[2] in ("no_source", "no_opposite") and not E.invariants(act, o),
         "reason=%s" % (r_end[2],))
except Exception:
    step("FATAL-F4", False, E.tb())


# --- F5 两侧段长 1 帧 vs 10000 帧 ---
try:
    o, act = mk("F5a", ((0, (0, 0, 0)), (1, (1, 2.56, 0.4)), (10001, (3, 6, 1.2))))
    set_side(o, 1, 'left', {0: 0.5, 1: 0.5, 2: 0.5}, {0: -1.0, 1: -1.0, 2: -1.0}, feel='LINK')
    set_side(o, 1, 'right', {0: 5000.0, 1: 5000.0, 2: 5000.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    before = E.invariants(act, o)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 1, hd.TRI_UP, None)
    after = E.invariants(act, o)
    info = info or {}
    dts = [dt_med(o, 1, 'left'), dt_med(o, 1, 'right')]
    spread = max(dt_of(o, 1, 'right').values()) - min(dt_of(o, 1, 'right').values())
    step("F5a ★ 左段 1 帧 / 右段 10000 帧：点左段 => 只写对侧、三轴 dt 一致、不炸",
         ok and spread < 1e-6 and not newinv(before, after),
         "dt=%s 对侧三轴极差=%.2e clamped=%s 新违规=%s"
         % ([round(x, 6) if x else x for x in dts], spread, info.get("clamped"),
            "; ".join(newinv(before, after))[:120]))

    o, act = mk("F5b", ((0, (0, 0, 0)), (1, (1, 2.56, 0.4)), (10001, (3, 6, 1.2))))
    set_side(o, 1, 'left', {0: 0.5, 1: 0.5, 2: 0.5}, {0: -1.0, 1: -1.0, 2: -1.0}, feel='LINK')
    set_side(o, 1, 'right', {0: 5000.0, 1: 5000.0, 2: 5000.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    before = E.invariants(act, o)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 1, hd.TRI_DOWN, None)
    after = E.invariants(act, o)
    info = info or {}
    spread_l = max(dt_of(o, 1, 'left').values()) - min(dt_of(o, 1, 'left').values())
    step("F5b ★ 点右段（10000 帧）=> 左段 dt 被重算，三轴仍一致",
         ok and spread_l < 1e-6 and not newinv(before, after),
         "dt=%s clamped=%s 新违规=%s"
         % ([round(dt_med(o, 1, 'left'), 6), round(dt_med(o, 1, 'right'), 6)], info.get("clamped"),
            "; ".join(newinv(before, after))[:120]))
except Exception:
    step("FATAL-F5", False, E.tb())


# --- F6 锁定 -> 解锁 -> 再锁定 的幂等性（走**真入口** toggle_frame_lock） ---
try:
    o, act = mk("F6", E.KEYS_3)
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'left', {0: 90.0, 1: 90.0, 2: 90.0}, {0: 2.0, 1: 2.0, 2: 2.0}, feel='LINK')
    sh = fake_handles(90)
    mpos = tri_mouse(hd.TRI_DOWN)

    xf.set_tri_locked(act, 90, False)
    ok1, msg1 = it.toggle_frame_lock(bpy.context, o, 90, sh, mpos, None, None)
    s_after_lock1 = E.handles_snapshot(act, o)
    dt_lock1 = (dt_med(o, 90, 'left'), dt_med(o, 90, 'right'))

    ok2, msg2 = it.toggle_frame_lock(bpy.context, o, 90, sh, mpos, None, None)
    ok3, msg3 = it.toggle_frame_lock(bpy.context, o, 90, sh, mpos, None, None)
    s_after_lock2 = E.handles_snapshot(act, o)
    dt_lock2 = (dt_med(o, 90, 'left'), dt_med(o, 90, 'right'))
    drift = max((abs(s_after_lock1[k][0] - s_after_lock2[k][0])
                 + abs(s_after_lock1[k][1] - s_after_lock2[k][1])) for k in s_after_lock1)
    step("F6a ★★ 锁定->解锁->再锁定：两次锁定后的数据完全一致（幂等）",
         ok1 and ok2 and ok3 and drift < 1e-6 and dt_lock1 == dt_lock2,
         "drift=%.2e dt=%s->%s msg1=%s" % (drift, [round(x, 4) for x in dt_lock1],
                                          [round(x, 4) for x in dt_lock2], msg1))

    okA, infoA, _ = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    sA = E.handles_snapshot(act, o)
    okB, infoB, _ = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    sB = E.handles_snapshot(act, o)
    drift2 = max((abs(sA[k][0] - sB[k][0]) + abs(sA[k][1] - sB[k][1])) for k in sA)
    step("F6b ★★ 连调两次 _align_opposite_speed：第二次零漂移",
         okA and okB and drift2 < 1e-6,
         "drift=%.2e v_after=%s -> %s" % (drift2,
                                          [round(x, 6) for x in (infoA or {}).get("v_after", [])],
                                          [round(x, 6) for x in (infoB or {}).get("v_after", [])]))
except Exception:
    step("FATAL-F6", False, E.tb())


# --- F7 锁定 x 体感 FREE / VECTOR ---
try:
    for feel in ('FREE', 'VECTOR'):
        o, act = mk("F7_" + feel, E.KEYS_3)
        set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
        set_side(o, 90, 'left', {0: 90.0, 1: 90.0, 2: 90.0}, {0: 2.0, 1: 2.0, 2: 2.0}, feel=feel)
        kp_l = kpmap(o, 90)[0]
        feel_before = xf.feel_type(kp_l, 'left')
        mode = xf._link_mode(kp_l, 'right')
        dt_before = dt_med(o, 90, 'left')
        ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
        kp_l2 = kpmap(o, 90)[0]
        feel_after = xf.feel_type(kp_l2, 'left')
        dt_after = dt_med(o, 90, 'left')
        wrote = abs((dt_after or 0) - (dt_before or 0)) > 1e-6
        step("F7 %-6s 锁定 x 对侧体感：体感记录不被冲掉 + 不变量干净" % feel,
             ok and feel_after == feel_before and not E.invariants(act, o),
             "NOTE _link_mode=%s；对侧 dt %.4f->%.4f（写了=%s => 双击是【命令】语义，"
             "以被双击侧为准，会覆盖 FREE/VECTOR 的疏密）体感 %s->%s"
             % (mode, dt_before or -1, dt_after or -1, wrote, feel_before, feel_after))
except Exception:
    step("FATAL-F7", False, E.tb())


# --- F8 锁定后三轴 dt 仍一致（对侧原本就散） ---
try:
    o, act = mk("F8", E.KEYS_3)
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'left', {0: 90.0, 1: 45.0, 2: 20.0}, {0: 2.0, 1: 2.0, 2: 2.0}, feel='LINK')
    before = E.invariants(act, o)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    after = E.invariants(act, o)
    dl = dt_of(o, 90, 'left')
    step("F8 ★★ 对侧 dt 原本散（90/45/20）=> 锁定后必须收敛成同一个 dt",
         ok and (max(dl.values()) - min(dl.values())) < 1e-6,
         "dt 90/45/20 -> %s（极差 %.2e）；before 违规=%d after 违规=%d"
         % ({k: round(v, 6) for k, v in dl.items()}, max(dl.values()) - min(dl.values()),
            len(before), len(after)))
except Exception:
    step("FATAL-F8", False, E.tb())


# --- F9 形状偏移有界 ---
try:
    o, act = mk("F9", E.KEYS_3)
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'left', {0: 30.0, 1: 30.0, 2: 30.0}, {0: 2.0, 1: 2.0, 2: 2.0}, feel='LINK')
    p0 = sample_path(o, act, 0, 117)
    L = path_len(p0)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    p1 = sample_path(o, act, 0, 117)
    dev = max_dev(p0, p1)
    step("F9 ★★ 锁定后形状偏移有界（最大偏移 / 路径长 < 10%）",
         ok and dev / max(1e-9, L) < 0.10,
         "路径长=%.4f 最大偏移=%.4f = %.3f%% clamped=%s"
         % (L, dev, 100.0 * dev / max(1e-9, L), (info or {}).get("clamped")))
except Exception:
    step("FATAL-F9", False, E.tb())


# --- F10 对侧被钳到 S_HARD_MAX：量化差多少倍 + v_after 是否如实 ---
try:
    o, act = mk("F10", E.KEYS_3)
    set_side(o, 90, 'right', {0: 27.0, 1: 27.0, 2: 27.0}, {0: 1.0, 1: 1.0, 2: 1.0}, feel='LINK')
    set_side(o, 90, 'left', {0: 90.0, 1: 90.0, 2: 90.0}, {0: 30.0, 1: 30.0, 2: 30.0}, feel='LINK')
    before = E.invariants(act, o)
    vs0, vo0 = speed_of(o, 90, 'right'), speed_of(o, 90, 'left')
    need_s = (dv_norm(o, 90, 'left') / speed_of(o, 90, 'right')) / 90.0
    p0 = sample_path(o, act, 0, 117)
    ok, info, reason = it._align_opposite_speed(bpy.context, o, 90, hd.TRI_DOWN, None)
    info = info or {}
    vs1, vo1 = speed_of(o, 90, 'right'), speed_of(o, 90, 'left')
    ratio = vo1 / vs1 if vs1 else float('inf')
    va = info.get("v_after") or [None, None]
    truth = (abs(float(va[0]) - vs1) <= 1e-9 * max(1.0, abs(vs1))
             and abs(float(va[1]) - vo1) <= 1e-9 * max(1.0, abs(vo1)))
    p1 = sample_path(o, act, 0, 117)
    step("F10a ★★ 对侧被钳到 S_HARD_MAX：clamped=True 且目标确实落空",
         ok and info.get("clamped") is True and ratio > 1.5 and not newinv(before, E.invariants(act, o)),
         "需要 s=%.4f（>1）=> 钳到 1.0；v 目标=%.6g 实际=%.6g => 差 %.2fx；形变=%.4f"
         % (need_s, vs1, vo1, ratio, max_dev(p0, p1)))
    step("F10b ★★★ info['v_after'] 如实反映（与独立复算逐位相符）",
         truth,
         "v_after=%s 独立实测=[%.9g, %.9g]" % ([round(x, 9) for x in va], vs1, vo1))

    xf.set_tri_locked(act, 90, False)
    sh = fake_handles(90)
    okk, msg = it.toggle_frame_lock(bpy.context, o, 90, sh, tri_mouse(hd.TRI_DOWN), None, None)
    has_num = ("%.2fx apart" % ratio) in str(msg)
    step("F10c ★★ 真入口文案带上真实倍数（不再无条件说'已一致'）",
         okk and has_num,
         "msg=%s | 期望含 %.2fx" % (msg, ratio))
except Exception:
    step("FATAL-F10", False, E.tb())


# ===========================================================================
E.flush(LOG, steps)
print("EB_SPEC_DONE")
