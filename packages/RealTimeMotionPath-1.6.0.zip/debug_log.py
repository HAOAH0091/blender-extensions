# -*- coding: utf-8 -*-
"""RTMP 调试日志 —— **正式机制**（不是用完即删的临时钩子）。

## 为什么需要它

交互类问题（手感不对 / 数值跳变 / 拖不动 / 偶发失效）在 headless 里**复现不出来**：
- 用假事件模拟，往往因缺字段而与真机行为不符；
- 纯读代码推演，容易连推三轮全错。

这类问题的正确解法是：**加日志 → 让用户真机操作一次 → 读日志定案**。
（2026-09-17 的「拖三角打满卡死」就是这么定位的：日志显示鼠标坐标是 `-1` 哨兵值。）

本模块把那次"临时钩子"沉淀成**长期可用的机制**，以后遇到同类问题直接开开关即可。

## 用法

```python
from .debug_log import dbg, set_enabled, read_tail, clear

dbg("drag.begin", frame=25.0, side='left', mode='UNIFORM',
    offset_world=[1.0, 0.0, 0.0])
```

- 未启用时 `dbg()` 是**零成本空操作**（只做一次布尔判断）。
- 启用方式（三条，任一即可）：
  1. 偏好设置里打开「Debug Log」（`debug_log_enabled` / UI 面板 `rtmp_debug_log`）
  2. 环境变量 `RTMP_DEBUG_LOG=1`（真值：`1` / `true` / `yes` / `on`，大小写无关）
  3. Python 里 `from RealTimeMotionPath.debug_log import set_enabled; set_enabled(True)`
- **优先级**：方式 1 / 3 一旦显式设定过，就**压倒**环境变量（便于测试与强制关闭）。
  从未显式设定时，才跟随环境变量。

## 日志位置

`<Blender 配置目录>/rtmp_debug/rtmp-YYYYMMDD.jsonl`（跨平台、可写；见 `default_path()`）。

⚠️ 日志**不会自动清理**。排查完请调 `clear()` 或直接删文件（偏好设置里有按钮）。
"""
import json
import os
import threading
import time

try:
    import bpy
except Exception:                                    # 允许在 Blender 外被 import（测试用）
    bpy = None

__all__ = ["dbg", "set_enabled", "is_enabled", "default_path", "read_tail", "clear",
           "log_path", "MAX_BYTES"]

# 单文件上限（超过就轮转），防止长期误开把磁盘写满
MAX_BYTES = 8 * 1024 * 1024

_lock = threading.Lock()
_enabled = False
_explicit = False        # set_enabled() 是否被显式调用过（显式设定优先于环境变量）
_path = None
_rotated = False

# ★★ 2026-09-29：环境变量启用方式此前只写在 docstring 里、代码并未实现（#6）。
#    现补齐。每进程直接读（os.environ.get 是纳秒级 dict 查找，不构成开销）。
_ENV_NAME = "RTMP_DEBUG_LOG"
_ENV_TRUE = ("1", "true", "yes", "on")


def _env_requested():
    """环境变量 `RTMP_DEBUG_LOG` 是否为真值（1 / true / yes / on，大小写无关）。"""
    try:
        v = os.environ.get(_ENV_NAME, "")
    except Exception:
        return False
    return str(v).strip().lower() in _ENV_TRUE


def default_path():
    """默认日志路径：`<用户配置目录>/rtmp_debug/rtmp-YYYYMMDD.jsonl`。

    取不到 bpy 时退回系统临时目录（测试/独立脚本用）。
    """
    day = time.strftime("%Y%m%d")
    base = None
    if bpy is not None:
        for kind in ("CONFIG", "SCRIPTS", "TEMP"):
            try:
                base = bpy.utils.user_resource(kind)
                if base:
                    break
            except Exception:
                continue
    if not base:
        import tempfile
        base = tempfile.gettempdir()
    return os.path.join(base, "rtmp_debug", "rtmp-%s.jsonl" % day)


def set_enabled(on, path=None):
    """开关调试日志（可同时指定路径）。返回当前是否启用。

    ★ 显式调用后会**压倒**环境变量 `RTMP_DEBUG_LOG`（便于测试与用户强制关闭）。
    """
    global _enabled, _explicit, _path, _rotated
    with _lock:
        _enabled = bool(on)
        _explicit = True
        if path:
            _path = path
        elif _enabled and not _path:
            _path = default_path()
        _rotated = False
    return _enabled


def is_enabled():
    """当前是否启用：显式设定优先；没设过则跟随环境变量 `RTMP_DEBUG_LOG`。"""
    return _enabled if _explicit else _env_requested()


def log_path():
    """当前日志文件路径（未启用时返回默认路径，便于 UI 展示）。"""
    return _path or default_path()


def _rotate_if_needed():
    """超过 MAX_BYTES 就轮转一次（保留 .1 备份），避免无限增长。"""
    global _rotated
    if _rotated:
        return
    try:
        if _path and os.path.exists(_path) and os.path.getsize(_path) > MAX_BYTES:
            bak = _path + ".1"
            try:
                if os.path.exists(bak):
                    os.remove(bak)
                os.replace(_path, bak)
            except Exception:
                pass
            _rotated = True
    except Exception:
        pass


def dbg(event, **data):
    """写一条结构化调试记录（未启用时是空操作）。

    event : 事件名（建议用 `域.动作`，如 `drag.begin` / `uniform.clamp`）
    data  : 任意可 JSON 序列化的键值（不可序列化的会被 repr 成字符串）
    """
    if not is_enabled():
        return
    try:
        rec = {"t": round(time.time(), 4), "ev": str(event)}
        for k, v in data.items():
            try:
                json.dumps(v)                       # 先探一次
                rec[k] = v
            except Exception:
                rec[k] = repr(v)
        line = json.dumps(rec, ensure_ascii=False)
        with _lock:
            _rotate_if_needed()
            if not _path:
                globals()["_path"] = default_path()
            d = os.path.dirname(_path)
            if d and not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            with open(_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        # 日志失败绝不能影响插件功能
        pass


def read_tail(n=200):
    """读最近 n 条记录（解析失败的原始行以 `{"raw": ...}` 返回）。"""
    p = log_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()[-n:]
    except Exception:
        return []
    out = []
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        try:
            out.append(json.loads(ln))
        except Exception:
            out.append({"raw": ln})
    return out


def clear():
    """清空日志文件（保留文件本身）。"""
    p = log_path()
    try:
        if os.path.exists(p):
            os.remove(p)
        return True
    except Exception:
        return False
