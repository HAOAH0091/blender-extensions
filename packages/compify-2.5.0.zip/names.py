MAIN_NODE_NAME = "Compify Footage"
BAKE_IMAGE_NODE_NAME = "Baked Lighting"
UV_LAYER_NAME = 'Compify Baked Lighting'

# UV Adjust node group constants
UV_ADJUST_NODE_GROUP_PREFIX = "UV Adjust"
UV_ADJUST_INPUT_SOCKET_NAME = "Camera Projection UV"
UV_ADJUST_OUTPUT_SOCKET_NAME = "Adjusted UV"

def compify_mat_name(context):
    """
    Get the Compify Material name for the active scene.
    
    Args:
        context: Blender context object
        
    Returns:
        str: The Compify material name (format: "Compify Footage | {scene_name}")
    """
    return "Compify Footage | " + context.scene.name


def compify_baked_texture_name(context):
    """
    Get the Compify baked lighting image name for the active scene.
    
    Args:
        context: Blender context object
        
    Returns:
        str: The Compify bake texture name (format: "Compify Bake | {scene_name}")
    """
    return "Compify Bake | " + context.scene.name


def uv_adjust_node_group_name(obj, camera):
    """
    Get the UV Adjust node group name for a specific object and camera.
    
    Uses data-block names to avoid losing linkage when object names change.
    
    Args:
        obj: Blender object
        camera: Blender camera object
        
    Returns:
        str: The UV Adjust node group name (format: "UV Adjust | {obj_data} | {cam_data}")
    """
    obj_data_name = obj.data.name if getattr(obj, 'data', None) else obj.name
    cam_data_name = camera.data.name if getattr(camera, 'data', None) else camera.name
    return f"{UV_ADJUST_NODE_GROUP_PREFIX} | {obj_data_name} | {cam_data_name}"


def camera_project_node_group_name(camera):
    """
    Get the Camera Project node group name for a specific camera.
    
    Uses camera data-block name for stable association.
    
    Args:
        camera: Blender camera object
        
    Returns:
        str: The Camera Project node group name (format: "Camera Project | {cam_data}")
    """
    cam_data_name = camera.data.name if getattr(camera, 'data', None) else camera.name
    return f"Camera Project | {cam_data_name}"


def baked_material_name(original_material_name):
    """
    Get baked material name from original material name.

    Format: "Baked_{original_material_name}"

    Args:
        original_material_name: Name of the original material

    Returns:
        str: The baked material name
    """
    return f"Baked_{original_material_name}"


def baked_image_name(material_name, object_data_name):
    """
    Get baked image name from material and object data names.

    Format: "Bake_{material_name}_{object_data_name}"
    Uses data-block names for stable association.

    Args:
        material_name: Name of the material being baked
        object_data_name: Data-block name of the object being baked

    Returns:
        str: The baked image name
    """
    return f"Bake_{material_name}_{object_data_name}"
