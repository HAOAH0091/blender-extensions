# Changelog


## [2.5.0] - 2026-06-23 - 材质烘焙修复与投影面板 UI 增强

### 🐛 Bug修复
- **修复 `hide_render` 继承导致多物体共用材质时烘焙失败**: `obj.copy()` 继承原物体的 `hide_render` 属性，副本在烘焙时被 Blender 拒绝。新增 Step 6.5 强制将所有烘焙副本的 `hide_render` 设为 `False`，并在烘焙前做防御性校验。
  - `bake_pipeline.py`: `bake_material_projection()` Step 6.5 + 防御校验
- **修复面板 draw 崩溃**: `selected_set and obj in selected_set` 在空集合时短路返回 `set()` 而非 `False`，赋值给 `UILayout.alert` 时抛 `TypeError`。改为 `selected_set is not None and obj in selected_set`
  - `__init__.py`: `_draw_material_object_sublist()`
- **修复 `baked_images` 与 `baked_objects` 索引越界风险**: Step 5+6 增加了长度校验，不匹配时返回 `_bake_error` 而非 `IndexError` 崩溃
- **修复 `name_to_baked` 映射不完整**: 长度不一致时记录 warn 日志
- **修复 `.session` 文件 BOM 头**: PowerShell `Out-File -Encoding utf8` 写入的 BOM 导致 Python 路径解析失败，改为 `[System.IO.File]::WriteAllText()`。同时 `startup_capture.py` 增加 BOM 剥离兜底

### ✨ 新增
- **单物体选择性烘焙**: `bake_material_projection()` 新增 `object_filter` 参数，支持只烘焙指定物体。`CompifyBakeMaterialProjection` 操作符新增 `object_name` 属性
  - `bake_pipeline.py`: Step 1.5 过滤逻辑 + `FILTER` 日志标签
  - `__init__.py`: 操作符 `invoke()/draw()/execute()` 适配
- **投影材质管理面板物体子列表**: 点击材质名可展开/折叠物体列表，每个物体显示状态图标（选中/关渲染/缺UV/正常），支持单物体烘焙和选中跳转
  - `__init__.py`: `_draw_material_object_sublist()` helper + `CompifyUVAdjust3DPanel.draw()` 单材质/共享组两处集成
- **新增 `CompifySelectObjectByName` 操作符**: 按物体名选择（区别于 `CompifySelectUVAdjustObject` 按 data name 选择）
- **调试日志全面升级**: `BakeLogger` 重构，新增文件日志 `bake_debug.log`（`tempfile.gettempdir()` 跨平台路径），`_write()` 先写文件再 `print()` 双重 try/except 隔离。新增 `RENDER`/`FILTER`/UI 选中变化日志
  - `bake_pipeline.py`: `BakeLogger._open_log_file()`, `_write()` 重构
  - `__init__.py`: 面板选中变化检测 + `[Compify|UI]` 日志

### 🎨 UI 优化
- **材质图标统一**: 有效材质头部图标从 `CHECKMARK` 改为 `MATERIAL`
- **选中物体红色高亮**: 材质行和物体行 `alert = True`，选中时文字变红
- **物体状态图标优先级**: 正在选中 > 关了渲染 > 缺 UV > 正常
- **选中检测改进**: 从 `gi["object"]` 单物体检测改为 `mat_to_objects` 查找表检测所有共用材质的物体
- **折叠层级重构**: 材质名本身变成折叠开关，物体列表在材质下缩进展开（非一级菜单常驻）
- **共享组子材质一致化**: 共享组子材质同样支持折叠+物体列表+选中高亮+box 包裹

### ⚡ 性能优化
- **消除重复查询**: `mat_to_objects` 查找表一次构建，单材质和共享组从中复用对象列表，避免每轮 draw 多次 `find_objects_using_material()`
- **场景过滤**: `mat_to_objects` 构建时过滤到当前 `scene.objects`，避免跨场景污染
- **模块重载句柄泄漏修复**: `BakeLogger._open_log_file()` 关闭旧文件句柄
- **`_last_sel` 默认 `frozenset()`**: 避免模块重载后首次 draw 的空遍历

### 🧪 测试工具改进
- **`blender-test-logger` Skill 升级**: 启动 Blender 时加载 `startup_capture.py` 脚本，将 Python stdout/stderr 重定向到 `_python.log` 文件，捕获完整 traceback
- **`.session` 文件写入**: 改用 `[System.IO.File]::WriteAllText()` 避免 BOM 头

### 🧹 代码清理
- 移除 `CompifyRefreshUVAdjustList` 中无用的 if/else 死分支（两分支均赋 `{"INFO"}`）


## [2.4.1] - 2026-05-24 - 烘焙贴图自动打包

### 🔧 改进
- **烘焙贴图自动打包进 .blend**: 光照烘焙和材质投影烘焙完成后，调用 `image.pack()` 自动将贴图嵌入 .blend 文件，Image Editor 中不再显示星号，用户无需手动保存
  - `bake.py`: `Baker.modal()` 清理阶段新增 `img.pack()`
  - `bake_pipeline.py`: `bake_material_projection()` 返回前循环 `img.pack()`

### 🛡️ 健壮性
- **单贴图打包失败不中断流程**: `bake_pipeline.py` 的 pack 循环用 try-except 隔离，单张失败只记录警告，不影响后续贴图和成功返回
- **取消烘焙不再打包半成品**: `Baker` 新增 `was_cancelled` 标记，用户取消时跳过 pack
- **消除 context 依赖**: `Baker.execute()` 中缓存图片名，`modal()` 清理阶段直接使用缓存，避免场景切换导致取错

### 🐛 Bug修复
- **修复材质投影烘焙潜伏的图片索引错位**: 步骤 4 创建贴图时跳过非 mesh 对象，使 `baked_images` 与 `baked_objects` 长度对齐，修正了之后步骤中 `baked_images[i]` 的索引取值错误


## [2.4.0] - 2026-05-24 - 架构重构：模块拆分与面板性能优化

### 🏗️ 架构重构
- **node_groups.py 拆分**: 从 2607 行单体拆为 3 个独立模块
  - `node_groups.py` (1318 行) — 核心节点组创建 + 边界计算 + 工具函数
  - `node_group_manager.py` (828 行) — UV Adjust 节点组增删改查管理
  - `bake_pipeline.py` (560 行) — 材质投影烘焙流水线 + BakeLogger
- **提取共享工具**: 新建 `properties.py`，收拢 `redraw_viewport()` 等重复代码

### ⚡ 性能优化
- **面板数据缓存**: `get_all_uv_adjust_node_groups()` 增加模块级缓存，避免每次 UI 刷新全量扫描材质和对象
- **缓存失效链路**: 批量生成、删除、更新、刷新、清理五个写操作符覆盖失效调用
- **全清策略**: `invalidate_uv_cache()` 清空整个缓存字典，防止场景重命名后残留键

### 🐛 Bug修复
- **修复文件缺失导致插件无法加载**: 补回遗漏的 `camera_align.py` 和 `bake.py`
- **修复烘焙 zip() 配对错误**: 原始对象含非 mesh 类型时列表长度不一致，改为基于名称的字典映射
- **修复面板刷新延迟**: 批量生成后缓存未失效，改为操作完成后立即清缓存
- **修复清理后缓存残留**: `clean_invalid`/`clean_orphan` 删除节点组后立即失效缓存

### 🧹 代码清理
- 删除 `NAME` 重复声明
- 删除函数内重复 `import json`
- 6 处重复 `tag_redraw` 循环收拢为 `redraw_viewport(context)`
- 清理未使用的 import（`re`、`create_uv_adjust_node_group`、`unwrap_baked_objects`）
- 删除死代码：`properties.py` 中未使用的 `CompifyFootageConfig` 和 fold 函数
- 删除死变量 `obj_name_part`


## [2.3.0] - 2026-05-06 - 材质投影烘焙全面升级

### 🆕 新功能
- **逐物体 UV 独立控制**: 烘焙对话框里新增物体列表，每个物体可独立切换 Unwrap / Keep UV
- **Smart UV Project 参数补全**: 新增 Area Weight、Correct Aspect、Scale to Bounds 三个参数，与 Blender 原生面板一致
- **记住用户设置**: 烘焙对话框现在会记住上次使用的所有参数（分辨率、UV 设置等），下次打开自动恢复

### 🔧 改进
- **烘焙类型改为 COMBINED**: 原生保留 alpha 通道，移除了破坏性的后处理 alpha 修复步骤
- **Mix Shader 连接顺序修正**: Transparent BSDF 连到上层 [1]，Emission 连到下层 [2]，半透明区域显示更准确
- **默认分辨率提高**: 2048 → **4096**
- **Scale to Bounds 默认勾选**: UV 岛自动缩放到 0-1 范围
- **贴图数据即时刷新**: 烘焙完成后调用 img.update() 强制刷新像素数据
- **调试日志增强**: 节点树 dump、像素采样验证、active node 追踪

### 🐛 Bug修复
- **修复 UV 开关不生效**: 修正了 original→baked 物体名称映射问题，Toggle 状态现在正确传递
- **移除破坏性 alpha 修复**: 不再需要额外后处理修复 alpha
- **修复 Angle Limit 参数无效**: 角度值未从度数转为弧度，导致设 2° 和 89° 结果一样
- **修复 BakeLogger NameError**: 模块级变量在类定义前引用，全新安装时崩溃

### 🧭 使用说明
- 打开烘焙对话框后可在 UV Handling 区域的物体列表中单独控制每个物体的 UV 处理方式
- Smart UV Project Settings 现在包含完整的 5 个参数：Angle Limit、Island Margin、Area Weight、Correct Aspect、Scale to Bounds
- Correct Aspect 和 Scale to Bounds 默认不勾选 / 已勾选（按 Blender 原生默认值调整）


## [2.2.0] - 2025-03-11 - 多场景支持与中文编码修复

### 🆕 新功能
- **多场景隔离支持**: UV调整功能现在支持多场景工作流程
  - 每个场景的UV调整节点组相互隔离，互不干扰
  - 面板只显示当前场景的节点组
  - 清理操作只影响当前场景

### 🔧 Bug修复
- **修复中文编码崩溃问题**: 解决了使用中文字符时的编码错误
  - 在 `get_node_group_usage_info()` 中添加防御性try-except块
  - 保护节点树名称比较免受 `UnicodeDecodeError` 错误
  - 在 `find_camera_connected_to_uv_adjust_in_material()` 中添加编码错误处理
  - 现在可以安全使用包含中文名称的材质

### 📋 技术变更
- 为以下函数添加 scene 参数：`get_all_uv_adjust_node_groups()`, `clean_invalid_uv_adjust_node_groups()`, `get_orphan_uv_adjust_node_groups()`, `clean_orphan_uv_adjust_node_groups()`, `handle_object_rename_in_node_groups()`
- 更新面板绘制以传递当前场景上下文
- 刷新和清理操作符现在传递 `context.scene`

### 🧭 使用说明
- 现有场景将继续正常工作（向后兼容）
- 在多场景工作流程中，切换场景时面板会自动更新
- 现在可以安全使用中文命名的材质


## [2.1.1] - 2025-12-07 - 复制粘贴自动分组修复

### 🔧 Bug修复
- **修复复制对象的刷新按钮问题**: "更新UV调整"按钮现在可以正确处理通过 Ctrl+C/Ctrl+V 复制的对象
  - 以前，刷新按钮在更新复制对象的UV参数时会失败或使用陈旧的元数据
  - 现在可以智能地从材质节点树解析实际的对象和相机连接
  - 自动更新节点组元数据以匹配实际连接，修复分组问题

### 📋 技术变更
- 增强了 `CompifyUpdateUVAdjust` 操作符，添加了智能对象/相机解析逻辑
- 添加了回退链：实际连接 → 元数据 → 名称解析，以实现最大兼容性
- 当节点组元数据与实际使用不匹配时，现在会自动更正

### 🧭 使用说明
- 现在完全支持复制粘贴工作流程，无需手动刷新或清理
- 现有场景将自动受益于改进的刷新逻辑
- "刷新并清理"按钮仍然适用于批量更新和名称同步


## [2.1.0] - 2025-12-07 - 基于材质的材质管理

### 🆕 主要新功能
- **投影材质管理**: 节点组管理界面的完全重新设计
  - 面板从"节点组管理"重命名为"投影材质管理"
  - 列表现在显示材质名称而不是对象数据名称
  - 用户重命名材质时，材质名称会自动同步
  - 更直观的工作流程，专注于材质而非技术节点组

### ✨ UI改进
- **以材质为中心的显示**: 
  - 每个列表项显示使用节点组的材质名称
  - 重命名材质时动态更新材质名称
  - 更清晰的视觉层次匹配用户工作流程
- **共享组管理**:
  - 共享相同节点组的多个材质会被分组在一起
  - 可折叠的"共享组 (N)"显示，带有可展开的材质列表
  - 共享组中的每个材质都有独立的选择按钮
- **选择材质对象按钮**:
  - 每个材质条目旁边新增按钮
  - 选择所有使用相应材质的对象（不只是单个）
  - 适用于单个材质和共享组中的材质
  - 图标: `RESTRICT_SELECT_OFF`（鼠标光标）

### 🔧 稳定性与改进
- **健壮的节点组识别**:
  - 添加 `compify_node_type` 自定义属性以实现可靠的节点组识别
  - 不再依赖节点组名称前缀（避免63字符限制问题）
  - 向后兼容：仍然通过名称前缀识别旧节点组
- **孤立节点组检测**:
  - 面板底部警告："发现 X 个未使用的节点组"，带有清理按钮
  - 自动从主列表中过滤掉未使用的节点组
  - 一键清理孤立节点组

### 📋 技术变更
- 修改 `get_all_uv_adjust_node_groups()` 以使用自定义属性识别
- 添加 `get_orphan_uv_adjust_node_groups()` 和 `clean_orphan_uv_adjust_node_groups()` 函数
- 新增操作符：`CompifySelectMaterialObjects` 用于按材质选择所有对象
- 增强节点组数据结构中的材质使用跟踪
- 更新所有新UI元素的翻译（简体中文和繁体中文）

### 🧭 使用说明
- 现有节点组将继续正常工作（向后兼容）
- 新节点组将通过自定义属性获得改进的识别
- 运行"刷新并清理"以更新现有节点组的新属性
- 基于材质的工作流程现在是主要界面


## [2.0.0] - 2025-10-18 - 短标签与稳定ID

### ✨ UI改进
- 简化节点组管理列表：每个相机只显示对象名称。
- 用微妙的灰色子框背景和状态图标替代红色高亮（`row.alert`）。
- 缩短编辑器节点标签：
  - UV调整节点显示对象的数据块名称。
  - 相机投影节点显示相机的数据块名称。
  - 现有节点在刷新时更新为短标签。

### 🔧 稳定性与清理
- 面板中的相相机分组现在通过ID属性而不是节点组名称进行键控，防止名称被截断时出现重复的相机组。
- 删除操作更健壮；从材质中移除UV调整和相机投影节点以避免孤立引用。

### 📋 技术变更
- 为UV调整节点组添加ID属性：`compify_uv_object_data_name` 和 `compify_uv_camera_data_name`。
- 检索和删除逻辑优先考虑ID属性，并有安全回退到名称解析。
- `__init__.py` 中的版本更新为 `2.0.0`。

### 🧭 使用说明
- 运行"刷新并清理"以在现有场景中应用新标签和UI样式。


## [1.1.0] - 2024-12-XX - 完全自动化版本

### 🆕 主要新功能
- **自动材质集成**: 革命性的一键工作流程
  - 自动将节点组添加到对象材质
  - 自动连接相机投影和UV调整节点
  - 如果不存在则自动创建材质
  - 消除手动着色器编辑器设置
- **🆕 增强的自动连接**: 扩展的自动节点连接系统
  - 自动将UV调整输出连接到第一个图像纹理节点的矢量输入
  - 智能检测材质中现有的图像节点
  - 与现有工作流程无缝集成
  - 具有冲突解决的智能连接管理

### ✨ 增强功能
- **3D视口侧边栏界面**: 从对象属性移动到专用侧边栏
- **批量操作**: 同时处理多个对象
- **智能节点组管理**: 具有状态指示器的完整管理系统
- **自动依赖创建**: 自动创建相机投影节点组
- **智能清理**: 自动刷新和清理无效引用
- **高级重命名处理**: 智能检测对象/相机重命名

### 🔧 改进
- **面板名称**: 更新为"相机投影UV调整"以提高清晰度
- **工作流程**: 从单对象简化为批处理
- **增强的删除功能**: 通过自动材质清理改进UV调整删除
  - 删除UV调整节点组数据块
  - 自动从对象材质中移除UV调整节点
  - 自动从对象材质中移除相机投影节点
  - 防止材质中出现孤立的节点引用
- **错误处理**: 全面的错误处理和详细反馈
- **性能**: 优化的节点组管理和引用处理
- **用户体验**: 增强的工具提示、状态指示器和操作反馈

### 📋 技术变更
- 将UI从对象属性面板迁移到3D视口侧边栏
- 实现自动材质节点树管理
- 添加智能节点连接系统
- 增强批处理并提供详细的进度报告

## [1.0.0] - 初始版本

### 新增
- **相机投影UV调整功能**: 核心UV映射调整功能
  - 对象特定的UV调整节点组
  - 相机视图坐标中的自动边界框计算
  - 带有偏移和缩放的完整UV变换
  - 对象属性面板中的UI集成
  - 支持相机投影UV重新映射到对象边界

### 增强
- 扩展 `names.py` 添加UV调整常量和命名函数
- 增强 `node_groups.py` 添加边界计算和节点组创建
- 更新 `__init__.py` 添加新的UI面板和操作符类


## [0.1.0] - 2022-03-05

### 一般改进
- 等等。

### Bug修复
- 等等。


[Unreleased]: https://github.com/EatTheFuture/gi_comp/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/EatTheFuture/image_rools/release/tag/v0.1.0
