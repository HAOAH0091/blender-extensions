# -*- coding: utf-8 -*-

"""
Compify插件的中文翻译
Translation dictionary for Compify addon
"""

import bpy

# 翻译字典，格式：{locale: {(context, msgid): translation}}
translations_dict = {
    "zh_CN": {
        # 面板标题 - 使用 "*" 上下文
        ("*", "Compify"): "Compify",
        ("*", "Camera Project UV Adjust"): "相机投影UV调整",
        ("*", "Align Camera Track"): "对齐相机跟踪",
        
        # 主面板标签
        ("*", "    Footage:"): "    素材:",
        ("*", "  Color Space"): "  色彩空间",
        ("*", "  Camera"): "  相机",
        ("*", "    Collections:"): "    集合:",
        ("*", "  Footage Geo"): "  素材几何体",
        ("*", "  Footage Lights"): "  素材灯光",
        
        # 操作按钮标题 - 使用 "*" 上下文（Blender会自动处理Operator标签）
        ("*", "Prep Scene"): "准备场景",
        ("*", "Bake Footage Lighting"): "烘焙素材光照",
        ("*", "Render Animation with Compify Integration"): "使用Compify集成渲染动画",
        ("*", "New Camera Project Node Group"): "新建相机投影节点组",
        ("*", "Add Footage Geo Collection"): "添加素材几何体集合",
        ("*", "Add Footage Lights Collection"): "添加素材灯光集合",
        ("*", "Batch Generate UV Adjust"): "批量生成UV调整",
        ("*", "Refresh & Clean UV Adjust List"): "刷新和清理UV调整列表",
        ("*", "Select Object"): "选择对象",
        ("*", "Select Camera"): "选择相机",
        ("*", "Update UV Adjust"): "更新UV调整",
        ("*", "Delete UV Adjust"): "删除UV调整",
        ("*", "Align Transform"): "对齐变换",
        ("*", "Add Alignment Point"): "添加对齐点",
        ("*", "Remove Alignment Point"): "移除对齐点",
        ("*", "Move Alignment Point"): "移动对齐点",
        ("*", "Set target to 3D cursor"): "设置目标到3D游标",
        ("*", "Set track point to 3D cursor"): "设置跟踪点到3D游标",
        
        # UV调整面板
        ("*", "Refresh & Clean"): "刷新和清理",
        ("*", "Batch Generate:"): "批量生成:",
        ("*", "Camera"): "相机",
        ("*", "Generate for Selected Objects"): "为选中对象生成",
        ("*", "Selected Mesh Objects: {}"): "选中的网格对象: {}",
        ("*", "No mesh objects selected"): "未选中网格对象",
        ("*", "Node Groups Management:"): "节点组管理:",
        ("*", "No UV Adjust node groups found"): "未找到UV调整节点组",
        
        # 投影材质管理面板
        ("*", "Projection Material Management:"): "投影材质管理:",
        ("*", "No projection materials found"): "未找到投影材质",
        ("*", "Found {} unused node groups"): "发现 {} 个未使用的节点组",
        ("*", "Clean"): "清理",
        ("*", "Shared Group"): "共用组",
        ("*", "Clean Unused Node Groups"): "清理未使用的节点组",
        ("*", "Clean unused node groups."): "清理未使用的节点组。",
        ("*", "Select Material Objects"): "选择材质物体",
        ("*", "Select all objects using this material."): "选择所有使用此材质的物体。",
        
        # UV调整操作 - 已移动到上面的操作按钮标题部分
        
        # 相机对齐面板（来自camera_align.py）
        ("*", "From"): "从",
        ("*", "To"): "到",
        ("*", "Name"): "名称",
        ("*", "Scene Point"): "场景点",
        ("*", "Track Point"): "跟踪点",
        
        # 相机对齐操作描述
        ("*", "Adds an alignment point"): "添加一个对齐点",
        ("*", "Removes an alignment point"): "移除一个对齐点",
        ("*", "Moves an alignment point's order in the list"): "移动对齐点在列表中的顺序",
        ("*", "Transforms the active object to move the specified track points to the specified target points"): "变换活动对象以将指定的跟踪点移动到指定的目标点",
        ("*", "Sets the target point to the current 3D cursor position"): "将目标点设置为当前3D光标位置",
        ("*", "Sets the tracking point to the current 3D cursor position"): "将跟踪点设置为当前3D光标位置",
        ("*", "Align multiple tracked cameras to each other."): "将多个跟踪相机相互对齐。",
        ("*", "Point {}"): "点 {}",
        
        # 属性描述
        ("*", "Footage Texture"): "素材纹理",
        ("*", "Footage Camera"): "素材相机",
        ("*", "Footage Geo Collection"): "素材几何体集合",
        ("*", "Footage Lights Collection"): "素材灯光集合",
        ("*", "Bake UV Margin"): "烘焙UV边距",
        ("*", "Bake Resolution"): "烘焙分辨率",
        ("*", "UV Adjust Camera"): "UV调整相机",
        ("*", "Camera to use for UV adjustment calculations"): "用于UV调整计算的相机",
        
        # 操作描述
        ("*", "Composite in 3D space."): "在3D空间中合成。",
        ("*", "Configure cameras for 3D compositing."): "配置用于3D合成的相机。",
        ("*", "Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."): "3D合成中对象的相机投影UV调整 - 3D视口侧边栏。",
        ("*", "Prepares the scene for compification"): "为合成准备场景",
        ("*", "Does the Compify lighting baking for proxy geometry"): "为代理几何体执行Compify光照烘焙",
        ("*", "Render, but with Compify baking before rendering each frame"): "渲染，但在渲染每帧之前进行Compify烘焙",
        ("*", "Creates and assigns a new empty collection for footage geometry"): "创建并分配新的空集合用于素材几何体",
        ("*", "Creates and assigns a new empty collection for footage lights"): "创建并分配新的空集合用于素材灯光",
        ("*", "Creates a new camera projection node group from the current selected camera"): "从当前选中的相机创建新的相机投影节点组",
        ("*", "Batch generate UV adjustment node groups for selected mesh objects"): "为选中的网格对象批量生成UV调整节点组",
        ("*", "Refresh UV Adjust node groups list and clean up invalid references"): "刷新UV调整节点组列表并清理无效引用",
        ("*", "Select the object associated with a UV Adjust node group"): "选择与UV调整节点组关联的对象",
        ("*", "Select the camera associated with a UV Adjust node group"): "选择与UV调整节点组关联的相机",
        ("*", "Update parameters of a UV Adjust node group"): "更新UV调整节点组的参数",
        ("*", "Delete a UV Adjust node group"): "删除UV调整节点组",
        ("*", "Add a collection for footage geometry."): "添加素材几何体集合。",
        ("*", "Add a collection for footage lights."): "添加素材灯光集合。",
        ("*", "Batch generate UV adjust node groups."): "批量生成UV调整节点组。",
        ("*", "Select the object associated with this UV adjust."): "选择与此UV调整关联的对象。",
        ("*", "Select the camera associated with this UV adjust."): "选择与此UV调整关联的相机。",
        ("*", "Delete UV adjust."): "删除UV调整。",

        # Baking feature
        ("*", "Bake Material Projection"): "烘焙材质投影",
        ("*", "Bake camera projection, creating new objects with baked textures"): "烘焙相机投影，创建带有烘焙纹理的新对象",
        ("*", "Auto-unwrap UV"): "自动展 UV",
        ("*", "Automatically unwrap UV for objects with existing UV layers"): "对已有 UV 层的对象自动执行展 UV",
        ("*", "UV Handling"): "UV 处理",
    },
    
    "zh_TW": {
        # 繁体中文翻译（可选）
        ("*", "Compify"): "Compify",
        ("*", "Camera Project UV Adjust"): "相機投影UV調整",
        ("*", "Align Camera Track"): "對齊相機跟蹤",
        ("*", "    Footage:"): "    素材:",
        ("*", "  Color Space"): "  色彩空間",
        ("*", "  Camera"): "  相機",
        ("*", "    Collections:"): "    集合:",
        ("*", "  Footage Geo"): "  素材幾何體",
        ("*", "  Footage Lights"): "  素材燈光",
        ("*", "Prep Scene"): "準備場景",
        ("*", "Bake Footage Lighting"): "烘焙素材光照",
        ("*", "Render Animation with Compify Integration"): "使用Compify整合渲染動畫",
        ("*", "Add Footage Geo Collection"): "添加素材幾何體集合",
        ("*", "Add Footage Lights Collection"): "添加素材燈光集合",
        ("*", "Batch Generate UV Adjust"): "批量生成UV調整",
        ("*", "Refresh & Clean UV Adjust List"): "刷新和清理UV調整列表",
        ("*", "Select Object"): "選擇物件",
        ("*", "Select Camera"): "選擇相機",
        ("*", "Update UV Adjust"): "更新UV調整",
        ("*", "Delete UV Adjust"): "刪除UV調整",
        ("*", "Align Transform"): "對齊變換",
        ("*", "Add Alignment Point"): "添加對齊點",
        ("*", "Remove Alignment Point"): "移除對齊點",
        ("*", "Move Alignment Point"): "移動對齊點",
        ("*", "Set target to 3D cursor"): "設置目標到3D游標",
        ("*", "Set track point to 3D cursor"): "設置跟蹤點到3D游標",

        # 3D視口分欄中的列表與狀態文本
        ("*", "Refresh & Clean"): "刷新和清理",
        ("*", "Batch Generate:"): "批量生成:",
        ("*", "Camera"): "相機",
        ("*", "Generate for Selected Objects"): "為選中對象生成",
        ("*", "Selected Mesh Objects: {}"): "選中的網格對象: {}",
        ("*", "No mesh objects selected"): "未選中網格對象",
        ("*", "Node Groups Management:"): "節點組管理:",
        ("*", "No UV Adjust node groups found"): "未找到UV調整節點組",

        # 投影材質管理面板
        ("*", "Projection Material Management:"): "投影材質管理:",
        ("*", "No projection materials found"): "未找到投影材質",
        ("*", "Found {} unused node groups"): "發現 {} 個未使用的節點組",
        ("*", "Clean"): "清理",
        ("*", "Shared Group"): "共用組",
        ("*", "Clean Unused Node Groups"): "清理未使用的節點組",
        ("*", "Clean unused node groups."): "清理未使用的節點組。",
        ("*", "Select Material Objects"): "選擇材質物體",
        ("*", "Select all objects using this material."): "選擇所有使用此材質的物體。",

        # 對齊面板的列標題
        ("*", "From"): "從",
        ("*", "To"): "到",
        ("*", "Name"): "名稱",
        ("*", "Scene Point"): "場景點",
        ("*", "Track Point"): "跟蹤點",

        # 操作描述（tooltip）
        ("*", "Adds an alignment point"): "添加一個對齊點",
        ("*", "Removes an alignment point"): "移除一個對齊點",
        ("*", "Moves an alignment point's order in the list"): "移動對齊點在列表中的順序",
        ("*", "Transforms the active object to move the specified track points to the specified target points"): "變換活動對象以將指定的跟蹤點移動到指定的目標點",
        ("*", "Sets the target point to the current 3D cursor position"): "將目標點設置為當前3D游標位置",
        ("*", "Sets the tracking point to the current 3D cursor position"): "將跟蹤點設置為當前3D游標位置",
        ("*", "Align multiple tracked cameras to each other."): "將多個跟蹤相機相互對齊。",
        ("*", "Point {}"): "點 {}",

        # 屬性描述
        ("*", "Footage Texture"): "素材紋理",
        ("*", "Footage Camera"): "素材相機",
        ("*", "Footage Geo Collection"): "素材幾何體集合",
        ("*", "Footage Lights Collection"): "素材燈光集合",
        ("*", "Bake UV Margin"): "烘焙UV邊距",
        ("*", "Bake Resolution"): "烘焙分辨率",
        ("*", "UV Adjust Camera"): "UV調整相機",
        ("*", "Camera to use for UV adjustment calculations"): "用於UV調整計算的相機",

        # 面板/操作的 tooltip 描述
        ("*", "Composite in 3D space."): "在3D空間中合成。",
        ("*", "Configure cameras for 3D compositing."): "配置用於3D合成的相機。",
        ("*", "Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."): "3D合成中對象的相機投影UV調整 - 3D視口側邊欄。",
        ("*", "Prepares the scene for compification"): "為合成準備場景",
        ("*", "Does the Compify lighting baking for proxy geometry"): "為代理幾何體執行Compify光照烘焙",
        ("*", "Render, but with Compify baking before rendering each frame"): "渲染，但在渲染每幀之前進行Compify烘焙",
        ("*", "Creates and assigns a new empty collection for footage geometry"): "創建並分配新的空集合用於素材幾何體",
        ("*", "Creates and assigns a new empty collection for footage lights"): "創建並分配新的空集合用於素材燈光",
        ("*", "Creates a new camera projection node group from the current selected camera"): "從當前選中的相機創建新的相機投影節點組",
        ("*", "Batch generate UV adjustment node groups for selected mesh objects"): "為選中的網格對象批量生成UV調整節點組",
        ("*", "Refresh UV Adjust node groups list and clean up invalid references"): "刷新UV調整節點組列表並清理無效引用",
        ("*", "Select the object associated with a UV Adjust node group"): "選擇與UV調整節點組關聯的物件",
        ("*", "Select the camera associated with a UV Adjust node group"): "選擇與UV調整節點組關聯的相機",
        ("*", "Update parameters of a UV Adjust node group"): "更新UV調整節點組的參數",
        ("*", "Delete a UV Adjust node group"): "刪除UV調整節點組",
        ("*", "Add a collection for footage geometry."): "添加素材幾何體集合。",
        ("*", "Add a collection for footage lights."): "添加素材燈光集合。",
        ("*", "Batch generate UV adjust node groups."): "批量生成UV調整節點組。",
        ("*", "Select the object associated with this UV adjust."): "選擇與此UV調整關聯的物件。",
        ("*", "Select the camera associated with this UV adjust."): "選擇與此UV調整關聯的相機。",
        ("*", "Delete UV adjust."): "刪除UV調整。",
        # 可以继续添加更多繁体中文翻译...

        # Baking feature
        ("*", "Bake Material Projection"): "烘焙材質投影",
        ("*", "Bake camera projection, creating new objects with baked textures"): "烘焙相機投影，創建帶有烘焙紋理的新物件",
        ("*", "Auto-unwrap UV"): "自動展 UV",
        ("*", "Automatically unwrap UV for objects with existing UV layers"): "對已有 UV 層的物件自動執行展 UV",
        ("*", "UV Handling"): "UV 處理",
    }
}

def register(module_name):
    """注册翻译，必须使用插件根模块名作为域"""
    try:
        # 兼容不同版本的中文语言代码：将 zh_CN 映射到 zh_Hans/zh_HANS/zh
        # 将 zh_TW 映射到 zh_Hant/zh_HANT
        aliases = {
            "zh_CN": ["zh_Hans", "zh_HANS", "zh"],
            "zh_TW": ["zh_Hant", "zh_HANT"],
        }
        for src, alist in aliases.items():
            if src in translations_dict:
                for alias in alist:
                    if alias not in translations_dict:
                        translations_dict[alias] = translations_dict[src]
        
        bpy.app.translations.register(module_name, translations_dict)
        print(f"Compify translations registered successfully for domain: {module_name}")
    except Exception as e:
        print(f"Failed to register Compify translations: {e}")


def unregister(module_name):
    """注销翻译，域必须与注册时一致"""
    try:
        bpy.app.translations.unregister(module_name)
        print(f"Compify translations unregistered successfully for domain: {module_name}")
    except Exception as e:
        print(f"Failed to unregister Compify translations: {e}")

if __name__ == "__main__":
    register(__name__)