# ====================== BEGIN GPL LICENSE BLOCK ======================
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ======================= END GPL LICENSE BLOCK ========================

"""UV Adjust node group management for Compify.

CRUD operations for UV Adjust node groups: list, clean, update, delete,
rename handling. Imports core creation and utility functions from node_groups.py.
"""

import bpy

from .names import (
    UV_ADJUST_INPUT_SOCKET_NAME,
    UV_ADJUST_OUTPUT_SOCKET_NAME,
    UV_ADJUST_NODE_GROUP_PREFIX,
    uv_adjust_node_group_name,
    camera_project_node_group_name,
)
from .node_groups import (
    find_object_by_data_name,
    find_objects_using_material,
    extract_camera_from_camera_project_group,
    find_camera_connected_to_uv_adjust_in_material,
    create_uv_adjust_node_group,
    ensure_camera_project_group,
    check_camera_project_group_exists,
    get_object_camera_bounds,
)

# ========================================================
# Module-level cache for get_all_uv_adjust_node_groups()
# Cache is keyed by scene name.  Rather than tracking individual
# invalidation per scene (which leaks entries on scene rename),
# we simply clear the entire cache.  The rescan is cheap and
# guarantees consistency after any write operation.
# ========================================================

_uv_adjust_cache = {}  # {scene_name: result_list}


def invalidate_uv_cache(scene=None):
    """Invalidate the cached UV adjust node group list.

    Call after any operation that modifies node groups or
    material assignments.  Clears the entire cache to avoid
    stale entries from scene renames or multi-scene edits.
    """
    _uv_adjust_cache.clear()


def get_all_uv_adjust_node_groups(scene=None):
    """
    Get all UV Adjust node groups in the current scene.

    Results are cached per scene and invalidated automatically
    when node groups are modified via Compify operators.

    Args:
        scene: Optional scene to filter by. If None, uses bpy.context.scene.

    Returns:
        list: List of dicts with node_group, object, camera, materials info.
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene

    # Return cached result if available
    if scene.name in _uv_adjust_cache:
        return _uv_adjust_cache[scene.name]
    uv_adjust_groups = []

    for group in bpy.data.node_groups:
        # Identify by custom property (preferred) or name prefix (fallback for old node groups)
        is_uv_adjust = group.get(
            "compify_node_type"
        ) == "uv_adjust" or group.name.startswith(f"{UV_ADJUST_NODE_GROUP_PREFIX} |")

        if not is_uv_adjust:
            continue

        # Prefer metadata properties over name parsing
        object_data_name = group.get("compify_uv_object_data_name", None)
        camera_data_name = group.get("compify_uv_camera_data_name", None)

        # Fallback to name parsing if metadata missing
        if not object_data_name or not camera_data_name:
            parts = group.name.split(" | ")
            if len(parts) == 3:
                _, object_data_name, camera_data_name = parts
            else:
                object_data_name = None
                camera_data_name = None

        usage_info = get_node_group_usage_info(group)
        materials = [info["material"] for info in usage_info]

        resolved_obj = None
        for mat_name in materials:
            objs = find_objects_using_material(mat_name)
            if objs:
                resolved_obj = objs[0]
                break
        if not resolved_obj and object_data_name:
            resolved_obj = find_object_by_data_name(
                object_data_name, type_filter="MESH"
            )

        resolved_cam = None
        for mat_name in materials:
            mat = bpy.data.materials.get(mat_name)
            if mat:
                cam_obj = find_camera_connected_to_uv_adjust_in_material(mat, group)
                if cam_obj:
                    resolved_cam = cam_obj
                    break
        if not resolved_cam and camera_data_name:
            resolved_cam = find_object_by_data_name(
                camera_data_name, type_filter="CAMERA"
            )

        is_valid = (
            resolved_obj is not None
            and resolved_cam is not None
            and resolved_obj.name in scene.objects
            and resolved_cam.name in scene.objects
            and resolved_cam.type == "CAMERA"
        )

        uv_adjust_groups.append(
            {
                "node_group": group,
                "object_name": (
                    resolved_obj.data.name
                    if resolved_obj and getattr(resolved_obj, "data", None)
                    else (object_data_name or "")
                ),
                "camera_name": (
                    resolved_cam.data.name
                    if resolved_cam and getattr(resolved_cam, "data", None)
                    else (camera_data_name or "")
                ),
                "object": resolved_obj,
                "camera": resolved_cam,
                "is_valid": is_valid,
                "materials": materials,
            }
        )

        try:
            if resolved_obj:
                new_obj_data_name = (
                    resolved_obj.data.name
                    if getattr(resolved_obj, "data", None)
                    else resolved_obj.name
                )
                if group.get("compify_uv_object_data_name") != new_obj_data_name:
                    group["compify_uv_object_data_name"] = new_obj_data_name
            if resolved_cam:
                new_cam_data_name = (
                    resolved_cam.data.name
                    if getattr(resolved_cam, "data", None)
                    else resolved_cam.name
                )
                if group.get("compify_uv_camera_data_name") != new_cam_data_name:
                    group["compify_uv_camera_data_name"] = new_cam_data_name
        except Exception as e:
            print(f"Compify: Warning - failed to update UV adjust metadata: {e}")

    # Filter by scene - only include groups used by objects in the specified scene
    scene_groups = []
    for group_info in uv_adjust_groups:
        materials = group_info.get("materials", [])
        is_in_scene = False

        # Check if any object in the scene uses these materials
        for obj in scene.objects:
            if obj.type == "MESH" and obj.data and obj.data.materials:
                obj_materials = {m.name for m in obj.data.materials if m}
                if any(mat_name in obj_materials for mat_name in materials):
                    is_in_scene = True
                    break

        if is_in_scene:
            scene_groups.append(group_info)

    # Cache result for subsequent calls
    _uv_adjust_cache[scene.name] = scene_groups
    return scene_groups


def clean_invalid_uv_adjust_node_groups(scene=None):
    """
    Remove UV Adjust node groups that reference non-existent objects or cameras.

    Args:
        scene: Optional scene to operate on. If None, uses current scene.

    Returns:
        int: Number of node groups cleaned up
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene
    invalidate_uv_cache(scene)

    cleaned_count = 0
    groups_to_remove = []

    for group_info in get_all_uv_adjust_node_groups(scene):
        if not group_info["is_valid"]:
            groups_to_remove.append(group_info["node_group"])

    # Remove invalid node groups
    for group in groups_to_remove:
        bpy.data.node_groups.remove(group)
        cleaned_count += 1

    # Re-invalidate after deletion: the earlier get_all_uv_adjust_node_groups()
    # rebuilt the cache, but we just removed groups from Blender, so cached
    # references are now stale.
    invalidate_uv_cache(scene)
    return cleaned_count


def get_orphan_uv_adjust_node_groups(scene=None):
    """
    Get UV Adjust node groups that are not used by any material.

    Args:
        scene: Optional scene to operate on. If None, uses current scene.

    Returns:
        list: List of node group objects that are orphans (not used in any material)
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene

    orphan_groups = []

    for group_info in get_all_uv_adjust_node_groups(scene):
        if not group_info["materials"]:  # No materials using this node group
            orphan_groups.append(group_info["node_group"])

    return orphan_groups


def clean_orphan_uv_adjust_node_groups(scene=None):
    """
    Remove UV Adjust node groups that are not used by any material.

    Args:
        scene: Optional scene to operate on. If None, uses current scene.

    Returns:
        int: Number of orphan node groups cleaned up
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene
    invalidate_uv_cache(scene)

    cleaned_count = 0
    orphan_groups = get_orphan_uv_adjust_node_groups(scene)

    for group in orphan_groups:
        try:
            bpy.data.node_groups.remove(group)
            cleaned_count += 1
        except Exception as e:
            print(f"Compify: Warning - failed to remove orphan node group: {e}")

    # Re-invalidate after deletion (same reason as clean_invalid above)
    invalidate_uv_cache(scene)
    return cleaned_count


def update_uv_adjust_node_group_parameters(node_group, obj, camera, scene):
    """
    Update the parameters of an existing UV Adjust node group without recreating it.

    Args:
        node_group: The UV Adjust node group to update
        obj: Blender object
        camera: Blender camera object
        scene: Blender scene object

    Returns:
        bool: True if update was successful, False otherwise
    """
    try:
        # Recalculate the UV adjustment parameters
        offset, scale = get_object_camera_bounds(scene, camera, obj)

        # Find the subtract and divide nodes
        subtract_node = None
        divide_node = None

        for node in node_group.nodes:
            if node.type == "VECT_MATH" and node.operation == "SUBTRACT":
                subtract_node = node
            elif node.type == "VECT_MATH" and node.operation == "DIVIDE":
                divide_node = node

        if subtract_node is None or divide_node is None:
            return False

        # Update the offset values
        subtract_node.inputs[1].default_value = (offset[0], offset[1], 0.0)

        # Update the scale values with safety check
        safe_scale_x = max(scale[0], 0.001)
        safe_scale_y = max(scale[1], 0.001)
        divide_node.inputs[1].default_value = (safe_scale_x, safe_scale_y, 1.0)

        return True

    except Exception as e:
        print(f"Compify: Warning in update_uv_adjust_node_group_parameters: {e}")
        return False


def clean_material_nodes_for_uv_adjust(obj, camera, uv_adjust_node_group):
    """
    Clean UV Adjust and Camera Project nodes from the object's material.

    Args:
        obj: Blender object
        camera: Blender camera object
        uv_adjust_node_group: The UV Adjust node group being deleted

    Returns:
        bool: True if cleanup was successful, False otherwise
    """
    try:
        # Check if object has materials
        if not obj or not obj.data.materials:
            return True

        # Get the first material
        material = obj.data.materials[0]
        if not material or not material.use_nodes:
            return True

        node_tree = material.node_tree
        if not node_tree:
            return True

        # Get camera project node group name
        camera_project_group_name = camera_project_node_group_name(camera)

        # Find and remove UV Adjust node from material
        uv_adjust_nodes_to_remove = []
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == uv_adjust_node_group.name
            ):
                uv_adjust_nodes_to_remove.append(node)

        # Find and remove Camera Project node from material
        camera_project_nodes_to_remove = []
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == camera_project_group_name
            ):
                camera_project_nodes_to_remove.append(node)

        # Remove the nodes
        for node in uv_adjust_nodes_to_remove:
            node_tree.nodes.remove(node)

        for node in camera_project_nodes_to_remove:
            node_tree.nodes.remove(node)

        return True

    except Exception as e:
        print(f"Compify: Warning in clean_material_nodes_for_uv_adjust: {e}")
        return False


def delete_uv_adjust_node_group(node_group):
    """
    Delete a UV Adjust node group and clean up related nodes in materials.

    Args:
        node_group: The node group to delete

    Returns:
        bool: True if deletion was successful, False otherwise
    """
    try:
        if not node_group or node_group.name not in bpy.data.node_groups:
            return False

        # Prefer metadata properties over name parsing
        object_data_name = node_group.get("compify_uv_object_data_name")
        camera_data_name = node_group.get("compify_uv_camera_data_name")

        # Fallback: parse the node group name
        if not object_data_name or not camera_data_name:
            parts = node_group.name.split(" | ")
            if len(parts) == 3:
                _, object_data_name, camera_data_name = parts

        # Resolve objects from data-block names
        obj = (
            find_object_by_data_name(object_data_name, type_filter="MESH")
            if object_data_name
            else None
        )
        camera_obj = (
            find_object_by_data_name(camera_data_name, type_filter="CAMERA")
            if camera_data_name
            else None
        )

        # Clean up material nodes if objects exist
        if obj and camera_obj:
            clean_material_nodes_for_uv_adjust(obj, camera_obj, node_group)

        # Delete the UV Adjust node group data block
        bpy.data.node_groups.remove(node_group)
        return True

    except Exception as e:
        print(f"Compify: Warning in delete_uv_adjust_node_group: {e}")
        return False


def handle_object_rename_in_node_groups(scene=None):
    """
    Handle object/camera renames by updating node group names to match current object names.
    This function attempts to match node groups with existing objects even if names have changed.

    Args:
        scene: Optional scene to filter by. If None, uses bpy.context.scene.

    Returns:
        dict: Summary of rename operations performed
            {
                'updated': int,  # Number of node groups updated
                'orphaned': int,  # Number of orphaned node groups found
                'details': list  # List of update details
            }
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene
    invalidate_uv_cache(scene)

    result = {"updated": 0, "orphaned": 0, "details": []}

    try:
        # Get all UV Adjust node groups
        all_groups = get_all_uv_adjust_node_groups(scene)

        for group_info in all_groups:
            node_group = group_info["node_group"]
            old_name = node_group.name

            # If the group is valid, check if we need to update the name
            if group_info["is_valid"]:
                obj = group_info["object"]
                camera = group_info["camera"]

                # Generate what the name should be based on current object names
                expected_name = uv_adjust_node_group_name(obj, camera)

                # If the name doesn't match, update it
                if old_name != expected_name:
                    # Check if the expected name already exists
                    if expected_name not in bpy.data.node_groups:
                        node_group.name = expected_name
                        result["updated"] += 1
                        result["details"].append(
                            f"Renamed '{old_name}' to '{expected_name}'"
                        )
                    else:
                        # Name conflict - keep the old name but note the issue
                        result["details"].append(
                            f"Name conflict: '{old_name}' should be '{expected_name}' but name exists"
                        )
            else:
                result["orphaned"] += 1
                result["details"].append(f"Orphaned node group: '{old_name}'")

        return result

    except Exception as e:
        result["details"].append(f"Error during rename handling: {str(e)}")
        return result


def get_node_group_usage_info(node_group):
    """
    Get information about where a node group is being used in materials.

    Args:
        node_group: The node group to check

    Returns:
        list: List of materials using this node group
    """
    usage_info = []

    try:
        # 遍历所有材质，每个材质单独保护
        for material in bpy.data.materials:
            try:
                # 安全访问材质节点树
                if not material.node_tree:
                    continue

                # 遍历节点，每个节点单独保护
                for node in material.node_tree.nodes:
                    try:
                        # 检查节点类型和节点树
                        if node.type != "GROUP":
                            continue

                        if not node.node_tree:
                            continue

                        # 安全比较节点树名称
                        try:
                            node_tree_name = node.node_tree.name
                            target_name = node_group.name

                            if node_tree_name == target_name:
                                # 安全获取名称
                                material_name = material.name
                                node_name = node.name

                                usage_info.append(
                                    {"material": material_name, "node": node_name}
                                )
                        except (UnicodeDecodeError, UnicodeEncodeError) as e:
                            # 编码错误 - 跳过这个节点，继续处理其他节点
                            print(
                                f"Compify: Encoding error in node tree name comparison: {e}"
                            )
                            continue

                    except Exception as e:
                        # 单个节点访问失败 - 跳过这个节点
                        print(f"Compify: Error accessing node: {e}")
                        continue

            except Exception as e:
                # 单个材质访问失败 - 跳过这个材质，继续处理其他材质
                print(
                    f"Compify: Error accessing material '{getattr(material, 'name', 'unknown')}': {e}"
                )
                continue

        return usage_info

    except Exception as e:
        # 整体错误（不太可能到这里，但作为最后防线）
        print(f"Compify: Warning in get_node_group_usage_info: {e}")
        return usage_info  # 返回已收集的数据，而不是空列表


def add_uv_adjust_to_material(obj, camera, uv_adjust_node_group):
    """
    Add UV Adjust node group to the first material of an object and connect it with Camera Project node group.

    Args:
        obj: Blender object
        camera: Blender camera object
        uv_adjust_node_group: The UV Adjust node group to add

    Returns:
        dict: Result information
            {
                'success': bool,
                'message': str,
                'material': Material or None,
                'camera_project_node': Node or None,
                'uv_adjust_node': Node or None
            }
    """
    result = {
        "success": False,
        "message": "",
        "material": None,
        "camera_project_node": None,
        "uv_adjust_node": None,
    }

    try:
        # Check if object has materials
        if not obj.data.materials:
            # Create a new material if none exists
            material = bpy.data.materials.new(name=f"{obj.name}_Material")
            obj.data.materials.append(material)
            # Enable use_nodes
            material.use_nodes = True
        else:
            # Use the first material
            material = obj.data.materials[0]
            if not material:
                result["message"] = "First material slot is empty"
                return result

            # Enable use_nodes if not already enabled
            if not material.use_nodes:
                material.use_nodes = True

        result["material"] = material
        node_tree = material.node_tree

        # Get camera project node group name
        camera_project_group_name = camera_project_node_group_name(camera)

        # Check if camera project node group exists
        if camera_project_group_name not in bpy.data.node_groups:
            result["message"] = (
                f"Camera project node group '{camera_project_group_name}' not found"
            )
            return result

        camera_project_group = bpy.data.node_groups[camera_project_group_name]

        # Check if camera project node already exists in the material
        camera_project_node = None
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == camera_project_group_name
            ):
                camera_project_node = node
                break

        # Add camera project node if it doesn't exist
        if not camera_project_node:
            camera_project_node = node_tree.nodes.new(type="ShaderNodeGroup")
            camera_project_node.node_tree = camera_project_group
            camera_project_node.name = camera_project_node_group_name(camera)
            # Short label: show camera data-block name
            camera_project_node.label = (
                camera.data.name if getattr(camera, "data", None) else camera.name
            )
            camera_project_node.location = (-400, 0)

        # Ensure short label even if node pre-existed
        camera_project_node.label = (
            camera.data.name if getattr(camera, "data", None) else camera.name
        )

        result["camera_project_node"] = camera_project_node

        # Check if UV adjust node already exists in the material
        uv_adjust_node = None
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == uv_adjust_node_group.name
            ):
                uv_adjust_node = node
                break

        # Add UV adjust node if it doesn't exist
        if not uv_adjust_node:
            uv_adjust_node = node_tree.nodes.new(type="ShaderNodeGroup")
            uv_adjust_node.node_tree = uv_adjust_node_group
            uv_adjust_node.name = uv_adjust_node_group_name(obj, camera)
            # Short label: show object data-block name
            uv_adjust_node.label = (
                obj.data.name if getattr(obj, "data", None) else obj.name
            )
            uv_adjust_node.location = (-200, 0)

        # Ensure short label even if node pre-existed
        uv_adjust_node.label = obj.data.name if getattr(obj, "data", None) else obj.name

        result["uv_adjust_node"] = uv_adjust_node

        # Connect camera project output to UV adjust input
        # Find the Vector output from camera project node
        camera_project_output = None
        for output in camera_project_node.outputs:
            if output.type == "VECTOR":
                camera_project_output = output
                break

        # Find the Camera Projection UV input in UV adjust node
        uv_adjust_input = None
        for input_socket in uv_adjust_node.inputs:
            if input_socket.name == UV_ADJUST_INPUT_SOCKET_NAME:
                uv_adjust_input = input_socket
                break

        # Create the connection if both sockets are found
        if camera_project_output and uv_adjust_input:
            # Remove existing connection to UV adjust input if any
            for link in node_tree.links:
                if link.to_socket == uv_adjust_input:
                    node_tree.links.remove(link)

            # Create new connection
            node_tree.links.new(camera_project_output, uv_adjust_input)

        # Connect UV adjust output to the first image texture node's Vector input
        # Find the Adjusted UV output from UV adjust node
        uv_adjust_output = None
        for output in uv_adjust_node.outputs:
            if output.name == UV_ADJUST_OUTPUT_SOCKET_NAME:
                uv_adjust_output = output
                break

        # Find the first image texture node in the material
        first_image_node = None
        for node in node_tree.nodes:
            if node.type == "TEX_IMAGE":
                first_image_node = node
                break

        # Connect UV adjust output to image node's Vector input if both are found
        if uv_adjust_output and first_image_node:
            # Find the Vector input in the image node
            vector_input = None
            for input_socket in first_image_node.inputs:
                if input_socket.type == "VECTOR" and input_socket.name == "Vector":
                    vector_input = input_socket
                    break

            if vector_input:
                # Remove existing connection to image node's Vector input if any
                for link in node_tree.links:
                    if link.to_socket == vector_input:
                        node_tree.links.remove(link)

                # Create new connection from UV adjust to image node
                node_tree.links.new(uv_adjust_output, vector_input)

        # Set success status and message
        if camera_project_output and uv_adjust_input:
            if uv_adjust_output and first_image_node:
                result["success"] = True
                result["message"] = (
                    f"Successfully added and connected node groups in material '{material.name}', including connection to image texture node"
                )
            else:
                result["success"] = True
                result["message"] = (
                    f"Successfully added and connected node groups in material '{material.name}', but no image texture node found for UV connection"
                )
        else:
            result["success"] = True  # Nodes were added even if connection failed
            result["message"] = (
                f"Added node groups to material '{material.name}' but connection failed"
            )

        return result

    except Exception as e:
        result["message"] = f"Error adding to material: {str(e)}"
        return result


def create_and_add_uv_adjust_node_group(scene, camera, obj):
    """
    Create UV adjustment node group and automatically add it to the object's first material.

    Args:
        scene: Blender scene object
        camera: Blender camera object
        obj: Blender object to create UV adjustment for

    Returns:
        dict: Result information
            {
                'success': bool,
                'message': str,
                'node_group': NodeGroup or None,
                'material_result': dict or None
            }
    """
    result = {
        "success": False,
        "message": "",
        "node_group": None,
        "material_result": None,
    }

    try:
        # Create the UV adjustment node group
        node_group = create_uv_adjust_node_group(scene, camera, obj)
        result["node_group"] = node_group

        # Add to material and connect
        material_result = add_uv_adjust_to_material(obj, camera, node_group)
        result["material_result"] = material_result

        if material_result["success"]:
            result["success"] = True
            result["message"] = (
                f"Created UV adjust node group and {material_result['message']}"
            )
        else:
            result["success"] = True  # Node group was created successfully
            result["message"] = (
                f"Created UV adjust node group but material integration failed: {material_result['message']}"
            )

        return result

    except Exception as e:
        result["message"] = f"Failed to create UV adjust node group: {str(e)}"
        return result
