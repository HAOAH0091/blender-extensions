---
tags: [compify, 技术笔记, 功能设计, 烘焙]
created: 2026-05-02
updated: 2026-05-03
source: 设计规划
status: 待执行
---

# 功能设计：UV 调整面板材质烘焙（备份式烘焙）

## 概述

在 Compify 的 "Camera Project UV Adjust" 3D 视口侧边栏面板中，为每个投影材质条目新增一个烘焙按钮。点击后弹窗选择分辨率，确认后生成独立的新对象和纯纹理材质，原模型原位不动做备份。

## 用户需求原文

> "用户点击后可以自动烘焙，先结合知识库帮我写个周全的计划"

> "烘焙模式：执行烘焙后直接生成一个新的物体和材质，保留原模型做备份"

---

## 一、功能流程

```
[场景中原本的状态]

  [原对象] ── 使用 ── [原材质]
                        ├── Camera Project 节点   ← 实时投影
                        └── UV Adjust 节点        ← 裁剪到对象边界

                      用户点击该材质的"烘焙"按钮

                      ┌──────────────────────────────────────┐
                      │ 弹窗（invoke_props_dialog）          │
                      │                                      │
                      │  材质：xxx                           │
                      │  关联对象：n 个                       │
                      │  烘焙分辨率：[ 1024 ]                │
                      │  ☐ 自动展 UV（n 个物体已有 UV）     │
                      │  ⚠ 其中 m 个物体无 UV 层，将强制展  │
                      │  ┌──────────────────┐                │
                      │  │     确认烘焙      │                │
                      │  └──────────────────┘                │
                      │                                      │
                      │  原对象不会被修改                    │
                      └──────────────────────────────────────┘

                      确认后自动执行：

  Step 1 ─ 复制原对象（mesh 数据全复制）
       │   → 得到 [烘焙对象]（独立 mesh、独立材质实例）
       │
  Step 2 ─ UV 检测与处理（新增，见下方详细逻辑）
       │
  Step 3 ─ 创建烘焙材质（独立副本，不污染原材质）
       │   → 命名：Baked_{原材质名}
       │
  Step 4 ─ 为每个烘焙对象创建独立烘焙纹理
       │   → 命名：Bake_{材质名}_{对象数据名}
       │
  Step 5 ─ 在烘焙材质中重建临时投影链路
       │   Camera Project 节点 ──→ UV Adjust 节点 ──→ TexImage 节点（设为 active）
       │   选中所有烘焙对象
       │   执行 EMIT 通道烘焙
       │   → 投影结果写入烘焙纹理
       │
  Step 6 ─ 清理烘焙材质中的投影节点
       │   保留：TexImage（烘焙纹理）──→ Material Output
       │   → 得到一个干净的不依赖相机的纯纹理材质
       │
  Step 7 ─ 赋予烘焙材质给烘焙对象
       │
       └── 完成

[结果]

  [原对象]        ── 使用 ── [原材质]         ← 保持不变，备份用
                                Camera Project
                                UV Adjust

  [烘焙对象(新)]  ── 使用 ── [烘焙材质]       ← 纯纹理，可导出
                                TexImage
```

### Step 2 详细逻辑：UV 检测与处理

```
遍历每个复制出来的烘焙对象：

  检查该对象的 mesh 是否有 UV 层（uv_layers.active）
       │
       ├── 有 UV 层 ──→ 用户弹窗中"自动展 UV"复选框的状态：
       │                    ├── 勾选 → 对该对象执行自动展 UV（覆盖原有 UV）
       │                    └── 未勾选 → 保留现有 UV，不处理
       │
       └── 无 UV 层 ──→ 强制执行自动展 UV
                          （弹窗中提示"m 个物体将强制展 UV"）
```

**展 UV 的执行方式**：使用 `bpy.ops.uv.smart_project()`，参数用默认值（角度阈值 66°，面积权重 = 1，等距缩放 = True）。如果后续需要更精细的控制可以再加参数。

---

## 二、设计决策

### 2.1 烘焙模式：备份式

| 选项 | 说明 | 选择 |
|------|------|------|
| 破坏性烘焙 | 直接修改原材质，替换投影节点 | ❌ |
| 非破坏性烘焙 | 在原材质中新增烘焙纹理节点，保留投影节点 | ❌ |
| **备份式烘焙** | **复制对象+材质，烘焙到副本** | ✅ |

优势：原场景零风险，烘焙结果独立干净，可直接导出。

### 2.2 操作模式：非模态（同步）

| 选项 | 说明 | 选择 |
|------|------|------|
| 模态 | 定时器分步执行，界面不卡但实现复杂 | ❌ |
| **非模态** | **同步执行，1~2 秒完成，实现简单** | ✅ |

理由：EMIT 通道的投影烘焙本质是"拍快照"，2048 分辨率内通常在 1~2 秒完成，不足以让用户感知到界面卡顿。如果后续发现大分辨率场景需要优化，可以再改模态。

### 2.3 弹窗交互

使用 Blender 的 `invoke_props_dialog()` 实现，该模式在项目中已有先例（`CompifyDeleteUVAdjust` 的 `invoke_confirm`）。

弹窗内容：
- 材质名（只读显示）
- 关联对象数（只读显示）
- 分辨率选择器（IntProperty，subtype="PIXEL"）
- **自动展 UV 复选框（BoolProperty，默认 True）** ← 新增
- **UV 状态提示文字** ← 新增
- 提示信息（"原对象不会被修改"）

默认分辨率从 `scene.compify_config.bake_image_res` 读取，与 Compify 场景配置保持一致。

### 2.4 纹理命名

格式：`Bake_{材质名}_{对象数据名}`

使用对象的数据块名称（data-block name）而非对象名称，与项目现有命名策略一致。

### 2.5 材质命名

格式：`Baked_{原材质名}`

### 2.6 UV 处理策略（新增）

| 场景 | 行为 | 用户控制 |
|------|------|---------|
| 所有复制对象都有 UV 层 | 按复选框决定是否展 UV | 可关闭 |
| 部分对象有 UV、部分没有 | 有 UV 的按复选框，无 UV 的强制展 | 部分可控 |
| 所有对象都没有 UV | 全部强制展，复选框不可修改 | 跳过 |
| 对象是曲线/表面等非 mesh 类型 | 操作前过滤，仅处理 mesh 对象 | 自动 |

展 UV 使用 Smart UV Project，这是对投影烘焙最稳妥的自动展开方式。不使用 Lightmap Pack 或其他展开方式，因为 Smart Project 的 Isotropic Scale 保证纹理密度均匀。

---

## 三、修改范围

### 涉及的文件

| 文件 | 改动内容 | 新增行数 |
|------|---------|---------|
| `node_groups.py` | 新增核心函数 `bake_material_projection()` | ~140 行 |
| `__init__.py` | 新增操作符类 + 面板加按钮 + 注册/注销 | ~120 行 |
| `names.py` | 新增命名函数 `baked_material_name()` `baked_image_name()` | ~15 行 |
| `uv_utils.py` | 新增 `unwrap_baked_objects()` 工具函数 | ~20 行 |
| `translations.py` | 简繁中文翻译字段 | ~20 行 |

### 不改动的文件

| 文件 | 原因 |
|------|------|
| `bake.py` | 现有 Baker 走光照烘焙（DIFFUSE 通道），和投影烘焙（EMIT 通道）路线不同 |
| `camera_align.py` | 独立功能模块，不相关 |

---

## 四、详细接口设计

### 4.1 `node_groups.py` — `bake_material_projection()`

```python
def bake_material_projection(scene, material, bake_resolution, auto_unwrap=True):
    """
    将材质的相机投影结果烘焙为新对象和新材质。
    
    Parameters
    ----------
    scene : bpy.types.Scene
        当前场景
    material : bpy.types.Material
        要烘焙的材质。必须包含 Camera Project + UV Adjust 节点。
    bake_resolution : int
        烘焙纹理分辨率（像素），范围 64~8192
    auto_unwrap : bool
        是否对已有 UV 的对象执行自动展 UV。无 UV 的对象不受此参数控制，强制展。
    
    Returns
    -------
    dict
        {
            "success": bool,
            "baked_objects": list[bpy.types.Object],
            "baked_material": bpy.types.Material | None,
            "baked_images": list[bpy.types.Image],
            "unwrapped_count": int,        ← 新增
            "forced_unwrap_count": int,    ← 新增
            "message": str
        }
    """
```

#### 伪代码逻辑（更新版）

```
1. 前置验证
   if material not in bpy.data.materials → return error
   objects = find_objects_using_material(material.name)
   if not objects → return error "材质没有被任何对象使用"
   if 材质中没有 Camera Project 节点 → return error "材质没有相机投影设置"

2. 创建烘焙材质
   baked_mat_name = baked_material_name(material.name)
   baked_mat = bpy.data.materials.new(baked_mat_name)
   baked_mat.use_nodes = True
   clear default nodes

3. 复制对象（全复制，含 mesh 数据）
   baked_objects = []
   original_to_baked = {}  # 映射关系
   for obj in objects:
       if obj.type != 'MESH':
           continue  # 仅处理 mesh 对象
       new_obj = obj.copy()
       new_obj.data = obj.data.copy()
       scene.collection.objects.link(new_obj)
       baked_objects.append(new_obj)
       original_to_baked[obj] = new_obj

4. UV 检测与处理（新增）
   unwrapped_count = 0
   forced_unwrap_count = 0
   
   for new_obj in baked_objects:
       mesh = new_obj.data
       has_uv = bool(mesh.uv_layers.active)
       
       if not has_uv:
           # 无 UV 层 → 强制展 UV
           set active object = new_obj
           bpy.ops.object.mode_set(mode='EDIT')
           bpy.ops.mesh.select_all(action='SELECT')
           bpy.ops.uv.smart_project()
           bpy.ops.object.mode_set(mode='OBJECT')
           forced_unwrap_count += 1
       elif auto_unwrap:
           # 有 UV 层 + 用户勾选了自动展 → 覆盖
           set active object = new_obj
           bpy.ops.object.mode_set(mode='EDIT')
           bpy.ops.mesh.select_all(action='SELECT')
           bpy.ops.uv.smart_project()
           bpy.ops.object.mode_set(mode='OBJECT')
           unwrapped_count += 1
       else:
           # 有 UV 层 + 用户未勾选 → 保留原 UV
           pass

5. 为每个烘焙对象创建纹理和节点
   baked_images = []
   for obj, new_obj in zip(objects, baked_objects):
       # 创建纹理
       img_name = baked_image_name(material.name, obj.data.name)
       img = bpy.data.images.new(img_name, bake_resolution, bake_resolution,
                                  alpha=True, float_buffer=True)
       baked_images.append(img)
       
       # 在烘焙材质中添加纹理节点
       tex_node = baked_mat.node_tree.nodes.new(type="ShaderNodeTexImage")
       tex_node.image = img
       tex_node.select = True
       baked_mat.node_tree.nodes.active = tex_node
       
       # 从原材质获取相机
       camera = find_camera_connected_to_uv_adjust_in_material(material, ...)
       
       # 添加 Camera Project 节点
       cp_node = baked_mat.node_tree.nodes.new(type="ShaderNodeGroup")
       cp_node.node_tree = ensure_camera_project_group(camera)
       
       # 添加 UV Adjust 节点
       uv_node = baked_mat.node_tree.nodes.new(type="ShaderNodeGroup")
       uv_node.node_tree = create_uv_adjust_node_group(scene, camera, obj)
       
       # 连接：Camera Project → UV Adjust → TexImage
       baked_mat.node_tree.links.new(cp_node.outputs["Vector"], uv_node.inputs[...])
       baked_mat.node_tree.links.new(uv_node.outputs["Adjusted UV"], tex_node.inputs["Vector"])
       
       # 连接 TexImage → Output（针对这个对象临时用）
       output = baked_mat.node_tree.nodes.new(type="ShaderNodeOutputMaterial")
       baked_mat.node_tree.links.new(tex_node.outputs["Color"], output.inputs["Surface"])

6. 执行 EMIT 烘焙
   取消全部选中
   逐个选中 baked_objects（或全选）
   bpy.ops.object.bake(
       type='EMIT',
       target='IMAGE_TEXTURES',
       use_clear=True,
       margin=4,
       margin_type='EXTEND',
       ...
   )

7. 清理投影节点
   keep_nodes = {tex_node for tex_node in baked_mat.node_tree.nodes 
                 if tex_node.type == 'TEX_IMAGE'}
   for node in list(baked_mat.node_tree.nodes):
       if node not in keep_nodes and node.type not in ('OUTPUT_MATERIAL',):
           baked_mat.node_tree.nodes.remove(node)
   
   # 重新连接：各 TexImage → Output
   for tex_node in keep_nodes:
       baked_mat.node_tree.links.new(
           tex_node.outputs["Color"],
           output_node.inputs["Surface"]
       )

8. 赋予材质
   for new_obj in baked_objects:
       new_obj.data.materials.clear()
       new_obj.data.materials.append(baked_mat)

9. 返回结果（含 unwrapped_count / forced_unwrap_count）
```

### 4.2 `uv_utils.py` — `unwrap_baked_objects()`（新增）

```python
def unwrap_baked_objects(baked_objects, auto_unwrap):
    """
    检测并处理烘焙对象的 UV。
    
    对无 UV 的对象强制展 UV，对有 UV 的对象按 auto_unwrap 决定是否展 UV。
    
    Parameters
    ----------
    baked_objects : list[bpy.types.Object]
        烘焙对象列表（已确认 type == 'MESH'）
    auto_unwrap : bool
        是否对已有 UV 的对象也执行自动展 UV
    
    Returns
    -------
    dict
        {
            "unwrapped": int,    # 按 auto_unwrap 展 UV 的对象数
            "forced": int,       # 强制展 UV 的对象数
            "skipped": int       # 跳过（已有 UV + auto_unwrap=False）
        }
    """
```

伪代码：

```
unwrapped = 0
forced = 0
skipped = 0

for obj in baked_objects:
    mesh = obj.data
    has_uv = bool(mesh.uv_layers.active)
    
    if not has_uv:
        # 无 UV → 强制展
        select_only(obj)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project()
        bpy.ops.object.mode_set(mode='OBJECT')
        forced += 1
    elif auto_unwrap:
        # 有 UV + 用户选择展 → 覆盖
        select_only(obj)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project()
        bpy.ops.object.mode_set(mode='OBJECT')
        unwrapped += 1
    else:
        skipped += 1

# 清理选中状态
bpy.ops.object.select_all(action='DESELECT')

return {"unwrapped": unwrapped, "forced": forced, "skipped": skipped}
```

### 4.3 `__init__.py` — `CompifyBakeMaterialProjection`（更新版）

```python
class CompifyBakeMaterialProjection(bpy.types.Operator):
    """Bake camera projection to textures for new objects"""

    bl_idname = "compify.bake_material_projection"
    bl_label = "Bake Material Projection"
    bl_description = "Bake camera projection, creating new objects with baked textures"
    bl_options = {"UNDO"}

    # ---- Properties ----
    material_name: bpy.props.StringProperty(options={"HIDDEN"})
    bake_resolution: bpy.props.IntProperty(
        name="Resolution",
        default=1024,
        min=64,
        max=8192,
        subtype="PIXEL",
        description="Bake texture resolution in pixels",
    )
    auto_unwrap: bpy.props.BoolProperty(           # ← 新增
        name="Auto-unwrap UV",
        default=True,
        description="Automatically unwrap UV for objects with existing UV layers",
    )

    # ---- Invoke (dialog) ----
    def invoke(self, context, event):
        # Validate material
        material = bpy.data.materials.get(self.material_name)
        if not material:
            self.report({"ERROR"}, "Material not found")
            return {"CANCELLED"}

        # Validate Camera Project node exists
        if not self._has_camera_project(material):
            self.report({"ERROR"}, "Material has no Camera Project node group. "
                                    "Run 'Generate for Selected Objects' first.")
            return {"CANCELLED"}

        # Validate objects exist
        self.affected_objects = find_objects_using_material(self.material_name)
        if not self.affected_objects:
            self.report({"ERROR"}, "No objects in the scene use this material")
            return {"CANCELLED"}

        # 检测 UV 状态（新增）
        self.has_uv_count = 0
        self.no_uv_count = 0
        for obj in self.affected_objects:
            if obj.type == 'MESH':
                if obj.data.uv_layers.active:
                    self.has_uv_count += 1
                else:
                    self.no_uv_count += 1

        # Default resolution from scene config
        self.bake_resolution = context.scene.compify_config.bake_image_res

        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        """Dialog UI layout"""
        layout = self.layout
        material = bpy.data.materials.get(self.material_name)

        # Info box
        box = layout.box()
        if material:
            box.label(text=f"Material:  {material.name}", icon="MATERIAL")
        if self.affected_objects:
            box.label(text=f"Objects:   {len(self.affected_objects)}", icon="MESH_DATA")
            box.label(text=f"Will create: {len(self.affected_objects)} new object(s)", icon="OBJECT_DATA")

        layout.separator()

        # Resolution selector
        layout.prop(self, "bake_resolution")

        layout.separator()

        # UV 处理区域（新增）
        uv_box = layout.box()
        uv_box.label(text="UV Handling", icon="UV")
        
        if self.no_uv_count > 0:
            # 有对象无 UV → 显示提示，强制展 UV
            uv_box.label(
                text=f"⚠ {self.no_uv_count} object(s) have NO UV layer — will auto-unwrap",
                icon="ERROR"
            )
            if self.has_uv_count > 0:
                # 混合场景：复选框对已有 UV 的对象生效
                uv_box.prop(self, "auto_unwrap")
        elif self.has_uv_count > 0:
            # 全部有 UV → 复选框自由控制
            uv_box.prop(self, "auto_unwrap")
        else:
            # 没有 mesh 对象或全部非 mesh
            uv_box.label(text="No mesh objects found", icon="INFO")

        layout.separator()

        # Safety notice
        note = layout.box()
        note.label(text="Original objects will NOT be modified.", icon="INFO")
        note.label(text="A new object with baked texture will be created for each.")

    # ---- Execute ----
    def execute(self, context):
        material = bpy.data.materials.get(self.material_name)
        if not material:
            self.report({"ERROR"}, f"Material '{self.material_name}' not found")
            return {"CANCELLED"}

        result = bake_material_projection(
            scene=context.scene,
            material=material,
            bake_resolution=self.bake_resolution,
            auto_unwrap=self.auto_unwrap,    # ← 传入
        )

        if result["success"]:
            count = len(result["baked_objects"])
            mat_name = result["baked_material"].name if result["baked_material"] else "N/A"
            
            # 组装结果信息（含 UV 处理统计）
            msg_parts = [f"Baked {count} object(s). New material: '{mat_name}'"]
            if result.get("unwrapped_count"):
                msg_parts.append(f"Unwrapped: {result['unwrapped_count']}")
            if result.get("forced_unwrap_count"):
                msg_parts.append(f"Forced unwrap: {result['forced_unwrap_count']}")
            self.report({"INFO"}, ". ".join(msg_parts))
            
            # Redraw 3D view
            for area in context.window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
            return {"FINISHED"}
        else:
            self.report({"ERROR"}, result["message"])
            return {"CANCELLED"}

    # ---- Helpers ----
    @staticmethod
    def _has_camera_project(material):
        if not material.node_tree:
            return False
        for node in material.node_tree.nodes:
            if node.type == "GROUP" and node.node_tree:
                if node.node_tree.name.startswith("Camera Project |"):
                    return True
        return False
```

### 4.4 UI 按钮位置

在 `CompifyUVAdjust3DPanel.draw()` 中，每个材质条目的按钮行。

**单材质条目**：

```
[Select] [Bake(新)] [Update] [Delete]
```

**共享组的子材质条目**：

```
[Select] [Bake(新)]
```

按钮参数：

| 属性 | 值 |
|------|-----|
| `text` | `""`（空，图标按钮） |
| `icon` | `"TEXTURE"` |
| `material_name` | 当前材质的名称 |

### 4.5 注册

```python
# register()
bpy.utils.register_class(CompifyBakeMaterialProjection)

# unregister()
bpy.utils.unregister_class(CompifyBakeMaterialProjection)
```

### 4.6 `names.py` — 命名函数

```python
def baked_material_name(original_material_name):
    """Get baked material name from original material name."""
    return f"Baked_{original_material_name}"


def baked_image_name(material_name, object_data_name):
    """Get baked image name from material and object data names."""
    return f"Bake_{material_name}_{object_data_name}"
```

### 4.7 `translations.py` — 翻译字段

```python
# 简体中文
("(*)", "Bake Material Projection"): "烘焙材质投影",
("(*)", "Bake camera projection, creating new objects with baked textures"): "烘焙相机投影，创建带有烘焙纹理的新对象",
("(*)", "Auto-unwrap UV"): "自动展 UV",
("(*)", "Automatically unwrap UV for objects with existing UV layers"): "对已有 UV 层的对象自动执行展 UV",

# 繁体中文
("(*)", "Bake Material Projection"): "烘焙材質投影",
("(*)", "Bake camera projection, creating new objects with baked textures"): "烘焙相機投影，創建帶有烘焙紋理的新物件",
("(*)", "Auto-unwrap UV"): "自動展 UV",
("(*)", "Automatically unwrap UV for objects with existing UV layers"): "對已有 UV 層的物件自動執行展 UV",
```

---

## 五、边界情况处理

| 场景 | 检测时机 | 处理方式 |
|------|---------|---------|
| 材质在数据库中被删除 | `invoke` 时 | 弹窗提示 "Material not found"，取消操作 |
| 材质没有 Camera Project 节点 | `invoke` 时 | 弹窗提示 "请先生成"，取消操作 |
| 材质关联的对象已被删除 | `invoke` 时 | 弹窗提示 "该材质没有任何对象使用"，取消操作 |
| 对象不在当前场景中 | 执行时 | 只处理 `scene.objects` 中的对象，跳过其他场景 |
| 烘焙时对象在相机视野外 | 执行时 | `world_to_camera_view` 检测，超出范围的对象跳过并警告 |
| 多个对象共用同一材质 | 执行时 | 每个对象独立复制为独立 mesh，共用烘焙材质 |
| Baked_xxx 材质名称已存在 | 执行时 | Blender 自动添加 `.001` 后缀 |
| 烘焙操作中途被取消 | 执行时 | 同步执行，异常时 `try-except` 捕获，清理已创建的对象 |
| 用户没有权限写入图像 | 执行时 | Blender 会抛异常，`try-except` 捕获后返回错误信息 |
| 场景开启多视图或多窗口 | 执行后 | 在面板的 `redraw` 区域循环中触发 `area.tag_redraw()` |
| **对象非 mesh 类型（曲线、表面等）** | **执行时** | **在对象复制阶段过滤，只处理 `type == 'MESH'` 的对象，非 mesh 跳过** |
| **对象有 UV 层但未展开（所有岛重叠）** | **执行时** | **Smart Project 会覆盖全部 UV 岛，结果等同于展开；即使用户未勾选展 UV，因有 UV 层所以不会触发强制展——这种情况后续烘焙可能会出问题，但目前无法可靠检测"有 UV 层但展得很烂"，暂不处理** |
| **部分对象有 UV、部分没有** | **弹窗时** | **有 UV 的按复选框，无 UV 的强制展，弹窗显示混合状态提示** |
| **脚本执行期间用户切换场景** | **执行时** | **操作前缓存当前场景引用，全部操作在目标场景上下文中完成，切换场景不影响已执行的步骤** |

---

## 六、实现步骤（更新版）

| 步 | 文件 | 内容 | 前置依赖 |
|----|------|------|---------|
| 1 | `names.py` | 添加 `baked_material_name()` `baked_image_name()` | 无 |
| 2 | `uv_utils.py` | 实现 `unwrap_baked_objects()` | 无 |
| 3 | `node_groups.py` | 实现 `bake_material_projection()`（内部调用 `unwrap_baked_objects`） | 步 1, 2 |
| 4 | `__init__.py` | 实现 `CompifyBakeMaterialProjection` 操作符类（含 UV 检测和对话框） | 步 3 |
| 5 | `__init__.py` | 在 `CompifyUVAdjust3DPanel.draw()` 中添加烘焙按钮 | 步 4 |
| 6 | `__init__.py` | 在 `register()` / `unregister()` 中注册/注销 | 步 4 |
| 7 | `translations.py` | 添加翻译字段 | 步 4 |
| 8 | 人工测试 | 验证全部边界情况 | 全部完成 |

---

## 七、测试清单（执行后验收）

### 烘焙核心功能
- [ ] 单对象材质烘焙：新建 1 个对象 + 1 个材质 + 1 个纹理
- [ ] 多对象共用材质：新建 n 个对象 + 1 个材质 + n 个纹理
- [ ] 原对象不被修改：位置、材质、节点全部保持不变
- [ ] 烘焙结果渲染正确：结果材质的纹理与原始投影一致
- [ ] 弹窗默认分辨率：从 `scene.compify_config.bake_image_res` 读取

### UV 处理专项（新增）
- [ ] 已有 UV + 勾选展 UV：执行 Smart Project，覆盖原有 UV
- [ ] 已有 UV + 未勾选展 UV：保留原 UV，不执行任何 UV 操作
- [ ] 无 UV 层 + 勾选展 UV：强制展 UV
- [ ] 无 UV 层 + 未勾选展 UV：强制展 UV（复选框状态不影响）
- [ ] 混合场景（n 个有 UV + m 个无 UV）：有 UV 的按复选框，无 UV 的强制展
- [ ] 多对象材质中混合 UV 状态，弹窗显示正确的提示文字
- [ ] 非 mesh 对象：跳过，不影响其他对象操作
- [ ] 所有对象都无 UV：复选框禁用/不可操作，显示强制展提示

### 容错与边界
- [ ] 材质名称冲突：`Baked_xxx.001` 自动递进
- [ ] 无效材质：提示错误，不崩溃
- [ ] 无 Camera Project 节点的材质：提示"请先生成"
- [ ] 无对象使用的材质：提示"无关联对象"
- [ ] 撤销操作（Ctrl+Z）：新建的对象和材质被删除
- [ ] UV 操作可撤销：展 UV 在撤销时回退

---

## 八、调试日志设计

为了在实现后的测试阶段能够快速定位问题，整个烘焙流程需要嵌入细致的调试日志。日志覆盖每个步骤的执行细节、关键变量的值、以及错误现场的上下文信息。

### 8.1 日志方案选择

| 方案 | 适用场景 | 选择 |
|------|---------|------|
| `print()` 直接输出 | 简单场景，直接在 Blender 系统控制台可见 | ✅ 核心方案 |
| Python `logging` 模块 | 需要输出到文件、按级别过滤 | ❌ 过度设计 |
| `self.report()` | 用户可见的报错/状态信息 | ✅ 用于用户交互反馈 |
| 自定义 Logger 类 | 统一格式、时间戳、分级控制 | ✅ 封装 `print()` |

最终方案：一个轻量的 `BakeLogger` 类，包装 `print()` 输出到控制台（Blender 的 System Console），同时使用 `self.report()` 将关键进展和错误暴露给用户界面。

### 8.2 BakeLogger 类设计

```python
class BakeLogger:
    """烘焙流程的调试日志记录器。

    输出到 Blender 系统控制台（Window > Toggle System Console）。
    支持分级日志，可控制详细程度。
    """

    # 日志级别
    DEBUG = 0   # 每一步的细节（节点创建、连线、循环遍历等）
    INFO = 1    # 流程节点（开始/完成某个阶段、计数结果）
    WARN = 2    # 非致命异常（如某对象无 UV 强制展）
    ERROR = 3   # 致命错误（操作终止）

    def __init__(self, operator=None, level=DEBUG):
        self.operator = operator  # 用于 self.report() 的 operator 实例
        self.level = level        # 当前日志级别，低于此级别的不输出

    def debug(self, tag, message):
        """Step-level detail."""
        if self.level <= self.DEBUG:
            print(f"[Bake|DEBUG|{tag}] {message}")

    def info(self, tag, message):
        """Phase-level info."""
        if self.level <= self.INFO:
            print(f"[Bake|INFO |{tag}] {message}")

    def warn(self, tag, message):
        """Non-fatal issue."""
        if self.level <= self.WARN:
            print(f"[Bake|WARN |{tag}] {message}")

    def error(self, tag, message):
        """Fatal error, also reports via operator if available."""
        if self.level <= self.ERROR:
            print(f"[Bake|ERROR|{tag}] {message}")
            if self.operator:
                self.operator.report({"ERROR"}, f"[{tag}] {message}")

    def separator(self):
        """Visual separator in console for readability."""
        print("=" * 60)
```

### 8.3 各步骤的日志点位

| 阶段 | 标签 | 级别 | 日志内容 |
|------|------|------|---------|
| 验证 | VALIDATE | INFO | 材质名、对象数 |
| 验证 | VALIDATE | DEBUG | 对象列表、材质 users |
| 克隆材质 | CLONE | INFO | 克隆原材质的节点树 |
| 克隆材质 | CLONE | DEBUG | 原始材质节点树 dump（节点名、类型、连接） |
| 克隆材质 | CLONE | DEBUG | `scene.compify_config.footage` 是否存在 |
| 复制对象 | COPY | INFO | 复制的对象数 |
| 复制对象 | COPY | DEBUG | 每个对象的复制映射 |
| 复制对象 | COPY | WARN | 跳过的非 mesh 对象 |
| UV 处理 | UV | INFO | 处理结果统计 |
| UV 处理 | UV | DEBUG | 每个对象的 has_uv、处理动作 |
| 加入烘焙目标 | TARGET | INFO | 添加的 bake target TexImage |
| 加入烘焙目标 | TARGET | DEBUG | 图片名、分辨率、active 状态 |
| 烘焙 | BAKE | INFO | 引擎切换：原引擎 → CYCLES |
| 烘焙 | BAKE | DEBUG | Cycles 采样数设置值 |
| 烘焙 | BAKE | DEBUG | 选中对象列表 |
| 烘焙 | BAKE | DEBUG | 烘焙参数（type, margin 等） |
| 烘焙 | BAKE | WARN | 像素校验：4 角+中心采样，全黑则告警 |
| 烘焙 | BAKE | INFO | 烘焙耗时 |
| 烘焙 | BAKE | INFO | 引擎恢复 |
| 清理 | CLEAN | DEBUG | 保留的节点和移除的节点完整列表 |
| 完成 | DONE | INFO | 生成对象数、材质名、纹理数 |
| 完成 | DONE | INFO | UV 展开统计 |
| 完成 | DONE | WARN | 像素 RGB 最大值（检测全黑） |
| 完成 | DONE | INFO | Alpha 通道状态（是否有 > 0 的值） |
| 完成 | DONE | INFO | 总耗时 |

### 8.4 节点树 Dump 函数

```python
def _dump_node_tree(material, label=""):
    """打印材质的完整节点结构，用于调试。"""
    if not material or not material.node_tree:
        print(f"[Bake|DEBUG|NODES] {label}: no node tree")
        return
    nt = material.node_tree
    print(f"[Bake|DEBUG|NODES] {label}: {material.name}")
    print(f"[Bake|DEBUG|NODES]   nodes ({len(nt.nodes)}):")
    for node in nt.nodes:
        in_count = len(node.inputs)
        out_count = len(node.outputs)
        print(f"    {node.name} ({node.type})")
        # Show first 3 input/output connections
        for sock in node.inputs[:3]:
            if sock.is_linked:
                from_node = sock.links[0].from_node.name
                print(f"      IN  {sock.name} <- {from_node}.{sock.links[0].from_socket.name}")
        for sock in node.outputs[:3]:
            if sock.is_linked:
                to_node = sock.links[0].to_node.name
                print(f"      OUT {sock.name} -> {to_node}.{sock.links[0].to_socket.name}")
```

### 8.5 像素校验函数

```python
def _sample_image_pixels(img, num_samples=5):
    """对纹理的多个位置采样像素值，返回统计信息。

    用于检测烘焙结果是否全黑。
    """
    if not img:
        return {"max_rgb": 0.0, "has_alpha": False, "samples": []}
    w, h = img.size
    positions = [(0, 0), (w-1, 0), (0, h-1), (w-1, h-1), (w//2, h//2)]
    samples = []
    max_rgb = 0.0
    has_alpha = False
    for x, y in positions:
        idx = (y * w + x) * 4
        rgba = tuple(img.pixels[idx:idx+4])
        r, g, b, a = rgba
        max_rgb = max(max_rgb, r, g, b)
        if a > 0.01:
            has_alpha = True
        samples.append({"pos": (x, y), "rgba": rgba})
    return {"max_rgb": max_rgb, "has_alpha": has_alpha, "samples": samples}
```

### 8.6 异常捕获日志

```python
def bake_material_projection(...):
    log = BakeLogger(level=BAKE_LOG_LEVEL)
    try:
        # ... 全部步骤 ...
    except Exception as e:
        log.error("FATAL", f"unexpected error: {str(e)}")
        log.debug("FATAL", f"traceback:\n{traceback.format_exc()}")
        return _bake_error(f"Baking failed: {str(e)}")
```

### 8.7 日志级别控制

| 级别 | 用途 | 默认状态 |
|------|------|---------|
| `DEBUG` | 每步细节、节点 dump、连线和值 | 测试时开启，发布前关闭 |
| `INFO` | 流程节点、计数、引擎切换 | 始终开启 |
| `WARN` | 非致命异常、全黑检测 | 始终开启 |
| `ERROR` | 致命错误 | 始终开启 |

```python
# node_groups.py 顶部
BAKE_LOG_LEVEL = BakeLogger.DEBUG  # 测试阶段
# BAKE_LOG_LEVEL = BakeLogger.INFO  # 发布阶段
```

---

## 九、EMIT 烘焙全黑问题分析与修复计划

### 9.1 现象

2026-05-03 测试结果：EMIT 烘焙无报错、日志完整，但输出的纹理全黑（RGB=0），且 Alpha 通道丢失（全透明）。

### 9.2 Blender 标准烘焙流程

在分析问题前，先厘清 Blender Cycles 的烘焙机制：

```
[标准烘焙工作流]

1. 对象需要有 UV Map
2. 对象材质中需要有 Image Texture 节点，设为 active（高亮选中）
3. 该 active Image Texture 节点关联的图片就是烘焙结果的写入目标
4. 材质中可以有任意复杂的节点链
5. Cycles 渲染材质的 Surface 输出 → 写入 active 纹理的像素

[EMIT 烘焙的特殊性]
- EMIT bake 捕获的是材质的 Emission 输出（Glow color）
- 材质必须通过 Emission Shader 将颜色输出到 Surface
- 不依赖光线追踪，只读取着色器输出
- 参考：docs.blender.org/manual/en/latest/render/cycles/baking.html
```

### 9.3 根因分析

#### 错误一：烘焙材质中没有实拍素材纹理

当前代码构建的烘焙材质节点链：

```
Camera Project(Vector)
    → UV Adjust(Adjusted UV)
    → TexImage(***空纹理***, Vector=Adjusted UV)  ← 读的是空图！
        → [Color]
    → Material Output(Surface)
```

Camera Project 算出的 UV 坐标去采样一张空白图片（`bpy.data.images.new()` 创建的新图），结果自然是纯黑 (0,0,0)。

**正确的做法**：Camera Project → UV Adjust 计算出的 UV 应该去采样 **实拍素材图片**（footage image），而不是空纹理。

#### 错误二：缺少 Emission Shader

即使是正确的图片，`TexImage(Color) → Material Output(Surface)` 在 Cycles 下也不工作。Cycles 的 Surface 输入需要 BSDF 着色器输出，裸颜色值被当作 0 处理。

**正确的做法**：TexImage(Color) → Emission Shader(Color) → Material Output(Surface)

#### 错误三：混淆了采样纹理和烘焙目标纹理

当前代码把同一个 TexImage 节点同时用作：
- **读取源**（Camera Project 的 UV 输入 → 采样颜色）
- **写入目标**（EMIT bake 将渲染结果写入 active 纹理）

这导致：它读的是空纹理→输出黑→EMIT capture 黑→写入也是黑。

**正确的做法**：两类纹理分离。

| 类型 | 作用 | 图片内容 | 是否 active | 是否在节点链中 |
|------|------|---------|-----------|-------------|
| **素材纹理** | 被 Camera Project 的 UV 采样 | 实拍素材图片 | ❌ | ✅ |
| **烘焙目标** | 接收 EMIT bake 的结果 | 空纹理 | ✅ 必须 active | ❌ 不在链中 |

### 9.4 修复方案

#### 核心思路：克隆原材质，注入烘焙目标纹理

取代当前"从零搭建节点链"的方案，改为：

```
[原材质]    ← 用户设置好的材质，包含 Camera Project + UV Adjust + 素材纹理 + Emission
    │
    ├── 克隆一份 → Baked_xxx（独立材质，不污染原材质）
    │         │
    │         ├── 保留原材质的所有节点和连线（投影链路不变）
    │         │
    │         ├── 新增烘焙目标 TexImage（空纹理，设为 active）
    │         │       └── 这个节点的图片就是最终输出
    │         │
    │         └── 赋予烘焙对象（确保烘焙时对象使用这个材质）
    │
    ├── EMIT bake → Cycles 求值材质的 Emission 输出
    │                 → 写入 active TexImage（烘焙目标）
    │
    └── 清理：移除所有投影相关节点（Camera Project、UV Adjust、素材 TexImage 等），保留：
                   ├── 烘焙目标 TexImage（烘焙纹理）
                   ├── Emission Shader（输出颜色）
                   ├── Transparent BSDF（输出透明通道）
                   ├── Mix Shader（混合透明和颜色）
                   └── Material Output
               连线：TexImage(Color)→Emission→Mix[1]
                     TexImage(Alpha)→Mix(Fac)
                     Transparent BSDF→Mix[2]
                     Mix→Output(Surface)
```

#### 如何获取实拍素材图片

不需要额外获取。原材质中已经包含素材 TexImage（指向 footage image），克隆材质时连同所有节点一起复制过来，素材纹理自然就在材质里了。

#### Alpha 通道修复

EMIT 烘焙只写入 RGB 通道，不写入 Alpha。用 `use_clear=True` 会把 Alpha 清为 0。

修复：烘焙完成后，遍历所有烘焙纹理，将 Alpha 通道设为 1.0。

```python
for img in baked_images:
    pixels = list(img.pixels)
    for i in range(3, len(pixels), 4):
        pixels[i] = 1.0
    img.pixels[:] = pixels
```

### 9.5 增强调试日志

在 8.3 日志点位的基础上，新增：

| 阶段 | 标签 | 级别 | 内容 |
|------|------|------|------|
| 克隆材质 | CLONE | DEBUG | 原始材质节点树 dump（_dump_node_tree） |
| 克隆材质 | CLONE | DEBUG | 克隆完成后的节点树 dump，确认注入成功 |
| 加入目标 | TARGET | DEBUG | 烘焙目标纹理的 active 状态、图片名 |
| 烘焙 | BAKE | WARN | 烤完后用 _sample_image_pixels 采样，全黑则告警 |
| 完成 | DONE | WARN | max_rgb 值，如果 < 0.01 标记 FAIL |
| 完成 | DONE | INFO | Alpha 通道状态 |

### 9.6 实现步骤

| 步 | 变更文件 | 内容 | 前置 |
|----|---------|------|------|
| 1 | `node_groups.py` | 新增 `_dump_node_tree()` 和 `_sample_image_pixels()` 工具函数 | 无 |
| 2 | `node_groups.py` | 新增 `_clone_material_with_bake_target()`：克隆材质 + 注入烘焙目标 TexImage | 步 1 |
| 3 | `node_groups.py` | 重写 `bake_material_projection()` 中的节点构建逻辑：用克隆替代从零搭建，分离两类纹理 | 步 2 |
| 4 | `node_groups.py` | 新增 Alpha 通道修复 | 步 3 |
| 5 | `node_groups.py` | 清理阶段：保留烘焙目标 TexImage + Emission + Transparent + Mix Shader + Output，移除其他节点 | 步 3 |
| 6 | `node_groups.py` | 清理阶段连线：TexImage(Color)→Emission, TexImage(Alpha)→Mix(Fac), Transparent→Mix[2], Emission→Mix[1], Mix→Output | 步 5 |
| 6 | 测试 | 验证非黑结果、Alpha 为 1.0、调试日志完整性 | 全部 |

### 9.7 测试验收清单

- [ ] 烘焙结果非黑：像素 RGB 最大值 > 0.1
- [ ] Alpha 通道为 1.0：遍历所有像素
- [ ] 烘焙后材质保留 Emission+Transparent+Mix Shader 结构
- [ ] 烘焙后材质节点连线正确：TexImage(Color)→Emission→Mix[1], TexImage(Alpha)→Mix(Fac), Transparent→Mix[2], Mix→Output
- [ ] 烘焙后材质在 EEVEE 和 Cycles 下都能正确显示透明/不透明
- [ ] 原材质未被修改（节点、纹理、设置保持不变）
- [ ] 原对象未被修改
- [ ] EEVEE 下正常烘焙（引擎自动切 Cycles 再恢复）
- [ ] 调试日志输出原始材质节点树 dump
- [ ] 调试日志输出克隆材质节点树 dump
- [ ] 调试日志包含像素校验结果
- [ ] 全黑时调试日志触发 WARN 告警
- [ ] 多对象共用材质：独立克隆，互不干扰
