# Compify 材质投影烘焙修复与优化计划

> **版本**: 草案 v1.0
> **日期**: 2026-06-23
> **触发问题**: 多物体共用投影材质时烘焙报错 `hide_render`；跨材质物体烘焙不支持单体选择

---

## 目录

1. [问题诊断](#1-问题诊断)
2. [修复项 A：hide_render 继承缺陷](#2-修复项-ahide_render-继承缺陷)
3. [增强项 B：单物体选择性烘焙](#3-增强项-b单物体选择性烘焙)
4. [调试日志体系](#4-调试日志体系)
5. [修改文件清单](#5-修改文件清单)
6. [实施步骤](#6-实施步骤)
7. [测试场景](#7-测试场景)
8. [回归风险](#8-回归风险)

---

## 1. 问题诊断

### 1.1 hide_render 报错链路

```
用户场景: 多物体共用投影材质，其中部分物体的 Outliner 渲染图标被关闭 (hide_render=True)

bake_material_projection()
  ├─ find_objects_using_material()     → 返回所有使用该材质的物体（含 hide_render=True 的）
  ├─ Step 2: obj.copy()                → 副本继承原物体的 hide_render 属性
  │           new_obj.hide_render = True   ← 根本没被修正
  ├─ Step 7: select all baked_objects
  └─ bpy.ops.object.bake()              → Blender 检查选中物体的 hide_render
       └─ 发现某副本 hide_render=True  → 抛出: "错误: 物体 'XXX' 未启用渲染"
```

对比旧流程 `bake.py` 的 `Baker` 类：
- `execute()`: 保存所有非代理物体的 `hide_render` 到 `self.hide_render_list`，强制设为 `True`
- `modal()`: 烘焙完成后恢复 `hide_render_list` 中的原始值
- **新流程 `bake_pipeline.py` 完全没有 `hide_render` 管理**

### 1.2 单物体烘焙缺失

`bake_material_projection()` 入参只有一个 `material`，内部硬编码了"取该材质的所有物体 → 全量复制 → 全量烘焙"。没有任何物体级别的过滤参数。

UI 层面每个材质只有一个烘焙按钮，也无法按物体选择烘焙。

---

## 2. 修复项 A：hide_render 继承缺陷

### 2.1 修改位置

**文件**: `bake_pipeline.py`
**函数**: `bake_material_projection()`

### 2.2 修改方案

在 Step 7（执行烘焙）之前，强制将所有 `baked_objects` 的 `hide_render` 设为 `False`，并同时保存原始状态以便后续逻辑需要时参考（当前后续逻辑不需要恢复，因为烘焙对象是新创建的副本，不涉及原始场景的恢复）。

**插入位置**: Step 6 之后、Step 7 之前（约第 420 行，`# ---- 7. Execute COMBINED bake ----` 注释之前）。

### 2.3 具体代码改动

```python
# ============ 新增：Step 6.5 渲染可见性修正 ============
log.info("RENDER", "===== step 6.5: fixing render visibility =====")

for obj in baked_objects:
    if obj.hide_render:
        log.warn("RENDER",
                 f"object '{obj.name}' has hide_render=True (inherited "
                 f"from original), forcing to False for bake")
        obj.hide_render = False
    # 同时确保对象在视口可见（某些极端情况）
    if obj.hide_viewport:
        log.debug("RENDER",
                  f"object '{obj.name}' also has hide_viewport=True, "
                  f"forcing to False")
        obj.hide_viewport = False

log.info("RENDER",
         f"verified {len(baked_objects)} object(s) renderable")
```

### 2.4 调试日志（此修改点）

| 日志级别 | 标签 | 内容 |
|---------|------|------|
| INFO | RENDER | 步骤标题、验证通过总数 |
| WARN | RENDER | 每个被强制修正 `hide_render` 的物体名称 |
| DEBUG | RENDER | 同时修正 `hide_viewport` 的情况 |
| DEBUG | RENDER | 每个物体的渲染状态详情（`hide_render`/`hide_viewport`/`visible_get()`） |

### 2.5 额外防护：烘焙前最终校验

在 `bpy.ops.object.bake()` 调用前增加断言式检查：

```python
# 烘焙前最终防御
unrenderable = [o.name for o in baked_objects if o.hide_render]
if unrenderable:
    log.error("BAKE",
              f"FATAL: {len(unrenderable)} object(s) still "
              f"have hide_render=True after fix: {unrenderable}")
    return _bake_error(
        "Internal error: failed to fix render visibility")
log.debug("BAKE",
          f"pre-bake render check: all {len(baked_objects)} "
          f"objects renderable ✓")
```

---

## 3. 增强项 B：单物体选择性烘焙

### 3.1 总体架构

```
面板层级（修改后）:
  Camera 分组（折叠）
    ├─ 材质 A ────────────────────────────────── [烘焙全部] [选择物体] [更新] [删除]
    │   └─ 物体子列表（折叠） ← 新增
    │       ├─ 物体 001 有UV ─────────────────── [烘焙] [选中物体]
    │       ├─ 物体 002 无UV ⚠ ──────────────── [烘焙] [选中物体]
    │       └─ 物体 003 hide_render=关 ──────── [烘焙] [选中物体]
    └─ 材质 B ────────────────────────────────── ...
```

### 3.2 后端修改

#### 3.2.1 `bake_pipeline.py` — 函数签名扩展

```python
def bake_material_projection(
        scene, material, bake_resolution,
        auto_unwrap=True,
        skip_unwrap_names=None,
        angle_limit=66, island_margin=0.0,
        area_weight=0.0, correct_aspect=False,
        scale_to_bounds=False,
        operator=None,
        object_filter=None,      # ← 新增: 可选，物体名集合 set[str]
):
```

#### 3.2.2 过滤逻辑

在获取 `objects` 列表后、Step 2 复制前插入过滤：

```python
# ---- 1.5 物体过滤（单物体烘焙） ----
if object_filter is not None:
    original_count = len(objects)
    objects = [o for o in objects if o.name in object_filter]
    log.info("FILTER",
             f"object_filter applied: {original_count} → "
             f"{len(objects)} objects")
    log.debug("FILTER",
              f"filter set: {sorted(object_filter)}")
    log.debug("FILTER",
              f"filtered out: "
              f"{[o.name for o in find_objects_using_material(material.name) if o.name not in object_filter]}")
    if not objects:
        log.error("FILTER",
                  "no objects match filter (all filtered out)")
        return _bake_error(
            "No objects match the specified filter")

    # 记录被过滤掉的对象渲染状态（调试用）
    all_objs = find_objects_using_material(material.name)
    for o in all_objs:
        if o.name not in object_filter:
            log.debug("FILTER",
                      f"excluded: '{o.name}' "
                      f"(hide_render={o.hide_render}, "
                      f"hide_viewport={o.hide_viewport})")
```

#### 3.2.3 `__init__.py` — `CompifyBakeMaterialProjection` 扩展

新增属性：

```python
# 单物体烘焙：如果指定，只烘焙这个物体
object_name: bpy.props.StringProperty(
    name="Object Name",
    default="",
    options={"HIDDEN", "SKIP_SAVE"},
    description="If set, only bake this specific object instead of all",
)
```

在 `execute()` 中构建 `object_filter` 并传入：

```python
def execute(self, context):
    material = bpy.data.materials.get(self.material_name)
    # ...

    # 构建物体过滤
    object_filter = None
    if self.object_name:
        object_filter = {self.object_name}
        log_msg = (f"Single-object bake: '{self.object_name}' "
                   f"from material '{self.material_name}'")
        print(f"[Bake|INFO |FILTER] {log_msg}")

    result = bake_material_projection(
        scene=context.scene,
        material=material,
        bake_resolution=self.bake_resolution,
        # ... 其他参数 ...
        object_filter=object_filter,    # ← 新增
        operator=self,
    )
```

#### 3.2.4 `invoke()` 中更新受影响物体统计

当 `object_name` 指定时，`self.affected_objects` 只包含该物体：

```python
def invoke(self, context, event):
    # ... 现有校验 ...

    self.affected_objects = find_objects_using_material(self.material_name)

    # 单物体过滤
    if self.object_name:
        self.affected_objects = [
            o for o in self.affected_objects
            if o.name == self.object_name
        ]
        if not self.affected_objects:
            self.report({"ERROR"},
                        f"Object '{self.object_name}' not found "
                        f"in material's users")
            return {"CANCELLED"}
```

#### 3.2.5 `draw()` 中 UI 文案适配

```python
def draw(self, context):
    # ...
    if self.object_name:
        box.label(text=f"Baking: single object '{self.object_name}'",
                  icon="MESH_DATA")
    else:
        box.label(text=f"Objects: {len(self.affected_objects)}",
                  icon="MESH_DATA")
        box.label(text=f"Will create: {self.mesh_count} new object(s)",
                  icon="OBJECT_DATA")
```

### 3.3 UI 修改

#### 3.3.1 面板层级扩展

**文件**: `__init__.py`
**类**: `CompifyUVAdjust3DPanel.draw()`

在材质条目的现有按钮行之后，新增可折叠的物体子列表。

#### 3.3.2 折叠 key 命名空间

```python
# 材质级物体子列表折叠 key
obj_list_key = f"objlist:{mat_name}"
obj_list_fold = _get_fold_state(context.scene, obj_list_key, False)  # 默认折叠
```

与已有相机折叠 key（`cam_name`）和共享组折叠 key（`shared_{node_group.name}`）隔离。

#### 3.3.3 物体子列表渲染

```python
# 获取使用该材质的所有物体
mat_objects = find_objects_using_material(mat_name)
mesh_objects = [o for o in mat_objects if o.type == 'MESH']

# 折叠切换按钮（放在材质操作按钮之后）
obj_toggle_row = group_box.row()
obj_toggle = obj_toggle_row.operator(
    "compify.toggle_uv_group_fold",
    text="",
    emboss=False,
    icon="TRIA_DOWN" if obj_list_fold else "TRIA_RIGHT",
)
obj_toggle.camera_name = obj_list_key
obj_toggle.new_state = not obj_list_fold
obj_toggle_row.label(
    text=f"Objects ({len(mesh_objects)})",
    icon="MESH_DATA")

# 物体列表
if obj_list_fold:
    for obj in mesh_objects:
        obj_row = group_box.row()

        # 状态图标
        has_uv = bool(obj.data.uv_layers.active)
        is_renderable = not obj.hide_render
        if not is_renderable:
            obj_row.label(text="", icon="HIDE_ON")
        elif not has_uv:
            obj_row.label(text="", icon="ERROR")
        else:
            obj_row.label(text="", icon="CHECKMARK")

        # 物体名
        obj_row.label(text=obj.name)

        # 选中物体按钮
        select_op = obj_row.operator(
            "compify.select_uv_adjust_object",
            text="",
            icon="RESTRICT_SELECT_OFF",
        )
        select_op.object_name = obj.name
        select_op.enabled = True

        # 单物体烘焙按钮 ← 核心新增
        bake_op = obj_row.operator(
            "compify.bake_material_projection",
            text="",
            icon="TEXTURE",
        )
        bake_op.material_name = mat_name
        bake_op.object_name = obj.name    # ← 传入物体名

        # 渲染状态警告（仅显示图标，不阻塞）
        if obj.hide_render:
            obj_row.label(text="", icon="INFO")
```

#### 3.3.4 物体状态提示文案

在物体子列表上方添加状态说明行：

```python
if obj_list_fold:
    # 统计状态
    no_uv_count = sum(1 for o in mesh_objects
                      if not o.data.uv_layers.active)
    hidden_count = sum(1 for o in mesh_objects if o.hide_render)

    if hidden_count or no_uv_count:
        warn_row = group_box.row()
        parts = []
        if hidden_count:
            parts.append(f"{hidden_count} hidden from render")
        if no_uv_count:
            parts.append(f"{no_uv_count} missing UV")
        warn_row.label(
            text="⚠ " + ", ".join(parts),
            icon="INFO")
```

### 3.4 修改范围边界

| 组件 | 操作 | 说明 |
|------|------|------|
| `bake_pipeline.py: bake_material_projection()` | 修改 | 新增 `object_filter` 参数 + 过滤逻辑 + render 修正 |
| `__init__.py: CompifyBakeMaterialProjection` | 修改 | 新增 `object_name` 属性，invoke/execute/draw 适配 |
| `__init__.py: CompifyUVAdjust3DPanel.draw()` | 修改 | 材质条目下新增物体子列表 |
| `__init__.py: CompifyToggleUVGroupFold` | **不改** | 复用现有折叠操作符，使用不同的 `camera_name` key |
| `node_group_manager.py` | **不改** | `get_all_uv_adjust_node_groups()` 不涉及此功能 |
| `bake.py` (旧 Baker) | **不改** | 不涉及此功能 |

---

## 4. 调试日志体系

### 4.1 日志级别定义

沿用 `BakeLogger` 现有四级制：

| 级别 | 值 | 用途 |
|------|---|------|
| DEBUG | 0 | 逐对象追踪：渲染状态、过滤结果、UV 状态 |
| INFO | 1 | 阶段里程碑：步骤开始/完成、修改计数 |
| WARN | 2 | 非致命问题：自动修正 hide_render、强制 UV 展开 |
| ERROR | 3 | 致命错误：操作中止 |

### 4.2 新增日志标签

| 标签 | 用途 | 出现位置 |
|------|------|---------|
| `RENDER` | hide_render 状态检查与修正 | `bake_pipeline.py` Step 6.5 |
| `FILTER` | 物体过滤逻辑 | `bake_pipeline.py` Step 1.5 |
| `FILTER` | 单物体模式标识 | `__init__.py` CompifyBakeMaterialProjection.execute() |
| `BAKE` | 烘焙前最终校验 | `bake_pipeline.py` Step 7 前 |

### 4.3 关键追踪点

#### 4.3.1 烘焙流水线 (`bake_pipeline.py`)

```
步骤                    日志
───────────────────────────────────────────────────
1. 验证                  [INFO] 开始烘焙、材质名、物体数量
1.5 物体过滤 (新增)        [INFO] 过滤前后数量对比
                         [DEBUG] 过滤集合内容
                         [DEBUG] 被过滤掉的物体名+渲染状态
                         [ERROR] 过滤后为空
2. 复制物体              [DEBUG] 源→副本名称映射
3. UV 检测               [DEBUG] 每个物体的 has_uv 状态
4. 创建烘焙目标           [DEBUG] 图片名称+分辨率
5+6. 克隆材质+分配        [DEBUG] 分配材质名→物体名
6.5 渲染可见性 (新增)      [INFO] 步骤标题
                         [WARN] 每个被强制修正的物体
                         [DEBUG] hide_viewport 修正
                         [DEBUG] 每个物体的最终渲染状态
7. 执行烘焙              [DEBUG] 选中物体列表
                         [DEBUG] 活动 TexImage 节点
                         [DEBUG] 烘焙前最终 hide_render 校验
8. 清理                  [DEBUG] 节点数量变化
                         [INFO] 烘焙完成
9. 像素验证              [DEBUG] 采样结果
                         [WARN] 全黑贴图警告
                         [INFO] 最终耗时
```

#### 4.3.2 操作符层 (`__init__.py`)

```
位置                    日志
───────────────────────────────────────────────────
invoke()                [console] 单物体模式: object_name + material_name
execute()               [console] object_filter 是否启用
execute()               [self.report] 最终结果（含烘焙物体数）
```

#### 4.3.3 UI 面板 (`__init__.py`)

不需要动态日志。面板渲染时的状态数据（物体数、UV 缺失数、隐藏数）通过 `find_objects_using_material()` 实时获取，不产生日志。

### 4.4 日志示例

正常多物体烘焙：
```
[Bake|INFO |VALIDATE] ===== start baking: material '投影材质' =====
[Bake|DEBUG|VALIDATE] objects using material: 3
[Bake|DEBUG|VALIDATE] object list: ['车主体.003', '车主体.004', '车主体.005']
[Bake|INFO |COPY] ===== step 2: copying objects =====
...

-- 修正后新增 --
[Bake|INFO |RENDER] ===== step 6.5: fixing render visibility =====
[Bake|WARN |RENDER] object '车主体.005.001' has hide_render=True (inherited from original), forcing to False for bake
[Bake|INFO |RENDER] verified 3 object(s) renderable
[Bake|DEBUG|BAKE] pre-bake render check: all 3 objects renderable ✓
```

单物体烘焙：
```
[Bake|INFO |VALIDATE] ===== start baking: material '投影材质' =====
[Bake|DEBUG|VALIDATE] objects using material: 3
[Bake|INFO |FILTER] object_filter applied: 3 → 1 objects
[Bake|DEBUG|FILTER] filter set: ['车主体.004']
[Bake|DEBUG|FILTER] filtered out: ['车主体.003', '车主体.005']
[Bake|DEBUG|FILTER] excluded: '车主体.003' (hide_render=False, hide_viewport=False)
[Bake|DEBUG|FILTER] excluded: '车主体.005' (hide_render=True, hide_viewport=False)
```

---

## 5. 修改文件清单

| 文件 | 修改类型 | 改动量（估） | 涉及内容 |
|------|---------|------------|---------|
| `bake_pipeline.py` | 函数修改 | ~50 行新增 | Step 1.5 过滤逻辑、Step 6.5 render 修正、烘焙前校验、`object_filter` 参数 |
| `__init__.py` | 类修改 + draw 修改 | ~100 行新增 | `CompifyBakeMaterialProjection` 新增属性/适配；面板新增物体子列表 |

**不改的文件**（但需验证兼容性）：
- `bake.py` — 旧 Baker，不涉及
- `node_group_manager.py` — 节点组管理，不涉及
- `node_groups.py` — `find_objects_using_material()` 原样复用

---

## 6. 实施步骤

### Phase 1: hide_render 修复（独立可交付）

| 序号 | 操作 | 文件 | 行位置 |
|------|------|------|--------|
| 1.1 | 在 `bake_material_projection()` Step 6 之后插入 render 修正代码块 | `bake_pipeline.py` | 约 L420 |
| 1.2 | 在 `bpy.ops.object.bake()` 前插入最终防御校验 | `bake_pipeline.py` | 约 L445 |
| 1.3 | 验证：给一个物体的 Outliner 关闭渲染图标，单材质单物体烘焙 → 应成功 |

### Phase 2: 单物体烘焙后端

| 序号 | 操作 | 文件 | 行位置 |
|------|------|------|--------|
| 2.1 | `bake_material_projection()` 签名加入 `object_filter` 参数 | `bake_pipeline.py` | L224 |
| 2.2 | 在 `objects` 获取后插入过滤逻辑（Step 1.5） | `bake_pipeline.py` | Step 1 与 Step 2 之间 |
| 2.3 | `CompifyBakeMaterialProjection` 新增 `object_name` 属性 | `__init__.py` | L1463 类定义内 |
| 2.4 | `invoke()` 中适配单物体模式 | `__init__.py` | L1540 附近 |
| 2.5 | `draw()` 中适配单物体文案 | `__init__.py` | L1578 附近 |
| 2.6 | `execute()` 中构建 `object_filter` 并传入 | `__init__.py` | L1640 附近 |

### Phase 3: UI 物体子列表

| 序号 | 操作 | 文件 | 行位置 |
|------|------|------|--------|
| 3.1 | 在材质条目的 bake 按钮区域后，新增物体折叠切换 + 子列表 | `__init__.py` | `CompifyUVAdjust3DPanel.draw()` 的材质循环内 |
| 3.2 | 物体子列表内每个物体添加：状态图标、名称、选中按钮、单物体烘焙按钮 | `__init__.py` | 同上 |
| 3.3 | 子列表上方添加状态统计提示行 | `__init__.py` | 同上 |

### Phase 4: 回归测试

见 [第 7 节](#7-测试场景)。

---

## 7. 测试场景

### 7.1 hide_render 修复验证

| # | 场景 | 操作 | 预期 |
|---|------|------|------|
| T1 | 单材质单物体，`hide_render=False` | 烘焙 | 正常完成 |
| T2 | 单材质单物体，`hide_render=True` | 烘焙 | 正常完成（修正后） |
| T3 | 单材质 3 物体，1 个 `hide_render=True` | 烘焙全部 | 3 个都正常完成 |
| T4 | 单材质 3 物体，全部 `hide_render=True` | 烘焙全部 | 3 个都正常完成 |
| T5 | 单材质 3 物体，1 个 `hide_viewport=True` | 烘焙全部 | 正常完成 |

### 7.2 单物体烘焙验证

| # | 场景 | 操作 | 预期 |
|---|------|------|------|
| T6 | 单材质 3 物体 | 对物体 A 点烘焙 | 只创建物体 A 的副本+贴图 |
| T7 | 单材质 3 物体，物体 B 缺 UV | 对物体 B 点烘焙 | 弹对话框，自动展开，强制 UV，正常完成 |
| T8 | 单材质 3 物体，物体 C 是曲线 | 列表不显示 C | 曲线物体不出现在子列表中 |
| T9 | `object_name` 指向不存在的物体 | 烘焙 | 报错 "Object not found in material's users" |

### 7.3 UI 验证

| # | 场景 | 操作 | 预期 |
|---|------|------|------|
| T10 | 单材质单物体 | 展开材质看子列表 | 子列表显示 1 个物体 |
| T11 | 单材质 3 物体 | 展开/折叠子列表 | 正常切换，刷新后面板状态记忆正确 |
| T12 | 材质 A 折叠 + 再展开材质 B | 两个子列表独立 | 互不影响 |
| T13 | 物体有 UV | 状态图标 | 显示绿色勾 |
| T14 | 物体缺 UV | 状态图标 | 显示警告三角 |
| T15 | 物体 `hide_render=True` | 状态图标 | 显示闭眼图标 |
| T16 | 有隐藏/缺 UV 物体 | 统计行 | 显示 "⚠ X hidden from render, Y missing UV" |

### 7.4 回归验证

| # | 场景 | 操作 | 预期 |
|---|------|------|------|
| T17 | 不传 `object_filter`（即从面板材质按钮点烘焙全部） | 烘焙 | 行为与修改前一致（全量烘焙） |
| T18 | 共享组多材质场景 | 面板显示 | 与修改前一致 |
| T19 | Refresh & Clean | 操作 | 与修改前一致 |
| T20 | 批量生成 UV Adjust | 操作 | 与修改前一致 |

---

## 8. 回归风险

| 风险 | 等级 | 缓解措施 |
|------|------|---------|
| `object_filter` 默认 `None` → 行为不变 | 低 | 默认值确保完全向后兼容 |
| `hide_render` 修正可能影响后续清理步骤 | 低 | 烘焙对象是新建副本，不参与原始场景状态恢复 |
| 面板折叠 key 命名空间与现有冲突 | 低 | 使用 `objlist:` 前缀隔离 |
| 老版本 Blender API 兼容性 | 低 | 不使用新 API，全部基于已有接口 |
| 性能：面板每帧 `find_objects_using_material()` | 中 | 当前面板已有缓存机制，`find_objects_using_material()` 本身开销小（遍历 `bpy.data.objects`）。如需优化可后续加入 session 级缓存 |

---

*计划结束。实施前请确认方案方向，有任何调整想法直接说。*
