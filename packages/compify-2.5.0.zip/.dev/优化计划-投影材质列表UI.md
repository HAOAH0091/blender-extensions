# Compify 投影材质管理列表 UI 优化计划

> **日期**: 2026-06-23
> **触发需求**: 材质图标统一 + 选中物体红色高亮 + 调试日志

---

## 现状分析

### 当前图标使用

| 位置 | valid 状态 | invalid 状态 |
|------|-----------|-------------|
| 材质行头部 | `CHECKMARK` | `ERROR` |
| 物体条目 | `CHECKMARK`（正常）/ `ERROR`（缺UV）/ `HIDE_ON`（关渲染） | — |

### 当前选中高亮

- 材质级：`gi["object"]` 只取第一个物体做判断，用户选中第 2、第 3 个共用材质的物体不会高亮
- 物体级：无任何选中反馈

---

## 优化项 1：材质图标改为 MATERIAL

### 改动

两处材质头部 `icon="CHECKMARK"` → `icon="MATERIAL"`，`icon="ERROR"` 不变。

---

## 优化项 2：选中物体红色高亮（alert）

### 2.1 选中检测修复

当前 `gi["object"]` 只取 first-match → 改为 `material_has_selected()` 检查任意物体：

```python
mat_to_objects = {}
for gi in active_groups:
    for mat_name in gi["materials"]:
        mat_to_objects.setdefault(mat_name, []).extend(
            find_objects_using_material(mat_name))

def material_has_selected(mat_name):
    objs = mat_to_objects.get(mat_name, [])
    return any(o in selected_set for o in objs)
```

### 2.2 材质级高亮

```python
header_row.alert = material_has_selected(mat_name)  # 选中→文字变红
```

### 2.3 物体级高亮

```python
obj_row.alert = (obj in selected_set)  # 选中→文字变红
```

### 2.4 状态图标优先级

| 优先级 | 条件 | 图标 |
|--------|------|------|
| 1 | 物体被选中 | `RESTRICT_SELECT_ON` |
| 2 | 物体关了渲染 | `HIDE_ON` |
| 3 | 物体缺 UV | `ERROR` |
| 4 | 正常 | `CHECKMARK` |

---

## 调试日志

### 策略

UI draw 每帧触发，不能在里面狂打 print。采用"变化时才记"：

| 事件 | 触发条件 | 内容 |
|------|---------|------|
| 查找表构建 | panel draw 中首次或失效后 | 材质数、物体总数 |
| 高亮材质变化 | 本次与上次 `selected_set` 不同 | 新选中材质列表 |
| 物体选中变化 | 物体子列表展开且选中变化 | 被选中物体名 |
| 查找表异常 | 材质名查不到物体 | WARN |

### 实现

panel 类增加类变量做变化检测：

```python
_last_selected_names = None  # frozenset of selected object names
```

draw 末尾比较：

```python
current = frozenset(o.name for o in selected_set)
if current != _last_selected_names:
    highlighted = [m for m, objs in mat_to_objects.items()
                   if any(o in selected_set for o in objs)]
    if highlighted:
        print(f"[Compify|UI] selected → highlighted materials: {highlighted}")
    _last_selected_names = current
```

物体子列表同理（`_draw_material_object_sublist` 内）：

```python
selected_names = [o.name for o in mesh_objects if o in selected_set]
if selected_names:
    print(f"[Compify|UI] '{mat_name}' objects selected: {selected_names}")
```

所有 UI 日志用 `print()`，也会进入 `BakeLogger` 同文件（如果 BakeLogger 已初始化，`print()` 输出经 `Tee` 重定向到 `bake_debug.log`）。

---

## 修改清单

| 文件 | 修改点 |
|------|--------|
| `__init__.py` | 构建 `mat_to_objects` 查找表 + `material_has_selected()` |
| `__init__.py` | 材质图标 `CHECKMARK` → `MATERIAL`（两处） |
| `__init__.py` | 材质行 + 物体行 `alert = True` 高亮 |
| `__init__.py` | 物体状态图标优先级重排 |
| `__init__.py` | 选中变化 debug 日志 |

---

## 不改的文件

- `bake_pipeline.py` — 不涉及 UI
- `node_group_manager.py` — 不涉及
- `node_groups.py` — 复用

---

## 视觉示意

```
修复前：
  [▸] ✓ 投影材质 (3)  [选择全部] [烘焙] [更新] [删除]
          ✓   车主体.002  [选中] [烘焙]
          ✗   车主体.003  [选中] [烘焙]
          👁‍🗨  车主体.005  [选中] [烘焙]

修复后（车主体.003 被选中）：
  [▸] ◉ 投影材质 (3)  [选择全部] [烘焙] [更新] [删除]  ← 红字
          ✓   车主体.002  [选中] [烘焙]
          ◎   车主体.003  [选中] [烘焙]                  ← 红字 + 选中图标
          👁‍🗨  车主体.005  [选中] [烘焙]
```
