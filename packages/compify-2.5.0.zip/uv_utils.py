import bpy
import math
from math import inf


def leftmost_u(mesh_objects, uv_layer_name):
    """
    Find the leftmost U coordinate in a set of mesh objects' UV layers.
    
    This function scans through all UV coordinates of the specified UV layer
    across all provided mesh objects and returns the minimum U value.
    
    Args:
        mesh_objects: List of mesh objects to scan
        uv_layer_name: Name of the UV layer to analyze
        
    Returns:
        float: The minimum U coordinate found, or infinity if no UVs exist
        
    Note:
        Used by Compify to calculate UV island margins for baking.
    """
    leftmost = inf
    for obj in mesh_objects:
        uvs = obj.data.uv_layers[uv_layer_name].data
        for uv in uvs:
            leftmost = min(leftmost, uv.uv[0])
    return leftmost


def unwrap_baked_objects(baked_objects, auto_unwrap,
                              skip_unwrap_names=None,
                              angle_limit=66, island_margin=0.0,
                              area_weight=0.0, correct_aspect=False,
                              scale_to_bounds=False):
    """
    Detect and handle UV layers on baked objects before baking.

    Objects without UV layers are force-unwrapped (baking requires UV).
    Objects with existing UV layers follow the auto_unwrap flag:
    - If True AND object not in skip_unwrap_names: re-unwrapped
    - If False OR object in skip_unwrap_names: kept as-is

    Uses Smart UV Project for automatic unwrapping.

    Args:
        baked_objects: List of copied mesh objects to process
        auto_unwrap: Whether to unwrap objects that already have UV layers
        skip_unwrap_names: set of object names to skip (even if auto_unwrap=True)
        angle_limit: Smart Project angle limit (default 66)
        island_margin: Smart Project island margin (default 0.0)
        area_weight: Smart Project area weight (default 0.0)
        correct_aspect: Correct aspect ratio (default False)
        scale_to_bounds: Scale to bounds (default False)

    Returns:
        dict: {
            "unwrapped": int,  # Objects unwrapped per auto_unwrap flag
            "forced": int,     # Objects force-unwrapped (no existing UV)
            "skipped": int     # Objects left unchanged
        }
    """
    if skip_unwrap_names is None:
        skip_unwrap_names = set()

    unwrapped = 0
    forced = 0
    skipped = 0

    for obj in baked_objects:
        mesh = obj.data
        has_uv = bool(mesh.uv_layers.active)
        in_skip = obj.name in skip_unwrap_names

        if not has_uv:
            # No UV layer: force unwrap (baking requires UV)
            _select_and_unwrap(obj, angle_limit, island_margin,
                               area_weight, correct_aspect, scale_to_bounds)
            forced += 1
        elif auto_unwrap and not in_skip:
            # Has UV + user chose to unwrap + not skipped: re-unwrap
            _select_and_unwrap(obj, angle_limit, island_margin,
                               area_weight, correct_aspect, scale_to_bounds)
            unwrapped += 1
        else:
            skipped += 1

    bpy.ops.object.select_all(action='DESELECT')

    return {"unwrapped": unwrapped, "forced": forced, "skipped": skipped}


def _select_and_unwrap(obj, angle_limit=66, island_margin=0.0,
                         area_weight=0.0, correct_aspect=False,
                         scale_to_bounds=False):
    """
    Select a single object, enter edit mode, unwrap via Smart Project, return to object mode.

    Internal helper, not part of the public API.

    Args:
        obj: Object to unwrap
        angle_limit: Smart Project angle limit
        island_margin: Smart Project island margin
        area_weight: Smart Project area weight
        correct_aspect: Correct aspect ratio
        scale_to_bounds: Scale to bounds
    """
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(
        angle_limit=math.radians(angle_limit),
        island_margin=island_margin,
        area_weight=area_weight,
        correct_aspect=correct_aspect,
        scale_to_bounds=scale_to_bounds,
    )
    bpy.ops.object.mode_set(mode='OBJECT')
