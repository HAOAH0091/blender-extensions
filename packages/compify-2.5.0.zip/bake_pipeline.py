# ====================== BEGIN GPL LICENSE BLOCK ======================
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ======================= END GPL LICENSE BLOCK ========================

"""Material projection baking pipeline for Compify.

Clones materials, injects bake targets, executes COMBINED bake via Cycles,
then strips down to a clean alpha-aware texture material.
"""

import bpy
import time
import traceback

from .names import (
    baked_material_name,
    baked_image_name,
)
from .node_groups import (
    find_objects_using_material,
    extract_camera_from_camera_project_group,
)
from .uv_utils import unwrap_baked_objects

def _dump_node_tree(material, tag="", log_fn=None):
    """Print full node tree structure of a material for debugging."""
    if log_fn is None:
        log_fn = print
    if not material or not material.node_tree:
        log_fn(f"[Bake|DEBUG|NODES] {tag}: no node tree")
        return
    nt = material.node_tree
    log_fn(f"[Bake|DEBUG|NODES] {tag}: {material.name}")
    log_fn(f"[Bake|DEBUG|NODES]   nodes ({len(nt.nodes)}):")
    for node in nt.nodes:
        log_fn(f"    {node.name} ({node.type})")
        for sock in node.inputs:
            if sock.is_linked:
                fn = sock.links[0].from_node.name
                fs = sock.links[0].from_socket.name
                log_fn(f"      IN  {sock.name} <- {fn}.{fs}")
        for sock in node.outputs:
            if sock.is_linked:
                tn = sock.links[0].to_node.name
                ts = sock.links[0].to_socket.name
                log_fn(f"      OUT {sock.name} -> {tn}.{ts}")


def _sample_image_pixels(img, num_samples=5):
    """Sample pixel values from an image at multiple positions.

    Returns dict with max_rgb, has_alpha, and sample list.
    """
    if not img:
        return {"max_rgb": 0.0, "has_alpha": False, "samples": []}
    w, h = img.size
    if w == 0 or h == 0:
        return {"max_rgb": 0.0, "has_alpha": False, "samples": []}
    positions = [(0, 0), (w-1, 0), (0, h-1), (w-1, h-1), (w//2, h//2)]
    samples = []
    max_rgb = 0.0
    has_alpha = False
    for x, y in positions:
        idx = (y * w + x) * 4
        rgba = tuple(img.pixels[idx:idx+4])
        r, g, b, a = rgba
        max_rgb = max(max_rgb, r, g, b)
        if a > 0.01:
            has_alpha = True
        samples.append({"pos": (x, y), "rgba": rgba})
    return {"max_rgb": max_rgb, "has_alpha": has_alpha, "samples": samples}


def _clone_material_with_bake_target(
        source_material, new_name, bake_images, log):
    """Clone a material completely, then inject bake target TexImage nodes.

    Returns the cloned material with bake target nodes added.
    The bake target nodes are set as active for EMIT baking.
    """
    log.info("CLONE", "===== cloning material =====")

    # Copy the entire source material
    cloned = source_material.copy()
    cloned.name = new_name
    cloned.use_nodes = True

    # Verify clone succeeded
    if not cloned or not cloned.node_tree:
        log.error("CLONE", "material clone failed")
        return None

    log.debug("CLONE", f"cloned '{source_material.name}' -> '{cloned.name}'")
    _dump_node_tree(cloned, "CLONED material (before target injection)",
                    lambda msg: log.debug("NODES", msg))

    # Inject bake target TexImage nodes for each image
    for i, img in enumerate(bake_images):
        tex_node = cloned.node_tree.nodes.new(type="ShaderNodeTexImage")
        tex_node.image = img
        tex_node.name = f"BakeTarget_{i}"
        tex_node.label = img.name

        # Mark as active (for bake target)
        tex_node.select = True
        cloned.node_tree.nodes.active = tex_node

        log.debug("TARGET",
                  f"injected bake target: {tex_node.name}"
                  f" -> {img.name} ({img.size[0]}x{img.size[1]})")

    log.info("CLONE", f"injected {len(bake_images)} bake target(s)")
    _dump_node_tree(cloned, "CLONED material (after target injection)",
                    lambda msg: log.debug("NODES", msg))

    return cloned


def _build_alpha_shader_chain(node_tree, tex_node, log):
    """Build Emission + Transparent + Mix Shader chain for alpha preservation.

    Connections:
      tex_node(Color) -> Emission -> Mix Shader[2]
      tex_node(Alpha) -> Mix Shader(Fac)
      Transparent BSDF  -> Mix Shader[1]
      Mix Shader -> Material Output(Surface)
    """
    # Find or create Output
    output = None
    for node in node_tree.nodes:
        if node.type == 'OUTPUT_MATERIAL':
            output = node
            break
    if not output:
        output = node_tree.nodes.new(type="ShaderNodeOutputMaterial")
        output.location = (400, 0)

    # Remove all existing links to Output Surface
    for link in list(output.inputs["Surface"].links):
        node_tree.links.remove(link)

    # Create Emission Shader
    emission = node_tree.nodes.new(type="ShaderNodeEmission")
    emission.location = (0, 200)
    node_tree.links.new(tex_node.outputs["Color"], emission.inputs["Color"])
    emission.inputs["Strength"].default_value = 1.0

    # Create Transparent BSDF
    transparent = node_tree.nodes.new(type="ShaderNodeBsdfTransparent")
    transparent.location = (0, 0)

    # Create Mix Shader
    mix = node_tree.nodes.new(type="ShaderNodeMixShader")
    mix.location = (200, 100)

    # Connect: Transparent -> Mix[1], Emission -> Mix[2], Alpha -> Mix(Fac)
    node_tree.links.new(transparent.outputs["BSDF"], mix.inputs[1])
    node_tree.links.new(emission.outputs["Emission"], mix.inputs[2])
    node_tree.links.new(tex_node.outputs["Alpha"], mix.inputs[0])

    # Connect Mix -> Output
    node_tree.links.new(mix.outputs["Shader"], output.inputs["Surface"])

    log.debug("CLEAN",
              "built alpha chain: TexImage(Color)->Emission->Mix[2],"
              " TexImage(Alpha)->Mix(Fac), Transparent->Mix[1],"
              " Mix->Output")



class BakeLogger:
    """Debug logger for the material projection baking workflow.

    Outputs to Blender's system console (Window > Toggle System Console)
    and also to a debug log file at <tempdir>/blender_logs/bake_debug.log.
    Supports four log levels for filtering verbosity.
    """

    DEBUG = 0   # Step-by-step detail (node creation, links, loops)
    INFO = 1    # Phase milestones (start/complete stage, counts)
    WARN = 2    # Non-fatal issues (e.g. object has no UV, forced unwrap)
    ERROR = 3   # Fatal errors (operation aborted)

    _log_file = None  # Class-level file handle; None=uninit, False=failed

    def __init__(self, operator=None, level=0):
        self.operator = operator  # Operator instance for self.report()
        self.level = level
        if BakeLogger._log_file is None:
            self._open_log_file()

    @staticmethod
    def _open_log_file():
        """Open a debug log file. Creates directory if needed.

        Uses tempfile.gettempdir() for cross-platform compatibility.
        Closes any previously-leaked handle from module reload.
        """
        import os, io, tempfile
        # Close previous handle (leaked on importlib.reload / addon toggle)
        if isinstance(BakeLogger._log_file, io.IOBase):
            try:
                BakeLogger._log_file.close()
            except Exception:
                pass
        log_dir = os.path.join(tempfile.gettempdir(), "blender_logs")
        log_path = os.path.join(log_dir, "bake_debug.log")
        try:
            os.makedirs(log_dir, exist_ok=True)
            BakeLogger._log_file = open(log_path, "a", encoding="utf-8")
            BakeLogger._log_file.write(
                f"=== BakeLogger started ===\n")
            BakeLogger._log_file.flush()
            print(f"[BakeLogger] writing to {log_path}")
        except Exception as e:
            print(f"[BakeLogger] FAILED to open log: {e}")
            BakeLogger._log_file = False

    def _write(self, level_tag, tag, message):
        """Write a log line to console and file."""
        line = f"[Bake|{level_tag}|{tag}] {message}"
        # Write to file first (more reliable in Blender's embedded Python)
        try:
            fh = BakeLogger._log_file
            if fh and fh is not False:
                fh.write(line + "\n")
                fh.flush()
        except Exception as e:
            # Log failure to console (the one output left when file fails)
            try:
                print(f"[BakeLogger] file write failed: {e}")
            except Exception:
                pass
        # Console output: may fail if stdout is in a bad state or
        # the console codec can't handle the characters in the line.
        try:
            print(line)
        except Exception:
            pass

    def debug(self, tag, message):
        if self.level <= self.DEBUG:
            self._write("DEBUG", tag, message)

    def info(self, tag, message):
        if self.level <= self.INFO:
            self._write("INFO ", tag, message)

    def warn(self, tag, message):
        if self.level <= self.WARN:
            self._write("WARN ", tag, message)

    def error(self, tag, message):
        if self.level <= self.ERROR:
            self._write("ERROR", tag, message)
            if self.operator:
                self.operator.report({"ERROR"}, f"[{tag}] {message}")

    def separator(self):
        self._write("----", "---", "=" * 60)


def bake_material_projection(scene, material, bake_resolution, auto_unwrap=True,
                              skip_unwrap_names=None,
                              angle_limit=66, island_margin=0.0,
                              area_weight=0.0, correct_aspect=False,
                              scale_to_bounds=False,
                              operator=None,
                              object_filter=None):
    """
    Bake camera projection results to textures for new objects.

    Clones the original material (preserving all projection nodes),
    injects a bake target TexImage (active), bakes via EMIT pass,
    then strips down to a clean alpha-aware texture material.

    Parameters
    ----------
    scene : bpy.types.Scene
        Current scene
    material : bpy.types.Material
        Material containing Camera Project node group
    bake_resolution : int
        Bake texture resolution in pixels, range 64~8192
    auto_unwrap : bool
        Whether to re-unwrap objects that already have UV layers
    operator : bpy.types.Operator | None
        Optional operator for self.report() integration
    object_filter : set or None
        Optional set of object names to bake. If None (default),
        all objects using the material are baked. If a set is
        provided, only objects whose name is in the set are baked.

    Returns
    -------
    dict
        {
            "success": bool,
            "baked_objects": list[bpy.types.Object],
            "baked_material": bpy.types.Material | None,
            "baked_images": list[bpy.types.Image],
            "unwrapped_count": int,
            "forced_unwrap_count": int,
            "message": str
        }
    """
    log = BakeLogger(operator=operator)
    start_time = time.time()

    log.separator()
    log.info("VALIDATE",
             f"===== start baking: material '{material.name}' =====")

    try:
        # ---- 1. Validate -------
        if material not in bpy.data.materials.values():
            log.error("VALIDATE", "material not found")
            return _bake_error("Material not found")

        objects = find_objects_using_material(material.name)
        if not objects:
            log.error("VALIDATE", "material not used by any object")
            return _bake_error("No objects use this material")

        # ---- 1.5. Object filter (single-object bake) ----
        if object_filter is not None:
            original_count = len(objects)
            all_obj_names = [o.name for o in objects]
            filtered_out = [o.name for o in objects
                            if o.name not in object_filter]
            objects = [o for o in objects if o.name in object_filter]
            log.info("FILTER",
                     f"object_filter applied: {original_count}"
                     f" → {len(objects)} objects")
            log.debug("FILTER",
                      f"filter set: {sorted(object_filter)}")
            log.debug("FILTER",
                      f"all objects before filter: {all_obj_names}")
            if filtered_out:
                log.debug("FILTER",
                          f"filtered out: {filtered_out}")
                for name in filtered_out:
                    orig_obj = bpy.data.objects.get(name)
                    if orig_obj:
                        log.debug("FILTER",
                                  f"excluded: '{name}'"
                                  f" (hide_render={orig_obj.hide_render},"
                                  f" hide_viewport={orig_obj.hide_viewport},"
                                  f" type={orig_obj.type})")
            if not objects:
                log.error("FILTER",
                          "no objects match filter (all filtered out)")
                return _bake_error(
                    "No objects match the specified filter")

        log.debug("VALIDATE", f"material: {material.name}")
        log.debug("VALIDATE", f"objects using material: {len(objects)}")
        log.debug("VALIDATE", f"object list: {[o.name for o in objects]}")

        # Log original material node tree
        _dump_node_tree(material, "ORIGINAL material",
                        lambda msg: log.debug("NODES", msg))

        # Validate Camera Project node and find camera
        camera = None
        if material.node_tree:
            for node in material.node_tree.nodes:
                if (node.type == "GROUP" and node.node_tree
                        and node.node_tree.name.startswith("Camera Project |")):
                    camera = extract_camera_from_camera_project_group(
                        node.node_tree)
                    break

        if not camera:
            log.error("VALIDATE",
                      "no Camera Project node found in material")
            return _bake_error(
                "Material has no Camera Project node group")

        log.info("VALIDATE", f"camera: {camera.name}")

        # ---- 2. Copy objects ----
        log.info("COPY", "===== step 2: copying objects =====")
        baked_objects = []
        non_mesh_skipped = 0

        for obj in objects:
            # find_objects_using_material() currently returns only MESH,
            # but this guard is kept as future-proofing.
            if obj.type != 'MESH':
                log.warn("COPY",
                         f"skipping non-mesh: {obj.name} (type={obj.type})")
                non_mesh_skipped += 1
                continue
            new_obj = obj.copy()
            new_obj.data = obj.data.copy()
            scene.collection.objects.link(new_obj)
            baked_objects.append(new_obj)
            log.debug("COPY", f"copied {obj.name} -> {new_obj.name}")

        log.info("COPY",
                 f"copied {len(baked_objects)} objects"
                 + (f" (skipped {non_mesh_skipped} non-mesh)"
                    if non_mesh_skipped else ""))

        if not baked_objects:
            log.error("COPY", "no mesh objects to bake")
            return _bake_error("No mesh objects found")

        # ---- 3. UV detection and handling ----
        log.info("UV", "===== step 3: UV detection and handling =====")
        for obj in baked_objects:
            has_uv = bool(obj.data.uv_layers.active)
            log.debug("UV",
                      f"object {obj.name}: has_uv={has_uv},"
                      f" auto_unwrap={auto_unwrap}")

        # Map skip names from original to baked objects
        # Build a name-based mapping to handle non-mesh objects safely.
        # Note: find_objects_using_material() only returns MESH objects
        # today, so the type check below is defensive future-proofing.
        name_to_baked = {}
        bake_idx = 0
        for obj in objects:
            if obj.type == "MESH" and bake_idx < len(baked_objects):
                name_to_baked[obj.name] = baked_objects[bake_idx].name
                bake_idx += 1
        # Safety: if baked_objects and baked_images have different
        # lengths, the mismatch was caught above in Step 5+6.
        # Here we only guard against incomplete name mapping.
        if bake_idx != len(baked_objects):
            log.warn("UV",
                     f"name_to_baked incomplete: mapped {bake_idx} of"
                     f" {len(baked_objects)} objects. Some skip_unwrap"
                     f" names may not resolve correctly.")

        baked_skip_names = set()
        if skip_unwrap_names:
            for obj_name in skip_unwrap_names:
                if obj_name in name_to_baked:
                    baked_skip_names.add(name_to_baked[obj_name])

        uv_result = unwrap_baked_objects(
            baked_objects, auto_unwrap,
            skip_unwrap_names=baked_skip_names,
            angle_limit=angle_limit,
            island_margin=island_margin,
            area_weight=area_weight,
            correct_aspect=correct_aspect,
            scale_to_bounds=scale_to_bounds)
        log.info("UV",
                 f"result: unwrapped={uv_result['unwrapped']},"
                 f" forced={uv_result['forced']},"
                 f" skipped={uv_result['skipped']}")

        # ---- 4. Create bake target images (mesh only) ----
        log.info("TEX",
                 "===== step 4: creating bake target images =====")
        baked_images = []
        for obj in objects:
            # Same future-proof guard as Step 2 — find_objects_using_material()
            # only returns MESH today, but if that ever changes, this prevents
            # baked_images from including non-mesh entries.
            if obj.type != 'MESH':
                continue
            img_name = baked_image_name(material.name, obj.data.name)
            img = bpy.data.images.new(
                img_name, bake_resolution, bake_resolution,
                alpha=True, float_buffer=True)
            baked_images.append(img)
            log.debug("TEX",
                      f"created bake target: {img_name}"
                      f" ({bake_resolution}x{bake_resolution})")

        # ---- 5+6. Clone material per-object + assign ----
        # Each object gets its own material clone with its own active bake target
        # Safety: baked_objects and baked_images must be aligned in length.
        # They are built from the same source list with identical filtering,
        # but a mismatch here is a silent catastrophe (IndexError crash).
        if len(baked_images) != len(baked_objects):
            log.error("CLONE",
                      f"FATAL: image/object count mismatch: "
                      f"{len(baked_images)} images vs "
                      f"{len(baked_objects)} objects")
            return _bake_error(
                f"Internal error: image/object count mismatch "
                f"({len(baked_images)} vs {len(baked_objects)})")
        baked_materials = []
        for i, new_obj in enumerate(baked_objects):
            per_obj_mat_name = f"{baked_material_name(material.name)}_{i}"
            per_obj_images = [baked_images[i]]
            per_obj_mat = _clone_material_with_bake_target(
                material, per_obj_mat_name, per_obj_images, log)
            if not per_obj_mat:
                log.error("CLONE",
                          f"failed to clone material for {new_obj.name}")
                return _bake_error(
                    f"Failed to clone material for {new_obj.name}")
            new_obj.data.materials.clear()
            new_obj.data.materials.append(per_obj_mat)
            baked_materials.append(per_obj_mat)
            log.debug("ASSIGN",
                      f"assigned '{per_obj_mat.name}' to {new_obj.name}")

        baked_mat = baked_materials[0]  # primary material for reporting
        log.info("CLONE",
                 f"created {len(baked_materials)} material clone(s)")

        # ---- 6.5. Fix render visibility ----
        # obj.copy() inherits hide_render from originals. If any original
        # object had hide_render=True, its copy will also be hidden and
        # bpy.ops.object.bake() will reject it.
        log.info("RENDER", "===== step 6.5: fixing render visibility =====")
        fixed_count = 0
        for obj in baked_objects:
            render_state_before = {
                "hide_render": obj.hide_render,
                "hide_viewport": obj.hide_viewport,
            }
            if obj.hide_render:
                log.warn("RENDER",
                         f"object '{obj.name}' has hide_render=True"
                         f" (inherited from original), forcing to False")
                obj.hide_render = False
                fixed_count += 1
            if obj.hide_viewport:
                log.debug("RENDER",
                          f"object '{obj.name}' also has hide_viewport=True,"
                          f" forcing to False")
                obj.hide_viewport = False
            log.debug("RENDER",
                      f"object '{obj.name}' render state: "
                      f"hide_render={render_state_before['hide_render']}"
                      f"→{obj.hide_render}, "
                      f"hide_viewport={render_state_before['hide_viewport']}"
                      f"→{obj.hide_viewport}")
        if fixed_count > 0:
            log.info("RENDER",
                     f"forced hide_render=False on {fixed_count} object(s)")
        log.info("RENDER",
                 f"verified {len(baked_objects)} object(s) renderable")

        # ---- 7. Execute COMBINED bake (with temporary Cycles switch) ----
        log.info("BAKE", "===== step 7: executing COMBINED bake =====")
        log.debug("BAKE",
                  f"objects to bake: {[o.name for o in baked_objects]}")
        log.debug("BAKE",
                  "settings: type=COMBINED, margin=4, margin_type=EXTEND")

        # Log active TexImage per object before baking
        for obj_idx, obj in enumerate(baked_objects):
            for slot in obj.material_slots:
                if slot.material and slot.material.node_tree:
                    active = slot.material.node_tree.nodes.active
                    if active:
                        log.debug("BAKE",
                                  f"  obj[{obj_idx}] {obj.name}:"
                                  f" active node = {active.name}"
                                  f" ({active.type})")
                        if active.type == 'TEX_IMAGE' and active.image:
                            channels = active.image.channels
                            log.debug("BAKE",
                                      f"    image: {active.image.name}"
                                      f" ({active.image.size[0]}"
                                      f"x{active.image.size[1]},"
                                      f" channels={channels})")

        original_engine = scene.render.engine
        if original_engine != 'CYCLES':
            log.info("BAKE",
                     f"switching render engine from {original_engine}"
                     f" to CYCLES for baking")
            scene.render.engine = 'CYCLES'
            try:
                scene.cycles.samples = 1
            except AttributeError:
                pass

        bpy.ops.object.select_all(action='DESELECT')
        for obj in baked_objects:
            obj.select_set(True)
        if baked_objects:
            bpy.context.view_layer.objects.active = baked_objects[0]

        # Pre-bake safety net: double-check no selected object is
        # hidden from render (defense against unforeseen edge cases).
        unrenderable = [o.name for o in baked_objects if o.hide_render]
        if unrenderable:
            log.error("BAKE",
                      f"FATAL: {len(unrenderable)} object(s) still have"
                      f" hide_render=True after fix: {unrenderable}")
            return _bake_error(
                "Internal error: failed to fix render visibility")
        log.debug("BAKE",
                  f"pre-bake render check: all {len(baked_objects)}"
                  f" objects renderable ✓")

        try:
            bpy.ops.object.bake(
                type='COMBINED',
                target='IMAGE_TEXTURES',
                use_clear=True,
                margin=4,
                margin_type='EXTEND',
            )
        finally:
            if original_engine != 'CYCLES':
                scene.render.engine = original_engine
                log.info("BAKE",
                         f"restored render engine to {original_engine}")

        elapsed = time.time() - start_time
        log.info("BAKE", f"bake completed ({elapsed:.1f}s)")

        # ---- 8. Clean up: strip to alpha-aware shader ----
        log.info("CLEAN", "===== step 9: cleaning up material(s) =====")

        for mat in baked_materials:
            target_nodes = []
            for node in list(mat.node_tree.nodes):
                if node.type == 'TEX_IMAGE' and node.name.startswith("BakeTarget_"):
                    target_nodes.append(node)
                elif node.type not in ('OUTPUT_MATERIAL',):
                    mat.node_tree.nodes.remove(node)

            for link in list(mat.node_tree.links):
                mat.node_tree.links.remove(link)

            # Count node types for logging
            total_before = len(mat.node_tree.nodes)
            group_nodes = sum(1 for n in mat.node_tree.nodes if n.type == 'GROUP')
            tex_nodes = sum(1 for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE')
            other_nodes = total_before - group_nodes - tex_nodes
            log.debug("CLEAN",
                      f"'{mat.name}': {total_before} nodes before cleanup"
                      f" ({group_nodes} groups, {tex_nodes} tex,"
                      f" {other_nodes} other)")
            log.debug("CLEAN",
                      f"  kept {len(target_nodes)} bake target(s),"
                      f" removed {total_before - len(target_nodes)} nodes")

            for tex_node in target_nodes:
                _build_alpha_shader_chain(
                    mat.node_tree, tex_node, log)

            _dump_node_tree(mat, f"CLEANED '{mat.name}'",
                            lambda msg: log.debug("NODES", msg))

        # ---- 10. Deselect all ----
        bpy.ops.object.select_all(action='DESELECT')

        # ---- 11. Pixel validation ----
        for img_idx, img in enumerate(baked_images):
            result = _sample_image_pixels(img)
            sample_str = "; ".join(
                f"({s['pos'][0]},{s['pos'][1]})"
                f"=[{s['rgba'][0]:.3f},{s['rgba'][1]:.3f},"
                f"{s['rgba'][2]:.3f},{s['rgba'][3]:.3f}]"
                for s in result['samples'])
            log.debug("DONE",
                      f"img[{img_idx}] '{img.name}':"
                      f" samples={sample_str}")
            if result["max_rgb"] < 0.01:
                log.warn("DONE",
                         f"  WARNING: '{img.name}' appears fully black"
                         f" (max_rgb={result['max_rgb']:.4f})")
            else:
                log.info("DONE",
                         f"  '{img.name}': max_rgb={result['max_rgb']:.4f},"
                         f" has_alpha={result['has_alpha']}")

        total_elapsed = time.time() - start_time
        mat_names = ", ".join(m.name for m in baked_materials)
        log.info("DONE", "===== baking complete =====")
        log.info("DONE", f"generated objects: {len(baked_objects)}")
        log.info("DONE", f"generated materials: {mat_names}")
        log.info("DONE", f"generated textures: {len(baked_images)}")
        log.info("DONE", f"UV unwrapped (user): {uv_result['unwrapped']}")
        log.info("DONE", f"UV unwrapped (forced): {uv_result['forced']}")
        log.info("DONE", f"total time: {total_elapsed:.1f}s")

        # Pack all baked images into .blend (each isolated, failures are warnings).
        for img in baked_images:
            try:
                img.pack()
            except Exception as pack_err:
                log.warn("PACK", f"failed to pack '{img.name}': {pack_err}")

        return {
            "success": True,
            "baked_objects": baked_objects,
            "baked_material": baked_materials[0] if baked_materials else None,
            "baked_images": baked_images,
            "unwrapped_count": uv_result['unwrapped'],
            "forced_unwrap_count": uv_result['forced'],
            "message": f"Baked {len(baked_objects)} object(s)",
        }

    except Exception as e:
        log.error("FATAL",
                  f"unexpected error during baking: {str(e)}")
        log.debug("FATAL", f"traceback:\n{traceback.format_exc()}")
        return _bake_error(f"Baking failed: {str(e)}")


def _bake_error(message):
    """Return a standardized error dict for bake_material_projection."""
    return {
        "success": False,
        "baked_objects": [],
        "baked_material": None,
        "baked_images": [],
        "unwrapped_count": 0,
        "forced_unwrap_count": 0,
        "message": message,
    }
