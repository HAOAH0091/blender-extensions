import bpy
import ast
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty

# Import helper functions
from ..utils import is_object_renderable, find_layer_collection_recursive, is_object_visible_in_viewlayer


def aov_node_type(node):
    """AOV type implied by the shader node's connected input."""
    value = node.inputs.get("Value")
    color = node.inputs.get("Color")
    if value is not None and value.is_linked and not (color is not None and color.is_linked):
        return 'VALUE'
    return 'COLOR'


def walk_aovs(tree, chain=(), seen=frozenset(), found=None):
    """Collect AOV nodes from a node tree, following groups at any depth."""
    if found is None:
        found = []
    for node in tree.nodes:
        if node.type == 'OUTPUT_AOV' and node.aov_name:
            found.append((node.aov_name, aov_node_type(node), chain))
        elif node.type == 'GROUP' and node.node_tree:
            name = node.node_tree.name
            if name in seen:
                continue
            walk_aovs(node.node_tree, chain + (name,), seen | {name}, found)
    return found


def layer_material_names(view_layer):
    names = set()
    for obj in bpy.data.objects:
        if obj.material_slots and is_object_renderable(obj, view_layer):
            for slot in obj.material_slots:
                if slot.material:
                    names.add(slot.material.name)
    return names


def collect_layer_sources(context, view_layer):
    """AOV sources reachable from this view layer's renderable materials."""
    material_names = layer_material_names(view_layer)
    material_to_objects = {}
    for obj in bpy.data.objects:
        for slot in obj.material_slots:
            if slot.material:
                material_to_objects.setdefault(slot.material.name, set()).add(obj.name)
    locations = {}
    for name in sorted(material_names):
        mat = bpy.data.materials.get(name)
        if mat is None or not mat.use_nodes:
            continue
        for aov_name, kind, chain in walk_aovs(mat.node_tree):
            entry = locations.setdefault(aov_name, {
                'materials': set(), 'material_groups': {}, 'objects': set(),
                'groups': set(), 'type': kind,
            })
            if not chain:
                entry['materials'].add(name)
            else:
                entry['material_groups'].setdefault(name, set()).add(chain)
                entry['groups'].add(chain[-1])
            entry['objects'].update(material_to_objects.get(name, ()))
    return locations


def load_index(scene):
    raw = getattr(scene, 'aov_locations', '{}')
    try:
        data = ast.literal_eval(raw) if isinstance(raw, str) else raw
    except (ValueError, SyntaxError):
        return {}
    if not isinstance(data, dict):
        return {}
    if data and all(isinstance(value, dict) and 'materials' in value for value in data.values()):
        return {'': data}
    return data


def store_index(scene, data):
    scene.aov_locations = repr(data)


def serialized(locations):
    result = {}
    for name, entry in locations.items():
        result[name] = {
            'materials': sorted(entry['materials']),
            'material_groups': {mat: [list(chain) for chain in sorted(chains)]
                                for mat, chains in sorted(entry['material_groups'].items())},
            'objects': sorted(entry['objects']),
            'groups': sorted(entry['groups']),
            'type': entry['type'],
        }
    return result


def sync_layer(context, view_layer):
    """Add missing AOVs for this layer; keep manual and unknown entries."""
    locations = collect_layer_sources(context, view_layer)
    data = load_index(context.scene)
    previous = data.get(view_layer.name, {})
    existing = {aov.name: aov for aov in view_layer.aovs}
    for name in list(previous):
        if name in locations or name not in existing:
            continue
        if aov_exists_anywhere(name):
            continue
        view_layer.aovs.remove(existing[name])
        existing.pop(name)
    conflicts = []
    added = 0
    for name, entry in locations.items():
        if name in existing:
            if existing[name].type != entry['type']:
                conflicts.append((name, existing[name].type, entry['type']))
            continue
        aov = view_layer.aovs.add()
        aov.name = name
        aov.type = entry['type']
        added += 1
    data[view_layer.name] = serialized(locations)
    store_index(context.scene, data)
    return locations, added, conflicts


def aov_exists_anywhere(aov_name):
    """True while any material still contains this AOV node, even if hidden here."""
    for mat in bpy.data.materials:
        if mat.use_nodes and any(name == aov_name for name, _, _ in walk_aovs(mat.node_tree)):
            return True
    return False


def all_sources_for(context, aov_name):
    materials = set()
    groups = set()
    for view_layer in context.scene.view_layers:
        entry = collect_layer_sources(context, view_layer).get(aov_name)
        if entry:
            materials.update(entry['materials'])
            groups.update(entry['groups'])
    index = load_index(context.scene).get(context.view_layer.name, {})
    stored = index.get(aov_name)
    if stored:
        materials.update(stored.get('materials', []))
        groups.update(stored.get('groups', []))
    return materials, groups


def impact_of(context, view_layer, aov_name):
    """Materials or other view layers that would change if this AOV is edited."""
    material_names = layer_material_names(view_layer)
    affected = set()
    for mat in bpy.data.materials:
        if not mat.use_nodes or mat.name in material_names:
            continue
        if any(name == aov_name for name, _, _ in walk_aovs(mat.node_tree)):
            affected.add(f"材质 {mat.name}")
    for other in context.scene.view_layers:
        if other == view_layer:
            continue
        if aov_name in collect_layer_sources(context, other):
            affected.add(f"视图层 {other.name}")
    return sorted(affected)


def layers_with_aov(context, aov_name):
    layers = []
    for other in context.scene.view_layers:
        if aov_name in collect_layer_sources(context, other) or any(a.name == aov_name for a in other.aovs):
            layers.append(other)
    return layers

class AOV_OT_sync_aovs(Operator):
    """同步所有材质中的AOV节点到渲染层AOV列表"""
    bl_idname = "render.sync_aovs"
    bl_label = "同步AOV节点"
    bl_options = {'REGISTER', 'UNDO'}

    def get_renderable_materials(self, context):
        """获取可渲染对象的材质列表"""
        renderable_materials = set()
        view_layer = context.view_layer

        for obj in bpy.data.objects:
            # 使用导入的辅助函数
            if obj.material_slots and is_object_renderable(obj, view_layer):
                for slot in obj.material_slots:
                    if slot.material:
                        renderable_materials.add(slot.material)

        return renderable_materials

    def execute(self, context):
        view_layer = context.view_layer
        locations, added, conflicts = sync_layer(context, view_layer)
        aov_states = context.scene.aov_states
        names = {aov.name for aov in view_layer.aovs}
        for index in reversed(range(len(aov_states))):
            if aov_states[index].name not in names:
                aov_states.remove(index)
        known = {state.name for state in aov_states}
        for name in sorted(locations):
            if name not in known:
                state = aov_states.add()
                state.name = name
                state.is_expanded = False
        for name, current, wanted in conflicts:
            self.report({'WARNING'}, f"AOV '{name}' 现有类型 {current}，节点输出 {wanted}；已保留现有类型")
        self.report({'INFO'}, f"AOV节点同步完成：新增 {added} 个，保留现有 {len(view_layer.aovs) - added} 个")
        return {'FINISHED'}

class AOV_OT_select_material(Operator):
    """选择材质"""
    bl_idname = "render.select_material"
    bl_label = "选择材质"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: StringProperty(name="Material Name")

    def execute(self, context):
        view_layer = context.view_layer
        found_objects = []

        for obj in bpy.data.objects:
            if obj.material_slots:
                for slot_idx, slot in enumerate(obj.material_slots):
                    if slot.material and slot.material.name == self.material_name:
                        if is_object_visible_in_viewlayer(obj, view_layer):
                            found_objects.append((obj, slot_idx))
                            break

        if not found_objects:
            all_objects = [(obj, slot_idx) for obj in bpy.data.objects
                           for slot_idx, slot in enumerate(obj.material_slots)
                           if slot.material and slot.material.name == self.material_name]

            if all_objects:
                obj_names = ", ".join(obj.name for obj, _ in all_objects)
                self.report({'WARNING'},
                    f"物体 {obj_names} 包含材质 '{self.material_name}'，但在当前视图层中不可见")
                return {'CANCELLED'}
            else:
                self.report({'WARNING'},
                    f"未找到使用材质 '{self.material_name}' 的物体")
                return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')

        for obj, slot_idx in found_objects:
            obj.select_set(True)
            if obj == found_objects[-1][0]:
                context.view_layer.objects.active = obj
                obj.active_material_index = slot_idx

        for area in context.screen.areas:
            if area.type == 'NODE_EDITOR':
                space = area.spaces.active
                space.tree_type = 'ShaderNodeTree'
                space.shader_type = 'OBJECT'
                mat = bpy.data.materials.get(self.material_name)
                if mat:
                    space.node_tree = mat.node_tree
                break

        return {'FINISHED'}

class AOV_OT_select_node_group(Operator):
    """选择节点组"""
    bl_idname = "render.select_node_group"
    bl_label = "选择节点组"
    bl_options = {'REGISTER', 'UNDO'}

    group_name: StringProperty(name="Group Name")
    material_name: StringProperty(name="Material Name", default="")

    def select_objects_with_material(self, context):
        """选择使用指定材质的物体"""
        view_layer = context.view_layer
        found_objects = []

        for obj in bpy.data.objects:
            if obj.material_slots:
                for slot_idx, slot in enumerate(obj.material_slots):
                    if slot.material and slot.material.name == self.material_name:
                        if is_object_visible_in_viewlayer(obj, view_layer):
                            found_objects.append((obj, slot_idx))
                            break

        if not found_objects:
            all_objects = [(obj, slot_idx) for obj in bpy.data.objects
                           for slot_idx, slot in enumerate(obj.material_slots)
                           if slot.material and slot.material.name == self.material_name]

            if all_objects:
                obj_names = ", ".join(obj.name for obj, _ in all_objects)
                self.report({'WARNING'},
                    f"物体 {obj_names} 包含材质 '{self.material_name}'，但在当前视图层中不可见")
                return False
            else:
                self.report({'WARNING'},
                    f"未找到使用材质 '{self.material_name}' 的物体")
                return False

        bpy.ops.object.select_all(action='DESELECT')

        for obj, slot_idx in found_objects:
            obj.select_set(True)
            if obj == found_objects[-1][0]:
                context.view_layer.objects.active = obj
                obj.active_material_index = slot_idx

        return True

    def find_node_editor(self, context):
        """找到或创建节点编辑器"""
        for area in context.screen.areas:
            if area.type == 'NODE_EDITOR':
                return area, area.spaces.active
        return None, None

    def setup_node_editor(self, space):
        """设置节点编辑器基本属性"""
        if space:
            space.tree_type = 'ShaderNodeTree'
            space.shader_type = 'OBJECT'
            return True
        return False

    def find_target_node(self, mat):
        """在材质中查找目标节点组"""
        if not mat or not mat.node_tree: return None
        for node in mat.node_tree.nodes:
            if (node.type == 'GROUP' and
                node.node_tree and
                node.node_tree.name == self.group_name):
                return node
        return None

    def modal(self, context, event):
        if event.type == 'TIMER':
            if not hasattr(self, "step"):
                self.step = 0
                if not self.select_objects_with_material(context):
                    context.window_manager.event_timer_remove(self._timer)
                    return {'CANCELLED'}

                self.node_editor, self.space = self.find_node_editor(context)
                if not self.node_editor:
                    self.report({'ERROR'}, "未找到节点编辑器")
                    context.window_manager.event_timer_remove(self._timer)
                    return {'CANCELLED'}

            if self.step == 0:
                if not self.setup_node_editor(self.space):
                    self.report({'ERROR'}, "无法设置节点编辑器")
                    context.window_manager.event_timer_remove(self._timer)
                    return {'CANCELLED'}
                self.step = 1

            elif self.step == 1:
                if self.material_name:
                    self.mat = bpy.data.materials.get(self.material_name)
                    if not self.mat:
                        self.report({'ERROR'}, f"未找到材质: {self.material_name}")
                        context.window_manager.event_timer_remove(self._timer)
                        return {'CANCELLED'}

                    self.space.node_tree = self.mat.node_tree
                    if context.active_object and context.active_object.active_material != self.mat:
                         # 确保活动对象的材质与目标材质一致
                         context.active_object.active_material = self.mat
                self.step = 2

            elif self.step == 2:
                self.target_node = None # Reset target node
                if hasattr(self, "mat") and self.mat:
                    self.target_node = self.find_target_node(self.mat)
                    if self.target_node:
                        # Ensure node tree is active
                        if self.space.node_tree != self.mat.node_tree:
                            self.space.node_tree = self.mat.node_tree
                        # Select and activate the node
                        for node in self.mat.node_tree.nodes:
                            node.select = False
                        self.target_node.select = True
                        self.mat.node_tree.nodes.active = self.target_node
                    else:
                        print(f"Warning: Target node group '{self.group_name}' not found in material '{self.material_name}'.")
                self.step = 3

            elif self.step == 3:
                if not self.target_node:
                    # If target node wasn't found in step 2, cancel
                    self.report({'WARNING'}, f"未能找到节点组 '{self.group_name}' 在材质 '{self.material_name}' 中.")
                    context.window_manager.event_timer_remove(self._timer)
                    return {'CANCELLED'}

                window_region = next((region for region in self.node_editor.regions
                                   if region.type == 'WINDOW'), None)

                if not window_region:
                    self.report({'ERROR'}, "未找到编辑器区域")
                    context.window_manager.event_timer_remove(self._timer)
                    return {'CANCELLED'}

                # Double-check context before overriding
                if not self.mat or not self.mat.node_tree or not self.target_node:
                     self.report({'ERROR'}, "上下文状态无效，无法进入节点组")
                     context.window_manager.event_timer_remove(self._timer)
                     return {'CANCELLED'}

                override = {
                    "window": context.window,
                    "screen": context.screen,
                    "area": self.node_editor,
                    "region": window_region,
                    "space_data": self.space,
                    "node_tree": self.mat.node_tree,
                    "edit_tree": self.mat.node_tree,
                    "active_node": self.target_node,
                    "selected_nodes": [self.target_node]
                }

                try:
                    with context.temp_override(**override):
                        bpy.ops.node.group_edit(exit=False)
                except Exception as e:
                    self.report({'ERROR'}, f"无法进入节点组: {str(e)}")
                    print(f"错误详情: {str(e)}")
                    print(f"Override context: {override}")
                finally:
                    # Always remove timer regardless of success or failure
                    context.window_manager.event_timer_remove(self._timer)

                return {'FINISHED'}

            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def execute(self, context):
        if not bpy.data.node_groups.get(self.group_name):
            self.report({'ERROR'}, f"未找到节点组: {self.group_name}")
            return {'CANCELLED'}

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window=context.window) # Reduced delay slightly
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class AOV_OT_rename_aov(Operator):
    """重命名AOV节点"""
    bl_idname = "render.rename_aov"
    bl_label = "重命名AOV"
    bl_options = {'REGISTER', 'UNDO'}

    old_name: StringProperty(name="原名称")
    new_name: StringProperty(name="新名称")
    confirm_shared: BoolProperty(name="确认影响其他层或材质", default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        impact = impact_of(context, context.view_layer, self.old_name)
        if impact:
            self.confirm_shared = True
            return context.window_manager.invoke_confirm(
                self, event,
                message=f"改名会影响 {'、'.join(impact)}，是否继续？",
            )
        return self.execute(context)

    def execute(self, context):
        if not self.new_name:
            self.report({'ERROR'}, "新名称不能为空")
            return {'CANCELLED'}

        if self.new_name == self.old_name:
            return {'CANCELLED'}

        view_layer = context.view_layer
        data = load_index(context.scene)
        layer_index = data.get(view_layer.name, {})
        locations = layer_index.get(self.old_name)
        if not locations:
            live = collect_layer_sources(context, view_layer)
            locations = serialized(live).get(self.old_name)
        if not locations:
            self.report({'ERROR'}, f"未找到AOV: {self.old_name}")
            return {'CANCELLED'}

        if self.new_name in layer_index or any(aov.name == self.new_name for aov in view_layer.aovs):
            self.report({'ERROR'}, f"AOV名称 '{self.new_name}' 已存在")
            return {'CANCELLED'}

        impact = impact_of(context, view_layer, self.old_name)
        if impact and not self.confirm_shared:
            self.report({'ERROR'}, f"改名会影响 {'、'.join(impact)}，未修改；请先确认影响范围")
            return {'CANCELLED'}

        materials, groups = all_sources_for(context, self.old_name)
        for mat_name in sorted(materials):
            mat = bpy.data.materials.get(mat_name)
            if mat and mat.use_nodes:
                for node in mat.node_tree.nodes:
                    if node.type == 'OUTPUT_AOV' and node.aov_name == self.old_name:
                        node.aov_name = self.new_name

        for group_name in sorted(groups):
            group = bpy.data.node_groups.get(group_name)
            if group:
                for node in group.nodes:
                    if node.type == 'OUTPUT_AOV' and node.aov_name == self.old_name:
                        node.aov_name = self.new_name

        for affected in layers_with_aov(context, self.old_name):
            for aov in affected.aovs:
                if aov.name == self.old_name:
                    aov.name = self.new_name
                    break
            sync_layer(context, affected)

        sync_layer(context, view_layer)
        aov_states = context.scene.aov_states
        for state in aov_states:
            if state.name == self.old_name:
                state.name = self.new_name
                break

        self.report({'INFO'}, f"已将AOV '{self.old_name}' 重命名为 '{self.new_name}'")
        return {'FINISHED'}

class AOV_OT_delete_aov(Operator):
    """删除AOV节点"""
    bl_idname = "render.delete_aov"
    bl_label = "删除AOV"
    bl_options = {'REGISTER', 'UNDO'}

    aov_name: StringProperty(name="AOV名称")
    confirm_shared: BoolProperty(name="确认影响其他层或材质", default=False, options={'HIDDEN'})

    # Add invoke method for confirmation
    def invoke(self, context, event):
        impact = impact_of(context, context.view_layer, self.aov_name)
        if impact:
            self.confirm_shared = True
            return context.window_manager.invoke_confirm(
                self, event,
                message=f"删除会影响 {'、'.join(impact)}，是否继续？",
            )
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        view_layer = context.view_layer
        data = load_index(context.scene)
        locations = data.get(view_layer.name, {}).get(self.aov_name)
        if not locations:
            locations = serialized(collect_layer_sources(context, view_layer)).get(self.aov_name)

        if not locations:
            aov_in_layer = next((a for a in view_layer.aovs if a.name == self.aov_name), None)
            if aov_in_layer:
                 view_layer.aovs.remove(aov_in_layer)
                 aov_states = context.scene.aov_states
                 for i, state in enumerate(aov_states):
                     if state.name == self.aov_name:
                         aov_states.remove(i)
                         break
                 sync_layer(context, view_layer)
                 self.report({'INFO'}, f"已从渲染层移除孤立的AOV '{self.aov_name}'")
                 return {'FINISHED'}
            else:
                self.report({'WARNING'}, f"未找到AOV: {self.aov_name}")
                return {'CANCELLED'}

        impact = impact_of(context, view_layer, self.aov_name)
        if impact and not self.confirm_shared:
            self.report({'ERROR'}, f"删除会影响 {'、'.join(impact)}，未修改；请先确认影响范围")
            return {'CANCELLED'}

        materials, groups = all_sources_for(context, self.aov_name)
        mat_count = len(materials)
        group_count = len(groups)
        for mat_name in sorted(materials):
            mat = bpy.data.materials.get(mat_name)
            if mat and mat.use_nodes:
                nodes_to_remove = [node for node in mat.node_tree.nodes if node.type == 'OUTPUT_AOV' and node.aov_name == self.aov_name]
                for node in nodes_to_remove:
                    mat.node_tree.nodes.remove(node)

        for group_name in sorted(groups):
            group = bpy.data.node_groups.get(group_name)
            if group:
                nodes_to_remove = [node for node in group.nodes if node.type == 'OUTPUT_AOV' and node.aov_name == self.aov_name]
                for node in nodes_to_remove:
                    group.nodes.remove(node)

        affected_layers = layers_with_aov(context, self.aov_name)
        for affected in affected_layers:
            for aov in list(affected.aovs):
                if aov.name == self.aov_name:
                    affected.aovs.remove(aov)
                    break
            sync_layer(context, affected)

        sync_layer(context, view_layer)
        aov_states = context.scene.aov_states
        for i, state in enumerate(aov_states):
            if state.name == self.aov_name:
                aov_states.remove(i)
                break

        self.report({'INFO'}, f"已删除AOV '{self.aov_name}' (从 {mat_count} 个材质和 {group_count} 个节点组中移除)")
        # Trigger a sync after deletion to refresh UI potentially
        # bpy.ops.render.sync_aovs('INVOKE_DEFAULT') # Can cause issues if run mid-operation
        return {'FINISHED'}


class AOV_OT_delete_material_aov(Operator):
    """删除指定材质中的AOV节点"""
    bl_idname = "render.delete_material_aov"
    bl_label = "删除材质AOV"
    bl_options = {'REGISTER', 'UNDO'}

    aov_name: StringProperty(name="AOV名称")
    material_name: StringProperty(name="材质名称")

    def execute(self, context):
        mat = bpy.data.materials.get(self.material_name)
        if not mat or not mat.use_nodes:
            self.report({'ERROR'}, f"未找到材质: {self.material_name}")
            return {'CANCELLED'}

        nodes_removed = 0
        nodes_to_remove = [node for node in mat.node_tree.nodes if node.type == 'OUTPUT_AOV' and node.aov_name == self.aov_name]
        for node in nodes_to_remove:
            mat.node_tree.nodes.remove(node)
            nodes_removed += 1

        if nodes_removed > 0:
              sync_layer(context, context.view_layer)

              self.report({'INFO'}, f"已从材质 '{self.material_name}' 中删除 {nodes_removed} 个 '{self.aov_name}' AOV节点")
             # Consider syncing AOV list after modification
             # bpy.ops.render.sync_aovs('INVOKE_DEFAULT')
        else:
             self.report({'INFO'}, f"在材质 '{self.material_name}' 中未找到 '{self.aov_name}' AOV节点")

        return {'FINISHED'}

class AOV_OT_delete_group_aov(Operator):
    """删除指定节点组中的AOV节点"""
    bl_idname = "render.delete_group_aov"
    bl_label = "删除节点组AOV"
    bl_options = {'REGISTER', 'UNDO'}

    aov_name: StringProperty(name="AOV名称")
    material_name: StringProperty(name="材质名称") # Still needed for context in locations dict
    group_name: StringProperty(name="节点组名称")

    def execute(self, context):
        group = bpy.data.node_groups.get(self.group_name)
        if not group:
            self.report({'ERROR'}, f"未找到节点组: {self.group_name}")
            return {'CANCELLED'}

        nodes_removed = 0
        nodes_to_remove = [node for node in group.nodes if node.type == 'OUTPUT_AOV' and node.aov_name == self.aov_name]
        for node in nodes_to_remove:
            group.nodes.remove(node)
            nodes_removed += 1

        if nodes_removed > 0:
            sync_layer(context, context.view_layer)

            self.report({'INFO'}, f"已从节点组 '{self.group_name}' (材质 '{self.material_name}') 中删除 {nodes_removed} 个 '{self.aov_name}' AOV节点")
             # bpy.ops.render.sync_aovs('INVOKE_DEFAULT')
        else:
             self.report({'INFO'}, f"在节点组 '{self.group_name}' 中未找到 '{self.aov_name}' AOV节点")

        return {'FINISHED'}

class AOV_OT_assign_aov(Operator):
    """将AOV节点添加到选中对象的所有材质中，并可选地复制其上游连接"""
    bl_idname = "render.assign_aov"
    bl_label = "赋予AOV"
    bl_options = {'REGISTER', 'UNDO'}

    aov_name: StringProperty(name="AOV名称")

    def execute(self, context):
        scene = context.scene # Get scene context
        if not self.aov_name:
            self.report({'WARNING'}, "AOV名称不能为空")
            return {'CANCELLED'}

        if not context.selected_objects:
            self.report({'WARNING'}, "未选中任何对象")
            return {'CANCELLED'}

        # 获取复选框状态 (如果属性未注册则默认为 False)
        assign_with_connected = getattr(scene, 'aov_plus_assign_with_connected', False)

        if not assign_with_connected:
            # --- 原有逻辑：仅添加AOV节点 ---
            nodes_added = 0
            materials_processed = set()

            for obj in context.selected_objects:
                if not obj.material_slots:
                    continue

                for slot in obj.material_slots:
                    if not slot.material or not slot.material.use_nodes:
                        continue

                    mat = slot.material
                    if mat.name in materials_processed:
                        continue

                    materials_processed.add(mat.name)
                    node_tree = mat.node_tree

                    exists = False
                    for node in node_tree.nodes:
                        if node.type == 'OUTPUT_AOV' and node.aov_name == self.aov_name:
                            exists = True
                            break

                    if not exists:
                        aov_node = node_tree.nodes.new('ShaderNodeOutputAOV')
                        aov_node.aov_name = self.aov_name

                        # --- 原有的节点定位逻辑 ---
                        max_x = 0
                        max_y = 0
                        output_node = None
                        for node in node_tree.nodes:
                             if node.location.x > max_x:
                                  max_x = node.location.x
                             if node.bl_idname == 'ShaderNodeOutputMaterial': # Find material output
                                  output_node = node
                                  max_y = node.location.y # Use Y of material output

                        if output_node:
                            aov_node.location.x = output_node.location.x + output_node.width + 100
                            aov_node.location.y = output_node.location.y # Align Y
                        else: # Fallback
                             aov_node.location.x = max_x + 300
                             aov_node.location.y = 0
                        # --- 结束：原有的节点定位逻辑 ---

                        nodes_added += 1

            if nodes_added > 0:
                self.report({'INFO'}, f"已添加 {nodes_added} 个 '{self.aov_name}' AOV节点到 {len(materials_processed)} 个材质中")
                # Consider syncing only if nodes were added
                bpy.ops.render.sync_aovs('INVOKE_DEFAULT')
            else:
                self.report({'INFO'}, f"未添加任何新的 '{self.aov_name}' AOV节点 (可能已存在)")
            return {'FINISHED'}
        else:
            # --- 新逻辑：添加AOV并复制连接 ---
            self.report({'INFO'}, "开始赋予AOV并复制连接...")

            # 1. 查找源 AOV 节点网络 (不再排除目标材质)
            source_candidates = self.find_source_aov_networks(context, self.aov_name)

            if not source_candidates:
                # --- 修改：如果找不到任何源，提示用户并尝试仅添加 --- #
                self.report({'INFO'}, f"在场景中未找到名称为 '{self.aov_name}' 的可用源节点网络，将尝试仅添加AOV节点。")
                nodes_added_fallback = 0
                mats_processed_fallback = set()
                for obj in context.selected_objects:
                    if not obj.material_slots: continue
                    for slot in obj.material_slots:
                        if not slot.material or not slot.material.use_nodes: continue
                        mat_fb = slot.material
                        if mat_fb.name in mats_processed_fallback: continue
                        mats_processed_fallback.add(mat_fb.name)
                        node_tree_fb = mat_fb.node_tree
                        exists_fb = any(n.type == 'OUTPUT_AOV' and n.aov_name == self.aov_name for n in node_tree_fb.nodes)
                        if not exists_fb:
                             added_node_fb = self.add_single_aov_node(node_tree_fb, self.aov_name)
                             if added_node_fb: nodes_added_fallback += 1
                if nodes_added_fallback > 0:
                     self.report({'INFO'}, f"已添加 {nodes_added_fallback} 个 '{self.aov_name}' AOV节点。")
                     bpy.ops.render.sync_aovs('INVOKE_DEFAULT')
                else:
                     self.report({'INFO'}, f"未添加任何新的 '{self.aov_name}' AOV节点 (无需添加或已存在)。")
                return {'FINISHED'}

            # TODO: Handle multiple candidates (popup)
            source_material, source_info = list(source_candidates.items())[0]
            source_node = source_info['node']
            is_group_source = source_info['is_group']
            is_connected_source = source_info['is_connected'] # 源节点是否有连接？

            log_source_type = "组内" if is_group_source else ("顶层已连接" if is_connected_source else "顶层未连接")
            self.report({'INFO'}, f"找到最佳源于材质 '{source_material.name}', 类型: {log_source_type}")

            # --- 应用到选中对象 --- #
            materials_processed = set()
            nodes_added_count = 0
            connections_made_count = 0
            copied_node_count = 0
            skipped_count = 0

            for obj in context.selected_objects:
                if not obj.material_slots: continue
                for slot in obj.material_slots:
                    if not slot.material or not slot.material.use_nodes: continue
                    target_mat = slot.material
                    if target_mat.name in materials_processed: continue
                    materials_processed.add(target_mat.name)
                    target_node_tree = target_mat.node_tree

                    # --- 新增：跳过源材质本身 --- #
                    if target_mat == source_material:
                        continue # 它就是源头，不需要处理
                    # --- 源材质跳过结束 --- #

                    # --- 检查目标材质是否已存在同名 AOV --- #
                    target_aov_node = None
                    existing_aov_found = False
                    if not is_group_source: # 只检查顶层 AOV，不检查组内是否已有
                        for node in target_node_tree.nodes:
                            if node.type == 'OUTPUT_AOV' and node.aov_name == self.aov_name:
                                target_aov_node = node
                                existing_aov_found = True
                                break

                    # --- 如果目标已存在 AOV，则跳过此材质的网络复制 --- #
                    if existing_aov_found:
                        self.report({'INFO'}, f"材质 '{target_mat.name}' 已存在 AOV '{self.aov_name}'，跳过网络复制。")
                        skipped_count += 1
                        continue # 处理下一个材质

                    # --- 如果源有连接，才进行复制和连接 --- #
                    if is_connected_source:
                        # --- 情况1: 源已连接 (执行递归复制) --- #
                        # self.report({'INFO'}, f"正在从 '{source_material.name}' 复制网络到 '{target_mat.name}'..." ) # Reduce console spam
                        
                        # 既然上面检查了不存在，这里就创建新的 AOV 节点 (仅当源是顶层AOV时)
                        if not is_group_source:
                            target_aov_node = self.add_single_aov_node(target_node_tree, self.aov_name)
                            if target_aov_node:
                                nodes_added_count += 1
                            else:
                                self.report({'WARNING'}, f"材质 '{target_mat.name}': 无法创建目标 AOV 节点。")
                                continue # 跳过此材质
                            # 注意：不再需要清空连接，因为是新节点
                            
                        # 执行复制
                        copied_nodes_map, output_socket_for_target_aov, target_aov_input_name = \
                            self.recursive_copy_network(target_node_tree, source_node, not is_group_source)

                        if not copied_nodes_map:
                            self.report({'ERROR'}, f"材质 '{target_mat.name}': 递归复制节点网络失败。")
                            # 如果复制失败，移除刚才可能创建的AOV节点
                            if target_aov_node:
                                try: target_node_tree.nodes.remove(target_aov_node)
                                except ReferenceError: pass # Ignore if already removed
                                nodes_added_count -= 1
                            continue # 跳过此材质
                        # --- Add check for output socket --- #
                        elif not is_group_source and not output_socket_for_target_aov:
                            self.report({'ERROR'}, f"材质 '{target_mat.name}': 复制顶层AOV网络后未能确定输出连接点。")
                            if target_aov_node:
                                try: target_node_tree.nodes.remove(target_aov_node)
                                except ReferenceError: pass
                                nodes_added_count -= 1
                            continue # 跳过此材质
                        else:
                            pass

                        current_copied_count = len(copied_nodes_map)
                        copied_node_count += current_copied_count # 累加复制的总数
                        # self.report({'INFO'}, f"材质 '{target_mat.name}': 成功复制 {current_copied_count} 个节点。") # 减少日志刷屏

                        # --- 建立最终连接 (仅当源是顶层AOV时) --- 
                        if not is_group_source:
                            if target_aov_node and output_socket_for_target_aov and target_aov_input_name:
                                try:
                                    target_input_socket = target_aov_node.inputs[target_aov_input_name]
                                    target_node_tree.links.new(output_socket_for_target_aov, target_input_socket)
                                    connections_made_count += 1
                                except KeyError:
                                    self.report({'WARNING'}, f"材质 '{target_mat.name}': 无法在AOV找到输入 '{target_aov_input_name}'.")
                                except Exception as e:
                                    self.report({'WARNING'}, f"材质 '{target_mat.name}': 连接出错: {e}")
                            else:
                                self.report({'WARNING'}, f"材质 '{target_mat.name}': 缺少连接信息，无法建立连接。")
                        # --- 最终连接结束 --- 

                    else:
                         # --- 情况2: 源未连接 (仅复制源节点本身或添加AOV) --- #
                         # 检查目标是否已存在同类节点 (理论上 existing_aov_found 已处理顶层AOV)
                         target_exists = False
                         if is_group_source:
                             target_exists = any(n.type == 'GROUP' and n.node_tree == source_node.node_tree for n in target_node_tree.nodes)
                         else: # Source is top-level AOV
                              target_exists = existing_aov_found # Reuse previous check

                         if not target_exists:
                             if is_group_source:
                                  copied_node = self.copy_single_node(target_node_tree, source_node)
                                  if copied_node:
                                       copied_node_count += 1
                                       # 定位逻辑
                                       output_node = next((n for n in target_node_tree.nodes if n.bl_idname == 'ShaderNodeOutputMaterial'), None)
                                       if output_node:
                                            copied_node.location = (output_node.location.x - copied_node.width - 50, output_node.location.y)
                                       else:
                                            copied_node.location = (0,0)
                             else: # Source is top-level AOV
                                 # 使用辅助函数添加和定位
                                 added_node = self.add_single_aov_node(target_node_tree, self.aov_name)
                                 if added_node: nodes_added_count += 1
            # --- 循环结束 --- 

            # --- 最终报告 --- # 
            report_message = f"操作完成。处理材质: {len(materials_processed)}。"
            if skipped_count > 0:
                 report_message += f" 跳过已存在AOV的材质: {skipped_count}。"
                 
            if is_connected_source:
                 if not is_group_source:
                      report_message += f" 创建新AOV: {nodes_added_count}, 复制节点: {copied_node_count}, 建立连接: {connections_made_count}"
                 else:
                      report_message += f" 复制节点组及上游 (复制节点: {copied_node_count})"
            else: # Source was not connected
                 if is_group_source:
                      report_message += f" 添加/复制节点组实例: {copied_node_count}"
                 else:
                      report_message += f" 添加顶层AOV节点: {nodes_added_count}"
            self.report({'INFO'}, report_message)

            # Sync if anything changed
            if nodes_added_count > 0 or connections_made_count > 0 or copied_node_count > 0:
                 bpy.ops.render.sync_aovs('INVOKE_DEFAULT')
            # --- 报告结束 --- # 

        return {'FINISHED'}

    def find_source_aov_networks(self, context, aov_name, exclude_material_names=None):
        """
        查找场景中所有材质里，名称匹配的AOV节点，并记录其类型和连接状态。
        # 移除 exclude_material_names 功能描述，虽然参数保留以防万一，但不再由 assign 调用
        查找优先级: 1. 顶层已连接 -> 2. 组内 -> 3. 顶层未连接
        返回: candidates = {material: {'node': source_node, 'is_group': bool, 'is_connected': bool}}
        """
        if exclude_material_names is None:
            exclude_material_names = set()
            
        candidates = {}
        found_sources = {}

        # 查找所有可能的源
        for mat in bpy.data.materials:
            # --- 不再需要排除逻辑 --- #
            # if mat.name in exclude_material_names:
            #      continue
                 
            if not mat.use_nodes or not mat.node_tree: continue

            found_in_mat = False
            # 1. 查找顶层AOV (已连接 + 未连接)
            for node in mat.node_tree.nodes:
                if node.type == 'OUTPUT_AOV' and node.aov_name == aov_name:
                    is_connected = False
                    if ('Color' in node.inputs and node.inputs['Color'].is_linked) or \
                       ('Value' in node.inputs and node.inputs['Value'].is_linked):
                        is_connected = True
                    # 记录优先级：已连接(1) > 组(2) > 未连接(3)
                    found_sources[mat] = {'node': node, 'is_group': False, 'is_connected': is_connected, 'priority': 1 if is_connected else 3}
                    found_in_mat = True
                    break # 一个材质只找一个顶层AOV
            
            if found_in_mat: continue # 如果找到顶层AOV，不再检查此材质的组

            # 2. 查找节点组内部AOV
            for node in mat.node_tree.nodes:
                 if node.type == 'GROUP' and node.node_tree:
                     for inner_node in node.node_tree.nodes:
                         if inner_node.type == 'OUTPUT_AOV' and inner_node.aov_name == aov_name:
                             # 检查顶层Group实例是否有任何输入连接
                             group_is_connected = any(inp.is_linked for inp in node.inputs)
                             # 组内AOV的优先级为 2
                             found_sources[mat] = {'node': node, 'is_group': True, 'is_connected': group_is_connected, 'priority': 2}
                             found_in_mat = True
                             break # 找到组内AOV，停止搜索此组
                     if found_in_mat: break # 找到组内AOV，停止搜索此材质的其他组

        if not found_sources:
            return {}

        # 按优先级选择最佳源 (1 > 2 > 3)
        best_priority = min(info['priority'] for info in found_sources.values())
        
        # 保留所有具有最佳优先级的候选者
        candidates = {mat: info for mat, info in found_sources.items() if info['priority'] == best_priority}

        return candidates

    def recursive_copy_network(self, target_node_tree, source_top_level_node, is_source_aov_node):
        """
        递归复制给定的顶层节点及其上游网络。
        返回: (copied_nodes_map, output_socket_for_target_aov, target_aov_input_name)
            - copied_nodes_map: {original_node: copied_node}
            - output_socket_for_target_aov: 如果源是顶层AOV，则为连接到目标AOV的输出socket；否则为None
            - target_aov_input_name: 如果源是顶层AOV，则为目标AOV的输入socket名 ('Color'/'Value'); 否则为None
        """
        copied_nodes_map = {}
        nodes_to_process = []
        processed_nodes = set()
        output_socket_for_target_aov = None
        target_aov_input_name = None
        start_node = None
        start_socket_identifier = None

        # 确定递归起点和连接信息
        if is_source_aov_node:
            source_input_socket = None
            if 'Color' in source_top_level_node.inputs and source_top_level_node.inputs['Color'].is_linked:
                source_input_socket = source_top_level_node.inputs['Color']
                target_aov_input_name = 'Color'
            elif 'Value' in source_top_level_node.inputs and source_top_level_node.inputs['Value'].is_linked:
                source_input_socket = source_top_level_node.inputs['Value']
                target_aov_input_name = 'Value'
            
            if not source_input_socket or not source_input_socket.links:
                 # 这个检查理论上不应触发，因为find_source_aov_networks已保证有连接
                 self.report({'ERROR'}, f"源AOV节点 '{source_top_level_node.name}' 输入连接丢失?" )
                 return {}, None, None
            
            link = source_input_socket.links[0]
            start_node = link.from_node
            start_socket_identifier = link.from_socket.identifier
            nodes_to_process.append(start_node) # 从上游节点开始递归
        else:
            # 源是节点组，直接从该节点组开始处理及其上游
            start_node = source_top_level_node
            nodes_to_process.append(start_node)

        source_node_tree = source_top_level_node.id_data

        while nodes_to_process:
            original_node = nodes_to_process.pop(0)

            if original_node in processed_nodes:
                continue
            processed_nodes.add(original_node)

            # --- 复制节点 (逻辑不变) ---
            new_node = None
            if original_node.type == 'GROUP':
                new_node = target_node_tree.nodes.new('ShaderNodeGroup')
                new_node.node_tree = original_node.node_tree
                new_node.location = original_node.location
                new_node.width = original_node.width
                new_node.height = original_node.height
                new_node.label = original_node.label
                new_node.mute = original_node.mute
                for i, inp in enumerate(original_node.inputs):
                    if i < len(new_node.inputs):
                        try: new_node.inputs[i].default_value = inp.default_value
                        except AttributeError: pass
            elif original_node.type not in {'OUTPUT_MATERIAL', 'OUTPUT_AOV'}:
                new_node = target_node_tree.nodes.new(original_node.bl_idname)
                new_node.location = original_node.location # Copy location first

                # --- 使用 RNA 属性进行更安全的复制 --- #
                for prop_id in original_node.bl_rna.properties.keys():
                    # 跳过只读、不可设置或内部属性，以及已处理的属性
                    if prop_id in ['rna_type', 'name', 'label', 'inputs', 'outputs', 'internal_links', 'parent', 'dimensions', 'location', 'width', 'height', 'select', 'use_custom_color', 'color']:
                         continue

                    prop_rna = original_node.bl_rna.properties.get(prop_id)
                    if not prop_rna or prop_rna.is_readonly:
                        continue

                    # 检查新节点是否也有此属性
                    if hasattr(new_node, prop_id):
                        try:
                            original_value = getattr(original_node, prop_id)
                            # 直接尝试设置属性值
                            setattr(new_node, prop_id, original_value)
                            # print(f"DEBUG: Copied {prop_id} = {original_value} from {original_node.name} to {new_node.name}") # 可选的详细日志
                        except AttributeError as e:
                            pass
                        except Exception as e:
                            # 报告其他错误
                            print(f"ERROR Copying Property: Failed to copy {prop_id} from {original_node.name} to {new_node.name}. Error: {e}")
                            # 可以在这里添加 self.report({'WARNING'}, ...) 如果需要UI提示
                # --- RNA 属性复制结束 --- #

                # --- 显式复制一些常用属性以确保一致性 --- #
                if hasattr(original_node, 'label') and hasattr(new_node, 'label'):
                    new_node.label = original_node.label
                if hasattr(original_node, 'mute') and hasattr(new_node, 'mute'):
                    new_node.mute = original_node.mute
                if hasattr(original_node, 'width') and hasattr(new_node, 'width'):
                    new_node.width = original_node.width
                # 高度通常会自动调整，或者复制可能导致显示问题，暂时跳过
                # if hasattr(original_node, 'height') and hasattr(new_node, 'height'):
                #    new_node.height = original_node.height
                # --- 常用属性复制结束 --- #

                # --- 新增：复制未连接输入端口的默认值 --- #
                for i, original_input in enumerate(original_node.inputs):
                    if not original_input.is_linked:
                         # 尝试通过索引和标识符查找新节点上的对应端口
                         new_input = None
                         if i < len(new_node.inputs) and new_node.inputs[i].identifier == original_input.identifier:
                             new_input = new_node.inputs[i]
                         else: # Fallback: search by identifier if index mismatch (less likely)
                             try:
                                 new_input = new_node.inputs[original_input.identifier]
                             except KeyError:
                                 # print(f"DEBUG: Input socket '{original_input.identifier}' not found on new node '{new_node.name}'")
                                 continue # Skip if socket doesn't exist on new node

                         if new_input and hasattr(new_input, 'default_value'): # Make sure the target socket has default_value
                            try:
                                original_default_value = original_input.default_value
                                # Blender often uses sequences for Vector/Color defaults
                                # Directly assigning might work for most types
                                new_input.default_value = original_default_value
                                # print(f"DEBUG: Copied default_value for '{new_input.identifier}' = {original_default_value} on {new_node.name}") # Optional debug
                            except AttributeError as e:
                                pass
                            except Exception as e:
                                print(f"ERROR Copying DefaultValue: Failed for input '{original_input.identifier}' on {new_node.name}. Error: {e}")
                # --- 默认值复制结束 --- #

            # --- 复制结束 --- (旧代码标记，实际复制逻辑已在上面完成)

            if new_node:
                copied_nodes_map[original_node] = new_node
                
                # 如果源是顶层AOV，记录需要连接到目标AOV的那个输出socket
                if is_source_aov_node and original_node == start_node:
                     try:
                         output_socket_for_target_aov = new_node.outputs[start_socket_identifier]
                     except KeyError:
                         # --- Report error if crucial socket not found --- #
                         print(f"ERROR: Cannot find start output socket '{start_socket_identifier}' on copied node '{new_node.name}' in {target_node_tree.name}")
                         self.report({'ERROR'}, f"复制起始节点时无法找到输出端口: '{start_socket_identifier}' on {new_node.name}")
                         return {}, None, None # Fail copy if start socket missing

                # 递归处理上游输入
                for input_socket in original_node.inputs:
                    if input_socket.is_linked:
                        for link in input_socket.links:
                            upstream_node = link.from_node
                            if upstream_node not in processed_nodes and upstream_node not in nodes_to_process:
                                # Don't process the original source AOV node if it's upstream somehow
                                if upstream_node != source_top_level_node:
                                     nodes_to_process.append(upstream_node)
            else:
                 copied_nodes_map[original_node] = None

        # --- 重建连接 (逻辑不变) ---
        for original_node, copied_node in copied_nodes_map.items():
            if not copied_node: continue
            for input_socket in original_node.inputs:
                 if input_socket.is_linked:
                     for link in input_socket.links:
                         original_from_node = link.from_node
                         original_from_socket = link.from_socket
                         # Check if the upstream node was actually copied (it might be source_top_level_node if is_source_aov_node)
                         if original_from_node in copied_nodes_map and copied_nodes_map[original_from_node]:
                             copied_from_node = copied_nodes_map[original_from_node]
                             try:
                                 copied_to_socket = copied_node.inputs[input_socket.identifier]
                                 # --- 修正：使用 original_from_socket.identifier --- #
                                 copied_from_socket = copied_from_node.outputs[original_from_socket.identifier]
                                 target_node_tree.links.new(copied_from_socket, copied_to_socket)
                             except KeyError as e:
                                 # More informative error for missing sockets
                                 # --- Report instead of just printing --- #
                                 print(f"ERROR Link KeyError: Socket '{e}'. {original_from_node.name}.{original_from_socket.name} -> {original_node.name}.{input_socket.name}")
                                 self.report({'WARNING'}, f"重建连接时跳过: 未找到 Socket '{e}'")
                                 # Continue linking other sockets
                             except Exception as e:
                                 # --- Report instead of just printing --- #
                                 print(f"ERROR Link General Error: {e}. While linking {original_from_node.name}.{original_from_socket.name} -> {original_node.name}.{input_socket.name}")
                                 self.report({'WARNING'}, f"重建连接时跳过: 发生错误 {e}")
                                 # Continue linking other sockets
                         # Handle case where input connects directly to the source AOV node (only if source is AOV)
                         elif is_source_aov_node and original_from_node == source_top_level_node:
                              # This scenario shouldn't happen if we start recursion from upstream node?
                              # print(f"Debug: Link from original source AOV detected: {original_node.name}.{input_socket.name}")
                              pass # Cannot link from a node that wasn't copied

        # --- 布局调整 (移动到这里，确保在所有节点和连接创建后运行) ---
        if copied_nodes_map:
            # 简单的相对布局调整: 将复制的节点整体移动到目标 AOV 节点的左侧 (如果源是AOV)
            # 或材质输出节点的左侧
            target_ref_node = None
            if is_source_aov_node:
                 target_ref_node = next((n for n in target_node_tree.nodes if n.type == 'OUTPUT_AOV' and n.aov_name == source_top_level_node.aov_name), None)
            if not target_ref_node:
                 target_ref_node = next((n for n in target_node_tree.nodes if n.bl_idname == 'ShaderNodeOutputMaterial'), None)

            if target_ref_node:
                 # 计算复制节点的边界框
                 min_x = min(n.location.x for n in copied_nodes_map.values() if n) if any(copied_nodes_map.values()) else 0
                 max_y = max(n.location.y + n.height for n in copied_nodes_map.values() if n) if any(copied_nodes_map.values()) else 0
                 min_y = min(n.location.y for n in copied_nodes_map.values() if n) if any(copied_nodes_map.values()) else 0
                 center_y = (max_y + min_y) / 2

                 # 计算目标位置
                 target_x = target_ref_node.location.x - 300 # 间距
                 target_y = target_ref_node.location.y

                 # 计算偏移量
                 offset_x = target_x - min_x
                 offset_y = target_y - center_y # 尝试垂直居中对齐?

                 # 应用偏移
                 for copied_node in copied_nodes_map.values():
                      if copied_node:
                           copied_node.location.x += offset_x
                           copied_node.location.y += offset_y
        # --- 布局调整结束 ---

        return copied_nodes_map, output_socket_for_target_aov, target_aov_input_name

    def copy_single_node(self, target_node_tree, source_node):
        """仅复制单个节点（处理普通节点和组实例）"""
        new_node = None
        if source_node.type == 'GROUP':
            new_node = target_node_tree.nodes.new('ShaderNodeGroup')
            new_node.node_tree = source_node.node_tree
            new_node.location = source_node.location
            new_node.width = source_node.width
            new_node.height = source_node.height
            new_node.label = source_node.label
            new_node.mute = source_node.mute
            for i, inp in enumerate(source_node.inputs):
                 if i < len(new_node.inputs):
                     try: new_node.inputs[i].default_value = inp.default_value
                     except AttributeError: pass
        elif source_node.type not in {'OUTPUT_MATERIAL', 'OUTPUT_AOV'}:
             new_node = target_node_tree.nodes.new(source_node.bl_idname)
             for prop_id in source_node.bl_rna.properties.keys():
                 if prop_id in ['rna_type', 'name', 'label', 'inputs', 'outputs', 'internal_links', 'parent', 'dimensions', 'location', 'width', 'height', 'select', 'use_custom_color', 'color']:
                      continue
                 prop_rna = source_node.bl_rna.properties.get(prop_id)
                 if not prop_rna or prop_rna.is_readonly:
                     continue
                 if hasattr(new_node, prop_id):
                     try:
                         original_value = getattr(source_node, prop_id)
                         setattr(new_node, prop_id, original_value)
                     except (AttributeError, TypeError) as e:
                         pass
             new_node.location = source_node.location
        return new_node
    
    def add_single_aov_node(self, node_tree, aov_name):
        """仅添加一个指定名称的AOV输出节点，并进行定位"""
        aov_node = node_tree.nodes.new('ShaderNodeOutputAOV')
        aov_node.aov_name = aov_name
        # 定位逻辑 (复用原有代码)
        max_x = 0
        output_node = None
        for node in node_tree.nodes:
            if node.location.x > max_x: max_x = node.location.x
            if node.bl_idname == 'ShaderNodeOutputMaterial': output_node = node
        if output_node:
            aov_node.location.x = output_node.location.x + output_node.width + 100
            aov_node.location.y = output_node.location.y
        else:
            aov_node.location.x = max_x + 300
            aov_node.location.y = 0
        return aov_node

class AOV_OT_select_object(Operator):
    """选择包含指定AOV的对象"""
    bl_idname = "render.select_object"
    bl_label = "选择对象"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty(name="对象名称")

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')

        obj = bpy.data.objects.get(self.object_name)
        if obj:
            # Check if object is visible in current view layer before selecting
            if obj.name in context.view_layer.objects:
                 # Ensure object itself isn't hidden in viewport
                 if not obj.hide_get(view_layer=context.view_layer):
                      # Check collection visibility recursively
                      is_visible = True
                      for coll in obj.users_collection:
                           layer_coll = find_layer_collection_recursive(context.view_layer.layer_collection, coll)
                           if layer_coll:
                                current = layer_coll
                                while current:
                                     if current.exclude or current.collection.hide_render or not current.visible_get():
                                          is_visible = False
                                          break
                                     try:
                                         if hasattr(current, 'parent') and current.parent:
                                              current = current.parent
                                              if current == layer_coll: break
                                         else: break
                                     except Exception: break
                                if not is_visible: break
                           else: # Object is in a collection not in this view layer structure
                                is_visible = False
                                break

                      if is_visible:
                           obj.select_set(True)
                           context.view_layer.objects.active = obj
                           if context.active_object and context.active_object.mode != 'OBJECT':
                               bpy.ops.object.mode_set(mode='OBJECT')
                           return {'FINISHED'}
                      else:
                           self.report({'WARNING'}, f"对象 '{self.object_name}' 在当前视图层中不可见 (集合隐藏或排除)")
                           return {'CANCELLED'}
                 else:
                      self.report({'WARNING'}, f"对象 '{self.object_name}' 在当前视图层中被隐藏")
                      return {'CANCELLED'}
            else:
                 self.report({'WARNING'}, f"对象 '{self.object_name}' 不属于当前视图层 '{context.view_layer.name}'")
                 return {'CANCELLED'}
        else:
            self.report({'WARNING'}, f"未找到对象: {self.object_name}")
            return {'CANCELLED'} 
