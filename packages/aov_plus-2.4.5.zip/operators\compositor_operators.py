import os
import re

import bpy
from bpy.types import Operator

from .selected_render import COMPOSITOR_OT_render_selected_view_layers


SOCKET_ITEM_TYPES = {"RGBA": "RGBA", "VECTOR": "VECTOR", "VALUE": "FLOAT", "INT": "FLOAT"}
DATA_SOCKETS = {"Depth", "Z", "Mist", "Normal", "Position", "Vector"}
NODE_NAMES = {
    ("image", False): "FileOutput_{layer}",
    ("image", True): "FileOutput_{layer}_Multi",
    ("data", False): "DataOutput_{layer}",
    ("data", True): "DataOutput_{layer}_Multi",
}


def is_data_socket(socket):
    return (
        socket.type in {"VECTOR", "VALUE"}
        or socket.name in DATA_SOCKETS
        or socket.name.startswith("Crypto")
    )


def current_tree(context):
    scene = context.scene
    effects = getattr(scene, "compositor_effects", None)
    if effects is not None:
        effect = effects.active
        return effect.node_group if effect and effect.node_group else None
    return getattr(scene, "compositing_node_group", None)


def new_compositor_tree(name):
    tree = bpy.data.node_groups.new(name, "CompositorNodeTree")
    tree.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")
    return tree


def ensure_target(context):
    """Return the current scene's compositor tree, creating an effect if needed."""
    scene = context.scene
    effects = getattr(scene, "compositor_effects", None)
    if effects is None:
        tree = getattr(scene, "compositing_node_group", None)
        if tree is None:
            raise ValueError("当前场景没有合成节点树")
        return tree
    effect = effects.active
    if effect is None:
        effect = effects.new(name="Scene Effect")
        effects.active = effect
    if effect.node_group is None:
        effect.node_group = new_compositor_tree(f"{scene.name} Compositor")
    return effect.node_group


def group_output(tree):
    return next((node for node in tree.nodes if node.type == "GROUP_OUTPUT" and node.is_active_output), None)


def ensure_group_output(tree):
    output = group_output(tree)
    if output is None:
        output = tree.nodes.new("NodeGroupOutput")
        output.location = (400, 0)
    if not any(item.in_out == "OUTPUT" for item in tree.interface.items_tree if item.item_type == "SOCKET"):
        tree.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")
    return output


def ensure_render_layer(context, tree):
    """Return the render-layer node for the active view layer, adding one if missing."""
    scene = context.scene
    layer = context.view_layer.name
    node = next(
        (item for item in tree.nodes
         if item.type == "R_LAYERS" and item.scene == scene and item.layer == layer),
        None,
    )
    if node is not None:
        return node, False
    node = tree.nodes.new("CompositorNodeRLayers")
    node.scene = scene
    node.layer = layer
    node.location = (-300, -40 * len(tree.nodes))
    output = ensure_group_output(tree)
    if output.inputs and not output.inputs[0].is_linked:
        tree.links.new(node.outputs["Image"], output.inputs[0])
    return node, True


def output_is_multilayer(node):
    return (
        getattr(node.format, "media_type", None) == "MULTI_LAYER_IMAGE"
        or node.format.file_format == "OPEN_EXR_MULTILAYER"
    )


def set_file_output_location(node, directory, file_name):
    if hasattr(node, "directory") and hasattr(node, "file_name"):
        node.directory = directory
        node.file_name = file_name
        return
    if not directory.endswith(("/", "\\")):
        directory += "/"
    node.base_path = directory + file_name


def get_output_base_directory(context):
    settings = context.scene.auto_rename_settings
    if getattr(settings, "use_custom_output_directory", False) and settings.custom_output_directory:
        base = settings.custom_output_directory
    else:
        base = "//renders/"
    return base if base.endswith(("/", "\\")) else base + "/"


def build_output_directory(context, scene_name, layer_name, subfolder=""):
    path = f"{get_output_base_directory(context)}{scene_name}/{layer_name}/"
    return f"{path}{subfolder}/" if subfolder else path


def prefix_text(settings, scene_name, layer_name):
    parts = []
    if settings.use_scene_prefix:
        parts.append(scene_name)
    if settings.use_layer_prefix:
        parts.append(layer_name)
    return "_".join(parts)


def computed_file_name(node, settings, scene_name, layer_name, multilayer):
    """Prefix for the current settings, keeping any frame template already set."""
    prefix = prefix_text(settings, scene_name, layer_name)
    current = node.file_name or ""
    match = re.search(r"#+", current)
    if match:
        return (prefix + "_" if prefix else "") + current[match.start():]
    if any("#" in item.name for item in node.file_output_items):
        return prefix + "_" if prefix else ""
    if multilayer:
        return f"{prefix}_####" if prefix else "####"
    return f"{prefix}_" if prefix else ""


def apply_file_name(node, settings, scene_name, layer_name, multilayer):
    node.file_name = computed_file_name(node, settings, scene_name, layer_name, multilayer)


def channel_name(socket, multilayer):
    return socket.name if multilayer else f"{socket.name}_"


def linked_index(node, socket):
    for index, inlet in enumerate(node.inputs):
        if inlet.is_linked and any(link.from_socket == socket for link in inlet.links):
            return index
    return None


def selected_nodes(context, tree):
    """Node-editor selection, readable in background mode as well."""
    try:
        return list(context.selected_nodes)
    except AttributeError:
        return [node for node in tree.nodes if node.select]


def connect_channel(node, tree, socket, multilayer):
    index = linked_index(node, socket)
    if index is not None:
        return index
    item = node.file_output_items.new(SOCKET_ITEM_TYPES.get(socket.type, "RGBA"), channel_name(socket, multilayer))
    if item.socket_type == "VECTOR":
        item.vector_socket_dimensions = 4
    elif item.socket_type == "FLOAT":
        item.vector_socket_dimensions = 1
    tree.links.new(socket, node.inputs[len(node.file_output_items) - 1])
    return len(node.file_output_items) - 1


def trace_to_render_layer_socket(input_socket, visited=None):
    if visited is None:
        visited = set()
    if input_socket in visited or not input_socket.links:
        return None
    visited.add(input_socket)
    from_socket = input_socket.links[0].from_socket
    from_node = from_socket.node
    if from_node.type == "R_LAYERS":
        return from_socket
    if from_node.type == "GROUP" and from_node.node_tree:
        output = group_output(from_node.node_tree)
        inlet = next((item for item in output.inputs if item.identifier == from_socket.identifier), None) if output else None
        return trace_to_render_layer_socket(inlet, visited) if inlet else None
    for inlet in from_node.inputs:
        if inlet.name == from_socket.name or not from_node.inputs:
            return trace_to_render_layer_socket(inlet, visited)
    return trace_to_render_layer_socket(from_node.inputs[0], visited) if from_node.inputs else None


def destination_key(node, directory=None, file_name=None):
    if node is not None:
        directory = node.directory if directory is None else directory
        file_name = node.file_name if file_name is None else file_name
    path = bpy.path.abspath(directory) if directory else ""
    return os.path.normcase(os.path.normpath(path)), os.path.normcase(file_name)


def validate_destinations(entries):
    seen = {}
    for label, directory, file_name, mute in entries:
        if mute:
            continue
        key = destination_key(None, directory, file_name)
        if key in seen:
            raise ValueError(
                f"输出路径冲突，两个节点会写同一个文件：{seen[key]}；{label}"
            )
        seen[key] = label


def scene_output_nodes(context):
    """Every render-enabled output node in the scene, across effects."""
    nodes = []
    effects = getattr(context.scene, "compositor_effects", None)
    if effects is None:
        tree = getattr(context.scene, "compositing_node_group", None)
        trees = [tree] if tree else []
    else:
        trees = [effect.node_group for effect in effects if effect.node_group and effect.enable_for_render]
    for tree in trees:
        nodes.extend(node for node in tree.nodes if node.type == "OUTPUT_FILE")
    return nodes


def source_context(socket):
    node = socket.node
    return node.scene.name, node.layer


def find_output_node(tree, layer, role, multilayer):
    names = {
        NODE_NAMES[(role, False)].format(layer=layer),
        NODE_NAMES[(role, True)].format(layer=layer),
    }
    for node in tree.nodes:
        if node.type == "OUTPUT_FILE" and node.name in names and output_is_multilayer(node) == multilayer:
            return node
    return tree.nodes.get(NODE_NAMES[(role, multilayer)].format(layer=layer))


def create_output_node(tree, layer, role, multilayer, location):
    node = tree.nodes.new("CompositorNodeOutputFile")
    node.format.media_type = "MULTI_LAYER_IMAGE" if multilayer else "IMAGE"
    node.format.file_format = "OPEN_EXR_MULTILAYER" if multilayer else "OPEN_EXR"
    node.name = NODE_NAMES[(role, multilayer)].format(layer=layer)
    node.label = f"{layer}{'数据' if role == 'data' else '图像'}输出" + (" (多层)" if multilayer else "")
    node.location = location
    return node


def configure_output_node(context, node, role, multilayer):
    settings = context.scene.auto_rename_settings
    node.format.media_type = "MULTI_LAYER_IMAGE" if multilayer else "IMAGE"
    node.format.file_format = "OPEN_EXR_MULTILAYER" if multilayer else "OPEN_EXR"
    try:
        if role == "data":
            node.format.color_depth = "32"
            node.format.exr_codec = "ZIP"
            if not multilayer:
                node.format.color_mode = "RGBA"
        else:
            node.format.color_depth = settings.exr_color_depth
            node.format.color_mode = settings.exr_color_mode
            node.format.exr_codec = "DWAA"
    except (AttributeError, TypeError):
        pass


def connection_plan(context, tree, targets, multilayer, destructive):
    """Collect per-layer work before touching the tree."""
    settings = context.scene.auto_rename_settings
    separate = settings.separate_data_light_outputs
    grouped = {}
    for render_layer in targets:
        layer = render_layer.layer
        for socket in render_layer.outputs:
            if not socket.enabled or socket.name == "Alpha":
                continue
            if not destructive and linked_index_of_output(tree, socket, multilayer) is not None:
                continue
            role = "data" if separate and is_data_socket(socket) else "image"
            grouped.setdefault((layer, role), []).append(socket)
    return [
        (layer, role, sockets, find_output_node(tree, layer, role, multilayer))
        for (layer, role), sockets in grouped.items()
    ]


def linked_index_of_output(tree, socket, multilayer):
    for node in tree.nodes:
        if node.type != "OUTPUT_FILE" or node.mute or output_is_multilayer(node) != multilayer:
            continue
        index = linked_index(node, socket)
        if index is not None:
            return index
    return None


def validate_plan(plan, multilayer):
    for layer, role, sockets, node in plan:
        if node is None:
            continue
        wanted = [channel_name(socket, multilayer) for socket in sockets]
        if len(wanted) != len(set(wanted)):
            raise ValueError(f"层 {layer} 有同名通道，无法无损区分：{'、'.join(wanted)}")
        keep = kept_item_names(node, sockets)
        clash = sorted(set(wanted) & set(keep))
        if clash:
            raise ValueError(f"输出节点 {node.name} 已有同名通道，无法无损改名：{'、'.join(clash)}")


def kept_item_names(node, sockets):
    """Names of items that stay as they are, i.e. not fed by the sockets being connected."""
    keep = []
    for index, item in enumerate(node.file_output_items):
        if index < len(node.inputs) and node.inputs[index].is_linked:
            sources = [link.from_socket for link in node.inputs[index].links]
            if any(source in sockets for source in sources):
                continue
        keep.append(item.name)
    return keep


class COMPOSITOR_OT_auto_connect_outputs(Operator):
    """为渲染层输出创建并连接文件输出节点"""
    bl_idname = "compositor.auto_connect_outputs"
    bl_label = "自动连接输出节点"
    bl_description = "为尚未连接到文件输出节点的渲染层输出创建连接 (保留现有连接)"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        settings = context.scene.auto_rename_settings
        try:
            tree = ensure_target(context)
            added_layer = False
            if not any(node.type == "R_LAYERS" for node in tree.nodes):
                ensure_render_layer(context, tree)
                added_layer = True
            destructive = settings.destructive_connect_mode
            if destructive:
                for node in [item for item in tree.nodes if item.type == "OUTPUT_FILE"]:
                    tree.nodes.remove(node)
                targets = [item for item in tree.nodes if item.type == "R_LAYERS"]
            else:
                selection = selected_nodes(context, tree)
                selected_layers = [item for item in selection if item.type == "R_LAYERS"]
                selected_outputs = [item for item in selection if item.type == "OUTPUT_FILE"]
                if selected_layers:
                    targets = selected_layers
                elif selected_outputs:
                    self.report({'WARNING'}, "非破坏性模式：选中文件输出节点时，不执行自动连接。请取消选择或选择渲染层节点。")
                    return {'CANCELLED'}
                else:
                    targets = [item for item in tree.nodes if item.type == "R_LAYERS"]
            if not targets:
                self.report({'INFO'}, "未找到需要处理的渲染层节点")
                return {'FINISHED'}

            multilayer = settings.use_multilayer_exr
            plan = connection_plan(context, tree, targets, multilayer, destructive)
            validate_plan(plan, multilayer)
            projected = {}
            planned_new = []
            for layer, role, sockets, node in plan:
                scene_name, layer_name = source_context(sockets[0])
                subfolder = "data" if role == "data" and settings.separate_data_light_outputs else (
                    "images" if settings.separate_data_light_outputs else ""
                )
                directory = build_output_directory(context, scene_name, layer_name, subfolder)
                file_name = computed_file_name(node, settings, scene_name, layer_name, multilayer) if node else (
                    f"{prefix_text(settings, scene_name, layer_name)}_####" if multilayer
                    else f"{prefix_text(settings, scene_name, layer_name)}_####_"
                )
                if node is not None:
                    projected[id(node)] = (directory, file_name)
                else:
                    planned_new.append((NODE_NAMES[(role, multilayer)].format(layer=layer_name), directory, file_name))
            destinations = [
                (item.name, *projected.get(id(item), (item.directory, item.file_name)), item.mute)
                for item in scene_output_nodes(context)
            ]
            destinations.extend((label, directory, file_name, False) for label, directory, file_name in planned_new)
            validate_destinations(destinations)
            created = 0
            connected = 0
            for layer, role, sockets, node in plan:
                scene_name, layer_name = source_context(sockets[0])
                if node is None:
                    offset = 120 if role == "data" else 0
                    render_layer = sockets[0].node
                    node = create_output_node(
                        tree, layer_name, role, multilayer,
                        (render_layer.location.x + render_layer.width + 220, render_layer.location.y + offset),
                    )
                    created += 1
                configure_output_node(context, node, role, multilayer)
                subfolder = "data" if role == "data" and settings.separate_data_light_outputs else (
                    "images" if settings.separate_data_light_outputs else ""
                )
                set_file_output_location(
                    node,
                    build_output_directory(context, scene_name, layer_name, subfolder),
                    node.file_name,
                )
                apply_file_name(node, settings, scene_name, layer_name, multilayer)
                for socket in sockets:
                    connect_channel(node, tree, socket, multilayer)
                    connected += 1
                node.select = False

            for node in tree.nodes:
                node.select = node.type == "R_LAYERS" and node in targets
            context.view_layer.update()
            parts = []
            if connected:
                parts.append(f"连接了 {connected} 个通道")
            if created:
                parts.append(f"创建了 {created} 个新文件输出节点")
            if added_layer:
                parts.append("添加了当前视图层")
            self.report({'INFO'}, "处理完成: " + "，".join(parts) if parts else "检查完成，未执行连接或创建操作")
            if added_layer:
                self.report({'INFO'}, "已选中新建的渲染层，请切换到「单帧」并点「渲染当前帧」验证输出。")
            return {'FINISHED'}
        except (AttributeError, OSError, ValueError, RuntimeError) as error:
            self.report({'ERROR'}, f"自动连接操作失败: {error}")
            return {'CANCELLED'}


class COMPOSITOR_OT_auto_rename_outputs(Operator):
    """批量处理输出文件名"""
    bl_idname = "compositor.auto_rename_outputs"
    bl_label = "批量处理输出文件名"
    bl_description = "根据连接的渲染层输出批量处理文件输出接口名称和路径"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        tree = current_tree(context)
        if tree is None:
            self.report({'WARNING'}, "没有活动的合成节点树")
            return {'CANCELLED'}
        settings = context.scene.auto_rename_settings
        nodes = [item for item in selected_nodes(context, tree) if item.type == "OUTPUT_FILE"]
        if not nodes:
            nodes = [item for item in tree.nodes if item.type == "OUTPUT_FILE"]
        if not nodes:
            self.report({'INFO'}, "未找到需要处理的文件输出节点")
            return {'FINISHED'}
        try:
            plan = rename_plan(nodes)
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        renamed = 0
        updated = 0
        ambiguous = []
        targets = {}
        for node, entries, contexts in plan:
            if len(contexts) != 1:
                targets[id(node)] = (node.directory, node.file_name)
                continue
            scene_name, layer_name = next(iter(contexts))
            subfolder = ""
            if settings.separate_data_light_outputs:
                subfolder = "data" if node.name.startswith("DataOutput_") else "images"
            directory = build_output_directory(context, scene_name, layer_name, subfolder)
            targets[id(node)] = (
                directory,
                computed_file_name(node, settings, scene_name, layer_name, output_is_multilayer(node)),
            )
        try:
            validate_destinations([
                (item.name, *targets.get(id(item), (item.directory, item.file_name)), item.mute)
                for item in scene_output_nodes(context)
            ])
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        for node, entries, contexts in plan:
            multilayer = output_is_multilayer(node)
            for index, socket in entries:
                name = channel_name(socket, multilayer)
                if node.file_output_items[index].name != name:
                    node.file_output_items[index].name = name
                    renamed += 1
                if node.inputs[index].name != name:
                    node.inputs[index].name = name
            if len(contexts) != 1:
                ambiguous.append(node.name)
                continue
            directory, file_name = targets[id(node)]
            previous = (node.directory, node.file_name)
            set_file_output_location(node, directory, file_name)
            if (node.directory, node.file_name) != previous:
                updated += 1
        parts = []
        if renamed:
            parts.append(f"重命名了 {renamed} 个通道")
        if updated:
            parts.append(f"更新了 {updated} 个输出路径")
        self.report({'INFO'}, "处理完成: " + "，".join(parts) if parts else "没有需要更新的通道或路径")
        if ambiguous:
            self.report({'WARNING'}, f"这些输出混合了多个渲染层，路径保持不变：{'、'.join(ambiguous)}")
        return {'FINISHED'}


def rename_plan(nodes):
    plan = []
    for node in nodes:
        entries = []
        contexts = set()
        for index, inlet in enumerate(node.inputs):
            if index >= len(node.file_output_items) or not inlet.is_linked:
                continue
            socket = trace_to_render_layer_socket(inlet)
            if socket is None:
                continue
            entries.append((index, socket))
            contexts.add(source_context(socket))
        if not entries:
            continue
        multilayer = output_is_multilayer(node)
        wanted = [channel_name(socket, multilayer) for _, socket in entries]
        if len(wanted) != len(set(wanted)):
            raise ValueError(f"节点 {node.name} 有同名通道，无法无损区分：{'、'.join(wanted)}")
        keep = kept_item_names(node, [socket for _, socket in entries])
        clash = sorted(set(wanted) & set(keep))
        if clash:
            raise ValueError(f"节点 {node.name} 已有同名通道，无法无损改名：{'、'.join(clash)}")
        plan.append((node, entries, contexts))
    return plan
