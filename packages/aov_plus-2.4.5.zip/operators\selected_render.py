from dataclasses import dataclass, field
import os
from pathlib import Path
import re
import shutil
import tempfile

import bpy
from bpy.types import Operator


_ACTIVE_RENDER = None
_WRITTEN_FILES = {}
_FRAME_FIELD = re.compile(r"#+")
_PATH_FIELD = re.compile(r"\{([^{}:]+)(?::([#.]+))?\}")
_EXTENSIONS = {
    "AVIF": ".avif", "BMP": ".bmp", "CINEON": ".cin", "DPX": ".dpx",
    "HDR": ".hdr", "IRIS": ".rgb", "JPEG": ".jpg", "OPEN_EXR": ".exr",
    "OPEN_EXR_MULTILAYER": ".exr", "PNG": ".png", "TARGA": ".tga",
    "TARGA_RAW": ".tga", "TIFF": ".tif", "WEBP": ".webp",
}
_ALTERNATE_EXTENSIONS = {
    "IRIS": (".sgi", ".bw", ".rgba"), "JPEG": (".jpeg",), "TIFF": (".tiff",),
}


def incoming(socket):
    return [
        link.from_socket
        for link in socket.links
        if link.is_valid and not link.is_muted and link.from_socket.enabled
    ] if socket.enabled else []


def group_output(tree):
    return next(
        (node for node in tree.nodes if node.type == "GROUP_OUTPUT" and node.is_active_output),
        None,
    )


def matching_socket(sockets, identifier):
    return next((socket for socket in sockets if socket.identifier == identifier), None)


def first_interface_socket(tree, direction):
    return next(
        (item for item in tree.interface.items_tree if item.item_type == "SOCKET" and item.in_out == direction),
        None,
    )


@dataclass
class TreeScope:
    tree: object
    path: tuple
    parent: object = None
    instance: object = None
    previous: frozenset = frozenset()
    effect_pointer: int | None = None
    children: dict = field(default_factory=dict)
    dependencies: dict = field(default_factory=dict)

    def child(self, node):
        if node.name not in self.children:
            self.children[node.name] = TreeScope(node.node_tree, (*self.path, node.name), self, node)
        return self.children[node.name]

    def trace_input(self, socket, scene):
        return frozenset().union(*(self.trace_output(source, scene) for source in incoming(socket)))

    def trace_output(self, socket, scene):
        if socket in self.dependencies:
            return self.dependencies[socket]
        self.dependencies[socket] = frozenset()
        node = socket.node
        if node.mute:
            inputs = [link.from_socket for link in node.internal_links if link.to_socket == socket]
        elif node.type == "R_LAYERS":
            if node.layer:
                self.dependencies[socket] = frozenset({(node.scene or scene, node.layer)})
            return self.dependencies[socket]
        elif node.type == "GROUP_INPUT":
            if self.parent:
                inlet = matching_socket(self.instance.inputs, socket.identifier)
                self.dependencies[socket] = self.parent.trace_input(inlet, scene) if inlet else frozenset()
            else:
                interface = first_interface_socket(self.tree, "INPUT")
                if interface and socket.identifier == interface.identifier:
                    self.dependencies[socket] = self.previous
            return self.dependencies[socket]
        elif node.type == "GROUP" and node.node_tree:
            outlet = group_output(node.node_tree)
            inlet = matching_socket(outlet.inputs, socket.identifier) if outlet else None
            if inlet:
                self.dependencies[socket] = self.child(node).trace_input(inlet, scene)
            return self.dependencies[socket]
        else:
            inputs = node.inputs
        self.dependencies[socket] = frozenset().union(*(self.trace_input(item, scene) for item in inputs))
        return self.dependencies[socket]

    def file_nodes(self):
        for node in self.tree.nodes:
            if node.type == "OUTPUT_FILE":
                yield self, node
            elif node.type == "GROUP" and node.node_tree and not node.mute:
                yield from self.child(node).file_nodes()

    def final_input(self):
        output = group_output(self.tree)
        if output:
            interface = first_interface_socket(self.tree, "OUTPUT")
            socket = matching_socket(output.inputs, interface.identifier) if interface else None
            return socket if socket and socket.type == "RGBA" and not output.mute else None
        return next(
            (node.inputs[0] for node in self.tree.nodes if node.type == "COMPOSITE" and not node.mute),
            None,
        )


@dataclass
class OutputNode:
    scope: TreeScope
    node: object
    indices: tuple
    number: int

    @property
    def key(self):
        return (*self.scope.path, self.node.name)

    def ownership(self, index):
        ancestry = []
        scope = self.scope
        while scope:
            instance = scope.instance.as_pointer() if scope.instance else scope.effect_pointer
            ancestry.append((scope.tree.session_uid, instance))
            scope = scope.parent
        indices = self.indices if index is None else (index,)
        sockets = tuple(
            (socket.identifier, socket.as_pointer(), tuple(source.as_pointer() for source in incoming(socket)))
            for socket in (self.node.inputs[item] for item in indices)
        )
        return self.key, tuple(ancestry), self.node.as_pointer(), sockets

    @property
    def multilayer(self):
        return self.node.format.file_format == "OPEN_EXR_MULTILAYER"

    def entries(self):
        if self.multilayer:
            yield None, "", self.node.format
        else:
            for index in self.indices:
                item = self.node.file_output_items[index]
                yield index, item.name, item.format if item.override_node_format else self.node.format


@dataclass
class OutputFile:
    destination: Path
    canonical: Path
    relative_stage: Path
    owner: tuple
    existing: tuple | None
    same_frame: bool


def path_key(path):
    return os.path.normcase(os.path.realpath(path))


def file_identity(path):
    try:
        stat = path.lstat()
    except FileNotFoundError:
        return None
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"输出目标不是普通文件：{path}")
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns


def validate_output_paths(files):
    destinations = {}
    directories = {}
    for output in files:
        path = output.destination
        canonical = Path(path_key(path))
        if canonical != output.canonical:
            raise ValueError(f"输出路径在确认后发生变化，现有文件已保留：{path}")
        for parent in canonical.parents:
            if parent in destinations:
                other = destinations[parent]
                raise ValueError(f"输出路径冲突，一个文件也是另一个输出的目录：{other}；{path}")
            directories.setdefault(parent, path)
        if canonical in destinations:
            raise ValueError(f"输出路径冲突，现有文件已保留：{destinations[canonical]}；{path}")
        if canonical in directories:
            raise ValueError(f"输出路径冲突，一个文件也是另一个输出的目录：{path}；{directories[canonical]}")
        destinations[canonical] = path
    for directory, child in directories.items():
        if directory.exists() and not directory.is_dir():
            raise ValueError(f"输出目录已被文件占用，现有文件已保留：{directory}；{child}")


def frame_name(name, frame):
    head, tail = os.path.split(name)
    fields = list(_FRAME_FIELD.finditer(tail))
    if not fields:
        return os.path.join(head, tail + f"{frame:04d}")
    last = fields[-1]
    digits = str(abs(frame)).zfill(min(16, len(last[0])))
    if frame < 0:
        digits = "-" + digits
    return os.path.join(head, tail[:last.start()] + digits + tail[last.end():])


def template_variables(scene, node):
    filename = bpy.data.filepath
    library = node.id_data.library
    library_file = bpy.path.abspath(library.filepath) if library else filename
    settings = scene.render
    values = {
        "blend_name": Path(filename).stem or "Unsaved",
        "blend_dir": os.path.dirname(filename) + os.sep if filename else "./",
        "blend_name_lib": Path(library_file).stem or "Unsaved",
        "blend_dir_lib": os.path.dirname(library_file) + os.sep if library_file else "./",
        "scene_name": scene.name,
        "node_name": node.name,
        "resolution_x": settings.resolution_x * settings.resolution_percentage // 100,
        "resolution_y": settings.resolution_y * settings.resolution_percentage // 100,
        "fps": settings.fps / settings.fps_base,
    }
    if scene.camera:
        values["camera_name"] = scene.camera.name
    project = getattr(bpy.data, "project", None)
    if project:
        values.update(project_name=project.name, project_root=project.root_path)
        values.update((variable.name, variable.value) for variable in project.variables)
    return values


def expand_path(value, variables):
    def resolve(match):
        variable, pattern = match.groups()
        if variable not in variables:
            raise ValueError(f"无法验证输出路径变量：{match[0]}")
        result = variables[variable]
        if isinstance(result, str):
            if pattern:
                raise ValueError(f"输出路径变量不支持该格式：{match[0]}")
            return result
        if not pattern:
            return str(result) if isinstance(result, int) else f"{result:g}"
        whole, point, fraction = pattern.partition(".")
        if point:
            return f"{result:0{len(whole) + len(fraction) + 1}.{len(fraction)}f}"
        if not isinstance(result, int):
            raise ValueError(f"无法验证输出路径变量格式：{match[0]}")
        return f"{result:0{len(whole)}d}"

    resolved = _PATH_FIELD.sub(resolve, value)
    if "{" in resolved or "}" in resolved:
        raise ValueError(f"无法验证输出路径模板：{value}")
    return resolved


def file_destination(scene, node, item_name, image_format, frame, suffix, animation):
    directory = node.directory
    filename = node.file_name + item_name
    if directory and not directory.endswith(("/", "\\")):
        directory += os.sep
    raw = directory + filename
    basename = re.split(r"[/\\]", raw)[-1]
    variables = template_variables(scene, node)
    if not animation and re.search(r"#+", _PATH_FIELD.sub("", basename)):
        raw = frame_name(raw, frame)
        absolute = bpy.path.abspath(expand_path(raw, variables))
    else:
        expanded = expand_path(raw, variables)
        absolute = frame_name(bpy.path.abspath(expanded), frame)
    if suffix:
        stem, extension = os.path.splitext(absolute)
        absolute = stem + suffix + extension
    if node.use_file_extension:
        format_name = image_format.file_format
        extension = ".j2c" if format_name == "JPEG2000" and image_format.jpeg2k_codec == "J2K" else (
            ".jp2" if format_name == "JPEG2000" else _EXTENSIONS.get(format_name)
        )
        if extension is None:
            raise ValueError(f"无法验证文件输出格式：{format_name}")
        if not absolute.lower().endswith((extension, *_ALTERNATE_EXTENSIONS.get(format_name, ()))):
            absolute += extension
    return Path(os.path.abspath(absolute))


def view_suffixes(scene, image_format):
    render = scene.render
    if not render.use_multiview or image_format.views_format != "INDIVIDUAL":
        return ("",)
    return tuple(view.file_suffix for view in render.views if view.use and (
        render.views_format != "STEREO_3D" or view.name in {"left", "right"}
    ))


def render_roots(scene):
    if hasattr(scene, "compositor_effects"):
        active = scene.compositor_effects.active
        return active, [
            (effect, effect.node_group, effect.enable_for_render)
            for effect in scene.compositor_effects if effect.node_group
        ]
    tree = getattr(scene, "compositing_node_group", None) or getattr(scene, "node_tree", None)
    return None, [(None, tree, True)] if tree else []


@dataclass
class RenderPlan:
    scene: object
    roots: list
    output_nodes: list
    files: list
    selected: set
    needed: set
    missing: list
    animation: bool
    first: int
    last: int
    has_final: bool

    @classmethod
    def build(cls, context):
        scene = context.scene
        selected_effect, roots = render_roots(scene)
        root = next((tree for effect, tree, _ in roots if effect == selected_effect), None)
        if root is None:
            raise ValueError("当前效果没有合成节点树。")
        space = context.space_data
        if getattr(space, "tree_type", "") == "CompositorNodeTree":
            editor_tree = space.edit_tree or space.node_tree
            if editor_tree and editor_tree != root:
                raise ValueError("请在当前效果的根节点树选择渲染层。")
        selected = {
            (scene, node.layer) for node in root.nodes
            if node.select and node.type == "R_LAYERS" and (node.scene is None or node.scene == scene)
            and scene.view_layers.get(node.layer)
        }
        if not selected:
            raise ValueError("请选择当前场景有效的渲染层节点。")
        settings = scene.auto_rename_settings
        animation = settings.render_mode != "STILL"
        if settings.render_mode == "RANGE":
            first, last = settings.render_frame_start, settings.render_frame_end
        elif animation:
            first, last = scene.frame_start, scene.frame_end
        else:
            first = last = scene.frame_current
        if first > last:
            raise ValueError("开始帧不能大于结束帧。")
        plan = cls(scene, [], [], [], selected, set(selected), [], animation, first, last, False)
        plan.find_outputs(selected_effect, roots)
        plan.find_files()
        if not plan.files and not plan.has_final:
            detail = "；".join(plan.missing) or "未找到与所选视图层相连的文件输出"
            raise ValueError(f"没有可用输出。{detail}。")
        return plan

    def find_outputs(self, active, roots):
        base_layer = self.scene.view_layers[0]
        previous = frozenset({(self.scene, base_layer.name)})
        reachable = True
        for effect, tree, enabled in roots:
            render_enabled = enabled and self.scene.render.use_compositing
            can_run = reachable and render_enabled
            scope = TreeScope(
                tree, (effect.name if effect else tree.name,),
                previous=previous if effect else frozenset(),
                effect_pointer=effect.as_pointer() if effect else None,
            )
            if can_run:
                self.roots.append((effect, scope))
                final = scope.final_input()
                self.has_final = bool(final and incoming(final))
                previous = scope.trace_input(final, self.scene) if self.has_final else frozenset()
                if effect:
                    first_output = first_interface_socket(tree, "OUTPUT")
                    reachable = bool(first_output and first_output.socket_type == "NodeSocketColor")
            if effect != active:
                continue
            for file_scope, node in scope.file_nodes():
                indices = []
                for index, _ in enumerate(node.file_output_items):
                    socket = node.inputs[index]
                    dependencies = file_scope.trace_input(socket, self.scene)
                    if not dependencies.intersection(self.selected):
                        continue
                    location = "/".join((*file_scope.path, node.name, socket.name))
                    if not render_enabled:
                        self.missing.append(f"{location}（未启用合成渲染）")
                    elif not can_run:
                        self.missing.append(f"{location}（前面的效果没有画面出口）")
                    elif node.mute:
                        self.missing.append(f"{location}（已静音）")
                    elif dependencies - self.selected:
                        self.missing.append(f"{location}（同时依赖未选视图层）")
                    else:
                        indices.append(index)
                if indices:
                    self.output_nodes.append(OutputNode(file_scope, node, tuple(indices), len(self.output_nodes)))
        if self.has_final:
            self.needed.update(
                (scene, name) for scene, name in previous if scene == self.scene and scene.view_layers.get(name)
            )

    def find_files(self):
        frames = range(self.first, self.last + 1, self.scene.frame_step if self.animation else 1)
        for output in self.output_nodes:
            for index, item_name, image_format in output.entries():
                identity = output.ownership(index)
                for suffix in view_suffixes(self.scene, image_format):
                    for frame in frames:
                        destination = file_destination(
                            self.scene, output.node, item_name, image_format, frame, suffix, self.animation
                        )
                        owner = (self.scene.session_uid, identity, suffix, frame)
                        label = "" if index is None else f"slot-{index}"
                        stage = Path(str(output.number), f"frame-{frame:04d}{label}{suffix}")
                        self.files.append(OutputFile(destination, Path(path_key(destination)), stage, owner, None, False))
        validate_output_paths(self.files)
        for output in self.files:
            output.existing = file_identity(output.destination)
            earlier = _WRITTEN_FILES.get(output.canonical)
            if output.existing and earlier and earlier[1] == output.existing and earlier[0] != output.owner:
                raise ValueError(f"该路径属于其他输出或帧，现有文件已保留：{output.destination}")
            output.same_frame = bool(output.existing and earlier == (output.owner, output.existing))

    @property
    def existing_files(self):
        return [output for output in self.files if output.existing]

    def confirmation_key(self):
        return (
            self.scene.session_uid, self.first, self.last, self.animation,
            frozenset(self.selected), frozenset(self.needed), tuple(self.missing),
            self.has_final, tuple((file.owner, file.destination, file.canonical, file.existing) for file in self.files),
        )


class RenderRun:
    def __init__(self, plan):
        self.plan = plan
        self.scene = plan.scene
        self.layers = [(layer, layer.use) for layer in self.scene.view_layers]
        self.frames = (self.scene.frame_start, self.scene.frame_end, self.scene.frame_current, self.scene.frame_subframe)
        self.filepath = self.scene.render.filepath
        self.temporary = tempfile.TemporaryDirectory(prefix="aov-plus-render-")
        self.root = Path(self.temporary.name)
        self.copies = []
        self.swaps = []
        self.completed = None

    def prepare(self):
        chosen = {output.key: output for output in self.plan.output_nodes}
        for effect, scope in self.plan.roots:
            copied = self.isolate(scope, chosen)
            if copied:
                owner, attribute = (effect, "node_group") if effect else (self.scene, "compositing_node_group")
                self.swaps.append((owner, attribute, scope.tree))
                setattr(owner, attribute, copied)
        for layer, _ in self.layers:
            layer.use = (self.scene, layer.name) in self.plan.needed
        if self.plan.animation:
            self.scene.frame_start = self.plan.first
            self.scene.frame_end = self.plan.last
            self.scene.render.filepath = str(self.root / "main" / "frame-####")
        bpy.app.handlers.render_complete.append(self.complete)
        bpy.app.handlers.render_cancel.append(self.cancel)

    def isolate(self, scope, chosen):
        nodes = [node for node in scope.tree.nodes if node.type == "OUTPUT_FILE" and not node.mute]
        groups = {}
        for node in scope.tree.nodes:
            if node.type == "GROUP" and node.node_tree and not node.mute:
                child = self.isolate(scope.child(node), chosen)
                if child:
                    groups[node.name] = child
        if not nodes and not groups:
            return None
        copied = scope.tree.copy()
        self.copies.append(copied)
        for name, tree in groups.items():
            copied.nodes[name].node_tree = tree
        for original in nodes:
            node = copied.nodes[original.name]
            output = chosen.get((*scope.path, original.name))
            if output is None:
                node.mute = True
                continue
            node.directory = str(self.root / str(output.number))
            node.file_name = "frame-####"
            node.use_file_extension = False
            for index in reversed(range(len(node.file_output_items))):
                item = node.file_output_items[index]
                if index not in output.indices:
                    node.file_output_items.remove(item)
                elif not output.multilayer:
                    item.name = f"slot-{index}"
        return copied

    def complete(self, scene, *_):
        if scene == self.scene:
            self.completed = True

    def cancel(self, scene, *_):
        if scene == self.scene:
            self.completed = False

    def publish(self):
        validate_output_paths(self.plan.files)
        for output in self.plan.files:
            if not (self.root / output.relative_stage).is_file():
                raise ValueError(f"渲染未产生预期输出，原文件已保留：{output.destination}")
            if file_identity(output.destination) != output.existing:
                raise ValueError(f"输出目标在渲染期间发生变化，现有文件已保留：{output.destination}")
        for output in self.plan.files:
            self.publish_file(output)

    def publish_file(self, output):
        destination = output.destination
        destination.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(prefix=".aov-plus-", dir=destination.parent)
        try:
            with os.fdopen(descriptor, "wb") as sink, (self.root / output.relative_stage).open("rb") as source:
                shutil.copyfileobj(source, sink)
            if file_identity(destination) != output.existing:
                raise ValueError(f"输出目标发生变化，现有文件已保留：{destination}")
            if output.existing:
                os.replace(temporary, destination)
            elif os.name == "nt":
                os.rename(temporary, destination)
            else:
                os.link(temporary, destination)
            _WRITTEN_FILES[output.canonical] = (output.owner, file_identity(destination))
        finally:
            Path(temporary).unlink(missing_ok=True)

    def restore(self):
        for callbacks, callback in (
            (bpy.app.handlers.render_complete, self.complete),
            (bpy.app.handlers.render_cancel, self.cancel),
        ):
            if callback in callbacks:
                callbacks.remove(callback)
        for owner, attribute, original in reversed(self.swaps):
            setattr(owner, attribute, original)
        for copied in reversed(self.copies):
            bpy.data.node_groups.remove(copied)
        for layer, enabled in self.layers:
            layer.use = enabled
        first, last, frame, subframe = self.frames
        self.scene.frame_start = first
        self.scene.frame_end = last
        self.scene.render.filepath = self.filepath
        if (self.scene.frame_current, self.scene.frame_subframe) != (frame, subframe):
            self.scene.frame_set(frame, subframe=subframe)
        self.temporary.cleanup()


def start_render(plan):
    return bpy.ops.render.render("EXEC_DEFAULT" if bpy.app.background else "INVOKE_DEFAULT", animation=plan.animation)


class COMPOSITOR_OT_render_selected_view_layers(Operator):
    """Render selected view layers and retain layers required by the compositor image"""

    bl_idname = "compositor.render_selected_view_layers"
    bl_label = "渲染选中视图层"
    bl_description = "只写当前效果中选中视图层的分通道文件，按需计算最终画面依赖的其他层"

    def invoke(self, context, event):
        try:
            plan = self.make_plan(context)
        except (OSError, ValueError) as error:
            self.report({"WARNING"}, str(error))
            return {"CANCELLED"}
        layers = "、".join(sorted(name for _, name in plan.selected))
        message = [f"帧：{plan.first}–{plan.last}。选中视图层：{layers}。"]
        additional = sorted(name for _, name in plan.needed - plan.selected)
        if additional:
            message.append(f"最终画面会额外计算：{'、'.join(additional)}。这些层不会写分通道文件。")
        if plan.missing:
            message.append(f"不会写出：{'；'.join(plan.missing)}。")
        if not plan.files:
            message.append("仅输出最终画面，不保存分通道文件。")
        recognized = [str(item.destination) for item in plan.existing_files if item.same_frame]
        unrecognized = [str(item.destination) for item in plan.existing_files if not item.same_frame]
        if recognized:
            message.append(f"确认重渲并覆盖同一输出同一帧：{'；'.join(recognized)}")
        if unrecognized:
            message.append(f"仅在确认是同一输出及同一帧时继续覆盖已有文件：{'；'.join(unrecognized)}")
        self.confirmed_plan = plan.confirmation_key()
        return context.window_manager.invoke_confirm(self, event, message="\n".join(message))

    def make_plan(self, context):
        if _ACTIVE_RENDER is not None or bpy.app.is_job_running("RENDER"):
            raise ValueError("渲染正在进行，请等待结束。")
        return RenderPlan.build(context)

    def execute(self, context):
        global _ACTIVE_RENDER
        try:
            plan = self.make_plan(context)
            confirmation = getattr(self, "confirmed_plan", None)
            if confirmation is not None and confirmation != plan.confirmation_key():
                raise ValueError("输出设置或文件在确认后发生变化，请重新确认。")
            if confirmation is None and (plan.existing_files or not plan.files):
                raise ValueError("需要在渲染确认框确认已有文件或仅输出最终画面。")
            if confirmation is None and plan.missing:
                self.report({"WARNING"}, f"不会写出：{'；'.join(plan.missing)}")
            self.run = _ACTIVE_RENDER = RenderRun(plan)
            self.run.prepare()
            result = start_render(plan)
            if result == {"RUNNING_MODAL"}:
                manager = context.window_manager
                self.timer = manager.event_timer_add(0.1, window=context.window)
                manager.modal_handler_add(self)
                return result
            return self.finish(result == {"FINISHED"} and self.run.completed is not False)
        except Exception as error:
            if getattr(self, "run", None) is not None:
                return self.finish(False, error)
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

    def modal(self, context, event):
        if event.type == "TIMER" and not bpy.app.is_job_running("RENDER"):
            context.window_manager.event_timer_remove(self.timer)
            return self.finish(self.run.completed is True)
        return {"PASS_THROUGH"}

    def finish(self, completed, error=None):
        global _ACTIVE_RENDER
        try:
            if completed:
                self.run.publish()
        except (OSError, ValueError) as failure:
            error = failure
        finally:
            try:
                self.run.restore()
            finally:
                self.run = _ACTIVE_RENDER = None
        if error:
            self.report({"ERROR"}, str(error))
        return {"FINISHED"} if completed and error is None else {"CANCELLED"}
