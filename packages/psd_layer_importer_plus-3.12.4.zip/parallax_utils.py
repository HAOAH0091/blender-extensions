"""PSD Layer Importer PLUS — 视差与相机匹配"""
import time
import bpy
import mathutils
import math
from bpy.app.handlers import persistent
from typing import Any, List, Tuple
from .constants import (
    _psd_log, PSD_DEBUG, ATTR_LAYER_ID,
    ATTR_INITIAL_TRANSFORM, ATTR_PRE_MATCH_TRANSFORM,
    TRANSFORM_CHANGE_THRESHOLD, MIN_DEPTH, MESH_SCALE_FACTOR,
    CAMERA_CHANGE_THRESHOLD, PARALLAX_CAMERA_SCROLL_SCALE,
    PSDImage,
)

# ── 相机适配日志节流 ──
# handler 挂在 depsgraph_update_post，移动相机时**每帧**触发；
# 若每帧每层都打日志会瞬间刷屏。故按「距上次打印的秒数」节流，
# 移动过程中最多每 PARALLAX_ADAPT_LOG_INTERVAL 秒记一条汇总。
PARALLAX_ADAPT_LOG_INTERVAL = 0.5
_adapt_log_state = {}       # {节流键: 上次打印时间} —— 按 集合|相机 分键，避免多卡片互相压日志
_handler_err_state = {"msg": None, "t": 0.0}    # handler 异常去重/节流

def get_collection_from_record(psd_file: Any) -> Any:
    """
    从PSD文件记录获取集合
    优先使用collection引用，如果无效则回退到名称查找

    Args:
        psd_file: PSDFileRecord对象

    Returns:
        Collection对象或None
    """
    # 优先使用直接引用
    if hasattr(psd_file, "collection") and psd_file.collection is not None:
        return psd_file.collection

    # 回退到名称查找（兼容旧数据）
    base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
    collection = bpy.data.collections.get(base_name)

    # 如果找到了集合，更新引用以便下次使用
    if collection is not None and hasattr(psd_file, "collection"):
        psd_file.collection = collection

    return collection


def get_all_objects_recursive(collection: Any) -> List[Any]:
    """
    递归获取集合及其所有子集合中的对象

    Args:
        collection: Blender集合对象

    Returns:
        包含所有对象的列表
    """
    objects = []

    # 添加当前集合的对象
    for obj in collection.objects:
        objects.append(obj)

    # 递归处理所有子集合
    for child_collection in collection.children:
        objects.extend(get_all_objects_recursive(child_collection))

    return objects


def get_mesh_dimensions(obj: Any) -> Tuple[float, float, float]:
    """从网格顶点获取对象的实际尺寸"""
    try:
        mesh = obj.data
        if mesh and len(mesh.vertices) >= 4:
            # 假设是矩形平面，获取顶点边界
            min_x = min(v.co.x for v in mesh.vertices)
            max_x = max(v.co.x for v in mesh.vertices)
            min_y = min(v.co.y for v in mesh.vertices)
            max_y = max(v.co.y for v in mesh.vertices)
            return (max_x - min_x, max_y - min_y, 1)
    except (AttributeError, TypeError, KeyError, RuntimeError):
        pass
    # 回退到 initial_scale（兼容旧数据）
    return (1, 1, 1)


def match_layers_to_camera(collection, camera, psd_file, target_objects=None,
                           update_state=True):
    """把 collection 里的 PSD 图层匹配到相机。

    target_objects: 若给定（对象集合），只处理这些对象（用于「对选中的图层对象执行操作」）；
                    为 None 时处理整个 collection（卡片按钮的旧行为）。
    update_state: 是否写 psd_file.last_camera_transform（选中行版传 False，用自己的状态字段）。
    """
    if target_objects is not None:
        target_objects = set(target_objects)
    if update_state:
        psd_file.last_camera_transform = str(
            tuple(tuple(row) for row in camera.matrix_world)
        )

    psd = PSDImage.open(psd_file.filepath)
    canvas_box = psd.viewbox
    canvas_width = canvas_box[2] - canvas_box[0]
    canvas_height = canvas_box[3] - canvas_box[1]

    min_point = mathutils.Vector((float("inf"), float("inf"), float("inf")))
    max_point = mathutils.Vector((float("-inf"), float("-inf"), float("-inf")))

    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj and (target_objects is None or obj in target_objects):
            # ★ 构图基准用【PSD 原始位置】(initial_transform)，不用用户手改后的当前位置。
            #   诉求：用户自行改过图层位置后，再点「匹配至相机」，相机视图里仍应呈现
            #   PSD 原始相对位置构图（忽略手改）。
            #   ⚠️ z 仍取【实际值】—— 那是用户摆的视差深度，不属于"构图"。
            #   （旧版曾用 initial_transform 算边界后被改成实际位置，是反方向的改动；
            #     见开发进度记录「相机匹配功能修复」。本次按用户诉求改回构图基准。）
            base = get_psd_initial_location(obj)
            actual_z = get_match_base_z(obj)
            # 从网格获取实际尺寸
            mesh_dims = get_mesh_dimensions(obj)

            half_width = mesh_dims[0] / 2
            half_height = mesh_dims[1] / 2
            corners = [
                mathutils.Vector((base.x + x * half_width, base.y + y * half_height,
                                  actual_z))
                for x, y in [(-1, -1), (-1, 1), (1, -1), (1, 1)]
            ]

            for corner in corners:
                for i in range(3):
                    min_point[i] = min(min_point[i], corner[i])
                    max_point[i] = max(max_point[i], corner[i])

    if min_point[0] == float("inf"):
        return

    center = mathutils.Vector((0, 0, (min_point.z + max_point.z) / 2))

    camera_pos = camera.matrix_world.translation
    distance = (camera_pos - center).length

    look_at = camera.matrix_world.to_quaternion()
    rotation_matrix = look_at.to_matrix().to_4x4()

    if camera.data.type == "PERSP":
        fov = camera.data.angle
        viewport_width = 2 * distance * math.tan(fov / 2)
        aspect_ratio = (
            bpy.context.scene.render.resolution_x
            / bpy.context.scene.render.resolution_y
        )
        viewport_height = viewport_width / aspect_ratio
    else:
        viewport_width = camera.data.ortho_scale
        viewport_height = viewport_width / (
            bpy.context.scene.render.resolution_x
            / bpy.context.scene.render.resolution_y
        )

    scale_x = viewport_width / (canvas_width * MESH_SCALE_FACTOR)
    scale_y = viewport_height / (canvas_height * MESH_SCALE_FACTOR)
    viewport_scale = max(scale_x, scale_y)

    n_matched = 0
    n_fallback = 0          # 无 initial_transform、回退用当前位置的层数
    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj and (target_objects is None or obj in target_objects):
            if "pre_match_transform" not in obj:
                obj["pre_match_transform"] = {
                    "matrix_world": [list(row) for row in obj.matrix_world],
                    "scale": list(obj.scale),
                    "rotation_euler": list(obj.rotation_euler),
                    "location": list(obj.location),
                }

            # ★ relative_pos 的 xy 用【PSD 原始位置】→ 相机视图里还原 PSD 原始构图；
            #   z 用【实际值】→ 保留用户摆的视差深度。
            base = get_psd_initial_location(obj)
            relative_pos = mathutils.Vector(
                (base.x - center.x, base.y - center.y, get_match_base_z(obj) - center.z)
            )

            new_pos = camera_pos - rotation_matrix.to_3x3() @ mathutils.Vector(
                (0, 0, distance)
            )
            new_pos += rotation_matrix @ (relative_pos * viewport_scale)

            # 设置位置和旋转
            obj.location = new_pos
            obj.rotation_euler = rotation_matrix.to_euler()

            # 设置缩放（网格已包含实际尺寸，只需统一缩放viewport_scale）
            obj.scale = (viewport_scale, viewport_scale, viewport_scale)

            n_matched += 1
            if ATTR_INITIAL_TRANSFORM not in obj:
                n_fallback += 1

    # 汇总一行。说明构图基准来源：正常用 PSD 原始位置（initial_transform），
    # 旧工程/非 PSD 图层缺该记录时回退当前位置（行为同旧版）。
    _psd_log(
        f"[PSD-匹配] 匹配至相机: {n_matched} 层, 相机='{camera.name}', "
        f"viewport_scale={viewport_scale:.5f}, 构图基准=PSD原始位置(initial_transform)"
        + (f", ⚠ {n_fallback} 层无该记录→回退当前位置" if n_fallback else "")
    )


def restore_pre_match_transform(collection, target_objects=None):
    if target_objects is not None:
        target_objects = set(target_objects)
    n_back = 0
    for obj in get_all_objects_recursive(collection):
        if (ATTR_LAYER_ID in obj and "pre_match_transform" in obj
                and (target_objects is None or obj in target_objects)):
            n_back += 1
            pre_match = obj["pre_match_transform"]
            # 重新构造 Matrix 对象
            try:
                obj.matrix_world = mathutils.Matrix(
                    [mathutils.Vector(row) for row in pre_match["matrix_world"]]
                )
            except (AttributeError, TypeError, ValueError, KeyError):
                # 如果 matrix_world 恢复失败，使用分离的属性
                try:
                    obj.scale = mathutils.Vector(pre_match["scale"])
                    obj.rotation_euler = mathutils.Euler(pre_match["rotation_euler"])
                    obj.location = mathutils.Vector(pre_match["location"])
                except (AttributeError, TypeError, ValueError, KeyError):
                    pass
            del obj["pre_match_transform"]

    _psd_log(f"[PSD-匹配] 恢复匹配前: {n_back} 层（回到匹配前的位置）")


def calculate_camera_sensor_dimensions(camera):
    camera_data = camera.data
    sensor_width = camera_data.sensor_width

    if camera_data.sensor_fit == "VERTICAL":
        sensor_height = sensor_width
        sensor_width = sensor_width / (
            bpy.context.scene.render.resolution_y
            / bpy.context.scene.render.resolution_x
        )
    elif camera_data.sensor_fit == "HORIZONTAL":
        sensor_height = sensor_width * (
            bpy.context.scene.render.resolution_y
            / bpy.context.scene.render.resolution_x
        )
    else:
        render_aspect = (
            bpy.context.scene.render.resolution_x
            / bpy.context.scene.render.resolution_y
        )
        if render_aspect >= 1.0:
            sensor_height = sensor_width / render_aspect
        else:
            sensor_height = sensor_width
            sensor_width = sensor_width * render_aspect

    return sensor_width, sensor_height


def get_camera_view_matrix(camera):
    """相机的「视图矩阵」：只含位置 + 朝向，【剥离对象 scale】。

    ⚠️ 为什么必须剥离：相机对象的 scale **不影响渲染**（渲染只用 location / rotation / lens），
    但它会污染 matrix_world。用户把相机缩放个几十倍（只为在视口里放大视锥体显示）时，
    matrix_world.inverted() 会把所有距离缩小同样倍数 ⇒ 深度算错 ⇒ 视差锁定/相机适配全废。

    实测事故（2026-10-09，用户工程 E:\\desktop\\test.blend）：
      相机 scale = 38.9465
      某层真实沿视线距离 12.936  →  算出 depth = 0.332（= 12.936 × 1/38.9465）
      ⇒ 画面滚动量放大 38.95 倍，用户反馈"稍微动一下相机就飞走了"。
    """
    loc, rot, _scale = camera.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def world_to_screen_coords(obj_pos, camera):
    camera_data = camera.data
    focal_length = camera_data.lens
    sensor_width, sensor_height = calculate_camera_sensor_dimensions(camera)

    # 用「视图矩阵」（剥离相机 scale），不用 matrix_world
    camera_matrix = get_camera_view_matrix(camera)
    camera_space_pos = camera_matrix.inverted() @ obj_pos

    if camera_space_pos.z < 0:
        depth = abs(camera_space_pos.z)
        screen_x = (camera_space_pos.x * focal_length) / (depth * sensor_width)
        screen_y = (camera_space_pos.y * focal_length) / (depth * sensor_height)
        return screen_x, screen_y, depth
    return 0, 0, 1


def get_object_center_world_pos(obj):
    bbox_corners = [
        obj.matrix_world @ mathutils.Vector(corner) for corner in obj.bound_box
    ]
    center = mathutils.Vector((0, 0, 0))
    for corner in bbox_corners:
        center += corner
    center /= len(bbox_corners)
    return center


def screen_to_world_position(screen_x, screen_y, depth, camera):
    camera_data = camera.data
    focal_length = camera_data.lens
    sensor_width, sensor_height = calculate_camera_sensor_dimensions(camera)

    camera_space_x = (screen_x * depth * sensor_width) / focal_length
    camera_space_y = (screen_y * depth * sensor_height) / focal_length
    camera_space_pos = mathutils.Vector(
        (
            camera_space_x,
            camera_space_y,
            -depth,
        )
    )
    # 与 world_to_screen_coords 对称：同样剥离相机 scale（否则往返不一致）
    camera_matrix = get_camera_view_matrix(camera)
    world_pos = camera_matrix @ camera_space_pos
    return world_pos


# 视差锁定属性键：对象带齐这些键 = 处于锁定状态（handler 也以此为准）
PARALLAX_LOCK_KEYS = (
    "original_location",
    "original_scale",
    "locked_screen_x",
    "locked_screen_y",
    "locked_depth",
    "center_offset",
    "locked_camera_sensor_height",
)


def is_obj_parallax_locked(obj) -> bool:
    """该对象是否处于视差锁定状态（= 带齐锁定属性）。"""
    return ATTR_LAYER_ID in obj and all(k in obj for k in PARALLAX_LOCK_KEYS)


def iter_objects_recursive(collection):
    """递归遍历集合树（**生成器**，支持 any() 早退）。

    与 get_all_objects_recursive 区别：后者先建完整 list，即使 any() 第一个就命中
    也要遍历完；本函数惰性迭代、命中即停。
    """
    for obj in collection.objects:
        yield obj
    for child in collection.children:
        yield from iter_objects_recursive(child)


def psd_has_locked_layers(psd_file) -> bool:
    """该 PSD 是否有任何已锁定图层（整份锁定 或 局部锁定）。

    用途：① handler 入口判据（不再依赖 record 开关/卡片相机）
         ② 刷新前警告（局部锁定也要警告）。
    """
    collection = get_collection_from_record(psd_file)
    if not collection:
        return False
    return any(is_obj_parallax_locked(o) for o in iter_objects_recursive(collection))


def psd_locked_now(psd_file) -> bool:
    """handler 用入口判据（带性能闸门 + 自愈）。

    账本（parallax_maybe_locked）为空 → O(1) 直接返回，不做全量扫描；
    账本非空 → 精确扫描；扫不到锁定对象就把账本归零（自愈），之后恢复 O(1)。

    失败安全：账本默认 True、只有"确认没有"才置 False，因此最坏情况是"多扫一次"，
    绝不会漏掉仍在生效的锁定。
    """
    if not getattr(psd_file, "parallax_maybe_locked", True):
        return False
    if psd_has_locked_layers(psd_file):
        return True
    psd_file.parallax_maybe_locked = False   # 自愈：账本归零，之后走 O(1) 短路
    return False


def record_parallax_lock_state(collection, camera, target_objects=None):
    """记录视差锁定状态。

    target_objects: 若给定（对象集合），**只处理这些对象**（用于「只锁选中图层」）；
                    为 None 时处理整个 collection（文件卡片按钮的旧行为）。
    """
    if target_objects is not None:
        target_objects = set(target_objects)
    # 视图矩阵（剥离相机 scale）—— 与 world_to_screen_coords 保持同一口径
    camera_matrix = get_camera_view_matrix(camera)

    # 相机对象带非 1 缩放时留痕（它不影响渲染，但历史上曾把深度算错几十倍；
    # 见 get_camera_view_matrix docstring。这里只提醒，实际计算已剥离。）
    cam_scale = camera.matrix_world.to_scale()
    if any(abs(s - 1.0) > 1e-4 for s in cam_scale):
        _psd_log(
            f"[PSD-视差] 相机 '{camera.name}' 带非1缩放 "
            f"({cam_scale.x:.4f}, {cam_scale.y:.4f}, {cam_scale.z:.4f}) "
            f"—— 已在相机空间变换中剥离，深度按真实距离计算"
        )

    n_locked = 0
    depths = []
    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj and (target_objects is None or obj in target_objects):
            obj["original_location"] = list(obj.location)
            obj["original_scale"] = list(obj.scale)
            obj["original_rotation"] = list(obj.rotation_euler)
            # 锁定时的【世界朝向】（纯旋转，已剔除 scale）。
            # 相机适配时要把图层放回"相对相机不变的朝向"，需要以它为基准。
            obj["locked_world_rotation"] = [
                list(row) for row in obj.matrix_world.to_quaternion().to_matrix()
            ]

            obj["parallax_camera_name"] = camera.name
            obj["locked_camera_matrix"] = [list(row) for row in camera_matrix]
            obj["locked_camera_focal_length"] = camera.data.lens
            obj["locked_camera_sensor_width"] = camera.data.sensor_width

            sensor_width, sensor_height = calculate_camera_sensor_dimensions(camera)
            obj["locked_camera_sensor_height"] = sensor_height

            obj_center_pos = get_object_center_world_pos(obj)
            screen_x, screen_y, depth = world_to_screen_coords(obj_center_pos, camera)

            center_offset = obj_center_pos - obj.matrix_world.translation
            obj["center_offset"] = list(center_offset)

            obj["locked_screen_x"] = screen_x
            obj["locked_screen_y"] = screen_y
            obj["locked_depth"] = depth
            obj["locked_visual_scale"] = list(obj.scale)

            obj["last_location"] = list(obj.location)
            obj["last_scale"] = list(obj.scale)
            # 相机适配锚点：记录"上次适配时的相机状态"，用于判断相机是否变过。
            # 初始 = 锁定时的相机 ⇒ 锁定时不算"移动过"。
            # ⚠️ 焦距必须单独记：改 lens **不改变 matrix_world**，只比矩阵会漏掉变焦
            #    （实测：变焦时 handler 一行都不执行 ⇒ 画面自然放大，与预期不符）。
            obj["last_camera_matrix"] = [list(row) for row in camera_matrix]
            obj["last_camera_focal"] = camera.data.lens

            n_locked += 1
            depths.append(depth)

    # 汇总一行（不逐层打，避免刷屏）。基准深度是"整组最深锁定层"，见
    # get_parallax_reference_depth；它的取值只影响相机横移时画面滚动的快慢。
    if n_locked:
        _psd_log(
            f"[PSD-视差] 锁定记录: {n_locked} 层, 相机='{camera.name}' "
            f"lens={camera.data.lens:.1f}mm, 深度范围=[{min(depths):.3f}, {max(depths):.3f}], "
            f"基准深度={max(depths):.3f}（=最深锁定层）"
            f" — 相机移动→图层跟随、构图冻结；想看视差请解锁后再移动相机"
        )
    else:
        _psd_log(f"[PSD-视差] 锁定记录: 0 层（集合='{collection.name}' 内无 PSD 图层命中）")


def restore_parallax_lock_state(collection, target_objects=None):
    """清除视差锁定状态。target_objects 给定时只处理这些对象。"""
    if target_objects is not None:
        target_objects = set(target_objects)
    n_restored = 0
    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj and (target_objects is None or obj in target_objects):
            n_restored += 1
            parallax_attrs = [
                "original_location",
                "original_scale",
                "original_rotation",
                "parallax_camera_name",
                "locked_camera_matrix",
                "locked_camera_focal_length",
                "locked_camera_sensor_width",
                "locked_camera_sensor_height",
                "locked_screen_x",
                "locked_screen_y",
                "locked_depth",
                "locked_visual_scale",
                "center_offset",
                "last_camera_matrix",
                "last_camera_focal",
                "locked_world_rotation",
            ]
            for attr in parallax_attrs:
                if attr in obj:
                    del obj[attr]

    # 说明「不归位」是有意设计：图层停在当前位置，不弹回锁定前的构图。
    _psd_log(
        f"[PSD-视差] 解除锁定: {n_restored} 层（清除锁定属性；"
        f"图层停在当前位置、不归位，方便接着在新机位干活）"
    )


def get_locked_camera_for_obj(obj, scene):
    """取该锁定图层记住的那台相机（对象上存的是相机名）。

    视差锁定把相机名写在 obj["parallax_camera_name"] 上 —— 不依赖卡片当前选中的相机，
    这样「只锁选中图层」的局部锁定也能找到自己那台。
    """
    name = obj.get("parallax_camera_name")
    if name:
        cam = bpy.data.objects.get(name)
        if cam is not None and cam.type == "CAMERA":
            return cam
    # 回退：相机被改名/删除时用场景当前相机，总比完全不动强
    if scene is not None and scene.camera is not None:
        return scene.camera
    return None


def get_psd_initial_location(obj):
    """图层在 PSD 里的【原始位置】（导入时按画布像素算出的布局，相对画布中心）。

    「匹配至相机」要以它为构图基准 —— 用户手改过图层位置后，再匹配仍应呈现
    PSD 原始相对位置构图（忽略手改）。

    无记录（旧工程 / 非 PSD 图层）时回退到当前位置，保持旧行为。
    """
    init = obj.get(ATTR_INITIAL_TRANSFORM)
    if init is not None:
        try:
            loc = init["location"]
            return mathutils.Vector((float(loc[0]), float(loc[1]), float(loc[2])))
        except (TypeError, KeyError, ValueError, IndexError):
            pass
    return obj.location.copy()


def get_match_base_z(obj) -> float:
    """「匹配至相机」要用的图层深度 z —— 必须是【稳定值】，否则重复匹配会漂移。

    为什么不能用 obj.location.z 直接当：
      匹配会把图层摆进相机空间，obj.location.z 随匹配结果改变；
      于是第二次匹配读到的是"上次匹配后的 z"，结果越匹配越偏 → 不幂等。
    稳定来源：优先取 pre_match_transform 里记的"匹配前 z"（= 用户摆的视差深度）；
      没有记录（首次匹配 / 旧数据）时才用当前位置 z。

    这样：手改过位置 → 首次匹配用你的 z ✓；再点几次都复用同一 z ✓ 幂等。
    """
    pre = obj.get(ATTR_PRE_MATCH_TRANSFORM)
    if pre is not None:
        try:
            return float(pre["location"][2])
        except (TypeError, KeyError, ValueError, IndexError):
            pass
    return obj.location.z


def get_parallax_reference_depth(locked_objects) -> float:
    """整组锁定层的「基准深度」= 最深那一层的 locked_depth。

    ⚠️ 它只影响「相机移动时画面滚动的快慢」，**不影响构图保持本身**
       （实测各种取法下各层屏幕位移都严格一致，离散 ~1e-8）。

    实测手感（相机横移 1.0；深度 6/9/12 的三层场景；1920 宽；50mm）：
        基准 = 最深 12  →  画面滚 222 px   ← 本实现
        基准 = 中位  9  →  画面滚 296 px
        基准 = 最浅  6  →  画面滚 444 px
    ⇒ 规律：**滚动量 = 相机位移 × 焦距(px) / 基准深度**（基准越深滚越慢）。

    ★ 取最深的理由：该层 k=1，相机移动时它的【世界坐标】保持不动，充当整叠图层里
      "钉死的锚点"，其余层相对它按深度比滑动 —— 视觉上最稳，也最符合直觉。

    ★ 自我纠错（两处，写在这里免得后人再踩）：
      1) 曾以为"基准取最深 ⇒ 近层几乎 1:1 跟着相机飞"，**是错的** ——
         各层【世界位移】确实不同（近层动得多），但【屏幕位移】严格一致，
         这正是"构图保持"的含义。手感差异只有一个维度：**整体滚动快慢**。
      2) 曾按反馈改成"中位数"，实测反而**更快**（296 > 222），已改回最深。

    ★ 若仍嫌滚太快：调 constants.PARALLAX_CAMERA_SCROLL_SCALE（<1 更慢）。
    """
    depths = [o["locked_depth"] for o in locked_objects if "locked_depth" in o]
    if not depths:
        return 0.0
    return max(depths)


def camera_changed_since_last_adapt(obj, camera) -> bool:
    """相机是否相对「上次适配时」有实质变化（平移/旋转都算）。

    比的是 obj["last_camera_matrix"]（上次适配后的快照），不是 locked_camera_matrix ——
    后者是固定锚点，若拿它比会每帧都判为"变过"，从而每帧重设 location、把用户的手动拖拽顶掉。
    """
    last = obj.get("last_camera_matrix")
    if last is None:
        return True
    # 与 record/apply 同一口径（视图矩阵）—— 相机 scale 变化不影响渲染，故不参与判定
    current = get_camera_view_matrix(camera)
    for r in range(4):
        for c in range(4):
            if abs(current[r][c] - last[r][c]) > CAMERA_CHANGE_THRESHOLD:
                return True
    # ★ 焦距也要比：改 lens 不影响 matrix_world，只比矩阵会把"变焦"整个漏掉
    last_focal = obj.get("last_camera_focal")
    if last_focal is None:
        return True
    if abs(camera.data.lens - last_focal) > 1e-6:
        return True
    return False


def apply_camera_adapt_to_obj(obj, camera, ref_depth):
    """相机变化后，把单个锁定图层放回「长图构图保持」的位姿。

    与 handler 里「拖图层」分支的分工：
      · 拖图层   → 保持【屏幕坐标】不变（原有语义，推拉单个图层用）
      · 相机变化 → 保持【长图构图】不变 + 画面可滚动 / 可缩放（本次新增）

    数学（与验证过的 demo 一致）：
      k     = locked_depth / ref_depth         该层相对基准层的深度比
      Δcs   = 相机世界位移在当前相机空间的分量
      dolly = (ref_depth - Δ轴) / ref_depth    相机沿锁定光轴移动 ⇒ 画面整体缩放
      zoom  = f_now / f_locked                 变焦补偿（令距离 ∝ 焦距 ⇒ 画面尺寸恒定）
      D     = locked_depth * dolly * zoom      目标深度（各层按同一比例缩放 ⇒ 无视差）
      local = (x0 - Δcs.x·k, y0 - Δcs.y·k, -D)
      world = camera.matrix_world @ local

    其中 xy 的 `-Δcs·k` 就是"每层按自己的深度适配"：**相机旋转时各层位移矢量各不相同**，
    所以必须逐层重算世界变换，不能真挂父子级（效果等价于刚性跟随，但父子级会让画面永远
    停在原地、滚不到长图其它位置，且会破坏 PSD 集合结构与 location 语义）。
    """
    locked_depth = obj["locked_depth"]
    # 后文用它作除数（cam_space_xy 反变换 = screen·depth·sensor/focal）：
    # 兜底防裸除零（review 指出；lens 理论恒 >0，这里是防御）。
    focal_locked = float(obj["locked_camera_focal_length"]) or MIN_DEPTH
    sensor_w = obj["locked_camera_sensor_width"]
    sensor_h = obj["locked_camera_sensor_height"]
    screen_x = obj["locked_screen_x"]
    screen_y = obj["locked_screen_y"]
    center_offset = mathutils.Vector(obj["center_offset"])
    original_scale = mathutils.Vector(obj["original_scale"])

    locked_camera_matrix = mathutils.Matrix(
        [mathutils.Vector(row) for row in obj["locked_camera_matrix"]]
    )
    # ⚠️ 必须用「视图矩阵」（剥离相机 scale）：否则含 scale 的矩阵会把 local 整体放大，
    #    图层被扔到几十倍远的地方（实测相机 scale=38.95 时世界位移从 3.7 变成 -2026）。
    current_matrix = get_camera_view_matrix(camera)
    current_rot = current_matrix.to_3x3()

    # 锁定时的相机空间 xy（图层中心）
    cam_space_x = screen_x * locked_depth * sensor_w / focal_locked
    cam_space_y = screen_y * locked_depth * sensor_h / focal_locked

    # 相机世界位移 → 当前相机空间分量（滚动修正用）
    eye_delta = current_matrix.translation - locked_camera_matrix.translation
    delta_cam_space = current_rot.transposed() @ eye_delta

    # 推拉：相机沿【锁定时的光轴】移动 → 画面整体缩放
    axis0 = locked_camera_matrix.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))
    axial = eye_delta.dot(axis0)
    if ref_depth > MIN_DEPTH:
        dolly = (ref_depth - axial) / ref_depth
    else:
        dolly = 1.0
    dolly = max(dolly, MIN_DEPTH)          # 相机推过头时兜底，避免深度归零/翻负

    # 变焦补偿：屏幕尺寸 ∝ 焦距 / 距离，令距离 ∝ 焦距 ⇒ 画面尺寸恒定
    focal_now = camera.data.lens
    zoom = (focal_now / focal_locked) if focal_locked > MIN_DEPTH else 1.0
    zoom = max(zoom, MIN_DEPTH)

    depth = max(locked_depth * dolly * zoom, MIN_DEPTH)
    # k = 该层相对基准层的深度比。PARALLAX_CAMERA_SCROLL_SCALE 整体缩放
    # "相机位移 → 画面滚动"的比率：<1 时画面滚得更慢（相机能移更多而构图不跑远）。
    # 它乘在 k 上，所以各层仍严格一致 ⇒ 不影响构图保持，只改滚动手感。
    k = (locked_depth / ref_depth) if ref_depth > MIN_DEPTH else 1.0
    k *= PARALLAX_CAMERA_SCROLL_SCALE

    local = mathutils.Vector(
        (
            cam_space_x - delta_cam_space.x * k,
            cam_space_y - delta_cam_space.y * k,
            -depth,
        )
    )
    world_center = current_matrix @ local

    # 尺寸保持 original_scale：深度乘了 sz 而尺寸不变 ⇒ 屏幕尺寸 ∝ 1/sz（推拉缩放生效、
    # 且各层比例一致 ⇒ 无视差）。变焦时因 depth ∝ f，屏幕尺寸恒定。
    obj.scale = original_scale

    # ── 朝向：保持图层【相对相机】的朝向不变 ⇒ 随相机一起转 ──
    # 网页 demo 里是 L.rot = R · d.lr（d.lr = 锁定时的相机空间朝向），本式等价：
    #     M_now = (V_now · V_locked⁻¹) · M_locked
    # 即"相机转了多少，图层就跟着转多少"，图层始终正对相机（与位置适配同一套旋转）。
    rot_delta = current_rot @ locked_camera_matrix.to_3x3().inverted()
    # ⚠️ 兼容老工程：`locked_world_rotation` 是本功能新增属性，早于本版锁定的图层没有它。
    #    若直接下标读取会 KeyError → 被 handler 的 except 吞掉 → 该层**永不适配**，
    #    且 PSD_DEBUG 打开时每帧重抛、控制台刷屏（实测复现）。
    #    兜底：此刻 obj 尚未被本函数修改，其世界朝向就是"锁定时的朝向"（老工程从未适配过），
    #    取它即可；并写回属性实现**自愈**，下次不再走兜底。
    wor = obj.get("locked_world_rotation")
    if wor is None:
        _rot_now = obj.matrix_world.to_quaternion().to_matrix()
        wor = [list(row) for row in _rot_now]
        obj["locked_world_rotation"] = [[float(x) for x in row] for row in wor]
        _psd_log(
            f"[PSD-视差] 图层 '{obj.name}' 缺 locked_world_rotation（老工程锁定记录）"
            f"，已用当前朝向兜底并补写"
        )
    locked_obj_rot = mathutils.Matrix([mathutils.Vector(row) for row in wor])
    new_obj_rot = rot_delta @ locked_obj_rot
    if obj.rotation_mode == "QUATERNION":
        obj.rotation_quaternion = new_obj_rot.to_quaternion()
    elif obj.rotation_mode == "AXIS_ANGLE":
        # ⚠️ 两个顺序**刻意不同**，极易写反（实测确认）：
        #    · mathutils 的 `to_axis_angle()` 返回 **(axis, angle)**
        #    · Blender 的 `rotation_axis_angle` 属性是 **(angle, x, y, z)**
        #    写反的后果：float 被当成 axis → `axis.x` 抛 AttributeError →
        #    被 handler 静默吞掉 → 该层朝向永不跟随（review 发现的真 bug）。
        _axis, _angle = new_obj_rot.to_quaternion().to_axis_angle()
        obj.rotation_axis_angle = (_angle, _axis.x, _axis.y, _axis.z)
    else:
        obj.rotation_euler = new_obj_rot.to_euler(obj.rotation_mode)

    # center_offset 是"物体几何中心相对原点的【世界】偏移"，物体转向后它同样要跟着转
    obj.location = world_center - (rot_delta @ center_offset)


@persistent
def parallax_scene_update_handler(scene):
    try:
        psd_tool = scene.psd_import_tool
        for psd_file in psd_tool.file_records:
            # 入口：该 PSD 有已锁定图层就处理 —— 不依赖卡片相机、也不依赖 record 开关，
            # 这样「只锁选中图层」的局部锁定也能生效（相机信息已存在对象属性里）。
            if psd_locked_now(psd_file):
                collection = get_collection_from_record(psd_file)
                if not collection:
                    continue

                # 先收集本组锁定层：基准深度要整组统一（各层共享同一个 dRef）
                locked_objects = [
                    o for o in iter_objects_recursive(collection)
                    if is_obj_parallax_locked(o)
                ]
                if not locked_objects:
                    continue
                ref_depth = get_parallax_reference_depth(locked_objects)

                n_adapted = 0          # 本组被「相机变化」适配的层数（用于汇总日志）
                adapt_info = None
                for obj in get_all_objects_recursive(collection):
                    if is_obj_parallax_locked(obj):
                        # ① 相机移动 → 整组「长图构图保持」适配（不再要求对象被选中）
                        locked_camera = get_locked_camera_for_obj(obj, scene)
                        if (locked_camera is not None
                                and camera_changed_since_last_adapt(obj, locked_camera)):
                            apply_camera_adapt_to_obj(obj, locked_camera, ref_depth)
                            obj["last_camera_matrix"] = [
                                list(row) for row in get_camera_view_matrix(locked_camera)
                            ]
                            obj["last_camera_focal"] = locked_camera.data.lens
                            obj["last_location"] = list(obj.location)
                            obj["last_scale"] = list(obj.scale)
                            # 只取本组第一层的量做汇总（相机位移 / 焦距变化）
                            if n_adapted == 0:
                                _cur = get_camera_view_matrix(locked_camera)
                                _lk = mathutils.Matrix(
                                    [
                                        mathutils.Vector(r)
                                        for r in obj["locked_camera_matrix"]
                                    ]
                                )
                                adapt_info = (
                                    (_cur.translation - _lk.translation).length,
                                    obj["locked_camera_focal_length"],
                                    locked_camera.data.lens,
                                )
                            n_adapted += 1
                            continue

                        # ② 拖图层 → 保持屏幕坐标（原有语义）
                        obj_selected = obj.select_get()
                        current_location = list(obj.location)
                        current_scale = list(obj.scale)

                        is_first_detection = "last_location" not in obj
                        if is_first_detection:
                            obj["last_location"] = current_location.copy()
                            obj["last_scale"] = current_scale.copy()
                            obj["last_plugin_location"] = current_location.copy()
                            obj["last_plugin_scale"] = current_scale.copy()

                        last_location = obj["last_location"]
                        last_scale = obj["last_scale"]

                        threshold = TRANSFORM_CHANGE_THRESHOLD
                        transform_changed = any(
                            abs(current_location[i] - last_location[i]) > threshold
                            for i in range(3)
                        ) or any(
                            abs(current_scale[i] - last_scale[i]) > threshold
                            for i in range(3)
                        )

                        update_this_obj = (
                            obj_selected
                            and transform_changed
                            and not is_first_detection
                        )

                        if update_this_obj:
                            original_scale = obj["original_scale"]
                            locked_screen_x = obj["locked_screen_x"]
                            locked_screen_y = obj["locked_screen_y"]
                            locked_depth = obj["locked_depth"]
                            locked_focal_length = obj["locked_camera_focal_length"]
                            locked_sensor_width = obj["locked_camera_sensor_width"]
                            locked_sensor_height = obj["locked_camera_sensor_height"]
                            center_offset = mathutils.Vector(obj["center_offset"])

                            locked_camera_matrix = mathutils.Matrix(
                                [
                                    mathutils.Vector(row)
                                    for row in obj["locked_camera_matrix"]
                                ]
                            )
                            locked_camera_matrix_inv = locked_camera_matrix.inverted()

                            obj_center_pos = get_object_center_world_pos(obj)
                            center_in_cam_space = (
                                locked_camera_matrix_inv @ obj_center_pos
                            )
                            current_depth = max(abs(center_in_cam_space.z), MIN_DEPTH)

                            cam_space_pos = mathutils.Vector(
                                (
                                    locked_screen_x
                                    * current_depth
                                    * locked_sensor_width
                                    / locked_focal_length,
                                    locked_screen_y
                                    * current_depth
                                    * locked_sensor_height
                                    / locked_focal_length,
                                    -current_depth,
                                )
                            )

                            final_center_pos = locked_camera_matrix @ cam_space_pos
                            scale_factor = current_depth / locked_depth

                            # ⚠️ center_offset 是"物体几何中心相对原点的世界偏移"，
                            #    朝向若已被相机适配转过（apply_camera_adapt_to_obj 会改 rotation），
                            #    它必须跟着转 —— 否则拖图层会偏（引入朝向跟随时产生的回归）。
                            if locked_camera is not None:
                                rot_delta = (
                                    get_camera_view_matrix(locked_camera).to_3x3()
                                    @ locked_camera_matrix.to_3x3().inverted()
                                )
                            else:
                                rot_delta = mathutils.Matrix.Identity(3)
                            scaled_center_offset = (rot_delta @ center_offset) * scale_factor
                            target_origin_pos = final_center_pos - scaled_center_offset

                            obj.location = target_origin_pos
                            obj.scale = mathutils.Vector(original_scale) * scale_factor

                            obj["last_location"] = list(obj.location)
                            obj["last_scale"] = list(obj.scale)
                            obj["last_plugin_location"] = list(obj.location)
                            obj["last_plugin_scale"] = list(obj.scale)

                # 相机适配汇总（**节流**）：handler 每帧触发，逐帧打会刷屏，
                # 故最多每 PARALLAX_ADAPT_LOG_INTERVAL 秒记一条。
                if n_adapted and adapt_info is not None:
                    _now = time.time()
                    # 按 集合|相机 分键节流（多 PSD 卡片时互不压制）
                    _key = f"{collection.name}|{locked_camera.name}"
                    if _now - _adapt_log_state.get(_key, 0.0) >= PARALLAX_ADAPT_LOG_INTERVAL:
                        _adapt_log_state[_key] = _now
                        _shift, _f0, _f1 = adapt_info
                        _psd_log(
                            f"[PSD-视差] 相机适配: {n_adapted} 层跟随 "
                            f"(相机位移={_shift:.3f}, 焦距={_f0:.1f}→{_f1:.1f}mm, "
                            f"画面构图冻结)"
                        )
    except (AttributeError, TypeError, RuntimeError, KeyError, ValueError) as e:
        # 场景更新回调需要静默处理异常以避免阻塞 Blender。
        # ⚠️ 但不能每帧都打印：handler 挂在 depsgraph_update_post，某些异常会被**每帧重抛**
        #    （如老工程缺属性），逐帧 print 会刷屏。故仅在「异常文本变化」或超过节流间隔时记一次。
        if PSD_DEBUG:
            _msg = f"{type(e).__name__}: {e}"
            _now = time.time()
            if (_msg != _handler_err_state["msg"]
                    or _now - _handler_err_state["t"] >= PARALLAX_ADAPT_LOG_INTERVAL):
                _handler_err_state["msg"] = _msg
                _handler_err_state["t"] = _now
                print(f"[PSD视差] handler 异常（已节流）: {_msg}")
