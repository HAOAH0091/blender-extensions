"""PSD Layer Importer PLUS — 共享常量与工具"""

import sys
import site

# ==================== 常量定义 ====================

# 缩放和尺寸相关
MESH_SCALE_FACTOR = 0.01  # Blender 单位缩放因子（将像素转换为Blender单位）
LAYER_Z_OFFSET = 0.01  # 图层之间的Z轴间距

# 文件和缓存相关
MAX_FILENAME_LENGTH = 200  # 文件名最大长度
PNG_COMPRESS_LEVEL = 6  # PNG 压缩级别

# 阈值和容差
TRANSFORM_CHANGE_THRESHOLD = 0.001  # 变换变化检测阈值
MIN_LAYER_SIZE = 1  # 最小图层尺寸（像素）
MIN_DEPTH = 0.001  # 深度计算最小值

# 材质默认值
DEFAULT_ALPHA = 1.0  # 默认透明度（完全不透明）

# UV坐标常量
UV_BOTTOM_LEFT = (0.0, 0.0)
UV_TOP_LEFT = (0.0, 1.0)
UV_TOP_RIGHT = (1.0, 1.0)
UV_BOTTOM_RIGHT = (1.0, 0.0)

# 属性键名
ATTR_LAYER_ID = "layer_identifier"
PSD_DEBUG = True  # 调试开关（设为True可跟踪[PSD图像]全链路日志）
LOG_TO_TEXT = False  # 日志写入文本块开关（由偏好面板控制）
ATTR_LAYER_BBOX = "layer_bbox"
ATTR_INITIAL_TRANSFORM = "initial_transform"
ATTR_PRE_MATCH_TRANSFORM = "pre_match_transform"
ATTR_PARALLAX_LOCKED = "parallax_locked"

# 节点组名称前缀
UV_ADJUST_NODEGROUP_PREFIX = "UV更新_"


def _psd_log(msg: str) -> None:
    """PSD 结构/导入/刷新调试日志，PSD_DEBUG=False 时静默"""
    if PSD_DEBUG:
        print(msg)
    if LOG_TO_TEXT:
        try:
            import bpy
            text = bpy.data.texts.get("_PSD_Importer_Debug_Log")
            if text is None:
                text = bpy.data.texts.new("_PSD_Importer_Debug_Log")
            text.write(msg + "\n")
        except Exception:
            pass


# 将用户站点包路径加入 sys.path（兼容手动安装场景）
user_site_packages = site.getusersitepackages()
if user_site_packages and user_site_packages not in sys.path:
    sys.path.append(user_site_packages)


# 延迟导入依赖
def import_dependencies():
    global PSDImage, Image, ImageOps
    from psd_tools import PSDImage
    from PIL import Image, ImageOps


try:
    import_dependencies()
except ImportError as e:
    print(f"导入错误: {e}")
    print("请确保所有必要的依赖库都已安装。")
