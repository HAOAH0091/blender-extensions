# 调试日志写入文本数据块 — 执行计划

> 版本：v1.1 | 2026-07-11 | 根据审查反馈修订

## 1. 问题回顾

### 当前现状

调试日志通过 `_psd_log()` → `print()` 输出到 Blender System Console。用户遇到刷新问题时，需要手动在终端全选复制日志。如果用户忘记复制就直接关掉 Blender 或转交工程，日志就丢了。工程文件（.blend）里不包含任何日志痕迹。

### 核心矛盾

用户转交问题工程时，无法附带"过程证据"。接收方只能看到结果（图像、材质、checksum 记录），看不到决策链路（skip_image_reload、校验命中、unpack 结果等），排查效率大打折扣。

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|---------|
| Blender 偏好设置增加"日志写入文本块"开关 | P0 | 偏好面板可见，开关默认关闭 |
| 日志同步写入 Blender 文本数据块 | P0 | 每条 `_psd_log` 同时在文本块中追加一行 |
| 文本块随 .blend 保存 | P0 | 保存工程后重新打开，文本块内容完整保留 |
| 每次刷新操作清空旧日志 | P0 | 刷新入口调用时，先清空再写新日志 |
| 不影响终端输出 | P1 | `PSD_DEBUG` 开关独立控制终端输出 |
| 用户删除文本块后自动重建 | P1 | 写日志时检测文本块是否存在，不存在则重建 |

---

## 3. 设计方案

### 核心思路

在 `_psd_log` 函数末尾增加一个可选路径：如果全局开关 `LOG_TO_TEXT` 打开，就把同一条消息追加到 Blender 文本数据块。开关由偏好面板控制。

```
_psd_log(msg)
  ├─ PSD_DEBUG=True  → print(msg)       [终端输出，逻辑不变]
  └─ LOG_TO_TEXT=True → text.write(msg)  [文本块输出，新增]
```

### 关键设计决策

**决策 1：用模块变量而非每帧查偏好**

`_psd_log` 调用频率很高（9 层 PSD 一次刷新 100+ 条日志）。每次查 `bpy.context.preferences.addons[...].preferences.log_to_text` 会有不必要的属性访问开销。改为在偏好面板的回调里修改 `constants.LOG_TO_TEXT` 模块变量，`_psd_log` 直接读模块变量，零额外开销。

**决策 2：两个开关独立**

`PSD_DEBUG` 控制终端输出，`LOG_TO_TEXT` 控制文本块输出。用户可以只开一个、只开另一个、或两个都开。不耦合。

**决策 3：每次刷新操作开始时清空文本块**

在 RefreshLayers / ForceRefreshLayers / RefreshSelectedLayers 的入口处，如果 `LOG_TO_TEXT` 开启，清空文本块。原因：用户转交工程时关心的是"最近一次刷新出了什么问题"，历史日志不需要累积。

**决策 4：文本块名固定为 `_PSD_Importer_Debug_Log`**

下划线前缀表明这是插件内部数据，用户容易识别且不易撞名。不存在时自动创建。

**决策 5：导入操作不清空文本块**

`PSD_OT_ImportLayers` 内的 `_psd_log` 也会写入文本块，但不清空。导入日志会累积到下次刷新被清空。这是刻意行为——保留导入过程的完整日志，供导入阶段的问题排查。

---

## 4. 详细设计

### 4.1 constants.py — 新增模块变量 + 增强 _psd_log

```python
LOG_TO_TEXT = False  # 默认关闭，由偏好面板控制

def _psd_log(msg: str) -> None:
    if PSD_DEBUG:
        print(msg)
    if LOG_TO_TEXT:
        try:
            import bpy
            text = bpy.data.texts.get("_PSD_Importer_Debug_Log")
            if text is None:
                text = bpy.data.texts.new("_PSD_Importer_Debug_Log")
            text.write(msg + "\n")
        except Exception:
            pass  # 日志写入失败不应影响主流程
```

`import bpy` 放在 `_psd_log` 内部而非模块顶部，避免在非 Blender 环境（如 pytest）中导入失败。

### 4.2 PSD_Layer_Importer.py — 新增 AddonPreferences + 偏好面板

```python
from bpy.types import AddonPreferences
from bpy.props import BoolProperty
from . import constants  # 模块对象引用，供 update 回调使用

class PSD_AddonPreferences(AddonPreferences):
    bl_idname = __package__  # "psd_layer_importer_plus"

    log_to_text: BoolProperty(
        name="写入文本块",
        description="将调试日志写入Blender文本数据块（_PSD_Importer_Debug_Log），随.blend文件保存",
        default=False,
        update=lambda self, ctx: (
            setattr(constants, "LOG_TO_TEXT", self.log_to_text)
            if hasattr(constants, "LOG_TO_TEXT") else None
        ),
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "log_to_text")
```

需要同时存在 `from . import constants`（模块对象，供 `setattr` 用）和现有的 `from .constants import (...)`（按名称导入具体符号），二者不冲突。

偏好面板自动出现在 Blender 偏好设置 → 插件 → PSD Layer Importer PLUS 下方。

### 4.3 PSD_Layer_Importer.py — 三个刷新入口加清空逻辑

在每个刷新入口的 `execute` 方法开头（`PSD_OT_RefreshLayers`、`PSD_OT_ForceRefreshLayers`、`PSD_OT_RefreshSelectedLayers`），各加一段：

```python
# 如果启用了日志写入文本块，每次刷新开始时清空
from . import constants
if constants.LOG_TO_TEXT:
    try:
        text = bpy.data.texts.get("_PSD_Importer_Debug_Log")
        if text:
            text.clear()
    except Exception:
        pass
```

放在 `_psd_log("[PSD刷新] >> ...")` 之前，确保清空先于新日志写入。

### 4.4 涉及的文件和改动点

| 文件 | 改动 | 行数 |
|------|------|------|
| `constants.py` | 新增 `LOG_TO_TEXT` 变量；增强 `_psd_log` 增加文本块写入路径 | ~10 行 |
| `PSD_Layer_Importer.py` | 新增 `from . import constants`；新增 `PSD_AddonPreferences` 类；`register()` 中注册；`classes` 元组追加；三个刷新入口各加清空逻辑 | ~30 行 |

### 4.5 不需要改动的部分

- 所有 `_psd_log` 调用点：不需要改动，函数签名不变
- `psd_utils.py`：不需要改动
- `parallax_utils.py`：不需要改动
- UI 面板（`PSD_PT_ImportPanel`）：不需要改动
- 使用说明书：本次不改，功能稳定后再更新

---

## 5. 实现步骤

### 步骤 1：修改 `constants.py`

新增 `LOG_TO_TEXT = False`，修改 `_psd_log` 函数增加文本块写入路径。

### 步骤 2：新增 `AddonPreferences` 类并注册

在 `PSD_Layer_Importer.py` 中新增 `PSD_AddonPreferences` 类和 `from . import constants`，`register()` 中注册，`classes` 元组中追加。

### 步骤 3：三个刷新入口加清空逻辑

在 `PSD_OT_RefreshLayers.execute`、`PSD_OT_ForceRefreshLayers.execute`、`PSD_OT_RefreshSelectedLayers.execute` 的开头各加清空文本块的逻辑。

### 步骤 4：语法检查 + 测试

- `py_compile` 检查语法
- Blender 后台验证插件加载
- 验证偏好面板出现
- 验证开关控制日志写入文本块
- 验证文本块随 .blend 保存
- 验证每次刷新清空文本块

---

## 6. 测试策略

| 场景 | 操作 | 预期 |
|------|------|------|
| 开关默认关闭 | 安装插件后打开偏好设置 | `log_to_text` 为关闭状态 |
| 开启后刷新 | 勾选开关，做一次刷新 | 文本编辑器出现 `_PSD_Importer_Debug_Log`，内容完整 |
| 保存后重开 | 保存 .blend 后重新打开 | 文本块内容保留 |
| 第二次刷新 | 再做一次刷新 | 文本块先被清空，再写入新日志 |
| 手动删除文本块 | 在文本编辑器中关闭 `_PSD_Importer_Debug_Log` | 下次刷新自动重建 |
| 仅终端不写文本块 | 关掉开关，`PSD_DEBUG=True` | 终端有日志，文本块不创建 |
| 仅文本块不终端 | 开开关，`PSD_DEBUG=False` | 终端无日志，文本块有日志 |
| 两个都开 | 都开 | 终端和文本块都有 |
| 强制刷新 | 开开关，点强制刷新 | 文本块清空后写入强制刷新日志 |
| 选中刷新 | 开开关，选图层点刷新 | 文本块清空后写入选中刷新日志 |
| 导入操作 | 开开关，导入新PSD | 文本块有导入日志（不清空），下次刷新清空 |
| 中途关闭再开启 | 开→关→开，中间各刷新 | 只有开关开启期间的刷新写入了文本块 |

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| `bpy` 在非 Blender 环境不可用 | 低 | 低 | `import bpy` 放在 `_psd_log` 内部的 try 中，失败静默 |
| 文本块写入异常导致刷新中断 | 低 | 高 | 整个文本块写入路径用 try/except 包裹，异常只吞不抛 |
| 偏好回调在模块未完全加载时触发 | 低 | 中 | `update` 回调内用 `hasattr` 防御，`constants.LOG_TO_TEXT` 不存在时跳过 |
| 清空文本块异常中断刷新 | 低 | 中 | 清空逻辑包裹 try/except |
| 大量日志导致文本块膨胀 | 低 | 低 | 每次刷新清空，不会无限增长 |
| `__package__` 在非包模式下为空 | 低 | 低 | 插件以包形式安装，`__package__` 一定为 `"psd_layer_importer_plus"` |

---

## 8. 参考

- `constants.py`：`_psd_log` 函数 + `PSD_DEBUG` 变量
- `PSD_Layer_Importer.py`：三个刷新入口 + 现有 `register()` / `classes` 元组
- Blender API 文档：`bpy.types.AddonPreferences`、`bpy.data.texts`

---

*计划版本：v1.1 | 2026-07-11 | 修订依据：审查官反馈*
