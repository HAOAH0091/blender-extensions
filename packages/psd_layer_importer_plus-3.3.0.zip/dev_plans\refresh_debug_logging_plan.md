# 刷新贴图全链路调试日志增强计划

> 版本：v1.2 | 2026-07-11 | 第二轮复审修订

## 1. 问题回顾

### 当前现状

用户反馈：某些情况下，对某个 PSD 图层做刷新操作后，该图层的贴图在 Blender 视口中不更新。用户侧的测试已验证了以下场景不会触发问题：
- 图层名变更
- 新增图层扰乱顺序
- Blender 侧对象重命名
- 图层内容修改 + 序号变化组合

这意味着核心匹配和更新链路在正常工作，问题出在更边缘的场景。

### 三种刷新入口的差异

插件有三个刷新入口，链路细节不同：

| 决策点 | RefreshLayers | ForceRefreshLayers | RefreshSelectedLayers |
|--------|--------------|-------------------|----------------------|
| mtime 检查 | 有，决定是否跳过贴图渲染 | 有，但不影响贴图（force=True） | **无** |
| 全局 checksum 预计算 | 批量渲染全部图层先算 hash | 逐个渲染写入 | **无**，逐个即时渲染 |
| skip_image_reload 决策 | 有 | 无，始终写入 PNG | **无**，直接 force=True |
| force 参数 | 仅 checksum 缺失时为 True | **始终 True** | **始终 True** |
| layer_checksums 更新 | 有 | 有 | **无** |
| 图层提取方式 | 支持层级/扁平 | 支持层级/扁平 | 仅扁平（get_visible_layers） |

### 当前刷新贴图的通用逻辑链路

```
刷新入口
  ├─ [A] mtime 检查（RefreshLayers/ForceRefreshLayers 有，RefreshSelectedLayers 无）
  ├─ [B] 提取图层列表（层级 / 扁平）
  ├─ [C] layer_identifier 匹配现有对象
  ├─ [D] render_layer_rgba → 渲染图层像素
  ├─ [E] checksum 计算与比较 → 决定 skip_image_reload（仅 RefreshLayers）
  ├─ [F] PNG 写入缓存文件
  ├─ [G] update_existing_layer_object
  │     ├─ [G1] 推导 image_name
  │     ├─ [G2] load_or_update_image_from_cache
  │     │     ├─ force 检查
  │     │     ├─ check_packed_image_validity
  │     │     ├─ bpy.data.images 查找 / 创建
  │     │     ├─ unpack → reload
  │     │     └─ pack → 写 checksum
  │     ├─ [G3] apply_uv_adjustment_to_material ← 当前无日志
  │     └─ [G4] remove_uv_adjustment_from_material ← 当前无日志
  ├─ [H] checksum 写入 Record（RefreshLayers/ForceRefreshLayers 有，RefreshSelectedLayers 无）
  └─ [I] 视口显示 ← 材质节点 → 纹理节点 → 图像对象

异常路径（环绕整个循环体）：
  └─ except Exception → 静默吞掉，日志看不出是哪步出错
```

### 核心矛盾

插件在 [G2] 环节更新了 `bpy.data.images` 里的图像对象，但 [I] 环节的材质纹理节点可能引用了不同的图像对象（原因可能是 [G3/G4] 的 UV 调整操作改变了连接、或材质节点被用户手动修改过）。**当前代码在多个关键决策点和全部异常路径都没有日志，无法判断链路在哪一步断裂。**

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|---------|
| 每个决策点都有日志输出 | P0 | 刷新一次后，日志能完整还原从入口到视口显示的每一步决策 |
| 异常路径可追溯 | P0 | 循环体内任何一步抛出异常时，日志记录异常类型和当前步骤 |
| 日志可过滤 | P0 | 所有日志带统一前缀 `[PSD-xxx]`，grep `PSD` 即可全部捕获 |
| 不影响现有功能行为 | P0 | 所有现有测试用例通过，日志仅为观测性代码 |
| 开关可控 | P1 | 复用现有 `PSD_DEBUG` 开关，不引入新的配置项 |
| 用户可自行收集并提交日志 | P1 | 说明文档告诉用户如何开启调试、重现问题、导出日志 |

---

## 3. 设计方案

### 核心思路

不改任何逻辑判断，只在关键决策点插入 `_psd_log()` 调用，输出"当前状态 + 做出的决策 + 影响"。日志标签体系化，让用户和开发者都能快速定位断裂点。

### 标签体系（统一中文格式，grep `PSD` 即可全部捕获）

| 标签 | 覆盖范围 |
|------|---------|
| `[PSD-入口]` | 刷新入口：mtime 检查、选项开关、图层数量、模式（普通/强制/选中） |
| `[PSD-匹配]` | 图层匹配：identifier 查找、existing vs new |
| `[PSD-渲染]` | 图层渲染：topil/composite 结果、图像尺寸、是否失败 |
| `[PSD-校验]` | 校验和：pixel_hash、metadata_hash、expected_checksum、比较结果、skip_image_reload 决策、Record 写入 |
| `[PSD-缓存]` | 缓存文件：PNG 路径、写入结果、文件存在性、文件大小 |
| `[PSD-图像]` | 图像生命周期：bpy.data.images 查找、source 类型、packed 状态、unpack、reload、pack、name 变更（含 Blender 可能的自动加后缀） |
| `[PSD-材质]` | 材质完整性：材质存在性、节点树状态、纹理节点引用、图像引用一致性、UV 调整节点组操作 |
| `[PSD-流程]` | 流程摘要：每个阶段进入/退出，携带关键状态值。异常路径记录 |
| `[PSD-异常]` | 异常捕获：异常类型、异常消息、当前步骤标识 |

### 关键设计决策

1. **复用 `PSD_DEBUG` 开关**：不新增配置项。现有 `PSD_DEBUG` 已控制 `_psd_log`，保持这个机制。

2. **标签统一为 `[PSD-中文]` 格式**：与现有中文标签（`[PSD刷新]`、`[PSD结构]`）视觉风格一致，grep `PSD` 即可捕获全部。避免新旧格式混用导致过滤复杂。

3. **日志内容结构化**：每条日志格式为 `[PSD-xxx] 动作: key=value, key=value`，便于文本工具分析。

4. **材质完整性检查只记录不修复**：在 `update_existing_layer_object` 末尾新增诊断代码，仅读取材质/节点/图像引用状态，发现问题只记日志，不改场景。

5. **异常路径独立日志标签**：所有 try/except 块内的异常用 `[PSD-异常]` 标签，记录"当前步骤 + 异常类型 + 异常消息"，让静默吞掉的异常可见化。

---

## 4. 详细设计

### 4.1 通用埋点表（RefreshLayers / ForceRefreshLayers）

#### 阶段 A：刷新入口（`PSD_OT_RefreshLayers.execute` / `PSD_OT_ForceRefreshLayers.execute`）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| 打开 PSD 后 | 每次 | `[PSD-入口]` | 模式（普通/强制）、filepath、mtime_current、mtime_stored、psd_unchanged 结果 |
| 选项读取后 | 每次 | `[PSD-入口]` | update_texture、update_mesh、update_transform、update_structure 各值 |
| 图层提取后 | 每次 | `[PSD-入口]` | 提取方式（层级/扁平）、图层总数、现有对象数 |

#### 阶段 B：图层匹配（刷新循环内，每个图层一条）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| 进入每个图层处理前 | 每次 | `[PSD-流程]` | 图层名、display_index、image_name、cache_png |
| identifier 查找后 | 每次 | `[PSD-匹配]` | identifier 尾 40 字符、是否找到现有对象、对象名 |
| 新图层路径 | 未找到对象时 | `[PSD-匹配]` | 目标集合名、是否创建新对象 |

#### 阶段 C：图层渲染与校验和（刷新循环内）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| render_layer_rgba 调用后 | 每次 | `[PSD-渲染]` | 图层名、是否成功、图像尺寸、layer 类型相关属性 |
| checksum 计算后 | 每次 | `[PSD-校验]` | pixel_hash 前 20 字符、metadata_hash 前 20 字符、expected_checksum |
| 现有 checksum 查找后 | 每次 | `[PSD-校验]` | 是否找到 Record、旧值前 20 字符、新值前 20 字符 |
| skip_image_reload 决策 | RefreshLayers 时 | `[PSD-校验]` | img_data 是否存在、packed 状态、checksum 对比结果、最终 skip 决策 |
| PNG 写入前后 | 需要写入时 | `[PSD-缓存]` | cache_png 路径、写入结果、写入后文件大小 |

#### 阶段 D：checksum 写入 Record（循环内，update_existing_layer_object 调用后）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| checksum Record 查找后 | 每次 | `[PSD-校验]` | layer.name、是否找到已有 Record、旧 Record 值 |
| checksum Record 写入后 | 每次 | `[PSD-校验]` | 写入的 layer.name、写入的完整值、写入结果 |

#### 阶段 E：异常路径（循环末尾的 except Exception 块内）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| 异常捕获时 | 任意步骤抛出异常 | `[PSD-异常]` | 图层名、异常类型（`type(e).__name__`）、异常消息 |

**实现策略**：把循环体 try 块拆成多个子块（渲染 → checksum → PNG 写入 → update_existing_layer_object → Record 写入），每步独立 catch 并记录 `[PSD-异常] 步骤=xxx, 图层=xxx, 异常=xxx`。外部大 catch 保留做兜底。

#### 阶段 F：图像加载/更新（`load_or_update_image_from_cache`）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| 函数入口 | 每次 | `[PSD-图像]` | image_name, cache_png, force, expected_checksum 有无 |
| force 分支判断 | 每次 | `[PSD-图像]` | force 值、是否跳过校验 |
| check_packed_image_validity | force=False 时 | `[PSD-图像]` | 图像是否存在于 bpy.data.images、packed 状态、存储 checksum、校验结果 |
| bpy.data.images.get 后 | 每次 | `[PSD-图像]` | 查找结果（found/not found）。如果找到：source 类型、packed 状态、users 数量、size |
| unpack 前后 | 有 packed_file 时 | `[PSD-图像]` | unpack 前后状态、method 参数、是否成功 |
| reload 前后 | 每次 | `[PSD-图像]` | filepath_raw 值、reload 结果、reload 后尺寸 |
| 新图像创建 | 未找到或 reload 失败时 | `[PSD-图像]` | 请求的 image_name、实际加载后的 image.name（可能被 Blender 加 .001 后缀）、来源文件 |
| colorspace 设置后 | 每次 | `[PSD-图像]` | 最终 colorspace |
| pack 后 | pack=True 时 | `[PSD-图像]` | pack 是否成功、打包大小 |
| checksum 写入图像属性 | expected_checksum 有值时 | `[PSD-图像]` | 写入的 checksum 值、写入结果 |
| 函数返回前 | 每次 | `[PSD-图像]` | 返回的图像名、实际 image.name（标记是否与请求名一致） |

#### 阶段 G：UV 调整节点组（`apply_uv_adjustment_to_material` / `remove_uv_adjustment_from_material`）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| apply 函数入口 | update_texture=True 且 update_mesh=False 时 | `[PSD-材质]` | scale_x、scale_y、offset_x、offset_y、nodegroup_name |
| 纹理节点查找后 | 每次 | `[PSD-材质]` | 是否找到 TEX_IMAGE 节点 |
| 现有连接检查后 | 每次 | `[PSD-材质]` | Vector 输入有无连接、源节点类型+名 |
| 现有 UV group 检查后 | 每次 | `[PSD-材质]` | 是否已存在、node_tree 是否有效 |
| 节点组创建/更新后 | 每次 | `[PSD-材质]` | nodegroup_name、group_node 位置 |
| 连接操作前后 | 每次 | `[PSD-材质]` | 断开了哪些连接、新建了哪些连接 |
| remove 函数入口 | update_mesh=True 或 UV 无需调整时 | `[PSD-材质]` | nodegroup_name（如有指定） |
| 连接恢复前后 | 每次 | `[PSD-材质]` | 恢复前结构、恢复后结构、是否有残留断链 |

#### 阶段 H：材质完整性检查（`update_existing_layer_object` 末尾新增）

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| 对象材质槽检查 | 每次 | `[PSD-材质]` | 对象名、材质槽数量、第一个材质名 |
| 材质节点树检查 | 有材质时 | `[PSD-材质]` | 材质名、use_nodes、节点总数 |
| 纹理节点查找 | 有节点树时 | `[PSD-材质]` | 找到几个 TEX_IMAGE、每个的图像名、label |
| 图像引用一致性 | 有纹理节点 且 update_texture=True 时 | `[PSD-材质]` | 纹理节点的 image.name vs 本次更新的 image.name 是否一致、不一致时列出差值 |
| 图像引用一致性 | 有纹理节点 且 update_texture=False 时 | `[PSD-材质]` | 仅记录纹理节点当前引用的图像名（无对比对象，因为图像未加载） |
| UV 调整节点组 | 有节点树时 | `[PSD-材质]` | 是否存在 `UV更新_` 前缀的节点组、节点组名 |

### 4.2 RefreshSelectedLayers 专用埋点表

RefreshSelectedLayers 的链路与 RefreshLayers 存在系统性差异（无 mtime 检查、无 checksum 预计算、无 skip 逻辑、始终 force=True、不更新 layer_checksums），需要独立描述。

| 埋点位置 | 条件 | 日志标签 | 记录内容 |
|----------|------|---------|---------|
| 函数入口 | 每次 | `[PSD-入口]` | 模式=选中刷新、选中对象数、对象名列表 |
| 每个选中对象的循环入口 | 每次 | `[PSD-流程]` | 对象名、对象所属集合、找到的 PSD Record |
| PSD Record 查找后 | 每次 | `[PSD-匹配]` | 是否通过集合引用找到、是否通过名称回退找到 |
| PSD 打开后 | 每次 | `[PSD-入口]` | 模式=选中刷新、filepath、（标注：跳过 mtime 检查） |
| 图层匹配 | 每次 | `[PSD-匹配]` | 按 layer_identifier 在 visible_layers 中查找、是否匹配到 |
| render_layer_rgba 后 | 每次 | `[PSD-渲染]` | 同上表 |
| checksum 计算后 | 每次 | `[PSD-校验]` | （标注：仅用于图像属性记录，不做 skip 决策） |
| PNG 强制写入 | 每次 | `[PSD-缓存]` | cache_png 路径、标注"强制写入（force=True）" |
| update_existing_layer_object 调用 | 每次 | `[PSD-流程]` | force=True（标注：始终强制） |
| layer_checksums 更新 | 每次 | `[PSD-校验]` | （标注：跳过，选中刷新不更新 Record） |
| 异常路径 | 每次 | `[PSD-异常]` | 对象名、图层名、异常类型、异常消息 |

### 4.3 涉及的文件

| 文件 | 改动类型 | 说明 |
|------|---------|------|
| `constants.py` | 不改动 | `_psd_log` 和 `PSD_DEBUG` 已存在 |
| `psd_utils.py` | 新增日志 | `render_layer_rgba`、`save_image_png`、`save_layer_to_png_and_checksum`、`check_packed_image_validity`、`load_or_update_image_from_cache` |
| `PSD_Layer_Importer.py` | 新增日志 + 异常路径重构 | 三个刷新入口的循环体、`update_existing_layer_object`（末尾新增材质完整性检查）、`apply_uv_adjustment_to_material`、`remove_uv_adjustment_from_material` |

### 4.4 不需要改动的部分

- 任何现有的逻辑判断和赋值语句
- UI 面板和属性定义
- 视差、相机匹配、混合模式切换等功能
- `create_or_update_mesh_object`（网格创建不涉及贴图更新链路）
- `update_material`、`setup_material_nodes`（仅导入时调用，不在刷新链路内）

### 4.5 日志过滤指南（供用户诊断用）

开启 `PSD_DEBUG = True` 后，在 Blender 终端中可用以下方式过滤日志：

```
# Windows（PowerShell / 命令提示符）
Select-String "PSD" console_output.txt
# 或者：findstr "PSD" console_output.txt

# macOS / Linux
grep "PSD" console_output.txt

# 按标签过滤（各平台通用逻辑，替换命令名即可）：
# 只看贴图更新相关 → grep/Select-String "PSD-图像"
# 只看材质节点状态 → grep/Select-String "PSD-材质"
# 只看校验和决策   → grep/Select-String "PSD-校验"
# 只看异常         → grep/Select-String "PSD-异常"
# 追踪某个特定图层 → grep/Select-String "图层名"
```

---

## 5. 实现步骤

### 步骤 1：在 `psd_utils.py` 中增强所有图像相关函数的日志

**涉及函数**：`render_layer_rgba`、`save_image_png`、`save_layer_to_png_and_checksum`、`check_packed_image_validity`、`load_or_update_image_from_cache`

按阶段 F 的埋点表逐函数添加 `[PSD-渲染]`、`[PSD-缓存]`、`[PSD-校验]`、`[PSD-图像]` 标签日志。特别注意 `load_or_update_image_from_cache` 中新图像创建的 `requested_name vs actual_name` 对比。

### 步骤 2：在 RefreshLayers 和 ForceRefreshLayers 刷新循环中添加日志

**涉及函数**：`PSD_OT_RefreshLayers.execute`、`PSD_OT_ForceRefreshLayers.execute`

按阶段 A~E 的埋点表添加日志。同时把循环体的 try 块拆成子块，在异常路径加 `[PSD-异常]` 日志。

**子块拆分方案**（以 RefreshLayers 为例）：

```python
skip_layer = False

# 子块1：渲染 + checksum
try:
    img = render_layer_rgba(layer)
    pixel_hash = compute_image_md5(img)
    checksum = f"{metadata_hash}_{pixel_hash}"
    _psd_log(f"[PSD-渲染] success: ...")
    _psd_log(f"[PSD-校验] computed: ...")
except Exception as e:
    _psd_log(f"[PSD-异常] 步骤=渲染, 图层={layer.name}, 异常={type(e).__name__}: {e}")
    skip_layer = True

# 子块2：PNG 写入
if not skip_layer:
    try:
        save_image_png(img, cache_png)
        _psd_log(f"[PSD-缓存] written: ...")
    except Exception as e:
        _psd_log(f"[PSD-异常] 步骤=PNG写入, 图层={layer.name}, 异常={type(e).__name__}: {e}")
        skip_layer = True

# 子块3：对象更新
if not skip_layer:
    try:
        update_existing_layer_object(...)
        _psd_log(f"[PSD-流程] updated: ...")
    except Exception as e:
        _psd_log(f"[PSD-异常] 步骤=对象更新, 图层={layer.name}, 异常={type(e).__name__}: {e}")
        skip_layer = True

# 子块4：checksum Record 写入
if not skip_layer:
    try:
        psd_file.layer_checksums...
        _psd_log(f"[PSD-校验] record_written: ...")
    except Exception as e:
        _psd_log(f"[PSD-异常] 步骤=Record写入, 图层={layer.name}, 异常={type(e).__name__}: {e}")
```

**关键约束**：`skip_layer` 标志保证"一步失败 → 后续步跳过"，与原始代码的控制流语义一致。不破坏原有行为。

### 步骤 3：在 `update_existing_layer_object` 末尾新增材质完整性检查

按阶段 H 的埋点表实现。关键条件处理：

- `update_texture=True` 时：做"图像引用一致性"对比（纹理节点 image.name vs 本次更新的 image.name）
- `update_texture=False` 时：仅记录存在性检查（材质是否存在、节点树状态、纹理节点引用内容），不做对比

所有检查用 try/except 包裹，异常只记录 `[PSD-异常]`，不向上抛。

### 步骤 4：在 UV 调整节点组函数中添加日志

**涉及函数**：`apply_uv_adjustment_to_material`、`remove_uv_adjustment_from_material`

按阶段 G 的埋点表实现。记录：当前的连接结构、节点组状态、即将执行的连接操作。

### 步骤 5：在 RefreshSelectedLayers 中添加独立埋点

按 4.2 节的专用埋点表实现。在入口处记录"跳过 mtime 检查"、"始终 force=True"、"不更新 layer_checksums"等关键差异。

### 步骤 6：编写用户诊断指南

在 `使用说明书.md` 的"常见问题"中新增一条，包含：
- 如何开启调试（`constants.py` 改 `PSD_DEBUG = True`）
- 如何查看终端（Window → Toggle System Console）
- 如何导出日志
- 如何用 grep 过滤（引用 4.5 节的过滤示例）

---

## 6. 测试策略

### 测试场景

| 场景 | 操作 | 预期日志关键内容 |
|------|------|-----------------|
| 正常刷新（无变化） | PSD 未修改时点刷新 | `[PSD-入口] psd_unchanged=True` → 贴图链路跳过 |
| 正常刷新（有变化） | 改 PSD 后刷新 | `[PSD-校验]` 校验不一致 → `[PSD-图像]` reload → `[PSD-材质]` 引用一致 |
| 强制刷新 | 点强制刷新 | `[PSD-入口]` 模式=强制 → `[PSD-图像]` force=True |
| 选中刷新 | 选中图层后点刷新 | `[PSD-入口]` 模式=选中刷新 → `[PSD-图像]` force=True |
| 材质缺失 | 手动删除某材质后刷新 | `[PSD-材质]` 报告"无材质" |
| 纹理节点图像被替换 | 手动换纹理节点图像后刷新 | `[PSD-材质]` 报告"图像引用不一致" |
| UV 调整触发 | 只更新贴图不更新网格（图层尺寸变化） | `[PSD-材质]` 记录节点组创建/连接操作 |
| 智能对象图层 | 修改智能对象内容后刷新 | `[PSD-渲染]` 记录渲染结果 → `[PSD-校验]` 对比 hash |
| 刷新时渲染抛出异常 | 模拟图层渲染失败 | `[PSD-异常]` 步骤=渲染, 异常=... |
| 快速连续刷新 | 连续点两次刷新 | `[PSD-入口]` 两次均有完整入口日志 |
| 渲染着色模式下刷新 | 视口切到 Rendered 后刷新 | `[PSD-图像]` reload 后尺寸比对新旧一致 |
| 刷新后保存再打开 | 刷新→保存→重新打开 blend | 图像 packed 状态在 reopened 后仍正确 |
| 0 层 PSD | 导入纯组无可见图层的 PSD 后刷新 | `[PSD-入口]` 图层数为 0，无循环执行 |
| 1 层 PSD | 只有 1 个图层的 PSD | 完整链路执行，无数组越界 |

### 手动测试 Checklist

- [ ] `PSD_DEBUG=False` 时无额外日志输出（性能无影响）
- [ ] `PSD_DEBUG=True` 时正常刷新，每条日志带 `[PSD-xxx]` 标签，grep `PSD` 可全部捕获
- [ ] grep `PSD-异常` 在正常刷新时无输出（只有真正异常时才出现）
- [ ] 日志不包含 Python 异常堆栈（除非真有错误且未被 catch）
- [ ] 刷新后场景状态与不加日志时完全一致
- [ ] 空场景（无 PSD 导入）刷新不崩溃
- [ ] 材质完整性检查在 update_texture=False 时不抛未定义变量异常

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 日志量过大导致终端卡顿 | 中 | 低 | `_psd_log` 本质是 `print()`，Blender 终端缓冲。多图层 PSD 会有数百行日志，在可接受范围内 |
| 材质完整性检查读取材质数据时触发异常 | 低 | 中 | 所有检查用 try/except 包裹，异常只记 `[PSD-异常]`，不向上抛 |
| 子块拆分的 skip 守卫逻辑失效 | 低 | 高 | 每个子块入口都有 `if not skip_layer:` 守卫。代码审查和测试 checklist 覆盖"渲染失败后后续步骤不执行"场景 |
| 日志标签 `[PSD-xxx]` 与旧标签 `[PSDxxx]` 视觉接近但格式不同 | 低 | 低 | 统一 grep `PSD` 即可全部捕获，无需区分新旧 |
| 用户场景无法在本地复现 | 高 | 中 | 这正是本计划要解决的核心问题——通过日志让远程用户收集信息。步骤 6 的诊断指南是关键 |

---

## 8. 后续可选项（不在本次实施范围内）

审查官提出了一个系统性改进建议：三个刷新入口有大量重复的图层遍历逻辑，细节差异散落在各处。如果后续维护成本过高，可以考虑提取一个共享核心函数 `_refresh_layers_core(psd_file, collection, options, force=False)`，把差异参数化。日志埋点只需埋一次。

这是架构优化而非调试需求，本次不改。如果本计划成功定位到 bug 后需要修复，届时一并重构。

---

## 9. 参考

- 当前源码：`F:\desktop\BaiduSyncdisk\addons\psd_layer_importer_plus\PSD_Layer_Importer.py`
- 当前源码：`F:\desktop\BaiduSyncdisk\addons\psd_layer_importer_plus\psd_utils.py`
- 当前源码：`F:\desktop\BaiduSyncdisk\addons\psd_layer_importer_plus\constants.py`
- 使用说明书：`F:\desktop\BaiduSyncdisk\addons\psd_layer_importer_plus\使用说明书.md`
- 审查反馈：2026-07-11，审查官 agent-mpj3kvf3，提出 4 MAJOR + 3 MINOR 问题，本版全部修正

---

*计划版本：v1.2 | 2026-07-11 | 修订依据：第二轮审查反馈*
