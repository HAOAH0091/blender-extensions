"""PSD Layer Importer PLUS — 视差与相机匹配"""
import bpy
import mathutils
import math
from bpy.app.handlers import persistent
from typing import Any, List, Tuple
from .constants import (
    _psd_log, PSD_DEBUG, ATTR_LAYER_ID,
    ATTR_INITIAL_TRANSFORM, ATTR_PRE_MATCH_TRANSFORM,
    TRANSFORM_CHANGE_THRESHOLD, MIN_DEPTH, MESH_SCALE_FACTOR,
    PSDImage,
)

def get_collection_from_record(psd_file: Any) -> Any:
    """
    从PSD文件记录获取集合
    优先使用collection引用，如果无效则回退到名称查找

    Args:
        psd_file: PSDFileRecord对象

    Returns:
        Collection对象或None
    """
    # 优先使用直接引用
    if hasattr(psd_file, "collection") and psd_file.collection is not None:
        return psd_file.collection

    # 回退到名称查找（兼容旧数据）
    base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
    collection = bpy.data.collections.get(base_name)

    # 如果找到了集合，更新引用以便下次使用
    if collection is not None and hasattr(psd_file, "collection"):
        psd_file.collection = collection

    return collection


def get_all_objects_recursive(collection: Any) -> List[Any]:
    """
    递归获取集合及其所有子集合中的对象

    Args:
        collection: Blender集合对象

    Returns:
        包含所有对象的列表
    """
    objects = []

    # 添加当前集合的对象
    for obj in collection.objects:
        objects.append(obj)

    # 递归处理所有子集合
    for child_collection in collection.children:
        objects.extend(get_all_objects_recursive(child_collection))

    return objects


def get_mesh_dimensions(obj: Any) -> Tuple[float, float, float]:
    """从网格顶点获取对象的实际尺寸"""
    try:
        mesh = obj.data
        if mesh and len(mesh.vertices) >= 4:
            # 假设是矩形平面，获取顶点边界
            min_x = min(v.co.x for v in mesh.vertices)
            max_x = max(v.co.x for v in mesh.vertices)
            min_y = min(v.co.y for v in mesh.vertices)
            max_y = max(v.co.y for v in mesh.vertices)
            return (max_x - min_x, max_y - min_y, 1)
    except (AttributeError, TypeError, KeyError, RuntimeError):
        pass
    # 回退到 initial_scale（兼容旧数据）
    return (1, 1, 1)


def match_layers_to_camera(collection, camera, psd_file):
    psd_file.last_camera_transform = str(
        tuple(tuple(row) for row in camera.matrix_world)
    )

    psd = PSDImage.open(psd_file.filepath)
    canvas_box = psd.viewbox
    canvas_width = canvas_box[2] - canvas_box[0]
    canvas_height = canvas_box[3] - canvas_box[1]

    min_point = mathutils.Vector((float("inf"), float("inf"), float("inf")))
    max_point = mathutils.Vector((float("-inf"), float("-inf"), float("-inf")))

    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj:
            # 使用对象的实际位置，而不是 initial_transform
            actual_location = obj.location.copy()
            # 从网格获取实际尺寸
            mesh_dims = get_mesh_dimensions(obj)

            half_width = mesh_dims[0] / 2
            half_height = mesh_dims[1] / 2
            corners = [
                actual_location + mathutils.Vector((x * half_width, y * half_height, 0))
                for x, y in [(-1, -1), (-1, 1), (1, -1), (1, 1)]
            ]

            for corner in corners:
                for i in range(3):
                    min_point[i] = min(min_point[i], corner[i])
                    max_point[i] = max(max_point[i], corner[i])

    if min_point[0] == float("inf"):
        return

    center = mathutils.Vector((0, 0, (min_point.z + max_point.z) / 2))

    camera_pos = camera.matrix_world.translation
    distance = (camera_pos - center).length

    look_at = camera.matrix_world.to_quaternion()
    rotation_matrix = look_at.to_matrix().to_4x4()

    if camera.data.type == "PERSP":
        fov = camera.data.angle
        viewport_width = 2 * distance * math.tan(fov / 2)
        aspect_ratio = (
            bpy.context.scene.render.resolution_x
            / bpy.context.scene.render.resolution_y
        )
        viewport_height = viewport_width / aspect_ratio
    else:
        viewport_width = camera.data.ortho_scale
        viewport_height = viewport_width / (
            bpy.context.scene.render.resolution_x
            / bpy.context.scene.render.resolution_y
        )

    scale_x = viewport_width / (canvas_width * MESH_SCALE_FACTOR)
    scale_y = viewport_height / (canvas_height * MESH_SCALE_FACTOR)
    viewport_scale = max(scale_x, scale_y)

    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj:
            if "pre_match_transform" not in obj:
                obj["pre_match_transform"] = {
                    "matrix_world": [list(row) for row in obj.matrix_world],
                    "scale": list(obj.scale),
                    "rotation_euler": list(obj.rotation_euler),
                    "location": list(obj.location),
                }

            # 使用对象的实际位置计算相对位置
            actual_location = obj.location.copy()
            relative_pos = actual_location - center

            new_pos = camera_pos - rotation_matrix.to_3x3() @ mathutils.Vector(
                (0, 0, distance)
            )
            new_pos += rotation_matrix @ (relative_pos * viewport_scale)

            # 设置位置和旋转
            obj.location = new_pos
            obj.rotation_euler = rotation_matrix.to_euler()

            # 设置缩放（网格已包含实际尺寸，只需统一缩放viewport_scale）
            obj.scale = (viewport_scale, viewport_scale, viewport_scale)


def restore_pre_match_transform(collection):
    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj and "pre_match_transform" in obj:
            pre_match = obj["pre_match_transform"]
            # 重新构造 Matrix 对象
            try:
                obj.matrix_world = mathutils.Matrix(
                    [mathutils.Vector(row) for row in pre_match["matrix_world"]]
                )
            except (AttributeError, TypeError, ValueError, KeyError):
                # 如果 matrix_world 恢复失败，使用分离的属性
                try:
                    obj.scale = mathutils.Vector(pre_match["scale"])
                    obj.rotation_euler = mathutils.Euler(pre_match["rotation_euler"])
                    obj.location = mathutils.Vector(pre_match["location"])
                except (AttributeError, TypeError, ValueError, KeyError):
                    pass
            del obj["pre_match_transform"]


def calculate_camera_sensor_dimensions(camera):
    camera_data = camera.data
    sensor_width = camera_data.sensor_width

    if camera_data.sensor_fit == "VERTICAL":
        sensor_height = sensor_width
        sensor_width = sensor_width / (
            bpy.context.scene.render.resolution_y
            / bpy.context.scene.render.resolution_x
        )
    elif camera_data.sensor_fit == "HORIZONTAL":
        sensor_height = sensor_width * (
            bpy.context.scene.render.resolution_y
            / bpy.context.scene.render.resolution_x
        )
    else:
        render_aspect = (
            bpy.context.scene.render.resolution_x
            / bpy.context.scene.render.resolution_y
        )
        if render_aspect >= 1.0:
            sensor_height = sensor_width / render_aspect
        else:
            sensor_height = sensor_width
            sensor_width = sensor_width * render_aspect

    return sensor_width, sensor_height


def world_to_screen_coords(obj_pos, camera):
    camera_data = camera.data
    focal_length = camera_data.lens
    sensor_width, sensor_height = calculate_camera_sensor_dimensions(camera)

    camera_matrix = camera.matrix_world
    camera_space_pos = camera_matrix.inverted() @ obj_pos

    if camera_space_pos.z < 0:
        depth = abs(camera_space_pos.z)
        screen_x = (camera_space_pos.x * focal_length) / (depth * sensor_width)
        screen_y = (camera_space_pos.y * focal_length) / (depth * sensor_height)
        return screen_x, screen_y, depth
    return 0, 0, 1


def get_object_center_world_pos(obj):
    bbox_corners = [
        obj.matrix_world @ mathutils.Vector(corner) for corner in obj.bound_box
    ]
    center = mathutils.Vector((0, 0, 0))
    for corner in bbox_corners:
        center += corner
    center /= len(bbox_corners)
    return center


def screen_to_world_position(screen_x, screen_y, depth, camera):
    camera_data = camera.data
    focal_length = camera_data.lens
    sensor_width, sensor_height = calculate_camera_sensor_dimensions(camera)

    camera_space_x = (screen_x * depth * sensor_width) / focal_length
    camera_space_y = (screen_y * depth * sensor_height) / focal_length
    camera_space_pos = mathutils.Vector(
        (
            camera_space_x,
            camera_space_y,
            -depth,
        )
    )
    camera_matrix = camera.matrix_world
    world_pos = camera_matrix @ camera_space_pos
    return world_pos


def record_parallax_lock_state(collection, camera):
    camera_matrix = camera.matrix_world.copy()

    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj:
            obj["original_location"] = list(obj.location)
            obj["original_scale"] = list(obj.scale)
            obj["original_rotation"] = list(obj.rotation_euler)

            obj["parallax_camera_name"] = camera.name
            obj["locked_camera_matrix"] = [list(row) for row in camera_matrix]
            obj["locked_camera_focal_length"] = camera.data.lens
            obj["locked_camera_sensor_width"] = camera.data.sensor_width

            sensor_width, sensor_height = calculate_camera_sensor_dimensions(camera)
            obj["locked_camera_sensor_height"] = sensor_height

            obj_center_pos = get_object_center_world_pos(obj)
            screen_x, screen_y, depth = world_to_screen_coords(obj_center_pos, camera)

            center_offset = obj_center_pos - obj.matrix_world.translation
            obj["center_offset"] = list(center_offset)

            obj["locked_screen_x"] = screen_x
            obj["locked_screen_y"] = screen_y
            obj["locked_depth"] = depth
            obj["locked_visual_scale"] = list(obj.scale)

            obj["last_location"] = list(obj.location)
            obj["last_scale"] = list(obj.scale)


def restore_parallax_lock_state(collection):
    for obj in get_all_objects_recursive(collection):
        if ATTR_LAYER_ID in obj:
            parallax_attrs = [
                "original_location",
                "original_scale",
                "original_rotation",
                "parallax_camera_name",
                "locked_camera_matrix",
                "locked_camera_focal_length",
                "locked_camera_sensor_width",
                "locked_camera_sensor_height",
                "locked_screen_x",
                "locked_screen_y",
                "locked_depth",
                "locked_visual_scale",
                "center_offset",
            ]
            for attr in parallax_attrs:
                if attr in obj:
                    del obj[attr]


@persistent
def parallax_scene_update_handler(scene):
    try:
        psd_tool = scene.psd_import_tool
        for psd_file in psd_tool.file_records:
            if psd_file.parallax_locked and psd_file.camera:
                collection = get_collection_from_record(psd_file)
                if not collection:
                    continue

                camera = psd_file.camera
                current_camera_transform = str(camera.matrix_world)
                camera_moved = False
                if psd_file.last_camera_transform != current_camera_transform:
                    try:
                        current_pos = camera.matrix_world.translation
                        if "last_camera_position" not in psd_file:
                            camera_moved = True
                        else:
                            last_pos = mathutils.Vector(
                                psd_file["last_camera_position"]
                            )
                            camera_moved = (
                                current_pos - last_pos
                            ).length > TRANSFORM_CHANGE_THRESHOLD
                        if camera_moved:
                            psd_file["last_camera_position"] = list(current_pos)
                            psd_file.last_camera_transform = current_camera_transform
                    except (AttributeError, TypeError, ValueError, KeyError):
                        camera_moved = True
                        psd_file.last_camera_transform = current_camera_transform

                for obj in get_all_objects_recursive(collection):
                    if ATTR_LAYER_ID in obj and all(
                        key in obj
                        for key in [
                            "original_location",
                            "original_scale",
                            "locked_screen_x",
                            "locked_screen_y",
                            "locked_depth",
                            "center_offset",
                            "locked_camera_sensor_height",
                        ]
                    ):
                        obj_selected = obj.select_get()
                        current_location = list(obj.location)
                        current_scale = list(obj.scale)

                        is_first_detection = "last_location" not in obj
                        if is_first_detection:
                            obj["last_location"] = current_location.copy()
                            obj["last_scale"] = current_scale.copy()
                            obj["last_plugin_location"] = current_location.copy()
                            obj["last_plugin_scale"] = current_scale.copy()

                        last_location = obj["last_location"]
                        last_scale = obj["last_scale"]

                        threshold = TRANSFORM_CHANGE_THRESHOLD
                        transform_changed = any(
                            abs(current_location[i] - last_location[i]) > threshold
                            for i in range(3)
                        ) or any(
                            abs(current_scale[i] - last_scale[i]) > threshold
                            for i in range(3)
                        )

                        update_this_obj = (
                            obj_selected
                            and transform_changed
                            and not is_first_detection
                        )

                        if update_this_obj:
                            original_scale = obj["original_scale"]
                            locked_screen_x = obj["locked_screen_x"]
                            locked_screen_y = obj["locked_screen_y"]
                            locked_depth = obj["locked_depth"]
                            locked_focal_length = obj["locked_camera_focal_length"]
                            locked_sensor_width = obj["locked_camera_sensor_width"]
                            locked_sensor_height = obj["locked_camera_sensor_height"]
                            center_offset = mathutils.Vector(obj["center_offset"])

                            locked_camera_matrix = mathutils.Matrix(
                                [
                                    mathutils.Vector(row)
                                    for row in obj["locked_camera_matrix"]
                                ]
                            )
                            locked_camera_matrix_inv = locked_camera_matrix.inverted()

                            obj_center_pos = get_object_center_world_pos(obj)
                            center_in_cam_space = (
                                locked_camera_matrix_inv @ obj_center_pos
                            )
                            current_depth = max(abs(center_in_cam_space.z), MIN_DEPTH)

                            cam_space_pos = mathutils.Vector(
                                (
                                    locked_screen_x
                                    * current_depth
                                    * locked_sensor_width
                                    / locked_focal_length,
                                    locked_screen_y
                                    * current_depth
                                    * locked_sensor_height
                                    / locked_focal_length,
                                    -current_depth,
                                )
                            )

                            final_center_pos = locked_camera_matrix @ cam_space_pos
                            scale_factor = current_depth / locked_depth

                            scaled_center_offset = center_offset * scale_factor
                            target_origin_pos = final_center_pos - scaled_center_offset

                            obj.location = target_origin_pos
                            obj.scale = mathutils.Vector(original_scale) * scale_factor

                            obj["last_location"] = list(obj.location)
                            obj["last_scale"] = list(obj.scale)
                            obj["last_plugin_location"] = list(obj.location)
                            obj["last_plugin_scale"] = list(obj.scale)
    except (AttributeError, TypeError, RuntimeError, KeyError, ValueError) as e:
        # 场景更新回调需要静默处理异常以避免阻塞Blender
        if PSD_DEBUG:
            print(f"[PSD视差] handler 异常: {e}")


