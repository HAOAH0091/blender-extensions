"""PSD Layer Importer PLUS — PSD解析、缓存、图像加载"""
import bpy
import os
import hashlib
import re
import json
from typing import Optional, Tuple, List, Dict, Any
from .constants import (
    _psd_log, PSD_DEBUG, ATTR_LAYER_ID, ATTR_LAYER_BBOX,
    MESH_SCALE_FACTOR, LAYER_Z_OFFSET, MAX_FILENAME_LENGTH,
    PNG_COMPRESS_LEVEL, MIN_LAYER_SIZE, DEFAULT_ALPHA,
    UV_BOTTOM_LEFT, UV_TOP_LEFT, UV_TOP_RIGHT, UV_BOTTOM_RIGHT,
    ATTR_INITIAL_TRANSFORM, UV_ADJUST_NODEGROUP_PREFIX,
)

def get_visible_layers(psd) -> List[Tuple[int, int, Any, str]]:
    """
    获取PSD文件中所有可见的非组图层

    Args:
        psd: PSDImage对象

    Returns:
        列表，每项为 (原始索引, 显示索引, 图层对象, 图层标识符)
    """
    visible_layers = []
    display_index = 0

    for i, layer in enumerate(psd.descendants()):
        # 跳过组图层（is_group 是方法，需要调用）
        if hasattr(layer, "is_group") and callable(layer.is_group) and layer.is_group():
            continue

        # 跳过不可见图层
        if hasattr(layer, "visible") and not bool(layer.visible):
            continue

        # 跳过尺寸为0的图层
        left, top, right, bottom = _get_layer_bbox(layer)
        if right - left <= MIN_LAYER_SIZE or bottom - top <= MIN_LAYER_SIZE:
            continue

        layer_identifier = create_layer_identifier(layer)
        visible_layers.append((i, display_index, layer, layer_identifier))
        display_index += 1

    return visible_layers


# ---------------- PSD层级结构处理 ----------------


def extract_layer_hierarchy(psd) -> Tuple[List[dict], List[dict]]:
    """
    递归遍历PSD的图层树，提取层级结构。

    Args:
        psd: PSDImage对象

    Returns:
        (tree, flat_list) 元组：
        - tree: 层级树结构，每项为 {"type": "group"/"layer", "name": str, ...}
        - flat_list: 扁平列表，每项为 {
            "layer": PSD图层对象,
            "identifier": str,
            "group_path": List[str],  # 从根到叶的组名称路径，根图层为[]
            "display_index": int,
          }
    """
    _psd_log("[PSD结构] >> extract_layer_hierarchy: 开始提取PSD层级结构")

    display_index = 0  # 全局显示序号（闭包变量，通过 nonlocal 修改）

    def _recursive_build(nodes, group_path):
        """递归构建层级树"""
        nonlocal display_index
        tree_children = []
        path_str = "/".join(group_path) if group_path else "(根目录)"
        for layer in nodes:
            is_group = (
                hasattr(layer, "is_group")
                and callable(layer.is_group)
                and layer.is_group()
            )

            if is_group:
                if hasattr(layer, "visible") and not bool(layer.visible):
                    _psd_log(f"[PSD结构]   - 跳过不可见图层组: {layer.name} (路径: {path_str})")
                    continue

                _psd_log(f"[PSD结构]   - 进入图层组: {layer.name} (路径: {path_str})")
                child_tree = _recursive_build(layer, group_path + [layer.name])
                if not child_tree:
                    _psd_log(f"[PSD结构]   - 跳过空组: {layer.name} (无可见图层)")
                    continue

                _psd_log(f"[PSD结构]   - 组 {layer.name} 包含 {len(child_tree)} 个子项")
                tree_children.append({
                    "type": "group",
                    "name": layer.name,
                    "children": child_tree,
                })
            else:
                if hasattr(layer, "visible") and not bool(layer.visible):
                    _psd_log(f"[PSD结构]   - 跳过不可见图层: {layer.name} (路径: {path_str})")
                    continue
                left, top, right, bottom = _get_layer_bbox(layer)
                if right - left <= MIN_LAYER_SIZE or bottom - top <= MIN_LAYER_SIZE:
                    _psd_log(f"[PSD结构]   - 跳过零尺寸图层: {layer.name} ({right-left}x{bottom-top})")
                    continue

                identifier = create_layer_identifier(layer)
                entry = {
                    "type": "layer",
                    "name": layer.name,
                    "layer": layer,
                    "identifier": identifier,
                    "group_path": list(group_path),
                    "display_index": display_index,
                }
                _psd_log(f"[PSD结构]   - 图层 #{display_index}: {layer.name} (路径: {path_str}, id: {identifier[-40:]}...)")
                tree_children.append(entry)
                display_index += 1

        return tree_children

    # psd 本身是可迭代的（根级图层列表）
    tree = _recursive_build(psd, [])
    _psd_log(f"[PSD结构] << extract_layer_hierarchy: 树构建完成，共 {display_index} 个可见图层")

    # 从树中提取扁平列表
    flat_list = []

    def _flatten(branch, out_list):
        for item in branch:
            if item["type"] == "layer":
                out_list.append(item)
            elif item["type"] == "group":
                _flatten(item["children"], out_list)

    _flatten(tree, flat_list)
    _psd_log(f"[PSD结构] << extract_layer_hierarchy: 扁平列表 {len(flat_list)} 项，层级树 {len(tree)} 个根级条目")

    return tree, flat_list


def ensure_collection_tree(
    parent_collection, hierarchy_tree, base_name
) -> None:
    """
    根据层级树，在 parent_collection 下递归创建子集合。
    对于已存在的同名集合，直接复用。

    Args:
        parent_collection: 父级Blender集合
        hierarchy_tree: extract_layer_hierarchy 返回的 tree
        base_name: PSD文件名（用于集合名前缀，避免同名冲突）
    """
    _psd_log(f"[PSD结构] >> ensure_collection_tree: 在集合 '{parent_collection.name}' 下构建层级树")
    created_count = 0
    reused_count = 0

    def _build(branch, current_collection, depth=0):
        nonlocal created_count, reused_count
        indent = "  " * depth
        for item in branch:
            if item["type"] == "group":
                # 创建或查找同名子集合
                # 安全说明：只遍历 children（不修改），找到后才 link，不会触发迭代时修改异常
                group_col = None
                for child in current_collection.children:
                    if child.name == item["name"]:
                        group_col = child
                        break
                if group_col is None:
                    group_col = bpy.data.collections.new(item["name"])
                    current_collection.children.link(group_col)
                    created_count += 1
                    _psd_log(f"[PSD结构] {indent}创建集合 '{item['name']}'")
                else:
                    reused_count += 1
                    _psd_log(f"[PSD结构] {indent}复用集合 '{item['name']}'")
                _build(item["children"], group_col, depth + 1)
            # layer 类型不需要在这里处理，由导入循环负责创建对象并放入正确集合

    _build(hierarchy_tree, parent_collection)
    _psd_log(f"[PSD结构] << ensure_collection_tree: 创建 {created_count} 个集合，复用 {reused_count} 个集合")


def find_layer_object_in_tree(
    collection, layer_identifier: str
) -> Optional[Any]:
    """
    在集合树中递归查找指定标识符的图层对象。

    Args:
        collection: 起始集合
        layer_identifier: 图层唯一标识符

    Returns:
        找到的Blender对象，或None
    """
    _psd_log(f"[PSD结构] find_layer_object_in_tree: 在集合 '{collection.name}' 中查找 id={layer_identifier[-40:]}...")
    for obj in collection.objects:
        if obj.get(ATTR_LAYER_ID) == layer_identifier:
            _psd_log(f"[PSD结构] find_layer_object_in_tree: 找到对象 '{obj.name}'")
            return obj
    for child_collection in collection.children:
        result = find_layer_object_in_tree(child_collection, layer_identifier)
        if result is not None:
            return result
    _psd_log(f"[PSD结构] find_layer_object_in_tree: 未找到 id={layer_identifier[-40:]}...")
    return None


def serialize_hierarchy_snapshot(hierarchy_tree) -> str:
    """
    将层级树序列化为JSON字符串，用于存储快照。
    只保留结构信息（组路径），不保留图层细节。

    Args:
        hierarchy_tree: extract_layer_hierarchy 返回的 tree

    Returns:
        JSON字符串
    """
    paths = []

    def _collect_paths(branch, current_path):
        for item in branch:
            if item["type"] == "group":
                path = current_path + [item["name"]]
                paths.append("/".join(path))
                _collect_paths(item["children"], path)

    _collect_paths(hierarchy_tree, [])
    snapshot = json.dumps(paths, ensure_ascii=False, sort_keys=True)
    _psd_log(f"[PSD结构] serialize_hierarchy_snapshot: 快照路径数={len(paths)}, 内容={snapshot[:200]}")
    return snapshot


def get_target_collection_for_layer(
    parent_collection, group_path
) -> Any:
    """
    根据 group_path 获取图层对象应该放入的目标集合。
    路径上的每个组都会查找或创建对应的Blender子集合。

    Args:
        parent_collection: PSD主集合
        group_path: 组路径列表（可能为空）

    Returns:
        目标Blender集合
    """
    if not group_path:
        _psd_log(f"[PSD结构] get_target_collection_for_layer: 根图层 -> 集合 '{parent_collection.name}'")
        return parent_collection
    current = parent_collection
    path_so_far = parent_collection.name
    for group_name in group_path:
        found = None
        for child in current.children:
            if child.name == group_name:
                found = child
                break
        if found is None:
            found = bpy.data.collections.new(group_name)
            current.children.link(found)
            _psd_log(f"[PSD结构] get_target_collection_for_layer: 创建集合 '{group_name}' (路径: {path_so_far}/{group_name})")
        else:
            _psd_log(f"[PSD结构] get_target_collection_for_layer: 复用集合 '{group_name}' (路径: {path_so_far}/{group_name})")
        current = found
        path_so_far = f"{path_so_far}/{group_name}"
    return current


def sync_collection_structure(
    psd, psd_file, parent_collection, base_name
) -> Tuple[dict, List[dict]]:
    """
    刷新时同步集合结构：对比当前PSD的层级与存储的快照，
    按需创建/删除集合，移动对象。
    此函数内部调用 extract_layer_hierarchy，调用方无需重复提取。

    Args:
        psd: PSDImage对象
        psd_file: PSDFileRecord
        parent_collection: PSD主集合
        base_name: PSD文件名

    Returns:
        (id_to_path, flat_list) 元组：
        - id_to_path: {layer_identifier: group_path} 映射
        - flat_list: 包含所有图层的扁平列表
    """
    _psd_log(f"[PSD结构] >> sync_collection_structure: 开始同步集合结构 (集合: '{parent_collection.name}')")

    # 读取旧快照
    old_snapshot = psd_file.group_hierarchy if psd_file.group_hierarchy else "[]"
    _psd_log(f"[PSD结构] sync_collection_structure: 旧快照 = {old_snapshot[:200]}")

    # 提取当前PSD的层级结构（只做一次）
    hierarchy_tree, flat_list = extract_layer_hierarchy(psd)
    new_snapshot = serialize_hierarchy_snapshot(hierarchy_tree)
    _psd_log(f"[PSD结构] sync_collection_structure: 新快照 = {new_snapshot[:200]}")

    # 对比快照，判断结构是否变化
    if old_snapshot == new_snapshot:
        _psd_log(f"[PSD结构] sync_collection_structure: 结构未变化，跳过重建")
    else:
        _psd_log(f"[PSD结构] sync_collection_structure: 结构已变化，重建集合树")
        ensure_collection_tree(parent_collection, hierarchy_tree, base_name)

    # 构建 {identifier: group_path} 映射
    id_to_path = {}
    for entry in flat_list:
        id_to_path[entry["identifier"]] = entry["group_path"]
    _psd_log(f"[PSD结构] sync_collection_structure: 映射了 {len(id_to_path)} 个图层到对应集合")

    # 更新快照
    psd_file.group_hierarchy = new_snapshot
    _psd_log(f"[PSD结构] << sync_collection_structure: 完成")

    return id_to_path, flat_list


def move_layer_object_to_collection(obj, target_collection) -> bool:
    """
    将对象从当前集合移到目标集合。
    如果已在目标集合中，不做任何操作。

    Returns:
        bool: 是否执行了移动
    """
    if not obj or not target_collection:
        _psd_log(f"[PSD结构] move_layer_object_to_collection: 跳过移动（obj={obj}, target={target_collection}）")
        return False

    old_cols = [c.name for c in obj.users_collection]

    # 检查是否已经在目标集合中
    if obj.name in target_collection.objects:
        _psd_log(f"[PSD结构] move_layer_object_to_collection: '{obj.name}' 已在集合 '{target_collection.name}' 中，无需移动")
        return False

    # 从所有当前集合中移除
    for col in list(obj.users_collection):
        col.objects.unlink(obj)

    # 链接到目标集合
    target_collection.objects.link(obj)
    _psd_log(f"[PSD结构] move_layer_object_to_collection: '{obj.name}' 从 {old_cols} -> '{target_collection.name}'")
    return True


# ---------------- 性能优化：缓存与并行 ----------------


def sanitize_filename(name: str) -> str:
    """
    将字符串转换为安全的文件名

    移除非字母数字字符（保留下划线、连字符和点），
    并截断到最大文件名长度。

    Args:
        name: 原始字符串

    Returns:
        安全的文件名
    """
    safe = re.sub(r"[^\w\-\.]+", "_", name)
    return safe[:MAX_FILENAME_LENGTH]


def get_cache_root() -> str:
    """
    获取PSD缓存根目录路径

    如果Blender项目已保存，使用项目目录下的psd_cache文件夹；
    否则使用系统临时目录。

    Returns:
        缓存根目录的绝对路径
    """
    try:
        # 获取当前Blender项目文件路径
        blend_filepath = bpy.data.filepath
        if blend_filepath:
            # 如果项目已保存，使用项目文件所在目录下的psd_cache子目录
            project_dir = os.path.dirname(blend_filepath)
            cache_root = os.path.join(project_dir, "psd_cache")
        else:
            # 如果项目未保存，使用临时目录
            import tempfile

            temp_dir = tempfile.gettempdir()
            cache_root = os.path.join(temp_dir, "blender_psd_cache")
    except (OSError, IOError):
        # 备选方案：使用临时目录
        import tempfile

        temp_dir = tempfile.gettempdir()
        cache_root = os.path.join(temp_dir, "blender_psd_cache")

    os.makedirs(cache_root, exist_ok=True)
    return cache_root


def get_cache_png_path(
    psd_filepath: str, index: int, layer_identifier: str, layer_name: str
) -> str:
    """
    生成图层缓存PNG文件的完整路径

    Args:
        psd_filepath: PSD文件路径
        index: 图层序号（用于排序）
        layer_identifier: 图层唯一标识符
        layer_name: 图层名称

    Returns:
        缓存PNG文件的完整路径
    """
    base = bpy.path.display_name_from_filepath(psd_filepath)
    folder = os.path.join(get_cache_root(), sanitize_filename(base))
    os.makedirs(folder, exist_ok=True)
    filename = f"{index:05d}_{sanitize_filename(layer_identifier)}_{sanitize_filename(layer_name)}.png"
    return os.path.join(folder, filename)


def cleanup_cache_files(psd_filepath: str) -> bool:
    """
    清理指定PSD文件的外部缓存文件和文件夹

    Args:
        psd_filepath: PSD文件路径

    Returns:
        bool: 清理是否成功
    """
    try:
        # 获取PSD文件对应的缓存文件夹
        base = bpy.path.display_name_from_filepath(psd_filepath)
        cache_folder = os.path.join(get_cache_root(), sanitize_filename(base))

        # 检查缓存文件夹是否存在
        if not os.path.exists(cache_folder):
            return True  # 文件夹不存在，认为清理成功

        # 安全检查：确保这是一个缓存文件夹
        cache_root = get_cache_root()
        if not cache_folder.startswith(cache_root):
            print(f"警告：缓存文件夹路径不安全，跳过清理: {cache_folder}")
            return False

        # 删除文件夹中的所有PNG文件
        deleted_files = 0
        for filename in os.listdir(cache_folder):
            if filename.lower().endswith(".png"):
                file_path = os.path.join(cache_folder, filename)
                try:
                    os.remove(file_path)
                    deleted_files += 1
                except Exception as e:
                    print(f"删除缓存文件失败: {file_path}, 错误: {e}")

        # 检查文件夹是否为空，如果为空则删除文件夹
        try:
            remaining_files = os.listdir(cache_folder)
            if not remaining_files:
                os.rmdir(cache_folder)
                print(
                    f"已清理PSD缓存文件夹: {cache_folder} (删除了 {deleted_files} 个文件)"
                )
            else:
                print(
                    f"已清理PSD缓存文件: {deleted_files} 个，文件夹仍有其他文件: {cache_folder}"
                )
        except Exception as e:
            print(f"删除缓存文件夹失败: {cache_folder}, 错误: {e}")

        return True

    except (OSError, IOError, PermissionError) as e:
        print(f"清理缓存文件时发生错误: {e}")
        return False


def _get_layer_bbox(layer: Any) -> Tuple[int, int, int, int]:
    try:
        left, top, right, bottom = (
            int(layer.left),
            int(layer.top),
            int(layer.right),
            int(layer.bottom),
        )
    except (AttributeError, TypeError, ValueError):
        try:
            # 兼容 psd_tools 的 bbox 接口
            b = layer.bbox
            left, top, right, bottom = int(b.x1), int(b.y1), int(b.x2), int(b.y2)
        except (AttributeError, TypeError):
            left = top = 0
            right = int(getattr(layer, "width", 0))
            bottom = int(getattr(layer, "height", 0))
    return left, top, right, bottom


def render_layer_rgba(layer: Any) -> Optional[Any]:
    try:
        try:
            img = layer.topil()
        except (AttributeError, NotImplementedError):
            img = layer.composite()
        if img.mode != "RGBA":
            img = img.convert("RGBA")
        # 基于图层边界裁剪到画布区域尺寸
        l, t, r, b = _get_layer_bbox(layer)
        bbox_w, bbox_h = max(r - l, 0), max(b - t, 0)
        try:
            if (
                bbox_w > 0
                and bbox_h > 0
                and (img.size[0] != bbox_w or img.size[1] != bbox_h)
            ):
                img = img.crop((l, t, r, b))
        except (OSError, IOError, ValueError):
            pass

        # Alpha边缘清理：将透明像素RGB设为黑，避免白边
        try:
            import numpy as np

            img_array = np.array(img)
            alpha_channel = img_array[:, :, 3]
            transparent_mask = alpha_channel == 0
            img_array[transparent_mask, 0:3] = 0
            from PIL import Image

            img = Image.fromarray(img_array, "RGBA")
            _psd_log(f"[PSD-渲染] Alpha清理(numpy): 图层='{layer.name}'")
        except ImportError:
            try:
                pixels = img.load()
                width, height = img.size
                for y in range(height):
                    for x in range(width):
                        r, g, b, a = pixels[x, y]
                        if a == 0:
                            pixels[x, y] = (0, 0, 0, 0)
                _psd_log(f"[PSD-渲染] Alpha清理(像素循环): 图层='{layer.name}'")
            except (AttributeError, TypeError):
                _psd_log(f"[PSD-渲染] Alpha清理跳过(不可用): 图层='{layer.name}'")
                pass
        _psd_log(f"[PSD-渲染] << 渲染成功: 图层='{layer.name}', 尺寸={img.size[0]}x{img.size[1]}")
        return img
    except (OSError, IOError, ValueError, AttributeError) as e:
        _psd_log(f"[PSD-渲染] << 渲染失败: 图层='{layer.name}', 异常={type(e).__name__}: {e}")
        return None


def compute_image_md5(img: Any) -> str:
    try:
        return hashlib.md5(img.tobytes()).hexdigest()
    except (OSError, IOError, ValueError, AttributeError):
        return ""


def save_image_png(img: Any, target_png_path: str) -> None:
    _psd_log(f"[PSD-缓存] >> save_image_png: path='{target_png_path}'")
    try:
        os.makedirs(os.path.dirname(target_png_path), exist_ok=True)
    except (OSError, IOError) as e:
        _psd_log(f"[PSD-缓存] 创建缓存目录失败: '{target_png_path}', 异常={type(e).__name__}: {e}")
        raise
    try:
        img.save(target_png_path, format="PNG", compress_level=PNG_COMPRESS_LEVEL)
        file_size = os.path.getsize(target_png_path) if os.path.exists(target_png_path) else -1
        _psd_log(f"[PSD-缓存] << PNG写入成功: path='{target_png_path}', size={file_size} bytes")
    except (OSError, IOError, ValueError) as e:
        _psd_log(f"[PSD-缓存] compress_level={PNG_COMPRESS_LEVEL} 写入失败: {e}，尝试无压缩写入")
        try:
            img.save(target_png_path, format="PNG")
            file_size = os.path.getsize(target_png_path) if os.path.exists(target_png_path) else -1
            _psd_log(f"[PSD-缓存] << PNG回退写入成功: path='{target_png_path}', size={file_size} bytes")
        except Exception as e2:
            _psd_log(f"[PSD-缓存] << PNG写入完全失败: path='{target_png_path}', 异常={type(e2).__name__}: {e2}")


def save_layer_to_png_and_checksum(layer: Any, target_png_path: str) -> str:
    _psd_log(f"[PSD-缓存] >> save_layer_to_png_and_checksum: 图层='{layer.name}', path='{target_png_path}'")
    try:
        img = render_layer_rgba(layer)
        if img is None:
            _psd_log(f"[PSD-缓存] << 渲染返回None，跳过PNG写入: 图层='{layer.name}'")
            return ""
        save_image_png(img, target_png_path)
        checksum = compute_image_md5(img)
        _psd_log(f"[PSD-校验] save_layer: 图层='{layer.name}', pixel_hash={checksum[:20] if checksum else '(空)'}...")
        return checksum
    except (OSError, IOError, ValueError, AttributeError) as e:
        _psd_log(f"[PSD-缓存] << 异常: 图层='{layer.name}', 异常={type(e).__name__}: {e}")
        return ""


def check_packed_image_validity(
    image_name: str, expected_checksum: Optional[str] = None
) -> Tuple[bool, Any]:
    """
    检查Blender中是否已存在有效的已打包图像；
    当提供期望校验和时，仅当与图像上记录的校验和一致才视为有效。
    """
    _psd_log(f"[PSD-图像] check_packed_image_validity: image='{image_name}', expected_checksum={'有' if expected_checksum else '无'}")
    image = bpy.data.images.get(image_name)
    if image is None:
        _psd_log(f"[PSD-图像] 图像不存在 bpy.data.images 中: '{image_name}' → 需创建")
        return False, None

    # 若图像已打包但没有校验和可比较，无法判定有效性，需重新加载
    if image.packed_file is not None and not expected_checksum:
        _psd_log(f"[PSD-图像] 已打包但无校验和: '{image_name}' → 强制重载")
        return False, None

    # 当提供了期望校验和时，用自定义属性进行快速比较
    if image.packed_file is not None and expected_checksum:
        try:
            stored = image.get("checksum")
            if stored and stored == expected_checksum:
                _psd_log(f"[PSD-图像] << 校验命中: '{image_name}' 校验一致，跳过重载")
                return True, image
            _psd_log(f"[PSD-图像] 校验失效: '{image_name}', 存储={stored[:20] if stored else 'None'}... != 期望={expected_checksum[:20]}...")
            return False, None
        except (AttributeError, KeyError, TypeError):
            return False, None

    # 未打包或无法校验，走重新加载路径
    _psd_log(f"[PSD-图像] 未打包或无法校验: '{image_name}' → 需从文件加载")
    return False, None


def load_or_update_image_from_cache(
    image_name: str,
    cache_png: str,
    pack: bool = True,
    expected_checksum: Optional[str] = None,
    force: bool = False,
) -> Any:
    _psd_log(f"[PSD-图像] >> load_or_update_image_from_cache: image='{image_name}', cache='{os.path.basename(cache_png)}', force={force}, pack={pack}, checksum={'有' if expected_checksum else '无'}")

    # 优先检查是否已存在且校验一致的打包图像
    if not force:
        _psd_log(f"[PSD-图像] force=False，执行校验检查")
        is_valid, existing_image = check_packed_image_validity(
            image_name, expected_checksum
        )
        if is_valid and existing_image:
            _psd_log(f"[PSD-图像] << 校验命中，跳过重载: '{image_name}'")
            try:
                existing_image.colorspace_settings.name = "sRGB"
            except (AttributeError, TypeError, RuntimeError):
                pass
            return existing_image
        _psd_log(f"[PSD-图像] 校验未命中，将重新加载")
    else:
        _psd_log(f"[PSD-图像] force=True，跳过校验检查")

    # 无效或未命中校验，重新从缓存加载
    image = bpy.data.images.get(image_name)
    if image is None:
        _psd_log(f"[PSD-图像] bpy.data.images 中未找到 '{image_name}'，从文件新建")
        image = bpy.data.images.load(cache_png, check_existing=True)
        _psd_log(f"[PSD-图像] load 后 name='{image.name}', requested='{image_name}', size={image.size[0]}x{image.size[1]}")
        image.name = image_name
        _psd_log(f"[PSD-图像] 设置 name 后: actual_name='{image.name}', 匹配={'是' if image.name == image_name else '否(可能有.001后缀)'}")
    else:
        _psd_log(f"[PSD-图像] bpy.data.images 中找到 '{image_name}': source={image.source}, packed={'是' if image.packed_file else '否'}, users={image.users}, size={image.size[0]}x{image.size[1]}")
        image.filepath_raw = cache_png
        _psd_log(f"[PSD-图像] 设置 filepath_raw='{cache_png}'")
        if image.packed_file is not None:
            _psd_log(f"[PSD-图像] 解除打包: '{image_name}'")
            try:
                image.unpack(method='REMOVE')
                image.source = 'FILE'
                _psd_log(f"[PSD-图像] unpack 成功: source={image.source}, packed={'是' if image.packed_file else '否'}")
            except Exception as e:
                _psd_log(f"[PSD-图像] unpack 失败: '{image_name}', 异常={type(e).__name__}: {e}")
        else:
            _psd_log(f"[PSD-图像] 图像未打包，直接 reload")
        try:
            image.reload()
            _psd_log(f"[PSD-图像] reload() 成功: '{image.name}', size={image.size[0]}x{image.size[1]}")
        except (AttributeError, RuntimeError, OSError, IOError) as e:
            _psd_log(f"[PSD-图像] reload() 失败: '{image_name}', 异常={type(e).__name__}: {e}，重新创建")
            image = bpy.data.images.load(cache_png, check_existing=True)
            image.name = image_name
            _psd_log(f"[PSD-图像] 重新创建后: name='{image.name}', size={image.size[0]}x{image.size[1]}")

    # 关键：确保使用sRGB色彩空间（避免单色/灰阶问题）
    try:
        image.colorspace_settings.name = "sRGB"
        _psd_log(f"[PSD-图像] colorspace=sRGB: '{image.name}'")
    except (AttributeError, TypeError, RuntimeError) as e:
        _psd_log(f"[PSD-图像] colorspace 设置失败: '{image.name}', 异常={type(e).__name__}")

    if pack:
        try:
            image.pack()
            packed_size = len(image.packed_file.data) if image.packed_file else 0
            _psd_log(f"[PSD-图像] pack() 完成: '{image.name}', size={packed_size} bytes")
        except (AttributeError, TypeError, RuntimeError) as e:
            _psd_log(f"[PSD-图像] pack() 失败: '{image.name}', 异常={type(e).__name__}")

    # 记录校验和，以便后续刷新比对
    try:
        if expected_checksum:
            image["checksum"] = expected_checksum
            _psd_log(f"[PSD-图像] checksum 已写入图像属性: '{image.name}' = {expected_checksum[:20]}...")
    except (TypeError, KeyError, RuntimeError) as e:
        _psd_log(f"[PSD-图像] checksum 写入失败: '{image.name}', 异常={type(e).__name__}")

    _psd_log(f"[PSD-图像] << 返回: name='{image.name}', size={image.size[0]}x{image.size[1]}, users={image.users}")
    return image


def create_layer_identifier(layer: Any) -> str:
    return str(layer.layer_id)