# -*- coding: utf-8 -*-
"""双击三角手柄 ⇒ 复制【同关键帧另一个三角】的速度值。

⚠️⚠️ 2026-09-18 语义升级说明（用户新需求，见 tests/gui_tri_lock_check.py）
----------------------------------------------------------------------
双击的**主语义**已从"复制值"升级为"**切换一体 / 分离**"：
    · 一体（默认）双击 ⇒ 分离
    · 分离双击       ⇒ 锁回一体 + **把对侧值同步到被双击的三角**（= 本文件测的"复制"）

⇒ 本文件保留，作为**"复制值"这条底层逻辑**的回归；
   双击**入口**的行为断言（C2/C3）已按新语义重写（见文件内 C2'/C3'）。
   "复制"这件事本身仍然被测（B 组直接调 `_copy_speed_value`，不受入口语义影响）。

需求原文
--------
    "当用户双击三角手柄时，可以把当前双击的三角手柄所负责速度分布值
     改为同关键帧的另外一个三角手柄相同的值"

数据模型（handles.py）
---------------------
每个关键帧有**两个**速度三角：

        ▼ up    （在关键帧上方）→ 负责【左段】（上一关键帧 → 本关键帧）
        ▲ down  （在关键帧下方）→ 负责【右段】（本关键帧 → 下一关键帧）

⇒ "另一个三角" = **相反的那个**（up ↔ down）。

关键设计决定
------------
1. **复制的是归一化值 `s`（= 该侧 dt/span），不是像素量 `d`**
   —— 界面显示的倍数 = `S_LIN / s`，只与 `s` 有关
     ⇒ 复制 `s` 后两边**显示倍数完全一致**（与两侧 span 是否相等无关）。
     若复制 `d`，两侧 span 不同时倍数会不一样。
2. **双击用【时间 + 位置】自判，不用 `event.value == 'DOUBLE_CLICK'`**
   —— 后者由 Blender 事件系统按 keymap 生成，常驻 modal 里能否收到**不确定**；
     而双击本来就是两个**可测量**的量 ⇒ 自判：行为确定、可复现、可 headless 测试。
3. **端点是正常边界**：首帧的左段 / 末帧的右段**没有三角**
   （`collect_handles` 不生成）⇒ 双击那里得到"无可复制"，**不是错误**。

本测试
------
A 组：双击判定（纯逻辑，时间/位置/阈值全注入 ⇒ 不必真等时间）
B 组：复制动作（值真的被写过去 + 倍数一致 + 边界 + 不互相覆盖）
C 组：入口 `try_copy_other_speed_click`（点空白断链 / 双击消费 / 消息）
D 组：静态契约（modal 里接了 + 函数存在）
E 组：bug 注入必须被抓
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, interaction as it
from RealTimeMotionPath import time_domain as td, handles as hd
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_dblclick_copy_result.json")
steps = []

KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))
F0, FM, F1 = 1.0, 25.0, 55.0
UP, DOWN = hd.TRI_UP, hd.TRI_DOWN          # up→左段, down→右段


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:900]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


def build(name):
    sc = bpy.context.scene
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in KFS:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(1)
    a = o.animation_data.action
    for c in xf._position_curves(a, o, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        c.update()
    bpy.context.view_layer.objects.active = o
    for ob in bpy.data.objects:
        ob.select_set(ob is o)
    return o, a


def read_s(o, frame, side):
    """★ **独立口径**：直接从 F-Curve 读时间分量、自己算 span。

    刻意**不调产品函数**（`td.read_s` / `it._read_side_s`）——
    否则产品里读法错了，测试也会跟着错（"用自己的尺子量自己的尺子"）。
    这里只依赖最原始的定义：`s = |手柄时间分量 − 关键帧帧号| / 相邻帧跨度`。
    """
    act = o.animation_data.action
    cs = {c.array_index: c for c in xf._position_curves(act, o, None)}
    if not cs:
        return None
    frames = sorted({float(k.co[0]) for c in cs.values() for k in c.keyframe_points})
    f = float(frame)
    if f not in frames:
        return None
    i = frames.index(f)
    kp = None
    for k in cs[0].keyframe_points:
        if abs(k.co[0] - f) < 1e-3:
            kp = k
            break
    if kp is None:
        return None
    if side == 'left':
        if i == 0:
            return None                      # 端点段：无相邻关键帧
        span = frames[i] - frames[i - 1]
        dt = abs(float(kp.co[0]) - float(kp.handle_left[0]))
    else:
        if i == len(frames) - 1:
            return None
        span = frames[i + 1] - frames[i]
        dt = abs(float(kp.handle_right[0]) - float(kp.co[0]))
    return dt / span if span > 1e-9 else None


def write_s(o, frame, side, s):
    """写某帧某侧的 s（走真实写入通路 `_apply_speed_d`）。"""
    return it._apply_speed_d(bpy.context, o, float(frame), side,
                             td.s_to_d(float(s)))


def ratio(s):
    return hd.ratio_of(s, td.S_LIN)


def mk_handles(frame, tri_list=(UP, DOWN), kf_screen=(100.0, 100.0)):
    out = []
    for t in tri_list:
        out.append(hd.make_handle(frame=float(frame), tri=t, span=24.0,
                                  s=td.S_LIN, d=td.CV_MID,
                                  kf_screen=kf_screen, kf_world=(0.0, 0.0, 0.0)))
    return out


def tri_screen_of(handle):
    return handle['tri_screen']


def reset_click():
    _session.speed_click_info = None


# ================================================================ A 组：双击判定
try:
    reset_click()
    T0 = 1000.0
    W = 0.35
    R = it.SPEED_TRI_PICK_RADIUS
    P = (200.0, 200.0)

    step("A0 起点：无上次点击记录 ⇒ 第一次点击不算双击",
         it.speed_double_click_hit(FM, UP, P, now=T0, window=W, radius=R) is False,
         "")

    # A1：同一三角 + 时间窗内 + 位置近 ⇒ 双击
    reset_click()
    it.speed_double_click_hit(FM, UP, P, now=T0, window=W, radius=R)
    hit1 = it.speed_double_click_hit(FM, UP, P, now=T0 + 0.1, window=W, radius=R)
    step("A1 ★★★ 同三角 + 窗内 + 位置近 ⇒ 判为双击", hit1 is True, "")

    # A2：超时间窗 ⇒ 不算
    reset_click()
    it.speed_double_click_hit(FM, UP, P, now=T0, window=W, radius=R)
    hit2 = it.speed_double_click_hit(FM, UP, P, now=T0 + W + 0.01,
                                     window=W, radius=R)
    step("A2 ★★ 超出时间窗 ⇒ 不算双击（两次独立单击）", hit2 is False,
         "间隔 %.2fs > 窗 %.2fs" % (W + 0.01, W))

    # A3：位置太远 ⇒ 不算
    reset_click()
    it.speed_double_click_hit(FM, UP, P, now=T0, window=W, radius=R)
    far = (P[0] + R * 3.0, P[1])
    hit3 = it.speed_double_click_hit(FM, UP, far, now=T0 + 0.05,
                                     window=W, radius=R)
    step("A3 ★★ 两次点击位置相距过远 ⇒ 不算双击", hit3 is False,
         "距离 %.1fpx > 半径 %.1fpx" % (R * 3.0, R))

    # A4：同帧的【另一个】三角 ⇒ 不算（各自独立计数）
    reset_click()
    it.speed_double_click_hit(FM, UP, P, now=T0, window=W, radius=R)
    hit4 = it.speed_double_click_hit(FM, DOWN, P, now=T0 + 0.05,
                                     window=W, radius=R)
    step("A4 ★★ 同帧的另一个三角 ⇒ 不算双击（各自计数）", hit4 is False, "")

    # A5：不同帧 ⇒ 不算
    reset_click()
    it.speed_double_click_hit(F0, UP, P, now=T0, window=W, radius=R)
    hit5 = it.speed_double_click_hit(F1, UP, P, now=T0 + 0.05,
                                     window=W, radius=R)
    step("A5 ★ 不同关键帧 ⇒ 不算双击", hit5 is False, "")

    # A6：双击被消费 ⇒ 紧接着的第三次不算双击（防三击连触发）
    reset_click()
    it.speed_double_click_hit(FM, UP, P, now=T0, window=W, radius=R)
    it.speed_double_click_hit(FM, UP, P, now=T0 + 0.05, window=W, radius=R)
    hit6 = it.speed_double_click_hit(FM, UP, P, now=T0 + 0.10,
                                     window=W, radius=R)
    step("A6 ★★ 双击后记录被【消费】⇒ 第三次点击不算双击", hit6 is False, "")

    # A7：clear 断链
    reset_click()
    it.speed_double_click_hit(FM, UP, P, now=T0, window=W, radius=R)
    it.clear_speed_click_chain()
    hit7 = it.speed_double_click_hit(FM, UP, P, now=T0 + 0.05,
                                     window=W, radius=R)
    step("A7 ★ clear_speed_click_chain 断链 ⇒ 下一次不算双击", hit7 is False, "")

    # A8：参数缺省时不崩（走真实偏好/单例时间）
    reset_click()
    try:
        _r = it.speed_double_click_hit(FM, UP, P)
        step("A8 参数缺省（now/window/radius 走默认）不崩", _r is False, "")
    except Exception as e:
        step("A8 参数缺省不崩", False, str(e)[:200])
    _session.speed_click_info = None

    # ============================================================ B 组：复制动作
    # B1：中间帧 down → up（双击 up，值应变成 down 的值）
    o, a = build("_DC1")
    write_s(o, FM, 'right', 0.20)          # down 负责右段
    s_down = read_s(o, FM, 'right')
    s_up_before = read_s(o, FM, 'left')
    ok, s_copied, why = it._copy_speed_value(bpy.context, o, FM, UP)
    s_up_after = read_s(o, FM, 'left')
    step("B1 ★★★ 双击 up ⇒ up 的值变成 down 的值",
         ok and abs(s_up_after - s_down) < 1e-6
         and abs(s_up_before - s_down) > 1e-6,
         "up %.6f → %.6f ; down %.6f (reason=%s)"
         % (s_up_before, s_up_after, s_down, why))

    # B2：反向 up → down
    o, a = build("_DC2")
    write_s(o, FM, 'left', 0.55)
    s_up = read_s(o, FM, 'left')
    ok2, sc2, _ = it._copy_speed_value(bpy.context, o, FM, DOWN)
    s_down2 = read_s(o, FM, 'right')
    step("B2 ★★★ 双击 down ⇒ down 的值变成 up 的值",
         ok2 and abs(s_down2 - s_up) < 1e-6,
         "down → %.6f ; up %.6f" % (s_down2, s_up))

    # B3：显示倍数一致（两条段 span 不同：左 24 / 右 30 ⇒ 复制的必须是 s 而非 d）
    o, a = build("_DC3")
    write_s(o, FM, 'right', 0.18)
    it._copy_speed_value(bpy.context, o, FM, UP)
    r_up = ratio(read_s(o, FM, 'left'))
    r_dn = ratio(read_s(o, FM, 'right'))
    span_l = td.resolve_target(a, o, FM, 'left')[1]
    span_r = td.resolve_target(a, o, FM, 'right')[1]
    step("B3 ★★★ 两侧【显示倍数】完全一致（proves 复制的是 s 而非 d）",
         abs(r_up - r_dn) < 1e-4 and abs(span_l - span_r) > 1.0,
         "左 span=%.1f 倍数 %.4fx ; 右 span=%.1f 倍数 %.4fx"
         % (span_l, r_up, span_r, r_dn))

    # B4：端点边界 —— 首帧 up（左段）没有三角 ⇒ 无可复制，且【值不变】
    o, a = build("_DC4")
    write_s(o, F0, 'right', 0.22)
    before = read_s(o, F0, 'right')
    ok4, sc4, why4 = it._copy_speed_value(bpy.context, o, F0, DOWN)
    after4 = read_s(o, F0, 'right')
    step("B4 ★★ 首帧 down：对侧（左段）是端点 ⇒ 报 no_opposite 且【值不变】",
         (not ok4) and why4 == "no_opposite" and abs(after4 - before) < 1e-9,
         "ok=%s reason=%s 值 %.6f→%.6f" % (ok4, why4, before, after4))

    # B5：端点边界 —— 末帧 down（右段）没有三角
    o, a = build("_DC5")
    write_s(o, F1, 'left', 0.27)
    before5 = read_s(o, F1, 'left')
    ok5, sc5, why5 = it._copy_speed_value(bpy.context, o, F1, UP)
    after5 = read_s(o, F1, 'left')
    step("B5 ★★ 末帧 up：对侧（右段）是端点 ⇒ 报 no_opposite 且【值不变】",
         (not ok5) and why5 == "no_opposite" and abs(after5 - before5) < 1e-9,
         "ok=%s reason=%s" % (ok5, why5))

    # B6：复制只影响【本侧】，对侧的值必须原样
    o, a = build("_DC6")
    write_s(o, FM, 'right', 0.20)
    w_up = write_s(o, FM, 'left', 0.60)          # 给两侧不同的值
    up_before = read_s(o, FM, 'left')
    dn_before = read_s(o, FM, 'right')
    it._copy_speed_value(bpy.context, o, FM, UP)   # 双击 up ⇒ up := down
    up_after = read_s(o, FM, 'left')
    dn_after = read_s(o, FM, 'right')
    step("B6 ★★ 复制只改本侧，对侧原样不动",
         abs(dn_after - dn_before) < 1e-9 and abs(up_after - dn_before) < 1e-6
         and abs(up_before - dn_before) > 1e-6,
         "up %.6f→%.6f ; down %.6f→%.6f" % (up_before, up_after, dn_before, dn_after))

    # B7：幂等（再复制一次不变）
    it._copy_speed_value(bpy.context, o, FM, UP)
    step("B7 幂等：再复制一次值不变",
         abs(read_s(o, FM, 'left') - up_after) < 1e-9,
         "%.6f → %.6f" % (up_after, read_s(o, FM, 'left')))

    # B8：倍数与源一致（用 ratio 验证"复制过来就是同一个倍数"）
    o, a = build("_DC8")
    write_s(o, FM, 'right', 0.12)
    src_ratio = ratio(read_s(o, FM, 'right'))
    it._copy_speed_value(bpy.context, o, FM, UP)
    dst_ratio = ratio(read_s(o, FM, 'left'))
    step("B8 ★ 复制后本侧显示倍数 == 源侧倍数",
         abs(dst_ratio - src_ratio) < 1e-4,
         "源 %.4fx → 本侧 %.4fx" % (src_ratio, dst_ratio))

    # ============================================================ C 组：入口
    o, a = build("_DC9")
    write_s(o, FM, 'right', 0.20)
    hs = mk_handles(FM)
    h_up = hd.find_handle(hs, FM, UP)
    pos = tri_screen_of(h_up)

    # C1：点空白 ⇒ (False, None) 且断链
    reset_click()
    _session.speed_click_info = {'frame': 1.0, 'tri': UP, 't': 0.0, 'pos': (0.0, 0.0)}
    consumed, msg = it.try_copy_other_speed_click(
        bpy.context, o, hs, (pos[0] + 500.0, pos[1] + 500.0))
    step("C1 ★ 双击入口：点空白 ⇒ (False,None) 且断掉双击链",
         consumed is False and msg is None and _session.speed_click_info is None,
         "consumed=%s msg=%s 链=%s" % (consumed, msg, _session.speed_click_info))

    # C2'（★ 2026-09-18 新语义）：一体态双击 ⇒ **切成分离**，值**不动**
    try:
        xf.clear_tri_lock(a)
    except Exception:
        pass
    reset_click()
    it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)       # 第 1 次点击
    consumed2, msg2 = it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)  # 第 2 次
    up_now = read_s(o, FM, 'left')
    _split = not xf.is_tri_locked(a, FM)
    step("C2' ★★★ 双击入口：一体态第 2 击 ⇒ consumed=True 且切成【分离】（值不动）",
         consumed2 is True and _split and abs(up_now - 0.20) > 1e-6,
         "consumed=%s 分离=%s up=%.6f msg=%r" % (consumed2, _split, up_now, msg2))

    # C3'（★ 新语义）：**分离**态双击 ⇒ 锁回一体 + 把对侧值同步过来（旧的"复制"在这里）
    reset_click()
    it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)       # 第 1 击
    consumed3, msg3 = it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)  # 第 2 击
    up_locked = read_s(o, FM, 'left')
    _locked = xf.is_tri_locked(a, FM)
    step("C3' ★★★ 分离态第 2 击 ⇒ 锁回一体，且对侧值已同步到被双击的三角",
         consumed3 is True and _locked and abs(up_locked - 0.20) < 1e-6,
         "consumed=%s 一体=%s up=%.6f msg=%r" % (consumed3, _locked, up_locked, msg3))
    step("C3'' ★ 锁定消息里带【倍数】（便于状态栏反馈）",
         msg3 is not None and len(msg3) > 0, "msg=%r" % (msg3,))

    # C4'（★ 2026-09-18 新语义）：双击序列结束时该帧已是【一体】⇒ **两个三角都选中**
    step("C4' 双击收在一体态 ⇒ 两个三角都选中（用户看得见一体）",
         xf.is_tri_locked(a, FM) is True
         and _session.is_locked_pair_selected(FM),
         "一体=%s 选中=%s" % (xf.is_tri_locked(a, FM), _session.selected_speed_handles))

    # C5：单击（间隔很长）不应触发复制
    o, a = build("_DC10")
    write_s(o, FM, 'right', 0.20)
    hs5 = mk_handles(FM)
    pos5 = tri_screen_of(hd.find_handle(hs5, FM, UP))
    reset_click()
    it.speed_double_click_hit(FM, UP, pos5, now=0.0, window=0.35,
                              radius=it.SPEED_TRI_PICK_RADIUS)
    c5, m5 = it.try_copy_other_speed_click(bpy.context, o, hs5, pos5)
    step("C5 ★★ 两次点击间隔很久（非双击）⇒ 不触发切换（保持默认一体）",
         c5 is False and xf.is_tri_locked(a, FM) is True,
         "consumed=%s 一体=%s" % (c5, xf.is_tri_locked(a, FM)))

    # ============================================================ D 组：静态契约
    src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    # ⚠️ 锚点用【语义稳定点】：三角处理段的第一行。
    # 别锚定具体的命中调用（裸 hd.hit_test 会被重构掉 ——
    # 本轮就把裸 hit_test 收敛成了 _triangle_under_cursor）。
    i_modal = src.find("hit_tri = _triangle_under_cursor(s_handles, local_mouse_pos)")
    step("D1 ★★ modal 里在【选中/拖拽之前】接了双击处理（新语义入口）",
         i_modal > 0 and "try_toggle_tri_lock_click(" in src[i_modal:i_modal + 900],
         "")
    for nm in ("speed_double_click_hit", "_copy_speed_value",
               "try_copy_other_speed_click", "try_toggle_tri_lock_click",
               "toggle_frame_lock", "clear_speed_click_chain"):
        step("D2 函数存在：%s" % nm, callable(getattr(it, nm, None)), "")
    step("D3 state 有 speed_click_info 字段",
         hasattr(_session, "speed_click_info"),
         "值=%r" % (getattr(_session, "speed_click_info", "★缺失"),))
    # ⚠️ 只看**代码**，不看注释/docstring —— 本仓库**故意**在注释里写了
    #    "为什么不用 event.value == 'DOUBLE_CLICK'"，含该字串是正确的。
    #    （与 gui_endpoint_tangent_check 的 D4 同一类坑：钉代码，别钉文本。）
    import re as _re

    def _code_only(s):
        s = _re.sub(r'"""[\s\S]*?"""', '""', s)
        s = _re.sub(r"'''[\s\S]*?'''", "''", s)
        s = _re.sub(r"#[^\n]*", "", s)
        return s

    _code = _code_only(src)
    step("D4 ★ 代码里【不用】 event.value == 'DOUBLE_CLICK'（确定性自判）",
         "DOUBLE_CLICK" not in _code,
         "代码里%s" % ("★出现" if "DOUBLE_CLICK" in _code else "无（只在注释里说明）"))

    # ============================================================ E 组：注入
    def _scen_B1():
        """双击 up ⇒ up == down 且确实发生变化。"""
        o, a = build("_EI1")
        write_s(o, FM, 'right', 0.20)
        before = read_s(o, FM, 'left')
        it._copy_speed_value(bpy.context, o, FM, UP)
        after = read_s(o, FM, 'left')
        return (abs(after - 0.20) < 1e-6) and (abs(before - 0.20) > 1e-6)

    def _scen_A2():
        """超时间窗的两次点击 ⇒ 不算双击。"""
        reset_click()
        it.speed_double_click_hit(FM, UP, (10.0, 10.0), now=0.0, window=0.35,
                                  radius=it.SPEED_TRI_PICK_RADIUS)
        return it.speed_double_click_hit(FM, UP, (10.0, 10.0), now=5.0,
                                         window=0.35,
                                         radius=it.SPEED_TRI_PICK_RADIUS) is False

    def _mk_reversed():
        """I1：把"另一个三角"映射搞反（复制自己）⇒ 值不变 ⇒ B1 检查应抓不到。"""
        _o = it._copy_speed_value

        def do():
            # 替换成"复制自己"的版本（= 等于没改）⇒ B1 检查必须察觉
            def self_copy(context, obj, frame, tri):
                side = hd.SIDE_BY_TRI.get(tri)
                s_self = read_s(obj, frame, side)
                if s_self is None:
                    return (False, None, "no_opposite")
                it._apply_speed_d(context, obj, float(frame), side,
                                  td.s_to_d(float(s_self)))
                return (True, float(s_self), None)
            it._copy_speed_value = self_copy

        def undo():
            it._copy_speed_value = _o
        return do, undo, "I1 ★'另一个三角'映射搞反（复制自己）⇒ 值不变"

    def _mk_no_window():
        """I2：双击判定忽略时间窗 ⇒ 相隔很久也算双击。"""
        _o = it._speed_dblclick_window

        def do():
            it._speed_dblclick_window = lambda ctx: 1e9

        def undo():
            it._speed_dblclick_window = _o
        return do, undo, "I2 ★忽略时间窗 ⇒ 相隔很久也判双击"

    def _scen_A2_no_window():
        """时间窗被无视时的检查：相隔 5s 应【不】判双击。"""
        reset_click()
        it.speed_double_click_hit(FM, UP, (10.0, 10.0), now=0.0,
                                  window=it._speed_dblclick_window(bpy.context),
                                  radius=it.SPEED_TRI_PICK_RADIUS)
        return it.speed_double_click_hit(FM, UP, (10.0, 10.0), now=5.0,
                                         window=it._speed_dblclick_window(bpy.context),
                                         radius=it.SPEED_TRI_PICK_RADIUS) is False

    base = (_scen_B1(), _scen_A2())
    step("E0 基线：未注入时 B1 / A2 检查都通过", all(base), "B1 A2 = %s" % (base,))

    for mk, chk in ((_mk_reversed, _scen_B1), (_mk_no_window, _scen_A2_no_window)):
        do, undo, label = mk()
        try:
            do()
            caught = not chk()
        except Exception:
            caught = True
            label += "（异常也算抓住）"
        finally:
            undo()
        step("★ %s ⇒ 测试抓住" % label, caught, "")

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-1200:])
finally:
    try:
        if hasattr(it, "_speed_dblclick_window"):
            pass
        _session.speed_click_info = None
    except Exception:
        pass

try:
    for n in ("_DC1", "_DC2", "_DC3", "_DC4", "_DC5", "_DC6", "_DC8",
              "_DC9", "_DC10", "_EI1"):
        x = bpy.data.objects.get(n)
        if x:
            bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
