import bpy
import os

from bpy.app.translations import pgettext_iface as iface_
from .state import get_addon_prefs
from . import interaction


def _sync_debug_log(self, context):
    """偏好设置 `debug_log_enabled` 变化时，同步 debug_log 模块的开关。

    ⚠️ 调试日志是**正式机制**（不是用完即删的临时钩子）：
    交互类问题在 headless 里复现不出来，正确解法是
    「加日志 → 让用户真机操作一次 → 读日志定案」（2026-09-17 实战验证）。
    """
    try:
        from . import debug_log
        debug_log.set_enabled(bool(self.debug_log_enabled))
    except Exception:
        pass


def sync_debug_log_from_prefs():
    """注册时把偏好设置「Debug Log」的当前值同步到 debug_log 模块（调一次）。

    ⚠️ 为什么不能只靠 `update=_sync_debug_log`：那个回调**只在值变化时**触发。
      若启动时偏好里就是「关」（用户确实关过），压根没有"变化"发生 ⇒
      模块侧 `_explicit` 保持 False ⇒ 模块按自己的默认（开）走 ⇒
      **UI 说关着、日志却在记**（说到做不到，最坏的一类不一致）。

    这里走 `apply_prefs_default()` 而不是 `set_enabled()`：后者会置 `_explicit`，
    把环境变量 `RTMP_DEBUG_LOG` 永久压掉（测试/批处理需要那个开关）。

    ⚠️ 2026-10-08 踩过：这里最初写成 `get_addon_prefs()`（**无参**），
       而它的签名是 `get_addon_prefs(context)` ⇒ TypeError ⇒ 被下面的宽 except
       吞掉 ⇒ 同步**静默失效** ⇒ 用户明明关了日志，日志还在记。
       （「UI 说关、日志却在记」正是本函数要防的事，结果自己先制造了一次。）
       ⇒ 现在直接用 `bpy.context`（register() 阶段没有 context 参数可传），
         而且**失败必须打出来**，不再静默返回 None。
    """
    try:
        entry = bpy.context.preferences.addons.get(__package__)
    except Exception as e:                       # noqa: BLE001
        print("[RealTimeMotionPath] 调试日志开关未能同步（拿不到偏好设置）: %s" % e)
        return None
    if entry is None:
        # 插件尚未在偏好里登记（正常：register 早期）—— 不算错误
        return None
    try:
        prefs = entry.preferences
    except Exception as e:                       # noqa: BLE001
        print("[RealTimeMotionPath] 调试日志开关未能同步（偏好实例取不到）: %s" % e)
        return None
    if prefs is None:
        return None
    try:
        from . import debug_log
        on = bool(prefs.debug_log_enabled)
        debug_log.apply_prefs_default(on)
        return on
    except Exception as e:                       # noqa: BLE001
        print("[RealTimeMotionPath] 调试日志开关未能同步（写模块失败）: %s" % e)
        return None


class RTMP_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    path_width: bpy.props.FloatProperty(name="Path Width", default=2.0, min=1.0, max=10.0)
    path_color: bpy.props.FloatVectorProperty(name="Path Color", subtype='COLOR', size=4, default=(0.8, 0.0, 0.0, 1.0), min=0.0, max=1.0)
    
    show_frame_points: bpy.props.BoolProperty(name="Show Frame Points", default=True)
    frame_point_size: bpy.props.FloatProperty(name="Frame Point Size", default=4.0, min=1.0, max=20.0)
    frame_point_color: bpy.props.FloatVectorProperty(name="Frame Point Color", subtype='COLOR', size=4, default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0)
    
    keyframe_point_size: bpy.props.FloatProperty(name="Keyframe Size", default=10.0, min=1.0, max=30.0)
    keyframe_point_color: bpy.props.FloatVectorProperty(name="Keyframe Color", subtype='COLOR', size=4, default=(0.953, 0.78, 0.0, 1.0), min=0.0, max=1.0)
    selected_keyframe_point_color: bpy.props.FloatVectorProperty(name="Selected Keyframe Color", subtype='COLOR', size=4, default=(1.0, 0.102, 0.0, 1.0), min=0.0, max=1.0)
    
    handle_line_width: bpy.props.FloatProperty(name="Handle Line Width", default=2.0, min=1.0, max=10.0)
    handle_line_color: bpy.props.FloatVectorProperty(name="Handle Line Color", subtype='COLOR', size=4, default=(0.0, 0.0, 0.0, 1.0), min=0.0, max=1.0)
    selected_handle_line_color: bpy.props.FloatVectorProperty(name="Selected Handle Line Color", subtype='COLOR', size=4, default=(1.0, 0.776, 0.561, 1.0), min=0.0, max=1.0)
    
    handle_endpoint_size: bpy.props.FloatProperty(name="Handle Endpoint Size", default=7.0, min=1.0, max=20.0)
    handle_endpoint_color: bpy.props.FloatVectorProperty(name="Handle Endpoint Color", subtype='COLOR', size=4, default=(0.953, 0.78, 0.0, 1.0), min=0.0, max=1.0)
    selected_handle_endpoint_color: bpy.props.FloatVectorProperty(name="Selected Handle Endpoint Color", subtype='COLOR', size=4, default=(1.0, 0.102, 0.0, 1.0), min=0.0, max=1.0)

    show_origin_indicator: bpy.props.BoolProperty(name="Show Origin Indicator", default=True)
    origin_indicator_style: bpy.props.EnumProperty(
        name="Origin Style",
        items=[
            ('RING',     "Ring",     "Hollow circle ring"),
            ('DOT',      "Dot",      "Filled circle dot"),
            ('RING_DOT', "Ring+Dot", "Ring with center dot (like Blender origin)"),
        ],
        default='RING_DOT')
    origin_indicator_size: bpy.props.FloatProperty(name="Origin Size", default=12.0, min=4.0, max=40.0)
    origin_indicator_color: bpy.props.FloatVectorProperty(name="Origin Color", subtype='COLOR', size=4, default=(1.0, 1.0, 1.0, 0.9), min=0.0, max=1.0)
    origin_indicator_inner_color: bpy.props.FloatVectorProperty(name="Origin Inner Color", subtype='COLOR', size=4, default=(1.0, 0.4, 0.0, 1.0), min=0.0, max=1.0)

    # ---- 性能（2026-09-17 从 3D 视图 HEADER 挪进偏好设置）----
    #
    # ⚠️ 这 3 个原来是 `WindowManager` 属性（`rtmp_refresh_strategy` /
    #    `rtmp_max_interaction_fps` / `rtmp_poll_frequency`）。
    #    **WindowManager 上的属性不写入文件**（实测 2026-09-17：
    #    设 TIMER/33/7 → 保存 → 重开变成默认的 SMART/60/10；
    #    RNA 的 `is_runtime` 也是 True），用户「改完重启就丢」——
    #    既然摆进"偏好设置"，就得真持久化 ⇒ 迁到 AddonPreferences
    #    （存 userpref，全局 + 持久）。
    #    读取方：`state.addon_pref()`（interaction.py 4 处），default 必须与这里一致。
    refresh_strategy: bpy.props.EnumProperty(
        name="Update Mode",
        description="Choose how the motion path updates",
        items=[
            ('SMART', "Smart (Event)",
             "Update only when relevant data changes (Zero idle power)"),
            ('TIMER', "Timer (Polling)",
             "Update periodically (Stable but higher power)"),
        ],
        default='SMART',
    )
    max_interaction_fps: bpy.props.IntProperty(
        name="Interaction FPS",
        description="Limit the frame rate of interaction and redrawing to save power",
        default=60, min=1, max=144)
    poll_frequency: bpy.props.IntProperty(
        name="Auto Update FPS",
        description="Frequency of checks in Timer mode (Hz)",
        default=10, min=1, max=60)

    # ---- 手柄拖拽模式（2026-09-17 用户拍板）----
    # ★ 2026-09-17：**显示位置挪到 3D 视图 HEADER 的 popover**
    #   （用户要求与"性能"对调）。属性本体仍留在偏好设置 ——
    #   它本来就是 AddonPreferences 属性（存 userpref、全局持久），
    #   只是换了展示位置；3D 视图面板里通过 `get_addon_prefs(context)` 引用同一个值。
    #
    # CLASSIC = 原有行为：拖手柄只改值分量 ⇒ 关键帧处速度【变】
    # UNIFORM = 同比例：值分量与时间分量同乘 k ⇒ 手柄变长/变短，速度【不变】
    #           （= Graph Editor「以各自中心 + S 缩放」的等价物）
    # ★★ 2026-09-17（用户反馈"描述过于笼统、名称不直观、意思难明白"）改写文案。
    #
    #    为什么这样写：拖手柄改的是【手柄长度 |dv|】，而【时间跨度 dt】只有一个
    #    位置可站 ⇒ **"速度"和"三角疏密"数学上只能保住一个**：
    #        速度   = |dv| ÷ dt     ；三角 s = dt ÷ span
    #    ⇒ 两个模式的名字必须直接说出**它保住了什么、代价是什么**，
    #      否则用户看不出该选哪个（旧名"改变速度 / 缩放手柄"只说动作、不说后果）。
    # ⚠️ 界面字符串必须写成【单个完整字面量】，**不要跨行拼接**
    #    （`"abc " "def"`）—— `tests/regression.py` 的 i18n 检查用正则按
    #    片段提取，拼接串只会被抓到第一段 ⇒ 报"漏翻 + 僵尸"。
    # ⚠️⚠️ **popover 宽度有限**（实测 3D HEADER popover ≈186px）
    #    ⇒ `expand=True` 的按钮名**最多约 5 个中文字**、说明行约 12 字，
    #      超了就被截成「改速度（疏密不...」（2026-09-17 实测踩坑，
    #      第一版写成「改速度（疏密不变）」就截断了）。
    #    ⇒ 按钮只放**最短的区分词**，代价说明放到下面**动态那一行**（见 draw）。
    # ★★★ 2026-09-17（用户两次反馈后定稿的文案原则）：
    #    ① 用【用户看得见、说得出的词】，不用内部术语：
    #         快慢     = 关键帧处的速度
    #         速度分布 = 路径上点的疏密（画面上那些小三角管的东西）
    #       不提 dt / span / s / 同比例，不写公式。
    #    ② 只描述【功能效果】，不解释"为什么"：
    #       用户要的是"我该选哪个"，不是"为什么数学上互斥"。
    #       （"适合…"、"因为…只能保住一个"这类解释一律不要。）
    handle_scale_mode: bpy.props.EnumProperty(
        # ★★ 2026-09-30 用户改文案：「拖动手柄 = 做什么」→「路径手柄模式」
        #    （原表述是"疑问句"，读起来像在问用户；改成名词短语，更像一个模式名。）
        name="Path Handle Mode",
        description="What a handle drag keeps: speed or speed distribution",
        items=[
            ('CLASSIC', "Change Speed",
             "Drag changes the speed only; the speed distribution stays"),
            ('UNIFORM', "Keep Speed",
             "Drag changes the shape only; speed stays, the speed distribution follows"),
        ],
        default='UNIFORM',
    )

    # ---- 调试日志（正式机制，见 debug_log.py）----
    # ★★ 2026-10-08：默认**开启**（原来是 False）。
    #    机制的意义是"出问题时能查"，而交互类问题只在复现那一刻才有日志 ——
    #    默认关闭等于"等你想起要开，现场已经过去了"。代价有上限（8MB 轮转）。
    debug_log_enabled: bpy.props.BoolProperty(
        name="Debug Log", default=True, update=_sync_debug_log,
        # ⚠️ 界面文案一律写**英文原文**，中文靠 translations.py 提供（i18n 门禁会卡）。
        # ⚠️ 而且**必须写在一行**：i18n 门禁是静态扫源码，不认识 Python 的
        #    隐式字符串拼接（`"a" "b"`）—— 拆成两行它只看到第一段（还带末尾空格），
        #    于是报"未收录"。踩过一次。
        description="Write the interaction trace to a JSONL log for troubleshooting (on by default; rotates at 8MB)")

    def draw(self, context):
        layout = self.layout
        prefs = self
        
        row = layout.row()
        row.alignment = 'RIGHT'
        row.operator("rtmp.reset_preferences", text=iface_("Restore Defaults"), icon='LOOP_BACK')

        col = layout.column()

        # ★★ 性能（2026-09-17 从 3D 视图 HEADER 挪进偏好设置，见类里的说明）
        col.label(text=iface_("Performance"))
        _prow = col.row()
        _prow.prop(prefs, "refresh_strategy", expand=True)
        col.prop(prefs, "max_interaction_fps")
        if prefs.refresh_strategy == 'TIMER':
            col.prop(prefs, "poll_frequency")
        col.separator()

        col.label(text=iface_("Style Settings"))
        col.prop(prefs, "path_width")
        col.prop(prefs, "path_color")
        
        col.separator()
        col.prop(prefs, "show_frame_points")
        if prefs.show_frame_points:
            col.prop(prefs, "frame_point_size")
            col.prop(prefs, "frame_point_color")
            
        col.separator()
        col.label(text=iface_("Keyframes"))
        col.prop(prefs, "keyframe_point_size")
        col.prop(prefs, "keyframe_point_color")
        col.prop(prefs, "selected_keyframe_point_color")
        
        col.separator()
        col.label(text=iface_("Handles"))
        col.prop(prefs, "handle_line_width")
        col.prop(prefs, "handle_line_color")
        col.prop(prefs, "selected_handle_line_color")
        col.prop(prefs, "handle_endpoint_size")
        col.prop(prefs, "handle_endpoint_color")
        col.prop(prefs, "selected_handle_endpoint_color")

        # ★ 拖手柄的语义（改速度 / 同比例缩放）已于 2026-09-17 挪到
        #   3D 视图 HEADER 的 popover（`RTMP_PT_header_settings`）——
        #   属性本体没变（仍是 AddonPreferences），只是换了展示位置。

        col.separator()
        col.label(text=iface_("Origin Indicator"))
        col.prop(prefs, "show_origin_indicator")
        if prefs.show_origin_indicator:
            col.prop(prefs, "origin_indicator_style")
            col.prop(prefs, "origin_indicator_size")
            col.prop(prefs, "origin_indicator_color")
            if prefs.origin_indicator_style in {'RING_DOT', 'DOT'}:
                col.prop(prefs, "origin_indicator_inner_color")

        # ★★ 调试日志（正式机制，见 debug_log.py）
        col.separator()
        col.label(text=iface_("Debug"), icon='CONSOLE')
        col.prop(prefs, "debug_log_enabled")
        if prefs.debug_log_enabled:
            try:
                from . import debug_log
                _box = col.box()
                _box.label(text=iface_("Log:"), icon='FILE_TEXT')
                _box.label(text=os.path.basename(debug_log.log_path()))
                _row = _box.row(align=True)
                _row.operator("rtmp.open_debug_log", text=iface_("Open"),
                              icon='FILE_FOLDER')
                _row.operator("rtmp.clear_debug_log", text=iface_("Clear"),
                              icon='TRASH')
            except Exception:
                col.label(text=iface_("debug_log unavailable"), icon='ERROR')


class RTMP_PT_header_settings(bpy.types.Panel):
    """3D 视图右上角工具栏的 popover（点小箭头展开）。

    ★ 2026-09-17（用户要求，与偏好设置**对调**）：
        · 「性能」（更新模式 / 交互帧率 / 轮询频率）→ 挪去**偏好设置**
          （顺带把存储从 WindowManager 换成 AddonPreferences，见那边注释：
            WindowManager 属性不写入文件，改完重启就丢）
        · 「手柄拖拽模式」→ 从偏好设置挪到**这里**
    ⚠️ 面板标题保持 `Motion Path Settings` 不变（用户已熟悉这个入口位置）。
    """

    bl_label = "Motion Path Settings"
    bl_idname = "RTMP_PT_header_settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    def draw(self, context):
        layout = self.layout
        try:
            prefs = get_addon_prefs(context)
        except Exception:
            # 拿不到偏好（异常 / 未完成加载）⇒ 画个提示而不是让 draw 崩掉
            # （draw 抛异常会让整个 popover 空白，用户以为插件坏了）
            layout.label(text=iface_("Addon preferences unavailable"), icon='ERROR')
            return

        # ★★ 2026-09-30（命名方案 D）：面向用户叫「运动路径校正」。
        #    不用「规范」——那是站在插件角度说的；用户关心的是
        #    "我在 3D 视图里拖手柄会不会走形"。
        #    为什么放这儿：用户开运动路径时最可能先看这个 popover。
        try:
            from .state import _session as _sess_chk
            _rep = getattr(_sess_chk, "spec_last_report", None)
            _n = len((_rep or {}).get("issues") or [])
            layout.label(text=iface_("Motion Path Correction"), icon='INFO')
            if _n:
                layout.label(
                    text=iface_("Found %d handle problem(s)") % _n,
                    icon='ERROR')
            row_chk = layout.row(align=True)
            # 有问题 ⇒ 按钮叫「校正手柄」（点开就是带勾选项的弹窗）；
            # 没问题 ⇒ 叫「检查手柄」（纯读，只告诉你"没问题"）。
            row_chk.operator("rtmp.spec_inspect",
                             text=iface_("Check Handles"),
                             icon=('ERROR' if _n else 'CHECKMARK'))
            if getattr(_sess_chk, "spec_last_snapshot", None):
                row_chk.operator("rtmp.spec_revert", text="", icon='LOOP_BACK')
        except Exception:
            pass

        # ★ 拖手柄的语义：改速度 / 保速度（2026-09-17 从偏好设置挪来）
        # ★★ 2026-09-30 用户改文案：「拖动手柄 = 做什么」→「**路径手柄模式**」。
        #    理由：原标题是个"疑问句"，像在问用户；改成名词短语更像一个【模式名】，
        #    和下面两个按钮（改速度 / 保速度）构成"模式 + 取值"的读法。
        #    ⚠️ 改这行必须同步改 `translations.py` 的词条 key（i18n 门禁按英文原文查表）。
        layout.label(text=iface_("Path Handle Mode"))
        # ★★ 用 `prop_enum` 而不是 `prop(..., expand=True)`（2026-09-17 实测决定）：
        #    · `expand=True` 的按钮**不显示 description** ⇒ 详细说明等于白写；
        #      而且 popover 窄（≈186px），长按钮名会被截断成「改速度（疏密不...」。
        #    · `prop_enum` 画**单个按钮**、**tooltip 取该 enum item 的 description**
        #      ⇒ 并排两个按钮 + 悬停看详细说明，两全。
        #    ⇒ 用户 2026-09-17 要求：「详细的内容写到悬停描述」——本实现正是如此：
        #      按钮只放短名（改速度 / 保速度），代价说明全在 tooltip 里。
        row = layout.row(align=True)
        row.prop_enum(prefs, "handle_scale_mode", value='CLASSIC')
        row.prop_enum(prefs, "handle_scale_mode", value='UNIFORM')

        # ★ 盲审 S1（2026-09-18）：本插件按整数帧建模，非整数帧关键帧会被合并掉。
        #   用户拍板"不支持子帧"⇒ 那就**明确提示**，别让用户对着
        #   "少了半个关键帧"的路径猜原因（原先完全静默）。
        #   只在真的存在子帧关键帧时才画这一行 —— 正常情况下不占地方。
        try:
            from .state import _session as _sess
            _n = getattr(_sess, "subframe_keyframe_count", 0)
            if _n:
                _ex = getattr(_sess, "subframe_keyframe_examples", []) or []
                _txt = " ".join("f%g" % f for f in _ex)
                layout.label(
                    text=iface_("Subframe keyframes are not supported"),
                    icon='INFO')
                if _txt:
                    layout.label(text=_txt)
        except Exception:
            pass


class RTMP_MT_context_menu(bpy.types.Menu):
    """右键菜单：设置 / 显示【体感手柄类型】。

    ★ 2026-09-17（方案 A）：菜单顶部的只读标签显示当前**体感**类型，
      并把当前体感对应的那一项**高亮**（`layout.operator(..., depress=True)`）。
      这样用户能直观看到"体感到底是什么"——因为 Graph Editor 属性面板里
      显示的只是**原始**手柄类型，方案 A 下两者可能不一致。
    """
    bl_label = "Motion Path Context Menu"
    bl_idname = "RTMP_MT_context_menu"

    def draw(self, context):
        layout = self.layout

        # ---- 当前体感手柄类型（只读展示 + 高亮） ----
        try:
            from . import interaction as _it
            cur = _it.current_feel_label(context)          # 'LINK'/'VECTOR'/'FREE'/None
        except Exception:
            cur = None

        box = layout.column(align=True)
        if cur:
            box.label(text=iface_("Feel: %s") % cur, icon='HANDLE_AUTO')
        else:
            box.label(text=iface_("Feel: (mixed / original)"), icon='INFO')
        layout.separator()

        # ---- 设置（写的是【体感类型】；原始类型按需写 FREE） ----
        # ★ 2026-09-17（方案A）：菜单只留 **2 项**。
        #   用户拍板（两轮）：
        #     ① `Vector` → 换成 `Auto Clamped`（Vector 太边缘用途）
        #     ② 再后来：「auto clamped 好像没啥用，去掉吧，留 Free / Aligned 就好」
        #   ⇒ 最终 = Free / Aligned 两项。
        #   （'VECTOR' / 'CLAMPED' 的**语义都保留**，兼容存量数据与旧接口，
        #     只是不进菜单；用户要用可以走 Graph Editor 或后续再加。）
        items = (
            ('FREE', iface_("Free")),
            ('LINK', iface_("Aligned")),
        )
        for value, label in items:
            # ⚠️⚠️ `depress` 必须作为 **layout.operator() 的关键字参数**传！
            #   写成 `op = layout.operator(...); op.depress = True` 会抛
            #   AttributeError（OperatorProperties 只声明了 handle_type），
            #   **draw() 当场中断 → 后面的项全不渲染**。
            #   实测症状（2026-09-17 用户报告）：菜单里只剩 1~2 项，且"选完变得更少"——
            #   体感 FREE 时第 1 项就炸（只剩 Free）；体感 LINK 时第 2 项炸（剩 Free+Aligned）。
            op = layout.operator("rtmp.change_handle_mode", text=label,
                                 depress=bool(cur and value == cur))
            op.handle_type = value


class RTMP_OT_ResetPreferences(bpy.types.Operator):
    bl_idname = "rtmp.reset_preferences"
    bl_label = "Reset to Default"
    bl_description = "Reset all motion path settings to default values"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        prefs = get_addon_prefs(context)
        prefs.property_unset("path_width")
        prefs.property_unset("path_color")
        prefs.property_unset("show_frame_points")
        prefs.property_unset("frame_point_size")
        prefs.property_unset("frame_point_color")
        prefs.property_unset("keyframe_point_size")
        prefs.property_unset("keyframe_point_color")
        prefs.property_unset("selected_keyframe_point_color")
        prefs.property_unset("handle_line_width")
        prefs.property_unset("handle_line_color")
        prefs.property_unset("selected_handle_line_color")
        prefs.property_unset("handle_endpoint_size")
        prefs.property_unset("handle_endpoint_color")
        prefs.property_unset("selected_handle_endpoint_color")
        prefs.property_unset("show_origin_indicator")
        prefs.property_unset("origin_indicator_style")
        prefs.property_unset("origin_indicator_size")
        prefs.property_unset("origin_indicator_color")
        prefs.property_unset("origin_indicator_inner_color")
        prefs.property_unset("debug_log_enabled")
        prefs.property_unset("handle_scale_mode")
        # ★ 性能 3 项（2026-09-17 从 WindowManager 迁来）
        prefs.property_unset("refresh_strategy")
        prefs.property_unset("max_interaction_fps")
        prefs.property_unset("poll_frequency")
        
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}


class RTMP_OT_ToggleCustomDraw(bpy.types.Operator):
    bl_idname = "rtmp.toggle_custom_draw"
    bl_label = "Toggle Custom Path"
    bl_description = "Enable/Disable Custom Motion Path Drawing"

    def execute(self, context):
        wm = context.window_manager
        new_state = not wm.rtmp_path_display_enabled
        wm.rtmp_path_display_enabled = new_state

        if new_state:
            if not interaction._find_and_start_motion_path_operators(context):
                self.report({'WARNING'}, iface_("Enabled Motion Path, but no 3D View found for interaction."))
        else:
            interaction._stop_motion_path_operators(context)

        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


def draw_header_button(self, context):
    layout = self.layout
    wm = context.window_manager
    row = layout.row(align=True)
    row.prop(wm, "rtmp_path_display_enabled", text="", icon='IPO_BEZIER', toggle=True)
    row.popover(panel="RTMP_PT_header_settings", text="")


class RTMP_OT_SpecInspect(bpy.types.Operator):
    """检查当前对象的手柄是否「贴合路径」。

    ★★ 本操作**纯读** —— 只检测、只报告，一个字节都不写。
       要改数据得点弹窗里的「确定」（那是 `rtmp.spec_fix`，见 `spec_ui`）。

    为什么需要它
    ------------
    用户手动微调过 Graph Editor 之后，3D 视图里的手柄可能**跟路径对不上**
    （拖起来手感不对、方向不贴）。判据见 `spec_check` 模块 docstring。
    本操作把"体检单"给用户看，**要不要修由用户决定**。

    ⚠️ 「折角」不在报告范围内（只作为灰色提示）：
       实测折角 29.6° 时两侧手柄仍然完全相切 —— 折角不影响 3D 操作。
    """

    bl_idname = "rtmp.spec_inspect"
    bl_label = "Check Motion Path Handles"
    bl_description = "Check whether the handles follow the path (read-only, changes nothing)"

    def execute(self, context):
        from . import spec_check as sc
        from .state import _session as _sess

        obj = context.active_object
        if obj is None or not getattr(obj, "animation_data", None) \
                or not getattr(obj.animation_data, "action", None):
            self.report({'WARNING'}, iface_("No animated object selected"))
            return {'CANCELLED'}

        action = obj.animation_data.action
        bone_name = None
        try:
            from .interaction import _pose_bone_name
            bone_name = _pose_bone_name(context)
        except Exception:
            bone_name = None

        try:
            report = sc.detect(action, obj, bone_name)
        except Exception as exc:
            print("RealTimeMotionPath: spec_inspect failed -> %r" % (exc,))
            self.report({'ERROR'}, iface_("Check failed (see console)"))
            return {'CANCELLED'}

        # 缓存最近一次结果，供 popover 显示（**只读状态，不落盘**）
        try:
            _sess.spec_last_report = report
        except Exception:
            pass

        issues = report.get("issues") or []
        if not issues:
            self.report({'INFO'}, iface_("Handles already follow the path"))
            if context.area:
                context.area.tag_redraw()
            return {'FINISHED'}

        # 有问题：把体检单打到控制台（开发者用）+ 开微调弹窗（用户用）
        print("=" * 70)
        print("[RTMP motion path correction] %s / %s : %d issue(s)"
              % (report.get("obj_name"), report.get("action_name"), len(issues)))
        for it in issues:
            print("  * " + it["detail"])
        print("=" * 70)
        self.report({'WARNING'},
                    iface_("Found %d handle problem(s)") % len(issues))
        if context.area:
            context.area.tag_redraw()
        # ★ 用户点按钮 ⇒ 直接给弹窗（弹窗里带完整清单 + 勾选项）
        try:
            bpy.ops.rtmp.spec_fix('INVOKE_DEFAULT')
        except Exception:
            pass
        return {'FINISHED'}


class RTMP_OT_OpenDebugLog(bpy.types.Operator):
    """在文件管理器里打开调试日志所在目录（2026-09-17）。"""
    bl_idname = "rtmp.open_debug_log"
    bl_label = "Open Debug Log"
    bl_description = "Open the folder that contains the debug log"

    def execute(self, context):
        from . import debug_log
        p = debug_log.log_path()
        d = os.path.dirname(p)
        try:
            if not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            bpy.ops.wm.path_open(filepath=p if os.path.exists(p) else d)
        except Exception as e:
            self.report({'ERROR'}, "Cannot open: %s" % e)
            return {'CANCELLED'}
        return {'FINISHED'}


class RTMP_OT_ClearDebugLog(bpy.types.Operator):
    """清空调试日志（2026-09-17）。"""
    bl_idname = "rtmp.clear_debug_log"
    bl_label = "Clear Debug Log"
    bl_description = "Clear the debug log file"

    def execute(self, context):
        from . import debug_log
        ok = debug_log.clear()
        debug_log.dbg("log.cleared")           # 记一条，确认开关正常
        self.report({'INFO'} if ok else {'WARNING'},
                    "Debug log cleared" if ok else "Nothing to clear")
        return {'FINISHED'}
