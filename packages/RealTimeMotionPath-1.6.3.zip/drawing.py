import bpy
import mathutils
import math
import gpu
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils
from .state import (_session, HANDLE_SELECT_RADIUS, SAFE_LIMIT, MIN_HANDLE_SCALE,
                    MAX_HANDLE_SCALE, HANDLE_ZERO_EPS, HANDLE_ZERO_SCREEN_PX,
                    get_addon_prefs)
from .cache import collect_animation_curves, is_position_animation, resolve_parent_transform
from .debug_log import dbg

# 「抓取环数据喂入」日志的节流状态：
#   render_path_overlay 是 POST_VIEW 绘制回调，**每帧**都跑；
#   若逐帧 dbg 会把日志淹掉。故只在「喂入的环集合（frame/side 签名）」变化时记一条。
#   环消失（签名变 ()）也会记 —— 能看出"环没了"。
_ring_feed_state = {"sig": None}


_circle_aa_shader = None
CIRCLE_AA_FEATHER = 0.1

_GLOW_LAYERS = 3
_GLOW_SIZE_STEP = 2
_GLOW_ALPHA_FACTOR = 0.3
_GLOW_PATH_COLOR_LIFT = 0.3
_GLOW_HANDLE_COLOR_LIFT = 0.2


def _get_circle_aa_shader():
    global _circle_aa_shader
    if _circle_aa_shader is None:
        vert_out = gpu.types.GPUStageInterfaceInfo("circle_aa_interface")
        vert_out.smooth('VEC2', "uvInterp")
        shader_info = gpu.types.GPUShaderCreateInfo()
        shader_info.push_constant('MAT4', "ModelViewProjectionMatrix")
        shader_info.push_constant('VEC4', "color")
        shader_info.push_constant('FLOAT', "feather")
        shader_info.vertex_in(0, 'VEC3', "pos")
        shader_info.vertex_in(1, 'VEC2', "uv")
        shader_info.vertex_out(vert_out)
        shader_info.fragment_out(0, 'VEC4', "FragColor")
        shader_info.vertex_source(
            "void main()"
            "{"
            "  uvInterp = uv;"
            "  gl_Position = ModelViewProjectionMatrix * vec4(pos, 1.0);"
            "}"
        )
        shader_info.fragment_source(
            "void main()"
            "{"
            "  vec2 uv_centered = uvInterp * 2.0 - 1.0;"
            "  float dist = length(uv_centered);"
            "  float alpha = 1.0 - smoothstep(1.0 - feather, 1.0 + feather, dist);"
            "  FragColor = color * alpha;"
            "}"
        )
        _circle_aa_shader = gpu.shader.create_from_info(shader_info)
        del vert_out
        del shader_info
    return _circle_aa_shader


def compute_camera_aligned_axes(context):
    """计算与摄像机视图对齐的坐标轴向量"""
    try:
        space_data = context.space_data
        if space_data is None:
            return None, None
            
        if not hasattr(space_data, 'region_3d'):
            return None, None
            
        region_3d = space_data.region_3d
        if region_3d is None:
            return None, None
        
        view_orientation = region_3d.view_rotation
        
        axis_x = mathutils.Vector((1.0, 0.0, 0.0))
        axis_y = mathutils.Vector((0.0, 1.0, 0.0))
        
        camera_right = view_orientation @ axis_x
        camera_up = view_orientation @ axis_y
        
        camera_right.normalize()
        camera_up.normalize()
        
        camera_forward = camera_right.cross(camera_up)
        camera_up = camera_forward.cross(camera_right)
        camera_up.normalize()
        
        for vec in (camera_right, camera_up):
            if not all(math.isfinite(c) for c in vec):
                return None, None
        
        return camera_right, camera_up
        
    except Exception:
        return None, None


def calculate_world_to_pixel_ratio(context, pos, pixel_size):
    """计算世界坐标到像素的缩放比例"""
    region = context.region
    rv3d = context.space_data.region_3d
    co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, pos)
    if co2d is None:
        return 0.0
        
    right = rv3d.view_rotation @ mathutils.Vector((1, 0, 0))
    offset_pos = mathutils.Vector(pos) + right * 0.001
    co2d_offset = view3d_utils.location_3d_to_region_2d(region, rv3d, offset_pos)
    
    if co2d_offset is None:
        return 0.0
        
    pixel_dist = (co2d - co2d_offset).length
    if pixel_dist < 0.0001:
        return 0.0
        
    world_per_pixel = 0.001 / pixel_dist
    scale = pixel_size * world_per_pixel
    
    if not math.isfinite(scale) or scale > 10000.0:
        return 0.0
        
    return scale


def render_facing_circle(context, pos, radius_in_pixels, color, shader=None):
    """渲染始终面向摄像机的圆形"""
    try:
        px, py, pz = pos[0], pos[1], pos[2]
        if not (math.isfinite(px) and math.isfinite(py) and math.isfinite(pz) and
                abs(px) < SAFE_LIMIT and abs(py) < SAFE_LIMIT and abs(pz) < SAFE_LIMIT):
            return
    except Exception:
        return

    right, up = compute_camera_aligned_axes(context)
    if right is None or up is None:
        return

    try:
        rx, ry, rz = right[0], right[1], right[2]
        ux, uy, uz = up[0], up[1], up[2]
    except Exception:
        return

    scale = calculate_world_to_pixel_ratio(context, pos, radius_in_pixels)
    if scale == 0:
        return

    c1 = (px - scale * rx - scale * ux, py - scale * ry - scale * uy, pz - scale * rz - scale * uz)
    c2 = (px + scale * rx - scale * ux, py + scale * ry - scale * uy, pz + scale * rz - scale * uz)
    c3 = (px + scale * rx + scale * ux, py + scale * ry + scale * uy, pz + scale * rz + scale * uz)
    c4 = (px - scale * rx + scale * ux, py - scale * ry + scale * uy, pz - scale * rz + scale * uz)
    for v in (c1, c2, c3, c4):
        if not (math.isfinite(v[0]) and math.isfinite(v[1]) and math.isfinite(v[2]) and
                abs(v[0]) < SAFE_LIMIT and abs(v[1]) < SAFE_LIMIT and abs(v[2]) < SAFE_LIMIT):
            return

    verts = (c1, c2, c3, c4)
    uvs = ((0, 0), (1, 0), (1, 1), (0, 1))
    indices = ((0, 1, 2), (0, 2, 3))
    try:
        if len(color) >= 4:
            color_tuple = (float(color[0]), float(color[1]), float(color[2]), float(color[3]))
        elif len(color) == 3:
            color_tuple = (float(color[0]), float(color[1]), float(color[2]), 1.0)
        else:
            color_tuple = (1.0, 1.0, 1.0, 1.0)
    except Exception:
        color_tuple = (1.0, 1.0, 1.0, 1.0)

    shader_aa = _get_circle_aa_shader()
    batch = batch_for_shader(shader_aa, 'TRIS', {"pos": verts, "uv": uvs}, indices=indices)
    shader_aa.bind()
    try:
        matrix = context.region_data.perspective_matrix
    except Exception:
        return
    shader_aa.uniform_float("ModelViewProjectionMatrix", matrix)
    shader_aa.uniform_float("color", color_tuple)
    shader_aa.uniform_float("feather", CIRCLE_AA_FEATHER)
    batch.draw(shader_aa)




def render_circle_batch(context, points, radius_in_pixels, color, shader=None, segments=8):
    """批量渲染圆形"""
    if not points or radius_in_pixels <= 0:
        return
    
    right, up = compute_camera_aligned_axes(context)
    if right is None or up is None:
        return
    
    try:
        rx, ry, rz = right[0], right[1], right[2]
        ux, uy, uz = up[0], up[1], up[2]
    except Exception:
        return
    
    try:
        if hasattr(color, 'to_tuple'):
            safe_color = color.to_tuple()
        else:
            safe_color = tuple(float(c) for c in color)
        if len(safe_color) == 3:
            safe_color = (safe_color[0], safe_color[1], safe_color[2], 1.0)
        elif len(safe_color) != 4:
            safe_color = (1.0, 1.0, 1.0, 1.0)
    except Exception:
        safe_color = (1.0, 1.0, 1.0, 1.0)

    uv_quad = ((0, 0), (1, 0), (1, 1), (0, 1))
    BATCH_SIZE = 500
    try:
        matrix = context.region_data.perspective_matrix
    except Exception:
        return
    shader_aa = _get_circle_aa_shader()

    for i in range(0, len(points), BATCH_SIZE):
        batch_points = points[i : min(i + BATCH_SIZE, len(points))]
        all_verts = []
        all_uvs = []
        all_indices = []
        base = 0
        for pos in batch_points:
            try:
                px, py, pz = float(pos[0]), float(pos[1]), float(pos[2])
                
                if not (math.isfinite(px) and math.isfinite(py) and math.isfinite(pz) and
                        abs(px) < SAFE_LIMIT and abs(py) < SAFE_LIMIT and abs(pz) < SAFE_LIMIT):
                    continue

                scale = calculate_world_to_pixel_ratio(context, (px, py, pz), radius_in_pixels)
                if scale == 0:
                    continue
                
                c1 = (px - scale * rx - scale * ux, py - scale * ry - scale * uy, pz - scale * rz - scale * uz)
                c2 = (px + scale * rx - scale * ux, py + scale * ry - scale * uy, pz + scale * rz - scale * uz)
                c3 = (px + scale * rx + scale * ux, py + scale * ry + scale * uy, pz + scale * rz + scale * uz)
                c4 = (px - scale * rx + scale * ux, py - scale * ry + scale * uy, pz - scale * rz + scale * uz)
                
                valid = True
                for v in (c1, c2, c3, c4):
                    if not (math.isfinite(v[0]) and math.isfinite(v[1]) and math.isfinite(v[2]) and
                            abs(v[0]) < SAFE_LIMIT and abs(v[1]) < SAFE_LIMIT and abs(v[2]) < SAFE_LIMIT):
                        valid = False
                        break
                if not valid:
                    continue
                    
                all_verts.extend((c1, c2, c3, c4))
                all_uvs.extend(uv_quad)
                all_indices.extend(((base, base + 1, base + 2), (base, base + 2, base + 3)))
                base += 4
            except Exception:
                continue
                
        if not all_verts or not all_indices:
            continue
        try:
            batch = batch_for_shader(shader_aa, 'TRIS', {"pos": all_verts, "uv": all_uvs}, indices=all_indices)
            shader_aa.bind()
            shader_aa.uniform_float("ModelViewProjectionMatrix", matrix)
            shader_aa.uniform_float("color", safe_color)
            shader_aa.uniform_float("feather", CIRCLE_AA_FEATHER)
            batch.draw(shader_aa)
        except Exception:
            pass


def segment_frame_range(action, obj, frame, side, bone_name=None):
    """某关键帧某一侧所覆盖的帧区间 (f0, f1)。端点段返回 None。"""
    if action is None:
        return None
    frames = set()
    try:
        for fc in collect_animation_curves(action, obj):
            if is_position_animation(fc, bone_name):
                for kp in fc.keyframe_points:
                    frames.add(round(float(kp.co[0]), 4))
    except Exception:
        return None
    fr = sorted(frames)
    try:
        i = fr.index(round(float(frame), 4))
    except ValueError:
        return None
    if side == 'right':
        return (fr[i], fr[i + 1]) if i + 1 < len(fr) else None
    return (fr[i - 1], fr[i]) if i - 1 >= 0 else None


class DrawCollector:
    """绘制元素收集器"""
    def __init__(self):
        self.lines = []
        self.line_colors = []
        self.circles = {}

    def add_line(self, p1, p2, color):
        try:
            if not (math.isfinite(p1[0]) and math.isfinite(p1[1]) and math.isfinite(p1[2]) and
                    math.isfinite(p2[0]) and math.isfinite(p2[1]) and math.isfinite(p2[2])):
                return
        except Exception:
            return

        self.lines.append(p1)
        self.lines.append(p2)
        self.line_colors.append(color)
        self.line_colors.append(color)

    def add_circle(self, pos, radius, color):
        r = round(radius, 2)
        
        if len(color) == 3:
            c_vals = (color[0], color[1], color[2], 1.0)
        elif len(color) >= 4:
            c_vals = (color[0], color[1], color[2], color[3])
        else:
            c_vals = (1.0, 1.0, 1.0, 1.0)
            
        c = tuple(round(x, 3) for x in c_vals)
        
        key = (r, c)
        if key not in self.circles:
            self.circles[key] = []
        self.circles[key].append(pos)
        
    def draw(self, context, styles):
        if self.lines:
            try:
                shader = gpu.shader.from_builtin('POLYLINE_SMOOTH_COLOR')
                batch = batch_for_shader(shader, 'LINES', {"pos": self.lines, "color": self.line_colors})
                shader.bind()
                viewport_size = gpu.state.viewport_get()[2:]
                shader.uniform_float("viewportSize", viewport_size)
                wm = context.window_manager
                line_width = styles.handle_line_width
                shader.uniform_float("lineWidth", line_width)
                batch.draw(shader)
            except Exception as e:
                print(f"Error drawing lines batch: {e}")
            
        for (radius, color), points in self.circles.items():
            render_circle_batch(context, points, radius, color, segments=8)


def _build_ring_vertices(px, py, pz, scale, rx, ry, rz, ux, uy, uz, segments=32):
    """构建环形顶点"""
    verts = []
    for i in range(segments):
        angle = 2 * math.pi * i / segments
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        verts.append((
            px + scale * (cos_a * rx + sin_a * ux),
            py + scale * (cos_a * ry + sin_a * uy),
            pz + scale * (cos_a * rz + sin_a * uz),
        ))
    return verts


def render_origin_marker(context, obj, bone, styles):
    """渲染原点标记"""
    try:
        if bone is not None:
            world_pos = (obj.matrix_world @ bone.matrix).translation
        else:
            world_pos = obj.matrix_world.translation

        px = world_pos[0]
        py = world_pos[1]
        pz = world_pos[2]

        if not (math.isfinite(px) and math.isfinite(py) and math.isfinite(pz) and
                abs(px) < SAFE_LIMIT and abs(py) < SAFE_LIMIT and abs(pz) < SAFE_LIMIT):
            return

        pos = (px, py, pz)
        style = styles.origin_indicator_style
        outer_size = styles.origin_indicator_size
        outer_color = tuple(styles.origin_indicator_color)
        inner_color = tuple(styles.origin_indicator_inner_color)

        gpu.state.blend_set('ALPHA')

        if style == 'DOT':
            render_facing_circle(context, pos, outer_size / 2, inner_color)

        elif style in {'RING', 'RING_DOT'}:
            right, up = compute_camera_aligned_axes(context)
            if right is None or up is None:
                return
            scale = calculate_world_to_pixel_ratio(context, pos, outer_size / 2)
            if scale == 0:
                return
            ring_verts = _build_ring_vertices(
                px, py, pz, scale,
                right[0], right[1], right[2],
                up[0], up[1], up[2],
            )
            shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'LINE_LOOP', {"pos": ring_verts})
            shader.bind()
            shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
            shader.uniform_float("lineWidth", 2.0)
            shader.uniform_float("color", outer_color)
            batch.draw(shader)
            if style == 'RING_DOT':
                render_facing_circle(context, pos, outer_size / 6, inner_color)

    except Exception as e:
        print(f"Error in render_origin_marker: {e}")


def compute_handle_display_factors(frame_kf_map):
    """计算手柄显示缩放因子 —— **恒为 1.0（显示真实长度）**。

    ⚠️⚠️ 为什么不再做"归一化"（2026-09-16 用户实测反馈"手柄一拖就跳变、无限跳变"）

    这个函数曾经是 `S = mean(某个量)`、`factor = S / 该量`，目的是让
    "同一个关键帧三个轴的手柄看起来一样长"（纯外观美化）。
    但它用的基准是**会变的量**，于是：

      · 基准用 dt（时间分量）
          → 速度编辑改 dt → 均值变 → **所有手柄长度一起跳**（用户 2026-09-15 反馈）
      · 基准用值分量（上一轮的"修复"）
          → **拖手柄就是在改值分量** → 均值变 → 显示长度跳
          → 而且拖多远跳多远，看起来"无限跳变"（用户 2026-09-16 反馈）

    **结论**：任何"用会变的量做基准"的归一化都会在某种编辑下跳。
    改为直接显示真实长度（factor ≡ 1.0）：
      · 拖手柄 → 长度线性跟随 → 平滑 ✓
      · 速度编辑 → 时间分量不影响值分量 → 外观不动 ✓
      · 拖关键帧 → co 与 handle 同量平移 → 差值不变 → 外观不动 ✓

    需要一个"整体放大手柄"的开关时，用偏好设置 `rtmp_handle_scale`
    （`render_keyframe_control_handles` 里的 `global_scale`），它是用户可控的固定值。
    """
    return {i: 1.0 for i in frame_kf_map}, {i: 1.0 for i in frame_kf_map}


# ============================================================================
# 端点手柄的「空心圆抓取点」（用户 2026-09-16 需求）
# ============================================================================
# 问题：手柄【长度为 0】时（端点未拖过；或停顿段中间帧），值偏移为 0 ⇒
#       抓取点与【关键帧点】在屏幕上完全重合，而拾取又优先手柄
#       ⇒ 用户每次想挪关键帧，都会先抓到手柄（误触）。
#
# 做法：把长度为 0 的手柄抓取点从关键帧中心沿【屏幕水平方向】挪开一段，
#       用小空心圆表示 —— 点关键帧中心 = 挪关键帧；点空心圆 = 抓手柄。
#
# ⚠️ 只挪【抓取点（UI）】，不改任何数据：
#      · 手柄长度仍为 0 ⇒ 不画手柄线（保持"未拖时看不见线"的现状语义）
#      · 这才是关键：不引入补偿、不引入中介层
#
# ★ 判据只认「长度为 0」，【不限】是不是首末帧（2026-09-17 用户拍板方案 A）：
#    根因是「长度 0 ⇒ 抓取点与关键帧重合」，与帧的位置无关。
#    停顿/保持段（相邻关键帧值相同 ⇒ 手柄值偏移 0）的【中间帧】同样会误触，
#    且这种段在动画里极常见（code review 实测：偏移 28px 时关键帧安全区只剩 ±8px）。
#
# ⚠️ 外侧手柄（首帧 left / 末帧 right）【不画不抓】（用户 2026-09-16 拍板）：
#    实测（`_outer4.py`，Blender 5.2.1）—— 外侧手柄不参与任何曲线段，
#    且 `extrapolation = CONSTANT`，改它的值分量/时间分量对曲线影响都是 **0.00000000**
#    ⇒ 给它抓取点会让人"拖了没反应"，所以干脆不给。
ENDPOINT_PICK_OFFSET_PX = 32.0     # 抓取点离关键帧的屏幕水平距离（= 关键帧盘 20 + 空心盘 12 ⇒ 两盘相切不重叠）
ENDPOINT_RING_RADIUS_PX = 6.0      # 空心圆屏幕半径
ENDPOINT_RING_SEGMENTS = 18        # 圆环段数
# 判定"手柄长度为 0"用唯一判据 `handle_is_zero_length()`（见下，屏幕像素口径）——
# ⚠️ 它与 `interaction.locate_handle_under_cursor` 的几何守卫共用同一函数、严格互补，
#    两者合起来覆盖全部区间，不留"两边都不认"的缝。
#    【不要】再写第二份判据（世界长度 1e-4 那版已被证明有 0.005px~20px 的死区）。


def _view_ctx(context):
    """拿当前 3D 视图的 (region, rv3d)；拿不到返回 (None, None)。"""
    try:
        region = getattr(context, "region", None)
        space = getattr(context, "space_data", None)
        rv3d = getattr(space, "region_3d", None) if space is not None else None
        if region is None or rv3d is None:
            return None, None
        return region, rv3d
    except Exception:
        return None, None


# ★★ 2026-10-02：`_world_at_screen_offset` 与 `_ring_world_points` **已删除**。
#
#   它们服务的是旧做法：把抓取环「正投到屏幕 → 加 32px → **反投影**回世界 →
#   当 3D 线画」。实测那趟往返**不闭合**（视口正中心差 10 像素）⇒
#     · 环与关键帧的实际屏幕间距 ≠ 32px ⇒ 拾取盘重叠/留死区（选不中/误触）
#     · 拖关键帧时误差随位置变 ⇒ 环抖
#
#   现在环走**和三角一样**的路：位置每帧现算、纯正向投影、画在 2D 层 ——
#   唯一真相 = `overlay.endpoint_ring_screen_pos`（绘制与拾取共用）。
#
#   ⚠️ 别再写回来。要"屏幕空间几何"就画在 2D 层（`overlay.draw_circle_2d`），
#      不要走"反投影成世界坐标"那条路。
def _endpoint_is_hidden_side(is_first, is_last, side):
    """该侧是否是「不画不抓」的外侧（首帧 left / 末帧 right）。"""
    return (is_first and side == 'left') or (is_last and side == 'right')


def _endpoint_offset_px(side):
    """长度为 0 的手柄抓取点，沿【屏幕水平方向】偏移的像素数。

    方向规则：`right` 向右(+)、`left` 向左(−) —— 即【背离关键帧中心】。
      · 首帧 right（内侧，唯一被登记的一侧）→ +32
      · 末帧 left（内侧，唯一被登记的一侧）→ −32
      · 中间帧两侧（该侧手柄长度为 0 时，如停顿段）→ left −32 / right +32

    外侧（首帧 left / 末帧 right）不登记抓取点，已在 `_endpoint_is_hidden_side` 跳过。
    """
    return ENDPOINT_PICK_OFFSET_PX if side == 'right' else -ENDPOINT_PICK_OFFSET_PX


def world_eps_for_screen(context, point_3d_world, px=None, region=None, rv3d=None):
    """把【屏幕像素】阈值换算成该位置对应的【世界】长度阈值。

    ★ 用途：让**纯数学层**（`transform_domain` 的封口闸门 `_ARM_EPS`）也能用
      「视觉零」口径 —— 那些模块拿不到视图上下文，所以由调用方（interaction）
      先换算好再传进去。这样「手柄长度是否为零」在全插件只有【一个语义】。

    ⚠️ 背景（2026-09-17 实测踩到的 bug）：封口闸门原本用 `_ARM_EPS = 1e-9`（世界），
      而空心圆判据用屏幕 6px ⇒ 两者之间有一段 6 个数量级的死区
      （世界 1e-8 ~ 1e-2 都算"视觉零"却够不到 1e-9）：
      用户把两侧手柄都缩到关键帧点（长度 ~1e-3）时，空心圆出现 ✓，
      一拖却触发封口 ⇒ 对侧 ALIGNED 被永久改成 FREE ✗。

    ⚠️ 取【最严格】的换算（各轴里像素密度最大的那个）：只在明确"视觉零"时才
      认为对侧长度为 0，把影响面压到最小。

    拿不到视图时返回 `HANDLE_ZERO_EPS`（退化为原口径，行为与旧版一致）。
    """
    if px is None:
        px = HANDLE_ZERO_SCREEN_PX
    if region is None or rv3d is None:
        region, rv3d = _view_ctx(context)
    if region is None or rv3d is None:
        return HANDLE_ZERO_EPS
    try:
        s0 = view3d_utils.location_3d_to_region_2d(region, rv3d, point_3d_world)
        if s0 is None:
            return HANDLE_ZERO_EPS
        px_per_world = 0.0
        for axis in ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)):
            s1 = view3d_utils.location_3d_to_region_2d(
                region, rv3d, point_3d_world + mathutils.Vector(axis))
            if s1 is None:
                continue
            px_per_world = max(px_per_world, (s1 - s0).length)
        if px_per_world <= 1e-9:
            return HANDLE_ZERO_EPS
        return px / px_per_world
    except Exception:
        return HANDLE_ZERO_EPS


def local_eps_for_screen(context, point_3d_world, parent_matrix=None,
                         global_scale=1.0, px=None, region=None, rv3d=None):
    """把「屏幕 px 像素」换算成 **F-Curve 局部空间** 的长度阈值。

    ★★ 2026-09-27（3c）：**补上口径换算的缺失一环**。

    ▎为什么要它 —— 绘制与闸门比的不是同一个"量"（实测确认）

      绘制侧判零（`handle_is_zero_length`）比的是**世界空间**长度：
          `wvec = parent_matrix.to_3x3() @ 局部值分量`（见本文件 :720-721）
          ⇒ 判零条件实际是 `|v_局部| · ps · gs ≤ 6/pxw`（ps = 父级 3×3 缩放）

      而封口闸门（`transform_domain` 的 `opp_len < zero_eps`）比的是
      **F-Curve 值分量的长度**（局部空间、既不含 gs 也不含 ps）：
          ⇒ 封口条件实际是 `|v_局部| ≥ 6/pxw`

      ⇒ 两者相差 **ps·gs 倍**。父级带缩放时，屏幕上明明只有 0.6~6px
        （看着就是零长度、也画了空心圆），一拖却触发封口
        ⇒ **对侧 ALIGNED 被永久改成 FREE** ——
        正是 2026-09-17 修过的那条 bug 的回归形态。

      实测数值（ps=0.1、pxw=49）：局部长度 0.5 时
          屏幕 = 0.5·0.1·49 = 2.45px  ⇒ 绘制判零 ✓（画空心圆）
          闸门 = 0.5 > 6/49 = 0.1224  ⇒ **封口** ✗（对侧被改 FREE）
        缝宽 = ps·gs = 10 倍。

    ▎实现说明
      `ps` 取父级 3×3 的**体积缩放因子** `|det|^(1/3)` —— 均匀缩放下精确；
      非均匀缩放时是几何平均（闸门只拿到一个标量长度，无法知道方向，
      这是可接受的最佳近似）。

    拿不到视图时退回 `HANDLE_ZERO_EPS`（与 `world_eps_for_screen` 一致）。
    """
    eps_world = world_eps_for_screen(context, point_3d_world, px, region, rv3d)
    ps = 1.0
    if parent_matrix is not None:
        try:
            ps = abs(float(parent_matrix.to_3x3().determinant())) ** (1.0 / 3.0)
        except Exception:
            ps = 1.0
    gs = float(global_scale) if global_scale else 1.0
    if ps <= 1e-9:
        ps = 1e-9
    if gs <= 1e-9:
        gs = 1e-9
    return eps_world / (ps * gs)


def handle_is_zero_length(context, point_3d_world, world_vec, global_scale,
                          region=None, rv3d=None):
    """该侧手柄是否应视为「长度 0」⇒ 走「空心圆抓取点」形态。

    ★ 口径 = 【屏幕像素】：手柄末端与关键帧点在屏幕上的距离
      <= `state.HANDLE_ZERO_SCREEN_PX`（默认 6px）。

    ⚠️ 为什么口径必须是屏幕像素，不能是世界长度：
      实测（2026-09-17）—— 1 世界单位 ≈ 49px（view_distance=18）
      ⇒ 旧判据 `world_vec.length <= HANDLE_ZERO_EPS(1e-4)` ≈ **0.005px**。
      用户用手拖出来的"很短"在屏幕上还有 1~20px，**永远达不到 1e-4**
      ⇒ 出现「短但不为零」的死区：既不画空心圆，抓取点又落回关键帧上（误触回归）。
      用户实测反馈："中间帧手柄缩小至关键帧点处后，空心圆有时会不出现"。

    优点：① 与用户视觉一致；② 天然随 `rtmp_handle_scale` 自适应
    （scale 调小 ⇒ 屏幕上变短 ⇒ 该判成零时就是零）。

    ⚠️ 本函数是**唯一**判据 —— 绘制侧（`render_keyframe_control_handles`）与
    交互侧（`interaction.locate_handle_under_cursor` 的几何守卫）**共用**，
    且**严格互补**（一边判零 ⇒ 另一边不做几何命中，改由 `get_handle_at_cursor`
    按空心圆抓取点的偏移位置命中）。**不要**再写第二份判据。

    拿不到视图上下文（后台 / 无 region）时降级为世界长度口径，保证不崩。
    """
    if region is None or rv3d is None:
        region, rv3d = _view_ctx(context)
    if region is not None and rv3d is not None:
        try:
            s_kf = view3d_utils.location_3d_to_region_2d(region, rv3d, point_3d_world)
            if s_kf is not None:
                s_end = view3d_utils.location_3d_to_region_2d(
                    region, rv3d, point_3d_world + world_vec * global_scale)
                if s_end is not None:
                    return (s_end - s_kf).length <= HANDLE_ZERO_SCREEN_PX
        except Exception:
            pass
    # 降级（拿不到视图）：退回世界长度口径
    return world_vec.length <= HANDLE_ZERO_EPS


def render_keyframe_control_handles(context, point_3d, frame_kf_map, shader, styles, frame_num, bone=None, parent_matrix=None, collector=None, obj_name=None, is_first_keyframe=False, is_last_keyframe=False):
    """渲染关键帧控制手柄"""
    global _session
    wm = context.window_manager
    global_scale = wm.rtmp_handle_scale
    
    if parent_matrix is None:
        parent_matrix = mathutils.Matrix.Identity(4)
            
    rotation_matrix = parent_matrix.to_3x3()
    
    handle_vector_left = mathutils.Vector((0.0, 0.0, 0.0))
    handle_vector_right = mathutils.Vector((0.0, 0.0, 0.0))
    
    factors_left, factors_right = compute_handle_display_factors(frame_kf_map)
    
    for array_index in range(3):
        if array_index in frame_kf_map:
            keyframe = frame_kf_map[array_index]
            if hasattr(keyframe, 'handle_left') and hasattr(keyframe, 'handle_right'):
                factor_l = factors_left.get(array_index, 1.0)
                factor_r = factors_right.get(array_index, 1.0)
                
                diff_left = (keyframe.handle_left[1] - keyframe.co[1]) * factor_l
                diff_right = (keyframe.handle_right[1] - keyframe.co[1]) * factor_r
                
                if array_index == 0: 
                    handle_vector_left.x = diff_left
                    handle_vector_right.x = diff_right
                elif array_index == 1: 
                    handle_vector_left.y = diff_left
                    handle_vector_right.y = diff_right
                elif array_index == 2: 
                    handle_vector_left.z = diff_left
                    handle_vector_right.z = diff_right
    
    world_vector_left = rotation_matrix @ handle_vector_left
    world_vector_right = rotation_matrix @ handle_vector_right

    # 选中态【不依赖 handle_edit_in_progress】：松开鼠标后仍保持高亮，
    # 这样用户能"选中手柄端点"再进模态操作（用户 2026-09-15 要求）。
    #
    # ⚠️ 用 **(frame, side) 身份**判断选中，不能用索引（2026-09-16 实测）
    #    `_session.active_handle_index` 是"本次收集顺序"里的下标，
    #    而 `handle_control_points` **每帧重绘都会重建** →
    #    索引随时错位 → 选中态根本显示不出来（端点选中"没有视觉反馈"）。
    #
    # ★ 2026-09-16 改为【两侧循环】，以便：
    #    · 跳过外侧（首帧 left / 末帧 right）—— 不画不抓
    #    · 「长度为 0」的抓取点挪开 + 空心圆（★ 2026-09-17 起【不限首末帧】，
    #      停顿段中间帧同样适用 —— 那是同一个根因）
    num_added = 0

    for side, wvec in (('left', world_vector_left), ('right', world_vector_right)):
        # ① 外侧：不画手柄线、不登记抓取点（拖了也没效果，见文件头说明）
        if _endpoint_is_hidden_side(is_first_keyframe, is_last_keyframe, side):
            continue

        scaled_vec = wvec * global_scale
        handle_pos = point_3d + scaled_vec
        is_selected = _session.is_endpoint_selected(
            frame_num, side,
            bone_name=(bone.name if bone else None), obj_name=obj_name)
        line_color = styles.handle_line_color if not is_selected else styles.selected_handle_line_color

        # ② 手柄长度为 0 -> 「空心圆抓取点」：
        #    抓取点沿屏幕水平挪开，好和关键帧点【错开】；不画手柄线。
        #    ★ 不限首末帧（2026-09-17）：停顿段中间帧的误触是【同一个根因】。
        #
        # ⚠️ 判据 = `handle_is_zero_length()`（**唯一**判据，屏幕像素口径 6px），
        #    与 `interaction.locate_handle_under_cursor` 的几何守卫**共用同一函数**、
        #    严格互补：一边判零 ⇒ 另一边不做几何命中，改由 `get_handle_at_cursor`
        #    按空心圆抓取点的偏移位置命中。
        #
        #    ⚠️ 口径是【屏幕像素】而非世界长度 —— 原因见该函数 docstring
        #    （旧的世界长度判据 1e-4 世界 ≈ 0.005px，用户永远拖不到 ⇒ 圆环时有时无）。
        if handle_is_zero_length(context, point_3d, wvec, global_scale):
            off_px = _endpoint_offset_px(side)
            # ★★★ 2026-10-02：抓取环**不再**在这里算位置、也不再在这里画。
            #
            #   旧做法 = 正投到屏幕 → 加 off_px → `region_2d_to_location_3d`
            #   **反投影回世界** → 登记成世界坐标 → 再当 3D 线画出去。
            #   实测那趟往返**不闭合**（视口正中心差 10 像素）⇒
            #     ① 环与关键帧的实际屏幕间距 ≠ off_px ⇒ 拾取盘重叠/留死区
            #        ⇒ 「选不中 / 误触」，且随视角与距离变
            #     ② 拖关键帧时误差随位置变 ⇒ 环**抖**
            #   （三角不抖，因为它只做**一次正向投影**。）
            #
            #   ⇒ 现在只登记**身份 + 像素偏移**，位置交给
            #     `overlay.endpoint_ring_screen_pos` **每帧现算** ——
            #     绘制与拾取共用那**一个**函数（唯一真相）。
            #     多视口也顺带修好了：各自视口各自现算，不会串坐标。
            _session.handle_control_points.append({
                'side': side,
                'frame': frame_num,
                'bone_name': bone.name if bone else None,
                'obj_name': obj_name,
                'hollow': True,
                'off_px': off_px,
            })
            num_added += 1
            # ⚠️ 这里**不再**画环 —— 环由 2D 覆盖层（`overlay._draw_2d`）负责。
            continue          # ← 空心态不画手柄线

        # ③ 常规：手柄线 + 抓取点登记在【手柄末端】
        _session.handle_control_points.append({
            'position': handle_pos,
            'side': side,
            'frame': frame_num,
            'bone_name': bone.name if bone else None,
            'obj_name': obj_name,
        })
        if collector:
            collector.add_line(point_3d, handle_pos, line_color)
        num_added += 1

    
    if num_added > 0:
        for i in range(num_added):
            idx = len(_session.handle_control_points) - num_added + i
            point = _session.handle_control_points[idx]

            # ★ 空心态（端点 + 手柄长度 0）：上面已经画了【空心圆环】，
            #   这里不再画实心端点圆 —— 否则会和空心圆叠成一个实心点。
            if point.get('hollow'):
                continue

            # 端点选中态同样保持（不依赖拖拽中）
            # ⚠️ 用 (frame, side) 身份，不用索引（见上）
            is_selected = _session.is_endpoint_selected(
                point['frame'], point['side'],
                bone_name=point.get('bone_name'),
                obj_name=point.get('obj_name'))
            if is_selected:
                color = styles.selected_handle_endpoint_color
                for layer in range(1, _GLOW_LAYERS + 1):
                    glow_size = styles.handle_endpoint_size + layer * _GLOW_SIZE_STEP
                    glow_alpha = _GLOW_ALPHA_FACTOR * (_GLOW_LAYERS + 1 - layer)
                    glow_color = (
                        min(1.0, color[0] + _GLOW_HANDLE_COLOR_LIFT),
                        min(1.0, color[1] + _GLOW_HANDLE_COLOR_LIFT),
                        min(1.0, color[2] + _GLOW_HANDLE_COLOR_LIFT),
                        glow_alpha
                    )
                    if collector:
                        collector.add_circle(point['position'], glow_size / 2, glow_color)
            else:
                color = styles.handle_endpoint_color
            if collector:
                collector.add_circle(point['position'], styles.handle_endpoint_size / 2, color)


def render_keyframe_marker(context, point_3d, frame_num,
                           is_keyframe_point, is_selected_keyframe,
                           frame_kf_map, action,
                           shader, styles, bone=None, parent_matrix=None, collector=None, obj_name=None,
                           endpoint_frames=None):
    """渲染关键帧标记

    `endpoint_frames`：全套关键帧里的 {最小帧, 最大帧}（首/末帧）。
                       用于端点手柄的「空心圆抓取点」处理（用户 2026-09-16）。
    """
    global _session
    wm = context.window_manager
    
    if _session.drag_in_progress and frame_num == _session.active_frame_number:
        color = styles.selected_keyframe_point_color
        size = styles.keyframe_point_size
    elif is_selected_keyframe:
        color = styles.selected_keyframe_point_color
        size = styles.keyframe_point_size
    elif frame_num == context.scene.frame_current:
        color = (0.3, 0.7, 1.0, 1.0)  
        size = styles.keyframe_point_size * 0.8
    elif is_keyframe_point:
        color = styles.keyframe_point_color
        size = styles.keyframe_point_size
    else:
        return  
    
    
    if is_selected_keyframe or frame_num == context.scene.frame_current or (_session.drag_in_progress and frame_num == _session.active_frame_number):
        
        for layer in range(1, _GLOW_LAYERS + 1):
            glow_size = size + layer * _GLOW_SIZE_STEP
            glow_alpha = _GLOW_ALPHA_FACTOR * (_GLOW_LAYERS + 1 - layer)
            glow_color = (
                min(1.0, color[0] + _GLOW_PATH_COLOR_LIFT),
                min(1.0, color[1] + _GLOW_PATH_COLOR_LIFT),
                min(1.0, color[2] + _GLOW_PATH_COLOR_LIFT),
                glow_alpha
            )
            if collector:
                collector.add_circle(point_3d, glow_size / 2, glow_color)
    
    
    # ⚠️ 端点选中的帧也要画手柄（2026-09-16）
    #    否则"只选端点"（关键帧点被清掉选中）时端点会消失、也无法再被点中。
    if is_selected_keyframe or _session.frame_has_selected_endpoint(
            frame_num, bone_name=(bone.name if bone else None),
            obj_name=obj_name):
        if is_keyframe_point and frame_kf_map:
            _epf = endpoint_frames or set()
            render_keyframe_control_handles(
                context, point_3d, frame_kf_map, shader, styles, frame_num,
                bone=bone, parent_matrix=parent_matrix, collector=collector, obj_name=obj_name,
                is_first_keyframe=(frame_num in _epf and frame_num == min(_epf)),
                is_last_keyframe=(frame_num in _epf and frame_num == max(_epf)),
            )

    if collector:
        collector.add_circle(point_3d, size / 2, color)


def render_motion_path_points(context, obj, parent_matrix, collector, styles, bone=None, obj_name=None):
    """渲染运动路径点"""
    global _session
    cache_key = bone.name if bone else None
    if obj_name is None:
        obj_name = obj.name
    obj_cache = _session.cached_positions.get(obj_name, {})
    if cache_key not in obj_cache:
        return
    bone_name = bone.name if bone else None
    action = obj.animation_data.action if obj.animation_data else None

    frame_keyframe_map = {}
    frame_selected = set()
    if action:
        for fcurve in collect_animation_curves(action, obj):
            if is_position_animation(fcurve, bone_name):
                for keyframe in fcurve.keyframe_points:
                    f = int(keyframe.co[0])
                    if f not in frame_keyframe_map:
                        frame_keyframe_map[f] = {}
                    frame_keyframe_map[f][fcurve.array_index] = keyframe
                    if keyframe.select_control_point:
                        frame_selected.add(f)

    # ★ 首帧 / 末帧（端点）—— 上下传给端点手柄的「空心圆抓取点」处理。
    #   注意：endpoint_frames 一定含 2 个元素（首、末）；只有 1 个关键帧时两者重合。
    endpoint_frames = set()
    if frame_keyframe_map:
        _all_f = list(frame_keyframe_map.keys())
        endpoint_frames = {min(_all_f), max(_all_f)}

    for frame_num, cache_data in obj_cache[cache_key].items():
        local_point = cache_data['position']
        point_3d = parent_matrix @ local_point
        frame_kf_map = frame_keyframe_map.get(frame_num, {})
        is_selected_keyframe = frame_num in frame_selected
        render_keyframe_marker(
            context, point_3d, frame_num,
            True, is_selected_keyframe,
            frame_kf_map, action,
            None, styles,
            bone=bone, parent_matrix=parent_matrix,
            collector=collector, obj_name=obj_name,
            endpoint_frames=endpoint_frames,
        )


def render_path_overlay():
    """渲染路径覆盖层"""
    context = bpy.context

    try:
        if not context.space_data or context.space_data.type != 'VIEW_3D':
             return

        wm = context.window_manager
        # ⚠️ 2026-09-27：getattr 守卫 —— 插件卸载后这两个属性都被 `del`，
        #    而**泄漏的**绘制回调仍会每帧走到这里（裸访问 ⇒ 每帧抛
        #    AttributeError，被外层 except 吞掉后 print + print_exc
        #    ⇒ 控制台每帧刷屏，正是 state.py 里记过的那类症状）。
        if not getattr(wm, "rtmp_edit_mode_active", False) \
                and not getattr(wm, "rtmp_path_display_enabled", False):
            return
        
        global _session
        obj = context.active_object

        styles = get_addon_prefs(context)

        gpu.state.blend_set('ALPHA')

        frame_start = context.scene.frame_start

        # 受影响路径段高亮（由交互层 overlay.set_segment_highlight 设置）
        hl = None
        hl_groups = []
        hl_color = (1.0, 0.62, 0.12, 0.95)
        hl_width = 4.0
        try:
            from . import overlay as _ovmod
            hl_color = _ovmod.SEGMENT_SPARSE_COLOR
            hl_width = _ovmod.SEGMENT_HIGHLIGHT_WIDTH
            hl_groups = _ovmod.get_segment_highlights()
            hl = hl_groups[0] if hl_groups else None
            if hl is not None and len(hl) > 3:
                # 颜色区分方向：变疏=橙，变密=蓝（用户 2026-09-15）
                hl_color = _ovmod.highlight_color(hl[3])
        except Exception:
            hl = None
            hl_groups = []

        shader = None
        if wm.rtmp_path_display_enabled and _session.path_point_sequence:
            shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
            viewport_size = gpu.state.viewport_get()[2:]
            
            for (pv_obj_name, pv_bone_name), vertices in _session.path_point_sequence.items():
                if not vertices:
                    continue
                draw_obj = bpy.data.objects.get(pv_obj_name)
                if not draw_obj:
                    continue
                
                draw_bone = None
                if pv_bone_name and draw_obj.mode == 'POSE' and draw_obj.pose:
                    draw_bone = draw_obj.pose.bones.get(pv_bone_name)
                    if not draw_bone:
                        continue
                
                pv_parent_matrix = resolve_parent_transform(draw_obj, draw_bone)
                
                world_points = []
                for v in vertices:
                    try:
                        p = pv_parent_matrix @ v
                        px = p[0]
                        py = p[1]
                        pz = p[2]
                        if (math.isfinite(px) and math.isfinite(py) and math.isfinite(pz) and
                            abs(px) < SAFE_LIMIT and abs(py) < SAFE_LIMIT and abs(pz) < SAFE_LIMIT):
                            world_points.append((px, py, pz))
                    except Exception:
                        continue
                
                if len(world_points) >= 2:
                    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": world_points})
                    shader.bind()
                    shader.uniform_float("viewportSize", viewport_size)
                    shader.uniform_float("lineWidth", styles.path_width)
                    shader.uniform_float("color", styles.path_color)
                    batch.draw(shader)

                # ★ 受影响路径段高亮
                #   用户 2026-09-15 定义的语义：
                #     高亮长度 = 疏密程度（"胀满整段" = 到达理论极值），
                #     相当于把"原来会移动的三角"换成"会生长的色带"。
                # ★ 多选时**所有**受影响的路径段都高亮（用户 2026-09-16）
                if hl_groups and shader is not None:
                    for hl in hl_groups:
                        try:
                            hl_frame, hl_side, hl_t = hl[0], hl[1], hl[2]
                            _c = hl_color
                            if len(hl) > 3:
                                _c = _ovmod.highlight_color(hl[3])
                            rng = segment_frame_range(
                                draw_obj.animation_data.action if draw_obj.animation_data else None,
                                draw_obj, hl_frame, hl_side, pv_bone_name)
                            if rng and hl_t > 1e-4:
                                i_kf = int(round(hl_frame)) - frame_start
                                i_nb = int(round(rng[0] if hl_side == 'left' else rng[1])) - frame_start
                                # 从关键帧朝相邻关键帧方向，按 t 决定胀满多少
                                span = i_nb - i_kf
                                i_end = i_kf + int(round(span * hl_t))
                                k0 = min(i_kf, i_end)
                                k1 = max(i_kf, i_end)
                                sub = []
                                for k in range(max(0, k0), min(k1 + 1, len(vertices))):
                                    try:
                                        p = pv_parent_matrix @ vertices[k]
                                        px, py, pz = p[0], p[1], p[2]
                                        if (math.isfinite(px) and math.isfinite(py)
                                                and math.isfinite(pz)
                                                and abs(px) < SAFE_LIMIT and abs(py) < SAFE_LIMIT
                                                and abs(pz) < SAFE_LIMIT):
                                            sub.append((px, py, pz))
                                    except Exception:
                                        continue
                                if len(sub) >= 2:
                                    hb = batch_for_shader(shader, 'LINE_STRIP', {"pos": sub})
                                    shader.bind()
                                    shader.uniform_float("viewportSize", viewport_size)
                                    shader.uniform_float("lineWidth", hl_width)
                                    shader.uniform_float("color", _c)
                                    hb.draw(shader)
                        except Exception:
                            pass

                if styles.show_frame_points and world_points:
                    render_circle_batch(context, world_points, styles.frame_point_size / 2, styles.frame_point_color, segments=8)
        
        _session.handle_control_points = []
        # ★ 2026-10-02（code review）：**同一帧同源**清掉抓取环记录 ——
        #   否则本函数若在收集前早退（路径显示关掉等），2D 覆盖层会拿着
        #   **上一帧**的环继续画（画在过期位置上）。
        try:
            from . import overlay as _ovm0
            _ovm0.get_overlay().set_hollow_records([])
        except Exception:
            pass
        
        collector = DrawCollector()
        
        if obj and obj.mode == 'POSE':
            try:
                bones_to_draw = list(context.selected_pose_bones or [])
                active_bone = context.active_pose_bone
                if active_bone and active_bone not in bones_to_draw:
                    bones_to_draw.append(active_bone)
            except Exception:
                bones_to_draw = []
            for bone in bones_to_draw:
                try:
                    bone_parent_matrix = resolve_parent_transform(obj, bone)
                    render_motion_path_points(context, obj, bone_parent_matrix, collector, styles, bone=bone)
                except Exception:
                    continue
        else:
            for obj_name_cache, obj_cache in _session.cached_positions.items():
                try:
                    draw_obj = bpy.data.objects.get(obj_name_cache)
                    if not draw_obj:
                        continue
                    obj_parent_matrix = resolve_parent_transform(draw_obj)
                    render_motion_path_points(context, draw_obj, obj_parent_matrix, collector, styles, obj_name=obj_name_cache)
                except Exception:
                    continue
             
        # ★★ 2026-10-02：把「抓取环」的身份记录交给 2D 覆盖层 ——
        #   环的**位置**由覆盖层每帧现算（`overlay.endpoint_ring_screen_pos`），
        #   这里只交出身份 + off_px。
        #   ⚠️ 必须在**收集之后**、与 `handle_control_points` 同一帧产出；
        #      漏了这一步 ⇒ 环**根本不会被画**（用户实测：「直接看不到抓取环」）。
        try:
            from . import overlay as _ovm
            # ★ 每条带上**选中态**：抓取环要用「选中色」画（与 3D 时代同一个判据
            #   `_session.is_endpoint_selected(frame, side)`）。
            #   ⚠️ 漏了它 ⇒ 选中后环**不高亮**（用户 2026-10-02 实测反馈）。
            _hollow_recs = []
            for _hp in _session.handle_control_points:
                if not _hp.get('hollow'):
                    continue
                _q = dict(_hp)
                try:
                    _q['selected'] = bool(_session.is_endpoint_selected(
                        _hp.get('frame'), _hp.get('side'),
                        bone_name=_hp.get('bone_name'),
                        obj_name=_hp.get('obj_name')))
                except Exception:
                    _q['selected'] = False
                _hollow_recs.append(_q)
            # ★ 抓取环数据喂入留痕（节流：仅集合变化时记，见 _ring_feed_state 说明）。
            #   排查"看不到抓取环 / 环数量不对 / 环身份错位"靠这条。
            _feed_sig = tuple((r.get('frame'), r.get('side')) for r in _hollow_recs)
            if _feed_sig != _ring_feed_state["sig"]:
                _ring_feed_state["sig"] = _feed_sig
                dbg("ring.feed", n=len(_hollow_recs),
                    frames=[r.get('frame') for r in _hollow_recs][:24],
                    sides=[r.get('side') for r in _hollow_recs][:24])
            _ovm.get_overlay().set_hollow_records(_hollow_recs)
        except Exception:
            pass

        collector.draw(context, styles)

        if obj and styles.show_origin_indicator:
            target_bone = None
            if obj.mode == 'POSE':
                target_bone = context.active_pose_bone
                if not target_bone and context.selected_pose_bones:
                    target_bone = context.selected_pose_bones[0]
            render_origin_marker(context, obj, target_bone, styles)
        
    except Exception as e:
        print(f"Error in path overlay: {e}")
        import traceback
        traceback.print_exc()


def attach_render_callback():
    """附加渲染回调"""
    if _session.render_callback_id is not None:
        return
    _session.render_callback_id = bpy.types.SpaceView3D.draw_handler_add(
        render_path_overlay, (), 'WINDOW', 'POST_VIEW')


def detach_render_callback():
    """分离渲染回调"""
    handler = _session.render_callback_id
    if handler is None:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
    except Exception:
        pass                       # 已被移除 / 句柄失效 —— 不能因此中断卸载
    _session.render_callback_id = None


def purge_stale_draw_handlers(keep_session=None):
    """清理【孤儿】绘制回调 —— 修「开关插件开关后绘制残留」（用户 2026-09-17）。

    ▎症状
        红色运动路径上出现**黑色长直线**（= 旧回调用旧数据又画了一遍），
        且关掉开关也消不掉。

    ▎机理（实测：诊断出 2 个 handler 同时注册）
        `draw_handler` 一旦注册，句柄**只存**在 `_session.render_callback_id` 里。
        若插件在**没走 detach** 的情况下卸载（旧版 `unregister()` 就漏了这一步），
        或模块被强制重载（绕过 unregister，例如热重载脚本删 `sys.modules`），
        句柄就丢了 —— 而**回调本身仍在注册表里**运行，且其闭包引用着
        **旧模块**（旧 `_session` / 旧 `render_path_overlay`）
        ⇒ GC 也收不走（被 C 层注册表持有）
        ⇒ 新模块再注册一个 ⇒ **两个回调同时画** ⇒ 残留。

    ▎做法
        扫 GC 找出插件的会话 / 覆盖层对象，把**它们还持有**的 handler 逐个移除。
        `keep_session` 传当前会话（不动它持有的 handler）。

        ※ 这是"兜底"：正常路径应是 `unregister()` 里调 `detach_render_callback()`。
          这里额外扫一遍，是为了兜住"绕过 unregister 的强制重载"。

    ▎判据
        用 `type(o).__module__.startswith(__package__)` 而非类名 ——
        跨模块重载后旧类是**另一个类对象**，但 `__module__` 仍是包名（可靠）；
        只比类名会误伤同名的第三方类。
        ⚠️ 包名必须取 `__package__`，**不能硬编码**：以 Blender Extension
        安装时模块名由 blender_manifest.toml 的 id 决定（2026-09-18 盲审 L5）。

    返回 `(removed, failed)` 两个句柄列表。
    """
    import gc as _gc
    removed, failed = [], []

    def _try_remove(owner, slot):
        h = getattr(owner, slot, None)
        if h is None:
            return
        try:
            bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
            removed.append(h)
        except Exception as e:
            # 已经移除过 / 句柄失效：记下来但**照旧清空字段**，
            # 免得下次又拿着同一个死句柄重试
            failed.append("%s: %s" % (repr(h)[:44], str(e)[:50]))
        setattr(owner, slot, None)

    # ★ 2026-09-18（盲审 L5）：包名**不要硬编码** —— 用 `__package__`。
    #   原因：以 Blender **Extension** 形式安装时，模块名由 blender_manifest.toml
    #   的 id 决定，不一定等于 "RealTimeMotionPath"。硬编码会导致本函数
    #   **静默什么都不清** ⇒ v1.2.1 修好的"绘制残留"回归。
    #   （`state.purge_stale_app_handlers` 用的就是这个正确写法。）
    pkg = __package__ or "RealTimeMotionPath"
    for o in _gc.get_objects():
        try:
            t = type(o)
            if not str(getattr(t, "__module__", "")).startswith(pkg):
                continue
            name = t.__name__
            if name == "MotionPathSession":
                if keep_session is not None and o is keep_session:
                    continue
                _try_remove(o, "render_callback_id")
            elif name == "Overlay":
                _try_remove(o, "_h_view")
                _try_remove(o, "_h_pixel")
        except Exception:
            continue
    return removed, failed
