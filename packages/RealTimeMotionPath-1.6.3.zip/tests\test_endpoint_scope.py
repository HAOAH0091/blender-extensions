# -*- coding: utf-8 -*-
"""回归：端点选中必须携带对象/骨骼身份，且同步 Blender 活动骨。"""
import importlib
import json
import os
import sys
import traceback
import types

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    pkg = types.ModuleType(PKG)
    pkg.__path__ = [ADDON_DIR]
    pkg.__package__ = PKG
    sys.modules[PKG] = pkg

state = importlib.import_module(PKG + ".state")
interaction = importlib.import_module(PKG + ".interaction")
modal_edit = importlib.import_module(PKG + ".modal_edit")
td = importlib.import_module(PKG + ".time_domain")

results = []


def check(name, ok, detail=""):
    results.append({
        "name": name,
        "ok": bool(ok),
        "detail": str(detail),
    })


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.frame_start, scene.frame_end = 1, 55
    bpy.ops.object.armature_add(location=(0, 0, 0))
    arm = bpy.context.view_layer.objects.active
    arm.name = "EndpointScope"
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = arm.data.edit_bones
    edit_bones[0].name = "BoneA"
    bone_b = edit_bones.new("BoneB")
    bone_b.head = (3.0, 0.0, 0.0)
    bone_b.tail = (3.0, 1.0, 0.0)
    bpy.ops.object.mode_set(mode='POSE')

    for frame in (1, 25, 55):
        for name in ("BoneA", "BoneB"):
            pb = arm.pose.bones[name]
            pb.location = (0.0, 0.0, 0.0)
            pb.keyframe_insert("location", frame=frame)
    scene.frame_set(25)
    for pb in arm.pose.bones:
        pb.select = True
    arm.data.bones.active = arm.data.bones["BoneA"]
    bpy.context.view_layer.update()
    for bone_name in ("BoneA", "BoneB"):
        for fc in td._collect_position_curves(
                arm.animation_data.action, arm, bone_name):
            for kp in fc.keyframe_points:
                kp.select_control_point = False
    return arm


try:
    arm = build()
    session = state._session
    session.reset()
    session.active_bone_identifier = "BoneA"

    handle_b = {
        "obj_name": arm.name,
        "bone_name": "BoneB",
        "frame": 25.0,
        "side": "left",
    }
    selected = interaction.select_handle_endpoint(
        bpy.context, arm, handle_b, shift=False)
    bpy.context.view_layer.update()

    check("endpoint click selects the clicked endpoint",
          selected is True and session.is_endpoint_selected(
              25.0, "left", bone_name="BoneB", obj_name=arm.name),
          session.selected_handle_endpoints)
    check("endpoint click syncs Blender active pose bone",
          (bpy.context.active_pose_bone is not None
           and bpy.context.active_pose_bone.name == "BoneB"),
          bpy.context.active_pose_bone.name if bpy.context.active_pose_bone else None)
    check("endpoint click syncs session bone identity",
          session.active_bone_identifier == "BoneB",
          session.active_bone_identifier)
    check("BoneA query cannot see BoneB endpoint",
          not session.is_endpoint_selected(
              25.0, "left", bone_name="BoneA", obj_name=arm.name),
          session.selected_handle_endpoints)

    eps_b = modal_edit._transform_targets(arm, arm.animation_data.action, "BoneB")
    eps_a = modal_edit._transform_targets(arm, arm.animation_data.action, "BoneA")
    check("modal target filter exposes only BoneB endpoint",
          bool(eps_b[2]) and eps_b[1] == [(25.0, "left")] and not eps_a[1],
          "BoneB=%r BoneA=%r" % (eps_b, eps_a))

    session.clear_endpoints()
    handle_a = dict(handle_b, bone_name="BoneA")
    interaction.select_handle_endpoint(bpy.context, arm, handle_a, shift=False)
    interaction.select_handle_endpoint(bpy.context, arm, handle_b, shift=True)
    scoped = session.endpoints_for_scope("BoneB", arm.name)
    stale_a = session.endpoints_for_scope("BoneA", arm.name)
    check("shift-click across bones replaces the old bone scope",
          scoped == [(25.0, "left")] and not stale_a,
          "BoneB=%r BoneA=%r raw=%r"
          % (scoped, stale_a, session.selected_handle_endpoints))

    def handle_y(bone_name, frame=25.0, side="left"):
        for fc in td._collect_position_curves(
                arm.animation_data.action, arm, bone_name):
            for kp in fc.keyframe_points:
                if abs(float(kp.co[0]) - frame) < 1e-3:
                    handle = kp.handle_left if side == "left" else kp.handle_right
                    return float(handle[1])
        return None

    win = bpy.context.window_manager.windows[0]
    area = next(a for a in win.screen.areas if a.type == 'VIEW_3D')
    region = next(r for r in area.regions if r.type == 'WINDOW')
    rv3d = area.spaces.active.region_3d
    rv3d.view_location = (3.0, 0.5, 0.0)
    rv3d.view_distance = 16.0
    mx = float(region.width) * 0.5 if region.width else 100.0
    my = float(region.height) * 0.5 if region.height else 100.0

    before_a = handle_y("BoneA")
    before_b = handle_y("BoneB")
    move = modal_edit.MoveSession("MOVE")
    routed = modal_edit._pose_bone_name(bpy.context)
    began = move.begin(
        arm, arm.animation_data.action, region, rv3d, mx, my,
        bone_name=routed)
    moved = move.update(mx, my + 45.0)
    after_a = handle_y("BoneA")
    after_b = handle_y("BoneB")
    move.restore()
    check("cross-bone G writes only the endpoint's bone",
          began is True and moved is True and routed == "BoneB"
          and before_a is not None and after_a is not None
          and before_b is not None and after_b is not None
          and abs(after_a - before_a) < 1e-7
          and abs(after_b - before_b) > 1e-5,
          "routed=%r BoneA=%r->%r BoneB=%r->%r"
          % (routed, before_a, after_a, before_b, after_b))

    session.active_bone_identifier = "BoneA"
    arm.data.bones.active = arm.data.bones["BoneA"]
    bpy.context.view_layer.update()
    interaction._activate_pose_bone_identity(bpy.context, arm, "BoneB")
    check("path-point/handle-line activation also switches active bone",
          (bpy.context.active_pose_bone is not None
           and bpy.context.active_pose_bone.name == "BoneB")
          and session.active_bone_identifier == "BoneB",
          bpy.context.active_pose_bone.name if bpy.context.active_pose_bone else None)
except Exception:
    check("exception", False, traceback.format_exc()[-2000:])

fails = [row for row in results if not row["ok"]]
summary = {
    "total": len(results),
    "fails": len(fails),
    "suspects": 0,
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "steps": results,
}
with open(os.path.join(HERE, "_es_result.json"), "w", encoding="utf-8") as fh:
    json.dump(summary, fh, ensure_ascii=False, indent=1)
print("ENDPOINT_SCOPE_TOTAL=%d FAILS=%d" % (len(results), len(fails)))
