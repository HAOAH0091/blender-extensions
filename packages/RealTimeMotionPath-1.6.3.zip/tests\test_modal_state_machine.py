# -*- coding: utf-8 -*-
"""模态状态机端到端验证（headless）

直接驱动 ModalSession（operator 只是薄壳），验证：
  1. begin 能解出目标（关键帧 + 侧）
  2. 向下拖 -> 该侧变疏
  3. 向上拖 -> 该侧变密
  4. cancel -> 恢复原状
  5. confirm -> 保留改动
  6. 端点段被拒绝
  7. 未实现模式被拒绝
  8. 鼠标远离关键帧被拒绝
  9. 改右侧不影响左侧段
"""
import sys, os, json, types, importlib

HERE = os.path.dirname(os.path.abspath(__file__))
ADDON_DIR = os.path.dirname(HERE)
PARENT = os.path.dirname(ADDON_DIR)
PKG = os.path.basename(ADDON_DIR)
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if PKG not in sys.modules:
    pkg = types.ModuleType(PKG); pkg.__path__ = [ADDON_DIR]; pkg.__package__ = PKG
    sys.modules[PKG] = pkg

import bpy, mathutils
td = importlib.import_module(PKG + ".time_domain")
me = importlib.import_module(PKG + ".modal_edit")
xf = importlib.import_module(PKG + ".transform_domain")

results = []
def check(name, ok, detail=""):
    results.append(("PASS" if ok else "FAIL", name, str(detail)))
def note(name, detail=""):
    results.append(("NOTE", name, str(detail)))

KEYPOS = {1: (0.0, 0.0, 0.0), 14: (4.0, 3.0, 0.0),
          27: (8.0, -2.0, 0.0), 40: (12.0, 1.0, 0.0)}
SCREEN = {1: (100, 300), 14: (180, 300), 27: (260, 300), 40: (340, 300)}


class FakeCtx:
    class _A:
        type = 'VIEW_3D'
        def tag_redraw(self): pass
    area = _A()
    region = object()
    region_data = object()


def fake_screen_pos(region, rv3d, world):
    for f, p in KEYPOS.items():
        if (abs(world.x - p[0]) < 1e-6 and abs(world.y - p[1]) < 1e-6
                and abs(world.z - p[2]) < 1e-6):
            return mathutils.Vector(SCREEN[f])
    return None

me._screen_pos = fake_screen_pos
me.PICK_RADIUS = 60.0
CTX = FakeCtx()


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.frame_start, sc.frame_end = 1, 40
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = "TestObj"
    for f, loc in [(1, (0, 0, 0)), (14, (4, 3, 0)), (27, (8, -2, 0)), (40, (12, 1, 0))]:
        sc.frame_set(f); o.location = loc; o.keyframe_insert("location", frame=f)
    act = o.animation_data.action
    for fc in td._collect_position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'; kp.handle_right_type = 'FREE'
        pts = list(fc.keyframe_points)          # 全段共线 = 匀速基线
        for i in range(len(pts) - 1):
            k0, k1 = pts[i], pts[i + 1]
            t0, v0, t1, v1 = k0.co[0], k0.co[1], k1.co[0], k1.co[1]
            k0.handle_right = (t0 + (t1 - t0) / 3, v0 + (v1 - v0) / 3)
            k1.handle_left = (t0 + 2 * (t1 - t0) / 3, v0 + 2 * (v1 - v0) / 3)
        fc.update()
    return o, act


def sample_x(o, act):
    for fc in td._collect_position_curves(act, o, None):
        if fc.array_index == 0:
            return [round(fc.evaluate(f), 8) for f in range(1, 41)]
    return []


def first_dist(o, act, kf_frame=14):
    """目标关键帧【之后】第一段帧距 —— 该侧疏密的直接体现"""
    X = sample_x(o, act)
    i = kf_frame            # 帧 kf+1 对应索引 kf（0-based）
    return abs(X[i] - X[i - 1])


def resolve(ctx, o, act, mx, my):
    return me.resolve_speed_target(ctx, o, act, mx, my)


# ---------------- 1. begin 解目标（鼠标在 f14 下方 -> right 段） ----------------
o, act = build()
sx, sy = SCREEN[14]
sess = me.ModalSession('SPEED')
ok = sess.begin(o, act, sx, sy - 20, lambda x, y: resolve(CTX, o, act, x, y))
check("begin() succeeds", ok is True, sess.message)
check("state == RUNNING", sess.state == me.STATE_RUNNING, sess.state)
check("target frame == 14", sess.target and int(sess.target["frame"]) == 14,
      sess.target and sess.target["frame"])
check("side == right (mouse below keyframe)", sess.target and sess.target["side"] == 'right',
      sess.target and sess.target["side"])
# ★ 2026-09-27（复盘）：i18n 把状态栏文案统一成英文后，这条钉死中文字串的
#   断言必然失败。改成【语义标记 + 双语兼容】—— 判"意图"而不是"某个中文词"，
#   以后统一文案不会再假失败（这次它正是被旧 JSON 藏起来的那批回归之一）。
_smt = sess.status_text()
check("status text mentions density",
      ("疏密" in _smt) or ("density" in _smt.lower()), _smt)

# ---------------- 2. 向下拖 -> 变疏 ----------------
base = first_dist(o, act)
sess.update(sx, sy - 20 - 30)     # 再下移 30px
down = first_dist(o, act)
check("drag DOWN -> sparser", down > base * 1.1,
      "base=%.6f down=%.6f (%.2fx)" % (base, down, down / base))
check("last_s decreased", sess.last_s < td.S_LIN, "s=%.4f" % sess.last_s)

# ---------------- 3. cancel -> 恢复 ----------------
sess.cancel()
check("cancel -> state DONE", sess.state == me.STATE_DONE, sess.state)
check("cancel restores frame-dist", abs(first_dist(o, act) - base) < 1e-6,
      "restored=%.8f base=%.8f" % (first_dist(o, act), base))

# ---------------- 4. 向上拖 -> 变密，confirm -> 保留 ----------------
o, act = build()
sess = me.ModalSession('SPEED')
sess.begin(o, act, sx, sy - 20, lambda x, y: resolve(CTX, o, act, x, y))
base = first_dist(o, act)
sess.update(sx, sy - 20 + 26)     # 上移 26px
up = first_dist(o, act)
check("drag UP -> denser", up < base * 0.9,
      "base=%.6f up=%.6f (%.2fx)" % (base, up, up / base))
sess.confirm()
check("confirm -> state DONE", sess.state == me.STATE_DONE, sess.state)
check("confirm KEEPS change", abs(first_dist(o, act) - up) < 1e-9,
      "kept=%.8f up=%.8f" % (first_dist(o, act), up))

# ---------------- 5. 上三角（鼠标在关键帧上方 -> left 段） ----------------
o, act = build()
sess = me.ModalSession('SPEED')
sess.begin(o, act, sx, sy + 20, lambda x, y: resolve(CTX, o, act, x, y))
check("mouse above keyframe -> side left", sess.target and sess.target["side"] == 'left',
      sess.target and sess.target["side"])

# ---------------- 6. 端点段被拒绝 ----------------
o, act = build()
s1x, s1y = SCREEN[1]
sess = me.ModalSession('SPEED')
ok = sess.begin(o, act, s1x, s1y + 20, lambda x, y: resolve(CTX, o, act, x, y))
check("endpoint segment (f1 left) rejected", ok is False, sess.message)
check("state stays IDLE", sess.state == me.STATE_IDLE, sess.state)

# ---------------- 7. 未实现模式 ----------------
o, act = build()
sess = me.ModalSession('MOVE')
ok = sess.begin(o, act, sx, sy, lambda x, y: resolve(CTX, o, act, x, y))
check("unimplemented mode rejected", ok is False, sess.message)

# ---------------- 8. 鼠标远离 ----------------
o, act = build()
sess = me.ModalSession('SPEED')
ok = sess.begin(o, act, 9999, 9999, lambda x, y: resolve(CTX, o, act, x, y))
check("mouse far -> rejected", ok is False, sess.message)

# ---------------- 9. 分离态：目标关键帧两侧独立 ----------------
o, act = build()
xf.set_tri_locked(act, 14, False)
sess = me.ModalSession('SPEED')
sess.begin(o, act, sx, sy - 20, lambda x, y: resolve(CTX, o, act, x, y))
X_before = sample_x(o, act)
sess.update(sx, sy - 20 - 30)
X_after = sample_x(o, act)
seg0_changed = max(abs(X_before[i] - X_after[i]) for i in range(0, 13))
check("split: editing right side does NOT change left segment", seg0_changed < 1e-6,
      "max dev in seg0 = %.2e" % seg0_changed)

# ---------------- 9b. 锁定态：两侧联动（对侧按 GE 共线反解） ----------------
o, act = build()
sess = me.ModalSession('SPEED')
sess.begin(o, act, sx, sy - 20, lambda x, y: resolve(CTX, o, act, x, y))
X_before = sample_x(o, act)
sess.update(sx, sy - 20 - 30)
X_after = sample_x(o, act)
seg0_changed_locked = max(abs(X_before[i] - X_after[i]) for i in range(0, 13))
check("locked: editing right side also adjusts left segment (keep GE collinear)",
      seg0_changed_locked > 1e-4,
      "max dev in seg0 = %.2e" % seg0_changed_locked)
sess.cancel()
X_restored = sample_x(o, act)
check("locked: cancel restores BOTH sides",
      max(abs(X_before[i] - X_restored[i]) for i in range(0, 40)) < 1e-6,
      "max dev after cancel = %.2e"
      % max(abs(X_before[i] - X_restored[i]) for i in range(0, 40)))


# ---------------- 10. 多目标取消：所有目标都必须回滚 ----------------
def current_s(o, act, frame, side):
    kf_map, span = td.resolve_target(act, o, frame, side, None)
    if not kf_map or span is None:
        return None
    return td.read_s(next(iter(kf_map.values())), span, side)


o, act = build()
specs = [(14.0, 'right'), (27.0, 'right')]


def multi_resolver(_mx, _my):
    out = []
    for frame, side in specs:
        kf_map, span = td.resolve_target(act, o, frame, side, None)
        out.append(me.make_target(
            frame, side, span, kf_map, 100.0, 100.0,
            world=None, bone_name=None))
    return out


sess = me.ModalSession('SPEED')
ok = sess.begin(o, act, 100.0, 100.0, multi_resolver)
before_multi = [current_s(o, act, frame, side) for frame, side in specs]
sess.update(100.0, 160.0)
during_multi = [current_s(o, act, frame, side) for frame, side in specs]
sess.cancel()
after_multi = [current_s(o, act, frame, side) for frame, side in specs]

check("multi-target begin captures every target snapshot",
      ok is True and len(getattr(sess, "snapshots", []) or []) == 2,
      "snapshots=%d" % len(getattr(sess, "snapshots", []) or []))
check("multi-target apply really changes every target",
      all(abs(a - b) > 1e-4 for a, b in zip(before_multi, during_multi)),
      "before=%r during=%r" % (before_multi, during_multi))
check("multi-target cancel restores every target",
      all(a is not None and b is not None and abs(a - b) < 1e-9
          for a, b in zip(before_multi, after_multi)),
      "before=%r after=%r" % (before_multi, after_multi))


fails = [r for r in results if r[0] == "FAIL"]
summary = {
    "total": len([r for r in results if r[0] != "NOTE"]),
    "fails": len(fails),
    "result": "ALL PASS" if not fails else "HAS FAILURES",
    "rows": [{"status": s, "name": n, "detail": d} for s, n, d in results],
}
json.dump(summary, open(os.path.join(HERE, "_ms_result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print("WROTE_MS_JSON")
