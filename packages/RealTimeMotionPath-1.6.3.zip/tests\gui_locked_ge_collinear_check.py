# -*- coding: utf-8 -*-
"""锁定态速度三角：拖动后 GE 左右手柄必须**逐轴共线**。

用户 2026-11-11：
    「三角控制柄处于锁定状态时，用户拖拽的话，Graph Editor 的贝塞尔控制柄
      有可能会变得不共线，这样关键帧进出时的速度可能就不同了。
      希望锁定状态下始终保证进出速度一致，也就是 GE 手柄保持共线。」

本测试的判据全部用独立口径（直接读 F-Curve）：
  · GE 逐轴折角 = (dtL,dvL) 与 (-dtR,-dvR) 的夹角；0° = 共线
  · 值分量 A/B 必须原样不动（3D 路径形状不变）
  · 锁定帧只允许“驱动侧 + 对侧反解”，不允许退回“只写驱动侧”

跑法：
  blender -b --factory-startup --python tests/gui_locked_ge_collinear_check.py
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import (time_domain as td, transform_domain as xf,
                                interaction as it, modal_edit as me,
                                handles as hd)
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_locked_ge_collinear_result.json")
steps = []
FR = 25.0

# 三轴 dv 比例刻意不同：
#   左 dv = (-6,-4,0)，右 dv = (8,2,0)；左右 dt 都是 8/10
#   ⇒ 初始 X 斜率 0.75/0.8、Y 斜率 0.5/0.2（不共线）
LEFT_DV = {0: -6.0, 1: -4.0, 2: 0.0}
RIGHT_DV = {0: 8.0, 1: 2.0, 2: 0.0}


def step(name, ok, detail=""):
    steps.append({"name": name, "ok": bool(ok), "detail": str(detail)[:1200]})


def build(name):
    sc = bpy.context.scene
    old = bpy.data.objects.get(name)
    if old:
        bpy.data.objects.remove(old, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in ((1, (-2.0, -1.0, -0.5)),
                   (25, (0.0, 0.0, 0.0)),
                   (55, (2.0, 1.0, 0.5))):
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(1)
    act = o.animation_data.action
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            kp.handle_left_type = 'FREE'
            kp.handle_right_type = 'FREE'
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - FR) < 1e-3:
                ax = int(fc.array_index)
                kp.co[1] = 0.0
                kp.handle_left = (FR - 8.0, LEFT_DV[ax])
                kp.handle_right = (FR + 10.0, RIGHT_DV[ax])
        fc.update()
    bpy.context.view_layer.objects.active = o
    for ob in bpy.data.objects:
        ob.select_set(ob is o)
    _session.clear_speed_handle()
    return o, act


def ge_state(o, frame=FR):
    out = {}
    act = o.animation_data.action
    for fc in xf._position_curves(act, o, None):
        for kp in fc.keyframe_points:
            if abs(float(kp.co[0]) - float(frame)) < 1e-3:
                co, hl, hr = tuple(kp.co), tuple(kp.handle_left), tuple(kp.handle_right)
                dtl, dtr = hl[0] - co[0], hr[0] - co[0]
                dvl, dvr = hl[1] - co[1], hr[1] - co[1]
                ux, uy = dtl, dvl
                vx, vy = -dtr, -dvr
                nu, nv = math.hypot(ux, uy), math.hypot(vx, vy)
                fold = (math.degrees(math.acos(max(-1.0, min(1.0,
                        (ux * vx + uy * vy) / (nu * nv)))))
                        if nu > 1e-12 and nv > 1e-12 else None)
                out[int(fc.array_index)] = {
                    "co": co, "hl": hl, "hr": hr,
                    "dtl": dtl, "dtr": dtr, "dvl": dvl, "dvr": dvr,
                    "slope_l": (dvl / dtl) if abs(dtl) > 1e-12 else None,
                    "slope_r": (dvr / dtr) if abs(dtr) > 1e-12 else None,
                    "fold": fold,
                }
                break
    return out


def ge_ok(o, frame=FR, tol=1e-3):
    st = ge_state(o, frame)
    folds = [v["fold"] for v in st.values() if v["fold"] is not None]
    return bool(folds) and all(f <= tol for f in folds), st


def dv_snapshot(o, frame=FR):
    return {ax: (v["dvl"], v["dvr"])
            for ax, v in ge_state(o, frame).items()}


def read_s(o, frame, side):
    kf, span = td.resolve_target(o.animation_data.action, o, frame, side, None)
    if not kf or span is None:
        return None
    return td.read_s(next(iter(kf.values())), span, side)


def fake_handles(o, frame=FR):
    out = []
    for tri in (hd.TRI_UP, hd.TRI_DOWN):
        side = hd.SIDE_BY_TRI[tri]
        kf, span = td.resolve_target(o.animation_data.action, o, frame, side, None)
        s = td.read_s(next(iter(kf.values())), span, side) if kf and span else None
        out.append(hd.make_handle(frame=float(frame), tri=tri, span=span or 1.0,
                                  s=s if s is not None else td.S_LIN,
                                  d=td.s_to_d(s if s is not None else td.S_LIN),
                                  kf_screen=(100.0, 100.0),
                                  kf_world=(0.0, 0.0, 0.0)))
    return out


def arm_mouse_drag(o, hit_tri=hd.TRI_DOWN, frame=FR):
    """走真实选中逻辑 + 真实 `_apply_speed_from_drag`。"""
    hs = fake_handles(o, frame)
    _session.clear_speed_handle()
    it.apply_speed_click_selection(o, hs, hd.find_handle(hs, frame, hit_tri))
    _session.speed_drag_origin_mouse = (100.0, 100.0)
    _session.speed_drag_origins = {}
    _session.speed_drag_origin_d = 0.0
    for (f, t) in list(_session.selected_speed_handles):
        side = hd.SIDE_BY_TRI.get(t)
        _session.speed_drag_origins[(f, t)] = td.s_to_d_unclamped(
            read_s(o, f, side))
    _session.speed_drag_origin_d = _session.speed_drag_origins.get(
        (frame, hit_tri), td.CV_MID)
    _session.speed_drag_group_origin_s = read_s(
        o, frame, hd.SIDE_BY_TRI.get(hit_tri))
    _session.speed_drag_locked_frame = frame
    _session.speed_drag_effective_px = 0.0
    _session.speed_drag_last_mouse = (100.0, 100.0)
    _session.speed_drag_precision = False
    return hs


def drag_mouse(o, dy=40.0, hit_tri=hd.TRI_DOWN):
    arm_mouse_drag(o, hit_tri=hit_tri)
    _session.speed_drag_last_mouse = (100.0, 100.0)
    it._apply_speed_from_drag(bpy.context, o, (100.0, 100.0 + dy))


def target(o, frame, side):
    kf, span = td.resolve_target(o.animation_data.action, o, frame, side, None)
    return me.make_target(frame, side, span, kf, 100.0, 100.0,
                          world=None, bone_name=None)


try:
    # ============================================================ A 初始场景
    o, act = build("_LGE_A")
    ok0, st0 = ge_ok(o)
    step("A1 初始：X/Y 确实不共线（否则测不出问题）",
         not ok0 and st0[0]["fold"] > 1.0 and st0[1]["fold"] > 1.0,
         "fold=%s slopes=%s" % ({k: round(v["fold"], 4) for k, v in st0.items()
                                 if v["fold"] is not None},
                                {k: (round(v["slope_l"], 4), round(v["slope_r"], 4))
                                 for k, v in st0.items()}))
    _dv0 = dv_snapshot(o)
    _dt0 = {ax: (v["dtl"], v["dtr"]) for ax, v in st0.items()}

    # ============================================================ B 数据层对齐
    res = td.align_locked_speed_pair(act, o, FR, 'left')
    ok1, st1 = ge_ok(o)
    step("B1 ★★★ 数据层对齐：GE 逐轴共线（fold≈0）",
         res.get("ok") is True and ok1,
         "res=%s fold=%s" % (res, {k: round(v["fold"], 8)
                                   for k, v in st1.items() if v["fold"] is not None}))
    step("B2 ★★★ 值分量（3D 路径形状）一个数都没动",
         dv_snapshot(o) == _dv0, "before=%s after=%s" % (_dv0, dv_snapshot(o)))
    step("B3 ★★★ 驱动侧 dt 未动；对侧逐轴 dt = dtL * dvR/dvL",
         abs(st1[0]["dtl"] - _dt0[0][0]) < 1e-9
         and abs(st1[1]["dtl"] - _dt0[1][0]) < 1e-9
         and abs(st1[0]["dtr"] - 8.0 * 8.0 / 6.0) < 1e-5
         and abs(st1[1]["dtr"] - 8.0 * 2.0 / 4.0) < 1e-5,
         "dtL=%s dtR=%s" % ({k: round(v["dtl"], 6) for k, v in st1.items()},
                            {k: round(v["dtr"], 6) for k, v in st1.items()}))
    step("B4 对侧三轴 dt 允许不同（保形状 + GE 共线的数学必然）",
         res.get("uniform") is False,
         "uniform=%s written=%s skipped=%s"
         % (res.get("uniform"), res.get("written_axes"), res.get("skipped_axes")))

    res2 = td.align_locked_speed_pair(act, o, FR, 'left')
    ok2, st2 = ge_ok(o)
    _drift = max(abs(st2[ax]["dtl"] - st1[ax]["dtl"]) +
                 abs(st2[ax]["dtr"] - st1[ax]["dtr"]) for ax in st2)
    step("B5 幂等：再对齐一次不写、不漂移",
         res2.get("already_aligned") is True and _drift < 1e-9,
         "already=%s drift=%.2e" % (res2.get("already_aligned"), _drift))

    # ============================================================ C 鼠标拖动
    o, act = build("_LGE_C")
    _dv_c = dv_snapshot(o)
    _dt_c0 = {ax: v["dtr"] for ax, v in ge_state(o).items()}
    _s_l0, _s_r0 = read_s(o, FR, 'left'), read_s(o, FR, 'right')
    drag_mouse(o, dy=40.0, hit_tri=hd.TRI_DOWN)
    ok3, st3 = ge_ok(o)
    _s_l1, _s_r1 = read_s(o, FR, 'left'), read_s(o, FR, 'right')
    step("C1 ★★★ 锁定态鼠标拖动 ⇒ GE 仍逐轴共线",
         ok3, "fold=%s" % {k: round(v["fold"], 8)
                           for k, v in st3.items() if v["fold"] is not None})
    step("C2 ★★★ 鼠标拖动只改时间分量（值分量不动）",
         dv_snapshot(o) == _dv_c)
    step("C3 ★★ 拖动确实改变了驱动侧（下三角 / right）",
         _s_r1 is not None and abs(_s_r1 - _s_r0) > 1e-4
         and any(abs(st3[ax]["dtr"] - _dt_c0[ax]) > 1e-4 for ax in (0, 1)),
         "s right %.6f→%.6f; dtR=%s" % (_s_r0 or -1, _s_r1 or -1,
                                        {k: round(v["dtr"], 4) for k, v in st3.items()}))
    step("C4 ★★ 对侧（left）被反解同步，而不是保持旧值",
         _s_l1 is not None and abs(_s_l1 - _s_l0) > 1e-4,
         "s left %.6f→%.6f" % (_s_l0 or -1, _s_l1 or -1))

    o, act = build("_LGE_C2")
    drag_mouse(o, dy=-300.0, hit_tri=hd.TRI_DOWN)
    okc2, stc2 = ge_ok(o)
    step("C5 ★★★ 极端拖动（对侧本会撞 s 上限）⇒ 收窄驱动侧范围，GE 仍共线",
         okc2, "fold=%s dtR=%s"
         % ({k: round(v["fold"], 6) for k, v in stc2.items()
             if v["fold"] is not None},
            {k: round(v["dtr"], 4) for k, v in stc2.items()}))

    # ============================================================ D 分离态
    o, act = build("_LGE_D")
    xf.set_tri_locked(act, FR, False)
    _dt_d0 = {ax: v["dtl"] for ax, v in ge_state(o).items()}
    drag_mouse(o, dy=40.0, hit_tri=hd.TRI_DOWN)
    _st_d = ge_state(o)
    step("D1 ★★★ 分离态拖动 ⇒ 对侧 dt 纹丝不动（不强制共线）",
         xf.is_tri_locked(act, FR) is False
         and all(abs(_st_d[ax]["dtl"] - _dt_d0[ax]) < 1e-9
                 for ax in _dt_d0),
         "dtL before=%s after=%s"
         % ({k: round(v, 5) for k, v in _dt_d0.items()},
            {k: round(v["dtl"], 5) for k, v in _st_d.items()}))

    # ============================================================ E 模态 G
    o, act = build("_LGE_E")
    _dv_e = dv_snapshot(o)
    sess = me.ModalSession('SPEED')
    okb = sess.begin(o, act, 100.0, 100.0,
                     lambda x, y: [target(o, FR, 'left'), target(o, FR, 'right')])
    sess.update(100.0, 125.0)
    ok4, st4 = ge_ok(o)
    step("E1 ★★★ 锁定态模态 G（竖直）⇒ GE 仍逐轴共线",
         okb is True and ok4,
         "fold=%s" % {k: round(v["fold"], 8)
                      for k, v in st4.items() if v["fold"] is not None})
    step("E2 模态 G 只改时间分量（值分量不动）", dv_snapshot(o) == _dv_e)
    sess.cancel()
    ok5, st5 = ge_ok(o)
    step("E3 模态 G 取消 ⇒ 两侧都恢复到初始值",
         all(abs(st5[ax]["dtl"] - st0[ax]["dtl"]) < 1e-9
             and abs(st5[ax]["dtr"] - _dt0[ax][1]) < 1e-9 for ax in st5),
         "dt after cancel=%s"
         % {k: (round(v["dtl"], 6), round(v["dtr"], 6)) for k, v in st5.items()})

    # ============================================================ F 模态 G（单侧目标）
    o, act = build("_LGE_F")
    sess = me.ModalSession('SPEED')
    okb2 = sess.begin(o, act, 100.0, 100.0,
                      lambda x, y: target(o, FR, 'right'))
    sess.update(100.0, 102.0)
    ok6, st6 = ge_ok(o)
    step("F1 ★★★ 锁定帧只选中一侧 ⇒ 模态仍把对侧对齐（GE 共线）",
         okb2 is True and ok6,
         "fold=%s dtL=%s dtR=%s slopes=%s"
         % ({k: round(v["fold"], 8) for k, v in st6.items() if v["fold"] is not None},
            {k: round(v["dtl"], 6) for k, v in st6.items()},
            {k: round(v["dtr"], 6) for k, v in st6.items()},
            {k: (round(v["slope_l"], 8), round(v["slope_r"], 8))
             for k, v in st6.items()}))
    sess.cancel()
    ok7, st7 = ge_ok(o)
    step("F2 ★★★ 单侧目标取消 ⇒ 被顺带改写的对侧也恢复",
         abs(st7[0]["dtl"] - st0[0]["dtl"]) < 1e-9
         and abs(st7[1]["dtl"] - st0[1]["dtl"]) < 1e-9
         and abs(st7[0]["dtr"] - _dt0[0][1]) < 1e-9
         and abs(st7[1]["dtr"] - _dt0[1][1]) < 1e-9,
         "dt after cancel=%s"
         % {k: (round(v["dtl"], 6), round(v["dtr"], 6)) for k, v in st7.items()})

    o, act = build("_LGE_F2")
    sess = me.ModalSession('SPEED')
    sess.begin(o, act, 100.0, 100.0,
               lambda x, y: target(o, FR, 'right'))
    sess.update(100.0, 300.0)
    okf3, stf3 = ge_ok(o)
    step("F3 ★★★ 极端模态拖动 ⇒ 驱动侧被可行区间收窄，GE 仍共线",
         okf3, "fold=%s dtR=%s"
         % ({k: round(v["fold"], 6) for k, v in stf3.items()
             if v["fold"] is not None},
            {k: round(v["dtr"], 4) for k, v in stf3.items()}))
    sess.cancel()

    # ============================================================ G 模态 S
    o, act = build("_LGE_G")
    sess = me.ModalSession('SPEED')
    okb3 = sess.begin(o, act, 100.0, 100.0,
                      lambda x, y: [target(o, FR, 'left'), target(o, FR, 'right')],
                      drag_mode='radial')
    sess.update(125.0, 100.0)
    ok8, st8 = ge_ok(o)
    step("G1 ★★★ 锁定态模态 S（径向）⇒ GE 仍逐轴共线",
         okb3 is True and ok8,
         "mode=%s fold=%s" % (getattr(sess, "drag_mode", None),
                             {k: round(v["fold"], 8) for k, v in st8.items()
                              if v["fold"] is not None}))

    # ============================================================ H 端点
    o, act = build("_LGE_H")
    _res_ep = td.align_locked_speed_pair(act, o, 1.0, 'left')
    step("H1 端点段（无对侧三角）⇒ 不报错、不写值",
         _res_ep.get("ok") is False
         and _res_ep.get("reason") in ("no_source", "no_opposite", "degenerate"),
         "res=%s" % (_res_ep,))

    # ============================================================ I 注入
    o, act = build("_LGE_I")
    _orig_align = td.align_locked_speed_pair

    def _no_align(*a, **k):
        return {"ok": False, "reason": "injected", "written_axes": [],
                "skipped_axes": {}, "clamped_axes": [], "dt": {}, "s": {},
                "uniform": None, "already_aligned": False}

    td.align_locked_speed_pair = _no_align
    try:
        drag_mouse(o, dy=40.0, hit_tri=hd.TRI_DOWN)
    finally:
        td.align_locked_speed_pair = _orig_align
    _ok_inj, st_inj = ge_ok(o)
    step("I1 ★★★ 注入：拿掉对侧对齐 ⇒ 鼠标拖动后 GE 不共线（测试抓得住）",
         _ok_inj is False,
         "fold=%s" % {k: round(v["fold"], 6)
                      for k, v in st_inj.items() if v["fold"] is not None})

    o, act = build("_LGE_J")
    td.align_locked_speed_pair = _no_align
    try:
        sess = me.ModalSession('SPEED')
        sess.begin(o, act, 100.0, 100.0,
                   lambda x, y: [target(o, FR, 'left'), target(o, FR, 'right')])
        sess.update(100.0, 160.0)
    finally:
        td.align_locked_speed_pair = _orig_align
    _ok_inj2, st_inj2 = ge_ok(o)
    step("I2 ★★★ 注入：拿掉对侧对齐 ⇒ 模态 G 后 GE 不共线（测试抓得住）",
         _ok_inj2 is False,
         "fold=%s" % {k: round(v["fold"], 6)
                      for k, v in st_inj2.items() if v["fold"] is not None})

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-3000:])

print("=" * 78)
for s in steps:
    print("[%s] %s  %s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                          ("<- " + s["detail"]) if s["detail"] else ""))
fails = sum(1 for s in steps if not s["ok"])
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - fails, fails,
         "ALL PASS" if not fails else "HAS FAILURES"))
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump({"total": len(steps), "fails": fails,
               "result": "ALL PASS" if not fails else "HAS FAILURES",
               "steps": steps}, fh, ensure_ascii=False, indent=1)
print("RESULT:", "PASS" if not fails else "FAIL")
sys.stdout.flush()
