# -*- coding: utf-8 -*-
"""回归测试：双击锁定 = **GE 左右手柄逐轴共线**（进出速度相等）。

★★ 2026-11-11 语义定案（用户新需求）：
    「三角控制柄处于锁定状态时，始终要保证关键帧进出速度一致，
      也就是 Graph Editor 贝塞尔控制柄保持共线」。

  ⇒ 判据是**逐轴** `dvL/dtL == dvR/dtR`，不是“三角值 s 相同”。
  ⇒ 只改时间分量、值分量不动 ⇒ 3D 路径形状不变。
  ⇒ `dv` 各轴比例不同时，对侧三轴 dt **允许不同**——这是
     “保形状 + GE 共线”的数学必然（强行统一 dt 只能改 dv = 改形状）。

历史三版（本测试只认现在这版）：
  · 09-18：按主用轴算一个 dt ⇒ 只有主用轴共线
  · 09-29：逐轴 dt ⇒ GE 共线 ✓，但对侧三轴 dt 被写散
  · 09-30：只同步 s ⇒ 三轴 dt 一致 ✓，但 GE **不保证共线**（用户报障）
  · **11-11（现在）**：逐轴反解 dt ⇒ GE 共线 ✓ + 值分量不动 ✓；
    同侧 dt 是否一致取决于 `dv` 比例（不再强求）。

本测试的**区分度**由 B 组（注入验证）保证：故意只写“单一 s”会留下折角，
C 组会立刻失败。

跑法（后台即可，不需要真机 GUI）：
    blender --background --factory-startup --python tests/gui_peraxis_align_check.py
"""
import sys, os, json, traceback
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG_PARENT = os.path.dirname(PLUGIN_DIR)
PKG_NAME = os.path.basename(PLUGIN_DIR)
if PKG_PARENT not in sys.path:
    sys.path.insert(0, PKG_PARENT)
import bpy

steps = []
def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)})

# ★ 用户 Suzanne f25 的真实手柄值（真机读回）—— 三轴 A/B 比例**互不相同**
REAL = {
    0: (-4.852765083312988, (17.0, -11.206832885742188), (35.0, 3.089820384979248)),
    1: (2.73264741897583, (17.0, -1.9671909809112549), (31.89328384399414, 4.570038795471191)),
    2: (13.08447265625, (17.0, 13.08447265625), (35.0, 13.08447265625)),
}
FR = 25.0

def main():
    try:
        import addon_utils, importlib
        addon_utils.enable(PKG_NAME, default_set=True, persistent=False)
        it = importlib.import_module(PKG_NAME + ".interaction")
        cache = importlib.import_module(PKG_NAME + ".cache")
        hd = importlib.import_module(PKG_NAME + ".handles")
        td = importlib.import_module(PKG_NAME + ".time_domain")

        for o in list(bpy.data.objects):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
        ob = bpy.context.view_layer.objects.active
        ob.name = "_PERAXIS"
        for f in (1, 25, 55):
            ob.location = (0, 0, 0)
            ob.keyframe_insert("location", frame=f)
        act = ob.animation_data.action

        def reset():
            for fc in cache.collect_animation_curves(act, ob):
                for kp in fc.keyframe_points:
                    if abs(float(kp.co[0]) - FR) < 1e-3:
                        co, hl, hr = REAL[fc.array_index]
                        kp.co[1] = co
                        kp.handle_left = hl
                        kp.handle_right = hr
                        kp.handle_left_type = 'FREE'
                        kp.handle_right_type = 'FREE'
            for fc in cache.collect_animation_curves(act, ob):
                fc.update()

        def survey():
            d = {}
            for fc in cache.collect_animation_curves(act, ob):
                for kp in fc.keyframe_points:
                    if abs(float(kp.co[0]) - FR) < 1e-3:
                        A = float(kp.co[1]) - float(kp.handle_left[1])
                        B = float(kp.handle_right[1]) - float(kp.co[1])
                        dtL = abs(float(kp.co[0]) - float(kp.handle_left[0]))
                        dtR = abs(float(kp.handle_right[0]) - float(kp.co[0]))
                        d[fc.array_index] = {
                            "A": A, "B": B, "dtL": dtL, "dtR": dtR,
                            "slopeL": (A / dtL) if dtL > 1e-12 else None,
                            "slopeR": (B / dtR) if dtR > 1e-12 else None,
                        }
                        d[fc.array_index]["collinear"] = (
                            d[fc.array_index]["slopeL"] is not None
                            and d[fc.array_index]["slopeR"] is not None
                            and abs(d[fc.array_index]["slopeL"] - d[fc.array_index]["slopeR"]) < 1e-6)
            return d

        # ---------- A 组：场景前提（三轴比例确实不同） ----------
        reset()
        a = survey()
        ratios = {ax: (abs(a[ax]["B"] / a[ax]["A"]) if abs(a[ax]["A"]) > 1e-12 else None)
                  for ax in sorted(a)}
        step("A1 ★ 场景前提：三轴 |B/A| 互不相同（复刻用户文件）",
             len({round(v, 6) for v in ratios.values() if v is not None}) >= 2,
             "|B/A| = %s" % {k: (round(v, 4) if v is not None else None) for k, v in ratios.items()})
        step("A2 初始：X 共线 / Y 不共线（= 用户报障时的状态）",
             a[0]["collinear"] and not a[1]["collinear"],
             "X:%.6f/%.6f Y:%.6f/%.6f" % (a[0]["slopeL"], a[0]["slopeR"],
                                          a[1]["slopeL"], a[1]["slopeR"]))

        # ---------- B 组：注入验证 —— 09-29 那版（逐轴各调一次）会把 dt 写散 ----------
        reset()
        kf_s, span_s = td.resolve_target(act, ob, FR, 'left')
        kf_o, span_o = td.resolve_target(act, ob, FR, 'right')
        for ax in kf_o:
            kp_s = kf_s.get(ax)
            if kp_s is None:
                continue
            A = float(kp_s.co[1]) - float(kp_s.handle_left[1])
            B = float(kp_s.handle_right[1]) - float(kp_s.co[1])
            if abs(A) < 1e-12 or abs(B) < 1e-12:
                continue
            dt_ideal = abs(float(kp_s.co[0]) - float(kp_s.handle_left[0])) * abs(B) / abs(A)
            td.write_s({ax: kf_o[ax]}, 'right', dt_ideal / span_o, span_o, act=act, obj=ob)
        for fc in cache.collect_animation_curves(act, ob):
            fc.update()
        b = survey()
        _spread = max(b[ax]["dtR"] for ax in (0, 1)) - min(b[ax]["dtR"] for ax in (0, 1))
        step("B1 ★★ 注入验证：09-29 那版（逐轴各调一次 write_s）⇒ **三轴 dt 被写散**"
             "（复刻用户报障，证明本测试能区分实现）",
             _spread > 1.0, "X.dtR=%.4f Y.dtR=%.4f（跨度 %.4f）" % (b[0]["dtR"], b[1]["dtR"], _spread))
        step("B2 ★★ 那版下同侧三轴 dt 不相等 ⇒ **打破「三轴 dt 一致」的规范**",
             _spread > 1.0, "dtR 跨度=%.4f（规范要求 0）" % _spread)

        # ---------- C 组：本版实现 ⇒ 两侧 s 相同 + 三轴 dt 一致 ----------
        reset()
        v0 = {ax: (survey()[ax]["A"], survey()[ax]["B"]) for ax in REAL if ax in survey()}

        def svals():
            """两侧的三角值 s = dt / 段跨度（取三轴中位数）。"""
            out = {}
            for sd in ('left', 'right'):
                kfm, span = td.resolve_target(act, ob, FR, sd)
                if not kfm or not span:
                    out[sd] = None
                    continue
                mags = []
                for ax, kp in kfm.items():
                    h = kp.handle_left if sd == 'left' else kp.handle_right
                    d = abs(float(h[0]) - float(kp.co[0]))
                    if d > 1e-9:
                        mags.append(d)
                out[sd] = (sorted(mags)[len(mags) // 2] / span) if mags else None
            return out

        s0 = svals()
        ok, info, reason = it._align_opposite_speed(bpy.context, ob, FR, hd.TRI_UP)
        step("C1 调用 _align_opposite_speed（双击上三角）", ok, "reason=%s" % reason)
        c = survey()
        s1 = svals()

        def vvals():
            """两侧的**物理速度** |v| = |dv| / dt（dt 取三轴中位数）。

            ★★ 2026-09-30 用户拍板方案 ②：目标量是 `|v|`（速度的**大小**），
               不是 `s = dt/段长`（那是"归一化时间跨度/疏密"，另一个量）。
               两者只有在 `|dv|/段长` 恒定时才等价 —— 真实工程里不成立。
            """
            out = {}
            for sd in ('left', 'right'):
                kfm, span = td.resolve_target(act, ob, FR, sd)
                if not kfm:
                    out[sd] = None
                    continue
                mags, dvs = [], []
                for ax, kp in kfm.items():
                    h = kp.handle_left if sd == 'left' else kp.handle_right
                    mags.append(abs(float(h[0]) - float(kp.co[0])))
                    dvs.append(float(h[1]) - float(kp.co[1]))
                dt = sorted(mags)[len(mags) // 2]
                n = sum(x * x for x in dvs) ** 0.5
                out[sd] = (n / dt) if dt > 1e-9 else None
            return out

        # ★★★ 本版的核心：**逐轴 GE 斜率相等**（= GE 手柄共线）
        _slope_eq = all(
            abs(c[ax]["slopeL"] - c[ax]["slopeR"]) < 1e-5
            for ax in (0, 1))
        step("C2 ★★★ 锁定后：**逐轴 GE 斜率相等**（进出速度一致 / 手柄共线）",
             _slope_eq,
             "slopes=%s" % {ax: (round(c[ax]["slopeL"], 9),
                                round(c[ax]["slopeR"], 9))
                            for ax in (0, 1)})

        _sp_l = max(c[ax]["dtL"] for ax in (0, 1, 2)) - min(c[ax]["dtL"] for ax in (0, 1, 2))
        _sp_r = max(c[ax]["dtR"] for ax in (0, 1)) - min(c[ax]["dtR"] for ax in (0, 1))
        step("C3 ★★★ 对侧三轴 dt 允许不同（B/A 比例不同 ⇒ 10 vs 3.1276）",
             _sp_l < 1e-6 and _sp_r > 1.0,
             "dtL 跨度=%.2e dtR(X/Y) 跨度=%.4f（这是保形状 + GE 共线的必然）"
             % (_sp_l, _sp_r))

        step("C4 ★ 保形状：三轴值分量 A/B 一个都没变（只动时间分量）",
             all(abs(v0[ax][0] - c[ax]["A"]) < 1e-9 and abs(v0[ax][1] - c[ax]["B"]) < 1e-9
                 for ax in c),
             "before=%s after=%s" % ({k: (round(v[0], 6), round(v[1], 6)) for k, v in sorted(v0.items())},
                                     {k: (round(c[k]["A"], 6), round(c[k]["B"], 6)) for k in sorted(c)}))
        # ★ 以被双击侧（left）为命令源：left dt 不动，right 逐轴反解。
        _dtL_unchanged = all(abs(c[ax]["dtL"] - a[ax]["dtL"]) < 1e-9 for ax in (0, 1, 2))
        _expR = {ax: abs(a[ax]["dtL"]) * abs(c[ax]["B"] / c[ax]["A"])
                 for ax in (0, 1)}
        step("C5 ★★★ 被双击侧 dt 未动 + 对侧逐轴 dt = |dtL| × |dvR/dvL|",
             _dtL_unchanged
             and all(abs(c[ax]["dtR"] - _expR[ax]) < 1e-5 for ax in (0, 1)),
             "dtR=%s 期望=%s；dtL 未动=%s"
             % ({ax: round(c[ax]["dtR"], 6) for ax in (0, 1)},
                {ax: round(_expR[ax], 6) for ax in (0, 1)},
                _dtL_unchanged))
        step("C6 ★ Z 轴退化（值分量为 0）自动跳过，不影响其它轴共线",
             abs(c[2]["A"]) < 1e-12 and c[0]["collinear"] and c[1]["collinear"],
             "Z: A=%.1e；X/Y 共线=%s/%s" % (c[2]["A"], c[0]["collinear"], c[1]["collinear"]))
        step("C7 ★ info 带 v_target / v_before / v_after（便于排查）",
             isinstance(info, dict) and "v_target" in info and "v_before" in info
             and "v_after" in info,
             json.dumps({k: (round(v, 4) if isinstance(v, float) else v)
                         for k, v in (info or {}).items()}, ensure_ascii=False)[:200])
        step("C8 ★★★ 本版目标达成：GE 手柄**确实共线**",
             c[0]["collinear"] and c[1]["collinear"],
             "X 共线=%s Y 共线=%s（dtR 可以不同，但斜率一致）"
             % (c[0]["collinear"], c[1]["collinear"]))
    except Exception:
        step("EXCEPTION", False, traceback.format_exc()[-1000:])

    print("=" * 74)
    for s in steps:
        print("[%s] %s  %s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                              ("<- " + s["detail"]) if s["detail"] else ""))
    fails = sum(1 for s in steps if not s["ok"])
    print("总计 %d 项 | PASS %d | FAIL %d | %s"
          % (len(steps), len(steps) - fails, fails, "ALL PASS" if not fails else "HAS FAILURES"))
    OUT = os.path.join(PLUGIN_DIR, "tests", "_peraxis_align_result.json")
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"total": len(steps), "fails": fails, "steps": steps}, f,
                  ensure_ascii=False, indent=1)
    print("RESULT:", "PASS" if not fails else "FAIL")
    sys.stdout.flush()

if __name__ == "__main__":
    main()
