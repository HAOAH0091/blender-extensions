
import bpy, sys, os, importlib.util, traceback
sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_repro"
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(PKG, os.path.join(PKG_DIR, "__init__.py"),
                                             submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec); sys.modules[PKG] = mod; spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
ng  = sys.modules[PKG + ".node_groups"]
nm  = sys.modules[PKG + ".names"]
mod.register()

def build(tag):
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam); sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag); mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup"); cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup"); uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return sc, obj, cam, uv

OUT = {}
bpy.ops.wm.read_factory_settings(use_empty=True)
sc, obj, cam, uv = build("A")
ngm.invalidate_uv_cache(sc)
g1 = ngm.get_all_uv_adjust_node_groups(sc)
OUT["A_scene"] = sc.name
OUT["A_groups"] = len(g1)
OUT["A_names"] = [x["node_group"].name for x in g1]
OUT["A_cache_keys"] = list(ngm._uv_adjust_cache.keys())

# ---- 模拟用户: File > New（不关 Blender）----
try:
    bpy.ops.wm.read_homefile(use_empty=True)
except Exception as e:
    OUT["homefile_err"] = repr(e)
    bpy.ops.wm.read_factory_settings(use_empty=True)

sc2 = bpy.context.scene
OUT["B_scene"] = sc2.name
OUT["B_obj_count"] = len(sc2.objects)
OUT["B_bpy_node_groups"] = [g.name for g in bpy.data.node_groups]
OUT["B_materials"] = [m.name for m in bpy.data.materials]
OUT["B_cache_keys_before_read"] = list(ngm._uv_adjust_cache.keys())

try:
    g2 = ngm.get_all_uv_adjust_node_groups(sc2)
    OUT["B_groups_reported"] = len(g2)
    detail = []
    for x in g2:
        row = {}
        try:
            row["ng_name"] = x["node_group"].name
        except Exception as e:
            row["ng_name"] = "ERRNAM:" + type(e).__name__
        row["mat_names"] = list(x["materials"])
        try:
            row["is_valid"] = bool(x["is_valid"])
        except Exception as e:
            row["is_valid"] = "ERR:" + type(e).__name__
        row["obj"] = repr(x["object"])
        row["cam"] = repr(x["camera"])
        detail.append(row)
    OUT["B_detail"] = detail
    OUT["B_names_safe"] = True
except Exception as e:
    OUT["B_read_err"] = type(e).__name__ + ": " + str(e)
    OUT["B_trace"] = traceback.format_exc()[-800:]

# 用户点的「刷新 & 清理」能否救回来
try:
    ngm.invalidate_uv_cache(sc2)
    g3 = ngm.get_all_uv_adjust_node_groups(sc2)
    OUT["C_after_refresh_groups"] = len(g3)
except Exception as e:
    OUT["C_after_refresh_err"] = type(e).__name__ + ": " + str(e)

for k, v in OUT.items():
    print("RESULT", k, "=", v)
