"""S2c 严格复现：为什么"模块重载"没让红字消失？

v3.0.3 的代码逻辑：
  get_all_uv_adjust_node_groups(scene)
    if scene.name in _uv_adjust_cache: return 缓存     <-- 命中就直接返回
    否则重新扫，扫的时候才调用 check_uv_adjust_validity_detailed 判有效

关键：重新扫时会重新判定相机在不在，所以**必然得到 False**。
所以"重载后变 True"只有在**缓存没被清、且新模块的缓存字典里还有旧条目**时才可能。
而重新 exec 模块会得到全新的空字典 _uv_adjust_cache = {}。

因此我怀疑 Chief 的"模块重新加载"用的是别的手段（比如禁用/启用插件），
那种情况下 Python 模块不重载，_uv_adjust_cache 里的旧条目**还在**。

这里把两种情况都测出来。
"""
import bpy
import sys
import os
import importlib.util
import importlib

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_s2c"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_fresh():
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    m = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = m
    spec.loader.exec_module(m)
    return m


mod = load_fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()

sc = bpy.context.scene
obj = bpy.data.objects.new("Obj_C", bpy.data.meshes.new("m_C"))
sc.collection.objects.link(obj)
cam = bpy.data.objects.new("Cam_C", bpy.data.cameras.new("CamData_C"))
sc.collection.objects.link(cam)
sc.camera = cam
cp = ng.ensure_camera_project_group(cam)
uv = ng.create_uv_adjust_node_group(sc, cam, obj)
mat = bpy.data.materials.new("M_C")
mat.use_nodes = True
nt = mat.node_tree
cpn = nt.nodes.new("ShaderNodeGroup")
cpn.node_tree = cp
uvn = nt.nodes.new("ShaderNodeGroup")
uvn.node_tree = uv
tex = nt.nodes.new("ShaderNodeTexImage")
nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
             uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
nt.links.new(next(s for s in uvn.outputs
                  if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
obj.data.materials.append(mat)

grp = ngm.get_all_uv_adjust_node_groups(sc)
print("A. 建缓存后 N =", len(grp), "valid =", [g["is_valid"] for g in grp])
print("   缓存字典:", {k: len(v) for k, v in ngm._uv_adjust_cache.items()})

bpy.data.objects.remove(cam)

# ---- 情况 1：重新 exec 模块（_uv_adjust_cache 变新空字典）----
g1 = ngm.get_all_uv_adjust_node_groups(sc)     # 第一次读：缓存命中，拿到旧数据
print("B. 删相机后立刻读（缓存命中）: N =", len(g1), "valid =", [g["is_valid"] for g in g1])

mod2 = load_fresh()
ngm2 = sys.modules[PKG + ".node_group_manager"]
print("C. 重新 exec 模块后缓存字典:", {k: len(v) for k, v in ngm2._uv_adjust_cache.items()})
g2 = ngm2.get_all_uv_adjust_node_groups(sc)
print("D. 重载后读（空缓存 -> 必须重扫）: N =", len(g2), "valid =", [g["is_valid"] for g in g2],
      "reason =", [g["status"].get("reason") for g in g2])

# ---- 情况 2：不重载，只是"缓存里已经有删相机之前的条目"----
bpy.ops.wm.read_factory_settings(use_empty=False)
mod3 = load_fresh()
ngm3 = sys.modules[PKG + ".node_group_manager"]
ng3 = sys.modules[PKG + ".node_groups"]
sc = bpy.context.scene
obj = bpy.data.objects.new("Obj_D", bpy.data.meshes.new("m_D"))
sc.collection.objects.link(obj)
cam = bpy.data.objects.new("Cam_D", bpy.data.cameras.new("CamData_D"))
sc.collection.objects.link(cam)
sc.camera = cam
cp = ng3.ensure_camera_project_group(cam)
uv = ng3.create_uv_adjust_node_group(sc, cam, obj)
mat = bpy.data.materials.new("M_D")
mat.use_nodes = True
nt = mat.node_tree
cpn = nt.nodes.new("ShaderNodeGroup")
cpn.node_tree = cp
uvn = nt.nodes.new("ShaderNodeGroup")
uvn.node_tree = uv
tex = nt.nodes.new("ShaderNodeTexImage")
nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
             uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
nt.links.new(next(s for s in uvn.outputs
                  if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
obj.data.materials.append(mat)
ngm3.get_all_uv_adjust_node_groups(sc)        # 建缓存
bpy.data.objects.remove(cam)
g3 = ngm3.get_all_uv_adjust_node_groups(sc)   # 缓存命中
print("E. 不重载、缓存命中: N =", len(g3), "valid =", [g["is_valid"] for g in g3],
      "reason =", [g["status"].get("reason") for g in g3])
g4 = ngm3.get_all_uv_adjust_node_groups(sc)
print("F. 再读一次（仍命中）: valid =", [g["is_valid"] for g in g4])
