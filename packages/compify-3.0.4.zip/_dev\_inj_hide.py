
import io, sys, re
which = sys.argv[1]
p = sys.argv[2]
with io.open(p, "r", encoding="utf-8") as f:
    src = f.read().replace("\r\n", "\n")

def cut_fn(src, fname):
    start = src.index("def " + fname)
    m = re.compile(r"^def ", re.M).search(src, start + 1)
    return start, (m.start() if m else len(src))

# 反查表里的写法（两个 if 之间没有空行）
IDX_ANCHOR = '''                        if node.type != "GROUP":
                            continue
                        if not node.node_tree:
                            continue
'''
IDX_ADD = IDX_ANCHOR + '''                        if getattr(node, "hide", False):
                            continue
'''
# 原函数的写法（有空行 + 注释）
ORIG_ANCHOR = '''                        if node.type != "GROUP":
                            continue

                        if not node.node_tree:
                            continue
'''
ORIG_ADD = ORIG_ANCHOR + '''                        if getattr(node, "hide", False):
                            continue
'''

def apply(src, fname, anchor, add):
    s, e = cut_fn(src, fname)
    body = src[s:e]
    cnt = body.count(anchor)
    assert cnt == 1, "%s anchor count=%d" % (fname, cnt)
    return src[:s] + body.replace(anchor, add, 1) + src[e:]

if which in ("orig_hide", "both_hide"):
    src = apply(src, "get_node_group_usage_info", ORIG_ANCHOR, ORIG_ADD)
if which in ("index_hide", "both_hide"):
    src = apply(src, "_uv_build_usage_index", IDX_ANCHOR, IDX_ADD)

with io.open(p, "w", encoding="utf-8", newline="\n") as f:
    f.write(src)
print("INJECTED", which)
