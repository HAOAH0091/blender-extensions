"""九行验收表的**带断言**版本（门禁用）。

`acceptance_probe.py` 只打印不判定——CodeAuditor 实测过：
把"每次现查现判"换成"命中缓存就直接返回快照"，九行表里最核心的四行
退回 valid=[True]，脚本照样退出、一条 FAIL 都没有。所以那个只能当读数工具。

这个文件把九行都变成断言，任何一行不符合预期就 [FAIL]。

用法：<blender> --background --factory-startup --python _dev/test_uv_acceptance.py
"""
import bpy
import sys
import os
import importlib.util
import tempfile

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_uvacc"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

PASS = []
FAIL = []


def chk(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()

REASON_CAM = "找不到相机（可能被删除或因重名改名 .001）"
REASON_OBJ = "找不到物体"


def build(tag):
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    ngm.invalidate_uv_cache(sc)
    return sc, obj, cam, uv, mat


def read_panel():
    """照面板真实路径读，同时数死引用。"""
    sc = bpy.context.scene
    groups = ngm.get_all_uv_adjust_node_groups(sc)
    dead = 0
    for g in groups:
        for key in ("node_group", "object", "camera"):
            rna = g.get(key)
            if rna is None:
                continue
            try:
                rna.name
            except ReferenceError:
                dead += 1
    return groups, dead


def scene_of(tag):
    bpy.ops.wm.read_factory_settings(use_empty=False)
    return build(tag)


# ============ 1. 正常组 ============
sc, obj, cam, uv, mat = scene_of("A1")
groups, dead = read_panel()
chk("1a 正常组：1 条", len(groups) == 1, f"N={len(groups)}")
chk("1b 正常组：有效", groups and groups[0]["is_valid"] is True,
    str([g["is_valid"] for g in groups]))
chk("1c 正常组：原因=无", groups and groups[0]["status"].get("reason") == "无",
    str([g["status"].get("reason") for g in groups]))
chk("1d 正常组：无死引用", dead == 0, f"dead={dead}")

# ============ 2. 删相机·不刷新 ============
bpy.data.objects.remove(cam)
groups, dead = read_panel()
chk("2a 删相机不刷新：仍 1 条（不消失）", len(groups) == 1, f"N={len(groups)}")
chk("2b 删相机不刷新：立刻失效（不是假有效）",
    groups and groups[0]["is_valid"] is False, str([g["is_valid"] for g in groups]))
chk("2c 删相机不刷新：红字写找不到相机",
    groups and groups[0]["status"].get("reason") == REASON_CAM,
    str([g["status"].get("reason") for g in groups]))
chk("2d 删相机不刷新：无死引用", dead == 0, f"dead={dead}")

# ============ 3. 删相机·刷新（同一个组） ============
ngm.invalidate_uv_cache(sc)
groups, dead = read_panel()
chk("3a 删相机刷新后：同一个组仍 1 条",
    len(groups) == 1 and groups[0]["node_group"].name == uv.name,
    str([g["node_group"].name for g in groups]))
chk("3b 删相机刷新后：仍失效且红字不变",
    groups and groups[0]["is_valid"] is False
    and groups[0]["status"].get("reason") == REASON_CAM)
chk("3c 删相机刷新前后结论一致（都是失效）",
    len(groups) == 1 and groups[0]["is_valid"] is False)

# ============ 4. 删物体·不刷新 ============
sc, obj, cam, uv, mat = scene_of("A4")
groups, _ = read_panel()
chk("4a 前提：删物体前 1 条有效", len(groups) == 1 and groups[0]["is_valid"] is True)
bpy.data.objects.remove(obj)
groups, dead = read_panel()
chk("4b 删物体不刷新：仍 1 条（不消失）", len(groups) == 1, f"N={len(groups)}")
chk("4c 删物体不刷新：立刻失效",
    groups and groups[0]["is_valid"] is False, str([g["is_valid"] for g in groups]))
chk("4d 删物体不刷新：红字写找不到物体",
    groups and groups[0]["status"].get("reason") == REASON_OBJ,
    str([g["status"].get("reason") for g in groups]))
chk("4e 删物体不刷新：无死引用", dead == 0, f"dead={dead}")

# ============ 5. 删物体·刷新（同一个组）+ 能删掉 ============
uv_name = uv.name
ngm.invalidate_uv_cache(sc)
groups, dead = read_panel()
chk("5a 删物体刷新后：同一个组仍 1 条",
    len(groups) == 1 and groups[0]["node_group"].name == uv_name,
    str([g["node_group"].name for g in groups]))
chk("5b 删物体刷新后：仍失效且红字不变",
    groups and groups[0]["is_valid"] is False
    and groups[0]["status"].get("reason") == REASON_OBJ)
chk("5c 删物体刷新后：无死引用", dead == 0, f"dead={dead}")

cleaned = ngm.clean_invalid_uv_adjust_node_groups(sc, confirm=False)
chk("5d 红字组能被「刷新&清理」真删掉", cleaned == 1, f"删除 {cleaned} 个")
chk("5e 组确实从文件里没了", bpy.data.node_groups.get(uv_name) is None)
groups, _ = read_panel()
chk("5f 清理后面板归零", len(groups) == 0, f"N={len(groups)}")

# ============ 6. File > New ============
sc, obj, cam, uv, mat = scene_of("A6")
old_name = uv.name
read_panel()
bpy.ops.wm.read_factory_settings(use_empty=False)
groups, dead = read_panel()
chk("6a File > New 不崩（能正常读）", True)
chk("6b File > New 后不显示上一个文件的组", len(groups) == 0, f"N={len(groups)}")
chk("6c File > New 后无死引用", dead == 0, f"dead={dead}")
chk("6d File > New 后没有漏过来的旧名字",
    all(old_name not in g["node_group"].name for g in groups))

# ============ 7. 交叉打开 A -> B -> A ============
fileA = os.path.join(tempfile.gettempdir(), "_uvacc_A.blend")
fileB = os.path.join(tempfile.gettempdir(), "_uvacc_B.blend")
sc, obj, cam, uv, mat = scene_of("A7")
nameA = uv.name
read_panel()
bpy.ops.wm.save_as_mainfile(filepath=fileA)

sc, obj, cam, uv, mat = scene_of("B7")
nameB = uv.name
read_panel()
bpy.ops.wm.save_as_mainfile(filepath=fileB)

bpy.ops.wm.open_mainfile(filepath=fileA)
gA, deadA = read_panel()
chk("7a 打开 A：显示 A 的组",
    len(gA) == 1 and gA[0]["node_group"].name == nameA,
    str([g["node_group"].name for g in gA]))
chk("7b 打开 A：无死引用", deadA == 0, f"dead={deadA}")

bpy.ops.wm.open_mainfile(filepath=fileB)
gB, deadB = read_panel()
chk("7c 打开 B：不显示 A 的组",
    all(g["node_group"].name != nameA for g in gB),
    str([g["node_group"].name for g in gB]))
chk("7d 打开 B：显示的是 B 自己的组",
    len(gB) == 1 and gB[0]["node_group"].name == nameB,
    str([g["node_group"].name for g in gB]))
chk("7e 打开 B：无死引用", deadB == 0, f"dead={deadB}")

bpy.ops.wm.open_mainfile(filepath=fileA)
gA2, deadA2 = read_panel()
chk("7f 切回 A：仍能看到 A 的组（不是永久坏掉）",
    len(gA2) == 1 and gA2[0]["node_group"].name == nameA,
    str([g["node_group"].name for g in gA2]))
chk("7g 切回 A：无死引用", deadA2 == 0, f"dead={deadA2}")

for f in (fileA, fileB):
    if os.path.exists(f):
        os.remove(f)

# ============ 8. 真·空结果能命中缓存 ============
bpy.ops.wm.read_factory_settings(use_empty=False)
sc = bpy.context.scene
chk("8a 前提：场景里没有任何 UV 组",
    not any(g.name.startswith("UV Adjust") for g in bpy.data.node_groups))
ngm.invalidate_uv_cache(sc)
groups = ngm.get_all_uv_adjust_node_groups(sc)
chk("8b 真·空结果：读出来就是 0 条", len(groups) == 0, f"N={len(groups)}")
raw = sc.get("compify_uv_cache")
chk("8c 空结果被写进缓存", isinstance(raw, str) and '"rows":[]' in raw, repr(raw))

misses = {"n": 0}
if not hasattr(ngm, "_uv_cache_read"):
    chk("8d 前置：_uv_cache_read 存在（判据依赖它）", False)
    misses["n"] = -1
else:
    _orig = ngm._uv_cache_read

    def _counting(s):
        r = _orig(s)
        if r is None:
            misses["n"] += 1
        return r

    ngm._uv_cache_read = _counting
    try:
        misses["n"] = 0
        for _ in range(10):
            ngm.get_all_uv_adjust_node_groups(sc)
    finally:
        ngm._uv_cache_read = _orig
    chk("8d 连读 10 次全部命中缓存（空结果真的缓存住了）", misses["n"] == 0,
        f"未命中 {misses['n']} 次")

# ============ 9. 原有功能没被搞垮 ============
try:
    sc, obj, cam, uv, mat = scene_of("A9")
    # 批量生成：同一机位、两个网格
    obj2 = bpy.data.objects.new("Obj_A9b", bpy.data.meshes.new("m_A9b"))
    sc.collection.objects.link(obj2)
    uv2 = ng.create_uv_adjust_node_group(sc, cam, obj2)
    m2 = bpy.data.materials.new("M_A9b")
    m2.use_nodes = True
    nt2 = m2.node_tree
    cpn2 = nt2.nodes.new("ShaderNodeGroup")
    cpn2.node_tree = cp if False else ng.ensure_camera_project_group(cam)
    uvn2 = nt2.nodes.new("ShaderNodeGroup")
    uvn2.node_tree = uv2
    tex2 = nt2.nodes.new("ShaderNodeTexImage")
    nt2.links.new(next(s for s in cpn2.outputs if s.name == "Vector"),
                  uvn2.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt2.links.new(next(s for s in uvn2.outputs
                       if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex2.inputs["Vector"])
    obj2.data.materials.append(m2)
    ngm.invalidate_uv_cache(sc)
    groups = ngm.get_all_uv_adjust_node_groups(sc)
    chk("9a 批量生成：同机位两网格 = 2 条", len(groups) == 2, f"N={len(groups)}")

    # 正常场景下「刷新&清理」清理数 = 0
    cleaned = ngm.clean_invalid_uv_adjust_node_groups(sc, confirm=False)
    chk("9b 正常场景「刷新&清理」清理数 = 0", cleaned == 0, f"删除 {cleaned} 个")
    groups = ngm.get_all_uv_adjust_node_groups(sc)
    chk("9c 清理后正常组仍在", len(groups) == 2, f"N={len(groups)}")

    # 孤立组识别：材质被摘掉后应能被识别
    chk("9d get_orphan_uv_adjust_node_groups 可调用",
        isinstance(ngm.get_orphan_uv_adjust_node_groups(sc), list))
except Exception as e:  # noqa: BLE001
    import traceback as _tb
    _tb.print_exc()
    chk("9 原有功能", False, f"{type(e).__name__}: {e}")

print()
print("=" * 52)
print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
if FAIL:
    print("FAILED:", FAIL)
print("=" * 52)
