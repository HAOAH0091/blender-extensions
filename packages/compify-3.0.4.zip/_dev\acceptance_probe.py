"""验收对照：把 Chief 那张表逐行实测出来。

九行场景，每行输出：面板条数、valid、红字原因、有无死引用、命中缓存与否。

用法：<blender> --background --factory-startup --python _dev/acceptance_probe.py
"""
import bpy
import sys
import os
import importlib.util
import json
import tempfile

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_acc"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = {}


def emit(k, v):
    OUT[k] = v
    print("ACC " + k + " = " + repr(v))


def fresh():
    for k in [k for k in list(sys.modules) if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    m = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = m
    spec.loader.exec_module(m)
    return m


def setup(mod, tag):
    ng = sys.modules[PKG + ".node_groups"]
    nm = sys.modules[PKG + ".names"]
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    ngm = sys.modules[PKG + ".node_group_manager"]
    ngm.invalidate_uv_cache(sc)
    return sc, obj, cam, uv, mat


def panel(ngm):
    """照面板真实路径读：包括取名字、取 object，任何异常都记下来。"""
    sc = bpy.context.scene
    try:
        groups = ngm.get_all_uv_adjust_node_groups(sc)
    except Exception as e:  # noqa: BLE001
        return {"err": f"{type(e).__name__}: {e}"}
    out = {"err": None, "n": len(groups), "valid": [], "reason": [], "dead": 0, "names": []}
    for g in groups:
        try:
            out["names"].append(g["node_group"].name)
        except Exception as e:  # noqa: BLE001
            out["names"].append(f"<DEAD:{type(e).__name__}>")
            out["dead"] += 1
        out["valid"].append(g["is_valid"])
        out["reason"].append(g["status"].get("reason"))
        for key in ("object", "camera"):
            rna = g.get(key)
            if rna is None:
                continue
            try:
                rna.name
            except Exception:  # noqa: BLE001
                out["dead"] += 1
    return out


# ============ 1. 正常组 ============
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "OK")
emit("1_normal", panel(ngm))

# 缓存命中：连读 10 次统计真扫描
scans = {"n": 0}
orig = ngm.find_objects_using_material


def counting(*a, **k):
    scans["n"] += 1
    return orig(*a, **k)


ngm.find_objects_using_material = counting
try:
    for _ in range(10):
        panel(ngm)
finally:
    ngm.find_objects_using_material = orig
emit("1b_repeat10_scan_calls", scans["n"])

# ============ 2. 删相机·不刷新 ============
bpy.data.objects.remove(cam)
emit("2_del_camera_no_refresh", panel(ngm))

# ============ 3. 删相机·刷新 ============
# ⚠️ 这里**沿用第 2 行那个组**（相机已删），只在它身上再加一次 invalidate，
#    这样第 2、3 行是同一个组、同一台相机，可以直接对比"刷新前后"。
#    原版这里新建了 CAM2，两行不是同一个场景，不可比。
ngm.invalidate_uv_cache(sc)
emit("3_del_camera_after_refresh_same_group", panel(ngm))

# ============ 4. 删物体·不刷新 ============
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "OBJ2")
panel(ngm)
bpy.data.objects.remove(obj)
emit("4_del_object_no_refresh", panel(ngm))

# ============ 5. 删物体·刷新 ============
# 同第 3 行的道理：**沿用第 4 行那个组**（物体已删），只再加一次 invalidate，
# 这样第 4、5 行是同一个组，可以直接对比"刷新前后"。
uv_name = uv.name
ngm.invalidate_uv_cache(sc)
emit("5_del_object_after_refresh_same_group", panel(ngm))

# 5b. 这个红字组能不能被「刷新&清理」删掉
try:
    cleaned = ngm.clean_invalid_uv_adjust_node_groups(sc, confirm=False)
    emit("5b_clean_invalid_deleted", cleaned)
    emit("5c_group_still_exists", bpy.data.node_groups.get(uv_name) is not None)
    emit("5d_panel_after_clean", panel(ngm))
except Exception as e:  # noqa: BLE001
    emit("5b_clean_invalid_error", f"{type(e).__name__}: {e}")

# ============ 6. File > New ============
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "FN")
old_name = uv.name
panel(ngm)
bpy.ops.wm.read_factory_settings(use_empty=False)
emit("6_file_new", panel(ngm))
emit("6b_leaks_old_group",
     any(old_name in n for n in (panel(ngm).get("names") or [])))

# ============ 7. 交叉打开 A -> B -> A ============
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
sys.modules[PKG].register()
fileA = os.path.join(tempfile.gettempdir(), "_acc_A.blend")
fileB = os.path.join(tempfile.gettempdir(), "_acc_B.blend")

bpy.ops.wm.read_factory_settings(use_empty=False)
sc, obj, cam, uv, mat = setup(m, "A")
nameA = uv.name
bpy.ops.wm.save_as_mainfile(filepath=fileA)

bpy.ops.wm.read_factory_settings(use_empty=False)
sc, obj, cam, uv, mat = setup(m, "B")
nameB = uv.name
bpy.ops.wm.save_as_mainfile(filepath=fileB)

bpy.ops.wm.open_mainfile(filepath=fileA)
emit("7a_open_A", panel(ngm))
bpy.ops.wm.open_mainfile(filepath=fileB)
pB = panel(ngm)
emit("7b_open_B", pB)
emit("7c_B_shows_A_group", any(nameA in str(n) for n in (pB.get("names") or [])))
bpy.ops.wm.open_mainfile(filepath=fileA)
pA2 = panel(ngm)
emit("7d_open_A_again", pA2)
emit("7e_A_group_visible", any(nameA in str(n) for n in (pA2.get("names") or [])))
for f in (fileA, fileB):
    if os.path.exists(f):
        os.remove(f)

# ============ 8. 真·空结果能命中缓存 ============
# ⚠️ 原版这里用"删物体"造场景，新实现会保留一条失效组（n=1），
#    那根本不是空结果，"空结果能命中缓存"压根没验到（Chief 指出的口径错误）。
#    现在改成：场景里**压根没有任何 UV Adjust 组**，扫出来真实就是 0 条。
#    判据也从"find_objects_using_material 次数"换成"缓存未命中次数"——
#    前者在空场景下恒为 0，没有判别力（实测：注入"空结果不写缓存"后它仍是 0）。
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc = bpy.context.scene
emit("8z_uv_groups_in_file",
     [g.name for g in bpy.data.node_groups if g.name.startswith("UV Adjust")])
ngm.invalidate_uv_cache(sc)

misses = {"n": 0}
_orig_read = ngm._uv_cache_read


def _read_counting(target):
    r = _orig_read(target)
    if r is None:
        misses["n"] += 1
    return r


ngm._uv_cache_read = _read_counting
try:
    misses["n"] = 0
    r = panel(ngm)
    emit("8a_empty_panel", r)
    emit("8a2_first_read_cache_misses", misses["n"])
    emit("8a3_cache_written", sc.get("compify_uv_cache"))

    misses["n"] = 0
    for _ in range(10):
        panel(ngm)
    emit("8b_repeat10_cache_misses", misses["n"])
finally:
    ngm._uv_cache_read = _orig_read

# ============ 9. 幽灵生效检查：红字组会不会叠加新组 ============
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
m.register()
sc, obj, cam, uv, mat = setup(m, "GHOST")
old_uv_name = uv.name
bpy.data.objects.remove(obj)
ngm.invalidate_uv_cache(sc)
before_groups = [g.name for g in bpy.data.node_groups if g.name.startswith("UV Adjust")]
# 新物体，复用同一材质
new_obj = bpy.data.objects.new("Obj_GHOST_new", bpy.data.meshes.new("m_new"))
sc.collection.objects.link(new_obj)
new_obj.data.materials.append(mat)
new_uv = ng.create_uv_adjust_node_group(sc, cam, new_obj)
# ⚠️ create_uv_adjust_node_group 只建组、**不往材质里接**；
#    真正接线的是 add_uv_adjust_to_material（批量生成 operator 会调它）。
#    第一版探针漏了这一步，看到的现象无效。
attach_result = ngm.add_uv_adjust_to_material(new_obj, cam, new_uv)
emit("9b2_attach_result", str(attach_result)[:200])
ngm.invalidate_uv_cache(sc)
after_groups = [g.name for g in bpy.data.node_groups if g.name.startswith("UV Adjust")]
emit("9a_groups_before_new", before_groups)
emit("9b_groups_after_new", after_groups)
# 材质里有几个指向 UV 组的节点
mat_group_nodes = [n for n in mat.node_tree.nodes
                   if n.type == "GROUP" and n.node_tree and
                   n.node_tree.name.startswith("UV Adjust")]
emit("9c_uv_group_nodes_in_material", [n.node_tree.name for n in mat_group_nodes])
emit("9d_old_group_still_there", bpy.data.node_groups.get(old_uv_name) is not None)

print("ACC_JSON " + json.dumps(OUT, ensure_ascii=False, default=str))
