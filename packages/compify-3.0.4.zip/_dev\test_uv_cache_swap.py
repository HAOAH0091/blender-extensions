"""数量哨兵回归：删一个组 + 加一个组（总数不变）后，面板必须显示新组。

为什么必须单独有这条：
  7b091d4 最初的哨兵只比对"UV 组总数"，总数没变就继续用旧缓存。
  于是缓存里留着已经被删掉的组名 → 名字查不到、数据名兜底也认领不上
  → 面板显示 0 条，而文件里明明有组。
  已改成比对"名字集合"。

这条测试的作用是：把哨兵改回只比数量，它必须变红。
否则这行代码谁都能随手改回去，没人报警。

用法：<blender> --background --factory-startup --python _dev/test_uv_cache_swap.py
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_swap"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

PASS = []
FAIL = []


def chk(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()


def build(tag, sc):
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME),
                 tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return obj, cam, uv, mat


def group_names(rows):
    return [r["node_group"].name for r in rows]


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene

# ---- 1. 基准：一个组，面板能看见 ----
o1, c1, u1, m1 = build("A", sc)
ngm.invalidate_uv_cache(sc)
rows = ngm.get_all_uv_adjust_node_groups(sc)
chk("1a 基准：1 条", len(rows) == 1, f"N={len(rows)}")
chk("1b 基准：是那个组", group_names(rows) == [u1.name], group_names(rows))

# ---- 2. 删一个 + 加一个，总数不变 —— 本次回归的核心 ----
# ⚠️ 先存下旧名字：删掉之后 u1 就是死引用，读 .name 会 ReferenceError
old_name = u1.name
bpy.data.node_groups.remove(u1)
o2, c2, u2, m2 = build("B", sc)
live = [g.name for g in bpy.data.node_groups if ngm._uv_group_is_uv_adjust(g)]
chk("2a 前提：文件里的 UV 组数量仍是 1（数量哨兵看不出来）",
    len(live) == 1, f"live={live}")

rows = ngm.get_all_uv_adjust_node_groups(sc)
chk("2b 换组后必须显示新组（不是空列表）",
    group_names(rows) == [u2.name], f"rows={group_names(rows)}")
chk("2c 不能显示已被删除的旧组",
    old_name not in group_names(rows), group_names(rows))

# ---- 3. 再读一次，缓存必须是干净的 ----
rows2 = ngm.get_all_uv_adjust_node_groups(sc)
chk("3a 第二次读仍是新组", group_names(rows2) == [u2.name], group_names(rows2))

# ---- 4. 两个场景各一组，互换后归属要对 ----
bpy.ops.wm.read_factory_settings(use_empty=True)
scA = bpy.context.scene
scA.name = "A"
oA, cA, uA, mA = build("A2", scA)
scB = bpy.data.scenes.new("B")
bpy.context.window.scene = scB
oB, cB, uB, mB = build("B2", scB)
ngm.invalidate_uv_cache(scA)
ngm.invalidate_uv_cache(scB)

a_rows = group_names(ngm.get_all_uv_adjust_node_groups(scA))
b_rows = group_names(ngm.get_all_uv_adjust_node_groups(scB))
chk("4a A 场景只显示自己的组", a_rows == [uA.name], a_rows)
chk("4b B 场景只显示自己的组", b_rows == [uB.name], b_rows)

print()
print("=" * 50)
print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
if FAIL:
    print("FAILED:", FAIL)
