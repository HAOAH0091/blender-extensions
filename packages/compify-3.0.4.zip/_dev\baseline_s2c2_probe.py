"""S2c 正确做法：真正重载子模块（清 sys.modules 再 import），模拟插件重载。"""
import bpy
import sys
import os
import importlib.util
import json

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_s2c2"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = {}


def emit(k, v):
    OUT[k] = v
    print("R " + k + " = " + repr(v))


def load_true_fresh():
    """把 PKG 及其所有子模块从 sys.modules 里摘掉，再重新 exec。"""
    for k in [k for k in list(sys.modules) if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    m = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = m
    spec.loader.exec_module(m)
    return m


def build(ng_mods, tag):
    sc = bpy.context.scene
    ng = ng_mods["node_groups"]
    nm = ng_mods["names"]
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return sc, obj, cam, uv, mat


m = load_true_fresh()
mods = {"node_groups": sys.modules[PKG + ".node_groups"],
        "names": sys.modules[PKG + ".names"]}
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()

sc, obj, cam, uv, mat = build(mods, "C")
g0 = ngm.get_all_uv_adjust_node_groups(sc)
emit("A_before", {"n": len(g0), "valid": [x["is_valid"] for x in g0]})
emit("A_cache", {k: len(v) for k, v in ngm._uv_adjust_cache.items()})

bpy.data.objects.remove(cam)

g1 = ngm.get_all_uv_adjust_node_groups(sc)
emit("B_after_del_no_invalidate", {"n": len(g1), "valid": [x["is_valid"] for x in g1],
                                   "reason": [x["status"].get("reason") for x in g1]})

# 真正重载：摘掉所有子模块
m2 = load_true_fresh()
ngm2 = sys.modules[PKG + ".node_group_manager"]
emit("C_cache_dict_after_true_reload", {k: len(v) for k, v in ngm2._uv_adjust_cache.items()})
g2 = ngm2.get_all_uv_adjust_node_groups(sc)
emit("D_after_true_reload", {"n": len(g2), "valid": [x["is_valid"] for x in g2],
                             "reason": [x["status"].get("reason") for x in g2]})

print("R_JSON " + json.dumps(OUT, ensure_ascii=False, default=str))
