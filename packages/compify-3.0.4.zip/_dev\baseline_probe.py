"""v3.0.3 行为基线测量。只读，不改仓库。

六个场景各测一遍，把「面板看到什么」「缓存命中与否」「真全量扫描几次」记下来。
统计口径严格分开：
  - 还原/判定次数  = 调 check_uv_adjust_validity_detailed 的次数（缓存命中也会计数）
  - 真全量扫描次数 = 调 find_objects_using_material 的次数（只有扫描路径才会调）

用法：<blender> --background --factory-startup --python _dev/baseline_probe.py
输出：BASELINE 前缀的行，可被下游脚本解析
"""
import bpy
import sys
import os
import importlib.util
import json
import traceback

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_baseline"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)

ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()

RESULT = {}


def emit(key, value):
    RESULT[key] = value
    print("BASELINE " + key + " = " + repr(value))


COUNTERS = {"scan": 0, "check": 0}


def install_counters():
    """把两个计数钩子装上。"""
    orig_find = ngm.find_objects_using_material
    orig_check = ngm.check_uv_adjust_validity_detailed

    def find_wrap(*a, **k):
        COUNTERS["scan"] += 1
        return orig_find(*a, **k)

    def check_wrap(*a, **k):
        COUNTERS["check"] += 1
        return orig_check(*a, **k)

    ngm.find_objects_using_material = find_wrap
    ngm.check_uv_adjust_validity_detailed = check_wrap
    return orig_find, orig_check


def reset_counters():
    COUNTERS["scan"] = 0
    COUNTERS["check"] = 0


def read_panel(scene):
    """照面板 draw 的真实路径读一遍，任何异常都记下来而不是崩掉。"""
    try:
        groups = ngm.get_all_uv_adjust_node_groups(scene)
    except Exception as e:  # noqa: BLE001
        return {"error": f"{type(e).__name__}: {e}", "n": None, "valid": None}
    try:
        names = [g["node_group"].name for g in groups]
        valid = [g["is_valid"] for g in groups]
        reasons = [g["status"].get("reason") for g in groups]
        return {"error": None, "n": len(groups), "names": names,
                "valid": valid, "reasons": reasons}
    except Exception as e:  # noqa: BLE001
        return {"error": f"{type(e).__name__}: {e}", "n": len(groups)}


def build(tag):
    """按插件真实路径搭：相机投影组 + UV 调整组 + 材质里的连线。"""
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    if hasattr(ngm, "invalidate_uv_cache"):
        ngm.invalidate_uv_cache(sc)
    return sc, obj, cam, uv, mat


orig_find, orig_check = install_counters()

try:
    # ============ 场景 1：正常一个组 ============
    reset_counters()
    sc, obj, cam, uv, mat = build("S1")
    reset_counters()
    n1 = read_panel(sc)
    first_scan = COUNTERS["scan"]
    reset_counters()
    for _ in range(10):
        read_panel(sc)
    repeat_scan = COUNTERS["scan"]
    emit("S1_normal_first_panel", n1)
    emit("S1_normal_first_scan_calls", first_scan)
    emit("S1_normal_repeat10_scan_calls", repeat_scan)

    # ============ 场景 2：删相机让组失效 ============
    bpy.ops.wm.read_factory_settings(use_empty=False)
    sc, obj, cam, uv, mat = build("S2")
    reset_counters()
    read_panel(sc)
    bpy.data.objects.remove(cam)
    if hasattr(ngm, "invalidate_uv_cache"):
        ngm.invalidate_uv_cache(sc)
    reset_counters()
    n2 = read_panel(sc)
    emit("S2_del_camera_panel", n2)
    reset_counters()
    for _ in range(10):
        read_panel(sc)
    emit("S2_del_camera_repeat10_scan_calls", COUNTERS["scan"])

    # ============ 场景 3：删物体让组失效 ============
    bpy.ops.wm.read_factory_settings(use_empty=False)
    sc, obj, cam, uv, mat = build("S3")
    reset_counters()
    read_panel(sc)
    bpy.data.objects.remove(obj)
    if hasattr(ngm, "invalidate_uv_cache"):
        ngm.invalidate_uv_cache(sc)
    reset_counters()
    n3 = read_panel(sc)
    emit("S3_del_object_panel", n3)
    reset_counters()
    for _ in range(10):
        read_panel(sc)
    emit("S3_del_object_repeat10_scan_calls", COUNTERS["scan"])

    # ============ 场景 4：两个文件都叫 Scene（同名） ============
    bpy.ops.wm.read_factory_settings(use_empty=False)
    sc, obj, cam, uv, mat = build("S4")
    name_s4 = uv.name
    reset_counters()
    read_panel(sc)
    emit("S4_before_new_panel", read_panel(sc))

    bpy.ops.wm.read_factory_settings(use_empty=False)   # 相当于 File > New，场景仍叫 Scene
    sc_new = bpy.context.scene
    reset_counters()
    n4 = read_panel(sc_new)
    emit("S4_after_new_scene_name", sc_new.name)
    emit("S4_after_new_panel", n4)
    emit("S4_leaks_old_group",
         any(g.get("node_group") and getattr(g.get("node_group"), "name", None) == name_s4
             for g in (n4.get("names") and [{"node_group": type("X", (), {"name": n})()}
                                            for n in n4["names"]] or []))
         if n4.get("names") else False)

    # ============ 场景 5：File > New 后读面板报什么 ============
    bpy.ops.wm.read_factory_settings(use_empty=False)
    sc, obj, cam, uv, mat = build("S5")
    reset_counters()
    read_panel(sc)
    bpy.ops.wm.read_factory_settings(use_empty=False)
    sc_new = bpy.context.scene
    n5 = read_panel(sc_new)
    emit("S5_after_file_new_panel", n5)

    # ============ 场景 6：刷新&清理 能不能用 ============
    bpy.ops.wm.read_factory_settings(use_empty=False)
    sc, obj, cam, uv, mat = build("S6")
    reset_counters()
    read_panel(sc)
    # 直接调底层清理（GUI operator 需要真实窗口上下文，headless 用底层函数代替）
    try:
        cleaned = ngm.clean_invalid_uv_adjust_node_groups(sc, confirm=False)
        emit("S6_clean_invalid_ok", True)
        emit("S6_clean_invalid_count", cleaned)
    except Exception as e:  # noqa: BLE001
        emit("S6_clean_invalid_ok", False)
        emit("S6_clean_invalid_error", f"{type(e).__name__}: {e}")

    # 刷新路径：读面板前先 invalidate（Refresh & Clean 的 invoke 就是这么干的）
    bpy.ops.wm.read_factory_settings(use_empty=False)
    sc, obj, cam, uv, mat = build("S6b")
    try:
        ngm.invalidate_uv_cache(sc) if hasattr(ngm, "invalidate_uv_cache") else None
        n6 = read_panel(sc)
        emit("S6_refresh_ok", True)
        emit("S6_refresh_panel", n6)
    except Exception as e:  # noqa: BLE001
        emit("S6_refresh_ok", False)
        emit("S6_refresh_error", f"{type(e).__name__}: {e}")

except Exception:  # noqa: BLE001
    traceback.print_exc()
finally:
    ngm.find_objects_using_material = orig_find
    ngm.check_uv_adjust_validity_detailed = orig_check

print("BASELINE_JSON " + json.dumps(RESULT, ensure_ascii=False, default=str))
print("BASELINE_VERSION " + str(mod.bl_info.get("version")))
