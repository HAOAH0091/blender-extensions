"""反查表等价性回归：_uv_build_usage_index() 必须和 get_node_group_usage_info() 逐条一致。

为什么必须单独有这条：
  反查表是为了性能（50 组 x 50 材质 = 2500 次节点遍历 -> 100 次）新加的，
  它复制了一份 get_node_group_usage_info 的过滤逻辑。**复制 = 迟早漂移**。
  哪天有人在原函数里加一个条件（比如 node.mute、或者 node 被禁用），
  反查表不会跟着变，两处结论就分叉了 —— 而现有测试只会因为"副作用"
  （失效原因文案变了、元数据没刷新）被绊倒，不会正面报警。

  这条测试的判据就一条：**逐组比对，两份实现的结果必须完全相同**。

注入验证（在临时副本里把反查表改成永远返回 []）：
  正常版    PASS 11 / FAIL 0
  注入版    FAIL（每一类边界都会红）

用法：<blender> --background --factory-startup --python _dev/test_uv_usage_index.py
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_usage_idx"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

PASS = []
FAIL = []


def chk(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()


def norm(usage):
    """归一化成可比较的元组集合（顺序无关）。"""
    return sorted((u["material"], u["node"]) for u in usage)


def compare(label, groups):
    """逐组比对反查表与原函数，任何一条不一致都算 FAIL。"""
    idx = ngm._uv_build_usage_index()
    bad = []
    for g in groups:
        a = norm(ngm.get_node_group_usage_info(g))
        b = norm(idx.get(g.name, []))
        if a != b:
            bad.append((g.name, a, b))
    chk(label, not bad, f"比对 {len(groups)} 组，不一致 {len(bad)} 条 "
                        + (str(bad[:2]) if bad else ""))
    return idx


def mk_group(tag, sc):
    obj = bpy.data.objects.new("O_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("C_" + tag, bpy.data.cameras.new("cd_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    return obj, cam, uv, cp


def mk_mat(name, groups):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    for g in groups:
        n = m.node_tree.nodes.new("ShaderNodeGroup")
        n.node_tree = g
    return m


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene

# ---- 1. 同一材质内多个 GROUP 节点引用同一个组 ----
o, c, uv, cp = mk_group("A", sc)
mk_mat("M_A", [uv, uv, uv])
compare("1 同一材质多个节点引用同一组", [uv])

# ---- 2. 一个材质同时引用多个不同的组 ----
g1 = mk_group("B1", sc)[2]
g2 = mk_group("B2", sc)[2]
mk_mat("M_B", [g1, g2])
compare("2 一个材质引用多个不同的组", [g1, g2])

# ---- 3. 中文 / 特殊字符 / 重名自动 .001 ----
g_cn = mk_group("CN", sc)[2]
g_cn.name = "UV Adjust | 中文物体 | 相机#1 (test) & <x>"
mk_mat("M中文", [g_cn])
g_dup = mk_group("DUP", sc)[2]
mk_mat("M_DUP1", [g_dup])
g_dup2 = mk_group("DUP2", sc)[2]          # 同名会被自动加 .001
compare("3 中文/特殊字符/重名 .001", [g_cn, g_dup, g_dup2])

# ---- 4. node_tree 为 None 的 GROUP 节点 + 混入非 GROUP 节点 ----
g3 = mk_group("C", sc)[2]
m_mix = bpy.data.materials.new("M_Mix")
m_mix.use_nodes = True
gn = m_mix.node_tree.nodes.new("ShaderNodeGroup")
gn.node_tree = None                        # node_tree 为 None
m_mix.node_tree.nodes.new("ShaderNodeTexImage")
m_mix.node_tree.nodes.new("ShaderNodeBsdfPrincipled")
compare("4 node_tree 为 None / 非 GROUP 节点", [g3])

# ---- 5. 材质被删除后 ----
g4 = mk_group("D", sc)[2]
m_del = bpy.data.materials.new("M_Del")
m_del.use_nodes = True
m_del.node_tree.nodes.new("ShaderNodeGroup").node_tree = g4
bpy.data.materials.remove(m_del)
compare("5 材质被删除之后", [g4])

# ---- 6. 普通节点组 / Camera Project 组 ----
plain = bpy.data.node_groups.new("PlainGroup", "ShaderNodeTree")
mk_mat("M_Plain", [plain])
o5, c5, uv5, cp5 = mk_group("E", sc)
o5.data.materials.append(mk_mat("M_E", [uv5, cp5]))
compare("6 普通节点组 + Camera Project 组", [plain, cp5, uv5])

# ---- 7. 全量比对（文件里所有节点组）----
all_groups = list(bpy.data.node_groups)
compare("7 全量比对所有节点组", all_groups)

# ---- 7b. 节点处于各种"可疑状态"时 ----
# ⚠️ 这一条是"防漂移"专用：如果将来有人给其中一份实现加了
#    node.mute / node.hide 之类的过滤条件而另一份没加，两边结论会在这里分叉。
#    没有这条用例的话，普通场景下两份实现"碰巧一致"，测试形同虚设
#    （实测：第一版没有这条，做单边漂移注入时仍然全绿）。
#
#    同一个材质里同时放："被 mute 的" + "被 hide 的" + "正常的"，
#    一次覆盖多个过滤维度 —— 只覆盖 mute 的话，将来加 hide 过滤照样抓不住。
#
#    ⚠️ 已知极限：这招只能抓**单边漂移**（只有一份实现被改）。
#       如果两边同时加一模一样的过滤，结论仍然一致，本测试抓不住 ——
#       这是任何"两份实现互比"的固有边界，除非引入第三方真值。
#       要防这个，只能靠人读代码 + code review，测试帮不上忙。
g_states = mk_group("STATES", sc)[2]
m_states = bpy.data.materials.new("M_States")
m_states.use_nodes = True
n_mute = m_states.node_tree.nodes.new("ShaderNodeGroup")
n_mute.node_tree = g_states
n_mute.mute = True                                   # 被 mute
n_hide = m_states.node_tree.nodes.new("ShaderNodeGroup")
n_hide.node_tree = g_states
n_hide.hide = True                                   # 被 hide
m_states.node_tree.nodes.new("ShaderNodeGroup").node_tree = g_states   # 正常
compare("7b mute / hide / 正常 三节点并存", [g_states])

# ---- 8. 大规模交叉：多个组 x 多个材质 ----
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
many = []
for i in range(12):
    o, c, uv, cp = mk_group("M%02d" % i, sc)
    many.append(uv)
for i in range(12):
    mk_mat("Cross%02d" % i, [many[i], many[(i + 1) % 12], many[(i + 5) % 12]])
compare("8 大规模交叉引用（12 组 x 12 材质）", many)

print()
print("=" * 50)
print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
if FAIL:
    print("FAILED:", FAIL)
