# _dev 本次新增文件清单（提交前分类）

分支 `fix/uv-cache-v304`，版本号 `(3,0,3)` 未改，CHANGELOG 未动。
清点时间：2026-10-20

---

## 一、长期该留的回归测试（建议进仓库，每次改动都要跑）

这三个是 `test_` 前缀，和 `_dev/` 里原有 34 个测试同一命名体系，
已有的跑法（遍历 `_dev\test_*.py`）会自动带上，不需要额外配置。

| 文件 | 判定条数 | 守什么 | 拆掉对应代码会不会红 |
|---|---:|---|---|
| `test_uv_acceptance.py` | **44** | 九行验收表全部带断言：正常组 / 删相机前后 / 删物体前后 / File > New / 交叉打开 / 空结果 / 原有功能（批量生成、正常清理） | 拆"每次现查现判" → **FAIL 6** |
| `test_uv_empty_cache.py` | 9 | 空结果（真 0 条）必须写进缓存并命中 | 拆"空结果写缓存" → **FAIL 3** |
| `test_uv_load_post.py` | 8 | 文件里的陈旧缓存在 File > Open 后必须被清掉 | 拆 `load_post` 注册 → **FAIL 2** |

**为什么要三个而不是一个**：每个只对自己那道防线敏感。

| 注入 | acceptance | empty_cache | load_post |
|---|---|---|---|
| 拆"每次现查现判"（返回快照） | **FAIL 6** | PASS | PASS |
| 空结果不写缓存 | PASS | **FAIL 3** | PASS |
| 拆 `load_post` | PASS | PASS | **FAIL 2** |

**只跑一个文件没有意义**，这是上一版栽过的坑。

---

## 二、一次性测量探针（基线/对照用，建议归档，不进长期回归）

这些**没有断言**，是"读数工具"，只用于把改动前后的数据量出来给人看。
留在 `_dev/` 里会被误当成门禁——`acceptance_probe.py` 就出过这个事。

| 文件 | 用途 | 建议 |
|---|---|---|
| `baseline_probe.py` | v3.0.3 九场景基线测量 | 归档 |
| `baseline_s2_probe.py` | 删相机三态 + 空结果入缓存 | 归档 |
| `baseline_s2c_probe.py` | 模块重载的第一版（**方法有误**，见下） | 删 |
| `baseline_s2c2_probe.py` | 真重载（清 `sys.modules`） | 归档 |
| `baseline_s3_probe.py` | 删物体两种顺序 | 归档 |
| `baseline_s4_probe.py` | 两个 .blend 交叉打开 | 归档 |
| `baseline_symmetry_probe.py` | 删相机 vs 删物体不对称 | 归档 |
| `acceptance_probe.py` | 九行表读数（**0 断言**） | 归档，**明确标注"不是门禁"** |

> `baseline_s2c_probe.py` 建议直接删：它用 `spec_from_file_location` 重复 exec 顶层包，
> 但子模块还在 `sys.modules` 里会被复用，**根本没重载**（实测两次 `id` 相同）。
> 结论已被 `baseline_s2c2_probe.py` 取代。留着会误导后来人。

---

## 三、文档（建议留，是这次决策的来龙去脉）

| 文件 | 内容 |
|---|---|
| `BASELINE-v3.0.3.md` | 改动前的行为基线 + 验收红线 R1/R2/R3/R4/R5/R6/R10 |
| `BASELINE-不对称.md` | 删相机 vs 删物体为什么不对称、孤儿组问题 |
| `ACCEPTANCE-UV缓存.md` | 九行对照表、行为变化清单、1e 判据之争的定案、注入证据 |

---

## 四、已清理

- `_dev/_tmp_r2.py` —— 中途临时脚本，已删除（内容已被 `test_uv_empty_cache.py` 吸收）
- `_dev/_tmp_*.py` 其他残留 —— 已确认没有

---

## 五、复跑

```
# 三个长期测试
<blender> --background --factory-startup --python _dev\test_uv_acceptance.py
<blender> --background --factory-startup --python _dev\test_uv_empty_cache.py
<blender> --background --factory-startup --python _dev\test_uv_load_post.py
```

实测：5.2.2 上 `41 / 8 / 8` 全过；5.1.2 上同样全过。
全量 `_dev` 37 个脚本：5.2.2 **538 PASS / 0 FAIL / 0 Traceback**，5.1.2 **ALL CLEAN**。
