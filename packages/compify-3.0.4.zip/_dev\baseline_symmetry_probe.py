"""复核 CodeAuditor 补的三条要求，特别是第 2 条"S3 第一次读就该 0 条"。

问题：S3 的情况是"删物体后，组在文件里还在、材质还在、只是没有物体用它"。
     要求"第一次读就 0 条"意味着：这个组从面板彻底消失，用户看不到、也删不掉。
     但 v3.0.3 的 S2（删相机）是保留在面板上显示红字的。

     这两者不一致：删相机保留、删物体就消失？
     测一下 v3.0.3 在这两种情况下，缓存里的行分别是什么。
"""
import bpy
import sys
import os
import importlib.util
import json

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_chk"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = {}


def emit(k, v):
    OUT[k] = v
    print("C " + k + " = " + repr(v))


def fresh():
    for k in [k for k in list(sys.modules) if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    m = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = m
    spec.loader.exec_module(m)
    return m


def setup(m, tag):
    ng = sys.modules[PKG + ".node_groups"]
    nm = sys.modules[PKG + ".names"]
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return sc, obj, cam, uv, mat


# ---- 删相机：看缓存行 ----
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "CAM")
g = ngm.get_all_uv_adjust_node_groups(sc)
row_cam = [(x["node_group"].name, x["camera"], x["is_valid"]) for x in g]
emit("del_camera_cached_row", str(row_cam))
bpy.data.objects.remove(cam)
g2 = ngm.get_all_uv_adjust_node_groups(sc)      # 命中旧缓存
emit("del_camera_after_read", [(x["node_group"].name, x["is_valid"]) for x in g2])
emit("group_still_in_file",
     bpy.data.node_groups.get(uv.name) is not None)
emit("material_still_in_file",
     bpy.data.materials.get("M_CAM") is not None)

# ---- 删物体：看缓存行 ----
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "OBJ")
g = ngm.get_all_uv_adjust_node_groups(sc)
row_obj = [(x["node_group"].name, x["object"], x["is_valid"]) for x in g]
emit("del_object_cached_row", str(row_obj))
bpy.data.objects.remove(obj)
g2 = ngm.get_all_uv_adjust_node_groups(sc)      # 命中旧缓存
emit("del_object_after_read", [(x["node_group"].name, x["is_valid"]) for x in g2])
emit("obj_group_still_in_file", bpy.data.node_groups.get(uv.name) is not None)
emit("obj_material_still_in_file", bpy.data.materials.get("M_OBJ") is not None)

# ---- 关键对照：删物体后 invalidate，组被谁过滤掉了 ----
ngm.invalidate_uv_cache(sc)
g3 = ngm.get_all_uv_adjust_node_groups(sc)
emit("del_object_after_invalidate", [(x["node_group"].name, x["is_valid"]) for x in g3])
emit("obj_group_still_in_file_after", bpy.data.node_groups.get(uv.name) is not None)

print("C_JSON " + json.dumps(OUT, ensure_ascii=False, default=str))
