"""S4 交叉验证：两个 .blend 文件来回打开（A->B->A），会不会串 / 会不会崩。

CodeAuditor 说我测的是 File > New，不是"两个文件交叉打开"。
这里走真实文件路径：存 A -> 存 B -> 开 A -> 开 B -> 再开 A。
"""
import bpy
import sys
import os
import importlib.util
import json
import tempfile

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_s4x"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = {}


def emit(k, v):
    OUT[k] = v
    print("S " + k + " = " + repr(v))


def fresh():
    for k in [k for k in list(sys.modules) if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    m = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = m
    spec.loader.exec_module(m)
    return m


m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
m.register()


def setup(tag):
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return sc, obj, cam, uv, mat


def panel():
    sc = bpy.context.scene
    try:
        g = ngm.get_all_uv_adjust_node_groups(sc)
        names = []
        for x in g:
            try:
                names.append(x["node_group"].name)
            except ReferenceError as e:
                names.append(f"<DEAD: {e}>")
        return {"n": len(g), "valid": [x["is_valid"] for x in g], "names": names}
    except Exception as e:  # noqa: BLE001
        return {"err": f"{type(e).__name__}: {e}"}


tmpdir = tempfile.gettempdir()
fileA = os.path.join(tmpdir, "_s4_A.blend")
fileB = os.path.join(tmpdir, "_s4_B.blend")

# 建 A 并保存
bpy.ops.wm.read_factory_settings(use_empty=False)
sc, obj, cam, uv, mat = setup("A")
nameA = uv.name
emit("A_panel", panel())
bpy.ops.wm.save_as_mainfile(filepath=fileA)

# 建 B 并保存
bpy.ops.wm.read_factory_settings(use_empty=False)
sc, obj, cam, uv, mat = setup("B")
nameB = uv.name
emit("B_panel", panel())
bpy.ops.wm.save_as_mainfile(filepath=fileB)

# A -> B
bpy.ops.wm.open_mainfile(filepath=fileA)
emit("open_A_panel", panel())
bpy.ops.wm.open_mainfile(filepath=fileB)
emit("open_B_panel", panel())

# B -> A
bpy.ops.wm.open_mainfile(filepath=fileA)
emit("open_A_again_panel", panel())
emit("expected_A_name", nameA)
emit("expected_B_name", nameB)

for f in (fileA, fileB):
    if os.path.exists(f):
        os.remove(f)

print("S_JSON " + json.dumps(OUT, ensure_ascii=False, default=str))
