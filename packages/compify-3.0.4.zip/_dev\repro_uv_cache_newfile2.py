
import bpy, sys, os, importlib.util, traceback
sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_repro2"
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(PKG, os.path.join(PKG_DIR, "__init__.py"),
                                             submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec); sys.modules[PKG] = mod; spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
ng  = sys.modules[PKG + ".node_groups"]
nm  = sys.modules[PKG + ".names"]
mod.register()

def build(tag):
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam); sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag); mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup"); cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup"); uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return sc, obj, cam, uv

def show(k, v):
    print("RESULT", k, "=", v)

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.scene.name = "Scene"
sc, obj, cam, uv = build("A")
ngm.invalidate_uv_cache()
g1 = ngm.get_all_uv_adjust_node_groups(sc)
show("A_groups", [x["node_group"].name for x in g1])
show("A_cache_keys", list(ngm._uv_adjust_cache.keys()))

# ---- 模拟 File > New（同一个 Blender 进程，不退出）----
bpy.ops.wm.read_factory_settings(use_empty=True)
sc2 = bpy.context.scene
sc2.name = "Scene"          # 新建工程的默认名字，用户就是这么撞上的
show("B_scene", sc2.name)
show("B_objects", len(sc2.objects))
show("B_all_node_groups", [g.name for g in bpy.data.node_groups])
show("B_all_materials", [m.name for m in bpy.data.materials])
show("B_cache_keys", list(ngm._uv_adjust_cache.keys()))

# 面板第一行代码就是它：
try:
    g2 = ngm.get_all_uv_adjust_node_groups(sc2)
    show("B_groups_len", len(g2))
    rows = []
    for x in g2:
        r = {}
        try:
            r["node_group_name"] = x["node_group"].name
        except Exception as e:
            r["node_group_name"] = "!!" + type(e).__name__
        r["materials"] = list(x["materials"])
        r["is_valid"] = x["is_valid"]
        r["status_reason"] = x.get("status", {}).get("reason")
        r["object_repr"] = repr(x["object"])
        r["camera_repr"] = repr(x["camera"])
        rows.append(r)
    show("B_rows", rows)
    # 面板过滤条件
    show("B_active_groups(会显示出来的)", [x["materials"] for x in g2 if x["materials"]])
except Exception as e:
    show("B_read_err", type(e).__name__ + ": " + str(e))
    show("B_trace", traceback.format_exc()[-1200:])

# 再打开面板另一处：折叠状态 / 选中判定用 find_objects_using_material
try:
    from importlib import import_module
    ngr = sys.modules[PKG + ".node_groups"]
    show("B_find_objects_using_material(M_A)", [o.name for o in ngr.find_objects_using_material("M_A")])
except Exception as e:
    show("B_find_err", type(e).__name__ + ": " + str(e))

# 用户点「刷新 & 清理」之后
ngm.invalidate_uv_cache()
show("C_after_refresh", len(ngm.get_all_uv_adjust_node_groups(sc2)))
