
import io, sys
p = sys.argv[1]
with io.open(p, "r", encoding="utf-8") as f:
    src = f.read().replace("\r\n", "\n")

# 注入：只给【原函数】加一个 node.mute 过滤（模拟"有人改了原函数忘了改反查表"）
a = '''                        if node.type != "GROUP":
                            continue

                        if not node.node_tree:
                            continue

                        # 安全比较节点树名称'''
b = '''                        if node.type != "GROUP":
                            continue

                        if not node.node_tree:
                            continue

                        if getattr(node, "mute", False):
                            continue

                        # 安全比较节点树名称'''
assert a in src, "drift anchor missing"
src = src.replace(a, b, 1)
with io.open(p, "w", encoding="utf-8", newline="\n") as f:
    f.write(src)
print("INJECTED drift(only original gets node.mute filter)")
