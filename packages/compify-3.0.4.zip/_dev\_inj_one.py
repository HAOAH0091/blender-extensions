
import io, sys
p = sys.argv[-1]
which = sys.argv[-2]
with io.open(p, "r", encoding="utf-8") as f:
    src = f.read().replace("\r\n", "\n")
if which == "sentinel":
    a = '''            live_names = set()
            for group in bpy.data.node_groups:
                if _uv_group_is_uv_adjust(group):
                    live_names.add(group.name)
            cached_names = {item["ng"] for item in rows}
            if live_names != cached_names:
                rows = None'''
    assert a in src
    src = src.replace(a, "            pass", 1)
elif which == "untrusted":
    c = '''            cache_untrusted = True
            continue'''
    assert c in src
    src = src.replace(c, "            continue", 1)
with io.open(p, "w", encoding="utf-8", newline="\n") as f:
    f.write(src)
print("ok", which)
