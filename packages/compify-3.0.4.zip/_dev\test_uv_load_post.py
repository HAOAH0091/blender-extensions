"""load_post 防线回归：文件里存一条陈旧缓存 → File > Open → 必须被清掉。

为什么必须单独有这条：
  缓存本身存在 scene ID 属性上，换文件时新文件天然没有旧属性——
  但**同一个 .blend 文件里存着的陈旧缓存**不会自己消失，必须靠
  load_post 处理器清掉。没有它，打开文件后会拿着上一会话留下的
  空壳缓存（虽然每次读都按名字现查，不会变成幽灵组，但会留着脏数据）。

这条测试的作用是：把 `invalidate_uv_cache_on_load` 注掉，
它必须变红。否则这行代码谁都能随手删，没人报警。

用法：<blender> --background --factory-startup --python _dev/test_uv_load_post.py
"""
import bpy
import sys
import os
import importlib.util
import tempfile

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_lp"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

PASS = []
FAIL = []


def chk(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
mod.register()

# ---- 1. handler 确实挂上了，且带 persistent ----
h = getattr(ngm, "invalidate_uv_cache_on_load", None)
chk("1a handler 存在", h is not None)
chk("1b register 后挂在 load_post 上", h is not None and h in bpy.app.handlers.load_post,
    str([getattr(x, "__name__", x) for x in bpy.app.handlers.load_post]))
chk("1c 带 persistent 标记（不加会被 Blender 读文件时清掉）",
    h is not None and "_bpy_persistent" in getattr(h, "__dict__", {}),
    str(getattr(h, "__dict__", {})))

# ---- 2. 行为：文件里存陈旧缓存 → 重开 → 被清掉 ----
bpy.ops.wm.read_factory_settings(use_empty=False)
sc = bpy.context.scene
stale = '{"v":1,"rows":[]}'
sc["compify_uv_cache"] = stale
lp = os.path.join(tempfile.gettempdir(), "_lp_test.blend")
bpy.ops.wm.save_as_mainfile(filepath=lp)
chk("2a 前提：磁盘文件里确实存着陈旧缓存",
    bpy.context.scene.get("compify_uv_cache") == stale,
    repr(bpy.context.scene.get("compify_uv_cache")))

# 在内存里改成别的内容（不保存），确保重开后不是"沿用内存值"
bpy.context.scene["compify_uv_cache"] = '{"v":1,"rows":["FROM_MEMORY"]}'

bpy.ops.wm.open_mainfile(filepath=lp)
after = bpy.context.scene.get("compify_uv_cache")
chk("2b File > Open 后陈旧缓存被清掉", after is None, repr(after))

# ---- 3. 清掉之后功能照常：能重新建缓存并工作 ----
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
sc2 = bpy.context.scene
obj = bpy.data.objects.new("Obj_LP", bpy.data.meshes.new("m_LP"))
sc2.collection.objects.link(obj)
cam = bpy.data.objects.new("Cam_LP", bpy.data.cameras.new("CamData_LP"))
sc2.collection.objects.link(cam)
sc2.camera = cam
cp = ng.ensure_camera_project_group(cam)
uv = ng.create_uv_adjust_node_group(sc2, cam, obj)
mat = bpy.data.materials.new("M_LP")
mat.use_nodes = True
nt = mat.node_tree
cpn = nt.nodes.new("ShaderNodeGroup")
cpn.node_tree = cp
uvn = nt.nodes.new("ShaderNodeGroup")
uvn.node_tree = uv
tex = nt.nodes.new("ShaderNodeTexImage")
nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
             uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
nt.links.new(next(s for s in uvn.outputs
                  if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
obj.data.materials.append(mat)
ngm.invalidate_uv_cache(sc2)
groups = ngm.get_all_uv_adjust_node_groups(sc2)
chk("3a 清掉缓存后仍能正常扫描出新组", len(groups) == 1, f"N={len(groups)}")
chk("3b 读出来的是活对象（不是死引用）",
    bool(groups) and groups[0]["node_group"] is not None
    and groups[0]["node_group"].name == uv.name,
    groups[0]["node_group"].name if groups else "N/A")

# ---- 4. 注销时摘掉 handler ----
mod.unregister()
chk("4a unregister 后 handler 被摘掉",
    h is not None and h not in bpy.app.handlers.load_post)

if os.path.exists(lp):
    os.remove(lp)

print()
print("=" * 50)
print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
if FAIL:
    print("FAILED:", FAIL)
