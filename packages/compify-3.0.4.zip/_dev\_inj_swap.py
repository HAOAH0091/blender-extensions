
import io, sys
p = sys.argv[-1]
with io.open(p, "r", encoding="utf-8") as f:
    src = f.read().replace("\r\n", "\n")
old = '''            live_names = set()
            for group in bpy.data.node_groups:
                if _uv_group_is_uv_adjust(group):
                    live_names.add(group.name)
            cached_names = {item["ng"] for item in rows}
            if live_names != cached_names:
                rows = None
'''
new = '''            live = 0
            for group in bpy.data.node_groups:
                if _uv_group_is_uv_adjust(group):
                    live += 1
            if live != len(rows):
                rows = None
'''
assert old in src, "ANCHOR MISSING"
src = src.replace(old, new, 1)
with io.open(p, "w", encoding="utf-8", newline="\n") as f:
    f.write(src)
print("INJECTED_OK")
