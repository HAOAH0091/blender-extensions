# v3.0.3 行为基线（修正版：S2 三态 + 空结果入缓存）

- **测量对象**：`F:\desktop\BaiduSyncdisk\addons\compify-master`，分支 `fix/uv-cache-v304`，HEAD `a8f1ef1`，版本 `(3,0,3)`
- **测量日期**：2026-10-20（修正版）
- **脚本**：`_dev/baseline_probe.py`（主）、`_dev/baseline_s2_probe.py`（S2 三态 + 空结果）、`_dev/baseline_s2c2_probe.py`（真重载）

> **统计口径**（严格分开）
> - **扫** = `find_objects_using_material` 调用次数（只有扫描路径会调）
> - **判** = `check_uv_adjust_validity_detailed` 调用次数（缓存命中也算）

---

## 一、S2 三态（删相机）

| 情况 | 面板结果 | 结论 |
|---|---|---|
| **S2a** 删相机，**不碰缓存** | `n=1, valid=[True], reason=['无']` | **旧缓存被当成有效** ⚠️ |
| **S2b** 删相机，**调 invalidate** | `n=1, valid=[False], reason=['找不到相机…']` | 红字出现 |
| **S2c** 删相机，**真正重载模块** | `n=1, valid=[False], reason=['找不到相机…']` | **重载后也是红字** |

### S2c 的关键更正（我第一版测错了）

第一版我报"重载后变有效"，**那是我的测量方法有问题**：
我用 `spec_from_file_location` 重新 exec 顶层包，但**子模块还留在 `sys.modules` 里**，
`from .node_group_manager import ...` 发现已存在就直接复用 ⇒ `_uv_adjust_cache` **还是老字典**，
等于没重载。实测证据：重载后缓存字典仍是 `{'Scene': 1}`，两次加载的模块对象 `id` 完全相同。

**真正重载**（把 `PKG` 及所有 `PKG.*` 从 `sys.modules` 摘掉再 exec）：
缓存字典变成 `{}`，重扫后 `valid=[False]` —— **红字正常出现**。

**最终事实**：v3.0.3 里，删相机之后只要**旧缓存还在**，面板就显示"有效"；
一旦缓存被清（invalidate / 真正重载 / 重扫），就正确显示失效红字。
**缺陷是"缓存不跟着场景变"，与重载与否无关。**

---

## 二、空结果到底有没有进缓存（关键，上次最大回归点）

| 检查项 | 实测值 |
|---|---|
| 删物体前扫描 | 缓存 `{'Scene': 'len=1'}` |
| 删物体后扫描 | 面板 `n=0` |
| 缓存字典 | `{'Scene': 'len=0'}` |
| **键是否存在** | **`True`** |
| **值是否为 `[]`** | **`True`** |

**结论：空结果确实被写进了缓存（`{场景名: []}`），不是"没写所以没重扫"。**
所以"空结果也能命中缓存"是 v3.0.3 的**真实行为**，新方案必须保住。

---

## 三、完整基线表

| # | 场景 | 面板 | 连续读 10 次扫描 | 备注 |
|---|---|---|---|---|
| S1 | 正常一组 | 1 条，`valid=[True]`，`无` | 首次 1，之后 **0** | 缓存正常 |
| S2a | 删相机·不碰缓存 | 1 条，`valid=[True]`，`无` | — | ⚠️ 旧缓存当有效 |
| S2b | 删相机·invalidate | 1 条，`valid=[False]`，红字 | — | 正确 |
| S2c | 删相机·真重载 | 1 条，`valid=[False]`，红字 | — | 正确 |
| S3a | 删物体·**先缓存后删·不刷新** | **1 条**，`valid=[True]`，`无` | — | ⚠️ 死条目被当有效 |
| S3b | 删物体·**删后 invalidate** | **0 条**（组消失） | 之后 **0**（空结果命中缓存） | ⚠️ 范围外老问题 |
| S4a | File > New | **`ReferenceError`**，返回 1 条 `<ShaderNodeTree invalid>` | — | **本次要修** |
| S4b | **两个 .blend 交叉打开**（A→B→A） | **全部 `<DEAD: StructRNA ...>`**，而且 `valid=[True]` | — | **比 S4a 更严重：新建 B 时就死引用了** |
| S6 | 刷新&清理 | 调用成功，清理 0 | — | 正常 |

### S3 两态与空结果缓存（第二版修正）

我第一版把 S3 只写成"0 条"，**是片面的**，CodeAuditor 这条指对了：

| 顺序 | 结果 |
|---|---|
| S3a：先建缓存 → 删物体 → **直接读** | **1 条、`valid=[True]`、`无`** ← 死条目被当成有效 |
| S3b：先建缓存 → 删物体 → **invalidate → 读** | **0 条**（组消失） |

**空结果入缓存——这次是干净验证的**（上次的质疑成立，我重做了）：

```
R_cache_cleared      = {}                 ← 先彻底清空缓存字典
R_scan_result        = n=0                ← 这一次必然是重扫
R_cache_after_scan   = {'Scene': 'len=0'} ← 扫完写入了空列表
R_key_present        = True
R_value_empty        = []
R_second_read_scan_calls = 0              ← 第二次读命中缓存，没重扫
```

**结论确凿：空结果确实被写进缓存（`{场景名: []}`），并且能命中。** 上次的推断这一步方向是对的，
但验证方法不干净；这次是"清空 → 强制重扫 → 观察写入 → 再读验证命中"，可以当硬指标。

---

## 四、改动后的验收红线

> **R10（CodeAuditor 提出，我实测确认）**：缓存里不许出现 `<Object invalid>` / `<ShaderNodeTree invalid>`
> 这类死引用，**更不能把它判成 `valid=True`**。

### R10 的实测证据（v3.0.3，已确认）

```
A. 缓存建立:            object = <bpy_struct, Object("Obj_R10") ...>   valid=[True]
B. 删物体后看缓存那条:   object = <bpy_struct, Object invalid>          is_valid = True
C. 读死对象的属性:      .name / .type / .data 全部抛 ReferenceError
D. 面板读（命中缓存）:   N=1  valid=[True]  object=[<Object invalid>]
```

**根因**：`is_valid` 只在**扫描那一刻**算一次（`node_group_manager.py:212-218`），
然后随缓存原样透出（`:242`）；**读取时从不重新判定**。
所以死引用不但会被当成旧数据，还会被直接判为"有效"。

| 编号 | 要求 |
|---|---|
| R1 | S1 缓存命中能力不能退化（首次 1 次扫描、之后 0） |
| R2 | **空结果必须能命中缓存**（S3b 连续读 0 次扫描）——已用干净方法确认成立 |
| R3 | S2b 红字与文案不能变（`找不到相机（可能被删除或因重名改名 .001）`） |
| R4 | S6 「刷新&清理」能力不能变 |
| R5 | S4a/S4b 必须从 `ReferenceError` / 死引用 变成"不报错、不显示别的文件的组" |
| **R10** | **有效状态必须每次读都重新判定，不许缓存 `is_valid` 快照；页面拿到的实体必须是活的** |
| R6 | S2a（删相机·不碰缓存）行为**会变**：从"显示有效"变成"显示红字"。**这是改进，必须明确承认并写进报告**，不许静默改 |
| R7 | 顺带说明：S3a 的"死条目被当有效"和 S2a 是同一个病根（缓存不跟着场景变）。新方案修 S2a 时，S3a 大概率一起变好——**必须报告，不能算作"没改行为"** |

---

## 五、本机测不了的（未验证）

- GUI 真实点击（`invoke_props_dialog` 需要真实窗口/事件）
- 面板 `draw()` 真实绘制上下文
- Blender 5.3（本机无二进制）
- **插件重载的真实路径**：我用"清 `sys.modules` + 重新 exec"模拟。Blender 里禁用/启用插件、
  或 `importlib.reload`，是否等价，**未验证**。

---

## 六、复跑

```
<blender> --background --factory-startup --python _dev\baseline_probe.py
<blender> --background --factory-startup --python _dev\baseline_s2_probe.py
<blender> --background --factory-startup --python _dev\baseline_s2c2_probe.py
```
