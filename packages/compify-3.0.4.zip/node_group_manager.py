# ====================== BEGIN GPL LICENSE BLOCK ======================
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ======================= END GPL LICENSE BLOCK ========================

"""UV Adjust node group management for Compify.

CRUD operations for UV Adjust node groups: list, clean, update, delete,
rename handling. Imports core creation and utility functions from node_groups.py.
"""

import json

import bpy

from .names import (
    UV_ADJUST_INPUT_SOCKET_NAME,
    UV_ADJUST_OUTPUT_SOCKET_NAME,
    UV_ADJUST_NODE_GROUP_PREFIX,
    uv_adjust_node_group_name,
    camera_project_node_group_name,
)
from .node_groups import (
    find_object_by_data_name,
    find_objects_using_material,
    extract_camera_from_camera_project_group,
    find_camera_connected_to_uv_adjust_in_material,
    create_uv_adjust_node_group,
    ensure_camera_project_group,
    check_camera_project_group_exists,
    get_object_camera_bounds,
)

# ========================================================
# UV Adjust 列表缓存
#
# 老实现（v3.0.3 及以前）有两个病，都在同三行代码上：
#
#   1) 键是 scene.name。每个新工程的场景都叫 "Scene"，
#      File > New / 换个 .blend 再读，名字撞键 ⇒ 直接拿到
#      上一个文件的缓存条目。
#   2) 条目里存的是 NodeGroup / Object / Camera 的 RNA 实体。
#      文件一换这些实体全被销毁，读 .name 就 ReferenceError。
#      更阴的是 is_valid 也是扫描那一刻算好的快照（见 :212-218），
#      跟着缓存一起透出 ⇒ 会拿到 <Object invalid> 却判定 True。
#
# 新实现的原则（一条）：**缓存里只许放名字，绝不放实体；
# 每次读都拿名字回 bpy.data 现查，并重新判定有效性。**
#
#   好比以前柜子里放的是实物，搬家时全成空壳；
#   现在柜子里只放写着名字的标签，用的时候按标签去仓库里现取——
#   取到了就是活的，取不到就明说"没有"，永远不会拿到空壳。
#
# 存放位置：每个场景自己的 ID 属性 scene["compify_uv_cache"]，
# 跟着 .blend 文件走。换文件时新文件的场景天然没有这个属性，
# 从根上不可能读到上一个文件的缓存；同名场景也各存各的。
# ========================================================

_UV_CACHE_PROP = "compify_uv_cache"
_UV_CACHE_VERSION = 1

# 兼容旧名字：老代码（及部分 _dev 脚本）读这个字典判断"缓存有没有东西"。
# 真正的数据已经挪到场景 ID 属性上，这里只保留一个空壳，不做数据源。
_uv_adjust_cache = {}


def _uv_cache_store(scene, rows):
    """把缓存写进场景 ID 属性。rows 为 None 表示清空。

    存的是 JSON（不是自己拼分隔符）——名字里可能出现任何字符，
    自制分隔符会被名字内容切断（实测材质名 "M|X" 会被切成两个）。
    """
    if scene is None:
        return
    if rows is None:
        try:
            if _UV_CACHE_PROP in scene:
                del scene[_UV_CACHE_PROP]
        except (AttributeError, TypeError, ReferenceError):
            pass
        return
    text = json.dumps({"v": _UV_CACHE_VERSION, "rows": rows},
                      ensure_ascii=False, separators=(",", ":"))
    try:
        # 内容没变就不写。面板 draw 每帧都会调到这里，
        # 无谓地写数据块会破坏"draw 只读"的约定，也会让 .blend 变脏。
        if scene.get(_UV_CACHE_PROP) == text:
            return
        scene[_UV_CACHE_PROP] = text
    except (AttributeError, TypeError):
        pass


def _uv_cache_read(scene):
    """读出缓存里的名字列表；读不出来（从没存过/版本不符/坏数据）返回 None。"""
    if scene is None:
        return None
    raw = scene.get(_UV_CACHE_PROP)
    if not isinstance(raw, str) or not raw:
        return None
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict) or data.get("v") != _UV_CACHE_VERSION:
        return None
    rows = data.get("rows")
    if not isinstance(rows, list):
        return None
    out = []
    for item in rows:
        if not isinstance(item, dict):
            return None
        ng = item.get("ng")
        if not isinstance(ng, str) or not ng:
            return None
        obj = item.get("obj")
        cam = item.get("cam")
        mats = item.get("mats") or []
        out.append({
            "ng": ng,
            "obj": obj if isinstance(obj, str) and obj else None,
            "cam": cam if isinstance(cam, str) and cam else None,
            "mats": [x for x in mats if isinstance(x, str)],
        })
    return out


def invalidate_uv_cache(scene=None):
    """让下次读重新扫描。

    签名不变（13 个调用点都传 scene），语义也不变：清掉这个场景的缓存。
    唯一的差别是作用域从"全进程所有场景"缩到"传入的这个场景"——
    更精确，不会因为改 A 场景而把 B 场景的缓存也清掉。
    """
    target = scene if scene is not None else bpy.context.scene
    _uv_cache_store(target, None)
    _uv_adjust_cache.clear()
    # 材质→物体缓存也一并失效：宁可多扫一次，也不要拿到改之前的答案
    _uv_material_objects_cache.clear()


@bpy.app.handlers.persistent
def invalidate_uv_cache_on_load(*_args):
    """File > Open / File > New / 重载 .blend 之后，把所有场景的缓存清掉。

    ⚠️ 必须带 @bpy.app.handlers.persistent。实测 Blender 5.2.2：
       普通函数挂到 bpy.app.handlers 上，读新文件时会被 Blender 一起清掉
       （File > Open / read_factory_settings 之后列表里只剩内置的两条）。

    清的方式是删掉每个场景上的缓存属性。场景可能正在被销毁，所以全程 try。
    """
    try:
        scenes = list(bpy.data.scenes)
    except (AttributeError, ReferenceError):
        return
    for scene in scenes:
        _uv_cache_store(scene, None)
    _uv_adjust_cache.clear()
    _uv_material_objects_cache.clear()


def _invalidate_scenes_for_object(obj):
    """把「这个物体可能改到的那些场景」逐个失效掉。

    为什么不能直接用 bpy.context.scene：
      写操作的调用方不一定处在目标物体所在的场景里（批处理、脚本、
      后台运行都可能是这样）。只清当前场景 ⇒ 目标场景的缓存留脏。

    打个比方：你在 3 号仓库里换了货，却只把 5 号仓库的账本擦了。
    所以这里按「物体的名字出现在哪些场景的 objects 里」挨个擦。
    写操作才走这条路，频率极低，全扫一遍无所谓。
    """
    scenes = []
    try:
        name = obj.name
        scenes = [s for s in bpy.data.scenes if name in s.objects]
    except (AttributeError, ReferenceError, TypeError):
        scenes = []

    # 兜底：上下文场景也擦一下（物体可能刚被解除关联、还来不及反映到 objects）
    try:
        ctx_scene = bpy.context.scene
    except AttributeError:
        ctx_scene = None
    if ctx_scene is not None and ctx_scene not in scenes:
        scenes.append(ctx_scene)

    for scene in scenes:
        try:
            invalidate_uv_cache(scene)
        except (AttributeError, ReferenceError, TypeError):
            pass


def check_uv_adjust_validity_detailed(
        scene, group, resolved_obj, resolved_cam, usage_info=None):
    """逐项诊断一个 UV Adjust 组的有效性，返回明细而非单一布尔。

    把原先 is_valid 的"5 个真与运算"拆成逐项检查，目的是让面板能
    显示"到底为什么失效"，而不是笼统一个感叹号。

    Args:
        scene: 目标场景
        group: UV Adjust 节点组
        resolved_obj: 解析到的物体（可能为 None）
        resolved_cam: 解析到的相机（可能为 None）

    Returns:
        dict: {
            "object_exists": bool,
            "object_in_scene": bool,      # 专门识别"在别的场景"
            "camera_exists": bool,
            "camera_is_camera": bool,
            "camera_in_scene": bool,
            "connected_to_material": bool,
            "is_valid": bool,
            "reason": str,                # 最醒目失效原因（人话）
        }
    """
    checks = {}

    checks["object_exists"] = resolved_obj is not None
    checks["object_in_scene"] = (
        resolved_obj is not None and resolved_obj.name in scene.objects
    )
    checks["camera_exists"] = resolved_cam is not None
    checks["camera_is_camera"] = (
        resolved_cam is not None and resolved_cam.type == "CAMERA"
    )
    checks["camera_in_scene"] = (
        resolved_cam is not None and resolved_cam.name in scene.objects
    )
    # ★ 允许调用方把已经算好的 usage_info 传进来复用。
    #
    # 为什么：_uv_row_from_group 里刚刚才调过一次 get_node_group_usage_info()
    # （要拿 materials 列表），这里再调一次就是纯重复劳动。
    # 实测 50 个组时每次读会调 100 次（每行两遍），单这一项就占掉约一半耗时。
    # 打个比方：刚数完抽屉里几样东西，转头又问一遍"抽屉里有几样"——
    # 答案不会变，纯属白跑一趟。
    if usage_info is None:
        usage_info = get_node_group_usage_info(group)
    checks["connected_to_material"] = bool(usage_info)

    # 归属判断：这个组是否"属于别的场景"？
    # 完整复制场景后，材质是共享的，旧场景的投影组会被"共享材质"带进当前场景。
    # 此时物体/相机都存在、材质也连着，但不在当前场景 -> 属于别的场景，
    # 而不是"真失效"。面板应该提示用户"为新物体生成独立投影"，而不是误判。
    object_elsewhere = checks["object_exists"] and not checks["object_in_scene"]
    camera_elsewhere = checks["camera_exists"] and not checks["camera_in_scene"]
    checks["belongs_to_other_scene"] = (
        bool(object_elsewhere or camera_elsewhere)
    )

    checks["is_valid"] = (
        checks["object_exists"] and checks["object_in_scene"]
        and checks["camera_exists"] and checks["camera_is_camera"]
        and checks["camera_in_scene"] and checks["connected_to_material"]
    )

    # 生成最醒目的人话原因（供面板显示）
    if not checks["object_exists"]:
        reason = "找不到物体"
    elif not checks["object_in_scene"]:
        reason = "物体不在当前场景（可能因场景复制/改名）"
    elif not checks["camera_exists"]:
        reason = "找不到相机（可能被删除或因重名改名 .001）"
    elif not checks["camera_is_camera"]:
        reason = "相机类型不正确"
    elif not checks["camera_in_scene"]:
        reason = "相机不在当前场景"
    elif not checks["connected_to_material"]:
        reason = "连接关系失效（材质里投影节点悬空）"
    else:
        reason = "无"
    checks["reason"] = reason

    return checks


# {材质名: (材质节点树的"指纹", [物体, ...])}
# 指纹只取"这个材质被哪些物体用着"这件事本身的变化——用物体名列表拼，
# 便宜且能精确反映增删改。材质改名 / 物体增删 / 换材质都会让它变。
_uv_material_objects_cache = {}


def _uv_material_fingerprint(mat_name):
    """这个材质当前被哪些物体用着（按名字排序）。纯遍历 data 指针，不建复杂结构。"""
    names = []
    for obj in bpy.data.objects:
        try:
            data = getattr(obj, "data", None)
            slots = getattr(data, "materials", None) if data is not None else None
            if not slots:
                continue
            if any(m is not None and m.name == mat_name for m in slots):
                names.append(obj.name)
        except (AttributeError, ReferenceError):
            continue
    names.sort()
    return tuple(names)


def _uv_objects_using_material(mat_name):
    """find_objects_using_material 的带缓存版本。

    缓存的是**物体名字**，命中后按名字回 bpy.data.objects 现取；
    取不到的（刚被删）直接忽略。指纹变了就重算。
    """
    fp = _uv_material_fingerprint(mat_name)
    hit = _uv_material_objects_cache.get(mat_name)
    if hit is not None and hit[0] == fp:
        result = []
        for name in hit[1]:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                result.append(obj)
        return result
    result = find_objects_using_material(mat_name)
    _uv_material_objects_cache[mat_name] = (
        fp, tuple(o.name for o in result if o is not None))
    return result


def _uv_group_is_uv_adjust(group):
    """这个节点组是不是 UV Adjust 组（属性优先，名称兜底）。"""
    try:
        if group.get("compify_node_type") == "uv_adjust":
            return True
        return group.name.startswith(f"{UV_ADJUST_NODE_GROUP_PREFIX} |")
    except (AttributeError, ReferenceError):
        return False


def _uv_row_from_group(scene, group, usage_index=None):
    """由节点组现算出一条结果（每次都重新解析、重新判定）。

    这就是"按标签去仓库现取"那一步：拿到的永远是**当前**活着的对象，
    算出来的永远是**当前**的有效性。绝不读任何快照。

    usage_index: 可选的「节点组名 → 材质/节点」反查表。传了就查表（O(1)），
                 不传就退回原来的全量遍历（保持对旧调用点的兼容）。
    """

    object_data_name = group.get("compify_uv_object_data_name", None)
    camera_data_name = group.get("compify_uv_camera_data_name", None)

    # 元数据缺失时回退到名称解析（兼容老文件）
    if not object_data_name or not camera_data_name:
        parts = group.name.split(" | ")
        if len(parts) == 3:
            _, object_data_name, camera_data_name = parts
        else:
            object_data_name = None
            camera_data_name = None

    if usage_index is None:
        usage_info = get_node_group_usage_info(group)
    else:
        usage_info = usage_index.get(group.name, [])
    materials = [info["material"] for info in usage_info]

    # 先按数据名直查（O(1)，精确匹配），命中就不必全库扫材质。
    # find_objects_using_material 是遍历 bpy.data.objects 的，面板 draw 每帧
    # 都走一次的话会很贵；只有在"名字对不上"（用户改名/换了物体）时才退回全库扫。
    # ⚠️ 全库扫（find_objects_using_material）是遍历 bpy.data.objects 的，
    #    面板 draw 每帧都走一次会很贵。这里做了两级避免：
    #      a) 先按数据名 O(1) 直查，命中就结束；
    #      b) 查不到时，用"材质 → 物体缓存"（按材质名，带失效判据）兜住，
    #         只有材质内容真的变了才重新扫。
    #    没有 b) 的话，"物体被删掉"的组每次读都会全库扫一遍——
    #    实测连续读 10 次就扫 10 次（这正是上一版踩过的那个回归）。
    resolved_obj = None
    if object_data_name:
        resolved_obj = find_object_by_data_name(object_data_name, type_filter="MESH")
    if not resolved_obj:
        for mat_name in materials:
            objs = _uv_objects_using_material(mat_name)
            if objs:
                resolved_obj = objs[0]
                break

    resolved_cam = None
    for mat_name in materials:
        mat = bpy.data.materials.get(mat_name)
        if mat:
            cam_obj = find_camera_connected_to_uv_adjust_in_material(mat, group)
            if cam_obj:
                resolved_cam = cam_obj
                break
    if not resolved_cam and camera_data_name:
        resolved_cam = find_object_by_data_name(camera_data_name, type_filter="CAMERA")

    is_valid = (
        resolved_obj is not None
        and resolved_cam is not None
        and resolved_obj.name in scene.objects
        and resolved_cam.name in scene.objects
        and resolved_cam.type == "CAMERA"
    )

    # 复用上面已经算好的 usage_info，不再重复调用一次（性能，见该函数内部说明）
    status = check_uv_adjust_validity_detailed(
        scene, group, resolved_obj, resolved_cam, usage_info=usage_info)

    row = {
        "node_group": group,
        "object_name": (
            resolved_obj.data.name
            if resolved_obj is not None and getattr(resolved_obj, "data", None)
            else (object_data_name or "")
        ),
        "camera_name": (
            resolved_cam.data.name
            if resolved_cam is not None and getattr(resolved_cam, "data", None)
            else (camera_data_name or "")
        ),
        "object": resolved_obj,
        "camera": resolved_cam,
        "is_valid": is_valid,
        "status": status,
        "belongs_to_other_scene": status.get("belongs_to_other_scene", False),
        "materials": materials,
        # 这两个名字是"回查用的标签"，缓存里只存它们
        "_object_data_name": object_data_name,
        "_camera_data_name": camera_data_name,
    }

    try:
        if resolved_obj:
            new_name = (resolved_obj.data.name
                        if getattr(resolved_obj, "data", None) else resolved_obj.name)
            if group.get("compify_uv_object_data_name") != new_name:
                group["compify_uv_object_data_name"] = new_name
        if resolved_cam:
            new_name = (resolved_cam.data.name
                        if getattr(resolved_cam, "data", None) else resolved_cam.name)
            if group.get("compify_uv_camera_data_name") != new_name:
                group["compify_uv_camera_data_name"] = new_name
    except Exception as e:  # noqa: BLE001
        print(f"Compify: Warning - failed to update UV adjust metadata: {e}")

    return row


def _uv_build_usage_index():
    """"节点组名 → [{material, node}, ...]"，一次遍历材质建好。

    语义与 get_node_group_usage_info(node_group) 逐条对齐：
      - 只认 node.type == "GROUP" 且 node.node_tree 非空的节点
      - 比较 node.node_tree.name == node_group.name（同名节点组算同一个）
      - 出错就跳过该节点/该材质，不中断整体
    唯一区别是**一次建好全部**，而不是每个组各扫一遍。

    返回: dict[str, list[dict]]
    """
    index = {}
    try:
        for material in bpy.data.materials:
            try:
                if not material.node_tree:
                    continue
                for node in material.node_tree.nodes:
                    try:
                        if node.type != "GROUP":
                            continue
                        if not node.node_tree:
                            continue
                        try:
                            group_name = node.node_tree.name
                            material_name = material.name
                            node_name = node.name
                        except (UnicodeDecodeError, UnicodeEncodeError) as e:
                            print(f"Compify: Encoding error in usage index: {e}")
                            continue
                        index.setdefault(group_name, []).append(
                            {"material": material_name, "node": node_name})
                    except Exception as e:  # noqa: BLE001
                        print(f"Compify: Error accessing node: {e}")
                        continue
            except Exception as e:  # noqa: BLE001
                print(f"Compify: Error accessing material "
                      f"'{getattr(material, 'name', 'unknown')}': {e}")
                continue
    except Exception as e:  # noqa: BLE001
        print(f"Compify: Warning in _uv_build_usage_index: {e}")
    return index


def _uv_scene_material_index(scene):
    """一次性算出「本场景用到哪些材质」「别的场景用到哪些材质」。

    为什么要有这个函数：
      "这个组属于哪个场景" 必须**每次现算**，不能存进缓存 —— 它是派生物，
      会被"把物体挪到别的场景""复制场景"这类操作随时改掉。存下来 =
      把派生结果冻成快照，用户挪完物体后面板就再也对不上了。

    为什么不能每个组都自己遍历一遍场景：
      那是 O(组数 × 全部物体)，面板每帧都跑一次会明显变卡。
      所以一次遍历把所有场景的"材质 → 谁在用"都记下来，供所有组共用。

    Returns:
        (own, others):
            own    = 本场景里被任意网格用着的材质名集合
            others = 除了本场景之外，别的场景里用着的材质名集合
    """
    own = set()
    others = set()
    try:
        scenes = list(bpy.data.scenes)
    except (AttributeError, ReferenceError):
        scenes = [scene]

    for candidate in scenes:
        target = own if candidate == scene else others
        try:
            objects = list(candidate.objects)
        except (AttributeError, ReferenceError):
            continue
        for obj in objects:
            try:
                if obj.type != "MESH" or not obj.data:
                    continue
                slots = obj.data.materials
                if not slots:
                    continue
                target.update(m.name for m in slots if m)
            except (AttributeError, ReferenceError):
                continue
    return own, others


def _uv_row_in_scene(scene, materials, index=None):
    """这个组的材质，跟当前场景有没有关系？

    判定分三种（顺序重要）：
      1) 本场景有物体用这些材质          -> 属于本场景
      2) 别的场景有物体用这些材质        -> 属于别的场景（不算）
      3) 哪个场景都没有物体用，
         但材质还挂在某个组节点上        -> **仍算本场景**

    第 3 种是老代码漏掉的，后果很实在：用户删掉物体之后，
    这个 UV Adjust 组在文件里、材质里、甚至还在生效，但面板上
    凭空消失，「刷新&清理」也管不到，「孤立组」也不认——变成幽灵。
    现在让它留下来，面板显示红字（原因："找不到物体"），用户能看能删。

    ⚠️ 这个结论**绝不进缓存、绝不存档**（见 _uv_scene_material_index 的说明）。
    每次读面板都重新算，代价只有一次全场景材质遍历。
    """
    if not materials:
        # 没有任何材质引用它 —— 归"本场景"，让面板能看见、能清理
        return True

    if index is None:
        own, others = _uv_scene_material_index(scene)
    else:
        own, others = index

    names = set(materials)
    if names & own:
        return True
    if names & others:
        return False
    # 哪个场景都没人用，但组还挂在材质节点上 —— 留在本场景（幽灵组可见化）
    return True


def get_all_uv_adjust_node_groups(scene=None):
    """列出当前场景的 UV Adjust 组。

    Args:
        scene: Optional scene to filter by. If None, uses bpy.context.scene.

    Returns:
        list: List of dicts with node_group, object, camera, materials info.
              node_group 一定是活的；object / camera 找不到时为 None，
              此时 is_valid=False，status["reason"] 会说明原因。
    """
    if scene is None:
        scene = bpy.context.scene

    # 缓存里存的是什么、不存什么（这一点是这次修复的核心）：
    #   存 —— 文件里有哪些 UV Adjust 组（名字 + 物体名 + 相机名 + 材质名）。
    #          这属于"文件里有什么"，一个 .blend 里不可能凭空多出来，
    #          所以它的快照是安全的，可以跟着文件走。
    #   不存 —— 这个组属于哪个场景、还有没有效。
    #          那是派生物，随时会被"挪物体 / 删相机 / 改材质"改掉，
    #          存下来就是把派生结果冻成快照（上一版就是栽在这里）。
    #
    # 打比方：柜子里可以长期放着"这间屋里有几把钥匙"的清单；
    # 但"这把钥匙现在能开哪扇门"必须每次去门口试，不能写在纸上。
    rows = _uv_cache_read(scene)

    # ---- 数量哨兵：文件里的 UV 组数量跟缓存对不上就重扫 ----
    # 上面那两个写函数已经自己失效缓存了，但总有绕过去的路径：
    # 用户在着色器编辑器里手动 new 一个 GROUP 节点、别的插件往材质里塞东西、
    # 或者脚本直接调底层的 create_uv_adjust_node_group。
    # 逐个 hook 不现实，所以放一只最便宜的哨兵：数一数文件里到底有几个 UV 组。
    # 数量变了 ⇒ 缓存必然不全 ⇒ 重扫。数量没变 ⇒ 大概率没事，继续用缓存。
    # 打比方：出门前先数一眼门口有几个人，人数对得上就不必挨个点名。
    if rows is not None:
        try:
            live_names = set()
            for group in bpy.data.node_groups:
                if _uv_group_is_uv_adjust(group):
                    live_names.add(group.name)
            cached_names = {item["ng"] for item in rows}
            if live_names != cached_names:
                rows = None
        except (AttributeError, ReferenceError, KeyError, TypeError):
            rows = None

    if rows is None:
        rows = []
        for group in bpy.data.node_groups:
            if not _uv_group_is_uv_adjust(group):
                continue
            try:
                mats = [info["material"] for info in get_node_group_usage_info(group)]
            except (AttributeError, ReferenceError):
                continue
            rows.append({
                "ng": group.name,
                "obj": group.get("compify_uv_object_data_name"),
                "cam": group.get("compify_uv_camera_data_name"),
                "mats": mats,
                # ⚠️ 这里**不再**做"这组属于哪个场景"的过滤。
                #    过滤挪到下面按场景现算 —— 否则挪物体之后面板永远对不上。
            })
        _uv_cache_store(scene, rows)

    # 无论缓存命不命中，**每条都现查现判**：
    #   ① 组还活着吗（死了就跳过）
    #   ② 它属于当前场景吗（每次现算，不读快照）
    #   ③ 有效性/失效原因（每次现算，不读快照）
    index = _uv_scene_material_index(scene)

    # ---- 「节点组名 → 用到它的材质/节点」反查表，整次读只建一遍 ----
    #
    # 为什么：get_node_group_usage_info(group) 每次都要遍历 bpy.data.materials
    # 下的全部材质、再遍历每个材质的全部节点。50 个组 × 50 个材质 = 2500 次
    # 节点遍历，实测这一项就占了整个面板读取的 68%（6.03ms / 8.83ms）。
    #
    # 改成：先把所有材质扫一遍、按"节点组名"归好类（50 次材质遍历），
    # 之后每一行 O(1) 查表。50×50 → 50+50。
    #
    # 打个比方：原来每来一个访客，都要把整栋楼的门牌号挨个报一遍；
    # 现在先把门牌号抄成一张表，谁来直接翻表。
    #
    # ⚠️ 语义必须与 get_node_group_usage_info 完全一致（同样的过滤条件、
    #    同样的返回结构、同样的出错就跳过），否则就会变成"另一个真相"。
    usage_index = _uv_build_usage_index()

    # ---- 按名字回查，名字对不上就按「物体数据名 + 相机数据名」兜底 ----
    #
    # 为什么需要兜底：缓存里的键是节点组的**名字**。用户在 Outliner 里手动
    # 改一次组名、或者复制材质时 GROUP 节点被自动加上 ".001"，名字就不一致了。
    # 只按名字查的例子是：整行从面板上凭空消失，可那个组还在、还连着材质、
    # 还在生效 —— 正是这版要消灭的"幽灵组"换了个入口又回来。
    #
    # 打个比方：柜子里记的是"张三"，人改名叫"张三丰"了，不能就当他没来过；
    # 我们还记了他的工号和部门（物体数据名 + 相机数据名），按这个也能认出来。
    by_data = {}
    try:
        for group in bpy.data.node_groups:
            if not _uv_group_is_uv_adjust(group):
                continue
            key = (group.get("compify_uv_object_data_name"),
                   group.get("compify_uv_camera_data_name"))
            if key[0] and key[1]:
                # ⚠️ 用 list 而不是 setdefault：
                #    两个组元数据完全相同时（复制材质 / node_groups.copy()），
                #    setdefault 只留第一个，另一个就再也认领不回来了 —— 静默丢组。
                #    存成列表，认领时按指针去重即可。
                by_data.setdefault(key, []).append(group)
    except (AttributeError, ReferenceError):
        by_data = {}

    result = []
    seen = set()
    cache_untrusted = False

    def _claim(item):
        """这一行缓存现在对应哪个活着的节点组？找不到返回 None。"""
        group = bpy.data.node_groups.get(item["ng"])
        if group is not None:
            return group
        # 名字对不上：按数据名兜底认领（用户改名 / 复制材质被自动加 .001）
        candidates = by_data.get((item.get("obj"), item.get("cam"))) or []
        for cand in candidates:
            try:
                if cand.as_pointer() not in seen:
                    return cand
            except (AttributeError, ReferenceError):
                continue
        return None

    for item in rows:
        group = _claim(item)

        if group is None:
            # ⚠️ 走到这里只说明"缓存里那行的名字对不上了"，
            #    **不等于**这个组已经消失。以前直接 continue 丢行，
            #    后果是：用户先给 mesh data 改名（元数据被更新成新名）、
            #    再给节点组改名 ⇒ 名字和数据名两条路都断了 ⇒ 该组永久
            #    从面板消失，可它还在、还连着材质、还在渲染里生效。
            #    （独立复审 B10 实测：master 正常，本分支 []，属回归）
            #
            #    打比方：点名册上写"张三"，人改名叫"张三丰"、工号也换了，
            #    点名册对不上不代表这个人没来上班。宁可下次重扫一遍，
            #    也不能让活人从名单上消失。
            #
            #    ⇒ 记一笔"缓存不可信"，本轮先跳过这一行，读完把缓存标脏，
            #      下一次读必然重扫，组就回来了。绝不在这里 break ——
            #      后面那些名字正常的行还要照常显示。
            cache_untrusted = True
            continue

        # 兜底认领成功 ⇒ 缓存里的名字已经过期，不能继续用它当键
        if group.name != item["ng"]:
            # 下次读之前必须重扫（否则名字会一直对不上）
            _uv_cache_store(scene, None)

        try:
            ptr = group.as_pointer()
        except (AttributeError, ReferenceError):
            ptr = None
        if ptr is not None:
            if ptr in seen:
                continue        # 同一个组被两条缓存记录指向，只出一条
            seen.add(ptr)

        # 缓存里记的材质名可能已经过期（用户改了材质的连接），现取一次更准。
        # 但 get_node_group_usage_info 要遍历材质节点树，比较贵；
        # 只有缓存里根本没有材质名时才现算。
        mats = item.get("mats") or []
        if not mats:
            try:
                mats = [info["material"] for info in get_node_group_usage_info(group)]
            except (AttributeError, ReferenceError):
                mats = []

        if not _uv_row_in_scene(scene, mats, index):
            continue

        result.append(_uv_row_from_group(scene, group, usage_index=usage_index))

    if cache_untrusted:
        # 有缓存行认领不到活组（多半是改名后名字/数据名两条路都断了）。
        # 本轮结果可能不全，把缓存标脏，保证下一次读一定重扫。
        _uv_cache_store(scene, None)

    return result


def clean_invalid_uv_adjust_node_groups(scene=None, confirm=True):
    """
    Remove UV Adjust node groups that reference non-existent objects or cameras.

    安全版清理：
    - 删除前先弹一次确认（列出全部将删的组），防误删。
    - 删除前先摘除材质里指向该组的 GROUP 节点，避免悬空死节点。
    - confirm 由调用方传入；负责 UI 的 operator 应传 True，纯脚本可传 False 跳过确认。

    Args:
        scene: Optional scene to operate on. If None, uses current scene.
        confirm: If True (default), prompt the user for confirmation.

    Returns:
        int: Number of node groups cleaned up
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene
    invalidate_uv_cache(scene)

    cleaned_count = 0
    groups_to_remove = []

    for group_info in get_all_uv_adjust_node_groups(scene):
        if not group_info["is_valid"]:
            groups_to_remove.append(group_info["node_group"])

    if not groups_to_remove:
        return 0

    # 确认对话框：只弹一次，列出全部将删的组
    if confirm:
        names = [g.name for g in groups_to_remove]
        if not _confirm_clean_uv(names):
            return 0  # 用户取消，不删

    # 安全删除：先摘材质节点，再删 datablock
    for group in groups_to_remove:
        _detach_group_from_all_materials(group)
        bpy.data.node_groups.remove(group)
        cleaned_count += 1

    # Re-invalidate after deletion: the earlier get_all_uv_adjust_node_groups()
    # rebuilt the cache, but we just removed groups from Blender, so cached
    # references are now stale.
    invalidate_uv_cache(scene)
    return cleaned_count


def _detach_group_from_all_materials(group):
    """在删除 node group datablock 前，先摘除所有材质里指向它的 GROUP 节点。

    这是防"悬空死节点"的关键：
    - 若不先摘除，node_groups.remove() 会把材质里引用它的 GROUP 节点的
      node_tree 指针清成 None，形成没内容的死节点。
    - 用指针身份比较 (n.node_tree is group) 而不是字符串名比较，避免误伤
      重名的其他组，也避免误伤 node_tree 已为 None 的既有死节点。

    Args:
        group: 即将被删除的 bpy.types.NodeGroup

    Returns:
        int: 从材质中摘除的 GROUP 节点数
    """
    detached = 0
    for material in bpy.data.materials:
        if not material.node_tree:
            continue
        targeted = [
            n for n in material.node_tree.nodes
            if n.type == "GROUP" and getattr(n, "node_tree", None) is group
        ]
        for node in targeted:
            # 先删掉连接该节点的所有 link，避免留下悬空连接
            for link in list(material.node_tree.links):
                if link.from_node is node or link.to_node is node:
                    material.node_tree.links.remove(link)
            material.node_tree.nodes.remove(node)
            detached += 1
    return detached


def _confirm_clean_uv(names):
    """弹一次确认框，询问是否删除这些无效节点组。

    提醒：底层函数无法真正弹 UI（后台进程 invoke_confirm 不生效），
    这个确认框的"真正弹出"交给 operator 层（CompifyRefreshUVAdjustList）
    在 execute 里先 report + 用 window_manager 弹窗，用户确认后再以
    confirm=False 调用本函数。这里保留一个可测试的返回值给纯脚本调用。
    """
    return True  # 默认放行；UI 层真正弹窗拦截


def get_orphan_uv_adjust_node_groups(scene=None):
    """
    Get UV Adjust node groups that are not used by any material.

    Args:
        scene: Optional scene to operate on. If None, uses current scene.

    Returns:
        list: List of node group objects that are orphans (not used in any material)
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene

    orphan_groups = []

    for group_info in get_all_uv_adjust_node_groups(scene):
        if not group_info["materials"]:  # No materials using this node group
            orphan_groups.append(group_info["node_group"])

    return orphan_groups


def clean_orphan_uv_adjust_node_groups(scene=None):
    """
    Remove UV Adjust node groups that are not used by any material.

    Args:
        scene: Optional scene to operate on. If None, uses current scene.

    Returns:
        int: Number of orphan node groups cleaned up
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene
    invalidate_uv_cache(scene)

    cleaned_count = 0
    orphan_groups = get_orphan_uv_adjust_node_groups(scene)

    for group in orphan_groups:
        try:
            bpy.data.node_groups.remove(group)
            cleaned_count += 1
        except Exception as e:
            print(f"Compify: Warning - failed to remove orphan node group: {e}")

    # Re-invalidate after deletion (same reason as clean_invalid above)
    invalidate_uv_cache(scene)
    return cleaned_count


def update_uv_adjust_node_group_parameters(node_group, obj, camera, scene):
    """
    Update the parameters of an existing UV Adjust node group without recreating it.

    Args:
        node_group: The UV Adjust node group to update
        obj: Blender object
        camera: Blender camera object
        scene: Blender scene object

    Returns:
        bool: True if update was successful, False otherwise
    """
    try:
        # Recalculate the UV adjustment parameters
        offset, scale = get_object_camera_bounds(scene, camera, obj)

        # Find the subtract and divide nodes
        subtract_node = None
        divide_node = None

        for node in node_group.nodes:
            if node.type == "VECT_MATH" and node.operation == "SUBTRACT":
                subtract_node = node
            elif node.type == "VECT_MATH" and node.operation == "DIVIDE":
                divide_node = node

        if subtract_node is None or divide_node is None:
            return False

        # Update the offset values
        subtract_node.inputs[1].default_value = (offset[0], offset[1], 0.0)

        # Update the scale values with safety check
        safe_scale_x = max(scale[0], 0.001)
        safe_scale_y = max(scale[1], 0.001)
        divide_node.inputs[1].default_value = (safe_scale_x, safe_scale_y, 1.0)

        return True

    except Exception as e:
        print(f"Compify: Warning in update_uv_adjust_node_group_parameters: {e}")
        return False


def clean_material_nodes_for_uv_adjust(obj, camera, uv_adjust_node_group):
    """
    Clean UV Adjust and Camera Project nodes from the object's material.

    Args:
        obj: Blender object
        camera: Blender camera object
        uv_adjust_node_group: The UV Adjust node group being deleted

    Returns:
        bool: True if cleanup was successful, False otherwise
    """
    try:
        # Check if object has materials
        if not obj or not obj.data.materials:
            return True

        # Get the first material
        material = obj.data.materials[0]
        if not material or not material.use_nodes:
            return True

        node_tree = material.node_tree
        if not node_tree:
            return True

        # Get camera project node group name
        camera_project_group_name = camera_project_node_group_name(camera)

        # Find and remove UV Adjust node from material
        uv_adjust_nodes_to_remove = []
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == uv_adjust_node_group.name
            ):
                uv_adjust_nodes_to_remove.append(node)

        # Find and remove Camera Project node from material
        camera_project_nodes_to_remove = []
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == camera_project_group_name
            ):
                camera_project_nodes_to_remove.append(node)

        # Remove the nodes
        for node in uv_adjust_nodes_to_remove:
            node_tree.nodes.remove(node)

        for node in camera_project_nodes_to_remove:
            node_tree.nodes.remove(node)

        return True

    except Exception as e:
        print(f"Compify: Warning in clean_material_nodes_for_uv_adjust: {e}")
        return False


def delete_uv_adjust_node_group(node_group):
    """
    Delete a UV Adjust node group and clean up related nodes in materials.

    Args:
        node_group: The node group to delete

    Returns:
        bool: True if deletion was successful, False otherwise
    """
    try:
        if not node_group or node_group.name not in bpy.data.node_groups:
            return False

        # Prefer metadata properties over name parsing
        object_data_name = node_group.get("compify_uv_object_data_name")
        camera_data_name = node_group.get("compify_uv_camera_data_name")

        # Fallback: parse the node group name
        if not object_data_name or not camera_data_name:
            parts = node_group.name.split(" | ")
            if len(parts) == 3:
                _, object_data_name, camera_data_name = parts

        # Resolve objects from data-block names
        obj = (
            find_object_by_data_name(object_data_name, type_filter="MESH")
            if object_data_name
            else None
        )
        camera_obj = (
            find_object_by_data_name(camera_data_name, type_filter="CAMERA")
            if camera_data_name
            else None
        )

        # Clean up material nodes if objects exist
        if obj and camera_obj:
            clean_material_nodes_for_uv_adjust(obj, camera_obj, node_group)

        # Delete the UV Adjust node group data block
        bpy.data.node_groups.remove(node_group)
        return True

    except Exception as e:
        print(f"Compify: Warning in delete_uv_adjust_node_group: {e}")
        return False


def handle_object_rename_in_node_groups(scene=None):
    """
    Handle object/camera renames by updating node group names to match current object names.
    This function attempts to match node groups with existing objects even if names have changed.

    Args:
        scene: Optional scene to filter by. If None, uses bpy.context.scene.

    Returns:
        dict: Summary of rename operations performed
            {
                'updated': int,  # Number of node groups updated
                'orphaned': int,  # Number of orphaned node groups found
                'details': list  # List of update details
            }
    """
    # Get the target scene
    if scene is None:
        scene = bpy.context.scene
    invalidate_uv_cache(scene)

    result = {"updated": 0, "orphaned": 0, "details": []}

    try:
        # Get all UV Adjust node groups
        all_groups = get_all_uv_adjust_node_groups(scene)

        for group_info in all_groups:
            node_group = group_info["node_group"]
            old_name = node_group.name

            # If the group is valid, check if we need to update the name
            if group_info["is_valid"]:
                obj = group_info["object"]
                camera = group_info["camera"]

                # Generate what the name should be based on current object names
                expected_name = uv_adjust_node_group_name(obj, camera)

                # If the name doesn't match, update it
                if old_name != expected_name:
                    # Check if the expected name already exists
                    if expected_name not in bpy.data.node_groups:
                        node_group.name = expected_name
                        result["updated"] += 1
                        result["details"].append(
                            f"Renamed '{old_name}' to '{expected_name}'"
                        )
                    else:
                        # Name conflict - keep the old name but note the issue
                        result["details"].append(
                            f"Name conflict: '{old_name}' should be '{expected_name}' but name exists"
                        )
            else:
                result["orphaned"] += 1
                result["details"].append(f"Orphaned node group: '{old_name}'")

        return result

    except Exception as e:
        result["details"].append(f"Error during rename handling: {str(e)}")
        return result


def get_node_group_usage_info(node_group):
    """
    Get information about where a node group is being used in materials.

    Args:
        node_group: The node group to check

    Returns:
        list: List of materials using this node group
    """
    usage_info = []

    try:
        # 遍历所有材质，每个材质单独保护
        for material in bpy.data.materials:
            try:
                # 安全访问材质节点树
                if not material.node_tree:
                    continue

                # 遍历节点，每个节点单独保护
                for node in material.node_tree.nodes:
                    try:
                        # 检查节点类型和节点树
                        if node.type != "GROUP":
                            continue

                        if not node.node_tree:
                            continue

                        # 安全比较节点树名称
                        try:
                            node_tree_name = node.node_tree.name
                            target_name = node_group.name

                            if node_tree_name == target_name:
                                # 安全获取名称
                                material_name = material.name
                                node_name = node.name

                                usage_info.append(
                                    {"material": material_name, "node": node_name}
                                )
                        except (UnicodeDecodeError, UnicodeEncodeError) as e:
                            # 编码错误 - 跳过这个节点，继续处理其他节点
                            print(
                                f"Compify: Encoding error in node tree name comparison: {e}"
                            )
                            continue

                    except Exception as e:
                        # 单个节点访问失败 - 跳过这个节点
                        print(f"Compify: Error accessing node: {e}")
                        continue

            except Exception as e:
                # 单个材质访问失败 - 跳过这个材质，继续处理其他材质
                print(
                    f"Compify: Error accessing material '{getattr(material, 'name', 'unknown')}': {e}"
                )
                continue

        return usage_info

    except Exception as e:
        # 整体错误（不太可能到这里，但作为最后防线）
        print(f"Compify: Warning in get_node_group_usage_info: {e}")
        return usage_info  # 返回已收集的数据，而不是空列表


def add_uv_adjust_to_material(obj, camera, uv_adjust_node_group):
    """
    Add UV Adjust node group to the first material of an object and connect it with Camera Project node group.

    Args:
        obj: Blender object
        camera: Blender camera object
        uv_adjust_node_group: The UV Adjust node group to add

    Returns:
        dict: Result information
            {
                'success': bool,
                'message': str,
                'material': Material or None,
                'camera_project_node': Node or None,
                'uv_adjust_node': Node or None
            }
    """
    result = {
        "success": False,
        "message": "",
        "material": None,
        "camera_project_node": None,
        "uv_adjust_node": None,
    }

    try:
        # Check if object has materials
        if not obj.data.materials:
            # Create a new material if none exists
            material = bpy.data.materials.new(name=f"{obj.name}_Material")
            obj.data.materials.append(material)
            # Enable use_nodes
            material.use_nodes = True
        else:
            # Use the first material
            material = obj.data.materials[0]
            if not material:
                result["message"] = "First material slot is empty"
                return result

            # Enable use_nodes if not already enabled
            if not material.use_nodes:
                material.use_nodes = True

        result["material"] = material
        node_tree = material.node_tree

        # Get camera project node group name
        camera_project_group_name = camera_project_node_group_name(camera)

        # Check if camera project node group exists
        if camera_project_group_name not in bpy.data.node_groups:
            result["message"] = (
                f"Camera project node group '{camera_project_group_name}' not found"
            )
            return result

        camera_project_group = bpy.data.node_groups[camera_project_group_name]

        # Check if camera project node already exists in the material
        camera_project_node = None
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == camera_project_group_name
            ):
                camera_project_node = node
                break

        # Add camera project node if it doesn't exist
        if not camera_project_node:
            camera_project_node = node_tree.nodes.new(type="ShaderNodeGroup")
            camera_project_node.node_tree = camera_project_group
            camera_project_node.name = camera_project_node_group_name(camera)
            # Short label: show camera data-block name
            camera_project_node.label = (
                camera.data.name if getattr(camera, "data", None) else camera.name
            )
            camera_project_node.location = (-400, 0)

        # Ensure short label even if node pre-existed
        camera_project_node.label = (
            camera.data.name if getattr(camera, "data", None) else camera.name
        )

        result["camera_project_node"] = camera_project_node

        # Check if UV adjust node already exists in the material
        uv_adjust_node = None
        for node in node_tree.nodes:
            if (
                node.type == "GROUP"
                and node.node_tree
                and node.node_tree.name == uv_adjust_node_group.name
            ):
                uv_adjust_node = node
                break

        # Add UV adjust node if it doesn't exist
        if not uv_adjust_node:
            uv_adjust_node = node_tree.nodes.new(type="ShaderNodeGroup")
            uv_adjust_node.node_tree = uv_adjust_node_group
            uv_adjust_node.name = uv_adjust_node_group_name(obj, camera)
            # Short label: show object data-block name
            uv_adjust_node.label = (
                obj.data.name if getattr(obj, "data", None) else obj.name
            )
            uv_adjust_node.location = (-200, 0)

        # Ensure short label even if node pre-existed
        uv_adjust_node.label = obj.data.name if getattr(obj, "data", None) else obj.name

        result["uv_adjust_node"] = uv_adjust_node

        # Connect camera project output to UV adjust input
        # Find the Vector output from camera project node
        camera_project_output = None
        for output in camera_project_node.outputs:
            if output.type == "VECTOR":
                camera_project_output = output
                break

        # Find the Camera Projection UV input in UV adjust node
        uv_adjust_input = None
        for input_socket in uv_adjust_node.inputs:
            if input_socket.name == UV_ADJUST_INPUT_SOCKET_NAME:
                uv_adjust_input = input_socket
                break

        # Create the connection if both sockets are found
        if camera_project_output and uv_adjust_input:
            # Remove existing connection to UV adjust input if any
            for link in node_tree.links:
                if link.to_socket == uv_adjust_input:
                    node_tree.links.remove(link)

            # Create new connection
            node_tree.links.new(camera_project_output, uv_adjust_input)

        # Connect UV adjust output to the first image texture node's Vector input
        # Find the Adjusted UV output from UV adjust node
        uv_adjust_output = None
        for output in uv_adjust_node.outputs:
            if output.name == UV_ADJUST_OUTPUT_SOCKET_NAME:
                uv_adjust_output = output
                break

        # Find the first image texture node in the material
        first_image_node = None
        for node in node_tree.nodes:
            if node.type == "TEX_IMAGE":
                first_image_node = node
                break

        # Connect UV adjust output to image node's Vector input if both are found
        if uv_adjust_output and first_image_node:
            # Find the Vector input in the image node
            vector_input = None
            for input_socket in first_image_node.inputs:
                if input_socket.type == "VECTOR" and input_socket.name == "Vector":
                    vector_input = input_socket
                    break

            if vector_input:
                # Remove existing connection to image node's Vector input if any
                for link in node_tree.links:
                    if link.to_socket == vector_input:
                        node_tree.links.remove(link)

                # Create new connection from UV adjust to image node
                node_tree.links.new(uv_adjust_output, vector_input)

        # Set success status and message
        if camera_project_output and uv_adjust_input:
            if uv_adjust_output and first_image_node:
                result["success"] = True
                result["message"] = (
                    f"Successfully added and connected node groups in material '{material.name}', including connection to image texture node"
                )
            else:
                result["success"] = True
                result["message"] = (
                    f"Successfully added and connected node groups in material '{material.name}', but no image texture node found for UV connection"
                )
        else:
            result["success"] = True  # Nodes were added even if connection failed
            result["message"] = (
                f"Added node groups to material '{material.name}' but connection failed"
            )

    except Exception as e:
        result["message"] = f"Error adding to material: {str(e)}"

    finally:
        # ★ 写操作自己失效缓存（见 create_and_add_uv_adjust_node_group 里的说明）。
        # 这里改了「材质 → 谁在用」这层关系，正是 UV 面板列表的依据。
        _invalidate_scenes_for_object(obj)

    return result


def create_and_add_uv_adjust_node_group(scene, camera, obj):
    """
    Create UV adjustment node group and automatically add it to the object's first material.

    Args:
        scene: Blender scene object
        camera: Blender camera object
        obj: Blender object to create UV adjustment for

    Returns:
        dict: Result information
            {
                'success': bool,
                'message': str,
                'node_group': NodeGroup or None,
                'material_result': dict or None
            }
    """
    result = {
        "success": False,
        "message": "",
        "node_group": None,
        "material_result": None,
    }

    try:
        # Create the UV adjustment node group
        node_group = create_uv_adjust_node_group(scene, camera, obj)
        result["node_group"] = node_group

        # Add to material and connect
        material_result = add_uv_adjust_to_material(obj, camera, node_group)
        result["material_result"] = material_result

        if material_result["success"]:
            result["success"] = True
            result["message"] = (
                f"Created UV adjust node group and {material_result['message']}"
            )
        else:
            result["success"] = True  # Node group was created successfully
            result["message"] = (
                f"Created UV adjust node group but material integration failed: {material_result['message']}"
            )

    except Exception as e:
        result["message"] = f"Failed to create UV adjust node group: {str(e)}"

    finally:
        # ★ 失效由"写操作"自己负责，不再指望每个调用方记得。
        #
        # 打个比方：这是"我刚刚动过这个抽屉"的自述，不是"请你记得提醒我动过"。
        # 以前失效调用散在 __init__.py 的各个 operator 里，批量生成还只写在
        # "全部成功"的分支上——一旦中途失败、或者将来有新的调用路径漏了这一步，
        # 面板就会"刚生成却不显示"，用户只能靠点「刷新&清理」救回来。
        #
        # 放在 finally：连失败/部分成功也要失效。宁可多扫一次，也不能留脏缓存。
        # 注意 scene 可能已被删除（极少数），所以整段 try 住。
        try:
            invalidate_uv_cache(scene)
        except (AttributeError, ReferenceError, TypeError):
            pass

    return result
