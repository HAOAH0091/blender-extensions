"""cache_untrusted 回归：改名后组的名字与数据名两条路都断了，也不能丢行。

为什么必须单独有这条：
  B10 场景（先给 mesh data 改名 -> 元数据被刷新成新名 -> 再给节点组改名）
  会让"按名字查"和"按数据名兜底"两条路同时断掉。
  曾经的代码在这里直接 continue 丢行 —— 组还在、还连着材质、还在渲染里生效，
  面板却永久显示 0 条（独立复审实测：master 正常，本分支 []）。

  ⚠️ 这道防线是**双保险**，但两道保的不是同一件事：
    - "名字集合哨兵"  保证 **本次读** 就正确（发现名字集合变了，立刻全量重扫）
    - "cache_untrusted" 保证 **下次读** 正确（本轮救不了，但会把缓存标脏，
                        下一次读必然重扫）
  ⇒ cache_untrusted **天然救不了"第一次读"**，这是设计使然，不是缺陷。

  注入验证（实测，三道对照）：
    正常版                         PASS 9 / FAIL 0
    只回退哨兵（留 untrusted）     PASS 8 / FAIL 1  ← 3a 红（首读为空）
    只回退 untrusted（留哨兵）     PASS 9 / FAIL 0  ← 哨兵独力守住首读
    两道同时回退                   PASS 6 / FAIL 3  ← 3a/3b/3c 全红

  ⇒ 3a 是**哨兵**的专属判据；3b/3c 是 **cache_untrusted** 的专属判据。
    所以本文件同时守着两道保险，删任一道都有断言会红。

  （记一笔踩坑：第一次做"只回退哨兵"注入时，注入脚本参数顺序写反导致
    注入根本没生效，跑出来是 9/0，差点误判成"cache_untrusted 也能守住首读"。
    注入没被抓住时，先怀疑注入没生效 —— 再次应验。）

用法：<blender> --background --factory-startup --python _dev/test_uv_cache_untrusted.py
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_untrusted"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

PASS = []
FAIL = []


def chk(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()


def group_names(rows):
    return [r["node_group"].name for r in rows]


def build(sc):
    """建一个接好材质的最小投影组，返回 (obj, cam, uv_group, mat)。"""
    obj = bpy.data.objects.new("O", bpy.data.meshes.new("m"))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("C", bpy.data.cameras.new("cd"))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M")
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME),
                 tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return obj, cam, uv, mat


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene

# ---- 1. 基准 ----
obj, cam, uv, mat = build(sc)
ngm.invalidate_uv_cache(sc)
rows = ngm.get_all_uv_adjust_node_groups(sc)
chk("1a 基准：1 条", len(rows) == 1, f"N={len(rows)}")
chk("1b 基准：有效", bool(rows) and rows[0]["is_valid"], rows and rows[0]["is_valid"])

# ---- 2. 制造 B10：先改 mesh data 名，让元数据被刷新成新名 ----
obj.data.name = "m_renamed"
rows = ngm.get_all_uv_adjust_node_groups(sc)
chk("2a 改数据名后仍能看到（元数据此时会被刷新）",
    len(rows) == 1, group_names(rows))
meta_obj = uv.get("compify_uv_object_data_name")
chk("2b 元数据确实已被刷新成新数据名（这是 B10 的成因）",
    meta_obj == "m_renamed", f"meta={meta_obj!r}")

# ---- 3. 再改组名：名字与数据名两条路同时断掉 ----
uv.name = "UV Adjust | totally-new | cd"
rows = ngm.get_all_uv_adjust_node_groups(sc)
chk("3a 改组名后第一次读必须仍能看到该组（不能是 []）",
    group_names(rows) == [uv.name], group_names(rows))

rows2 = ngm.get_all_uv_adjust_node_groups(sc)
chk("3b 第二次读仍能看到（缓存必须已被标脏并重扫）",
    group_names(rows2) == [uv.name], group_names(rows2))

rows3 = ngm.get_all_uv_adjust_node_groups(sc)
chk("3c 第三次读仍稳定",
    group_names(rows3) == [uv.name], group_names(rows3))

# ---- 4. 该组必须仍然真的活着、连着材质（不是被误判造出来的幽灵）----
chk("4a 组确实还在文件里", uv.name in bpy.data.node_groups, uv.name)
chk("4b 组仍接在材质上",
    any(getattr(n, "node_tree", None) == uv for n in mat.node_tree.nodes))

print()
print("=" * 50)
print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
if FAIL:
    print("FAILED:", FAIL)
