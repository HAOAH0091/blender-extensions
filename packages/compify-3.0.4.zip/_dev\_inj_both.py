
import io, sys
p = sys.argv[-1]
with io.open(p, "r", encoding="utf-8") as f:
    src = f.read().replace("\r\n", "\n")

# 注入 1：哨兵永不重扫
a = '''            live_names = set()
            for group in bpy.data.node_groups:
                if _uv_group_is_uv_adjust(group):
                    live_names.add(group.name)
            cached_names = {item["ng"] for item in rows}
            if live_names != cached_names:
                rows = None'''
b = '''            pass'''
assert a in src, "anchor1 missing"
src = src.replace(a, b, 1)

# 注入 2：认领不到直接丢行（保留变量定义，避免 NameError）
c = '''            cache_untrusted = True
            continue'''
d = '''            continue'''
assert c in src, "anchor2 missing"
src = src.replace(c, d, 1)

with io.open(p, "w", encoding="utf-8", newline="\n") as f:
    f.write(src)
print("DOUBLE_INJECTED_OK")
