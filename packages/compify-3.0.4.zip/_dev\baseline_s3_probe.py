"""严格区分 S3 的两种顺序 + 空结果入缓存的正确判法（v3.0.3）。

CodeAuditor 的质疑：
  S3 我报的"0 条"只是"刷新后"那一种；"先缓存后删物体"会显示 1 条红字。
  而且我的"空结果命中缓存 0 次扫描"是在旧缓存上测的，没走到"空结果写缓存"。

这里把两种顺序都测，并且**证明空结果确实是新写进去的**：
  - 删物体后先清缓存 -> 读一次（必然是重扫，N 应 0 或多）
  - 检查缓存字典里这个键的值
  - 再清一次「假想的外部改动」并连读，看到底命不命中
"""
import bpy
import sys
import os
import importlib.util
import json

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_s3x"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = {}


def emit(k, v):
    OUT[k] = v
    print("X " + k + " = " + repr(v))


def fresh():
    for k in [k for k in list(sys.modules) if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    m = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = m
    spec.loader.exec_module(m)
    return m


def setup(m, tag):
    ng = sys.modules[PKG + ".node_groups"]
    nm = sys.modules[PKG + ".names"]
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return sc, obj, cam, uv, mat


def panel(ngm, sc):
    try:
        g = ngm.get_all_uv_adjust_node_groups(sc)
        return {"n": len(g), "valid": [x["is_valid"] for x in g],
                "reason": [x["status"].get("reason") for x in g]}
    except Exception as e:  # noqa: BLE001
        return {"err": f"{type(e).__name__}: {e}"}


# ================= S3-1：先建缓存，再删物体，然后读 =================
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "P")
emit("P_before", panel(ngm, sc))
bpy.data.objects.remove(obj)
emit("P_after_del_no_invalidate", panel(ngm, sc))

# ================= S3-2：先建缓存，删物体，invalidate，再读 =================
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "Q")
emit("Q_before", panel(ngm, sc))
bpy.data.objects.remove(obj)
ngm.invalidate_uv_cache(sc)
emit("Q_after_del_with_invalidate", panel(ngm, sc))

# ================= 空结果入缓存：干净验证 =================
bpy.ops.wm.read_factory_settings(use_empty=False)
m = fresh()
ngm = sys.modules[PKG + ".node_group_manager"]
m.register()
sc, obj, cam, uv, mat = setup(m, "R")
panel(ngm, sc)
bpy.data.objects.remove(obj)

# 关键：彻底清空缓存字典，强制下一次读必须重扫
ngm._uv_adjust_cache.clear()
emit("R_cache_cleared", dict(ngm._uv_adjust_cache))
r1 = panel(ngm, sc)
emit("R_scan_result", r1)
emit("R_cache_after_scan", {k: ("len=%d" % len(v)) for k, v in ngm._uv_adjust_cache.items()})
emit("R_key_present", sc.name in ngm._uv_adjust_cache)
emit("R_value_empty", ngm._uv_adjust_cache.get(sc.name))

# 再读：如果空结果被缓存住，这次应该命中（不再重扫）
scans = {"n": 0}
orig = ngm.find_objects_using_material


def counting(*a, **k):
    scans["n"] += 1
    return orig(*a, **k)


ngm.find_objects_using_material = counting
r2 = panel(ngm, sc)
ngm.find_objects_using_material = orig
emit("R_second_read_scan_calls", scans["n"])
emit("R_second_read_panel", r2)

print("X_JSON " + json.dumps(OUT, ensure_ascii=False, default=str))
