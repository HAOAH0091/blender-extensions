"""S2 三态补充测量 + 空结果入缓存验证（v3.0.3 基线）。

S2a：删相机，不碰缓存，直接读
S2b：删相机，调 invalidate_uv_cache，再读
S2c：删相机，模块重新加载（模拟插件重载），再读

E1：删物体后，空结果是真的写进缓存了吗？还是根本没写、所以没重扫？
    判定方法：直接检查 _uv_adjust_cache 里有没有这个键、值是什么。
"""
import bpy
import sys
import os
import importlib.util
import json

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_s2"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

RESULT = {}


def emit(k, v):
    RESULT[k] = v
    print("S2BASE " + k + " = " + repr(v))


def load_pkg():
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    m = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = m
    spec.loader.exec_module(m)
    return m


mod = load_pkg()
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()
print("VERSION", mod.bl_info["version"])


def build(tag):
    sc = bpy.context.scene
    obj = bpy.data.objects.new("Obj_" + tag, bpy.data.meshes.new("m_" + tag))
    sc.collection.objects.link(obj)
    cam = bpy.data.objects.new("Cam_" + tag, bpy.data.cameras.new("CamData_" + tag))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cp = ng.ensure_camera_project_group(cam)
    uv = ng.create_uv_adjust_node_group(sc, cam, obj)
    mat = bpy.data.materials.new("M_" + tag)
    mat.use_nodes = True
    nt = mat.node_tree
    cpn = nt.nodes.new("ShaderNodeGroup")
    cpn.node_tree = cp
    uvn = nt.nodes.new("ShaderNodeGroup")
    uvn.node_tree = uv
    tex = nt.nodes.new("ShaderNodeTexImage")
    nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
                 uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
    nt.links.new(next(s for s in uvn.outputs
                      if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
    obj.data.materials.append(mat)
    return sc, obj, cam, uv, mat


def panel(sc):
    try:
        groups = ngm.get_all_uv_adjust_node_groups(sc)
        return {"err": None, "n": len(groups),
                "valid": [g["is_valid"] for g in groups],
                "reason": [g["status"].get("reason") for g in groups]}
    except Exception as e:  # noqa: BLE001
        return {"err": f"{type(e).__name__}: {e}"}


# ---- 先建缓存，让"旧缓存"这个前提成立 ----
bpy.ops.wm.read_factory_settings(use_empty=False)
sc, obj, cam, uv, mat = build("S2")
panel(sc)                     # 建缓存
emit("S2_pre_cache_keys", list(ngm._uv_adjust_cache.keys()))
emit("S2_pre_panel", panel(sc))

# ===== S2a：删相机，不碰缓存 =====
bpy.data.objects.remove(cam)
emit("S2a_panel_no_invalidate", panel(sc))

# ===== S2b：再建一次，删相机后 invalidate =====
bpy.ops.wm.read_factory_settings(use_empty=False)
sc, obj, cam, uv, mat = build("S2b")
panel(sc)
bpy.data.objects.remove(cam)
try:
    ngm.invalidate_uv_cache()
except TypeError:
    ngm.invalidate_uv_cache(sc)
emit("S2b_panel_with_invalidate", panel(sc))

# ===== S2c：删相机 + 模块重新加载（不碰缓存字典，模拟插件重载）=====
bpy.ops.wm.read_factory_settings(use_empty=False)
sc, obj, cam, uv, mat = build("S2c")
panel(sc)
bpy.data.objects.remove(cam)
# 模拟重载：重新 exec 模块（_uv_adjust_cache 会变成新字典）
mod2 = load_pkg()
ngm2 = sys.modules[PKG + ".node_group_manager"]
emit("S2c_cache_keys_after_reload", list(ngm2._uv_adjust_cache.keys()))
try:
    groups = ngm2.get_all_uv_adjust_node_groups(sc)
    emit("S2c_panel_after_reload",
         {"err": None, "n": len(groups),
          "valid": [g["is_valid"] for g in groups],
          "reason": [g["status"].get("reason") for g in groups]})
except Exception as e:  # noqa: BLE001
    emit("S2c_panel_after_reload", {"err": f"{type(e).__name__}: {e}"})

print()
print("=" * 60)
print("E1：空结果到底有没有写进缓存？")
print("=" * 60)
# 干净场景：一个组 -> 删物体 -> 看缓存字典里有没有这个键
bpy.ops.wm.read_factory_settings(use_empty=False)
mod3 = load_pkg()
ngm3 = sys.modules[PKG + ".node_group_manager"]
ng3 = sys.modules[PKG + ".node_groups"]
# 复用 build 但用 ngm3 的模块
sc = bpy.context.scene
obj = bpy.data.objects.new("Obj_E1", bpy.data.meshes.new("m_E1"))
sc.collection.objects.link(obj)
cam = bpy.data.objects.new("Cam_E1", bpy.data.cameras.new("CamData_E1"))
sc.collection.objects.link(cam)
sc.camera = cam
cp = ng3.ensure_camera_project_group(cam)
uv = ng3.create_uv_adjust_node_group(sc, cam, obj)
mat = bpy.data.materials.new("M_E1")
mat.use_nodes = True
nt = mat.node_tree
cpn = nt.nodes.new("ShaderNodeGroup")
cpn.node_tree = cp
uvn = nt.nodes.new("ShaderNodeGroup")
uvn.node_tree = uv
tex = nt.nodes.new("ShaderNodeTexImage")
nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
             uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
nt.links.new(next(s for s in uvn.outputs
                  if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
obj.data.materials.append(mat)

ngm3._uv_adjust_cache.clear()
r0 = ngm3.get_all_uv_adjust_node_groups(sc)
emit("E1_before_delete_n", len(r0))
emit("E1_cache_after_scan", {k: ("len=%d" % len(v)) for k, v in ngm3._uv_adjust_cache.items()})

bpy.data.objects.remove(obj)
ngm3._uv_adjust_cache.clear()
r1 = ngm3.get_all_uv_adjust_node_groups(sc)
emit("E1_after_delete_panel_n", len(r1))
cache_now = {k: ("len=%d" % len(v)) for k, v in ngm3._uv_adjust_cache.items()}
emit("E1_cache_after_delete_scan", cache_now)
emit("E1_key_present", sc.name in ngm3._uv_adjust_cache)
emit("E1_cached_value_is_empty_list",
     ngm3._uv_adjust_cache.get(sc.name) == [] if sc.name in ngm3._uv_adjust_cache else "KEY_MISSING")

print("S2BASE_JSON " + json.dumps(RESULT, ensure_ascii=False, default=str))
