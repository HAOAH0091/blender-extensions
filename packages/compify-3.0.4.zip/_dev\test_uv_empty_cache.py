"""R2 回归：真·空结果（0 条）必须写进缓存并能命中。

这是上一版最大的回归点：
  - 老实现（v3.0.3）：空列表 {scene_name: []} 也算缓存，能命中。
  - 上一版改造：rows 为空时永远不命中，每次读都全量重扫。
  - 现在：scene["compify_uv_cache"] 存 {"v":1,"rows":[]}，同样能命中。

⚠️ 注意：必须是**真正扫描出 0 条**的场景（文件里压根没有 UV Adjust 组）。
   用"删物体"造场景是错的——新实现会保留一条失效组（n=1），
   那不是空结果。这一点验收时踩过一次。

用法：<blender> --background --factory-startup --python _dev/test_uv_empty_cache.py
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_r2t"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

PASS = []
FAIL = []


def chk(name, ok, detail=""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
mod.register()

bpy.ops.wm.read_factory_settings(use_empty=False)
sc = bpy.context.scene

chk("1a 前提：场景里没有任何 UV Adjust 组",
    not any(g.name.startswith("UV Adjust") for g in bpy.data.node_groups),
    str([g.name for g in bpy.data.node_groups]))

ngm.invalidate_uv_cache(sc)

# ⚠️ 判据选择踩过一次坑：
#    第一版用"find_objects_using_material 调用次数"当尺子，注入"空结果不写缓存"
#    之后它仍然是 0 —— 因为空场景里压根没有 UV 组，扫描循环根本不会调到那个函数。
#    这把尺子在这个场景下**没有判别力**（假绿）。
#    改用"缓存未命中次数"：_uv_cache_read 返回 None = 没缓存 = 必须重扫。
#    实测：修复版连读 10 次未命中 0 次；注入版 10 次。有判别力。
# CodeAuditor 提醒：_uv_cache_read 是内部函数名，将来若改名，下面那句会直接
# AttributeError 崩掉，看起来像"测试挂了"而不是"断言不成立"。先探一下，
# 让失败原因一眼能看清。
if not hasattr(ngm, "_uv_cache_read"):
    chk("0 前置：判据依赖的 _uv_cache_read 存在", False,
        "内部函数改名了，判据失效——请改用等价判据并更新本测试")
    print()
    print("=" * 50)
    print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
    raise SystemExit(1)

misses = {"n": 0}
_orig_read = ngm._uv_cache_read


def _counting_read(target_scene):
    r = _orig_read(target_scene)
    if r is None:
        misses["n"] += 1
    return r


ngm._uv_cache_read = _counting_read
try:
    misses["n"] = 0
    r1 = ngm.get_all_uv_adjust_node_groups(sc)
    chk("1b 首次读确实是 0 条（真·空结果）", len(r1) == 0, f"N={len(r1)}")
    chk("1b2 首次读必然未命中缓存（要重扫）", misses["n"] == 1,
        f"未命中 {misses['n']} 次")

    raw = sc.get("compify_uv_cache")
    chk("1c 空结果被写进了缓存", isinstance(raw, str) and raw != "", repr(raw))
    chk("1d 缓存内容确实是空行列表", '"rows":[]' in (raw or ""), repr(raw))

    misses["n"] = 0
    for _ in range(10):
        ngm.get_all_uv_adjust_node_groups(sc)
    chk("1e 连读 10 次全部命中缓存（空结果真的缓存住了）", misses["n"] == 0,
        f"缓存未命中 {misses['n']} 次")

    r2 = ngm.get_all_uv_adjust_node_groups(sc)
    chk("1f 再读仍然是 0 条", len(r2) == 0, f"N={len(r2)}")
finally:
    ngm._uv_cache_read = _orig_read

# 反向对照：确实有一个组的场景，读出来必须是 1 条（证明上面的 0 不是"什么都没读"）
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
obj = bpy.data.objects.new("Obj_R2", bpy.data.meshes.new("m_R2"))
sc.collection.objects.link(obj)
cam = bpy.data.objects.new("Cam_R2", bpy.data.cameras.new("CamData_R2"))
sc.collection.objects.link(cam)
sc.camera = cam
cp = ng.ensure_camera_project_group(cam)
uv = ng.create_uv_adjust_node_group(sc, cam, obj)
mat = bpy.data.materials.new("M_R2")
mat.use_nodes = True
nt = mat.node_tree
cpn = nt.nodes.new("ShaderNodeGroup")
cpn.node_tree = cp
uvn = nt.nodes.new("ShaderNodeGroup")
uvn.node_tree = uv
tex = nt.nodes.new("ShaderNodeTexImage")
nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
             uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
nt.links.new(next(s for s in uvn.outputs
                  if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
obj.data.materials.append(mat)
ngm.invalidate_uv_cache(sc)
r3 = ngm.get_all_uv_adjust_node_groups(sc)
chk("2a 对照：有组时能读出来（证明尺子没坏）", len(r3) == 1, f"N={len(r3)}")

print()
print("=" * 50)
print(f"PASS {len(PASS)} / FAIL {len(FAIL)}")
if FAIL:
    print("FAILED:", FAIL)
