"""B10 复现：改 mesh data 名 -> 再改节点组名 -> 组不能从面板消失。

这是 v3.0.4 开发过程中最难抓的一个回归，单独留一份手工复现脚本。

背景（独立复审 B10 实测）：
  1) 给 mesh data 改名  -> _uv_row_from_group 会把新名写回组的元数据
  2) 再给节点组改名     -> "按名字查" 和 "按数据名兜底" 两条路同时断掉
  3) 曾经的代码在这里直接 continue 丢行
  => 该组仍在文件里、仍连着材质、仍在渲染中生效，面板却永久显示 0 条。

版本对照：
  master(v3.0.3)  正常显示
  9d3b251         显示 []（回归）
  7b091d4         显示 []（未修）
  v3.0.4 当前     正常显示

双保险（两道任一存在都能救回，已由 test_uv_cache_untrusted.py 守着）：
  - 名字集合哨兵    : 保证本次读就正确
  - cache_untrusted : 保证下次读正确（本轮会跳过，但把缓存标脏）

用法：<blender> --background --factory-startup --python _dev/repro_uv_cache_b10.py
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_b10_repro"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)

spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
ngm = sys.modules[PKG + ".node_group_manager"]
ng = sys.modules[PKG + ".node_groups"]
nm = sys.modules[PKG + ".names"]
mod.register()

OK = []
BAD = []


def chk(name, ok, detail=""):
    (OK if ok else BAD).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


def names(rows):
    return [r["node_group"].name for r in rows]


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene

obj = bpy.data.objects.new("O", bpy.data.meshes.new("m"))
sc.collection.objects.link(obj)
cam = bpy.data.objects.new("C", bpy.data.cameras.new("cd"))
sc.collection.objects.link(cam)
sc.camera = cam
cp = ng.ensure_camera_project_group(cam)
uv = ng.create_uv_adjust_node_group(sc, cam, obj)
mat = bpy.data.materials.new("M")
mat.use_nodes = True
nt = mat.node_tree
cpn = nt.nodes.new("ShaderNodeGroup")
cpn.node_tree = cp
uvn = nt.nodes.new("ShaderNodeGroup")
uvn.node_tree = uv
tex = nt.nodes.new("ShaderNodeTexImage")
nt.links.new(next(s for s in cpn.outputs if s.name == "Vector"),
             uvn.inputs[nm.UV_ADJUST_INPUT_SOCKET_NAME])
nt.links.new(next(s for s in uvn.outputs
                  if s.name == nm.UV_ADJUST_OUTPUT_SOCKET_NAME), tex.inputs["Vector"])
obj.data.materials.append(mat)

ngm.invalidate_uv_cache(sc)
chk("1 基准：1 条", len(ngm.get_all_uv_adjust_node_groups(sc)) == 1)

# ---- 制造 B10：先改 mesh data 名（元数据被刷新成新名）----
obj.data.name = "m_renamed"
rows = ngm.get_all_uv_adjust_node_groups(sc)
chk("2 改数据名后仍可见", len(rows) == 1, names(rows))
chk("3 元数据确实被刷新（B10 的成因）",
    uv.get("compify_uv_object_data_name") == "m_renamed",
    uv.get("compify_uv_object_data_name"))

# ---- 再改组名：两条路同时断掉 ----
uv.name = "UV Adjust | totally-new | cd"
r1 = names(ngm.get_all_uv_adjust_node_groups(sc))
r2 = names(ngm.get_all_uv_adjust_node_groups(sc))
r3 = names(ngm.get_all_uv_adjust_node_groups(sc))
chk("4 第一次读可见", r1 == [uv.name], r1)
chk("5 第二次读可见", r2 == [uv.name], r2)
chk("6 第三次读可见", r3 == [uv.name], r3)
chk("7 组仍在文件里", uv.name in bpy.data.node_groups)
chk("8 组仍连着材质",
    any(getattr(n, "node_tree", None) == uv for n in mat.node_tree.nodes))

print()
print("=" * 50)
print(f"PASS {len(OK)} / FAIL {len(BAD)}")
if BAD:
    print("FAILED:", BAD)
