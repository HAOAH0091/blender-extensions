
import io, sys
p = sys.argv[1]
with io.open(p, "r", encoding="utf-8") as f:
    src = f.read().replace("\r\n", "\n")
# 注入：反查表永远返回空（模拟"有人改了过滤条件导致查不到"）
a = '''    index = {}
    try:
        for material in bpy.data.materials:'''
b = '''    index = {}
    return index
    try:
        for material in bpy.data.materials:'''
assert a in src, "anchor missing"
src = src.replace(a, b, 1)
with io.open(p, "w", encoding="utf-8", newline="\n") as f:
    f.write(src)
print("INJECTED index-always-empty")
