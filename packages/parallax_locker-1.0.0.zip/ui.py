"""Parallax Locker — UI 面板"""

import bpy

# 锁定物体列表最大显示行数
UI_LIST_ROWS = 6


class PARALLAX_UL_LockedObjects(bpy.types.UIList):
    """视差锁定物体列表"""

    bl_idname = "PARALLAX_UL_LockedObjects"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        # filter_items 已隐藏不存在的物体，这里只处理正常条目
        layout.label(text=item.obj_name, icon="OBJECT_DATA")
        op = layout.operator(
            "parallax.unlock_single",
            text="",
            icon="X",
            emboss=False,
        )
        op.obj_name = item.obj_name

    def filter_items(self, context, data, propname):
        """过滤掉不存在的物体（静默隐藏，不显示在列表中）。"""
        items = getattr(data, propname)
        filtered = []
        for i, item in enumerate(items):
            # 保留存在的物体
            if bpy.data.objects.get(item.obj_name) is not None:
                filtered.append(self.bitflag_filter_item)
            else:
                filtered.append(0)  # 隐藏
        return filtered, []


class PARALLAX_PT_MainPanel(bpy.types.Panel):
    """视差锁定主面板"""

    bl_label = "视差锁定"
    bl_idname = "PARALLAX_PT_MainPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "视差锁定"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # === 相机选择行 ===
        layout.prop_search(
            scene,
            "parallax_locker_camera",
            scene,
            "objects",
            text="相机",
            icon="CAMERA_DATA",
        )

        # === 操作按钮行 ===
        row = layout.row(align=True)
        row.operator("parallax.lock_selected", text="锁定选中", icon="LOCKED")
        row.operator("parallax.unlock_all", text="全部解锁", icon="UNLOCKED")

        layout.separator()

        # === 锁定物体列表 ===
        locked_list = scene.parallax_locker_objects
        if len(locked_list) > 0:
            layout.label(text=f"已锁定物体 ({len(locked_list)})")
        else:
            layout.label(text="暂无锁定物体", icon="INFO")

        layout.template_list(
            "PARALLAX_UL_LockedObjects",
            "",
            scene,
            "parallax_locker_objects",
            scene,
            "parallax_locker_active_index",
            rows=UI_LIST_ROWS,
        )
