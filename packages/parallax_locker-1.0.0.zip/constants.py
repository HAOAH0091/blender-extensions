"""Parallax Locker — 常量定义"""

# 变换变化检测阈值（Blender 单位）
# 物体位置/缩放变化超过此值才判定为"用户手动移动"
TRANSFORM_CHANGE_THRESHOLD = 0.001

# 最小深度值，防止除零和负深度
MIN_DEPTH = 0.001

# 调试日志开关
# True: 输出所有关键路径日志  False: 只输出错误/警告
PARALLAX_DEBUG = False

# 调试日志前缀
LOG_PREFIX = "[PL]"

# 锁定物体写入的自定义属性键名列表
# 解锁时按此列表批量删除
LOCK_ATTRS = [
    "parallax_original_scale",
    "parallax_camera_name",
    "parallax_locked_camera_matrix",
    "parallax_locked_focal_length",
    "parallax_locked_sensor_width",
    "parallax_locked_sensor_height",
    "parallax_locked_screen_x",
    "parallax_locked_screen_y",
    "parallax_locked_depth",
    "parallax_center_offset",
    "parallax_last_location",
    "parallax_last_scale",
    # 旧版本残留属性（不再写入，但解锁时清理）
    "parallax_last_world_pos",
]


def debug_log(msg, level="INFO"):
    """调试日志输出。

    PARALLAX_DEBUG=False 时静默。
    调用方式: debug_log("锁定: 已记录 3 个物体") 或 debug_log("异常", "ERROR")
    """
    if not PARALLAX_DEBUG and level != "ERROR":
        return
    print(f"{LOG_PREFIX} [{level}] {msg}")
