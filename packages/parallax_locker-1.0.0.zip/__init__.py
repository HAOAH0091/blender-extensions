"""Parallax Locker — Blender 通用视差锁定插件

将选中的物体"钉"在相机屏幕空间上。用户手动拖拽物体改变深度时，
插件自动保持屏幕坐标不变，缩放随深度按比例变化。

来源：从 PSD_Layer_Importer_PLUS 视差锁定功能分离改造。
"""

import bpy
from bpy.props import (
    PointerProperty,
    CollectionProperty,
    StringProperty,
    IntProperty,
)

from .core import parallax_update_handler
from .constants import debug_log
from .operators import (
    PARALLAX_OT_LockSelected,
    PARALLAX_OT_UnlockAll,
    PARALLAX_OT_UnlockSingle,
)
from .ui import PARALLAX_UL_LockedObjects, PARALLAX_PT_MainPanel


bl_info = {
    "name": "Parallax Locker",
    "author": "HAOAH / hanako",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "3D 视图 > 侧边栏 > 视差锁定",
    "description": "将选中物体钉在相机屏幕空间，拖拽时自动保持屏幕坐标并缩放",
    "category": "3D View",
}


# ==================== 数据模型 ====================

class ParallaxLockedItem(bpy.types.PropertyGroup):
    """锁定列表中每个条目的数据结构"""
    obj_name: StringProperty(name="物体名称")


# ==================== 注册/注销 ====================

classes = (
    ParallaxLockedItem,
    PARALLAX_UL_LockedObjects,
    PARALLAX_PT_MainPanel,
    PARALLAX_OT_LockSelected,
    PARALLAX_OT_UnlockAll,
    PARALLAX_OT_UnlockSingle,
)


def _scene_props_register():
    """在 Scene 上注册插件所需的属性。"""
    bpy.types.Scene.parallax_locker_camera = PointerProperty(
        type=bpy.types.Object,
        name="相机",
        description="用于视差计算的相机",
        poll=lambda self, obj: obj.type == "CAMERA",
    )
    bpy.types.Scene.parallax_locker_objects = CollectionProperty(
        type=ParallaxLockedItem
    )
    bpy.types.Scene.parallax_locker_active_index = IntProperty(default=-1)


def _scene_props_unregister():
    """注销 Scene 上的插件属性。"""
    del bpy.types.Scene.parallax_locker_camera
    del bpy.types.Scene.parallax_locker_objects
    del bpy.types.Scene.parallax_locker_active_index


def _handler_register():
    """注册 depsgraph_update_post handler，防止重复注册。"""
    handlers = bpy.app.handlers.depsgraph_update_post
    if parallax_update_handler not in handlers:
        handlers.append(parallax_update_handler)


def _handler_unregister():
    """注销 handler。"""
    handlers = bpy.app.handlers.depsgraph_update_post
    if parallax_update_handler in handlers:
        handlers.remove(parallax_update_handler)


def register():
    debug_log("插件注册开始")

    # 先注册所有类（含 PropertyGroup，Scene 属性依赖它）
    for cls in classes:
        bpy.utils.register_class(cls)
        debug_log(f"注册类: {cls.__name__}")

    # 再注册 Scene 属性（此时 PropertyGroup 的 RNA 类型已就绪）
    _scene_props_register()
    debug_log("Scene 属性已注册")

    # 注册 handler
    _handler_register()
    debug_log("handler 已注册")


def unregister():
    debug_log("插件注销开始")

    # 注销 handler
    _handler_unregister()
    debug_log("handler 已注销")

    # 先删除 Scene 属性（解除对 PropertyGroup 的引用依赖）
    _scene_props_unregister()
    debug_log("Scene 属性已注销")

    # 再注销所有类
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
        debug_log(f"注销类: {cls.__name__}")


if __name__ == "__main__":
    register()
