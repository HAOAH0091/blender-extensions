"""Parallax Locker — 核心算法

屏幕空间锚定：
  锁定瞬间将物体中心投影到相机屏幕空间，记录 (screen_x, screen_y, depth)。
  用户手动拖拽物体后，保持 screen_x/screen_y 不变，用新深度反算 3D 位置，
  缩放按深度比例变化。

从 psd_layer_importer_plus/parallax_utils.py 提取并改造。
"""

import bpy
import mathutils
import math
from bpy.app.handlers import persistent
from .constants import (
    TRANSFORM_CHANGE_THRESHOLD,
    MIN_DEPTH,
    LOCK_ATTRS,
    debug_log,
)


# ==================== 相机传感器尺寸计算 ====================

def calculate_camera_sensor_dimensions(camera, render_res_x, render_res_y):
    """根据 sensor_fit 模式返回实际传感器宽高。

    Args:
        camera: 相机对象
        render_res_x: 渲染分辨率 X
        render_res_y: 渲染分辨率 Y

    改造自原版：解耦 bpy.context 依赖，render 分辨率由调用方传入。
    """
    camera_data = camera.data
    sensor_width = camera_data.sensor_width

    if render_res_y == 0:
        render_res_y = 1
    if render_res_x == 0:
        render_res_x = 1

    if camera_data.sensor_fit == "VERTICAL":
        sensor_height = sensor_width
        sensor_width = sensor_width / (render_res_y / render_res_x)
    elif camera_data.sensor_fit == "HORIZONTAL":
        sensor_height = sensor_width * (render_res_y / render_res_x)
    else:  # AUTO
        render_aspect = render_res_x / render_res_y
        if render_aspect >= 1.0:
            sensor_height = sensor_width / render_aspect
        else:
            sensor_height = sensor_width
            sensor_width = sensor_width * render_aspect

    return sensor_width, sensor_height


# ==================== 坐标转换 ====================

def world_to_screen_coords(obj_pos, camera, render_res_x, render_res_y):
    """将世界空间坐标投影到相机屏幕空间。

    Args:
        obj_pos: 世界空间位置 (mathutils.Vector)
        camera: 相机对象
        render_res_x: 渲染分辨率 X
        render_res_y: 渲染分辨率 Y

    Returns:
        (screen_x, screen_y, depth) 三元组
        screen_x/screen_y 为归一化屏幕坐标（基于传感器尺寸）
        depth 为相机空间中的 Z 深度（正值）
    """
    camera_data = camera.data
    focal_length = camera_data.lens
    sensor_width, sensor_height = calculate_camera_sensor_dimensions(
        camera, render_res_x, render_res_y
    )

    camera_matrix = camera.matrix_world
    camera_space_pos = camera_matrix.inverted() @ obj_pos

    if camera_space_pos.z < 0:
        depth = abs(camera_space_pos.z)
        screen_x = (camera_space_pos.x * focal_length) / (depth * sensor_width)
        screen_y = (camera_space_pos.y * focal_length) / (depth * sensor_height)
        return screen_x, screen_y, depth
    # 物体在相机后方或同平面 → 兜底值
    debug_log(
        f"world_to_screen_coords: 物体在相机后方 (z={camera_space_pos.z:.4f})，返回兜底值",
        "WARNING",
    )
    return 0.0, 0.0, MIN_DEPTH


def get_object_center_world_pos(obj):
    """通过 bounding box 角点计算物体在世界空间中的包围盒中心。

    比直接使用 obj.location 更准确，适用于原点不在几何中心的物体。
    """
    bbox_corners = [
        obj.matrix_world @ mathutils.Vector(corner) for corner in obj.bound_box
    ]
    center = mathutils.Vector((0.0, 0.0, 0.0))
    for corner in bbox_corners:
        center += corner
    center /= len(bbox_corners)
    return center


# ==================== 锁定 / 解锁 ====================

def record_lock_state(obj, camera, render_res_x, render_res_y):
    """为单个物体写入视差锁定所需的全部自定义属性。

    Args:
        obj: Blender 物体
        camera: 关联的相机
        render_res_x: 渲染分辨率 X
        render_res_y: 渲染分辨率 Y
    """
    camera_matrix = camera.matrix_world.copy()

    obj["parallax_original_scale"] = list(obj.scale)

    obj["parallax_camera_name"] = camera.name
    obj["parallax_locked_camera_matrix"] = [list(row) for row in camera_matrix]
    obj["parallax_locked_focal_length"] = camera.data.lens
    obj["parallax_locked_sensor_width"] = camera.data.sensor_width

    sensor_width, sensor_height = calculate_camera_sensor_dimensions(
        camera, render_res_x, render_res_y
    )
    obj["parallax_locked_sensor_height"] = sensor_height

    obj_center_pos = get_object_center_world_pos(obj)
    screen_x, screen_y, depth = world_to_screen_coords(
        obj_center_pos, camera, render_res_x, render_res_y
    )

    center_offset = obj_center_pos - obj.matrix_world.translation
    obj["parallax_center_offset"] = list(center_offset)

    obj["parallax_locked_screen_x"] = screen_x
    obj["parallax_locked_screen_y"] = screen_y
    obj["parallax_locked_depth"] = depth

    obj["parallax_last_location"] = list(obj.location)
    obj["parallax_last_scale"] = list(obj.scale)

    parent_info = f" parent={obj.parent.name}" if obj.parent else ""
    debug_log(
        f"锁定: obj={obj.name}{parent_info} camera={camera.name} "
        f"screen=({screen_x:.4f},{screen_y:.4f}) depth={depth:.4f}"
    )


def restore_lock_state(obj):
    """清除物体上所有视差锁定相关的自定义属性。

    Args:
        obj: Blender 物体
    """
    for attr in LOCK_ATTRS:
        if attr in obj:
            del obj[attr]
    debug_log(f"解锁: obj={obj.name}")


def has_lock_attrs(obj):
    """检查物体是否包含完整的视差锁定属性。

    _recalculate_position 会读取这些属性，必须全部存在才能安全计算。
    """
    required = [
        "parallax_original_scale",
        "parallax_locked_screen_x",
        "parallax_locked_screen_y",
        "parallax_locked_depth",
        "parallax_locked_focal_length",
        "parallax_locked_sensor_width",
        "parallax_locked_sensor_height",
        "parallax_center_offset",
        "parallax_locked_camera_matrix",
    ]
    return all(key in obj for key in required)


def transform_changed(obj):
    """检测物体位置或缩放是否在上次记录后发生了变化。

    只检测局部坐标（obj.location），不检测世界坐标。
    父子级问题由锁定前的层级过滤处理：有父级关系的物体只锁最顶层。

    判定标准：任一轴的变化量超过 TRANSFORM_CHANGE_THRESHOLD。
    """
    current_loc = list(obj.location)
    current_scale = list(obj.scale)

    if "parallax_last_location" not in obj:
        obj["parallax_last_location"] = current_loc
        obj["parallax_last_scale"] = current_scale
        return False

    last_loc = obj["parallax_last_location"]
    last_scale = obj["parallax_last_scale"]

    loc_changed = any(
        abs(current_loc[i] - last_loc[i]) > TRANSFORM_CHANGE_THRESHOLD
        for i in range(3)
    )
    scale_changed = any(
        abs(current_scale[i] - last_scale[i]) > TRANSFORM_CHANGE_THRESHOLD
        for i in range(3)
    )

    changed = loc_changed or scale_changed
    if changed:
        parts = []
        if loc_changed:
            parts.append("local")
        if scale_changed:
            parts.append("scale")
        debug_log(
            f"变换检测: obj={obj.name} 变化维度=[{', '.join(parts)}] "
            f"loc=({obj.location.x:.4f},{obj.location.y:.4f},{obj.location.z:.4f})"
        )

    return changed


# ==================== Handler ====================

def _get_selected_names():
    """获取当前 view_layer 中所有选中物体的名称集合。

    handler 中没有 context 参数，通过 bpy.context 获取。
    """
    try:
        return {
            obj.name
            for obj in bpy.context.view_layer.objects.selected.values()
            if obj is not None
        }
    except (AttributeError, RuntimeError):
        debug_log("获取选中物体列表失败", "WARNING")
        return set()


def _world_to_local_location(obj, world_pos):
    """将世界空间位置转换为物体的局部坐标。

    有父级时需要考虑 matrix_parent_inverse：
    obj.matrix_world = parent.matrix_world @ obj.matrix_parent_inverse @ obj.matrix_local
    因此：obj.matrix_local.translation = (parent.matrix_world @ matrix_parent_inverse).inverted() @ world_pos

    父级矩阵不可逆时（如缩放到零），回退到直接使用世界坐标。
    """
    if obj.parent:
        try:
            combined = obj.parent.matrix_world @ obj.matrix_parent_inverse
            return combined.inverted() @ world_pos
        except ValueError:
            debug_log(
                f"世界→局部转换失败: obj={obj.name} parent={obj.parent.name} "
                f"矩阵不可逆，回退到世界坐标",
                "ERROR",
            )
            return world_pos
    return world_pos


def _recalculate_position(obj):
    """根据物体当前深度重新计算屏幕空间锚定后的 3D 位置和缩放。

    核心逻辑：
    1. 从锁定相机视角获取物体当前深度
    2. 保持 locked_screen_x / locked_screen_y 不变
    3. 用当前深度反算 3D 世界坐标
    4. 缩放按 depth_current / depth_locked 比例调整

    注意：所有相机参数均从物体锁定快照读取，不使用当前相机。
    这确保锁定后相机可自由移动。
    """
    original_scale = obj["parallax_original_scale"]
    locked_screen_x = obj["parallax_locked_screen_x"]
    locked_screen_y = obj["parallax_locked_screen_y"]
    locked_depth = obj["parallax_locked_depth"]
    locked_focal_length = obj["parallax_locked_focal_length"]
    locked_sensor_width = obj["parallax_locked_sensor_width"]
    locked_sensor_height = obj["parallax_locked_sensor_height"]
    center_offset = mathutils.Vector(obj["parallax_center_offset"])

    # 重建锁定时的相机矩阵
    locked_camera_matrix = mathutils.Matrix(
        [mathutils.Vector(row) for row in obj["parallax_locked_camera_matrix"]]
    )
    locked_camera_matrix_inv = locked_camera_matrix.inverted()

    # 获取物体当前包围盒中心在锁定相机空间中的深度
    obj_center_pos = get_object_center_world_pos(obj)
    center_in_cam_space = locked_camera_matrix_inv @ obj_center_pos
    current_depth = max(abs(center_in_cam_space.z), MIN_DEPTH)

    # 保持屏幕坐标不变，用当前深度反算相机空间位置
    cam_space_pos = mathutils.Vector((
        locked_screen_x * current_depth * locked_sensor_width / locked_focal_length,
        locked_screen_y * current_depth * locked_sensor_height / locked_focal_length,
        -current_depth,
    ))

    # 转回世界空间
    final_center_pos = locked_camera_matrix @ cam_space_pos

    # 缩放按深度比例
    scale_factor = current_depth / locked_depth
    scaled_center_offset = center_offset * scale_factor
    target_origin_pos = final_center_pos - scaled_center_offset

    # 将世界坐标转换为局部坐标（处理父子级关系）
    obj.location = _world_to_local_location(obj, target_origin_pos)
    obj.scale = mathutils.Vector(original_scale) * scale_factor

    parent_info = f" parent={obj.parent.name}" if obj.parent else ""
    debug_log(
        f"重算: obj={obj.name}{parent_info} "
        f"depth={locked_depth:.4f}→{current_depth:.4f} "
        f"scale_factor={scale_factor:.4f} "
        f"world=({target_origin_pos.x:.4f},{target_origin_pos.y:.4f},{target_origin_pos.z:.4f})"
        f"→local=({obj.location.x:.4f},{obj.location.y:.4f},{obj.location.z:.4f})"
    )


def _update_tracking(obj):
    """更新 last_location / last_scale 防止下一帧循环触发。"""
    obj["parallax_last_location"] = list(obj.location)
    obj["parallax_last_scale"] = list(obj.scale)


@persistent
def parallax_update_handler(scene):
    """depsgraph_update_post 回调。

    只在用户手动移动被锁定的物体时触发位置重算。
    相机移动不需要处理——透视投影自身就产生视差效果。
    """
    try:
        locked_objects = scene.parallax_locker_objects
        if len(locked_objects) == 0:
            return

        camera = scene.parallax_locker_camera
        if not camera:
            return

        debug_log(f"handler: 锁定物体数={len(locked_objects)}")

        selected_names = _get_selected_names()

        # 从后往前遍历，因为可能在循环中移除条目
        for i in range(len(locked_objects) - 1, -1, -1):
            item = locked_objects[i]
            obj = scene.objects.get(item.obj_name)

            # 物体已被删除 → 自动清理
            if obj is None:
                locked_objects.remove(i)
                debug_log(f"handler: 物体 {item.obj_name} 已删除，自动清理")
                continue

            # 物体缺少锁定属性 → 跳过（可能被外部修改破坏）
            if not has_lock_attrs(obj):
                debug_log(f"handler: 物体 {obj.name} 缺少锁定属性，跳过", "WARNING")
                continue

            # 只响应被选中且发生了实际位移的物体
            if obj.name in selected_names and transform_changed(obj):
                debug_log(
                    f"handler: 物体 {obj.name} 变换已变化，重算位置 "
                    f"loc=({obj.location.x:.4f},{obj.location.y:.4f},{obj.location.z:.4f})"
                )
                _recalculate_position(obj)
                _update_tracking(obj)

    except (AttributeError, TypeError, RuntimeError, KeyError, ValueError) as e:
        # handler 异常必须静默处理，避免阻塞 Blender 更新管线
        debug_log(f"handler 异常: {e}", "ERROR")
