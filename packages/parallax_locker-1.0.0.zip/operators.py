"""Parallax Locker — 操作符"""

import bpy
from bpy.props import StringProperty
from .core import record_lock_state, restore_lock_state
from .constants import debug_log


class PARALLAX_OT_LockSelected(bpy.types.Operator):
    """将当前选中的物体加入视差锁定列表"""

    bl_idname = "parallax.lock_selected"
    bl_label = "锁定选中"
    bl_description = "将选中的物体加入视差锁定，记录其屏幕空间锚点和相机参数"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return (
            scene.parallax_locker_camera is not None
            and len(context.selected_objects) > 0
        )

    def _filter_out_descendants(self, objects):
        """过滤子孙级：跳过有祖先也在同一列表中的物体，只保留最顶层。

        返回 (filtered, skipped_names) 元组。
        """
        names = {obj.name for obj in objects}
        filtered = []
        skipped = []
        for obj in objects:
            parent = obj.parent
            skip = False
            while parent:
                if parent.name in names:
                    skip = True
                    break
                parent = parent.parent
            if skip:
                skipped.append(obj.name)
            else:
                filtered.append(obj)
        return filtered, skipped

    def _constrained_objects(self, candidates):
        """从候选物体列表中返回有约束的物体。"""
        constrained = []
        for obj in candidates:
            if len(obj.constraints) > 0:
                constrained.append(obj)
        return constrained

    def invoke(self, context, event):
        filtered, skipped = self._filter_out_descendants(context.selected_objects)
        self._filtered = filtered

        if skipped:
            debug_log(f"层级过滤: 跳过子级物体 {skipped}，只锁定顶层父级")
            self.report(
                {"INFO"},
                f"检测到父子级关系，已自动排除 {len(skipped)} 个子级物体"
            )
        constrained = self._constrained_objects(filtered)
        if constrained:
            self._constrained_names = [
                f"{o.name} ({', '.join(c.name for c in o.constraints)})"
                for o in constrained
            ]
            return context.window_manager.invoke_props_dialog(
                self, width=400
            )
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="以下物体存在约束，视差锁定可能不准确：", icon="ERROR")
        layout.separator()
        for name in self._constrained_names:
            layout.label(text=f"  • {name}")
        layout.separator()
        layout.label(text="约束会覆盖插件的位置计算，建议先解除约束再锁定。")
        layout.label(text="是否继续锁定？")

    def execute(self, context):
        scene = context.scene
        camera = scene.parallax_locker_camera
        locked_list = scene.parallax_locker_objects

        # 层级过滤：如果同时选中父级和子级，只保留最顶层祖先
        # invoke 已计算则复用，否则自行计算
        if hasattr(self, '_filtered'):
            filtered = self._filtered
        else:
            filtered, skipped = self._filter_out_descendants(context.selected_objects)
            if skipped:
                debug_log(
                    f"层级过滤: 跳过子级物体 {skipped}，只锁定顶层父级"
                )
                self.report(
                    {"INFO"},
                    f"检测到父子级关系，已自动排除 {len(skipped)} 个子级物体"
                )

        render = context.scene.render
        render_res_x = render.resolution_x
        render_res_y = render.resolution_y

        already_locked = {item.obj_name for item in locked_list}
        new_count = 0
        skipped_camera = False
        warned_constraints = []

        for obj in filtered:
            if obj.name in already_locked:
                continue
            if obj == camera:
                skipped_camera = True
                debug_log(f"跳过相机物体: {obj.name}")
                continue
            if len(obj.constraints) > 0:
                constraint_names = [c.name for c in obj.constraints]
                warned_constraints.append(obj.name)
                debug_log(
                    f"约束警告: obj={obj.name} constraints={constraint_names}",
                    "WARNING",
                )
            record_lock_state(obj, camera, render_res_x, render_res_y)
            item = locked_list.add()
            item.obj_name = obj.name
            new_count += 1

        if new_count > 0:
            msg = f"已锁定 {new_count} 个物体"
            if skipped_camera:
                msg += "（已跳过相机）"
            if warned_constraints:
                msg += f"（{len(warned_constraints)} 个有约束）"
            self.report({"INFO"}, msg)
            debug_log(f"锁定选中: {new_count} 个物体, 相机={camera.name}")
        else:
            if skipped_camera:
                self.report({"WARNING"}, "相机已排除，未选中其他可锁定物体")
            else:
                self.report({"WARNING"}, "选中的物体已在锁定列表中")
        return {"FINISHED"}


class PARALLAX_OT_UnlockAll(bpy.types.Operator):
    """解除所有物体的视差锁定并清空列表"""

    bl_idname = "parallax.unlock_all"
    bl_label = "全部解锁"
    bl_description = "解除所有物体的视差锁定，恢复普通状态"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return len(context.scene.parallax_locker_objects) > 0

    def execute(self, context):
        scene = context.scene
        locked_list = scene.parallax_locker_objects
        count = len(locked_list)
        for i in range(count - 1, -1, -1):
            item = locked_list[i]
            obj = scene.objects.get(item.obj_name)
            if obj:
                restore_lock_state(obj)
            locked_list.remove(i)
        scene.parallax_locker_active_index = -1
        self.report({"INFO"}, f"已解锁 {count} 个物体")
        debug_log(f"全部解锁: {count} 个物体")
        return {"FINISHED"}


class PARALLAX_OT_UnlockSingle(bpy.types.Operator):
    """从视差锁定列表中移除指定物体"""

    bl_idname = "parallax.unlock_single"
    bl_label = "移除"
    bl_description = "从视差锁定列表中移除该物体"
    bl_options = {"REGISTER", "UNDO"}

    obj_name: StringProperty(name="物体名称")

    def execute(self, context):
        scene = context.scene
        locked_list = scene.parallax_locker_objects
        for i in range(len(locked_list) - 1, -1, -1):
            if locked_list[i].obj_name == self.obj_name:
                obj = scene.objects.get(self.obj_name)
                if obj:
                    restore_lock_state(obj)
                locked_list.remove(i)
                self.report({"INFO"}, f"已解锁: {self.obj_name}")
                debug_log(f"单个解锁: obj={self.obj_name}")
                return {"FINISHED"}
        self.report({"WARNING"}, f"未找到物体: {self.obj_name}")
        return {"CANCELLED"}
