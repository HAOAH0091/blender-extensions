"""后向注入：临时把 draw 里的开关判断改坏，验证 test_hide_update_button 必须变红。

做法：注入一个"永远画按钮"的补丁 —— 用 monkeypatch 把常量换成 True 还不够
（那是在测开关本身），这里直接改面板类的 draw 源码，模拟"有人把 if 删了"。
"""
import bpy, sys, os, importlib.util
sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_inject_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
mod.register()

ngm = sys.modules[PKG + ".node_group_manager"]
ngs = sys.modules[PKG + ".node_groups"]
scene = bpy.context.scene
cam_data = bpy.data.cameras.new("INJ_CAM")
cam = bpy.data.objects.new("INJ_CAM", cam_data); scene.collection.objects.link(cam)
mesh = bpy.data.meshes.new("INJ_MESH")
mesh.from_pydata([(-1,-1,0),(1,-1,0),(1,1,0),(-1,1,0)], [], [(0,1,2,3)]); mesh.update()
obj = bpy.data.objects.new("INJ_OBJ", mesh); scene.collection.objects.link(obj)
if not obj.data.uv_layers: obj.data.uv_layers.new(name="UVMap")
ngs.ensure_camera_project_group(cam, default_aspect=1.0)
ngm.create_and_add_uv_adjust_node_group(scene, cam, obj)

# ---- 注入：panel 里所有 SHOW_UPDATE_UV_ADJUST_BUTTON 判断一律放行 ----
# 等价于"有人手滑把 if 删掉了"
import inspect, textwrap
src = inspect.getsource(mod.CompifyUVAdjust3DPanel.draw)
bad = src.replace("if SHOW_UPDATE_UV_ADJUST_BUTTON:", "if True:")
ns = dict(mod.__dict__)
ns["_"] = mod._
exec(compile(textwrap.dedent(bad), "<injected>", "exec"), ns)
# getSource 只拿到 draw 这一个函数，类本身还在 mod 里 ——
# 所以要造一个子类，把注入版 draw 挂上去，否则测的还是原逻辑（假绿）。
InjectedPanel = type("InjectedPanel", (mod.CompifyUVAdjust3DPanel,),
                      {"draw": ns["draw"]})

class Rec:
    def __init__(s, sink): object.__setattr__(s, "_sink", sink)
    def __getattr__(s, n):
        if n == "_sink": raise AttributeError(n)
        def _any(*a, **k):
            if n == "operator" and a: s._sink.append(a[0])
            return s
        return _any
    def __setattr__(s, n, v): object.__setattr__(s, n, v)

class Fake:
    def __init__(s, sink): s.layout = Rec(sink)

ops = []
# 注入版 draw 是独立函数体，self 只要给个带 layout 的空壳
InjectedPanel.draw(Fake(ops), bpy.context)
n = ops.count("compify.update_uv_adjust")
print("INJECTED_DRAW_COUNT=%d" % n)
print("VERDICT=%s" % ("检测成功（测试会变红）" if n > 0 else "注入无效，测试是假绿"))
mod.unregister()
