import bpy
import math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

from .names import (
    UV_ADJUST_INPUT_SOCKET_NAME,
    UV_ADJUST_OUTPUT_SOCKET_NAME,
    uv_adjust_node_group_name,
    camera_project_node_group_name,
)

from .names import (PLOCK_S_NODE, PLOCK_C_NODE,
                    PLOCK_DELTA_VERSION_KEY, PLOCK_DELTA_VERSION)


CAMERA_PROJECT_PREFIX = "Camera Project | "


def find_object_by_data_name(data_name, type_filter=None, scene=None):
    """
    Find an object by its data-block name (mesh, camera, etc.).

    This function searches for objects by their underlying data-block name
    rather than their object name. It first searches the current scene, then
    falls back to searching all objects in the blend file.

    Args:
        data_name: Name of the data block to search for
        type_filter: Optional type filter (e.g., 'MESH', 'CAMERA')
        scene: Optional scene to search first.  When omitted, the context
            scene is used (legacy behavior).  Callers that operate on a
            non-current scene should pass it explicitly.

    Returns:
        bpy.types.Object: The found object, or None if not found

    Example:
        # Find a camera by its data name
        camera_obj = find_object_by_data_name("Camera", type_filter='CAMERA')
    """
    # Prefer objects in the requested scene first.  Falling back to the
    # context scene is intentional for old callers, but passing `scene`
    # keeps background / multi-scene operations from resolving the wrong
    # data-block when two scenes share the same data name.
    search_scene = scene
    if search_scene is None:
        try:
            search_scene = bpy.context.scene
        except (AttributeError, RuntimeError):
            search_scene = None
    if search_scene is not None:
        for obj in search_scene.objects:
            if getattr(obj, "data", None) and obj.data and obj.data.name == data_name:
                if type_filter and obj.type != type_filter:
                    continue
                return obj
    # Fallback: search all objects
    for obj in bpy.data.objects:
        if getattr(obj, "data", None) and obj.data and obj.data.name == data_name:
            if type_filter and obj.type != type_filter:
                continue
            return obj
    return None


def find_objects_using_material(material_name):
    """
    Find all mesh objects that use a specific material.

    Searches through all objects in the blend file and returns
    a list of mesh objects that have the specified material assigned.

    Args:
        material_name: Name of the material to search for

    Returns:
        list: List of mesh objects using the material (empty list if none found)

    Note:
        Returns empty list if material doesn't exist
    """
    objs = []
    mat = bpy.data.materials.get(material_name)
    if not mat:
        return objs
    for obj in bpy.data.objects:
        if (
            obj.type == "MESH"
            and getattr(obj, "data", None)
            and obj.data
            and obj.data.materials
        ):
            for m in obj.data.materials:
                if m and m.name == material_name:
                    objs.append(obj)
                    break
    return objs


def extract_camera_from_camera_project_group(group):
    try:
        for n in group.nodes:
            if (
                hasattr(n, "object")
                and n.object
                and getattr(n.object, "type", None) == "CAMERA"
            ):
                return n.object
        parts = group.name.split(" | ")
        if len(parts) == 2:
            cam_data_name = parts[1]
            return find_object_by_data_name(cam_data_name, type_filter="CAMERA")
    except Exception as e:
        print(f"Compify: Warning in extract_camera_from_camera_project_group: {e}")
    return None


def find_camera_connected_to_uv_adjust_in_material(material, uv_adjust_group):
    try:
        nt = material.node_tree
        if not nt:
            return None
        uv_node = None
        for node in nt.nodes:
            try:
                if (
                    node.type == "GROUP"
                    and node.node_tree
                    and node.node_tree.name == uv_adjust_group.name
                ):
                    uv_node = node
                    break
            except (UnicodeDecodeError, UnicodeEncodeError):
                # 节点名称编码问题 - 跳过
                continue
        if not uv_node:
            return None
        uv_input = None
        for inp in uv_node.inputs:
            if inp.name == UV_ADJUST_INPUT_SOCKET_NAME:
                uv_input = inp
                break
        if not uv_input:
            return None
        for link in nt.links:
            if link.to_socket == uv_input:
                from_node = link.from_node
                if from_node and from_node.type == "GROUP" and from_node.node_tree:
                    return extract_camera_from_camera_project_group(from_node.node_tree)
        return None
    except Exception as e:
        print(
            f"Compify: Warning in find_camera_connected_to_uv_adjust_in_material: {e}"
        )
        return None


def ensure_camera_project_group(camera, default_aspect=1.0):
    """
    Ensures there is a node group for projecting textures from a specific camera.

    Creates a node group that handles camera projection calculations including
    lens, sensor size, lens shift, aspect ratio, and user-adjustable transforms.
    The group is automatically linked to the camera via drivers.

    Args:
        camera: The camera object to create projection for
        default_aspect: Default aspect ratio to use (default 1.0)

    Returns:
        bpy.types.NodeGroup: The Camera Project node group

    Note:
        The created group is specific to the camera and will be named
        "Camera Project | {camera_data_name}"
    """
    name = camera_project_node_group_name(camera)

    # Fetch or create group.
    group = None
    if name in bpy.data.node_groups:
        group = bpy.data.node_groups[name]
    else:
        group = bpy.data.node_groups.new(name, type="ShaderNodeTree")

    # Clear all nodes, to start from a clean slate.
    for node in group.nodes:
        group.nodes.remove(node)

    # Create the group inputs.
    if not "Aspect Ratio" in group.interface.items_tree:
        socket = group.interface.new_socket(
            name="Aspect Ratio", socket_type="NodeSocketFloat", in_out="INPUT"
        )
        socket.default_value = default_aspect
    if not "Rotation" in group.interface.items_tree:
        group.interface.new_socket(
            name="Rotation", socket_type="NodeSocketFloat", in_out="INPUT"
        )
    if not "Loc X" in group.interface.items_tree:
        group.interface.new_socket(
            name="Loc X", socket_type="NodeSocketFloat", in_out="INPUT"
        )
    if not "Loc Y" in group.interface.items_tree:
        group.interface.new_socket(
            name="Loc Y", socket_type="NodeSocketFloat", in_out="INPUT"
        )

    # Create the group outputs.
    if not "Vector" in group.interface.items_tree:
        group.interface.new_socket(
            name="Vector", socket_type="NodeSocketVector", in_out="OUTPUT"
        )

    # -------------------
    # Create the nodes.
    input = group.nodes.new(type="NodeGroupInput")
    output = group.nodes.new(type="NodeGroupOutput")

    camera_transform = group.nodes.new(type="ShaderNodeTexCoord")
    lens = group.nodes.new(type="ShaderNodeValue")
    sensor_width = group.nodes.new(type="ShaderNodeValue")
    lens_shift_x = group.nodes.new(type="ShaderNodeValue")
    lens_shift_y = group.nodes.new(type="ShaderNodeValue")

    zoom_1 = group.nodes.new(type="ShaderNodeMath")
    zoom_2 = group.nodes.new(type="ShaderNodeMath")
    lens_shift_1 = group.nodes.new(type="ShaderNodeCombineXYZ")
    to_radians = group.nodes.new(type="ShaderNodeMath")
    user_location = group.nodes.new(type="ShaderNodeCombineXYZ")

    perspective_1 = group.nodes.new(type="ShaderNodeSeparateXYZ")
    perspective_2 = group.nodes.new(type="ShaderNodeMath")
    perspective_3 = group.nodes.new(type="ShaderNodeMath")
    perspective_4 = group.nodes.new(type="ShaderNodeCombineXYZ")
    # ★★ 解锁「落实构图」用的 C + k 参数（见 compify_parallax_lock.unlock_group）：
    #
    #    实测（_dev/diag_affine.py）解锁所需的 UV 修正量总能精确写成
    #        delta = C + k · persp(p)
    #    所以投影组里只需两个**普通数值节点**：
    #        persp → [SCALE  S] → [ADD  C] → 下游 zoom/shift/...
    #    即  UV = persp · S + C   （S = 1 + k）
    #
    #    数值由插件写入，**不是逐顶点属性** ⇒ 任何网格用了这个投影材质
    #    就自动共享同一构图（不存在「解锁后才换材质的网格拿不到状态」）。
    #    锁定期间 S = 1、C = 0 ⇒ 恒等变换，主链行为与旧版完全一致。
    plock_scale = group.nodes.new(type="ShaderNodeVectorMath")
    plock_scale.operation = 'SCALE'
    plock_offset = group.nodes.new(type="ShaderNodeVectorMath")
    plock_offset.operation = 'ADD'
    zoom_3 = group.nodes.new(type="ShaderNodeVectorMath")
    lens_shift_2 = group.nodes.new(type="ShaderNodeVectorMath")

    user_translate = group.nodes.new(type="ShaderNodeVectorMath")
    user_rotate = group.nodes.new(type="ShaderNodeVectorRotate")
    aspect_ratio_1 = group.nodes.new(type="ShaderNodeCombineXYZ")
    aspect_ratio_2 = group.nodes.new(type="ShaderNodeCombineXYZ")
    aspect_ratio_div = group.nodes.new(type="ShaderNodeMath")
    aspect_ratio_lt = group.nodes.new(type="ShaderNodeMath")
    aspect_ratio_switch = group.nodes.new(type="ShaderNodeMixRGB")
    user_transforms = group.nodes.new(type="ShaderNodeVectorMath")

    recenter = group.nodes.new(type="ShaderNodeVectorMath")

    # --------------------
    # Label the nodes.
    camera_transform.label = "Camera Transform"
    lens.label = "Lens"
    sensor_width.label = "Sensor Width"
    lens_shift_x.label = "Lens Shift X"
    lens_shift_y.label = "Lens Shift Y"

    zoom_1.label = "Zoom 1"
    zoom_2.label = "Zoom 2"
    lens_shift_1.label = "Lens Shift 1"
    to_radians.label = "Degrees to Radians"
    user_location.label = "User Location"

    perspective_1.label = "Perspective 1"
    perspective_2.label = "Perspective 2"
    perspective_3.label = "Perspective 3"
    perspective_4.label = "Perspective 4"
    plock_scale.label = "PLock Delta Scale"
    plock_offset.label = "PLock Delta Offset"
    # 固定节点名，插件按名字找（label 用户可改，name 才是稳定标识）
    plock_scale.name = PLOCK_S_NODE
    plock_offset.name = PLOCK_C_NODE
    zoom_3.label = "Zoom 3"
    lens_shift_2.label = "Lens Shift 2"

    user_translate.label = "User Translate"
    user_rotate.label = "User Rotate"

    aspect_ratio_1.label = "Aspect Ratio 1"
    aspect_ratio_2.label = "Aspect Ratio 2"
    aspect_ratio_div.label = "Divide"
    aspect_ratio_lt.label = "Less Than"
    aspect_ratio_switch.label = "Aspect Ratio Switch"

    user_transforms.label = "User Transforms"

    recenter.label = "Recenter"

    # ---------------------
    # Position the nodes.
    hs = 250.0
    x = 0.0

    camera_transform.location = (x, 0.0)
    lens.location = (x, -700.0)
    sensor_width.location = (x, -900.0)
    lens_shift_x.location = (x, -1100.0)
    lens_shift_y.location = (x, -1300.0)
    input.location = (x, -1500.0)

    x += hs
    zoom_1.location = (x, -700.0)
    lens_shift_1.location = (x, -1100.0)
    to_radians.location = (x, -1500.0)
    user_location.location = (x, -1700.0)

    x += hs
    zoom_2.location = (x, -700.0)

    x += hs
    perspective_1.location = (x, 0.0)

    x += hs
    perspective_2.location = (x, 0.0)
    perspective_3.location = (x, -200.0)

    x += hs
    perspective_4.location = (x, 0.0)

    x += hs
    zoom_3.location = (x, 0.0)

    x += hs
    lens_shift_2.location = (x, 0.0)
    aspect_ratio_div.location = (x, -850.0)

    x += hs
    user_translate.location = (x, 0.0)
    aspect_ratio_lt.location = (x, -500.0)
    aspect_ratio_1.location = (x, -700.0)
    aspect_ratio_2.location = (x, -850.0)

    x += hs
    user_rotate.location = (x, 0.0)
    aspect_ratio_switch.location = (x, -600.0)

    x += hs
    user_transforms.location = (x, 0.0)

    x += hs
    recenter.location = (x, 0.0)

    x += hs
    output.location = (x, 0.0)

    # ---------------------
    # Set up the drivers.

    drv_lens = lens.outputs["Value"].driver_add("default_value").driver
    drv_lens.type = "SUM"
    var = drv_lens.variables.new()
    var.type = "SINGLE_PROP"
    var.targets[0].id_type = "CAMERA"
    var.targets[0].id = camera.data
    var.targets[0].data_path = "lens"

    drv_width = sensor_width.outputs["Value"].driver_add("default_value").driver
    drv_width.type = "SUM"
    var = drv_width.variables.new()
    var.type = "SINGLE_PROP"
    var.targets[0].id_type = "CAMERA"
    var.targets[0].id = camera.data
    var.targets[0].data_path = "sensor_width"

    drv_shift_x = lens_shift_x.outputs["Value"].driver_add("default_value").driver
    drv_shift_x.type = "SUM"
    var = drv_shift_x.variables.new()
    var.type = "SINGLE_PROP"
    var.targets[0].id_type = "CAMERA"
    var.targets[0].id = camera.data
    var.targets[0].data_path = "shift_x"

    drv_shift_y = lens_shift_y.outputs["Value"].driver_add("default_value").driver
    drv_shift_y.type = "SUM"
    var = drv_shift_y.variables.new()
    var.type = "SINGLE_PROP"
    var.targets[0].id_type = "CAMERA"
    var.targets[0].id = camera.data
    var.targets[0].data_path = "shift_y"

    # ----------------------
    # Configure the nodes.
    camera_transform.object = camera

    zoom_1.operation = "DIVIDE"
    zoom_1.use_clamp = False
    zoom_2.operation = "MULTIPLY"
    zoom_2.use_clamp = False
    zoom_2.inputs[1].default_value = -1.0
    lens_shift_1.inputs[2].default_value = 0.0
    to_radians.operation = "MULTIPLY"
    to_radians.use_clamp = False
    to_radians.inputs[1].default_value = math.pi / 180.0
    user_location.inputs[2].default_value = 0.0

    perspective_2.operation = "DIVIDE"
    perspective_2.use_clamp = False
    perspective_3.operation = "DIVIDE"
    perspective_3.use_clamp = False
    zoom_3.operation = "MULTIPLY"
    lens_shift_2.operation = "SUBTRACT"

    # C+k 默认值 = 恒等变换（锁定期间必须如此）
    plock_scale.inputs["Scale"].default_value = 1.0
    plock_offset.inputs[1].default_value = (0.0, 0.0, 0.0)
    group[PLOCK_DELTA_VERSION_KEY] = PLOCK_DELTA_VERSION

    user_translate.operation = "SUBTRACT"
    user_rotate.rotation_type = "Z_AXIS"
    user_rotate.invert = False
    user_rotate.inputs["Center"].default_value = (0.0, 0.0, 0.0)
    aspect_ratio_1.inputs["X"].default_value = 1.0
    aspect_ratio_1.inputs["Z"].default_value = 0.0
    aspect_ratio_2.inputs["Y"].default_value = 1.0
    aspect_ratio_2.inputs["Z"].default_value = 0.0
    aspect_ratio_div.operation = "DIVIDE"
    aspect_ratio_div.inputs[0].default_value = 1.0
    aspect_ratio_lt.operation = "LESS_THAN"
    aspect_ratio_lt.inputs[1].default_value = 1.0
    aspect_ratio_switch.blend_type = "MIX"
    aspect_ratio_switch.use_clamp = False

    user_transforms.operation = "MULTIPLY"

    recenter.operation = "ADD"
    recenter.inputs[1].default_value = (0.5, 0.5, 0.0)

    # --------------------
    # Hook up the nodes.
    group.links.new(camera_transform.outputs["Object"], perspective_1.inputs["Vector"])
    group.links.new(lens.outputs["Value"], zoom_1.inputs[0])
    group.links.new(sensor_width.outputs["Value"], zoom_1.inputs[1])
    group.links.new(zoom_1.outputs["Value"], zoom_2.inputs[0])
    group.links.new(zoom_2.outputs["Value"], zoom_3.inputs[1])
    group.links.new(lens_shift_x.outputs["Value"], lens_shift_1.inputs["X"])
    group.links.new(lens_shift_y.outputs["Value"], lens_shift_1.inputs["Y"])
    group.links.new(lens_shift_1.outputs["Vector"], lens_shift_2.inputs[1])

    group.links.new(input.outputs["Aspect Ratio"], aspect_ratio_1.inputs["Y"])
    group.links.new(input.outputs["Aspect Ratio"], aspect_ratio_div.inputs[1])
    group.links.new(input.outputs["Aspect Ratio"], aspect_ratio_lt.inputs[0])
    group.links.new(input.outputs["Rotation"], to_radians.inputs[0])
    group.links.new(to_radians.outputs["Value"], user_rotate.inputs["Angle"])
    group.links.new(input.outputs["Loc X"], user_location.inputs["X"])
    group.links.new(input.outputs["Loc Y"], user_location.inputs["Y"])
    group.links.new(user_location.outputs["Vector"], user_translate.inputs[1])

    group.links.new(perspective_1.outputs["X"], perspective_2.inputs[0])
    group.links.new(perspective_1.outputs["Y"], perspective_3.inputs[0])
    group.links.new(perspective_1.outputs["Z"], perspective_2.inputs[1])
    group.links.new(perspective_1.outputs["Z"], perspective_3.inputs[1])
    group.links.new(perspective_1.outputs["Z"], perspective_4.inputs["Z"])
    group.links.new(perspective_2.outputs["Value"], perspective_4.inputs["X"])
    group.links.new(perspective_3.outputs["Value"], perspective_4.inputs["Y"])
    # 透视结果 → (×S) → (+C) → zoom_3     即 UV = persp·S + C
    # 默认 S=1、C=0 ⇒ 恒等，锁定期间行为与旧版完全一致。
    group.links.new(perspective_4.outputs["Vector"], plock_scale.inputs[0])
    group.links.new(plock_scale.outputs["Vector"], plock_offset.inputs[0])
    group.links.new(plock_offset.outputs["Vector"], zoom_3.inputs[0])
    group.links.new(zoom_3.outputs["Vector"], lens_shift_2.inputs[0])
    group.links.new(lens_shift_2.outputs["Vector"], user_translate.inputs[0])

    group.links.new(aspect_ratio_div.outputs[0], aspect_ratio_2.inputs["X"])
    group.links.new(aspect_ratio_1.outputs[0], aspect_ratio_switch.inputs[1])
    group.links.new(aspect_ratio_2.outputs[0], aspect_ratio_switch.inputs[2])
    group.links.new(aspect_ratio_lt.outputs[0], aspect_ratio_switch.inputs[0])

    group.links.new(user_translate.outputs["Vector"], user_rotate.inputs["Vector"])
    group.links.new(user_rotate.outputs["Vector"], user_transforms.inputs[0])
    group.links.new(aspect_ratio_switch.outputs[0], user_transforms.inputs[1])
    group.links.new(user_transforms.outputs["Vector"], recenter.inputs[0])

    group.links.new(recenter.outputs["Vector"], output.inputs["Vector"])

    return group


def scene_aspect_ratio(scene=None):
    """Return the effective render aspect ratio for *scene*.

    This mirrors the calculation used by the batch generator and matches the
    normalized coordinates returned by ``world_to_camera_view``.  Keeping one
    helper avoids the old situation where different creation paths used
    ``1.0``, ``1.77`` and the current render settings respectively.
    """
    if scene is None:
        try:
            scene = bpy.context.scene
        except (AttributeError, RuntimeError):
            scene = None
    if scene is None:
        return 1.0
    try:
        width = float(scene.render.resolution_x) * float(
            scene.render.pixel_aspect_x)
        height = float(scene.render.resolution_y) * float(
            scene.render.pixel_aspect_y)
        if width <= 0.0 or height <= 0.0:
            return 1.0
        aspect = width / height
        return aspect if math.isfinite(aspect) and aspect > 0.0 else 1.0
    except (AttributeError, TypeError, ValueError):
        return 1.0


def _find_interface_socket(group, name, in_out="INPUT"):
    """Find a node-group interface socket by name.

    Blender's interface collection contains both panels and sockets; checking
    ``item_type`` keeps panels with the same name from being mistaken for the
    actual input socket.
    """
    try:
        for item in group.interface.items_tree:
            if getattr(item, "name", None) != name:
                continue
            if getattr(item, "item_type", "SOCKET") != "SOCKET":
                continue
            if getattr(item, "in_out", in_out) != in_out:
                continue
            return item
    except (AttributeError, RuntimeError, TypeError):
        return None
    return None


def sync_camera_project_aspect(scene, aspect=None):
    """Push the scene's current aspect ratio into Camera Project groups.

    Blender stores group-socket defaults on the interface *and* copies them
    onto every group-node instance.  Updating only the interface is not enough
    for materials that already contain a Camera Project node, so both places
    are updated.  Linked inputs are left alone: an explicit link is a user
    override and must not be stomped on by a render-setting change.

    Returns the number of sockets/nodes actually changed.
    """
    if aspect is None:
        aspect = scene_aspect_ratio(scene)
    try:
        aspect = float(aspect)
    except (TypeError, ValueError):
        return 0
    if not math.isfinite(aspect) or aspect <= 0.0:
        return 0

    changed = 0

    # 1) Interface defaults, used by newly created group nodes.
    for group in bpy.data.node_groups:
        if not group.name.startswith(CAMERA_PROJECT_PREFIX):
            continue
        socket = _find_interface_socket(group, "Aspect Ratio")
        if socket is None:
            continue
        try:
            if abs(float(socket.default_value) - aspect) > 1e-9:
                socket.default_value = aspect
                changed += 1
        except (AttributeError, TypeError, ValueError):
            continue

    # 2) Existing group-node instances.  Blender does not reliably propagate
    #    interface-default changes to nodes that were created earlier.
    for material in bpy.data.materials:
        node_tree = getattr(material, "node_tree", None)
        if node_tree is None:
            continue
        for node in node_tree.nodes:
            if node.type != "GROUP" or node.node_tree is None:
                continue
            if not node.node_tree.name.startswith(CAMERA_PROJECT_PREFIX):
                continue
            socket = node.inputs.get("Aspect Ratio")
            if socket is None or socket.is_linked:
                continue
            try:
                if abs(float(socket.default_value) - aspect) > 1e-9:
                    socket.default_value = aspect
                    changed += 1
            except (AttributeError, TypeError, ValueError):
                continue

    return changed


# Gets the object's bounding box in camera view coordinates.
#
# Returns the complete bounding box and calculated offset/scale parameters
# for UV adjustment in camera view space.
def get_object_camera_bounds(scene, camera, obj):
    """
    Calculate the 2D bounding box of an object in camera view coordinates
    and compute UV adjustment parameters.

    Args:
        scene: Blender scene object
        camera: Blender camera object
        obj: Blender object to calculate bounds for

    Returns:
        tuple: (offset, scale) where:
            - offset: (min_x, min_y) - UV offset to align to object's bottom-left
            - scale: (width, height) - object size in camera view coordinates
    """
    # Get the object's 8 bounding box corners in world coordinates
    bbox_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]

    # Convert 3D world coordinates to camera view 2D coordinates
    cam_coords = [
        world_to_camera_view(scene, camera, corner) for corner in bbox_corners
    ]

    # Calculate the complete 2D bounding box
    min_x = min(coord.x for coord in cam_coords)
    max_x = max(coord.x for coord in cam_coords)
    min_y = min(coord.y for coord in cam_coords)
    max_y = max(coord.y for coord in cam_coords)

    # Calculate UV adjustment parameters
    offset = (min_x, min_y)  # Offset to move UV origin to object's bottom-left
    scale = (max_x - min_x, max_y - min_y)  # Object size in camera view coordinates

    return offset, scale


# Creates a UV adjustment node group for a specific object and camera.
#
# This node group takes camera projection UV coordinates and offsets them
# to align with the object's bounding box in camera view.
def create_uv_adjust_node_group(scene, camera, obj):
    """
    Create a UV adjustment node group that offsets camera projection UV
    coordinates to align with the object's bounding box.

    Args:
        scene: Blender scene object
        camera: Blender camera object
        obj: Blender object to create UV adjustment for

    Returns:
        NodeGroup: The created UV adjustment node group
    """
    # Generate the node group name
    name = uv_adjust_node_group_name(obj, camera)

    # Create or get existing node group
    if name in bpy.data.node_groups:
        group = bpy.data.node_groups[name]
        # Clear existing nodes to start fresh
        for node in group.nodes:
            group.nodes.remove(node)
    else:
        group = bpy.data.node_groups.new(name, type="ShaderNodeTree")

    # Store stable association metadata (object/camera data-block names)
    try:
        group["compify_node_type"] = "uv_adjust"  # Identifier for node group type
        group["compify_uv_object_data_name"] = (
            obj.data.name if getattr(obj, "data", None) else obj.name
        )
        group["compify_uv_camera_data_name"] = (
            camera.data.name if getattr(camera, "data", None) else camera.name
        )
    except Exception as e:
        # ID properties write may fail in unusual contexts; log and continue
        print(f"Compify: Warning - failed to store UV adjust metadata: {e}")

    # Clear existing interface items
    group.interface.clear()

    # Create input socket
    group.interface.new_socket(
        name=UV_ADJUST_INPUT_SOCKET_NAME, socket_type="NodeSocketVector", in_out="INPUT"
    )

    # Create output socket
    group.interface.new_socket(
        name=UV_ADJUST_OUTPUT_SOCKET_NAME,
        socket_type="NodeSocketVector",
        in_out="OUTPUT",
    )

    # Create nodes
    input_node = group.nodes.new(type="NodeGroupInput")
    output_node = group.nodes.new(type="NodeGroupOutput")
    subtract_node = group.nodes.new(type="ShaderNodeVectorMath")
    divide_node = group.nodes.new(type="ShaderNodeVectorMath")

    # Configure subtract node (UV offset)
    subtract_node.operation = "SUBTRACT"
    subtract_node.label = "UV Offset"

    # Configure divide node (UV scale)
    divide_node.operation = "DIVIDE"
    divide_node.label = "UV Scale"

    # Calculate the UV adjustment parameters based on object bounds in camera view
    offset, scale = get_object_camera_bounds(scene, camera, obj)

    # Set the offset values (subtract offset to move UV origin to object's bottom-left)
    subtract_node.inputs[1].default_value = (offset[0], offset[1], 0.0)

    # Set the scale values (divide by scale to match UV range to object size)
    # Ensure we don't divide by zero
    safe_scale_x = max(scale[0], 0.001)  # Minimum scale to avoid division by zero
    safe_scale_y = max(scale[1], 0.001)
    divide_node.inputs[1].default_value = (safe_scale_x, safe_scale_y, 1.0)

    # Position nodes
    input_node.location = (0, 0)
    subtract_node.location = (200, 0)
    divide_node.location = (400, 0)
    output_node.location = (600, 0)

    # Connect nodes: Input UV -> Subtract (offset) -> Divide (scale) -> Output UV
    group.links.new(
        input_node.outputs[UV_ADJUST_INPUT_SOCKET_NAME], subtract_node.inputs[0]
    )
    group.links.new(subtract_node.outputs["Vector"], divide_node.inputs[0])
    group.links.new(
        divide_node.outputs["Vector"], output_node.inputs[UV_ADJUST_OUTPUT_SOCKET_NAME]
    )

    return group


# Checks if a camera projection node group exists for the given camera.
def check_camera_project_group_exists(camera):
    """
    Check if a camera projection node group exists for the specified camera.

    Args:
        camera: Blender camera object

    Returns:
        bool: True if the node group exists, False otherwise
    """
    group_name = camera_project_node_group_name(camera)
    return group_name in bpy.data.node_groups
