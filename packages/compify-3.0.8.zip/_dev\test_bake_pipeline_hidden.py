"""End-to-end regression: bake a material whose source object is hidden.

Runs a tiny 64x64 Cycles bake in a factory-empty scene.  Also verifies that a
failure after copies/images are created removes those temporary artifacts.

Run:
  blender --background --factory-startup --python _dev/test_bake_pipeline_hidden.py
"""

import bpy
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_bake_pipeline_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)

bp = sys.modules[PKG + ".bake_pipeline"]
uv = sys.modules[PKG + ".uv_utils"]

PASS = []
FAIL = []


def chk(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", name, detail))


def setup_hidden_scene(obj_name="Hidden_Bake_Source",
                       mat_name="Hidden_Bake_Mat"):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    view_layer = bpy.context.view_layer

    mesh = bpy.data.meshes.new(obj_name + "_Mesh")
    mesh.from_pydata(
        [(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)],
        [], [(0, 1, 2, 3)])
    mesh.update()
    obj = bpy.data.objects.new(obj_name, mesh)
    scene.collection.objects.link(obj)

    cam_data = bpy.data.cameras.new("Hidden_Bake_CamData")
    cam = bpy.data.objects.new("Hidden_Bake_Cam", cam_data)
    scene.collection.objects.link(cam)
    scene.camera = cam

    # Camera Project node group: TexCoord.object is what the add-on reads.
    group = bpy.data.node_groups.new(
        "Camera Project | Hidden_Bake_CamData", "ShaderNodeTree")
    texcoord = group.nodes.new("ShaderNodeTexCoord")
    texcoord.object = cam

    mat = bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    group_node = mat.node_tree.nodes.new("ShaderNodeGroup")
    group_node.node_tree = group
    obj.data.materials.append(mat)

    obj.hide_set(True)
    obj.hide_viewport = True
    obj.hide_render = True
    obj.hide_select = True
    view_layer.update()

    return scene, view_layer, obj, mat


print("=" * 64)
print("[1] full bake with a hidden source object")
print("=" * 64)

scene, view_layer, source, material = setup_hidden_scene()
result = bp.bake_material_projection(
    scene=scene,
    material=material,
    bake_resolution=64,
    auto_unwrap=False,
)

chk("bake reports success", result["success"] is True, result["message"])
chk("one baked object created", len(result["baked_objects"]) == 1)
chk("one image created", len(result["baked_images"]) == 1)

if result["success"]:
    baked = result["baked_objects"][0]
    image = result["baked_images"][0]
    chk("baked object is visible and renderable",
        not baked.hide_viewport and not baked.hide_render)
    chk("baked object has UV", bool(baked.data.uv_layers.active))
    chk("baked object has its own mesh", baked.data != source.data)
    chk("baked image is 64x64",
        tuple(image.size) == (64, 64), str(tuple(image.size)))
    chk("source object still exists", source.name in bpy.data.objects)
    chk("source stays hidden",
        source.hide_viewport
        and source.hide_render
        and source.hide_select
        and source.hide_get(view_layer=view_layer) is True)

print()
print("=" * 64)
print("[2] failing UV step cleans up the bake copy")
print("=" * 64)

scene, view_layer, source, material = setup_hidden_scene(
    "Fail_UV_Source", "Fail_UV_Mat")
baseline_objects = len(bpy.data.objects)

original_unwrap = uv._select_and_unwrap


def fail_mode_set(*args, **kwargs):
    raise RuntimeError(
        "Operator bpy.ops.object.mode_set.poll() Context missing active object")


uv._select_and_unwrap = fail_mode_set
try:
    result = bp.bake_material_projection(
        scene=scene,
        material=material,
        bake_resolution=64,
        auto_unwrap=False,
    )
finally:
    uv._select_and_unwrap = original_unwrap

chk("bake reports failure", result["success"] is False)
chk("message explains visibility",
    "hidden" in result["message"].lower()
    and "view layer" in result["message"].lower(),
    result["message"])
chk("no temporary object left behind",
    len(bpy.data.objects) == baseline_objects,
    "%d -> %d" % (baseline_objects, len(bpy.data.objects)))
chk("source object survived",
    bpy.data.objects.get("Fail_UV_Source") is not None)

print()
print("=" * 64)
print("[3] failing material clone cleans objects + images")
print("=" * 64)

scene, view_layer, source, material = setup_hidden_scene(
    "Fail_Clone_Source", "Fail_Clone_Mat")
baseline_objects = len(bpy.data.objects)
baseline_images = len(bpy.data.images)
baseline_materials = len(bpy.data.materials)

original_clone = bp._clone_material_with_bake_target


def fail_clone(*args, **kwargs):
    raise RuntimeError("simulated clone failure")


bp._clone_material_with_bake_target = fail_clone
try:
    result = bp.bake_material_projection(
        scene=scene,
        material=material,
        bake_resolution=64,
        auto_unwrap=False,
    )
finally:
    bp._clone_material_with_bake_target = original_clone

chk("bake reports failure", result["success"] is False)
chk("clone failure is reported",
    "simulated clone failure" in result["message"], result["message"])
chk("temporary objects removed",
    len(bpy.data.objects) == baseline_objects,
    "%d -> %d" % (baseline_objects, len(bpy.data.objects)))
chk("temporary images removed",
    len(bpy.data.images) == baseline_images,
    "%d -> %d" % (baseline_images, len(bpy.data.images)))
chk("temporary materials removed",
    len(bpy.data.materials) == baseline_materials,
    "%d -> %d" % (baseline_materials, len(bpy.data.materials)))
chk("source object survived",
    bpy.data.objects.get("Fail_Clone_Source") is not None)

print()
print("=" * 64)
print("PASS %d / FAIL %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("FAILED:", FAIL)
print("=" * 64)

sys.exit(1 if FAIL else 0)
