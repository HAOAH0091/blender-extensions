# 烘焙隐藏对象修复 + 弹窗中文化 · 验收对照表

- **版本号**：`(3, 0, 6)`
- **日期**：2026-11-11
- **改动文件**：`bake_visibility.py`（新增）、`bake_pipeline.py`、
  `uv_utils.py`、`__init__.py`、`translations.py`
- **回归脚本**：`_dev/test_bake_hidden_visibility.py`、
  `_dev/test_bake_pipeline_hidden.py`、`_dev/test_bake_dialog_i18n.py`

---

## 一、根因

`obj.copy()` 复制烘焙副本时会继承源对象的 `hide_viewport` /
`hide_render` / `hide_select`。副本在视口里不可选，
`select_set()` 静默失败，随后 `bpy.ops.object.mode_set()` 报
`Context missing active object`。

另一个容易混淆的点：`collection.objects.link(obj)` 之后，
`ViewLayer.objects` 不会立即刷新，必须调用 `view_layer.update()`，
否则刚链进来的对象会被误判为“不在当前视图层”。

## 二、改法

- 新增 `bake_visibility.py`，统一统计视口隐藏、渲染隐藏、不可选择、
  视图层排除、缺少 UV。
- 复制对象后、UV 展开前，只恢复**副本**的可见性；原对象保持不变。
- UV 展开使用 `temp_override` + `try/finally`，失败不会卡在 Edit Mode。
- 烘焙失败自动清理本次创建的副本 / 材质 / 图片；烘焙已成功后不清。
- 弹窗明确范围（单个对象 / 全部材质使用者），并提示隐藏、排除、不可选择、
  缺 UV 的数量。
- 弹窗正文、属性标签、成功/失败提示接入简繁中文；标题显式传
  `invoke_props_dialog(title=...)`，不依赖未翻译的 `bl_label`。

## 三、验收结果

| 场景 | 预期 | 实测 | 判定 |
|---|---|---|---|
| 隐藏源对象 → 烘焙 | 副本可见，烘焙成功 | 64×64 Cycles 完整烘焙成功 | ✅ |
| 烘焙后原对象 | 保持隐藏、不改材质 | `hide_viewport/hide_render/hide_select` 全部保持 | ✅ |
| 集合被当前视图层排除 | 副本仍可展开 UV | 副本链接到主集合后可操作 | ✅ |
| UV 步骤失败 | 报可操作错误 + 清理副本 | 无 `.001` 残留，源对象仍在 | ✅ |
| 材质克隆失败 | 清理副本 / 图片 / 材质 | 数据块数量恢复到烘焙前 | ✅ |
| 中文界面 | 弹窗全中文 | 58 条文案全部命中简繁词条 | ✅ |
| 英文界面 | 弹窗全英文 | `en_US` 下所有文案保持英文 | ✅ |
| 弹窗标题 | 跟随语言 | 简体「烘焙材质投影」/ 繁体「烘焙材質投影」 | ✅ |

## 四、跑法

```bat
<blender> --background --factory-startup --python _dev\test_bake_hidden_visibility.py
<blender> --background --factory-startup --python _dev\test_bake_pipeline_hidden.py
<blender> --background --factory-startup --python _dev\test_bake_dialog_i18n.py
```

结果：27 + 19 + 15 = **61 PASS / 0 FAIL**；
现有 `test_register.py`（7 PASS）与 `test_hide_update_button.py`
（15 PASS）无回归。

> 语言相关注意：`pgettext_iface()` 受
> `Preferences > Interface > Translation > Interface` 勾选影响；
> 关闭后即使 `locale == zh_HANS`，内置 `Cancel` 也会返回英文。
