"""Regression: bake dialog follows Blender's UI language.

Checks:
  1. Every ``_()`` string in the bake dialog (draw/invoke/execute) exists in
     both zh_CN and zh_TW catalogs.
  2. Runtime language switching works: zh_HANS -> Chinese, en_US -> English,
     then back to zh_HANS -> Chinese again.

Run:
  blender --background --factory-startup --python _dev/test_bake_dialog_i18n.py
"""

import ast
import bpy
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_bake_i18n_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)

trans = sys.modules[PKG + ".translations"]

PASS = []
FAIL = []


def chk(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %-56s %s" % ("PASS" if cond else "FAIL", name, detail))


def has_cjk(text):
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def collect_msgids():
    source = open(
        os.path.join(PKG_DIR, "__init__.py"), encoding="utf-8").read()
    tree = ast.parse(source)
    cls = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef)
        and node.name == "CompifyBakeMaterialProjection")

    msgids = set()

    for method_name in ("invoke", "draw", "execute"):
        method = next(
            node for node in cls.body
            if isinstance(node, ast.FunctionDef)
            and node.name == method_name)
        for node in ast.walk(method):
            if (isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name)
                    and node.func.id == "_"
                    and node.args
                    and isinstance(node.args[0], ast.Constant)
                    and isinstance(node.args[0].value, str)):
                msgids.add(node.args[0].value)

    # Property labels and tooltips shown in the dialog.
    for node in ast.walk(cls):
        if not isinstance(node, ast.Call):
            continue
        if not (isinstance(node.func, ast.Attribute)
                and node.func.attr in {
                    "IntProperty", "FloatProperty", "BoolProperty",
                    "StringProperty"}):
            continue
        for kw in node.keywords:
            if (kw.arg in {"name", "description"}
                    and isinstance(kw.value, ast.Constant)
                    and isinstance(kw.value.value, str)):
                msgids.add(kw.value.value)

    return msgids


def title_is_wired_to_translation():
    source = open(
        os.path.join(PKG_DIR, "__init__.py"), encoding="utf-8").read()
    tree = ast.parse(source)
    cls = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef)
        and node.name == "CompifyBakeMaterialProjection")
    invoke = next(
        node for node in cls.body
        if isinstance(node, ast.FunctionDef) and node.name == "invoke")

    for node in ast.walk(invoke):
        if not (isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "invoke_props_dialog"):
            continue
        for kw in node.keywords:
            if kw.arg != "title":
                continue
            if (isinstance(kw.value, ast.Call)
                    and isinstance(kw.value.func, ast.Name)
                    and kw.value.func.id == "_"
                    and kw.value.args
                    and isinstance(kw.value.args[0], ast.Constant)
                    and kw.value.args[0].value == "Bake Material Projection"):
                return True
    return False


PIPELINE_MSGIDS = {
    "Objects ({})",
    "No objects use this material",
    "No objects match the specified filter",
    "Material has no Camera Project node group",
    "Internal error: image/object count mismatch ({} vs {})",
    "Failed to clone material for {}",
    "Internal error: failed to fix render visibility",
    "Internal error: bake copies are excluded from the current view layer",
    "Could not enter Edit Mode for UV unwrap: {}. The object is hidden in"
    " the viewport or excluded from the current view layer.",
    "Baking failed: {}",
    "Baked {} object(s)",
}


print("=" * 68)
print("[1] catalog completeness")
print("=" * 68)

chk("dialog title passes translated text", title_is_wired_to_translation())
msgids = collect_msgids() | PIPELINE_MSGIDS
for locale in ("zh_CN", "zh_TW"):
    catalog = trans.translations_dict[locale]
    missing = sorted(msgid for msgid in msgids if ("*", msgid) not in catalog)
    chk("%s catalog covers %d dialog strings" % (locale, len(msgids)),
        not missing, "missing: %s" % missing)

print()
print("=" * 68)
print("[2] runtime language switching")
print("=" * 68)

mod.register()
try:
    bpy.context.preferences.view.language = "zh_HANS"
    chk("locale switched to Simplified Chinese",
        bpy.app.translations.locale == "zh_HANS",
        bpy.app.translations.locale)

    untranslated = []
    for msgid in sorted(msgids):
        value = bpy.app.translations.pgettext_iface(msgid)
        if value == msgid or not has_cjk(value):
            untranslated.append((msgid, value))
    chk("all dialog strings become Chinese", not untranslated,
        str(untranslated[:5]))

    samples = {
        "Bake Material Projection": "烘焙材质投影",
        "Material:  {}": "材质：  {}",
        "Will create: {} new object(s)": "将创建 {} 个新对象",
        "Smart UV Project Settings": "智能 UV 投影设置",
        "Original objects will NOT be modified.": "原对象不会被修改。",
    }
    for msgid, expected in samples.items():
        actual = bpy.app.translations.pgettext_iface(msgid)
        chk("check '%s'" % msgid, actual == expected,
            "actual=%r expected=%r" % (actual, expected))

    bpy.context.preferences.view.language = "en_US"
    chk("locale switched back to English",
        bpy.app.translations.locale == "en_US",
        bpy.app.translations.locale)
    english_ok = all(
        bpy.app.translations.pgettext_iface(msgid) == msgid
        for msgid in samples)
    chk("dialog strings return to English", english_ok)

    bpy.context.preferences.view.language = "zh_HANS"
    chk("switch back to Chinese works at runtime",
        bpy.app.translations.pgettext_iface("Bake check") == "烘焙前检查",
        bpy.app.translations.pgettext_iface("Bake check"))

    bpy.context.preferences.view.language = "zh_HANT"
    traditional = bpy.app.translations.pgettext_iface(
        "Material:  {}")
    chk("Traditional Chinese catalog is active",
        traditional == "材質：  {}", traditional)
    chk("Traditional title is translated",
        bpy.app.translations.pgettext_iface(
            "Bake Material Projection") == "烘焙材質投影",
        bpy.app.translations.pgettext_iface("Bake Material Projection"))
finally:
    bpy.context.preferences.view.language = "en_US"
    mod.unregister()

print()
print("=" * 68)
print("PASS %d / FAIL %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("FAILED:", FAIL)
print("=" * 68)

sys.exit(1 if FAIL else 0)
