"""渲染可视验证：移相机时投影材质是否还贴合网格。

3 张对比：
  01_initial      初始
  02_nolock_moved 移相机·未锁定（网格世界不动 → 图案应在网格上滑动）
  03_locked_moved 锁定后移相机（网格跟随 → 图案应与 01 相对网格一致）
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]

scene = bpy.context.scene
cam = bpy.data.objects["Camera"]
meshes = [o for o in scene.objects if o.type == "MESH"]
OUT = os.path.join(IDES_HOME, "workspace", "_plock_render")
os.makedirs(OUT, exist_ok=True)

# UV Adjust 组名（让目标识别生效）
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam.data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

# ── footage 图：棋盘 + 同心环，移位时图案滑动肉眼可辨 ──
W = H = 256
img = bpy.data.images.new("Footage", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        checker = ((x // 16) + (y // 16)) % 2
        r = math.hypot(x - W / 2, y - H / 2)
        ring = 1.0 if (int(r) // 12) % 2 == 0 else 0.0
        px[i] = 0.85 if checker else 0.15
        px[i + 1] = ring
        px[i + 2] = 0.9 if (x // 8) % 2 == 0 else 0.1
        px[i + 3] = 1.0
img.pixels.foreach_set(px)
img.pack()

# ── 第一次跑只建 TexCoord(Camera)，没有 Camera Project 组 ──
# 结果：lock_group 返回成功，但明确警告「图案冻结未启用（该相机还没有
# Camera Project 投影组）」，锁定后画面照样滑动 —— 这是【产品正确的降级行为】，
# 不是 bug。所以这里改成建真组，让主路径可测；降级路径另外单独断一条。
#
# 投影材质：Camera Project 组输出 → Image → Emission
ng_mod = sys.modules[PKG + ".node_groups"]
# ensure_camera_project_group 要的是【相机对象】，不是 cam.data（内部自己取 .data）
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
print("PROJECT_GROUP:", grp.name if grp else None)

mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gnode = nt.nodes.new("ShaderNodeGroup")
gnode.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage")
tex.image = img
emit = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gnode.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], emit.inputs["Color"])
nt.links.new(emit.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

scene.render.resolution_x = 512
scene.render.resolution_y = 512
# Blender 5.x：先设 media_type=IMAGE，file_format 才有 PNG（否则 enum 里只有 FFMPEG）
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
try:
    scene.render.engine = "BLENDER_EEVEE_NEXT"
except Exception:
    scene.render.engine = "CYCLES"
if scene.render.engine == "CYCLES":
    scene.cycles.samples = 16
    scene.cycles.device = "CPU"
print("ENGINE=%s" % scene.render.engine)


def shot(name):
    scene.render.filepath = os.path.join(OUT, name)
    bpy.ops.render.render(write_still=True)
    print("SHOT_OK %s" % name)


P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if c else "FAIL", n, d))


def read_png_pixels(path):
    """回读渲染出的 PNG，返回 (宽, 高, 像素 list)。用 Blender 自己加载，不引第三方库。

    只用平均色差做判据太粗，所以同时算「逐像素差异比例」：
    两个画面同位置像素差 > 阈值 的比例。这才是「画面变了没」的可量化判据。
    """
    img = bpy.data.images.load(path, check_existing=False)
    w, h = img.size
    px = list(img.pixels[:])
    bpy.data.images.remove(img)
    return w, h, px


def diff_ratio(pa, pb, thr=0.02):
    """同尺寸像素数组中，差异超过 thr 的分量比例（0~1）。"""
    n = min(len(pa), len(pb))
    if n == 0:
        return 1.0
    bad = 0
    step = 4  # 只看 RGB 里的 R，sample 加速；命中率足够判「变了没」
    for i in range(0, n, step):
        if abs(pa[i] - pb[i]) > thr:
            bad += 1
    return bad / (n / step)


start_loc = tuple(cam.location)

p1 = os.path.join(OUT, "01_initial.png")
shot("01_initial.png")

# 未锁定移相机
cam.location.x += 3.0
bpy.context.view_layer.update()
p2 = os.path.join(OUT, "02_nolock_moved.png")
shot("02_nolock_moved.png")

# 回位 → 锁定 → 移相机
cam.location = start_loc
bpy.context.view_layer.update()
r = plock.lock_group(scene, cam)
print("LOCK:", r["success"], r["message"])
cam.location.x += 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
p3 = os.path.join(OUT, "03_locked_moved.png")
shot("03_locked_moved.png")

# ── 断言：用回读的像素判定，不看截图 ──
print()
chk("锁定成功", bool(r["success"]), r["message"])

for name, p in (("01", p1), ("02", p2), ("03", p3)):
    chk("渲染产物 %s 存在且非空" % name, os.path.exists(p) and os.path.getsize(p) > 1000,
        "%d bytes" % (os.path.getsize(p) if os.path.exists(p) else 0))

w1, h1, px1 = read_png_pixels(p1)
w2, h2, px2 = read_png_pixels(p2)
w3, h3, px3 = read_png_pixels(p3)
chk("三张图尺寸一致", w1 == w2 == w3 and h1 == h2 == h3, "%dx%d / %dx%d / %dx%d" % (w1, h1, w2, h2, w3, h3))

# ── 判据的口径（同一个坑我踩了两次，写清楚免得再犯）──────────────
#
# 「构图保持」≠「画面不变」。锁定后横移相机，各层按 Δ(1−k) 走，
# 整个构图会【整体平移】——所以 03 和 01 的逐像素差异必然很大（实测 15.56%）。
# 我第一版拿「画面接近初始图」当判据，把正确的行为判成了 FAIL。
#
# 正确的分工：
#   像素层：只能判「有没有剧烈变化」（未锁定 vs 初始），不能判「构图保持」。
#   几何层：用 Blender 官方投影 world_to_camera_view 算每个顶点的屏幕位移，
#           所有顶点位移相同 ⇒ 构图保持。这是严格定义，也是 test_frozen 用的判据。
#
# 渲染测试的价值 = 出图给人看 + 几何量兜底，不是拿像素做构图断言。

d_nolock = diff_ratio(px1, px2)
chk("对照（未锁定）移相机后画面确实变了", d_nolock > 0.02,
    "差异像素占比 %.2f%% —— 图案在网格上滑走，被拉成条纹" % (d_nolock * 100))

# 锁定后画面也必然不同（整体平移），但差异形态应是「平移」而不是「拉扯」。
# 这里只断「确实还在动」，真正判「构图保持」交给下面几何量。
d_lock = diff_ratio(px1, px3)
chk("锁定后画面同样位移（整体平移，非原地不动）", d_lock > 0.02,
    "差异像素占比 %.2f%%" % (d_lock * 100))

# ── 几何量：构图保持的严格判据 ──
import bpy_extras.object_utils  # noqa: E402

MESH = meshes[0]


def screen_pts():
    bpy.context.view_layer.update()
    pts = []
    n = len(MESH.data.vertices)
    for idx in range(min(n, 40)):  # 立方体只有 8 个顶点，全取
        co = MESH.matrix_world @ MESH.data.vertices[idx].co
        s = bpy_extras.object_utils.world_to_camera_view(scene, cam, co)
        pts.append((s.x, s.y))
    return pts


# ⚠️⚠️ 这条判据踩了两个坑，都记在这里，别再犯：
#
# 坑 1（采样时机）：上面渲染三步已经把相机移了两次，state 里的
#   locked_matrix / applied_dolly 还停在上一次的位置，直接接着采会拿到错位基准。
#   ⇒ 采样前 reset + 重新 lock。
#
# 坑 2（移动方向，这个才是主因）：默认场景的 Camera 旋转是
#   (63.56°, 0, 46.69°)，forward = (-0.6516, 0.6142, -0.4453)。
#   所以 `cam.location.x += 3.0`（沿【世界 +X】）里
#       world+X · forward = -0.6516   ← 65% 是「沿视线推进」
#       world+X · right   = +0.6859   ← 只有 69% 是真横移
#   即：这不是纯横移，相机同时被推近了 1.95 单位。
#   而「所有顶点屏幕位移相同」只在【纯横移】下成立 —— 前提不成立，判据必红。
#
#   ⇒ 必须沿相机自己的 right 轴移动，剔除沿视线分量。
#     （diag_render_truth.py 用正对相机 (90°,0,0) 复现同一逻辑，
#       实测屏幕位移极差 2.98e-08、世界位移与 Δ(1−k) 误差 2.95e-07。）
plock.reset_group(scene, cam)
cam.location = start_loc
bpy.context.view_layer.update()
r2 = plock.lock_group(scene, cam)
print("RE-LOCK:", r2["success"], r2["message"])
bpy.context.view_layer.update()
G0 = screen_pts()

# 沿相机 right 轴移动（纯横移，不混入沿视线分量）
import mathutils  # noqa: E402

MOVE = 3.0
cam_right = (cam.matrix_world.to_3x3() @ mathutils.Vector((1.0, 0.0, 0.0))).normalized()
cam_forward = (cam.matrix_world.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))).normalized()
dot_fwd = cam_right.dot(cam_forward)
print("相机 right·forward = %.6f（应为 0，证明是纯横移）" % dot_fwd)
cam.location = tuple(mathutils.Vector(start_loc) + cam_right * MOVE)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
bpy.context.view_layer.update()
G1 = screen_pts()

shifts = [(b[0] - a[0], b[1] - a[1]) for a, b in zip(G0, G1)]
sx = [s[0] for s in shifts]
sy = [s[1] for s in shifts]
spread_x = max(sx) - min(sx)
spread_y = max(sy) - min(sy)
chk("锁定后移相机：所有顶点屏幕位移相同（构图保持）",
    spread_x < 1e-5 and spread_y < 1e-5,
    "x 极差 %.3e  y 极差 %.3e  位移 (%.6f, %.6f)"
    % (spread_x, spread_y, sum(sx) / len(sx), sum(sy) / len(sy)))

print()
print("=" * 88)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("RENDER_DONE %s" % OUT)
