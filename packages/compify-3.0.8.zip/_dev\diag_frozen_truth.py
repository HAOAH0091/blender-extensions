"""诊断：test_frozen 里「锁定后移相机画面没冻结」到底真不真。

疑点：对照组（未锁定）画面变化 0.1330，锁定后变化 0.1200 —— 几乎一样大，
      说明网格压根没跟着相机走。但 test_zoom_dolly 的同类判据过了（1.7e-08）。
      两者差异：dolly 测【改焦距】，frozen 测【移相机位置】。

本脚本只打印，不下结论。逐项对比 C（锁定瞬间）与 D（移相机+handler 之后）：
  - 每个球的世界坐标（看网格到底动没动）
  - 每个球的屏幕坐标
  - 相机自身位置
  - state 里的 ref_depth / locked_depth
分别在 handler 之后【补一次 view_layer.update()】再采样一遍，
用来区分「handler 没生效」和「采样时机太早」。
"""
import importlib.util
import math
import os
import sys

import bpy
import bpy_extras.object_utils

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_diag_frozen"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("Cam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

for i, (x, y, z, r) in enumerate([(-5.0, 16.0, 0.0, 1.15), (-2.5, 16.0, 0.0, 1.15),
                                  (0.0, 16.0, 0.0, 1.15), (2.5, 16.0, 0.0, 1.15),
                                  (5.0, 16.0, 0.0, 1.15)]):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
    bpy.ops.object.shade_smooth()
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gnode = nt.nodes.new("ShaderNodeGroup")
gnode.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage")
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gnode.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)
    nm = "UV Adjust | %s | %s" % (o.data.name, cam_data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

print("TARGETS:", len(plock.get_lock_targets(scene, cam)))


def snap(tag):
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    rows = []
    for o in meshes:
        co0 = o.matrix_world @ o.data.vertices[0].co
        s = bpy_extras.object_utils.world_to_camera_view(scene, cam, co0)
        rows.append((o.name, tuple(round(v, 5) for v in co0), round(s.x, 6), round(s.y, 6)))
    st = plock.get_state(scene, cam)
    print("--- %s ---" % tag)
    print("   cam loc  :", tuple(round(v, 5) for v in cam.location))
    print("   ref_depth:", st.get("ref_depth"))
    print("   state keys:", sorted(st.keys()))
    for r in rows:
        print("   %-6s world=%s  screen=(%.6f, %.6f)" % r)
    return rows


X0 = cam.location.x
DX = 2.0

cam.location.x = X0
bpy.context.view_layer.update()
r = plock.lock_group(scene, cam)
print("LOCK:", r["success"], r["message"])
snap("C 锁定瞬间")

print("\n>>> 移相机 +2.0，调 handler <<<")
cam.location.x = X0 + DX
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
snap("D handler 之后（未额外 update）")

bpy.context.view_layer.update()
snap("D' handler 之后 + 手动 view_layer.update()")

# 再跑一次 handler（看是不是需要两拍）
plock.parallax_lock_update_handler(scene)
snap("D'' 又跑一次 handler")

print("\nDIAG_FROZEN_DONE")
