"""Regression: bake uses fast temporary Cycles settings and restores them.

Run:
  blender --background --factory-startup --python _dev/test_bake_speed_settings.py
"""

import bpy
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_bake_speed_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)

bp = sys.modules[PKG + ".bake_pipeline"]

PASS = []
FAIL = []


def chk(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %-58s %s" % ("PASS" if cond else "FAIL", name, detail))


def setup_scene(engine):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = engine

    mesh = bpy.data.meshes.new("Speed_Mesh")
    mesh.from_pydata(
        [(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)],
        [], [(0, 1, 2, 3)])
    mesh.update()
    obj = bpy.data.objects.new("Speed_Source", mesh)
    scene.collection.objects.link(obj)

    cam_data = bpy.data.cameras.new("Speed_CamData")
    cam = bpy.data.objects.new("Speed_Cam", cam_data)
    scene.collection.objects.link(cam)
    scene.camera = cam

    group = bpy.data.node_groups.new(
        "Camera Project | Speed_CamData", "ShaderNodeTree")
    texcoord = group.nodes.new("ShaderNodeTexCoord")
    texcoord.object = cam

    mat = bpy.data.materials.new("Speed_Mat")
    mat.use_nodes = True
    group_node = mat.node_tree.nodes.new("ShaderNodeGroup")
    group_node.node_tree = group
    obj.data.materials.append(mat)
    return scene, obj, mat


def make_user_settings(scene, engine='CYCLES'):
    c = scene.cycles
    scene.render.engine = engine
    c.samples = 64
    c.use_denoising = False
    if hasattr(c, "denoising_quality"):
        c.denoising_quality = 'HIGH'
    if hasattr(c, "denoising_prefilter"):
        c.denoising_prefilter = 'ACCURATE'


def snapshot(scene):
    c = scene.cycles
    return (
        scene.render.engine,
        c.samples,
        c.use_denoising,
        getattr(c, "denoising_quality", None),
        getattr(c, "denoising_prefilter", None),
    )


print("=" * 68)
print("[1] context manager forces fast settings, restores user settings")
print("=" * 68)

scene, obj, mat = setup_scene('BLENDER_EEVEE')
make_user_settings(scene, 'BLENDER_EEVEE')
before = snapshot(scene)

with bp._temporary_bake_settings(scene, samples=1):
    during = snapshot(scene)
    chk("engine forced to CYCLES", during[0] == 'CYCLES', during[0])
    chk("samples forced to 1", during[1] == 1, str(during[1]))
    chk("denoising forced on", during[2] is True, str(during[2]))
    if hasattr(scene.cycles, "denoising_quality"):
        chk("denoise quality forced to BALANCED",
            during[3] == 'BALANCED', str(during[3]))
    if hasattr(scene.cycles, "denoising_prefilter"):
        chk("denoise prefilter forced to FAST",
            during[4] == 'FAST', str(during[4]))

after = snapshot(scene)
chk("engine restored", after[0] == before[0], f"{before[0]} -> {after[0]}")
chk("samples restored", after[1] == before[1], f"{before[1]} -> {after[1]}")
chk("denoising restored", after[2] == before[2], f"{before[2]} -> {after[2]}")
chk("denoise quality restored", after[3] == before[3],
    f"{before[3]} -> {after[3]}")
chk("denoise prefilter restored", after[4] == before[4],
    f"{before[4]} -> {after[4]}")

print()
print("=" * 68)
print("[2] exception inside the bake still restores settings")
print("=" * 68)

scene, obj, mat = setup_scene('BLENDER_EEVEE')
make_user_settings(scene, 'BLENDER_EEVEE')
before = snapshot(scene)
try:
    with bp._temporary_bake_settings(scene, samples=1):
        raise RuntimeError("simulated bake failure")
except RuntimeError:
    pass
after = snapshot(scene)
chk("settings restored after exception", after == before,
    f"{before} -> {after}")

print()
print("=" * 68)
print("[3] full bake leaves the user's render settings untouched")
print("=" * 68)

scene, obj, mat = setup_scene('CYCLES')
make_user_settings(scene)
before = snapshot(scene)
result = bp.bake_material_projection(
    scene=scene,
    material=mat,
    bake_resolution=64,
    auto_unwrap=False,
)
chk("bake reports success", result["success"] is True, result["message"])
after = snapshot(scene)
chk("engine restored after full bake", after[0] == before[0])
chk("samples restored after full bake", after[1] == before[1],
    f"{before[1]} -> {after[1]}")
chk("denoising restored after full bake", after[2] == before[2])
chk("denoise quality restored after full bake", after[3] == before[3])
chk("denoise prefilter restored after full bake", after[4] == before[4])

print()
print("=" * 68)
print("RESULT: %d PASS, %d FAIL" % (len(PASS), len(FAIL)))
if FAIL:
    for name in FAIL:
        print("  FAILED:", name)
    sys.exit(1)
print("ALL PASS")

