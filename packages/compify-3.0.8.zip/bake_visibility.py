"""Visibility diagnostics and temporary-unhide helpers for baking.

The bake pipeline copies source objects and runs Edit Mode operators on the
copies.  A copy inherits ``hide_viewport`` / ``hide_render`` / ``hide_select``
from its source, so a hidden source can make the copy unpickable and
``bpy.ops.object.mode_set`` fails with a missing active object.

These helpers only touch the copies passed in; callers are responsible for
never passing original objects.
"""

import bpy


ISSUE_HIDE_VIEWPORT = "hide_viewport"
ISSUE_HIDE_RENDER = "hide_render"
ISSUE_HIDE_SELECT = "hide_select"
ISSUE_NOT_IN_VIEW_LAYER = "not_in_view_layer"


def get_scene_view_layer(scene=None):
    """Return the view layer that belongs to *scene*.

    Prefer the current context view layer so operators act on what the user
    sees.  Fall back to the scene's first view layer when the context points
    at another scene (background scripts).
    """
    try:
        if scene is None or bpy.context.scene == scene:
            view_layer = bpy.context.view_layer
            if view_layer is not None:
                return view_layer
    except (AttributeError, RuntimeError):
        pass

    if scene is not None:
        try:
            if len(scene.view_layers):
                return scene.view_layers[0]
        except AttributeError:
            pass
    return None


def is_in_view_layer(obj, view_layer=None):
    """True when *obj* is evaluated in *view_layer* (not collection-excluded)."""
    view_layer = view_layer or get_scene_view_layer()
    if view_layer is None:
        return False
    try:
        return obj.name in view_layer.objects
    except (AttributeError, ReferenceError):
        return False


def visibility_issues(obj, view_layer=None):
    """Return a list of things that can block selecting/baking *obj*."""
    issues = []
    if getattr(obj, "hide_viewport", False):
        issues.append(ISSUE_HIDE_VIEWPORT)
    if getattr(obj, "hide_render", False):
        issues.append(ISSUE_HIDE_RENDER)
    if getattr(obj, "hide_select", False):
        issues.append(ISSUE_HIDE_SELECT)

    view_layer = view_layer or get_scene_view_layer()
    if view_layer is not None and not is_in_view_layer(obj, view_layer):
        issues.append(ISSUE_NOT_IN_VIEW_LAYER)
    return issues


def summarize_visibility(objects, view_layer=None):
    """Count visibility and UV problems for a list of objects.

    Only mesh objects are counted.  ``with_issues`` counts objects with at
    least one visibility problem, so one object can appear in several buckets.
    """
    view_layer = view_layer or get_scene_view_layer()
    summary = {
        "total": 0,
        "hide_viewport": 0,
        "hide_render": 0,
        "hide_select": 0,
        "not_in_view_layer": 0,
        "no_uv": 0,
        "with_issues": 0,
    }

    for obj in objects:
        if getattr(obj, "type", None) != "MESH":
            continue
        summary["total"] += 1
        issues = visibility_issues(obj, view_layer)
        for issue in issues:
            if issue in summary:
                summary[issue] += 1
        if issues:
            summary["with_issues"] += 1
        if not (obj.data and obj.data.uv_layers.active):
            summary["no_uv"] += 1

    return summary


def prepare_object_for_bake(obj, view_layer=None, collection=None):
    """Make a bake *copy* selectable, renderable and visible.

    Returns a list of applied fixes (empty when the object was already fine).
    """
    view_layer = view_layer or get_scene_view_layer()
    fixed = []
    needs_layer_update = False

    if view_layer is not None and not is_in_view_layer(obj, view_layer):
        target = collection or view_layer.layer_collection.collection
        try:
            if obj.name not in target.objects:
                target.objects.link(obj)
                fixed.append(ISSUE_NOT_IN_VIEW_LAYER)
            needs_layer_update = True
        except (AttributeError, RuntimeError):
            pass

    # Linking a datablock does not refresh ViewLayer.objects immediately.
    if needs_layer_update:
        try:
            view_layer.update()
        except (AttributeError, RuntimeError):
            pass

    for attr in (ISSUE_HIDE_VIEWPORT, ISSUE_HIDE_RENDER, ISSUE_HIDE_SELECT):
        try:
            if getattr(obj, attr, False):
                setattr(obj, attr, False)
                fixed.append(attr)
        except (AttributeError, RuntimeError):
            pass

    if view_layer is not None and is_in_view_layer(obj, view_layer):
        try:
            if obj.hide_get(view_layer=view_layer):
                obj.hide_set(False, view_layer=view_layer)
                fixed.append("hidden_in_view_layer")
        except (RuntimeError, TypeError):
            pass

    return fixed


def describe_objects(objects, limit=3):
    """Compact object-name list for error messages."""
    names = [obj.name for obj in objects[:limit]]
    text = ", ".join(names)
    remaining = len(objects) - limit
    if remaining > 0:
        text += f" (+{remaining} more)"
    return text
