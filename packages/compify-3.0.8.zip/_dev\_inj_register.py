"""后向注入验证：证明 test_register.py 的断言有判别力（不是恒真/恒假）。

背景：写这几条断言时我连续错了两次——
  ① 按 COMPIFY_PT_ 前缀在 bpy.types 里找面板 —— 恒 0，永远 FAIL（假红）
  ② hasattr(bpy.types, "CompifyUVAdjust3DPanel") —— register 之后仍 False，
     也永远 FAIL（假红）
  ③ 正解：bpy.types.Panel.bl_rna_get_subclass_py(bl_idname)

假红至少会立刻暴露，假绿才致命。这里验证第 ③ 种写法真的能区分：

  A 未 register  →  panel_cls() 必须是 None   （断言在这种状态下该红）
  B register 后  →  panel_cls() 必须非 None   （断言该绿）
  C unregister 后 →  panel_cls() 必须又变 None （断言该红）

同理验 operator 那条（hasattr 在 operator 上是可用的）和 handler 那条。
三条都必须在两种状态间翻转，才说明断言有效。
"""
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_inj_register"
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)

spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)

import bpy  # noqa: E402

PANEL_ID = "VIEW3D_PT_compify_uv_adjust"
plock = sys.modules[PKG + ".compify_parallax_lock"]
h = plock.parallax_lock_update_handler

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if c else "FAIL", n, d))


def state():
    return (
        bpy.types.Panel.bl_rna_get_subclass_py(PANEL_ID),
        hasattr(bpy.types, "COMPIFY_OT_parallax_lock_toggle"),
        h in bpy.app.handlers.depsgraph_update_post,
    )


# ── A 未注册 ──
panel0, op0, h0 = state()
print("A 未注册:  panel=%s op=%s handler=%s" % (panel0, op0, h0))
chk("注入A：未注册时面板查不到（断言会红）", panel0 is None)
chk("注入A：未注册时 operator 查不到（断言会红）", op0 is False)
chk("注入A：未注册时 handler 没挂（断言会红）", h0 is False)

# ── B 注册后 ──
mod.register()
panel1, op1, h1 = state()
print("B 已注册:  panel=%s op=%s handler=%s" % (panel1, op1, h1))
chk("注入B：注册后面板查得到（断言会绿）", panel1 is not None)
chk("注入B：注册后 operator 查得到（断言会绿）", op1 is True)
chk("注入B：注册后 handler 挂着（断言会绿）", h1 is True)

# ── C 注销后 ──
mod.unregister()
panel2, op2, h2 = state()
print("C 已注销:  panel=%s op=%s handler=%s" % (panel2, op2, h2))
chk("注入C：注销后面板又查不到（断言会红）", panel2 is None)
chk("注入C：注销后 operator 又查不到（断言会红）", op2 is False)
chk("注入C：注销后 handler 又摘掉（断言会红）", h2 is False)

print()
print("=" * 78)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("VERDICT: 三个探针都在 True/False 之间翻转 ⇒ test_register 的断言有判别力，"
      "不是恒真也不是恒假。")
print("INJ_REGISTER_DONE")
