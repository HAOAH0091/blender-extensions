"""诊断：test_render_verify 里「所有顶点屏幕位移不一致（4.8e-02）」到底是不是真 bug。

两个测试的差异：
  test_frozen       : 5 个球，每个球半径 1.15，顶点深度 22.0~23.15，屏幂位移极差 5.96e-08 ✓
  test_render_verify: 1 个立方体，8 个顶点，厚度跨 12.967±?，屏幂位移极差 4.8e-02 ✗

疑点清单（逐个排除，不猜）：
  A. 立方体顶点深度跨度大 → 世界位移按 Δ(1−k) 本就不同，但屏幕位移应当一致
  B. test_render_verify 的流程里相机被移了两次（第 3 步已锁+移动，第 4 步又移回），
     state 里的 dolly/locked_matrix 可能已经和 ref 对不上 ⇒ 采样时机污染
  C. 场景里的 Camera 是 factory-startup 自带的，可能带 shift / 非 50mm 等差异

本脚本干净地重建一个立方体场景，一次锁定、一次移动，逐顶点打印
depth / k / 世界位移 / 理论值 / 屏幕位移，看差在哪。
"""
import importlib.util
import math
import os
import sys

import bpy
import bpy_extras.object_utils
import mathutils

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_diag_render"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene

cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cd.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cd)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

bpy.ops.mesh.primitive_cube_add(size=2.0, location=(0.0, 16.0, 0.0))
cube = bpy.context.active_object
cube.name = "Cube"
bpy.context.view_layer.update()

cam_data = cam.data
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage")
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
cube.data.materials.clear()
cube.data.materials.append(mat)
nm = "UV Adjust | %s | %s" % (cube.data.name, cam_data.name)
if nm not in bpy.data.node_groups:
    bpy.data.node_groups.new(nm, "ShaderNodeTree")

print("TARGETS:", len(plock.get_lock_targets(scene, cam)))


def sample():
    bpy.context.view_layer.update()
    fwd = (cam.matrix_world.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))).normalized()
    cpos = cam.matrix_world.translation
    rows = []
    for idx in range(len(cube.data.vertices)):
        co = cube.matrix_world @ cube.data.vertices[idx].co
        s = bpy_extras.object_utils.world_to_camera_view(scene, cam, co)
        rows.append({
            "i": idx, "co": co.copy(), "sx": s.x, "sy": s.y,
            "depth": (co - cpos).dot(fwd),
        })
    return rows


X0 = cam.location.x
DX = 3.0

r = plock.lock_group(scene, cam)
print("LOCK:", r["success"], r["message"])
st = plock.get_state(scene, cam)
REF = float(st["ref_depth"])
print("ref_depth:", REF)
print("state:", {k: v for k, v in st.items() if k != "objects"})

S0 = sample()
cam.location.x = X0 + DX
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
S1 = sample()

print("\n%-3s %8s %8s %12s %12s %10s %10s %10s %10s" % (
    "v", "depth", "k", "world_dx", "theory_dx", "sx0", "sx1", "dscreen_x", "dscreen_y"))
worst_d = 0.0
worst_w = 0.0
for a, b in zip(S0, S1):
    k = a["depth"] / REF
    wx = b["co"].x - a["co"].x
    th = DX * (1.0 - k)
    dsx = b["sx"] - a["sx"]
    dsy = b["sy"] - a["sy"]
    worst_d = max(worst_d, abs(th - wx))
    print("%-3d %8.4f %8.5f %12.7f %12.7f %10.7f %10.7f %10.7f %10.7f" % (
        a["i"], a["depth"], k, wx, th, a["sx"], b["sx"], dsx, dsy))

dsx_all = [b["sx"] - a["sx"] for a, b in zip(S0, S1)]
dsy_all = [b["sy"] - a["sy"] for a, b in zip(S0, S1)]
print("\n屏幕位移 x 极差: %.3e   y 极差: %.3e" % (
    max(dsx_all) - min(dsx_all), max(dsy_all) - min(dsy_all)))
print("世界位移 vs 理论 Δ(1−k) 最大绝对误差: %.3e" % worst_d)
print("理论位移量 Δ(1−k)：depth 越小越接近 DX")
print("DIAG_RENDER_DONE")
