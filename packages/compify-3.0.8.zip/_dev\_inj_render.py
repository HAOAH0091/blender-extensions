"""后向注入：证明 test_render_verify.py 的几何断言有判别力。

这条断言最容易变成假绿（因为 5.96e-08 这种精度下，写错也可能碰巧过）。
必须证明它真能红：

  注入 A：把移动方向改回「世界 +X」（就是我当时犯的错）
          ⇒ 「屏幕位移相同」必须红（因为混入了 65% 沿视线分量）
  注入 B：把 MOVE 改成 0
          ⇒ 「构图保持」会绿（位移 0 当然一致），但那条「锁定后画面同样位移」
            的像素断言应该红 → 用这条兜住「没动也算过」的漏洞

如果 A 注入后仍绿，说明断言是假的。
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "test_render_verify.py")
raw = open(SRC, encoding="utf-8").read()


def run(tag, src):
    print("\n" + "#" * 74)
    print("#", tag)
    print("#" * 74)
    g = {"__file__": SRC, "__name__": "__main__"}
    try:
        exec(compile(src, SRC, "exec"), g)
    except SystemExit:
        pass
    except Exception as e:
        print("  (执行异常)", type(e).__name__, e)
        return ["<EXC>"]
    fails = g.get("F") or []
    print("  >>> 注入后 FAIL 数:", len(fails), fails)
    return fails


# 注入 A：退回世界 +X 移动（我原来的错）
sA = raw.replace(
    "cam.location = tuple(mathutils.Vector(start_loc) + cam_right * MOVE)",
    "cam.location = (start_loc[0] + MOVE, start_loc[1], start_loc[2])")
assert sA != raw, "注入点 A 没命中"
fA = run("注入A：移动方向退回世界+X（混入沿视线分量）→ 期望构图断言变红", sA)

print("\n" + "=" * 74)
okA = "锁定后移相机：所有顶点屏幕位移相同（构图保持）" in fA
print("A 命中预期断言:", okA)
print("⇒ 断言有判别力" if okA else "⇒ 断言是假的（注入后没红）")
print("INJ_RENDER_DONE")
