"""后向注入：证明 test_frozen.py 的三条新断言都有判别力。

三条核心断言：
  ① 构图保持 = 所有顶点屏幕位移完全相同
  ② 世界位移 = Δ(1−k)
  ③ 锁定瞬间画面与锁定前一致

分别注入一个已知错误，对应那条必须变红：

  注入 A：把 dx_world 改成 2.5（假装相机移了 2.5）
          ⇒ ② 「世界位移=Δ(1−k)」必须红；① ③ 应仍绿（不相干）
  注入 B：把 handler 那行改成 pass（不调用法）
          ⇒ ① 「屏幕位移一致」必须红（网格不跟随 ⇒ 屏幕位移全是相机运动量，
             但各层深度不同会散开）；② 也应红
  注入 C：把锁定前的采样 SL_A 整体加 1e-3
          ⇒ ③ 「锁定瞬间画面与锁定前一致」必须红

如果注入后仍全绿，说明断言是恒真的（假绿），必须重修。

用法：改动只在内存里的源码字符串上做，不碰磁盘文件。
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "test_frozen.py")
raw = open(SRC, encoding="utf-8").read()


def run(tag, src):
    print("\n" + "#" * 76)
    print("#", tag)
    print("#" * 76)
    g = {"__file__": SRC, "__name__": "__main__"}
    try:
        exec(compile(src, SRC, "exec"), g)
    except SystemExit:
        pass
    fails = g.get("F") or []
    print("  >>> 注入后 FAIL 数:", len(fails), fails)
    return fails


# ── 注入 A：dx_world 改错 ──
s = raw.replace("dx_world = DX", "dx_world = DX * 1.25")
assert s != raw, "注入点 A 没命中"
fA = run("注入A：dx_world = DX*1.25 → 期望『世界位移=Δ(1−k)』变红", s)

# ── 注入 B：不调 handler ──
s = raw.replace("plock.parallax_lock_update_handler(scene)\nshot(\"D_frozen_moved\")",
                "pass\nshot(\"D_frozen_moved\")")
assert s != raw, "注入点 B 没命中"
fB = run("注入B：不调 handler → 期望『屏幕位移一致』与『世界位移』都红", s)

# ── 注入 C：污染锁定前采样 ──
s = raw.replace("SL_A = sample_all()",
                "SL_A = sample_all()\nfor _k in SL_A:\n    SL_A[_k] = [(r[0], r[1], r[2]+1e-3, r[3], r[4]) for r in SL_A[_k]]")
assert s != raw, "注入点 C 没命中"
fC = run("注入C：SL_A 整体 +1e-3 → 期望『锁定瞬间画面一致』变红", s)

print("\n" + "=" * 76)
print("汇总：")
print("  A 红:", fA)
print("  B 红:", fB)
print("  C 红:", fC)
okA = "世界位移 = Δ(1−k)（按视锥体，非刚性平移）" in fA
okB1 = "锁定后移相机：所有顶点屏幕位移完全相同（构图保持）" in fB
okB2 = "世界位移 = Δ(1−k)（按视锥体，非刚性平移）" in fB
okC = "锁定瞬间画面与锁定前一致（补丁不改初始画面）" in fC
print("  期望命中的断言都红了:", all([okA, okB1, okB2, okC]),
      "(A=%s B1=%s B2=%s C=%s)" % (okA, okB1, okB2, okC))
print("INJ_FROZEN_DONE")
