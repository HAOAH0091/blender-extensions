# _dev 诊断脚本说明

本目录是排查过程留下的验证/诊断脚本。**不是回归网**（回归网是 test_*.py）。

## 怎么跑回归

```bat
python _dev\run_regression.py                :: 全部
python _dev\run_regression.py test_uv_*.py   :: 只跑匹配的
```

一文件一 Blender 进程（各测试用自己的 importlib 名字空间加载插件，同进程连跑会互相污染）。

### 这个 runner 踩过的两个坑（2026-10-21）

1. **汇总格式不统一**。有的测试打 `PASS 9 / FAIL 0`，有的打 `PASS=9 FAIL=0`，
   有的根本不打汇总。第一版只认 `PASS=n FAIL=n`，把 **40 个文件全判成 CRASH**。
   量具坏掉的后果比没有量具更糟——结论会反向。现在三种格式都认，
   完全没汇总时才退回去数 `[PASS]` / `[FAIL]` 行。
2. **文件名带 `test_` 不等于它是测试**。曾经有 4 个只打印数据、
   一条断言都没有的探针：`test_frozen.py` / `test_register.py` /
   `test_render_verify.py` / `test_zoom_dolly.py`。
   它们**永远不会 FAIL**，算成 PASS 就是假绿。runner 会把这类标成 `PROBE`
   单独计数、不计入 PASS 总数。

   **2026-10-21 已把这 4 个全部补上断言**，PROBE 归零：
   579 PASS → **610 PASS**（+31 = 10+7+8+6），数字精确对得上。
   补完每个都做了注入验证，证明断言真能红（见下节）。

## 结论可信的（可以作为依据）

| 脚本 | 用途 |
|---|---|
| `verify_psd_align.py` | **最终判据**：拖动当帧不动、拖动后移相机构图保持、基准按当前几何重算、滚动 ∝ 1/基准。统一用 Blender 官方 `world_to_camera_view` 做尺子。 |
| `verify_layers_adapt.py` | 三层同视线，世界位移 = Δ(1−k)，三层屏幕位移严格一致 |
| `verify_drag_along_ray.py` | 拖动沿【相机视线】而非世界 Z（x ÷ 深度 恒定） |
| `verify_cam_adapt3.py` | 世界位移 = Δ(1−k) 的两层验证 |
| `compare_ref_update.py` | 「冻结 ref」vs「对齐 PSD（相机变化时重算）」对比 |
| `diag_bcal.py` | 手算 vs 实测逐项对照（曾用它发现「顶点 ≠ 中心」的混淆） |
| `diag_spy.py` | 插桩跟踪 recompute/adapt 实际用的 ref（曾用它抓到 ref 未持久化） |

## 投影组「节点被删」相关（2026-10-20，**功能已撤销**）

> 用户判断：「用户不会进节点组内部删节点，这个问题可以忽略了」⇒ 选 B，整个功能撤销。
> 下面几个脚本**不再是回归网**，保留是因为它们记录的事实/方法有独立价值。

| 脚本 | 保留价值 |
|---|---|
| `repro_node_damage.py` | 复现了「删掉投影组内的 S 节点 ⇒ 点解锁时 `_ensure_delta_group` 会**清空整组重建**，把用户自定义节点一起推平」（实测 `USER_MARK` 在解锁瞬间消失）。这条产品行为是事实，以后再碰投影组重建时用得上。 |
| `diag_sc_sockets.py` | ★ 用它发现 **bpy 结构体不能用 `is` 比较** —— 同一个节点，`ng.nodes.get("PLock Delta S") is link.from_node` 返回 **False**（bpy 是 C 数据块的包装器，不保证 Python 单例）。这个坑有普适性，跟本次功能无关也该记住。 |
| `diag_panel_ui3.py` | **GUI 截图验证方法**。连踩 5 个坑才拍成，坑见下。它会因 `plock.projection_group_damage` 已删而报错，属预期。 |

### 已撤销的实现（git 历史 `d825536` 可查）

`compify_parallax_lock.py` 的 `projection_group_damage()` / `_find_node_by_label()` /
`repair_projection_group()`、`__init__.py` 的 `CompifyRepairProjectionGroup` 及面板按钮、
`test_repair_projection.py` / `test_repair_button_gate.py` 已全部移除。

## 已删除的（保留在 git 历史里）

| 脚本 | 为什么删 |
|---|---|
| `verify_cam_adapt.py` | 「刚性跟随视锥体」对照实现写错了（矩阵用反），测出「A 画面位置变化 2.69」是**错误结论**。正确判据见 `verify_psd_align.py`。 |
| `verify_cam_adapt2.py` | 同段错误对照；它的有效发现（同视线上不同深度的两点屏幕位移相同）已被 `verify_psd_align.py` 覆盖。 |
| `diag_ratio.py` | 同时用了两套屏幕度量（手写 x/depth 与另一套），其中一套在相机移动后忘了减相机位置，导致同一现象算出互相矛盾的数，结论不可信。 |

## 教训

**手写屏幕度量是坑**：x/z、x/depth、NDC 三者单位不同，符号容易搞反，相机移动后容易忘减相机位置。
所有「是否跳变 / 是否移动」的判据，**只用 `world_to_camera_view`**（渲染实际使用的投影，含 lens/sensor/shift）。

## UV 缓存相关（2026-10-20，v3.0.4）

> 这一批**是回归网**（`test_uv_*.py`），已纳入版本库，不是一次性诊断脚本。
> 每一条都做过后向注入验证：把对应逻辑改坏，它必须变红。

| 脚本 | 守什么 | 项数 |
|---|---|---|
| `test_uv_load_post.py` | 换文件后陈旧缓存必须被清（含 `@persistent` 标记、注销时摘除） | 8 |
| `test_uv_empty_cache.py` | 空结果也要能进缓存（否则每次读都全库扫） | 8 |
| `test_uv_acceptance.py` | 验收对照表全部条目：正常/删相机/删物体/换文件/A→B→A/清理 | 41 |
| `test_uv_cache_swap.py` | **删一个加一个、总数不变**时必须重扫（数量哨兵回归） | 8 |
| `test_uv_cache_untrusted.py` | 组改名后**不许**从面板消失（B10 回归，双保险） | 9 |
| `test_uv_usage_index.py` | 材质反查表与原函数**逐条等价**（防两份实现漂移） | 9 |
| `repro_uv_cache_b10.py` | B10 手工复现脚本（不是测试，出问题时先跑它定位） | 8 |

### 这一批踩过的坑（都是"操作没生效却当成结论"）

1. **拿工作区冒充版本对照**：用 `Copy-Item` 复制工作区文件当 master，
   而当时工作区已在 fix 分支上 ⇒ 对照的是自己 ⇒ 得出"三版本性能持平"的错误结论。
   **对照代码必须用 `git archive <ref>`。**
2. **注入没生效**：注入脚本参数顺序写反，实际跑的是空操作，
   却把结果当成"测试没判别力"。**注入后先确认改动行号。**
3. **测试场景缺关键用例**：反查表等价性测试最初没有 mute/hide 节点，
   做"单边漂移"注入时仍然全绿 ⇒ 测试等于没写。
   **判据要覆盖会分叉的那个维度。**

### 已知极限

- 反查表等价性测试靠"两份实现互比"，**抓不住"两边同时加同样过滤"**。
  这是互比型测试的固有限制，已在测试注释写明，靠 code review 兜底。

## 4 个 PROBE 补断言（2026-10-21）

| 文件 | 补了几项 | 注入验证脚本 | 关键判据 |
|---|---|---|---|
| `test_frozen.py` | 10 | `_inj_frozen.py` | 平移下「所有顶点屏幕位移相同」+「世界位移 = Δ(1−k)」 |
| `test_register.py` | 7 | `_inj_register.py` | register/unregister 三态翻转（面板/operator/handler） |
| `test_render_verify.py` | 8 | `_inj_render.py` | 几何量兜底构图保持；像素只判「变没变」 |
| `test_zoom_dolly.py` | 6 | `_inj_zoom_dolly.py` | 变焦下「屏幕位置严格不变」+ 位移 = ref(k−1) |

全部做过后向注入：注入一个已知错误 → 对应断言必须变红 → 其余保持绿。

### ⚠️ 补断言时踩的判据口径坑（三次，务必分清）

这三条看起来像 bug，其实全是**我判据用错**，产品一直是对的：

**坑 1：把「变焦」的判据套到「平移」上。**
- 变焦（改 lens）：相机沿 forward 移动抵消变焦 ⇒ 屏幕坐标**严格不变**。
- 平移（相机横移）：各层按 Δ(1−k) 走 ⇒ 世界坐标必然不同，屏幕坐标**整体一致平移**。
- 我拿后者去套「屏幕位置不变」，报出 0.1200 的 FAIL。
  实测世界位移 0.09935 与理论 Δ(1−k)=0.09935 **精确吻合**，产品没错。

**坑 2：拿像素差判「构图保持」。**
- 锁定后横移，整个构图会整体平移 ⇒ 03 与 01 逐像素差必然很大（实测 15.56%）。
- 判断「构图保持」只能用几何量（官方 `world_to_camera_view` 算全部顶点屏幕位移）。
- 看渲染图确认了：02 未锁定时图案被拉成条纹，03 锁定时同心圆环仍居中。

**坑 3（主因）：移动方向不是纯横移。**
- 默认场景 Camera 旋转 `(63.56°, 0, 46.69°)`，
  `world+X · forward = -0.6516` —— 沿世界 X 移动有 65% 是往视线里推。
- 「屏幕位移一致」只在纯横移下成立，前提不成立判据必红。
- 改成沿相机 `right` 轴移动后，极差从 4.8e-02 降到 **5.96e-08**。

对照诊断脚本 `diag_render_truth.py`（干净正对相机场景）：
屏幕位移 x 极差 2.98e-08，世界位移与 Δ(1−k) 最大误差 2.95e-07 —— 证明产品正确。

## 「更新UV调整」按钮隐藏（2026-10-21，v3.0.5）

> 用户判断：这按钮守的场景（挪完相机再手动重算 UV）实际不成立 ⇒ 藏入口不删实现。
> 开关在 `__init__.py` 顶部 `SHOW_UPDATE_UV_ADJUST_BUTTON = False`。

| 脚本 | 守什么 | 项数 |
|---|---|---|
| `test_hide_update_button.py` | 隐藏态 draw 里 `update_uv_adjust` 出现 0 次、`delete`/`bake` 仍在（行没塌）、开关改 True 按钮回来、operator 仍可从脚本调 | 15 |
| `_inj_hide_button.py` | **后向注入**：把 draw 里 `if SHOW_UPDATE_UV_ADJUST_BUTTON:` 改成 `if True:` ⇒ 按钮出现 1 次，证明上面那条测试真有判别力（不是假绿） | 1 |

注入用的是「先 `inspect.getsource` 拿 draw 源码 → 改字符串 → exec → 挂到子类的 draw 上」，
**不能只把常量 monkeypatch 成 True**——那是在测开关本身，不是在测「有人把 if 删了」。
另注意：`getsource` 只拿到函数体，类还在原 module 里，所以必须造子类挂注入版 draw，
否则跑的还是原逻辑（假绿）。

## 烘焙隐藏对象与弹窗中文化（2026-11-11，v3.0.6）

| 脚本 | 守什么 | 项数 |
|---|---|---|
| `test_bake_hidden_visibility.py` | 隐藏源对象复制后恢复可见、原对象保持隐藏；视图层排除、未链接对象、失败清理 | 27 |
| `test_bake_pipeline_hidden.py` | 64×64 Cycles 完整烘焙成功；UV 失败 / 材质克隆失败后临时对象、图片、材质全部清掉 | 19 |
| `test_bake_dialog_i18n.py` | 58 条弹窗/属性/错误文案简繁覆盖；运行时 `zh_HANS → en_US → zh_HANS → zh_HANT` 切换；标题显式翻译 | 15 |

跑法：

```bat
<blender> --background --factory-startup --python _dev\test_bake_hidden_visibility.py
<blender> --background --factory-startup --python _dev\test_bake_pipeline_hidden.py
<blender> --background --factory-startup --python _dev\test_bake_dialog_i18n.py
```

### 这次踩到的两个坑

1. **`mode_set.poll()` 报 active object 缺失，不一定是“没选中”。**
   副本会继承源对象的 `hide_viewport` / `hide_render` / `hide_select`；
   源对象所在集合还可能被当前视图层排除。另外，`collection.objects.link(obj)`
   之后 `ViewLayer.objects` **不会立即刷新**，必须先 `view_layer.update()`，
   否则会把刚链进来的对象误判成“不在视图层”。

2. **插件翻译受 Blender 的 Interface 开关控制。**
   `bpy.app.translations.pgettext_iface()` 不只看 `locale`，还看
   `Preferences > Interface > Translation > Interface` 是否勾选；
   关掉后即使 `locale == zh_HANS`，`Cancel` 也会返回英文。
   弹窗正文用 `_()` 没问题，但标题不能依赖 operator 的 `bl_label`，
   必须显式传给 `invoke_props_dialog(title=_("Bake Material Projection"),
   translate=False)`，否则标题会一直保持英文。

## 投影组安全性与 Aspect 同步（2026-11-11，v3.0.8）

| 脚本 | 守什么 | 项数 |
|---|---|---|
| `test_review_fixes11.py` | 跨场景共享组保留、删除 Shared Group 后所有材质无死节点、部分接线不报成功、Aspect 变化同时更新 Camera Project 与 UV Adjust、同场景共享材质拒绝覆盖、跨场景替换仍可用、handler 热重载去重 | 28 |
| `test_hide_update_button.py` | 场景准备改为真实接通 Image Texture，避免继续依赖“未接通材质也算成功”的旧行为 | 15 |

跑法：

```bat
<blender> --background --factory-startup --python _dev\test_review_fixes11.py
python _dev\run_regression.py test_review_fixes11.py
```

### runner 补充

- 支持 `BLENDER_BIN` 环境变量、`PATH`、`C:\Program Files\Blender Foundation`
  和 Steam 常见安装路径自动探测；不再只认 `G:\steam\...`。
- 新增 `RESULT: n PASS, m FAIL` 汇总格式识别。
- 只在最终汇总之后检查 traceback；测试故意触发的、已捕获的异常不再被误判为 CRASH。

### 已知限制

- Camera Project 是全局 datablock，同一相机在两个场景使用不同 Aspect 时仍会
  互相覆盖。
- 删除 UV Adjust 组只摘除该组引用，不删除可能仍被其它投影使用的 Camera Project 节点。
