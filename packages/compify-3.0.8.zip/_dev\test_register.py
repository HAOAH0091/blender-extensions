"""验证 compify-parallax-lock 整体加载 + 注册 + handler 挂载。"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")

spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
print("IMPORT_OK")

mod.register()
print("REGISTER_OK")

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-46s %s" % ("PASS" if c else "FAIL", n, d))


has_toggle = hasattr(bpy.types, "COMPIFY_OT_parallax_lock_toggle")
has_reset = hasattr(bpy.types, "COMPIFY_OT_parallax_lock_reset")
print("HAS_TOGGLE=%s HAS_RESET=%s" % (has_toggle, has_reset))

plock = sys.modules[PKG + ".compify_parallax_lock"]
h = plock.parallax_lock_update_handler
mounted = h in bpy.app.handlers.depsgraph_update_post
print("HANDLER_MOUNTED=%s" % mounted)

chk("bl_info 版本号是三元组", isinstance(mod.bl_info.get("version"), tuple)
    and len(mod.bl_info["version"]) == 3, str(mod.bl_info.get("version")))
chk("register 后两条 operator 都在", has_toggle and has_reset,
    "toggle=%s reset=%s" % (has_toggle, has_reset))
chk("register 后 handler 挂在 depsgraph_update_post", mounted)
# 面板类的查法（这里踩过两次坑）：
#  ① bpy.types 里【没有】CompifyUVAdjust3DPanel 这个属性 —— 别用 hasattr，
#     也别按 COMPIFY_PT_ 前缀猜。实测 hasattr(bpy.types, "CompifyUVAdjust3DPanel")
#     在 register() 之后仍然返回 False。
#  ② 正确查法是按 bl_idname 走 bl_rna_get_subclass_py：
#         bpy.types.Panel.bl_rna_get_subclass_py("VIEW3D_PT_compify_uv_adjust")
#     注册上返回类对象，注销后返回 None。
#  （operator 那边 hasattr(bpy.types, "COMPIFY_OT_xxx") 是可用的，两者行为不同。）
PANEL_ID = "VIEW3D_PT_compify_uv_adjust"


def panel_cls():
    return bpy.types.Panel.bl_rna_get_subclass_py(PANEL_ID)


chk("register 后面板类已注册", panel_cls() is not None, PANEL_ID)

mod.unregister()
print("UNREGISTER_OK")
removed = h not in bpy.app.handlers.depsgraph_update_post
print("HANDLER_REMOVED=%s" % removed)

chk("unregister 后 handler 已摘除", removed)
chk("unregister 后 operator 已注销",
    not hasattr(bpy.types, "COMPIFY_OT_parallax_lock_toggle"))
chk("unregister 后面板类已注销", panel_cls() is None)

print()
print("=" * 86)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("TEST_REGISTER_DONE")
