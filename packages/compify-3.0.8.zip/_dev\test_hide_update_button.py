"""验证：「更新UV调整」按钮隐藏后，面板不再绘制它，但 operator 仍可用。

判据（数值，不看截图）：
  1) 开关为 False 时，面板 draw 期间**没有**发起 compify.update_uv_adjust；
     但 compify.delete_uv_adjust / compify.bake_material_projection 照常出现
     —— 证明隐藏的是单个按钮，不是整行塌掉。
  2) 开关为 True 时，按钮**立刻回来**（证明开关是活的，不是硬删）。
  3) 无论开关如何，operator 始终注册着，bpy.ops 能直接调。
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_hidebtn_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
mod.register()

ngm = sys.modules[PKG + ".node_group_manager"]
ngs = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-46s %s" % ("PASS" if cond else "FAIL", name, detail))

# ---------------- 搭一个真的能出按钮的场景 ----------------
scene = bpy.context.scene
cam_data = bpy.data.cameras.new("HIDE_CAM")
cam = bpy.data.objects.new("HIDE_CAM", cam_data)
scene.collection.objects.link(cam)

mesh = bpy.data.meshes.new("HIDE_MESH")
mesh.from_pydata([(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)], [], [(0, 1, 2, 3)])
mesh.update()
obj = bpy.data.objects.new("HIDE_OBJ", mesh)
scene.collection.objects.link(obj)

if not obj.data.uv_layers:
    obj.data.uv_layers.new(name="UVMap")

# The projection chain is only considered valid when it reaches an image
# texture's Vector input.  Pre-create the material and its texture node so
# this UI test exercises a genuinely wired setup.
hide_mat = bpy.data.materials.new("HIDE_OBJ_Material")
hide_mat.use_nodes = True
hide_mat.node_tree.nodes.new("ShaderNodeTexImage")
obj.data.materials.append(hide_mat)

ngs.ensure_camera_project_group(cam, default_aspect=1.0)
r = ngm.create_and_add_uv_adjust_node_group(scene, cam, obj)
chk("场景准备：UV Adjust 组建好", r.get("success") is True, "→%s" % r.get("message"))

groups = [g for g in ngm.get_all_uv_adjust_node_groups(scene) if g["materials"]]
chk("场景准备：面板列表里至少 1 个带材质的组", len(groups) >= 1, "→%d" % len(groups))

# 选中物体，让 draw 走"高亮"分支
for o in bpy.context.selected_objects:
    o.select_set(False)
obj.select_set(True)
bpy.context.view_layer.objects.active = obj

# ---------------- 录制型假 layout ----------------
class RecLayout:
    """记录所有 operator() 调用；其余方法一律当布局容器用，不崩。"""
    def __init__(self, sink):
        object.__setattr__(self, "_sink", sink)

    def __getattr__(self, name):
        if name in ("_sink",):
            raise AttributeError(name)
        def _any(*a, **k):
            if name == "operator" and a:
                self._sink.append(a[0])
            return self
        return _any

    # 允许 row.alert = True / row.enabled = False 这类赋值
    def __setattr__(self, name, value):
        object.__setattr__(self, name, value)


class FakePanel:
    """面板 draw 只用到 self.layout，所以给个空壳就能把 draw 当普通函数跑。"""
    def __init__(self, sink):
        self.layout = RecLayout(sink)


def run_draw():
    """用假 layout 跑一次真实的 Panel.draw，返回调用过的 operator idname 列表。"""
    ops = []
    panel_cls = mod.CompifyUVAdjust3DPanel
    panel_cls.draw(FakePanel(ops), bpy.context)
    return ops


def ops_shown_count(ops, idname="compify.update_uv_adjust"):
    """某个 operator 在这一次 draw 里被画了几次。"""
    return ops.count(idname)

# ---------------- 1) 开关 = False（当前状态） ----------------
chk("开关默认值是 False", mod.SHOW_UPDATE_UV_ADJUST_BUTTON is False,
    "→%s" % mod.SHOW_UPDATE_UV_ADJUST_BUTTON)

ops_hidden = run_draw()
chk("隐藏态[单材质条目]：draw 没崩", True)
chk("隐藏态[单材质条目]：没有 update_uv_adjust",
    "compify.update_uv_adjust" not in ops_hidden,
    "→出现了 %d 次" % ops_shown_count(ops_hidden))
chk("隐藏态[单材质条目]：delete 仍在（行没塌）",
    "compify.delete_uv_adjust" in ops_hidden)
chk("隐藏态[单材质条目]：bake 仍在（行没塌）",
    any(o.startswith("compify.bake_material_projection") for o in ops_hidden))

# 单材质状态下也验证一次"打开就能回来"——两个分支互斥，
# 加了第二个材质后这个组就变成共享组了，所以这里必须趁它还单材质时测。
mod.SHOW_UPDATE_UV_ADJUST_BUTTON = True
_single_shown = run_draw()
chk("打开[单材质条目]：update_uv_adjust 回来 1 次",
    ops_shown_count(_single_shown) == 1,
    "→%d 次" % ops_shown_count(_single_shown))
mod.SHOW_UPDATE_UV_ADJUST_BUTTON = False

# 再补一个物体共用同一材质 —— 覆盖"共享组"条目的那处开关
mesh2 = bpy.data.meshes.new("HIDE_MESH2")
mesh2.from_pydata([(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)], [], [(0, 1, 2, 3)])
mesh2.update()
obj2 = bpy.data.objects.new("HIDE_OBJ2", mesh2)
scene.collection.objects.link(obj2)
mat = bpy.data.materials["HIDE_OBJ_Material"]
mesh2.materials.append(mat)

# 单材质条目 vs 共享组条目的判据是 len(materials)==1，
# 所以真正的"共享组"分支要靠 node_group 被多个材质引用才会走到
# —— 再造一个材质挂同一个组。
mat2 = bpy.data.materials.new("HIDE_MAT2")
mat2.use_nodes = True
grp = groups[0]["node_group"]
gnode = mat2.node_tree.nodes.new("ShaderNodeGroup")
gnode.node_tree = grp
chk("场景准备：造出 2 个材质共用一个组（触发共享组分支）",
    len([g for g in ngm.get_all_uv_adjust_node_groups(scene)
         if len(g["materials"]) > 1]) >= 1)

ops_hidden_shared = run_draw()
chk("隐藏态[共享组条目]：没有 update_uv_adjust",
    "compify.update_uv_adjust" not in ops_hidden_shared,
    "→出现了 %d 次" % ops_shown_count(ops_hidden_shared))
chk("隐藏态[共享组条目]：delete 仍在（行没塌）",
    ops_shown_count(ops_hidden_shared, "compify.delete_uv_adjust") >= 1)

# ---------------- 2) 开关 = True（验证开关是活的） ----------------
mod.SHOW_UPDATE_UV_ADJUST_BUTTON = True
ops_shown = run_draw()
# 注意：此刻该组 materials=2，只走共享组分支（两分支互斥）。
chk("打开[共享组条目]：update_uv_adjust 回来 1 次",
    ops_shown_count(ops_shown) == 1,
    "→%d 次" % ops_shown_count(ops_shown))
mod.SHOW_UPDATE_UV_ADJUST_BUTTON = False

# ---------------- 3) operator 始终可用 ----------------
chk("operator 仍注册（RNA 类在）",
    hasattr(bpy.types, "COMPIFY_OT_update_uv_adjust"))
chk("operator 仍注册（bpy.ops 在）",
    hasattr(bpy.ops.compify, "update_uv_adjust"))
try:
    rr = bpy.ops.compify.update_uv_adjust(node_group_name=groups[0]["node_group"].name)
    chk("隐藏期间仍能从脚本直接调用", rr == {"FINISHED"}, "→%s" % (rr,))
except Exception as e:
    chk("隐藏期间仍能从脚本直接调用", False, str(e))

# ---------------- 收尾 ----------------
mod.unregister()
print("\nRESULT: PASS=%d FAIL=%d" % (len(P), len(F)))
if F:
    print("FAILED: %s" % F)
