"""回归 runner：逐个 test_*.py 起独立 Blender 进程跑，汇总 PASS/FAIL。

用法：
    python _dev\\run_regression.py              跑全部
    python _dev\\run_regression.py test_uv_*.py  只跑匹配的（支持通配）

每个测试都用自己的 importlib 名字空间加载插件，所以必须一文件一进程。

── 判据（这里踩过两个坑，别回头）──────────────────────────────────────
① 汇总格式不统一：有 "PASS 9 / FAIL 0"，有 "PASS=9 FAIL=0"，
   还有不打印汇总的。第一版只认 "PASS=n FAIL=n"，
   把 40 个文件全判成 CRASH —— 量具坏了，结论就全错。
② 「文件名叫 test_」不等于「是测试」。本目录里有几个只打印数据、
   没有任何断言的探针（test_frozen / test_register / test_render_verify /
   test_zoom_dolly）。它们永远不会有 FAIL，把它们算成 PASS 是假绿。
   所以单独标成 PROBE 并计数，不计入 PASS 总数。
"""
import glob
import os
import re
import shutil
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")


def find_blender():
    """Resolve Blender from BLENDER_BIN, PATH, or a few common installs."""
    env_bin = os.environ.get("BLENDER_BIN")
    if env_bin:
        return env_bin
    found = shutil.which("blender")
    if found:
        return found
    patterns = [
        r"C:\Program Files\Blender Foundation\Blender *\blender.exe",
        r"G:\steam\steamapps\common\Blender\blender.exe",
        os.path.expanduser(
            r"~\scoop\apps\blender\current\blender.exe"),
    ]
    for pattern in patterns:
        matches = sorted(glob.glob(pattern))
        if matches:
            return matches[-1]
    return ""


BL = find_blender()
if not BL:
    print("Blender not found. Set BLENDER_BIN to the Blender executable.")
    sys.exit(2)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

SUM_A = re.compile(r"PASS\s*(\d+)\s*/\s*FAIL\s*(\d+)")
SUM_B = re.compile(r"PASS=(\d+)\s*FAIL=(\d+)")
SUM_C = re.compile(r"RESULT:\s*(\d+)\s+PASS,\s*(\d+)\s+FAIL")
LINE_PASS = re.compile(r"^\s*\[?PASS\]?", re.M)
LINE_FAIL = re.compile(r"^\s*\[?FAIL\]?", re.M)
DONE = re.compile(r"^[A-Z0-9_]+_DONE\b|^DONE$|^TEST_DONE$", re.M)
BAD = re.compile(r"Traceback \(most recent call last\)|^\w*Error:|Exception", re.M)

args = sys.argv[1:]
if args:
    tests = sorted(f for pat in args for f in glob.glob(os.path.join(HERE, pat)))
    tests = [os.path.basename(f) for f in tests if os.path.basename(f).startswith("test_")]
else:
    tests = sorted(f for f in os.listdir(HERE) if f.startswith("test_") and f.endswith(".py"))

tot_p = tot_f = 0
failing, probes = [], []

for t in tests:
    path = os.path.join(HERE, t)
    src = open(path, encoding="utf-8", errors="replace").read()
    # 有断言 = 真测试；没有 = 只打印数据的探针
    has_assert = ("assert " in src) or ("FAIL" in src) or ("sys.exit" in src)

    r = subprocess.run(
        [BL, "--background", "--factory-startup", "--python", path],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=600, cwd=ROOT,
    )
    out = (r.stdout or "") + (r.stderr or "")
    body = "\n".join(
        l for l in out.splitlines()
        if "DeprecationWarning" not in l and not l.strip().startswith("mat")
    )

    m = SUM_A.search(body) or SUM_B.search(body) or SUM_C.search(body)
    have_summary = bool(m)
    if m:
        p, f = int(m.group(1)), int(m.group(2))
    else:
        p, f = len(LINE_PASS.findall(body)), len(LINE_FAIL.findall(body))

    ran = bool(DONE.search(out)) or have_summary
    # Only inspect output after the final summary.  Some tests deliberately
    # exercise a failure path, print that caught traceback, and then finish
    # with "PASS n / FAIL 0"; that is not a crash.
    bad = bool(BAD.search(body[m.end():] if m else body))

    if not has_assert:
        tag = "PROBE"
        probes.append(t)
    elif not ran or bad:
        tag = "CRASH"
    elif f:
        tag = "FAIL"
    else:
        tag = "OK"

    note = "" if have_summary else ("  (计数来自 [PASS]/[FAIL] 行)" if has_assert else "  (无断言，仅打印数据)")
    print("%-34s %-6s PASS=%-4d FAIL=%-3d rc=%d%s" % (t, tag, p, f, r.returncode, note))
    if tag in ("CRASH", "FAIL"):
        for l in [x for x in body.splitlines() if x.strip()][-8:]:
            print("      | " + l[:170])

    if tag not in ("PROBE",):
        tot_p += p
        tot_f += f
    if tag in ("CRASH", "FAIL"):
        failing.append(t)

print("=" * 66)
print("TOTAL PASS=%d FAIL=%d  files=%d  failing=%d  probes(不计入)=%d"
      % (tot_p, tot_f, len(tests), len(failing), len(probes)))
if probes:
    print("PROBE:", ", ".join(probes))
if failing:
    print("FAILED:", ", ".join(failing))
