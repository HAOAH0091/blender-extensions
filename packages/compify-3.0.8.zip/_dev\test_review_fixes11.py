"""Regression for the review fixes:

1. Refresh & Clean must not delete a projection group shared with another
   scene (the group datablock is global).
2. Deleting a shared UV Adjust group must detach it from *every* material,
   not just the resolved object's first material.
3. A partially wired projection must not be reported as success.
4. Render-aspect changes must update both Camera Project and UV Adjust.

Run:
  blender --background --factory-startup --python _dev/test_review_fixes11.py
"""

import bpy
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_review_fixes11_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)

ng = sys.modules[PKG + ".node_groups"]
ngm = sys.modules[PKG + ".node_group_manager"]

PASS = []
FAIL = []


def chk(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %-58s %s" % ("PASS" if cond else "FAIL", name, detail))


def fresh_scene(x=1920, y=1080, px=1.0, py=1.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.resolution_x = x
    scene.render.resolution_y = y
    scene.render.pixel_aspect_x = px
    scene.render.pixel_aspect_y = py
    return scene


def add_camera(scene, obj_name="Cam", data_name="CamData"):
    cam_data = bpy.data.cameras.new(data_name)
    cam_data.lens = 50.0
    camera = bpy.data.objects.new(obj_name, cam_data)
    scene.collection.objects.link(camera)
    camera.location = (0.0, 0.0, 10.0)
    scene.camera = camera
    bpy.context.view_layer.update()
    return camera


def add_plane(scene, obj_name="Plane", data_name="PlaneData",
              location=(0.0, 0.0, 0.0)):
    mesh = bpy.data.meshes.new(data_name)
    mesh.from_pydata(
        [(-1.0, -1.0, 0.0), (1.0, -1.0, 0.0),
         (1.0, 1.0, 0.0), (-1.0, 1.0, 0.0)],
        [], [(0, 1, 2, 3)])
    mesh.update()
    obj = bpy.data.objects.new(obj_name, mesh)
    scene.collection.objects.link(obj)
    obj.location = location
    bpy.context.view_layer.update()
    return obj


def make_projection(scene, obj, camera, material_name="ProjMat",
                    with_texture=True):
    """Create Camera Project + UV Adjust nodes and wire them into a material."""
    cam_group = ng.ensure_camera_project_group(
        camera, ng.scene_aspect_ratio(scene))
    uv_group = ng.create_uv_adjust_node_group(scene, camera, obj)

    material = bpy.data.materials.new(material_name)
    material.use_nodes = True
    tree = material.node_tree
    tree.nodes.clear()

    cam_node = tree.nodes.new("ShaderNodeGroup")
    cam_node.node_tree = cam_group
    uv_node = tree.nodes.new("ShaderNodeGroup")
    uv_node.node_tree = uv_group
    tree.links.new(
        cam_node.outputs["Vector"],
        uv_node.inputs["Camera Projection UV"])

    texture = None
    if with_texture:
        texture = tree.nodes.new("ShaderNodeTexImage")
        tree.links.new(
            uv_node.outputs["Adjusted UV"],
            texture.inputs["Vector"])
    obj.data.materials.append(material)
    return material, cam_group, uv_group, cam_node, uv_node, texture


print("=" * 68)
print("[1] Refresh & Clean keeps cross-scene shared groups")
print("=" * 68)

scene_a = fresh_scene()
cam_a = add_camera(scene_a)
obj_a = add_plane(scene_a)
mat_a, cp_a, uv_a, _, _, _ = make_projection(scene_a, obj_a, cam_a)

# A second scene shares the material but owns different mesh data
# (the normal result of a full scene copy: MeshData -> MeshData.001).
scene_b = bpy.data.scenes.new("SceneB")
mesh_b = obj_a.data.copy()
mesh_b.name = "PlaneData.001"
obj_b = bpy.data.objects.new("PlaneB", mesh_b)
scene_b.collection.objects.link(obj_b)
obj_b.data.materials.append(mat_a)
bpy.context.window.scene = scene_b

rows_b = ngm.get_all_uv_adjust_node_groups(scene_b)
chk("scene B sees the shared group", len(rows_b) == 1,
    "rows=%d" % len(rows_b))
chk("shared row is marked belongs_to_other_scene",
    bool(rows_b) and rows_b[0].get("belongs_to_other_scene") is True)

cleaned = ngm.clean_invalid_uv_adjust_node_groups(scene_b, confirm=False)
chk("Refresh & Clean deletes zero shared groups", cleaned == 0,
    "cleaned=%d" % cleaned)
chk("group still exists after Refresh & Clean",
    bpy.data.node_groups.get(uv_a.name) is not None)

rename = ngm.handle_object_rename_in_node_groups(scene_b)
chk("rename pass does not classify shared group as orphan",
    rename.get("orphaned") == 0 and rename.get("other_scene", 0) >= 1,
    "orphaned=%d other=%d" % (
        rename.get("orphaned", -1), rename.get("other_scene", -1)))


print()
print("=" * 68)
print("[2] Deleting a shared group detaches every material")
print("=" * 68)

scene = fresh_scene()
cam = add_camera(scene)
obj = add_plane(scene)
mat1, cp, uv, _, _, _ = make_projection(scene, obj, cam, "Mat1")

mat2 = bpy.data.materials.new("Mat2")
mat2.use_nodes = True
mat2.node_tree.nodes.clear()
group2 = mat2.node_tree.nodes.new("ShaderNodeGroup")
group2.node_tree = uv

uv_name = uv.name
ok = ngm.delete_uv_adjust_node_group(uv)
chk("delete reports success", ok is True)
chk("UV group datablock removed", bpy.data.node_groups.get(uv_name) is None)

dead = []
for material in (mat1, mat2):
    for node in material.node_tree.nodes:
        if node.type == "GROUP" and node.node_tree is None:
            dead.append((material.name, node.name))
chk("no dead GROUP nodes remain", not dead, str(dead))


print()
print("=" * 68)
print("[3] Partially wired projection is not success")
print("=" * 68)

scene = fresh_scene()
cam = add_camera(scene)
obj = add_plane(scene)
material, cp, uv, _, _, _ = make_projection(
    scene, obj, cam, "NoTexture", with_texture=False)

direct = ngm.add_uv_adjust_to_material(obj, cam, uv)
chk("direct add reports failure when no image texture exists",
    direct["success"] is False, direct["message"])
chk("failure message names the missing link",
    "image texture" in direct["message"].lower()
    or "connection" in direct["message"].lower(),
    direct["message"])

obj2 = add_plane(scene, "Plane2", "PlaneData2")
material2 = bpy.data.materials.new("NoTexture2")
material2.use_nodes = True
material2.node_tree.nodes.clear()
cp_node2 = material2.node_tree.nodes.new("ShaderNodeGroup")
cp_node2.node_tree = cp
obj2.data.materials.append(material2)

result = ngm.create_and_add_uv_adjust_node_group(scene, cam, obj2)
chk("create+add reports failure when material cannot be wired",
    result["success"] is False, result["message"])
chk("new orphan group is cleaned up after failure",
    result.get("node_group") is None)


print()
print("=" * 68)
print("[4] Aspect change updates Camera Project and UV Adjust")
print("=" * 68)

scene = fresh_scene(1920, 1080)
cam = add_camera(scene)
obj = add_plane(scene)
material, cp, uv, cam_node, uv_node, _ = make_projection(
    scene, obj, cam, "AspectMat")

# Force both storage locations to a stale value so the sync has real work to
# do (a freshly created group already matches the scene).
stale_socket = ng._find_interface_socket(cp, "Aspect Ratio")
stale_socket.default_value = 1.0
cam_node.inputs["Aspect Ratio"].default_value = 1.0

changed = ng.sync_camera_project_aspect(
    scene, ng.scene_aspect_ratio(scene))
chk("aspect sync changes interface/node defaults", changed >= 2,
    "changed=%d" % changed)
chk("Camera Project node follows 16:9",
    abs(float(cam_node.inputs["Aspect Ratio"].default_value)
        - (16.0 / 9.0)) < 1e-5,
    str(cam_node.inputs["Aspect Ratio"].default_value))

uv_div = next(
    n for n in uv.nodes
    if n.type == "VECT_MATH" and n.operation == "DIVIDE")
before_scale = tuple(uv_div.inputs[1].default_value)

scene.render.resolution_x = 1080
scene.render.resolution_y = 1080
ng.sync_camera_project_aspect(scene, ng.scene_aspect_ratio(scene))
refreshed = ngm.refresh_uv_adjust_parameters_for_scene(scene)

chk("Camera Project node follows square render",
    abs(float(cam_node.inputs["Aspect Ratio"].default_value) - 1.0) < 1e-5,
    str(cam_node.inputs["Aspect Ratio"].default_value))
chk("UV Adjust group was refreshed", refreshed >= 1,
    "refreshed=%d" % refreshed)
chk("UV Adjust divide/scale changed",
    tuple(uv_div.inputs[1].default_value) != before_scale,
    "%s -> %s" % (before_scale, tuple(uv_div.inputs[1].default_value)))


print()
print("=" * 68)
print("[5] Shared material is rejected instead of silently overwritten")
print("=" * 68)

scene = fresh_scene()
cam = add_camera(scene)
obj_a = add_plane(scene, "PlaneA", "PlaneDataA")
mat_shared, cp, uv_a, cam_node_a, uv_node_a, texture = make_projection(
    scene, obj_a, cam, "SharedMat")

obj_b = add_plane(scene, "PlaneB", "PlaneDataB")
obj_b.data.materials.append(mat_shared)

link_before = [
    link for link in mat_shared.node_tree.links
    if link.to_socket == texture.inputs["Vector"]
]
result = ngm.create_and_add_uv_adjust_node_group(scene, cam, obj_b)
chk("second object on shared material is rejected",
    result["success"] is False, result["message"])
chk("message explains the shared-material cause",
    "shared" in result["message"].lower()
    and "another object" in result["message"].lower(),
    result["message"])
chk("no orphan group is left behind", result.get("node_group") is None)

link_after = [
    link for link in mat_shared.node_tree.links
    if link.to_socket == texture.inputs["Vector"]
]
chk("existing texture connection was not overwritten",
    len(link_after) == 1 and len(link_before) == 1
    and link_after[0].from_node == link_before[0].from_node)
chk("material still contains exactly one UV Adjust node",
    len([
        n for n in mat_shared.node_tree.nodes
        if n.type == "GROUP" and n.node_tree
        and ngm._uv_group_is_uv_adjust(n.node_tree)
    ]) == 1)


print()
print("=" * 68)
print("[6] Cross-scene replacement is still allowed")
print("=" * 68)

scene_a = fresh_scene()
cam = add_camera(scene_a)
obj_a = add_plane(scene_a, "SrcPlane", "SrcPlaneData")
mat_cross, cp_cross, uv_cross, _, _, texture_cross = make_projection(
    scene_a, obj_a, cam, "CrossMat")

scene_b = bpy.data.scenes.new("CrossScene")
obj_b = add_plane(scene_b, "DstPlane", "DstPlaneData")
obj_b.data.materials.append(mat_cross)
bpy.context.window.scene = scene_b
bpy.context.view_layer.update()

result = ngm.create_and_add_uv_adjust_node_group(scene_b, cam, obj_b)
chk("projection copied from another scene can be replaced",
    result["success"] is True, result["message"])
new_uv = result.get("node_group")
chk("replacement created its own UV Adjust group",
    new_uv is not None and new_uv is not uv_cross)
chk("texture now follows the replacement group",
    any(
        link.to_socket == texture_cross.inputs["Vector"]
        and link.from_node.node_tree is new_uv
        for link in mat_cross.node_tree.links
    ))


print()
print("=" * 68)
print("[7] Handler registration is reload-safe")
print("=" * 68)


def _fake_handler(*_args):
    pass


handlers = []
mod._ensure_handler(handlers, _fake_handler)
mod._ensure_handler(handlers, _fake_handler)


def _old_handler(*_args):
    pass


_old_handler.__name__ = _fake_handler.__name__
handlers.append(_old_handler)
mod._ensure_handler(handlers, _fake_handler)
chk("re-registering keeps exactly one handler",
    handlers == [_fake_handler], handlers)

scene = fresh_scene()
original_sync = mod.sync_camera_project_aspect


def _fail_sync(*_args, **_kwargs):
    raise RuntimeError("synthetic sync failure")


try:
    mod.sync_camera_project_aspect = _fail_sync
    mod.sync_projection_aspect_handler(scene)
finally:
    mod.sync_camera_project_aspect = original_sync
chk("failed sync does not record the aspect signature",
    scene.get(mod._ASPECT_SIG_KEY) is None,
    repr(scene.get(mod._ASPECT_SIG_KEY)))

mod.sync_projection_aspect_handler(scene)
chk("successful sync records the aspect signature",
    scene.get(mod._ASPECT_SIG_KEY) is not None,
    repr(scene.get(mod._ASPECT_SIG_KEY)))


print()
print("=" * 68)
print("PASS %d / FAIL %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("FAILED:", FAIL)
print("TEST_DONE")
print("=" * 68)

sys.exit(1 if FAIL else 0)
