"""Regression: baking a material used by hidden objects must not crash.

Reproduces the original failure:
  source object hidden -> obj.copy() inherits hide flags -> select_set()
  silently fails -> mode_set.poll() reports "Context missing active object".

Run:
  blender --background --factory-startup --python _dev/test_bake_hidden_visibility.py
"""

import bpy
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_bake_visibility_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)

bv = sys.modules[PKG + ".bake_visibility"]
uv = sys.modules[PKG + ".uv_utils"]
bp = sys.modules[PKG + ".bake_pipeline"]

PASS = []
FAIL = []


def chk(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", name, detail))


def make_plane(name):
    mesh = bpy.data.meshes.new(name + "_Mesh")
    mesh.from_pydata(
        [(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)],
        [], [(0, 1, 2, 3)])
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    return obj


def find_layer_collection(layer_collection, name):
    if layer_collection.collection.name == name:
        return layer_collection
    for child in layer_collection.children:
        found = find_layer_collection(child, name)
        if found:
            return found
    return None


print("=" * 62)
print("setup")
print("=" * 62)

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
view_layer = bpy.context.view_layer

# ---------------------------------------------------------------
# 1. Hidden source -> copy -> prepare -> unwrap
# ---------------------------------------------------------------
print("\n[1] hidden source object")
source = make_plane("Hidden_Source")
scene.collection.objects.link(source)
source.hide_set(True)
source.hide_viewport = True
source.hide_render = True
source.hide_select = True
bpy.context.view_layer.update()

summary = bv.summarize_visibility([source], view_layer)
chk("summary sees hidden source",
    summary["hide_viewport"] == 1
    and summary["hide_render"] == 1
    and summary["hide_select"] == 1
    and summary["with_issues"] == 1
    and summary["no_uv"] == 1,
    str(summary))
chk("original is not visible",
    source.hide_get(view_layer=view_layer) is True)

baked = source.copy()
baked.data = source.data.copy()
scene.collection.objects.link(baked)

chk("copy inherits hidden flags",
    baked.hide_viewport and baked.hide_render and baked.hide_select)

fixed = bv.prepare_object_for_bake(
    baked, view_layer, collection=scene.collection)
chk("prepare reports each fix",
    set(fixed) >= {"hide_viewport", "hide_render", "hide_select"},
    str(fixed))
chk("copy is visible and selectable",
    not baked.hide_viewport
    and not baked.hide_render
    and not baked.hide_select
    and baked.hide_get(view_layer=view_layer) is False)
chk("copy is in the current view layer",
    baked.name in view_layer.objects)
chk("original stays hidden and unchanged",
    source.hide_viewport
    and source.hide_render
    and source.hide_select
    and source.hide_get(view_layer=view_layer) is True)

print("\n[2] unwrap hidden-source copy")
uv_result = uv.unwrap_baked_objects(
    [baked], auto_unwrap=False, view_layer=view_layer)
chk("copy got a forced UV layer",
    bool(baked.data.uv_layers.active) and uv_result["forced"] == 1,
    str(uv_result))
chk("original mesh still has no UV layer",
    not source.data.uv_layers.active)
chk("copy and original use separate meshes",
    baked.data != source.data)
chk("both objects are back in Object Mode",
    baked.mode == "OBJECT" and bpy.context.mode == "OBJECT",
    "baked.mode=%s context.mode=%s" % (baked.mode, bpy.context.mode))
chk("copy is the active object after unwrap",
    view_layer.objects.active == baked)

# ---------------------------------------------------------------
# 3. Object excluded from the current view layer
# ---------------------------------------------------------------
print("\n[3] collection excluded from view layer")
excluded_coll = bpy.data.collections.new("Excluded_Coll")
scene.collection.children.link(excluded_coll)
excluded_obj = make_plane("Excluded_Source")
excluded_coll.objects.link(excluded_obj)
layer_coll = find_layer_collection(
    view_layer.layer_collection, excluded_coll.name)
layer_coll.exclude = True
bpy.context.view_layer.update()

excluded_summary = bv.summarize_visibility([excluded_obj], view_layer)
chk("summary sees excluded object",
    excluded_summary["not_in_view_layer"] == 1,
    str(excluded_summary))

excluded_copy = excluded_obj.copy()
excluded_copy.data = excluded_obj.data.copy()
scene.collection.objects.link(excluded_copy)
bpy.context.view_layer.update()
chk("master-collection copy is in view layer",
    excluded_copy.name in view_layer.objects)
bv.prepare_object_for_bake(
    excluded_copy, view_layer, collection=scene.collection)
chk("excluded-source copy can be prepared",
    excluded_copy.name in view_layer.objects
    and not excluded_copy.hide_viewport)

# ---------------------------------------------------------------
# 4. Unlinked object gets linked by prepare
# ---------------------------------------------------------------
print("\n[4] object outside any collection")
orphan = make_plane("Orphan_Copy")
orphan_summary = bv.summarize_visibility([orphan], view_layer)
chk("summary sees unlinked object",
    orphan_summary["not_in_view_layer"] == 1,
    str(orphan_summary))
fixed = bv.prepare_object_for_bake(
    orphan, view_layer, collection=scene.collection)
chk("prepare links object into the view layer",
    "not_in_view_layer" in fixed and orphan.name in view_layer.objects,
    str(fixed))

# ---------------------------------------------------------------
# 5. Low-level error message is explainable
# ---------------------------------------------------------------
print("\n[5] friendly error message")
msg = bp._friendly_error_message(
    RuntimeError(
        "Operator bpy.ops.object.mode_set.poll() Context missing active object"),
    [baked])
chk("mode_set error names the object",
    "Hidden_Source.001" in msg, msg)
chk("mode_set error explains visibility",
    "hidden" in msg.lower() and "view layer" in msg.lower(), msg)

# ---------------------------------------------------------------
# 6. Failed bake cleanup removes only created artifacts
# ---------------------------------------------------------------
print("\n[6] cleanup of failed bake artifacts")
temp_obj = make_plane("Temp_Baked")
scene.collection.objects.link(temp_obj)
temp_mat = bpy.data.materials.new("Temp_Baked_Mat")
temp_img = bpy.data.images.new("Temp_Baked_Img", 8, 8)
keep_obj = make_plane("Keep_Me")
scene.collection.objects.link(keep_obj)

removed = bp._cleanup_bake_artifacts(
    [temp_obj], [temp_mat], [temp_img])
chk("cleanup reports removed objects", removed == 1, str(removed))
chk("temporary object removed",
    bpy.data.objects.get("Temp_Baked") is None)
chk("temporary material removed",
    bpy.data.materials.get("Temp_Baked_Mat") is None)
chk("temporary image removed",
    bpy.data.images.get("Temp_Baked_Img") is None)
chk("unrelated object untouched",
    bpy.data.objects.get("Keep_Me") is not None)

# ---------------------------------------------------------------
# 7. Original data is never passed to cleanup by the pipeline
# ---------------------------------------------------------------
print("\n[7] source object survives cleanup")
bp._cleanup_bake_artifacts([baked], [], [])
chk("bake copy removed",
    bpy.data.objects.get("Hidden_Source.001") is None)
chk("source object still exists",
    bpy.data.objects.get("Hidden_Source") is not None)
chk("source is still hidden",
    source.hide_viewport
    and source.hide_render
    and source.hide_select)

print()
print("=" * 62)
print("PASS %d / FAIL %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("FAILED:", FAIL)
print("=" * 62)

sys.exit(1 if FAIL else 0)
