"""验证：图案冻结（投影组补丁）是否真生效。

用 compify 【真实的 Camera Project 组】建材质，验证：
  A 未打补丁·初始
  B 未打补丁·移动后（图案应滑动）
  C 打补丁·初始（应与 A 完全一致 —— 补丁不影响锁定瞬间的画面）
  D 打补丁·移动后（图案应钉住 = 与 C 一致）
"""
import bpy
import sys
import os
import math
import mathutils
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("Cam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

specs = [(-5.0, 16.0, 0.0, 1.15), (-2.5, 16.0, 0.0, 1.15), (0.0, 16.0, 0.0, 1.15),
         (2.5, 16.0, 0.0, 1.15), (5.0, 16.0, 0.0, 1.15)]
for i, (x, y, z, r) in enumerate(specs):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
    bpy.ops.object.shade_smooth()
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()
ORIG = {o.name: [tuple(v.co) for v in o.data.vertices] for o in meshes}

# 图案
W = H = 512
img = bpy.data.images.new("Footage", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        v = 0.93 if ((x // 32) + (y // 32)) % 2 else 0.05
        R = G = B = v
        d = math.hypot(x - W / 2, y - H / 2)
        if d < 72:
            R, G, B = 0.95, 0.12, 0.10
        elif d < 80:
            R, G, B = 0.98, 0.98, 0.98
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

# ── compify 真实 Camera Project 组 ──
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
print("GROUP:", grp.name if grp else None)

# 材质：组输出 → Image Texture
mat = bpy.data.materials.new("Proj")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gnode = nt.nodes.new("ShaderNodeGroup")
gnode.node_tree = grp
gnode.inputs["Loc X"].default_value = 0.0
gnode.inputs["Loc Y"].default_value = 0.0
gnode.inputs["Rotation"].default_value = 0.0
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gnode.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

# 让 get_lock_targets 认得
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam_data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

print("TARGETS:", len(plock.get_lock_targets(scene, cam)))
print("PROJ_USERS:", len(plock.objects_using_projection(cam_data.name)))

scene.render.resolution_x = 760
scene.render.resolution_y = 320
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 20
scene.cycles.device = "CPU"
OUT = os.path.join(IDES_HOME, "workspace", "_plock_frozen")
os.makedirs(OUT, exist_ok=True)


def shot(n):
    scene.render.filepath = os.path.join(OUT, n + ".png")
    bpy.ops.render.render(write_still=True)
    print("SHOT", n)


def restore():
    for o in meshes:
        f = []
        for c in ORIG[o.name]:
            f.extend(c)
        o.data.vertices.foreach_set("co", f)
        o.data.update()
    bpy.context.view_layer.update()


X0 = cam.location.x
DX = 2.0

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if c else "FAIL", n, d))


def sample_all():
    """每球取 3 个顶点：世界坐标 + 屏幕坐标（官方投影）+ 该顶点的相机深度。

    返回 dict: name -> [(idx, world_co, sx, sy, depth), ...]
    深度沿相机 forward 方向算（用相机矩阵，不用手写公式）。
    """
    fwd = (cam.matrix_world.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))).normalized()
    cpos = cam.matrix_world.translation
    out = {}
    for o in meshes:
        rows = []
        n = len(o.data.vertices)
        for idx in (0, n // 2, n - 1):
            co = o.matrix_world @ o.data.vertices[idx].co
            s = bpy_extras.object_utils.world_to_camera_view(scene, cam, co)
            depth = (co - cpos).dot(fwd)
            rows.append((idx, co.copy(), s.x, s.y, depth))
        out[o.name] = rows
    return out


def maxdiff(a, b):
    """逐顶点比对屏幕坐标最大差（NDC 单位）。"""
    m = 0.0
    for k in a:
        for r1, r2 in zip(a[k], b[k]):
            m = max(m, abs(r1[2] - r2[2]), abs(r1[3] - r2[3]))
    return m


def screen_shifts(a, b):
    """所有顶点的屏幕位移列表 —— 用来验「各层位移是否一致」。"""
    ds = []
    for k in a:
        for r1, r2 in zip(a[k], b[k]):
            ds.append((r2[2] - r1[2], r2[3] - r1[3]))
    return ds


import bpy_extras.object_utils  # noqa: E402  官方投影

# A/B 未打补丁
cam.location.x = X0; bpy.context.view_layer.update(); restore()
shot("A_live_init")
SL_A = sample_all()
cam.location.x = X0 + DX; bpy.context.view_layer.update()
shot("B_live_moved")
SL_B = sample_all()

# 回位 → 锁定（打补丁）→ C 初始
cam.location.x = X0; bpy.context.view_layer.update(); restore()
r = plock.lock_group(scene, cam)
print("LOCK:", r["success"], r["message"])
patched = bool(grp.get(plock.PATCH_KEY))
print("PATCHED:", patched)
ATTR = plock._campos_attr_name(cam_data.name)
has_attr = any(n.type == "ATTRIBUTE" and n.attribute_name == ATTR for n in grp.nodes)
print("ATTR_NODE:", has_attr)
shot("C_frozen_init")
SL_C = sample_all()
# ⚠️ ref_depth 必须在这里读 —— reset_group() 会把 state 清空，
#    放到断言段（reset 之后）读会拿到 None（已踩过）。
REF_DEPTH = float(plock.get_state(scene, cam)["ref_depth"])
print("REF_DEPTH:", REF_DEPTH)

# D 移动 + 变形
cam.location.x = X0 + DX; bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
shot("D_frozen_moved")
SL_D = sample_all()

# 重置 → 验还原
r2 = plock.reset_group(scene, cam)
print("RESET:", r2["success"], r2["message"])
patch_cleared = not bool(grp.get(plock.PATCH_KEY))
print("PATCH_CLEARED:", patch_cleared)
attr_gone = not any(n.type == "ATTRIBUTE" and n.attribute_name == ATTR for n in grp.nodes)
print("ATTR_NODE_REMOVED:", attr_gone)
restore()

# ── 断言 ──
print()
chk("锁定成功", bool(r["success"]), r["message"])
chk("锁定后补丁标记写入", patched)
chk("锁定后 ATTR 节点已插入", has_attr)

# ── 判据的正确口径（这里踩过一个大坑，别改回去）──────────────────────
#
# 平移相机 ≠ 变焦。两者的「构图保持」是两件不同的事：
#
#   变焦（改 lens）：相机沿 forward 移动抵消变焦 ⇒ 每个顶点的屏幕坐标【严格不变】。
#                  用于 test_zoom_dolly，判据就是「屏幕位置不变」。
#   平移（相机横移）：各层按各自深度走 Δ(1−k)，k = 顶点深度 / ref_depth。
#                  世界坐标【必然不同】，屏幕坐标【整体一致地平移】。
#                  所以这里不能要求「屏幕位置不变」——那是错的判据。
#
# 我第一版就错把变焦判据套到了平移上，报出「最大变化 0.1200，FAIL」。
# 查 diag_frozen_truth.py 才看清：世界位移实测 0.09935，
# 而理论 Δ(1−k) = 2.0 × (1 − 22/23.15) = 0.09935 —— 精确吻合，产品没 bug。
#
# 平移的正确判据是三条：
#   ① 对照（未锁定）屏幕必然大幅变化；
#   ② 锁定后【所有顶点的屏幕位移必须相同】（= 构图保持的严格定义）；
#   ③ 世界位移 = Δ(1−k)，逐顶点按各自深度核对（证明是按视锥体而非刚性平移）。

d_live = maxdiff(SL_A, SL_B)
chk("对照（未锁定）移相机后画面确实变了", d_live > 1e-3,
    "最大变化 %.6f —— 若这条不成立，下面『构图保持』就没有说服力" % d_live)

# ② 屏幕位移一致性 —— 这是「构图保持」的严格定义
shifts = screen_shifts(SL_C, SL_D)
sx = [s[0] for s in shifts]
sy = [s[1] for s in shifts]
# 三个球各取 3 顶点，共 9 个采样（5 球 → 15 个）
spread_x = max(sx) - min(sx)
spread_y = max(sy) - min(sy)
chk("锁定后移相机：所有顶点屏幕位移完全相同（构图保持）",
    spread_x < 1e-5 and spread_y < 1e-5,
    "x 位移极差 %.3e，y 位移极差 %.3e，位移量 (%.6f, %.6f)"
    % (spread_x, spread_y, sum(sx) / len(sx), sum(sy) / len(sy)))

# ③ 世界位移 = Δ(1−k)，逐顶点按各自深度核对
ref = REF_DEPTH
dx_world = DX
worst_rel = 0.0
worst_desc = ""
for k_name in SL_C:
    for r0, r1 in zip(SL_C[k_name], SL_D[k_name]):
        real = r1[1].x - r0[1].x
        expect = dx_world * (1.0 - r0[4] / ref)
        rel = abs(real - expect) / max(abs(expect), 1e-9)
        if rel > worst_rel:
            worst_rel = rel
            worst_desc = "%s v%d depth=%.3f 实测 %.6f vs 理论 %.6f" % (
                k_name, r0[0], r0[4], real, expect)
chk("世界位移 = Δ(1−k)（按视锥体，非刚性平移）", worst_rel < 1e-3,
    "最差相对误差 %.2e：%s" % (worst_rel, worst_desc))

# 补丁不该影响锁定瞬间的画面（C 应与 A 一致）
d_ca = maxdiff(SL_A, SL_C)
chk("锁定瞬间画面与锁定前一致（补丁不改初始画面）", d_ca < 1e-4, "最大变化 %.3e" % d_ca)

chk("重置成功", bool(r2["success"]), r2["message"])
chk("重置后补丁标记已清除", patch_cleared)
chk("重置后 ATTR 节点已移除", attr_gone)

print()
print("=" * 88)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("FROZEN_DONE", OUT)
