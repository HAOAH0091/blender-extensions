"""后向注入验证：证明 test_zoom_dolly.py 新加的断言真有判别力。

做法：读 test_zoom_dolly.py 源码 → 人为制造一个**已知错误** → exec →
断言必须变红。若注入后仍全绿，说明那些断言是假的（永远为真）。

注入两处：
  ① theory 放大 5%  ⇒ 「位移量 = ref(k-1)」必须 FAIL
  ② 把构图对比的 S1 整体平移 1e-3  ⇒ 「构图冻结」必须 FAIL

这两个都是本文件的核心判据，必须都能被抓住。
"""
import io
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "test_zoom_dolly.py")
raw = open(SRC, encoding="utf-8").read()


def run(tag, src):
    print("\n" + "=" * 70)
    print("注入:", tag)
    print("=" * 70)
    g = {"__file__": SRC, "__name__": "__main__"}
    try:
        exec(compile(src, SRC, "exec"), g)
    except SystemExit:
        pass
    fails = g.get("F") or []
    print("  >>> 注入后 FAIL 数:", len(fails), fails)


# ── 注入 1：理论值放大 5% ──
s1 = raw.replace("theory = ref * (k - 1.0)", "theory = ref * (k - 1.0) * 1.05")
assert s1 != raw, "注入点 1 没命中——源码变了，先更新注入脚本"
run("theory 放大 5% → 期望『位移量=ref(k-1)』变红", s1)

# ── 注入 2：变焦后的屏幕采样整体平移 1e-3 ──
s2 = raw.replace(
    "S1 = screen_samples()",
    "S1 = [(x + 1e-3, y) for (x, y) in screen_samples()]",
)
assert s2 != raw, "注入点 2 没命中——源码变了，先更新注入脚本"
run("变焦后屏幕采样平移 1e-3 → 期望『构图冻结』变红", s2)

print("\n" + "=" * 70)
print("VERDICT: 若上面两轮各自只红了对应那一条（其余仍绿），断言有判别力。")
print("INJ_DOLLY_DONE")
