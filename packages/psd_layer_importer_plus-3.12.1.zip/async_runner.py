"""异步 PSD 导入/刷新执行器。

把耗时的 PSD 解析、逐层像素渲染、校验和计算、缓存 PNG 写入放后台线程；
主线程用计时器驱动的模态操作符，逐层做 bpy 应用（建物体/贴材质/打包/挪集合/记校验和）。

后台线程遵循「不碰 bpy 数据块」的铁律：所有 bpy 调用都来自主线程。
后台只调用 psd_tools / PIL / numpy / hashlib / os（纯计算与磁盘操作）。

界面不冻结的机理：
  - 后台 C 库（numpy/PIL）运行时释放 GIL，主线程能抢到控制权去重绘、响应用户；
  - 主线程每 tick 只消费一个成品（轻量 bpy 应用），做完立即回到事件循环。
"""

import bpy
import threading
import queue
import os
import hashlib
from typing import Optional, Any


# ==================== 延迟导入（避免循环依赖） ====================

def _mods():
    """延迟导入插件各模块，返回可复用函数的命名空间。"""
    from . import PSD_Layer_Importer as PSL
    from . import psd_utils as U
    from . import parallax_utils as PA
    from . import constants as C
    return PSL, U, PA, C


# ==================== 后台渲染工作线程 ====================

def _perf_opts(context):
    """读「⚙ 设置 → 性能/存储」里的选项（异常安全：拿不到就用默认值）。

    返回 (png_compress_level, workers)
      · png_compress_level：PNG 压缩等级 0~9，越低越快，默认 1
      · workers：写盘并行线程数。默认 min(16, CPU核数)——
        实测 16 线程是提速拐点，再多受内存带宽限制，收益不再涨。
    """
    import os as _os
    lvl = None
    nw = min(16, (_os.cpu_count() or 4))
    try:
        tool = context.scene.psd_import_tool
        lvl = int(tool.png_compress_level)
    except Exception:
        try:
            from .constants import PNG_COMPRESS_LEVEL as _L
            lvl = int(_L)
        except Exception:
            lvl = None
    return lvl, nw


class _RenderWorker(threading.Thread):
    """后台线程：逐层渲染，产出「成品」放入队列。不碰任何 bpy。"""

    def __init__(self, psd, cache_infos, out_queue, cancel_event, status_cb,
                 png_level=None, workers=None):
        super().__init__(daemon=True)
        self.psd = psd
        self.cache_infos = cache_infos  # 主线程预计算：layer/name/cache_png/metadata_hash/snap 等
        self.out_queue = out_queue
        self.cancel_event = cancel_event
        self.status_cb = status_cb
        # PNG 压缩等级（None = 用模块默认常量）；workers<=1 时走原来的串行路径
        self.png_level = png_level
        self.workers = int(workers or 0)

    def run(self):
        _, U, _, _ = _mods()
        total = len(self.cache_infos)
        try:
            if self.workers > 1 and total > 1:
                self._run_parallel(U, total)
                return
            for i, info in enumerate(self.cache_infos):
                if self.cancel_event.is_set():
                    self.out_queue.put({"type": "cancel"})
                    return
                layer = info["layer"]
                self._status(f"渲染中 {i+1}/{total}")

                img = None
                try:
                    img = U.render_layer_rgba(layer)
                except Exception as e:
                    self.out_queue.put({
                        "type": "layer", "index": i, "render_error": repr(e),
                        "snap": info.get("snap", {}),
                    })
                    continue

                pixel_hash = U.compute_image_md5(img) or ""
                png_error = None
                try:
                    if img is not None:
                        U.save_image_png(img, info["cache_png"], self.png_level)
                except Exception as e:
                    png_error = repr(e)

                metadata_hash = info.get("metadata_hash", "")
                expected_checksum = None
                if metadata_hash and pixel_hash:
                    expected_checksum = f"{metadata_hash}_{pixel_hash}"

                self._status(f"渲染中 {i+1}/{total}")
                self.out_queue.put({
                    "type": "layer",
                    "index": i,
                    "img_ready": img is not None,
                    "png_error": png_error,
                    "pixel_hash": pixel_hash,
                    "metadata_hash": metadata_hash,
                    "expected_checksum": expected_checksum,
                    "layer_name": info.get("layer_name", ""),
                    "image_name": info["image_name"],
                    "cache_png": info["cache_png"],
                    "identifier": info.get("identifier", ""),
                    "snap": info.get("snap", {}),
                    "group_path": info.get("group_path", []),
                })
            self.out_queue.put({"type": "done", "total": total})
        except Exception as e:
            import traceback
            self.out_queue.put({"type": "error", "msg": repr(e), "tb": traceback.format_exc()})

    def _run_parallel(self, U, total):
        """并行版渲染：PNG 写盘交给线程池，渲染本身仍逐层串行。

        为什么这么切：
          · 实测 PNG 写盘占首次导入大头（46 层约 8s / 55%），是真瓶颈；
          · psd-tools 的 layer 对象**不保证并发安全**，渲染只占 ~5%，保持串行最稳；
          · PIL 底层 zlib 会释放 GIL，所以写盘用**线程池**就真并行（本机 16 线程约 6~7 倍）。

        分块执行，换来两件事：
          · 内存可控（同时在内存里的图最多 chunk 张，不是全部）
          · 输出**保序**（主线程消费顺序与串行路径完全一致）
        """
        from concurrent.futures import ThreadPoolExecutor
        nw = max(2, min(self.workers, 32))
        chunk = max(2, nw * 2)
        self._status(f"并行渲染中（{nw} 线程）")
        try:
            with ThreadPoolExecutor(max_workers=nw) as pool:
                start = 0
                while start < total:
                    end = min(start + chunk, total)
                    # ① 块内逐层渲染（串行）
                    prepared = []
                    for i in range(start, end):
                        if self.cancel_event.is_set():
                            self.out_queue.put({"type": "cancel"})
                            return
                        info = self.cache_infos[i]
                        self._status(f"渲染中 {i+1}/{total}")
                        img, err = None, None
                        try:
                            img = U.render_layer_rgba(info["layer"])
                        except Exception as e:
                            err = repr(e)
                        prepared.append((i, info, img, err))
                    # ② 块内并行写 PNG
                    futs = []
                    for i, info, img, err in prepared:
                        fut = None
                        if img is not None and err is None:
                            fut = pool.submit(U.save_image_png, img,
                                              info["cache_png"], self.png_level)
                        futs.append((i, info, img, err, fut))
                    # ③ 保序取回并发出（字段与串行路径完全一致）
                    for i, info, img, err, fut in futs:
                        if err is not None:
                            self.out_queue.put({
                                "type": "layer", "index": i, "render_error": err,
                                "snap": info.get("snap", {}),
                            })
                            continue
                        png_error = None
                        if fut is not None:
                            try:
                                fut.result()
                            except Exception as e:
                                png_error = repr(e)
                        pixel_hash = U.compute_image_md5(img) or ""
                        metadata_hash = info.get("metadata_hash", "")
                        expected_checksum = None
                        if metadata_hash and pixel_hash:
                            expected_checksum = f"{metadata_hash}_{pixel_hash}"
                        self.out_queue.put({
                            "type": "layer",
                            "index": i,
                            "img_ready": img is not None,
                            "png_error": png_error,
                            "pixel_hash": pixel_hash,
                            "metadata_hash": metadata_hash,
                            "expected_checksum": expected_checksum,
                            "layer_name": info.get("layer_name", ""),
                            "image_name": info["image_name"],
                            "cache_png": info["cache_png"],
                            "identifier": info.get("identifier", ""),
                            "snap": info.get("snap", {}),
                            "group_path": info.get("group_path", []),
                        })
                    start = end
            self.out_queue.put({"type": "done", "total": total})
        except Exception as e:
            import traceback
            self.out_queue.put({"type": "error", "msg": repr(e), "tb": traceback.format_exc()})

    def _status(self, text):
        """后台线程上报进度状态。

        不直接碰 bpy（后台线程严禁访问 bpy 数据块），改为往 out_queue 丢一个
        status 消息，由主线程 modal 消费时写入面板属性。极轻量，不会堆积。
        """
        try:
            self.out_queue.put({"type": "status", "text": text})
        except Exception:
            pass


# ==================== 主线程模态操作符 ====================

class PSD_OT_AsyncJob(bpy.types.Operator):
    """驱动后台渲染 + 主线程逐层应用的模态操作符。"""

    bl_idname = "psd.async_job"
    bl_label = "后台处理 PSD 图层"
    bl_description = "后台解析渲染 PSD，主线程逐层应用到场景（不冻结界面）"
    bl_options = {"REGISTER", "UNDO"}

    mode: bpy.props.EnumProperty(
        items=[
            ("IMPORT", "导入", ""),
            ("APPEND", "追加导入", ""),
            ("REFRESH", "刷新", ""),
            ("FORCE_REFRESH", "强制刷新", ""),
            ("REFRESH_SELECTED", "刷新选中", ""),
        ],
        name="模式",
        default="REFRESH",
    )
    file_index: bpy.props.IntProperty(default=-1)

    PROP_ACTIVE = "refresh_active"
    PROP_PROGRESS = "refresh_progress"
    PROP_STATUS = "refresh_status"

    def invoke(self, context, event):
        # 互斥：已有后台任务在运行时拒绝新的，避免缓存写竞争/对象并发
        try:
            if context.scene.psd_import_tool.refresh_active:
                self.report({"WARNING"}, "已有 PSD 后台任务在运行，请先等待或取消")
                try:
                    from . import PSD_Layer_Importer as _PSL
                    _PSL._last_async_error = "已有 PSD 后台任务在运行，请先等待完成或取消"
                except Exception:
                    pass
                return {"CANCELLED"}
        except Exception:
            pass

        self._mode = self.mode
        self._file_index = self.file_index

        # 构建任务上下文（主线程准备，含后台要用的 info）。
        # _build 若返回 False 会设 self._error 并 CANCELLED; 若抛异常则由
        # launch_async_job 捕获并记录到 _last_async_error。这里不 catch，
        # 让异常向上传给 bpy.ops → launch_async_job 能拿到并记录真实原因。
        ok = self._build(context)
        if not ok:
            err = getattr(self, "_error", "启动失败")
            # IMPORT 构建失败 → 回滚刚登记的空记录（+ 本次新建且仍为空的集合），
            # 避免留下指向坏文件 / 空 PSD 的"幽灵卡片"。
            if self._mode == "IMPORT":
                try:
                    psd_tool = context.scene.psd_import_tool
                    idx = getattr(self, "_import_rec_index", -1)
                    if 0 <= idx < len(psd_tool.file_records):
                        psd_tool.file_records.remove(idx)
                    col = getattr(self, "_collection", None)
                    if getattr(self, "_import_created_collection", False) and col is not None:
                        if len(col.objects) == 0 and len(col.children) == 0:
                            bpy.data.collections.remove(col)
                except Exception:
                    pass
            self._report(context, {"ERROR"}, err)
            # 让 launch_async_job 在检测到 CANCELLED 时能拿到具体原因
            try:
                from . import PSD_Layer_Importer as _PSL
                _PSL._last_async_error = err
            except Exception:
                pass
            return {"CANCELLED"}

        # 启动后台线程
        self._cancel = threading.Event()
        self._done_count = 0
        self._total = len(self._cache_infos)
        self._failed_layers = 0
        self._finished = False
        self._out_queue = queue.Queue()
        self._backlog = []  # 本 tick 取出但超配额未处理的 item，下个 tick 先消费（修复 S1 漏图层）
        self._applications_succeeded = 0  # 真实成功应用的图层数（S1/M3 进度口径）
        self._created_objects = []        # 本批次**新建**的对象（追加后自动选中用）

        _lvl, _nw = _perf_opts(context)
        try:
            from .constants import _psd_log as _plog
            _plog(f"[PSD-性能] PNG压缩等级={_lvl}, 写盘线程数={_nw}")
        except Exception:
            pass
        self._worker = _RenderWorker(
            self._psd, self._cache_infos, self._out_queue, self._cancel, None,
            png_level=_lvl, workers=_nw,
        )
        self._worker.start()

        # 计时器 + 模态
        self._timer = context.window_manager.event_timer_add(0.05, window=context.window)
        context.window_manager.modal_handler_add(self)

        # 初始化进度
        self._set_active(True)
        self._set_status("解析中…")
        self._set_progress(0.0)

        return {"RUNNING_MODAL"}

    # ---------------- 构建（主线程） ----------------

    def _resolve_active_ids(self, rec):
        """刷新/强制刷新时生效的图层 identifier 集合（= record 的已导入清单）。

        清单是**唯一口径**：
        - None  = 该模式不按清单过滤（导入/追加/选中刷新 —— 各自另有依据）
        - set() = 清单为空 → 当前不管理任何图层（刷新不动任何东西）

        ⚠️ 不再针对"旧工程（无清单）"做全量兜底 —— 那会造成两套口径
        （列表显示"都没勾选"，刷新却全量更新）。旧工程要恢复管理，
        在列表里点「全选」或重新导入即可。
        """
        if self._mode not in ("REFRESH", "FORCE_REFRESH"):
            return None
        if rec is None:
            return None
        raw = getattr(rec, "imported_layer_ids", "")
        return set(x for x in raw.split(",") if x)

    def _build(self, ctx):
        PSL, U, PA, C = _mods()
        psd_tool = ctx.scene.psd_import_tool

        rec = None
        if 0 <= self._file_index < len(psd_tool.file_records):
            rec = psd_tool.file_records[self._file_index]

        # ---- 文件路径 ----
        if self._mode == "IMPORT":
            filepath = getattr(PSL, "_import_filepath", "")
        elif self._mode == "REFRESH_SELECTED":
            # 选中刷新没有统一 file_index，需要从选中对象反查所属 PSD record
            sel_rec = self._find_selected_record(ctx)
            self._record = sel_rec
            filepath = sel_rec.filepath if sel_rec else ""
        else:
            filepath = rec.filepath if rec else ""
        if not filepath:
            self._error = "未指定 PSD 文件路径"
            return False
        self._filepath = filepath

        # IMPORT 模式：新建 file record 并登记（含相机/文件信息）
        if self._mode == "IMPORT":
            rec = psd_tool.file_records.add()
            # 记下刚登记的记录下标：构建若失败要回滚它，避免留下"幽灵卡片"。
            self._import_rec_index = len(psd_tool.file_records) - 1
            rec.filepath = filepath
            try:
                rec.file_mtime = repr(os.path.getmtime(filepath))
            except (OSError, IOError):
                rec.file_mtime = ""
            if ctx.scene.camera:
                rec.camera = ctx.scene.camera
                rec.last_camera_transform = str(ctx.scene.camera.matrix_world)
                rec["last_camera_position"] = list(ctx.scene.camera.matrix_world.translation)
            self._record = rec
        elif self._mode == "REFRESH_SELECTED":
            # 已在路径解析处反查，self._record 已是选中对象所属 record
            rec = self._record  # 局部 rec 对齐，供后续读取刷新选项/集合
        else:
            self._record = rec

        # ---- 打开 PSD（主线程，读取型）----
        try:
            self._psd = C.open_psd(filepath)
        except Exception as e:
            self._error = f"无法打开 PSD 文件: {e}"
            return False
        self._psd_width, self._psd_height = self._psd.size
        self._base_name = bpy.path.display_name_from_filepath(filepath)

        # 数据源日志（排查"改了没反应"：确认读的是哪个文件、何时读、是否已解析）
        try:
            mtime = os.path.getmtime(filepath)
        except (OSError, IOError):
            mtime = 0.0
        C._psd_log(
            f"[PSD-入口] 异步处理: mode={self._mode}, file='{filepath}', "
            f"base='{self._base_name}', size={self._psd_width}x{self._psd_height}, "
            f"mtime={mtime}"
        )

        # ---- 刷新选项（全局统管）----
        # v3.11.0 起：刷新选项收归「⚙ 设置」子面板，全局一份；不再每张卡片各一份。
        _gtool = getattr(getattr(ctx, "scene", None), "psd_import_tool", None)
        if _gtool is not None:
            self._update_texture = bool(getattr(_gtool, "refresh_update_texture", True))
            self._update_mesh = bool(getattr(_gtool, "refresh_update_mesh", False))
            self._update_transform = bool(getattr(_gtool, "refresh_update_transform", False))
            self._update_structure = bool(getattr(_gtool, "refresh_update_structure", False))
            # 隐藏层开关：本次任务是否连 PSD 里的隐藏图层/文件夹一起收
            self._include_hidden = bool(getattr(_gtool, "include_hidden_layers", False))
        else:
            self._update_texture = True
            self._update_mesh = False
            self._update_transform = False
            self._update_structure = False
            self._include_hidden = False

        # ---- 集合 ----
        collection = None
        if rec is not None:
            collection = PA.get_collection_from_record(rec)
        if collection is None:
            # 未记录集合时按名称查找（IMPORT 时可能尚不存在，需创建）
            collection = bpy.data.collections.get(self._base_name)
            if collection is None and self._mode == "IMPORT":
                collection = bpy.data.collections.new(self._base_name)
                # 本次新建了集合 → 失败回滚时若它仍为空则一并删掉，别留空壳。
                self._import_created_collection = True
                try:
                    ctx.scene.collection.children.link(collection)
                except (RuntimeError, ValueError):
                    pass
        self._collection = collection

        # 防御：非 IMPORT 且找不到集合时，提前报错（避免后续 find_layer_object_in_tree(None,...) 崩溃）
        if self._mode != "IMPORT" and collection is None:
            self._error = f"找不到名为 {self._base_name} 的集合"
            return False

        # S2修复：IMPORT 时把集合引用写回 record，保证后续"选中刷新"能按 collection 精确反查
        if self._mode == "IMPORT" and rec is not None and collection is not None:
            try:
                rec.collection = collection
            except Exception:
                pass

        # ---- 提取图层 ----
        self._id_to_path = {}
        # 本次生效的图层 identifier 集合（None=无清单，沿用全量=旧行为）
        self._active_ids = self._resolve_active_ids(rec)
        if self._mode in ("IMPORT", "APPEND"):
            hierarchy_tree, flat = U.extract_layer_hierarchy(self._psd, getattr(self, "_include_hidden", False))
            # name_index 要用【整份 PSD 的层数】算，否则部分导入时会得到负数
            self._name_total = len(flat)
            # 卡片图层列表缓存：存【整份 PSD 的完整层级】（含未勾选层），
            # 供卡片展开时显示"有哪些层 / 哪些已导入"。必须在按勾选裁剪**之前**写。
            if rec is not None:
                try:
                    rec.layer_list_json = U.build_layer_list_json(hierarchy_tree)
                except Exception as ex:
                    C._psd_log(f"[PSD-列表] 写图层列表缓存失败: {type(ex).__name__}: {ex}")
            # 图层选择：指定了勾选集合时只保留勾选的图层（None=全选，保持旧行为）
            sel = getattr(PSL, "_import_selected_ids", None)
            if sel is not None:
                # 结构一并按勾选裁剪，避免为未导入图层建出空文件夹集合
                hierarchy_tree = U.filter_hierarchy_by_ids(hierarchy_tree, sel)
                flat = [e for e in flat if e["identifier"] in sel]
            if flat:
                U.ensure_collection_tree(collection, hierarchy_tree, self._base_name)
                if rec is not None:
                    rec.group_hierarchy = U.serialize_hierarchy_snapshot(hierarchy_tree)
                for e in flat:
                    self._id_to_path[e["identifier"]] = e["group_path"]
            self._flat_list = flat
        elif self._mode == "REFRESH" and self._update_structure:
            self._id_to_path, self._flat_list = U.sync_collection_structure(
                self._psd, rec, collection, self._base_name,
                active_ids=self._active_ids,
            )
        elif self._mode == "FORCE_REFRESH" and self._update_structure:
            self._id_to_path, self._flat_list = U.sync_collection_structure(
                self._psd, rec, collection, self._base_name,
                active_ids=self._active_ids,
            )
        elif self._mode == "REFRESH_SELECTED":
            # M1'：选中刷新支持跨多 PSD。收集选中对象跨的所有 record，
            # 逐 PSD 提取并生成 cache_infos（各 info 自含所属 PSD 的 size/collection）。
            try:
                infos, flat = self._collect_selected_multi(ctx)
            except Exception as e:
                import traceback
                C._psd_log(f"[PSD-异常] _collect_selected_multi 失败: {type(e).__name__}: {e}")
                C._psd_log(f"[PSD-异常] 堆栈: {traceback.format_exc()}")
                self._error = f"选中刷新准备失败: {e}"
                return False
            if not infos:
                self._error = "选中的图层未匹配到所属 PSD 的可见图层"
                return False
            self._cache_infos = infos
            self._flat_list = flat
            self._total = len(infos)
            # record 相关收尾（选中刷新不写 checksum/layer_order，仅更新引用）
            return True
        else:
            non_group = U.get_visible_layers(self._psd, getattr(self, "_include_hidden", False))
            self._flat_list = []
            for i, disp, layer, ident in non_group:
                self._flat_list.append({
                    "layer": layer, "identifier": ident,
                    "group_path": [], "display_index": disp, "i": i,
                })
            # 刷新按「已导入清单」过滤，不把 PSD 里未勾选的图层带进来
            if self._active_ids is not None:
                self._flat_list = [
                    e for e in self._flat_list if e["identifier"] in self._active_ids
                ]

        if not self._flat_list:
            # 分清两种"空"：PSD 里本来就没有可见层 vs 有层但一个都没归插件管
            if self._active_ids is not None and len(self._active_ids) == 0:
                self._error = "该 PSD 还没有勾选任何图层（在卡片列表里勾选后再试）"
            else:
                self._error = "PSD 中没有找到可见的图层"
            return False

        # name_index 基于整份 PSD 层数（IMPORT/APPEND 已在过滤前设 _name_total），
        # 使同一图层无论「部分导入」还是「全量导入」得到相同的名字与缓存路径。
        total_count = getattr(self, "_name_total", None)
        if total_count is None:
            total_count = len(self._flat_list)

        # ---- 预计算 cache info（主线程，因走 bpy.path）----
        infos = []
        for entry in self._flat_list:
            layer = entry["layer"]
            disp_idx = entry["display_index"]
            name_index = total_count - 1 - disp_idx
            image_name = f"{name_index}_{self._base_name}_{layer.name}"
            identifier = entry.get("identifier") or U.create_layer_identifier(layer)
            cache_png = U.get_cache_png_path(filepath, name_index, identifier, layer.name)
            try:
                l, t, r, b = U._get_layer_bbox(layer)
                metadata = f"{layer.name}{l}{t}{r}{b}"
                metadata_hash = hashlib.md5(metadata.encode()).hexdigest()
            except Exception:
                metadata_hash = ""
            infos.append({
                "layer": layer,
                "display_index": disp_idx,
                "name_index": name_index,
                "image_name": image_name,
                "cache_png": cache_png,
                "identifier": identifier,
                "layer_name": layer.name,
                "metadata_hash": metadata_hash,
                "group_path": entry.get("group_path", []),
                # M1'：每个 info 自包含所属 PSD 的尺寸与目标集合，支持跨多 PSD 的选中刷新
                "psd_width": self._psd_width,
                "psd_height": self._psd_height,
                "collection": collection,
                "snap": {
                    "left": int(layer.left), "top": int(layer.top),
                    "width": int(layer.width), "height": int(layer.height),
                },
            })
        self._cache_infos = infos
        self._total = total_count
        return True

    def _collect_selected(self, ctx):
        _, U, _, _ = _mods()
        selected = [o for o in ctx.selected_objects if o.get("layer_identifier")]
        flat = []
        all_layers = U.get_visible_layers(self._psd, getattr(self, "_include_hidden", False))
        for obj in selected:
            oid = obj.get("layer_identifier")
            for i, disp, layer, ident in all_layers:
                if ident == oid:
                    flat.append({
                        "layer": layer, "identifier": ident,
                        "group_path": [], "display_index": disp, "i": i,
                    })
                    break
        return flat

    def _collect_selected_multi(self, ctx):
        """M1'：支持跨多个 PSD 的选中刷新。

        把选中对象按所属 collection 分组；对每组反查其 record、打开对应 PSD、
        提取该 PSD 的可见图层并用本组选中对象匹配，生成 cache_infos（各 info 自含
        所属 PSD 的 size/collection）。合并所有组返回 (infos, flat_list)。
        若选中对象只属一个 PSD，结果与单 PSD 流程一致。

        分组 key 用 id(col)（对象身份），避免同名 collection 被合并（A）。
        """
        PSL, U, _, C = _mods()
        psd_tool = ctx.scene.psd_import_tool
        # 按 collection 对象身份分组：{id(col): {"col": col, "objs": [...]}}
        groups = {}
        selected = [o for o in ctx.selected_objects if o.get("layer_identifier")]
        for obj in selected:
            col = obj.users_collection[0] if obj.users_collection else None
            if not col:
                continue
            g = groups.setdefault(id(col), {"col": col, "objs": []})
            g["objs"].append(obj)

        infos = []
        flat_all = []
        self._psd_filepaths = getattr(self, "_psd_filepaths", []) or []
        for _cid, grp in groups.items():
            col = grp["col"]
            objs = grp["objs"]
            rec = self._find_selected_record(ctx, col)
            if not rec:
                continue
            filepath = rec.filepath
            if not filepath:
                continue
            try:
                psd = C.open_psd(filepath)
            except Exception:
                continue
            if filepath not in self._psd_filepaths:
                self._psd_filepaths.append(filepath)
            base_name = bpy.path.display_name_from_filepath(filepath)
            # C：跨同名 PSD 时给图片/缓存名加 filepath 短 hash，避免同名 base 碰撞
            fp_key = hashlib.md5(filepath.encode("utf-8", "replace")).hexdigest()[:6]
            W, H = psd.size
            # 该 PSD 的全部可见图层
            all_layers = U.get_visible_layers(psd, getattr(self, "_include_hidden", False))
            # 匹配本组选中对象（oid -> layer）
            wanted = {}
            for o in objs:
                oid = o.get("layer_identifier")
                for i, disp, layer, ident in all_layers:
                    if ident == oid:
                        wanted[oid] = (layer, disp)
                        break
            total_count = len(all_layers)
            for o in objs:
                oid = o.get("layer_identifier")
                if oid not in wanted:
                    continue  # 该对象不属于此 PSD（理论上不会，防御）
                layer, disp = wanted[oid]
                name_index = total_count - 1 - disp
                image_name = f"{name_index}_{base_name}_{fp_key}_{layer.name}"
                cache_png = U.get_cache_png_path(filepath, name_index, oid, layer.name)
                try:
                    l, t, r, b = U._get_layer_bbox(layer)
                    mh = hashlib.md5(f"{layer.name}{l}{t}{r}{b}".encode()).hexdigest()
                except Exception:
                    mh = ""
                infos.append({
                    "layer": layer, "display_index": disp, "name_index": name_index,
                    "image_name": image_name, "cache_png": cache_png,
                    "identifier": oid, "layer_name": layer.name,
                    "metadata_hash": mh, "group_path": [],
                    "psd_width": W, "psd_height": H, "collection": col,
                    "snap": {"left": int(layer.left), "top": int(layer.top),
                             "width": int(layer.width), "height": int(layer.height)},
                })
                flat_all.append({"layer": layer, "identifier": oid,
                                 "group_path": [], "display_index": disp, "i": disp})
        return infos, flat_all

    def _collection_chain(self, col):
        """返回 [col, col的父集合, 祖父集合, ...] 的集合链（从当前集合向上到根）。

        选中刷新的对象可能落在子集合里(按 PSD 文件夹生成)，但 record 关联的是主集合。
        因此反查 record 时需沿对象所在集合的祖先链向上匹配，直到与 rec.collection 对上。
        已去重，且用 visited 集合防死循环。
        """
        if col is None:
            return []
        chain = []
        visited = set()
        cur = col
        all_cols = list(bpy.data.collections)
        while cur is not None:
            if cur.name in visited:
                break
            visited.add(cur.name)
            chain.append(cur)
            # 找父集合：某个集合 c 的 children 里含有名为 cur.name 的子集合
            parent = None
            for c in all_cols:
                if c.name in visited:
                    continue
                try:
                    child_names = [ch.name for ch in c.children]
                    if cur.name in child_names:
                        parent = c
                        break
                except Exception:
                    pass
            cur = parent
        return chain

    def _find_selected_record(self, ctx, collection=None):
        """从选中对象反查所属 PSD 记录（与原始 RefreshSelectedLayers 逻辑一致）。

        优先按 collection 引用匹配；失败再按集合名称回退。
        collection 指定时只用该集合；否则遍历选中对象。
        返回 record 或 None。
        """
        _, _, PA, _ = _mods()
        psd_tool = ctx.scene.psd_import_tool

        def _match(col):
            # 按 collection 引用匹配
            rec = next(
                (f for f in psd_tool.file_records
                 if hasattr(f, "collection") and f.collection == col),
                None,
            )
            if rec:
                return rec
            # 名称回退
            rec = next(
                (f for f in psd_tool.file_records
                 if bpy.path.display_name_from_filepath(f.filepath) == col.name),
                None,
            )
            if rec:
                # M2修复：名称回退命中后写回 collection 引用，避免每次都走回退
                try:
                    if hasattr(rec, "collection"):
                        rec.collection = col
                except Exception:
                    pass
                return rec
            return None

        if collection is not None:
            # 沿集合链(含祖先)匹配，因为对象可能在子集合里，record 关联的是主集合
            for c in self._collection_chain(collection):
                rec = _match(c)
                if rec:
                    return rec
            return None

        selected = [o for o in ctx.selected_objects if o.get("layer_identifier")]
        seen = set()
        for obj in selected:
            # 对象可能在子集合里：匹配"对象所在集合 + 其所有祖先集合"
            start = obj.users_collection[0] if obj.users_collection else None
            if not start:
                continue
            for c in self._collection_chain(start):
                if c.name in seen:
                    continue
                seen.add(c.name)
                rec = _match(c)
                if rec:
                    return rec
        return None

    def _find_by_name(self, collection, layer_name):
        """按图层名在集合树里查找已有对象（用于判断"id 变了但名字还在"）。

        对象名格式为 {name_index}_{base_name}_{layer_name}_object，
        用 layer_name 做子串匹配（避免 name_index 前缀干扰）。
        返回匹配的对象或 None。
        """
        _, U, PA, _ = _mods()
        if collection is None:
            return None
        try:
            objs = PA.get_all_objects_recursive(collection)
        except Exception:
            return None
        # 精确后缀匹配优先（layer_name 在对象名末尾），其次是子串包含
        for o in objs:
            base = o.name
            if base.endswith(f"_{layer_name}") or base.endswith(f"_{layer_name}_object"):
                return o
        for o in objs:
            if layer_name and layer_name in o.name:
                return o
        return None

    def _find_by_name_all(self, collection, layer_name):
        """按图层名返回【所有】匹配对象（同名多候选时，迁移须跳过以免张冠李戴）。"""
        _, U, PA, _ = _mods()
        if collection is None:
            return []
        try:
            objs = PA.get_all_objects_recursive(collection)
        except Exception:
            return []
        exact = [o for o in objs
                 if o.name.endswith(f"_{layer_name}") or o.name.endswith(f"_{layer_name}_object")]
        if exact:
            return exact
        return [o for o in objs if layer_name and layer_name in o.name]

    # ---------------- 模态 ----------------

    def modal(self, context, event):
        if event.type == "ESC":
            self._teardown(context, cancelled=True)
            return {"CANCELLED"}
        if event.type != "TIMER":
            return {"RUNNING_MODAL"}

        processed = False
        # 每 tick 处理少量图层，避免单次卡太久（保持界面响应）。
        # status 消息极轻量（只更新面板文本），不计入图层处理额度。
        #
        # 【S1修复】不再把超配额的 item 放回 queue（FIFO 会破坏顺序、让 done 抢在 layer 前，
        # 导致漏图层）。改为：先把队列里的全部消息搬到 self._backlog（保持顺序），
        # 再从 backlog 队头依次处理。终止信号(done/error/cancel)只在其前面的 layer 都已
        # 处理完（即它成为 backlog 队头）时才触发，从根本上杜绝"漏图层但报完成"。
        max_per_tick = 2
        processed_layers = 0
        terminate_item = None

        # 1) 搬队列 → backlog（保持 FIFO 顺序，不丢失任何消息）
        while True:
            try:
                item = self._out_queue.get_nowait()
            except queue.Empty:
                break
            self._backlog.append(item)

        # 2) 从 backlog 队头开始处理
        while self._backlog:
            head = self._backlog[0]
            t = head.get("type")
            if t == "status":
                self._backlog.pop(0)
                self._set_status(head.get("text", ""))
                processed = True
                continue
            if t in ("done", "error", "cancel"):
                # 终止信号：出现在队头说明前面的 layer 都已处理完，安全结束
                self._backlog.pop(0)
                terminate_item = head
                processed = True
                break
            # layer
            if processed_layers >= max_per_tick:
                # 本 tick 配额已满，剩余 layer 留在 backlog 供下个 tick 处理（不丢失）
                break
            self._backlog.pop(0)
            processed_layers += 1
            processed = True
            self._handle_item(context, head)

        # 3) 处理终止信号（若有）
        if terminate_item is not None:
            self._handle_item(context, terminate_item)

        # 进度用真实成功应用数（S1/M3 口径），避免漏处理时虚高
        progress_count = self._applications_succeeded
        frac = (progress_count / self._total) if self._total else 1.0
        self._set_progress(frac)
        self._set_status(f"处理中 {progress_count}/{self._total}")

        try:
            for area in context.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
                elif area.type in ("PROPERTIES", "VIEW_3D"):
                    area.tag_redraw()
        except Exception:
            pass

        if self._finished:
            self._teardown(context)
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def _handle_item(self, context, item):
        t = item.get("type")
        if t == "layer":
            self._apply_layer(context, item)
        elif t == "done":
            # 保留真实计数（_done_count 每层+1，_applications_succeeded 是成功应用数），
            # 不再强制置为 total——避免漏处理时虚高（S1/M3）
            self._finished = True
            self._finalize(context)
        elif t == "error":
            self._report(context, {"ERROR"}, f"后台处理出错: {item.get('msg', '')}")
            self._finished = True
        elif t == "cancel":
            self._finished = True

    def _apply_layer(self, context, item):
        PSL, U, _, C = _mods()
        log = C._psd_log
        try:
            idx = item["index"]
            if idx >= len(self._cache_infos):
                return
            info = self._cache_infos[idx]
            layer = info["layer"]
            disp_idx = info["display_index"]
            image_name = info["image_name"]
            cache_png = info["cache_png"]
            expected_checksum = item.get("expected_checksum")

            if item.get("render_error"):
                raise RuntimeError(f"渲染失败: {item['render_error']}")
            if item.get("png_error"):
                raise RuntimeError(f"PNG 写入失败: {item['png_error']}")

            info_col = info.get("collection", self._collection)
            info_w, info_h = info.get("psd_width", self._psd_width), info.get("psd_height", self._psd_height)
            layer_name = info.get("layer_name", layer.name)

            # ===== 匹配决策日志（排查"改了没反应"关键点）=====
            # 先尝试按 layer_id 精确匹配
            existing_obj = U.find_layer_object_in_tree(info_col, info["identifier"])
            matched_mode = "id"
            # 若按 id 没匹配到，尝试按"图层名"搜索场景里是否有同名对象（判断是否 id 变了但名字还在）
            name_match = None
            if existing_obj is None:
                name_match = self._find_by_name(info_col, layer_name)
                if name_match is not None:
                    matched_mode = "name"
            if existing_obj is None and name_match is not None:
                # id 匹配失败但名字匹配到。
                # 特例：本修复前，对「缺 layer_id 的 PSD」identifier 一律被写成 "-1"；
                # 若命中对象带的正是这种旧值，说明是同一图层、只是编号方式升级了，
                # 迁移到新 identifier 并就地更新，避免刷新时重复建对象。
                old_id = name_match.get(C.ATTR_LAYER_ID)
                cands = self._find_by_name_all(info_col, layer_name) if old_id in (None, "", "-1") else []
                if old_id in (None, "", "-1") and len(cands) == 1:
                    try:
                        name_match[C.ATTR_LAYER_ID] = info["identifier"]   # 迁移对象属性
                    except Exception:
                        pass
                    # 同步迁移该层的旧 checksum（避免残留 "-1" 孤儿，保住内容比对基线）
                    try:
                        if self._record is not None:
                            for cs in self._record.layer_checksums:
                                if cs.identifier in (None, "", "-1") and cs.name == layer_name:
                                    cs.identifier = info["identifier"]
                    except Exception:
                        pass
                    existing_obj = name_match
                    name_match = None
                    log(f"[PSD-匹配] layer='{layer_name}': 旧 identifier={old_id!r} → 迁移为 "
                        f"'{info['identifier']}' 并就地更新（兼容修复前的旧文件）")
                elif old_id in (None, "", "-1"):
                    # 同名多候选：无法确定哪一层是它，跳过迁移（保守，避免张冠李戴）
                    log(f"[PSD-匹配] layer='{layer_name}': 旧 identifier={old_id!r} 但有 "
                        f"{len(cands)} 个同名对象，无法确定归属 → 跳过迁移")
                else:
                    # 说明图层本体可能被换（id 变），名字还在。
                    log(f"[PSD-匹配] layer='{layer_name}' id={info['identifier']}: 按id未匹配到, 但按名字命中 "
                        f"名称='{name_match.name}' → 疑似图层本体被替换(id变化)")
            elif existing_obj is None:
                log(f"[PSD-匹配] layer='{layer_name}' id={info['identifier']}: 按id未匹配到, 按名字也未命中"
                    f" → 判定为新增图层")
            else:
                log(f"[PSD-匹配] layer='{layer_name}' id={info['identifier']}: 按id命中 "
                    f"existing='{existing_obj.name}' → 走更新")

            # 追加导入-「追加为新图层」：忽略已有匹配，总是新建（重名时 Blender 自动加 .001 序号）
            if self._mode == "APPEND" and getattr(PSL, "_import_append_mode", "NEW") == "NEW":
                existing_obj = None
                name_match = None
            force = (self._mode == "REFRESH_SELECTED")
            if existing_obj is not None:
                # 预判校验结果：本次 expected_checksum 与旧记录对比（定位"改了但校验命中跳过"）
                old_ck = None
                if self._record is not None:
                    try:
                        old = next((cs for cs in self._record.layer_checksums
                                    if cs.name == layer_name), None)
                        if old is not None:
                            old_ck = old.value
                    except Exception:
                        old_ck = None
                if self._update_texture and expected_checksum:
                    if old_ck == expected_checksum:
                        log(f"[PSD-校验] layer='{layer_name}': 本次期望值==旧记录"
                            f"({expected_checksum[:16]}...) → 若贴图像上校验亦命中, 将被判定无变化跳过")
                    else:
                        log(f"[PSD-校验] layer='{layer_name}': 本次期望值!=旧记录"
                            f"(旧={old_ck[:16] if old_ck else '无'}, 新={expected_checksum[:16]}...) → 应触发更新")

                PSL.update_existing_layer_object(
                    context, existing_obj, layer,
                    info_w, info_h, disp_idx,
                    self._update_texture, self._update_mesh, self._update_transform,
                    cache_png, expected_checksum, info_col,
                    force=force,
                    pack=(U.get_texture_store_mode() == "PACK"),
                )
                log(f"[PSD-刷新结果] layer='{layer_name}': 已更新已有对象 '{existing_obj.name}' "
                    f"(贴图更新={'是' if self._update_texture else '否'} checksum={'有' if expected_checksum else '无'})")
                self._report(context, {"INFO"}, f"图层 '{layer_name}': 已更新")
                # 友好提示：只更新贴图且做了 UV 位置校正时，提醒若仍偏移该怎么办
                try:
                    if self._update_texture and not self._update_mesh:
                        adj = PSL.calculate_adjusted_uv(existing_obj, layer)
                        if adj is not None:
                            log(f"[PSD-UV] layer='{layer_name}': 已做UV位置校正(按旧网格对齐新贴图)")
                            self._report(
                                context, {"INFO"},
                                f"图层 '{layer_name}': 贴图已按旧网格位置对齐"
                                f"(若仍有偏移, 建议在刷新选项勾选『网格』)"
                            )
                except Exception:
                    pass
            else:
                target_col = U.get_target_collection_for_layer(info_col, info["group_path"])
                is_append = (self._mode == "APPEND")
                new_obj = PSL.process_layer_from_cache(
                    context, layer, image_name, target_col,
                    info_w, info_h, disp_idx,
                    cache_png, is_new=True, expected_checksum=expected_checksum,
                    force=force,
                    # 不再强制加 .NNN：交给 Blender 自然命名（只有真撞名才加后缀）。
                    # 这样「删干净后再追加」拿到的是干净的原始名，而不是 .001。
                    force_suffix=False,
                    # 追加 = 完全独立的数据块（独立贴图/材质），互不共用；
                    # 首次导入的对象打「原始」标记（供行尾 ✕ 认出原始那份）。
                    independent=is_append,
                    is_primary=not is_append,
                    # 对象属性写入同一 identifier（与勾选过滤/checksum 一致）
                    identifier=info.get("identifier"),
                    # 贴图存放：打包进工程 or 外放 PSD_texture 文件夹（读「⚙ 设置」）
                    pack=(U.get_texture_store_mode() == "PACK"),
                )
                if new_obj is not None:
                    self._created_objects.append(new_obj)
                if name_match is not None:
                    # 按名字找到了旧的，但现在却新建了——说明 id 变了导致匹配丢失，提示用户
                    msg = (f"图层 '{layer_name}': 未匹配到已有对象(PSD里可能删/改名/调了结构), "
                           f"已作为新图层导入")
                    log(f"[PSD-刷新结果] layer='{layer_name}': {msg}")
                    self._report(context, {"INFO"}, msg)
                else:
                    msg = f"图层 '{layer_name}': 新增"
                    log(f"[PSD-刷新结果] layer='{layer_name}': 新增图层")
                    self._report(context, {"INFO"}, msg)

            if self._mode != "REFRESH_SELECTED" and self._record is not None:
                self._write_checksum(info, expected_checksum)

            self._done_count += 1
            self._applications_succeeded += 1
        except Exception as e:
            self._failed_layers += 1
            self._report(context, {"WARNING"}, f"处理图层 '{item.get('layer_name', '')}' 时出错: {e}")
            self._done_count += 1

    def _write_checksum(self, info, expected_checksum):
        record = self._record
        try:
            ident = info.get("identifier", "")
            layername = info["layer_name"]
            existing = None
            # 优先按图层 ID 匹配（同名图层不再互相覆盖）；旧记录无 ID 时回退按名字
            if ident:
                existing = next((cs for cs in record.layer_checksums
                                 if cs.identifier == ident), None)
            if existing is None:
                existing = next((cs for cs in record.layer_checksums
                                 if (not cs.identifier) and cs.name == layername), None)
            value = expected_checksum or ""
            if existing is None:
                nc = record.layer_checksums.add()
                nc.name = layername
                nc.identifier = ident
                nc.value = value
            else:
                existing.name = layername
                existing.identifier = ident
                existing.value = value
        except Exception as ex:
            # 写入失败 → 该层 checksum 不更新，下次比对会误判，必须留痕
            # 注意：本方法作用域内没有 C（C 只是 _mods() 的局部变量），必须就地导入
            from .constants import _psd_log as _log
            _log(f"[PSD-校验] 写入 checksum 失败: {type(ex).__name__}: {ex}")

    def _finalize(self, context):
        try:
            if self._mode != "REFRESH_SELECTED" and self._record is not None:
                # 记录的是【本次批次】的层名：APPEND 模式下只含本次追加的层，并非完整列表。
                # 该字段当前只写不读（无消费者）。将来若要按它还原/比对图层顺序，须先明确
                # 语义（改为合并全量，或改存 identifier），否则会丢信息。
                self._record.layer_order = ",".join(
                    [info["layer_name"] for info in self._cache_infos]
                )
                # imported_layer_ids：已导入图层清单（刷新基准）。
                # IMPORT 覆盖为本批；APPEND 与旧清单取并集（新追加层也纳入刷新范围）。
                if self._mode in ("IMPORT", "APPEND"):
                    new_ids = [info.get("identifier") for info in self._cache_infos
                               if info.get("identifier")]
                    if self._mode == "APPEND":
                        old_ids = set()
                        prev = getattr(self._record, "imported_layer_ids", "")
                        if prev:
                            old_ids = set(x for x in prev.split(",") if x)
                        old_ids.update(new_ids)
                        new_ids = sorted(old_ids)
                    else:
                        new_ids = sorted(set(new_ids))
                    self._record.imported_layer_ids = ",".join(new_ids)
        except Exception:
            pass
        try:
            _, U, _, _ = _mods()
            # B：清理本次处理涉及的所有 PSD 的缓存（跨多 PSD 场景逐个清）。
            #
            # ⚠️ 「外放 PSD_texture」模式**绝不能清** —— 那些 PNG 是用户要长期保留的
            #    贴图资产（.blend 只存路径引用），清掉 = 工程里的贴图全变成空图。
            #    PACK 模式才可以清：图像已打包进 .blend，缓存 PNG 只是中间产物。
            if U.get_texture_store_mode() == "PACK":
                paths = getattr(self, "_psd_filepaths", None) or []
                if self._filepath and self._filepath not in paths:
                    paths.append(self._filepath)
                for p in paths:
                    try:
                        U.cleanup_cache_files(p)
                    except Exception:
                        pass
            else:
                _b = None
                try:
                    from .constants import _psd_log as _b
                    _b("[PSD-缓存] 外放模式 → 跳过缓存清理（PSD_texture 是用户资产）")
                except Exception:
                    pass
        except Exception:
            pass
        msg = f"已处理 {self._applications_succeeded}/{self._total} 个图层"
        if self._failed_layers:
            msg += f"，{self._failed_layers} 个图层出错"
        self._report(context, {"INFO"}, msg)
        # 刷新卡片图层列表视图：行尾 ✕ 的依据（has_object）按场景实况算，
        # 导入/追加改了场景对象 → 必须重建显示行，否则 ✕ 会"迟到"到下次
        # 折叠等操作才出现（问题1：删了对象再追加回来，✕ 不回来）。
        try:
            PSL2, _, _, _ = _mods()
            fi = getattr(self, "_file_index", -1)
            tool = getattr(getattr(context, "scene", None), "psd_import_tool", None)
            if (self._record is not None and tool is not None
                    and 0 <= fi < len(tool.file_records)):
                PSL2._rebuild_layer_items(self._record, fi)
        except Exception:
            pass
        # 追加完成后：自动选中本次追加的对象（列表选中 + 场景选中一起同步），
        # 用户追加完就能直接对它操作，不必再去 3D 视图里找。
        if self._mode == "APPEND" and getattr(self, "_created_objects", None):
            try:
                PSL3, _, _, C3 = _mods()
                fi = getattr(self, "_file_index", -1)
                tool = getattr(getattr(context, "scene", None), "psd_import_tool", None)
                if tool is not None and 0 <= fi < len(tool.file_records):
                    rec3 = tool.file_records[fi]
                    idents = [o.get(C3.ATTR_LAYER_ID) for o in self._created_objects]
                    idents = [x for x in idents if x]
                    if idents:
                        PSL3._set_sel(rec3, set(idents))
                        PSL3._rebuild_layer_items(rec3, fi)
                        # 只选中**本次新增的**对象（用户要的是「追加的那个」；
                        # 不含同 identifier 的旧副本），列表选中同步到这些 identifier。
                        PSL3._select_only_objects(context, list(self._created_objects))
            except Exception:
                pass

    # ---------------- 收尾 ----------------

    def _teardown(self, context, cancelled=False):
        if getattr(self, "_timer", None) is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if cancelled and getattr(self, "_cancel", None) is not None:
            self._cancel.set()
        self._set_active(False)
        self._set_progress(0.0)
        if cancelled:
            self._set_status("已取消")
            msg = f"已取消，完成 {self._done_count}/{self._total} 个图层"
            self._report(context, {"INFO"}, msg)

        # ---- 释放重引用（内存泄漏修复）----
        # Blender 会保留已完成的 modal operator 实例（recent operators），
        # 本实例挂着 _worker（→ psd_tools 解析树 + 解码像素缓冲）/ _psd /
        # _cache_infos / _flat_list / _id_to_path。收尾时不清空的话，
        # 每次导入/刷新都会永久泄漏一整棵解析树（实测真实文件约 +210~300MB/次，
        # 10 次刷新 +3GB，gc.collect() 与清空场景都不回收）。
        # 只置 None，不动功能：teardown 之后不再有 timer 回调读这些属性。
        self._worker = None
        self._psd = None
        self._cache_infos = None
        self._flat_list = None
        self._id_to_path = None

    def cancel(self, context):
        self._teardown(context, cancelled=True)

    # ---------------- 进度属性 ----

    def _set_active(self, v):
        try:
            setattr(bpy.context.scene.psd_import_tool, self.PROP_ACTIVE, bool(v))
        except Exception:
            pass

    def _set_progress(self, v):
        try:
            setattr(bpy.context.scene.psd_import_tool, self.PROP_PROGRESS, float(v))
        except Exception:
            pass

    def _set_status(self, text):
        try:
            setattr(bpy.context.scene.psd_import_tool, self.PROP_STATUS, str(text))
        except Exception:
            pass

    def _report(self, context, level, msg):
        try:
            self.report(level, msg)
        except Exception:
            pass


# ==================== 启动入口 ====================

def launch_async_job(context, mode: str, file_index: int = -1, filepath: str = ""):
    """由各入口操作符调用，启动异步处理。

    返回 bool。失败时把真实原因存入 PSL._last_async_error，供 UI 读取大白话提示。
    """
    from . import PSD_Layer_Importer as PSL
    from .constants import _psd_log
    PSL._import_filepath = filepath  # IMPORT 模式暂存路径
    PSL._last_async_error = ""
    try:
        ret = bpy.ops.psd.async_job("INVOKE_DEFAULT", mode=mode, file_index=file_index)
        # 若 invoke 里 _build 返回 False（CANCELLED），此处不会抛异常但应视为失败
        if ret == {"CANCELLED"}:
            if not PSL._last_async_error:
                PSL._last_async_error = "任务被取消（构建阶段失败）"
            return False
        return True
    except Exception as e:
        # 记录真实异常，避免只显示"启动失败"却看不到原因
        import traceback
        _psd_log(f"[PSD-异常] launch_async_job 失败: mode={mode}, file_index={file_index}, "
                 f"异常={type(e).__name__}: {e}")
        _psd_log(f"[PSD-异常] 堆栈: {traceback.format_exc()}")
        # 存大白话原因，供 UI 提示（若 _build 已设 _error 则优先用）
        PSL._last_async_error = f"{type(e).__name__}: {e}"
        return False
