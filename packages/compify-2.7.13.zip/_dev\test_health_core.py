"""核心功能门禁（每次改动后必跑）—— 按【设计语义】验证正常功能未被破坏。

⚠️ 尺子必须先对齐（这一条我踩过）：
   · 相机**平移** ⇒ 投影形状不变 + **整体滚动**（各层屏幕位移一致）—— 不是"完全冻结"
   · **变焦**     ⇒ 构图冻结（相机自己 dolly 补偿）
   · **拖动网格** ⇒ 构图冻结（PSD「拖图层」语义）
   · **图案钉住** ⇒ 冻结坐标（campos）不被改写
   · **重置**     ⇒ 几何回到【首次锁定前】的原形
   ⚠️ 我曾把"相机平移该整体滚动"误当成"该完全冻结"，一度误报核心功能坏了。
   ⚠️ 渲染会改 scene.render.resolution —— shot() 里先存后还原（不换尺子）。
"""

import bpy
import sys
import os
import time
import importlib.util
import mathutils as MU

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
D = PKG_DIR
OUT = os.path.join(os.path.dirname(PKG_DIR), "IDES", "workspace", "_plock_health")
os.makedirs(OUT, exist_ok=True)
spec = importlib.util.spec_from_file_location(PKG, os.path.join(D, "__init__.py"),
                                              submodule_search_locations=[D])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

RES = []
def chk(n, c, d=""):
    RES.append(c); print("  [%s] %-54s %s" % ("PASS" if c else "FAIL", n, d))


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0.0, 0.0, 10.0)
sc.camera = cam
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("P"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
tex = nt.nodes.new("ShaderNodeTexChecker"); tex.inputs["Scale"].default_value = 8.0
g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
o = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(g.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], o.inputs["Surface"])
objs = []
for i, z in enumerate([0.0, -2.0, -4.0]):
    bpy.ops.mesh.primitive_plane_add(size=6.0, location=(0.0, 0.0, z))
    ob = bpy.context.active_object
    ob.name = "L%d" % i; ob.data.name = "L%dMesh" % i
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    objs.append(ob)
ld = bpy.data.lights.new("L", "SUN"); ld.energy = 5.0
lo = bpy.data.objects.new("L", ld); sc.collection.objects.link(lo)
lo.rotation_euler = (0.6, 0.2, 0.3)
_eng = [i.identifier for i in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in _eng else "BLENDER_EEVEE"
sc.render.resolution_x, sc.render.resolution_y = 480, 270
sc.render.image_settings.file_format = "PNG"
bpy.context.view_layer.update()


def screen(ob, view, lens, sensor=36.0):
    f = lens / sensor
    out = []
    for v in ob.data.vertices:
        cs = view.inverted() @ (ob.matrix_world @ v.co)
        d = -cs.z
        out.append(None if d <= 1e-6 else (cs.x / d * f, cs.y / d * f))
    return out


def maxd(a, b):
    return max(max(abs(x[0] - y[0]), abs(x[1] - y[1])) for x, y in zip(a, b) if x and y)


def campos(ob, camname):
    a = ob.data.attributes.get(plock._campos_attr_name(camname))
    if a is None:
        return None
    n = len(a.data); b = [0.0] * (n * 3)
    a.data.foreach_get("vector", b)
    return b


def wco(ob):
    return [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]


def shot(tag):
    rx, ry = sc.render.resolution_x, sc.render.resolution_y
    p = os.path.join(OUT, tag + ".png")
    sc.render.filepath = p
    bpy.ops.render.render(write_still=True)
    sc.render.resolution_x, sc.render.resolution_y = rx, ry
    return p


def pixdiff(a, b):
    """像素平均差 + 亮像素数（防空对空）。PIL 不可用时返回 (0, -1) 并跳过像素级断言。"""
    try:
        from PIL import Image
    except ImportError:
        return 0.0, -1
    ia, ib = Image.open(a).convert("RGB"), Image.open(b).convert("RGB")
    pa, pb = ia.load(), ib.load()
    w, h = ia.size
    tot = 0.0; bright = 0
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            ca, cb = pa[x, y], pb[x, y]
            tot += sum(abs(ca[i] - cb[i]) for i in range(3))
            if sum(ca) > 40:
                bright += 1
    return tot / ((h // 2) * (w // 2)) / 3.0, bright


def run():
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


W_ORIG = [wco(o) for o in objs]          # ★ 真正的初始形状（锁定【之前】记）

print("=" * 74)
print("【1】锁定 → 相机平移 ⇒ 承诺：图形整体滚动（各层位移【一致】）")
r = plock.lock_group(sc, cam)
print("   lock:", r["success"], "| frozen =", r.get("frozen"))
chk("1a 锁定成功且 frozen=True", r["success"] and r.get("frozen") is True)
v_lock = plock.get_camera_view_matrix(cam)
s_lock = [screen(ob, v_lock, cam.data.lens) for ob in objs]
cp_lock = [campos(ob, cam.data.name) for ob in objs]

cam.location.x = 2.0
run()
v_mv = plock.get_camera_view_matrix(cam)
s_mv = [screen(ob, v_mv, cam.data.lens) for ob in objs]
shifts = [maxd(s_lock[i], s_mv[i]) for i in range(len(objs))]
print("   各层屏幕位移 =", ["%.6f" % x for x in shifts])
chk("1b 平移后各层屏幕位移【一致】（= 整体滚动，P2）",
    max(shifts) - min(shifts) < 1e-6 and max(shifts) > 1e-6,
    "最大差 %.2e" % (max(shifts) - min(shifts)))
cp_mv = [campos(ob, cam.data.name) for ob in objs]
chk("1c 图案钉住：冻结坐标【完全没被改写】",
    all(a == b for a, b in zip(cp_lock, cp_mv)))

print()
print("=" * 74)
print("【2】变焦 ⇒ 承诺：构图冻结（画面不变，相机自己 dolly 补偿）")
p_mv = shot("A_moved")
cam.data.lens = 85.0
run()
p_zm = shot("B_zoom")
d, br = pixdiff(p_mv, p_zm)
print("   变焦前后像素差 = %.4f  亮像素 = %d" % (d, br))
chk("2a 画面非空（防空对空）", br > 200 or br == -1, "亮像素 %d" % br)
chk("2b 变焦后构图【精确冻结】", d < 0.5, "像素差 %.4f" % d)
v_zm = plock.get_camera_view_matrix(cam)
s_zm = [screen(ob, v_zm, cam.data.lens) for ob in objs]
dv = [maxd(s_mv[i], s_zm[i]) for i in range(len(objs))]
print("   变焦前后各层屏幕变化 =", ["%.6f" % x for x in dv])
chk("2c 变焦后屏幕构图冻结（数值）", max(dv) < 1e-4, "最大 %.2e" % max(dv))
cam.data.lens = 50.0
run()

print()
print("=" * 74)
print("【3】拖动锁定网格 ⇒ 承诺：构图冻结（PSD「拖图层」语义）")
p_pre = shot("C_before_drag")
axis = plock.get_camera_view_matrix(cam).to_3x3() @ MU.Vector((0, 0, -1))
objs[0].location = objs[0].location + axis * (-2.0)
run()
p_dg = shot("D_drag")
d2, br2 = pixdiff(p_pre, p_dg)
print("   拖动前后像素差 = %.4f  亮像素 = %d" % (d2, br2))
chk("3a 拖动后画面非空", br2 > 200 or br2 == -1, "亮像素 %d" % br2)
chk("3b 拖动后构图【精确冻结】", d2 < 0.5, "像素差 %.4f" % d2)

print()
print("=" * 74)
print("【4】性能：相机移动时 handler 每帧耗时")
for _ in range(3):
    run()
ts = []
for i in range(20):
    cam.location.y = 0.02 * i
    bpy.context.view_layer.update()
    t0 = time.perf_counter()
    plock.parallax_lock_update_handler(sc)
    ts.append((time.perf_counter() - t0) * 1000)
    bpy.context.view_layer.update()
ts.sort()
print("   3 层网格：中位 %.2f ms/帧  最差 %.2f ms" % (ts[len(ts) // 2], ts[-1]))
chk("4a handler 耗时 <50ms（手感）", ts[len(ts) // 2] < 50, "%.2f ms" % ts[len(ts) // 2])

print()
print("=" * 74)
print("【5】面板：正常场景不得误报孤儿")
orph = plock.find_orphan_locks(sc)
chk("5a 无孤儿误报", len(orph) == 0, "误报 %d 个" % len(orph))
stt = plock.lock_status(sc, cam)
chk("5b lock_status 正常", stt["locked"] and stt["patched"], str(stt))

print()
print("=" * 74)
print("【6】重置 ⇒ 承诺：几何回到【首次锁定前】的原形")
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
w_after = [wco(o) for o in objs]
dd = max(max(max(abs(a[i] - b[i]) for i in range(3)) for a, b in zip(x, y))
         for x, y in zip(W_ORIG, w_after))
print("   与初始形状最大偏差 = %.6f" % dd)
chk("6a 重置后几何 = 初始原形", dd < 1e-4, "偏差 %.6f" % dd)
chk("6b 重置后解除锁定", not plock.is_locked(sc, cam))
chk("6c 重置后无孤儿残留", len(plock.find_orphan_locks(sc)) == 0)

print()
print("=" * 74)
print("【7】解锁 ⇒ 不得改动任何东西（只停止跟随）")
plock.lock_group(sc, cam)
cam.location.x = 5.0
run()
b_geo = [wco(o) for o in objs]
b_loc = tuple(cam.location)
b_cp = [campos(o, cam.data.name) for o in objs]
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
a_geo = [wco(o) for o in objs]
a_loc = tuple(cam.location)
a_cp = [campos(o, cam.data.name) for o in objs]
chk("7a 解锁不改几何",
    max(max(max(abs(x[i] - y[i]) for i in range(3)) for x, y in zip(p, q))
        for p, q in zip(b_geo, a_geo)) < 1e-6)
chk("7b 解锁不改相机", max(abs(x - y) for x, y in zip(b_loc, a_loc)) < 1e-9)
chk("7c 解锁不改冻结坐标", all(x == y for x, y in zip(b_cp, a_cp)))

print()
print("=" * 74)
print("【8】真实模型形态：带修改器/形态键/共享网格的对象 ⇒ 必须【跳过并提示】")
# ★ 这一组来自**用户实测反馈**（2026-10-10）：
#   真实模型常带细分修改器 / 形态键 / PSD 导入的共享网格，
#   这类对象在**锁定时就被排除**，于是移相机时几何纹丝不动 = 用户看到的「适配失效」。
#   承诺（CHANGELOG 2.6.0）：这类对象要**跳过【并提示】**。
#   ⚠️ 我的旧测试全是"光秃秃的平面"，**永远测不到这一类** —— 补上。
bpy.ops.wm.read_factory_settings(use_empty=True)
plock._proj_cache.clear()
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0.0, 0.0, 10.0)
sc.camera = cam
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("M"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gg = nt.nodes.new("ShaderNodeGroup"); gg.node_tree = grp
oo = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gg.outputs["Vector"], oo.inputs["Surface"])


def _add(name, z, mod=None, shapekey=False):
    bpy.ops.mesh.primitive_plane_add(size=6.0, location=(0.0, 0.0, z))
    ob = bpy.context.active_object; ob.name = name; ob.data.name = name + "M"
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name), "ShaderNodeTree")
    if mod:
        ob.modifiers.new(mod, mod)
    if shapekey:
        ob.shape_key_add(name="Key1")
    return ob


o_norm = _add("Normal", 0.0)
# ⚠️ 必须再放一个**深度不同**的正常网格：如果场景里只有一个能锁定的对象，
#    它就是基准层（锚点，k=1），移相机时**本来就不动** ⇒ 拿它当尺子会误判"没适配"
#    （基准层陷阱，我已踩第 3 次）。Normal2 深度不同 ⇒ 它会动。
o_norm2 = _add("Normal2", -0.5)
o_mod = _add("HasSubdiv", -1.0, mod="SUBSURF")     # ← 别丢：这是本组的主角
o_key = _add("HasShapeKey", -2.0, shapekey=True)
# 共享网格（Alt+D 形态：两个对象共用一个 mesh）
o_sh1 = _add("Shared1", -3.0)
bpy.ops.mesh.primitive_plane_add(size=6.0, location=(2.0, 0.0, -3.0))
o_sh2 = bpy.context.active_object; o_sh2.name = "Shared2"
o_sh2.data = o_sh1.data
bpy.data.node_groups.new("UV Adjust | %s | %s" % (o_sh2.data.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
_r8 = plock.lock_group(sc, cam)
_msg8 = str(_r8.get("message", ""))
print("   消息 = %s…" % _msg8[:150])
chk("8a 带修改器的对象被跳过", any(o.name == "HasSubdiv" for o, _ in _r8.get("skipped", [])))
chk("8b 带形态键的对象被跳过", any(o.name == "HasShapeKey" for o, _ in _r8.get("skipped", [])))
chk("8c 正常网格仍被锁定（两个都锁上）",
    all(any(o.name == _n for o in _r8.get("locked", [])) for _n in ("Normal", "Normal2")))
# ★ 关键承诺：跳过必须【并提示】（含原因，让用户能自己诊断）
chk("8d 消息里写出了跳过【原因】（不是只给数字）",
    ("跳过" in _msg8) and ("修改器" in _msg8 or "形态键" in _msg8),
    _msg8[-90:] if _msg8 else "(空)")
# 行为上确认：被跳过的对象移相机时几何不动（这是"适配失效"的现象）
_OM = bpy.data.objects["HasSubdiv"]
_b8 = [tuple(_OM.matrix_world @ v.co) for v in _OM.data.vertices]
cam.location.x = 3.0
run()
_d8 = max(max(abs(a[i] - b[i]) for i in range(3)) for a, b in zip(_b8,
          [tuple(_OM.matrix_world @ v.co) for v in _OM.data.vertices]))
chk("8e 被跳过的对象确实不被改写（已知设计限制，不是 bug）", _d8 < 1e-9,
    "Δ=%.2e" % _d8)
# 而正常网格仍要正常适配（非空对空）
# ⚠️ 动态挑一个【非锚点】的锁定对象来量（锚点 k=1 本来就不动）——
#    不要凭猜"哪个更浅"（我已经猜错两次：第一版拿唯一的对象、第二版拿 Normal2，
#    两个都恰好是锚点）。直接算每个对象的深度，对比 state 里的 ref_depth。
_st8 = plock.get_state(sc, cam)
_ref8 = _safe_ref = _st8.get("ref_depth", 0.0)
_vm8 = plock.get_camera_view_matrix(cam).inverted()
_ON = None
for _nm in ("Normal", "Normal2"):
    _cand = bpy.data.objects[_nm]
    _dep = -(_vm8 @ (_cand.matrix_world @ _cand.data.vertices[0].co)).z
    if abs(_dep - _ref8) > 0.1:          # 与锚点深度不同 ⇒ 它一定会动
        _ON = _cand
        print("   （量 %s：深度 %.2f，锚点 %.2f）" % (_nm, _dep, _ref8))
        break
assert _ON is not None, "找不到非锚点的锁定对象（测试前提不成立）"
_b9 = [tuple(_ON.matrix_world @ v.co) for v in _ON.data.vertices]
cam.location.x = 6.0
run()
_d9 = max(max(abs(a[i] - b[i]) for i in range(3)) for a, b in zip(_b9,
          [tuple(_ON.matrix_world @ v.co) for v in _ON.data.vertices]))
chk("8f 同场景里正常网格仍正常适配（用非锚点层量）", _d9 > 1e-6, "Δ=%.6f" % _d9)

print()
print("=" * 74)
print("PASS %d / FAIL %d" % (sum(RES), len(RES) - sum(RES)))
print("HEALTHCORE_DONE")
