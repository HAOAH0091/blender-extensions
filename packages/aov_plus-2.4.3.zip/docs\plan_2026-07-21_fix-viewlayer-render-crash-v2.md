# 执行计划：单层视图层渲染崩溃修复（逐层渲染方案）

> 计划日期：2026-07-21
> 关联崩溃：0718_6 ~ 0718_7, 1~4.txt（共 6 份报告）
> Blender 版本：5.2.0（Commit fbe6228777e7）
> 前置研究：view_layer.use = False 触发 Blender 5.2 C 层 depsgraph 崩溃（函数 `deg_check_base_in_depsgraph`），Python 层无法规避

## 1. 问题回顾

### 1.1 核心矛盾

```
view_layer.use = False → Base 内存释放 → 渲染线程独立建图时
持有过期 Base 指针 → deg_check_base_in_depsgraph 空指针解引用 → 崩溃
```

渲染线程（`render_startjob` → `RE_RenderAnim`）重新构建自己的依赖图，与主线程的依赖图无关。`context.evaluated_depsgraph_get()` 只能刷新主线程的图，无法影响渲染线程——这是上一轮修复（2 行 depsgraph 刷新）失败的根本原因。

### 1.2 崩溃统计（6 份报告）

| 文件 | 总层数 | 禁用数 | 崩溃时机 | 特征 |
|------|--------|--------|----------|------|
| 0718_6 | 11 | 10 | 第 3 次 | |
| 0718_7 | 11 | 10 | 第 1 次 | 含 depsgraph 修复 |
| 1.txt | 11 | 10 | 第 2 次 | |
| 2.txt | 6 | 5 | 第 2 次 | |
| 3.txt | 3 | 2 | 第 2 次 | |
| 4.txt | 9 | 8 | 第 1 次 | |

规律：与视图层总数无关、与禁用数量无关、非必现。崩溃条件只有一个——`view_layer.use = False` + 渲染。

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| 消除崩溃 | P0 | 任何规模的场景、任意数量的视图层，反复单层渲染 10 次不崩溃 |
| 保留旧方案为可选 | P0 | 用户可手动切回旧方案（需要时），切换后行为与改造前一致 |
| 保持一键操作 | P0 | 用户仍是一次点击完成全部选中层的渲染 |
| 版本自适应默认值 | P1 | Blender 5.2+ 默认使用新方案，5.1 及以下默认使用旧方案 |
| 不影响其他功能 | P0 | 全层渲染、动画渲染、帧范围渲染均正常 |

## 3. 设计方案

### 3.1 核心思路

用 `scene.render.use_single_layer` 替代 `view_layer.use = False` 来控制"只渲哪一层"。

`use_single_layer` 是 Blender 内置的渲染选项，告诉渲染引擎"只渲当前活跃视图层"。它不修改 `view_layer.use`，因此不会触发 depsgraph 崩溃。

多选视图层时，通过 handler 链逐层串行渲染：渲完第一层 → handler 触发 → 切到第二层 → 渲染 → 第三层 → 全部完成 → 恢复状态。

### 3.2 两种模式的设计

**模式 A：旧方案（"快速模式"）**

不改逻辑。`view_layer.use = False` + 一次渲染。Blender 5.1 及以下正常使用。

**模式 B：新方案（"安全模式"）**

```
execute():
  1. 解析选中的 Render Layers 节点 → selected_layer_names 列表
  2. 保存状态快照：
     - original_use_single_layer = scene.render.use_single_layer
     - original_active_vl = context.window.view_layer
     - original_file_output_states（mute 状态，和现在一样）
  3. Mute 无关 File Output 节点（和现在一样）
  4. 设置 scene.render.use_single_layer = True
  5. 构建渲染队列（按选中顺序）
  6. 启动第一层渲染 → 其余由 handler 链驱动
  7. 全部完成后 handler 恢复所有状态
```

**handler 链逻辑**：

```
render_complete_handler(scene, depsgraph):
  if 队列非空:
    next_layer = 队列.pop(0)
    context.window.view_layer = scene.view_layers[next_layer]
    # 重新 mute File Output（为当前层调整）
    bpy.ops.render.render('INVOKE_DEFAULT', animation=True/False)
  else:
    restore_all_states()

render_cancel_handler(scene, depsgraph):
  restore_all_states()
```

### 3.3 面板 UI

在"渲染选中视图层"区域内，按钮上方新增一行：

```
☑ 逐层渲染（安全模式）
```

勾选 = 模式 B，不勾 = 模式 A。

**默认值策略**：插件加载时检测 `bpy.app.version >= (5, 2, 0)`。5.2+ 默认勾选，5.1 及以下默认不勾。用户手动改过后，后续按用户的选择。

### 3.4 File Output mute 的处理

旧方案里，mute 在一次性渲染前设好就行。新方案每层渲染前需要针对当前层调整 mute：

- 与当前视图层相关的 File Output 节点 → unmute
- 与其他视图层相关的 → mute

**当前版本采用一次性 mute 策略**：在 `execute()` 中一次性设好所有 File Output 节点的 mute 状态，各层渲染间不重新计算。

**已知副作用（风险等级：中）**：每层渲染时，不属于当前层的 File Output 节点也保持 unmute。由于它们的输入源（非活跃层的 Render Layers 节点）可能产出黑帧或不相关数据，这些文件会被写入但内容可能是无效的。

这个问题将在后续迭代中通过每层动态 mute 解决。目前权衡是可接受的——空文件不会损坏数据，用户可手动清理。面板说明文字中建议提示此行为。

### 3.5 方案对比

| 维度 | 旧方案（模式 A） | 新方案（模式 B） |
|------|-----------------|-----------------|
| 触发 depsgraph 崩溃 | 是（5.2） | 否 |
| 修改 view_layer.use | 是 | 否 |
| 渲染次数 | 1 次（所有层合成） | N 次（逐层） |
| 引擎启动开销 | 1 次 | N 次 |
| File Output mute 逻辑 | 一次性 | 一次性（复用） |
| handler 复杂度 | 低（仅恢复） | 中（恢复+链式启动） |

## 4. 详细设计

### 4.1 涉及的文件

| 文件 | 改动类型 | 说明 |
|------|----------|------|
| `properties/settings.py` | 新增 1 个 BoolProperty | `use_single_layer_rendering` |
| `panels/node_editor_panel.py` | 新增 1 行 UI | 复选框 |
| `operators/compositor_operators.py` | 重构 execute() | 双路径逻辑 + handler 链 |
| `__init__.py` | 修改 register() | 版本检测设置默认值 |

### 4.2 properties/settings.py

在 `AutoRenameSettings` 类末尾新增。注意：`default` 值在模块级直接使用 `bpy.app.version` 判断，避免 register() 时序问题（class 在 `register_class()` 时已固化 property 定义，之后改 `default` 不保证生效）：

```python
use_single_layer_rendering: BoolProperty(
    name="逐层渲染（安全模式）",
    description="使用 view_layer 切换逐层渲染而非禁用视图层，"
                "可避免 Blender 5.2 的 depsgraph 渲染崩溃。"
                "代价是每层需要独立的渲染 pass",
    default=(bpy.app.version >= (5, 2, 0))
)

# 用于追踪用户是否手动修改过此设置
_single_layer_user_set: BoolProperty(
    name="_single_layer_user_set",
    description="内部标记：用户是否手动设置过逐层渲染选项",
    default=False,
    options={'HIDDEN'}
)
```

### 4.3 __init__.py

不需要修改 `register()`。版本检测已在 property 定义时完成（见 §4.2）。

面板 draw() 中可在用户修改复选框时更新 `_single_layer_user_set` 标记（通过 update 回调或面板逻辑）。

### 4.4 panels/node_editor_panel.py

在渲染模式选择下方（约第 135 行 `row_range.prop(settings, "render_frame_end", ...)` 之后），渲染按钮之前，新增复选框。

同时设置 `_single_layer_user_set` 标记（通过 update 回调，当用户手改复选框时触发）：

```python
# 逐层渲染模式开关
render_box.separator()
row_single = render_box.row()
row_single.prop(settings, "use_single_layer_rendering")
# 面板不需要显式设置 _single_layer_user_set——在 draw 中
# 通过 row.prop 渲染的复选框由 Blender UI 系统处理值变更。
# 可以用一个简单的 update 函数在 property 定义中实现：
# update=lambda self, ctx: setattr(self, '_single_layer_user_set', True)
```

### 4.5 operators/compositor_operators.py

#### 4.5.1 execute() 改造

核心逻辑拆分为两个路径：

```python
def execute(self, context):
    # ... 现有代码：获取 node_tree, selected_layer_names, settings, original_states ...
    # ... 现有代码：设置 node mute, 检查有效输出 ...

    # 根据设置选择渲染路径
    if settings.use_single_layer_rendering:
        return self._render_single_layer_mode(
            context, scene, node_tree, selected_layer_names, settings,
            original_view_layer_states, original_file_output_states,
            original_frame_start, original_frame_end, related_file_outputs
        )
    else:
        return self._render_legacy_mode(
            context, scene, node_tree, selected_layer_names, settings,
            original_view_layer_states, original_file_output_states,
            original_frame_start, original_frame_end, related_file_outputs
        )
```

#### 4.5.2 _render_legacy_mode()（旧方案，不改）

把现有的 try/except 块中的逻辑（设置 view_layer.use → 渲染 → handler 注册）原样移到这个函数。此行不删不减。

#### 4.5.3 _render_single_layer_mode()（新方案）

**重复调用保护**：使用类级标志 `_render_chain_running` 防止用户在链式渲染未完成时重复点击。Blender 可能在不同调用中创建不同 operator 实例，标志必须是类属性而非实例属性。

```python
class COMPOSITOR_OT_render_selected_view_layers(Operator):
    # ... 现有属性 ...

    # 类级标志：防止重复链式渲染
    _render_chain_running = False

    def execute(self, context):
        # ... 前面代码不变 ...

        if settings.use_single_layer_rendering:
            # 检查是否已有链式渲染在运行
            if COMPOSITOR_OT_render_selected_view_layers._render_chain_running:
                self.report({'WARNING'},
                    "上一次逐层渲染尚未完成，请等待完成后再试")
                return {'CANCELLED'}
            return self._render_single_layer_mode(
                context, scene, node_tree, selected_layer_names, settings,
                original_view_layer_states, original_file_output_states,
                original_frame_start, original_frame_end, related_file_outputs
            )
        else:
            return self._render_legacy_mode(...)


def _render_single_layer_mode(self, context, scene, node_tree,
                               selected_layer_names, settings,
                               original_view_layer_states,
                               original_file_output_states,
                               original_frame_start, original_frame_end,
                               related_file_outputs):
    # 1. 保存新方案特有的状态
    original_use_single_layer = scene.render.use_single_layer
    original_active_vl = context.window.view_layer

    # 2. 设置 File Output mute（复用现有逻辑）
    enabled_outputs = 0
    disabled_outputs = 0
    for node in node_tree.nodes:
        if node.type == 'OUTPUT_FILE':
            if node in related_file_outputs:
                node.mute = False
                enabled_outputs += 1
            else:
                node.mute = True
                disabled_outputs += 1

    # 2b. Composite 输出检查（与旧方案保持一致）
    has_composite = False
    for node in node_tree.nodes:
        if node.type == 'COMPOSITE' and not node.mute:
            has_composite = True
            break
    if enabled_outputs == 0 and not has_composite:
        self.report({'ERROR'},
            "未找到与选中渲染层相连的文件输出节点，且没有活动的合成输出节点。")
        return {'CANCELLED'}

    # 3. 构建渲染队列
    render_queue = list(selected_layer_names)

    # 4. 报告
    self.report({'INFO'},
        f"开始逐层渲染 {len(render_queue)} 个视图层\n"
        f"启用 {enabled_outputs} 个文件输出节点（已禁用 {disabled_outputs} 个）")

    # 5. 保存队列和恢复数据。
    # 关键：保存 window 和 scene 的引用而非 context，因为 handler 回调中
    # bpy.context 可能不稳定（用户可能在渲染期间切换工作区）。
    # window 和 scene 是长生命周期对象，在渲染会话期间不会失效。
    self._render_queue = render_queue
    self._restore_data = {
        'scene': scene,
        'window': context.window,  # 保存引用，不用 bpy.context
        'node_tree': node_tree,
        'original_use_single_layer': original_use_single_layer,
        'original_active_vl': original_active_vl,
        'original_file_output_states': original_file_output_states,
        'original_view_layer_states': original_view_layer_states,
        'original_frame_start': original_frame_start,
        'original_frame_end': original_frame_end,
        'settings': settings,
    }

    # 6. 标记链式渲染已启动
    COMPOSITOR_OT_render_selected_view_layers._render_chain_running = True

    # 7. 启用单层渲染 + 启动第一层
    scene.render.use_single_layer = True
    if not self._start_next_render():
        # 第一层就失败了，清理并返回
        self._restore_all_states()
        self.report({'ERROR'}, "启动渲染失败")
        return {'CANCELLED'}

    # 8. 注册 handlers
    bpy.app.handlers.render_complete.append(self._render_complete_handler)
    bpy.app.handlers.render_cancel.append(self._render_cancel_handler)

    return {'FINISHED'}


def _start_next_render(self):
    """启动队列中下一个视图层的渲染。
    返回 True 表示成功启动，False 表示失败（调用方负责恢复状态）。
    """
    if not self._render_queue:
        self._restore_all_states()
        return True  # 队列空是正常完成，不算失败

    data = self._restore_data
    scene = data['scene']
    window = data['window']
    layer_name = self._render_queue.pop(0)

    # 验证视图层存在
    if layer_name not in scene.view_layers:
        print(f"AOV+: 视图层 '{layer_name}' 不存在，跳过")
        return self._start_next_render()  # 递归处理下一层

    # 切换活跃视图层（使用保存的 window 引用而非 bpy.context）
    try:
        window.view_layer = scene.view_layers[layer_name]
    except Exception as e:
        print(f"AOV+: 无法切换到视图层 '{layer_name}': {e}")
        self._restore_all_states()
        return False

    settings = data['settings']
    try:
        if settings.render_mode in ('ANIMATION', 'RANGE'):
            bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
        else:
            bpy.ops.render.render('INVOKE_DEFAULT')
    except Exception as e:
        print(f"AOV+: 启动视图层 '{layer_name}' 渲染失败: {e}")
        self._restore_all_states()
        return False

    return True


def _render_complete_handler(self, scene, depsgraph):
    """渲染完成：启动下一层或恢复状态。
    注意：handler 作为 bound method 注册，持有 operator 实例引用。
    只要 handler 列表持有此引用，operator 实例就不会被 GC 回收。
    这是安全的——handler 在 _restore_all_states 中被移除后才释放引用。
    """
    self._start_next_render()


def _render_cancel_handler(self, scene, depsgraph):
    """渲染取消：恢复所有状态"""
    self._restore_all_states()


def _restore_all_states(self):
    """恢复所有状态并清理 handlers"""
    # 清除运行标志（最先执行，防止后续操作被误判为重复调用）
    COMPOSITOR_OT_render_selected_view_layers._render_chain_running = False

    data = self._restore_data
    scene = data['scene']
    node_tree = data['node_tree']
    window = data['window']

    # 恢复 use_single_layer
    scene.render.use_single_layer = data['original_use_single_layer']

    # 恢复活跃视图层（使用保存的 window 引用）
    try:
        window.view_layer = data['original_active_vl']
    except Exception:
        pass

    # 恢复 view_layer.use
    for view_layer in scene.view_layers:
        if view_layer.name in data['original_view_layer_states']:
            view_layer.use = data['original_view_layer_states'][view_layer.name]

    # 恢复 File Output mute
    for node_name, original_mute in data['original_file_output_states'].items():
        if node_name in [n.name for n in node_tree.nodes]:
            node_tree.nodes[node_name].mute = original_mute

    # 恢复帧范围
    scene.frame_start = data['original_frame_start']
    scene.frame_end = data['original_frame_end']

    # 清理 handlers
    if self._render_complete_handler in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(self._render_complete_handler)
    if self._render_cancel_handler in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(self._render_cancel_handler)

    # 清理实例状态
    self._render_queue = []
    self._restore_data = {}

    print("AOV+: 逐层渲染完成，所有状态已恢复")
```

### 4.6 与旧 handler 的兼容

旧方案的 handler（`render_complete_handler` / `render_cancel_handler`）在 `_render_legacy_mode()` 中保持不变。新方案有自己独立的 handler 方法。两者互不干扰。

### 4.7 版本检测的注意事项

`bpy.app.version` 返回 `(5, 2, 0)` 格式的元组。`bl_info` 中的 `"blender"` 是声明的最低兼容版本，不影响运行时行为。版本检测在 `register()` 时执行一次即可。

## 5. 实现步骤

| 步骤 | 操作 | 涉及文件 | 预计改动 |
|------|------|----------|----------|
| 1 | 添加 `use_single_layer_rendering` + `_single_layer_user_set` BoolProperty（含 update 回调），default 基于 `bpy.app.version` | `properties/settings.py` | +12 行 |
| 2 | 在面板渲染区添加复选框 | `panels/node_editor_panel.py` | +3 行 |
| 3 | 重构 execute() 为双路径，添加类级 `_render_chain_running` 标志 | `operators/compositor_operators.py` | +10 行 |
| 4 | 实现 `_render_single_layer_mode()`（含 Composite 检查） | `operators/compositor_operators.py` | +30 行 |
| 5 | 实现 `_start_next_render()`（含 try/except + 视图层存在验证，使用保存的 window/scene 引用） | `operators/compositor_operators.py` | +25 行 |
| 6 | 实现 handler 方法和 `_restore_all_states()`（使用保存的 window 引用） | `operators/compositor_operators.py` | +35 行 |
| 7 | 提取 `_render_legacy_mode()`（原 execute() 逻辑不变） | `operators/compositor_operators.py` | 代码移动 |
| 8 | 语法检查 | 所有修改文件 | |
| 9 | 代码审查 | 所有修改文件 | |
| 10 | 测试 | 见测试策略 | |

## 6. 测试策略

### 6.1 测试场景

| # | 场景 | 模式 | 操作 | 预期 |
|---|------|------|------|------|
| 1 | 全层渲染 | 旧方案 | 11 层全选，渲染一次 | 正常完成 |
| 2 | 全层渲染 | 新方案 | 11 层全选，渲染一次 | 正常完成（11 次 pass） |
| 3 | 单层渲染 ×10 | 新方案 | 依次选不同层，每次 1 层，重复 10 次 | 10 次均无崩溃 |
| 4 | 多重渲染 | 新方案 | 选 3 层，点击一次 | 3 次串行 pass，全部成功 |
| 5 | 动画渲染 | 新方案 | 选 1 层，渲染模式=动画，30 帧 | 正常完成 |
| 6 | 帧范围渲染 | 新方案 | 选 1 层，帧范围模式 | 正常完成 |
| 7 | 渲染取消 | 新方案 | 渲染中途按 ESC | handler 正确恢复状态 |
| 8 | 连续切换渲染 | 新方案 | 渲完 3 层 → handler 恢复 → 立刻选另外 2 层渲 | 无崩溃 |
| 9 | 旧方案正常 | 旧方案 | 5.1 环境下全层渲染 | 和改造前行为一致 |
| 10 | 版本默认值 | 新方案 | 5.2 环境下加载插件 | 复选框默认勾选 |
| 11 | 用户切换模式 | 新→旧→新 | 取消勾选渲染 → 勾回 → 渲染 | 各自正常工作 |
| 12 | 链中失败恢复 | 新方案 | 模拟第 N 层渲染启动失败 | 状态完全恢复（use_single_layer、view_layer、mute） |
| 13 | 重复点击保护 | 新方案 | 链式渲染未完成时再次点击渲染按钮 | 弹出"请等待"提示，不破坏状态 |

### 6.2 手动测试 checklist

- [ ] 旧方案：全层渲染正常（不崩即可，5.2 有已知崩风险）
- [ ] 新方案：单层切换渲染 10 次不崩溃
- [ ] 新方案：选 3 层一键渲染，3 次串行 pass 全部成功
- [ ] 新方案：动画渲染正常
- [ ] 新方案：帧范围渲染正常
- [ ] 新方案：渲染取消后状态恢复
- [ ] 新方案：连续切换渲染 5 次不崩溃
- [ ] 复选框：默认勾选（5.2）
- [ ] 复选框：取消 → 渲染走旧方案 → 勾回 → 渲染走新方案
- [ ] 链中失败：状态完全恢复
- [ ] 重复点击：提示等待，不破坏状态

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| 重复点击破坏 handler 链状态 | 中 | 状态恢复数据丢失，需手动恢复 | 类级 `_render_chain_running` 标志，execute() 入口拦截 (#CRITICAL fix) |
| 渲染启动失败导致 handlers 永久残留 | 中 | 状态永久改变 | `_start_next_render` 内 try/except + `_restore_all_states` (#MAJOR fix) |
| handler 中 `bpy.context` 不稳定 | 中 | 无法切换到下一层或恢复状态 | 在 `_restore_data` 中保存 `window`/`scene` 引用，不依赖 `bpy.context` (#MAJOR fix) |
| 版本检测默认值不生效 | 低 | 5.2 用户需手动勾选 | 在 property 定义处直接做版本检测，不依赖 register() 时序 (#MAJOR fix) |
| File Output 逐层写出无效文件 | 中 | 每层产生不属于当前层的输出文件 | 面板提示 + 后续版本实现每层动态 mute |
| 大场景逐层渲染耗时太长 | 中 | 用户体验变差 | 方案 B 的固有代价，面板说明中注明。用户可手动切回旧方案 |
| 旧方案在 Blender 5.2 后续补丁中被修复 | 低 | 新方案不再必要 | 保留两种模式，用户可根据实际情况自由切换 |

### 7.1 回退方案

如果新方案引入严重问题：将复选框默认值改回 `False`，用户不勾选就回退到旧方案。不影响已发布的任何功能。

## 8. 参考

- 崩溃报告：`0718_6.crash.txt` ~ `0718_7.crash.txt`，`1.txt` ~ `4.txt`
- 根因分析：`deg_check_base_in_depsgraph` 空指针，渲染线程独立 depsgraph
- Blender 5.2 API：`bpy.types.RenderSettings.use_single_layer`
- 源码：
  - `operators/compositor_operators.py` L1128-1355
  - `properties/settings.py`
  - `panels/node_editor_panel.py`
  - `__init__.py`
- 知识库：`Dev/aov_plus/`
