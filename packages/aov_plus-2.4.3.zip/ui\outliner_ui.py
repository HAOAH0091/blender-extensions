import bpy

# 导入需要引用的 Operator ID
from ..operators.outliner_operators import (OUTLINER_OT_isolate_collections,
                                          OUTLINER_OT_toggle_collection_lock,
                                          OUTLINER_OT_toggle_full_isolation)

def draw_outliner_header_buttons(self, context):
    """绘制大纲视图 Header 按钮"""
    layout = self.layout
    scene = context.scene

    row = layout.row(align=True)

    # 隔离按钮
    row.operator(OUTLINER_OT_isolate_collections.bl_idname, text="", icon='RENDERLAYERS')

    # 锁定按钮
    row.operator(OUTLINER_OT_toggle_collection_lock.bl_idname, text="", icon='LOCKED')

    # 完全隔离切换按钮
    # 确保 scene 和 is_full_isolation_enabled 属性存在
    if scene and hasattr(scene, 'is_full_isolation_enabled'):
         if scene.is_full_isolation_enabled:
             icon = 'HIDE_ON'
             tooltip = "完全隔离模式已启用 - 新创建的集合将在其他视图层自动排除"
         else:
             icon = 'HIDE_OFF'
             tooltip = "完全隔离模式已禁用 - 新创建的集合将在所有视图层可见"
         op = row.operator(OUTLINER_OT_toggle_full_isolation.bl_idname, text="", icon=icon)
         # Tooltips are defined in the Operator's bl_description
    else:
         # Fallback or error icon if property is missing
         row.label(text="", icon='ERROR') 