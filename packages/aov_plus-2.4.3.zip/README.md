# AOV+ (v2.3.0)

一个 Blender (5.0+) 插件，用于 AOV (Arbitrary Output Variables) 节点管理和输出文件名批处理，是基于原始脚本的重构版本。

**作者:** HAOAH
**类别:** 渲染 (Render)
**位置:**
*   属性编辑器 > 视图层属性 > AOV 助手 (Properties > View Layer > AOV 助手)
*   节点编辑器 > 侧边栏 (N) > AOV+ (Node Editor > Sidebar (N) > AOV+)
*   大纲视图 > 标题栏 (Outliner > Header)

## 主要功能

### 1. AOV 管理 (AOV Management) - `Properties > View Layer > AOV 助手`

此面板提供对场景中 AOV 输出节点的集中管理。

*   **同步 AOV (`render.sync_aovs`):**
    *   点击 `同步AOV节点` 按钮触发。
    *   扫描当前视图层中所有**可渲染**对象 (`utils.helpers.is_object_renderable`) 的材质及其节点组。
    *   收集所有找到的 `OUTPUT_AOV` 节点的名称及其所在位置（材质、节点组、对象）。
    *   在场景属性 (`Scene.aov_locations`) 中存储这些信息（以字符串形式）。
    *   在视图层 (`ViewLayer.aovs`) 中添加/移除 AOV 通道以匹配找到的节点。
    *   动态创建用于 UI 显示的临时场景属性 (`Scene.temp_aov_name_*`, `Scene.temp_aov_expand_*`)。
*   **AOV 列表显示:**
    *   根据 `Scene.aov_locations` 中的数据，按名称排序显示 AOV 列表。
    *   每个 AOV 条目包含：
        *   **展开/折叠按钮 (`Scene.temp_aov_expand_*`):** 显示/隐藏详细信息。
        *   **AOV 名称 (可编辑, `Scene.temp_aov_name_*`):** 显示当前 AOV 名称，可在此处输入新名称。
        *   **重命名按钮 (`render.rename_aov`, ✔️图标):** 使用文本框中输入的新名称，查找并重命名所有材质和节点组中的同名 `OUTPUT_AOV` 节点。同时更新视图层中的 AOV 通道名称。
        *   **赋予 AOV 按钮 (`render.assign_aov`, + 图标):** 将此 AOV 添加到当前选定对象所使用的所有材质中。
            *   **选项 (`Scene.aov_plus_assign_with_connected`):** 如果勾选 "赋予AOV时连带其连接的节点"，则在添加 AOV 节点时，会尝试查找场景中已存在的同名 AOV 节点（优先选择顶层材质中有连接的AOV作为源），并将其上游连接的所有节点网络（包括节点参数）**可靠地复制**到目标材质中，并正确连接到新创建（或已存在但未连接）的 AOV 节点的输入端。如果目标材质已存在同名 AOV，则会跳过该材质。如果找不到合适的外部源网络或未勾选此项，则仅添加一个单独的 AOV 输出节点。
        *   **删除 AOV 按钮 (`render.delete_aov`, X 图标):** 弹出确认框，确认后将在所有关联的材质和节点组中删除对应的 `OUTPUT_AOV` 节点，并从视图层中移除该 AOV 通道。
*   **展开后的详细信息:**
    *   **材质列表:**
        *   列出直接使用了该 AOV 的所有材质名称。
        *   点击材质名称 (`render.select_material`): 选择使用了该材质的**可见**对象，并将节点编辑器切换到该材质的节点树。激活对象对应的材质槽。
        *   点击旁边的 `X` 按钮 (`render.delete_material_aov`): 仅从此特定材质中删除该 AOV 节点。
    *   **对象列表:**
        *   列出其材质直接或间接（通过节点组）使用了该 AOV 的所有对象名称。
        *   点击对象名称 (`render.select_object`): 在 3D 视图中选择该对象。
    *   **节点组列表:**
        *   列出使用了该 AOV 的节点组，格式为 `材质名称 > 节点组名称`。
        *   点击条目 (`render.select_node_group`): 选择使用了该材质的**可见**对象，将节点编辑器切换到该材质节点树，并尝试**导航**到材质中对应的节点组节点内部（如果编辑器空间允许）。
        *   点击旁边的 `X` 按钮 (`render.delete_group_aov`): 仅从此特定节点组中删除该 AOV 节点。

### 2. 合成器工具 (Compositor Tools) - `Node Editor > Sidebar (N) > AOV+`

此面板出现在节点编辑器的侧边栏（仅当编辑器处于合成器模式时），提供文件输出节点的管理功能。

*   **命名与格式设置 (`Scene.auto_rename_settings`):**
    *   `Use Scene Prefix`: 重命名时是否添加场景名称作为前缀。
    *   `Use Layer Prefix`: 重命名时是否添加视图层名称作为前缀。
    *   `Use MultiLayer EXR`: 自动连接或重命名时，是否将文件输出节点设置为 `OPEN_EXR_MULTILAYER` 格式。否则使用 `OPEN_EXR`（Blender 5.0 采用 `directory + file_name` 的新路径模型）。
    *   `区分数据与灯光通道 (Separate Data/Light Outputs)`: (新选项) 控制自动连接行为。勾选时 (默认)，数据通道 (如 Depth, Normal) 和图像/灯光通道会连接到不同的文件输出节点。取消勾选时，所有通道会合并连接到一个文件输出节点，并且接口会尝试按照渲染层节点的原始顺序排序。
    *   **EXR格式设置:**
        *   `EXR色深`: 设置非数据通道文件输出节点的颜色深度。可选Half (16位) 或 Full (32位)，默认为16位。数据通道始终使用32位以保证精度。
        *   `EXR颜色`: 设置非数据通道文件输出节点的颜色模式。可选RGB或RGBA，默认为RGBA。数据通道始终使用RGBA。
*   **自动连接输出 (`compositor.auto_connect_outputs`):**
    *   **行为模式 (`destructive_connect_mode`):**
        *   **非破坏性 (默认):**
            *   检查渲染层节点的每个输出端口。如果端口未连接，或其连接路径最终**未**通向任何 `文件输出 (File Output)` 节点 (使用 `utils.helpers.check_path_reaches_file_output` 检测)，则认为需要连接。
            *   为需要连接的端口寻找或创建对应的 `文件输出` 节点。
            *   **根据 "区分数据与灯光通道" 和 "使用多层EXR格式" 设置，自动配置基础路径和文件槽路径，规则如下:**
                1.  **区分通道 + 多层EXR**: 
                    *   数据节点: `//renders/{scene_name}/{layer_name}/data/{scene_name}_{layer_name}_`
                    *   图像节点: `//renders/{scene_name}/{layer_name}/images/{scene_name}_{layer_name}_`
                2.  **区分通道 + 单层EXR**:
                    *   数据节点基础路径: `//renders/{scene_name}/{layer_name}/`
                    *   图像节点基础路径: `//renders/{scene_name}/{layer_name}/`
                    *   文件槽路径: `Scene_Layer_ChannelName_` (例如: `MyScene_MyLayer_Depth_`)
                3.  **合并通道 + 多层EXR**:
                    *   节点基础路径: `//renders/{scene_name}/{layer_name}/{scene_name}_{layer_name}_`
                4.  **合并通道 + 单层EXR**:
                    *   节点基础路径: `//renders/{scene_name}/{layer_name}/`
                    *   文件槽路径: `Scene_Layer_ChannelName_` (例如: `MyScene_MyLayer_Image_`)
            *   根据通道类型（或合并模式）连接到对应的 `文件输出` 节点。
            *   **选择逻辑:**
                *   如果选中一个或多个 `渲染层 (R_LAYERS)` 节点，则仅处理选中的节点。
                *   如果选中任何 `文件输出 (OUTPUT_FILE)` 节点，则不执行任何操作并提示用户。
                *   如果未选中任何节点，则处理场景中所有的 `渲染层` 节点。
        *   **破坏性:**
            *   首先**删除**合成器节点树中所有现有的 `
#### Blender 5.0 适配说明（File Output 节点）

Blender 5.0 对合成器的文件输出节点进行了重构：

- 将原先的 `base_path` 拆分为 `directory` 与 `file_name`。
- 单层图片模式使用 `file_output_items[i].name` 来决定每个输入的文件名后缀（最终文件名构成为：`{directory}/{file_name}{SocketName}{frame}.{ext}`）。
- 多层 EXR 模式使用 `layer_slots` 管理每个层的名称，并保存为同一个 EXR 文件的多层。

本插件已适配以上变化，自动连接与批量重命名功能在 5.0 中保持原有目标与行为。

#### 版本兼容与智能适配

- 自动检测节点 API：优先使用 `directory/file_name/file_output_items`；旧版自动回退到 `base_path/file_slots`。
- 输入创建：统一使用 `layer_slots.new(name)` 创建输入，兼容多层 EXR 和单层图像模式。
- 节点树访问：优先使用编辑器中的活动合成器节点树；5.0 使用 `scene.compositing_node_group`；旧版回退到 `scene.node_tree`。

#### 自动链接逻辑（简述）
- 查找所有未连接到文件输出的渲染层端口，按设置分离“数据类”与“其他”通道。
- 自动创建/复用目标文件输出节点，配置输出目录与文件名前缀。
- 为每个输入建立链接，并设置单项名称（或旧版路径）保证最终文件名可读。