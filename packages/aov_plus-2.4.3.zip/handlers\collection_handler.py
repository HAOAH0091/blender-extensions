import bpy
from bpy.app.handlers import persistent

# 全局变量，用于跟踪已处理的集合和初始化状态
processed_collections = set()
_aov_plus_initialized = False

def find_layer_collection_recursive(layer_collection, target_collection):
    """递归查找与目标集合关联的层级集合 (辅助函数)"""
    if not layer_collection or not target_collection: return None
    # 使用 collection 属性比较，更可靠
    if hasattr(layer_collection, 'collection') and layer_collection.collection == target_collection:
        return layer_collection
    if hasattr(layer_collection, 'children'):
        for child in layer_collection.children:
            found = find_layer_collection_recursive(child, target_collection)
            if found:
                return found
    return None

def init_collection_handler_internal():
    """初始化集合处理器状态"""
    global processed_collections, _aov_plus_initialized
    processed_collections.clear()
    if bpy.data and hasattr(bpy.data, 'collections'):
        try:
             for coll in bpy.data.collections:
                 processed_collections.add(coll.name_full) # Use name_full for unique ID
        except Exception as e:
             print(f"Error initializing collection handler: {e}")
    _aov_plus_initialized = True
    print("AOV+ Collection Handler Initialized.") # 添加调试信息

def ensure_handler_initialized():
    """确保处理器已初始化 - 可在需要时主动调用"""
    global _aov_plus_initialized
    if not _aov_plus_initialized:
        try:
            if bpy.data and hasattr(bpy.data, 'collections'):
                init_collection_handler_internal()
                return True
        except Exception as e:
            print(f"Error in ensure_handler_initialized: {e}")
            return False
    return _aov_plus_initialized

@persistent
def collection_handler(scene):
    """Depsgraph更新后处理器，用于处理新创建的集合（完全隔离模式）"""
    global _aov_plus_initialized, processed_collections

    # --- 初始化检查 ---
    if not _aov_plus_initialized:
        try:
            if scene and bpy.data and hasattr(bpy.data, 'collections'):
                init_collection_handler_internal()
            else:
                return # Data not ready
        except (AttributeError, ReferenceError):
            return # Blender data structures not fully initialized
        if not _aov_plus_initialized:
            return # Initialization failed

    # --- 检查模式是否启用 --- #
    if not hasattr(scene, 'is_full_isolation_enabled') or not scene.is_full_isolation_enabled:
        # Keep processed_collections updated even when disabled
        if bpy.data and hasattr(bpy.data, 'collections'):
             try:
                 current_collections = set(coll.name_full for coll in bpy.data.collections)
                 processed_collections.clear()
                 processed_collections.update(current_collections)
             except ReferenceError:
                 pass # Closing file
             except Exception as e:
                 print(f"Error updating processed collections while disabled: {e}")
        return

    # --- 数据可用性检查 --- #
    if not bpy.data or not hasattr(bpy.data, 'collections') or not hasattr(scene, 'view_layers'):
        return

    # --- 检查新集合 --- #
    try:
        current_collections_names = set(coll.name_full for coll in bpy.data.collections)
    except ReferenceError:
        return # Closing file
    except Exception as e:
         print(f"Error getting current collections: {e}")
         return

    new_collection_names = current_collections_names - processed_collections

    # 如果没有新集合，仅更新列表并返回
    if not new_collection_names:
        processed_collections.clear()
        processed_collections.update(current_collections_names)
        return

    # --- 处理新集合 --- #
    active_view_layer = bpy.context.view_layer if bpy.context else None

    for coll_name_full in new_collection_names:
        try:
            # Find the actual collection object by its full name path if necessary
            # This part might be complex if dealing with deeply nested structures immediately after creation.
            # A simpler approach is often to find it by simple name if context allows, but full name is safer.
            # Let's assume we can get it directly for now.
            collection = bpy.data.collections.get(coll_name_full.split("->")[-1]) # Try simple name first
            if not collection:
                 # TODO: Add logic to find collection by full path if simple name fails
                 print(f"Warning: Could not find collection '{coll_name_full}' immediately after creation.")
                 continue

            # Skip specific collections like Scene Collection
            if collection.name == "Scene Collection" or collection.name == "Master Collection":
                continue

            # Process this collection in all view layers *except* the active one
            for view_layer in scene.view_layers:
                if active_view_layer and view_layer == active_view_layer:
                    continue

                if not hasattr(view_layer, 'layer_collection'): continue

                # Find the corresponding LayerCollection in this view layer
                layer_coll_found = find_layer_collection_recursive(view_layer.layer_collection, collection)

                if layer_coll_found and hasattr(layer_coll_found, 'exclude'):
                    # Exclude in non-active view layers
                    layer_coll_found.exclude = True
                    # print(f"Excluded '{coll_name_full}' in VL '{view_layer.name}'") # Optional debug print

        except ReferenceError:
             continue # Object might be gone
        except AttributeError:
             continue # Attribute might not be available yet
        except Exception as e:
             print(f"Error processing new collection '{coll_name_full}': {e}")
             import traceback
             traceback.print_exc()

    # --- 更新已处理列表 --- #
    processed_collections.clear()
    processed_collections.update(current_collections_names)


# --- 注册/注销 Handlers --- #

@persistent
def load_post_handler(dummy):
    """文件加载后初始化处理器"""
    global _aov_plus_initialized
    print("AOV+ Collection Handler: File loaded, initializing...")
    _aov_plus_initialized = False
    # 延迟初始化，给Blender时间完全加载数据
    def delayed_init():
        try:
            init_collection_handler_internal()
        except Exception as e:
            print(f"Error in delayed initialization: {e}")
    
    # 使用timer确保在下一帧执行初始化
    bpy.app.timers.register(delayed_init, first_interval=0.1)

def register_handlers():
    global _aov_plus_initialized
    # 重置初始化标志，以便在加载或启用插件时重新初始化
    _aov_plus_initialized = False
    
    # 确保处理器只添加一次
    if collection_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(collection_handler)
    
    # 添加文件加载后的处理器
    if load_post_handler not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(load_post_handler)
    
    # 立即尝试初始化（如果数据可用）
    try:
        if bpy.data and hasattr(bpy.data, 'collections'):
            init_collection_handler_internal()
    except Exception as e:
        print(f"Error in immediate initialization: {e}")

def unregister_handlers():
    global _aov_plus_initialized
    if collection_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(collection_handler)
    if load_post_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(load_post_handler)
    _aov_plus_initialized = False # Reset on unregister too
    processed_collections.clear() 