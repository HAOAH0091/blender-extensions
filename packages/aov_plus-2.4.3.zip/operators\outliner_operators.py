import bpy
from bpy.types import Operator, Panel

from ..handlers import collection_handler

LAYER_NAME_COUNTER_WIDTH = 3
NODE_SPACING_Y = 300


# ---------------------------------------------------------------------------
# 核心隔离逻辑（模块级函数，供多个 Operator 共用）
# ---------------------------------------------------------------------------

def _do_isolate(operator, context, selected_collections, include_children):
    """
    执行隔离操作。
    selected_collections: set of bpy.types.Collection
    include_children: bool，是否将子级集合也纳入可见范围
    """
    scene = context.scene

    if hasattr(scene, 'is_full_isolation_enabled') and scene.is_full_isolation_enabled:
        collection_handler.ensure_handler_initialized()

    if not selected_collections:
        operator.report({'WARNING'}, "请先选择至少一个集合")
        return {'CANCELLED'}

    if len(selected_collections) == 1:
        new_layer_name = next(iter(selected_collections)).name
    else:
        new_layer_name = "_".join(
            coll.name for coll in sorted(selected_collections, key=lambda c: c.name)
        )

    base_name = new_layer_name
    counter = 1
    while new_layer_name in scene.view_layers:
        new_layer_name = f"{base_name}.{str(counter).zfill(LAYER_NAME_COUNTER_WIDTH)}"
        counter += 1

    bpy.ops.scene.view_layer_add(type='COPY')
    new_view_layer = scene.view_layers[-1]
    new_view_layer.name = new_layer_name

    override = context.copy()
    override['view_layer'] = new_view_layer

    # 若单选且包含子级：
    #   1. 收集所有后代集合加入可见范围
    #   2. 快照当前视图层的 exclude 状态，用于在新视图层中保持子级原本的禁用状态
    # 两个操作条件刻意保持一致，只在需要时执行。
    effective_collections = set(selected_collections)
    original_exclude = {}
    if len(selected_collections) == 1 and include_children:
        def collect_descendants(coll):
            for child in coll.children:
                effective_collections.add(child)
                collect_descendants(child)
        for coll in selected_collections:
            collect_descendants(coll)

        def snapshot_exclude(layer_coll):
            if not layer_coll:
                return
            try:
                original_exclude[layer_coll.collection] = layer_coll.exclude
            except AttributeError:
                pass
            for child in layer_coll.children:
                snapshot_exclude(child)
        snapshot_exclude(context.view_layer.layer_collection)

    with context.temp_override(**override):
        def process_collection_visibility(layer_collection):
            if not layer_collection:
                return
            for layer_coll in layer_collection.children:
                if not layer_coll:
                    continue
                try:
                    is_locked = getattr(layer_coll.collection, 'is_locked_for_isolate', False)
                    is_selected = layer_coll.collection in effective_collections

                    if is_locked:
                        # 锁定集合：始终强制可见，忽略原始状态
                        layer_coll.exclude = False
                        layer_coll.hide_viewport = False
                    elif is_selected:
                        # 选中集合（父级本身 or 子级）：保持原视图层中的 exclude 状态
                        was_excluded = original_exclude.get(layer_coll.collection, False)
                        is_parent = layer_coll.collection in selected_collections
                        if is_parent or not was_excluded:
                            layer_coll.exclude = False
                            layer_coll.hide_viewport = False
                        else:
                            layer_coll.exclude = True
                    else:
                        layer_coll.exclude = True

                    process_collection_visibility(layer_coll)
                except AttributeError:
                    print(f"Warning: Could not access attributes for layer collection '{layer_coll.name}'")
                    continue

        process_collection_visibility(new_view_layer.layer_collection)

    # --- Compositor Node Handling ---
    node_tree = getattr(scene, 'compositing_node_group', None)
    if not node_tree:
        node_tree = getattr(scene, 'node_tree', None)
    if node_tree:
        rlayer_nodes = [node for node in node_tree.nodes if node.type == 'R_LAYERS']
        lowest_y = min((node.location[1] for node in rlayer_nodes), default=0)

        render_layer_node = node_tree.nodes.new('CompositorNodeRLayers')
        render_layer_node.layer = new_view_layer.name

        # 若已有 RLayer 节点则排在最下方，否则放在原点
        offset_y = lowest_y - NODE_SPACING_Y if rlayer_nodes else 0
        render_layer_node.location = (0, offset_y)
    else:
        print("No compositor node tree on scene, skipping compositor node creation.")

    return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class OUTLINER_OT_toggle_collection_lock(Operator):
    """切换集合锁定状态"""
    bl_idname = "outliner.toggle_collection_lock"
    bl_label = "锁定/解锁集合"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_collections = []
        for item in context.selected_ids:
            if isinstance(item, bpy.types.Collection):
                selected_collections.append(item)

        if not selected_collections:
            self.report({'WARNING'}, "请先选择至少一个集合")
            return {'CANCELLED'}

        for collection in selected_collections:
            collection.is_locked_for_isolate = not collection.is_locked_for_isolate
            if collection.is_locked_for_isolate:
                collection.color_tag = 'COLOR_02'
            else:
                collection.color_tag = 'NONE'

        return {'FINISHED'}


class OUTLINER_OT_isolate_collections_do(Operator):
    """执行隔离（无弹框判断），供询问框按钮直接调用"""
    bl_idname = "outliner.isolate_collections_do"
    bl_label = "执行隔离集合"
    bl_options = {'REGISTER', 'UNDO'}

    include_children: bpy.props.BoolProperty(
        name="同时隔离子级集合",
        default=True,
        options={'SKIP_SAVE'},
    )

    def execute(self, context):
        selected = set()
        for item in context.selected_ids:
            if isinstance(item, bpy.types.Collection):
                selected.add(item)
        return _do_isolate(self, context, selected, self.include_children)


class OUTLINER_PT_isolate_collections_ask(Panel):
    """询问是否连同子级集合一起隔离的浮动面板"""
    bl_idname = "OUTLINER_PT_isolate_collections_ask"
    bl_label = "隔离集合"
    bl_space_type = 'TOPBAR'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 16

    def draw(self, context):
        layout = self.layout
        layout.label(text="是否连同子级集合一起隔离？")
        layout.separator()

        row = layout.row(align=True)
        row.scale_y = 1.3

        col_yes = row.column(align=True)
        col_yes.active_default = True
        op_yes = col_yes.operator("outliner.isolate_collections_do", text="是")
        op_yes.include_children = True

        col_no = row.column(align=True)
        op_no = col_no.operator("outliner.isolate_collections_do", text="否")
        op_no.include_children = False


class OUTLINER_OT_isolate_collections(Operator):
    """隔离选中的集合（入口：判断是否弹框）"""
    bl_idname = "outliner.isolate_collections"
    bl_label = "隔离集合"
    bl_options = {'REGISTER', 'UNDO'}

    def _get_selected_collections(self, context):
        selected = set()
        for item in context.selected_ids:
            if isinstance(item, bpy.types.Collection):
                selected.add(item)
        return selected

    def invoke(self, context, event):
        selected_collections = self._get_selected_collections(context)

        # 多选时直接执行，不弹框
        if len(selected_collections) != 1:
            return self.execute(context)

        # 单选时检查是否有子集合
        single_coll = next(iter(selected_collections))
        if len(single_coll.children) > 0:
            bpy.ops.wm.call_panel(name="OUTLINER_PT_isolate_collections_ask", keep_open=False)
            return {'FINISHED'}

        # 单选且无子集合，直接执行
        return self.execute(context)

    def execute(self, context):
        selected = self._get_selected_collections(context)
        # 入口 execute 不含子级（多选或无子集合场景），include_children=False
        return _do_isolate(self, context, selected, include_children=False)


class OUTLINER_OT_toggle_full_isolation(Operator):
    """切换完全隔离模式"""
    bl_idname = "outliner.toggle_full_isolation"
    bl_label = "完全隔离模式"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "切换完全隔离模式。启用后，新创建的集合将在其他视图层自动排除"

    def execute(self, context):
        context.scene.is_full_isolation_enabled = not context.scene.is_full_isolation_enabled

        if context.scene.is_full_isolation_enabled:
            collection_handler.ensure_handler_initialized()
            self.report({'INFO'}, "完全隔离模式已启用")
        else:
            self.report({'INFO'}, "完全隔离模式已禁用")

        return {'FINISHED'}
