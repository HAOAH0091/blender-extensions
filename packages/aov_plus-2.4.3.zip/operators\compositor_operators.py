import bpy
from bpy.types import Operator
from bpy.props import BoolProperty

# --- Helper Function to Trace Paths ---
def check_path_reaches_file_output(start_output_socket, visited_sockets=None):
    """
    Recursively checks if any path starting from start_output_socket 
    eventually reaches an input socket of a node with type 'OUTPUT_FILE'.
    Uses visited_sockets to handle cycles and prevent infinite recursion.
    Returns True if a File Output node is found, False otherwise.
    """
    if visited_sockets is None:
        visited_sockets = set()

    # Prevent infinite loops by checking if we've visited this socket before *in this trace path*
    if start_output_socket in visited_sockets:
        return False
    visited_sockets.add(start_output_socket)

    # Iterate through all links originating from the current socket
    for link in start_output_socket.links:
        to_socket = link.to_socket
        to_node = to_socket.node

        # Base case: Found a File Output node
        if to_node.type == 'OUTPUT_FILE':
            return True

        # Recursive step: Check outputs of the connected node
        # If the connected node has outputs, trace them.
        # Be careful about nodes that don't propagate signals straightforwardly (e.g., Mix nodes with Factor)
        # For simplicity, we trace all *enabled* outputs.
        for next_output_socket in to_node.outputs:
            if next_output_socket.enabled:
                # Pass the *same* visited_sockets set to the recursive call to track the overall path
                if check_path_reaches_file_output(next_output_socket, visited_sockets):
                    return True # Found a path down this branch
    
    # If no path from this socket leads to a File Output node
    return False

# --- 新增辅助函数 ---
def get_prefixed_name(source_socket, render_layer_node, context):
    """生成前缀文件名，不包括通道子目录"""
    name_parts = []
    settings = context.scene.auto_rename_settings

    try:
         scene_name = render_layer_node.scene.name
         layer_name = render_layer_node.layer
    except AttributeError:
         print("Warning: Could not get scene/layer name for prefixing.")
         scene_name = "Scene"
         layer_name = "Layer"

    if settings.use_scene_prefix: name_parts.append(scene_name)
    if settings.use_layer_prefix: name_parts.append(layer_name)
    name_parts.append(source_socket.name)

    return "_".join(name_parts) + "_"

def get_channel_directory(socket_name):
    """获取通道子目录名称"""
    return f"{socket_name}/"

def get_file_base_name(source_socket, render_layer_node, context):
    """生成文件基础名（File Output 的 File Name 前缀）

    在 Blender 5.0 中，文件输出节点使用 `directory` 与 `file_name`，
    单层图片模式下最终文件名为：{directory}/{file_name}{SocketName}{frame}.{ext}
    这里返回的就是 `file_name` 的基础前缀（已带下划线）。
    """
    prefixed_name = get_prefixed_name(source_socket, render_layer_node, context)
    return prefixed_name

def get_output_base_directory(context):
    """获取输出基础目录，优先使用用户自定义目录"""
    settings = context.scene.auto_rename_settings
    if getattr(settings, 'use_custom_output_directory', False) and getattr(settings, 'custom_output_directory', ''):
        base_dir = settings.custom_output_directory
        # 确保以 / 结尾
        if not base_dir.endswith('/') and not base_dir.endswith('\\'):
            base_dir = base_dir + '/'
        return base_dir
    return "//renders/"

def build_output_directory(context, scene_name, layer_name, subfolder=""):
    """构建完整的输出目录路径，自动处理自定义根目录"""
    base_dir = get_output_base_directory(context)
    # 确保 base_dir 以 / 结尾
    if not base_dir.endswith('/') and not base_dir.endswith('\\'):
        base_dir = base_dir + '/'
    path = f"{base_dir}{scene_name}/{layer_name}/"
    if subfolder:
        path = f"{path}{subfolder}/"
    return path

def trace_to_render_layer_socket(input_socket, visited=None):
    """Traces back from a file output input socket to the originating Render Layer output socket."""
    if visited is None: visited = set()
    if input_socket in visited: return None
    visited.add(input_socket)

    if not input_socket.links: return None

    from_socket = input_socket.links[0].from_socket
    from_node = from_socket.node

    if from_node.type == 'R_LAYERS':
        return from_socket # Found the source Render Layer socket
    else:
        # If it's not an RLayer node, trace back its *relevant* input
        # This logic might need refinement depending on node types encountered
        # For simple passthrough nodes, trace the first input
        if from_node.inputs:
            # Find the input corresponding to the socket we came from (if possible)
            # This assumes a direct relationship which might not always hold
            # A more robust approach might be needed for complex node groups
            relevant_input = None
            for inp in from_node.inputs:
                 # Heuristic: match names or types if possible, otherwise default to first
                 if inp.name == from_socket.name: # Check name first
                      relevant_input = inp
                      break
            if not relevant_input and from_node.inputs: # Fallback to first input
                 relevant_input = from_node.inputs[0]

            if relevant_input and relevant_input.links:
                 # Recursive call
                 return trace_to_render_layer_socket(relevant_input, visited)

    return None # Trace failed or hit a dead end

def get_all_connected_render_layer_nodes(input_socket, visited=None):
    """
    Recursively finds all Render Layer nodes connected to the given input socket.
    Returns a set of R_LAYERS nodes.
    """
    if visited is None:
        visited = set()
    
    # Prevent cycles
    if input_socket in visited:
        return set()
    visited.add(input_socket)
    
    connected_nodes = set()
    
    if not input_socket.links:
        return connected_nodes
        
    for link in input_socket.links:
        from_socket = link.from_socket
        from_node = from_socket.node
        
        if from_node.type == 'R_LAYERS':
            connected_nodes.add(from_node)
        else:
            # Recursively trace all inputs of this node
            # This ensures we traverse through Mix nodes, Math nodes, etc.
            for inp in from_node.inputs:
                # Optimization: only trace if linked
                if inp.links:
                    connected_nodes.update(get_all_connected_render_layer_nodes(inp, visited))
                    
    return connected_nodes

# --- End Helper Function ---

# --- Compositor Tree Access (Blender 5.0) ---
def get_active_compositor_tree(context):
    """获取当前活动的合成器节点树（适配 Blender 5.0）

    优先使用节点编辑器中的树；否则使用场景的 `compositing_node_group`；
    再否则回退到第一个 CompositorNodeTree。
    """
    try:
        # Prefer the node editor's active tree when in Compositor
        space = getattr(context, 'space_data', None)
        if space and getattr(space, 'tree_type', '') == 'CompositorNodeTree':
            tree = getattr(space, 'edit_tree', None) or getattr(space, 'node_tree', None)
            if tree:
                return tree
        # Fallback: scene-linked compositor tree
        tree = getattr(context.scene, 'compositing_node_group', None)
        if tree:
            return tree
        # Legacy fallback: Scene.node_tree (<5.0)
        legacy_tree = getattr(context.scene, 'node_tree', None)
        if legacy_tree:
            return legacy_tree
        # Last resort: first compositor node tree in data
        for ng in bpy.data.node_groups:
            if getattr(ng, 'bl_idname', '') == 'CompositorNodeTree':
                return ng
    except Exception:
        pass
    return None

# --- Version / Node API helpers ---
def file_output_supports_new_api(node):
    """检测 File Output 节点是否为 5.0 新API（directory/file_name/file_output_items）。"""
    return hasattr(node, 'directory') and hasattr(node, 'file_name') and hasattr(node, 'file_output_items')

def set_file_output_location(node, directory, file_name):
    """统一设置文件输出节点的路径（兼容旧版）。"""
    if file_output_supports_new_api(node):
        node.directory = directory
        node.file_name = file_name
    else:
        # 旧版：只有 base_path，需将目录与文件名前缀拼接
        if not directory.endswith('/') and not directory.endswith('\\'):
            directory = directory + '/'
        try:
            node.base_path = directory + file_name
        except Exception:
            node.base_path = directory

def set_item_name_or_path(node, index, name):
    """设置单项的名称（5.0）或旧版路径槽的 path。"""
    try:
        if file_output_supports_new_api(node) and hasattr(node, 'file_output_items'):
            # 确保 index 有效
            if index < len(node.file_output_items):
                try:
                    node.file_output_items[index].name = name
                except Exception as e:
                    print(f"    Warning: Could not set file_output_items[{index}].name to '{name}': {e}")
            else:
                print(f"    Warning: Index {index} out of range for file_output_items (len={len(node.file_output_items)})")
        else:
            # 旧版：file_slots
            if hasattr(node, 'file_slots'):
                while len(node.file_slots) <= index:
                    node.file_slots.new(f"Slot_{len(node.file_slots)+1}")
                node.file_slots[index].path = name
    except Exception as e:
        print(f"    Warning: Could not set item name/path for index {index} to '{name}': {e}")

def normalize_socket_name(name: str) -> str:
    """将本地化/别名端口名归一化为文件输出层常用英文名。"""
    if not name:
        return name
    n = name.strip().lower()
    mapping = {
        '图像': 'Image',
        'combined': 'Image',
        'image': 'Image',
        'alpha': 'Alpha',
        '深度': 'Depth',
        'z': 'Depth',
        'depth': 'Depth',
        '雾': 'Mist',
        'mist': 'Mist',
        '法线': 'Normal',
        'normal': 'Normal',
        '位置': 'Position',
        'position': 'Position',
        '向量': 'Vector',
        'vector': 'Vector',
    }
    return mapping.get(n, name)

def format_output_name(name: str, is_single_layer: bool) -> str:
    """
    格式化输出通道名称
    
    参数：
        name: 原始通道名称
        is_single_layer: 是否为单层模式（True=单层EXR，False=多层EXR）
    
    返回：
        格式化后的名称（单层模式下添加下划线后缀）
    """
    if is_single_layer:
        return f"{name}_"
    return name

def ensure_file_output_input_via_link(node, node_tree, output_socket, target_name):
    """通过创建连线的方式确保文件输出节点存在输入端口（Blender 5.0新方法）
    
    核心思路：利用Blender的特性 - 当连线连接到File Output节点时，
    如果节点的输入不足，Blender会自动创建新的输入端口。
    
    参数：
        node: 文件输出节点
        node_tree: 节点树
        output_socket: 源输出端口（渲染层的输出）
        target_name: 目标输入名称
        
    返回：
        成功创建的连线对象，失败返回None
    """
    try:
        # 方法1: 检查是否已有同名输入，避免重复创建
        existing_input = node.inputs.get(target_name)
        if existing_input:
            # 检查是否已经连接
            if not existing_input.is_linked:
                link = node_tree.links.new(output_socket, existing_input)
                return link
            else:
                # 已连接，返回现有连线
                return existing_input.links[0] if existing_input.links else None
        
        # 方法2: 利用Blender 5.0的自动输入创建机制
        # 当我们创建连线时，File Output节点会自动添加新的输入端口
        
        # 记录连线前的输入数量
        inputs_before = len(node.inputs)
        
        # 尝试连接到一个"虚拟"位置来触发新输入创建
        # Blender会自动为新连接创建输入端口
        try:
            # 对于多层EXR模式，使用layer_slots
            if hasattr(node, 'layer_slots') and node.format.file_format == 'OPEN_EXR_MULTILAYER':
                # 创建新的layer slot
                slot = node.layer_slots.new(target_name)
                # 多重刷新策略
                node.update()
                node_tree.update_tag()
                
                # 尝试多种方式找到对应的输入
                new_input = None
                
                # 方式1：通过名称精确匹配（最可靠）
                new_input = node.inputs.get(target_name)
                
                # 方式2：遍历所有输入，找名称匹配的（即使已连接）
                if not new_input:
                    for inp in node.inputs:
                        if inp.name == target_name:
                            new_input = inp
                            break
                
                # 方式3：查找最后一个未连接的输入（最后的回退）
                if not new_input and len(node.inputs) > inputs_before:
                    # 从后往前找第一个未连接的
                    for inp in reversed(list(node.inputs)):
                        if not inp.is_linked:
                            new_input = inp
                            # 尝试设置名称
                            try:
                                inp.name = target_name
                            except Exception:
                                pass
                            break
                
                # 如果找到了输入，创建连线
                if new_input:
                    link = node_tree.links.new(output_socket, new_input)
                    node_tree.update_tag()
                    return link
                else:
                    print(f"    Warning: Layer slot created but input not found for '{target_name}'")
        except Exception as e:
            print(f"    Layer slots method failed: {e}")
        
        # 方法3: 使用file_output_items（Blender 5.0新API）
        if hasattr(node, 'file_output_items'):
            try:
                # 推断socket类型（注意：Blender 5.0使用的枚举值）
                # 可用值: 'FLOAT', 'INT', 'BOOLEAN', 'VECTOR', 'RGBA', 'ROTATION', 'MATRIX', 'STRING', etc.
                socket_type = 'RGBA'  # 默认为RGBA（图像类型）
                vector_dims = 0
                
                target_lower = target_name.lower()
                if target_lower in ('depth', 'z', 'mist', 'alpha', 'shadow'):
                    socket_type = 'FLOAT'
                elif target_lower in ('vector', 'position', 'normal', 'uv'):
                    socket_type = 'VECTOR'
                    vector_dims = 3
                elif target_lower in ('indexob', 'indexma'):  # Crypto passes
                    socket_type = 'FLOAT'
                # 其他所有（Image, Combined, Diffuse, Glossy等）使用 RGBA
                
                # 创建新的输出项
                # Blender 5.0 API: new(socket_type, name) ← 注意顺序！
                item = node.file_output_items.new(socket_type, target_name)
                
                # 设置向量维度（如果需要）
                if socket_type == 'VECTOR' and vector_dims > 0:
                    item.vector_socket_dimensions = vector_dims
                
                # 关键步骤：强制节点树更新
                # 这会触发file_output_items到node.inputs的同步
                node_tree.update_tag()
                node.update()
                
                # 尝试获取新输入
                # 策略1：通过名称匹配（最可靠）
                new_input = node.inputs.get(target_name)
                
                # 策略2：如果没找到，取最后创建的输入
                if not new_input and len(node.inputs) > inputs_before:
                    new_input = node.inputs[-1]
                
                # 策略3：如果还是没有，使用第一个可用输入
                if not new_input and len(node.inputs) > 0:
                    new_input = node.inputs[0]
                
                # 创建连线
                if new_input:
                    link = node_tree.links.new(output_socket, new_input)
                    return link
                else:
                    print(f"    Warning: Could not find input for '{target_name}' on node '{node.name}'")
                    return None
                    
            except Exception as e:
                print(f"    File output items method failed: {e}")
        
        # 方法4: 直接尝试连线到节点（让Blender自动处理）
        # 这是最后的尝试 - 连接到第一个可用输入或创建新输入
        try:
            # 如果节点至少有一个输入，我们可以尝试复制它的模式
            if len(node.inputs) > 0:
                # 使用第一个输入作为模板
                template_input = node.inputs[0]
                # 尝试通过layer_slots复制
                if hasattr(node, 'layer_slots'):
                    node.layer_slots.new(target_name)
                    node.update()
                    
                    # 检查新输入是否创建
                    if len(node.inputs) > inputs_before:
                        new_input = node.inputs[-1]
                        link = node_tree.links.new(output_socket, new_input)
                        return link
        except Exception as e:
            print(f"    Template-based creation failed: {e}")
        
        # 如果所有方法都失败了，返回None
        print(f"    Warning: All methods failed to create input for '{target_name}' on node '{node.name}'")
        return None
        
    except Exception as e:
        print(f"    Error in ensure_file_output_input_via_link: {e}")
        import traceback
        traceback.print_exc()
        return None

class COMPOSITOR_OT_auto_connect_outputs(Operator):
    """自动为渲染层输出创建并连接文件输出节点 (非破坏性) - v3"""
    bl_idname = "compositor.auto_connect_outputs"
    bl_label = "自动连接输出节点"
    bl_description = "为尚未连接到文件输出节点的渲染层输出创建连接 (保留现有连接)"
    bl_options = {'REGISTER', 'UNDO'}

    # Removed confirm property

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        try:
            node_tree = get_active_compositor_tree(context)
            if not node_tree:
                self.report({'WARNING'}, "没有活动的合成节点树")
                return {'CANCELLED'}
            settings = context.scene.auto_rename_settings
            total_connected_count = 0
            total_created_output_nodes = 0
            separate_outputs = settings.separate_data_light_outputs # 获取新属性的值

            # --- Check Destructive Mode --- 
            is_destructive = settings.destructive_connect_mode
            if is_destructive:
                print("Executing in DESTRUCTIVE mode.")
                # Remove all existing File Output nodes
                nodes_to_remove = [node for node in node_tree.nodes if node.type == 'OUTPUT_FILE']
                print(f"  Removing {len(nodes_to_remove)} existing File Output nodes.")
                for node in nodes_to_remove:
                    node_tree.nodes.remove(node)
                
                # Process all Render Layer nodes for recreation
                nodes_to_process = [node for node in node_tree.nodes if node.type == 'R_LAYERS']
                print(f"  Recreating outputs for {len(nodes_to_process)} Render Layer nodes.")
            else:
                print("Executing in Non-Destructive mode.")
                # --- Determine Nodes to Process (Non-Destructive Logic) ---
                nodes_to_process = []
                selected_rl_nodes = []
                selected_output_node = None

                if context.selected_nodes:
                    for node in context.selected_nodes:
                        if node.type == 'R_LAYERS' and node.select:
                            selected_rl_nodes.append(node)
                    if not selected_rl_nodes:
                        for node in context.selected_nodes:
                            if node.type == 'OUTPUT_FILE' and node.select:
                                selected_output_node = node
                                break

                if selected_rl_nodes:
                    nodes_to_process = selected_rl_nodes
                elif selected_output_node:
                    self.report({'WARNING'}, "非破坏性模式：选中文件输出节点时，不执行自动连接。请取消选择或选择渲染层节点。")
                    return {'CANCELLED'}
                else:
                    nodes_to_process = [node for node in node_tree.nodes if node.type == 'R_LAYERS']

            if not nodes_to_process:
                 self.report({'INFO'}, "未找到需要处理的渲染层节点")
                 return {'FINISHED'}
            
            print(f"Processing {len(nodes_to_process)} Render Layer node(s)...")

            # --- Process Each Render Layer Node ---
            for rl_node in nodes_to_process:
                layer_connected_count = 0
                layer_created_nodes = 0

                try:
                    layer_name = rl_node.layer
                    scene_name = rl_node.scene.name
                    if layer_name is None or scene_name is None:
                        raise AttributeError("未能检索到层或场景名称")
                except AttributeError as e:
                    print(f"警告: 无法获取节点 {rl_node.name} 的层/场景名称，已跳过。错误: {e}")
                    continue

                print(f"Checking node: {rl_node.name} (Layer: {layer_name})")

                # 1. Identify outputs needing connection
                outputs_to_connect_data = []
                outputs_to_connect_other = []
                
                if is_destructive:
                    # Destructive: Connect ALL enabled outputs (except Alpha)
                    for output in rl_node.outputs:
                         if output.enabled and output.name != 'Alpha':
                            if (output.name in ['Depth', 'Z', 'Mist', 'Normal', 'Position', 'Vector'] or
                                output.name.startswith('Crypto')):
                                outputs_to_connect_data.append(output)
                            else:
                                outputs_to_connect_other.append(output)
                    print(f"  Destructive mode: Found Data={len(outputs_to_connect_data)}, Other={len(outputs_to_connect_other)}")
                else:
                    # Non-Destructive: Check existing links
                    for output in rl_node.outputs:
                        if not output.enabled or output.name == 'Alpha':
                            continue

                        needs_connection = False
                        if not output.links:
                            needs_connection = True
                        else:
                            if not check_path_reaches_file_output(output, visited_sockets=set()):
                                needs_connection = True
                        
                        if needs_connection:
                            if (output.name in ['Depth', 'Z', 'Mist', 'Normal', 'Position', 'Vector'] or
                                output.name.startswith('Crypto')):
                                outputs_to_connect_data.append(output)
                            else:
                                outputs_to_connect_other.append(output)
                    print(f"  Non-Destructive mode: Outputs needing connection: Data={len(outputs_to_connect_data)}, Other={len(outputs_to_connect_other)}")

                # Decide whether to merge outputs based on the new setting
                all_outputs_to_connect = []
                if not separate_outputs:
                    # Merge data and other outputs if separation is disabled
                    all_outputs_to_connect = outputs_to_connect_data + outputs_to_connect_other
                    outputs_to_connect_data = [] # Clear data list as we'll use a single node
                    outputs_to_connect_other = all_outputs_to_connect # Use 'other' list for the combined outputs
                    print(f"  Separation disabled: Merged all {len(all_outputs_to_connect)} outputs.")

                    # << NEW: Sort the combined list based on the original Render Layer node output order >>
                    try:
                        # Create a mapping from output name to its index on the RL node
                        rl_output_order = {out.name: idx for idx, out in enumerate(rl_node.outputs)}
                        # Sort the combined list using the index lookup
                        outputs_to_connect_other.sort(key=lambda sock: rl_output_order.get(sock.name, float('inf'))) # Use inf for safety
                        print(f"  Sorted merged outputs based on RL node order.")
                    except Exception as e:
                        print(f"  Warning: Could not sort outputs based on RL node order: {e}")
                    # << END NEW SORTING LOGIC >>

                if not outputs_to_connect_data and not outputs_to_connect_other:
                    # If even in destructive mode there are no outputs, skip
                    print(f"  Skipping {rl_node.name}: No outputs found to connect.")
                    continue 

                # 2. Find or Create Target File Output Nodes
                # In destructive mode, we always create. In non-destructive, we find first.
                data_output_node = None
                other_output_node = None
                newly_created_data_node = False
                newly_created_other_node = False

                # Adjust node names based on separation setting
                if separate_outputs:
                    data_node_name = f"DataOutput_{layer_name}"
                    other_node_name = f"Output_{layer_name}"
                    data_node_label = f"{layer_name}数据输出"
                    other_node_label = f"{layer_name}图像输出"
                else:
                    # If not separating, use a generic name for the single output node
                    data_node_name = None # We won't create a data node
                    other_node_name = f"FileOutput_{layer_name}" # Generic name
                    data_node_label = None
                    other_node_label = f"{layer_name}输出" # Generic label

                if not is_destructive:
                    # Try to find existing nodes by name only in non-destructive mode
                    for node in node_tree.nodes:
                        if node.type == 'OUTPUT_FILE':
                            if separate_outputs and node.name == data_node_name: # Only look for data node if separating
                                data_output_node = node
                            elif node.name == other_node_name: # Always look for the 'other' (or combined) node
                                other_output_node = node
                            # Break condition depends on whether we expect one or two nodes
                            if separate_outputs:
                                if data_output_node and other_output_node: break
                            else:
                                if other_output_node: break

                # Create Data node IF NEEDED (only if separating)
                if separate_outputs and outputs_to_connect_data and (is_destructive or not data_output_node):
                    # Check again if it exists ONLY if we are in non-destructive mode
                    if not is_destructive:
                         data_output_node = node_tree.nodes.get(data_node_name)
                    
                    # If still no node, create it
                    if not data_output_node:
                        data_output_node = node_tree.nodes.new('CompositorNodeOutputFile')
                        # CRITICAL: Set media_type FIRST, then file_format
                        if settings.use_multilayer_exr:
                            data_output_node.format.media_type = 'MULTI_LAYER_IMAGE'
                            data_output_node.format.file_format = 'OPEN_EXR_MULTILAYER'
                        else:
                            data_output_node.format.media_type = 'IMAGE'
                            data_output_node.format.file_format = 'OPEN_EXR'
                        data_output_node.name = data_node_name
                        data_output_node.label = data_node_label # Use assigned label
                        data_output_node.location = (rl_node.location.x + rl_node.width + 100, rl_node.location.y + 100)
                        layer_created_nodes += 1
                        newly_created_data_node = True

                # Create Other (or combined) node IF NEEDED
                if outputs_to_connect_other and (is_destructive or not other_output_node): 
                    if not is_destructive:
                        other_output_node = node_tree.nodes.get(other_node_name)
                    
                    if not other_output_node:
                        other_output_node = node_tree.nodes.new('CompositorNodeOutputFile')
                        # CRITICAL: Set media_type FIRST, then file_format
                        if settings.use_multilayer_exr:
                            other_output_node.format.media_type = 'MULTI_LAYER_IMAGE'
                            other_output_node.format.file_format = 'OPEN_EXR_MULTILAYER'
                        else:
                            other_output_node.format.media_type = 'IMAGE'
                            other_output_node.format.file_format = 'OPEN_EXR'
                        other_output_node.name = other_node_name
                        other_output_node.label = other_node_label # Use assigned label
                        # Adjust position slightly if it's the only node being created
                        y_pos = rl_node.location.y - 200 if separate_outputs else rl_node.location.y # Center if only one
                        other_output_node.location = (rl_node.location.x + rl_node.width + 100, y_pos)
                        layer_created_nodes += 1
                        newly_created_other_node = True

                # 3. Configure Nodes (always configure if destructive, only new if non-destructive)
                use_multilayer = settings.use_multilayer_exr
                file_name_prefix = f"{scene_name}_{layer_name}_"
                target_format = 'OPEN_EXR_MULTILAYER' if use_multilayer else 'OPEN_EXR'
                
                # 3.1 Format Compatibility Check (for non-destructive mode)
                # If the node exists but has incompatible format, delete and recreate
                
                # Check data_output_node
                if separate_outputs and data_output_node and not is_destructive and not newly_created_data_node:
                    current_media_type = getattr(data_output_node.format, 'media_type', None)
                    target_media_type = 'MULTI_LAYER_IMAGE' if use_multilayer else 'IMAGE'
                    
                    if current_media_type != target_media_type:
                        print(f"  Data node media_type mismatch: {current_media_type} != {target_media_type}, rebuilding...")
                        node_tree.nodes.remove(data_output_node)
                        # Recreate the node with correct mode and format
                        data_output_node = node_tree.nodes.new('CompositorNodeOutputFile')
                        # Set media_type FIRST, then file_format
                        data_output_node.format.media_type = target_media_type
                        if use_multilayer:
                            data_output_node.format.file_format = 'OPEN_EXR_MULTILAYER'
                        else:
                            data_output_node.format.file_format = 'OPEN_EXR'
                        data_output_node.name = data_node_name
                        data_output_node.label = data_node_label
                        data_output_node.location = (rl_node.location.x + rl_node.width + 100, rl_node.location.y + 100)
                        layer_created_nodes += 1
                        newly_created_data_node = True
                
                # Check other_output_node
                if other_output_node and not is_destructive and not newly_created_other_node:
                    current_media_type = getattr(other_output_node.format, 'media_type', None)
                    target_media_type = 'MULTI_LAYER_IMAGE' if use_multilayer else 'IMAGE'
                    
                    if current_media_type != target_media_type:
                        print(f"  Other node media_type mismatch: {current_media_type} != {target_media_type}, rebuilding...")
                        node_tree.nodes.remove(other_output_node)
                        # Recreate the node with correct mode and format
                        other_output_node = node_tree.nodes.new('CompositorNodeOutputFile')
                        # Set media_type FIRST, then file_format
                        other_output_node.format.media_type = target_media_type
                        if use_multilayer:
                            other_output_node.format.file_format = 'OPEN_EXR_MULTILAYER'
                        else:
                            other_output_node.format.file_format = 'OPEN_EXR'
                        other_output_node.name = other_node_name
                        other_output_node.label = other_node_label
                        y_pos = rl_node.location.y - 200 if separate_outputs else rl_node.location.y
                        other_output_node.location = (rl_node.location.x + rl_node.width + 100, y_pos)
                        layer_created_nodes += 1
                        newly_created_other_node = True

                # Configure Data node (only if separating)
                # Note: Always configure in non-destructive mode too, in case settings changed
                if separate_outputs and data_output_node:
                    # print(f"  Configuring Data node: {data_output_node.name}")
                    if use_multilayer:
                        # Blender 5.0: 使用 directory + file_name（旧版自动拼接为 base_path）
                        set_file_output_location(
                            data_output_node,
                            build_output_directory(context, scene_name, layer_name, "data"),
                            file_name_prefix
                        )
                        # Ensure correct mode and format
                        if getattr(data_output_node.format, 'media_type', None) != 'MULTI_LAYER_IMAGE':
                            data_output_node.format.media_type = 'MULTI_LAYER_IMAGE'
                        if data_output_node.format.file_format != 'OPEN_EXR_MULTILAYER':
                            data_output_node.format.file_format = 'OPEN_EXR_MULTILAYER'
                        try:
                            data_output_node.format.color_depth = '32'
                            data_output_node.format.exr_codec = 'ZIP'
                        except Exception as e: print(f"  Config Error (Data Multi): {e}")
                    else:
                        # 单层图片（EXR）：目录到视图层，文件名前缀用于组合最终文件名
                        set_file_output_location(
                            data_output_node,
                            build_output_directory(context, scene_name, layer_name),
                            file_name_prefix
                        )
                        # Ensure correct mode and format: media_type FIRST
                        if getattr(data_output_node.format, 'media_type', None) != 'IMAGE':
                            data_output_node.format.media_type = 'IMAGE'
                        if data_output_node.format.file_format != 'OPEN_EXR':
                            data_output_node.format.file_format = 'OPEN_EXR'
                        try:
                            data_output_node.format.color_depth = '32'
                            data_output_node.format.exr_codec = 'ZIP'
                            # 设置颜色模式为RGBA
                            data_output_node.format.color_mode = 'RGBA'
                        except Exception as e:
                            print(f"  Config Error (Data Single): {e}")

                # Configure Other (or combined) node
                # Note: Always configure in non-destructive mode too, in case settings changed
                if other_output_node:
                    # print(f"  Configuring Other node: {other_output_node.name}")
                    if use_multilayer:
                        # 多层EXR模式
                        other_dir = (
                            build_output_directory(context, scene_name, layer_name, "images") if separate_outputs
                            else build_output_directory(context, scene_name, layer_name)
                        )
                        set_file_output_location(
                            other_output_node,
                            other_dir,
                            file_name_prefix
                        )
                        # Ensure correct mode and format
                        if getattr(other_output_node.format, 'media_type', None) != 'MULTI_LAYER_IMAGE':
                            other_output_node.format.media_type = 'MULTI_LAYER_IMAGE'
                        if other_output_node.format.file_format != 'OPEN_EXR_MULTILAYER':
                            other_output_node.format.file_format = 'OPEN_EXR_MULTILAYER'
                        try:
                            # 使用用户设置的色深和颜色模式
                            other_output_node.format.color_depth = settings.exr_color_depth
                            other_output_node.format.color_mode = settings.exr_color_mode
                            other_output_node.format.exr_codec = 'DWAA'
                        except Exception as e: print(f"  Config Error (Other Multi): {e}")
                    else:
                        # 单层图片（EXR）模式：目录为视图层路径，文件名前缀用于组合最终文件名
                        set_file_output_location(
                            other_output_node,
                            build_output_directory(context, scene_name, layer_name),
                            file_name_prefix
                        )
                        # Ensure correct mode and format: media_type FIRST
                        if getattr(other_output_node.format, 'media_type', None) != 'IMAGE':
                            other_output_node.format.media_type = 'IMAGE'
                        if other_output_node.format.file_format != 'OPEN_EXR':
                            other_output_node.format.file_format = 'OPEN_EXR'
                        try:
                            # 使用用户设置的色深和颜色模式
                            other_output_node.format.color_depth = settings.exr_color_depth
                            other_output_node.format.color_mode = settings.exr_color_mode
                            other_output_node.format.exr_codec = 'DWAA'
                        except Exception as e:
                            print(f"  Config Error (Other Single): {e}")

                # 4. Connect Sockets
                connected_in_pass = 0
                # Connect Data sockets (only if separating)
                if separate_outputs and data_output_node and outputs_to_connect_data:
                    # print(f"  Connecting {len(outputs_to_connect_data)} sockets to Data node {data_output_node.name}")
                    
                    for i, output in enumerate(outputs_to_connect_data):
                        target_slot_name = format_output_name(output.name, not use_multilayer)
                        
                        # 检查是否已连接
                        already_connected = False
                        for inp in data_output_node.inputs:
                            if inp.is_linked:
                                for link in inp.links:
                                    if link.from_socket == output:
                                        already_connected = True
                                        break
                            if already_connected:
                                break
                        
                        if already_connected:
                            continue  # 跳过已连接的
                        
                        # 使用新的基于连线的方法创建输入并连接
                        link = ensure_file_output_input_via_link(
                            data_output_node, 
                            node_tree, 
                            output, 
                            target_slot_name
                        )
                        
                        if link:
                            connected_in_pass += 1
                            # 对于单层图片模式，更新项名称
                            if not use_multilayer:
                                try:
                                    # 找到新创建的输入在列表中的索引
                                    if link.to_socket in data_output_node.inputs:
                                        idx = list(data_output_node.inputs).index(link.to_socket)
                                        set_item_name_or_path(data_output_node, idx, target_slot_name)
                                except Exception as e:
                                    print(f"    Warning: could not set item name/path for '{target_slot_name}': {e}")
                        else:
                            print(f"    Connect Warning: Could not create connection for {output.name} on {data_output_node.name}")

                # Connect Other (or combined) sockets
                if other_output_node and outputs_to_connect_other:
                    # print(f"  Connecting {len(outputs_to_connect_other)} sockets to Other node {other_output_node.name}")
                    
                    for i, output in enumerate(outputs_to_connect_other):
                        target_slot_name = format_output_name(output.name, not use_multilayer)
                        
                        # 检查是否已连接
                        already_connected = False
                        for inp in other_output_node.inputs:
                            if inp.is_linked:
                                for link in inp.links:
                                    if link.from_socket == output:
                                        already_connected = True
                                        break
                            if already_connected:
                                break
                        
                        if already_connected:
                            continue  # 跳过已连接的
                        
                        # 使用新的基于连线的方法创建输入并连接
                        link = ensure_file_output_input_via_link(
                            other_output_node, 
                            node_tree, 
                            output, 
                            target_slot_name
                        )
                        
                        if link:
                            connected_in_pass += 1
                            # 对于单层图片模式，更新项名称
                            if not use_multilayer:
                                try:
                                    # 找到新创建的输入在列表中的索引
                                    if link.to_socket in other_output_node.inputs:
                                        idx = list(other_output_node.inputs).index(link.to_socket)
                                        set_item_name_or_path(other_output_node, idx, target_slot_name)
                                except Exception as e:
                                    print(f"    Warning: could not set item name/path for '{target_slot_name}': {e}")
                        else:
                            print(f"    Connect Warning: Could not create connection for {output.name} on {other_output_node.name}")

                layer_connected_count = connected_in_pass
                total_connected_count += layer_connected_count
                total_created_output_nodes += layer_created_nodes
            # --- End Loop Through RL Nodes ---

            # Final Report
            mode_prefix = "[破坏性模式] " if is_destructive else ""
            if total_connected_count > 0 or total_created_output_nodes > 0:
                msg_parts = []
                if total_connected_count > 0:
                    msg_parts.append(f"连接了 {total_connected_count} 个通道") # Report total connections made
                if total_created_output_nodes > 0:
                    msg_parts.append(f"创建了 {total_created_output_nodes} 个新文件输出节点")
                self.report({'INFO'}, mode_prefix + "处理完成: " + "，".join(msg_parts))
            elif not is_destructive and selected_rl_nodes: # Specific check for non-destructive selected nodes
                layer_names = ", ".join([rl.layer for rl in selected_rl_nodes])
                self.report({'INFO'}, mode_prefix + f"渲染层 '{layer_names}' 没有需要连接到文件输出的通道")
            else: # General case for no action needed
                self.report({'INFO'}, mode_prefix + "检查完成，未执行连接或创建操作")

        except Exception as e:
            self.report({'ERROR'}, f"自动连接操作失败: {str(e)}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}

        return {'FINISHED'}


class COMPOSITOR_OT_auto_rename_outputs(Operator):
    """批量处理输出文件名"""
    bl_idname = "compositor.auto_rename_outputs"
    bl_label = "批量处理输出文件名"
    bl_description = "根据连接的渲染层输出批量处理文件输出接口名称和路径"
    bl_options = {'REGISTER', 'UNDO'}

    # confirm: BoolProperty(
    #     name="确认操作",
    #     description="确认执行操作",
    #     default=True # 保留属性
    # )

    def invoke(self, context, event):
        # 直接执行
        return self.execute(context)
        # # 检查是否存在文件输出节点
        # has_output_nodes = False
        # if context.scene and context.scene.use_nodes and context.scene.node_tree:
        #     for node in context.scene.node_tree.nodes:
        #         if node.type == 'OUTPUT_FILE':
        #             has_output_nodes = True
        #             break
        # # 只有在存在节点且未选中特定节点时才弹窗
        # if has_output_nodes and not context.selected_nodes:
        #      # return context.window_manager.invoke_props_dialog(self) # 移除弹窗
        #      return self.execute(context)
        # else:
        #      return self.execute(context)

    # def draw(self, context):
    #     # 不再需要
    #     # layout = self.layout
    #     # layout.label(text="此操作将对所有(或选中)文件输出节点应用批量重命名")
    #     # layout.label(text="并将根据连接的渲染层更新基础路径")
    #     # layout.label(text="是否继续?")
    #     pass

    def execute(self, context):
        node_tree = get_active_compositor_tree(context)
        if not node_tree:
            self.report({'WARNING'}, "没有活动的合成节点树")
            return {'CANCELLED'}

        settings = context.scene.auto_rename_settings
        renamed_count = 0
        path_updated_count = 0
        
        # 获取是否区分数据和灯光通道的设置
        separate_outputs = settings.separate_data_light_outputs

        # Determine nodes to process
        nodes_to_process = []
        if context.selected_nodes:
            nodes_to_process = [node for node in context.selected_nodes if node.type == 'OUTPUT_FILE']
            if not nodes_to_process:
                 self.report({'INFO'}, "选中的节点中没有文件输出节点")
                 return {'FINISHED'}
        else:
            nodes_to_process = [node for node in node_tree.nodes if node.type == 'OUTPUT_FILE']

        if not nodes_to_process:
             self.report({'INFO'}, "未找到需要处理的文件输出节点")
             return {'FINISHED'}

        # --- First Pass: Rename Slots/Layers --- #
        for node in nodes_to_process:
            is_multilayer = node.format.file_format == 'OPEN_EXR_MULTILAYER'

            # Iterate through a copy of inputs as names might change
            inputs_copy = list(node.inputs)
            for i, input_slot in enumerate(inputs_copy):
                if not input_slot.links: continue

                source_socket = trace_to_render_layer_socket(input_slot)

                if source_socket and source_socket.node.type == 'R_LAYERS':
                    render_layer_node = source_socket.node
                    try:
                        if is_multilayer:
                            # Multilayer EXR: Use original socket name for layer slot
                            original_slot_name = source_socket.name
                            # Ensure corresponding layer slot exists
                            while len(node.layer_slots) <= i:
                                 node.layer_slots.new(f"Layer_{len(node.layer_slots)+1}")
                            # Rename layer slot if needed
                            if node.layer_slots[i].name != original_slot_name:
                                node.layer_slots[i].name = original_slot_name
                                # Also rename the input socket to match
                                if i < len(node.inputs) and node.inputs[i].name != original_slot_name:
                                     node.inputs[i].name = original_slot_name
                                renamed_count += 1
                        else:
                            # 单层图片：设置节点的 file_name 前缀，并将对应条目名称设置为源 socket 名称
                            new_base_name = get_file_base_name(source_socket, render_layer_node, context)
                            # 更新全局 file_name 前缀（或旧版 base_path 前缀）
                            set_file_output_location(node, getattr(node, 'directory', build_output_directory(context, render_layer_node.scene.name, render_layer_node.layer)), new_base_name)
                            # 确保对应输入存在（若不存在，尝试通过 layer_slots 创建）
                            while len(node.inputs) <= i:
                                try:
                                    if hasattr(node, 'layer_slots'):
                                        node.layer_slots.new(f"Input_{len(node.inputs)+1}")
                                    else:
                                        break
                                except Exception:
                                    break
                            # 设置 file_output_items 的名称为来源 socket 名称（用于最终文件名后缀）
                            try:
                                # 判断当前节点是否为单层模式
                                is_single_layer = (
                                    hasattr(node.format, 'media_type') and 
                                    node.format.media_type == 'IMAGE'
                                )
                                target_name = format_output_name(source_socket.name, is_single_layer)
                                set_item_name_or_path(node, i, target_name)
                                # 也同步输入 socket 的名称，便于 UI 统一
                                if i < len(node.inputs) and node.inputs[i].name != target_name:
                                    node.inputs[i].name = target_name
                                renamed_count += 1
                            except Exception as e:
                                print(f"Warning: Could not set file_output_items[{i}] name: {e}")
                    except AttributeError as e:
                         print(f"Warning: Could not process slot {i} for node {node.name}: {e}")
                    except IndexError:
                         print(f"Warning: Index out of range for slot {i} on node {node.name} during renaming.")
                # else: # No source RLayer found or trace failed
                    # print(f"Could not trace source for input '{input_slot.name}' of node '{node.name}'")

        # --- Second Pass: Update Base Path --- #
        for node in nodes_to_process:
            is_multilayer = node.format.file_format == 'OPEN_EXR_MULTILAYER'
            connected_rl = None
            layer_name = "unknown_layer"
            scene_name = "unknown_scene"

            # Find the *first* connected Render Layer node to determine context
            for input_slot in node.inputs:
                if input_slot.links:
                    source_socket = trace_to_render_layer_socket(input_slot)
                    if source_socket and source_socket.node.type == 'R_LAYERS':
                        connected_rl = source_socket.node
                        break # Found one, use its context

            if connected_rl:
                try:
                    layer_name = connected_rl.layer
                    scene_name = connected_rl.scene.name
                except AttributeError:
                     print(f"Warning: Could not get attributes from connected RLayer {connected_rl.name} for path update.")
            else:
                 # Fallback: try to infer from node name if no connection found
                 node_name = node.name
                 if node_name.startswith("DataOutput_") or node_name.startswith("Output_"):
                      parts = node_name.split('_', 1)
                      if len(parts) == 2: layer_name = parts[1]
                 scene_name = context.scene.name # Use current scene name as fallback

            # Determine directory/file_name based on node type (Data vs Image) and multilayer setting
            is_data_node = node.name.startswith("DataOutput_") or "数据" in node.label
            target_directory = ""
            target_file_name = f"{scene_name}_{layer_name}_"

            if is_multilayer:
                file_prefix = f"{scene_name}_{layer_name}_"
                if separate_outputs:
                    # 1. 区分通道 + 多层EXR
                    if is_data_node:
                        target_directory = build_output_directory(context, scene_name, layer_name, "data")
                    else:
                        target_directory = build_output_directory(context, scene_name, layer_name, "images")
                else:
                    # 3. 合并通道 + 多层EXR
                    target_directory = build_output_directory(context, scene_name, layer_name)
            else:
                # 单层图片：不使用子目录，直接到视图层目录；文件名前缀在 file_name
                target_directory = build_output_directory(context, scene_name, layer_name)

            # Update output location (directory/file_name or base_path)
            try:
                # Compare current to target to avoid extra writes
                current_dir = getattr(node, 'directory', '')
                current_file = getattr(node, 'file_name', '')
                if current_dir != target_directory or current_file != target_file_name:
                    set_file_output_location(node, target_directory, target_file_name)
                    path_updated_count += 1
            except Exception as e:
                print(f"Warning: Could not update output location for node {node.name}: {e}")

        # --- Final Report --- #
        report_parts = []
        processed_node_count = len(nodes_to_process)
        target_desc = f"{processed_node_count}个文件输出节点" if processed_node_count > 1 else f"节点 '{nodes_to_process[0].name}'" if processed_node_count == 1 else "文件输出节点"
        if context.selected_nodes and processed_node_count > 0:
             target_desc = f"选中的{target_desc}"

        if renamed_count > 0:
             report_parts.append(f"重命名了 {renamed_count} 个接口")
        if path_updated_count > 0:
             report_parts.append(f"更新了 {path_updated_count} 个基础路径")

        if report_parts:
            self.report({'INFO'}, f"在{target_desc}上: " + "，".join(report_parts))
        else:
            self.report({'INFO'}, f"在{target_desc}上没有需要更新的接口或路径")

        return {'FINISHED'}

class COMPOSITOR_OT_render_selected_view_layers(Operator):
    """仅渲染选中的视图层节点对应的视图层"""
    bl_idname = "compositor.render_selected_view_layers"
    bl_label = "渲染选中视图层"
    bl_description = "只渲染当前选中的渲染层节点对应的视图层，其他视图层和文件输出将临时禁用"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        # 检查是否有合成节点树
        node_tree = get_active_compositor_tree(context)
        if not node_tree:
            self.report({'ERROR'}, "没有活动的合成节点树")
            return {'CANCELLED'}

        # 获取选中的渲染层节点
        selected_rl_nodes = [node for node in node_tree.nodes 
                           if node.select and node.type == 'R_LAYERS']
        
        if not selected_rl_nodes:
            self.report({'WARNING'}, "请选择要渲染的渲染层节点")
            return {'CANCELLED'}

        # 获取对应的视图层名称
        selected_layer_names = []
        for node in selected_rl_nodes:
            try:
                layer_name = node.layer
                if layer_name:
                    selected_layer_names.append(layer_name)
            except AttributeError:
                continue

        if not selected_layer_names:
            self.report({'ERROR'}, "选中的渲染层节点没有有效的视图层信息")
            return {'CANCELLED'}

        # 获取渲染设置
        settings = context.scene.auto_rename_settings
        render_mode = settings.render_mode
        
        # 根据渲染模式设置描述文本
        if render_mode == 'ANIMATION':
            mode_text = f"动画序列（帧 {context.scene.frame_start}-{context.scene.frame_end}）"
        elif render_mode == 'STILL':
            mode_text = f"单帧（当前帧 {context.scene.frame_current}）"
        elif render_mode == 'RANGE':
            mode_text = f"帧范围（帧 {settings.render_frame_start}-{settings.render_frame_end}）"
        
        # 显示确认对话框
        selected_names_str = "、".join(selected_layer_names)
        return context.window_manager.invoke_confirm(
            self, event, 
            message=f"渲染模式：{mode_text}\n将只渲染以下视图层：{selected_names_str}\n\n其他视图层和无关文件输出将临时禁用，确定继续？"
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.auto_rename_settings
        
        # 检查合成节点树
        node_tree = get_active_compositor_tree(context)
        if not node_tree:
            self.report({'ERROR'}, "没有活动的合成节点树")
            return {'CANCELLED'}

        # 获取选中的渲染层节点
        selected_rl_nodes = [node for node in node_tree.nodes 
                           if node.select and node.type == 'R_LAYERS']
        
        if not selected_rl_nodes:
            self.report({'WARNING'}, "请选择要渲染的渲染层节点")
            return {'CANCELLED'}

        # 收集要渲染的视图层名称
        selected_layer_names = set()
        for node in selected_rl_nodes:
            try:
                layer_name = node.layer
                if layer_name:
                    selected_layer_names.add(layer_name)
            except AttributeError:
                continue

        if not selected_layer_names:
            self.report({'ERROR'}, "选中的渲染层节点没有有效的视图层信息")
            return {'CANCELLED'}

        # 保存当前所有视图层的使用状态
        original_view_layer_states = {}
        for view_layer in scene.view_layers:
            original_view_layer_states[view_layer.name] = view_layer.use

        # 保存文件输出节点的静音状态
        original_file_output_states = {}
        # 已获取 node_tree
        
        # 找到所有连接到选中视图层的文件输出节点
        related_file_outputs = set()
        
        for node in node_tree.nodes:
            if node.type == 'OUTPUT_FILE':
                # 保存所有文件输出节点的原始静音状态
                original_file_output_states[node.name] = node.mute
                
                # 检查是否连接到选中的渲染层节点
                is_related = False
                for input_socket in node.inputs:
                    if input_socket.links:
                        # 使用新的递归函数查找所有连接的渲染层节点
                        connected_rl_nodes = get_all_connected_render_layer_nodes(input_socket)
                        # 检查是否有交集（即是否有连接到选中的渲染层节点）
                        if not connected_rl_nodes.isdisjoint(selected_rl_nodes):
                            is_related = True
                            break
                
                if is_related:
                    related_file_outputs.add(node)

        # 保存渲染帧范围设置
        original_frame_start = scene.frame_start
        original_frame_end = scene.frame_end

        try:
            # 设置视图层渲染状态
            enabled_count = 0
            disabled_count = 0
            
            for view_layer in scene.view_layers:
                if view_layer.name in selected_layer_names:
                    view_layer.use = True
                    enabled_count += 1
                else:
                    view_layer.use = False
                    disabled_count += 1

            # 设置文件输出节点状态：只启用相关的文件输出节点
            enabled_outputs = 0
            disabled_outputs = 0
            
            for node in node_tree.nodes:
                if node.type == 'OUTPUT_FILE':
                    if node in related_file_outputs:
                        node.mute = False  # 启用相关的文件输出
                        enabled_outputs += 1
                    else:
                        node.mute = True   # 禁用无关的文件输出
                        disabled_outputs += 1
            
            # 检查是否有有效的输出节点
            has_composite = False
            for node in node_tree.nodes:
                if node.type == 'COMPOSITE' and not node.mute:
                    has_composite = True
                    break
            
            if enabled_outputs == 0 and not has_composite:
                 raise Exception("未找到与选中渲染层相连的文件输出节点，且没有活动的合成输出节点。请检查节点连接。")

            # 根据渲染模式设置帧范围
            if settings.render_mode == 'RANGE':
                scene.frame_start = settings.render_frame_start
                scene.frame_end = settings.render_frame_end

            # 开始渲染
            self.report({'INFO'}, 
                       f"开始渲染 {enabled_count} 个视图层（已禁用 {disabled_count} 个）\n"
                       f"启用 {enabled_outputs} 个文件输出节点（已禁用 {disabled_outputs} 个）")

            # 强制刷新依赖图，确保 view_layer.use 状态变更在渲染前完全生效
            # 避免渲染线程持有已禁用视图层的悬空对象引用导致崩溃
            context.view_layer.update()
            context.evaluated_depsgraph_get()

            # 根据渲染模式执行不同的渲染操作
            if settings.render_mode == 'ANIMATION' or settings.render_mode == 'RANGE':
                bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
            else:  # STILL mode
                bpy.ops.render.render('INVOKE_DEFAULT')

        except Exception as e:
            # 如果出错，恢复原始状态
            for view_layer in scene.view_layers:
                if view_layer.name in original_view_layer_states:
                    view_layer.use = original_view_layer_states[view_layer.name]
            
            for node_name, original_mute in original_file_output_states.items():
                if node_name in [n.name for n in node_tree.nodes]:
                    node = node_tree.nodes[node_name]
                    node.mute = original_mute
            
            scene.frame_start = original_frame_start
            scene.frame_end = original_frame_end
            
            self.report({'ERROR'}, f"渲染启动失败: {str(e)}")
            return {'CANCELLED'}

        # 注册一个应用程序处理程序来在渲染完成后恢复状态
        def restore_all_states():
            # 恢复视图层状态
            for view_layer in scene.view_layers:
                if view_layer.name in original_view_layer_states:
                    view_layer.use = original_view_layer_states[view_layer.name]
            
            # 恢复文件输出节点状态
            for node_name, original_mute in original_file_output_states.items():
                if node_name in [n.name for n in node_tree.nodes]:
                    node = node_tree.nodes[node_name]
                    node.mute = original_mute
            
            # 恢复帧范围设置
            scene.frame_start = original_frame_start
            scene.frame_end = original_frame_end
            
            print("AOV+: 视图层和文件输出状态已恢复")

        # 使用应用程序处理程序在渲染完成后恢复状态
        def render_complete_handler(scene, depsgraph):
            restore_all_states()
            # 移除处理程序以避免重复调用
            if render_complete_handler in bpy.app.handlers.render_complete:
                bpy.app.handlers.render_complete.remove(render_complete_handler)

        def render_cancel_handler(scene, depsgraph):
            restore_all_states()
            # 移除处理程序
            if render_cancel_handler in bpy.app.handlers.render_cancel:
                bpy.app.handlers.render_cancel.remove(render_cancel_handler)

        # 添加处理程序
        bpy.app.handlers.render_complete.append(render_complete_handler)
        bpy.app.handlers.render_cancel.append(render_cancel_handler)

        return {'FINISHED'}