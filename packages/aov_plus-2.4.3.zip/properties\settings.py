import bpy
from bpy.types import PropertyGroup
from bpy.props import StringProperty, BoolProperty

class AutoRenameSettings(PropertyGroup):
    """存储自动重命名的设置"""
    use_scene_prefix: BoolProperty(
        name="添加场景名前缀",
        description="添加场景名称作为前缀",
        default=True
    )

    use_layer_prefix: BoolProperty(
        name="添加视图层名前缀",
        description="添加视图层名称作为前缀",
        default=True
    )

    use_multilayer_exr: BoolProperty(
        name="使用多层EXR格式",
        description="创建/配置输出节点时使用多层EXR格式",
        default=True
    )

    separate_data_light_outputs: BoolProperty(
        name="区分数据与灯光通道",
        description="勾选时，数据和灯光通道会连接到不同的文件输出节点；取消勾选时，所有通道连接到同一个文件输出节点。",
        default=False
    )

    destructive_connect_mode: BoolProperty(
        name="破坏性模式",
        description="启用后，'自动连接'将删除所有现有文件输出节点并重新创建连接",
        default=False
    )

    # Properties for toggling description visibility
    show_connect_description: BoolProperty(
        name="显示'自动连接'说明",
        description="显示或隐藏自动连接功能的详细行为说明",
        default=False 
    )
    show_rename_description: BoolProperty(
        name="显示'批量重命名'说明",
        description="显示或隐藏批量重命名功能的详细行为说明",
        default=False
    )
    show_render_description: BoolProperty(
        name="显示'渲染选中视图层'说明",
        description="显示或隐藏渲染选中视图层功能的详细行为说明",
        default=False
    )

    # 渲染模式设置
    render_mode: bpy.props.EnumProperty(
        name="渲染模式",
        description="选择渲染模式",
        items=[
            ('ANIMATION', "动画序列", "渲染整个动画序列", 'RENDER_ANIMATION', 0),
            ('STILL', "单帧", "只渲染当前帧", 'RENDER_STILL', 1),
            ('RANGE', "帧范围", "渲染指定帧范围", 'RENDER_REGION', 2),
        ],
        default='ANIMATION'
    )

    render_frame_start: bpy.props.IntProperty(
        name="开始帧",
        description="渲染开始帧（仅在帧范围模式下有效）",
        default=1,
        min=1
    )

    render_frame_end: bpy.props.IntProperty(
        name="结束帧",
        description="渲染结束帧（仅在帧范围模式下有效）",
        default=250,
        min=1
    )

    # EXR输出格式设置
    exr_color_depth: bpy.props.EnumProperty(
        name="EXR色深",
        description="EXR文件输出的颜色深度设置（不影响数据通道）",
        items=[
            ('16', "Half (16位)", "16位半精度浮点", '', 0),
            ('32', "Full (32位)", "32位全精度浮点", '', 1),
        ],
        default='16'
    )

    exr_color_mode: bpy.props.EnumProperty(
        name="EXR颜色模式",
        description="EXR文件输出的颜色模式设置（不影响数据通道）",
        items=[
            ('RGB', "RGB", "RGB颜色模式（无Alpha通道）", '', 0),
            ('RGBA', "RGBA", "RGBA颜色模式（包含Alpha通道）", '', 1),
        ],
        default='RGBA'
    )

    use_custom_output_directory: BoolProperty(
        name="使用自定义输出目录",
        description="启用后将使用下方指定的自定义目录作为输出根目录，而非默认的 //renders/",
        default=False
    )

    custom_output_directory: StringProperty(
        name="自定义输出目录",
        description="自定义的文件输出根目录路径（建议以 / 或 \\ 结尾）",
        default="",
        subtype='DIR_PATH'
    )

class AOVNameProperties(PropertyGroup):
    """存储AOV名称的属性组"""
    new_name: StringProperty(
        name="新名称",
        description="AOV的新名称",
        default=""
    )
    is_expanded: BoolProperty(
        name="展开",
        description="显示/隐藏位置信息",
        default=False
    )


class AOVStateItem(PropertyGroup):
    """存储单个AOV的状态"""
    name: StringProperty(
        name="AOV名称",
        description="AOV名称",
        default=""
    )
    is_expanded: BoolProperty(
        name="展开",
        description="是否展开显示详细信息",
        default=False
    ) 