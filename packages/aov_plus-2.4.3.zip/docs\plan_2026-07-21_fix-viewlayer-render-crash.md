# 执行计划：修复单层视图层渲染崩溃

> 计划日期：2026-07-21
> 关联崩溃：0718_6.crash.txt
> Blender 版本：5.2.0（Commit fbe6228777e7）

## 1. 问题回顾

### 1.1 当前流程

```
用户选择渲染层节点 → 点击渲染
  → execute()：
    1. 保存所有 view_layer.use 快照
    2. 保存所有 File Output 节点 mute 快照
    3. 设置 view_layer.use：选中的=True，其他的=False   ← 状态改变
    4. 设置 File Output 节点 mute：相关的=False，其他的=True
    5. bpy.ops.render.render()                          ← 崩溃（竞态）
    6. [handler] 渲染完成后恢复所有状态
```

### 1.2 核心矛盾

步骤 3 把不需要的视图层通过 `view_layer.use = False` 从依赖图中移除。步骤 5 立即启动渲染时，Blender 的渲染管线在 `deg_flush_updates_and_refresh` 阶段持有对已移除视图层中 Base 对象的过期引用，`deg_check_base_in_depsgraph` 验证这些引用时拿到空指针（偏移 0x10），触发 `EXCEPTION_ACCESS_VIOLATION`。

### 1.3 崩溃证据

| 项 | 值 |
|------|------|
| 崩溃函数 | `deg_check_base_in_depsgraph` → 空指针解引用 |
| 触发链 | `deg_update_eval_copy_datablock` → `deg_evaluate_on_refresh` → `deg_flush_updates_and_refresh` → `RE_RenderAnim` |
| 复现特征 | 第二次切换单层渲染（11层→1层）后崩溃；非必现，时序敏感 |
| Blender 内部阶段 | 渲染 job 线程构建 depsgraph 时，验证已移除 ViewLayer 的 Base 对象 |

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| 消除崩溃 | P0 | 11 视图层场景反复单层渲染 10 次不崩溃 |
| 不影响现有功能 | P0 | 全 11 层渲染、动画渲染、帧范围渲染均正常 |
| 不增加可感知延迟 | P1 | depsgraph 刷新 <100ms（11 层场景） |

## 3. 设计方案

### 3.1 核心思路

在步骤 3（设置 `view_layer.use`）和步骤 5（启动渲染）之间，**显式触发一次依赖图更新**，让 Blender 在渲染前完成内部状态的清理和重建。

### 3.2 API 选择

查阅 Blender 5.2 Python API 文档后，选择两层防御：

**第一层：`context.view_layer.update()`**

> "Now all dependent data (child objects, modifiers, drivers, etc.) have been recalculated."

官方文档描述其用途为：属性修改后触发依赖数据重新计算。**注意**：`context.view_layer` 只返回当前活动视图层，即 `.update()` 仅刷新 11 个视图层中的 1 个。如果当前活动视图层恰好是被禁用的那个，这行刷新的恰恰是即将不参与渲染的层；如果恰好是保留渲染的那个，至少保证活动层的状态一致性。

保留它的原因是成本极低（<1ms），作为防御性措施无副作用。

**第二层：`context.evaluated_depsgraph_get()`（主力）**

> "This call ensure the dependency graph is fully evaluated. This might be expensive if changes were made to the scene, but is needed to ensure no dangling or incorrect pointers are exposed."

全场景级别的依赖图重建。所有视图层的状态变更（不仅是活动视图层）在这步统一处理。这是修复的核心——它清除已禁用视图层的悬空对象引用，正好对应崩溃根因。

调用本身触发完整评估，无需额外 `.update()` 调用（Depsgraph 对象上没有 `.update()` 方法）。

### 3.3 方案对比

| 方案 | 做法 | 优点 | 缺点 |
|------|------|------|------|
| A：仅 view_layer.update() | `context.view_layer.update()` | 最轻量，<1ms | 仅刷新活动视图层（1/11），其余层不覆盖 |
| B：仅 evaluated_depsgraph_get() | `context.evaluated_depsgraph_get()` | 语义精确匹配"消除悬空指针"，全场景覆盖 | 比 A 重一些 |
| **C：两层防御（选择）** | A + B 组合 | B 覆盖全场景，A 做防御性入口保护 | 2 行代码 |

### 3.4 为什么两层都加

`evaluated_depsgraph_get()` 是主力，它重建整个依赖图并清理悬空引用，直接对应崩溃根因。

`view_layer.update()` 是辅助防御。它确保当前活动视图层的 Python 层数据与内部状态同步（官方文档描述其用途为触发依赖数据重新计算）。对 `.use` 属性变更的具体效果未在文档中明确列出，但这行调用成本极低（<1ms），作为防御性措施保留。

两者的分工：第二层保证全场景的指针清理（必须），第一层保证入口层的状态一致性（锦上添花）。非活动视图层的状态变更由第二层的全场景评估统一处理，不需要每个视图层单独调 `.update()`。

## 4. 详细设计

### 4.1 改动位置

文件：`operators/compositor_operators.py`
类：`COMPOSITOR_OT_render_selected_view_layers`
方法：`execute()`
插入点：第 1295 行（`self.report(...)` 之后、渲染调用之前）

### 4.2 改动代码

```python
# ===== 现有代码（约 1293-1295 行）=====
self.report({'INFO'}, 
           f"开始渲染 {enabled_count} 个视图层（已禁用 {disabled_count} 个）\n"
           f"启用 {enabled_outputs} 个文件输出节点（已禁用 {disabled_outputs} 个）")

# ===== 新增：强制刷新依赖图（2 行）=====
# 第一层（辅助）：刷新当前活动视图层，确保入口状态一致
context.view_layer.update()

# 第二层（主力）：全场景依赖图重建，清除悬空引用
context.evaluated_depsgraph_get()
# ===== 新增结束 =====

# ===== 现有代码继续 =====
if settings.render_mode == 'ANIMATION' or settings.render_mode == 'RANGE':
    bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
else:
    bpy.ops.render.render('INVOKE_DEFAULT')
```

### 4.3 为什么不需要 None 检查

`context.view_layer` 和 `context.evaluated_depsgraph_get()` 在 Operator 的 `execute()` 方法中始终可用。如果 context 异常到连 view_layer 都没有，Blender 自身会在更早的阶段报错——不属于本修复的防御范围。

### 4.4 涉及的文件

| 文件 | 改动类型 | 说明 |
|------|----------|------|
| `operators/compositor_operators.py` | 新增 2 行 | 在 execute() 渲染调用前插入 depsgraph 刷新 |

### 4.5 不需要改动的部分

- `invoke()` 方法：仅做确认对话框，不涉及渲染
- `render_complete_handler` / `render_cancel_handler`：状态恢复逻辑正确
- UI 面板：不涉及
- 其他 Operator：不涉及
- 其他文件：不涉及

## 5. 实现步骤

| 步骤 | 操作 | 输入 | 输出 | 预计时间 |
|------|------|------|------|----------|
| 1 | 在 execute() 中插入 2 行 depsgraph 刷新代码 | compositor_operators.py | 修改后的文件 | 1 分钟 |
| 2 | 代码审查（通过 subagent 派给审查官） | 修改后的 diff | 审查结果 | 5 分钟 |
| 3 | 本地验证 | 11 视图层测试场景 | 测试结果 | 15 分钟 |
| 4 | 回归验证 | 全层/动画/帧范围渲染各 3 次 | 全部通过 | 10 分钟 |

## 6. 测试策略

### 6.1 测试场景

| 场景 | 操作 | 预期结果 |
|------|------|----------|
| 全层渲染 | 11 个视图层全部启用，渲染 | 正常完成，所有视图层渲染 |
| 单层渲染 ×10 | 依次选择不同 Render Layers 节点，每次只渲染 1 个视图层，重复 10 次 | 10 次均无崩溃 |
| 快速切换渲染 | 全层渲染 → 单层渲染 → 另一单层渲染，间隔 <1 秒 | 无崩溃 |
| 动画渲染 | 选择 1 个视图层，渲染模式=动画，渲染 30 帧 | 正常完成，handler 正确恢复状态 |
| 帧范围渲染 | 选择 1 个视图层，渲染模式=帧范围（自定义起止帧） | 正常完成 |
| 无选择渲染 | 不选任何渲染层节点，点击渲染按钮 | 弹出警告提示，不崩溃 |
| 渲染中途取消 | 渲染过程中按 ESC 取消 | render_cancel_handler 正确恢复状态 |
| 连续切换渲染 | 单层渲染 → 等完成 → handler 恢复所有状态 → 立即选另一层渲染，连续 5 次 | 5 次均无崩溃，状态恢复正确 |
| 非合成器上下文 | 在 3D View 中误调用（不应发生，但做兜底） | 正常降级处理或不触发 |

### 6.2 手动测试 checklist

- [ ] 全层渲染正常
- [ ] 单层切换渲染 10 次不崩溃
- [ ] 快速切换渲染不崩溃
- [ ] 动画渲染正常，状态恢复
- [ ] 帧范围渲染正常
- [ ] 渲染取消后状态恢复
- [ ] 连续切换渲染 5 次不崩溃（handler 恢复 + 立即再渲染）
- [ ] 恢复后全层渲染仍正常（验证 handler 没把状态弄乱）

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| 修复不能 100% 消除崩溃（Blender 内部 bug） | 中 | 仍有用户崩溃 | 此修复覆盖已知触发路径。若修复后仍崩，收集新崩溃日志向 Blender 官方报 bug |
| depsgraph 全量评估触发驱动器/修改器重算，导致中间状态可见 | 极低 | 闪烁或数值跳动（瞬态） | 插入点在 report 之后、渲染之前，中间无 UI 刷新。Blender 不会在 operator execute 中途刷新视口 |
| `evaluated_depsgraph_get()` 在大场景中耗时 >100ms | 低 | 渲染启动前多等一瞬间 | depsgraph 增量评估很快，11 层场景预期 <50ms。如确认性能问题可通过 settings 加开关 |
| 现有功能被影响 | 极低 | 全层渲染、动画渲染出问题 | 改动仅 2 行，且只在"渲染选中视图层"路径执行。全层渲染时所有 view_layer.use=True（无禁用），degsgraph 刷新为无操作 |

### 7.1 回退方案

如果修复后出现意外问题，直接回退：移除新增的 2 行代码。改动极小且独立，回退不引入额外风险。

## 8. 参考

- 崩溃报告：`0718_6.crash.txt`
- 源码：`operators/compositor_operators.py` L1250-1355
- Blender 5.2 API 文档：`Python-API-v5.2/bpy.types.Depsgraph.md` — `evaluated_depsgraph_get()` 说明
- Blender 5.2 gotchas：`Python-API-v5.2/info_gotchas_internal_data_and_python_objects.md` — `view_layer.update()` 说明
- 分析文档：`docs/plan_2026-07-21_fix-viewlayer-render-crash.md`（上一版本分析）
- 知识库：`Dev/aov_plus/03-功能详解/合成器输出助手.md`

## 附录：关键 API 文档原文

### A. `context.evaluated_depsgraph_get()`

来源：`Python-API-v5.2/bpy.types.Depsgraph.md`，"Dependency graph: Evaluated ID example" 示例代码注释

```
# NOTE: This call ensure the dependency graph is fully evaluated.
# This might be expensive if changes were made to the scene,
# but is needed to ensure no dangling or incorrect pointers
# are exposed.
depsgraph = context.evaluated_depsgraph_get()
```

### B. `view_layer.update()`

来源：`Python-API-v5.2/info_gotchas_internal_data_and_python_objects.md`，"No updates after setting values" 章节

```
To avoid expensive recalculations every time a property is modified,
Blender defers the evaluation until the results are needed.
However, while the script runs you may want to access the updated values.
In this case you need to call bpy.types.ViewLayer.update after
modifying values, for example:

bpy.context.object.location = 1, 2, 3
bpy.context.view_layer.update()

Now all dependent data (child objects, modifiers, drivers, etc.)
have been recalculated and are available to the script within the
active view layer.
```
