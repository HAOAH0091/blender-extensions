import bpy
from bpy.types import Panel

# 导入 Operator ID，以便在 UI 中引用它们
from ..operators.compositor_operators import (COMPOSITOR_OT_auto_connect_outputs,
                                           COMPOSITOR_OT_auto_rename_outputs,
                                           COMPOSITOR_OT_render_selected_view_layers)

class NODE_PT_auto_rename_settings(Panel):
    """合成器输出助手面板 (重构UI)"""
    bl_label = "合成器输出助手"
    bl_idname = "NODE_PT_auto_rename_settings"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "AOV+"

    @classmethod
    def poll(cls, context):
        # 5.0：场景不再提供 scene.node_tree；改为独立的 CompositorNodeTree 数据块
        try:
            if not context.space_data or context.space_data.tree_type != 'CompositorNodeTree':
                return False
            tree = (
                getattr(context.space_data, 'edit_tree', None) or
                getattr(context.space_data, 'node_tree', None) or
                getattr(context.scene, 'compositing_node_group', None)
            )
            return tree is not None
        except Exception:
            return False

    def draw(self, context):
        layout = self.layout
        # Ensure settings exist before accessing
        if not hasattr(context.scene, 'auto_rename_settings'):
            layout.label(text="无法加载设置", icon='ERROR')
            return 
        settings = context.scene.auto_rename_settings

        # Optional: Overall description
        # layout.label(text="管理文件输出节点的连接与命名", icon='INFO')
        # layout.separator()

        # --- Settings Box ---
        settings_box = layout.box()
        settings_box.label(text="命名与格式设置", icon='TEXT')
        col_settings = settings_box.column(align=True)
        col_settings.prop(settings, "use_scene_prefix")
        col_settings.prop(settings, "use_layer_prefix")
        col_settings.prop(settings, "use_multilayer_exr")
        col_settings.prop(settings, "separate_data_light_outputs")

        # 自定义输出目录
        col_settings.separator()
        col_settings.prop(settings, "use_custom_output_directory")
        if settings.use_custom_output_directory:
            col_settings.prop(settings, "custom_output_directory")

        # EXR格式设置子区域
        col_settings.separator()
        col_settings.label(text="EXR格式设置:", icon='SETTINGS')
        exr_row = col_settings.row(align=True)
        exr_row.prop(settings, "exr_color_depth", text="色深")
        exr_row.prop(settings, "exr_color_mode", text="颜色")

        # --- Auto Connect Box ---
        connect_box = layout.box()
        connect_box.label(text="自动连接输出", icon='AUTOMERGE_ON') # Changed icon
        
        # Destructive mode toggle with tooltip (tooltip comes from property's description)
        row_destructive = connect_box.row()
        row_destructive.prop(settings, "destructive_connect_mode", icon='ERROR') 

        # Auto Connect Button
        connect_box.separator() 
        row_connect_button = connect_box.row()
        row_connect_button.scale_y = 1.5
        row_connect_button.operator(COMPOSITOR_OT_auto_connect_outputs.bl_idname, text="自动连接输出", icon='LINKED') # Changed icon

        # Toggle for Auto Connect Description
        row_desc_toggle_connect = connect_box.row()
        row_desc_toggle_connect.prop(settings, "show_connect_description", icon="TRIA_DOWN" if settings.show_connect_description else "TRIA_RIGHT", icon_only=True, emboss=False)
        row_desc_toggle_connect.label(text="行为说明" if not settings.show_connect_description else "行为说明:") # Adjust label slightly when open

        # Auto Connect Behavior Description Box (Conditional)
        if settings.show_connect_description:
            desc_connect_box = connect_box.box()
            col_connect_desc = desc_connect_box.column(align=True)
            col_connect_desc.label(text="- 默认 (非破坏性): 仅连接未通向文件输出的通道。", icon='CHECKMARK')
            col_connect_desc.label(text="  保留现有连接。")
            col_connect_desc.separator() # Visually separate modes
            col_connect_desc.label(text="- 破坏性模式: 删除所有文件输出节点并重建所有连接。", icon='CANCEL')
            col_connect_desc.separator()
            col_connect_desc.label(text="- 选择 (非破坏性时):", icon='SELECT_SET')
            col_connect_desc.label(text="  - 选中渲染层: 仅处理该节点。")
            col_connect_desc.label(text="  - 选中文件输出: 不执行操作。")
            col_connect_desc.label(text="  - 未选中: 处理所有渲染层。")


        # --- Batch Rename Box ---
        rename_box = layout.box()
        rename_box.label(text="批量重命名输出", icon='FILE_REFRESH')

        # Batch Rename Button
        rename_box.separator() 
        row_rename_button = rename_box.row()
        row_rename_button.scale_y = 1.5
        row_rename_button.operator(COMPOSITOR_OT_auto_rename_outputs.bl_idname, text="应用批量重命名", icon='FILE_REFRESH') 

        # Toggle for Batch Rename Description
        row_desc_toggle_rename = rename_box.row()
        row_desc_toggle_rename.prop(settings, "show_rename_description", icon="TRIA_DOWN" if settings.show_rename_description else "TRIA_RIGHT", icon_only=True, emboss=False)
        row_desc_toggle_rename.label(text="行为说明" if not settings.show_rename_description else "行为说明:")

        # Batch Rename Behavior Description Box (Conditional)
        if settings.show_rename_description:
            desc_rename_box = rename_box.box()
            col_rename_desc = desc_rename_box.column(align=True)
            col_rename_desc.label(text="- 根据设置重命名插槽/层名称并更新基础路径。", icon='SYNTAX_ON')
            col_rename_desc.separator()
            col_rename_desc.label(text="- 选择:", icon='SELECT_SET')
            col_rename_desc.label(text="  - 选中文件输出: 仅处理该节点。")
            col_rename_desc.label(text="  - 未选中: 处理所有文件输出节点。") 

        # --- Render Selected View Layers Box ---
        render_box = layout.box()
        render_box.label(text="渲染选中视图层", icon='RENDER_ANIMATION')

        # Render Mode Selection
        render_box.separator()
        row_mode = render_box.row()
        row_mode.prop(settings, "render_mode", text="模式")
        
        # Frame Range Settings (only show when RANGE mode is selected)
        if settings.render_mode == 'RANGE':
            row_range = render_box.row()
            row_range.prop(settings, "render_frame_start", text="开始")
            row_range.prop(settings, "render_frame_end", text="结束")

        # Render Selected View Layers Button
        render_box.separator() 
        row_render_button = render_box.row()
        row_render_button.scale_y = 1.5
        
        # Dynamic button text and icon based on render mode
        try:
            if settings.render_mode == 'ANIMATION':
                button_text = "渲染动画序列"
                button_icon = 'RENDER_ANIMATION'
            elif settings.render_mode == 'STILL':
                button_text = "渲染当前帧"
                button_icon = 'RENDER_STILL'
            elif settings.render_mode == 'RANGE':
                button_text = "渲染帧范围"
                button_icon = 'RENDER_ANIMATION'  # 使用与动画相同的图标
            else:
                # 默认值，以防万一
                button_text = "渲染选中视图层"
                button_icon = 'RENDER_STILL'
                
            row_render_button.operator(COMPOSITOR_OT_render_selected_view_layers.bl_idname, text=button_text, icon=button_icon)
        except Exception as e:
            # 如果出现任何错误，显示基本按钮
            print(f"AOV+ 渲染按钮显示错误: {e}")
            row_render_button.operator(COMPOSITOR_OT_render_selected_view_layers.bl_idname, text="渲染选中视图层", icon='RENDER_STILL') 

        # Toggle for Render Selected Description
        row_desc_toggle_render = render_box.row()
        row_desc_toggle_render.prop(settings, "show_render_description", icon="TRIA_DOWN" if getattr(settings, "show_render_description", False) else "TRIA_RIGHT", icon_only=True, emboss=False)
        row_desc_toggle_render.label(text="行为说明" if not getattr(settings, "show_render_description", False) else "行为说明:")

        # Render Selected Description Box (Conditional)
        if getattr(settings, "show_render_description", False):
            desc_render_box = render_box.box()
            col_render_desc = desc_render_box.column(align=True)
            col_render_desc.label(text="- 只渲染当前选中的渲染层节点对应的视图层。", icon='CHECKMARK')
            col_render_desc.label(text="- 临时禁用未选中的视图层和无关文件输出。", icon='HIDE_OFF')
            col_render_desc.label(text="- 支持动画序列、单帧、帧范围三种渲染模式。", icon='SCENE_DATA')
            col_render_desc.label(text="- 渲染完成后自动恢复所有状态。", icon='RECOVER_LAST')
            col_render_desc.separator()
            col_render_desc.label(text="- 使用方法:", icon='INFO')
            col_render_desc.label(text="  1. 在合成器中选择要渲染的渲染层节点")
            col_render_desc.label(text="  2. 点击按钮开始渲染")
            col_render_desc.label(text="  3. 渲染完成后视图层状态自动恢复")