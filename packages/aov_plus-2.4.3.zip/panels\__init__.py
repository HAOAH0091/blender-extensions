from .properties_panel import AOV_PT_assistant
from .node_editor_panel import NODE_PT_auto_rename_settings

__all__ = [
    "AOV_PT_assistant",
    "NODE_PT_auto_rename_settings",
] 