import bpy
from bpy.types import Panel
from bpy.props import StringProperty, BoolProperty

class AOV_PT_assistant(Panel):
    """AOV助手面板"""
    bl_label = "AOV 助手"
    bl_idname = "VIEW_LAYER_PT_aov_assistant"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "view_layer"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        box = layout.box()
        row = box.row()
        row.scale_y = 3.0
        row.operator("render.sync_aovs", icon='FILE_REFRESH')

        # --- 添加开始 ---
        # 添加用于控制是否同时赋予连接节点的复选框
        assign_box = layout.box()
        assign_box.prop(scene, "aov_plus_assign_with_connected", text="赋予AOV时连带其连接的节点")
        # --- 添加结束 ---

        try:
            aov_locations_repr = getattr(scene, 'aov_locations', '{}')
            if not isinstance(aov_locations_repr, str) or not aov_locations_repr:
                 aov_locations = {}
            else:
                 aov_locations = eval(aov_locations_repr)

            if not isinstance(aov_locations, dict):
                aov_locations = {} # Reset if eval resulted in wrong type

            if not aov_locations:
                 layout.label(text="未找到AOV。请先添加AOV节点并点击同步。")
                 return

            main_box = layout.box()

            # Sort AOV names for consistent order
            sorted_aov_names = sorted(aov_locations.keys())

            for aov_name in sorted_aov_names:
                locations = aov_locations[aov_name]
                aov_box = main_box.box()
                header_row = aov_box.row(align=True)
                split = header_row.split(factor=0.7)

                name_row = split.row(align=True)

                prop_name = f"temp_aov_name_{aov_name}"
                expand_prop = f"temp_aov_expand_{aov_name}"

                # Use getattr with default to avoid error if property not registered
                is_expanded = getattr(scene, expand_prop, False) # Default to False if not found
                icon = 'TRIA_DOWN' if is_expanded else 'TRIA_RIGHT'

                # Use prop, assuming property *is* registered on Scene type
                # Add try-except block for safety. If not registered, show label instead.
                try:
                    # Check if properties actually exist before trying to use them in UI
                    if hasattr(bpy.types.Scene, expand_prop) and hasattr(bpy.types.Scene, prop_name):
                        name_row.prop(scene, expand_prop, text="", icon=icon, emboss=False)
                        name_row.label(text="AOV:", icon='NODE_MATERIAL')
                        name_row.prop(scene, prop_name, text="")
                    else:
                         # If properties aren't registered, just display the name as a label
                         name_row.label(text=f"AOV: {aov_name}", icon='NODE_MATERIAL')
                         # Add a spacer or similar if needed to maintain alignment
                         name_row.label(text="") # Placeholder for alignment?

                except Exception as e: # Catch broader exceptions during UI drawing for robustness
                    print(f"Error drawing UI elements for AOV {aov_name}: {e}")
                    name_row.label(text=f"UI Error for {aov_name}", icon='ERROR')

                button_row = split.row(align=True)

                rename_op = button_row.operator("render.rename_aov", text="", icon='CHECKMARK')
                rename_op.old_name = aov_name
                # Use getattr with default to avoid error, default to original name
                rename_op.new_name = getattr(scene, prop_name, aov_name)

                assign_op = button_row.operator("render.assign_aov", text="", icon='PLUS')
                assign_op.aov_name = aov_name

                # Use the delete operator which now includes confirmation
                delete_op = button_row.operator("render.delete_aov", text="", icon='X')
                delete_op.aov_name = aov_name

                if getattr(scene, expand_prop, False):
                    info_box = aov_box.box()
                    has_previous_section = False

                    # Materials
                    if locations.get('materials'):
                        info_box.label(text="材质:", icon='MATERIAL')
                        col = info_box.column(align=True)
                        for mat_name in sorted(list(locations['materials'])): # Sort list
                            row = col.row(align=True)
                            sub_row = row.row(align=True)
                            op = sub_row.operator("render.select_material", text=f"  {mat_name}", icon='RIGHTARROW_THIN')
                            op.material_name = mat_name
                            del_op = sub_row.operator("render.delete_material_aov", text="", icon='X')
                            del_op.material_name = mat_name
                            del_op.aov_name = aov_name
                        has_previous_section = True

                    # Objects
                    if locations.get('objects'):
                        if has_previous_section:
                            info_box.separator()
                        info_box.label(text="对象:", icon='OBJECT_DATA')
                        col = info_box.column(align=True)
                        for obj_name in sorted(list(locations['objects'])):
                            row = col.row(align=True)
                            op = row.operator("render.select_object", text=f"  {obj_name}", icon='RIGHTARROW_THIN')
                            op.object_name = obj_name
                        has_previous_section = True

                    # Node Groups
                    if locations.get('material_groups'):
                        if has_previous_section:
                            info_box.separator()
                        info_box.label(text="节点组:", icon='NODETREE')
                        col = info_box.column(align=True)
                        # Sort by material name, then group name
                        for mat_name in sorted(locations['material_groups'].keys()):
                            groups = locations['material_groups'][mat_name]
                            for group_name in sorted(list(groups)):
                                row = col.row(align=True)
                                sub_row = row.row(align=True)
                                op = sub_row.operator("render.select_node_group", text=f"  {mat_name} > {group_name}", icon='RIGHTARROW_THIN')
                                op.material_name = mat_name
                                op.group_name = group_name
                                del_op = sub_row.operator("render.delete_group_aov", text="", icon='X')
                                del_op.material_name = mat_name
                                del_op.group_name = group_name
                                del_op.aov_name = aov_name

                main_box.separator()

        except Exception as e:
             print(f"Error drawing AOV Assistant panel: {str(e)}")
             import traceback
             traceback.print_exc()
             layout.label(text="渲染AOV助手时出错，请检查控制台", icon='ERROR') 