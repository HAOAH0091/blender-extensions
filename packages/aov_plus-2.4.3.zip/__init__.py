import bpy
import importlib
import sys  # <-- Add import for sys

# Check if 'bpy' exists in the local namespace.
# This helps determine if the script is being reloaded versus loaded for the first time.
if "bpy" in locals():
    # --- Pre-unload existing registration (as per spec) ---
    try:
        unregister_old = locals().get("unregister")
        if unregister_old and callable(unregister_old):
            print("Attempting to unregister previous version...")
            unregister_old()
            print("Previous version unregistered.")
        else:
            print("No previous unregister function found or it's not callable.")
    except Exception as e:
        print(f"Error during previous unregister: {e}")
    # --- End Pre-unload ---

    # Define the modules you want to reload here
    local_modules = {
        "properties": locals().get("properties"),
        "operators": locals().get("operators"),
        "panels": locals().get("panels"),
        "ui": locals().get("ui"),
        "handlers": locals().get("handlers"),
    }
    for name, module in local_modules.items():
        if module:
            try:
                importlib.reload(module)
                print(f"Reloaded submodule: {name}")
            except Exception as e:
                print(f"Failed to reload submodule {name}: {e}")

# --- Regular Addon Code Starts Here ---
# IMPORTANT: Import your submodules AFTER the HMR block
from . import properties
from . import operators
from . import panels
from . import ui
from . import handlers

from bpy.types import Operator, PropertyGroup, Panel
from bpy.props import StringProperty, BoolProperty, PointerProperty, CollectionProperty

# --- Import modules ---
# Order matters for dependencies during registration/unregistration
# from . import properties  <-- Moved
# from . import operators   <-- Moved
# from . import panels      <-- Moved
# from . import ui          <-- Moved
# from . import handlers    <-- Moved

bl_info = {
    "name": "AOV+",
    "author": "HAOAH",
    "version": (2, 4, 3),
    "blender": (5, 0, 0),
    "location": "Properties > View Layer > AOV 助手, Node Editor > Sidebar (N) > AOV+",
    "description": "AOV节点管理、输出文件名批处理与选择性渲染工具",
    "category": "Render",
    "doc_url": "",
    "tracker_url": "",
}

# --- Properties to Register ---
addon_properties = [
    (bpy.types.Scene, "aov_locations", StringProperty(default="{}")), # Store AOV location data
    (bpy.types.Scene, "aov_states", CollectionProperty(type=properties.AOVStateItem)), # Store AOV states
    (bpy.types.Scene, "auto_rename_settings", PointerProperty(type=properties.AutoRenameSettings)),
    (bpy.types.Collection, "is_locked_for_isolate", BoolProperty(
        name="Locked for Isolate",
        default=False,
        description="Collection will not be excluded when using isolate function"
    )),
    (bpy.types.Scene, "is_full_isolation_enabled", BoolProperty(
        name="Full Isolation Enabled",
        default=False,
        description="When enabled, newly created collections will be automatically excluded in other view layers"
    )),
    (bpy.types.Scene, "aov_plus_assign_with_connected", BoolProperty(
        name="Assign AOV with Connected Nodes",
        default=False,
        description="When assigning an AOV, also copy its upstream connected nodes"
    )),
]

# --- Temporary Properties (managed by AOV sync) ---
# These are dynamically added/removed in operators/aov_operators.py:AOV_OT_sync_aovs
# and cleaned up in unregister. No explicit registration needed here, but listing for clarity.
# - bpy.types.Scene.temp_aov_name_* : StringProperty
# - bpy.types.Scene.temp_aov_expand_* : BoolProperty

# --- Classes to Register ---
classes = (
    # Properties first
    properties.AOVNameProperties,
    properties.AOVStateItem,
    properties.AutoRenameSettings,
    # Operators
    operators.AOV_OT_sync_aovs,
    operators.AOV_OT_select_material,
    operators.AOV_OT_select_node_group,
    operators.AOV_OT_rename_aov,
    operators.AOV_OT_delete_aov,
    operators.AOV_OT_delete_material_aov,
    operators.AOV_OT_delete_group_aov,
    operators.AOV_OT_assign_aov,
    operators.AOV_OT_select_object,
    operators.OUTLINER_OT_toggle_collection_lock,
    operators.OUTLINER_OT_isolate_collections_do,
    operators.OUTLINER_PT_isolate_collections_ask,
    operators.OUTLINER_OT_isolate_collections,
    operators.OUTLINER_OT_toggle_full_isolation,
    operators.COMPOSITOR_OT_auto_connect_outputs,
    operators.COMPOSITOR_OT_auto_rename_outputs,
    operators.COMPOSITOR_OT_render_selected_view_layers,
    # Panels
    panels.AOV_PT_assistant,
    panels.NODE_PT_auto_rename_settings,
)

# --- Registration ---
def register():
    # Register classes
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError as e:
             print(f"Warning: Class {cls.__name__} already registered? {e}")


    # Register properties
    for owner, prop_name, prop_value in addon_properties:
         if not hasattr(owner, prop_name):
              setattr(owner, prop_name, prop_value)
         # else: # Optional: warn if property exists but is different type?
         #     existing_prop = getattr(owner, prop_name, None)
         #     # Check if existing property type matches (this comparison might be tricky)
         #     # ... comparison logic ...
         #     # if not types_match:
         #     #     print(f"Warning: Property {prop_name} on {owner} exists with potentially different type.")
         #     pass


    # Append UI elements
    try:
         bpy.types.OUTLINER_HT_header.append(ui.draw_outliner_header_buttons)
    except Exception as e:
         print(f"Error appending to Outliner header: {e}")


    # Register handlers
    handlers.register_handlers()


    print("AOV+ registered successfully.")


def unregister():
    print("Unregistering AOV+...")
    # Unregister handlers first
    handlers.unregister_handlers()


    # Remove UI elements
    try:
        bpy.types.OUTLINER_HT_header.remove(ui.draw_outliner_header_buttons)
    except Exception: # Function might already be removed
        pass


    # Unregister classes (in reverse order)
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            # Already unregistered or Blender is shutting down
            # print(f"Info: Could not unregister class {cls.__name__} (might be already unregistered)")
            pass


    # --- Clean up Properties ---
    # Delete addon properties
    for owner, prop_name, _ in addon_properties:
        if hasattr(owner, prop_name):
            try:
                delattr(owner, prop_name)
            except Exception as e:
                print(f"Warning: Could not delete property {prop_name} from {owner}: {e}")


    # --- Clean up sys.modules cache (as per spec) ---
    try:
        prefix = __package__ or __name__
        if prefix: # Ensure prefix is not empty
            modules_to_delete = []
            for module_name in sys.modules:
                 # Check if the module name starts with the package name followed by a dot,
                 # or if it exactly matches the package name (for __init__.py itself)
                if module_name == prefix or module_name.startswith(prefix + '.'):
                    modules_to_delete.append(module_name)

            if modules_to_delete:
                print(f"Cleaning sys.modules cache for prefix '{prefix}': {modules_to_delete}")
                for module_name in modules_to_delete:
                    try:
                        del sys.modules[module_name]
                    except KeyError:
                         print(f"Warning: Module {module_name} already removed from sys.modules?")
                    except Exception as e:
                         print(f"Error removing module {module_name} from sys.modules: {e}")
            else:
                print(f"No modules found in sys.modules with prefix '{prefix}' to clean.")
        else:
             print("Warning: Could not determine package prefix for sys.modules cleanup.")

    except Exception as e:
         print(f"Error during sys.modules cleanup: {e}")
    # --- End sys.modules cleanup ---


    print("AOV+ unregistered.")


# This allows the script to be run directly in Blender Text Editor
# (useful for testing, but standard install uses register/unregister)
# if __name__ == "__main__":
#     register()