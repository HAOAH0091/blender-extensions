# 修复计划：单层视图层渲染崩溃

> 计划日期：2026-07-21
> 关联崩溃报告：0718_6.crash.txt
> Blender 版本：5.2.0（Commit fbe6228777e7）

## 1. 问题回顾

### 当前现状

AOV+ 的"渲染选中视图层"功能（`COMPOSITOR_OT_render_selected_view_layers`）执行流程：

```
用户选择渲染层节点 → 点击渲染
  → execute()：
    1. 保存所有 view_layer.use 快照
    2. 保存所有 File Output 节点 mute 快照
    3. 设置 view_layer.use：选中的=True，其他的=False   ← 关键步骤
    4. 设置 File Output 节点 mute：相关的=False，其他的=True
    5. bpy.ops.render.render()                          ← 崩溃发生在这里
    6. [handler] 渲染完成后恢复所有状态
```

### 核心矛盾

步骤 3 通过 `view_layer.use = False` 将不需要的视图层从 Blender 依赖图（Depsgraph）中移除。步骤 5 紧接着启动渲染时，Blender 的渲染管线在 `deg_flush_updates_and_refresh` 阶段**持有对已移除视图层中 Base 对象的过期引用**，`deg_check_base_in_depsgraph` 尝试验证这些引用时拿到空指针，触发 `EXCEPTION_ACCESS_VIOLATION`。

白话版：跟一个人说"你部门解散了"然后立刻说"现在把部门所有活干完"。对方手里还拿着旧部门的花名册，翻到一页发现是个空名单，系统崩溃。

### 崩溃特征

| 项 | 值 |
|------|------|
| 崩溃函数 | `deg_check_base_in_depsgraph` → 偏移 0x10 空指针解引用 |
| 触发条件 | `view_layer.use = False` 后立即 `bpy.ops.render.render()` |
| 复现概率 | 非必现（时序敏感的竞态条件），多次切换后概率升高 |
| 影响范围 | 使用了"渲染选中视图层"功能的用户，Blender 5.2 |

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| 消除崩溃 | P0 | 在 11 视图层场景中反复切换单层渲染 10 次不崩溃 |
| 不影响原有功能 | P0 | 现有的全部 11 层渲染、动画渲染、帧范围渲染均正常 |
| 不增加渲染延迟 | P1 | depsgraph 刷新时间在 100ms 以内（11 层场景） |

## 3. 设计方案

### 核心思路

在步骤 3（设置 view_layer.use）和步骤 5（启动渲染）之间，**显式触发一次依赖图更新**，让 Blender 在渲染前完成所有内部状态的清理和重建。这相当于"部门解散通知发出后，等 HR 系统更新完花名册再开始干活"。

### 方案对比

| 方案 | 做法 | 优点 | 缺点 |
|------|------|------|------|
| A：场景帧刷新 | `scene.frame_set(scene.frame_current)` | 简单，一行代码 | 可能触发不必要的帧变化回调 |
| B：Depsgraph 显式更新 | `context.evaluated_depsgraph_get().update()` | 语义明确，只更新依赖图 | 需要 context 可用 |
| C：ViewLayer 更新 | `context.view_layer.update()` | 最轻量 | 不确定是否会刷新被禁用视图层的残留引用 |
| **D：多层防御（推荐）** | B + A 组合：先 depsgraph 刷新，再 frame_set | 最大覆盖，防御性最强 | 多一行代码，但都是轻量操作 |

### 选择方案 D 的理由

1. `depsgraph.update()` 语义上是正确的目标：让依赖图完成状态切换
2. `scene.frame_set()` 作为兜底：间接触发更广泛的场景状态同步
3. 两层保护在性能上是可接受的（合计 <100ms，用户感知不到）
4. 不依赖任何实验性 API，兼容 Blender 4.x 到 5.x 全版本

## 4. 详细设计

### 改动位置

文件：`operators/compositor_operators.py`
类：`COMPOSITOR_OT_render_selected_view_layers.execute()`
行号：约 1295 行（`self.report(...)` 之后，渲染调用之前）

### 伪代码

```python
# 现有代码（约 1293-1295 行）
self.report({'INFO'}, 
           f"开始渲染 {enabled_count} 个视图层...")

# ===== 新增：强制刷新依赖图 =====
# 确保 view_layer.use 的状态变更已在依赖图中完全生效
depsgraph = context.evaluated_depsgraph_get()
depsgraph.update()

# 兜底：通过帧设置间接触发场景状态同步
scene.frame_set(scene.frame_current)
# ===== 新增结束 =====

# 现有代码继续
if settings.render_mode == 'ANIMATION' or settings.render_mode == 'RANGE':
    bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
else:
    bpy.ops.render.render('INVOKE_DEFAULT')
```

### 涉及的文件

| 文件 | 改动类型 | 说明 |
|------|----------|------|
| `operators/compositor_operators.py` | 修改 3 行（插入） | 在 execute() 中添加 depsgraph 刷新 |

### 不需要改动的部分

- `invoke()` 方法：仅做确认对话框，不改
- `render_complete_handler` / `render_cancel_handler`：状态恢复逻辑正确，不改
- UI 面板：不改
- 其他 Operator：不改

## 5. 实现步骤

| 步骤 | 操作 | 输入 | 输出 |
|------|------|------|------|
| 1 | 在 execute() 中插入 depsgraph 刷新代码 | 当前源码 | 修改后的 compositor_operators.py |
| 2 | 代码审查 | 修改后的代码 | 审查通过 |
| 3 | 本地验证：创建 11 视图层测试场景，反复单层渲染 10 次 | 测试场景 | 无崩溃 |
| 4 | 回归验证：全层渲染、动画渲染、帧范围渲染各 3 次 | 测试场景 | 全部通过 |

## 6. 测试策略

### 测试场景

| 场景 | 操作 | 预期结果 |
|------|------|----------|
| 全层渲染 | 11 个视图层全部启用，渲染 | 正常完成 |
| 单层渲染 ×10 | 依次选择不同视图层，每次只渲染 1 个，重复 10 次 | 10 次均无崩溃 |
| 动画渲染 | 选择 1 个视图层，渲染模式=动画，渲染 30 帧 | 正常完成，handler 正确恢复状态 |
| 帧范围渲染 | 选择 1 个视图层，渲染模式=帧范围 | 正常完成 |
| 无选择渲染 | 不选任何渲染层节点，点击渲染按钮 | 弹出警告提示，不崩溃 |
| 渲染中途取消 | 渲染过程中按 ESC 取消 | render_cancel_handler 正确恢复状态 |

### 手动测试 checklist

- [ ] 全层渲染正常
- [ ] 单层切换渲染 10 次不崩溃
- [ ] 动画渲染正常
- [ ] 帧范围渲染正常
- [ ] 渲染取消后状态恢复
- [ ] 非合成器场景不触发

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| `context.evaluated_depsgraph_get()` 在某些上下文中返回 None | 低 | 代码报错 | 加 None 检查，失败则跳过 depsgraph 步骤（仍保留 frame_set 兜底） |
| depsgraph.update() 在大场景中耗时过长 | 低 | 渲染体验变慢 | depsgraph 增量更新很快（已被 view_layer.use 变化标记 dirty 的部分），11 层场景预期 <100ms |
| 修复不能 100% 消除崩溃（纯 Blender bug） | 中 | 仍有用户崩溃 | 此修复已覆盖已知触发路径。若修复后仍崩，向 Blender 官方提交 bug report |
| scene.frame_set 触发意料外的回调 | 低 | 其他 handler 异常 | frame_set 本身是 Blender 常用操作，handler 应已处理此场景。AOV+ 自身的 handler 在渲染完成后才注册 |

### 回退方案

如果修复引入新问题，直接回退到当前版本（移除 3 行新增代码），影响范围仅此 3 行。

## 8. 参考

- 崩溃报告：`0718_6.crash.txt`（本会话附件）
- 知识库：`Dev/aov_plus/03-功能详解/合成器输出助手.md` 第 3 节
- Blender 命令行动画参数（depsgraph debug）：`Blender_base/01-手册-v5.2/advanced/command_line/arguments.md`
