import bpy

def is_object_visible_in_viewlayer(obj, view_layer):
    """检查物体在当前视图层中是否可见"""
    if obj.name not in view_layer.objects:
        return False

    for collection in obj.users_collection:
        if collection.name in view_layer.layer_collection.children:
            layer_collection = view_layer.layer_collection.children[collection.name]
            if layer_collection.exclude or not layer_collection.visible_get():
                return False

    return not obj.hide_viewport and not obj.hide_get()

def is_object_renderable(obj, view_layer):
    """检查对象是否可以被渲染"""
    if obj.hide_render:
        return False

    if obj.name not in view_layer.objects:
        return False


    # 检查对象自身及其所属集合的排除和隐藏状态
    for collection in obj.users_collection:
        layer_collection = find_layer_collection_recursive(view_layer.layer_collection, collection)
        if layer_collection:
            # 检查当前集合及其所有父集合的可见性
            current = layer_collection
            while current:
                if current.exclude or current.collection.hide_render:
                    return False
                # 安全地获取父级
                try:
                    # 在较新版本Blender中，直接访问 parent 可能导致无限递归或错误
                    # 尝试使用更稳定的方法获取父级，但 Blender API 可能没有直接提供
                    # 一个间接的方法是检查 parent 属性是否存在且有效
                    if hasattr(current, 'parent') and current.parent:
                        current = current.parent
                        # 防止无限循环（虽然理论上不应发生）
                        if current == layer_collection: break
                    else:
                        break # 到达根集合或无法获取父级
                except Exception:
                    # print(f"Error getting parent for {current.name}")
                    break # 发生错误时中断检查


    return True

def find_layer_collection_recursive(layer_collection, target_collection):
    """递归查找与目标集合关联的层级集合"""
    if layer_collection.collection == target_collection:
        return layer_collection
    for child in layer_collection.children:
        found = find_layer_collection_recursive(child, target_collection)
        if found:
            return found
    return None 