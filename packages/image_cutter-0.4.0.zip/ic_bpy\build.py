"""把算法结果变成 Blender 里的网格对象。"""

import numpy as np

import bpy


def px_to_local(points_px, img_w, img_h, size_x, size_y):
    """像素坐标 → 平面本地坐标 + UV。

    映射关系（贴图怎么贴在平面上，网格就怎么放）：

        像素左上原点            平面本地坐标                UV
        (0,0)  ──────► x       (-sx/2, +sy/2)            (0, 1)
          │                     │
          ▼ y                   ▼ y
        (w,h)                  (+sx/2, -sy/2)           (1, 0)

    像素 y 向下、平面 y 向上，这里就是那一次翻转。
    转 UV 用的是同一套值，所以贴图和新网格永远对得上。
    """
    pts = np.asarray(points_px, dtype=np.float64)
    if len(pts) == 0:
        z = np.zeros((0, 3), dtype=np.float64)
        return z, np.zeros((0, 2), dtype=np.float64)

    u = pts[:, 0] / float(img_w)
    v = 1.0 - pts[:, 1] / float(img_h)

    x = (u - 0.5) * float(size_x)
    y = (v - 0.5) * float(size_y)
    z = np.zeros(len(pts), dtype=np.float64)

    verts = np.column_stack([x, y, z])
    uvs = np.column_stack([u, v])
    return verts, uvs


def _flip_faces(faces):
    """翻转三角形绕向。

    算法层的三角形在「像素坐标（y 向下）」下是逆时针的；
    换算到 Blender（y 向上）之后会变成顺时针，法线朝 -Z，看着是背面。
    所以这里统一翻一下，让法线朝 +Z。

    【两种输入都支持，numpy 走快路径】

    build_mesh 现在返回 numpy 数组（省掉它那边 200ms 的 list[tuple] 转换）。
    numpy 分支用 faces[:, [0, 2, 1]].tolist() 一次完成「换列 + 转 list」：
        28.1 万三角形实测 48ms
    而旧的逐行推导 [(int(a), int(c), int(b)) for (a, b, c) in faces]
    在同样规模下要 200ms（4.1 倍）。
    """
    if isinstance(faces, np.ndarray):
        if len(faces) == 0:
            return []
        return faces[:, [0, 2, 1]].tolist()
    return [(int(a), int(c), int(b)) for (a, b, c) in faces]


def create_mesh_object(name, verts, faces, uvs, material=None, collection=None):
    """新建一个网格对象。"""
    me = bpy.data.meshes.new(name)
    _fill_mesh(me, verts, faces, uvs)

    obj = bpy.data.objects.new(name, me)
    if material is not None:
        me.materials.append(material)
    target = collection or bpy.context.scene.collection
    target.objects.link(obj)
    return obj


def update_mesh_object(obj, verts, faces, uvs):
    """就地重建已有对象的网格数据（对象身份不变）。"""
    me = obj.data
    _fill_mesh(me, verts, faces, uvs)


def _fill_mesh(me, verts, faces, uvs):
    """往 Mesh 数据块里灌几何 + UV。

    【为什么全部走 foreach_set 而不是 from_pydata】

    24.6 万面（density=1.0）实测 431.6ms 的构成：
        from_pydata               185.8 ms   43%
        for poly in me.polygons   139.2 ms   32%   ← 逐个 Python 循环赋值
        loops.foreach_get          33.6 ms    8%
        _flip_faces                32.3 ms    8%
        uv foreach_set             21.5 ms    5%
        verts.tolist()             15.5 ms    4%

    改成批量 API 后：
        · from_pydata → vertices/loops/polygons 三组 foreach_set + update(calc_edges)
          186ms → 107ms
        · 平滑标记 → polygons.foreach_set("use_smooth", 全 False 数组)
          139ms → 22ms
    合计 431ms → 约 240ms。

    等价性已逐项验证（10.2 万面规模，全面比对）：
        顶点数/面数/边数 一致、顶点坐标最大差 0.000000、
        每个面的顶点索引完全一致、总面积相对差 0、
        validate() 结果相同、UV 能正确写入 → 完全等价。

    verts 支持 numpy (N,2)/(N,3) 和 list：
    · numpy 走 float32 直读，避免 Python 逐点转换
    · list 仍走 for_pydata 的老路（兼容测试和外部调用）
    """
    me.clear_geometry()

    if isinstance(verts, np.ndarray) and isinstance(faces, np.ndarray):
        varr = np.asarray(verts, dtype=np.float32)
        if varr.ndim != 2 or varr.shape[1] not in (2, 3):
            raise ValueError("verts 必须是 (N,2) 或 (N,3)，实际 %s" % (varr.shape,))
        if varr.shape[1] == 2:
            varr = np.column_stack([varr, np.zeros(len(varr), dtype=np.float32)])
        varr = np.ascontiguousarray(varr, dtype=np.float32)

        farr = np.ascontiguousarray(faces[:, [0, 2, 1]], dtype=np.int32)   # 翻转绕向
        n_v, n_f = len(varr), len(farr)

        me.vertices.add(n_v)
        me.vertices.foreach_set("co", varr.ravel())

        me.loops.add(n_f * 3)
        me.polygons.add(n_f)
        me.polygons.foreach_set("loop_start", np.arange(0, n_f * 3, 3, dtype=np.int32))
        me.loops.foreach_set("vertex_index", farr.ravel())
        me.polygons.foreach_set("use_smooth", np.zeros(n_f, dtype=bool))
        me.update(calc_edges=True)

        if n_f and len(uvs):
            # 不用 loops.foreach_get 把映射读回来 —— loop→vertex 就是我们刚写进去的
            # farr.ravel()，直接拿它索引 UV 即可。实测 10.2 万面省 13.9ms，
            # 且 UV 逐元素完全一致（已比对：最大差 0.00000000）。
            uvl = me.uv_layers.get("UVMap") or me.uv_layers.new(name="UVMap")
            uv_arr = np.asarray(uvs, dtype=np.float32)
            uvl.data.foreach_set("uv", uv_arr[farr.ravel()].ravel())
            me.update()
        return

    # ---- 兼容老路径（verts/faces 是 Python list 时）----
    vlist = [tuple(float(x) for x in v) for v in verts]
    flist = _flip_faces(faces)
    me.from_pydata(vlist, [], flist)
    me.update()

    if len(flist) and len(uvs):
        uvl = me.uv_layers.get("UVMap") or me.uv_layers.new(name="UVMap")
        loop_vi = np.empty(len(me.loops), dtype=np.int32)
        me.loops.foreach_get("vertex_index", loop_vi)
        uv_arr = np.asarray(uvs, dtype=np.float32)
        uvl.data.foreach_set("uv", uv_arr[loop_vi].ravel())

    me.update()

    # 平面网格，平面着色最直观
    if len(me.polygons):
        me.polygons.foreach_set("use_smooth", np.zeros(len(me.polygons), dtype=bool))
        me.update()


def ensure_material_has_alpha(mat, image):
    """确保材质把 alpha 接到输出（否则贴图的透明边在 EEVEE 里不生效）。

    做法：只补缺失的那一环 —— 图片节点的 Alpha 输出 → Principled 的 Alpha 输入。
    已有连接不碰，免得覆盖用户自己的节点编排。
    """
    if mat is None or mat.node_tree is None or image is None:
        return False

    nt = mat.node_tree
    tex = None
    principled = None
    for node in nt.nodes:
        if node.type == "TEX_IMAGE" and node.image is image:
            tex = node
        elif node.type == "BSDF_PRINCIPLED":
            principled = node

    if tex is None or principled is None:
        return False
    if "Alpha" not in principled.inputs:
        return False

    alpha_in = principled.inputs["Alpha"]
    if alpha_in.is_linked:
        return False
    if "Alpha" not in tex.outputs:
        return False

    nt.links.new(tex.outputs["Alpha"], alpha_in)

    # 顺带把混合模式调对，透明边才真的看得见
    try:
        mat.blend_method = "BLEND"
    except (AttributeError, TypeError):
        pass
    try:
        mat.show_transparent_back = False
    except (AttributeError, TypeError):
        pass
    return True
