"""把各步串成一条流水线，并管住「改一个参数要重算到哪一步」。

【为什么要有缓存边界】

这是整个插件唯一需要认真设计的地方：
「认轮廓」（分割 → 追踪 → 简化 → 平滑）是**慢的**，跟贴图大小成正比；
「铺网格」（撒点 → 三角化）是**快的**，只跟目标密度有关。

如果每拖一下滑块都从头认一遍轮廓，4K 贴图会卡到没法用。
所以缓存按「阶段」切：

    阶段 A（重）：分割 / 追踪 / 简化 / 平滑      键 = 图 + 阈值 + 精度 + 圆滑 + 引导 + 外扩
    阶段 B（轻）：撒点 / 三角化                  键 = 阶段 A 结果 + 网格密度

改网格密度只重跑 B；改阈值才重跑 A。

注意：**阶段 B 没有缓存**（B 快，缓存管理比重算还贵）。
缓存只缓存 A —— 见下面 stage_a_key 的说明。
"""

import collections
import hashlib
import time
from dataclasses import dataclass, field

import numpy as np

from . import mask as mask_mod
from . import outline as outline_mod
from . import simplify as simplify_mod
from . import triangulate as tri_mod
from . import warp as warp_mod


# ==========================================================================
# 【掩膜记忆化 + 增量膨胀 —— 2026-10-21】
#
# 用户的真实工程（3883×1978，expand=656）实测 A 阶段 181ms 的构成：
#     build_mask   25ms   ← 只跟 alpha+阈值有关，与外扩毫无关系
#     edge_style   11ms   ← 同上（而且必须在膨胀前算）
#     dilate      104ms   ← 外扩本身
#     trace        36ms
#     simplify      5ms
# 拖外扩时前两项每格都重算，纯白算 36ms。
#
# 更要紧的是 dilate：**膨胀是可组合的** D_a∘D_b = D_(a+b)（方形结构元是
# 正方的，不存在圆形结构元那种「两次小圆不等于一个大圆」的问题）。
# 实测（真实图，和直接算逐像素完全一致）：
#     在已算好的 mask 上再膨胀 1 步 → 3.9ms   （从头算 101ms，26 倍）
#     再膨胀 2 步 → 5.8ms，4 步 → 9.1ms，8 步 → 16.6ms，16 步 → 32.7ms
#     32 步 → 66.9ms（和从头算的交叉点大约在 40 步）
# 而拖动滑块时原本的 expand 每格只动 1~几像素 —— 正好命中这个区间。
#
# 所以策略：
#   ① build_mask / edge_style 按 (图, 阈值, 引导) 记忆化，外扩不动它们；
#   ② 膨胀结果按 (图, 阈值, 引导, expand) 存一个很小的 LRU；
#   ③ 新 expand 先找缓存里「不超过它、且差距 ≤ _INCR_MAX」的最大档位，
#      在那上面增量膨胀；找不到就老实从头算（行为和以前完全一样）。
#
# 内存：一张 3883×1978 的 bool 掩膜是 7.4MB，膨胀缓存留 6 档 ≈ 45MB，
# 掩膜缓存留 4 项。release_mask_cache() 可以一键清空。
# ==========================================================================

_MASK_MEMO = {}                       # key -> (base_mask, style, ratio, mstats)
_MASK_MEMO_MAX = 4
_CROP_MEMO = collections.OrderedDict()     # (key, margin) -> (sub, off_x, off_y)
_CROP_MEMO_MAX = 3
_DILATE_MEMO = collections.OrderedDict()   # (key, expand) -> (mask, off_x, off_y)
_DILATE_MEMO_MAX = 6
_STYLE_MEMO = {}                      # (img_key, alpha_sig) -> (style, ratio)
_STYLE_MEMO_MAX = 8
_INCR_MAX = 40                        # 增量膨胀的最大步数（实测交叉点 ~40）

# 位图缓存的字节预算。一张 4K 图的 bool 掩膜 7.4MB，padding 过的能到 15MB，
# 所以**光按条数限不住**（6 条 × 15MB = 90MB）。按字节封顶，超了从最久
# 未用的开始丢。用户实际感受不到重算 —— 拖回去时重算一次也就几十毫秒。
_CACHE_BYTES_BUDGET = 110 * 1024 * 1024


def _nbytes_of_val(val):
    """估算一个缓存值占多少字节（值是数组，或数组 + 两个整数的元组）。"""
    n = 0
    if isinstance(val, tuple):
        for x in val:
            n += getattr(x, "nbytes", 0)
    else:
        n = getattr(val, "nbytes", 0)
    return n


def _trim_memo(memo, max_len):
    """按条数淘汰（OrderedDict，oldest first）。字节预算见 _trim_all。"""
    while len(memo) > max_len:
        memo.popitem(last=False)


def _trim_all():
    """全局字节预算：三张位图缓存加起来不超过 _CACHE_BYTES_BUDGET。

    【为什么必须是全局而不是各自限】
    早先给 _CROP_MEMO 和 _DILATE_MEMO 各留 110MB 预算 —— 那是两份，
    最坏 220MB，比不设还糟。而且 _MASK_MEMO 当时根本没做淘汰（普通 dict，
    只按条数 pop 最早插入的那个，从不清字节），等于漏了。

    现在统一：先按条数各自淘汰，再看总字节，超了从最久未用的一张开始丢。
    """
    _trim_memo(_CROP_MEMO, _CROP_MEMO_MAX)
    _trim_memo(_DILATE_MEMO, _DILATE_MEMO_MAX)
    while len(_STYLE_MEMO) > _STYLE_MEMO_MAX:
        _STYLE_MEMO.pop(next(iter(_STYLE_MEMO)))
    while len(_MASK_MEMO) > _MASK_MEMO_MAX:
        _MASK_MEMO.pop(next(iter(_MASK_MEMO)))

    while mask_cache_footprint() > _CACHE_BYTES_BUDGET:
        if len(_DILATE_MEMO) > 1:
            _DILATE_MEMO.popitem(last=False)
        elif len(_CROP_MEMO) > 1:
            _CROP_MEMO.popitem(last=False)
        elif len(_MASK_MEMO) > 1:
            _MASK_MEMO.pop(next(iter(_MASK_MEMO)))
        else:
            break


def _alpha_sig(alpha):
    """alpha 的轻量指纹 —— 缓存键必须自己认得出「这是哪张图」。

    【为什么必须有它 —— 2026-10-21 踩到的真 bug】
    原先 key = (img_key, 阈值, 引导)。而 img_key 是个默认参数 "img"，
    调用方忘了传就全都撞成一个键。测试里连续用不同图调 run_stage_a，
    第二次起直接拿到**上一张图**的掩膜，结果覆盖率掉到 34%，
    表现是「形状莫名其妙少了一大块」。

    这跟代码库里那条规矩一致：缓存键是这套缓存的自洽契约，
    不能只靠调用点传对参数（调用点漏一次就退化成串用缓存）。

    抽样 4096 个点 + 形状 + dtype 就够区分了，成本约 1ms（全量 hash 要几十 ms）。
    """
    a = np.asarray(alpha)
    flat = a.ravel()
    step = max(1, flat.size // 4096)
    s = flat[::step]
    try:
        sig = float(np.nansum(s)) * 1000.0
    except Exception:
        sig = float("nan")
    return (tuple(a.shape), str(a.dtype), int(flat.size), round(sig, 3))


def _guide_sig(guide_mask):
    """引导掩膜的轻量指纹。全量 hash 一张 7MB 图太贵，抽样即可。"""
    if guide_mask is None:
        return None
    try:
        flat = np.asarray(guide_mask).ravel()
        step = max(1, flat.size // 4096)
        return (flat.shape, int(flat.size), int(flat[::step].sum()))
    except Exception:
        return ("obj", id(guide_mask))


def release_mask_cache(img_key=None):
    """清记忆化缓存。img_key=None 时全清（对象/图片被删时调）。"""
    if img_key is None:
        _MASK_MEMO.clear()
        _CROP_MEMO.clear()
        _DILATE_MEMO.clear()
        _STYLE_MEMO.clear()
        tri_mod.clear_ring_grid_cache()
        return
    for memo in (_MASK_MEMO, _CROP_MEMO, _DILATE_MEMO):
        for k in list(memo):
            # _MASK_MEMO 的键是 (img_key, ...)；
            # _CROP_MEMO / _DILATE_MEMO 的键是 (mkey, ...)，而 mkey 本身是
            # _get_base_mask 返回的元组 (img_key, ...)。两种层级都要认。
            owner = k[0][0] if isinstance(k[0], tuple) else k[0]
            if owner == img_key:
                memo.pop(k, None)
    for k in list(_STYLE_MEMO):
        if k[0] == img_key:
            _STYLE_MEMO.pop(k, None)
    # 线段空间哈希只保留最近一份轮廓；释放图片缓存时一起丢掉，
    # 避免用户删掉对象后还留着一套环数组。
    tri_mod.clear_ring_grid_cache()


def mask_cache_footprint():
    """当前缓存占用（字节，粗估）。给面板报账用。"""
    n = 0
    for base, _s, _r, _m in _MASK_MEMO.values():
        n += getattr(base, "nbytes", 0)
    for sub, _x, _y in _CROP_MEMO.values():
        n += getattr(sub, "nbytes", 0)
    for mk, _x, _y in _DILATE_MEMO.values():
        n += getattr(mk, "nbytes", 0)
    return n


def _get_base_mask(alpha, threshold, guide_mask, guide_mode, img_key,
                   assume_unit=False):
    """build_mask + edge_style + apply_guide 的结果，按图记忆化。"""
    key = (img_key, _alpha_sig(alpha), round(float(threshold), 4),
           guide_mode, _guide_sig(guide_mask), bool(assume_unit))
    hit = _MASK_MEMO.get(key)
    if hit is not None:
        return key, hit
    m, mstats = mask_mod.build_mask(alpha, threshold, assume_unit=assume_unit)
    # 软硬边必须在膨胀之前判：外扩会把边界推出形状，那圈像素 alpha 接近 0，
    # 拿它统计会把任何图都判成硬边（这是真踩过的 bug）。
    # 软硬边由 alpha 的过渡区决定，与 threshold 的具体数值无关；
    # 4K 图上 edge_style 一次约 35ms，拖阈值时没必要反复算。
    skey = (img_key, _alpha_sig(alpha))
    style_hit = _STYLE_MEMO.get(skey)
    if style_hit is None:
        style, ratio = mask_mod.edge_style(alpha, m)
        _STYLE_MEMO[skey] = (style, ratio)
        _trim_all()
    else:
        style, ratio = style_hit
    if guide_mask is not None:
        m = mask_mod.apply_guide(m, guide_mask, guide_mode)
    # 只改不重建：apply_guide 可能返回新数组，缓存里存它自己就够
    val = (m, style, ratio, mstats)
    _MASK_MEMO[key] = val
    _trim_all()
    return key, val


# 「边缘外扩」滑块的物理上限 = 长边 × 这个比例（但不小于 64）。
# ⚠️ 这里和 props.expand_limit 必须是**同一个真相源** —— 早先 UI 里写死一份、
#    Params 默认值写死另一份，导致「UI 生成」和「API 生成」结果不一致，
#    排查起来像见鬼。现在 props 直接调这个函数。
EXPAND_RATIO = 0.20
EXPAND_MIN_LIMIT = 64


def expand_limit(img_long=0):
    """外扩滑块的上限（像素）。img_long = 图片长边。"""
    if not img_long or img_long <= 0:
        return EXPAND_MIN_LIMIT
    return max(EXPAND_MIN_LIMIT, int(round(float(img_long) * EXPAND_RATIO)))


def _expand_limit_for(shape):
    """按掩膜形状（H, W）算外扩上限。"""
    try:
        return expand_limit(max(shape))
    except Exception:
        return EXPAND_MIN_LIMIT


def _content_bbox(mask):
    """内容 bbox（x1/y1 是 exclusive）。全空返回 None。"""
    rows = np.asarray(mask).any(axis=1)
    if not rows.any():
        return None
    cols = np.asarray(mask).any(axis=0)
    y0 = int(np.argmax(rows))
    y1 = int(len(rows) - np.argmax(rows[::-1]))
    x0 = int(np.argmax(cols))
    x1 = int(len(cols) - np.argmax(cols[::-1]))
    return x0, y0, x1, y1


def _crop_and_pad(base_mask, margin):
    """裁到内容 bbox，四周再留 margin 个**空像素**。返回 (子图, off_x, off_y)。

    这是整条流水线里性价比最高的一步，两个理由：

    ① **原图大量像素是纯空白**。用户那张 3883×1978 的图，内容 bbox 只有
       x[1288,3882] y[0,1977]：左边 1288 列、整块 100% 空。不裁的话，
       后面 dilate / trace 每一步都在为这片空白付钱。

    ② **固定 margin 让增量膨胀重新可用**。上一版按 max(0, expand-距离)
       逐档补 padding，画布尺寸随 expand 变 → 坐标系每档都不一样 →
       上一档的膨胀结果没法复用（增量膨胀直接失效）。
       这里改成 margin 取**滑块上限**（每张图固定），画布尺寸就固定了，
       拖动时可以在上一档结果上累加（实测每格 4~17ms vs 从头 65ms）。

    margin=0 时就是纯裁剪（expand=0 用这个，实测 trace 42ms → 28ms）。
    若内容本来就撑满全图，裁剪是空操作，行为与以前完全一致。
    """
    bbox = _content_bbox(base_mask)
    if bbox is None:
        return None, 0, 0
    x0, y0, x1, y1 = bbox
    H, W = base_mask.shape
    m = max(0, int(margin))

    # 子图 = 内容 bbox 再各边扩 m，扩出去的部分落在原图外的用空像素填
    vw = (x1 - x0) + 2 * m
    vh = (y1 - y0) + 2 * m
    sub = np.zeros((vh, vw), dtype=bool)

    src_x0 = max(0, x0 - m)
    src_x1 = min(W, x1 + m)
    src_y0 = max(0, y0 - m)
    src_y1 = min(H, y1 + m)
    sub[src_y0 - (y0 - m): src_y1 - (y0 - m),
        src_x0 - (x0 - m): src_x1 - (x0 - m)] = base_mask[src_y0:src_y1, src_x0:src_x1]
    return sub, (x0 - m), (y0 - m)


_MARGIN_STEP = 64


def _margin_bucket(expand, margin_limit=None):
    """把 margin 量化到 64 的整数倍。

    【为什么不是直接取 expand —— 这里有个两头拉扯】
    画布越大，dilate 和 trace 越慢；画布尺寸一变，上一档的膨胀结果就
    没法增量复用（坐标系不同）。所以：

        取 margin = expand      画布最小，但每一档尺寸都不同 → 增量全废
        取 margin = 滑块上限     尺寸固定 → 增量可用，但小 expand 也在为大画布付钱
                                （实测 expand=8 时 trace 30ms → 85ms）

    量化到 64 的桶是折中：同一个桶内尺寸固定（增量可用），
    且画布只比实际需要大不到 64px。实测这版连续拖动 0→200 平均 82ms/步。

    另外 margin >= expand 是**正确性要求**：只有留够 expand 的空白，
    膨胀才不会被画布边缘切掉，轮廓才能长到原图外面。
    """
    step = _MARGIN_STEP
    m = (int(expand) + step - 1) // step * step
    if margin_limit:
        m = min(m, max(step, int(margin_limit) + step))   # 别超过滑块上限太多
    return max(step, m)


def _canvas(key, base_mask, margin):
    """裁剪好的画布 (sub, ox, oy)，按 (图, margin) 缓存。

    缓存它有两个原因：① 算 bbox 要扫两遍全图（7.7M 像素约 3ms），
    每拖一格都扫一次纯浪费；② 增量膨胀必须确认「画布形状没变」，
    而固定 margin 下形状只取决于内容 bbox，算一次就够。
    """
    ck = (key, margin)
    hit = _CROP_MEMO.get(ck)
    if hit is not None:
        _CROP_MEMO.pop(ck, None)
        _CROP_MEMO[ck] = hit
        return hit
    sub, ox, oy = _crop_and_pad(base_mask, margin)
    _CROP_MEMO[ck] = (sub, ox, oy)
    _trim_all()
    return (sub, ox, oy)


def _get_dilated(key, base_mask, expand, margin_limit=None):
    """→ (掩膜, off_x, off_y)。坐标减 (off_x, off_y) 才是原图坐标。

    - expand=0：只裁剪不膨胀（trace 42ms → 28ms）
    - expand>0：裁剪 + 固定 margin 补齐 + 膨胀，轮廓可以长到原图外面
    - 能增量就增量（D_a∘D_b = D_(a+b)，逐像素一致，实测过）

    margin_limit 传滑块上限，让同一张图在所有档位用同一个画布尺寸 ——
    这是增量能生效的前提（尺寸一变，上一档结果就用不了）。
    """
    expand = int(expand)
    ck = (key, expand)
    hit = _DILATE_MEMO.get(ck)
    if hit is not None:
        _DILATE_MEMO.pop(ck, None)
        _DILATE_MEMO[ck] = hit            # 挪到最近使用
        return hit

    margin = 0 if expand <= 0 else _margin_bucket(expand, margin_limit)
    sub, ox, oy = _canvas(key, base_mask, margin)
    if sub is None:                       # 全空图
        return (base_mask, 0, 0)

    if expand <= 0:
        out = (sub, ox, oy)
    else:
        # 找同画布的上一档累加（省掉重复的全量膨胀）
        best_e, best_m = 0, None
        for (k, e), mk in _DILATE_MEMO.items():
            if k != key or e <= 0 or e > expand or e <= best_e:
                continue
            if mk[0].shape != sub.shape:
                continue
            best_e, best_m = e, mk
        if best_m is not None and (expand - best_e) <= _INCR_MAX:
            out = (mask_mod.dilate_mask(best_m[0], expand - best_e), ox, oy)
        else:
            out = (mask_mod.dilate_mask(sub, expand), ox, oy)

    _DILATE_MEMO[ck] = out
    _trim_all()
    return out


@dataclass
class Params:
    """全部可调参数。单位都是**像素**（贴图自己的像素）。"""

    threshold: float = 0.5      # alpha 超过它算实心
    tolerance: float = 4.05     # 轮廓容差：越大顶点越少、边越直（与面板隐藏默认值一致）
    # 边缘外扩像素。**必须和 UI 默认值保持一致**（props.IC_Settings.expand = 0）。
    # 早先这里写 2、UI 写 0，于是同一张图走 UI 和走 API 会得到不同的环数
    # （1px 细缝在 expand=2 时被合上、expand=0 时保留），排查时极易误判成 bug。
    expand: int = 0
    # 【2026-10-21 移除 smooth（拐角圆滑）字段】
    #
    # 真实图（3883×1978 软边）实测各档效果几乎为零：
    #     smooth  环点数  面数    覆盖率    面积变化   A 阶段耗时
    #     0        1481   44238  99.82%   +0.00%     177.9 ms
    #     2        1478   44125  99.81%   -0.04%     196.2 ms
    #     4        1477   44149  99.80%   -0.07%     221.1 ms
    #     12       1477   44204  99.72%   -0.15%     318.8 ms
    # 环点数差 0.3%、覆盖率差 0.1%、面积差 0.15% —— 用户拖滑块看不出任何变化，
    # 但拖到 12 要多花 141 ms 重算 A 阶段。
    #
    # 换格子网格之后它就更没意义了：边缘形状由「格点吸附到 densify 后的轮廓」决定，
    # 原始环点被平滑掉多少已经不主导最终外观。
    #
    # 硬边图本来就跳过平滑（磨圆等于把像素画设计磨掉）。
    # 所以固定为「不平滑」，不再对外暴露。
    # 网格目标边长：越小越密。
    #
    # ⚠️ 15.29 是「图片长边 ≤ 192px」时 UI 密度 0.55 的换算值，也是无图尺寸
    #    信息时唯一能用的保守回退。UI 的 spacing 会随 stat_img_long 缩放
    #    （见 spacing_from_density），所以脚本/测试若要和 UI 完全一致，应显式传
    #    spacing=spacing_from_density(0.55, image_long_side=...)。
    spacing: float = 15.29
    # 闭合路径圈内：add 补实心 / carve 挖空。
    # guide_enabled 必须与 UI 默认一致（props.IC_Settings.guide_enabled = True）——
    # 早先这里是 False、UI 是 True，于是「名字都叫 Params()」，测试/API 走「引导关」、
    # UI 走「引导开」，同一个名字两种行为，排查时会怀疑人生。
    guide_enabled: bool = True   # 引导是否参与计算（也要与 UI 默认 True 一致）
    guide_mode: str = "add"
    def stage_a_key(self, img_key, guide_ver=0):
        """阶段 A 的缓存键。

        引导**没启用**时，guide_ver 对结果没有任何影响（guide_mask 恒为 None），
        所以不能让它进键 —— 否则「引导关着、改个别的参数」也会判成缓存失效，
        白白重算一遍轮廓。4K 图上这就是几百毫秒的无谓卡顿。

        判定放在这里而不是调用点：键是这套缓存的自洽契约，
        调用点漏判一次就退回旧行为（真踩过 —— 调用点改了、这里没改，测试立刻红）。
        """
        # guide_mode 只在**真的有引导路径**时才影响结果：
        #   引导关着 → build_guide_mask 返回 None，mode 无意义
        #   引导开着但一条没画 → 同样返回 None
        # 早先 guide_mode 无条件进键，导致「引导关着时切一下模式」
        # 也会让 4K 图的阶段 A 白重算一次（实测 230~250ms）。
        # guide_mode / guide_ver 都只在**真的画了路径**时才影响结果：
        #   引导关着 → build_guide_mask 返回 None，两个字段都无意义
        #   引导开着但一条没画 → 同样返回 None
        #
        # 早先只修了 mode、漏了 ver：`guide_part = str(guide_ver) if self.guide_enabled else "-"`
        # 于是「用户只是切一下『启用引导』开关、一条路径没画」→ 键变了
        # （实测 a33f86a5… vs e347274b…）→ A 阶段白重算一遍。
        #
        # 判据统一成「有引导路径才算」：guide_ver > 0 且 guide_enabled。
        # 调用方 ops.rebuild_object 传的 guide_sig 已经是 `guide_ver if has_strokes else 0`，
        # 这里再做一次自洽判断（键是缓存契约，不能只靠调用点）。
        has_guide = bool(self.guide_enabled) and guide_ver > 0
        mode_part = self.guide_mode if has_guide else "-"
        guide_part = str(guide_ver) if has_guide else "-"
        raw = "|".join([
            str(img_key), guide_part,
            "%.4f" % self.threshold, "%.4f" % self.tolerance,
            str(int(self.expand)), mode_part,
        ])
        return hashlib.md5(raw.encode("utf-8")).hexdigest()[:16]

    # 【为什么不给阶段 B 做缓存 —— 删掉了 stage_b_key】
    #
    # 早先这里有个 stage_b_key(spacing)，但全代码库没有任何地方调用它：
    # B 阶段（撒点 + 三角化）每次 rebuild 都无条件重跑。看着像"漏了缓存"，
    # 实测后确认这是对的，不是遗漏：
    #
    #   阶段 B 现在的耗时（走 mathutils C 实现后）：
    #     1024/0.55 → 6ms    1024/1.0 → 183ms
    #     2048/1.0  → 757ms   4096/1.0 → 2084ms
    #   而 A 阶段是 15~250ms。
    #
    # 也就是说 B 只在「4K + 密度拉满」时才值得缓存，其余情况缓存管理
    # （存 mesh 数据、判失效、占内存）的成本比重算还高。
    # 而真到 4K/1.0 那个量级，用户更该做的是调小密度 ——
    # 面板上已经有面数预估，能提前看到代价。
    #
    # 结论：这个函数是死代码，删掉。哪天 B 阶段真的变慢了（比如加了新的
    # 后处理步骤），再回来做缓存，届时用「A 的指纹 + spacing」做键即可。


@dataclass
class StageA:
    """慢阶段的产物：几何轮廓。"""

    rings: list = field(default_factory=list)      # 外环（洞已丢弃）
    inner_count: int = 0
    raw_ring_count: int = 0
    solid: int = 0
    empty: int = 0
    edge_style: str = "hard"
    edge_ratio: float = 0.0
    ms: dict = field(default_factory=dict)
    # 轮廓几何统计。阶段 B 在拖密度时频繁重跑，但轮廓本身没变；
    # 每次都重新扫一遍全部环只为更新面板数字是纯浪费。
    area_px: float = 0.0
    perimeter_px: float = 0.0
    dominant: float = 0.0
    # >1 表示这是拖动参数时的降采样轮廓，只用于中间预览；
    # 停手后的精确阶段 A 会恢复为 1。
    preview_factor: int = 1
    # 手绘引导里「挖掉」的区域（原图尺寸 bool，True = 要剔除）。
    #
    # split_outer 为了「中心不留洞」会丢掉所有内环；如果用户画了一个
    # 完全位于形状内部的闭合 carve，这个洞也会被丢掉，结果就是 carve
    # 完全没效果。阶段 B 用这张掩膜把洞里的三角形再剔一次。
    # 它只包含引导的负值区域，不包含源图本身的洞 —— 源图洞仍按产品约定填实。
    carve_mask: object = None


def ring_metrics(rings):
    """外环的面积、周长和最大环占比。

    返回值供面板显示和面数预估使用。向量化按环计算；空输入返回全零。
    """
    area_px = 0.0
    biggest = 0.0
    perimeter_px = 0.0
    for ring in rings:
        pts = np.asarray(ring, dtype=np.float64)
        if len(pts) < 3:
            continue
        x = pts[:, 0]
        y = pts[:, 1]
        area = 0.5 * abs(float(np.dot(x, np.roll(y, -1))
                              - np.dot(y, np.roll(x, -1))))
        area_px += area
        if area > biggest:
            biggest = area
        dx = np.diff(np.append(x, x[0]))
        dy = np.diff(np.append(y, y[0]))
        perimeter_px += float(np.hypot(dx, dy).sum())
    dominant = (biggest / area_px) if area_px > 1e-9 else 0.0
    return {
        "area": area_px,
        "perimeter": perimeter_px,
        "dominant": dominant,
    }


def run_stage_a(alpha, params, guide_mask=None, img_key="img",
                alpha_is_unit=False):
    """分割 → 追踪 → 丢洞 → 简化。慢，结果该被缓存。"""
    t0 = time.perf_counter()

    # 分割 + 判软硬边 + 引导 —— 只跟贴图/阈值有关，拖外扩时不该重算（省 36ms）
    mkey, (m_base, style, ratio, mstats) = _get_base_mask(
        alpha, params.threshold, guide_mask, params.guide_mode, img_key,
        assume_unit=alpha_is_unit)
    t_mask = time.perf_counter()

    # 引导的 -1 区域是「要挖掉」：开放路径沿线挖，闭合路径圈内挖。
    # 单独留一张全图坐标的掩膜给阶段 B，因为 rings 里的洞会被 split_outer
    # 丢掉，单靠 rings 没法把这个洞重新表达出来。
    carve_mask = None
    # solid_only 明确承诺「绝不挖掉自动结果」：即使调用方传了 -1，
    # apply_guide 也会忽略；阶段 B 的洞过滤必须遵守同一语义。
    if guide_mask is not None and params.guide_mode != "solid_only":
        try:
            gm = np.asarray(guide_mask)
            if gm.shape == np.asarray(alpha).shape:
                neg = gm < 0
                carve_mask = neg if bool(neg.any()) else None
        except Exception:
            carve_mask = None

    # 裁到内容 bbox + 固定 margin 补齐 + 膨胀。
    # margin 用滑块上限（每张图固定），画布尺寸才不会随 expand 变 —— 这是
    # 增量膨胀能复用的前提。内容贴边时轮廓会长到原图外面去（AE 同款行为）。
    m, off_x, off_y = _get_dilated(
        mkey, m_base, params.expand, margin_limit=_expand_limit_for(m_base.shape))

    rings = outline_mod.trace_rings(m)
    if off_x or off_y:
        # off 是「子图左上角在原图里的坐标」，恢复要**加**回去。
        # （第一版写成减，结果整张轮廓平移了 1288px —— bbox 从 x[1288,3882]
        #   变成 x[-1288,1307]，看着像个正常数字，其实整体错位。）
        # 加回来之后坐标可能是负数 / 超过 W-1，那正是「轮廓跑到原图外」，
        # 下游按平面本地坐标线性映射，不依赖坐标必须落在 [0, W-1]。
        rings = [[(x + off_x, y + off_y) for (x, y) in r] for r in rings]
    outer, inner = outline_mod.split_outer(rings)
    t_trace = time.perf_counter()
    # 2026-10-21：smooth 已移除，不再平滑。
    # 真实图上它各档效果 <0.3%（见 Params 里那段实测），白花 18~141ms。
    smooth_iters = 0

    tolerance = max(0.05, float(params.tolerance))
    trimmed = []
    for r in outer:
        if len(r) < 4:
            continue

        # 【顺序：先在密环上平滑、再抽稀 —— 这是唯一不破坏覆盖的做法】
        #
        # 我在这块先后错了三次，每次都"看着有理"：
        #
        # ── 错法一：先平滑再抽稀，但用老的固定 0.25/0.5/0.25 滑动平均 ──
        # 覆盖 100% 没问题，但平滑**完全无效**（转折角 57.10°→57.16°）：
        # 1 像素邻域对几十像素的点距毫无影响，用户拖滑块看不出变化。
        #
        # ── 错法二：改成「先抽稀、再在稀疏点上平滑、再抽稀」──
        # 平滑是有效了（转折角降到 15°），但**把实心区吃掉了**：
        # 抽稀后一圈只剩 77 点，Laplacian 把点拉向两个邻居的中点，
        # 位移动辄上百像素（实测 smooth=2 中位位移 156px、最大 911px）。
        # 点是还在实心区内（逐点校验能过），但**连成的边横穿了透明区**，
        # 那一大片实心区就没面了。
        # 实测最终网格对实心区的覆盖：
        #     smooth=0 → 99.89%      （正常）
        #     smooth=2 → 83.90%      ← 用户报的"没透明的地方也被抠掉"
        #     smooth=8 → 74.74%
        #
        # ── 现在：在密环上平滑，逐点约束必须在实心区内 ──
        # 密环的点距只有 1~2px，Laplacian 的位移天然很小，不会横穿缺口；
        # 再叠上 mask 逐点校验（跑出去就退回原位），覆盖就稳住了。
        # 实测（真实人物图）：
        #     iters=0 → 99.95%    iters=4 → 99.92%
        #     iters=12 → 99.79%   iters=24 → 99.72%
        # 代价是平滑力度比"稀疏点上猛拉"弱：锯齿圆转折角 43.97°→39.7°。
        # 这是正确的取舍 —— 宁可磨得慢一点，也不能吃掉实心区。
        if smooth_iters > 0:
            r = warp_mod.smooth_ring(r, smooth_iters, mask=m)
        trimmed.append(r)

    # 同点数的环会合并成一次批量 DP。逐环调用在像素画/图标集这类
    # 「上百个中等环」的素材上会让 numpy 的固定调用开销占主导。
    simplified = simplify_mod.simplify_rings(trimmed, tolerance)
    out = [s for s in simplified if len(s) >= 3]
    metrics = ring_metrics(out)
    t_fin = time.perf_counter()

    return StageA(
        rings=out,
        inner_count=len(inner),
        raw_ring_count=len(rings),
        solid=mstats["solid"],
        empty=mstats["empty"],
        edge_style=style,
        edge_ratio=ratio,
        area_px=metrics["area"],
        perimeter_px=metrics["perimeter"],
        dominant=metrics["dominant"],
        # 只用引导的负值区域做洞过滤；源图洞仍按约定填实。
        carve_mask=carve_mask,
        ms={
            "mask": round((t_mask - t0) * 1000, 1),
            "trace": round((t_trace - t_mask) * 1000, 1),
            "simplify": round((t_fin - t_trace) * 1000, 1),
            "stage_a": round((t_fin - t0) * 1000, 1),
        },
    )


def _downsample_alpha_block(alpha, factor):
    """隔点降采样，供拖动参数时的粗轮廓预览使用。

    这里刻意不做均值/最大值池化：4K/3 倍下池化要 60ms，和阶段 A 本体
    差不多；隔点采样约 3ms。细发丝在粗预览里可能少一根，但停手后的
    精确重建会完整恢复，换来的是拖动期间真正能持续出图。
    """
    a = np.asarray(alpha, dtype=np.float32)
    factor = max(1, int(factor))
    if factor == 1:
        return a
    return a[::factor, ::factor].copy()


def run_stage_a_preview(alpha, params, guide_mask=None, img_key="img", factor=2):
    """拖动 threshold / expand 时的降采样阶段 A。

    只求几十毫秒内给出一张形状接近的粗轮廓，不写回精确缓存。
    返回的环坐标已映射回原图像素坐标，阶段 B 可以直接使用。
    """
    factor = max(1, int(factor))
    if factor <= 1:
        return run_stage_a(alpha, params, guide_mask, img_key,
                           alpha_is_unit=True)

    a_small = _downsample_alpha_block(alpha, factor)
    h, w = np.asarray(alpha).shape
    sh, sw = a_small.shape
    p_small = Params(
        threshold=float(params.threshold),
        tolerance=max(0.05, float(params.tolerance) / factor),
        expand=max(0, int(round(float(params.expand) / factor))),
        spacing=max(2.0, float(params.spacing) / factor),
        guide_enabled=bool(params.guide_enabled),
        guide_mode=params.guide_mode,
    )
    sa = run_stage_a(
        a_small, p_small, guide_mask,
        "%s|preview:%d:%dx%d" % (img_key, factor, sw, sh),
        alpha_is_unit=True,
    )

    offset = (factor - 1) * 0.5
    rings = [
        np.asarray(r, dtype=np.float64) * factor + offset
        for r in sa.rings
    ]
    metrics = ring_metrics(rings)

    carve_mask = None
    if getattr(sa, "carve_mask", None) is not None:
        try:
            small_carve = np.asarray(sa.carve_mask, dtype=bool)
            carve_mask = np.repeat(
                np.repeat(small_carve, factor, axis=0), factor, axis=1
            )[:h, :w]
        except Exception:                               # noqa: BLE001
            carve_mask = None

    return StageA(
        rings=rings,
        inner_count=int(sa.inner_count),
        raw_ring_count=int(sa.raw_ring_count),
        solid=int(sa.solid),
        empty=int(sa.empty),
        edge_style=sa.edge_style,
        edge_ratio=sa.edge_ratio,
        ms=dict(sa.ms),
        area_px=metrics["area"],
        perimeter_px=metrics["perimeter"],
        dominant=metrics["dominant"],
        carve_mask=carve_mask,
        preview_factor=factor,
    )


def run_stage_b(stage_a, params):
    """撒点 → 三角化。轻，参数一改就能重算。"""
    t0 = time.perf_counter()
    res = tri_mod.build_mesh(
        stage_a.rings,
        max(2.0, float(params.spacing)),
        carve_mask=getattr(stage_a, "carve_mask", None),
    )
    t1 = time.perf_counter()
    res["stats"]["stage_b"] = round((t1 - t0) * 1000, 1)
    return res


def run(alpha, params, guide_mask=None, img_key="img"):
    """一次跑完（不做缓存，给测试 / 一次性调用用）。"""
    a = run_stage_a(alpha, params, guide_mask, img_key)
    b = run_stage_b(a, params)
    return a, b


# 稀疏端（密度=0）的目标边长 = 图片长边 × 这个比例。
# 0.25 的意思是「最粗时每 4 个三角形横跨整个宽度」——
# 用户实测大图拉到 0 还嫌密，25% 让大图也能真的粗下来。
# 小图仍受 max_px=48 的绝对下限保护（见 spacing_from_density）。
SPARSE_RATIO = 0.25


def spacing_from_density(v, min_px=6.0, max_px=48.0, image_long_side=None):
    """把 UI 上的「网格密度」0..1 映射成目标边长。

    【为什么不是线性映射】

    面数 ∝ 1/spacing²。线性改 spacing 会让面数在中段之后暴涨：
        线性映射下 density 0.85 → 11.5px、1.0 → 5.0px，
        面数从 11792 跳到 61838（+424%）。
    用户拖滑块的感觉是「前半段几乎没变化，最后半段直接卡死」。

    改成**几何级数**（等比）：spacing 按指数从 max 降到 min，
    于是「拖同样的距离，面数变化倍率相同」，手感均匀：
        0.0 → 48px      1.0 → 6px
        每 +0.1 面数约 ×1.5（全程一致），不会在某处突然爆炸。

    【为什么最小值是 6px 而不是 5px】

    实测：3996² 图、密度拉满（spacing=6px）要 **1751ms**、约 47 万面 ——
    能用，但绝对谈不上"流畅"（拖滑块时每次重建都要一秒多）。
    5px 会到 85 万面，视觉收益不明显但耗时再翻一倍，所以不收 5px。
    （早先这里写「够用且不至于卡死」，偏乐观了 —— 实测数字摆在这里。）

    ⚠️ 这个 6px 下限是**参数默认值**，不再在函数体里偷偷抬高调用方传的值。
       早先形参默认是 5.0，函数体里却写 `lo = max(6.0, min_px)` ——
       调用方显式传 5.0 会被静默改成 6.0，而文档字符串还写着「1.0 → 5px」。
       三处（形参/函数体/文档）说的不是同一个数，谁读谁懵。
       现在统一成 6.0，并且**尊重调用方显式传的值**（只要比 max 小）。

    【为什么稀疏端要跟着图片尺寸缩放 —— 用户实测反馈】

    用户报：「网格密度设成 0，还是挺高，没法再减少」。

    48px 是**绝对像素**，而「粗不粗」是相对形状看的。实测密度=0 时的面数：
        256×256   →    56 面   （48px 占长边 18.8%）
        512×512   →   168 面   （9.4%）
       1024×1024  →   616 面   （4.7%）
       2048×2048  →  2376 面   （2.3%）
       3883×1978  →  2224 面   （1.2%）   ← 用户这种大图，滑块到底了还是密

    所以稀疏端改成「按长边比例」：max_px = 长边 × SPARSE_RATIO（25%），
    但**不小于 max_px 原值**（小图仍按 48px，不然 256 图会变成 4 个三角形）。

    密集端（min_px=6px）**不缩放**：它受 Delaunay 和面数上限约束，
    跟图多大无关，6px 在任何尺寸下都是"很细"。
    """
    v = min(max(float(v), 0.0), 1.0)
    lo = float(min_px)
    hi = float(max_px)

    # 稀疏端按长边比例放大（但不会比原 max_px 更小）
    if image_long_side and float(image_long_side) > 0:
        by_ratio = float(image_long_side) * SPARSE_RATIO
        if by_ratio > hi:
            hi = by_ratio

    if hi <= lo:
        return lo
    # 等比：spacing = hi * (lo/hi)^v
    return hi * ((lo / hi) ** v)
