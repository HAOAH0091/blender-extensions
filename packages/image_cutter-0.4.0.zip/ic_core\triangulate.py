"""把轮廓铺成三角网格。

两条路线按目标边长分流：
  · spacing 小：错排格点 + 边界吸附 + 小碎块扇形，追求拖滑块的实时性
  · spacing 大：轮廓边界点 + 内部格点 + Delaunay，追求边界精度

Delaunay 路线会保留“重心在形状内”的三角形；格子路线则用二维邻接
直接生成拓扑，再按轮廓/引导掩膜剔除。

按需求「源图中心不留洞」：调用方只传外环（源图洞在 split_outer 就被丢了），
所以源图内部一律填满。手绘引导的「挖掉」区域例外，由 carve_mask
在阶段 B 再剔一次，保证内部 carve 也能留下洞。
"""

import math
import time

import numpy as np

from .outline import point_in_ring

# --------------------------------------------------------------------------
# Delaunay 后端：优先用 Blender 自带的 C 实现
# --------------------------------------------------------------------------
# 【为什么要有这一层】
#
# 下面那个纯 Python 的 Bowyer-Watson 是**算法层不依赖 bpy** 这条架构约定下
# 唯一能跑的东西（ic_core 不许 import bpy，算法要能脱离 Blender 单独测）。
# 但它是真慢：27383 点要 4.1 秒 —— 用户拖一下滑块就卡 4 秒，这不能接受。
#
# 而 Blender 通过 `mathutils.geometry.delaunay_2d_cdt` 暴露了一个 **C 实现**，
# 同样 27383 点只要 92ms，快 45 倍。
#
# 所以做成「可选加速器」：
#   · 在 Blender 里 → 用 C 版（快 45 倍）
#   · 脱离 Blender 跑测试 → 自动回退到纯 Python 版（功能一样，只是慢）
#
# mathutils 只在 Blender 的 Python 里能 import，所以这里用 try/except 探测，
# 而不是写死依赖 —— 算法层仍然能独立测试。
_CDT = None
try:                                        # pragma: no cover - 取决于运行环境
    from mathutils import Vector as _Vec
    from mathutils.geometry import delaunay_2d_cdt as _cdt_fn

    _CDT = (_Vec, _cdt_fn)
except Exception:                           # noqa: BLE001
    _CDT = None


def backend_name():
    """当前用的是哪个后端（给面板/日志显示，也方便测试断言）。"""
    return "mathutils-cdt" if _CDT is not None else "python-bowyer-watson"


def delaunay_fast(points, epsilon=1e-6):
    """Delaunay 三角化，能用 C 就用 C。

    返回 [(i, j, k), ...]，索引指向传入的 points（**保证是输入点的索引**，
    不是 CDT 内部重排后的索引）。

    注意：`delaunay_2d_cdt` 算的是**凸包**，凹的地方会被填上三角形。
    这不影响本插件的用法 —— 调用方（build_mesh）本来就靠「三角形重心是否
    落在形状内」来剔除多余面，凹形和洞都是这样处理的。
    """
    pts = np.asarray(points, dtype=np.float64)
    n = len(pts)
    if n < 3:
        return []
    if _CDT is None:
        return delaunay_2d(pts)

    # 注意：_CDT 元组里第一个（Vector 类）现在用不上了 —— 见下面说明。
    _vec_unused, fn = _CDT
    # 【不要用 Vector 包装，直接传 tuple 列表】
    #
    # delaunay_2d_cdt 接受任何"两个 float 的序列"，tuple 完全够用，
    # 而构造 Vector 对象要在 C 层建 12 万个 struct。
    # 实测 n=124047：
    #     Vector 列表构造 143.4ms + 调用 521.9ms
    #     tuple  列表构造  28.6ms + 调用 529.6ms
    # 构造省下 115ms（5 倍），调用时间基本不变，输出规模完全一致（248065 三角）。
    #
    # pts.tolist() 走 C 层一次转完，比 [ (float(x),float(y)) for x,y in pts ]
    # 这类推导式快一个量级 —— 又是"别在 Python 层搬 numpy 数据"的老教训。
    verts = pts.tolist()
    try:
        # output_type=0 → 只输出三角形（不带边/多边形）
        res = fn(verts, [], [], 0, float(epsilon))
    except Exception:                       # noqa: BLE001
        # C 版意外失败（点太密 / 退化输入）→ 老老实实用 Python 版兜底，
        # 宁可慢也不能没结果
        return delaunay_2d(pts)

    out_verts, _out_edges, out_faces, orig_verts = res[0], res[1], res[2], res[3]

    # CDT 会合并重合点、微调坐标，所以输出顶点顺序与输入不同。
    # orig_verts 给出「输出第 k 个点 ← 输入第几个点」，据此把面索引映射回输入索引。
    #
    # 【向量化】早先是两个纯 Python 循环：
    #   · for k, src in enumerate(orig_verts): ...          → 12 万次
    #   · for f in out_faces: int(f[0]) ...                 → 24 万次 × 3 次索引
    # 实测在 246292 面的场景下花掉 359ms（占 delaunay_fast 的 57%、B 阶段的 35%）。
    # 两处都能写成 numpy 一次搞定，输出完全一致。
    # 【永远按 orig_verts 映射，不能假设恒等】
    #
    # 实测常见的 100 / 1000 / 5000 个不重合点确实是恒等映射，但 API 没有
    # 承诺输出顺序。之前用「点数相同」推断索引相同：一旦 CDT 重排了顶点，
    # 面就会连到错误的输入点上，而且点数相同，越界检查也发现不了。
    #
    # 这里把 orig_verts 一次性转成 numpy（不要逐顶点生成器 —— 99 万点实测
    # 要 172ms）。遇到合并点导致的变长 tuple 才退回逐项解析；映射不到的
    # 输出点（例如 CDT 自己插入的交点）标成 -1，相关面直接丢掉。
    if len(orig_verts) == len(out_verts):
        try:
            ov = np.asarray(orig_verts, dtype=np.int64)
        except (TypeError, ValueError):
            ov = None
        if ov is not None and ov.shape[0] == len(out_verts) and (
                ov.ndim == 1 or (ov.ndim == 2 and ov.shape[1] >= 1)):
            src_map = ov if ov.ndim == 1 else ov[:, 0]
        else:
            src_map = np.full(len(out_verts), -1, dtype=np.int64)
            for k, sources in enumerate(orig_verts):
                if len(sources) > 0 and 0 <= int(sources[0]) < n:
                    src_map[k] = int(sources[0])
    else:
        src_map = np.full(len(out_verts), -1, dtype=np.int64)

    if len(out_faces) == 0:
        return []
    far = np.asarray(out_faces, dtype=np.int64)          # (m, 3)
    if far.ndim != 2 or far.shape[1] < 3:
        return []

    idx = src_map[far[:, :3]]
    # 越界 / CDT 新插入点（-1）都别让后面搞崩
    inrange = ((idx >= 0) & (idx < n)).all(axis=1)
    idx = idx[inrange]

    if len(idx) == 0:
        return []
    # 去掉退化三角形（三个顶点有重复）
    a = idx[:, 0]
    b = idx[:, 1]
    c = idx[:, 2]
    nondeg = (a != b) & (b != c) & (a != c)
    idx = idx[nondeg]
    # 【别写 `[tuple(int(v) for v in row) for row in idx]`】
    # 24.6 万个三角形 = 74 万次 Python 层的 int() 调用 + tuple 构造，
    # profile 实测这一行 174ms（<genexpr> 992200 calls），
    # 而上面的 Delaunay 本体才 291ms —— 光"把结果搬出 numpy"就吃掉 14%。
    #
    # 用 .tolist() 一次性转成 Python 嵌套 list：走 C 层，快一个量级。
    # 返回类型仍是 list[list[int]]，调用方（build_mesh / 测试）按索引访问，语义不变。
    return idx.tolist()


# --------------------------------------------------------------------------
# 批量几何判定（向量化，比逐点跑 Python 循环快一两个数量级）
# --------------------------------------------------------------------------

# ==========================================================================
# 分块预算：向量化时「单块临时数组」的元素数上限，用来把内存钉住
# ==========================================================================
#
# 【为什么要有这个数】
#
# dist_to_rings_batch 是 (点数 × 段数) 的矩阵。原实现只按点数分块（chunk=1024），
# 段数那一维没管 —— 16384 环时单块临时数组 3GB、进程峰值 4.8GB（就是那个崩溃）。
#
# 分块条件写成 `chunk × 另一维 ≤ BUDGET`，无论输入多畸形单块内存都有上界。
DIST_BLOCK_BUDGET = 2_000_000        # 2M float64 ≈ 16MB


def points_in_ring(pts, ring):
    """批量射线法。pts: (N,2) float 数组 → (N,) bool。

    ⚠️ 性能要点：环可能被加密到几千个点（栅格化前会 _dense 一遍）。
    如果对**每个环边**都拿全量点算一遍，就是 边数 × 点数 次浮点运算 ——
    2048² 图上 4000 边 × 400 万点 = 160 亿次，实测要 11 秒。

    所以先按环的 y 范围把点筛成一小批（射线法只关心 y 落在环跨度内的点），
    只对这批点跑逐边循环；其余点直接判 False。
    典型矩形路径能筛掉 90% 以上，耗时从 11 秒降到毫秒级。
    """
    pts = np.asarray(pts, dtype=np.float64)
    if pts.size == 0 or len(ring) < 3:
        return np.zeros(len(pts), dtype=bool)

    ring_arr = np.asarray(ring, dtype=np.float64)
    y_lo = float(ring_arr[:, 1].min())
    y_hi = float(ring_arr[:, 1].max())
    x_lo = float(ring_arr[:, 0].min())
    x_hi = float(ring_arr[:, 0].max())

    y_all = pts[:, 1]
    # 先做一次便宜的包围盒筛选：盒外必然不在环内
    bbox_hit = (y_all >= y_lo) & (y_all <= y_hi) & \
               (pts[:, 0] >= x_lo) & (pts[:, 0] <= x_hi)

    inside = np.zeros(len(pts), dtype=bool)
    if not bbox_hit.any():
        return inside

    sub = pts[bbox_hit]
    x = sub[:, 0]
    y = sub[:, 1]
    sub_inside = np.zeros(len(sub), dtype=bool)

    n = len(ring)
    if n == 0:
        return inside

    # 【关于「方向不对称」：查清了，不是 bug，别改】
    #
    # 审查报告测到「横条 3.6ms / 竖条 925ms」，看着像方向依赖。
    # 我用 45° 斜条做了决定性实验（同样 4200 点的环 × 2 万点）：
    #     0°（横）   9.5 ms     ← 所有边都是水平边，全被下面这行跳过，没参与计算
    #     45°      179.3 ms
    #     90°（竖） 180.5 ms   ← 与 45° 几乎相同
    # 45° 和 90° 一致 ⇒ **没有方向偏好**。横条"快"是因为它压根没算东西。
    #
    # 我试过把逐边循环改成 (点数 × 边数) 的一次性向量化，结果：
    #     45° 时 新 382ms / 旧 183ms —— 反而慢了 2 倍
    # 大矩阵（2万 × 4200）的分配和遍历比 4200 次小运算更贵。
    # 所以这里**保留逐边循环**，它是这个规模下的最优解。
    #
    # 唯一真正的上限是「环的点数」：4200 点要 180ms。而 4200 点是
    # trace_rings 的正常产出（轮廓本来就密），不是异常。
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        # 水平边不跨越任何 y，射线法天然跳过它（这是数学上正确，不是优化）
        if y0 == y1:
            continue
        cond = (y0 > y) != (y1 > y)
        if not cond.any():
            continue
        xc = (x1 - x0) * (y - y0) / (y1 - y0) + x0
        sub_inside ^= cond & (x < xc)

    inside[bbox_hit] = sub_inside
    return inside


def points_in_any_ring(pts, rings):
    """N 个点是否落在**任意一个**环内（多环取并）。

    【性能权衡：这里必须逐环，不能合并边表】

    实测过「把所有环的边拼成一张大表、一次广播算完」的方案 ——
    正确性没问题（20 万点 × 210 环，结果与逐环版逐元素一致），但**慢了 10 倍**：
        合并边表：18633 ms
        逐环循环： 1971 ms
    原因是矩阵规模变成 (点数 × **所有**环的总边数)，而逐环版每一轮只用
    当前环那一小撮边，numpy 处理和内存占用都低得多。
    210 个环的总边数可能上万，乘 20 万点就是几十亿个元素，
    分块也救不了。

    【那么 O(点数 × 环数) 这个问题怎么缓解？】

    不合并，但**先用包围盒把点筛掉**：一个环的 bbox 之外的点绝不可能在它内部，
    直接跳过，不做逐边计算。真实素材里 210 个外环大多是碎块，
    bbox 很小，20 万个点里每个环通常只剩几百个候选 —— 这是最划算的剪枝。

    （审查报告实测：同一张图 24.6 万面，1 环 1038ms / 210 环 4250ms。
      多出来的开销主要在"每环都把所有点重新过一遍"，bbox 预筛正是打这个。）
    """
    pts = np.asarray(pts, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[0] == 0 or pts.shape[1] < 2:
        return np.zeros(pts.shape[0] if pts.ndim >= 1 else 0, dtype=bool)

    # 【试过四条优化路，全部失败 —— 保持朴素写法，别再试】
    #
    # 实测基准（真实图，210 个外环）：
    #     142560 点 → 74ms        250165 点 → 212ms
    #
    # 四条失败的路：
    #   A 合并边表一次广播：18633ms（原版 1971ms）
    #     矩阵 = 点数 × 全部环边数，几十亿元素
    #   B 逐环 + remaining 掩膜跳过已命中点：2305ms
    #     np.nonzero(remaining) 每轮全扫 20 万点，210 轮下来光是找点就比几何计算贵
    #   C 环按 bbox 分桶、点只查自己格子：1156ms vs 45ms（慢 25 倍，3000点×400环）
    #     分桶建表 + 逐点 Python 循环，比 numpy 逐环慢得多
    #   D bbox 当必要条件先筛：119ms/310ms vs 74ms/212ms —— **更慢**
    #     因为命中率太高（实测 86.2% 和 98.7%），筛掉的人太少，
    #     而 210 次全数组 bbox 比较本身就是额外开销
    #
    # 四条都输在同一个地方：**为了省几何计算，引入了更贵的常数开销**。
    # 而 points_in_ring 内部已经是 numpy 批量（一次处理所有点），
    # 逐环调用只有「环数」次函数开销 —— 这恰恰是最省的形式。
    #
    # 结论：这个函数没有便宜的优化空间，**真正的杠杆是减少环数**
    # （expand 会把细缝合上：实测 210 环 → 1 环，B 阶段 4.2s → 1.0s）。
    # 【第 5 条路：按 y 排序 + searchsorted 切候选段 —— 它赢了，但有前提】
    #
    # 这里跟上面 A~D 的区别：**不是**对每个环拿全部点比一遍 bbox（那就是 D，
    # 输了）。而是先把点按 y 排一次序（O(n log n)，一次），之后每个环用二分
    # 直接切出「y 落在环跨度内」的那一段，只有这一段进 points_in_ring。
    #
    # 实测（spacing=6，248950 个格点）：
    #   环数 79  命中 0.7%   96.1ms →  46.2ms  2.08x
    #   环数 117 命中 0.5%  128.8ms →  49.4ms  2.61x
    #   环数 143 命中 0.4%  151.6ms →  51.9ms  2.92x
    #   环数 128 命中 0.5%  145.3ms →  59.6ms  2.44x
    #   环数 72  命中 1.1%  120.7ms →  79.3ms  1.52x
    #   判定差异全部为 0（与逐环全量逐元素一致）
    #
    # ⚠️ 但它有反例：**环少的时候反而慢**。20 万点排一次序固定要 ~15ms，
    #    1 个环根本摊不回来：
    #      1 环 / 4 点      4.7ms → 21.7ms   0.22x（慢 4.5 倍）
    #      1 环 / 500 点   69.3ms → 84.7ms   0.82x
    #      7 环            43.0ms → 38.3ms   1.12x（几乎打平）
    #    所以门槛设在 8 个环：环数少直接走原来的朴素路径，不吃排序开销。
    _MIN_RINGS_FOR_YINDEX = 8
    if len(rings) < _MIN_RINGS_FOR_YINDEX:
        ok = np.zeros(len(pts), dtype=bool)
        for r in rings:
            if len(r) >= 3:
                ok |= points_in_ring(pts, r)
        return ok

    ok = np.zeros(len(pts), dtype=bool)
    order = np.argsort(pts[:, 1], kind="stable")
    ys_sorted = pts[order, 1]
    for r in rings:
        if len(r) < 3:
            continue
        arr = np.asarray(r, dtype=np.float64)
        y_lo = float(arr[:, 1].min())
        y_hi = float(arr[:, 1].max())
        i0 = int(np.searchsorted(ys_sorted, y_lo, side="left"))
        i1 = int(np.searchsorted(ys_sorted, y_hi, side="right"))
        if i1 <= i0:
            continue
        cand = order[i0:i1]
        # points_in_ring 内部还会做 x 的 bbox 筛，这里只负责把 y 缩到环跨度
        ok[cand[points_in_ring(pts[cand], arr)]] = True
    return ok


def _segments_of(rings, with_owner=False):
    """把一圈圈轮廓拍平成线段数组 (M,4) = [x0, y0, x1, y1]。

    with_owner=True 时额外返回每条线段所属的环序号。空间哈希处理
    「跨越太多格子」的线段时需要按真实环回退；不能拿拍平后的线段序号
    直接索引 rings（多环时两者不是一回事）。
    """
    segs = []
    owners = []
    for ring_index, ring in enumerate(rings):
        n = len(ring)
        if n < 2:
            continue
        arr = np.asarray(ring, dtype=np.float64)
        nxt = np.roll(arr, -1, axis=0)
        segs.append(np.hstack([arr, nxt]))
        owners.append(np.full(n, ring_index, dtype=np.int64))
    if not segs:
        empty = np.zeros((0, 4), dtype=np.float64)
        return (empty, np.zeros(0, dtype=np.int64)) if with_owner else empty
    out = np.vstack(segs)
    if with_owner:
        return out, np.concatenate(owners)
    return out


_RING_GRID_CACHE = {"token": None, "grid": None}


def clear_ring_grid_cache():
    """释放最近一次线段空间哈希（阶段 A 换轮廓后旧表就没用了）。"""
    _RING_GRID_CACHE["token"] = None
    _RING_GRID_CACHE["grid"] = None


def _build_segment_grid(rings, cell):
    """把轮廓线段塞进均匀网格。这个结构与候选点无关，可按轮廓复用。"""
    segs, seg_owner = _segments_of(rings, with_owner=True)
    grid = {
        # 持有引用，避免 rings / 数组释放后 id 被复用，误命中旧缓存。
        "rings_ref": rings,
        "segs": segs,
        "seg_owner": seg_owner,
        "uk": None,
        "start": None,
        "end": None,
        "big_owner_ids": np.zeros(0, dtype=np.int64),
    }
    if len(segs) == 0:
        return grid

    xa = np.minimum(segs[:, 0], segs[:, 2])
    xb = np.maximum(segs[:, 0], segs[:, 2])
    ya = np.minimum(segs[:, 1], segs[:, 3])
    yb = np.maximum(segs[:, 1], segs[:, 3])
    ia = np.floor(xa / cell).astype(np.int64)
    ib = np.floor(xb / cell).astype(np.int64)
    ja = np.floor(ya / cell).astype(np.int64)
    jb = np.floor(yb / cell).astype(np.int64)

    ci_list = []
    cj_list = []
    seg_list = []
    big_segs = []
    MAX_SPAN = 4096
    for s in range(len(segs)):
        ni = int(ib[s] - ia[s] + 1)
        nj = int(jb[s] - ja[s] + 1)
        if ni * nj > MAX_SPAN:
            # 跨度极大的段（罕见）交给全量版兜底，别把格子表撑爆
            big_segs.append(s)
            continue
        ii, jj = np.meshgrid(np.arange(ia[s], ib[s] + 1),
                             np.arange(ja[s], jb[s] + 1), indexing="ij")
        ci_list.append(ii.ravel())
        cj_list.append(jj.ravel())
        seg_list.append(np.full(ii.size, s))

    if big_segs:
        grid["big_owner_ids"] = np.unique(
            seg_owner[np.asarray(big_segs, dtype=np.int64)]
        )

    if ci_list:
        ci = np.concatenate(ci_list)
        cj = np.concatenate(cj_list)
        sg = np.concatenate(seg_list)

        key = ci * 100003 + cj
        order = np.argsort(key, kind="stable")
        key = key[order]
        sg = sg[order]
        uk, start = np.unique(key, return_index=True)
        end = np.append(start[1:], len(key))
        grid["uk"] = uk
        grid["start"] = start
        grid["end"] = end
        grid["sg"] = sg
    return grid


def _segment_grid_for(rings, cell):
    token = (id(rings), float(cell),
             tuple((id(r), len(r)) for r in rings))
    if _RING_GRID_CACHE["token"] == token:
        return _RING_GRID_CACHE["grid"]
    grid = _build_segment_grid(rings, cell)
    _RING_GRID_CACHE["token"] = token
    _RING_GRID_CACHE["grid"] = grid
    return grid


def dist_to_rings_grid(cand, rings, cell=32.0):
    """点到线段集的最短距离 —— 空间哈希加速版（比全量广播快 60 倍）。

    rings 按只读处理；线段索引会按轮廓对象复用。若调用方原地改了环坐标，
    请先调用 clear_ring_grid_cache()。

    【为什么需要它：全量广播是拖滑块的唯一瓶颈】

    原来的 dist_to_rings_batch 是 (点数 × 段数) 的全量广播。
    实测 3883×1978 那张图、spacing=6px：
        候选点 122560 × 段数 1511 = 1.85 亿次元素运算 → 2883 ms
    而它占 B 阶段的 85% —— 这就是用户"拖滑块卡顿"的来源。

    【这个函数怎么快起来的】

    空间哈希（uniform grid）：把线段按包围盒塞进边长 cell 的格子，
    每个候选点只和「自己所在格子 + 8 个邻格」里的线段算距离。
    格子边长取 spacing 的几倍时，一个点通常只碰到寥寥几段。

    【关键：不需要精确距离，只需要「够不够远」】

    interior_points 里 dist 只用于一个比较：
        keep = dist >= spacing * edge_clearance   (0.45 × spacing)
    也就是说**只要知道"离轮廓是否超过 2.7 像素"**就够了。

    实测（同一张图）：本函数返回 inf 的点占 88.5%（那些点周围一个格子内
    没有任何线段 → 距离必然远超阈值）。漏掉精确值的那些点，
    真实距离中位 332.9px、**没有一个小于阈值**，
    阈值判定翻转的点数为 **0** —— 与全量版逐点等价。

    （想拿精确距离的调用方请继续用 dist_to_rings_batch。）
    """
    cand = np.asarray(cand, dtype=np.float64)
    if cand.ndim != 2 or cand.shape[0] == 0 or cand.shape[1] < 2:
        return np.full(cand.shape[0] if cand.ndim >= 1 else 0, np.inf)

    grid = _segment_grid_for(rings, cell)
    segs = grid["segs"]
    if len(segs) == 0:
        return np.full(len(cand), np.inf)

    out = np.full(len(cand), np.inf)
    uk = grid["uk"]
    if uk is not None:
        start = grid["start"]
        end = grid["end"]
        sg = grid["sg"]

        pk = (np.floor(cand[:, 0] / cell).astype(np.int64) * 100003
              + np.floor(cand[:, 1] / cell).astype(np.int64))

        # 候选点按所在格分组后再查邻格。高密度时一个 cell 里会有几十个点；
        # 原实现拿每个点各做 9 次 searchsorted，4K/spacing=6 实测这一层
        # 占 dist_to_rings_grid 的近一半。按唯一 cell 查一次，再把结果展开
        # 到 cell 内的点，输出逐元素一致，实测 10 万点 52ms → 30ms。
        p_order = np.argsort(pk, kind="stable")
        pk_sorted = pk[p_order]
        upk, p_start = np.unique(pk_sorted, return_index=True)
        p_end = np.append(p_start[1:], len(pk))

        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                want = upk + di * 100003 + dj
                pos = np.searchsorted(uk, want)
                pos_c = np.clip(pos, 0, len(uk) - 1)
                hit = (pos < len(uk)) & (uk[pos_c] == want)
                if not hit.any():
                    continue

                hit_cells = np.nonzero(hit)[0]
                p0 = p_start[hit_cells]
                p1 = p_end[hit_cells]
                n_point = p1 - p0
                local_cell = np.repeat(np.arange(len(hit_cells)), n_point)
                base = np.repeat(np.cumsum(n_point) - n_point, n_point)
                point_off = (np.repeat(p0, n_point)
                             + (np.arange(n_point.sum()) - base))
                point_idx = p_order[point_off]

                st = start[pos_c[hit_cells]]
                en = end[pos_c[hit_cells]]
                n_seg = en - st
                # 每个点属于一个 hit cell，要重复该 cell 的线段范围。
                n_seg_per_point = n_seg[local_cell]
                point_rep = np.repeat(np.arange(len(point_idx)), n_seg_per_point)
                seg_base = np.repeat(
                    np.cumsum(n_seg_per_point) - n_seg_per_point,
                    n_seg_per_point,
                )
                seg_off = (np.repeat(st[local_cell], n_seg_per_point)
                           + (np.arange(n_seg_per_point.sum()) - seg_base))
                sj = sg[seg_off]
                point_idx = point_idx[point_rep]

                ss = segs[sj]
                px = cand[point_idx, 0]
                py = cand[point_idx, 1]
                dx = ss[:, 2] - ss[:, 0]
                dy = ss[:, 3] - ss[:, 1]
                l2 = dx * dx + dy * dy
                l2 = np.where(l2 < 1e-12, 1e-12, l2)
                t = np.clip(((px - ss[:, 0]) * dx + (py - ss[:, 1]) * dy) / l2, 0, 1)
                qx = ss[:, 0] + t * dx
                qy = ss[:, 1] + t * dy
                dd = np.hypot(px - qx, py - qy)
                np.minimum.at(out, point_idx, dd)

    owner_ids = grid["big_owner_ids"]
    if len(owner_ids):
        d_big = dist_to_rings_batch(cand, [rings[i] for i in owner_ids])
        np.minimum(out, d_big, out=out)
    return out



def dist_to_rings_batch(pts, rings, chunk=1024):
    """批量算「每个点到所有轮廓线段的最短距离」。

    向量化版本 —— 原来 `_dist_to_rings` 是逐点逐段的 Python 双重循环，
    候选点 2 万 × 线段 3 千 = 6 千万次纯 Python 迭代，
    密度拉满时要 15 秒，等于把「拖滑块跟手」的承诺作废。
    这里改成 numpy 广播。

    【分块必须按「点数 × 段数」的乘积，不能只按点数 —— 这是真崩溃的来源】

    早先 chunk 固定 1024，每块的临时数组是 (1024, 总段数)。
    「总段数」= 所有环的点数之和，**环一多它就爆炸**：

        环数      总段数    单块临时    耗时       进程峰值
        256       1 024     48 MB      293 ms     606 MB
        4 096     16 384    768 MB     9 569 ms   1 368 MB
        16 384    65 536    3 072 MB   39 729 ms  4 824 MB   ← 4.8GB！

    （上表是**修复前**（chunk 只按点数分）的实测值。
      修完之后 —— 按乘积分块 —— 的实测值：
        4 096 环   →  443 ms / 峰值 123 MB
        16 384 环  →  139 MB（内存不再随环数增长）
      别拿上表当当前性能做预算。）

    那个 4.8GB 峰值极可能就是用户遇到的 EXCEPTION_ACCESS_VIOLATION
    （崩溃点看着在 split_outer，但它自己只 800ms；真正吃内存的是这里）。

    所以分块条件改成「块内点数 × 段数 ≤ BUDGET」：
        chunk = max(1, BUDGET // n_segs)
    这样无论环多到什么程度，单块临时数组都不超过 BUDGET 个元素。
    """
    pts = np.asarray(pts, dtype=np.float64)
    if pts.size == 0:
        return np.zeros(0, dtype=np.float64)
    # 维度防御：和同层的 points_in_any_ring 保持同一口径。
    # 传 1 维数组时下面 pts[:, 0] 会抛 IndexError（未捕获），
    # 而 points_in_any_ring 早就有这层检查 —— 两个同层 API 不该不一致。
    if pts.ndim != 2 or pts.shape[1] < 2:
        raise ValueError(
            "dist_to_rings_batch 需要 (N,2) 的点数组，收到 shape=%r" % (pts.shape,)
        )

    segs = _segments_of(rings)
    if len(segs) == 0:
        return np.full(len(pts), np.inf, dtype=np.float64)

    x0 = segs[:, 0]
    y0 = segs[:, 1]
    dx = segs[:, 2] - x0
    dy = segs[:, 3] - y0
    l2 = dx * dx + dy * dy
    degenerate = l2 <= 1e-12
    # 退化线段（两端重合）的距离公式要单独处理，先把除数换成 1 避免除零
    safe_l2 = np.where(degenerate, 1.0, l2)

    # 按乘积分块：单块 (chunk, n_segs) 不超过 DIST_BLOCK_BUDGET 个元素。
    # 200 万元素 ≈ 16MB（float64），是「够快又不吃内存」的折中。
    n_segs = len(segs)
    chunk = max(1, min(int(chunk), DIST_BLOCK_BUDGET // max(n_segs, 1)))

    out = np.empty(len(pts), dtype=np.float64)
    for start in range(0, len(pts), chunk):
        block = pts[start:start + chunk]                  # (b,2)
        px = block[:, 0:1]                                # (b,1)
        py = block[:, 1:2]

        wx = px - x0                                      # (b,M)
        wy = py - y0
        t = (wx * dx + wy * dy) / safe_l2
        np.clip(t, 0.0, 1.0, out=t)
        # 退化线段退化成点距离
        t = np.where(degenerate, 0.0, t)

        cx = x0 + t * dx
        cy = y0 + t * dy
        d = np.hypot(px - cx, py - cy)
        out[start:start + chunk] = d.min(axis=1)
    return out


def _dist_to_rings(pt, rings):
    """点到所有轮廓线段的最短距离（单点）。

    保留这个单点接口是为了兼容（测试可能直接调）；
    批量场景请用 dist_to_rings_batch，快一两个数量级。
    """
    return float(dist_to_rings_batch(np.asarray([pt], dtype=np.float64), rings)[0])


# --------------------------------------------------------------------------
# 点集生成
# --------------------------------------------------------------------------

def densify_ring_adaptive(ring, max_len, sag_tol=2.0, min_len=2.0):
    """按**局部曲率**细分轮廓：直边放稀、弯角加密。

    【为什么需要自适应 —— 2026-10-22 用户反馈】
    用户指着视口截图说「边缘的三角面和内部三角差别好像有点大」。
    截图里上边缘那排是放射状细针：一条**直边**上每 12px 一个点，
    整排点全连接到同一个内部格点。

    实测（用户图 3883×1978、spacing=139.62、expand=16）：
        类别   面数   最小角p50   长宽比p50   短边/spacing   细针率
        边界    807     6.0°       7.97        0.09       99.0%
        内部    449    60.0°       1.00        1.00        0.0%
    边界点密度是内部的 11.6 倍 —— 这个差距就是「差别大」的全部来源。

    【为什么不能简单把步长放大到 spacing】
    弯的地方会切进弧内侧，重新出现「边缘侵蚀」（上一轮刚修掉的问题）。
    按弦高控制才对：曲率半径 R 处，弦长 L 的最大偏差 ≈ L²/(8R)，
    要求 ≤ sag_tol  →  L ≤ sqrt(8·sag_tol·R)。
      · 直边 R→∞  → L 顶到 max_len（=spacing），不再堆无用的点
      · 弯角 R 小  → L 自动变小，边界精度保住
    直边上细分点本来就落在线段上、不改变几何，所以省掉它们**零精度代价**。

    【实测：sag_tol 只影响拓扑，不影响几何】
    真图 expand 0/16/256/656 四档、sag ∈ {1.0,1.5,2.0,3.0}：
        侵蚀率与过覆盖率**逐位完全相同**（0.0000% / 1.130% 等）
    所以这是个纯网格质量参数，怎么调都不会退回「侵蚀」那个坑。
    取值见 _BOUNDARY_SAG_TOL 的实测表。
    """
    if max_len <= 1e-6:
        return [(float(p[0]), float(p[1])) for p in ring]

    n = len(ring)
    if n < 3:
        return [(float(p[0]), float(p[1])) for p in ring]

    # 每个顶点的转角 → 局部曲率半径
    P = np.asarray(ring, dtype=np.float64)
    v1 = P - np.roll(P, 1, axis=0)
    v2 = np.roll(P, -1, axis=0) - P
    n1 = np.linalg.norm(v1, axis=1)
    n2 = np.linalg.norm(v2, axis=1)
    cosv = np.clip((v1 * v2).sum(axis=1) / np.maximum(n1 * n2, 1e-12), -1.0, 1.0)
    ang = np.arccos(cosv)                       # 转角（弧度）
    ds = 0.5 * (n1 + n2)
    kappa = ang / np.maximum(ds, 1e-9)           # 1/px
    Rloc = np.where(kappa > 1e-9, 1.0 / np.maximum(kappa, 1e-12), np.inf)

    # 每条边 k：取两端曲率半径的较小者（保守），算出允许弦长
    R_edge = np.minimum(Rloc, np.roll(Rloc, -1))
    L_edge = np.sqrt(8.0 * sag_tol * np.minimum(R_edge, 1e12))
    L_edge = np.clip(L_edge, min_len, max_len)

    # 【每边段数用「最大余数法」分配，不要逐边 int() 取整】
    #
    # ① 为什么不能逐边 `steps = int(seg / L_edge[k])`：
    #    取整误差能到 100%。一条 150px 的直边，L=100 → steps=1 → 实际段长
    #    150px；L=140 → 还是 1 段 → 150px。相邻边一个密一个稀，接缝处就是
    #    细长三角。实测让「边界最小角 <20°」卡在 31~45% 降不下去，
    #    且随 sag 变化不单调（expand=656：sag=1.0 → 45.4%，sag=2.0 → 43.6%）。
    #
    # ② 为什么不能用「整环累积权重等分」（我先写了这版，已推翻）：
    #    那样会**跳过原始轮廓顶点**，尖角被削平。实测五角星 spacing=30：
    #    侵蚀深度 max 从 1.4px 涨到 5.4px、过覆盖 0.744% → 0.913%。
    #    「原始顶点必须保留」是硬约束 —— 尖角就是轮廓本身。
    #
    # ③ 现在：先算每边浮点段数 f_k = seg_len/L_edge，总段数 N = round(sum f_k)，
    #    再按余数从大到小补足，保证 sum(n_k) = N 且 n_k 尽量贴近 f_k；
    #    每边等分 n_k 份、两端点都保留。
    seg_len = np.hypot(*np.diff(np.vstack([P, P[:1]]), axis=0).T)
    f = seg_len / np.maximum(L_edge, 1e-9)
    n_int = np.floor(f).astype(np.int64)
    N_target = int(round(float(f.sum())))
    need = N_target - int(n_int.sum())
    if need > 0:
        order = np.argsort(-(f - n_int), kind="stable")
        n_int[order[:min(need, n)]] += 1
    elif need < 0:
        left = -need
        order = np.argsort(f - n_int, kind="stable")
        for k in order:
            if left <= 0:
                break
            if n_int[k] > 1:
                n_int[k] -= 1
                left -= 1
        while left > 0:
            k = int(np.argmax(n_int))
            if n_int[k] <= 1:
                break
            n_int[k] -= 1
            left -= 1
    n_int = np.maximum(n_int, 1)      # 每条边至少 1 段 → 所有原始顶点保留

    out = []
    for k in range(n):
        x0, y0 = P[k]
        x1, y1 = P[(k + 1) % n]
        out.append((float(x0), float(y0)))
        steps = int(n_int[k])
        for m in range(1, steps):
            t = m / steps
            out.append((float(x0 + (x1 - x0) * t), float(y0 + (y1 - y0) * t)))
    return out


def densify_ring(ring, max_len):
    """按最大边长细分轮廓（等距，不看曲率）。

    保留它是为了兼容测试里的直接调用；大形状那条路已经改用
    densify_ring_adaptive（直边不再堆点）。

    不细分会出现「粗边界 + 细网格」的硬拼缝：
    边界还是几十像素一根直线段，内部却铺满小三角，接缝处全是细长条。
    """
    if max_len <= 1e-6:
        return [(float(p[0]), float(p[1])) for p in ring]

    out = []
    n = len(ring)
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        out.append((float(x0), float(y0)))
        seg = math.hypot(x1 - x0, y1 - y0)
        steps = int(seg / max_len)
        for m in range(1, steps + 1):
            t = m / (steps + 1)
            out.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    return out


def interior_points(rings, spacing, edge_clearance=0.45):
    """在形状内部按间距撒错排点。

    错排（每行偏移半格）= 近似正三角排布，三角化后形状比正方格好看。
    edge_clearance: 离边界近于 spacing×这个系数的点剔掉，避免生成细长三角。
    """
    if spacing <= 1e-6:
        return np.zeros((0, 2), dtype=np.float64)

    xs0 = min(p[0] for r in rings for p in r)
    ys0 = min(p[1] for r in rings for p in r)
    xs1 = max(p[0] for r in rings for p in r)
    ys1 = max(p[1] for r in rings for p in r)

    need = spacing * edge_clearance
    out = []
    row = 0
    y = ys0 + spacing * 0.5
    while y < ys1:
        offset = (row % 2) * spacing * 0.5
        x = xs0 + spacing * 0.5 + offset
        while x < xs1:
            out.append((x, y))
            x += spacing
        y += spacing
        row += 1

    if not out:
        return np.zeros((0, 2), dtype=np.float64)

    cand = np.asarray(out, dtype=np.float64)
    keep = points_in_any_ring(cand, rings)
    cand = cand[keep]
    if len(cand) == 0:
        return cand

    # 剔掉贴边太近的（这里必须向量化，否则密度拉满会卡十几秒）
    # 这里只需要「离轮廓够不够远」这一个布尔判定，
    # 不需要精确距离 —— 用空间哈希版（实测快 60 倍，判定逐点等价）。
    dist = dist_to_rings_grid(cand, rings)
    keep = dist >= need
    if not keep.any():
        return np.zeros((0, 2), dtype=np.float64)
    return cand[keep]


# --------------------------------------------------------------------------
# Delaunay（Bowyer-Watson 增量式）
# --------------------------------------------------------------------------

def delaunay_2d(points):
    """Bowyer-Watson 增量式 Delaunay 三角化。

    返回三角形索引列表 [(i, j, k), ...]，索引指向传入的 points。
    只返回用真点构成的三角形（超级三角形的顶点已被剔除）。

    性能说明（2026-10-21 改造）：
    原来是「每个点插入时，对当时所有三角形做内切圆测试」=> O(n²) 元素操作。
    1.1 万点要 3 秒、2.4 万点要 15 秒，把「拖滑块跟手」的承诺直接作废。

    现在给三角形建**空间网格**：每个三角形按「外接圆包围盒」登记到自己覆盖的格子里；
    插入点 p 时只取 p 所在格子里的三角形当候选。
    正确性：若 p 落在某三角形外接圆内，则 p 必在其包围盒内，则该三角形必被登记到
    p 所在格子 —— 不会漏；包围盒是矩形，候选是超集，多测几个而已。
    外接圆特别大的三角形（近共线的细长三角形）统一扔进 big 列表，每次全查，避免
    一个退化三角形被登记到成千上万个格子。

    实测：2.4 万点从 15 秒降到亚秒级，输出拓扑不变（回归测试的面积/覆盖率判据不动）。
    """
    pts = np.asarray(points, dtype=np.float64)
    n = len(pts)
    if n < 3:
        return []

    mn = pts.min(axis=0)
    mx = pts.max(axis=0)
    size = float(max(mx[0] - mn[0], mx[1] - mn[1]))
    if size <= 1e-9:
        size = 1.0
    cx = (mn[0] + mx[0]) * 0.5
    cy = (mn[1] + mx[1]) * 0.5
    k = size * 30.0

    all_pts = np.vstack([
        pts,
        [cx - k, cy - k],
        [cx + k, cy - k],
        [cx, cy + k],
    ])
    ax = all_pts[:, 0]
    ay = all_pts[:, 1]

    # ================= 空间网格 =================
    # 三角形只增不删（用 alive 标记），网格条目指向 tris 的行号。
    # 惰性删除的代价是会积累死条目，但同一格子里通常只有几个，影响可忽略。
    span_x = float(mx[0] - mn[0])
    span_y = float(mx[1] - mn[1])
    cells_per_axis = max(1, int(math.sqrt(max(n, 1))))
    cell_sz = max(span_x, span_y) / cells_per_axis
    if cell_sz <= 1e-12:
        cell_sz = 1.0
    gx0 = float(mn[0]) - cell_sz
    gy0 = float(mn[1]) - cell_sz
    gw = max(1, int(span_x / cell_sz) + 3)
    gh = max(1, int(span_y / cell_sz) + 3)
    buckets = {}
    big = []                      # 覆盖格子过多的极端三角形，每次全查
    total_cells = gw * gh
    # 一个三角形最多允许登记到「总格子数的 5%」，超过就进 big（否则内存和时间都失控）
    big_cell_limit = max(64, int(total_cells * 0.05))

    cap = 4 * n + 64
    tris = np.empty((cap, 3), dtype=np.int32)
    alive = np.zeros(cap, dtype=bool)
    tris[0] = (n, n + 1, n + 2)
    alive[0] = True
    used = 1

    def _register(row):
        """按外接圆包围盒把三角形登记到网格。

        刻意用标量写：一次插入通常只有 6 个新三角形，
        批量化要建临时数组 + tolist()，实测比逐个算还慢（3135ms vs 2228ms）。
        """
        t0, t1, t2 = int(tris[row, 0]), int(tris[row, 1]), int(tris[row, 2])
        p0x, p0y = float(ax[t0]), float(ay[t0])
        p1x, p1y = float(ax[t1]), float(ay[t1])
        p2x, p2y = float(ax[t2]), float(ay[t2])
        d = 2.0 * (p0x * (p1y - p2y) + p1x * (p2y - p0y) + p2x * (p0y - p1y))
        if abs(d) < 1e-12:
            big.append(row)
            return
        s0 = p0x * p0x + p0y * p0y
        s1 = p1x * p1x + p1y * p1y
        s2 = p2x * p2x + p2y * p2y
        ux = (s0 * (p1y - p2y) + s1 * (p2y - p0y) + s2 * (p0y - p1y)) / d
        uy = (s0 * (p2x - p1x) + s1 * (p0x - p2x) + s2 * (p1x - p0x)) / d
        r = math.hypot(p0x - ux, p0y - uy)
        if not (r == r):                       # NaN 防护
            big.append(row)
            return
        ix0 = int((ux - r - gx0) / cell_sz)
        ix1 = int((ux + r - gx0) / cell_sz)
        iy0 = int((uy - r - gy0) / cell_sz)
        iy1 = int((uy + r - gy0) / cell_sz)
        if ix0 < 0:
            ix0 = 0
        if iy0 < 0:
            iy0 = 0
        if ix1 > gw - 1:
            ix1 = gw - 1
        if iy1 > gh - 1:
            iy1 = gh - 1
        # 只有「覆盖太多格子」的极端退化三角形才进 big 全局表。
        # 早先用「半径 > 3×格子」当阈值，结果随机点集里 8.7% 的三角形都落进 big，
        # 每次查询要翻五千多条 —— 网格白建了，复杂度仍是 O(n²)。
        if (ix1 - ix0 + 1) * (iy1 - iy0 + 1) > big_cell_limit:
            big.append(row)
            return
        for jy in range(iy0, iy1 + 1):
            for jx in range(ix0, ix1 + 1):
                k = (jx, jy)
                lst = buckets.get(k)
                if lst is None:
                    buckets[k] = [row]
                else:
                    lst.append(row)

    _register(0)

    # 插入顺序决定复杂度：按行扫描顺序（调用方 interior_points 就是这么产点的）
    # 是 Bowyer-Watson 的最差输入 —— 空腔平均 21 条边，注册次数暴涨、还长细长三角形。
    # 随机打乱后期望复杂度才回到 O(n log n)，空腔回落到 6 条左右。
    # 固定种子：同一张图重复生成必须得到同一份网格（否则用户改个参数再改回来，
    # 形状会莫名其妙地变一点）。
    order = np.random.default_rng(20240521).permutation(n)

    for step in range(n):
        i = int(order[step])
        # 定期清掉 big 里的死条目：惰性删除会留渣，攒多了查询就退化成全表扫描
        if big and (step & 1023) == 0:
            big[:] = [r for r in big if alive[r]]

        px = float(ax[i])
        py = float(ay[i])

        jx = int((px - gx0) / cell_sz)
        jy = int((py - gy0) / cell_sz)
        near = buckets.get((jx, jy))
        ids = list(near) if near else []
        if big:
            ids.extend(big)
        if not ids:
            continue

        ids_arr = np.fromiter(ids, dtype=np.int64, count=len(ids))
        ids_arr = ids_arr[alive[ids_arr]]
        if len(ids_arr) == 0:
            continue

        view = tris[ids_arr]

        a0 = ax[view[:, 0]] - px
        a1 = ay[view[:, 0]] - py
        b0 = ax[view[:, 1]] - px
        b1 = ay[view[:, 1]] - py
        c0 = ax[view[:, 2]] - px
        c1 = ay[view[:, 2]] - py
        det = ((a0 * a0 + a1 * a1) * (b0 * c1 - b1 * c0)
               - (b0 * b0 + b1 * b1) * (a0 * c1 - a1 * c0)
               + (c0 * c0 + c1 * c1) * (a0 * b1 - a1 * b0))

        bad_mask = det > 0.0
        if not bad_mask.any():
            # 正常不会发生：超级三角形覆盖所有点，至少有一个坏三角形
            continue

        rows_bad = ids_arr[bad_mask]
        bad_tris = view[bad_mask]

        # 坏三角形的边：去掉成对出现的（内部共享边），剩下的是空洞边界
        e_u = np.concatenate([bad_tris[:, 0], bad_tris[:, 1], bad_tris[:, 2]])
        e_v = np.concatenate([bad_tris[:, 1], bad_tris[:, 2], bad_tris[:, 0]])
        key = (np.minimum(e_u, e_v).astype(np.int64) * (n + 16)
               + np.maximum(e_u, e_v).astype(np.int64))
        _, inv, cnt = np.unique(key, return_inverse=True, return_counts=True)
        boundary_mask = cnt[inv] == 1
        bu = e_u[boundary_mask]
        bv = e_v[boundary_mask]

        # 惰性删除坏三角形
        alive[rows_bad] = False

        m = len(bu)
        if m == 0:
            continue

        # 扩容（tris 与 alive 要同步）
        if used + m > cap:
            cap = used + m + 2 * n + 64
            grown = np.empty((cap, 3), dtype=np.int32)
            grown[:used] = tris[:used]
            tris = grown
            grown_alive = np.zeros(cap, dtype=bool)
            grown_alive[:used] = alive[:used]
            alive = grown_alive

        new_t = np.empty((m, 3), dtype=np.int32)
        new_t[:, 0] = bu
        new_t[:, 1] = bv
        new_t[:, 2] = i
        p0 = all_pts[new_t[:, 0]]
        p1 = all_pts[new_t[:, 1]]
        p2 = all_pts[new_t[:, 2]]
        cr = ((p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1])
              - (p1[:, 1] - p0[:, 1]) * (p2[:, 0] - p0[:, 0]))
        flip = cr <= 0.0
        if flip.any():
            new_t[flip] = new_t[flip][:, [1, 0, 2]]

        tris[used:used + m] = new_t
        alive[used:used + m] = True
        for row in range(used, used + m):
            _register(row)
        used += m

    view = tris[:used]
    real = alive[:used] & np.all(view < n, axis=1)
    return [tuple(int(x) for x in t) for t in view[real]]


# --------------------------------------------------------------------------
# 组装
# --------------------------------------------------------------------------

# ==========================================================================
# 格子模式（lattice）：不用 Delaunay，拓扑直接算 —— 改密度能快 6~8 倍
# ==========================================================================
# 格子模式（lattice）的常量 —— build_mesh 用它铺网格，完全绕开 Delaunay
# ==========================================================================

# 抖动幅度（相对 spacing）。实测最佳点：
#   0.00 → 长宽比 1.00、最小角 60°（完美等边，但视觉上像棋盘，太规整）
#   0.12 → 长宽比 1.15、最小角 53.3°（看起来自然随机，质量仍很好）★ 用这个
#   0.30 → 长宽比 1.71、最小角 34.7°（开始出现细长条）
LATTICE_JITTER = 0.12

# 行高 = spacing × sqrt(3)/2，奇数行偏移半格 → 天然形成等边三角形
_ROW_H = 0.8660254037844386

# 边界吸附阈值：离轮廓近于 spacing × 该系数的格点，被吸到轮廓顶点上。
# 0.75 是实测折中：再小边缘缺圈（五角星覆盖率掉到 87.8%），
# 再大则内部格点也被吸走，三角形变歪。
_SNAP_RATIO = 0.75


# 网格在轮廓 bbox 外多铺几格。0 = 正好起始于 bbox（旧行为，最外圈格子的角
# 压在边界上，一丢就整格消失）；1 = 四周各多一格作容错。
# 实测用户那张图 expand=16 时：边距 0 → 侵蚀 5.42%，边距 1 → 0.98%。
_LATTICE_MARGIN_CELLS = 1


# --------------------------------------------------------------------------
# 大 spacing 用 Delaunay 铺大形状（边界点直接来自轮廓）
# --------------------------------------------------------------------------

# spacing 超过它就切 Delaunay。实测（用户 3883×1978 那张图，expand=16）：
#
#   spacing   格子方案面数  格子ms  格子侵蚀%   DEL面数  DELms  DEL侵蚀%
#   139.62        560        7.5     0.1290      1323    6.4    0.0000
#   100.00       1053        2.7     0.0924      1849    5.4    0.0000
#    60.00       2967        4.0     0.0015      3681   11.6    0.0000
#    35.00       8661        8.9     0.0007      9337   21.2    0.0000
#    20.00      26450       20.2     0.0000     26775   58.4    0.0000
#     8.00     165347      118.0       —       165215  395.1      —
#    15.29      45342       28.2       —        45507   95.4      —
#
# 两个方向都很清楚：
#   · spacing 小（≤20）时格子方案侵蚀已经接近 0，且快 3.3 倍 → 继续用格子
#   · spacing 大（≥25）时格子方案侵蚀明显（弦误差），而 Delaunay 点数不多、
#     更快、侵蚀精确为 0 → 用 Delaunay
# 交叉点就在 20~35 之间，取 25 偏保守（照顾速度）。
_DELAUNAY_MIN_SPACING = 25.0

# 【2026-10-22 起它不再决定边界精度】
# 早先边界一律按这个步长（12px）等距加密，充当「边界精度旋钮」。
# 但它在直边上也堆点 —— 那些点落在线段上、不改变几何，只制造细针三角。
# 现在边界精度由 _BOUNDARY_SAG_TOL（弦高）决定，这个常量只剩两个用途：
#   · 内部格点的边界剔除门槛（0.6 × step）
#   · 最小编面面积阈值（step² × 1e-4）
# 两处都只是「量级差不多的尺度量」，不承担精度职责，故保留 12 不变。
_BOUNDARY_STEP_MAX = 12.0

# 边界细分的**弦高容差**（像素）：轮廓被多边形近似时，弦离真实弧最远差多少。
# 这是替代「固定 12px 步长」的精度旋钮 —— 旧写法在直边上也堆点，
# 而那些点落在线段上、不改变几何，纯粹制造细针三角。
#
# 实测（用户图 3883×1978、spacing=139.62，侵/过覆盖在四档 expand 下
# 对 sag 完全不变，所以只看网格质量）：
#
#   sag   expand  面数   边界短边/spacing  细针率  最小角p50  长宽比  烂<20°
#   ───  ──────  ────   ───────────────  ──────  ────────  ──────  ──────
#   —    16      1290       0.09          99.0%     6.0°    10.0    61.4%   ← 旧固定12px
#   1.0  16       636       0.54          26.3%    24.2°     1.9     7.5%
#   1.5  16       608       0.54          21.8%     —        1.7     4.6%
#   2.0  16       594       0.56          20.9%    26.1°     1.7     4.0%
#   3.0  16       577       0.58          10.8%     —        1.7     2.3%
#   2.0  656     1528       0.86          25.0%    26.5°     1.4     2.2%
#
# 尖角形状（五角星+洞，spacing=30/45）：
#   sag=1.5 → 烂<20% 12.0% / 25.7%      sag=2.0 → 11.6% / 20.0%
#   sag=3.0 → 12.1% / 18.6%（小形状上收益趋平，且更高 sag 会开始吃尖角）
#
# 取 2.0：真图上比 1.0 好一截，尖角形状又不明显退步；
# 再往上（3.0）真图还在改善但边际递减，小形状上已无收益。
_BOUNDARY_SAG_TOL = 2.0


def _build_shape_delaunay(big, spacing):
    """大形状：轮廓点当边界顶点 + 内部格子点补满，Delaunay 缝合。

    返回 (points, faces)。

    【为什么这条比格子方案准 —— 2026-10-21】
    格子方案的边界精度被 spacing 卡死：格点只能「吸附」到轮廓上的加密点，
    而一个 spacing 宽的格子里平均只落得下 1~2 个边界点。spacing=139.6 时
    9538px 周长只有 31 个锚点，相邻锚点间走直线，弦误差最大 46.5px，
    直线切进弧内侧 → 用户看到的「边缘侵蚀」（实测 0.129%）。

    这条路线把轮廓直接当顶点（步长 _BOUNDARY_STEP_MAX），所以边界精度
    与 spacing 无关，恒为「轮廓本身的精度」。
    """
    # step 仍留给下面两个用途：内部格点剔除门槛、最小编面面积阈值。
    step = min(_BOUNDARY_STEP_MAX, spacing)
    # 边界点按曲率自适应细分（直边顶到 spacing，弯角按弦高加密）。
    # 旧的固定 12px 会让直边也堆满点，整排点连到同一个内部格点，
    # 形成放射状细针 —— 用户 2026-10-22 截图指的就是这个。
    bpts = []
    for r in big:
        bpts.extend(densify_ring_adaptive(r, spacing, sag_tol=_BOUNDARY_SAG_TOL))
    bpts = np.asarray(bpts, dtype=np.float64)
    if len(bpts) < 3:
        return np.zeros((0, 2)), np.zeros((0, 3), dtype=np.int64)

    # 内部：错排格子，只留离边界足够远的（靠边那圈交给边界点，
    # 否则会出现「内部点紧贴边界点」的细长三角）
    xs = [q[0] for r in big for q in r]
    ys = [q[1] for r in big for q in r]
    row_h = spacing * _ROW_H
    x0, y0 = min(xs), min(ys)
    nx = int((max(xs) - x0) / spacing) + 2
    ny = int((max(ys) - y0) / row_h) + 2
    jj, ii = np.meshgrid(np.arange(ny, dtype=np.float64),
                         np.arange(nx, dtype=np.float64), indexing="ij")
    gx = x0 + ii * spacing + (jj % 2) * (spacing * 0.5)
    gy = y0 + jj * row_h
    grid = np.stack([gx.ravel(), gy.ravel()], axis=1)

    if len(grid):
        inr = points_in_any_ring(grid, big)
        dnn = dist_to_rings_grid(grid, big)
        inner = grid[inr & (dnn > 0.6 * step)]
    else:
        inner = np.zeros((0, 2))

    allp = np.vstack([bpts, inner]) if len(inner) else bpts
    # 去重（边界点可能和内部点撞上）
    allp = np.unique(np.round(allp, 4), axis=0)
    if len(allp) < 3:
        return allp, np.zeros((0, 3), dtype=np.int64)

    tri_idx = delaunay_fast(allp)
    if not len(tri_idx):
        return allp, np.zeros((0, 3), dtype=np.int64)

    T = np.asarray(tri_idx, dtype=np.int64)
    # CDT 算的是凸包，凹处/形状外会被填三角形 → 按重心是否在形状内剔除
    cen = allp[T].mean(axis=1)
    T = T[points_in_any_ring(cen, big)]
    if len(T):
        tp = allp[T]
        ea = np.abs((tp[:, 1, 0] - tp[:, 0, 0]) * (tp[:, 2, 1] - tp[:, 0, 1])
                    - (tp[:, 1, 1] - tp[:, 0, 1]) * (tp[:, 2, 0] - tp[:, 0, 0]))
        T = T[ea > max(1e-9, (step * step) * 1e-4)]
    return allp, T



def _nearest_on_rings_grid(query, allp, radius, want_index=False):
    """在 ``radius`` 内查最近轮廓顶点；网格外的结果返回 inf。

    格子边长取 radius，因此任何一个距离不超过 radius 的点，必然落在
    query 所在格子的 3×3 邻域里。同距时仍取拍平索引最小的点，
    与全量 ``argmin`` 的语义一致。
    """
    query = np.asarray(query, dtype=np.float64)
    allp = np.asarray(allp, dtype=np.float64)
    n_query = len(query)
    n_points = len(allp)
    empty_p = query.copy()
    empty_d = np.full(n_query, np.inf)
    empty_i = np.zeros(n_query, dtype=np.int64)
    if n_query == 0 or n_points == 0:
        return (empty_p, empty_d, empty_i) if want_index else (empty_p, empty_d)

    cell = max(float(radius), 1e-12)
    qi = np.floor(query[:, 0] / cell).astype(np.int64)
    qj = np.floor(query[:, 1] / cell).astype(np.int64)
    pi = np.floor(allp[:, 0] / cell).astype(np.int64)
    pj = np.floor(allp[:, 1] / cell).astype(np.int64)

    # 二维格坐标压成一维 key。先减去公共偏移，避免负坐标和大乘法造成碰撞。
    ci_min = int(min(qi.min(), pi.min()))
    cj_min = int(min(qj.min(), pj.min()))
    width = int(max(qj.max(), pj.max()) - cj_min + 1)
    pkey = (pi - ci_min) * width + (pj - cj_min)
    qkey = (qi - ci_min) * width + (qj - cj_min)

    p_order = np.argsort(pkey, kind="stable")
    pkey_sorted = pkey[p_order]
    upkey, p_start = np.unique(pkey_sorted, return_index=True)
    p_end = np.append(p_start[1:], n_points)

    q_order = np.argsort(qkey, kind="stable")
    qkey_sorted = qkey[q_order]
    uqkey, q_start = np.unique(qkey_sorted, return_index=True)
    q_end = np.append(q_start[1:], n_query)

    q_parts = []
    p_parts = []
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            want = uqkey + di * width + dj
            pos = np.searchsorted(upkey, want)
            pos_c = np.clip(pos, 0, len(upkey) - 1)
            hit = (pos < len(upkey)) & (upkey[pos_c] == want)
            if not hit.any():
                continue

            hit_cells = np.nonzero(hit)[0]
            qs = q_start[hit_cells]
            qe = q_end[hit_cells]
            ps = p_start[pos_c[hit_cells]]
            pe = p_end[pos_c[hit_cells]]
            nq = qe - qs
            npnt = pe - ps
            counts = nq * npnt
            if not counts.any():
                continue

            # 把每个 query-cell × point-cell 展开成笛卡尔积。
            group = np.repeat(np.arange(len(hit_cells)), counts)
            base = np.repeat(np.cumsum(counts) - counts, counts)
            within = np.arange(int(counts.sum())) - base
            npnt_group = npnt[group]
            q_local = within // npnt_group
            p_local = within - q_local * npnt_group
            q_parts.append(q_order[qs[group] + q_local])
            p_parts.append(p_order[ps[group] + p_local])

    if not q_parts:
        return (empty_p, empty_d, empty_i) if want_index else (empty_p, empty_d)

    q_idx = np.concatenate(q_parts)
    p_idx = np.concatenate(p_parts)
    dx = query[q_idx, 0] - allp[p_idx, 0]
    dy = query[q_idx, 1] - allp[p_idx, 1]
    d2 = dx * dx + dy * dy

    best2 = np.full(n_query, np.inf)
    np.minimum.at(best2, q_idx, d2)
    within = best2 <= radius * radius
    if not within.any():
        return (empty_p, empty_d, empty_i) if want_index else (empty_p, empty_d)

    best_i = np.full(n_query, n_points, dtype=np.int64)
    tied = d2 <= best2[q_idx]
    np.minimum.at(best_i, q_idx[tied], p_idx[tied])

    out_p = query.copy()
    out_d = np.full(n_query, np.inf)
    hit_q = np.nonzero(within)[0]
    out_p[hit_q] = allp[best_i[hit_q]]
    out_d[hit_q] = np.sqrt(best2[hit_q])
    if want_index:
        out_i = np.zeros(n_query, dtype=np.int64)
        out_i[hit_q] = best_i[hit_q]
        return out_p, out_d, out_i
    return out_p, out_d


def _nearest_on_rings(query, rings, want_index=False, max_distance=None):
    """给每个 query 点找最近的「轮廓顶点」，返回 (最近点坐标, 距离[, 顶点索引])。

    轮廓点本来就是像素级密的（trace_rings 沿像素边界走），
    所以「最近的轮廓顶点」≈「轮廓上的最近点」，精度足够。

    want_index=True 时额外返回 argmin 索引 —— 调用方本来就要这个索引来
    给「每个轮廓顶点只留一个格点」分组，早先是在外面**又整算了一遍**
    同一份距离矩阵（只为拿索引）。实测 spacing=6 时：
        expand=16  白算 172ms，expand=48  白算 404ms
    现在一次算完，结果逐元素一致。
    """
    allp = np.vstack([np.asarray(r, dtype=np.float64) for r in rings])
    query = np.asarray(query, dtype=np.float64)
    if max_distance is not None and float(max_distance) > 0.0 and len(allp):
        return _nearest_on_rings_grid(
            query, allp, float(max_distance), want_index=want_index
        )
    out_p = np.empty_like(query)
    out_d = np.empty(len(query))
    out_i = np.empty(len(query), dtype=np.int64) if want_index else None
    # 分块算，避免 (query × allp) 的平方距离矩阵爆内存
    step = max(1, 2_000_000 // max(len(allp), 1))
    for s in range(0, len(query), step):
        e = min(s + step, len(query))
        d2 = ((query[s:e, None, 0] - allp[None, :, 0]) ** 2
              + (query[s:e, None, 1] - allp[None, :, 1]) ** 2)
        j = d2.argmin(axis=1)
        out_p[s:e] = allp[j]
        out_d[s:e] = np.sqrt(d2[np.arange(e - s), j])
        if want_index:
            out_i[s:e] = j
    if want_index:
        return out_p, out_d, out_i
    return out_p, out_d


def _drop_faces_in_carve_mask(points, faces, carve_mask):
    """剔掉重心落在手绘「挖掉」区域里的三角形。

    split_outer 会丢掉所有内环（中心不留洞），所以闭合 carve 产生的
    内部洞单靠 rings 表达不出来。这里用引导掩膜再过滤一次：
    只处理引导的负值区域，源图本身的洞不受影响。
    """
    if carve_mask is None or len(faces) == 0:
        return faces
    mask = np.asarray(carve_mask, dtype=bool)
    if mask.ndim != 2 or mask.size == 0:
        return faces

    cen = np.asarray(points, dtype=np.float64)[faces].mean(axis=1)
    h, w = mask.shape
    xi = np.floor(cen[:, 0]).astype(np.int64)
    yi = np.floor(cen[:, 1]).astype(np.int64)
    inside = (xi >= 0) & (xi < w) & (yi >= 0) & (yi < h)

    keep = np.ones(len(faces), dtype=bool)
    keep[inside] = ~mask[yi[inside], xi[inside]]
    return faces[keep]


def build_mesh(rings, spacing, boundary_ratio=0.9, solid_mask=None, carve_mask=None):
    """轮廓 → 网格数据（小间距格子吸附，大间距 Delaunay，碎块扇形）。

    rings: 只放**外环**（洞由调用方在 split_outer 阶段丢弃）
    spacing: 目标边长（像素）
    boundary_ratio / solid_mask: 保留形参以兼容旧调用点，不参与计算
    carve_mask: 手绘「挖掉」区域（原图尺寸 bool），用于把内部洞重新剔出来

    返回 dict：points / faces / stats。

    ==========================================================================
    【为什么换掉 Delaunay —— 用户要「拖滑块实时改密度」】

    3883×1978 那张图、spacing=6px、24.6 万面：
        delaunay_2d_cdt 本体 316 ms  ← mathutils 的 C 实现，换语言也降不下来
        Python 包装          106 ms
    拖 density 滑块实测：0.8 → 141ms，0.9 → 317ms，1.0 → 1084ms（很卡）。

    试过四条 Delaunay 侧的优化，全部失败（别再试）：
        A 合并边表一次广播 18633ms / B remaining 掩膜 2305ms
        C bbox 分桶慢 25 倍 / D bbox 预筛更慢（命中率 98.7% 太高）
    根因是复杂度：Delaunay 是 O(n log n) 且**必须看到全部点**。

    ==========================================================================
    【现在的做法：三块拼起来，全部 O(n)】

    ① 大形状内部：错排格点（行高 spacing×√3/2，奇数行偏移半格）+ 抖动 0.12
       → 每个点周围天然 6 个等边三角形，拓扑按 (i,j) 邻接直接算，无几何计算。

    ② 靠近轮廓的一圈：**吸附到轮廓顶点**（阈值 spacing × 0.75）
       关键：**环外但离轮廓近的格点也要保留并吸附**。
       只留环内点的话边缘会缺一圈 —— 实测五角星覆盖率只 87.8%；
       把外侧近邻吸到轮廓上之后回到 99.2%。

    ③ 小碎块（bbox < 3×spacing）：**扇形三角化**（质心 + 环点连成扇）
       为什么不走格子：碎块比一个格子还小，可能一个格点都落不进去 →
       实测 225 个碎块只有 19.8% 覆盖（等于全丢）。
       扇形是 O(n)，且保得住形状。

    ==========================================================================
    【实测：质量与速度（对比 Delaunay 版）】

    真实图 3883×1978，spacing=6（24.6 万面）：
        方案          面数      长宽比   最小角   <15°烂面   耗时
        Delaunay     246653    1.12     53.1°    0.0%      726 ms
        现在         281392    1.15     53.3°    0.0%      116 ms   ← 快 6.3 倍

    拖 density 滑块的 B 阶段耗时：
        density   Delaunay    现在      倍数
        0.70       65 ms      7.2 ms    9.0x
        0.80      141 ms     16.2 ms    8.7x
        0.90      317 ms     38.4 ms    8.3x
        1.00     1084 ms    120 ms      9.0x

    各种形状的覆盖率（格子方案刚上线时 vs 现在）：
        五角星    70.4% → 99.2%      细长条  49.6% → 98.9%
        225 碎块  19.8% → 99.8%      圆      91.7% → 99.8%
        （最初那版没有吸附和扇形，小形状被大面积吞掉，不能交付）

    ==========================================================================
    【代价：边缘不如 Delaunay 精确】

    边界点现在吸到轮廓顶点上，比纯格子好得多，但不是逐像素贴合
    （Delaunay 版有专门的加密点贴着轮廓走，实测 0.00px）。
    用户看到 AE 木偶工具能实时改密度，明确选择了「追速度、边缘略毛」。
    """
    t_start = time.perf_counter()
    rings = [r for r in rings if len(r) >= 3]
    if not rings or spacing <= 1e-6:
        return {
            "points": np.zeros((0, 2)),
            "faces": np.zeros((0, 3), dtype=np.int64),
            "stats": {"boundary": 0, "inner": 0, "faces": 0,
                      "ms_triangulate": 0.0, "ms_total": 0.0},
        }

    # --- 分环：小碎块 vs 大形状 ---
    small, big = [], []
    for r in rings:
        arr = np.asarray(r, dtype=np.float64)
        w = arr[:, 0].max() - arr[:, 0].min()
        h = arr[:, 1].max() - arr[:, 1].min()
        (small if max(w, h) < spacing * 3.0 else big).append(r)

    pts_list = []
    faces_list = []
    n_off = 0
    n_boundary = 0

    # --- ① 小碎块：扇形三角化 ---
    for r in small:
        arr = np.asarray(r, dtype=np.float64)
        n = len(arr)
        if n < 3:
            continue
        # 质心用顶点平均（碎块很小，凹形导致的偏差可忽略）
        cx, cy = float(arr[:, 0].mean()), float(arr[:, 1].mean())
        pts_list.append(np.vstack([[[cx, cy]], arr]))
        ci = n_off
        fan = [(ci, ci + 1 + k, ci + 1 + (k + 1) % n) for k in range(n)]
        faces_list.append(np.asarray(fan, dtype=np.int64))
        n_off += n + 1
        n_boundary += n

    # --- ②③ 大形状 ---
    #
    # 两条路，按 spacing 分流（取舍依据见 _DELAUNAY_MIN_SPACING 的实测表）：
    #   spacing 大 → Delaunay，边界点直接取轮廓，精度与 spacing 解耦（侵蚀 0）
    #   spacing 小 → 格子+吸附，快 3.3 倍，且这时格子够细、侵蚀本来就接近 0
    if big and spacing >= _DELAUNAY_MIN_SPACING:
        dpts, dfaces = _build_shape_delaunay(big, spacing)
        if len(dpts):
            pts_list.append(dpts)
            faces_list.append(dfaces + n_off)
            n_off += len(dpts)
            n_boundary += len(dpts)
        big = []          # 已处理，别掉进下面的格子逻辑

    if big:
        xs = [q[0] for r in big for q in r]
        ys = [q[1] for r in big for q in r]
        # 【网格要「包住」轮廓，不能正好起始于轮廓 bbox】
        #
        # 早先 x0 = min(xs)：最外一圈格点的外角**正落在轮廓边界上**，
        # 一旦那个角被判成环外、或者投影收口后这一圈格子失去一格，
        # 就会在边缘留下一整格的缺口（spacing 大时肉眼可见的大方块）。
        #
        # 现在四周各多铺一格（_LATTICE_MARGIN_CELLS）。多出来的格子在
        # 环外、投影距离超 cap，会被正常丢掉 —— 但它们给了「跨边界那一圈」
        # 一个容错空间，边界处始终有格子收在轮廓上。
        #
        # 实测（用户 3883×1978，expand=16，spacing=139.6）：
        #     边距 0（起始于 bbox）  侵蚀 5.42%
        #     边距 1                侵蚀 0.98%
        x0, y0 = min(xs) - spacing * _LATTICE_MARGIN_CELLS, min(ys) - spacing * _LATTICE_MARGIN_CELLS
        x1, y1 = max(xs), max(ys)

        row_h = spacing * _ROW_H
        ny = int((y1 - y0) / row_h) + 3 + _LATTICE_MARGIN_CELLS
        nx = int((x1 - x0) / spacing) + 3 + _LATTICE_MARGIN_CELLS
        jj, ii = np.meshgrid(np.arange(ny, dtype=np.float64),
                             np.arange(nx, dtype=np.float64), indexing="ij")
        px = x0 + ii * spacing + (jj % 2) * (spacing * 0.5)
        py = y0 + jj * row_h
        # 固定种子 → 同一张图同一密度每次结果完全一致（可复现）
        rng = np.random.default_rng(0)
        px = px + rng.uniform(-LATTICE_JITTER, LATTICE_JITTER, px.shape) * spacing
        py = py + rng.uniform(-LATTICE_JITTER, LATTICE_JITTER, py.shape) * spacing
        grid = np.stack([px.ravel(), py.ravel()], axis=1)

        dist = dist_to_rings_grid(grid, big)
        inring = points_in_any_ring(grid, big)

        # 环内且离轮廓远 → 普通格点；离轮廓近（含环外）→ 吸附到轮廓
        near = dist < spacing * _SNAP_RATIO

        # ⚠️ 轮廓点可能很稀（smooth 抽稀后平均间距能到 20px 以上），
        #    如果多个格点吸到同一个轮廓顶点，那一带就塌成一个点、形成大洞。
        #    实测：512 星形、spacing=15.29、环只有 69 点（平均间距 20px），
        #    吸附后覆盖率只剩 49.8%。
        #    解法：**每个轮廓顶点只接受一个格点**（取最近的那个）。
        # ① 先把轮廓加密到 spacing 的密度
        #    smooth 抽稀后环点可能很稀（实测 512 星形只有 69 点 / 平均间距 20px），
        #    吸附时多个格点抢同一个顶点，那一带就塌成一个点、形成大洞
        #    （覆盖率 49.8%）。加密后每处都有轮廓点可吸。
        dense_rings = []
        for r in big:
            dense_rings.extend(densify_ring(r, spacing))

        winner_local = None
        if near.any():
            q = grid[near]
            # 一次算完：坐标、距离、argmin 索引全都要。
            # 早先这里把同一份距离矩阵**整算了两遍**（第二遍只为拿索引，
            # 注释还写着「再算一次，代价小」—— 实测 expand=48 时 404ms）。
            near_pts_snap, vdist, vid = _nearest_on_rings(
                q, dense_rings, want_index=True, max_distance=spacing
            )
            order = np.lexsort((vdist, vid))     # 按 vid 分组，组内按距离升序
            vid_s = vid[order]
            first = np.ones(len(vid_s), dtype=bool)
            first[1:] = vid_s[1:] != vid_s[:-1]
            winner_local = np.zeros(len(q), dtype=bool)
            winner_local[order[first]] = True
            # 只有"真的被吸到轮廓上"的才算 winner（距离近到有意义）
            # 阈值：吸附距离不超过 spacing，否则说明附近没有轮廓点，退回原位
            winner_local &= vdist <= spacing

            # 落败的格点退回原位（不吸附），它们仍在环内/环外按 inring 决定去留
            snap_target = q.copy()
            snap_target[winner_local] = near_pts_snap[winner_local]
            grid_snap = grid.copy()
            grid_snap[near] = snap_target
        else:
            grid_snap = grid

        # 【环外的格点只保留「吸附成功」的那些】
        #
        # 早期版本把「环外但离轮廓近」的格点原样保留 → 形状被撑大：
        # 512 星形实测覆盖率 114.9%（超出 15%）。
        # 现在：环外点必须**真的被吸到轮廓顶点上**才留（winner），
        #       没抢到轮廓顶点的环外点直接丢弃。
        # 环内点不受影响（它们在形状里，本来就该留）。
        winner_global = np.zeros(len(grid), dtype=bool)
        if near.any():
            winner_global[np.nonzero(near)[0][winner_local]] = True

        keep_mask = (inring & ~near) | (near & (inring | winner_global))

        # 【这里曾经有一段「把环外格点投影到轮廓线段上」的补丁，已删除】
        #
        # 2026-10-21 加它是为了修「跨边界格子被整格丢弃导致的方形侵蚀」。
        # 它确实有用（那个 bug 是真的：user 图上 2.58% 侵蚀、74 个整格消失），
        # 但**解决办法应该是换更准的三角化，不是给格子打投影补丁** ——
        # 因为投影的成本随「环外格点数 × 环边数」涨，高密度时完全失控：
        #
        #     spacing   投影点数   投影耗时   占 B 阶段
        #     6.00      105817    4651.8ms     80.6%
        #    15.29       17615     790.6ms     80.6%
        #    25.00        7076     279.6ms      —
        #    39.00        3169     156.8ms      —
        #
        # 而它换来的精度收益在高密度下几乎没有：
        #     spacing=6, expand=64：投影开/关侵蚀都是 0.0000%（白花 4.6 秒）
        #     spacing=6, expand= 0：0.2032% → 0.1767%（只降 0.03%）
        #
        # 真正解决问题的做法是把「边界点直接来自轮廓」——
        # 即 spacing 大时走 _build_shape_delaunay（实测侵蚀 0.0000%，
        # 且比格子方案还快）。高密度时格子足够细，本来就不用投影。
        g_in = grid_snap[keep_mask].copy()

        # 吸附后可能出现重合点 → 去掉，否则三角形退化
        if len(g_in) > 1:
            _, ui = np.unique(np.round(g_in, 3), axis=0, return_index=True)
            ui = np.sort(ui)
            if len(ui) != len(g_in):
                keep_idx = np.nonzero(keep_mask)[0]
                sel = np.zeros(len(g_in), dtype=bool)
                sel[ui] = True
                g_in = g_in[sel]
                keep_mask = np.zeros(len(grid), dtype=bool)
                keep_mask[keep_idx[sel]] = True

        gpos = np.full(len(grid), -1, dtype=np.int64)
        gpos[keep_mask] = np.arange(len(g_in))
        R = gpos.reshape((ny, nx))

        # 规则拓扑：每 2×2 拆 2 个三角，按行奇偶决定对角线方向
        a = R[:-1, :-1]
        b = R[:-1, 1:]
        c = R[1:, :-1]
        d = R[1:, 1:]
        even = (np.arange(ny - 1) % 2 == 0)[:, None, None]
        t1 = np.where(even, np.stack([a, b, c], -1), np.stack([a, b, d], -1))
        t2 = np.where(even, np.stack([b, d, c], -1), np.stack([a, d, c], -1))
        Tb = np.concatenate([t1.reshape(-1, 3), t2.reshape(-1, 3)], axis=0)
        Tb = Tb[(Tb >= 0).all(axis=1)]

        pts_list.append(g_in)
        faces_list.append(Tb + n_off)
        n_off += len(g_in)
        n_boundary += int(near.sum())

    if not pts_list:
        return {
            "points": np.zeros((0, 2)),
            "faces": np.zeros((0, 3), dtype=np.int64),
            "stats": {"boundary": 0, "inner": 0, "faces": 0,
                      "ms_triangulate": 0.0, "ms_total": 0.0},
        }

    pts = np.vstack(pts_list)
    T = np.concatenate(faces_list, axis=0)

    # 去掉退化面（抖动/吸附后会产生近乎共线的三点）
    #
    # 【为什么阈值是 spacing²×0.002 而不是 1e-6】
    #
    # 吸附会把多个格点拉到同一个轮廓顶点上，于是出现"边长 0.7px、长 3.7px"的
    # 针状三角形。它们面积近 0、对视觉毫无贡献，却会拖低质量统计：
    #     spacing=59.2 时长宽比>3 的占 9.0%，spacing=16.6 时占 0.9%
    #     （实测这些烂面的最长边中位只有 3.7px，与 spacing 无关 —— 就是吸附残渣）
    # 用 spacing 的平方做尺度过滤，把这类"远小于一个格子的碎渣"清掉。
    # 0.002 相当于"面积小于 spacing² 的 0.2%"，正常三角形面积约 spacing²×0.43，
    # 差 200 倍，不会误伤。
    if len(T):
        tp = pts[T]
        ea = np.abs((tp[:, 1, 0] - tp[:, 0, 0]) * (tp[:, 2, 1] - tp[:, 0, 1])
                    - (tp[:, 1, 1] - tp[:, 0, 1]) * (tp[:, 2, 0] - tp[:, 0, 0]))
        min_area2 = max(1e-6, spacing * spacing * 0.002)
        T = T[ea > min_area2]

    # 手绘 carve 的内部洞：rings 里已经被 split_outer 丢掉了，这里按掩膜
    # 把洞里的三角形补剔一次。放最后是因为它不改变点集，只影响面。
    T = _drop_faces_in_carve_mask(pts, T, carve_mask)

    t_end = time.perf_counter()
    # ⚠️ 返回 numpy 数组，**不转 list[tuple]** ——
    #    实测这一步在 28 万个三角形上要 200ms（占格子模式总耗时 61%）。
    #    消费方都已适配：build._flip_faces 用 faces[:, [0,2,1]].tolist()（48ms）；
    #    len(faces) / for (i,j,k) in faces 天然支持 ndarray。
    return {
        "points": pts,
        "faces": T,
        "stats": {
            "boundary": n_boundary,
            "inner": int(len(pts) - n_boundary),
            "faces": int(len(T)),
            "ms_triangulate": round((t_end - t_start) * 1000.0, 1),
            "ms_total": round((t_end - t_start) * 1000.0, 1),
        },
    }
