"""面板参数。

设计选择：**参数挂在生成出来的网格对象上**，不是全局设置。
理由：同场景里可以对好几张图、用不同参数各生成一份网格，
拖动滑块时改的是「这个对象自己的参数」，不会互相干扰。

面板显示谁，就改谁 —— 用户选中哪个网格，改的就是哪个。
"""

import bpy

from ..ic_core import pipeline as pipe


def _on_change(self, context):
    """任一分法参数变了就重建网格。"""
    from . import ops
    ops.schedule_rebuild(self.id_data, context)


def _on_expand_change(self, context):
    """expand 改了：先钳到当前图的有效上限，再触发重建。"""
    _clamp_expand(self)
    _on_change(self, context)


def _redraw_paths(self, context):
    """只重绘视口，不重建网格（显示开关不该触发计算）。"""
    try:
        wm = context.window_manager if context is not None else bpy.context.window_manager
        for win in wm.windows:
            for area in win.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    except Exception:                                  # noqa: BLE001
        pass


def _poll_mesh(self, obj):
    return obj is not None and obj.type == "MESH"


class IC_GuidePoint(bpy.types.PropertyGroup):
    """钢笔的一个锚点（像素坐标）+ 两个贝塞尔控制柄（相对锚点的偏移）。"""

    x: bpy.props.FloatProperty()
    y: bpy.props.FloatProperty()
    in_dx: bpy.props.FloatProperty(default=0.0)
    in_dy: bpy.props.FloatProperty(default=0.0)
    out_dx: bpy.props.FloatProperty(default=0.0)
    out_dy: bpy.props.FloatProperty(default=0.0)


class IC_GuideStroke(bpy.types.PropertyGroup):
    """一条钢笔画出来的路径（像素坐标，左上原点）。"""

    closed: bpy.props.BoolProperty(default=False)
    enabled: bpy.props.BoolProperty(
        name="启用这条路径",
        description="临时停用但保留路径，方便对比不同引导组合",
        default=True,
    )
    mode: bpy.props.EnumProperty(
        name="圈内",
        description="这条闭合路径圈起来的区域怎么处理；开放路径始终沿线切开",
        items=[
            ("auto", "跟随默认", "使用面板上的「新路径圈内」设置"),
            ("add", "补成实心", "圈起来的地方变成实心"),
            ("carve", "挖掉", "圈起来的地方从形状里挖掉"),
        ],
        default="auto",
    )
    points: bpy.props.CollectionProperty(type=IC_GuidePoint)


# expand 的上限 = 图片长边 × 这个比例（但不小于 EXPAND_MIN_LIMIT）。
# 20% 的依据见 IC_Settings.expand 的注释：实测四种尺寸都是「长边 28% 顶到图边」，
# ⚠️ 别在这里再写一份常量 —— 直接转发到 pipeline。
# 早先 UI 一份、Params 默认值一份，两边漂了之后「UI 生成」和「API 生成」
# 得到不同结果，排查像见鬼。现在 expand_limit 只在 pipeline 里定义一次，
# 那边算 padding margin 也用它，天然一致。
EXPAND_RATIO = pipe.EXPAND_RATIO
EXPAND_MIN_LIMIT = pipe.EXPAND_MIN_LIMIT


def expand_limit(img_long=0):
    """当前图片下，「边缘外扩」的有效上限（像素）。

    img_long=0（还没生成过、不知道图多大）时返回 EXPAND_MIN_LIMIT。
    """
    try:
        L = int(img_long or 0)
    except Exception:
        L = 0
    return pipe.expand_limit(L)


def _clamp_expand(s):
    """把 expand 钳到当前图片的有效上限内。

    Blender 的 IntProperty.max 是**静态**的，没法随图尺寸变。
    所以硬上限设成 512（够大图用的天花板），真正的钳制在这里按图长边做。
    图换小了（或者用户先在小图上把 expand 拉很大、再换成大图/小图），
    越界的值会被拉回来 —— 否则会出现"滑块显示 300 但实际早就顶边无效"。
    """
    lim = expand_limit(getattr(s, "stat_img_long", 0))
    if int(s.expand) > lim:
        s.expand = lim

def _density_to_spacing(v, img_long=0):
    """UI 的 0..1 密度 → 目标边长（像素）。

    这里**必须**显式对齐 pipeline.spacing_from_density 的默认值。
    早先这里传 5.0、函数体内部又 max(6.0, ...) 抬回 6.0 ——
    看起来能跑，实际是「调用方以为自己传的值生效了，其实没有」。
    现在两边都是 6.0，不再有静默改写。
    """
    return pipe.spacing_from_density(v, min_px=6.0, max_px=48.0, image_long_side=img_long)


class IC_Settings(bpy.types.PropertyGroup):
    """挂在网格对象上的一套抠图参数。"""

    source_obj: bpy.props.PointerProperty(
        name="源平面",
        description="这张网格是从哪个平面抠出来的（改它会重建）",
        type=bpy.types.Object,
        poll=_poll_mesh,
        update=_on_change,
    )

    # 源平面的名字（只读，用来区分「从没指定」和「指定过但被删了」）。
    # PointerProperty 指向的对象被删后会被 Blender 自动置空，光看 source_obj
    # 分不清这两种情况，错误提示就会误导用户。
    source_name: bpy.props.StringProperty(
        name="源平面名",
        description="源平面的名字快照（源平面被删时靠它给出准确提示）",
        default="",
    )

    # ---- 形状识别 ----
    threshold: bpy.props.FloatProperty(
        name="透明判定阈值",
        description="alpha 超过这根线的像素算「实心」。调高更瘦，调低更胖。"
                    "边缘有一圈半透明描边看不清时调它",
        default=0.5, min=0.01, max=0.99, precision=2,
        update=_on_change,
    )

    # ---- 轮廓 ----
    tolerance: bpy.props.FloatProperty(
        name="轮廓容差",
        description="顶点抽稀力度（像素）。越大顶点越少、边越直；越小越贴原图。"
                    "实测 512 圆：0.5→52 点，1.5→36 点，3→32 点，6→16 点。"
                    "⚠️ 调到 0.3 以下不会更准多少，但会慢 8 倍（0.1 要 31ms vs 1.5 的 3.7ms）",
        # 【下限为什么从 0.1 抬到 0.5 —— 实测的性能悬崖】
        #
        # 早先注释写「0.1 会产生碎边，实际用处不大，但保留宽范围」。
        # 实测下来不是"用处不大"，是**明确有害**：
        #     512 软边圆，A 阶段耗时 / 顶点数
        #       0.1 → 31.3 ms / 136 点
        #       0.2 → 28.5 ms /  77 点
        #       0.3 → 27.4 ms /  68 点
        #       0.5 → 19.8 ms /  52 点
        #       0.7 → 11.7 ms /  36 点
        #       1.5 →  3.7 ms /  36 点      ← 默认值
        # 0.1 相比 1.5：点数多 3.8 倍，耗时多 8.5 倍。
        # 而这点细节在最终网格上看不出来（面数只从 376 涨到 456，+21%）。
        # 下推到 0.5 仍保留"想要更贴原图"的空间，但砍掉了纯亏的那一段。
        #
        # 上限 12 保留：圆这种简单形状 6 以后确实无变化，但**复杂形状**
        # （五角星）到 20 还在变（56→25→21 点），所以不能因为圆上的表现就砍上限。
        # 【上限为什么从 12 收到 4.05 —— 实测后半段完全冻结】
        #
        # 软边毛刺圆（spacing=16）实测：
        #     tol    环点数  面积比   漏(mask未盖)   面数   A 阶段耗时
        #     0.50     232   102.6%      0.60%       968
        #     1.50     100   102.4%      0.55%       959
        #     4.05      10    99.7%      2.48%       914
        #     8.00      10    99.7%      2.48%       914   ← 和 4.05 完全一样
        #     12.00     10    99.7%      2.48%       914
        # 4.05 以上环点数冻结在 10，拖滑块毫无反应、只会误导用户。
        #
        # 真实大图（3883×1978）上 4.05→12 的 A 阶段耗时只差 2ms（186.3 vs 188.5），
        # 所以收窄不是为了提速，是为了让滑块每一格都有真实效果。
        #
        # 下限 0.5 保留：实测 0.5 相比 1.5 点数多 1.9 倍、耗时多 1.2 倍，
        # 换来漏画从 0.55% 降到 0.60%（反而略高，但边缘更细），想要更贴原图时有用。
        #
        # 【默认值 1.5 → 4.05，且从面板上隐藏（2026-10-22 用户拍板）】
        #
        # 用户原话：「轮廓容差这个参数感觉已经影响不大了，可以设定为 4.05 的
        # 默认值然后把调整参数隐藏掉」。
        #
        # 实测支持这个判断 —— 真实图 3883×1978，expand=0（无外扩掩盖时的影响）：
        #     tol    环点数   面数    漏画      过覆盖
        #     1.50    1511    695   0.1172%   0.0308%
        #     2.50    1479    654   0.1233%   0.0360%
        #     3.00    1475    653   0.1262%   0.0372%
        #     4.05    1481    654   0.1395%   0.0363%
        #   1.5 → 4.05 漏画只差 0.022 个百分点，肉眼看不出来。
        #
        # 唯一有感知差异的是小图尖角（五角星 512、spacing=15.29）：
        #     tol 1.5 → 漏 3.283%      tol 4.05 → 漏 4.054%（差 0.77pp）
        # 权衡后接受：真实素材图上几乎无差，换来面板少一个无效滑块。
        #
        # 属性本身**保留**（不删）：老 .blend 里存的值仍生效，
        # 需要时可从 Python 侧改（obj.image_cutter.tolerance = ...）。
        default=4.05, min=0.5, max=4.05, precision=2,
        update=_on_change,
    )
    expand: bpy.props.IntProperty(
        name="边缘外扩",
        description="轮廓整体往外推几像素，防止边缘裁太紧露出底色。"
                    "⚠️ 这是形态学膨胀：比它窄的细缝会被合上 —— "
                    "实测 1 像素宽的网格线在 expand=1 时就完全消失（100 个环变 1 个）。"
                    "作品里有细缝/细线时，先调到 0 看看。"
                    "（另注：源图镂空会被填实，与本参数无关；手绘『挖掉』除外）",
        # 【上限：按图片尺寸动态算，硬上限只是它的天花板】
        #
        # 用户两次反馈：先"32 拉满了"，我抬到 64，又问"能不能再大点"。
        # 实测确认他是对的 —— expand 是**绝对像素**，大图上根本不够用：
        #
        #   3883×1978 真实人物图：
        #     expand=0   → 442 万实心像素
        #     expand=64  → 461 万（+19 万）  179ms
        #     expand=128 → 479 万（+37 万）  327ms
        #     expand=256 → 515 万（+72 万）  575ms
        #     expand=384 → 549 万（+107 万） 903ms   ← 到 384 仍线性有效
        #
        #   而 512 小图上，expand=160 就把半径 100 的圆撑到顶屏幕边了 ——
        #   再大纯属无效区间。
        #
        # 也就是说「最大能给多少」取决于图有多大，一个固定数字必然有一头错。
        #
        # 【反推出的规律】四种尺寸（256/512/1024/2048）各二分找「刚好顶到图边」
        # 的 expand，结果高度一致：
        #     256  → 71  （长边 28%）
        #     512  → 143 （28%）
        #     1024 → 286 （28%）
        #     2048 → 573 （28%）
        # 这是几何必然：形状占半幅时，外扩到长边 28% 就填满半幅剩的边距。
        #
        # 所以上限取「长边 × 20%」（留 8% 余量，因为真实素材形状大小不一），
        # 但不小于 64px（小图别缩得太狠）。
        #     → 256 图: 64px      512 图: 102px
        #     → 1024 图: 205px    3883 图: 777px
        #
        # 实现说明：Blender 的 IntProperty.max 是静态的，没法跟着图尺寸变。
        # 所以硬上限设成 1024（够 4096 图用的天花板；3883 图的动态上限是 777，
        # 曾经设成 512 结果大图根本够不着），真正的钳制在 update 回调里
        # 按当前图长边做 —— 见 _clamp_expand()。面板上会显示当前有效上限。
        default=0, min=0, max=1024,
        update=_on_expand_change,
    )
    # 【2026-10-21 移除「拐角圆滑」滑块】
    #
    # 它原本是「磨掉像素楼梯」。实测真实图（3883×1978 软边）各档：
    #     smooth  环点数  面数    覆盖率    面积变化   A 阶段耗时
    #     0        1481   44238  99.82%   +0.00%     177.9 ms
    #     2        1478   44125  99.81%   -0.04%     196.2 ms
    #     12       1477   44204  99.72%   -0.15%     318.8 ms
    # 拖滑块看不出差别，拖到 12 却要多花 141 ms 重算 A 阶段（卡顿）。
    # 而且换成格子网格后，边缘形状由「格点吸附到轮廓」决定，
    # 平滑原始环点的收益已经被稀释掉了。
    #
    # 锯齿问题现在的解法是「轮廓容差调小」——留着点更密，边缘自然更细。

    # ---- 网格 ----
    density: bpy.props.FloatProperty(
        name="网格密度",
        description="往里拖 = 三角形更密更贴细节。"
                    "每 +0.1 面数约 ×1.5（等比映射，不会在某一段突然变多变少）",
        default=0.55, min=0.0, max=1.0, precision=3, subtype="FACTOR",
        update=_on_change,
    )

    # ---- 引导（钢笔） ----
    guide_mode: bpy.props.EnumProperty(
        name="新路径圈内",
        description="新建闭合路径默认怎么处理；已画路径可在下方逐条切换",
        items=[
            ("add", "补成实心", "圈起来的地方变成实心（自动没认出来的部分，手动补上）"),
            ("carve", "挖掉", "圈起来的地方从形状里挖掉（自动多认的部分，手动切掉）"),
        ],
        default="add",
        update=_on_change,
    )
    guide_enabled: bpy.props.BoolProperty(
        name="启用引导",
        description="关掉就用纯自动结果（画好的路径不会丢）",
        default=True,
        update=_on_change,
    )
    guide_show: bpy.props.BoolProperty(
        name="视口显示路径",
        description="在 3D 视口里叠加显示所有已画路径（只影响显示，不影响结果）",
        default=True,
        update=_redraw_paths,
    )
    strokes: bpy.props.CollectionProperty(type=IC_GuideStroke)
    guide_ver: bpy.props.IntProperty(default=0)

    # ---- 状态回显（只读，给面板显示） ----
    stat_faces: bpy.props.IntProperty(default=0)
    stat_points: bpy.props.IntProperty(default=0)
    stat_rings: bpy.props.IntProperty(default=0)
    stat_edge: bpy.props.StringProperty(default="")
    stat_edge_ratio: bpy.props.FloatProperty(default=0.0)
    # 内环数量（源图洞 + 手绘挖洞）。源图洞会填实，手绘闭合 carve 会保留。
    # 面板据此明确告知，避免用户以为是某参数没调好。
    stat_inner: bpy.props.IntProperty(default=0)
    # 最大那个环占总面积的比例（0~1）。
    # 用途：判断「环很多」到底是"碎成一堆小块"还是"一个主体带一堆发丝碎屑"。
    # 实测真实人物贴图有 210 个外环，但最大环占 99.99% —— 那是正常的
    # 头发丝碎屑，不是失败现场，不该提示用户去调 expand。
    stat_dominant: bpy.props.FloatProperty(default=0.0)
    # 所有环的周长之和（像素）。用于给「预估面数」兜一个下限 ——
    # 细长形状（1px 线）的实际三角形是沿边界的细长条，面积远小于 spacing²×0.43，
    # 只按面积估会低估 200 倍（实测 1px 横线估 27 面 / 实际 5600 面）。
    stat_perimeter: bpy.props.FloatProperty(default=0.0)
    # （曾有一个 stat_alpha_soft 字段想记录「alpha 有多少中间灰度」，
    #  后来发现 stat_edge_ratio 已经表达了同一件事 —— 它就是轮廓附近
    #  alpha 落在中间地带的比例，接近 0 = 纯硬边。同一个事实两个字段是冗余，
    #  删掉。死字段留着比删掉更贵：下次有人读代码会以为它在被使用。）
    stat_ms_a: bpy.props.FloatProperty(default=0.0)
    # 最近一次精确阶段 A 的耗时。拖动 threshold / expand 时用它决定
    # 粗预览要不要降采样，以及降几倍。
    stat_ms_a_full: bpy.props.FloatProperty(default=0.0)
    stat_ms_b: bpy.props.FloatProperty(default=0.0)
    # 最近一次**完整密度**的 B 阶段耗时。预览帧会按它自动放大粗网格，
    # 避免 4K 高密度时固定 2.2 倍仍然每帧卡几百毫秒。
    stat_ms_b_full: bpy.props.FloatProperty(default=0.0)
    # 拖动滑块时的临时粗网格。停手后会自动做一次精确重建并清掉。
    stat_preview: bpy.props.BoolProperty(default=False)
    # 形状面积（像素²），面板用它预估「这个密度会铺多少面」
    stat_area: bpy.props.FloatProperty(default=0.0)
    # 源贴图的长边像素数。
    # 用途：密度=0 的「最粗」要按图片尺寸缩放 —— 48px 固定值在 3883 宽的图上
    # 只占 1.2%，用户拉到底还是嫌密（实测 2224 面）。
    # 0 表示还没生成过（此时按 48px 的保守下限走）。
    stat_img_long: bpy.props.IntProperty(default=0)
    # 原图宽高：视口里的引导路径叠加层要按它换算像素 → 屏幕坐标。
    stat_img_w: bpy.props.IntProperty(default=0)
    stat_img_h: bpy.props.IntProperty(default=0)
    last_error: bpy.props.StringProperty(default="")
    built: bpy.props.BoolProperty(default=False)

    def spacing(self):
        return _density_to_spacing(self.density, self.stat_img_long)

    def params(self):
        return pipe.Params(
            threshold=float(self.threshold),
            tolerance=float(self.tolerance),
            expand=int(self.expand),
            spacing=_density_to_spacing(self.density, self.stat_img_long),
            guide_mode=self.guide_mode,
            guide_enabled=bool(self.guide_enabled),
        )
