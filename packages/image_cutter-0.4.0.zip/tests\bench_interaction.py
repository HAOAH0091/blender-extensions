# -*- coding: utf-8 -*-
"""交互重建基准：量化拖滑块时每一帧到底花在哪里。

    blender --background --factory-startup --python tests/bench_interaction.py

输出三类数字：
  · density 精确重建（阶段 A 命中，只跑 B + 写网格）
  · density 预览帧（当前策略：粗 spacing）
  · threshold 预览帧 / 停手精确帧（阶段 A 失效）
"""

import os
import statistics
import sys
import time

import numpy as np

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG)
for path in (ADDONS, PKG, HERE):
    if path not in sys.path:
        sys.path.insert(0, path)

import fixture
import image_cutter
if not hasattr(bpy.types.Object, "image_cutter"):
    image_cutter.register()

from image_cutter.ic_core import mask as mask_mod
from image_cutter.ic_core import outline as outline_mod
from image_cutter.ic_ui import ops


def _make_image(name, size):
    rgba = fixture.make_rgba(size, size, soft=True, with_hole=True, with_dot=True)
    image = bpy.data.images.new(name, width=size, height=size, alpha=True)
    image.pixels.foreach_set(fixture.to_blender_pixels(rgba).ravel())
    image.pack()
    return image


def _make_plane(name, image):
    bpy.ops.mesh.primitive_plane_add(size=2.0)
    plane = bpy.context.active_object
    plane.name = name
    mat = bpy.data.materials.new(name + "_mat")
    tex = mat.node_tree.nodes.new("ShaderNodeTexImage")
    tex.image = image
    for node in mat.node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            mat.node_tree.links.new(tex.outputs["Color"], node.inputs["Base Color"])
            break
    plane.data.materials.append(mat)
    return plane


def _timed_preview(obj, count):
    times = []
    for i in range(count):
        obj.image_cutter.density = 0.80 + (i % 11) * 0.02
        t0 = time.perf_counter()
        ops.rebuild_object(obj, bpy.context, preview=True)
        times.append((time.perf_counter() - t0) * 1000.0)
    return times


def _timed_exact(obj, count):
    times = []
    for i in range(count):
        obj.image_cutter.density = 0.90 + i * 0.05
        t0 = time.perf_counter()
        ops.rebuild_object(obj, bpy.context, preview=False)
        times.append((time.perf_counter() - t0) * 1000.0)
    return times


def _summary(name, values):
    if not values:
        return
    ordered = sorted(values)
    p95 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.95))]
    print("%-22s median=%6.1fms  p95=%6.1fms  max=%6.1fms"
          % (name, statistics.median(values), p95, max(values)))


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    image = _make_image("BenchImage", 4096)
    plane = _make_plane("BenchPlane", image)
    for obj in bpy.data.objects:
        obj.select_set(False)
    plane.select_set(True)
    bpy.context.view_layer.objects.active = plane

    t0 = time.perf_counter()
    bpy.ops.image_cutter.generate()
    print("\nfirst_generate=%.1fms" % ((time.perf_counter() - t0) * 1000.0))

    obj = bpy.data.objects.get("BenchPlane_cutout")
    if obj is None:
        raise RuntimeError("基准场景生成失败")

    _summary("density exact", _timed_exact(obj, 8))
    _summary("density preview", _timed_preview(obj, 24))

    _timed_exact(obj, 1)
    threshold_preview = []
    for i in range(8):
        obj.image_cutter.threshold = 0.42 + i * 0.02
        t0 = time.perf_counter()
        ops.rebuild_object(obj, bpy.context, preview=True)
        threshold_preview.append((time.perf_counter() - t0) * 1000.0)
    _summary("threshold preview", threshold_preview)

    threshold_exact = []
    for i in range(4):
        obj.image_cutter.threshold = 0.44 + i * 0.03
        t0 = time.perf_counter()
        ops.rebuild_object(obj, bpy.context, preview=False)
        threshold_exact.append((time.perf_counter() - t0) * 1000.0)
    _summary("threshold exact", threshold_exact)

    settings = obj.image_cutter
    print("\nfaces=%d points=%d rings=%d stage_a=%.1fms stage_b=%.1fms"
          % (settings.stat_faces, settings.stat_points, settings.stat_rings,
             settings.stat_ms_a, settings.stat_ms_b))
    ent = ops._IMG_CACHE.get(ops._CACHE.get("img_key"))
    if ent is not None and ent.get("stage_a") is not None:
        print("stage_a_breakdown=%r" % (ent["stage_a"].ms,))
        alpha = ent["alpha"]
        t0 = time.perf_counter()
        mask, _stats = mask_mod.build_mask(alpha, 0.5)
        print("mask_build=%.1fms" % ((time.perf_counter() - t0) * 1000.0))
        t0 = time.perf_counter()
        _style, _ratio = mask_mod.edge_style(alpha, mask)
        print("edge_style=%.1fms" % ((time.perf_counter() - t0) * 1000.0))
        t0 = time.perf_counter()
        rings = outline_mod.trace_rings(mask)
        print("trace_rings=%.1fms / %d rings"
              % ((time.perf_counter() - t0) * 1000.0, len(rings)))
        from image_cutter.ic_core import pipeline as pipe
        t0 = time.perf_counter()
        _small = pipe._downsample_alpha_block(alpha, 3)
        print("downsample3=%.1fms shape=%r"
              % ((time.perf_counter() - t0) * 1000.0, _small.shape))
        t0 = time.perf_counter()
        pipe.run_stage_a_preview(
            alpha, settings.params(), None, "bench-preview", factor=3
        )
        print("stage_a_preview3=%.1fms"
              % ((time.perf_counter() - t0) * 1000.0))


if __name__ == "__main__":
    main()
