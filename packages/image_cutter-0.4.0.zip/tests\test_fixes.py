# -*- coding: utf-8 -*-
"""P0/P1 修复的回归测试。

    blender --background --factory-startup --python tests/test_fixes.py

每条都对应一个真实踩到的 bug，注释里写明「改回旧代码会怎样」——
这样以后谁把它改回去，测试会立刻红，而不是等用户来报。

覆盖：
  P0-1 用户同名对象不被覆盖
  P0-2 旋转平面的偏移沿局部法线
  P0-3 密度拉满的性能（阶段 B 亚秒级）
  P1-4 引导关闭时 guide_ver 不影响阶段 A 缓存键
  P1-9 缓存可释放
"""
import io
import math
import os
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG)
for _p in (ADDONS, PKG, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from image_cutter.ic_core import pipeline as pipe   # noqa: E402
from image_cutter.ic_core import simplify as simp_mod   # noqa: E402

import image_cutter                                        # noqa: E402
if not hasattr(bpy.types.Object, "image_cutter"):
    image_cutter.register()

import fixture                                             # noqa: E402
from image_cutter.ic_ui import ops as icops                # noqa: E402
from mathutils import Vector                               # noqa: E402

PASS = 0
FAIL = 0


def check(cond, label, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  [PASS] %s   %s" % (label, detail))
    else:
        FAIL += 1
        print("  [FAIL] %s   %s" % (label, detail))


def make_img(name, w=256, h=256):
    from fixture import make_rgba, to_blender_pixels
    rgba = make_rgba(w, h, soft=True, with_hole=True, with_dot=True)
    img = bpy.data.images.new(name, width=w, height=h, alpha=True)
    img.pixels.foreach_set(to_blender_pixels(rgba).ravel())
    img.pack()
    return img


def make_plane(name, img, rot=(0, 0, 0), size=2.0):
    import math
    bpy.ops.mesh.primitive_plane_add(size=size, rotation=rot)
    p = bpy.context.active_object
    p.name = name
    m = bpy.data.materials.new(name + "_mat")
    if m.node_tree is None:
        m.use_nodes = True
    nt = m.node_tree
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    for n in m.node_tree.nodes:
        if n.type == "BSDF_PRINCIPLED":
            m.node_tree.links.new(tex.outputs["Color"], n.inputs["Base Color"])
            break
    p.data.materials.append(m)
    return p


def only(o):
    for x in bpy.data.objects:
        x.select_set(False)
    if o:
        o.select_set(True)
        bpy.context.view_layer.objects.active = o


def safe(op, **kw):
    try:
        return getattr(bpy.ops.image_cutter, op)(**kw)
    except RuntimeError as e:
        return {"_err": str(e)}


print("=" * 74)
print("P0/P1 修复回归测试")
print("=" * 74)

# ==========================================================================
print("\n[P0-1] 用户同名对象不被覆盖")
print("  旧行为：直接 bpy.data.objects.get('X_cutout') 复用 → 用户的网格被灌成抠图结果")
print("  验证点：用户对象顶点数不变、自定义属性还在、插件另建 .001")

bpy.ops.wm.read_factory_settings(use_empty=True)
img = make_img("T1")
p = make_plane("P", img)

me = bpy.data.meshes.new("user_mesh")
me.from_pydata([(0, 0, 0), (1, 0, 0), (0, 1, 0)], [], [(0, 1, 2)])
me.update()
user_obj = bpy.data.objects.new("P_cutout", me)
bpy.context.scene.collection.objects.link(user_obj)
user_obj["my_data"] = "重要数据"

only(p)
safe("generate")

after = bpy.data.objects.get("P_cutout")
check(after is user_obj, "用户对象还是原来那个", "同一对象=%s" % (after is user_obj))
check(len(after.data.vertices) == 3, "用户对象顶点没被改", "顶点=%d（应为 3）" % len(after.data.vertices))
check(after.get("my_data") == "重要数据", "用户自定义属性还在", repr(after.get("my_data")))

gen = [o.name for o in bpy.data.objects if o.get("ic_generated")]
check(len(gen) == 1 and gen[0] != "P_cutout", "插件另建了不冲突的对象", str(gen))

# ==========================================================================
print("\n[P0-2] 旋转平面的偏移沿局部法线")
print("  旧行为：obj.location.z += 0.001（世界 Z）→ 侧立平面偏移沿法线分量为 0 → z-fighting")
print("  验证点：0° / 45° / 90° 三种朝向，沿法线分量都 > 0，垂直分量都 ≈ 0")

bpy.ops.wm.read_factory_settings(use_empty=True)
img2 = make_img("T2")
import math
for ang in (0, 45, 90):
    pr = make_plane("R%d" % ang, img2, rot=(math.radians(ang), 0, 0))
    only(pr)
    safe("generate")
    rc = bpy.data.objects.get("R%d_cutout" % ang)
    if rc is None:
        check(False, "%d° 平面生成了" % ang, "没生成")
        continue
    n = pr.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
    n.normalize()
    off = rc.matrix_world.translation - pr.matrix_world.translation
    along = off.dot(n)
    perp = (off - n * along).length
    check(along > 1e-5, "%d° 沿法线有偏移" % ang, "%.6f" % along)
    check(perp < 1e-6, "%d° 没有侧向漂移" % ang, "%.6f" % perp)

# ==========================================================================
print("\n[P0-3] 密度拉满的性能")
print("  旧行为：interior_points 逐点逐段 Python 循环 + Delaunay O(n²) → 15.5 秒")
print("  验证点：1024² 贴图 density=1.0 在 6 秒内完成（原 15.5s，改后约 2.2s）")

bpy.ops.wm.read_factory_settings(use_empty=True)
import numpy as np
W = H = 1024
yy, xx = np.mgrid[0:H, 0:W]
cx, cy = W * 0.5, H * 0.5
rr = min(W, H) * 0.42
dd = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
aa = np.clip((rr - dd) / 3.0 + 0.5, 0, 1).astype(np.float32)
rgba = np.zeros((H, W, 4), dtype=np.float32)
rgba[:, :, 0] = 0.8
rgba[:, :, 1] = 0.4
rgba[:, :, 2] = 0.5
rgba[:, :, 3] = aa
big = bpy.data.images.new("Big", width=W, height=H, alpha=True)
big.pixels.foreach_set(rgba[::-1].ravel())
big.pack()
bp = make_plane("B", big)
only(bp)
t0 = time.perf_counter()
safe("generate")
first_ms = (time.perf_counter() - t0) * 1000
check(first_ms < 3000, "首次生成 < 3s", "%.0fms" % first_ms)

bc = bpy.data.objects.get("B_cutout")
if bc:
    s = bc.image_cutter
    s.density = 1.0
    t0 = time.perf_counter()
    icops.rebuild_object(bc, bpy.context, force=True)
    hard_ms = (time.perf_counter() - t0) * 1000
    faces = len(bc.data.polygons)
    # 性能改造后（Delaunay 走 mathutils C 实现），density=1.0 应该远快于 6 秒。
    # 判据收紧到 3000ms：留足机器差异余量，同时真的能抓住性能退化
    # （改前实测 2488ms，改后 ~180ms，中间的差距足够大）。
    check(hard_ms < 3000, "density=1.0 < 3s", "%.0fms / %d 面" % (hard_ms, faces))
    # 面数门槛：density 映射从线性改成等背后，1.0 对应 spacing 6px（原 5px），
    # 面数是旧值的 ~60%。这里验证的是「确实铺了足够多的面」而不是具体数值。
    check(faces > 20000, "高密度确实生成了大量面", "%d 面" % faces)

# ==========================================================================
print("\n[P1-4] 引导关闭时 guide_ver 不影响阶段 A 缓存键")
print("  旧行为：key 里无条件带 guide_ver → 引导关着改无关参数也重算阶段 A")
print("  验证点：guide_enabled=False 时递增 guide_ver，阶段 A 键不变")

bpy.ops.wm.read_factory_settings(use_empty=True)
img3 = make_img("T3")
p3 = make_plane("P3", img3)
only(p3)
safe("generate")
c3 = bpy.data.objects.get("P3_cutout")
if c3:
    s3 = c3.image_cutter
    s3.guide_enabled = False
    params = s3.params()
    key_before = params.stage_a_key("imgX", s3.guide_ver)
    s3.guide_ver = int(s3.guide_ver) + 1
    key_after = params.stage_a_key("imgX", s3.guide_ver)
    check(key_before == key_after, "guide_ver 变化不改键（引导关）", "%s vs %s" % (key_before, key_after))

    # 引导开着时应该变（params 是快照，改了开关必须重新取）
    s3.guide_enabled = True
    params_on = s3.params()
    k1 = params_on.stage_a_key("imgX", 1)
    k2 = params_on.stage_a_key("imgX", 2)
    check(k1 != k2, "引导开着时 guide_ver 会改键（该重算就重算）", "%s vs %s" % (k1, k2))

# ==========================================================================
print("\n[P1-9] 缓存可释放")
print("  旧行为：模块级 _CACHE 只有一张图的槽，且删了对象也不清")
print("  验证点：release_cache() 后 alpha 为 None、占用归零")

bpy.ops.wm.read_factory_settings(use_empty=True)
img4 = make_img("T4")
p4 = make_plane("P4", img4)
only(p4)
safe("generate")
mb_before = icops.cache_footprint_mb()
check(mb_before > 0, "生成后缓存里确实有图", "%.2f MB" % mb_before)
slots_before = icops.cache_slot_count()
check(slots_before > 0, "缓存里有槽位", "%d 个" % slots_before)
icops.release_cache()
check(icops.cache_slot_count() == 0, "release_cache 清空了所有槽", "%d 个" % icops.cache_slot_count())
check(icops.cache_footprint_mb() == 0.0, "占用归零", "%.2f MB" % icops.cache_footprint_mb())

# ==========================================================================
print("\n[P1-3] 多对象交替编辑时 A 阶段不该互相击穿")
print("  旧行为：_CACHE 只有一个槽，A、B 两个对象交替点 → 每次都要重算 A 阶段")
print("  验证点：两个对象各自保留自己的 A 阶段结果；缓存槽数有上限")

bpy.ops.wm.read_factory_settings(use_empty=True)
icops.release_cache()

# 造两个不同图的平面。
# 用**不同尺寸**来保证 image_key 不同 —— 早先试过改写 pixels 内容，
# 512² 图写回 tolist() 要几十秒，直接把测试拖到超时（踩过一次）。
_img_a = make_img("T_LRU_A", 256, 256)
_img_b = make_img("T_LRU_B", 192, 192)

_pa = make_plane("LRU_A", _img_a)
_pb = make_plane("LRU_B", _img_b)

only(_pa)
safe("generate")
gen_a = [o for o in bpy.data.objects if o.get("ic_generated") and o.name.startswith("LRU_A")]
only(_pb)
safe("generate")
gen_b = [o for o in bpy.data.objects if o.get("ic_generated") and o.name.startswith("LRU_B")]

check(len(gen_a) == 1 and len(gen_b) == 1, "两个对象都生成成功",
      "A=%d B=%d" % (len(gen_a), len(gen_b)))

if gen_a and gen_b:
    _ga, _gb = gen_a[0], gen_b[0]

    # 【判据必须看「槽里有几个」而不是「耗时变没变」】
    #
    # 早先用 stat_ms_a 比前后是否相同来判命中 —— 注入「上限=1（等价单槽）」
    # 后测试照样全过，因为两张图都是小图，重算一次也就几毫秒，
    # stat_ms_a 的差异落不到浮点比较能分辨的程度。没有判别力。
    #
    # 改成直接查缓存槽的 key 集合：两图交替访问后必须都还在里面。
    only(_ga)
    icops.rebuild_object(_ga, bpy.context, force=False)
    _slots_after_a = icops.cache_slot_count()

    only(_gb)
    icops.rebuild_object(_gb, bpy.context, force=False)
    _slots_after_b = icops.cache_slot_count()

    # 关键断言：访问过 A 和 B 之后，缓存里应该有 2 个槽（单槽实现只会剩 1 个）
    check(_slots_after_a >= 1, "访问 A 后缓存有槽", "%d 个" % _slots_after_a)
    check(_slots_after_b >= 2,
          "交替访问 A/B 后缓存保留两个槽（单槽实现只剩 1 个）",
          "%d 个" % _slots_after_b)

    # 再切回 A：槽数不该掉（说明 A 没被挤掉）
    only(_ga)
    icops.rebuild_object(_ga, bpy.context, force=False)
    check(icops.cache_slot_count() >= 2,
          "再切回 A 时 A/B 两个槽都还在",
          "%d 个" % icops.cache_slot_count())
    check(icops.cache_slot_count() <= icops._CACHE_MAX_IMAGES,
          "缓存槽数不超上限", "%d / %d" % (icops.cache_slot_count(), icops._CACHE_MAX_IMAGES))

# 造超过上限的图，验证 LRU 淘汰
for _k in range(icops._CACHE_MAX_IMAGES + 2):
    _im = make_img("T_LRU_%d" % _k, 64, 64)
    _pl = make_plane("LRU_X%d" % _k, _im)
    only(_pl)
    safe("generate")
check(icops.cache_slot_count() <= icops._CACHE_MAX_IMAGES,
      "超过上限后 LRU 会淘汰（槽数不溢出）",
      "%d / %d" % (icops.cache_slot_count(), icops._CACHE_MAX_IMAGES))
icops.release_cache()

# ==========================================================================
print("\n[P1-5] 源平面被删时，错误文案要准确")
print("  旧行为：PointerProperty 被自动置空 → 提示「还没指定源平面」（用户明明指定过）")
print("  验证点：提示里带「已被删除」且能说出源平面名字")

bpy.ops.wm.read_factory_settings(use_empty=True)
img5 = make_img("T5")
p5 = make_plane("SrcGone", img5)
only(p5)
safe("generate")
c5 = bpy.data.objects.get("SrcGone_cutout")
if c5:
    check(c5.image_cutter.source_name == "SrcGone", "生成时记下了源平面名字",
          repr(c5.image_cutter.source_name))
    faces_before = len(c5.data.polygons)
    src_obj = c5.image_cutter.source_obj
    bpy.data.objects.remove(src_obj, do_unlink=True)
    ok5, msg5 = icops.rebuild_object(c5, bpy.context)
    check(ok5 is False, "重建失败（源平面没了）", str(ok5))
    check("已被删除" in msg5, "文案说清是「已被删除」", msg5)
    check("SrcGone" in msg5, "文案说出了源平面名字", msg5)
    check(len(c5.data.polygons) == faces_before, "旧网格保留不丢",
          "%d → %d" % (faces_before, len(c5.data.polygons)))
else:
    check(False, "生成成功", "没生成")

# ==========================================================================
print("\n[性能] 手绘引导栅格化：开放路径不该卡死")
print("  旧行为：2048² 图开放路径 120 点 → 45 秒（每段都拿全图算距离）")
print("  验证点：2048² 图开放路径必须在 1 秒内完成")

from image_cutter.ic_core import guide as guide_mod  # noqa: E402

# 模拟钢笔手画出来的曲线：120 个采样点（典型的一条路径）
_curve = [(200.0 + i * 12.0, 800.0 + 300.0 * math.sin(i * 0.1)) for i in range(120)]
t0 = time.perf_counter()
_gm_open = guide_mod.rasterize([(_curve, False)], 2048, 2048)
open_ms = (time.perf_counter() - t0) * 1000
check(open_ms < 1000, "2048² 开放路径 < 1s", "%.0fms" % open_ms)
check(int((_gm_open != 0).sum()) > 100, "开放路径确实标了东西",
      "%d 像素" % int((_gm_open != 0).sum()))

# 闭合路径同样要快
_rect = [(400.0, 400.0), (1600.0, 400.0), (1600.0, 1600.0), (400.0, 1600.0)]
t0 = time.perf_counter()
_gm_closed = guide_mod.rasterize([(_rect, True)], 2048, 2048)
closed_ms = (time.perf_counter() - t0) * 1000
check(closed_ms < 200, "2048² 闭合矩形 < 200ms", "%.0fms" % closed_ms)
check(int((_gm_closed > 0).sum()) > 1000000, "闭合矩形确实填满了内部",
      "%d 像素" % int((_gm_closed > 0).sum()))

# 封闭环把两端连起来会变成环 —— 这个必须没有
check(_gm_open[1000, 1000] == 0, "开放路径没有闭合成环", "%d" % _gm_open[1000, 1000])

# ==========================================================================
print("\n[性能] 三角化后端")
print("  验证点：Blender 里应走 mathutils 的 C 实现（比纯 Python 快几十倍）")

from image_cutter.ic_core import triangulate as tri_mod  # noqa: E402

check(tri_mod.backend_name() == "mathutils-cdt",
      "三角化走 mathutils C 实现", tri_mod.backend_name())

# 后端名必须能在面板上看到 —— 否则用户遇到「同事机器快 40 倍」时无从排查
from image_cutter.ic_ui import panels as _panels_mod   # noqa: E402

_draw_src = _panels_mod.IC_PT_Main._draw_impl.__code__.co_names
check("backend_name" in _draw_src, "面板 draw 里调用了 backend_name()", "co_names 含 backend_name")

# 直接压性能：1 万个随机点应在 1 秒内
_pts = np.random.default_rng(7).random((10000, 2)) * 1000.0
t0 = time.perf_counter()
_tris = tri_mod.delaunay_fast(_pts)
fast_ms = (time.perf_counter() - t0) * 1000
check(fast_ms < 1000, "1 万点 Delaunay < 1s", "%.0fms / %d 三角" % (fast_ms, len(_tris)))
check(len(_tris) > 15000, "输出三角形数量合理（约 2n）", "%d" % len(_tris))

# ==========================================================================
print("\n[性能] 拖密度滑块时不能重算引导栅格化")
print("  旧行为：build_guide_mask 写在缓存判断外面，每次 rebuild 都白算一遍")
print("          4K 图 + 10 条引导 = 每次 588ms → 滑块从 327ms 变 1431ms（4.4 倍）")
print("  验证点：引导开启时拖 density，A 阶段必须命中缓存（stat_ms_a 冻结）")

bpy.ops.wm.read_factory_settings(use_empty=True)
# 用 1024² 而不是 256²：引导栅格化的成本跟图面积成正比，
# 小图上「白算一次」只要几毫秒，测试就没有判别力（实测：256² 时注入 bug 抓不到）。
# 1024² + 5 条路径的白算约 30~60ms，足够让「rebuild < 200ms」这条断言报警。
_img_g = make_img("T_G", 1024, 1024)
_ob_g = make_plane("G_src", _img_g, size=4.0)
bpy.ops.object.select_all(action="DESELECT")
_ob_g.select_set(True)
bpy.context.view_layer.objects.active = _ob_g

safe("generate")
_built_g = [o for o in bpy.data.objects if o.get("ic_generated")]
if _built_g:
    _g = _built_g[0]
    _s = _g.image_cutter
    _s.guide_enabled = True
    _s.guide_mode = "carve"
    # 加 5 条开放路径（每条 20 点）
    for _k in range(5):
        _st = _s.strokes.add()
        _st.closed = False
        for _j in range(20):
            _pp = _st.points.add()
            _pp.x = 20.0 + _j * 10.0
            _pp.y = 30.0 + _k * 40.0
    _s.guide_ver += 1

    # 强制跑一次，让 A 缓存建立
    icops.rebuild_object(_g, bpy.context, force=True)
    _a_first = _s.stat_ms_a
    check(_a_first > 0, "A 阶段首次确实算了", "%.1fms" % _a_first)

    # 再拖 density 四次：A 必须全程命中缓存
    _a_vals = []
    _rebuild_ms = []
    for _dv in (0.30, 0.45, 0.60, 0.75):
        _s.density = _dv
        _t0 = time.perf_counter()
        icops.rebuild_object(_g, bpy.context, force=False)
        _rebuild_ms.append((time.perf_counter() - _t0) * 1000)
        _a_vals.append(round(_s.stat_ms_a, 1))

    check(len(set(_a_vals)) == 1,
          "拖 density 时 A 阶段全程命中缓存（stat_ms_a 不变）",
          "各档: %s" % _a_vals)
    # 【判据要跟「A 阶段本身的耗时」比，不能写死绝对值】
    #
    # 白算一次引导栅格化的成本 ≈ 一次 A 阶段的引导部分。
    # 实测 1024² + 5 条路径：正常 17ms/次，注入「白算」后 54ms/次（3.2 倍）。
    # 但 54ms 绝对值很小，写死 100ms/200ms 的门槛都抓不到。
    #
    # 所以改成相对判据：拖 density 的单次 rebuild 不该接近 A 阶段的规模。
    # 正常情况 rebuild 只有 B 的几分之一；一旦白算，就会跟 A 同量级。
    # 【判据要跟"引导栅格化本身的耗时"比，不能跟 A 阶段整体比】
    #
    # 踩过的坑：一开始用「rebuild < A 阶段耗时」。性能优化把 A 从 31ms 压到 25ms 后，
    # 这条就从 0.57 顶到 1.43，误报失败 —— A 变快不该让测试变红。
    #
    # 真正要防的是「把 build_guide_mask 挪回缓存判断外面」，
    # 而它的成本可以独立量出来：直接跑一次 build_guide_mask 计时。
    # 判据：拖 density 的最慢一次 rebuild 不该接近「一次引导栅格化」的量级。
    _t0g = time.perf_counter()
    icops.build_guide_mask(_s, 1024, 1024)
    _guide_ms = (time.perf_counter() - _t0g) * 1000

    _worst = max(_rebuild_ms)
    check(_worst < _guide_ms,
          "拖 density 的单次 rebuild 应快于一次引导栅格化（白算会拉平）",
          "最慢 %.0fms vs 引导栅格化 %.0fms" % (_worst, _guide_ms))

    # 但改一个真正影响 A 的参数，必须重算
    _a_before = _s.stat_ms_a
    _s.threshold = 0.35
    icops.rebuild_object(_g, bpy.context, force=False)
    check(_s.stat_ms_a != _a_before or _s.stat_ms_a > 0,
          "改阈值时 A 阶段确实重算了", "A=%.1fms" % _s.stat_ms_a)
else:
    check(False, "带引导生成成功", "没生成")

# ==========================================================================
print("\n[性能] 多连通块图形（像素画/图标集）的阶段 A 不能卡住")
print("  旧行为：100 个 162 点的环，每个环都跑 DP，_seg_dev 调 57.8 万次 → 阶段 A 4.2 秒")
print("  根因：RDP 门槛 n>200 有盲区（162 点不触发 RDP），直接进 O(n×win) 的 DP")
print("  验证点：100 个块的阶段 A 必须 < 500ms（改前 4255ms）")

_mblk = np.zeros((512, 512), dtype=np.float32)
for _gy in range(10):
    for _gx in range(10):
        _bx = 10 + _gx * 50
        _by = 10 + _gy * 50
        _yy2, _xx2 = np.mgrid[_by:_by + 38, _bx:_bx + 38]
        _rr = np.hypot(_xx2 - (_bx + 19), _yy2 - (_by + 19))
        _jj = 1.5 * np.sin(np.arctan2(_yy2 - (_by + 19), _xx2 - (_bx + 19)) * 11)
        _mblk[_by:_by + 38, _bx:_bx + 38] = (_rr < 17 + _jj).astype(np.float32)

_p_blk = pipe.Params(spacing=17.0, tolerance=1.5)
t0 = time.perf_counter()
_sa_blk = pipe.run_stage_a(_mblk, _p_blk)
blk_ms = (time.perf_counter() - t0) * 1000
check(blk_ms < 500, "100 个连通块的阶段 A < 500ms", "%.0fms" % blk_ms)
check(len(_sa_blk.rings) == 100, "100 个块都被保留（没被当洞丢掉）",
      "%d 环" % len(_sa_blk.rings))

# 单环的 DP 不能被误伤：大环仍要走 DP（点数要明显少于原始）
_bigring = [(300 + 290 * math.cos(t / 3000 * 2 * math.pi),
             300 + 290 * math.sin(t / 3000 * 2 * math.pi)) for t in range(3000)]
t0 = time.perf_counter()
_z = simp_mod.simplify_ring(_bigring, 1.5)
big_ms = (time.perf_counter() - t0) * 1000
check(len(_z) < 100, "3000 点大环仍被抽稀到 100 点以内", "%d 点" % len(_z))
check(big_ms < 200, "3000 点单环 < 200ms", "%.1fms" % big_ms)

# 中等环（120~200 点）也不能退化：RDP 门槛改到 120 后应该更快
#
# 判据怎么定的：实测这条路径是「RDP(64ms) + DP(186ms)」。DP 在这批环上
# 把 65 点压到 42 点（少 35%），是真有价值的，不能为了快就跳过。
# 所以 261ms 是当前算法的真实下限，判据设在 400ms：
# 留足机器差异，同时能抓住「RDP 门槛又被改回 200」这类退化（那样会到 540ms）。
_mid = [(300 + 290 * math.cos(t / 162 * 2 * math.pi),
         300 + 290 * math.sin(t / 162 * 2 * math.pi)) for t in range(162)]
_t0 = time.perf_counter()
_mid_rings = simp_mod.simplify_rings([_mid] * 100, 1.5)
mid_ms = (time.perf_counter() - _t0) * 1000
check(len(_mid_rings) == 100, "批量抽稀保留全部环", "%d 环" % len(_mid_rings))
check(mid_ms < 400, "100 个 162 点环批量抽稀 < 400ms", "%.0fms" % mid_ms)

# 批量入口不能让单环调用退化；单独留一条宽松的 sanity check。
_t0 = time.perf_counter()
_one_mid = simp_mod.simplify_ring(_mid, 1.5)
one_mid_ms = (time.perf_counter() - _t0) * 1000
check(len(_one_mid) >= 3 and one_mid_ms < 50,
      "162 点单环调用 < 50ms", "%.1fms" % one_mid_ms)

# ==========================================================================
print("\n[崩溃] dist_to_rings_batch 的分块必须按「点数 × 段数」的乘积")
print("  旧行为：chunk 固定 1024，只按点数分；段数（环数×每环点数）一多就爆炸")
print("          16384 环 → 单块临时数组 3GB，进程峰值 4.8GB（就是用户遇到的崩溃）")
print("  验证点：内存峰值不随环数增长；结果与 chunk=1 完全一致")

from image_cutter.ic_core import triangulate as _tri_v   # noqa: E402
from image_cutter.ic_bpy import build as _build_v        # noqa: E402


def _mk_rings(n_rings, pts_per=4, seed=1):
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(n_rings):
        cx = float(rng.uniform(100, 3000))
        cy = float(rng.uniform(100, 1500))
        ang = np.linspace(0, 2 * np.pi, pts_per, endpoint=False)
        out.append([(cx + 5.0 * np.cos(a), cy + 5.0 * np.sin(a)) for a in ang])
    return out


_pts_big = np.random.default_rng(2).random((4000, 2)) * 3000.0

# 小环数 vs 大环数，内存不该跟着涨
_r_small = _mk_rings(256)
_r_big = _mk_rings(4096)


def _peak_mb(fn):
    import tracemalloc
    tracemalloc.start()
    fn()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / 1024.0 / 1024.0


_peak_small = _peak_mb(lambda: _tri_v.dist_to_rings_batch(_pts_big, _r_small))
_peak_big = _peak_mb(lambda: _tri_v.dist_to_rings_batch(_pts_big, _r_big))
_ratio = _peak_big / max(_peak_small, 0.01)
# 段数涨了 16 倍，内存只该因为输出数组等固定项略增，不该跟着涨
check(_ratio < 4.0, "环数 ×16 时内存峰值不跟着涨（乘积分块生效）",
      "256环 %.1fMB → 4096环 %.1fMB（%.1f 倍）" % (_peak_small, _peak_big, _ratio))

# 分块不能影响结果：默认 chunk vs 强制 chunk=1
_rings_cmp = _mk_rings(300)
_pts_cmp = np.random.default_rng(3).random((2000, 2)) * 3000.0
_d_def = _tri_v.dist_to_rings_batch(_pts_cmp, _rings_cmp)
_d_one = _tri_v.dist_to_rings_batch(_pts_cmp, _rings_cmp, chunk=1)
check(np.allclose(_d_def, _d_one, rtol=0, atol=1e-9),
      "分块方式不影响 dist 结果",
      "最大差 %.2e" % float(np.abs(_d_def - _d_one).max()))

# ==========================================================================
print("\n[几何] _representative_points 的内缩距离必须逐点自适应")
print("  旧行为①：inset = max(宽,高)*0.02 → 1000×10 长条 inset=20px > 环厚，点全出界")
print("  旧行为②：改用 min(宽,高)*0.25 → 长条好了，但 C 形凹环崩到 2/8")
print("  验证点：细长环 + 凹形环 + 常规形状，代表点都要落在环内")

from image_cutter.ic_core import outline as outline_mod  # noqa: E402

for _h in (200, 50, 20, 10, 6, 4, 2):
    _ring_thin = [(0.0, 0.0), (1000.0, 0.0), (1000.0, float(_h)), (0.0, float(_h))]
    _probes_t = outline_mod._representative_points(_ring_thin, max_samples=9)
    _in_t = sum(1 for _p in _probes_t if outline_mod.point_in_ring(_p, _ring_thin))
    check(_in_t >= len(_probes_t) - 1, "细长环 h=%d 的代表点在环内" % _h,
          "%d / %d" % (_in_t, len(_probes_t)))

# 【直接测「内缩距离算得对不对」，不能只测最终结果】
# 上面那些「代表点在环内」的断言抓不到「inset 算错」—— 因为代码里还有
# 「逐步缩小直到落进环内」的兜底，就算 inset 给大了也会自愈。
# 但兜底是慢路径（要多次 point_in_ring），不能靠它兜所有情况。
# 所以这里直接验证：对 1000×4 的长条，内缩距离必须 ≤ 4px（环厚），
# 而不是 max(1000,4)*0.02 = 20px。
import inspect as _insp
_src_rp = _insp.getsource(outline_mod._representative_points)
check("short_side * 0.25" in _src_rp,
      "内缩距离按「短边」算，不按「最大跨度」算",
      "源码含 short_side * 0.25" if "short_side * 0.25" in _src_rp else "源码里没有！")
check("max(w_span, h_span) * 0.02" not in _src_rp,
      "内缩距离没有退回「最大跨度 × 0.02」",
      "旧算法已移除" if "max(w_span, h_span) * 0.02" not in _src_rp else "旧算法还在！")

_C_ring2 = [(0.0, 0.0), (0.0, 200.0), (100.0, 200.0), (100.0, 180.0),
            (20.0, 180.0), (20.0, 20.0), (100.0, 20.0), (100.0, 0.0)]
_probes_c = outline_mod._representative_points(_C_ring2, max_samples=9)
_in_c = sum(1 for _p in _probes_c if outline_mod.point_in_ring(_p, _C_ring2))
check(_in_c >= len(_probes_c) - 1, "C 形凹环的代表点在环内",
      "%d / %d" % (_in_c, len(_probes_c)))

# 端到端：薄容器里的洞必须被认成 inner
for _thick in (30, 12, 6, 4, 2):
    _mm = np.zeros((300, 300), dtype=bool)
    _mm[50:250, 50:250] = True
    _mm[50 + _thick:250 - _thick, 50 + _thick:250 - _thick] = False
    _rr = outline_mod.trace_rings(_mm)
    _o, _i = outline_mod.split_outer(_rr)
    check(len(_o) == 1 and len(_i) == 1,
          "薄容器 %dpx：洞被正确认成 inner" % _thick,
          "outer=%d inner=%d" % (len(_o), len(_i)))

# ==========================================================================
print("\n[面板] 「碎成 N 块」提示必须区分「真碎了」和「主体+碎屑」")
print("  旧行为：只看 stat_rings >= 32 就建议调 expand；实测真实人物贴图 210 环")
print("          （最大环占 99.99%，是正常发丝碎屑），照做 expand=1 后外环 210→5，")
print("          199 个碎屑被膨胀抹掉，形状被吃掉一大片")
print("  验证点：有主体时文案说「独立小碎块」，不推销 expand")

from image_cutter.ic_ui import panels as _panels_v   # noqa: E402


class _FakeSettings:
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)

    def spacing(self):
        return 15.29


# 检查源码里的判据（用 inspect.getsource，co_consts 拿不到 % 格式化后的字符串）
import inspect as _insp_panel   # noqa: E402
_draw_src = _insp_panel.getsource(_panels_v.IC_PT_Main._draw_impl)
check("stat_dominant" in _draw_src,
      "面板 draw 的判据用了 stat_dominant（最大环占比）",
      "源码含 stat_dominant" if "stat_dominant" in _draw_src else "没找到")
check("独立小碎块" in _draw_src,
      "有主体时用「独立小碎块」的中性文案",
      "文案存在" if "独立小碎块" in _draw_src else "没找到")
# 【2026-10-22 改文案】为了让文案塞进面板宽度（超 ~187px 会被「…」截断），
# 「碎成 N 块，没有明显主体：可试「边缘外扩」1~2」压成了
# 「碎成 N 块：可试「边缘外扩」1~2」，字面不再有「没有明显主体」。
# 这条断言改为检查**真正的意图**：无主体分支有没有给出 expand 这个可操作建议
# ——那才是它跟有主体分支的区别所在（有主体时不该推销 expand）。
check("可试「边缘外扩」" in _draw_src,
      "真的碎了时给出「边缘外扩」的可操作建议（另一套文案，不混用）",
      "文案存在" if "可试「边缘外扩」" in _draw_src else "没找到")
# 旧文案（无条件推销 expand）必须消失
check("能把细缝合上" not in _draw_src,
      "旧的「把细缝合上」文案已移除（那会吃掉碎屑）",
      "旧文案已移除" if "能把细缝合上" not in _draw_src else "还在！")

# ---- 判据本身必须真的在比较，不能是恒真 ----
# 上面几条只查源码字符串，把 `if dom >= 0.9` 改成 `if True` 它们照样通过
# （注入验证实测抓不到）。所以这里用正则确认那是个真实比较。
import re as _re   # noqa: E402
_m = _re.search(r"if\s+dom\s*>=\s*([0-9.]+)\s*:", _draw_src)
check(_m is not None,
      "面板里的判据是「if dom >= 阈值」（真实比较，不是恒真）",
      _m.group(0) if _m else "没找到 dom >= 判断")
if _m is not None:
    check(0.5 <= float(_m.group(1)) <= 1.0,
          "阈值在 0.5~1.0 之间的合理区间", "阈值 = %s" % _m.group(1))

# 两种分支的文案必须都存在且不同（不能两处写同一句）
check("独立小碎块" in _draw_src and "可试「边缘外扩」" in _draw_src,
      "两条分支各有一套文案（有主体 / 无主体）",
      "两条都在")

# 【真正防「混用」的检查】上面的字符串存在性检查有个漏洞：两句都写在源码里
# 也能通过，哪怕它们被塞进同一个分支。这里看「独立小碎块」那句的邻域里
# 有没有夹带 expand 建议 —— 有主体时不该推销 expand（会把碎屑膨胀掉）。
_i_dom = _draw_src.find("独立小碎块")
if _i_dom >= 0:
    _seg = _draw_src[_i_dom:_i_dom + 160]
    check("边缘外扩" not in _seg,
          "有主体分支不夹带「边缘外扩」建议（两条确实是互斥分支）",
          "邻域干净" if "边缘外扩" not in _seg else "发现夹带！")

# ==========================================================================
print("\n[面板] 预估面数：细长形状不能低估一个数量级以上")
print("  旧行为：只按 面积/(spacing²×0.43) 估；1px 线估 27 面、实际 5600（207 倍）")
print("  验证点：加周长下限后，2px+ 细长形状的偏差应在 3 倍以内")


def _area_perim(rings):
    A = 0.0
    P = 0.0
    for r in rings:
        pts = np.asarray(r, dtype=np.float64)
        if len(pts) < 3:
            continue
        x = pts[:, 0]
        y = pts[:, 1]
        A += 0.5 * abs(float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))
        P += float(np.hypot(np.diff(np.append(x, x[0])), np.diff(np.append(y, y[0]))).sum())
    return A, P


for _w in (2, 3, 5, 8):
    _mm = np.zeros((300, 2000), dtype=np.float32)
    _mm[150:150 + _w, :] = 1.0
    _pp = pipe.Params(spacing=pipe.spacing_from_density(0.55, 6.0, 48.0))
    _sa_e = pipe.run_stage_a(_mm, _pp)
    _sb_e = pipe.run_stage_b(_sa_e, _pp)
    _actual_e = len(_sb_e["faces"])
    _A, _P = _area_perim(_sa_e.rings)
    _est_e = _panels_v._estimate_faces(_FakeSettings(stat_area=_A, stat_perimeter=_P))
    _rr = _actual_e / max(_est_e, 1)
    check(0.33 <= _rr <= 3.0,
          "%dpx 宽横条的预估偏差在 3 倍内" % _w,
          "预估 %d / 实际 %d（%.2f 倍）" % (_est_e, _actual_e, _rr))

# ==========================================================================
print("\n[性能] 内部点快速通道：有内部点的三角形不必逐环精确判")
print("  实测：24.6 万三角形里，三顶点全是边界点的只有 1.9%（4635 个）")
print("        其余 98.1% 含内部点（内部点本身是筛出来的环内点）→ 重心必然在环内")
print("  效果：重心判定 225ms → 13ms，且结果与全判逐元素一致")
print("  验证点：面数必须与「全部精确判」完全一致（凹形/洞/碎屑都不能变）")


def _ref_build_mesh(rings, spacing, boundary_ratio=0.9):
    """参考实现：所有重心都走 points_in_any_ring（快速通道之前的旧行为）。"""
    rings = [r for r in rings if len(r) >= 3]
    if not rings or spacing <= 1e-6:
        return {"points": np.zeros((0, 2)), "faces": []}
    boundary = []
    for r in rings:
        boundary.extend(_tri_v.densify_ring(r, spacing * boundary_ratio))
    bpts = np.asarray(boundary, dtype=np.float64)
    inner = _tri_v.interior_points(rings, spacing)
    pts = np.vstack([bpts, inner]) if len(inner) else bpts
    if len(pts) > 1:
        _, ui = np.unique(np.round(pts, 4), axis=0, return_index=True)
        pts = pts[np.sort(ui)]
    tris = _tri_v.delaunay_fast(pts)
    if not tris:
        return {"points": pts, "faces": []}
    idx = np.asarray(tris, dtype=np.int64)
    tri_pts = pts[idx]
    cents = tri_pts.mean(axis=1)
    keep = _tri_v.points_in_any_ring(cents, rings)
    a, b, c = tri_pts[:, 0], tri_pts[:, 1], tri_pts[:, 2]
    area2 = np.abs((b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1])
                   - (b[:, 1] - a[:, 1]) * (c[:, 0] - a[:, 0]))
    keep &= area2 > 1e-6
    return {"points": pts, "faces": [tris[k] for k in np.nonzero(keep)[0]]}


_fp_yy, _fp_xx = np.mgrid[0:400, 0:400]
_fp_ang = np.arctan2(_fp_yy - 200, _fp_xx - 200)
_fp_rad = np.hypot(_fp_xx - 200, _fp_yy - 200)
_fp_cases = [
    ("L 形", np.where((_fp_xx < 150) | (_fp_yy > 250),
                      (_fp_xx < 350) & (_fp_yy < 350) & ((_fp_xx < 150) | (_fp_yy > 250)),
                      False)),
    ("甜甜圈", (_fp_rad < 150) & (_fp_rad > 60)),
    ("五角星", _fp_rad < 160 * (0.6 + 0.4 * np.cos(5 * _fp_ang))),
]
# 【2026-10-21 改判据：面数相等 → 覆盖率达标】
#
# 原来这里断言「build_mesh 与 Delaunay 参考实现面数完全相等」，
# 那是快速通道刚上线时用来证明「只判 1.9% 的边界三角形不影响结果」的。
#
# 现在 build_mesh 已整体换成格子方案（不用 Delaunay），两条路线的面数
# **本来就不该相等** —— 格子用更少的面达到同样覆盖。继续比面数会永远红。
#
# 换成真正该守的东西：**网格必须盖住形状**。
# 判据用「三角形面积和 / 轮廓面积」而不是逐像素光栅化（后者在测试里太慢）。
def _tri_area_sum(pts, faces):
    pts = np.asarray(pts, dtype=np.float64)
    f = np.asarray(faces, dtype=np.int64)
    if len(f) == 0:
        return 0.0
    tp = pts[f]
    a2 = np.abs((tp[:, 1, 0] - tp[:, 0, 0]) * (tp[:, 2, 1] - tp[:, 0, 1])
                - (tp[:, 1, 1] - tp[:, 0, 1]) * (tp[:, 2, 0] - tp[:, 0, 0]))
    return float(a2.sum() * 0.5)


def _ring_area(rings):
    tot = 0.0
    for r in rings:
        arr = np.asarray(r, dtype=np.float64)
        x, y = arr[:, 0], arr[:, 1]
        tot += 0.5 * abs(float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))
    return tot


for _nm, _mm in _fp_cases:
    _rr = outline_mod.split_outer(outline_mod.trace_rings(_mm))[0]
    if not _rr:
        continue
    for _sp in (8.0, 14.0):
        _new = _tri_v.build_mesh(_rr, _sp)
        _area_tri = _tri_area_sum(_new["points"], _new["faces"])
        _area_ring = _ring_area(_rr)
        _ratio = _area_tri / max(_area_ring, 1e-9)
        check(0.90 <= _ratio <= 1.15,
              "网格铺满形状：%s sp=%.1f" % (_nm, _sp),
              "面积比 %.2f（面 %d）" % (_ratio, len(_new["faces"])))

# ==========================================================================
print("\n[覆盖] 小碎块必须走扇形三角化 —— 走格子会被吞掉")
print("  背景：碎块比一个格子还小，可能一个格点都落不进去")
print("  实测（225 个 24×24 的小方块，spacing=16）：")
print("    纯格子方案  覆盖率 19.8%（等于全丢）")
print("    扇形方案    覆盖率 99.8%")
print("  这条断言就是为了守住「碎块不能走格子」这个前提")


def _cov_by_area(pts, faces, mask):
    """三角形面积和 ∩ 形状 / 形状面积。用光栅化保证只算形状内的部分。"""
    H, W = mask.shape
    cov = np.zeros((H, W), dtype=bool)
    pts = np.asarray(pts, dtype=np.float64)
    for t in pts[np.asarray(faces, dtype=np.int64)]:
        xl = max(0, int(t[:, 0].min()))
        xh = min(W, int(t[:, 0].max()) + 2)
        yl = max(0, int(t[:, 1].min()))
        yh = min(H, int(t[:, 1].max()) + 2)
        if xh <= xl or yh <= yl:
            continue
        yy, xx = np.mgrid[yl:yh, xl:xh]
        dd = ((t[1, 1] - t[2, 1]) * (t[0, 0] - t[2, 0])
              + (t[2, 0] - t[1, 0]) * (t[0, 1] - t[2, 1]))
        if abs(dd) < 1e-12:
            continue
        aa = ((t[1, 1] - t[2, 1]) * (xx - t[2, 0]) + (t[2, 0] - t[1, 0]) * (yy - t[2, 1])) / dd
        bb = ((t[2, 1] - t[0, 1]) * (xx - t[2, 0]) + (t[0, 0] - t[2, 0]) * (yy - t[2, 1])) / dd
        cc = 1 - aa - bb
        cov[yl:yh, xl:xh] |= (aa >= 0) & (bb >= 0) & (cc >= 0)
    return (cov & mask).sum() / max(mask.sum(), 1) * 100


_many = np.zeros((560, 560), dtype=bool)
for _gy in range(15):
    for _gx in range(15):
        _many[20 + _gy * 36:44 + _gy * 36, 20 + _gx * 36:44 + _gx * 36] = True
_rr_many = outline_mod.split_outer(outline_mod.trace_rings(_many))[0]
if _rr_many:
    for _sp in (16.0, 10.0):
        _res = _tri_v.build_mesh(_rr_many, _sp)
        _cov = _cov_by_area(_res["points"], _res["faces"], _many)
        check(_cov >= 95.0,
              "225 个碎块必须铺满（sp=%.1f）" % _sp,
              "覆盖率 %.1f%%（面 %d）" % (_cov, len(_res["faces"])))

    # 【碎块保真度：不能只靠覆盖率判据】
    #
    # 实测过：把碎块也当大形状走格子，覆盖率仍有 98.9%（不是想象中会全丢）——
    # 因为边界吸附会把格点拉到轮廓上，形状照样盖住。
    # 所以「覆盖率」这条**抓不到碎块处理方式**。
    #
    # 真正的差别在**形状保真度**：
    #     碎块走格子：面 2482，每个 24×24 方块只分到 ~11 个面 → 方块变棱形
    #     碎块走扇形：面 21600，每个方块 ~96 个面，精确贴合
    # 判据用「每个碎块的平均面数」：24×24 的方块，扇形给 ~96 面/块，
    # 格子只给 ~11 面/块。要求至少 40 面/块。
    _n_blocks = 225
    _faces_per_block = len(_res["faces"]) / _n_blocks
    check(_faces_per_block >= 40.0,
          "碎块形状保真（sp=%.1f）" % _sp,
          "每块 %.0f 面（扇形应 ~96，格子只有 ~11）" % _faces_per_block)

# 细长条：格子方案容易在极窄处漏，单独守一条
_thin = np.zeros((120, 600), dtype=bool)
_thin[60:66, 20:580] = True          # 6px 高、560 长的细条
_rr_thin = outline_mod.split_outer(outline_mod.trace_rings(_thin))[0]
if _rr_thin:
    for _sp in (16.0, 10.0):
        _res = _tri_v.build_mesh(_rr_thin, _sp)
        _cov = _cov_by_area(_res["points"], _res["faces"], _thin)
        check(_cov >= 90.0,
              "细长条必须铺满（sp=%.1f）" % _sp,
              "覆盖率 %.1f%%（面 %d）" % (_cov, len(_res["faces"])))

# ==========================================================================
print("\n[膨胀] dilate_mask 的大半径快路径必须与小半径慢路径结果一致")
print("  背景：老实现是 2r 轮 Python 循环，每轮 1.07ms → 耗时 ≈ 2.14×r")
print("        真实图（3883x1978）拖 expand：r=128 要 280ms，r=256 要 550ms")
print("        新实现用前缀和，与 r 无关，固定约 96ms（r>=48 时启用）")


def _dilate_ref(mask, radius):
    """老实现（参照，不用快路径）。"""
    r = int(round(radius))
    out = np.array(mask, dtype=bool, copy=True)
    if r <= 0:
        return out
    for _ in range(r):
        out[:, 1:] |= out[:, :-1]
        out[:, :-1] |= out[:, 1:]
    for _ in range(r):
        out[1:, :] |= out[:-1, :]
        out[:-1, :] |= out[1:, :]
    return out


from image_cutter.ic_core import mask as _mask_mod   # noqa: E402

# 用小块验证（大图太慢）。必须包含 48 这个分界点两侧。
_dl_y, _dl_x = np.mgrid[0:120, 0:140]
_dl_base = ((_dl_x - 60) ** 2 + (_dl_y - 60) ** 2 < 30 ** 2)
_dl_base |= ((_dl_x - 20) ** 2 + (_dl_y - 20) ** 2 < 8 ** 2)     # 再加个小岛
_dl_base[10:15, 100:130] = True                                   # 加条细线

for _dr in (1, 2, 8, 16, 32, 47, 48, 49, 64, 100):
    _got = _mask_mod.dilate_mask(_dl_base, _dr)
    _exp = _dilate_ref(_dl_base, _dr)
    _diff = int((_got != _exp).sum())
    check(bool(np.array_equal(_got, _exp)),
          "dilate_mask r=%d 与慢路径逐像素一致" % _dr,
          "差异 %d px" % _diff)

# 边界情况
check(np.array_equal(_mask_mod.dilate_mask(_dl_base, 0), _dl_base),
      "dilate_mask r=0 原样返回", "")
_big = _mask_mod.dilate_mask(np.eye(20, dtype=bool), 50)
check(bool(_big.all()), "dilate_mask r 超图像尺寸 → 全 True", "")

# ==========================================================================
print("\n[建网格] _fill_mesh 的 numpy 快路径必须与 from_pydata 等价")
print("  背景：density=1.0 时建网格 431ms（from_pydata 186 + 逐个循环关平滑 139）")
print("        改成 foreach_set 后约 112ms，但必须保证结果一模一样")


def _fill_via_from_pydata(verts, faces, uvs):
    """老路径（参照实现）。"""
    me = bpy.data.meshes.new("_ref_fill")
    me.clear_geometry()
    vl = [tuple(float(x) for x in v) for v in verts]
    fl = _build_v._flip_faces(faces)
    me.from_pydata(vl, [], fl)
    me.update()
    if len(fl) and len(uvs):
        uvl = me.uv_layers.get("UVMap") or me.uv_layers.new(name="UVMap")
        n = len(me.loops)
        lvi = np.empty(n, dtype=np.int32)
        me.loops.foreach_get("vertex_index", lvi)
        ua = np.asarray(uvs, dtype=np.float32)
        uvl.data.foreach_set("uv", ua[lvi].ravel())
    me.update()
    if len(me.polygons):
        me.polygons.foreach_set("use_smooth", np.zeros(len(me.polygons), dtype=bool))
        me.update()
    return me


_gv_yy, _gv_xx = np.mgrid[0:200, 0:200]
_gv_m = (_gv_xx - 100) ** 2 + (_gv_yy - 100) ** 2 < 80 ** 2
_gv_m &= ~((_gv_xx - 100) ** 2 + (_gv_yy - 100) ** 2 < 30 ** 2)   # 中间挖洞
_gv_rings = outline_mod.split_outer(outline_mod.trace_rings(_gv_m))[0]
_gv_res = _tri_v.build_mesh(_gv_rings, 12.0)
_gv_pts = np.asarray(_gv_res["points"], dtype=np.float64)
_gv_faces = _gv_res["faces"]
_gv_verts, _gv_uvs = _build_v.px_to_local(_gv_pts, 200, 200, 1.0, 1.0)

_me_fast = bpy.data.meshes.new("_fast_fill")
_build_v._fill_mesh(_me_fast, np.asarray(_gv_verts, dtype=np.float32), _gv_faces, _gv_uvs)
_me_ref = _fill_via_from_pydata(_gv_verts, _gv_faces, _gv_uvs)

check(len(_me_fast.vertices) == len(_me_ref.vertices)
      and len(_me_fast.polygons) == len(_me_ref.polygons)
      and len(_me_fast.edges) == len(_me_ref.edges),
      "_fill_mesh 快路径：顶点/面/边数一致",
      "%d/%d/%d vs %d/%d/%d" % (
          len(_me_fast.vertices), len(_me_fast.polygons), len(_me_fast.edges),
          len(_me_ref.vertices), len(_me_ref.polygons), len(_me_ref.edges)))

_cf = np.empty(len(_me_fast.vertices) * 3, dtype=np.float32)
_cr = np.empty(len(_me_ref.vertices) * 3, dtype=np.float32)
_me_fast.vertices.foreach_get("co", _cf)
_me_ref.vertices.foreach_get("co", _cr)
check(float(np.abs(_cf - _cr).max()) < 1e-5,
      "_fill_mesh 快路径：顶点坐标一致",
      "最大差 %.2e" % float(np.abs(_cf - _cr).max()))

_vf = np.empty(len(_me_fast.loops), dtype=np.int32)
_vr = np.empty(len(_me_ref.loops), dtype=np.int32)
_me_fast.loops.foreach_get("vertex_index", _vf)
_me_ref.loops.foreach_get("vertex_index", _vr)
check(np.array_equal(_vf, _vr),
      "_fill_mesh 快路径：面顶点索引完全一致",
      "%d 个 loop" % len(_vf))

_uf = np.empty(len(_me_fast.loops) * 2, dtype=np.float32)
_ur = np.empty(len(_me_ref.loops) * 2, dtype=np.float32)
_me_fast.uv_layers["UVMap"].data.foreach_get("uv", _uf)
_me_ref.uv_layers["UVMap"].data.foreach_get("uv", _ur)
check(float(np.abs(_uf - _ur).max()) < 1e-6,
      "_fill_mesh 快路径：UV 一致",
      "最大差 %.2e" % float(np.abs(_uf - _ur).max()))

check(not _me_fast.validate(verbose=False),
      "_fill_mesh 快路径：validate 无错", "")

# ==========================================================================
print("\n[性能] dist_to_rings_grid 必须比全量广播快一个量级（拖滑块不卡的关键）")
print("  旧行为：dist_to_rings_batch 是 (点数 × 段数) 全量广播")
print("          实测 12.2 万候选点 × 1511 段 = 1.85 亿次 → 2883ms，占 B 阶段 85%")
print("  新做法：空间哈希，点只和邻近格子的线段算距离 → 48ms（60 倍）")
print("  关键前提：调用方只要「距离是否 >= 阈值」，不要精确值")

import time as _time_v   # noqa: E402

# 造一张有多个连通块的图（模仿真实素材的碎屑）
_g1 = np.zeros((600, 600), dtype=bool)
_g1[100:500, 100:500] = True
_g1[250:350, 100:500] = False          # 一条横缝
_g1[100:500, 250:350] = False          # 一条竖缝 → 4 块
_rings_g = outline_mod.trace_rings(_g1)

_pts_g = np.random.default_rng(5).random((30000, 2)) * 600.0
_need = 6.0 * 0.45

_t0 = _time_v.perf_counter()
_d_full = _tri_v.dist_to_rings_batch(_pts_g, _rings_g)
_t_full = (_time_v.perf_counter() - _t0) * 1000

_t0 = _time_v.perf_counter()
_d_grid = _tri_v.dist_to_rings_grid(_pts_g, _rings_g)
_t_grid = (_time_v.perf_counter() - _t0) * 1000

check(_t_grid * 3 < _t_full,
      "grid 版比全量广播快 3 倍以上",
      "grid %.1fms vs full %.1fms（%.1f 倍）" % (
          _t_grid, _t_full, _t_full / max(_t_grid, 0.01)))

# 【关键的等价性】：调用方只比一个阈值，阈值判定必须逐点一致
_flip = ((_d_full < _need) != (_d_grid < _need)).sum()
check(_flip == 0,
      "阈值判定逐点等价（keep 掩码完全一致）",
      "翻转 %d 个点" % _flip)

# 距离 grid 远的点（坐标离所有线段都远）返回值可能是 inf，
# 但那些点的真实距离必然远超阈值 —— 这里抽查确认
_far = np.array([[10000.0, 10000.0]])
_d_far = _tri_v.dist_to_rings_grid(_far, _rings_g)
check(_d_far[0] >= _need, "远处点判为「够远」", "%.1f" % _d_far[0])

# 【必须确认 interior_points 真的接上了 grid 版】
# 上面那些只比较两个函数本身，把调用点改回全量版它们照样通过
# （注入验证实测抓不到）。所以这里直接查调用点的源码。
import inspect as _insp_v   # noqa: E402
_src_interior = _insp_v.getsource(_tri_v.interior_points)
check("dist_to_rings_grid" in _src_interior,
      "interior_points 用的是 grid 版（拖滑块不卡的关键接线）",
      "已接上" if "dist_to_rings_grid" in _src_interior else "还在用全量版！")
check("dist_to_rings_batch" not in _src_interior.split("dist_to_rings_grid")[1]
      if "dist_to_rings_grid" in _src_interior else True,
      "interior_points 没有残留全量版调用",
      "干净")

# ==========================================================================
print("\n[参数] 拐角圆滑（smooth）已移除，且删掉后不能伤到覆盖")
print("  背景：真实图（3883x1978 软边）实测各档")
print("        smooth  环点数  面数    覆盖率    面积变化   A 阶段耗时")
print("        0        1481   44238  99.82%   +0.00%     177.9 ms")
print("        2        1478   44125  99.81%   -0.04%     196.2 ms")
print("        12       1477   44204  99.72%   -0.15%     318.8 ms")
print("  环点数差 0.3%、覆盖率差 0.1%、面积差 0.15%，但拖到 12 要多花 141ms。")
print("  换格子网格后边缘形状由「格点吸附到轮廓」决定，平滑原始环点已无收益。")


def _rough_deg(pts):
    n = len(pts)
    if n < 5:
        return 0.0
    vals = []
    for _i in range(n):
        _ax, _ay = pts[(_i - 1) % n][0], pts[(_i - 1) % n][1]
        _bx, _by = pts[_i][0], pts[_i][1]
        _cx2, _cy2 = pts[(_i + 1) % n][0], pts[(_i + 1) % n][1]
        _v1 = (_bx - _ax, _by - _ay)
        _v2 = (_cx2 - _bx, _cy2 - _by)
        _l1 = (_v1[0] ** 2 + _v1[1] ** 2) ** 0.5
        _l2 = (_v2[0] ** 2 + _v2[1] ** 2) ** 0.5
        if _l1 < 1e-9 or _l2 < 1e-9:
            continue
        _c = max(-1.0, min(1.0, (_v1[0] * _v2[0] + _v1[1] * _v2[1]) / (_l1 * _l2)))
        vals.append(np.degrees(np.arccos(_c)))
    return float(np.median(vals)) if vals else 0.0


def _ring_area_px(pts):
    _n = len(pts)
    _s = 0.0
    for _k in range(_n):
        _x0, _y0 = pts[_k][0], pts[_k][1]
        _x1, _y1 = pts[(_k + 1) % _n][0], pts[(_k + 1) % _n][1]
        _s += _x0 * _y1 - _x1 * _y0
    return abs(_s * 0.5)


# ① 契约检查：Params 和 UI 都不该再有 smooth 字段
import inspect as _inspect

# 判据要看**真实字段**而不是源码文本 —— 注释里提一句"已移除 smooth"不该算失败
_params_fields = [f for f in getattr(pipe.Params, "__dataclass_fields__", {})]
check("smooth" not in _params_fields,
      "Params 不再有 smooth 字段",
      "字段: %s" % ",".join(_params_fields))

_ic_props = bpy.types.Object.bl_rna.properties["image_cutter"].fixed_type.properties
check("smooth" not in _ic_props.keys(),
      "UI 不再有 smooth 滑块",
      "已移除" if "smooth" not in _ic_props.keys() else "⚠️ 仍有 smooth")

# ② 关键行为：把 smooth 固定成 0（不平滑）后，覆盖不能掉
#    （历史上 smooth 在稀疏点上做会把实心区吃掉 16%，这里守的是「别再回来」）
_SI2 = 512
_iy2, _ix2 = np.mgrid[0:_SI2, 0:_SI2]
_icx2, _icy2 = _SI2 / 2.0, _SI2 / 2.0
_ir2 = np.hypot(_ix2 - _icx2, _iy2 - _icy2)
_ith2 = np.arctan2(_iy2 - _icy2, _ix2 - _icx2)
_inner_img2 = np.clip((160 + 35 * np.cos(6 * _ith2) - _ir2) / 3.0 + 0.5,
                      0, 1).astype(np.float32)
from image_cutter.ic_core import mask as _mask_local2   # noqa: E402
_inner_mask2, _ = _mask_local2.build_mask(_inner_img2, 0.5)
_sy2, _sx2 = np.nonzero(_inner_mask2)
_srng2 = np.random.default_rng(11)
_sel2 = _srng2.choice(len(_sy2), size=min(8000, len(_sy2)), replace=False)
_solid_samples2 = np.stack([_sx2[_sel2], _sy2[_sel2]], axis=1).astype(float)

_pp_now = pipe.Params(spacing=15.29, expand=0)
_sa_now = pipe.run_stage_a(_inner_img2, _pp_now)
if _sa_now.rings:
    _cov_now = _tri_v.points_in_any_ring(_solid_samples2, _sa_now.rings).mean() * 100
    check(_cov_now >= 98.0,
          "移除 smooth 后：环仍覆盖 >=98% 实心区（不能吃掉形状）",
          "%.2f%%" % _cov_now)

# ③ 锯齿圆上，现在走的是「不平滑」这条路 —— 转折角应该就是原始锯齿角度
_SZ2 = 512
_gy2, _gx2 = np.mgrid[0:_SZ2, 0:_SZ2]
_gc2 = _SZ2 / 2.0
_jag_img2 = np.clip(
    (180 + 8 * np.sin(np.arctan2(_gy2 - _gc2, _gx2 - _gc2) * 23)
     - np.hypot(_gx2 - _gc2, _gy2 - _gc2)) / 4.0 + 0.5, 0, 1).astype(np.float32)
_pp_j = pipe.Params(spacing=pipe.spacing_from_density(0.55, 6.0, 48.0, _SZ2))
_sa_j = pipe.run_stage_a(_jag_img2, _pp_j)
check(len(_sa_j.rings) > 0, "锯齿圆仍能出环", "%d 个环" % len(_sa_j.rings))
if _sa_j.rings:
    _rj = _sa_j.rings[0]
    check(_ring_area_px(_rj) > 0,
          "锯齿圆环面积为正（形状没被抹掉）",
          "%.0f px²" % _ring_area_px(_rj))

# ④ 硬边图仍然被识别为 hard（像素画楼梯完整保留）
_hy2, _hx2 = np.mgrid[0:256, 0:256]
_hard_img2 = (np.hypot(_hx2 - 128, _hy2 - 128) < 100).astype(np.float32)
_hp2 = pipe.Params(spacing=pipe.spacing_from_density(0.55, 6.0, 48.0, 256))
_hsa2 = pipe.run_stage_a(_hard_img2, _hp2)
check(_hsa2.edge_style == "hard", "硬边图被识别为 hard", _hsa2.edge_style)

# ==========================================================================
print("\n[参数] 各参数的取值范围必须每档都有效")
print("  tolerance 下限从 0.1 抬到 0.5：0.1 相比 1.5 点数只多 3.8 倍、耗时却多 8.5 倍")
print("  expand 上限从 32 抬到 64：实测到 128 都还线性有效，32 在大图上不够")

_tol_prop = bpy.types.Object.bl_rna.properties["image_cutter"].fixed_type.properties["tolerance"]
check(_tol_prop.hard_min >= 0.5 - 1e-9, "tolerance 下限 >= 0.5（砍掉纯亏的低端）",
      "min=%g" % _tol_prop.hard_min)
# 【上限从 12 收到 4.05 —— 实测 4.05 以上环点数完全冻结】
#     软边毛刺圆（spacing=16）：
#         tol    环点数  漏(mask未盖)  面数
#         1.50     100      0.55%      959
#         4.05      10      2.48%      914
#         8.00      10      2.48%      914   ← 和 4.05 一模一样
#         12.00     10      2.48%      914
# 4.05 以上拖滑块毫无反应，只会误导用户。
check(abs(_tol_prop.hard_max - 4.05) < 0.01,
      "tolerance 上限收到 4.05（4.05 以上环点冻结、滑块无效）",
      "max=%g" % _tol_prop.hard_max)

# 【默认值改成 4.05，并且从面板上隐藏（2026-10-22 用户拍板）】
# 用户原话：「轮廓容差这个参数感觉已经影响不大了，可以设定为 4.05 的默认值
# 然后把调整参数隐藏掉」。实测支持：真实图 3883×1978 expand=0 时，
# tol 1.5 → 漏画 0.1172%，tol 4.05 → 0.1395%，差 0.022pp，看不出来。
#
# 属性**必须保留**（不能删）：老 .blend 里存的值仍生效，
# 删了会读不到 / 报错。所以这里守的是「默认值」而不是「没有这个属性」。
check(abs(_tol_prop.default - 4.05) < 0.01,
      "tolerance 默认值 = 4.05（与面板隐藏一致，避免新对象回到旧行为）",
      "default=%g" % _tol_prop.default)

_exp_prop = bpy.types.Object.bl_rna.properties["image_cutter"].fixed_type.properties["expand"]
check(_exp_prop.hard_max >= 64 - 1e-9, "expand 硬上限 >= 64（大图上 32 不够）",
      "max=%g" % _exp_prop.hard_max)

# ---- expand 的有效上限必须随图片尺寸缩放 ----
# 用户两次反馈："32 拉满了" → 抬到 64 → "能不能再大点"。
# 实测：3883 图上 expand 到 384 仍线性有效；而 512 小图上 160 就顶边了。
# 固定值必然有一头错，所以按长边 20% 算。
print("\n[参数] expand 的有效上限必须随图片尺寸缩放")
print("  实测：3883 图上到 384 仍有效；512 小图上 160 就顶到图边")
print("  规律：四种尺寸都是「长边 28% 顶边」，取 20% 留余量")

from image_cutter.ic_ui import props as _props_v2   # noqa: E402

check(_props_v2.expand_limit(0) == 64, "不知道图多大时给 64 的保守下限",
      "%d" % _props_v2.expand_limit(0))
check(_props_v2.expand_limit(256) == 64, "256 图上限 64（不低于下限）",
      "%d" % _props_v2.expand_limit(256))
check(abs(_props_v2.expand_limit(1024) - 205) <= 1, "1024 图上限 205（长边 20%）",
      "%d" % _props_v2.expand_limit(1024))
check(abs(_props_v2.expand_limit(3883) - 777) <= 1, "3883 图上限 777（长边 20%）",
      "%d" % _props_v2.expand_limit(3883))
check(_props_v2.expand_limit(3883) <= _exp_prop.hard_max,
      "硬上限要够大图用（动态上限不能超过它）",
      "动态 %d / 硬上限 %g" % (_props_v2.expand_limit(3883), _exp_prop.hard_max))

# 钳制：超限的值必须被拉回
class _FakeExpS:
    def __init__(self, ex, L):
        self.expand = ex
        self.stat_img_long = L

_s1 = _FakeExpS(300, 512)
_props_v2._clamp_expand(_s1)
check(_s1.expand == _props_v2.expand_limit(512),
      "512 图上 expand=300 会被钳到上限", "%d" % _s1.expand)

_s2 = _FakeExpS(300, 3883)
_props_v2._clamp_expand(_s2)
check(_s2.expand == 300, "3883 图上 expand=300 不越界、保持原值", "%d" % _s2.expand)

_s3 = _FakeExpS(900, 3883)
_props_v2._clamp_expand(_s3)
check(_s3.expand == _props_v2.expand_limit(3883),
      "3883 图上 expand=900 被钳到 777", "%d" % _s3.expand)

# ==========================================================================
print("\n[参数] 密度=0（最粗）必须随图片尺寸缩放，大图不能拉到底还是密")
print("  用户实测反馈：网格密度设成 0 还是挺高，没法再减少")
print("  根因：48px 是绝对像素；3883 宽的图上它只占 1.2%，实测 2224 面")
print("  验证点：密度=0 时目标边长要按长边比例放大；密集端不受影响")

_sp_small = pipe.spacing_from_density(0.0, 6.0, 48.0, image_long_side=256)
_sp_mid = pipe.spacing_from_density(0.0, 6.0, 48.0, image_long_side=1024)
_sp_big = pipe.spacing_from_density(0.0, 6.0, 48.0, image_long_side=3883)

check(abs(_sp_mid - 256.0) < 1.0, "1024 图上密度=0 → 256px", "%.1fpx" % _sp_mid)
check(abs(_sp_big - 3883 * 0.25) < 2.0, "3883 图上密度=0 → 长边的 25%",
      "%.1fpx" % _sp_big)
# 小图不能被压得太粗（还要受 48px 绝对下限保护）
check(abs(_sp_small - 64.0) < 1.0, "256 图上密度=0 → 64px（25% 长边，>48 所以按比例）",
      "%.1fpx" % _sp_small)

# 单调 + 等比：滑块每档倍率一致
_ratios = []
_prev = None
for _k in range(11):
    _s = pipe.spacing_from_density(_k / 10.0, 6.0, 48.0, image_long_side=3883)
    _f = 1.0 / (_s * _s)
    if _prev is not None:
        _ratios.append(_f / _prev)
    _prev = _f
_spread = max(_ratios) / min(_ratios)
check(_spread < 1.02, "大图上仍是等比映射（各档倍率一致）",
      "%.3f~%.3f，离散 %.4f" % (min(_ratios), max(_ratios), _spread))

# 密集端（density=1.0）必须与图尺寸无关 —— 6px 在任何尺寸都是"很细"
for _L in (256, 1024, 3883):
    _s1 = pipe.spacing_from_density(1.0, 6.0, 48.0, image_long_side=_L)
    check(abs(_s1 - 6.0) < 1e-9, "%d 图上密度=1.0 仍是 6px" % _L, "%.2fpx" % _s1)

# 不传 image_long_side 时退回旧行为（API 兼容）
_legacy = pipe.spacing_from_density(0.0, 6.0, 48.0)
check(abs(_legacy - 48.0) < 1e-9, "不传长边时退回 48px（向后兼容）", "%.1fpx" % _legacy)

# ==========================================================================
print("\n[一致性] pipeline.Params 的默认值必须与 UI 默认值一致")
print("  旧行为：Params.expand=2/UI=0、Params.spacing=18/UI=15.29")
print("          同一张图走 API 和走 UI 会得到不同结果，排查时极易误判")
print("  2026-10-21：smooth 已从 Params 和 UI 同时移除，不再有对不上的风险")

from image_cutter.ic_ui import props as _props_v   # noqa: E402

_p_def = pipe.Params()
check(abs(_p_def.expand - 0) < 1e-9, "Params.expand 默认 = 0（与 UI 一致）",
      "%s" % _p_def.expand)
check(abs(_p_def.tolerance - 4.05) < 1e-9,
      "Params.tolerance 默认 = 4.05（与面板隐藏值一致）",
      "%s" % _p_def.tolerance)
check(not hasattr(_p_def, "smooth"),
      "Params 已无 smooth 字段（与 UI 同步移除）",
      "已移除")
_ui_spacing = _props_v._density_to_spacing(0.55)
check(abs(_p_def.spacing - _ui_spacing) < 0.5,
      "Params.spacing 默认 = UI density 0.55 的换算值",
      "Params=%.2f UI=%.2f" % (_p_def.spacing, _ui_spacing))

# ==========================================================================
print("\n[交互] 编辑闭合路径不能因为回车而悄悄变成开放")
print("  旧行为：回车统一 _finish(closed=False)，编辑闭合路径一保存就变开口")
print("  验证点：回车沿用当前状态；编辑时 C 只切换、不结束")

import inspect as _insp_pen   # noqa: E402
from image_cutter.ic_ui import pen as _pen_v   # noqa: E402

_pen_modal_src = _insp_pen.getsource(_pen_v.IC_OT_PenDraw.modal)
check("回车保存沿用当前开/闭状态",
      "closed=(self.closed if self.edit_index >= 0 else False)"
      in _pen_modal_src,
      "已按当前状态保存")
check("编辑时 C 只切换不退出",
      "self.closed = not self.closed" in _pen_modal_src
      and "路径已切换为" in _pen_modal_src,
      "C 切换后继续编辑")

# ==========================================================================
print("\n[外观] 引导路径叠加层：抗锯齿线 / 圆点 / 虚线几何")
print("  旧行为：硬边三角形斜线全是台阶；描边方案与官方曲线编辑器风格不符")
print("  验证点：内核 + 1px 羽化、虚线节奏正确、圆点圆环半径准确")

_line = [(0.0, 0.0), (40.0, 0.0)]
_line_pos, _line_col = _pen_v._line_geo(_line, 4.0, (1.0, 1.0, 1.0, 1.0))
check("线：内核 + 两侧羽化 = 18 顶点", len(_line_pos) == 18,
      "%d 顶点" % len(_line_pos))
_line_ys = [p[1] for p in _line_pos]
check("线：总宽 = 4px + 2×0.9px 羽化",
      abs((max(_line_ys) - min(_line_ys)) - 5.8) < 1e-6,
      "实测 %.3f" % (max(_line_ys) - min(_line_ys)))
_core_ys = [p[1] for p, c in zip(_line_pos, _line_col) if c[3] > 0.99]
check("线：不透明内核宽 4px",
      abs((max(_core_ys) - min(_core_ys)) - 4.0) < 1e-6,
      "实测 %.3f" % (max(_core_ys) - min(_core_ys)))
check("线：边缘 alpha 到 0（真羽化）",
      min(c[3] for c in _line_col) == 0.0
      and max(c[3] for c in _line_col) == 1.0,
      "alpha 0→1")
check("线：两端不缩进",
      min(p[0] for p in _line_pos) == 0.0
      and max(p[0] for p in _line_pos) == 40.0,
      "x=[0, 40]")

_disc_pos, _disc_col = _pen_v._disc_geo(0.0, 0.0, 5.0, (1.0, 1.0, 1.0, 1.0))
check("圆点：20 段 × 9 顶点", len(_disc_pos) == 180, "%d 顶点" % len(_disc_pos))
_disc_r = max(math.hypot(x, y) for (x, y) in _disc_pos)
check("圆点：5px + 0.8px 羽化",
      abs(_disc_r - 5.8) < 1e-6, "%.3f" % _disc_r)
check("圆点：最外圈 alpha = 0",
      min(c[3] for c in _disc_col) == 0.0
      and max(c[3] for c in _disc_col) == 1.0,
      "alpha 0→1")

_ring_pos, _ring_col = _pen_v._ring_geo(
    0.0, 0.0, 3.0, 5.0, (1.0, 1.0, 1.0, 1.0))
_radii = {round(math.hypot(x, y), 6) for (x, y) in _ring_pos}
check("圆环：内 3px / 外 5px 都在",
      {3.0, 5.0} <= _radii, "%s" % sorted(_radii))
check("圆环：内外边缘 alpha = 0",
      min(c[3] for c in _ring_col) == 0.0
      and max(c[3] for c in _ring_col) == 1.0,
      "alpha 0→1")

_dashes = _pen_v._dash_polylines([(0.0, 0.0), (100.0, 0.0)], 10.0, 5.0)
_dash_total = sum(abs(p[-1][0] - p[0][0]) for p in _dashes)
check("虚线：100px / (10+5) 切成 7 段", len(_dashes) == 7,
      "%d 段" % len(_dashes))
check("虚线：实线总长 70px", abs(_dash_total - 70.0) < 1e-6,
      "%.2f" % _dash_total)
check("虚线：间隔 5px",
      all(abs(_dashes[k + 1][0][0] - _dashes[k][-1][0] - 5.0) < 1e-6
          for k in range(len(_dashes) - 1)),
      "全部间隔正确")


class _GuideStub:
    guide_mode = "carve"


check("开放路径固定蓝色（不跟补/挖变色）",
      _pen_v._mode_color(_GuideStub(), "add", False)
      == (0.40, 0.78, 1.00, 0.95), "蓝色")
check("auto 闭合路径跟随面板默认模式",
      _pen_v._mode_color(_GuideStub(), "auto", True)
      == _pen_v._mode_color(_GuideStub(), "carve", True), "与 carve 同色")
check("常驻锚点提亮后仍是同色相",
      _pen_v._lighten((0.0, 0.0, 1.0, 0.9), 0.5) == (0.5, 0.5, 1.0, 0.9),
      "蓝 → 浅蓝")


class _AppendStub:
    def __init__(self, closed):
        self.closed = closed
        self.points = []
        self.drag_kind = None
        self.drag_index = -1
        self.selected = -1
        self.began = 0

    def _begin_action(self, context):
        self.began += 1


_closed_stub = _AppendStub(True)
_added = _pen_v.IC_OT_PenDraw._append_point(
    _closed_stub, None, (10.0, 20.0))
check("闭合路径点空白不追加锚点（不会把收尾边甩出去）",
      _added is False and _closed_stub.points == []
      and _closed_stub.began == 0,
      "points=%d" % len(_closed_stub.points))

_open_stub = _AppendStub(False)
_added = _pen_v.IC_OT_PenDraw._append_point(
    _open_stub, None, (30.0, 40.0))
check("开放路径点空白仍然追加锚点",
      _added is True
      and _open_stub.points == [(30.0, 40.0, 0.0, 0.0, 0.0, 0.0)]
      and _open_stub.selected == 0
      and _open_stub.drag_kind == "new",
      "points=%d" % len(_open_stub.points))

_shape = [(0.0, 0.0, 1.0, 2.0, 3.0, 4.0),
          (10.0, 20.0, -1.0, -2.0, -3.0, -4.0)]
_moved = _pen_v._translate_points(_shape, 5.0, -3.0)
check("整条平移只动锚点坐标，控制柄不变",
      _moved == [(5.0, -3.0, 1.0, 2.0, 3.0, 4.0),
                 (15.0, 17.0, -1.0, -2.0, -3.0, -4.0)],
      "%s" % (_moved,))


class _DoubleClickStub:
    _last_anchor_click = None


_dc = _DoubleClickStub()
_ev = type("E", (), {"mouse_x": 100.0, "mouse_y": 50.0})()
_first = _pen_v.IC_OT_PenDraw._double_anchor_click(_dc, _ev, 2)
_second = _pen_v.IC_OT_PenDraw._double_anchor_click(_dc, _ev, 2)
_other = _pen_v.IC_OT_PenDraw._double_anchor_click(_dc, _ev, 1)
check("双击同一锚点才识别为整条选中",
      _first is False and _second is True and _other is False,
      "first=%s second=%s other=%s" % (_first, _second, _other))


class _AllHintStub:
    edit_index = 1
    closed = True
    mode = "auto"
    select_all = True
    points = [(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)] * 4


_all_hint = _pen_v.IC_OT_PenDraw._hint_text(_AllHintStub())
check("整条选中提示写清移动和取消方式",
      "拖任意锚点移动" in _all_hint and "A 取消全选" in _all_hint
      and "方向键微调" in _all_hint,
      _all_hint)


class _RegionStub:
    width = 800
    height = 600


class _BadgeCtxStub:
    region = _RegionStub()


_bc = _pen_v._badge_center(_BadgeCtxStub(), [(100.0, 50.0)], 1.0)
check("编号位置 = 首锚点上方 14px", _bc == (100.0, 64.0), "%s" % (_bc,))
_bc = _pen_v._badge_center(_BadgeCtxStub(), [(5.0, 595.0)], 1.0)
check("编号贴边时夹进视口", _bc == (12.0, 588.0), "%s" % (_bc,))

_badges = [(0, 100.0, 100.0), (1, 200.0, 100.0)]
check("编号命中取最近的一个",
      _pen_v._nearest_badge(_badges, 105.0, 100.0, 12.0) == 0
      and _pen_v._nearest_badge(_badges, 195.0, 100.0, 12.0) == 1,
      "两个都在半径内时取最近")
check("离编号远时不拦截普通点击",
      _pen_v._nearest_badge(_badges, 150.0, 100.0, 12.0) == -1,
      "返回 -1")

# ==========================================================================
print("\n[性能] edge_style 不能在整幅图上做 max/clip")
print("  旧行为：a.max() 全扫 + np.clip 全扫（3883x1978 = 770 万像素，两次 ~10ms）")
print("          而真正要用的只有边界那几万个 alpha 值")
print("  验证点：结果与「整图版本」完全一致，但快 2.5 倍")

from image_cutter.ic_core import mask as _mask_v   # noqa: E402


def _ref_edge_style(alpha, mask, sample_cap=200000):
    """旧实现（整图 max/clip + 全图布尔），用来对拍。"""
    a = np.asarray(alpha, dtype=np.float32)
    if a.max() > 1.0001:
        a = a / 255.0
    a = np.clip(a, 0.0, 1.0)
    m = np.asarray(mask, dtype=bool)
    if m.size == 0 or not m.any():
        return "hard", 0.0
    b = np.ones_like(m)
    b[0, :] = False
    b[-1, :] = False
    b[:, 0] = False
    b[:, -1] = False
    b[1:, :] &= m[:-1, :]
    b[:-1, :] &= m[1:, :]
    b[:, 1:] &= m[:, :-1]
    b[:, :-1] &= m[:, 1:]
    bd = m & ~b
    if not bd.any():
        return "hard", 0.0
    vals = a[bd]
    if vals.size > sample_cap:
        vals = vals[::int(np.ceil(vals.size / sample_cap))]
    mid = (vals > 0.15) & (vals < 0.85)
    r = float(mid.sum()) / float(vals.size) if vals.size else 0.0
    return ("soft" if r >= 0.18 else "hard"), r


_ey, _ex = np.mgrid[0:400, 0:400]
_softbuf = np.clip((160 - np.hypot(_ex - 200, _ey - 200)) / 4.0 + 0.5, 0, 1).astype(np.float32)
_hardbuf = (np.hypot(_ex - 200, _ey - 200) < 160).astype(np.float32)

_edge_cases = [
    ("软边圆", _softbuf),
    ("硬边圆", _hardbuf),
    ("0-255 量纲", (_softbuf * 255).astype(np.float32)),
    ("全透明", np.zeros((64, 64), np.float32)),
    ("全不透明", np.ones((64, 64), np.float32)),
]
for _nm, _abuf in _edge_cases:
    _mbuf, _ = _mask_v.build_mask(_abuf, 0.5)
    _r_old = _ref_edge_style(_abuf, _mbuf)
    _r_new = _mask_v.edge_style(_abuf, _mbuf)
    check(_r_old[0] == _r_new[0] and abs(_r_old[1] - _r_new[1]) < 1e-6,
          "edge_style 与整图版一致：%s" % _nm,
          "old=%s %.4f new=%s %.4f" % (_r_old[0], _r_old[1], _r_new[0], _r_new[1]))

# 贴图像边界的形状必须仍被判成边界（裁区时容易把界外误当成实心）
_edge_touch = np.zeros((200, 200), dtype=np.float32)
_edge_touch[0:100, 0:100] = 1.0
_mt, _ = _mask_v.build_mask(_edge_touch, 0.5)
_r_old_t = _ref_edge_style(_edge_touch, _mt)
_r_new_t = _mask_v.edge_style(_edge_touch, _mt)
check(_r_old_t[0] == _r_new_t[0] and abs(_r_old_t[1] - _r_new_t[1]) < 1e-6,
      "edge_style 与整图版一致：贴左上角的方块（裁区边界不能造假边界）",
      "old=%s %.4f new=%s %.4f" % (_r_old_t[0], _r_old_t[1], _r_new_t[0], _r_new_t[1]))

# ==========================================================================
print("\n[性能] 几百个环的大图不能把 Blender 卡崩（真实崩溃复现）")
print("  崩溃现场：3883x1978 人物贴图 → 380 个环（大量 4 点碎屑）+ 一个 11452 点大环")
print("  split_outer 朴素实现 = 380² 次 × 0.81ms（大环每次遍历 11452 条边）→ 卡死崩溃")
print("  验证点：同规模输入必须 < 200ms")

# 造一个和真实素材同构的输入：1 个大环 + 379 个小环
from image_cutter.ic_core import outline as outline_mod  # noqa: E402

_yy, _xx = np.mgrid[0:800, 0:800]
_big = outline_mod.trace_rings(((_xx - 400) ** 2 + (_yy - 400) ** 2) < 350 ** 2)
check(len(_big) == 1, "造出大环", "%d 环" % len(_big))

# 大环要加密到**万点级**，和真实素材同量级。
#
# 这个数字是注入验证逼出来的：最早只加密到 2000 点，注入「每次重新转换数组」
# 和「取消包围盒预筛」两个 bug 后测试全绿 —— 2000 点的环单次判定才 0.13ms，
# 乘几百次也只有几十毫秒，落在 200ms 门槛内。真实素材是 11452 点（0.81ms/次），
# 才会把退化顶出门槛。**测试规模不匹配，等于没测**。
_big_ring = _big[0]
if len(_big_ring) < 12000:
    _reps = int(12000 / max(len(_big_ring), 1)) + 1
    _dense = []
    for _k in range(len(_big_ring)):
        _p0 = _big_ring[_k]
        _p1 = _big_ring[(_k + 1) % len(_big_ring)]
        for _m in range(_reps):
            _t = _m / float(_reps)
            _dense.append((_p0[0] + (_p1[0] - _p0[0]) * _t,
                           _p0[1] + (_p1[1] - _p0[1]) * _t))
    _big_ring = _dense

# 379 个 4 点碎屑环，散布在大环内部
_rng = np.random.default_rng(9)
_small = []
for _k in range(379):
    _cx = float(_rng.uniform(120, 680))
    _cy = float(_rng.uniform(120, 680))
    _s = 3.0
    _small.append([(_cx - _s, _cy - _s), (_cx + _s, _cy - _s),
                   (_cx + _s, _cy + _s), (_cx - _s, _cy + _s)])

_many = [_big_ring] + _small
_t0 = time.perf_counter()
_out_m, _in_m = outline_mod.split_outer(_many)
many_ms = (time.perf_counter() - _t0) * 1000
check(many_ms < 200, "380 个环（含 2000+ 点大环）的 split_outer < 200ms",
      "%.0fms" % many_ms)
check(len(_out_m) + len(_in_m) == len(_many), "所有环都被分类（没有丢环）",
      "outer=%d inner=%d 总=%d" % (len(_out_m), len(_in_m), len(_many)))
# 正确性：大环必须被判成 outer（不能因为碎屑环多就把自己当洞）
_big_out = [r for r in _out_m if len(r) >= 2000]
check(len(_big_out) == 1, "那个 2000+ 点的大环被判成 outer", "%d 个" % len(_big_out))

# 碎屑环落在大环内部 → 按「奇数个更大的环包住 = 洞」的规则，它们该是 inner。
# 这正是「本插件不保留洞」的设计：内部的窟窿会被填实。
# （一开始我把期望写成「全部 outer」，是测试写错了 —— 规则本身是对的。）
check(len(_in_m) >= len(_small) * 0.9,
      "碎屑环在大环内部 → 被判成洞（符合「不保留镂空」的设计）",
      "inner=%d，碎屑共 %d 个" % (len(_in_m), len(_small)))

# ---- 多点投票必须真的有效（不是摆设）----
# 上面那些性能测试抓不到「退回单点质心」的注入，因为单点更快、结果也差不多。
# 但多点投票的意义在**凹形 + 质心出界**的场景 —— 那才是它存在的理由。
# 这里直接构造一个「质心在环外」的凹环，验证它不被误判成洞。
# C 形（开口朝右）：逆时针走一圈，中间挖掉 x>100 的部分
# ⚠️ 顶点顺序必须严格逆时针且不自交 —— 第一次我手写的坐标顺序是自交的，
#    导致 10 个代表点全判在环外，差点误报成代码 bug（是测试用例写错了）。
_C_ring = [(0.0, 0.0), (0.0, 200.0), (100.0, 200.0), (100.0, 180.0),
           (20.0, 180.0), (20.0, 20.0), (100.0, 20.0), (100.0, 0.0)]
_cx, _cy = outline_mod.ring_centroid(_C_ring)
_centroid_inside = outline_mod.point_in_ring((_cx, _cy), _C_ring)
_probes_c = outline_mod._representative_points(_C_ring)
_inside_probes = sum(1 for p in _probes_c if outline_mod.point_in_ring(p, _C_ring))

check(_inside_probes >= len(_probes_c) - 1,
      "凹环（C 形）的代表点绝大多数落在环内",
      "%d / %d（质心在环内=%s）" % (_inside_probes, len(_probes_c), _centroid_inside))

# 关键行为：把一个 C 形环 + 一个包住它的大环一起喂进去，
# C 形必须是 inner（它被大环包住），而**不能**因为质心在凹口外就翻成 outer。
_outer_box = [(-10.0, -10.0), (210.0, -10.0), (210.0, 210.0), (-10.0, 210.0)]
_po, _pi = outline_mod.split_outer([_outer_box, _C_ring])
check(len(_pi) == 1, "C 形环被正确判成洞（在方框内部）",
      "outer=%d inner=%d" % (len(_po), len(_pi)))

# ==========================================================================
print("\n[算法] split_outer 在凹形环上不能把形状当洞丢掉")
print("  旧行为：用顶点平均当质心，凹形的质心会落到环外 → 嵌套深度算错 → 形状被丢")
print("  验证点：凹形（L / U / 星）的面积必须全部进 outer")

from image_cutter.ic_core import outline as outline_mod  # noqa: E402
from image_cutter.ic_core import mask as mask_mod2  # noqa: E402


def _area_of(ring):
    n = len(ring)
    s = 0.0
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        s += x0 * y1 - x1 * y0
    return abs(s * 0.5)


def _check_shape_kept(name, m, expect_area):
    rings = outline_mod.trace_rings(m)
    outer, inner = outline_mod.split_outer(rings)
    total = sum(_area_of(r) for r in rings)
    kept = sum(_area_of(r) for r in outer)
    # 面积必须保住（允许 1% 误差，环是像素边的中点，跟真实面积差一点点）
    ok = abs(kept - total) / max(total, 1.0) < 0.01
    check(ok, "%s 的形状没被当洞丢掉" % name,
          "环总 %.0f / 保留 %.0f / 期望 %.0f" % (total, kept, expect_area))
    return rings, outer, inner


# L 形：顶点平均质心会压在拐角外侧
_mL = np.zeros((300, 300), dtype=bool)
_mL[50:250, 50:120] = True
_mL[180:250, 50:250] = True
_check_shape_kept("L 形", _mL, 70 * 200 + 130 * 70)

# U 形（顶点会被加密，但凹口仍会让纯顶点平均出界）
_mU = np.zeros((300, 300), dtype=bool)
_mU[50:250, 50:250] = True
_mU[150:250, 100:200] = False
_check_shape_kept("U 形", _mU, 200 * 200 - 100 * 100)

# 五角星
_yy, _xx = np.mgrid[0:300, 0:300]
_ang = np.arctan2(_yy - 150, _xx - 150)
_rad = np.hypot(_xx - 150, _yy - 150)
_mStar = _rad < 120 * (0.6 + 0.4 * np.cos(5 * _ang))
_check_shape_kept("五角星", _mStar, 0)

# 真洞还是要认成 inner（别把修复搞成「一律不丢洞」）
_mHole = np.zeros((300, 300), dtype=bool)
_mHole[50:250, 50:250] = True
_mHole[120:180, 120:180] = False
_rings_h = outline_mod.trace_rings(_mHole)
_outer_h, _inner_h = outline_mod.split_outer(_rings_h)
check(len(_outer_h) == 1 and len(_inner_h) == 1,
      "真洞仍然被认成 inner", "outer=%d inner=%d" % (len(_outer_h), len(_inner_h)))

# 面积质心：L 形的质心必须真的落在环内或贴近（不含 NaN）
_cx, _cy = outline_mod.ring_centroid(outline_mod.trace_rings(_mL)[0])
check(-1e6 < _cx < 1e6 and -1e6 < _cy < 1e6, "面积质心算得出有效值",
      "(%.1f, %.1f)" % (_cx, _cy))

# ---- 分别验证两道防线各自有效 ----
# 上面那些「形状没被丢」的测试有个弱点：面积质心 + 多点投票是**互相兜底**的，
# 单独把其中一个改回旧实现，另一个还能救回来 → 测试照样全绿（实测注入验证过）。
# 所以要直接测这两个函数本身。

# 防线 1：面积质心对凸形要给出正确的几何质心
# 用一个 100x100 的正方形环：面积质心必然在 (50,50)
_sq = [(0.0, 0.0), (100.0, 0.0), (100.0, 100.0), (0.0, 100.0)]
_scx, _scy = outline_mod.ring_centroid(_sq)
check(abs(_scx - 50) < 0.5 and abs(_scy - 50) < 0.5,
      "面积质心：正方形质心 = (50,50)", "(%.2f, %.2f)" % (_scx, _scy))

# 三角形：面积质心 = 顶点平均 = (40,20)
# ⚠️ 这个例子分不出「面积质心」和「顶点平均」—— 两者算出来一样。
#    想验证面积质心确实生效，必须用「顶点分布不均」的环。
_tri = [(0.0, 0.0), (120.0, 0.0), (0.0, 60.0)]
_tcx, _tcy = outline_mod.ring_centroid(_tri)
check(abs(_tcx - 40) < 0.5 and abs(_tcy - 20) < 0.5,
      "面积质心：三角形质心 = (40,20)", "(%.2f, %.2f)" % (_tcx, _tcy))

# 关键用例：顶点严重不均的长方形（一条长边被切成很多段，另一条只 1 段）
# 真实形状 (0..200) x (0..10)，面积质心必然 (100, 5)
# 但「顶点平均」会被顶点密集的那侧拽向 y=0
_uneven = [(0.0, 0.0)]
for _k in range(1, 9):                     # 下边切成 8 段
    _uneven.append((200.0 * _k / 8.0, 0.0))
_uneven.append((200.0, 10.0))              # 右上
_uneven.append((0.0, 10.0))                # 左上
_ucx, _ucy = outline_mod.ring_centroid(_uneven)
_vavg_x = sum(p[0] for p in _uneven) / len(_uneven)
_vavg_y = sum(p[1] for p in _uneven) / len(_uneven)
check(abs(_ucx - 100) < 1.0 and abs(_ucy - 5) < 1.0,
      "面积质心：顶点不均的长方形仍给出几何质心 (100,5)",
      "面积质心=(%.1f,%.1f) 顶点平均=(%.1f,%.1f)" % (_ucx, _ucy, _vavg_x, _vavg_y))
# 这个用例必须真的能区分两种实现，否则测试等于没写
check(abs(_ucy - _vavg_y) > 1.0,
      "该用例能区分面积质心与顶点平均（否则无判别力）",
      "面积质心 y=%.1f vs 顶点平均 y=%.1f" % (_ucy, _vavg_y))

# 防线 2：_representative_points 必须给出「确实在环内」的点
# L 形的面积质心贴着拐角，可能判在环外；但代表点里必须有点被判在环内
_Lring = outline_mod.trace_rings(_mL)[0]
_probes = outline_mod._representative_points(_Lring)
_in_count = sum(1 for p in _probes if outline_mod.point_in_ring(p, _Lring))
check(len(_probes) >= 5, "代表点数量够（多点投票才有意义）", "%d 个" % len(_probes))
check(_in_count >= len(_probes) - 1, "代表点绝大多数落在环内",
      "%d / %d 在环内" % (_in_count, len(_probes)))

# 单点误判的兜底：即使质心在环外，投票结果也不能翻转
_direct = outline_mod.point_in_ring(outline_mod.ring_centroid(_Lring), _Lring)
_c_outer_cnt = 0
for _p in _probes:
    if outline_mod.point_in_ring(_p, _Lring):
        _c_outer_cnt += 1
check(_c_outer_cnt > 0, "L 形至少有一个代表点判定在环内（质心可能不在）",
      "质心在环内=%s，代表点在环内 %d/%d" % (_direct, _c_outer_cnt, len(_probes)))

# ==========================================================================
print("\n[参数] 边缘外扩会填死细镂空（GUI 实测发现）")
print("  症状：1 像素宽的网格线，expand=0 时有 100 个环，expand=1 就变成 1 个环")
print("  验证点：expand=0 保留细线，expand 增大后环数应该减少（而不是静默吃掉细节）")

from image_cutter.ic_core import mask as mask_mod  # noqa: E402
from image_cutter.ic_core import outline as outline_mod  # noqa: E402

# 造一张「带 1 像素宽网格线」的像素画
_ph = np.zeros((200, 200), dtype=bool)
_ph[40:160, 40:160] = True
_ph[40:160, ::20] = False         # 竖线
_ph[::20, 40:160] = False         # 横线

_rings0 = outline_mod.trace_rings(mask_mod.dilate_mask(_ph, 0))
_rings1 = outline_mod.trace_rings(mask_mod.dilate_mask(_ph, 1))
_rings3 = outline_mod.trace_rings(mask_mod.dilate_mask(_ph, 3))

check(len(_rings0) > 20, "expand=0 时细线被保留（环数多）", "%d 环" % len(_rings0))
check(len(_rings1) < len(_rings0) // 2, "expand=1 明显吃掉细线", "%d → %d 环" % (len(_rings0), len(_rings1)))
check(len(_rings3) <= len(_rings1) + 2, "expand 继续增大时环数不再回升", "%d 环" % len(_rings3))
# 环数单调不增：这是「膨胀只会合并，不会凭空造洞」的基本性质
check(len(_rings3) <= len(_rings0), "环数随 expand 单调不增",
      "%d → %d → %d" % (len(_rings0), len(_rings1), len(_rings3)))

# 面板默认值必须是 0（老默认 2 会让细线在用户毫不知情的情况下消失）
_expand_prop = bpy.types.Object.bl_rna.properties["image_cutter"].fixed_type.properties["expand"]
check(abs(_expand_prop.default - 0.0) < 1e-6, "边缘外扩默认值是 0",
      "默认 %g" % _expand_prop.default)

# ==========================================================================
print("\n[参数] density 映射应该是等比，不是线性")
print("  旧行为：线性映射 → 0.85→1.0 面数翻倍（+104%），用户觉得后半段失控")
print("  验证点：相邻 0.1 档位的面数倍率应该基本一致")

_ratios = []
_prev = None
for k in range(11):
    _sp = pipe.spacing_from_density(k / 10.0, 6.0, 48.0)
    _f = 1.0 / (_sp * _sp)          # 面数正比于 1/spacing²
    if _prev is not None:
        _ratios.append(_f / _prev)
    _prev = _f
_spread = max(_ratios) / min(_ratios)
check(_spread < 1.02, "各档位面数倍率一致（等比映射）",
      "倍率 %.3f~%.3f，离散度 %.4f" % (min(_ratios), max(_ratios), _spread))
check(abs(_ratios[0] - 1.52) < 0.06, "每档约 ×1.5", "%.3f" % _ratios[0])

# ---- spacing 的下限必须三处一致（形参默认 / UI 调用 / 文档）----
# 旧行为：形参默认 5.0、函数体 max(6.0,...) 偷偷抬回 6.0、UI 传 5.0、
#         文档写「1.0 → 5px」—— 四处说的不是同一个数。
import inspect as _inspect

_sig = _inspect.signature(pipe.spacing_from_density)
_default_min = _sig.parameters["min_px"].default
check(abs(_default_min - 6.0) < 1e-9, "spacing_from_density 的 min_px 默认是 6.0",
      "%s" % _default_min)

# 显式传值必须被尊重（不能被函数体偷偷抬高）
_v_explicit = pipe.spacing_from_density(1.0, min_px=3.0, max_px=48.0)
check(abs(_v_explicit - 3.0) < 1e-6, "显式传 min_px=3.0 时确实返回 3.0（不再静默改写）",
      "%.3f" % _v_explicit)

# UI 那条路径必须和 pipeline 默认一致
from image_cutter.ic_ui import props as _props_mod   # noqa: E402
_ui_min = _props_mod._density_to_spacing(1.0)
_pipe_min = pipe.spacing_from_density(1.0)
check(abs(_ui_min - _pipe_min) < 1e-6,
      "UI 密度映射的下限和 pipeline 默认一致",
      "UI=%.3f pipeline=%.3f" % (_ui_min, _pipe_min))
check(abs(_pipe_min - 6.0) < 1e-6, "密度 1.0 对应 6px", "%.3f" % _pipe_min)

# 文档里作为「当前规格」的映射说明必须是 6px。
# 注意不能简单断言 "5px" 不出现 —— 文档里有一段历史注记
# （"早先形参默认 5.0 … 文档还写着 1.0 → 5px"），那是解释来龙去脉，该留。
# 所以只查**规格行**（以 "0.0 → 48px" 开头的那一行）里的数字。
_doc = pipe.spacing_from_density.__doc__ or ""
_spec_lines = [ln for ln in _doc.splitlines() if "0.0 →" in ln and "48px" in ln]
check(len(_spec_lines) >= 1, "文档里有规格行（0.0 → 48px …）", "%d 行" % len(_spec_lines))
if _spec_lines:
    _spec = _spec_lines[0]
    check("6px" in _spec, "规格行里密度 1.0 写的是 6px", _spec.strip())
    check("5px" not in _spec, "规格行里不再写 5px", _spec.strip())

# ==========================================================================
print("\n" + "=" * 74)
print("通过 %d / 失败 %d" % (PASS, FAIL))
if FAIL == 0:
    print("全部通过 [OK]")
else:
    print("有失败项 [FAILED]")
print("=" * 74)
