"""钢笔画出来的引导路径 → 栅格化成掩膜。

路径的语义（用户能理解的说法）：

    · 画一条**闭合**路径 → 圈起来的这一块就当作形状。
      自动追踪的结果在这块区域内被覆盖掉。
      适合「自动追得不对，我自己描一遍」。

    · 画**开放**路径 → 沿线加一条「边界」，先把线本身附近标上，
      再让自动结果去覆盖它。适合「这条边应该从这儿切」。

路径点是像素坐标（左上原点），和贴图对齐。

贝塞尔：ps 钢笔那样带控制柄的曲线，在存储上是「采样后的密集点」。
画的时候实时采成点串，这里就只处理点串，不用再管切线 ——
既简化了数据结构，也让「画的」和「存的」永远是同一份东西。
"""

import math

import numpy as np

from .triangulate import points_in_ring


def sample_cubic(p0, c0, c1, p1, steps=12):
    """三次贝塞尔采样。钢笔拖动时把曲线转成点串用。"""
    out = []
    for k in range(1, steps + 1):
        t = k / float(steps)
        u = 1.0 - t
        x = (u * u * u * p0[0] + 3 * u * u * t * c0[0]
             + 3 * u * t * t * c1[0] + t * t * t * p1[0])
        y = (u * u * u * p0[1] + 3 * u * u * t * c0[1]
             + 3 * u * t * t * c1[1] + t * t * t * p1[1])
        out.append((x, y))
    return out


def split_bezier_segment(anchors, seg_index, t):
    """在一条贝塞尔段的参数 t 处插一个锚点，并保持曲线形状不变。

    anchors 是钢笔存储格式 [(x, y, in_dx, in_dy, out_dx, out_dy), ...]；
    seg_index 为 n-1 且路径闭合时，表示「末点 → 首点」那一段。

    返回 (新锚点列表, 新锚点索引)。两个端点的控制柄按 de Casteljau
    拆分更新，插点前后整条曲线逐点相同 —— 用户点曲线加点时，
    不会看到形状突然拐一下。
    """
    n = len(anchors)
    if n < 2:
        return list(anchors), -1
    seg = int(seg_index) % n
    t = min(1.0, max(0.0, float(t)))
    a = tuple(float(v) for v in anchors[seg])
    b = tuple(float(v) for v in anchors[(seg + 1) % n])

    p0 = (a[0], a[1])
    c0 = (a[0] + a[4], a[1] + a[5])
    c1 = (b[0] + b[2], b[1] + b[3])
    p1 = (b[0], b[1])

    def lerp(u, v, k):
        return (u[0] + (v[0] - u[0]) * k,
                u[1] + (v[1] - u[1]) * k)

    q0 = lerp(p0, c0, t)
    q1 = lerp(c0, c1, t)
    q2 = lerp(c1, p1, t)
    r0 = lerp(q0, q1, t)
    r1 = lerp(q1, q2, t)
    s = lerp(r0, r1, t)

    out = [tuple(float(v) for v in p) for p in anchors]
    aa = list(out[seg])
    aa[4] = q0[0] - p0[0]
    aa[5] = q0[1] - p0[1]
    out[seg] = tuple(aa)

    bi = (seg + 1) % n
    bb = list(out[bi])
    bb[2] = q2[0] - p1[0]
    bb[3] = q2[1] - p1[1]
    out[bi] = tuple(bb)

    mid = (s[0], s[1], r0[0] - s[0], r0[1] - s[1],
           r1[0] - s[0], r1[1] - s[1])
    pos = seg + 1
    out.insert(pos, mid)
    return out, pos


def anchors_to_points(anchors, curve_steps=12, closed=False):
    """锚点 + 控制柄 → 密集点串。

    anchors: [(x, y, in_dx, in_dy, out_dx, out_dy), ...]
    这是钢笔的存储格式：锚点位置 + 相对它的两个控制柄偏移。
    采样成点串之后，下游（栅格化 / 轮廓）只认点串，不用管曲线。
    closed=True 时补采「末点 → 首点」这一段；少了它，闭合路径的
    最后一段曲线会在填充时退化成首尾直线。
    """
    if not anchors:
        return []
    pts = [tuple(float(v) for v in a) for a in anchors]
    out = [(pts[0][0], pts[0][1])]
    last = len(pts) if closed else len(pts) - 1
    for k in range(last):
        a = pts[k]
        b = pts[(k + 1) % len(pts)]
        c0 = (a[0] + a[4], a[1] + a[5])      # 前一点的出柄
        c1 = (b[0] + b[2], b[1] + b[3])      # 后一点的入柄
        out.extend(sample_cubic((a[0], a[1]), c0, c1, (b[0], b[1]), curve_steps))
    return out


def stroke_to_points(stroke, curve_steps=12, closed=False):
    """把一条钢笔画转成密集点串。

    支持两种存法：
      · 只有顶点（折线）
      · 顶点 + 控制柄（贝塞尔）—— 控制柄按「上一段出柄、下一段入柄」成对读
    """
    pts = list(stroke)
    if not pts:
        return []

    if len(pts) >= 3 and all(len(p) >= 6 for p in pts):
        # 每项 = (x, y, in_dx, in_dy, out_dx, out_dy)
        out = [(pts[0][0], pts[0][1])]
        last = len(pts) if closed else len(pts) - 1
        for k in range(last):
            a = pts[k]
            b = pts[(k + 1) % len(pts)]
            c0 = (a[0] + a[4], a[1] + a[5])     # 前一点的出柄
            c1 = (b[0] + b[2], b[1] + b[3])     # 后一点的入柄
            out.extend(sample_cubic((a[0], a[1]), c0, c1, (b[0], b[1]), curve_steps))
        return out

    return [(float(p[0]), float(p[1])) for p in pts]


def _dense(poly, step=1.5, closed=False):
    """把折线按步长加密，保证栅格化不漏缝。

    closed 决定要不要把「末点→首点」也算一段：
    开放路径算上那一段会凭空把线闭合成一个环，用户画一条横线，
    结果圈出一大块 —— 症状是「我明明只画了一条线，怎么整块都变了」。
    """
    if len(poly) < 2:
        return poly
    out = []
    n = len(poly)
    last = n if closed else n - 1
    for k in range(last):
        x0, y0 = poly[k]
        x1, y1 = poly[(k + 1) % n]
        out.append((float(x0), float(y0)))
        seg = math.hypot(x1 - x0, y1 - y0)
        steps = int(seg / step)
        for m in range(1, steps + 1):
            t = m / (steps + 1.0)
            out.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    if not closed:
        out.append((float(poly[-1][0]), float(poly[-1][1])))
    return out


def _fill_polygon(out, pts, value, x0, y0, x1, y1):
    """扫描线填充多边形（even-odd），写进 out[y0:y1, x0:x1]。

    【为什么不用逐像素射线法】

    早先是「把包围盒里每个像素都拿去和所有边做射线法」。复杂度是
    **像素数 × 边数**：2048² 图上一个 200 点的曲线环 = 400 万 × 200 = 8 亿次，
    实测要好几秒；换成扫描线后是 **行数 × 边数** = 2048 × 200 = 41 万次，
    快三个数量级，而且天然处理凹多边形和自交（even-odd 规则）。

    even-odd 的意思：一条水平射线穿过奇数条边 = 在里面。
    所以把交点排序后两两成对填充即可。
    """
    arr = np.asarray(pts, dtype=np.float64)
    n = len(arr)
    if n < 3:
        return

    sub = out[y0:y1, x0:x1]
    sub_h, sub_w = sub.shape

    xa = arr[:, 0]
    ya = arr[:, 1]
    xb = np.roll(xa, -1)
    yb = np.roll(ya, -1)

    # 像素中心：像素 (j, i) 的中心是 (j+0.5, i+0.5)
    rows = np.arange(y0, y1, dtype=np.float64) + 0.5

    # (边数, 行数) 的穿越掩膜。半开区间 (ya > y) != (yb > y) 避免顶点被算两次。
    cond = (ya[:, None] > rows[None, :]) != (yb[:, None] > rows[None, :])
    dy = yb - ya
    dy_safe = np.where(np.abs(dy) < 1e-12, 1e-12, dy)
    t = (rows[None, :] - ya[:, None]) / dy_safe[:, None]
    xc = xa[:, None] + t * (xb - xa)[:, None]
    xc = np.where(cond, xc, np.nan)

    # 逐行取交点、排序、成对填。行数一般几千，Python 循环开销可忽略。
    #
    # ⚠️ 交点 xc 是**图像绝对坐标**，而 sub 是从 x0 开始的切片 ——
    #    填的时候必须减掉 x0 换成列内偏移。早先直接拿绝对坐标当列索引，
    #    结果 60~140 的矩形只填了右边缘附近一小条（列 116~144），
    #    症状是「画了个框，只有框右边一小块变色」，很容易误判成路径没闭合。
    for ri in range(sub_h):
        xs = xc[:, ri]
        xs = xs[~np.isnan(xs)]
        if xs.size < 2:
            continue
        xs.sort()
        for k in range(0, xs.size - 1, 2):
            lo = int(np.ceil(xs[k] - 0.5)) - x0
            hi = int(np.floor(xs[k + 1] - 0.5)) - x0
            if lo < 0:
                lo = 0
            if hi > sub_w - 1:
                hi = sub_w - 1
            if hi >= lo:
                sub[ri, lo:hi + 1] = value


def _stamp_segment(out, ax, ay, bx, by, radius, value):
    """把「到线段 (a,b) 距离 <= radius」的像素标上值。

    只扫**这一段自己的包围盒**，不是整条路径的包围盒。
    这一条就是手绘引导从「45 秒」变成「毫秒」的关键：
    原来每条加密段都要拿整幅图（400 万像素）算一遍距离，
    现在每段只碰它附近几十个像素。
    """
    r = radius + 1.0
    h, w = out.shape
    x0 = max(0, int(math.floor(min(ax, bx) - r)))
    y0 = max(0, int(math.floor(min(ay, by) - r)))
    x1 = min(w, int(math.ceil(max(ax, bx) + r)) + 1)
    y1 = min(h, int(math.ceil(max(ay, by) + r)) + 1)
    if x1 <= x0 or y1 <= y0:
        return

    xs = np.arange(x0, x1, dtype=np.float64) + 0.5
    ys = np.arange(y0, y1, dtype=np.float64) + 0.5
    gx, gy = np.meshgrid(xs, ys)

    dx = bx - ax
    dy = by - ay
    l2 = dx * dx + dy * dy
    if l2 <= 1e-12:
        d2 = (gx - ax) ** 2 + (gy - ay) ** 2
    else:
        t = np.clip(((gx - ax) * dx + (gy - ay) * dy) / l2, 0.0, 1.0)
        d2 = (gx - (ax + t * dx)) ** 2 + (gy - (ay + t * dy)) ** 2

    hit = d2 <= (radius + 0.5) ** 2
    if hit.any():
        out[y0:y1, x0:x1][hit] = value


def rasterize(strokes, width, height, line_radius=2.0, closed_value=1):
    """笔画列表 → 三态掩膜 (H, W) int8。

    strokes: [(点串, 是否闭合[, 圈内值])]，点串是像素坐标。
    第三项可选；不传时用 closed_value，第三方旧调用保持兼容。
    closed_value: 闭合路径圈内默认标什么（+1 = 补实心 / -1 = 挖空）
    返回 +1 = 强制实心，-1 = 强制空心，0 = 不管

    【语义】闭合路径 = 圈定一块区域（圈内标这份笔画自己的值，圈外不管）；
    开放路径 = 沿线切一刀（线附近标 -1）。因此同一个对象里可以同时存在
    「这一圈补、那一圈挖」，第三项就是给这种情况用的。
    """
    out = np.zeros((height, width), dtype=np.int8)
    if not strokes:
        return out

    for stroke in strokes:
        if len(stroke) >= 3:
            poly, closed, value = stroke[0], stroke[1], stroke[2]
        else:
            poly, closed, value = stroke[0], stroke[1], closed_value
        pts = [(float(p[0]), float(p[1])) for p in poly]
        if len(pts) < 2:
            continue

        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        pad = int(math.ceil(line_radius)) + 2
        x0 = max(0, int(math.floor(min(xs))) - pad)
        y0 = max(0, int(math.floor(min(ys))) - pad)
        x1 = min(width, int(math.ceil(max(xs))) + pad + 1)
        y1 = min(height, int(math.ceil(max(ys))) + pad + 1)
        if x1 <= x0 or y1 <= y0:
            continue

        if closed and len(pts) >= 3:
            _fill_polygon(out, pts, int(value), x0, y0, x1, y1)
        else:
            # 开放路径：沿线切。按 line_radius 的一半加密，
            # 保证相邻两段之间的距离不超过半径，粗线不会断。
            dense = _dense(pts, step=max(1.0, line_radius * 0.5), closed=False)
            for k in range(len(dense) - 1):
                ax, ay = dense[k]
                bx, by = dense[k + 1]
                _stamp_segment(out, ax, ay, bx, by, line_radius, -1)

    return out
