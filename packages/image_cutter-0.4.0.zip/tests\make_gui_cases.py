# -*- coding: utf-8 -*-
"""造一个 GUI 自查用的场景：覆盖面板的各条分支。

    blender --background --factory-startup --python tests/make_gui_cases.py -- <输出.blend>

场景里放 5 个平面，分别对应面板会走到的不同分支：
  1. Star      正常带 alpha 的图      → 「下一步：点这里生成」
  2. NoImage   有材质但没有图片节点    → 红框提示缺节点
  3. Opaque    有图片但无 alpha        → 红框提示没有透明区
  4. Pixel     像素画（硬边）          → 生成后提示跳过圆滑
  5. Big       大图（测性能）          → 生成后看耗时

其中 Star 会先生成一次，这样打开就能直接看到「参数面板」长什么样。
"""
import io
import math
import os
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG)
for _p in (ADDONS, PKG, HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import image_cutter                                          # noqa: E402
if not hasattr(bpy.types.Object, "image_cutter"):
    image_cutter.register()

argv = sys.argv
if "--" in argv:
    OUT = argv[argv.index("--") + 1]
else:
    OUT = os.path.join(os.path.dirname(PKG), "ic_gui_cases.blend")


def log(*a):
    print("[cases]", *a, flush=True)


def make_img_from_rgba(name, rgba):
    h, w = rgba.shape[:2]
    img = bpy.data.images.new(name, width=w, height=h, alpha=True)
    img.pixels.foreach_set(rgba[::-1].ravel())
    img.pack()
    return img


def star_alpha(w=512, h=512):
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = w * 0.5, h * 0.5
    ang = np.arctan2(yy - cy, xx - cx)
    rad = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    # 五角星：半径随角度周期变化
    k = 5
    r_out = min(w, h) * 0.44
    r_in = r_out * 0.42
    t = (np.cos(k * (ang - math.pi / 2)) + 1.0) * 0.5
    edge = r_in + (r_out - r_in) * t
    a = np.clip((edge - rad) / 2.0 + 0.5, 0, 1)
    rgba = np.zeros((h, w, 4), dtype=np.float32)
    rgba[:, :, 0] = 0.85
    rgba[:, :, 1] = 0.35
    rgba[:, :, 2] = 0.55
    rgba[:, :, 3] = a
    return rgba


def opaque_rgba(w=256, h=256):
    yy, xx = np.mgrid[0:h, 0:w]
    rgba = np.zeros((h, w, 4), dtype=np.float32)
    rgba[:, :, 0] = 0.2 + 0.6 * (xx / w)
    rgba[:, :, 1] = 0.5
    rgba[:, :, 2] = 0.8 - 0.5 * (yy / h)
    rgba[:, :, 3] = 1.0
    return rgba


def pixel_rgba(w=128, h=128):
    """硬边像素画：一个方块 + 一个小洞，边界突变。"""
    rgba = np.zeros((h, w, 4), dtype=np.float32)
    rgba[24:104, 24:104, :3] = (0.95, 0.75, 0.15)
    rgba[24:104, 24:104, 3] = 1.0
    rgba[52:76, 52:76, 3] = 0.0        # 中间挖个洞
    rgba[:, :, 0] = np.where(rgba[:, :, 3] > 0, 0.95, 0)
    rgba[:, :, 1] = np.where(rgba[:, :, 3] > 0, 0.75, 0)
    rgba[:, :, 2] = np.where(rgba[:, :, 3] > 0, 0.15, 0)
    return rgba


def big_alpha(w=2048, h=2048):
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = w * 0.5, h * 0.5
    rad = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    edge = min(w, h) * 0.45
    a = np.clip((edge - rad) / 3.0 + 0.5, 0, 1)
    rgba = np.zeros((h, w, 4), dtype=np.float32)
    rgba[:, :, 0] = 0.25
    rgba[:, :, 1] = 0.65
    rgba[:, :, 2] = 0.85
    rgba[:, :, 3] = a
    return rgba


def make_plane(name, img, loc, size=2.0, link_image=True, make_material=True):
    bpy.ops.mesh.primitive_plane_add(size=size, location=loc)
    p = bpy.context.active_object
    p.name = name
    if not make_material:
        return p
    m = bpy.data.materials.new(name + "_mat")
    nt = m.node_tree
    if nt is None:
        m.use_nodes = True
        nt = m.node_tree
    if link_image and img is not None:
        tex = nt.nodes.new("ShaderNodeTexImage")
        tex.image = img
        for n in nt.nodes:
            if n.type == "BSDF_PRINCIPLED":
                nt.links.new(tex.outputs["Color"], n.inputs["Base Color"])
                nt.links.new(tex.outputs["Alpha"], n.inputs["Alpha"])
                break
    p.data.materials.append(m)
    return p


def only(o):
    for x in bpy.data.objects:
        x.select_set(False)
    if o:
        o.select_set(True)
        bpy.context.view_layer.objects.active = o


bpy.ops.wm.read_factory_settings(use_empty=True)

# ---- 1. 正常五角星 ----
img_star = make_img_from_rgba("StarTex", star_alpha())
p_star = make_plane("Star", img_star, (0.0, 0.0, 0.0))

# ---- 2. 有材质但没图片节点 ----
p_noimg = make_plane("NoImage", None, (3.2, 0.0, 0.0), link_image=False)

# ---- 3. 有图片但无 alpha ----
img_opaque = make_img_from_rgba("OpaqueTex", opaque_rgba())
p_opaque = make_plane("Opaque", img_opaque, (6.4, 0.0, 0.0))

# ---- 4. 像素画 ----
img_pixel = make_img_from_rgba("PixelTex", pixel_rgba())
p_pixel = make_plane("Pixel", img_pixel, (9.6, 0.0, 0.0))

# ---- 5. 大图 ----
img_big = make_img_from_rgba("BigTex", big_alpha())
p_big = make_plane("Big", img_big, (12.8, 0.0, 0.0))

# ---- 生成 Star 和 Pixel，留出「已有生成物」的分支 ----
for pl in (p_star, p_pixel):
    only(pl)
    try:
        r = bpy.ops.image_cutter.generate()
        log("%s generate → %s" % (pl.name, r))
    except RuntimeError as e:
        log("%s generate 抛错: %s" % (pl.name, e))

# 把相机摆在能一眼看全的位置
cam_data = bpy.data.cameras.new("CaseCam")
cam = bpy.data.objects.new("CaseCam", cam_data)
bpy.context.scene.collection.objects.link(cam)
cam.location = (6.4, -16.0, 14.0)
cam.rotation_euler = (math.radians(48), 0, 0)
cam_data.lens = 32
bpy.context.scene.camera = cam

# 打个 sun 免得全黑
light_data = bpy.data.lights.new("CaseSun", type="SUN")
light_data.energy = 3.0
light = bpy.data.objects.new("CaseSun", light_data)
bpy.context.scene.collection.objects.link(light)
light.rotation_euler = (math.radians(50), math.radians(20), math.radians(30))

# 让视口用相机视角
for win in bpy.context.window_manager.windows:
    for area in win.screen.areas:
        if area.type == "VIEW_3D":
            sp = area.spaces.active
            if sp.region_3d:
                sp.region_3d.view_perspective = "CAMERA"
            sp.shading.type = "MATERIAL"
            sp.show_region_ui = True

only(p_star)
bpy.ops.wm.save_as_mainfile(filepath=OUT)
log("已保存 %s" % OUT)
log("对象：%s" % [o.name for o in bpy.data.objects if o.type == "MESH"])
