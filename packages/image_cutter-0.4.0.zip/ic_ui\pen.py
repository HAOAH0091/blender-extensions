"""钢笔工具：对着源平面画路径。

【为什么画在 3D 视口，而不是图片编辑器】

图片编辑器看着更「像画图」，但它的「屏幕 ↔ 图像像素」换算没有现成工具，
得自己摸 zoom / offset，Blender 各版本还不一样，很容易画歪。

3D 视口这边有 `view3d_utils` 现成的坐标工具：鼠标位置 → 射线，
射线和源平面求交 → 世界坐标 → 平面本地坐标 → 像素坐标。
换算链路每一段都有官方函数兜底，而且**画的时候能同时看到网格在变**。

代价是需要正对着平面画才不变形 —— 所以面板上提示先切顶视图（小键盘 7）。

交互照着 PS 钢笔来：

    左键点击        落一个锚点
    按住左键拖      拉出这个锚点的对称控制柄（曲线就出来了）
    C               闭合当前路径并结束
    回车 / 右键     结束当前路径（不闭合）
    Delete          退回上一个锚点
    Esc             整个取消

路径存的是「锚点 + 进出控制柄」，不是采样后的点串 ——
既能无损再编辑，也让存的东西和画的时候看到的是同一份。
"""

import math
import time

import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from ..ic_bpy import imgio
from ..ic_core import guide as guide_mod


_OVERLAY_HANDLE = None
_KEYMAP_ITEM = None
_ACTIVE_PEN = None

_BADGE_BG = (0.09, 0.09, 0.11, 0.88)
_AA_SHADER = None


def _aa_shader():
    """带顶点色的着色器，用来做边缘透明羽化（真抗锯齿）。

    UNIFORM_COLOR 只能整块一个颜色，画出来的斜线全是台阶；SMOOTH_COLOR
    允许每个顶点带 alpha，于是可以在 1px 的边缘上做 1→0 的渐变。
    """
    global _AA_SHADER
    if _AA_SHADER is None:
        try:
            _AA_SHADER = gpu.shader.from_builtin("SMOOTH_COLOR")
        except Exception:                        # noqa: BLE001
            _AA_SHADER = False
    return _AA_SHADER or None


def _draw_aa(pos, col):
    if not pos:
        return
    shader = _aa_shader()
    if shader is None:
        return
    try:
        gpu.state.blend_set("ALPHA")
        batch_for_shader(shader, "TRIS",
                         {"pos": pos, "color": col}).draw(shader)
    except Exception:                            # noqa: BLE001
        pass


def _ui_scale():
    """界面缩放。POST_PIXEL 坐标是物理像素，尺寸要跟着放大才不显细。"""
    try:
        return max(1.0, min(2.0, float(
            bpy.context.preferences.system.ui_scale)))
    except Exception:                            # noqa: BLE001
        return 1.0


def _line_normals(coords):
    """每个采样点的左法线（已含斜接缩放），保证粗线拐角不断开。"""
    n = len(coords)
    dirs = []
    for k in range(n - 1):
        dx = coords[k + 1][0] - coords[k][0]
        dy = coords[k + 1][1] - coords[k][1]
        length = math.hypot(dx, dy)
        if length < 1e-6:
            dirs.append(None)
        else:
            dirs.append((dx / length, dy / length))
    out = []
    for k in range(n):
        if k == 0:
            d = dirs[0]
            scale = 1.0
        elif k == n - 1:
            d = dirs[-1]
            scale = 1.0
        else:
            a = dirs[k - 1]
            b = dirs[k]
            if a is None:
                a = b
            if b is None:
                b = a
            if a is None:
                out.append((0.0, 0.0))
                continue
            mx, my = a[0] + b[0], a[1] + b[1]
            ml = math.hypot(mx, my)
            if ml < 1e-6:
                d = a
                scale = 1.0
            else:
                mx /= ml
                my /= ml
                d = (mx, my)
                scale = 1.0 / max(0.45, mx * a[0] + my * a[1])
        if d is None:
            out.append((0.0, 0.0))
            continue
        scale = min(scale, 2.4)
        out.append((-d[1] * scale, d[0] * scale))
    return out


def _band(pos, col, a_pts, b_pts, ca, cb):
    for k in range(len(a_pts) - 1):
        a0, a1 = a_pts[k], a_pts[k + 1]
        b0, b1 = b_pts[k], b_pts[k + 1]
        pos.extend((a0, b0, b1, a0, b1, a1))
        col.extend((ca, cb, cb, ca, cb, ca))


def _line_geo(coords, width, color, aa=0.9):
    """折线 → (pos, color)。内核 + 两侧 1px 的透明羽化边。"""
    n = len(coords)
    if n < 2:
        return [], []
    half = max(0.35, width * 0.5)
    normals = _line_normals(coords)
    lo, li, ri, ro = [], [], [], []
    for k, (x, y) in enumerate(coords):
        nx, ny = normals[k]
        lo.append((x + nx * (half + aa), y + ny * (half + aa)))
        li.append((x + nx * half, y + ny * half))
        ri.append((x - nx * half, y - ny * half))
        ro.append((x - nx * (half + aa), y - ny * (half + aa)))
    pos = []
    col = []
    cin = color
    cout = (color[0], color[1], color[2], 0.0)
    _band(pos, col, lo, li, cout, cin)
    _band(pos, col, li, ri, cin, cin)
    _band(pos, col, ri, ro, cin, cout)
    return pos, col


def _disc_geo(cx, cy, r, color, aa=0.8, segs=20):
    """实心圆 + 1px 羽化边。"""
    pos = []
    col = []
    cin = color
    cout = (color[0], color[1], color[2], 0.0)
    for k in range(segs):
        a0 = 2.0 * math.pi * k / segs
        a1 = 2.0 * math.pi * (k + 1) / segs
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)
        i0 = (cx + r * c0, cy + r * s0)
        i1 = (cx + r * c1, cy + r * s1)
        o0 = (cx + (r + aa) * c0, cy + (r + aa) * s0)
        o1 = (cx + (r + aa) * c1, cy + (r + aa) * s1)
        pos.extend(((cx, cy), i0, i1))
        col.extend((cin, cin, cin))
        pos.extend((i0, o0, o1, i0, o1, i1))
        col.extend((cin, cout, cout, cin, cout, cin))
    return pos, col


def _ring_geo(cx, cy, r_in, r_out, color, aa=0.8, segs=24):
    """圆环 + 内外两侧羽化。"""
    gap = r_out - r_in
    if gap <= 1e-6:
        return [], []
    t = min(aa, gap * 0.45)
    radii = (r_in, r_in + t, r_out - t, r_out)
    alphas = (0.0, 1.0, 1.0, 0.0)
    pos = []
    col = []
    for k in range(segs):
        a0 = 2.0 * math.pi * k / segs
        a1 = 2.0 * math.pi * (k + 1) / segs
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)
        for j in range(3):
            r0, r1 = radii[j], radii[j + 1]
            a_in = alphas[j]
            a_out = alphas[j + 1]
            ca = (color[0], color[1], color[2], color[3] * a_in)
            cb = (color[0], color[1], color[2], color[3] * a_out)
            p00 = (cx + r0 * c0, cy + r0 * s0)
            p01 = (cx + r1 * c0, cy + r1 * s0)
            p11 = (cx + r1 * c1, cy + r1 * s1)
            p10 = (cx + r0 * c1, cy + r0 * s1)
            pos.extend((p00, p01, p11, p00, p11, p10))
            col.extend((ca, cb, cb, ca, cb, ca))
    return pos, col


def _dash_polylines(coords, dash=7.0, gap=5.0):
    """按屏幕弧长切虚线。开放路径和停用路径靠它一眼区分。"""
    out = []
    cur = []
    drawing = True
    remain = max(0.5, dash)
    for k in range(len(coords) - 1):
        x0, y0 = coords[k]
        x1, y1 = coords[k + 1]
        length = math.hypot(x1 - x0, y1 - y0)
        if length < 1e-9:
            continue
        dx, dy = (x1 - x0) / length, (y1 - y0) / length
        pos = 0.0
        while pos < length - 1e-9:
            step = min(remain, length - pos)
            ax, ay = x0 + dx * pos, y0 + dy * pos
            pos += step
            bx, by = x0 + dx * pos, y0 + dy * pos
            if drawing:
                if not cur:
                    cur = [(ax, ay)]
                cur.append((bx, by))
            remain -= step
            if remain <= 1e-9:
                if drawing and len(cur) >= 2:
                    out.append(cur)
                cur = []
                drawing = not drawing
                remain = dash if drawing else gap
    if drawing and len(cur) >= 2:
        out.append(cur)
    return out


def _stroke_line(coords, color, width=1.4, dashed=False):
    """细线 + 1px 羽化边。描边按用户反馈去掉了，靠颜色本身区分。"""
    u = _ui_scale()
    parts = _dash_polylines(coords, 7.0 * u, 5.0 * u) if dashed else [coords]
    if not parts:
        return
    pos = []
    col = []
    for part in parts:
        p, c = _line_geo(part, width * u, color)
        pos.extend(p)
        col.extend(c)
    _draw_aa(pos, col)


def _dots(points, radius, color):
    """批量画圆点（锚点/控制柄），比逐个画省 draw call。"""
    if not points:
        return
    u = _ui_scale()
    r = max(0.8, radius * u)
    pos = []
    col = []
    for (x, y) in points:
        p, c = _disc_geo(x, y, r, color)
        pos.extend(p)
        col.extend(c)
    _draw_aa(pos, col)


def _ring(x, y, r_in, r_out, color, segs=24):
    u = _ui_scale()
    pos, col = _ring_geo(x, y, r_in * u, r_out * u, color,
                         aa=0.6, segs=segs)
    _draw_aa(pos, col)


def _badge(x, y, text, color):
    """路径编号徽标：和面板里的「1 闭·挖 / 2 开·切」对上号。

    形状和颜色能表达补/挖，但同一张图上常常有好几条同色路径，
    没有编号就只能靠猜哪条对应面板哪一行。
    """
    try:
        import blf
    except Exception:                            # noqa: BLE001
        return
    u = _ui_scale()
    r = 9.0 * u
    pos, col = _disc_geo(x, y, r, _BADGE_BG, aa=0.7, segs=20)
    rpos, rcol = _ring_geo(x, y, r - 1.5 * u, r, color,
                           aa=0.5, segs=20)
    pos.extend(rpos)
    col.extend(rcol)
    _draw_aa(pos, col)
    try:
        blf.size(0, int(round(10.0 * u)))
        tw, th = blf.dimensions(0, text)
        blf.color(0, 1.0, 1.0, 1.0, 0.95)
        # 5.x 的 blf.draw 只收 (fontid, text)，坐标必须先 position；
        # 4.x 的旧签名是 draw(fontid, text, x, y)。两套都兼容。
        try:
            blf.position(0, x - tw * 0.5, y - th * 0.5, 0.0)
            blf.draw(0, text)
        except TypeError:
            blf.draw(0, text, x - tw * 0.5, y - th * 0.5)
    except Exception:                            # noqa: BLE001
        pass


def _badge_center(context, anchor_screen, u=None):
    """编号徽标的屏幕中心。绘制和点击命中共用同一套偏移/夹取。"""
    region = context.region
    if region is None or not anchor_screen:
        return None
    if u is None:
        u = _ui_scale()
    x, y = anchor_screen[0]
    bx = min(max(x, 12.0 * u),
             max(12.0 * u, region.width - 12.0 * u))
    by = min(max(y + 14.0 * u, 12.0 * u),
             max(12.0 * u, region.height - 12.0 * u))
    return bx, by


def _iter_badges(context, settings, src, img_size, size):
    """当前对象所有路径的 (序号, 屏幕x, 屏幕y)。和叠加层绘制一一对应。"""
    u = _ui_scale()
    out = []
    for idx, st in enumerate(settings.strokes):
        anchors = _stroke_anchors(st)
        if len(anchors) < 2:
            continue
        sc = _screen_of(context, src, img_size, size,
                        anchors[0][0], anchors[0][1])
        if sc is None:
            continue
        center = _badge_center(context, [sc], u)
        if center is not None:
            out.append((idx, center[0], center[1]))
    return out


def _nearest_badge(badges, mx, my, radius):
    """最近编号（带命中半径）；没命中返回 -1。"""
    best = -1
    best_d = radius
    for idx, bx, by in badges:
        d = math.hypot(bx - mx, by - my)
        if d <= best_d:
            best_d = d
            best = idx
    return best


def _badge_hit(context, settings, src, img_size, size, mx, my):
    """点到了哪个编号徽标；没点中返回 -1。"""
    return _nearest_badge(
        _iter_badges(context, settings, src, img_size, size),
        mx, my, 12.0 * _ui_scale(),
    )


def _stroke_anchors(stroke):
    return [(float(p.x), float(p.y),
             float(p.in_dx), float(p.in_dy),
             float(p.out_dx), float(p.out_dy)) for p in stroke.points]


def _screen_of(context, source, img_size, size, px, py):
    """贴图像素坐标 → 屏幕坐标。钢笔模态和常驻叠加层共用。"""
    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None:
        return None
    w, h = img_size
    sx, sy = size
    if w <= 0 or h <= 0:
        return None
    u = px / float(w)
    v = 1.0 - py / float(h)
    local = Vector(((u - 0.5) * sx, (v - 0.5) * sy, 0.0))
    world = source.matrix_world @ local
    return view3d_utils.location_3d_to_region_2d(region, rv3d, world)


def _view_signature(context):
    """当前视口的投影指纹。缩放/平移后屏幕坐标缓存必须失效。"""
    if context is None:
        return None
    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None:
        return None
    try:
        mat = tuple(round(float(v), 6)
                    for row in rv3d.perspective_matrix for v in row)
    except Exception:                            # noqa: BLE001
        mat = ()
    return (region.width, region.height, mat)


def _bezier_xy(a, b, t):
    """两锚点之间贝塞尔段在参数 t 处的贴图像素坐标。"""
    p0 = (a[0], a[1])
    c0 = (a[0] + a[4], a[1] + a[5])
    c1 = (b[0] + b[2], b[1] + b[3])
    p1 = (b[0], b[1])
    u = 1.0 - t
    x = (u * u * u * p0[0] + 3 * u * u * t * c0[0]
         + 3 * u * t * t * c1[0] + t * t * t * p1[0])
    y = (u * u * u * p0[1] + 3 * u * u * t * c0[1]
         + 3 * u * t * t * c1[1] + t * t * t * p1[1])
    return x, y


def _curve_steps(context, source, img_size, size, a, b):
    """按屏幕上的控制多边形长度决定采样步数。

    固定 16 步在放大后能看出折角（一段跨半屏时相邻采样点差几十像素）。
    按 6px 一段自适应，放大仍然顺滑，缩小时也不会白算。
    """
    nodes = ((a[0], a[1]),
             (a[0] + a[4], a[1] + a[5]),
             (b[0] + b[2], b[1] + b[3]),
             (b[0], b[1]))
    total = 0.0
    prev = None
    for (x, y) in nodes:
        sc = _screen_of(context, source, img_size, size, x, y)
        if sc is None:
            return 16
        if prev is not None:
            total += math.hypot(sc[0] - prev[0], sc[1] - prev[1])
        prev = sc
    return max(10, min(48, int(total / (6.0 * _ui_scale()))))


def _curve_screen(context, source, img_size, size, a, b, steps=None):
    """两锚点之间的贝塞尔段 → 屏幕坐标串。"""
    if steps is None:
        steps = _curve_steps(context, source, img_size, size, a, b)
    out = []
    for k in range(steps + 1):
        t = k / float(steps)
        x, y = _bezier_xy(a, b, t)
        sc = _screen_of(context, source, img_size, size, x, y)
        if sc is None:
            return []
        out.append((sc[0], sc[1]))
    return out


def _anchor_curve_screen(op, context, anchors, closed=False, steps=None):
    """锚点串 → 屏幕折线。闭合路径会补上「末点 → 首点」那一段。"""
    n = len(anchors)
    if n < 2:
        return []
    last = n if closed else n - 1
    out = []
    for k in range(last):
        a = anchors[k]
        b = anchors[(k + 1) % n]
        out.extend(op.curve_screen(context, a, b, steps=steps))
    return out


def _closest_on_screen_polyline(coords, mx, my):
    """点到屏幕折线的最近位置，返回 (距离, t∈[0,1])。"""
    if len(coords) < 2:
        return 1e30, 0.0
    best_d = 1e30
    best_t = 0.0
    for k in range(len(coords) - 1):
        ax, ay = coords[k]
        bx, by = coords[k + 1]
        dx = bx - ax
        dy = by - ay
        l2 = dx * dx + dy * dy
        if l2 < 1e-12:
            frac = 0.0
        else:
            frac = ((mx - ax) * dx + (my - ay) * dy) / l2
            frac = min(1.0, max(0.0, frac))
        qx = ax + dx * frac
        qy = ay + dy * frac
        d = math.hypot(mx - qx, my - qy)
        if d < best_d:
            best_d = d
            best_t = (k + frac) / float(len(coords) - 1)
    return best_d, best_t


def _store_stroke(settings, points, closed, edit_index=-1, mode=None):
    """把锚点写进对象设置；edit_index>=0 时覆盖原路径而不是新增。"""
    if 0 <= int(edit_index) < len(settings.strokes):
        st = settings.strokes[int(edit_index)]
        st.points.clear()
    else:
        st = settings.strokes.add()
        st.mode = "auto"
    st.closed = bool(closed)
    if mode is not None:
        st.mode = mode
    for (px, py, ix, iy, ox, oy) in points:
        p = st.points.add()
        p.x = px
        p.y = py
        p.in_dx = ix
        p.in_dy = iy
        p.out_dx = ox
        p.out_dy = oy
    return st


def _stroke_matches(settings, index, points, closed, mode):
    """当前存储的路径是否已经等于这份编辑状态。"""
    index = int(index)
    if not (0 <= index < len(settings.strokes)):
        return False
    st = settings.strokes[index]
    stored = _stroke_anchors(st)
    if len(stored) != len(points) or bool(st.closed) != bool(closed):
        return False
    if getattr(st, "mode", "auto") != mode:
        return False
    for a, b in zip(stored, points):
        if any(abs(float(x) - float(y)) > 1e-9 for x, y in zip(a, b)):
            return False
    return True


def _persist_edit(settings, index, points, closed, mode):
    """把编辑中的状态写回路径；返回是否真的发生了修改。

    编辑时不再等回车才落盘：拖完一个锚点、插点或删点就写回并安排重建，
    用户能立即看到引导对网格的影响。Esc 会用进入编辑时的快照恢复。
    """
    if not (0 <= int(index) < len(settings.strokes)):
        return False
    if _stroke_matches(settings, index, points, closed, mode):
        return False
    _store_stroke(settings, points, closed, index, mode=mode)
    settings.guide_ver = int(settings.guide_ver) + 1
    return True


def _drag_anchor(point, kind, dx, dy, mirror=True):
    """按拖动类型更新一个锚点；mirror=False 时只改被拖的那一侧手柄。"""
    p = list(point)
    if kind == "new":
        p[4] = dx
        p[5] = dy
        p[2] = -dx
        p[3] = -dy
    elif kind == "anchor":
        p[0] += dx
        p[1] += dy
    elif kind == "out":
        p[4] = dx
        p[5] = dy
        if mirror:
            p[2] = -dx
            p[3] = -dy
    elif kind == "in":
        p[2] = dx
        p[3] = dy
        if mirror:
            p[4] = -dx
            p[5] = -dy
    return tuple(p)


def _translate_points(points, dx, dy):
    """整条路径平移：只动锚点坐标，进出控制柄保持相对形状。"""
    return [(p[0] + dx, p[1] + dy, p[2], p[3], p[4], p[5])
            for p in points]


_MODE_ORDER = ("auto", "add", "carve")
_MODE_LABEL = {"auto": "跟随默认", "add": "补成实心", "carve": "挖掉"}


def _next_mode(mode):
    """按「默认 → 补 → 挖」循环；未知旧值回到默认。"""
    current = mode if mode in _MODE_ORDER else "auto"
    return _MODE_ORDER[(_MODE_ORDER.index(current) + 1) % len(_MODE_ORDER)]


def _closes_on_anchor_click(closed, point_count, kind, index):
    """点击第一个锚点是否表示闭合。"""
    return (kind == "anchor" and int(index) == 0
            and not bool(closed) and int(point_count) >= 3)


class IC_OT_PenDraw(bpy.types.Operator):
    """画或编辑一条引导路径（PS 钢笔式：点击落点、拖动出曲线）。"""

    bl_idname = "image_cutter.pen_draw"
    bl_label = "画引导路径"
    bl_description = "在 3D 视口里对着源平面点画路径；建议先按小键盘 7 切到顶视图"
    bl_options = {"REGISTER", "UNDO"}

    # -1 = 新建；>=0 = 编辑已有路径（面板每行的编辑按钮）。
    stroke_index: bpy.props.IntProperty(default=-1, min=-1)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == "MESH"
                and bool(obj.get("ic_generated"))
                and context.area is not None and context.area.type == "VIEW_3D")

    def invoke(self, context, event):
        global _ACTIVE_PEN
        obj = context.active_object
        s = obj.image_cutter
        src = s.source_obj
        if src is None:
            self.report({"ERROR"}, "还没有源平面")
            return {"CANCELLED"}

        img, _node, _mat = imgio.find_image_slot(src)
        if img is None:
            self.report({"ERROR"}, "源平面的材质里找不到图片纹理")
            return {"CANCELLED"}

        self.target = obj
        self.source = src
        self.img_size = (int(img.size[0]), int(img.size[1]))
        self.size = imgio.object_local_size(src)

        self.edit_index = int(self.stroke_index)
        if not (0 <= self.edit_index < len(s.strokes)):
            self.edit_index = -1

        if self.edit_index >= 0:
            st = s.strokes[self.edit_index]
            self.points = _stroke_anchors(st)
            self.closed = bool(st.closed)
            self.mode = getattr(st, "mode", "auto")
            self.original_edit = (
                list(self.points), bool(self.closed), str(self.mode)
            )
        else:
            self.points = []   # [(px, py, in_dx, in_dy, out_dx, out_dy)]
            self.closed = False
            self.mode = "auto"
            self.original_edit = None

        self.dragging = False
        self.drag_kind = None       # "new" / "anchor" / "all" / "in" / "out"
        self.drag_index = -1
        self.selected = -1
        self.select_all = False
        self._last_anchor_click = None
        self.hover = None
        self.hover_hit = (None, -1)
        self.hover_seg = (-1, 0.0)
        self._cursor_shape = "CROSSHAIR"
        self._nudge_undo_at = 0.0
        self._nudge_undo_index = -1
        self._segment_cache_key = None
        self._segment_cache = {}
        self._nudge_timer = None
        self.history = []
        self.redo = []
        self.pending_before = None
        self._hint_area = None
        self._hint_workspace = None
        _ACTIVE_PEN = self
        # 让面板立刻切到「编辑中」：高亮当前行 + 顶部的保存/取消提示。
        try:
            if context.area is not None:
                context.area.tag_redraw()
        except Exception:                        # noqa: BLE001
            pass

        self._handler = bpy.types.SpaceView3D.draw_handler_add(
            _draw_cb, (self, context), "WINDOW", "POST_PIXEL"
        )
        context.window_manager.modal_handler_add(self)
        self._cursor(context, "CROSSHAIR")
        self._set_hint(context, self._hint_text())
        if self.edit_index >= 0:
            self.report(
                {"INFO"},
                "编辑路径 %d：拖锚点/控制柄，Alt 单侧，C 开闭，"
                "M 切补/挖，Ctrl+Z 撤销，Ctrl+Shift+Z 重做，回车保存"
                % (self.edit_index + 1),
            )
        else:
            self.report(
                {"INFO"},
                "左键落点 / 拖出曲线 / 点首锚或 C 闭合 / 回车结束 / Esc 取消",
            )
        return {"RUNNING_MODAL"}

    # ---------------------------------------------------------------- 坐标

    def pixel_at(self, context, event):
        """鼠标位置 → 贴图像素坐标。视线打不到平面时返回 None。"""
        region = context.region
        rv3d = context.region_data
        if region is None or rv3d is None:
            return None

        coord = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

        mw = self.source.matrix_world
        normal = (mw.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
        plane_pt = mw.translation

        denom = direction.dot(normal)
        if abs(denom) < 1e-9:
            return None
        t = (plane_pt - origin).dot(normal) / denom
        if t <= 0:
            return None
        hit = origin + direction * t

        local = mw.inverted() @ hit
        w, h = self.img_size
        sx, sy = self.size
        u = local.x / sx + 0.5
        v = local.y / sy + 0.5
        return (u * w, (1.0 - v) * h)

    def screen_of(self, context, px, py):
        """贴图像素坐标 → 屏幕坐标。"""
        return _screen_of(
            context, self.source, self.img_size, self.size, px, py
        )

    def curve_screen(self, context, a, b, steps=None):
        """两锚点之间的贝塞尔段 → 屏幕坐标串。"""
        return _curve_screen(
            context, self.source, self.img_size, self.size, a, b, steps
        )

    def segment_screen(self, context, seg):
        """按段缓存屏幕投影；鼠标悬停时不必每次重算整条路径。"""
        key = (tuple(self.points), bool(self.closed),
               _view_signature(context))
        if key != self._segment_cache_key:
            self._segment_cache_key = key
            self._segment_cache.clear()
        coords = self._segment_cache.get(seg)
        if coords is None:
            n = len(self.points)
            if n < 2:
                return []
            coords = self.curve_screen(
                context, self.points[seg], self.points[(seg + 1) % n]
            )
            self._segment_cache[seg] = coords
        return coords

    def _near(self, context, event, px, py, radius):
        sc = self.screen_of(context, px, py)
        if sc is None:
            return False
        return math.hypot(sc[0] - event.mouse_region_x,
                          sc[1] - event.mouse_region_y) <= radius

    def _hit_test(self, context, event):
        """返回 ("anchor"/"in"/"out", index) 或 (None, -1)。

        已选锚点的控制柄优先：它们和锚点只差十几像素，先测锚点会让
        用户永远抓不到控制柄。
        """
        if self.selected >= 0 and self.selected < len(self.points):
            a = self.points[self.selected]
            anchor_sc = self.screen_of(context, a[0], a[1])
            for kind, hx, hy in (("in", a[0] + a[2], a[1] + a[3]),
                                 ("out", a[0] + a[4], a[1] + a[5])):
                handle_sc = self.screen_of(context, hx, hy)
                if anchor_sc is None or handle_sc is None:
                    continue
                # 零长度控制柄和锚点重合；这时应优先抓锚点移动，
                # 否则用户点锚点会莫名其妙只改曲线柄。
                if (math.hypot(handle_sc[0] - anchor_sc[0],
                               handle_sc[1] - anchor_sc[1]) > 4.0
                        and self._near(context, event, hx, hy, 8.0)):
                    return kind, self.selected

        for idx in range(len(self.points) - 1, -1, -1):
            a = self.points[idx]
            if self._near(context, event, a[0], a[1], 10.0):
                return "anchor", idx
        return None, -1

    def _segment_hit(self, context, event):
        """鼠标附近有没有已画曲线的某一段，返回 (段号, t) 或 (-1, 0)。"""
        n = len(self.points)
        if n < 2:
            return -1, 0.0
        last = n if self.closed else n - 1
        best_d = 8.0
        best = (-1, 0.0)
        mx = event.mouse_region_x
        my = event.mouse_region_y
        for seg in range(last):
            coords = self.segment_screen(context, seg)
            d, t = _closest_on_screen_polyline(coords, mx, my)
            if d < best_d:
                best_d = d
                best = (seg, t)
        return best

    def _update_hover(self, context, event):
        """刷新「鼠标下是什么」：锚点/控制柄优先，其次才是曲线段。"""
        self.hover = self.pixel_at(context, event)
        if self.dragging:
            return
        self.hover_hit = self._hit_test(context, event)
        if self.hover_hit[0] is None:
            self.hover_seg = self._segment_hit(context, event)
        else:
            self.hover_seg = (-1, 0.0)
        shape = "HAND" if self.hover_hit[0] is not None else "CROSSHAIR"
        if shape != getattr(self, "_cursor_shape", None):
            self._cursor(context, shape)
            self._cursor_shape = shape

    def _hint_text(self):
        mode = _MODE_LABEL.get(self.mode, "跟随默认")
        if getattr(self, "select_all", False):
            if self.edit_index >= 0:
                return (
                    "整条路径已选中（%d 锚点）｜ 拖任意锚点移动 · "
                    "方向键微调 · A 取消全选 · C 开闭 · M 切模式 · "
                    "Ctrl+Z 撤销 · 回车保存 · Esc 放弃"
                    % len(self.points)
                )
            return (
                "整条路径已选中（%d 锚点）｜ 拖任意锚点移动 · "
                "方向键微调 · A 取消全选 · 右键/回车结束 · Esc 取消"
                % len(self.points)
            )
        blank = ("点空白取消选择" if self.closed else "点空白加锚点")
        if self.edit_index >= 0:
            return (
                "钢笔编辑 %d · %s · %s ｜ 拖锚点/控制柄 · Alt 单侧 · "
                "点曲线插点 · %s · A 全选 · C 开闭 · M 切模式 · "
                "Ctrl+Z 撤销 · "
                "Ctrl+Shift+Z 重做 · 方向键微调 · Tab 切锚点 · "
                "右键/回车保存 · Esc 放弃"
                % (self.edit_index + 1, "闭合" if self.closed else "开放",
                   mode, blank)
            )
        return (
            "钢笔绘制 ｜ 左键落点 · 拖动出曲线 · 点曲线插点 · "
            "%s · A 全选 · 点首锚/C 开闭 · 右键/回车结束 · Ctrl+Z 撤销 · "
            "Ctrl+Shift+Z 重做 · 方向键微调 · Esc 取消"
            % blank
        )

    def _set_hint(self, context, text):
        """把快捷键和当前模式固定在视口上方，别只闪一下状态栏。"""
        try:
            area = context.area
            if area is not None:
                self._hint_area = area
                area.header_text_set(text)
        except Exception:                        # noqa: BLE001
            self._hint_area = None
        try:
            workspace = context.workspace
            if workspace is not None:
                self._hint_workspace = workspace
                workspace.status_text_set(text)
        except Exception:                        # noqa: BLE001
            self._hint_workspace = None

    def _clear_hint(self):
        try:
            if self._hint_area is not None:
                self._hint_area.header_text_set(None)
        except Exception:                        # noqa: BLE001
            pass
        try:
            if self._hint_workspace is not None:
                self._hint_workspace.status_text_set(None)
        except Exception:                        # noqa: BLE001
            pass
        self._hint_area = None
        self._hint_workspace = None

    def _live_sync(self, context, interactive=False):
        """编辑路径时把当前状态立即写回，并触发网格更新。"""
        if self.edit_index < 0 or context is None:
            return False
        changed = _persist_edit(
            self.target.image_cutter, self.edit_index,
            self.points, self.closed, self.mode,
        )
        if changed:
            stroke = self.target.image_cutter.strokes[self.edit_index]
            if bool(getattr(stroke, "enabled", True)):
                from . import ops
                ops.schedule_rebuild(
                    self.target, context, interactive=bool(interactive)
                )
        self._set_hint(context, self._hint_text())
        return changed

    def _restore_original(self, context):
        """Esc / 失败退出时恢复进入编辑前的路径。"""
        if self.edit_index < 0 or self.original_edit is None:
            return False
        points, closed, mode = self.original_edit
        changed = _persist_edit(
            self.target.image_cutter, self.edit_index,
            points, closed, mode,
        )
        if changed:
            stroke = self.target.image_cutter.strokes[self.edit_index]
            if bool(getattr(stroke, "enabled", True)):
                from . import ops
                ops.schedule_rebuild(self.target, context, interactive=False)
        return changed

    def _remember(self, keep_nudge=False):
        """在会改动路径的操作之前记一份快照。"""
        self._push_history((
            list(self.points), bool(self.closed),
            int(self.selected), str(self.mode),
        ))
        if not keep_nudge:
            self._nudge_undo_index = -1
            self._cancel_nudge_timer()

    def _push_history(self, state):
        self.history.append(state)
        if len(self.history) > 50:
            self.history.pop(0)
        self.redo.clear()

    def _begin_action(self, context=None):
        """鼠标按下时先暂存，松开且确实改了才进撤销栈。"""
        if getattr(self, "_nudge_timer", None) is not None:
            self._cancel_nudge_timer()
            if context is not None:
                self._live_sync(context, interactive=True)
        self._nudge_undo_index = -1
        self.pending_before = (
            list(self.points), bool(self.closed),
            int(self.selected), str(self.mode),
        )

    def _cancel_nudge_timer(self):
        func = getattr(self, "_nudge_timer", None)
        if func is None:
            return
        try:
            if bpy.app.timers.is_registered(func):
                bpy.app.timers.unregister(func)
        except Exception:                        # noqa: BLE001
            pass
        self._nudge_timer = None

    def _schedule_nudge_sync(self, context):
        """方向键连按时先只动路径，停顿后再合并重建网格。"""
        self._cancel_nudge_timer()

        def flush():
            self._nudge_timer = None
            if _ACTIVE_PEN is self:
                try:
                    self._live_sync(bpy.context, interactive=True)
                except Exception:                # noqa: BLE001
                    pass
            return None

        # register() 在 Blender 里返回 None；必须自己保存函数对象才能取消。
        self._nudge_timer = flush
        try:
            bpy.app.timers.register(flush, first_interval=0.16)
        except Exception:                        # noqa: BLE001
            self._nudge_timer = None
            flush()

    def _commit_action(self, context=None):
        before = getattr(self, "pending_before", None)
        self.pending_before = None
        if before is None:
            return
        after = (list(self.points), bool(self.closed),
                 int(self.selected), str(self.mode))
        if before != after:
            self._push_history(before)
            self._live_sync(context)

    def _restore(self, state):
        self.points, self.closed, self.selected, self.mode = state
        self.select_all = False

    def _undo(self, context=None):
        self._cancel_nudge_timer()
        if not self.history:
            self.report({"WARNING"}, "没有可撤销的操作")
            return
        self.redo.append((
            list(self.points), bool(self.closed),
            int(self.selected), str(self.mode),
        ))
        self._restore(self.history.pop())
        self._live_sync(context)
        self.report({"INFO"}, "已撤销上一步")

    def _redo_step(self, context=None):
        self._cancel_nudge_timer()
        if not self.redo:
            self.report({"WARNING"}, "没有可重做的操作")
            return
        self.history.append((
            list(self.points), bool(self.closed),
            int(self.selected), str(self.mode),
        ))
        self._restore(self.redo.pop())
        self._live_sync(context)
        self.report({"INFO"}, "已重做")

    # ---------------------------------------------------------------- 模态

    def _append_point(self, context, hp):
        """空白处追加锚点。闭合路径不追加。

        闭合路径的收尾边是「最后一个锚点 → 第一个锚点」；在空白处追加一个
        锚点，等于把这条边从原位置直接甩到鼠标处，看起来就像“最后选中的
        锚点被强行拖到了空白处”。所以闭合后点空白只取消选择。
        """
        if self.closed:
            return False
        self._begin_action(context)
        self.points.append((hp[0], hp[1], 0.0, 0.0, 0.0, 0.0))
        self.drag_kind = "new"
        self.drag_index = len(self.points) - 1
        self.selected = self.drag_index
        self.select_all = False
        return True

    def _double_anchor_click(self, event, idx):
        """同一锚点 0.4 秒内点第二下 = 选中整条路径。"""
        now = time.monotonic()
        x = float(getattr(event, "mouse_x", 0.0))
        y = float(getattr(event, "mouse_y", 0.0))
        last = self._last_anchor_click
        self._last_anchor_click = (now, int(idx), x, y)
        if last is None:
            return False
        return (last[1] == int(idx) and now - last[0] <= 0.4
                and abs(last[2] - x) <= 6.0 and abs(last[3] - y) <= 6.0)

    def modal(self, context, event):
        if context.area is None:
            return self._finish(context, cancelled=True)

        context.area.tag_redraw()

        if event.type == "ESC":
            return self._finish(context, cancelled=True)

        if (event.type == "Z" and event.value == "PRESS"
                and getattr(event, "ctrl", False) and not self.dragging):
            if getattr(event, "shift", False):
                self._redo_step(context)
            else:
                self._undo(context)
            return {"RUNNING_MODAL"}

        if event.type in {"RET", "NUMPAD_ENTER", "RIGHTMOUSE"}:
            # 编辑已有路径时回车只保存，不能把原来的闭合状态改掉；
            # 开/闭由 C 显式切换（见下面）。
            return self._finish(
                context,
                closed=(self.closed if self.edit_index >= 0 else False),
            )

        if event.type in {"DEL", "BACKSPACE"} and event.value == "PRESS":
            if self.dragging:
                return {"RUNNING_MODAL"}
            if 0 <= self.selected < len(self.points):
                self._remember()
                self.points.pop(self.selected)
                idx = self.selected
                self.selected = -1
                self._live_sync(context)
                self.report({"INFO"}, "已删除锚点 %d（还剩 %d 个）"
                            % (idx + 1, len(self.points)))
                return {"RUNNING_MODAL"}
            if self.points:
                self._remember()
                self.points.pop()
                self.select_all = False
                self.selected = -1
                self._live_sync(context)
                self.report({"INFO"}, "已退回上一个锚点（还剩 %d 个）" % len(self.points))
            else:
                self.report({"WARNING"}, "已经没有锚点可退")
            return {"RUNNING_MODAL"}

        if event.type == "C" and event.value == "PRESS" and not self.dragging:
            if len(self.points) >= 3:
                if self.edit_index >= 0:
                    # 编辑时 C 只切换状态，不结束 —— 切完还能继续拖锚点。
                    self._remember()
                    self.closed = not self.closed
                    self._live_sync(context)
                    self.report(
                        {"INFO"},
                        "路径已切换为%s，回车保存" % ("闭合" if self.closed else "开放"),
                    )
                    return {"RUNNING_MODAL"}
                # 新建时 C = 闭合并结束。
                return self._finish(context, closed=True)
            if self.edit_index >= 0:
                self.report({"WARNING"}, "至少 3 个锚点才能闭合")
            return {"RUNNING_MODAL"}

        if event.type == "M" and event.value == "PRESS" and not self.dragging:
            self._remember()
            self.mode = _next_mode(self.mode)
            self._live_sync(context)
            suffix = "" if self.closed else "（开放路径不参与圈内处理）"
            self.report(
                {"INFO"},
                "路径模式：%s%s" % (_MODE_LABEL[self.mode], suffix),
            )
            return {"RUNNING_MODAL"}

        if event.type == "MOUSEMOVE":
            self._update_hover(context, event)
            if (self.dragging and self.hover is not None
                    and 0 <= self.drag_index < len(self.points)):
                p = self.points[self.drag_index]
                dx = self.hover[0] - p[0]
                dy = self.hover[1] - p[1]
                if self.drag_kind == "all":
                    if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                        self.points = _translate_points(self.points, dx, dy)
                else:
                    self.points[self.drag_index] = _drag_anchor(
                        p, self.drag_kind, dx, dy,
                        mirror=not getattr(event, "alt", False),
                    )
            return {"RUNNING_MODAL"}

        if event.type == "A" and event.value == "PRESS" and not self.dragging:
            if self.points:
                self.select_all = not self.select_all
                if self.select_all:
                    self.selected = 0
                self._set_hint(context, self._hint_text())
                self.report(
                    {"INFO"},
                    ("已选中整条路径（%d 个锚点）" % len(self.points))
                    if self.select_all else "已取消整条选中",
                )
            return {"RUNNING_MODAL"}

        if (event.type in {"TAB", "LEFT_ARROW", "RIGHT_ARROW",
                           "UP_ARROW", "DOWN_ARROW"}
                and event.value == "PRESS" and not self.dragging):
            if event.type == "TAB":
                n = len(self.points)
                if n:
                    step = -1 if getattr(event, "shift", False) else 1
                    current = self.selected if 0 <= self.selected < n else (
                        -1 if step > 0 else 0
                    )
                    self.selected = (current + step) % n
                    self.select_all = False
                    self._nudge_undo_index = -1
                    self._set_hint(context, self._hint_text())
                    return {"RUNNING_MODAL"}
            elif self.select_all or 0 <= self.selected < len(self.points):
                step = 10.0 if getattr(event, "shift", False) else 1.0
                dx = dy = 0.0
                if event.type == "LEFT_ARROW":
                    dx = -step
                elif event.type == "RIGHT_ARROW":
                    dx = step
                elif event.type == "UP_ARROW":
                    dy = -step
                else:
                    dy = step
                now = time.monotonic()
                key = -2 if self.select_all else self.selected
                if (key != self._nudge_undo_index
                        or now - self._nudge_undo_at > 0.8):
                    self._remember(keep_nudge=True)
                self._nudge_undo_at = now
                self._nudge_undo_index = key
                if self.select_all:
                    self.points = _translate_points(self.points, dx, dy)
                else:
                    self.points[self.selected] = _drag_anchor(
                        self.points[self.selected], "anchor", dx, dy
                    )
                self._schedule_nudge_sync(context)
                self._set_hint(context, self._hint_text())
                return {"RUNNING_MODAL"}

        if event.type == "LEFTMOUSE":
            if event.value == "PRESS":
                hp = self.pixel_at(context, event)
                if hp is None:
                    return {"RUNNING_MODAL"}
                kind, idx = self._hit_test(context, event)
                if kind is not None:
                    if _closes_on_anchor_click(
                            self.closed, len(self.points), kind, idx):
                        if self.edit_index >= 0:
                            self._remember()
                            self.closed = True
                            self.selected = 0
                            self._live_sync(context)
                            self.report({"INFO"}, "路径已闭合，回车保存")
                            return {"RUNNING_MODAL"}
                        return self._finish(context, closed=True)
                    if kind == "anchor" and self._double_anchor_click(event, idx):
                        self.select_all = True
                    elif kind in ("in", "out"):
                        self.select_all = False
                    self._begin_action(context)
                    self.drag_kind = (
                        "all" if kind == "anchor" and self.select_all else kind
                    )
                    self.drag_index = idx
                    self.selected = idx
                else:
                    seg, t = self._segment_hit(context, event)
                    n = len(self.points)
                    if seg >= 0 and n >= 2:
                        # 点在已有曲线上 = 插一个锚点，而不是把点追加到
                        # 路径末尾。PS 钢笔也是这个习惯，改中段不用重画。
                        if t <= 0.04:
                            self._begin_action(context)
                            new_idx = seg
                        elif t >= 0.96:
                            self._begin_action(context)
                            new_idx = (seg + 1) % n
                        else:
                            self._begin_action(context)
                            self.points, new_idx = guide_mod.split_bezier_segment(
                                self.points, seg, t
                            )
                            self.report({"INFO"}, "已在第 %d 段插入锚点" % (seg + 1))
                        self.drag_kind = "anchor"
                        self.drag_index = new_idx
                        self.selected = new_idx
                        self.select_all = False
                    else:
                        if not self._append_point(context, hp):
                            self.selected = -1
                            self.select_all = False
                            self.dragging = False
                            self.drag_kind = None
                            self._set_hint(context, self._hint_text())
                            return {"RUNNING_MODAL"}
                self.dragging = True
                self._cursor(context, "CROSSHAIR")
            else:
                self._commit_action(context)
                self.dragging = False
                self.drag_kind = None
                self.drag_index = -1
                self._update_hover(context, event)
            return {"RUNNING_MODAL"}

        return {"RUNNING_MODAL"}

    @staticmethod
    def _cursor(context, shape):
        try:
            context.window.cursor_set(shape)
        except Exception:                        # noqa: BLE001
            pass

    def _finish(self, context, cancelled=False, closed=False):
        global _ACTIVE_PEN
        self._cancel_nudge_timer()
        self._clear_hint()
        if self._handler is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._handler, "WINDOW")
            except Exception:                    # noqa: BLE001
                pass
            self._handler = None
        self._cursor(context, "DEFAULT")
        _ACTIVE_PEN = None
        try:
            if context.area is not None:
                context.area.tag_redraw()
        except Exception:                        # noqa: BLE001
            pass

        if cancelled:
            self._restore_original(context)
            return {"CANCELLED"}
        if len(self.points) < 2:
            self._restore_original(context)
            self.report({"WARNING"},
                        "路径太短，保持原样" if self.edit_index >= 0 else "路径太短，已丢弃")
            return {"CANCELLED"}

        s = self.target.image_cutter
        changed = _persist_edit(
            s, self.edit_index, self.points, closed, self.mode
        ) if self.edit_index >= 0 else False

        if self.edit_index < 0:
            _store_stroke(s, self.points, closed, -1, mode=self.mode)
            # 新建路径意味着“我要用引导”，自动打开；编辑已有路径则保留
            # 用户当前的启用状态，不能因为改一笔就偷偷把引导重新打开。
            s.guide_enabled = True
            s.guide_ver = int(s.guide_ver) + 1
            changed = True

        if changed:
            from . import ops
            ops.schedule_rebuild(self.target, context, interactive=False)

        if self.edit_index >= 0:
            self.report({"INFO"}, "已更新路径 %d（%s）· 可再次点「编辑」继续调整"
                        % (self.edit_index + 1, "闭合" if closed else "开放"))
        else:
            self.report({"INFO"}, "已加一条路径（共 %d 条）%s"
                        % (len(s.strokes), "，已闭合" if closed else "")
                        + "，可点路径行的「编辑」继续调整")
        return {"FINISHED"}


def _draw_cb(op, context):
    """视口绘制回调。这里抛异常会让整个视口黑掉，必须全吞。"""
    try:
        if _aa_shader() is None or context.region is None:
            return
        pts = op.points

        anchor_col = (1.0, 0.86, 0.28, 1.0)
        handle_col = (0.74, 0.68, 1.0, 0.95)

        # 正在编辑的路径之外，把已有路径淡淡画出来。原来进入画模式后
        # 视口里只剩这一条，用户无从判断它和别的补/挖区域怎么叠。
        s = op.target.image_cutter
        curve_col = _mode_color(s, op.mode, op.closed)
        for idx, st in enumerate(s.strokes):
            if idx == op.edit_index:
                continue
            old = _anchor_curve_screen(
                op, context, _stroke_anchors(st), closed=bool(st.closed)
            )
            if len(old) >= 2:
                c = _overlay_color(s, st)
                old_col = (c[0], c[1], c[2], min(c[3], 0.34))
                _stroke_line(old, old_col, 1.2, dashed=not st.closed)

        seg = []
        if len(pts) >= 2:
            last = len(pts) if op.closed else len(pts) - 1
            for k in range(last):
                seg.extend(op.segment_screen(context, k))
        if len(seg) >= 2:
            _stroke_line(seg, curve_col, 1.6)

        anchors = []
        for a in pts:
            sc = op.screen_of(context, a[0], a[1])
            if sc is not None:
                anchors.append((sc[0], sc[1]))
        if anchors:
            _dots(anchors, 4.0, anchor_col)
            if getattr(op, "select_all", False):
                for (ax, ay) in anchors:
                    _ring(ax, ay, 5.0, 7.0, (1.0, 1.0, 1.0, 0.9))

        hover_kind, hover_idx = getattr(op, "hover_hit", (None, -1))
        if (not op.dragging and hover_kind == "anchor"
                and 0 <= hover_idx < len(pts)):
            sc = op.screen_of(context, pts[hover_idx][0], pts[hover_idx][1])
            if sc is not None:
                _ring(sc[0], sc[1], 5.6, 7.6, (1.0, 1.0, 1.0, 0.95))

        if 0 <= op.selected < len(pts):
            last = pts[op.selected]
            ipt = (last[0] + last[2], last[1] + last[3])
            opt = (last[0] + last[4], last[1] + last[5])
            c = op.screen_of(context, last[0], last[1])
            h1 = op.screen_of(context, ipt[0], ipt[1])
            h2 = op.screen_of(context, opt[0], opt[1])
            if c and h1 and h2:
                _stroke_line(
                    [(h1[0], h1[1]), (c[0], c[1]),
                     (c[0], c[1]), (h2[0], h2[1])],
                    handle_col, 1.0,
                )
                _dots([(h1[0], h1[1]), (h2[0], h2[1])], 2.4, handle_col)
            # 选中锚点用白圈标出来；原来只靠控制柄提示，锚点一多就分不清。
            if c is not None:
                _ring(c[0], c[1], 5.0, 7.0, (1.0, 1.0, 1.0, 0.95))

        if (not op.dragging and hover_kind in ("in", "out")
                and 0 <= op.selected < len(pts)):
            a = pts[op.selected]
            hx = a[0] + (a[2] if hover_kind == "in" else a[4])
            hy = a[1] + (a[3] if hover_kind == "in" else a[5])
            sc = op.screen_of(context, hx, hy)
            if sc is not None:
                _ring(sc[0], sc[1], 3.2, 4.8, (1.0, 1.0, 1.0, 0.95))

        hover_seg, hover_t = getattr(op, "hover_seg", (-1, 0.0))
        if (not op.dragging and hover_kind is None
                and 0 <= hover_seg < len(pts) and len(pts) >= 2):
            a = pts[hover_seg]
            b = pts[(hover_seg + 1) % len(pts)]
            t = min(1.0, max(0.0, float(hover_t)))
            x, y = _bezier_xy(a, b, t)
            sc = op.screen_of(context, x, y)
            if sc is not None:
                # 曲线上给一个「落在这儿会插点」的白色标记。
                _ring(sc[0], sc[1], 3.8, 5.8, (1.0, 1.0, 1.0, 0.92))
                _dots([(sc[0], sc[1])], 2.2, curve_col)

        if (op.hover is not None and pts and not op.dragging and not op.closed
                and hover_kind is None and hover_seg < 0):
            # 预览下一段。用贝塞尔而不是直线：最后那个锚点可能带着拖出来的
            # out 控制柄，成品是弯的，预览画直的会「画的和得到的不一样」。
            last = pts[-1]
            ghost = (op.hover[0], op.hover[1], 0.0, 0.0, 0.0, 0.0)
            preview = op.curve_screen(context, last, ghost)
            if len(preview) >= 2:
                _stroke_line(preview, (1.0, 1.0, 1.0, 0.6),
                             1.2, dashed=True)
            # 落点位置给个点，让用户知道会落在哪
            hp = op.screen_of(context, op.hover[0], op.hover[1])
            if hp is not None:
                _dots([(hp[0], hp[1])], 2.4, (1.0, 1.0, 1.0, 0.85))
    except Exception:                            # noqa: BLE001
        pass


def _mode_color(settings, mode, closed):
    """补 / 挖 / 开放路径的统一配色。钢笔和常驻叠加层共用一套。"""
    if not closed:
        return (0.40, 0.78, 1.00, 0.95)
    if mode == "auto":
        mode = getattr(settings, "guide_mode", "add")
    if mode == "carve":
        return (1.00, 0.36, 0.32, 0.95)
    if mode == "add":
        return (0.30, 0.90, 0.46, 0.95)
    return (0.33, 0.84, 0.70, 0.95)


def _overlay_color(settings, stroke):
    if not getattr(stroke, "enabled", True):
        return (0.52, 0.55, 0.60, 0.45)
    return _mode_color(settings, getattr(stroke, "mode", "auto"),
                       bool(stroke.closed))


def _lighten(color, amount=0.45):
    """锚点比路径本身亮一点，叠在同色线上才看得出是节点。"""
    k = max(0.0, min(1.0, amount))
    return (color[0] + (1.0 - color[0]) * k,
            color[1] + (1.0 - color[1]) * k,
            color[2] + (1.0 - color[2]) * k,
            color[3])


def _overlay_cb():
    """常驻叠加层：不在钢笔画模式时也显示已保存的引导路径。

    这是「画完还能看懂自己画了什么」的关键。只在当前选中的生成物上画，
    不碰渲染结果；面板的「视口显示路径」可以关掉。
    """
    try:
        if _ACTIVE_PEN is not None:
            return
        context = bpy.context
        area = context.area
        if area is None or area.type != "VIEW_3D":
            return
        sp = context.space_data
        if sp is not None and getattr(sp, "overlay", None) is not None:
            if not sp.overlay.show_overlays:
                return
        obj = context.active_object
        if obj is None or obj.type != "MESH" or not obj.get("ic_generated"):
            return
        s = obj.image_cutter
        if not getattr(s, "guide_show", True) or len(s.strokes) == 0:
            return
        src = s.source_obj
        w = int(getattr(s, "stat_img_w", 0) or 0)
        h = int(getattr(s, "stat_img_h", 0) or 0)
        if src is None or w <= 0 or h <= 0:
            return
        if _aa_shader() is None:
            return
        size = imgio.object_local_size(src)
        img_size = (w, h)

        u = _ui_scale()
        for idx, st in enumerate(s.strokes):
            anchors = _stroke_anchors(st)
            if len(anchors) < 2:
                continue
            closed = bool(st.closed)
            enabled = bool(getattr(st, "enabled", True))
            color = _overlay_color(s, st)
            last = len(anchors) if closed else len(anchors) - 1
            coords = []
            for k in range(last):
                coords.extend(_curve_screen(
                    context, src, img_size, size,
                    anchors[k], anchors[(k + 1) % len(anchors)],
                ))
            if len(coords) >= 2:
                _stroke_line(coords, color,
                             1.4 if enabled else 1.0,
                             dashed=(not closed) or not enabled)
            points = []
            for a in anchors:
                sc = _screen_of(context, src, img_size, size, a[0], a[1])
                if sc is not None:
                    points.append((sc[0], sc[1]))
            if points:
                point_col = _lighten(color, 0.5) if enabled else color
                _dots(points, 2.6 if enabled else 1.8, point_col)
                center = _badge_center(context, points, u)
                if center is not None:
                    _badge(center[0], center[1], str(idx + 1), point_col)
    except Exception:                            # noqa: BLE001
        pass


def register_overlay():
    global _OVERLAY_HANDLE, _KEYMAP_ITEM
    if _OVERLAY_HANDLE is None:
        _OVERLAY_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
            _overlay_cb, (), "WINDOW", "POST_PIXEL"
        )
    # 左键优先问一句「点到编号了吗」；没点中返回 PASS_THROUGH，
    # 原来的选择/框选完全不受影响。
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        if kc is None:
            return
        km = kc.keymaps.get("3D View")
        if km is None:
            km = kc.keymaps.new(name="3D View", space_type="VIEW_3D",
                                region_type="WINDOW")
        for item in list(km.keymap_items):
            if item.idname == "image_cutter.pick_path":
                km.keymap_items.remove(item)
        item = km.keymap_items.new(
            "image_cutter.pick_path", "LEFTMOUSE", "PRESS", head=True
        )
        _KEYMAP_ITEM = (km, item)
    except Exception:                            # noqa: BLE001
        _KEYMAP_ITEM = None


def unregister_overlay():
    global _OVERLAY_HANDLE, _KEYMAP_ITEM
    if _OVERLAY_HANDLE is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_OVERLAY_HANDLE, "WINDOW")
        except Exception:                        # noqa: BLE001
            pass
        _OVERLAY_HANDLE = None
    if _KEYMAP_ITEM is not None:
        km, item = _KEYMAP_ITEM
        try:
            km.keymap_items.remove(item)
        except Exception:                        # noqa: BLE001
            pass
        _KEYMAP_ITEM = None


class IC_OT_PenCycleMode(bpy.types.Operator):
    bl_idname = "image_cutter.pen_cycle_mode"
    bl_label = "切换这条路径的圈内处理"
    bl_description = "在「跟随默认 / 补成实心 / 挖掉」之间循环"
    bl_options = {"REGISTER", "UNDO"}

    stroke_index: bpy.props.IntProperty(default=-1, min=-1)

    def execute(self, context):
        obj = context.active_object
        if obj is None or not obj.get("ic_generated"):
            self.report({"ERROR"}, "先选中本插件生成的网格")
            return {"CANCELLED"}
        s = obj.image_cutter
        i = int(self.stroke_index)
        if not (0 <= i < len(s.strokes)):
            self.report({"ERROR"}, "这条路径已经不存在了")
            return {"CANCELLED"}
        st = s.strokes[i]
        current = getattr(st, "mode", "auto")
        nxt = _next_mode(current)
        st.mode = nxt
        s.guide_ver = int(s.guide_ver) + 1
        from . import ops
        ops.schedule_rebuild(obj, context, interactive=False)
        suffix = "（开放路径仍沿线切）" if not st.closed else ""
        if not s.guide_enabled:
            suffix += "（引导当前关闭，启用后生效）"
        self.report({"INFO"}, "路径 %d：%s%s"
                    % (i + 1, _MODE_LABEL[nxt], suffix))
        return {"FINISHED"}


class IC_OT_PenToggle(bpy.types.Operator):
    bl_idname = "image_cutter.pen_toggle"
    bl_label = "启用/停用这条引导路径"
    bl_description = "保留路径但暂时不参与计算，方便对比不同引导组合"
    bl_options = {"REGISTER", "UNDO"}

    stroke_index: bpy.props.IntProperty(default=-1, min=-1)

    def execute(self, context):
        obj = context.active_object
        if obj is None or not obj.get("ic_generated"):
            self.report({"ERROR"}, "先选中本插件生成的网格")
            return {"CANCELLED"}
        s = obj.image_cutter
        i = int(self.stroke_index)
        if not (0 <= i < len(s.strokes)):
            self.report({"ERROR"}, "这条路径已经不存在了")
            return {"CANCELLED"}
        st = s.strokes[i]
        st.enabled = not bool(getattr(st, "enabled", True))
        s.guide_ver = int(s.guide_ver) + 1
        from . import ops
        ops.schedule_rebuild(obj, context, interactive=False)
        self.report(
            {"INFO"},
            "路径 %d：%s" % (i + 1, "已启用" if st.enabled else "已暂时停用"),
        )
        return {"FINISHED"}


class IC_OT_PenDelete(bpy.types.Operator):
    bl_idname = "image_cutter.pen_delete"
    bl_label = "删除这条引导路径"
    bl_description = "只删除这一条路径，其他引导保留"
    bl_options = {"REGISTER", "UNDO"}

    stroke_index: bpy.props.IntProperty(default=-1, min=-1)

    def execute(self, context):
        obj = context.active_object
        if obj is None or not obj.get("ic_generated"):
            self.report({"ERROR"}, "先选中本插件生成的网格")
            return {"CANCELLED"}
        s = obj.image_cutter
        i = int(self.stroke_index)
        if not (0 <= i < len(s.strokes)):
            self.report({"ERROR"}, "这条路径已经不存在了")
            return {"CANCELLED"}
        s.strokes.remove(s.strokes[i])
        s.guide_ver = int(s.guide_ver) + 1
        from . import ops
        ops.schedule_rebuild(obj, context, interactive=False)
        self.report({"INFO"}, "已删除路径 %d（还剩 %d 条）"
                    % (i + 1, len(s.strokes)))
        return {"FINISHED"}


class IC_OT_PenClear(bpy.types.Operator):
    bl_idname = "image_cutter.pen_clear"
    bl_label = "清空引导路径"
    bl_description = "删掉所有画好的路径，回到纯自动结果"
    bl_options = {"REGISTER", "UNDO"}

    def invoke(self, context, event):
        obj = context.active_object
        if (obj is None or not obj.get("ic_generated")
                or len(obj.image_cutter.strokes) == 0):
            return self.execute(context)
        # 整组删除必须确认，误点一次垃圾桶不该把路径全清掉。
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = context.active_object
        if obj is None or not obj.get("ic_generated"):
            self.report({"ERROR"}, "先选中本插件生成的网格")
            return {"CANCELLED"}
        s = obj.image_cutter
        n = len(s.strokes)
        s.strokes.clear()
        s.guide_ver = int(s.guide_ver) + 1
        from . import ops
        ops.schedule_rebuild(obj, context, interactive=False)
        self.report({"INFO"}, "已清空 %d 条路径" % n)
        return {"FINISHED"}


class IC_OT_PickPath(bpy.types.Operator):
    """视口里点路径编号 → 直接进入这条路径的钢笔编辑。"""

    bl_idname = "image_cutter.pick_path"
    bl_label = "点击编号进入路径编辑"
    bl_description = "在视口里点路径的编号徽标，直接编辑对应路径"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == "MESH"
                and obj.mode == "OBJECT"
                and bool(obj.get("ic_generated"))
                and context.area is not None
                and context.area.type == "VIEW_3D"
                and context.region is not None
                and context.region.type == "WINDOW")

    def invoke(self, context, event):
        if _ACTIVE_PEN is not None:
            return {"PASS_THROUGH"}
        obj = context.active_object
        s = obj.image_cutter
        if not getattr(s, "guide_show", True) or not len(s.strokes):
            return {"PASS_THROUGH"}
        sp = context.space_data
        if sp is not None and getattr(sp, "overlay", None) is not None:
            if not sp.overlay.show_overlays:
                return {"PASS_THROUGH"}
        src = s.source_obj
        w = int(getattr(s, "stat_img_w", 0) or 0)
        h = int(getattr(s, "stat_img_h", 0) or 0)
        if src is None or w <= 0 or h <= 0:
            return {"PASS_THROUGH"}
        idx = _badge_hit(
            context, s, src, (w, h), imgio.object_local_size(src),
            event.mouse_region_x, event.mouse_region_y,
        )
        if idx < 0:
            return {"PASS_THROUGH"}
        bpy.ops.image_cutter.pen_draw("INVOKE_DEFAULT",
                                      stroke_index=int(idx))
        return {"FINISHED"}


def stroke_to_points(stroke):
    """存下来的笔画 → 密集点串（含贝塞尔控制柄）。给 guide 栅格化用。"""
    return guide_mod.anchors_to_points(
        _stroke_anchors(stroke),
        closed=bool(getattr(stroke, "closed", False)),
    )
