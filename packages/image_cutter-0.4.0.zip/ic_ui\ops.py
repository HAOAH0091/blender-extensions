"""插件的主要操作：生成、重建、修材质。

【重建策略】

参数一变就重建。但「重建」分两级，靠 pipeline 里那两个阶段键来决定跑多远：

  · 改**网格密度** → 阶段 A（认轮廓）结果照用，只重跑阶段 B（铺网格）
    —— 几十毫秒，拖滑块是跟手的

  · 改**阈值 / 精度 / 外扩 / 圆滑 / 引导** → 阶段 A 失效，两级都跑
    —— 稍慢，但这是形状真的变了，慢是应该的

交互：滑块拖动时 update 回调每帧都会响。现在不直接做精确重建，而是
65ms 合批 + 粗一档的预览网格；停手 300ms 后自动补一次精确重建。
阈值/外扩/引导这类要重算阶段 A 的参数，预览帧直接跳过，避免拖动中卡住。
"""

import json
import math
import time
from dataclasses import replace

import bpy
import numpy as np
from mathutils import Vector

from ..ic_bpy import build as build_mod
from ..ic_bpy import imgio
from ..ic_core import guide as guide_mod
from ..ic_core import pipeline as pipe

# 缓存「最近几张图」的中间结果。
#
# 【为什么不是单槽】
#
# 早先只有一个槽（img_key / alpha / info / stage_a 各存一份）。
# 场景里有多个生成物时，用户在 A、B 两个对象之间来回点时：
#   选 A → 算 A 的 A 阶段（比如 200ms）
#   选 B → 槽被 B 覆盖，A 的结果丢了
#   选回 A → A 阶段又要重算 200ms
# 交替编辑两个对象 = 每次都全量重算，正是「拖滑块卡」的隐藏原因之一。
#
# 【为什么不是无限缓存】
#
# alpha 一张 4K 贴图就 33MB，stage_a 的轮廓也要几 MB。
# 无上限缓存在大场景里会吃光内存。所以做成容量很小的 LRU（默认 4 张）：
# 交替点两三个对象够用，再多就按「最久没用的先扔」淘汰。
_CACHE_MAX_IMAGES = 4

# key = 图片指纹；value = {"alpha": ndarray, "info": dict, "stage_a_key": str|None, "stage_a": StageA|None}
_IMG_CACHE = {}

# 最近一次用过的 key（release_cache / footprint 要按它来找）
_CACHE = {"img_key": None}

_PENDING = set()
_TIMER_NAME = "image_cutter_rebuild"

# 交互预览：拖滑块时先用粗一档的 spacing 快速反馈；停手 0.3s 后再用
# 用户真正选中的密度重建。阈值/外扩这类会改阶段 A 的参数在预览帧里
# 直接跳过计算，保持旧网格 —— 宁可晚 0.2 秒变，也不要在拖动中卡住。
_IMMEDIATE = set()
_LAST_TOUCH = {}
_PREVIEW_IDLE = 0.30
_PREVIEW_INTERVAL = 0.065
_PREVIEW_SPACING_SCALE = 2.2
_PREVIEW_SPACING_SCALE_MAX = 8.0
_PREVIEW_TARGET_B_MS = 25.0
_PREVIEW_BUCKET_RATIO = 1.22
# 阶段 A 超过这个耗时就不再在拖动帧里跑全分辨率：4K 图精确 A 约 100ms，
# 降到 1/4 分辨率后拖动帧能稳定在 30ms 左右。
_PREVIEW_A_DIRECT_MS = 35.0
_PREVIEW_A_TARGET_MS = 10.0
_PREVIEW_A_FACTOR_MAX = 6
# 阈值/外扩这类参数在拖动时会重算阶段 A。既然轮廓本来就是粗的，
# 预览网格再故意放大一档，避免“粗轮廓 + 细网格”白花几十毫秒。
_PREVIEW_A_SPACING_MULT = 2.5

# 同一对象最近一次预览的几何指纹。密度在同一个量化桶里连续变化时，
# 直接复用刚写进对象的粗网格，不再重跑阶段 B。
_PREVIEW_STATE = {}
_PREVIEW_STATE_MAX = 8

# 生成物与源平面的间隙（米）。放在法线方向上，免得共面闪烁。
OFFSET_ALONG_NORMAL = 0.001


def _cache_get(key):
    """取一个缓存槽（命中时把它挪到最近使用的位置）。"""
    ent = _IMG_CACHE.get(key)
    if ent is None:
        return None
    # dict 保持插入顺序：先删再塞 = 挪到末尾（表示最近用过）
    _IMG_CACHE.pop(key)
    _IMG_CACHE[key] = ent
    return ent


def _cache_put(key, ent):
    """写入缓存槽，超容量时淘汰最久没用的那个。"""
    _IMG_CACHE.pop(key, None)
    _IMG_CACHE[key] = ent
    while len(_IMG_CACHE) > _CACHE_MAX_IMAGES:
        oldest = next(iter(_IMG_CACHE))
        _IMG_CACHE.pop(oldest, None)


def _clear_preview_state(name):
    if name:
        _PREVIEW_STATE.pop(name, None)


def _preview_spacing(settings, spacing):
    """按上一次完整 B 阶段耗时，自适应选预览边长。

    固定放大 2.2 倍在 1024² 图上够用，但 4K 高密度时完整 B 可能超过 1 秒，
    2.2 倍后仍然要几百毫秒。阶段 B 的点数大致与 spacing² 成反比，
    所以用 sqrt(耗时 / 目标耗时) 推需要放大多少，再量化到几何桶，
    让拖动过程中多次落在同一个粗网格上，可直接复用。
    """
    full_ms = float(getattr(settings, "stat_ms_b_full", 0.0) or 0.0)
    if full_ms <= 0.0:
        full_ms = float(getattr(settings, "stat_ms_b", 0.0) or 0.0)

    scale = float(_PREVIEW_SPACING_SCALE)
    if full_ms > _PREVIEW_TARGET_B_MS * 1.25:
        scale = max(scale, math.sqrt(full_ms / _PREVIEW_TARGET_B_MS))
    scale = min(_PREVIEW_SPACING_SCALE_MAX, scale)
    wanted = max(float(spacing) * scale, float(spacing) + 2.0)

    # 向下量化：粗一档没关系，但绝不能比算出来的目标更细。
    bucket = int(math.floor(
        math.log(max(wanted, 1e-6)) / math.log(_PREVIEW_BUCKET_RATIO)
    ))
    return _PREVIEW_BUCKET_RATIO ** bucket


def _preview_a_factor(settings):
    """阶段 A 预览的降采样倍数。小图直接算精确 A，大图按耗时开方降采样。"""
    full_ms = float(getattr(settings, "stat_ms_a_full", 0.0) or 0.0)
    if full_ms <= 0.0:
        full_ms = float(getattr(settings, "stat_ms_a", 0.0) or 0.0)
    if full_ms <= _PREVIEW_A_DIRECT_MS:
        return 1
    factor = int(math.ceil(math.sqrt(full_ms / _PREVIEW_A_TARGET_MS)))
    return min(_PREVIEW_A_FACTOR_MAX, max(2, factor))


def release_cache(alpha_only=False):
    """主动释放缓存里的图数据。

    一张 4K 贴图的 alpha 是 3840×2160×4B ≈ 33MB，加上 stage_a 的轮廓，
    删掉生成物之后这些内存还挂在模块级字典上，用户看不到但确实占着。
    这里供对象被删/收尾时调用；alpha_only=True 时清空像素缓存，
    同时也会丢掉阶段 A（目前没有调用点依赖“只留轮廓”的中间态）。

    注意：清的是**全部**槽，不只是最近一张 —— 用户删对象时希望看到内存
    真的降下来，只清一张会让人以为没生效。
    """
    if alpha_only:
        for ent in _IMG_CACHE.values():
            ent["alpha"] = None
            ent["info"] = None
            ent["stage_a_key"] = None
            ent["stage_a"] = None
        _IMG_CACHE.clear()
        _CACHE["img_key"] = None
        _PREVIEW_STATE.clear()
        return
    _IMG_CACHE.clear()
    _PREVIEW_STATE.clear()
    _LAST_TOUCH.clear()
    _IMMEDIATE.clear()
    _PENDING.clear()
    for k in list(_CACHE.keys()):
        _CACHE[k] = None
    # 掩膜/裁剪/膨胀缓存也归这里管；否则删掉对象后这几张位图还会
    # 挂在 pipeline 模块级字典上（上限约 110MB）。
    try:
        pipe.release_mask_cache()
    except Exception:                                  # noqa: BLE001
        pass


def cache_footprint_mb():
    """缓存当前占多少 MB（面板上显示用，也让测试有据可查）。"""
    total = 0
    for ent in _IMG_CACHE.values():
        a = ent.get("alpha")
        if a is not None:
            total += float(getattr(a, "nbytes", 0))
    return total / (1024.0 * 1024.0)


def cache_slot_count():
    """当前缓存了几个图（测试用）。"""
    return len(_IMG_CACHE)


def resolve_target_object(base_name):
    """决定这次生成的结果该放进哪个对象，**绝不碰用户自己的对象**。

    返回 (obj_or_None, final_name, renamed)：
      obj 为 None 表示要新建；renamed 为 True 表示原名被占，换了名字。

    判定依据是自定义属性 ic_generated —— 只认带这个标记的对象是「自己人」。
    为什么不能只看名字：用户完全可能自己建了个叫 P_cutout 的物体，
    直接复用会把他的网格覆盖掉（几何和自定义属性一起丢，且 undo 未必救得回来）。
    """
    obj = bpy.data.objects.get(base_name)
    if obj is None:
        return None, base_name, False
    if obj.get("ic_generated"):
        # 自己之前生成的，直接复用（这就是「重新生成」的正常路径）
        return obj, base_name, False

    # 名字被用户的物体占着 → 往后找空位或自己的
    idx = 1
    while True:
        cand = "%s.%03d" % (base_name, idx)
        other = bpy.data.objects.get(cand)
        if other is None:
            return None, cand, True
        if other.get("ic_generated"):
            return other, cand, True
        idx += 1


def offset_along_plane_normal(obj, src):
    """把生成物放在源平面「正前方一点点」——沿平面局部法线，不是世界 Z。

    为什么不能写死 location.z += 0.001：
    平面一旦被旋转（比如绕 X 轴转 90° 立起来），世界 Z 就与平面法线垂直，
    偏移量沿法线分量是 0 —— 两个面共面，必然 z-fighting 闪成一片。

    ⚠️ 必须走 matrix_world：`obj.location` 是**父级坐标系**下的值，
    拿 `src.location`（也是父级系）直接加法线（世界系）会在有父级/缩放时错位。
    这里统一在世界空间算好，再换算回各自的父级系。
    """
    normal_world = (src.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0)))
    if normal_world.length < 1e-9:
        normal_world = Vector((0.0, 0.0, 1.0))
    normal_world.normalize()

    target_world = src.matrix_world.translation + normal_world * OFFSET_ALONG_NORMAL
    # 只改平移，保留已有的旋转/缩放（生成物要跟源平面同朝向）
    m = obj.matrix_world.copy()
    m.translation = target_world
    obj.matrix_world = m


# --------------------------------------------------------------------------
# 引导（钢笔画出来的路径）
# --------------------------------------------------------------------------

def collect_strokes(settings):
    """把面板里存的笔画转成 (密集点串, 是否闭合, 圈内值) 列表。

    圈内值按「单条路径覆盖 → 面板默认」解析：
      · 单条 mode=add/carve 时用单条设置
      · mode=auto 时沿用 guide_mode（兼容旧工程）
      · 开放路径始终是 -1（沿线切开）
    """
    out = []
    for st in settings.strokes:
        if not getattr(st, "enabled", True):
            continue
        anchors = [(float(p.x), float(p.y),
                    float(p.in_dx), float(p.in_dy),
                    float(p.out_dx), float(p.out_dy)) for p in st.points]
        if len(anchors) < 2:
            continue
        sampled = guide_mod.anchors_to_points(
            anchors, closed=bool(st.closed)
        )
        if len(sampled) >= 2:
            if not st.closed:
                value = -1
            else:
                mode = getattr(st, "mode", "auto")
                if mode == "add":
                    value = 1
                elif mode == "carve":
                    value = -1
                else:
                    value = -1 if settings.guide_mode == "carve" else 1
            out.append((sampled, bool(st.closed), int(value)))
    return out


def build_guide_mask(settings, width, height, scale=1.0):
    """把钢笔路径栅格化成三态掩膜（+1 保留 / -1 剔除）。没有笔画返回 None。

    每条闭合路径的圈内值由 collect_strokes 解析：
      单条 add/carve → 覆盖全局；auto → 跟随 guide_mode
    开放路径永远标 -1（沿这条线切一刀）—— 这是「切」的唯一含义，
    不随模式变，否则用户画条线却切不动，只会更困惑。
    """
    if not settings.guide_enabled:
        return None
    strokes = collect_strokes(settings)
    if not strokes:
        return None
    scale = float(scale)
    if scale > 1.0:
        strokes = [
            ([(x / scale, y / scale) for (x, y) in pts], closed, value)
            for (pts, closed, value) in strokes
        ]
    closed_value = -1 if settings.guide_mode == "carve" else 1
    return guide_mod.rasterize(strokes, width, height, closed_value=closed_value)


# --------------------------------------------------------------------------
# 重建
# --------------------------------------------------------------------------

def rebuild_object(obj, context, force=False, preview=False):
    """按对象上存的参数，把它的网格重建一遍。返回 (ok, message)。

    preview=True 用于拖滑块的中间帧：阶段 A 没变时用粗一档 spacing 快速出图；
    阶段 A 需要重算时先不阻塞主线程，等参数停稳后的 exact 重建。
    """
    if obj is None or obj.type != "MESH":
        return False, "不是网格对象"

    s = obj.image_cutter
    if not preview:
        s.stat_preview = False
    src = s.source_obj
    if src is None:
        # 关键：PointerProperty 指向的对象被删掉后，Blender 会把它**自动置空**，
        # 于是这里分不清「从没指定过」和「指定过但被删了」。
        # 所以生成时把源平面的名字也存一份，靠它判断该说哪句话。
        # （不存名字的话，用户删掉源平面后看到的是「还没指定源平面」——
        #  他明明指定过，会以为插件把记录弄丢了。）
        prev = (s.source_name or "").strip()
        if prev:
            s.last_error = "源平面「%s」已被删除" % prev
        else:
            s.last_error = "还没指定源平面"
        return False, s.last_error
    if src.name not in bpy.data.objects:
        s.last_error = "源平面「%s」已被删除" % src.name
        return False, s.last_error

    img, node, mat = imgio.find_image_slot(src)
    if img is None:
        s.last_error = "源平面的材质里没有「图片纹理」节点"
        return False, s.last_error

    key = imgio.image_key(img)
    _CACHE["img_key"] = key

    # 按图片指纹取缓存槽（LRU）。多对象交替编辑时各自保留自己的 A 阶段结果，
    # 不会互相击穿 —— 详见文件顶部 _IMG_CACHE 的说明。
    ent = None if force else _cache_get(key)
    if ent is None:
        try:
            alpha, info = imgio.read_alpha(img)
        except Exception as exc:                       # noqa: BLE001
            s.last_error = "读图片失败：%s" % exc
            return False, s.last_error
        ent = {"alpha": alpha, "info": info, "stage_a_key": None, "stage_a": None}
        _cache_put(key, ent)

    alpha = ent["alpha"]
    info = ent["info"]

    if not info["has_alpha"]:
        s.last_error = "这张贴图没有透明区（整张都是不透明的），没东西可抠"
        return False, s.last_error

    # 先把图片尺寸写回去，再算 params。否则新生成物第一次构建时
    # stat_img_long 还是 0，密度会按 48px 的回退值算；构建结束才写入真实长边，
    # 于是“首次生成”和“再点一次重建”会得到完全不同的 spacing（4K 图上差约 4 倍，
    # 面数差约 15 倍，甚至会跨过 Delaunay 分流阈值）。
    s.stat_img_long = int(max(info["width"], info["height"]))
    s.stat_img_w = int(info["width"])
    s.stat_img_h = int(info["height"])
    params = s.params()
    # 旧工程/换图后可能存着超过当前图上限的 expand。先按当前图钳制参数，
    # 但不要在这里改 s.expand —— 那会触发 update 回调再排一次重建。
    # 真正的属性回写在构建成功后由 _clamp_expand 完成。
    _lim = pipe.expand_limit(s.stat_img_long)
    if int(params.expand) > int(_lim):
        params.expand = int(_lim)

    # 引导没启用时，guide_ver 的数值对结果毫无影响（guide_mask 恒为 None）。
    # 之前无条件把它塞进 key，导致「引导关着、改个无关参数」也会让阶段 A 缓存失效，
    # 白白重算一遍轮廓（4K 图就是几百毫秒的卡顿）。
    #
    # 另外：一条路径都没画时，guide_ver 同样没有意义 —— 两次的 mask 都是 None。
    has_strokes = s.guide_enabled and len(s.strokes) > 0
    guide_sig = s.guide_ver if has_strokes else 0
    akey = params.stage_a_key(key, guide_sig)

    # ⚠️ build_guide_mask 必须放在缓存判断**里面**。
    #
    # 它唯一的消费者是 run_stage_a，而 run_stage_a 在缓存命中时根本不被调用。
    # 早先它写在 if 外面，于是「拖 density 滑块」（设计上只该重跑 B 阶段）
    # 每次都要把全部笔画重新栅格化一遍：
    #   4K 图 + 10 条引导 = 每次 588ms 白算
    #   实测 density=0.55 的 rebuild 从 327ms 涨到 1431ms（4.4 倍）
    # 用户感受就是「引导一开，滑块就不跟手了」。
    #
    # 语义完全等价：stage_a_key 已经把 guide_ver 纳入键，引导一变必然重算 A。
    a_preview_coarse = False
    if force or ent["stage_a_key"] != akey or ent["stage_a"] is None:
        a_preview = bool(
            preview and not force and ent["stage_a"] is not None
        )
        factor = _preview_a_factor(s) if a_preview else 1
        if factor > 1:
            a_preview_coarse = True
            pkey = (akey, factor)
            if ent.get("preview_a_key") == pkey and ent.get("preview_a") is not None:
                sa = ent["preview_a"]
            else:
                sw = (info["width"] + factor - 1) // factor
                sh = (info["height"] + factor - 1) // factor
                guide_mask = build_guide_mask(s, sw, sh, scale=factor)
                sa = pipe.run_stage_a_preview(
                    alpha, params, guide_mask, key, factor=factor
                )
                ent["preview_a_key"] = pkey
                ent["preview_a"] = sa
        else:
            guide_mask = build_guide_mask(s, info["width"], info["height"])
            sa = pipe.run_stage_a(
                alpha, params, guide_mask, key, alpha_is_unit=True
            )
            ent["stage_a_key"] = akey
            ent["stage_a"] = sa
            ent["preview_a_key"] = None
            ent["preview_a"] = None
    else:
        sa = ent["stage_a"]

    if not sa.rings:
        _clear_preview_state(obj.name)
        s.last_error = "没找到任何轮廓 —— 试试调低「透明判定阈值」"
        s.stat_faces = 0
        s.stat_points = 0
        s.stat_rings = 0
        s.stat_area = 0.0
        s.stat_perimeter = 0.0
        s.stat_dominant = 0.0
        s.stat_inner = 0
        s.stat_edge = ""
        s.stat_edge_ratio = 0.0
        s.stat_ms_a = sa.ms.get("stage_a", 0.0)
        s.stat_ms_b = 0.0
        s.stat_preview = False
        # 必须把旧几何清掉：否则面板说“没找到轮廓”，视口里却还是上一次的网格。
        try:
            build_mod.update_mesh_object(
                obj,
                np.zeros((0, 2), dtype=np.float64),
                np.zeros((0, 3), dtype=np.int64),
                np.zeros((0, 2), dtype=np.float64),
            )
        except Exception as exc:                       # noqa: BLE001
            s.last_error = "%s（清空旧网格失败：%s）" % (s.last_error, exc)
        return False, s.last_error

    size_x, size_y = imgio.object_local_size(src)
    build_params = params
    if preview:
        preview_spacing = _preview_spacing(s, params.spacing)
        if a_preview_coarse:
            preview_spacing *= _PREVIEW_A_SPACING_MULT
        preview_key = (
            akey, round(preview_spacing, 6),
            round(float(size_x), 6), round(float(size_y), 6),
        )
        last = _PREVIEW_STATE.get(obj.name)
        if not force and last is not None and last.get("key") == preview_key:
            s.stat_preview = True
            return True, "交互预览（复用当前粗网格）"
        build_params = replace(params, spacing=preview_spacing)
    else:
        _clear_preview_state(obj.name)

    sb = pipe.run_stage_b(sa, build_params)

    verts, uvs = build_mod.px_to_local(
        sb["points"], info["width"], info["height"], size_x, size_y
    )
    build_mod.update_mesh_object(obj, verts, sb["faces"], uvs)
    if preview:
        _PREVIEW_STATE[obj.name] = {"key": preview_key}
        while len(_PREVIEW_STATE) > _PREVIEW_STATE_MAX:
            _PREVIEW_STATE.pop(next(iter(_PREVIEW_STATE)))

    # 材质：沿用源平面的，并确保 alpha 接上了
    if mat is not None:
        same_mat = (len(obj.data.materials) == 1
                    and obj.data.materials[0] is mat)
        if not preview or not same_mat:
            if not same_mat:
                obj.data.materials.clear()
                obj.data.materials.append(mat)
            build_mod.ensure_material_has_alpha(mat, img)

    s.stat_faces = len(sb["faces"])
    s.stat_points = len(sb["points"])
    s.stat_rings = len(sa.rings)
    # 源图长边：密度=0 的「最粗」要按它缩放（48px 固定值在大图上太细）；
    # expand 的有效上限也要按它算（见 props.expand_limit）
    s.stat_img_long = int(max(info["width"], info["height"]))
    s.stat_img_w = int(info["width"])
    s.stat_img_h = int(info["height"])
    # 图可能换了（或者旧工程里存着超限的 expand）→ 钳一次
    try:
        from . import props as _props_mod
        _props_mod._clamp_expand(s)
    except Exception:                                  # noqa: BLE001
        pass
    # 几何统计在阶段 A 已经算过一次；拖密度时轮廓没变，直接复用。
    s.stat_area = float(getattr(sa, "area_px", 0.0))
    s.stat_perimeter = float(getattr(sa, "perimeter_px", 0.0))
    s.stat_dominant = float(getattr(sa, "dominant", 0.0))
    s.stat_edge = sa.edge_style
    s.stat_edge_ratio = round(sa.edge_ratio, 3)
    # 源图里有多少个洞。split_outer 已经把内环丢掉了（本插件不保留镂空），
    # 这里只是把「原来有几个洞」报给面板，让用户知道它们被填实了。
    s.stat_inner = int(getattr(sa, "inner_count", 0))
    s.stat_ms_a = sa.ms.get("stage_a", 0.0)
    s.stat_ms_b = sb["stats"].get("stage_b", 0.0)
    if not preview:
        s.stat_ms_a_full = s.stat_ms_a
    if not preview:
        s.stat_ms_b_full = s.stat_ms_b
    s.stat_preview = bool(preview)
    s.built = True
    s.last_error = ""

    # 记下这次用的源图，换图时能察觉
    obj["ic_source_image"] = key
    msg = "面 %d / 点 %d" % (len(sb["faces"]), len(sb["points"]))
    if preview:
        msg += "（交互预览）"
    return True, msg


def _flush_pending():
    """把攒下来的重建请求按用户参数精确做完（测试/非交互路径）。"""
    _cancel_interactive_timer()
    try:
        names = list(_PENDING)
        _PENDING.clear()
        _IMMEDIATE.clear()
        _LAST_TOUCH.clear()
        ctx = bpy.context
        for name in names:
            obj = bpy.data.objects.get(name)
            if obj is not None and obj.type == "MESH":
                try:
                    rebuild_object(obj, ctx)
                except Exception as exc:                # noqa: BLE001
                    obj.image_cutter.last_error = "重建出错：%s" % exc
    except Exception as exc:                            # noqa: BLE001
        print("[image_cutter] flush 失败：%s" % exc)
    return None


def _cancel_interactive_timer():
    try:
        if bpy.app.timers.is_registered(_flush_interactive):
            bpy.app.timers.unregister(_flush_interactive)
    except Exception:                                   # noqa: BLE001
        pass


def _flush_interactive():
    """滑块拖动用的自适应定时器。

    · 连续变化期间先跑粗一档的预览网格，保持视觉反馈且不堵主线程；
    · 参数停稳 300ms 后自动跑精确网格；
    · 阈值/外扩/引导变化在预览帧直接跳过，避免 4K 图上反复重算阶段 A。
    """
    names = list(_PENDING)
    _PENDING.clear()
    waiting = False
    now = time.monotonic()
    work_t0 = time.perf_counter()
    try:
        ctx = bpy.context
        for name in names:
            obj = bpy.data.objects.get(name)
            if obj is None or obj.type != "MESH":
                _LAST_TOUCH.pop(name, None)
                _IMMEDIATE.discard(name)
                continue

            idle = now - _LAST_TOUCH.get(name, 0.0)
            exact = name in _IMMEDIATE or idle >= _PREVIEW_IDLE
            try:
                ok, _msg = rebuild_object(obj, ctx, preview=not exact)
            except Exception as exc:                    # noqa: BLE001
                obj.image_cutter.last_error = "重建出错：%s" % exc
                ok = False

            if exact:
                _LAST_TOUCH.pop(name, None)
                _IMMEDIATE.discard(name)
            elif ok:
                _PENDING.add(name)
                waiting = True
            else:
                _LAST_TOUCH.pop(name, None)
                _IMMEDIATE.discard(name)
    except Exception as exc:                            # noqa: BLE001
        print("[image_cutter] interactive flush 失败：%s" % exc)
    if _PENDING:
        # 重建过程中 _clamp_expand 等属性回写可能又排进一个新请求；
        # 这一轮已清空集合，必须把新请求接回同一个定时器。
        waiting = True
    if not waiting:
        return None
    # 粗预览也可能要几十毫秒。固定 65ms 重排会让主线程没有喘息时间；
    # 按上一帧实际耗时留出一点空隙，保持约 10fps 且不持续占满 CPU。
    elapsed = time.perf_counter() - work_t0
    return min(0.30, max(_PREVIEW_INTERVAL, elapsed * 1.15))


def schedule_rebuild(obj, context=None, interactive=True):
    """把 obj 排进重建队列。

    interactive=True（滑块）走「粗预览 → 停手后精确」；
    interactive=False（画完/删路径/切换模式）直接安排精确重建。
    """
    if obj is None:
        return
    try:
        name = obj.name
        _PENDING.add(name)
        if interactive:
            _LAST_TOUCH[name] = time.monotonic()
            _IMMEDIATE.discard(name)
        else:
            _LAST_TOUCH.pop(name, None)
            _IMMEDIATE.add(name)
    except AttributeError:
        return
    try:
        if not bpy.app.timers.is_registered(_flush_interactive):
            bpy.app.timers.register(
                _flush_interactive,
                first_interval=0.0 if _IMMEDIATE else _PREVIEW_INTERVAL,
            )
    except Exception:                                   # noqa: BLE001
        # 定时器不可用时退化成直接重建，至少功能不丢
        _flush_pending()


# --------------------------------------------------------------------------
# 操作符
# --------------------------------------------------------------------------

def _pick_source(context):
    """挑源平面：优先当前选中的网格。"""
    sel = [o for o in context.selected_objects if o.type == "MESH"]
    if len(sel) == 1:
        return sel[0]
    act = context.active_object
    if act is not None and act.type == "MESH":
        return act
    return None


class IC_OT_Generate(bpy.types.Operator):
    bl_idname = "image_cutter.generate"
    bl_label = "生成抠图网格"
    bl_description = "从选中平面的贴图里抠出形状，铺成一片带贴图的三角网格"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(o.type == "MESH" for o in context.selected_objects) or (
            context.active_object is not None and context.active_object.type == "MESH"
        )

    def execute(self, context):
        src = _pick_source(context)

        # 选中的已经是「本插件生成的网格」→ 就地重建，别越建越多
        if src is not None and src.get("ic_generated"):
            ok, msg = rebuild_object(src, context, force=True)
            self.report({"INFO"} if ok else {"WARNING"}, msg)
            return {"FINISHED"} if ok else {"CANCELLED"}

        if src is None:
            self.report({"ERROR"}, "先选中一个贴了图的平面")
            return {"CANCELLED"}

        img, node, mat = imgio.find_image_slot(src)
        if img is None:
            self.report({"ERROR"}, "这个物体的材质里找不到「图片纹理」节点")
            return {"CANCELLED"}

        try:
            _alpha, info = imgio.read_alpha(img)
        except Exception as exc:                        # noqa: BLE001
            self.report({"ERROR"}, "读图片失败：%s" % exc)
            return {"CANCELLED"}

        if not info["has_alpha"]:
            self.report({"WARNING"}, "这张贴图没有透明区，抠出来会是一整块")
            return {"CANCELLED"}

        base_name = "%s_cutout" % src.name
        obj, final_name, renamed = resolve_target_object(base_name)
        if obj is None:
            # 新对象先建空的，再让 rebuild 灌数据（避免两套建对象逻辑）
            me = bpy.data.meshes.new("%s_mesh" % final_name)
            obj = bpy.data.objects.new(final_name, me)
            coll = src.users_collection[0] if src.users_collection else context.scene.collection
            coll.objects.link(obj)

        obj["ic_generated"] = True
        s = obj.image_cutter
        s.source_obj = src
        s.source_name = src.name          # 名字快照：源平面被删后靠它说清是哪个
        s.guide_ver = int(s.guide_ver) + 1

        # 放在源平面正前方一点点（沿局部法线），免得和源平面重叠闪烁
        obj.rotation_euler = src.rotation_euler
        obj.scale = src.scale
        offset_along_plane_normal(obj, src)

        ok, msg = rebuild_object(obj, context, force=True)
        if not ok:
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        for o in bpy.context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        if renamed:
            self.report({"WARNING"},
                        "已生成到 %s（%s 是你自己的物体，没动它）"
                        % (obj.name, base_name))
        self.report({"INFO"}, "生成完成：%s" % msg)
        return {"FINISHED"}


class IC_OT_Rebuild(bpy.types.Operator):
    bl_idname = "image_cutter.rebuild"
    bl_label = "重新生成"
    bl_description = "丢掉缓存，从头算一遍"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if obj is None or not obj.get("ic_generated"):
            self.report({"ERROR"}, "请先选中一个由本插件生成的网格")
            return {"CANCELLED"}
        ok, msg = rebuild_object(obj, context, force=True)
        self.report({"INFO"} if ok else {"ERROR"}, msg)
        return {"FINISHED"} if ok else {"CANCELLED"}


class IC_OT_FixAlpha(bpy.types.Operator):
    bl_idname = "image_cutter.fix_alpha"
    bl_label = "修好贴图透明"
    bl_description = "把贴图的 alpha 接到材质输出上，透明边缘才会真的透"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            self.report({"ERROR"}, "先选中一个对象")
            return {"CANCELLED"}
        src = obj.image_cutter.source_obj or obj
        img, node, mat = imgio.find_image_slot(src)
        if img is None:
            self.report({"ERROR"}, "找不到图片纹理节点")
            return {"CANCELLED"}
        changed = build_mod.ensure_material_has_alpha(mat, img)
        self.report({"INFO"} if changed else {"WARNING"},
                    "已接上 alpha" if changed else "alpha 本来就已经接好了")
        return {"FINISHED"}


class IC_OT_SelectSource(bpy.types.Operator):
    bl_idname = "image_cutter.select_source"
    bl_label = "选中源平面"
    bl_description = "跳到生成这张网格的那个平面"

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            return {"CANCELLED"}
        src = obj.image_cutter.source_obj
        if src is None or src.name not in bpy.data.objects:
            self.report({"WARNING"}, "源平面已经不在了")
            return {"CANCELLED"}
        for o in context.selected_objects:
            o.select_set(False)
        src.select_set(True)
        context.view_layer.objects.active = src
        return {"FINISHED"}


# --------------------------------------------------------------------------
# 引导数据的读写（用 custom property 存 JSON，简单可靠）
# --------------------------------------------------------------------------

def save_strokes(settings, strokes):
    """strokes: [(点串, 是否闭合)] → 写进面板的属性里。"""
    settings.strokes.clear()
    for pts, closed in strokes:
        st = settings.strokes.add()
        st.closed = bool(closed)
        for (x, y) in pts:
            p = st.points.add()
            p.x = float(x)
            p.y = float(y)
    settings.guide_ver = int(settings.guide_ver) + 1


def strokes_to_json(settings):
    return json.dumps(
        [{"closed": bool(st.closed),
          "points": [[float(p.x), float(p.y)] for p in st.points]}
         for st in settings.strokes]
    )
