"""核心算法自检 —— 不依赖 Blender，直接 `python tests/test_core.py` 跑。

测的是算法本身对不对，不是插件能不能装。
这里过不了，接进 Blender 只会把问题藏得更深。
"""

import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

if HERE not in sys.path:
    sys.path.insert(0, HERE)

from ic_core import mask as mask_mod          # noqa: E402
from ic_core import outline as outline_mod    # noqa: E402
from ic_core import pipeline as pipe         # noqa: E402
from ic_core import simplify as simplify_mod  # noqa: E402
from ic_core import triangulate as tri_mod    # noqa: E402
from ic_core import warp as warp_mod          # noqa: E402

PASS = []
FAIL = []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    tag = "PASS" if cond else "FAIL"
    line = "  [%s] %s" % (tag, name)
    if detail:
        line += "   %s" % detail
    print(line)


# --------------------------------------------------------------------------
# 合成测试图
# --------------------------------------------------------------------------

from fixture import make_alpha as make_test_alpha  # noqa: E402  共用素材，别各写一份


def tri_area_sum(pts, faces):
    s = 0.0
    for (i, j, k) in faces:
        a = pts[i]
        b = pts[j]
        c = pts[k]
        s += abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) * 0.5
    return s


def point_in_tri(p, a, b, c):
    d1 = (p[0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (p[1] - b[1])
    d2 = (p[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (p[1] - c[1])
    d3 = (p[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (p[1] - a[1])
    neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (neg and pos)


print("=" * 74)
print("image_cutter 核心算法自检")
print("=" * 74)

# --------------------------------------------------------------------------
print("\n[1] 分割")
alpha = make_test_alpha(soft=True)
m, st = mask_mod.build_mask(alpha, 0.5)
check("阈值分割能切出实心/空心", st["solid"] > 0 and st["empty"] > 0,
      "solid=%d empty=%d" % (st["solid"], st["empty"]))

style, ratio = mask_mod.edge_style(alpha, m)
check("软边图能被认出来", style == "soft", "ratio=%.3f" % ratio)

hard = np.zeros((64, 64), np.float32)
hard[16:48, 16:48] = 1.0
mh, _ = mask_mod.build_mask(hard, 0.5)
style_h, ratio_h = mask_mod.edge_style(hard, mh)
check("像素画被认成硬边", style_h == "hard", "ratio=%.3f" % ratio_h)

# --------------------------------------------------------------------------
print("\n[2] 轮廓追踪")
corner = np.zeros((2, 2), dtype=bool)
corner[0, 0] = True
corner[1, 1] = True
crings = outline_mod.trace_rings(corner)
check("对角相触的两块被拆成 2 圈（不黏连）", len(crings) == 2,
      "rings=%d" % len(crings))

rings = outline_mod.trace_rings(m)
outer, inner = outline_mod.split_outer(rings)
check("星形+洞+小圆 → 追出 3 圈（含洞）", len(rings) == 3, "rings=%d" % len(rings))
check("丢洞后剩 2 圈外轮廓", len(outer) == 2, "outer=%d inner=%d" % (len(outer), len(inner)))

# --------------------------------------------------------------------------
print("\n[3] 抽稀")
dense = outer[0]
simp = simplify_mod.simplify_ring(dense, 1.5)
check("抽稀明显减少顶点", len(simp) < len(dense) * 0.5,
      "%d → %d" % (len(dense), len(simp)))
a0 = abs(outline_mod.ring_area(dense))
a1 = abs(outline_mod.ring_area(simp))
check("抽稀后面积基本不变（走样在容差内）", abs(a1 - a0) / max(a0, 1e-9) < 0.05,
      "面积变化 %.2f%%" % (abs(a1 - a0) / max(a0, 1e-9) * 100))

tol_loose = simplify_mod.simplify_ring(dense, 5.0)
check("容差越大顶点越少", len(tol_loose) <= len(simp),
      "tol1.5→%d  tol5.0→%d" % (len(simp), len(tol_loose)))

# --------------------------------------------------------------------------
print("\n[4] 圆滑与外扩")
sm = warp_mod.smooth_ring(simp, 3)
check("圆滑不改变顶点数", len(sm) == len(simp))
check("圆滑不炸掉坐标", all(abs(p[0]) < 1e5 and abs(p[1]) < 1e5 for p in sm))

big = mask_mod.dilate_mask(m, 3)
check("膨胀让实心像素变多", big.sum() > m.sum(), "%d → %d" % (m.sum(), big.sum()))
r_exp = outline_mod.trace_rings(big)
o_exp, _ = outline_mod.split_outer(r_exp)
bx = abs(outline_mod.ring_area(o_exp[0]))
check("外扩后轮廓面积变大", bx > a0, "%.0f → %.0f" % (a0, bx))

# --------------------------------------------------------------------------
print("\n[5] Delaunay 三角化")
grid = []
for i in range(8):
    for j in range(8):
        grid.append((j * 10.0, i * 10.0))
t0 = time.perf_counter()
tris = tri_mod.delaunay_2d(np.asarray(grid))
t1 = time.perf_counter()

check("三角化有点产出", len(tris) > 0, "%d 个三角形 %.1fms" % (len(tris), (t1 - t0) * 1000))
allv = set()
for t in tris:
    allv.update(t)
check("覆盖全部输入点", len(allv) == len(grid), "%d/%d" % (len(allv), len(grid)))

ga = np.asarray(grid)
area_sum = tri_area_sum(ga, tris)
# 点从 (0,0) 排到 (70,70)，凸包就是 70x70 的正方形
hull_area = 70.0 * 70.0
check("三角形总面积 = 凸包面积（无重叠无缺口）",
      abs(area_sum - hull_area) < 1.0,
      "%.2f vs %.2f" % (area_sum, hull_area))

# C 后端（mathutils）不承诺输出顶点顺序。这里用一个“点数相同但顶点重排”
# 的假 CDT 覆盖旧实现只比较点数的错误：面必须通过 orig_verts 映射回输入索引。
print("\n[5b] Delaunay C 后端索引映射")
_old_cdt = tri_mod._CDT
try:
    def _fake_cdt(verts, _edges, _faces, _output_type, _epsilon):
        order = [2, 0, 3, 1]
        return (
            [verts[i] for i in order],
            [],
            [[0, 1, 2], [0, 2, 3]],
            [(i,) for i in order],
        )

    tri_mod._CDT = (None, _fake_cdt)
    _reordered = tri_mod.delaunay_fast(
        np.asarray([(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)])
    )
    check("重排后的面索引被正确映射回输入顶点",
          _reordered == [[2, 0, 3], [2, 3, 1]],
          "%s" % _reordered)
finally:
    tri_mod._CDT = _old_cdt

# --------------------------------------------------------------------------
print("\n[6] 铺网格（完整流程）")
params = pipe.Params(threshold=0.5, tolerance=1.5, expand=2, spacing=14.0)
t0 = time.perf_counter()
sa = pipe.run_stage_a(alpha, params)
sb = pipe.run_stage_b(sa, params)
t1 = time.perf_counter()

pts = sb["points"]
faces = sb["faces"]
check("产出三角形", len(faces) > 0, "%d 面 / %d 点" % (len(faces), len(pts)))
check("识别为软边 → 做了圆滑", sa.edge_style == "soft")

# 「中心不留洞」：星形正中心必须被某个三角形盖住
# ⚠️ fixture 默认出 512x512 的图，这里的中心坐标得按 512 算（按 256 算过一次，是错的）
cx, cy = 512 * 0.40, 512 * 0.44
covered = False
for (i, j, k) in faces:
    if point_in_tri((cx, cy), pts[i], pts[j], pts[k]):
        covered = True
        break
check("★ 星形正中心被网格盖住（中心不留洞）", covered)

# 覆盖面积应接近「外轮廓面积之和」
tot = tri_area_sum(pts, faces)
ring_area_sum = sum(abs(outline_mod.ring_area(r)) for r in sa.rings)
check("铺满程度合理（>85%）", tot > ring_area_sum * 0.85,
      "网格 %.0f / 轮廓 %.0f = %.1f%%" % (tot, ring_area_sum, tot / max(ring_area_sum, 1e-9) * 100))

# 三角形数随密度上升
counts = []
for sp in (40.0, 22.0, 12.0, 7.0):
    p2 = pipe.Params(threshold=0.5, tolerance=1.5, expand=2, spacing=sp)
    b2 = pipe.run_stage_b(sa, p2)
    counts.append(len(b2["faces"]))
check("网格密度越高三角形越多（单调）",
      all(counts[i] < counts[i + 1] for i in range(len(counts) - 1)),
      " → ".join(str(c) for c in counts))

# --------------------------------------------------------------------------
print("\n[6b] 阶段 A 统计缓存与拖动态预览")

_m_unit, _st_unit = mask_mod.build_mask(alpha, 0.5, assume_unit=True)
_m_ref, _st_ref = mask_mod.build_mask(alpha, 0.5)
check("assume_unit 不改变二值掩膜",
      np.array_equal(_m_unit, _m_ref)
      and _st_unit == _st_ref)

_metrics = pipe.ring_metrics(sa.rings)
check("StageA 的面积/周长/最大环占比与按需计算一致",
      abs(sa.area_px - _metrics["area"]) < 1e-9
      and abs(sa.perimeter_px - _metrics["perimeter"]) < 1e-9
      and abs(sa.dominant - _metrics["dominant"]) < 1e-9,
      "area=%.1f perimeter=%.1f dominant=%.3f"
      % (sa.area_px, sa.perimeter_px, sa.dominant))

_pa = pipe.run_stage_a_preview(alpha, params, None, "preview-probe", factor=3)
_all_preview = np.asarray([pt for ring in _pa.rings for pt in ring])
check("降采样预览的坐标已还原到原图尺度",
      _pa.preview_factor == 3
      and _all_preview[:, 0].min() >= 0.0
      and _all_preview[:, 1].min() >= 0.0
      and _all_preview[:, 0].max() <= alpha.shape[1]
      and _all_preview[:, 1].max() <= alpha.shape[0],
      "bounds x=[%.1f, %.1f] y=[%.1f, %.1f]"
      % (_all_preview[:, 0].min(), _all_preview[:, 0].max(),
         _all_preview[:, 1].min(), _all_preview[:, 1].max()))
_area_ratio = _pa.area_px / max(sa.area_px, 1e-9)
check("降采样预览面积接近精确轮廓",
      0.85 <= _area_ratio <= 1.15,
      "预览 %.0f / 精确 %.0f = %.1f%%"
      % (_pa.area_px, sa.area_px, _area_ratio * 100.0))
check("降采样预览保留主要环数",
      abs(len(_pa.rings) - len(sa.rings)) <= 1,
      "预览 %d 环 / 精确 %d 环" % (len(_pa.rings), len(sa.rings)))

# --------------------------------------------------------------------------
print("\n[7] 引导路径（钢笔）")
from ic_core import guide as guide_mod  # noqa: E402

# 闭合路径 → 圈起来的那块被标成「保留」
closed = ([(60, 60), (140, 60), (140, 140), (60, 140)], True)
gm = guide_mod.rasterize([closed], 200, 200)
check("闭合路径圈出的区域被标为保留", int((gm > 0).sum()) > 5000,
      "%d 像素" % int((gm > 0).sum()))
check("闭合路径内部确实是保留", gm[100, 100] == 1, "中心=%d" % gm[100, 100])
check("闭合路径外部不受影响", gm[10, 10] == 0, "外圈=%d" % gm[10, 10])

# 开放路径 → 沿线「切一刀」：只标线附近，且标的是 -1（剔除）
openp = ([(20, 20), (180, 20)], False)
gm2 = guide_mod.rasterize([openp], 200, 200)
n_line = int((gm2 != 0).sum())
check("开放路径只标线附近（不是一整块）", 100 < n_line < 1200, "%d 像素" % n_line)
check("开放路径线上标的是剔除(-1)", gm2[20, 100] == -1, "%d" % gm2[20, 100])
check("开放路径线下没标记", gm2[60, 100] == 0, "%d" % gm2[60, 100])
check("开放路径不会把线两端连起来成环", gm2[100, 100] == 0, "%d" % gm2[100, 100])

# 同一对象里允许「一个圈补、另一个圈挖」。全局 guide_mode 只是新路径默认值。
gm_mixed = guide_mod.rasterize([
    ([(20, 20), (70, 20), (70, 70), (20, 70)], True, 1),
    ([(110, 110), (170, 110), (170, 170), (110, 170)], True, -1),
], 200, 200)
check("混用模式：第一个闭合圈标 +1", gm_mixed[45, 45] == 1,
      "%d" % gm_mixed[45, 45])
check("混用模式：第二个闭合圈标 -1", gm_mixed[140, 140] == -1,
      "%d" % gm_mixed[140, 140])

# 距离空间哈希：同一格里有多个候选点时，结果仍要和全量版一致。
_grid_rings = [np.asarray([(-20.0, -10.0), (90.0, -10.0),
                           (90.0, 70.0), (-20.0, 70.0)])]
_gx, _gy = np.meshgrid(np.arange(-35.0, 105.0, 3.0),
                       np.arange(-25.0, 85.0, 3.0))
_grid_pts = np.column_stack([_gx.ravel(), _gy.ravel()])
_d_fast = tri_mod.dist_to_rings_grid(_grid_pts, _grid_rings)
_d_ref = tri_mod.dist_to_rings_batch(_grid_pts, _grid_rings)
_d_ok = np.isfinite(_d_fast)
check("dist_to_rings_grid 多候选点同格仍与全量版一致",
      _d_ok.any() and np.allclose(_d_fast[_d_ok], _d_ref[_d_ok]),
      "%d/%d 个有限值" % (int(_d_ok.sum()), len(_d_fast)))
_d_cached = tri_mod.dist_to_rings_grid(_grid_pts, _grid_rings)
check("线段空间哈希可复用且结果不变",
      np.array_equal(_d_fast, _d_cached)
      and tri_mod._RING_GRID_CACHE["grid"]["rings_ref"] is _grid_rings)
_new_rings = [np.asarray([(0.0, 0.0), (60.0, 0.0),
                          (60.0, 40.0), (0.0, 40.0)])]
_d_new = tri_mod.dist_to_rings_grid(_grid_pts, _new_rings)
_d_new_ref = tri_mod.dist_to_rings_batch(_grid_pts, _new_rings)
_d_new_ok = np.isfinite(_d_new)
check("换一套轮廓后空间哈希不会误用旧表",
      _d_new_ok.any()
      and np.allclose(_d_new[_d_new_ok], _d_new_ref[_d_new_ok]))

# 超长线段会从空间哈希回退到全量距离。回退时必须按段落的**所属环**
# 取轮廓，不能把拍平后的线段序号当成 rings 的索引。
_fallback_rings = [
    np.asarray([(0.0, 0.0), (100.0, 100.0), (100.0, 0.0)]),
    np.asarray([(200.0, 200.0), (300.0, 300.0), (300.0, 200.0)]),
]
_fallback_pts = np.asarray([
    (10.0, 10.0), (150.0, 150.0), (250.0, 250.0), (500.0, 500.0),
])
_fallback_fast = tri_mod.dist_to_rings_grid(
    _fallback_pts, _fallback_rings, cell=1.0
)
_fallback_ref = tri_mod.dist_to_rings_batch(
    _fallback_pts, _fallback_rings
)
check("超长线段回退时按所属环取轮廓",
      np.allclose(_fallback_fast, _fallback_ref),
      "fast=%s ref=%s" % (_fallback_fast, _fallback_ref))

# 最近轮廓顶点：格子吸附只需要 spacing 半径内的精确结果。
_nr_rng = np.random.default_rng(42)
_nr_rings = [
    np.column_stack([
        _nr_rng.uniform(-10.0, 110.0, 80),
        _nr_rng.uniform(-10.0, 110.0, 80),
    ]),
    np.column_stack([
        _nr_rng.uniform(150.0, 250.0, 60),
        _nr_rng.uniform(20.0, 120.0, 60),
    ]),
]
_nr_query = np.vstack([
    _nr_rng.uniform(-30.0, 270.0, 800),
    _nr_rng.uniform(-30.0, 150.0, 800),
]).T
_nr_ref_p, _nr_ref_d, _nr_ref_i = tri_mod._nearest_on_rings(
    _nr_query, _nr_rings, want_index=True
)
_nr_fast_p, _nr_fast_d, _nr_fast_i = tri_mod._nearest_on_rings(
    _nr_query, _nr_rings, want_index=True, max_distance=12.0
)
_nr_in = _nr_ref_d <= 12.0
_nr_out = ~_nr_in
check("最近轮廓顶点：半径内坐标/距离/索引与全量版逐元素一致",
      np.array_equal(_nr_fast_p[_nr_in], _nr_ref_p[_nr_in])
      and np.array_equal(_nr_fast_d[_nr_in], _nr_ref_d[_nr_in])
      and np.array_equal(_nr_fast_i[_nr_in], _nr_ref_i[_nr_in]),
      "%d/%d 个点在半径内" % (int(_nr_in.sum()), len(_nr_query)))
check("最近轮廓顶点：半径外明确返回 inf",
      bool(np.isinf(_nr_fast_d[_nr_out]).all()),
      "%d 个半径外点" % int(_nr_out.sum()))

_nr_tie = [np.asarray([(1.0, 0.0), (-1.0, 0.0), (0.0, 1.0)])]
_nr_tie_p, _nr_tie_d, _nr_tie_i = tri_mod._nearest_on_rings(
    np.asarray([(0.0, 0.0)]), _nr_tie, want_index=True, max_distance=2.0
)
check("最近轮廓顶点：同距时仍取最小拍平索引",
      _nr_tie_i[0] == 0 and _nr_tie_p[0, 0] == 1.0 and _nr_tie_d[0] == 1.0,
      "index=%d point=%s" % (int(_nr_tie_i[0]), _nr_tie_p[0]))

# 贝塞尔采样：锚点 + 控制柄 → 点串，且曲线经过端点
anchors = [(0.0, 0.0, 0.0, 0.0, 30.0, 0.0), (100.0, 100.0, -30.0, 0.0, 0.0, 0.0)]
pts = guide_mod.anchors_to_points(anchors, curve_steps=8)
check("贝塞尔采样出点串", len(pts) > 5, "%d 点" % len(pts))
check("曲线经过起点", abs(pts[0][0]) < 1e-6 and abs(pts[0][1]) < 1e-6)
check("曲线到得了终点", abs(pts[-1][0] - 100) < 1e-6 and abs(pts[-1][1] - 100) < 1e-6)
check("曲线被控制柄拉弯了（不是直线）",
      any(abs(p[1]) > 1.0 for p in pts[1:-1]),
      "中间点 y 最大 %.2f" % max(abs(p[1]) for p in pts[1:-1]))

# 闭合路径必须补采「末点 → 首点」那一段；否则填充时最后一段会变直线。
_closed_anchors = [
    (10.0, 10.0, -5.0, 2.0, 25.0, 30.0),
    (90.0, 15.0, -18.0, 8.0, 4.0, -6.0),
    (50.0, 95.0, 6.0, -20.0, -12.0, 4.0),
]
_closed_pts = guide_mod.anchors_to_points(
    _closed_anchors, curve_steps=8, closed=True
)
_last_seg = guide_mod.sample_cubic(
    (_closed_anchors[2][0], _closed_anchors[2][1]),
    (_closed_anchors[2][0] + _closed_anchors[2][4],
     _closed_anchors[2][1] + _closed_anchors[2][5]),
    (_closed_anchors[0][0] + _closed_anchors[0][2],
     _closed_anchors[0][1] + _closed_anchors[0][3]),
    (_closed_anchors[0][0], _closed_anchors[0][1]),
    steps=8,
)
check("闭合路径补采末段曲线",
      len(_closed_pts) == 1 + 3 * 8
      and np.allclose(np.asarray(_closed_pts[-8:]),
                      np.asarray(_last_seg)))
_open_pts = guide_mod.anchors_to_points(
    _closed_anchors, curve_steps=8, closed=False
)
check("开放路径不补末段", len(_open_pts) == 1 + 2 * 8,
      "%d 点" % len(_open_pts))

# 引导并进掩膜
base = np.zeros((200, 200), dtype=bool)
base[150:190, 150:190] = True
merged = mask_mod.apply_guide(base, gm, "follow")
check("引导能把区域加进掩膜", merged[100, 100] and not base[100, 100])
keep_only = mask_mod.apply_guide(base, gm, "solid_only")
check("只补不挖模式下不会挖掉原来的", keep_only[170, 170])

# 挖空模式：掩膜本身标成 -1（这是 build_guide_mask 在 carve 模式下产出的东西），
# apply_guide 照符号执行 —— 不能拿 +1 掩膜去测 carve，那测的是旧语义。
base2 = np.zeros((200, 200), dtype=bool)
base2[40:160, 40:160] = True          # 一整块
gm_carve = guide_mod.rasterize(
    [([(60, 60), (140, 60), (140, 140), (60, 140)], True)], 200, 200, closed_value=-1
)
check("carve 模式下闭合路径圈内标 -1", gm_carve[100, 100] == -1, "%d" % gm_carve[100, 100])
check("carve 模式下圈外仍是 0", gm_carve[10, 10] == 0, "%d" % gm_carve[10, 10])
carved = mask_mod.apply_guide(base2, gm_carve, "follow")
check("挖空模式把圈内挖掉了", not carved[100, 100], "圈内=%s" % carved[100, 100])

# carve / add 都属于「废弃别名」，必须和 follow 完全等价。
# 这条测试的价值：防止有人日后又给 carve 加一套独立行为（接口冗余就是这么长回来的）。
_alias_carve = mask_mod.apply_guide(base2, gm_carve, "carve")
_alias_add = mask_mod.apply_guide(base2, gm_carve, "add")
check("carve 是 follow 的别名（行为完全一致）",
      np.array_equal(_alias_carve, carved))
check("add 也是 follow 的别名",
      np.array_equal(_alias_add, carved))
# solid_only 必须**真的不同**（它是唯一独立分支）
_solid = mask_mod.apply_guide(base2, gm_carve, "solid_only")
check("solid_only 和 follow 行为不同（确实不挖）",
      not np.array_equal(_solid, carved))
check("挖空模式保留圈外", carved[50, 50] and carved[150, 150],
      "圈外 %s / %s" % (carved[50, 50], carved[150, 150]))
check("挖空模式确实减少了实心像素", carved.sum() < base2.sum(),
      "%d → %d" % (base2.sum(), carved.sum()))
cut_all = mask_mod.apply_guide(
    base,
    np.full((200, 200), -1, dtype=np.int8),
    "carve",
)
check("全剔除的引导能把掩膜清空", not cut_all.any())

# --------------------------------------------------------------------------
print("\n[7b] 手绘挖洞要保留到最终网格")

# 用没有源图洞的五角星，画一个完全位于实心区内部的闭合 carve。
# split_outer 会把这个洞环丢掉；阶段 B 必须再按 carve 掩膜剔一次，
# 否则 center 仍被三角形盖住，用户画了“挖掉”却完全没效果。
a_nohole = make_test_alpha(soft=True, with_hole=False, with_dot=False)
hole_box = [(170, 190), (240, 190), (240, 260), (170, 260)]
gm_hole = guide_mod.rasterize([(hole_box, True)], 512, 512, closed_value=-1)
p_hole = pipe.Params(
    threshold=0.5, tolerance=4.05, expand=0, spacing=15.29,
    guide_mode="carve",
)
sa_hole = pipe.run_stage_a(a_nohole, p_hole, gm_hole, "carve-hole-test")
sb_hole = pipe.run_stage_b(sa_hole, p_hole)
hpts = sb_hole["points"]
hfaces = sb_hole["faces"]
center = (205.0, 225.0)
center_covered = any(
    point_in_tri(center, hpts[i], hpts[j], hpts[k])
    for (i, j, k) in hfaces
)
check("内部 carve 确实产生了内环", sa_hole.inner_count >= 1,
      "inner=%d" % sa_hole.inner_count)
check("内部 carve 后中心不再被三角形覆盖", not center_covered,
      "%d 面" % len(hfaces))

p_keep = pipe.Params(
    threshold=0.5, tolerance=4.05, expand=0, spacing=15.29,
    guide_mode="solid_only",
)
sa_keep = pipe.run_stage_a(a_nohole, p_keep, gm_hole, "solid-only-hole-test")
sb_keep = pipe.run_stage_b(sa_keep, p_keep)
keep_center_covered = any(
    point_in_tri(center, sb_keep["points"][i], sb_keep["points"][j],
                 sb_keep["points"][k])
    for (i, j, k) in sb_keep["faces"]
)
check("solid_only 忽略 carve 掩膜，不会在阶段 B 偷挖洞",
      keep_center_covered)

# --------------------------------------------------------------------------
print("\n[7c] 钢笔插点不能改变曲线形状")


def _cubic_at(a, b, t):
    p0 = (a[0], a[1])
    c0 = (a[0] + a[4], a[1] + a[5])
    c1 = (b[0] + b[2], b[1] + b[3])
    p1 = (b[0], b[1])
    u = 1.0 - t
    return (
        u * u * u * p0[0] + 3 * u * u * t * c0[0]
        + 3 * u * t * t * c1[0] + t * t * t * p1[0],
        u * u * u * p0[1] + 3 * u * u * t * c0[1]
        + 3 * u * t * t * c1[1] + t * t * t * p1[1],
    )


_anchors_split = [
    (30.0, 40.0, -8.0, 3.0, 14.0, -9.0),
    (140.0, 70.0, -20.0, 12.0, 9.0, 17.0),
    (210.0, 160.0, -13.0, -10.0, 6.0, 2.0),
]
_split_t = 0.37
_before = _cubic_at(_anchors_split[0], _anchors_split[1], _split_t)
_new_anchors, _new_idx = guide_mod.split_bezier_segment(
    _anchors_split, 0, _split_t
)
_err = 0.0
for _k in range(21):
    _u = _k / 20.0
    if _u <= _split_t:
        _p = _cubic_at(_new_anchors[0], _new_anchors[1], _u / _split_t)
    else:
        _p = _cubic_at(
            _new_anchors[1], _new_anchors[2],
            (_u - _split_t) / (1.0 - _split_t),
        )
    _q = _cubic_at(_anchors_split[0], _anchors_split[1], _u)
    _err = max(_err, abs(_p[0] - _q[0]), abs(_p[1] - _q[1]))
check("插点后整段曲线逐点一致", _err < 1e-9, "最大差 %.2e" % _err)
check("插点位置在段中间", _new_idx == 1 and len(_new_anchors) == 4,
      "index=%d / %d 点" % (_new_idx, len(_new_anchors)))
check("插点落在原曲线参数位置",
      max(abs(_new_anchors[1][0] - _before[0]),
          abs(_new_anchors[1][1] - _before[1])) < 1e-9)
check("未参与拆分的控制柄保持不变",
      _new_anchors[0][2:4] == _anchors_split[0][2:4]
      and _new_anchors[2][4:] == _anchors_split[1][4:]
      and _new_anchors[3] == _anchors_split[2])

_closed_anchors = [
    (40.0, 40.0, -5.0, 2.0, 12.0, 1.0),
    (160.0, 50.0, -9.0, 6.0, 7.0, -4.0),
    (100.0, 170.0, 4.0, -8.0, -11.0, 5.0),
]
_wrap_t = 0.61
_wrap_before = _cubic_at(_closed_anchors[2], _closed_anchors[0], _wrap_t)
_wrap_new, _wrap_idx = guide_mod.split_bezier_segment(
    _closed_anchors, 2, _wrap_t
)
_wrap_err = 0.0
for _k in range(21):
    _u = _k / 20.0
    if _u <= _wrap_t:
        _p = _cubic_at(_wrap_new[2], _wrap_new[3], _u / _wrap_t)
    else:
        _p = _cubic_at(
            _wrap_new[3], _wrap_new[0],
            (_u - _wrap_t) / (1.0 - _wrap_t),
        )
    _q = _cubic_at(_closed_anchors[2], _closed_anchors[0], _u)
    _wrap_err = max(_wrap_err, abs(_p[0] - _q[0]), abs(_p[1] - _q[1]))
check("闭合路径末段插点也保持形状", _wrap_err < 1e-9,
      "最大差 %.2e" % _wrap_err)
check("闭合末段插点追加在路径末尾",
      _wrap_idx == 3 and len(_wrap_new) == 4)
check("末段插点落在原曲线参数位置",
      max(abs(_wrap_new[3][0] - _wrap_before[0]),
          abs(_wrap_new[3][1] - _wrap_before[1])) < 1e-9)

# 批量 DP 必须与逐环版逐元素一致；混合长度 + 超过批大小都要覆盖。
_rng_dp = np.random.default_rng(21)
_dp_ok = True
for _n in (4, 5, 12, 31, 65, 120):
    _items = [_rng_dp.normal(size=(_n, 2)) * 30 for _ in range(5)]
    _got = simplify_mod._dp_shortest_many(_items, 1.5)
    for _pts, _g in zip(_items, _got):
        _want = simplify_mod._dp_shortest(_pts, 1.5)
        if not np.array_equal(np.asarray(_want), _g):
            _dp_ok = False
check("批量 DP 与逐环版逐元素一致（混合长度）", _dp_ok)

_items = [_rng_dp.normal(size=(20, 2)) * 30
          for _ in range(simplify_mod._DP_BATCH + 2)]
_got = simplify_mod._dp_shortest_many(_items, 1.5)
_dp_ok = all(
    np.array_equal(
        np.asarray(simplify_mod._dp_shortest(_pts, 1.5)), _g
    )
    for _pts, _g in zip(_items, _got)
)
check("批量 DP 跨批次边界仍一致", _dp_ok)

# --------------------------------------------------------------------------
print("\n[8] 性能")
params2 = pipe.Params(threshold=0.5, tolerance=1.5, expand=2, spacing=8.0)
t0 = time.perf_counter()
sa2 = pipe.run_stage_a(alpha, params2)
mid = time.perf_counter()
sb2 = pipe.run_stage_b(sa2, params2)
t1 = time.perf_counter()
print("  · 阶段 A（认轮廓） %.0f ms" % ((mid - t0) * 1000))
print("  · 阶段 B（铺网格） %.0f ms" % ((t1 - mid) * 1000))
print("  · 点 %d / 面 %d" % (len(sb2["points"]), len(sb2["faces"])))
check("阶段 A 在 1s 内", (mid - t0) < 1.0, "%.0f ms" % ((mid - t0) * 1000))
check("阶段 B 在 2s 内", (t1 - mid) < 2.0, "%.0f ms" % ((t1 - mid) * 1000))

# --------------------------------------------------------------------------
print("\n[9] 缓存释放")
pipe.release_mask_cache()
_cache_params = pipe.Params(threshold=0.5, tolerance=4.05, expand=2, spacing=15.29)
pipe.run_stage_a(alpha, _cache_params, img_key="cache-release-test")
check("跑过阶段 A 后掩膜缓存非空", pipe.mask_cache_footprint() > 0,
      "%d bytes" % pipe.mask_cache_footprint())
pipe.release_mask_cache("cache-release-test")
check("按图片释放能清掉掩膜/裁剪/膨胀三层缓存",
      pipe.mask_cache_footprint() == 0,
      "%d bytes" % pipe.mask_cache_footprint())
tri_mod.dist_to_rings_grid(_grid_pts, _grid_rings)
pipe.release_mask_cache("cache-release-test")
check("释放图片缓存时线段空间哈希也清空",
      tri_mod._RING_GRID_CACHE["token"] is None
      and tri_mod._RING_GRID_CACHE["grid"] is None)

# --------------------------------------------------------------------------
print("\n" + "=" * 74)
print("通过 %d / 失败 %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("失败项：")
    for f in FAIL:
        print("  x", f)
    sys.exit(1)
print("全部通过 [OK]")
