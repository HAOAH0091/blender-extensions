"""轮廓的几何后处理：拐角圆滑。

【为什么外扩不在这里】

「边缘外扩」看着像个几何操作（把轮廓往外推 dist 像素），但**在轮廓层做法线平移会自交**：
凹口处两侧的法线会交叉，推出去以后轮廓自己打个结，三角化直接崩。

正确位置是在**掩膜层做形态学膨胀** —— 位图膨胀天然不会自交，
膨胀完再重新追轮廓，出来的就是干净的外扩轮廓。见 mask.dilate_mask()。
本模块只管圆滑。
"""


def smooth_ring(ring, iters=1, lam=0.5, mask=None, max_out_ratio=0.02):
    """闭合环 Laplacian 平滑，把像素楼梯磨圆。

    只该对**软边图**用。像素画磨圆等于把设计磨掉。

    【为什么要 lam 参数（原实现效果太弱）】

    原来固定写 0.25/0.5/0.25 的滑动平均。它的问题是 **只有 1 像素邻域**：
    1024 图上轮廓点间距可能是几十像素，1 个邻域内的位移对整体形状几乎没有影响 ——
    实测 smooth 从 0 调到 6，顶点数只从 56 变到 60，用户拖滑块看不出任何变化。

    改成可调强度的 Laplacian：新位置 = 原点 + lam × (邻域中点 - 原点)。
    lam=0.5 时是标准平滑；配合 iters 可以真正把楼梯磨圆。
    同时保留「不收缩」的处理：每轮后按原质心/面积做一次校正，
    避免迭代多了整个轮廓缩水（这是滑动平均的老毛病，迭代 6 次缩 1~2%）。

    【mask 参数：防止「平滑把实心区磨掉」—— 这是用户报的回归】

    全局面积/质心校正**管不住局部**。真实素材的形状很复杂：
    一处凸起被磨平、另一处凹口被填上，全局面积可以几乎不变，
    但**局部**轮廓已经离开实心区了。

    实测（3883×1978 人物图，默认参数）：
        smooth=0 → 只有 0.12% 的实心像素落在环外
        smooth=1 → 13.33%
        smooth=2 → 16.93%   ← 默认值，用户看到的效果就是"实心处被抠掉"
        smooth=8 → 23.65%
    那些落在环外的实心区，其三角形重心被判到环外 → 面被丢弃 → 出现空洞。

    修法：传进原掩膜，逐轮检查每个点是否还在**实心区**内（允许极小误差），
    跑到外面的点直接拉回平滑前的位置。这样平滑只改「走向」，
    不会把轮廓推出实心区。

    mask=None 时不校验（保持旧行为，给不关心掩膜的调用方）。
    """
    cur = [(float(p[0]), float(p[1])) for p in ring]
    n_iters = int(iters)
    n = len(cur)
    if n_iters <= 0 or n < 4:
        return cur

    # 记录原始面积和质心，每轮后把「缩水」补回去
    def _area(pts):
        s = 0.0
        m = len(pts)
        for k in range(m):
            x0, y0 = pts[k]
            x1, y1 = pts[(k + 1) % m]
            s += x0 * y1 - x1 * y0
        return s * 0.5

    def _centroid(pts):
        m = len(pts)
        return (sum(p[0] for p in pts) / m, sum(p[1] for p in pts) / m)

    a0 = abs(_area(cur))
    c0 = _centroid(cur)

    lam = max(0.0, min(1.0, float(lam)))

    # 掩膜查表（bool 数组）。用它判断「这个点还算不算在实心区里」。
    mshape = None
    if mask is not None:
        try:
            _m = mask
            mshape = (_m.shape[1], _m.shape[0])     # (W, H)
        except Exception:                            # noqa: BLE001
            mshape = None

    def _in_solid(px, py):
        """点是否落在实心区（越界算否）。"""
        if mask is None or mshape is None:
            return True
        xi = int(px)
        yi = int(py)
        if xi < 0 or yi < 0 or xi >= mshape[0] or yi >= mshape[1]:
            return False
        return bool(mask[yi, xi])

    # 【单点必须留在实心区内 —— 这是"平滑把实心区吃掉"的防线】
    #
    # 调用方传 mask 时，每个点平滑后都要检查是否还在实心区，跑出去就退回原位。
    #
    # ⚠️ 但光有这个防线**不够**：它只管"点在不在实心区"，管不住
    #    "两点之间连的线横穿了透明区"。在**稀疏点**上做 Laplacian 时
    #    （抽稀后只剩几十点），位移可达上百像素，点虽然都还在实心区里，
    #    连成的边却跨过了缺口，那一大片实心区就没面了。
    #    所以**平滑必须在密环上做**（见 pipeline.run_stage_a 的说明），
    #    密环的点距只有 1~2px，位移天然很小。
    for _ in range(n_iters):
        nxt = []
        for i in range(n):
            a = cur[(i - 1) % n]
            b = cur[i]
            c = cur[(i + 1) % n]
            midx = (a[0] + c[0]) * 0.5
            midy = (a[1] + c[1]) * 0.5
            nx = b[0] + lam * (midx - b[0])
            ny = b[1] + lam * (midy - b[1])
            # 跑出实心区 → 退回原位
            if not _in_solid(nx, ny):
                nx, ny = b
            nxt.append((nx, ny))
        cur = nxt

        # 面积/位置校正：平滑会收缩，按比例放大回原面积并移回原质心。
        # ⚠️ 这一步是**全局缩放**，会绕过上面的逐点 mask 校验 ——
        #    所以缩放后要再校验一次，把跑出实心区的点拉回缩放前的位置。
        #    （实测：不校验的话，smooth=2 仍有 15/77 个点落在环外）
        a1 = abs(_area(cur))
        if a0 > 1e-9 and a1 > 1e-9:
            k = (a0 / a1) ** 0.5
            if abs(k - 1.0) > 1e-6:
                cx, cy = _centroid(cur)
                scaled = []
                for p in cur:
                    sx = cx + (p[0] - cx) * k
                    sy = cy + (p[1] - cy) * k
                    if _in_solid(sx, sy):
                        scaled.append((sx, sy))
                    else:
                        scaled.append(p)     # 缩放会推到区外 → 保持缩放前
                cur = scaled
        cx, cy = _centroid(cur)
        if abs(cx - c0[0]) > 1e-9 or abs(cy - c0[1]) > 1e-9:
            cur = [(p[0] + c0[0] - cx, p[1] + c0[1] - cy) for p in cur]

    return cur


def ring_bbox(ring):
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    return min(xs), min(ys), max(xs), max(ys)


def rings_bbox(rings):
    xs0, ys0, xs1, ys1 = [], [], [], []
    for r in rings:
        if not r:
            continue
        x0, y0, x1, y1 = ring_bbox(r)
        xs0.append(x0)
        ys0.append(y0)
        xs1.append(x1)
        ys1.append(y1)
    if not xs0:
        return (0.0, 0.0, 0.0, 0.0)
    return min(xs0), min(ys0), max(xs1), max(ys1)
