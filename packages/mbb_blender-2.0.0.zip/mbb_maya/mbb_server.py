# mbb_server.py
# ---------------------------------------------------------------------------
# Maya <-> Blender Bridge
# ---------------------------------------------------------------------------

import socket
import threading
import traceback
import os
import json
import shutil
import glob
import re
import maya.utils
import maya.cmds as cmds

_server = None
_running = False
_log_buffer = []  # 攒日志，导出后一并返回 Blender

# ── ExportChaser 注册（引用去重功能，注册失败不影响导出）──
_has_chaser = False
try:
    from mbb_chaser import register_chaser
    _has_chaser = register_chaser()
except Exception as e:
    print(f"[MBB Server] ExportChaser 注册失败: {e}")
    print("[MBB Server] 引用去重功能不可用，但不影响其他功能")

del register_chaser  # 清理命名空间

# 取消标志：由 CANCEL 命令设置，长操作在关键点检测
_cancel_requested = False

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------
def log(msg):
    print(f"[MBB] {msg}")
    _log_buffer.append(msg)


# ---------------------------------------------------------------------------
# UDIM 检测（与 Blender 端 __init__.py 保持一致）
# 注意：两端独立维护，修改时需同步更新
# ---------------------------------------------------------------------------

_UDIM_TOKEN_PATTERN = re.compile(r'<(UDIM|UVTILE)>', re.IGNORECASE)
_UDIM_TILE_PATTERN = re.compile(
    r'[._](1\d{3})\.(png|jpg|jpeg|tga|exr|tiff|tif|hdr|bmp)(?:[.][^.]+)?$',
    re.IGNORECASE
)

_UDIM_TILE_MIN = 1001
_UDIM_TILE_MAX = 1999

_UVTILE_FILE_PATTERN = re.compile(r'[._]u(\d+)_v(\d+)\.', re.IGNORECASE)


def _uvtile_to_udim_number(u_str, v_str):
    """将 UVTILE 坐标映射为 UDIM tile number。
    UVTILE: u(u_tile+1)_v(v_tile+1), 从 1 开始
    UDIM:   1001 + u_tile + v_tile * 10
    """
    u = int(u_str) - 1
    v = int(v_str) - 1
    tile_num = 1001 + u + v * 10
    if tile_num < _UDIM_TILE_MIN or tile_num > _UDIM_TILE_MAX:
        return -1
    return tile_num


def detect_udim_tiles(filepath):
    """检测给定路径是否为 UDIM 纹理瓦片族的一部分。
    与 Blender 端 __init__.py 中的同名函数逻辑完全一致，两处需同步维护。
    """
    directory = os.path.dirname(filepath)
    basename = os.path.basename(filepath)

    # Step 1: <UDIM> / <UVTILE> token
    token_match = _UDIM_TOKEN_PATTERN.search(filepath)
    if token_match:
        token_type = token_match.group(1).upper()
        pattern = _UDIM_TOKEN_PATTERN.sub('*', filepath)
        tiles = {}
        for match_path in glob.glob(pattern):
            fname = os.path.basename(match_path)
            if token_type == 'UDIM':
                m = re.search(r'[._](\d{4})\.', fname)
                if m:
                    tile_num = int(m.group(1))
                    if _UDIM_TILE_MIN <= tile_num <= _UDIM_TILE_MAX:
                        tiles[tile_num] = match_path
            else:  # UVTILE
                m = _UVTILE_FILE_PATTERN.search(fname)
                if m:
                    tile_num = _uvtile_to_udim_number(m.group(1), m.group(2))
                    if tile_num > 0:
                        tiles[tile_num] = match_path
        if len(tiles) > 1:
            return {"is_udim": True, "tiles": tiles}
        else:
            return {"is_udim": False, "tiles": {}}

    # Step 2: 显式瓦片号
    tile_match = _UDIM_TILE_PATTERN.search(basename)
    if tile_match:
        tile_number = int(tile_match.group(1))
        if tile_number < _UDIM_TILE_MIN or tile_number > _UDIM_TILE_MAX:
            return {"is_udim": False, "tiles": {}}

        prefix = basename[:tile_match.start(1)]
        suffix = basename[tile_match.end(1):]
        glob_pattern = os.path.join(directory, f"{prefix}*{suffix}")
        tiles = {}
        for match_path in glob.glob(glob_pattern):
            m = _UDIM_TILE_PATTERN.search(os.path.basename(match_path))
            if m:
                num = int(m.group(1))
                if _UDIM_TILE_MIN <= num <= _UDIM_TILE_MAX:
                    tiles[num] = match_path

        if len(tiles) > 1:
            return {"is_udim": True, "tiles": tiles}

    return {"is_udim": False, "tiles": {}}



# ---------------------------------------------------------------------------
# Import USD file
# ---------------------------------------------------------------------------
def import_usd(path):
    try:
        if not cmds.pluginInfo('mayaUsdPlugin', query=True, loaded=True):
            cmds.loadPlugin('mayaUsdPlugin')
            log("mayaUsdPlugin loaded.")

        cmds.file(path, i=True, type="USD Import")
        return "IMPORT_SUCCESS"
    except Exception as e:
        traceback.print_exc()
        return f"IMPORT_FAILED: {e}"


# ---------------------------------------------------------------------------
# 采集材质元数据：扫描 aiStandardSurface，提取贴图→socket 映射
# ---------------------------------------------------------------------------
def collect_material_metadata(selected_only=True):
    """
    扫描场景材质，记录每个 PBR 槽位对应的贴图文件路径或默认值。
    不修改场景中的任何材质。

    泛用策略：沿连线递归向上追踪，直到找到 file/aiImage 节点。
    简单路径（直达或一层中间节点）→ 自动连线到 BSDF socket。
    复杂路径（多层/分支）→ 贴图放入材质但不自动连线。

    返回: (metadata: dict, texture_set: set)
    """
    metadata = {}
    texture_set = set()

    arnold_shaders = cmds.ls(type='aiStandardSurface')
    if not arnold_shaders:
        log("场景中没有 aiStandardSurface 材质")
        return metadata, texture_set

    for shader in arnold_shaders:
        sg_list = cmds.listConnections(shader, type='shadingEngine')
        if not sg_list:
            continue

        # 优先选有 mesh 成员的 SG，避免拿到材质创建时自动生成但从未使用的空壳
        sg = None
        sg_has_members = False
        candidate_info = []
        sg_members_cache = {}  # 缓存候选 SG 的成员查询结果，避免下游重复查询
        for candidate in sg_list:
            members = cmds.sets(candidate, query=True) or []
            sg_members_cache[candidate] = members
            candidate_info.append(f"{candidate}({len(members)}m)")
            if members and sg is None:
                sg = candidate
                sg_has_members = True
        if sg is None:
            sg = sg_list[0]

        # 区分 fallback 场景：单候选全空（正常） vs 多候选全空（异常）
        if sg_has_members:
            label = '(有成员)'
        elif len(sg_list) == 1:
            label = '(单候选/空)'
        else:
            label = '(多候选/全空→fallback)'
        log(f"  SG 候选: {', '.join(candidate_info)} → 选中: {sg} {label}")

        mat_name = _normalize_material_name(sg)  # key: shadingEngine 名（与 USD 材质 prim 命名一致）
        log(f"采集材质: {mat_name} (shader: {shader})")
        mat_info = {}

        # 记录物体-面映射（支持面级材质分配）
        assigned = sg_members_cache.get(sg, cmds.sets(sg, query=True) or [])
        face_map = {}   # {transform_name: [face_indices, ...]}
        obj_names = []  # 向后兼容的物体名列表

        for entry in assigned:
            # 解析组件字符串: 'pCube1.f[0:5]' 或 'pCube1Shape.f[0:5]' 或 'pCube1'
            obj_part = entry
            face_indices = None

            if '.' in entry:
                obj_part, comp = entry.split('.', 1)
                if comp.startswith('f['):
                    inner = comp[2:-1]  # 去掉 f[ 和 ]
                    face_indices = []
                    for seg in inner.split(':'):
                        try:
                            face_indices.append(int(seg))
                        except ValueError:
                            face_indices = None
                            break

            # 转 Transform 名
            node_type = cmds.nodeType(obj_part) if cmds.objExists(obj_part) else ''
            is_shape = 'shape' in node_type.lower() if node_type else False
            if is_shape:
                parents = cmds.listRelatives(obj_part, parent=True, fullPath=False)
                tf_name = parents[0] if parents else obj_part
            else:
                tf_name = obj_part

            # face_map key 归一化（与 Blender 对象名一致）
            norm_tf_name = tf_name.replace(':', '_')

            if face_indices and len(face_indices) == 2:
                # 范围: f[0:5] → 0,1,2,3,4,5
                face_list = list(range(face_indices[0], face_indices[1] + 1))
                if norm_tf_name not in face_map:
                    face_map[norm_tf_name] = []
                face_map[norm_tf_name].extend(face_list)
            elif face_indices and len(face_indices) == 1:
                # 单面
                if norm_tf_name not in face_map:
                    face_map[norm_tf_name] = []
                face_map[norm_tf_name].append(face_indices[0])
            else:
                # 整个物体（无面信息）
                face_map[norm_tf_name] = []  # 空列表 = 整个物体

            if tf_name not in obj_names:
                # Maya 长名 → USD prim 路径
                long_name = cmds.ls(tf_name, long=True)
                if long_name:
                    path = _maya_dag_to_usd_prim_path(long_name[0])
                    obj_names.append(path)
                else:
                    obj_names.append(tf_name)

        mat_info['_objects'] = obj_names
        mat_info['_face_map'] = face_map
        log(f"  关联物体: {list(face_map.keys())}")

        # --- 遍历所有 Arnold 属性，泛用追踪 ---
        all_attrs = [attr for attr in cmds.listAttr(shader, visible=True, hasData=True)
                     if not attr.startswith('_')]

        # 补充隐藏但常用的属性（listAttr 扫不到）
        HIDDEN_ATTRS = ['normalCamera', 'bumpMap']
        for ha in HIDDEN_ATTRS:
            if cmds.attributeQuery(ha, node=shader, exists=True) and ha not in all_attrs:
                all_attrs.append(ha)

        # --- 阶段 1: 原始采集（不判定复杂度） ---
        raw_textures = {}  # {blender_socket: [tex_path, ...]}

        for arnold_attr in all_attrs:
            blender_socket = _map_to_blender_socket(arnold_attr)
            if blender_socket is None:
                continue

            tex_paths = _trace_textures_upstream(shader, arnold_attr)

            if tex_paths:
                # extend 而非覆盖：防止 normalCamera 和 bumpMap 等多源映射到同一 socket 时丢失数据
                if blender_socket not in raw_textures:
                    raw_textures[blender_socket] = tex_paths
                else:
                    raw_textures[blender_socket].extend(tp for tp in tex_paths if tp not in raw_textures[blender_socket])
                for tp in tex_paths:
                    texture_set.add(tp)
            else:
                # 无贴图连接 → 读默认值
                val = _read_attr_value(shader, arnold_attr)
                if val is not None and blender_socket != 'Normal':
                    if isinstance(val, (list, tuple)) and len(val) >= 3:
                        mat_info[blender_socket] = {'color': list(val[:3])}
                    elif isinstance(val, float):
                        mat_info[blender_socket] = {'value': val}

        # --- 阶段 2: 拓扑判复杂度 ---
        # 规则: 同一贴图出现在多个 socket → 复杂(1对多)
        #       同一 socket 有多个贴图源 → 复杂(多对1)
        #       其他所有情况 → 简单，自动连线

        # 2a: 统计每张贴图被几个 socket 使用
        tex_to_sockets = {}  # {tex_path: {socket, ...}}
        for socket, tex_paths in raw_textures.items():
            for tp in tex_paths:
                if tp not in tex_to_sockets:
                    tex_to_sockets[tp] = set()
                tex_to_sockets[tp].add(socket)

        # 2b: 写入 mat_info
        for socket, tex_paths in raw_textures.items():
            for tp in tex_paths:
                is_one_to_many = len(tex_to_sockets[tp]) > 1       # 同贴图多socket
                is_many_to_one = len(tex_paths) > 1                # 同socket多贴图
                is_complex = is_one_to_many or is_many_to_one

                if is_complex:
                    mat_info[socket] = {'texture': tp, 'connect': False}
                    log(f"  [{mat_name}] {socket}: {os.path.basename(tp)} → 复杂"
                          f"({'1对多' if is_one_to_many else ''}{'+' if is_one_to_many and is_many_to_one else ''}{'多对1' if is_many_to_one else ''})")
                else:
                    mat_info[socket] = {'texture': tp}
                    log(f"  [{mat_name}] {socket}: {os.path.basename(tp)} → 简单(自动连)")

        if mat_info:
            metadata[mat_name] = mat_info

    return metadata, texture_set


def _trace_textures_upstream(shader, attr_name, visited=None, depth=0, max_depth=10):
    """
    泛用递归：从 shader.attr_name 沿连线向上游追踪，找到所有 file/aiImage 贴图。
    不判定复杂度——复杂度由调用方根据拓扑（1对多/多对1）判断。

    返回: [texture_path, ...]
    """
    if visited is None:
        visited = set()
    if depth > max_depth:
        return []

    node_key = f"{shader}.{attr_name}"
    if node_key in visited:
        return []
    visited.add(node_key)

    connections = cmds.listConnections(node_key, source=True, destination=False)
    if not connections:
        return []

    results = []
    for conn in connections:
        conn_type = cmds.nodeType(conn)

        # 终点：贴图文件节点
        if conn_type == 'file':
            path = cmds.getAttr(f'{conn}.fileTextureName')
            if path and path not in results:
                results.append(path)
        elif conn_type == 'aiImage':
            path = cmds.getAttr(f'{conn}.filename')
            if path and path not in results:
                results.append(path)
        else:
            # 中间节点 → 递归探测它的所有入向连接
            try:
                # 用 plugs=True 一次性获取精确的属性级上游连接
                src_plugs = cmds.listConnections(conn, source=True, destination=False, plugs=True)
                if src_plugs:
                    for src_plug in src_plugs:
                        parts = src_plug.split('.')
                        if len(parts) < 2:
                            continue
                        src_node, src_attr = parts[0], parts[1]
                        src_type = cmds.nodeType(src_node)
                        if src_type == 'file':
                            path = cmds.getAttr(f'{src_node}.fileTextureName')
                            if path and path not in results:
                                results.append(path)
                        elif src_type == 'aiImage':
                            path = cmds.getAttr(f'{src_node}.filename')
                            if path and path not in results:
                                results.append(path)
                        else:
                            sub = _trace_textures_upstream(
                                src_node, src_attr, visited, depth + 1, max_depth)
                            for tp in sub:
                                if tp not in results:
                                    results.append(tp)
                else:
                    # plugs 查不到时，退回到遍历中间节点的可见属性
                    for sub_attr in cmds.listAttr(conn, visible=True, hasData=True) or []:
                        if sub_attr.startswith('_'):
                            continue
                        sub_results = _trace_textures_upstream(
                            conn, sub_attr, visited, depth + 1, max_depth)
                        for tp in sub_results:
                            if tp not in results:
                                results.append(tp)
            except Exception as e:
                log(f"  ⚠ 追踪贴图失败 {conn}: {e}")

    return results


def _map_to_blender_socket(arnold_attr):
    """Arnold 属性名 → Blender Principled BSDF socket 名"""
    MAP = {
        'baseColor': 'Base Color',
        'specularRoughness': 'Roughness',
        'metalness': 'Metallic',
        'emissionColor': 'Emission Color',
        'specularColor': 'Specular Tint',
        'coat': 'Coat Weight',
        'coatRoughness': 'Coat Roughness',
        'normalCamera': 'Normal',
        'bumpMap': 'Bump',     # 高度图 → 走 Bump 节点，不走 Normal Map
        'opacity': 'Alpha',
        'transmission': 'Transmission Weight',
    }
    return MAP.get(arnold_attr)


def _read_attr_value(shader, attr_name):
    """读取属性的默认值（无连接时）"""
    try:
        val = cmds.getAttr(f'{shader}.{attr_name}')
        return val
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 路径与名称归一化工具函数
# ---------------------------------------------------------------------------
def _maya_dag_to_usd_prim_path(maya_long_name):
    """将 Maya DAG 长名转换为 USD prim 路径。

    行为与 mayaUSDExport 内部转换一致：
    - 去掉前导 |
    - 用 / 替换路径分隔符
    - 用 _ 替换命名空间冒号
    - 末段如果是 Shape 节点则去掉
    """
    path = '/' + maya_long_name.lstrip('|').replace('|', '/').replace(':', '_')
    parts = path.rsplit('/', 1)
    if len(parts) == 2 and 'Shape' in parts[1]:
        path = parts[0]
    return path


def _normalize_material_name(sg_name):
    """将 Maya SG 名转换为与 USD 材质 prim 一致的名称。"""
    return sg_name.replace(':', '_')


# ---------------------------------------------------------------------------
# 材质类型检测
# ---------------------------------------------------------------------------
def detect_material_types(selected_only=True):
    """检测场景中选中物体使用的材质节点类型。

    判断逻辑:
      遍历每个选中物体（含深层子 mesh）→ 查 shadingEngine → 查 surfaceShader → 取 nodeType

    selected_only=False 为预留接口，供后续批量导出场景时使用。当前仅以默认值调用。

    返回: set of strings，例如 {'aiStandardSurface'} 或 {'UsdPreviewSurface'}
    如果物体没有材质，返回空 set。
    """
    types = set()

    # 获取目标物体列表
    if selected_only:
        objects = cmds.ls(selection=True, type='transform')
    else:
        objects = cmds.ls(type='transform')

    # 递归展开所有子 mesh（处理 Group 嵌套场景）
    all_meshes = set()
    for obj in objects:
        descendants = cmds.listRelatives(obj, allDescendents=True, fullPath=True, type='mesh') or []
        for d in descendants:
            all_meshes.add(d)

    for shape in all_meshes:
        sgs = cmds.listConnections(shape, type='shadingEngine') or []
        for sg in sgs:
            shaders = cmds.listConnections(f'{sg}.surfaceShader') or []
            for shader in shaders:
                try:
                    node_type = cmds.nodeType(shader)
                    types.add(node_type)
                except RuntimeError:
                    log(f"  跳过无效 shader 节点: {shader}")

    return types


# ---------------------------------------------------------------------------
# 写入 prim 材质标记（从 export_usd_from_maya 抽取，支持多材质类型）
# ---------------------------------------------------------------------------
def _write_prim_material_markers(usd_path):
    """用 pxr 在 USD prim 上写 mbb_material 标记，支持所有材质类型。

    泛用策略：从 shadingEngine 反向查找所有材质，不依赖材质类型白名单。
    先用精确路径匹配，失败时用叶子名 fallback。
    """
    try:
        from pxr import Usd, Sdf

        layer = Sdf.Layer.FindOrOpen(usd_path)
        stage = Usd.Stage.Open(layer)

        # 预建叶子名→prim 字典（一次遍历，O(n)）
        leaf_to_prim = {}
        collision_names = set()
        for p in stage.Traverse():
            name = p.GetName()
            if name in leaf_to_prim:
                log(f"⚠ 叶子名冲突: {name} ({leaf_to_prim[name].GetPath()} vs {p.GetPath()})")
                collision_names.add(name)
            else:
                leaf_to_prim[name] = p

        written = 0
        for sg in cmds.ls(type='shadingEngine'):
            shaders = cmds.listConnections(f'{sg}.surfaceShader') or []
            for shader in shaders:
                mat_name = _normalize_material_name(sg)
                assigned = cmds.sets(sg, query=True) or []
                for entry in assigned:
                    obj_name = entry.split('.')[0]
                    full_path = cmds.ls(obj_name, long=True)
                    if not full_path:
                        continue
                    usd_path_str = _maya_dag_to_usd_prim_path(full_path[0])

                    # 精确匹配
                    prim = stage.GetPrimAtPath(usd_path_str)
                    if not prim or not prim.IsValid():
                        # 叶子名 fallback：仅在无歧义时使用
                        leaf_name = usd_path_str.rsplit('/', 1)[-1]
                        if leaf_name in collision_names:
                            log(f"⚠ 跳过叶子名冲突的 prim: {usd_path_str}（叶子名 {leaf_name} 存在冲突，不写入 mbb_material）")
                        elif leaf_name in leaf_to_prim:
                            prim = leaf_to_prim[leaf_name]
                        else:
                            log(f"⚠ 跳过: {usd_path_str}（叶子名 {leaf_name} 未在 USD 中找到对应 prim）")

                    if prim and prim.IsValid():
                        prim.SetCustomDataByKey('mbb_material', mat_name)
                        written += 1

        stage.GetRootLayer().Save()
        log(f"已写入 prim 材质标记: {written} 个（共 {len(cmds.ls(type='shadingEngine'))} 个 SG）")
    except Exception as e:
        log(f"⚠ 写入材质标记失败: {e}")


# ---------------------------------------------------------------------------
# 复制贴图文件到 temp 目录
# ---------------------------------------------------------------------------
def copy_texture_files(texture_set, temp_dir, metadata):
    """
    将贴图文件复制到 temp_dir/textures/，更新 metadata 中的路径为相对路径。
    """
    tex_dir = os.path.join(temp_dir, 'textures')
    os.makedirs(tex_dir, exist_ok=True)

    # 收集已使用的文件名（处理「不同源文件同名」的冲突）
    used_names = {}
    # 源路径 → 已复制的目标相对路径（同一源文件去重，不重复复制）
    src_to_dest = {}

    updated_metadata = {}
    for mat_name, mat_info in metadata.items():
        updated_info = {}
        for socket_name, socket_data in mat_info.items():
            if socket_name.startswith('_'):
                updated_info[socket_name] = socket_data
                continue

            if 'texture' not in socket_data:
                updated_info[socket_name] = socket_data
                continue

            src_path = socket_data['texture']

            # UDIM 检测（优先于 os.path.exists，token 路径在磁盘上不存在）
            udim_info = detect_udim_tiles(src_path)
            if udim_info["is_udim"]:
                log(f"  检测到 UDIM 贴图: {src_path}（{len(udim_info['tiles'])} 个瓦片）")
                first_copied = None
                for tile_num in sorted(udim_info["tiles"].keys()):
                    tile_path = udim_info["tiles"][tile_num]

                    # 源路径去重：同一瓦片已复制过则复用
                    tile_path_norm = os.path.normcase(os.path.normpath(tile_path))
                    if tile_path_norm in src_to_dest:
                        if first_copied is None:
                            first_copied = src_to_dest[tile_path_norm]
                        continue

                    t_filename = os.path.basename(tile_path)
                    if t_filename in used_names:
                        used_names[t_filename] += 1
                        base, ext = os.path.splitext(t_filename)
                        t_filename = f"{base}_{used_names[t_filename]}{ext}"
                    else:
                        used_names[t_filename] = 1
                    t_dst = os.path.join(tex_dir, t_filename)
                    try:
                        shutil.copy2(tile_path, t_dst)
                        src_to_dest[tile_path_norm] = f"textures/{t_filename}"
                        if first_copied is None:
                            first_copied = f"textures/{t_filename}"
                    except Exception as e:
                        log(f"  ⚠ 复制 UDIM 瓦片失败 {t_filename}: {e}")
                if first_copied:
                    # 保留 socket_data 中的其他字段（如 connect）
                    entry = {k: v for k, v in socket_data.items() if k != 'texture'}
                    entry['texture'] = first_copied
                    updated_info[socket_name] = entry
                continue

            # 源路径去重：同一贴图已复制过则复用
            src_path_norm = os.path.normcase(os.path.normpath(src_path))
            if src_path_norm in src_to_dest:
                entry = {k: v for k, v in socket_data.items() if k != 'texture'}
                entry['texture'] = src_to_dest[src_path_norm]
                updated_info[socket_name] = entry
                continue

            if not os.path.exists(src_path):
                log(f"  ⚠ 贴图不存在: {src_path}")
                continue

            filename = os.path.basename(src_path)

            # 处理重名
            if filename in used_names:
                used_names[filename] += 1
                base, ext = os.path.splitext(filename)
                filename = f"{base}_{used_names[filename]}{ext}"
            else:
                used_names[filename] = 1

            dst_path = os.path.join(tex_dir, filename)

            try:
                shutil.copy2(src_path, dst_path)
                rel_path = f"textures/{filename}"
                src_to_dest[src_path_norm] = rel_path
                # 保留 socket_data 中的其他字段（如 connect）
                entry = {k: v for k, v in socket_data.items() if k != 'texture'}
                entry['texture'] = rel_path
                updated_info[socket_name] = entry
            except Exception as e:
                log(f"  ⚠ 复制贴图失败 {filename}: {e}")
                continue

        updated_metadata[mat_name] = updated_info

    return updated_metadata


# ---------------------------------------------------------------------------
# 写材质元数据 JSON
# ---------------------------------------------------------------------------
def write_material_json(metadata, json_path):
    """将材质元数据写入 JSON 文件，UTF-8 编码。"""
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    log(f"材质元数据已写入: {json_path}")


# ---------------------------------------------------------------------------
# 导出 USD + 材质元数据
# ---------------------------------------------------------------------------
def export_usd_from_maya(path, selected_only=True, anim_config=None):
    """
    主导出函数：
    1. 采集材质元数据
    2. 复制贴图到 temp 目录
    3. 写 JSON
    4. 导出 USD（纯几何）

    anim_config 格式: {"mode": "CACHE"|"SKELETAL", "frame_start": int, "frame_end": int, "frame_step": int}
    为 None 时不导出动画（向后兼容）。
    """
    try:
        global _log_buffer
        _log_buffer = []
        log(f"开始导出: {path}")

        # ── 构建动画导出参数 ──
        anim_kwargs = {}
        if anim_config:
            # 版本检测：Maya 2024+ 支持 frameRange 关键字参数
            try:
                maya_version = int(cmds.about(version=True))
            except (ValueError, TypeError):
                maya_version = 0
            if maya_version < 2024:
                log(f"警告: 动画导出需要 Maya 2024+，当前版本 {maya_version} 可能不支持，将导出静态帧")
                anim_config = None

        if anim_config:
            if not isinstance(anim_config, dict):
                log(f"anim_config 格式错误: {type(anim_config)}")
                return "EXPORT_FAILED: anim_config 格式错误，应为 JSON 对象"
            mode = anim_config.get("mode", "NONE")
            if mode in ("CACHE", "SKELETAL"):
                frame_start = anim_config.get("frame_start", 0)
                frame_end = anim_config.get("frame_end", 0)
                frame_step = anim_config.get("frame_step", 1)

                # 留空 → 自动取 Maya 时间滑条范围
                if frame_start <= 0 or frame_end <= 0:
                    frame_start = int(cmds.playbackOptions(query=True, min=True))
                    frame_end = int(cmds.playbackOptions(query=True, max=True))
                    log(f"自动获取时间滑条范围: {frame_start} - {frame_end}")

                if frame_start > frame_end:
                    return f"EXPORT_FAILED: 帧范围无效 (start={frame_start} > end={frame_end})"

                anim_kwargs["frameRange"] = (frame_start, frame_end)
                anim_kwargs["frameStride"] = frame_step
                log(f"动画模式: {mode}, 帧 {frame_start}-{frame_end}, 步长 {frame_step}")

                if mode == "SKELETAL":
                    anim_kwargs["exportSkels"] = "auto"
                    anim_kwargs["exportSkin"] = "auto"
                    anim_kwargs["exportBlendShapes"] = True
                    log("骨骼导出: Skel=auto, Skin=auto, BlendShapes=on")

        # 1. 加载插件
        if not cmds.pluginInfo('mayaUsdPlugin', query=True, loaded=True):
            cmds.loadPlugin('mayaUsdPlugin')
            log("mayaUsdPlugin loaded.")

        # 2. 材质类型检测 → 分支路由
        mat_types = detect_material_types(selected_only)
        log(f"检测到材质类型: {mat_types}")

        # ── Arnold 额外采集（如果有 aiStandardSurface）──
        json_path = None
        if 'aiStandardSurface' in mat_types:
            metadata, texture_set = collect_material_metadata(selected_only)
            if metadata:
                temp_dir = os.path.dirname(path)
                metadata = copy_texture_files(texture_set, temp_dir, metadata)
                base = os.path.splitext(os.path.basename(path))[0]
                json_path = os.path.join(temp_dir, f"{base}_meta.json")
                write_material_json(metadata, json_path)

        # ── 统一导出（始终 shd='useRegistry' + 材质转换）──
        export_kwargs = {
            'file': path,
            'sl': selected_only,
            'shd': 'useRegistry',
            'convertMaterialsTo': ['UsdPreviewSurface'],
        }
        if _has_chaser:
            export_kwargs['chaser'] = ['mbbReferenceSource']

        cmds.mayaUSDExport(**export_kwargs, **anim_kwargs)
        log(f"USD 已导出: {path}")

        # ── 写入 prim 材质标记 ──
        _write_prim_material_markers(path)

        # ── 构造返回字符串 ──
        result = f"EXPORT_SUCCESS:{path.replace(os.sep, '/')}"
        if json_path:
            result += f"|{json_path.replace(os.sep, '/')}"
        if _log_buffer:
            result += f"|LOG:{';'.join(_log_buffer[-20:])}"
        return result

    except Exception as e:
        traceback.print_exc()
        return f"EXPORT_FAILED: {e}"


# ---------------------------------------------------------------------------
# Client handler
# ---------------------------------------------------------------------------
def handle_client(conn, addr):
    log(f"Connection from {addr}")
    with conn:
        while _running:
            try:
                data = b''
                while True:
                    chunk = conn.recv(8192)
                    if not chunk:
                        break
                    data += chunk
                    if b'\n' in data:
                        break
                if not data:
                    break

                msg = data.decode("utf-8").strip()
                log(f"Received: {msg}")

                # 对耗时操作先发 PROCESSING 确认
                parts = msg.split(" ", 1)
                cmd = parts[0].lower()
                if cmd in ("import_usd", "export_selected"):
                    # 检测是否有取消请求
                    global _cancel_requested
                    if _cancel_requested:
                        _cancel_requested = False
                        response = "CANCELLED"
                        conn.sendall((response + "\n").encode("utf-8"))
                        continue
                    conn.sendall("PROCESSING\n".encode("utf-8"))

                response = process_message(msg)
                conn.sendall((response + "\n").encode("utf-8"))

            except Exception as e:
                log(f"Error: {e}")
                try:
                    conn.sendall(f"Error: {e}\n".encode("utf-8"))
                except Exception:
                    pass
                break
    
    log(f"Client {addr} disconnected")


# ---------------------------------------------------------------------------
# Command dispatcher: Based on the command given by client, this server will
# perform different tasks.
# ---------------------------------------------------------------------------
def process_message(msg):
    log(f"processing message!")

    # Format of the command should always be {CMD} {arg1} {arg2}.
    # This format is case insensitive.
    parts = msg.strip().split(" ", 1)
    cmd = parts[0].lower()

    # Gets only the first argument.
    # TODO: In future may need support for more than one arguments.
    arg = parts[1].strip() if len(parts) > 1 else ""

    if cmd == "ping":
        return "pong"

    elif cmd == "import_usd":
        def _do_import():
            result = import_usd(arg)
            log(result)
            return result
        return maya.utils.executeInMainThreadWithResult(_do_import)

    elif cmd == "cancel":
        global _cancel_requested
        _cancel_requested = True
        log("取消信号已接收")
        return "CANCELLED"

    elif cmd == "export_selected":
        def _do_export():
            # 尝试 JSON 解析（新协议）：{"path":"...","anim_config":{...}}
            try:
                cfg = json.loads(arg)
                path = cfg.get("path")
                if not path:
                    return "EXPORT_FAILED: JSON 中缺少 'path' 字段"
                anim_config = cfg.get("anim_config")
                result = export_usd_from_maya(path, anim_config=anim_config)
            except (json.JSONDecodeError, ValueError):
                # 旧协议：arg 就是纯路径
                result = export_usd_from_maya(arg)
            log(result)
            return result
        return maya.utils.executeInMainThreadWithResult(_do_export)

    elif cmd == "eval":
        # Execute arbitrary Python code, return captured stdout
        def _do_eval():
            import sys
            from io import StringIO
            old_stdout = sys.stdout
            buf = StringIO()
            # Provide common Maya modules in exec namespace
            import maya.cmds as cmds
            import maya.mel as mel
            namespace = {'__builtins__': __builtins__, 'cmds': cmds, 'mel': mel}
            try:
                sys.stdout = buf
                exec(arg, namespace)
                output = buf.getvalue()
                return output if output else "OK"
            except Exception as e:
                import traceback
                return f"EVAL_ERROR: {e}\n{traceback.format_exc()}"
            finally:
                sys.stdout = old_stdout
        return maya.utils.executeInMainThreadWithResult(_do_eval)

    return f"UNKNOWN_COMMAND: {cmd}"


# ---------------------------------------------------------------------------
# Starts a socket connection for communication between external software with Maya
# ---------------------------------------------------------------------------
def start_server(host="127.0.0.1", port=50008):
    global _server, _running

    # If it is running, skip this process.
    if _running:
        log("Already running.")
        return

    # Sets the required properties for server to start.
    _running = True
    _server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    _server.bind((host, port))
    _server.listen(1)

    log(f"Listening on {host}:{port}")

    def accept_loop():
        while _running:
            try:
                conn, addr = _server.accept()
                try:
                    threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()
                except Exception:
                    conn.close()  # 线程创建失败时关闭连接，避免客户端挂起
                    log(f"Failed to start handler thread for {addr}")
            except OSError:
                break

    threading.Thread(target=accept_loop, daemon=True).start()


# ---------------------------------------------------------------------------
# Stops the socket connection.
# ---------------------------------------------------------------------------
def stop_server():
    global _server, _running
    if not _running:
        log("Not running.")
        return
    _running = False
    if _server:
        try:
            _server.close()
        except Exception:
            pass
        _server = None
        
    log("Stopped.")
