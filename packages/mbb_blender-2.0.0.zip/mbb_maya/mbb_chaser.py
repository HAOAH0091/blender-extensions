# mbb_chaser.py
# ---------------------------------------------------------------------------
# MBB Maya USD ExportChaser — 给 USD prim 标记 Maya 引用源文件路径。
#
# 集成方式：在 mbb_server.py 模块顶层注册，mayaUSDExport 调用时通过
# chaser 参数激活。注册失败不影响导出流程。
# ---------------------------------------------------------------------------

import sys
import traceback

try:
    import mayaUsd.lib as mayaUsdLib
    _MAYAUSD_AVAILABLE = True
except ImportError:
    _MAYAUSD_AVAILABLE = False

try:
    import maya.cmds as cmds
    _MAYA_AVAILABLE = True
except ImportError:
    _MAYA_AVAILABLE = False

from pxr import UsdShade


class MBBReferenceChaser(mayaUsdLib.ExportChaser if _MAYAUSD_AVAILABLE else object):
    """在 USD prim 上标记 Maya 引用源文件路径。

    分两次遍历：
    1. DAG 节点：通过 GetDagToUsdMap() 获取 Maya→USD 精确映射，
       用 referenceQuery 反查源文件。
    2. 材质 prim：遍历 stage 中所有 UsdShade.Material，
       通过 prim 名称反查 Maya SG 的引用归属。
    """

    name = "mbbReferenceSource"

    def __init__(self, factoryContext, *args, **kwargs):
        if not _MAYAUSD_AVAILABLE:
            raise RuntimeError("mayaUsd.lib 不可用，无法创建 MBBReferenceChaser")
        super().__init__(factoryContext, *args, **kwargs)
        self._stage = factoryContext.GetStage()
        self._dag_to_usd = factoryContext.GetDagToUsdMap()

    # ------------------------------------------------------------------
    # 工具方法
    # ------------------------------------------------------------------

    @staticmethod
    def _build_ref_node_source_map():
        """构建 {引用节点名: 源文件路径} 映射。"""
        ref_map = {}
        for ref_node in cmds.ls(type="reference"):
            try:
                fname = cmds.referenceQuery(
                    ref_node, filename=True, withoutCopyNumber=True
                )
                ref_map[ref_node] = fname
                print(f"[MBB Chaser] 引用映射: '{ref_node}' → {fname}")
            except Exception as e:
                print(f"[MBB Chaser] 警告: 无法查询引用节点 {ref_node}: {e}")
        return ref_map

    @staticmethod
    def _build_material_name_source_map(ref_node_source_map):
        """构建 {规范化SG名 → (源文件路径, SG基础名)} 映射表。

        USD 中材质 prim 名是通过 _normalize_material_name() 转换后的下划线版本。
        SG 基础名是去掉 Maya namespace 前缀后的原始 shadingEngine 名称，
        用于 Blender 侧按 SG 名分组去重。
        """
        mat_map = {}
        try:
            import mbb_server as _ms
            _normalize = _ms._normalize_material_name
        except (ImportError, AttributeError):
            _normalize = lambda s: s.replace(':', '_')

        for sg in cmds.ls(type='shadingEngine'):
            normalized = _normalize(sg)
            ref_node = None
            try:
                ref_node = cmds.referenceQuery(sg, referenceNode=True)
            except RuntimeError:
                pass
            if ref_node and ref_node in ref_node_source_map:
                # 提取 SG 基础名：去掉 namespace 前缀
                # sg 格式如 "C06DaoDunBing_Rig1RN:daodunbingSG"
                if ':' in sg:
                    base_sg = sg.split(':')[-1]
                else:
                    base_sg = sg
                mat_map[normalized] = (ref_node_source_map[ref_node], base_sg)
        return mat_map

    @staticmethod
    def _get_source_for_dag(maya_dag_path_str, ref_node_source_map):
        """从 Maya DAG 路径反查引用节点名，返回对应的源文件路径。"""
        try:
            ref_node = cmds.referenceQuery(
                maya_dag_path_str, referenceNode=True
            )
            return ref_node_source_map.get(ref_node) if ref_node else None
        except RuntimeError:
            return None

    # ------------------------------------------------------------------
    # PostExport
    # ------------------------------------------------------------------

    def PostExport(self):
        """导出完成后，遍历 DAG prim 和材质 prim 打标记。"""
        print("[MBB Chaser] ======== PostExport 开始 ========")

        # Step 0：构建引用映射表
        ref_node_source_map = self._build_ref_node_source_map()
        print(f"[MBB Chaser] 引用节点总数: {len(ref_node_source_map)}")

        # Step 0b：构建材质规范化名称映射表
        mat_name_source_map = self._build_material_name_source_map(
            ref_node_source_map
        )
        print(
            f"[MBB Chaser] 材质名称映射: "
            f"{len(mat_name_source_map)} 个 SG 已映射"
        )

        # ── Step 1：DAG prim 打标 ──
        dag_stats = {"total": 0, "tagged": 0, "no_ref": 0, "error": 0}
        no_ref_samples = []

        for item in self._dag_to_usd:
            maya_path = str(item.key())
            usd_path = item.data()
            dag_stats["total"] += 1

            source = self._get_source_for_dag(maya_path, ref_node_source_map)
            if source:
                prim = self._stage.GetPrimAtPath(usd_path)
                if prim and prim.IsValid():
                    prim.SetCustomDataByKey("mbb_source_file", source)
                    dag_stats["tagged"] += 1
                else:
                    dag_stats["error"] += 1
                    print(f"[MBB Chaser] prim 不存在或无效: usd_path={usd_path}")
            else:
                dag_stats["no_ref"] += 1
                if len(no_ref_samples) < 20:
                    no_ref_samples.append(maya_path)

        print(
            f"[MBB Chaser] DAG: 总={dag_stats['total']}, "
            f"已打标={dag_stats['tagged']}, "
            f"非引用={dag_stats['no_ref']}, "
            f"错误={dag_stats['error']}"
        )
        if no_ref_samples:
            print(f"[MBB Chaser] 非引用 DAG 路径样本（前 {len(no_ref_samples)} 个）:")
            for p in no_ref_samples:
                print(f"[MBB Chaser]   {p}")

        # ── Step 2：材质 prim 打标 ──
        mat_stats = {"total": 0, "tagged": 0, "no_ref": 0}
        no_ref_mat_samples = []

        for prim in self._stage.Traverse():
            if not prim.IsA(UsdShade.Material):
                continue
            mat_stats["total"] += 1

            prim_name = prim.GetName()
            # 用规范化名称在映射表中查找 (源文件, SG基础名)
            entry = mat_name_source_map.get(prim_name)
            if entry:
                source, base_sg = entry
                prim.SetCustomDataByKey("mbb_source_file", source)
                prim.SetCustomDataByKey("mbb_sg_name", base_sg)
                mat_stats["tagged"] += 1
            else:
                mat_stats["no_ref"] += 1
                if len(no_ref_mat_samples) < 10:
                    no_ref_mat_samples.append(prim_name)

        print(
            f"[MBB Chaser] 材质: 总={mat_stats['total']}, "
            f"已打标={mat_stats['tagged']}, "
            f"非引用={mat_stats['no_ref']}"
        )
        if no_ref_mat_samples:
            print(
                f"[MBB Chaser] 非引用材质 prim 样本"
                f"（前 {len(no_ref_mat_samples)} 个）:"
            )
            for n in no_ref_mat_samples:
                print(f"[MBB Chaser]   {n}")

        print("[MBB Chaser] ======== PostExport 完成 ========")
        return True


# ---------------------------------------------------------------------------
# 注册 / 注销
# ---------------------------------------------------------------------------

def register_chaser():
    """注册 MBBReferenceChaser。返回 True 表示成功。"""
    if not _MAYAUSD_AVAILABLE:
        print("[MBB Chaser] mayaUsd.lib 不可用，跳过注册")
        return False
    try:
        # 先注销旧版本（如果开发期间重新加载）
        try:
            mayaUsdLib.ExportChaser.Unregister(
                MBBReferenceChaser, MBBReferenceChaser.name
            )
        except Exception:
            pass
        mayaUsdLib.ExportChaser.Register(
            MBBReferenceChaser, MBBReferenceChaser.name
        )
        print(f"[MBB Chaser] ExportChaser '{MBBReferenceChaser.name}' 已注册")
        return True
    except Exception as e:
        print(f"[MBB Chaser] 注册失败: {e}")
        traceback.print_exc()
        return False


def unregister_chaser():
    """注销 MBBReferenceChaser。"""
    if not _MAYAUSD_AVAILABLE:
        return
    try:
        mayaUsdLib.ExportChaser.Unregister(
            MBBReferenceChaser, MBBReferenceChaser.name
        )
        print(f"[MBB Chaser] ExportChaser '{MBBReferenceChaser.name}' 已注销")
    except Exception as e:
        print(f"[MBB Chaser] 注销失败: {e}")
