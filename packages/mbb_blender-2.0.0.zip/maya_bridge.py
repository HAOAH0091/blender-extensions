"""Maya 远程控制桥接模块。

通过 MBB 服务器的 EVAL 命令，从外部 Python 脚本控制 Maya：
    from maya_bridge import Maya

    with Maya() as m:
        m.select(['a', 'b', 'c'])
        print(m.detect_material_types())

依赖：Maya 必须已启动 MBB 服务器并开启 EVAL 命令支持。
"""

import socket
import time
import subprocess
import os


class MayaBridgeError(Exception):
    """Maya 桥接错误。"""
    pass


class Maya:
    """Maya 远程控制客户端。

    通过 TCP socket 连接 MBB 服务器，发送 EVAL 命令执行任意 Python 代码。

    用法:
        with Maya() as m:
            m.select(['a', 'b'])
            print(m.detect_material_types())
    """

    DEFAULT_HOST = '127.0.0.1'
    DEFAULT_PORT = 50008
    DEFAULT_TIMEOUT = 10
    MAYA_EXE = r'C:\Program Files\Autodesk\Maya2025\bin\maya.exe'
    MBB_PATH = r'F:\desktop\BaiduSyncdisk\addons\mbb_blender\mbb_maya'

    def __init__(self, host=None, port=None):
        self.host = host or self.DEFAULT_HOST
        self.port = port or self.DEFAULT_PORT
        self._sock = None

    # ── 连接管理 ──────────────────────────────────────────

    def connect(self, timeout=None):
        """建立与 Maya MBB 服务器的连接。"""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(timeout or self.DEFAULT_TIMEOUT)
        try:
            self._sock.connect((self.host, self.port))
        except (ConnectionRefusedError, socket.timeout) as e:
            self._sock.close()
            self._sock = None
            raise MayaBridgeError(
                f"无法连接 Maya（{self.host}:{self.port}）。Maya 是否已启动 MBB 服务器？"
            ) from e
        return self

    def close(self):
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None

    def __enter__(self):
        return self.connect()

    def __exit__(self, *args):
        self.close()

    @property
    def connected(self):
        return self._sock is not None

    # ── 低级通信 ──────────────────────────────────────────

    def _send(self, msg):
        """发送原始消息，返回响应字符串。"""
        if not self._sock:
            raise MayaBridgeError("未连接到 Maya，请先调用 connect()")
        self._sock.sendall((msg + '\n').encode('utf-8'))
        data = b''
        deadline = time.time() + self.DEFAULT_TIMEOUT
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            self._sock.settimeout(min(remaining, 2))
            try:
                chunk = self._sock.recv(8192)
                if not chunk:
                    break
                data += chunk
                if b'\n' in data:
                    break
            except socket.timeout:
                break
        return data.decode('utf-8', errors='replace').strip()

    def ping(self):
        return self._send('PING')

    # ── 核心：执行 Python 代码 ────────────────────────────

    def eval(self, code):
        """在 Maya 中执行 Python 代码，捕获 stdout 并返回。

        cmds 和 mel 模块已预置在执行命名空间，无需手动 import。
        多行代码用 ; 拼接为单行（MBB 协议按换行分帧）。
        """
        lines = [line.strip() for line in code.strip().split('\n') if line.strip()]
        compact = '; '.join(lines)
        response = self._send(f'EVAL {compact}')
        if response.startswith('EVAL_ERROR:'):
            raise MayaBridgeError(response)
        return response

    # ── 便捷方法 ──────────────────────────────────────────

    def select(self, objects):
        names = ', '.join(repr(o) for o in objects)
        self.eval(f"cmds.select([{names}])")

    def selection(self):
        out = self.eval("print(repr(cmds.ls(selection=True)))")
        return eval(out) if out else []

    def file_open(self, path, force=True):
        self.eval(f"cmds.file(r'{path}', open=True, force={force})")

    def file_save(self):
        self.eval("cmds.file(save=True)")

    def scene_name(self):
        return self.eval("print(cmds.file(query=True, sceneName=True) or '')")

    def detect_material_types(self):
        out = self.eval(
            f"import sys; sys.path.insert(0, r'{self.MBB_PATH}'); "
            f"import mbb_server; print(repr(mbb_server.detect_material_types()))"
        )
        return eval(out) if out else set()

    def export_usd(self, path, selected_only=True):
        return self.eval(
            f"import sys; sys.path.insert(0, r'{self.MBB_PATH}'); "
            f"import mbb_server; print(mbb_server.export_usd_from_maya("
            f"r'{path}', selected_only={selected_only}))"
        )

    def reload_mbb(self):
        self.eval(
            f"import sys, importlib; sys.path.insert(0, r'{self.MBB_PATH}'); "
            f"import mbb_server; importlib.reload(mbb_server); "
            f"mbb_server.stop_server(); mbb_server.start_server(); print('MBB reloaded')"
        )
        return 'MBB reloaded'

    # ── Maya 进程管理 ─────────────────────────────────────

    @classmethod
    def launch_maya(cls, scene_file=None, wait=25):
        """启动 Maya、加载场景、等待就绪并返回已连接的实例。"""
        mel_path = r'C:\temp\maya_startup.mel'
        py_startup = r'C:\temp\maya_startup.py'

        with open(py_startup, 'w', encoding='utf-8') as f:
            f.write(f'''
import maya.cmds as cmds
import sys
try:
    cmds.commandPort(name=":7002", close=True)
except:
    pass
cmds.commandPort(name=":7002", sourceType="python", echoOutput=True)
sys.path.insert(0, r'{cls.MBB_PATH}')
import mbb_server
import importlib
importlib.reload(mbb_server)
mbb_server.stop_server()
mbb_server.start_server()
print("[AUTO] Ready")
''')

        with open(mel_path, 'w', encoding='ascii') as f:
            f.write(f'python("exec(open(\'{py_startup.replace(chr(92), chr(47))}\').read())");\n')

        cmd = [cls.MAYA_EXE, '-script', mel_path]
        if scene_file:
            cmd.extend(['-file', scene_file])

        print(f'Launching: {" ".join(cmd)}')
        subprocess.Popen(cmd)
        print(f'Waiting {wait}s...')
        time.sleep(wait)

        m = cls()
        m.connect()
        return m

    @staticmethod
    def kill_maya():
        subprocess.run(['taskkill', '/F', '/IM', 'maya.exe'], capture_output=True)
        time.sleep(2)
