bl_info = {
    "name": "Maya Blender Bridge (MBB)",
    "author": "Edward Lim / HAOAH",
    "version": (2, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Maya Bridge",
    "description": "USD-based bridge: Blender <-> Maya via socket + USD + auto material reconstruction",
    "category": "Import-Export",
}

import bpy
import os
import json
import glob
import re
import time
from datetime import datetime
import socket
import traceback

# MBB 子模块
from . import usd_hook
from . import reference_dedup

HOST = '127.0.0.1'

# 取消标志：Cancel 按钮设为 True，Modal 在 modal() 入口检测到后中止
_cancel_flag = False

# 操作互斥锁：防止 Import 和 Export 同时运行
_operation_in_progress = False

# Principled BSDF socket → 色彩空间映射（贴图类型决定色彩空间）
NON_COLOR_SOCKETS = {
    'Roughness', 'Metallic', 'Normal', 'Alpha',
    'Coat Weight', 'Coat Roughness',
    'Specular Tint', 'Transmission Weight',
    'Bump',
}

class MBB_CONFIG(bpy.types.PropertyGroup):
    connection_port: bpy.props.IntProperty(
        name = "Port",
        description = "Insert port number. Preferably from 1024 - 65535. Note that some of the ports might not work if it is being occupied",
        default = 50008
    )


class MBB_ANIM_CONFIG(bpy.types.PropertyGroup):
    """动画导出设置，挂到 Scene 级，跟随场景保存。"""
    anim_mode: bpy.props.EnumProperty(
        name="Animation",
        description="动画导出模式",
        items=[
            ('NONE', 'None', '不导出动画，仅当前帧'),
            ('CACHE', 'Cache', '逐帧烘焙顶点位置，Blender 加 Mesh Sequence Cache'),
            ('SKELETAL', 'Skeletal', '导出骨骼+蒙皮+动画曲线，Blender 重建 Armature'),
        ],
        default='NONE',
    )
    frame_start: bpy.props.IntProperty(
        name="Start",
        description="动画起始帧（留空则使用 Maya 时间滑条范围）",
        default=0,
    )
    frame_end: bpy.props.IntProperty(
        name="End",
        description="动画结束帧（留空则使用 Maya 时间滑条范围）",
        default=0,
    )
    frame_step: bpy.props.IntProperty(
        name="Step",
        description="帧采样步长",
        default=1,
        min=1,
    )

# ------------------------------------------------------------------------
# Addon Preferences (for storing Maya paths)
# ------------------------------------------------------------------------
class MBB_ADDON_PREF(bpy.types.AddonPreferences):
    bl_idname = __name__

    temp_work_dir: bpy.props.StringProperty(
        name="Temp Work Dir",
        description="USD 临时文件及贴图的存放目录",
        subtype='DIR_PATH',
        default=r"C:\temp"
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Maya Bridge Settings")
        layout.prop(self, "temp_work_dir")


# ------------------------------------------------------------------------
# Operator
# ------------------------------------------------------------------------
class PORT_TEST_PROC(bpy.types.Operator):
    bl_idname = "proc.port_test"
    bl_label = "Test the connection to Maya with the specified port"

    def execute(self, context):
        try:
            data = send_to_maya(
                f"PING",
                context.scene.mbb_config.connection_port
            )

            # Log the response from Maya.
            self.report({'INFO'}, f"[MBB Client] Received: {data.decode('utf-8')}")

        except Exception as e:
            self.report({'ERROR'}, f"[MBB Client] Process failed: {e}")
        return {'FINISHED'}

class EXPORT_SELECTION_PROC(bpy.types.Operator):
    bl_idname = "proc.export_selection"
    bl_label = "Send selected meshes to Maya"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        global _cancel_flag, _operation_in_progress
        _cancel_flag = False

        if _operation_in_progress:
            self.report({'WARNING'}, "已有操作在进行中")
            return {'CANCELLED'}
        _operation_in_progress = True

        prefs = bpy.context.preferences.addons[__name__].preferences
        self._temp_work_dir = prefs.temp_work_dir
        self._port = context.scene.mbb_config.connection_port
        self._scene = context.scene

        self._selected_objects = list(context.selected_objects)
        if not self._selected_objects:
            self.report({'WARNING'}, "No objects selected for export.")
            _operation_in_progress = False
            return {'CANCELLED'}

        self._state = 'CLEANUP'
        self._socket = None
        self._timer = None
        self._error_msg = ''
        self._response_data = b''
        self._temp_usd_path = None

        try:
            wm = context.window_manager
            self._timer = wm.event_timer_add(0.05, window=context.window)
            wm.modal_handler_add(self)
        except Exception:
            _operation_in_progress = False
            raise

        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        global _cancel_flag

        if _cancel_flag:
            if self._state in ('WAIT_PROCESSING', 'WAIT_RESULT', 'SEND_MAYA_IMPORT'):
                self._state = 'NOTIFY_CANCEL'
            elif self._state in ('CLEANUP', 'USD_EXPORT'):
                self._state = 'CANCELLED'

        if self._state == 'CLEANUP':
            return self._do_cleanup(context)
        elif self._state == 'USD_EXPORT':
            return self._do_usd_export(context)
        elif self._state == 'SEND_MAYA_IMPORT':
            return self._do_send_maya_import(context)
        elif self._state == 'WAIT_PROCESSING':
            return self._do_wait_processing(context)
        elif self._state == 'WAIT_RESULT':
            return self._do_wait_result(context)
        elif self._state == 'FINISHED':
            return self._do_finished(context)
        elif self._state == 'CANCELLED':
            return self._do_cancelled(context)
        elif self._state == 'NOTIFY_CANCEL':
            return self._do_notify_cancel(context)
        elif self._state == 'ERROR':
            return self._do_error(context, self._error_msg)

        return {'RUNNING_MODAL'}

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer:
            try:
                wm.event_timer_remove(self._timer)
            except RuntimeError:
                pass
            self._timer = None
        if self._socket:
            try:
                self._socket.close()
            except OSError:
                pass
            self._socket = None
        global _operation_in_progress
        if _operation_in_progress:
            _operation_in_progress = False

    def _do_cleanup(self, context):
        _cleanup_temp(self._temp_work_dir)
        ts = int(datetime.now().timestamp() * 1000)
        self._temp_usd_path = os.path.join(self._temp_work_dir, f"{ts}.usdc")
        self._state = 'USD_EXPORT'
        return {'RUNNING_MODAL'}

    def _do_usd_export(self, context):
        try:
            bpy.ops.wm.usd_export(
                filepath=self._temp_usd_path,
                selected_objects_only=True,
                convert_scene_units='CENTIMETERS',
                export_materials=False,
                export_uvmaps=True,
                export_normals=True,
            )
        except Exception as e:
            self._error_msg = f"USD 导出失败: {e}"
            self._state = 'ERROR'
            return {'RUNNING_MODAL'}
        self._state = 'SEND_MAYA_IMPORT'
        return {'RUNNING_MODAL'}

    def _do_send_maya_import(self, context):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5.0)
            s.connect((HOST, self._port))
            s.sendall(f"IMPORT_USD {self._temp_usd_path}\n".encode('utf-8'))
            s.setblocking(False)
            self._socket = s
            self._state = 'WAIT_PROCESSING'
        except (socket.timeout, ConnectionRefusedError, OSError) as e:
            try:
                s.close()
            except OSError:
                pass
            self._error_msg = f"Maya 连接失败: {e}"
            self._state = 'ERROR'
        return {'RUNNING_MODAL'}

    def _do_wait_processing(self, context):
        try:
            chunk = self._socket.recv(256)
            if chunk:
                ack = chunk.decode('utf-8').strip()
                if ack == 'PROCESSING':
                    self._state = 'WAIT_RESULT'
                    self._response_data = b''
                else:
                    self._response_data = chunk
                    self._state = 'WAIT_RESULT'
        except BlockingIOError:
            pass
        return {'RUNNING_MODAL'}

    def _do_wait_result(self, context):
        try:
            chunk = self._socket.recv(8192)
            if chunk:
                self._response_data += chunk
                if b'\n' in self._response_data:
                    if self._socket:
                        try:
                            self._socket.close()
                        except OSError:
                            pass
                        self._socket = None
                    result = self._response_data.decode('utf-8').strip()
                    if result.startswith('EXPORT_FAILED') or result.startswith('Error:'):
                        self._error_msg = f"Maya 操作失败: {result}"
                        self._state = 'ERROR'
                    else:
                        print(f"[MBB] Maya: {result}")
                        self._state = 'FINISHED'
            else:
                self._error_msg = "Maya 连接已关闭"
                self._state = 'ERROR'
        except BlockingIOError:
            pass
        return {'RUNNING_MODAL'}

    def _do_finished(self, context):
        self._cleanup(context)
        self.report({'INFO'}, "[MBB] 导出完成")
        return {'FINISHED'}

    def _do_cancelled(self, context):
        if self._temp_usd_path and os.path.exists(self._temp_usd_path):
            try:
                os.remove(self._temp_usd_path)
            except OSError:
                pass
        self._cleanup(context)
        self.report({'WARNING'}, "[MBB] 操作已取消")
        return {'CANCELLED'}

    def _do_notify_cancel(self, context):
        if self._socket:
            try:
                self._socket.setblocking(True)
                self._socket.settimeout(1.0)
                self._socket.sendall(b'CANCEL\n')
                try:
                    self._socket.recv(256)
                except socket.timeout:
                    pass
            except OSError:
                pass
            finally:
                try:
                    self._socket.close()
                except OSError:
                    pass
                self._socket = None
        if self._temp_usd_path and os.path.exists(self._temp_usd_path):
            try:
                os.remove(self._temp_usd_path)
            except OSError:
                pass
        self._cleanup(context)
        self.report({'WARNING'}, "[MBB] 操作已取消")
        return {'CANCELLED'}

    def _do_error(self, context, msg):
        if self._socket:
            try:
                self._socket.close()
            except OSError:
                pass
            self._socket = None
        if self._temp_usd_path and os.path.exists(self._temp_usd_path):
            try:
                os.remove(self._temp_usd_path)
            except OSError:
                pass
        self._cleanup(context)
        self.report({'ERROR'}, f"[MBB] {msg}")
        return {'CANCELLED'}


class IMPORT_SELECTION_PROC(bpy.types.Operator):
    bl_idname = "proc.import_selection"
    bl_label = "Import selected Maya mesh to Blender"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        global _cancel_flag, _operation_in_progress
        _cancel_flag = False

        if _operation_in_progress:
            self.report({'WARNING'}, "已有操作在进行中")
            return {'CANCELLED'}
        _operation_in_progress = True

        prefs = bpy.context.preferences.addons[__name__].preferences
        self._port = context.scene.mbb_config.connection_port
        self._temp_work_dir = prefs.temp_work_dir
        self._scene = context.scene
        self._selected_objects = list(context.selected_objects)

        self._state = 'CLEANUP'
        self._socket = None
        self._timer = None
        self._cancel_after_done = False
        self._error_msg = ''
        self._response_data = b''
        self._temp_usd_path = None
        self._usd_path = ''
        self._json_path = ''

        # 预读动画配置（模态期间 context.scene 可能不可靠）
        anim = context.scene.mbb_anim_config
        self._anim_mode = anim.anim_mode
        self._anim_frame_start = anim.frame_start
        self._anim_frame_end = anim.frame_end
        self._anim_frame_step = anim.frame_step

        try:
            wm = context.window_manager
            self._timer = wm.event_timer_add(0.05, window=context.window)
            wm.modal_handler_add(self)
        except Exception:
            _operation_in_progress = False
            raise

        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        global _cancel_flag

        if _cancel_flag and not self._cancel_after_done:
            if self._state in ('WAIT_PROCESSING', 'WAIT_RESULT', 'SEND_MAYA_EXPORT'):
                self._state = 'NOTIFY_CANCEL'
            elif self._state in ('CLEANUP',):
                self._state = 'CANCELLED'
            elif self._state in ('USD_IMPORT', 'MATERIAL_RECONSTRUCT', 'ASSIGN_PRIM', 'REFERENCE_DEDUP'):
                self._cancel_after_done = True

        if self._cancel_after_done:
            if self._state in ('MATERIAL_RECONSTRUCT', 'ASSIGN_PRIM', 'REFERENCE_DEDUP'):
                self._state = 'CLEAN_AFTER_CANCEL'

        if self._state == 'CLEANUP':
            return self._do_cleanup(context)
        elif self._state == 'SEND_MAYA_EXPORT':
            return self._do_send_maya_export(context)
        elif self._state == 'WAIT_PROCESSING':
            return self._do_wait_processing(context)
        elif self._state == 'WAIT_RESULT':
            return self._do_wait_result(context)
        elif self._state == 'PARSE_RESPONSE':
            return self._do_parse_response(context)
        elif self._state == 'USD_IMPORT':
            return self._do_usd_import(context)
        elif self._state == 'MATERIAL_RECONSTRUCT':
            return self._do_material_reconstruct(context)
        elif self._state == 'ASSIGN_PRIM':
            return self._do_assign_prim(context)
        elif self._state == 'REFERENCE_DEDUP':
            return self._do_reference_dedup(context)
        elif self._state == 'FINISHED':
            return self._do_finished(context)
        elif self._state == 'CANCELLED':
            return self._do_cancelled(context)
        elif self._state == 'NOTIFY_CANCEL':
            return self._do_notify_cancel(context)
        elif self._state == 'CLEAN_AFTER_CANCEL':
            return self._do_clean_after_cancel(context)
        elif self._state == 'ERROR':
            return self._do_error(context, self._error_msg)

        return {'RUNNING_MODAL'}

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer:
            try:
                wm.event_timer_remove(self._timer)
            except RuntimeError:
                pass
            self._timer = None
        if self._socket:
            try:
                self._socket.close()
            except OSError:
                pass
            self._socket = None
        global _operation_in_progress
        if _operation_in_progress:
            _operation_in_progress = False

    def _do_cleanup(self, context):
        _cleanup_temp(self._temp_work_dir)
        ts = int(datetime.now().timestamp() * 1000)
        self._temp_usd_path = os.path.join(self._temp_work_dir, f"{ts}.usdc")
        self._state = 'SEND_MAYA_EXPORT'
        return {'RUNNING_MODAL'}

    def _do_send_maya_export(self, context):
        try:
            payload = _build_export_message_from_stored(
                self._temp_usd_path,
                self._anim_mode,
                self._anim_frame_start,
                self._anim_frame_end,
                self._anim_frame_step,
            )
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5.0)
            s.connect((HOST, self._port))
            s.sendall(f"EXPORT_SELECTED {payload}\n".encode('utf-8'))
            s.setblocking(False)
            self._socket = s
            self._state = 'WAIT_PROCESSING'
        except (socket.timeout, ConnectionRefusedError, OSError) as e:
            try:
                s.close()
            except OSError:
                pass
            self._error_msg = f"Maya 连接失败: {e}"
            self._state = 'ERROR'
        return {'RUNNING_MODAL'}

    def _do_wait_processing(self, context):
        try:
            chunk = self._socket.recv(256)
            if chunk:
                ack = chunk.decode('utf-8').strip()
                if ack == 'PROCESSING':
                    self._state = 'WAIT_RESULT'
                    self._response_data = b''
                else:
                    self._response_data = chunk
                    self._state = 'WAIT_RESULT'
        except BlockingIOError:
            pass
        return {'RUNNING_MODAL'}

    def _do_wait_result(self, context):
        try:
            chunk = self._socket.recv(8192)
            if chunk:
                self._response_data += chunk
                if b'\n' in self._response_data:
                    if self._socket:
                        try:
                            self._socket.close()
                        except OSError:
                            pass
                        self._socket = None
                    self._state = 'PARSE_RESPONSE'
            else:
                self._error_msg = "Maya 连接已关闭"
                self._state = 'ERROR'
        except BlockingIOError:
            pass
        return {'RUNNING_MODAL'}

    def _do_parse_response(self, context):
        try:
            response = self._response_data.decode('utf-8')
            usd_path, json_path, _ = parse_response(response)
            self._usd_path = usd_path
            self._json_path = json_path
            print(f"[MBB-DBG] _do_parse_response: usd={usd_path}, json={json_path}")
            if not usd_path:
                self._error_msg = f"Maya 返回异常: {response}"
                self._state = 'ERROR'
            else:
                print(f"[MBB] Maya: {response}")
                self._state = 'USD_IMPORT'
        except Exception as e:
            self._error_msg = f"解析 Maya 响应失败: {e}"
            self._state = 'ERROR'
        return {'RUNNING_MODAL'}

    def _do_usd_import(self, context):
        try:
            print(f"[MBB-DBG] _do_usd_import: 开始 (usd={self._usd_path})")
            # 记录导入前场景中已有的 MESH 物体
            before_meshes = set(o.name for o in bpy.context.scene.objects if o.type == 'MESH')
            # 统一：始终导入材质（所有材质类型走 shd='useRegistry' + convertMaterialsTo）
            bpy.ops.wm.usd_import(
                filepath=self._usd_path,
                import_materials=True,
                import_usd_preview=True,
                import_all_materials=True,
                apply_unit_conversion_scale=True,
            )
            after_meshes = set(o.name for o in bpy.context.scene.objects if o.type == 'MESH')
            new_meshes = after_meshes - before_meshes
            print(f"[MBB-DBG] _do_usd_import: 完成, 新增 {len(new_meshes)} 个 MESH: {list(new_meshes)}")

            # 从 USD 文件传播 source 标记（替代有缺陷的 USDHook.on_import）
            reference_dedup._propagate_source_for_new_objects(
                self._usd_path, new_meshes
            )
            # 打印每个 MESH 的材质槽数
            for name in new_meshes:
                obj = bpy.data.objects.get(name)
                if obj:
                    slots = [m.name for m in obj.data.materials if m]
                    print(f"[MBB-DBG]   {name}: {len(slots)} 槽 → {slots}")
        except Exception as e:
            self._error_msg = f"USD 导入失败: {e}"
            self._state = 'ERROR'
            return {'RUNNING_MODAL'}

        if self._cancel_after_done:
            self._state = 'CLEAN_AFTER_CANCEL'
        else:
            self._state = 'MATERIAL_RECONSTRUCT'
        return {'RUNNING_MODAL'}

    def _do_material_reconstruct(self, context):
        if self._cancel_after_done:
            print(f"[MBB-DBG] _do_material_reconstruct: 已取消，跳过")
            self._state = 'CLEAN_AFTER_CANCEL'
            return {'RUNNING_MODAL'}

        # 有 JSON → Arnold 高保真重建（覆盖 USD 导入的低质量版本）
        if self._json_path and os.path.exists(self._json_path):
            print(f"[MBB-DBG] _do_material_reconstruct: 开始 (json={self._json_path})")
            try:
                reconstruct_materials(self._json_path)
            except Exception as e:
                print(f"[MBB] 材质重建失败: {e}")
                traceback.print_exc()
                self._error_msg = f"材质重建失败: {e}"
                self._state = 'ERROR'
                return {'RUNNING_MODAL'}
            print(f"[MBB-DBG] _do_material_reconstruct: 完成")

        if self._cancel_after_done:
            self._state = 'CLEAN_AFTER_CANCEL'
        else:
            self._state = 'ASSIGN_PRIM'
        return {'RUNNING_MODAL'}

    def _do_assign_prim(self, context):
        if self._cancel_after_done:
            print(f"[MBB-DBG] _do_assign_prim: 已取消，跳过")
            self._state = 'CLEAN_AFTER_CANCEL'
            return {'RUNNING_MODAL'}

        print(f"[MBB-DBG] _do_assign_prim: 开始 (usd={self._usd_path})")
        try:
            _assign_by_prim_metadata(self._usd_path, scene=self._scene)
        except Exception as e:
            print(f"[MBB] prim标记分配失败: {e}")
            traceback.print_exc()

        print(f"[MBB-DBG] _do_assign_prim: 完成")
        self._state = 'REFERENCE_DEDUP'
        return {'RUNNING_MODAL'}

    def _do_reference_dedup(self, context):
        if self._cancel_after_done:
            print(f"[MBB-DBG] _do_reference_dedup: 已取消，跳过")
            self._state = 'CLEAN_AFTER_CANCEL'
            return {'RUNNING_MODAL'}

        print(f"[MBB-DBG] _do_reference_dedup: 开始")
        try:
            result = reference_dedup.deduplicate_mesh_and_material_datablocks()
            print(f"[MBB-DBG] _do_reference_dedup: 完成, "
                  f"mat_merged={result['mat_merged']}, "
                  f"mesh_merged={result['mesh_merged']}")
        except Exception as e:
            print(f"[MBB] 引用去重失败: {e}")
            traceback.print_exc()

        if self._cancel_after_done:
            self._state = 'CLEAN_AFTER_CANCEL'
        else:
            self._state = 'FINISHED'
        return {'RUNNING_MODAL'}

    def _do_finished(self, context):
        self._cancel_after_done = False  # 状态重置
        self._cleanup(context)
        self.report({'INFO'}, "[MBB] 导入完成")
        return {'FINISHED'}

    def _do_cancelled(self, context):
        self._cleanup(context)
        self.report({'WARNING'}, "[MBB] 操作已取消")
        return {'CANCELLED'}

    def _do_notify_cancel(self, context):
        if self._socket:
            try:
                self._socket.setblocking(True)
                self._socket.settimeout(1.0)
                self._socket.sendall(b'CANCEL\n')
                try:
                    self._socket.recv(256)
                except socket.timeout:
                    pass
            except OSError:
                pass
            finally:
                try:
                    self._socket.close()
                except OSError:
                    pass
                self._socket = None
        if self._temp_usd_path and os.path.exists(self._temp_usd_path):
            try:
                os.remove(self._temp_usd_path)
            except OSError:
                pass
        self._cleanup(context)
        self.report({'WARNING'}, "[MBB] 操作已取消")
        return {'CANCELLED'}

    def _do_clean_after_cancel(self, context):
        if self._socket:
            try:
                self._socket.close()
            except OSError:
                pass
            self._socket = None
        if self._temp_usd_path and os.path.exists(self._temp_usd_path):
            try:
                os.remove(self._temp_usd_path)
            except OSError:
                pass
        self._cleanup(context)
        # 根据场景给出准确的取消提示
        if self._json_path:
            self.report({'WARNING'}, "[MBB] 操作已取消，几何体与基础材质已导入但 Arnold 高保真版本未重建。可用 Ctrl+Z 撤销")
        else:
            self.report({'WARNING'}, "[MBB] 操作已取消，几何体与材质已导入。可用 Ctrl+Z 撤销")
        return {'FINISHED'}

    def _do_error(self, context, msg):
        if self._socket:
            try:
                self._socket.close()
            except OSError:
                pass
            self._socket = None
        if self._temp_usd_path and os.path.exists(self._temp_usd_path):
            try:
                os.remove(self._temp_usd_path)
            except OSError:
                pass
        self._cleanup(context)
        self.report({'ERROR'}, f"[MBB] {msg}")
        return {'CANCELLED'}


class CANCEL_PROC(bpy.types.Operator):
    bl_idname = "proc.cancel"
    bl_label = "Cancel current operation"
    bl_description = "取消当前正在进行的导入/导出操作"

    def execute(self, context):
        global _cancel_flag
        _cancel_flag = True
        self.report({'INFO'}, "[MBB] 已发送取消信号")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Creates a Panel in the N tool sidebar.
# ------------------------------------------------------------------------
class MAYA_BRIDGE_PANEL(bpy.types.Panel):
    bl_label = "Maya Bridge"
    bl_idname = "MAYA_BRIDGE_PANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Maya Bridge"

    def draw(self, context):
        layout = self.layout

        layout.prop(context.scene.mbb_config, "connection_port")
        layout.operator("proc.port_test", text="Port Test", icon='ARROW_LEFTRIGHT')
        layout.separator()

        # ── Animation Settings（仅 Import 时生效）──
        anim = context.scene.mbb_anim_config
        anim_box = layout.box()
        col = anim_box.column(align=True)
        col.prop(anim, "anim_mode")

        is_anim = anim.anim_mode != 'NONE'
        sub = col.column(align=True)
        sub.enabled = is_anim
        sub.prop(anim, "frame_start")
        sub.prop(anim, "frame_end")
        sub.prop(anim, "frame_step")
        if is_anim and anim.frame_start <= 0 and anim.frame_end <= 0:
            sub.label(text="（留空时将使用 Maya 时间滑条范围）", icon='INFO')
        if is_anim and anim.frame_start > 0 and anim.frame_end > 0:
            count = abs(anim.frame_end - anim.frame_start) // anim.frame_step + 1
            sub.label(text=f"  预计 {count} 帧", icon='TIME')
        if is_anim and anim.frame_start > anim.frame_end:
            sub.label(text="⚠ 起始帧大于结束帧", icon='ERROR')

        layout.separator()
        layout.operator("proc.export_selection", text="Export Selection", icon='EXPORT')
        layout.operator("proc.import_selection", text="Import Selection", icon='IMPORT')
        layout.separator()
        layout.operator("proc.cancel", text="Cancel", icon='CANCEL')


# ------------------------------------------------------------------------
# Utility functions
# ------------------------------------------------------------------------
def _build_export_message_from_stored(temp_path, anim_mode, frame_start, frame_end, frame_step):
    """构建 EXPORT_SELECTED 命令的载荷（使用预存值，供 Modal Operator 调用）。

    anim_mode == 'NONE' → 返回纯路径（旧协议，兼容旧版 Maya MBB）
    anim_mode != 'NONE' → 返回 JSON 字符串（新协议，需新版 Maya）
    """
    if anim_mode == 'NONE':
        return temp_path

    cfg = {
        "path": temp_path,
        "anim_config": {
            "mode": anim_mode,
        },
    }
    if frame_start > 0:
        cfg["anim_config"]["frame_start"] = frame_start
    if frame_end > 0:
        cfg["anim_config"]["frame_end"] = frame_end
    if frame_step > 1:
        cfg["anim_config"]["frame_step"] = frame_step
    return json.dumps(cfg)


def _build_export_message(temp_path, context):
    """构建 EXPORT_SELECTED 命令的载荷（从 context 读取，供直接调用使用）。

    注意：Modal Operator 内应使用 _build_export_message_from_stored,
    因为 context.scene 在模态期间可能不可靠。
    """
    anim = context.scene.mbb_anim_config
    return _build_export_message_from_stored(
        temp_path,
        anim.anim_mode,
        anim.frame_start,
        anim.frame_end,
        anim.frame_step,
    )


def parse_response(data):
    """解析 Maya 返回字符串。

    格式:
        EXPORT_SUCCESS_USD_MAT:/path/file.usdc|LOG:msg
        EXPORT_SUCCESS:/path/file.usdc|/path/file_meta.json|LOG:msg
        EXPORT_SUCCESS:/path/file.usdc

    返回: (usd_path, json_path_or_None, use_usd_materials)
      use_usd_materials=True  → USD 文件自带材质，Blender 导入时直接用
      use_usd_materials=False → 走 JSON 重建流程（Arnold → Principled BSDF）
    """
    msg = data.strip()

    # 新格式：USD 内置材质（UsdPreviewSurface）
    if msg.startswith('EXPORT_SUCCESS_USD_MAT:'):
        parts = msg[len('EXPORT_SUCCESS_USD_MAT:'):].split('|')
        usd_path = parts[0].strip()
        for part in parts:
            if part.startswith('LOG:'):
                for log_msg in part[4:].split(';'):
                    print(f"[Maya] {log_msg}")
        return usd_path, None, True

    # 旧格式：JSON 重建（aiStandardSurface）
    if msg.startswith('EXPORT_SUCCESS:'):
        parts = msg[len('EXPORT_SUCCESS:'):].split('|')
        usd_path = parts[0].strip()
        json_path = parts[1].strip() if len(parts) > 1 and not parts[1].startswith('LOG:') else None
        for part in parts:
            if part.startswith('LOG:'):
                for log_msg in part[4:].split(';'):
                    print(f"[Maya] {log_msg}")
        return usd_path, json_path, False

    if msg.startswith('EXPORT_FAILED:'):
        raise RuntimeError(f"Maya export failed: {msg}")

    return None, None, False


# ---------------------------------------------------------------------------
# UDIM 检测（与 Maya 端 mbb_server.py 保持一致）
# ---------------------------------------------------------------------------

# 贴图路径中的 UDIM token 模式：匹配 <UDIM> 或 <UVTILE>
_UDIM_TOKEN_PATTERN = re.compile(r'<(UDIM|UVTILE)>', re.IGNORECASE)

# UDIM 瓦片号模式：匹配 .1001.png 或 _1001.png 格式（仅 1xxx 系列）
# tiff 在 tif 前面，避免 tif 先匹配导致 .tiff 后缀的文件被截断
_UDIM_TILE_PATTERN = re.compile(
    r'[._](1\d{3})\.(png|jpg|jpeg|tga|exr|tiff|tif|hdr|bmp)(?:[.][^.]+)?$',
    re.IGNORECASE
)

# UDIM 编号范围：1001~1999（10×10 网格）
_UDIM_TILE_MIN = 1001
_UDIM_TILE_MAX = 1999

# UVTILE 文件名格式：u1_v1, u2_v3 等
_UVTILE_FILE_PATTERN = re.compile(r'[._]u(\d+)_v(\d+)\.', re.IGNORECASE)


def _uvtile_to_udim_number(u_str, v_str):
    """将 UVTILE 坐标映射为 UDIM tile number。

    UVTILE 格式: u(u_tile+1)_v(v_tile+1)，从 1 开始
    UDIM 编号:   1001 + u_tile + v_tile * 10
    例如 u1_v2 → u_tile=0, v_tile=1 → tile number=1011
    """
    u = int(u_str) - 1
    v = int(v_str) - 1
    tile_num = 1001 + u + v * 10
    if tile_num < _UDIM_TILE_MIN or tile_num > _UDIM_TILE_MAX:
        return -1  # 超出 UDIM 范围
    return tile_num


def detect_udim_tiles(filepath):
    """检测给定路径是否为 UDIM 纹理瓦片族的一部分。

    支持三种检测模式：
    1. 路径中含 <UDIM> token → 按 token 模板 glob 扫描目录
    2. 路径中含 <UVTILE> token → 同上，文件名从 u1_v1 格式映射到 UDIM tile number
    3. 路径中显式含 4 位瓦片号（≥1001）→ 检查同目录是否存在同族瓦片

    返回 dict:
      - is_udim: bool
      - tiles: {tile_number: absolute_path}  仅 is_udim=True 时有值
    """
    directory = os.path.dirname(filepath)
    basename = os.path.basename(filepath)

    # Step 1: 检查 <UDIM> / <UVTILE> token
    token_match = _UDIM_TOKEN_PATTERN.search(filepath)
    if token_match:
        token_type = token_match.group(1).upper()
        # 将 token 替换为 * 做 glob
        pattern = _UDIM_TOKEN_PATTERN.sub('*', filepath)
        tiles = {}
        for match_path in glob.glob(pattern):
            fname = os.path.basename(match_path)
            if token_type == 'UDIM':
                m = re.search(r'[._](\d{4})\.', fname)
                if m:
                    tile_num = int(m.group(1))
                    if _UDIM_TILE_MIN <= tile_num <= _UDIM_TILE_MAX:
                        tiles[tile_num] = match_path
            else:  # UVTILE
                m = _UVTILE_FILE_PATTERN.search(fname)
                if m:
                    tile_num = _uvtile_to_udim_number(m.group(1), m.group(2))
                    if tile_num > 0:  # -1 表示超出范围
                        tiles[tile_num] = match_path
        if len(tiles) > 1:
            return {"is_udim": True, "tiles": tiles}
        else:
            return {"is_udim": False, "tiles": {}}

    # Step 2: 检查显式瓦片号（文件名含 ≥1001 的 4 位数字）
    tile_match = _UDIM_TILE_PATTERN.search(basename)
    if tile_match:
        tile_number = int(tile_match.group(1))
        if tile_number < _UDIM_TILE_MIN or tile_number > _UDIM_TILE_MAX:
            return {"is_udim": False, "tiles": {}}

        # 检查同目录是否有同族瓦片
        prefix = basename[:tile_match.start(1)]
        suffix = basename[tile_match.end(1):]
        glob_pattern = os.path.join(directory, f"{prefix}*{suffix}")
        tiles = {}
        for match_path in glob.glob(glob_pattern):
            m = _UDIM_TILE_PATTERN.search(os.path.basename(match_path))
            if m:
                num = int(m.group(1))
                if _UDIM_TILE_MIN <= num <= _UDIM_TILE_MAX:
                    tiles[num] = match_path

        if len(tiles) > 1:
            return {"is_udim": True, "tiles": tiles}

    # Step 3: 不是 UDIM
    return {"is_udim": False, "tiles": {}}


def load_image_as_udim(tiles_dict, colorspace_name):
    """以 UDIM 模式加载一组瓦片贴图。

    用 bpy.ops.image.open(use_udim_detecting=True) 自动检测并创建 TILED Image，
    然后设置正确的色彩空间。

    tiles_dict: {1001: "C:/tex/body_diff.1001.png", 1002: "..."}
    colorspace_name: 'sRGB' 或 'Non-Color'
    返回: bpy.types.Image 或 None（加载失败时）
    """
    first_tile_num = min(tiles_dict.keys())
    first_tile_path = tiles_dict[first_tile_num]
    directory = os.path.dirname(first_tile_path)
    filename = os.path.basename(first_tile_path)

    # 记录加载前的 image 名列表和 TILED Image 瓦片数
    before = set(bpy.data.images.keys())
    before_tile_counts = {}
    for i in bpy.data.images:
        if i.source == 'TILED':
            before_tile_counts[i.name] = len(i.tiles)

    try:
        bpy.ops.image.open(
            filepath=first_tile_path,
            directory=directory,
            files=[{"name": filename}],
            use_udim_detecting=True,
            relative_path=False,
        )
    except RuntimeError as e:
        print(f"[MBB] UDIM 贴图加载失败: {e}")
        return None

    # 策略 1：在新建的 Image 中找 TILED 的
    after = set(bpy.data.images.keys())
    new_names = after - before
    img = None
    for name in new_names:
        candidate = bpy.data.images.get(name)
        if candidate and candidate.source == 'TILED':
            img = candidate
            break

    # 策略 2：已存在的 TILED Image 中，找到瓦片数量增加的
    if img is None:
        for i in bpy.data.images:
            if i.source != 'TILED':
                continue
            prev_count = before_tile_counts.get(i.name, 0)
            if len(i.tiles) > prev_count:
                img = i
                break

    # 策略 3：最后的 fallback — 按 UDIM 文件路径模式匹配
    # 保留原始文件名中的分隔符（_ 或 .），只把瓦片号替换为 <UDIM>
    if img is None:
        expected_udim = re.sub(r'([._])\d{4}(\.)', r'\1<UDIM>\2', filename)
        for i in bpy.data.images:
            if i.source == 'TILED' and expected_udim in i.filepath:
                img = i
                break

    if img is None:
        print(f"[MBB] UDIM 贴图加载失败，未找到 TILED Image: {first_tile_path}")
        return None

    img.colorspace_settings.name = colorspace_name
    print(f"[MBB] UDIM 贴图已加载: {img.name}（{len(img.tiles)} 个瓦片）")
    return img


def reconstruct_materials(json_path):
    """读取材质元数据 JSON，在 Blender 中创建 Principled BSDF 材质树。

    贴图自动设正确的色彩空间（sRGB vs Non-Color），
    法线贴图自动插入 Normal Map 节点。
    UDIM 贴图自动检测并设为 TILED 模式。
    """
    with open(json_path, 'r', encoding='utf-8') as f:
        metadata = json.load(f)

    json_dir = os.path.dirname(json_path)

    print(f"[MBB-DBG] reconstruct_materials: 开始处理 {len(metadata)} 个材质")

    for idx, (mat_name, socket_data) in enumerate(metadata.items()):
        # 跳过空材质或标记为复杂的材质
        if not socket_data:
            print(f"[MBB-DBG] reconstruct_materials [{idx}/{len(metadata)}]: {mat_name} (跳过-无数据)")
            continue

        # 创建或获取材质（支持冒号/下划线双向变体查找，兼容历史 JSON 和旧版 USD 导入）
        mat = bpy.data.materials.get(mat_name)
        lookup_path = f"精确: {'✓' if mat else '✗'}"
        if mat is None:
            alt1 = mat_name.replace('_', ':')
            mat = bpy.data.materials.get(alt1)
            lookup_path += f" → 下划线换冒号({alt1}): {'✓' if mat else '✗'}"
        if mat is None:
            alt2 = mat_name.replace(':', '_')
            mat = bpy.data.materials.get(alt2)
            lookup_path += f" → 冒号换下划线({alt2}): {'✓' if mat else '✗'}"
        if mat is None:
            mat = bpy.data.materials.new(name=mat_name)
            lookup_path += " → 新建材料"
        else:
            lookup_path += " → 匹配到已有材料"
        print(f"[MBB-DBG] reconstruct_materials [{idx}/{len(metadata)}]: {mat_name} | {lookup_path}")

        # 检查是否有贴图数据需要重建（跳过只有默认值的材质，保留 USD 导入结果）
        has_textures = any(
            isinstance(v, dict) and 'texture' in v
            for k, v in socket_data.items()
            if not k.startswith('_')
        )
        if not has_textures:
            # 保留 USD 导入的节点树，不重建。兜底确保 use_nodes 开启
            mat.use_nodes = True
            target_objects = socket_data.get('_objects', [])
            face_map = socket_data.get('_face_map', {})
            assign_material_to_objects(mat, target_objects, face_map)
            print(f"[MBB] 材质保留（无贴图数据）: {mat_name} → {target_objects}")
            continue

        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links

        # 清空并重建
        nodes.clear()

        # 核心节点
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (0, 0)

        output_node = nodes.new('ShaderNodeOutputMaterial')
        output_node.location = (300, 0)
        links.new(bsdf.outputs['BSDF'], output_node.inputs['Surface'])

        # 逐槽位处理
        tex_index = 0
        for socket_name, socket_info in socket_data.items():
            if socket_name.startswith('_'):
                continue

            if 'texture' not in socket_info:
                # 默认值
                if socket_name in bsdf.inputs:
                    if 'value' in socket_info:
                        try:
                            bsdf.inputs[socket_name].default_value = socket_info['value']
                        except Exception as e:
                            print(f"[MBB] ⚠ {mat_name}.{socket_name} 赋值失败: {e}")
                    elif 'color' in socket_info:
                        color = list(socket_info['color'])
                        if len(color) == 3:
                            color.append(1.0)
                        try:
                            bsdf.inputs[socket_name].default_value = color
                        except Exception as e:
                            print(f"[MBB] ⚠ {mat_name}.{socket_name} 赋值失败: {e}")
                continue

            # === 贴图连接 ===
            tex_rel = socket_info['texture']
            tex_abs = tex_rel if os.path.isabs(tex_rel) else os.path.normpath(
                os.path.join(json_dir, tex_rel))

            if not os.path.exists(tex_abs):
                print(f"[MBB] 贴图不存在: {tex_abs}")
                continue

            tex_node = nodes.new('ShaderNodeTexImage')
            tex_node.location = (-400, -tex_index * 250)

            # 色彩空间
            is_data_socket = socket_name in NON_COLOR_SOCKETS
            colorspace_name = 'Non-Color' if is_data_socket else 'sRGB'

            # UDIM 检测
            udim_info = detect_udim_tiles(tex_abs)
            if udim_info["is_udim"]:
                img = load_image_as_udim(udim_info["tiles"], colorspace_name)
                if img is None:
                    print(f"[MBB] UDIM 贴图加载失败，跳过: {tex_abs}")
                    nodes.remove(tex_node)
                    continue
            else:
                img = bpy.data.images.load(tex_abs)
                img.colorspace_settings.name = colorspace_name

            tex_node.image = img

            # 决定是否连线
            should_connect = socket_info.get('connect', True)
            if not should_connect:
                tex_node.label = f"[ref] {img.name}"
                tex_index += 1
                continue

            # 连接到 BSDF socket
            if socket_name == 'Normal':
                # 法线贴图：插入 Normal Map 节点
                normal_node = nodes.new('ShaderNodeNormalMap')
                normal_node.location = (-200, -tex_index * 250)
                links.new(tex_node.outputs['Color'], normal_node.inputs['Color'])
                links.new(normal_node.outputs['Normal'], bsdf.inputs['Normal'])
            elif socket_name == 'Bump':
                # 高度图：插入 Bump 节点（非 Normal Map）
                bump_node = nodes.new('ShaderNodeBump')
                bump_node.location = (-200, -tex_index * 250)
                links.new(tex_node.outputs['Color'], bump_node.inputs['Height'])
                links.new(bump_node.outputs['Normal'], bsdf.inputs['Normal'])
            elif socket_name in bsdf.inputs:
                links.new(tex_node.outputs['Color'], bsdf.inputs[socket_name])

            tex_index += 1

        # 分配材质到导入的物体（按名称匹配，支持面级）
        target_objects = socket_data.get('_objects', [])
        face_map = socket_data.get('_face_map', {})
        assign_material_to_objects(mat, target_objects, face_map)
        print(f"[MBB] 材质已重建: {mat_name} → {target_objects}")


def _assign_mat(obj, material, face_indices=None):
    """将材质赋给物体。

    face_indices=None → 整个物体
    face_indices=[]   → 整个物体
    face_indices=[0,1,5] → 只赋到指定面
    """
    face_count = len(face_indices) if face_indices else 0
    print(f"[MBB-DBG] _assign_mat 入: obj={obj.name}, mat={material.name}, faces={face_count}")

    # 清理重复的材质槽（同名材质只保留第一个，防止重复导入时累积）
    # 同时将指向被删槽的面重定向到保留的槽
    seen = {}  # {material_name: first_slot_index}
    dup_indices = []
    for i, m in enumerate(obj.data.materials):
        if m and m.name in seen:
            # 重复槽：把指向此槽的面重定向到第一个同名的槽
            dup_indices.append(i)
            keep_idx = seen[m.name]
            redirected = 0
            for poly in obj.data.polygons:
                if poly.material_index == i:
                    poly.material_index = keep_idx
                    redirected += 1
            print(f"[MBB-DBG]   _assign_mat 去重: Slot {i}={m.name} → Slot {keep_idx} (重定向 {redirected} 面)")
        elif m:
            seen[m.name] = i
    # 从后往前移除重复槽，避免索引漂移
    for i in reversed(dup_indices):
        print(f"[MBB-DBG]   _assign_mat 移除重复槽: Slot {i}")
        obj.data.materials.pop(index=i)

    # 确保材质在 slot 中
    slot_count_before = len(obj.data.materials)
    existing_names = [m.name for m in obj.data.materials if m]
    if material.name not in existing_names:
        print(f"[MBB-DBG]   _assign_mat 追加材质到槽 (当前 {slot_count_before} 槽，槽名列表: {existing_names})")
        obj.data.materials.append(material)
        slot_count_after = len(obj.data.materials)
        if slot_count_after <= slot_count_before:
            print(f"[MBB-DBG]   ⚠ _assign_mat append 未生效！前={slot_count_before} 后={slot_count_after}")
            return
    else:
        print(f"[MBB-DBG]   _assign_mat 材质已存在槽中，跳过追加")

    try:
        slot = list(obj.data.materials).index(material)
    except ValueError:
        print(f"[MBB-DBG]   ❌ _assign_mat .index() 失败！材质 {material.name} 不在 {[m.name for m in obj.data.materials]}")
        return
    print(f"[MBB-DBG]   _assign_mat 材质在 Slot {slot} (总槽数={len(obj.data.materials)})")

    if not face_indices:
        # 整个物体：所有面指向同一个 slot
        for poly in obj.data.polygons:
            poly.material_index = slot
        print(f"[MBB-DBG]   _assign_mat 已赋所有面 → Slot {slot}")
    else:
        # 只赋到指定面
        assigned = 0
        skipped = 0
        for fi in face_indices:
            if fi < len(obj.data.polygons):
                obj.data.polygons[fi].material_index = slot
                assigned += 1
            else:
                skipped += 1
        print(f"[MBB-DBG]   _assign_mat 已赋 {assigned} 面 → Slot {slot}" + (f" (跳过 {skipped} 越界面)" if skipped else ""))


def _object_to_path(obj):
    """构造 Blender 物体的层级路径，匹配 USD prim 路径格式。"""
    parts = [obj.name]
    parent = obj.parent
    while parent:
        parts.append(parent.name)
        parent = parent.parent
    return '/' + '/'.join(reversed(parts))


def assign_material_to_objects(material, target_names=None, face_map=None):
    """将材质分配给场景中的物体，支持面级分配。

    face_map: {obj_name: [face_indices, ...]}
      空列表 = 整个物体，非空列表 = 只赋到指定面
    """
    matched = 0
    mat_name = material.name if material else 'None'
    print(f"[MBB-DBG] assign_material_to_objects 入: mat={mat_name}, targets={target_names}, face_map_keys={list(face_map.keys()) if face_map else 'None'}")

    # 场景诊断
    scene_meshes = [o.name for o in bpy.context.scene.objects if o.type == 'MESH']
    print(f"[MBB-DBG] assign_material_to_objects: 当前场景有 {len(scene_meshes)} 个 MESH 物体: {scene_meshes}")

    if target_names:
        for obj in bpy.context.scene.objects:
            # 实例可能是 EMPTY 类型（非 MESH）
            is_empty_inst = (obj.type == 'EMPTY' and
                             obj.instance_type == 'COLLECTION' and
                             obj.instance_collection)
            if obj.type != 'MESH' and not is_empty_inst:
                continue

            match_name = obj.name
            obj_path = _object_to_path(obj)
            for tname in target_names:
                # 用层级路径精确匹配（prim 路径 = Maya 长名转 USD 格式）
                # 叶子名比较时剥掉 Blender 添加的 .NNN 后缀
                leaf = re.sub(r'\.\d{3,}$', '', match_name)
                if obj_path == tname or leaf == tname.split('/')[-1]:
                    match_type = "路径" if obj_path == tname else "叶子"
                    print(f"[MBB-DBG] assign_material_to_objects: ✓ {match_type}匹配 obj={obj.name} ({obj_path})")
                    if is_empty_inst:
                        src_objs = [o for o in obj.instance_collection.all_objects
                                    if o.type == 'MESH']
                        if src_objs:
                            faces = _get_faces(face_map, obj.name)
                            _assign_mat(src_objs[0], material, faces)
                            matched += 1
                            break
                    else:
                        faces = _get_faces(face_map, obj.name)
                        _assign_mat(obj, material, faces)
                        matched += 1
                        break

    # 回退: 用 proto 源网格名匹配（__→_ 转换），处理无实例的导入
    if matched == 0 and target_names:
        print(f"[MBB-DBG] assign_material_to_objects: 主路径未匹配，进入 proto 回退")
        for coll in bpy.data.collections:
            if 'proto' not in coll.name.lower():
                continue
            for obj in coll.all_objects:
                if obj.type != 'MESH':
                    continue
                # proto 名: vczndjqja__Var1__LOD0Shape → vczndjqja_Var1_LOD0
                proto_clean = re.sub(r'Shape$', '', obj.name).replace('__', '_')
                found = False
                for tname in target_names:
                    if proto_clean == tname.split('/')[-1]:
                        _assign_mat(obj, material)
                        matched += 1
                        found = True
                        break
                if found:
                    break

    # 所有匹配路径均失败：仅警告，不自行为材质选择目标物体
    if matched == 0 and target_names:
        print(f"[MBB] ⚠ 面级分配未匹配: mat={mat_name}, targets={target_names}，材质未写入任何物体")

    print(f"[MBB-DBG] assign_material_to_objects 出: matched={matched}")
    
    # 验证：检查 target_names 中的物体是否真的拿到了这个材质
    if matched > 0 and target_names:
        for obj in bpy.context.scene.objects:
            if obj.type != 'MESH':
                continue
            obj_path = _object_to_path(obj)
            for tname in target_names:
                if obj_path == tname or obj.name == tname.split('/')[-1]:
                    in_slots = material in list(obj.data.materials)
                    print(f"[MBB-DBG] assign_material_to_objects 验证: obj={obj.name} 槽含 {material.name}: {in_slots} (共 {len(list(obj.data.materials))} 槽)")
                    break


def _get_faces(face_map, obj_name):
    """从 face_map 获取物体对应的面索引。键是 Maya 短名或 prim 路径。

    支持冒号/下划线变体匹配，兼容历史 JSON（旧版 face_map key 含冒号）。
    支持剥除 Blender 导入重名时添加的 .NNN 后缀。
    """
    if not face_map:
        return None
    # 剥掉 Blender 重名后缀（如 ren.001 → ren）
    obj_name_stripped = re.sub(r'\.\d{3,}$', '', obj_name)
    for key, faces in face_map.items():
        # 精确匹配 / 路径末段匹配
        if obj_name_stripped == key or key.split('/')[-1] == obj_name_stripped:
            return faces if faces else None
        # 变体：冒号 → 下划线（兼容历史 JSON）
        alt_key = key.replace(':', '_')
        if obj_name_stripped == alt_key or alt_key.split('/')[-1] == obj_name_stripped:
            return faces if faces else None
    return None


# ------------------------------------------------------------------------
# Registration
# ------------------------------------------------------------------------
classes = (
    MBB_CONFIG,
    MBB_ANIM_CONFIG,
    MBB_ADDON_PREF,
    PORT_TEST_PROC,
    EXPORT_SELECTION_PROC,
    IMPORT_SELECTION_PROC,
    CANCEL_PROC,
    MAYA_BRIDGE_PANEL,
)

def register():
    # 注册 USDHook（Blender 导入时自动触发）
    usd_hook.register()

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.mbb_config = bpy.props.PointerProperty(type=MBB_CONFIG)
    bpy.types.Scene.mbb_anim_config = bpy.props.PointerProperty(type=MBB_ANIM_CONFIG)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    # 注销 USDHook
    usd_hook.unregister()
    try:
        del bpy.types.Scene.mbb_config
    except AttributeError:
        pass
    try:
        del bpy.types.Scene.mbb_anim_config
    except AttributeError:
        pass


def _assign_by_prim_metadata(usd_path, scene=None):
    """检查 USD prim 上的 mbb_material 标记与实际材质槽是否一致（仅诊断，不修改）。

    scene: 可选场景对象。传入缓存的 scene 引用可避免 bpy.context 漂移。
           None 时回退到 bpy.context.scene。
    """
    try:
        from pxr import Usd
        stage = Usd.Stage.Open(usd_path)
        target_scene = scene if scene is not None else bpy.context.scene
        obj_by_path = {}
        for obj in target_scene.objects:
            if obj.type == 'MESH':
                obj_by_path[_object_to_path(obj)] = obj

        checked = 0
        for prim in stage.Traverse():
            mat_name = prim.GetCustomDataByKey('mbb_material')
            if not mat_name:
                continue
            mat = bpy.data.materials.get(mat_name)
            if mat is None:
                mat = bpy.data.materials.get(mat_name.replace('_', ':'))
            if mat is None:
                mat = bpy.data.materials.get(mat_name.replace(':', '_'))
            if not mat:
                print(f"[MBB] ⚠ prim={prim.GetPath()}: mbb_material={mat_name} 在 Blender 中不存在")
                continue
            prim_path = str(prim.GetPath())
            obj = obj_by_path.get(prim_path)
            if obj:
                checked += 1
                in_slots = mat in list(obj.data.materials)
                slot_names = [m.name for m in obj.data.materials if m]
                if not in_slots:
                    print(f"[MBB] ⚠ 面级分配缺失: obj={obj.name} prim={prim_path} mbb_material={mat_name}，当前槽={slot_names}")
            else:
                # .NNN后缀回退
                found = False
                for bp, bo in obj_by_path.items():
                    bp_leaf = re.sub(r'/([^/]+)\.\d{3,}$', r'/\1', bp)
                    if bp_leaf == prim_path:
                        checked += 1
                        in_slots = mat in list(bo.data.materials)
                        if not in_slots:
                            print(f"[MBB] ⚠ 面级分配缺失(.NNN回退): obj={bo.name} prim={prim_path} mbb_material={mat_name}")
                        found = True
                        break
                if not found:
                    print(f"[MBB] ⚠ prim={prim_path} 在 Blender 场景中未找到对应物体")
        print(f"[MBB] prim 材质一致性检查: {checked} 个 prim")
    except Exception as e:
        print(f"[MBB] prim 材质检查失败: {e}")


def _cleanup_temp(temp_dir, max_age_seconds=3600):
    """清理超过 max_age_seconds 的临时 USD/JSON/贴图文件。"""
    if not os.path.isdir(temp_dir):
        return
    try:
        now = time.time()
        for fn in os.listdir(temp_dir):
            fp = os.path.join(temp_dir, fn)
            try:
                if os.path.isfile(fp) and (now - os.path.getmtime(fp)) > max_age_seconds:
                    if any(fn.endswith(ext) for ext in ('.usdc', '.usda', '.usd', '.json')):
                        os.remove(fp)
            except OSError:
                pass
        # 清理 textures 子目录
        tex_dir = os.path.join(temp_dir, 'textures')
        if os.path.isdir(tex_dir):
            for fn in os.listdir(tex_dir):
                fp = os.path.join(tex_dir, fn)
                try:
                    if os.path.isfile(fp) and (now - os.path.getmtime(fp)) > max_age_seconds:
                        os.remove(fp)
                except OSError:
                    pass
    except Exception:
        pass


def send_to_maya(message, port):
    """向 Maya 发送 PING 命令并等待响应。

    精简版：仅处理 PING。耗时命令由 Modal Operator 管理。
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(3.0)
        s.connect((HOST, port))
        s.sendall((message + '\n').encode('utf-8'))
        return s.recv(256)


if __name__ == "__main__":
    register()
