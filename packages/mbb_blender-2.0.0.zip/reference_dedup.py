import bpy
# reference_dedup.py
# ---------------------------------------------------------------------------
# MBB 引用去重 — 两阶段：先材质后 mesh
#
# 阶段一：材质去重（户口本 + SG 名分组 → 合并 → 更新引用者 → 清理）
# 阶段二：mesh 去重（户口本分组 + 几何比对 + 材质槽校验 → 合并 → 清理）
#
# 入口函数：deduplicate_mesh_and_material_datablocks()
# ---------------------------------------------------------------------------

import os
import struct
import hashlib
import time
from collections import defaultdict


# ======================================================================
# 材质去重
# ======================================================================

def _deduplicate_materials():
    """阶段一：按户口本分组，比较节点树，合并相同材质。

    返回统计信息。
    """
    stats = {
        "total": len(bpy.data.materials),
        "merged": 0,
        "skipped_no_source": 0,
        "removed": 0,
    }

    t_start = time.time()

    # Step M1：按 source 分组
    material_source_groups = defaultdict(list)
    no_source_materials = []

    for mat in bpy.data.materials:
        source = mat.get("mbb_source_file")
        if source:
            material_source_groups[source].append(mat)
        else:
            no_source_materials.append(mat)
            stats["skipped_no_source"] += 1

    print(
        f"[MBB Dedup Mat] 材质分组: "
        f"{len(material_source_groups)} 个唯一源文件"
    )
    for src, mats in material_source_groups.items():
        print(
            f"[MBB Dedup Mat]   {os.path.basename(src)}: "
            f"{len(mats)} 个材质"
        )
    if no_source_materials:
        names = [m.name for m in no_source_materials[:20]]
        print(
            f"[MBB Dedup Mat] 无 source 标记的材质 "
            f"({stats['skipped_no_source']} 个): {names}"
        )

    # Step M2：组内按 mbb_sg_name 分组（SG 名由 Maya chaser 打标）
    swap_map = {}

    for source, materials in material_source_groups.items():
        sg_groups = defaultdict(list)
        for mat in materials:
            sg = mat.get("mbb_sg_name", mat.name.rsplit('.', 1)[0])
            sg_groups[sg].append(mat)

        for sg, identical_mats in sg_groups.items():
            if len(identical_mats) <= 1:
                continue

            keeper_mat = identical_mats[0]
            for old_mat in identical_mats[1:]:
                swap_map[old_mat] = keeper_mat
                stats["merged"] += 1
                print(
                    f"[MBB Dedup Mat] 合并: "
                    f"'{old_mat.name}' → '{keeper_mat.name}' "
                    f"(source={os.path.basename(source)}, SG={sg})"
                )

    # 批量替换材质槽（O(n×s) 遍历一次而不是 O(m×n×s)）
    if swap_map:
        swap_count = 0
        for obj in bpy.data.objects:
            if obj.type != "MESH":
                continue
            for i, slot in enumerate(obj.data.materials):
                if slot in swap_map:
                    obj.data.materials[i] = swap_map[slot]
                    swap_count += 1
        print(
            f"[MBB Dedup Mat] 材质槽批量更新: "
            f"{swap_count} 个槽被替换"
        )

    print(
        f"[MBB Dedup Mat] 合并阶段: 合并 {stats['merged']} 个材质, "
        f"耗时 {((time.time() - t_start) * 1000):.0f}ms"
    )

    return stats, no_source_materials


def _cleanup_orphan_materials():
    """清理 users == 0 且无伪用户标记的 material data-block。"""

    removed = 0
    skipped_fake_user = 0

    for mat in list(bpy.data.materials):
        if mat.users > 0:
            continue
        if mat.use_fake_user:
            skipped_fake_user += 1
            continue
        try:
            bpy.data.materials.remove(mat)
            removed += 1
        except Exception as e:
            print(f"[MBB Dedup Mat] 无法删除材质 '{mat.name}': {e}")

    print(
        f"[MBB Dedup Mat] 清理: 删除 {removed} 个冗余材质, "
        f"跳过伪用户 {skipped_fake_user} 个"
    )
    return removed


# ======================================================================
# Mesh 去重
# ======================================================================

def _mesh_fast_hash(mesh):
    """快速哈希：前 100 顶点坐标 + 前 100 面索引。

    同源文件的重复 mesh 在比特层面完全一致，
    这个级别的比较足以区分。
    """
    h = hashlib.sha256()
    h.update(struct.pack("ii", len(mesh.vertices), len(mesh.polygons)))
    for v in list(mesh.vertices)[:100]:
        h.update(struct.pack("fff", v.co.x, v.co.y, v.co.z))
    for p in list(mesh.polygons)[:100]:
        h.update(struct.pack(f"{len(p.vertices)}i", *p.vertices))
    return h.hexdigest()


def _mesh_full_hash(mesh):
    """全量哈希：所有顶点坐标 + 所有面索引。

    仅在 fast_hash 冲突时使用。
    """
    h = hashlib.sha256()
    for v in mesh.vertices:
        h.update(struct.pack("fff", v.co.x, v.co.y, v.co.z))
    for p in mesh.polygons:
        h.update(struct.pack(f"{len(p.vertices)}i", *p.vertices))
    return h.hexdigest()


def _materials_identical(mesh_a, mesh_b):
    """检查两个 mesh data-block 的材质分配是否完全一致。"""
    mats_a = [m.name if m else "" for m in mesh_a.materials]
    mats_b = [m.name if m else "" for m in mesh_b.materials]
    if mats_a != mats_b:
        return False
    if len(mesh_a.polygons) != len(mesh_b.polygons):
        return False
    for pa, pb in zip(mesh_a.polygons, mesh_b.polygons):
        if pa.material_index != pb.material_index:
            return False
    return True


def _deduplicate_meshes():
    """阶段二：按户口本分组，几何比对，合并相同 mesh。

    必须在材质去重之后调用。
    """

    stats = {
        "total_objects": 0,
        "merged": 0,
        "skipped_mat_mismatch": 0,
        "skipped_no_source": 0,
    }

    t_start = time.time()

    # Step 1：按 source 分组
    source_groups = defaultdict(list)
    no_source_objects = []

    for obj in bpy.data.objects:
        if obj.type != "MESH":
            continue
        stats["total_objects"] += 1
        source = obj.get("mbb_source_file")
        if source:
            source_groups[source].append(obj)
        else:
            no_source_objects.append(obj)
            stats["skipped_no_source"] += 1

    print(
        f"[MBB Dedup Mesh] 物体分组: "
        f"{len(source_groups)} 个唯一源文件"
    )
    for src, objs in source_groups.items():
        print(
            f"[MBB Dedup Mesh]   {os.path.basename(src)}: "
            f"{len(objs)} 个物体"
        )
    if no_source_objects:
        names = [o.name for o in no_source_objects[:20]]
        print(
            f"[MBB Dedup Mesh] 无 source 标记的物体 "
            f"({stats['skipped_no_source']} 个): {names}"
        )

    # Step 2 + 3：组内比对 + 合并
    for source, objects in source_groups.items():
        # 快速指纹分组
        fp_groups = defaultdict(list)
        for obj in objects:
            vc = len(obj.data.vertices)
            pc = len(obj.data.polygons)
            fp_groups[(vc, pc)].append(obj)

        for (vc, pc), objs in fp_groups.items():
            if len(objs) <= 1:
                continue

            t_fast = time.time()
            fast_groups = defaultdict(list)
            for obj in objs:
                fh = _mesh_fast_hash(obj.data)
                fast_groups[fh].append(obj)
            t_fast_elapsed = (time.time() - t_fast) * 1000

            t_full = time.time()
            for fh, fast_objs in fast_groups.items():
                if len(fast_objs) <= 1:
                    continue

                full_groups = defaultdict(list)
                for obj in fast_objs:
                    fh_full = _mesh_full_hash(obj.data)
                    full_groups[fh_full].append(obj)

                for fh_full, identical_objs in full_groups.items():
                    if len(identical_objs) <= 1:
                        continue

                    # 材质校验
                    keeper = identical_objs[0]
                    mergable = [keeper]
                    skipped_mat = []
                    for obj in identical_objs[1:]:
                        if _materials_identical(keeper.data, obj.data):
                            mergable.append(obj)
                        else:
                            skipped_mat.append(obj.name)
                            stats["skipped_mat_mismatch"] += 1

                    if skipped_mat:
                        print(
                            f"[MBB Dedup Mesh] 跳过合并（材质不一致）: "
                            f"keeper={keeper.name}, 跳过={skipped_mat}"
                        )

                    # 执行合并
                    keeper_data = mergable[0].data
                    for obj in mergable[1:]:
                        old_name = obj.data.name
                        obj.data = keeper_data
                        stats["merged"] += 1
                        print(
                            f"[MBB Dedup Mesh] 合并: "
                            f"{obj.name}.data "
                            f"{old_name} → {keeper_data.name}"
                        )

            t_full_elapsed = (time.time() - t_full) * 1000
            if t_fast_elapsed > 100 or t_full_elapsed > 500:
                print(
                    f"[MBB Dedup Mesh] 耗时警告: "
                    f"fast_hash={t_fast_elapsed:.0f}ms, "
                    f"full_hash={t_full_elapsed:.0f}ms "
                    f"(处理 {vc} 顶点 {pc} 面的组)"
                )

    t_total = (time.time() - t_start) * 1000
    print(
        f"[MBB Dedup Mesh] 完成: "
        f"合并 {stats['merged']} 个, "
        f"跳过(材质不一致) {stats['skipped_mat_mismatch']} 个, "
        f"跳过(无source) {stats['skipped_no_source']} 个, "
        f"总耗时 {t_total:.0f}ms"
    )

    return stats


def _cleanup_orphan_meshes():
    """清理 users == 0 且无伪用户标记的 mesh data-block。"""

    removed = 0
    skipped_fake_user = 0
    skipped_has_users = 0

    for mesh in list(bpy.data.meshes):
        if mesh.users > 0:
            skipped_has_users += 1
            continue
        if mesh.use_fake_user:
            skipped_fake_user += 1
            continue
        try:
            bpy.data.meshes.remove(mesh)
            removed += 1
        except Exception as e:
            print(f"[MBB Dedup Mesh] 无法删除 mesh '{mesh.name}': {e}")

    print(
        f"[MBB Dedup Mesh] 清理完毕: "
        f"删除 {removed} 个, "
        f"跳过伪用户 {skipped_fake_user} 个, "
        f"跳过有用户 {skipped_has_users} 个"
    )
    return removed


# ======================================================================
# 入口函数
# ======================================================================

def _propagate_source_for_new_objects(usd_path, new_object_names):
    """导入后从 USD 文件读取 source 标记，写入 Blender 对象和材质。

    Blender 5.2 的 USDHook.on_import 不传 import_context 参数（API 缺陷），
    因此改为导入后直接读 USD 文件。

    Args:
        usd_path: USD 文件路径
        new_object_names: 新导入的物体名集合（用于限定匹配范围）
    """

    stats = {"mesh_tagged": 0, "mat_tagged": 0, "no_source": 0, "skipped": 0}
    no_source_prims = []
    t_start = time.time()

    try:
        from pxr import Usd, UsdShade
    except ImportError:
        print("[MBB Propagate] pxr 不可用，跳过 source 传播")
        return stats

    stage = Usd.Stage.Open(usd_path)

    # 构建叶子名 → 所有 prim 路径的映射（处理同名冲突）
    leaf_to_prims = defaultdict(list)
    for prim in stage.Traverse():
        leaf_to_prims[prim.GetName()].append(prim)

    # 构建 Blender 对象名 → 对象引用
    bl_objs = {}
    for name in new_object_names:
        obj = bpy.data.objects.get(name)
        if obj and obj.type == 'MESH':
            bl_objs[name] = obj

    # 构建 Blender 材质名 → 材质引用
    bl_mats = {m.name: m for m in bpy.data.materials}

    # 对于新导入的物体，匹配 USD prim
    for obj_name, obj in bl_objs.items():
        # 尝试名字精确匹配
        prims = leaf_to_prims.get(obj_name, [])
        if not prims:
            # 尝试去掉 .001 等后缀
            base_name = obj_name.rsplit('.', 1)[0]
            prims = leaf_to_prims.get(base_name, [])

        for prim in prims:
            if not prim.IsA(UsdShade.Material):
                source = prim.GetCustomDataByKey("mbb_source_file")
                if source:
                    obj["mbb_source_file"] = source
                    stats["mesh_tagged"] += 1
                    break
        else:
            stats["no_source"] += 1
            if len(no_source_prims) < 20:
                no_source_prims.append(obj_name)

    # 对材质做同样匹配
    # 材质匹配时也处理 .NNN 后缀和 : → _ 规范化
    for mat_name, mat in bl_mats.items():
        prims = leaf_to_prims.get(mat_name, [])
        if not prims:
            base = mat_name.rsplit('.', 1)[0]
            prims = leaf_to_prims.get(base, [])
        if not prims:
            alt = mat_name.replace(':', '_')
            prims = leaf_to_prims.get(alt, [])

        for prim in prims:
            if prim.IsA(UsdShade.Material):
                source = prim.GetCustomDataByKey("mbb_source_file")
                if source:
                    mat["mbb_source_file"] = source
                    # 同时读取 SG 基础名
                    sg_name = prim.GetCustomDataByKey("mbb_sg_name")
                    if sg_name:
                        mat["mbb_sg_name"] = sg_name
                    stats["mat_tagged"] += 1
                    break

    print(
        f"[MBB Propagate] 完成: mesh={stats['mesh_tagged']}, "
        f"mat={stats['mat_tagged']}, 无source={stats['no_source']}, "
        f"耗时={((time.time() - t_start) * 1000):.0f}ms"
    )
    if no_source_prims:
        print(
            f"[MBB Propagate] 无 source 标记的物体（前 20 个）: "
            f"{no_source_prims}"
        )

    return stats


def deduplicate_mesh_and_material_datablocks():
    """两阶段去重：先材质后 mesh。

    材质先去重（统一材质槽），mesh 去重时
    _materials_identical 自然通过。

    返回 dict 包含各阶段统计。
    """

    print("[MBB Dedup] ======== 开始去重 ========")

    # 阶段一：材质去重
    mat_stats, _ = _deduplicate_materials()
    mat_removed = _cleanup_orphan_materials()

    # 阶段二：mesh 去重
    mesh_stats = _deduplicate_meshes()
    mesh_removed = _cleanup_orphan_meshes()

    result = {
        "mat_merged": mat_stats["merged"],
        "mat_removed": mat_removed,
        "mat_skipped_no_source": mat_stats["skipped_no_source"],
        "mesh_merged": mesh_stats["merged"],
        "mesh_removed": mesh_removed,
        "mesh_skipped_mat_mismatch": mesh_stats["skipped_mat_mismatch"],
        "mesh_skipped_no_source": mesh_stats["skipped_no_source"],
    }

    print(
        f"[MBB Dedup] ======== 去重完成 ========\n"
        f"[MBB Dedup] 材质: 合并={result['mat_merged']}, "
        f"清理={result['mat_removed']}, "
        f"无source={result['mat_skipped_no_source']}\n"
        f"[MBB Dedup] Mesh: 合并={result['mesh_merged']}, "
        f"清理={result['mesh_removed']}, "
        f"跳过(材质不一致)={result['mesh_skipped_mat_mismatch']}, "
        f"无source={result['mesh_skipped_no_source']}"
    )

    return result
