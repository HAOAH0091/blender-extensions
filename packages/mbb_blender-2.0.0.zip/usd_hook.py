# usd_hook.py
# ---------------------------------------------------------------------------
# MBB Blender USDHook — 占位 hook，实际 source 传播由 reference_dedup 模块完成。
#
# Blender 5.2 的 on_import 不传 import_context 参数（与文档不符的 API 缺陷），
# 因此 hook 不做实际操作。source 传播改为在 _do_usd_import 中调用
# reference_dedup._propagate_source_for_new_objects() 直读 USD 文件。
#
# 注册方式：在 __init__.py 的 register() 中
#   bpy.utils.register_class(MBBSourcePropagationHook)
# 卸载方式：在 unregister() 中
#   bpy.utils.unregister_class(MBBSourcePropagationHook)
# ---------------------------------------------------------------------------

import bpy


class MBBSourcePropagationHook(bpy.types.USDHook):
    """Blender 5.2 兼容的 USDHook 占位实现。

    实际 source 传播由 reference_dedup._propagate_source_for_new_objects() 完成。
    """

    bl_idname = "mbb.source_propagation"
    bl_label = "MBB Source Propagation"

    def on_import(self, *args):
        """占位：source 传播由 reference_dedup 模块直读 USD 文件完成。"""
        print("[MBB Hook] on_import 触发（source 传播由 reference_dedup 模块处理）")
        return True


# ---------------------------------------------------------------------------
# 注册 / 注销（由 __init__.py 调用）
# ---------------------------------------------------------------------------

def register():
    """注册 MBBSourcePropagationHook 到 Blender。"""
    try:
        bpy.utils.register_class(MBBSourcePropagationHook)
        print("[MBB Hook] MBBSourcePropagationHook 已注册")
    except Exception as e:
        print(f"[MBB Hook] 注册失败: {e}")


def unregister():
    """从 Blender 注销 MBBSourcePropagationHook。"""
    try:
        bpy.utils.unregister_class(MBBSourcePropagationHook)
        print("[MBB Hook] MBBSourcePropagationHook 已注销")
    except Exception as e:
        print(f"[MBB Hook] 注销失败: {e}")
