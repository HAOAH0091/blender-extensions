# MBB Changelog

## v2.5 — 兜底回退安全化 + 调试日志 (2026-07-15)

### 新增

- `[MBB-DBG]` 调试日志框架：覆盖 `reconstruct_materials`、`assign_material_to_objects`、`_assign_mat`、`_assign_by_prim_metadata`、modal 回调函数等关键路径，方便排查材质分配问题

### 修改

- `_assign_by_prim_metadata`：从"修改材质槽"改为"纯诊断"，不再执行 `obj.data.materials[0] = mat`（此前会覆盖 USD 导入时 GeomSubset 放在 Slot 0 的正确材质），改为检查一致性并在不匹配时打 `[MBB] ⚠` 警告
- `assign_material_to_objects`：删除 Tier 3 回退（路径匹配和 proto 匹配都失败后把材质塞给选中无材质物体的行为），改为 `[MBB] ⚠` 警告
- Maya 端 `_write_prim_material_markers` 叶子名 fallback：新增 `collision_names` 集合检测同名叶子 prim 冲突，冲突时跳过写入并打日志

### 修复

- `replace('Shape', '')` 改为 `re.sub(r'Shape$', '', ...)`，避免误删名称中部出现的 "Shape" 子串
- `_get_faces` 新增 `.NNN` 后缀剥离（兼容 Blender 导入重名物体时自动加的 `.001` `.002` 后缀）
- `_assign_mat` append 失败后 `return` 提前退出，避免二次报错

---

## v2.4 — 引用资产材质修复 (2026-07-14)

### 修复

- 引用资产导入时材质重复创建：同名材质只保留第一个，将指向被删槽的面重定向
- 面级材质分配到已存在物体时漏配：修复匹配路径中的 `.NNN` 后缀处理

---

## v2.3 — UDIM + 混合材质 (2026-07-13)

### 新增功能

**UDIM 多瓦片贴图支持**
- 自动检测 `<UDIM>` token 和显式瓦片号命名（`1001`~`1999`）
- Blender 端加载为 TILED Image，支持 `<UVTILE>` token 的 Maya 命名风格
- 瓦片文件复制去重，避免重复写入同名文件

**混合材质场景支持**
- 废除材质类型白名单：`export_usd_from_maya` 统一走 `useRegistry` + `convertMaterialsTo=['UsdPreviewSurface']`
- SG 命名规范化：Maya `shadingEngine` 名直接作为材质 key，不依赖 shader 节点名
- 贴图复制去重：同一源路径只复制一次

### 修复

- 材质槽清理：同名材质重复时自动去重，防止重复导入累积
- UDIM 加载失败时跳过该贴图而非崩溃
- 混合材质场景中 Arnold + UsdPreviewSurface 共存时的材质保存

---

## v2.2 — Modal 重构 + 动画导出 (2026-07-09)

### 新增功能

**动画导出支持**
- Cache 模式：逐帧烘焙顶点位置，Maya 端写 Mesh Sequence Cache，Blender 端读取
- Skeletal 模式：导出骨骼+蒙皮+动画曲线，Blender 重建 Armature + 约束
- `MBB_ANIM_CONFIG` 面板：动画模式选择、帧范围、步长配置
- 帧范围留空自动取 Maya 时间滑条范围

### 修改

**Import/Export 改造为 Modal Operator**
- 从阻塞式 `execute()` 改为 `invoke()` + `modal()` 状态机
- 支持 Cancel 按钮中止长操作
- 操作互斥锁：防止 Import 和 Export 同时运行
- UI 不再卡死：模态期间 Blender 界面保持响应

### 删除

- 固定超时机制：改为完全由用户 Cancel 中断

---

## v2.1 — UsdPreviewSurface 材质支持 (2026-07-08)

### 新增功能

**UsdPreviewSurface 材质直通导入**
- Maya 端检测材质节点类型，UsdPreviewSurface 走 USD 内置材质导出（`shd='useRegistry'`），跳过 JSON 重建流程
- Blender 端识别 `EXPORT_SUCCESS_USD_MAT:` 前缀，自动切换 `import_materials=True` + `import_usd_preview=True` + `import_all_materials=True`
- Arnold（aiStandardSurface）路径逻辑完全不变，零回归

**MBB EVAL 远程命令**
- `process_message()` 新增 `EVAL` 命令，支持从外部通过 socket 执行任意 Maya Python 代码并捕获 stdout
- 预置 `cmds`、`mel` 模块在执行命名空间

**maya_bridge.py — Maya 远程控制模块**
- `Maya` 类：连接管理、`eval()` 远程执行、`select()`/`detect_material_types()`/`export_usd()`/`reload_mbb()` 等便捷方法
- `Maya.launch_maya()` 一键启动 Maya + 加载场景 + 自动连接
- 上下文管理器支持：`with Maya() as m: ...`

**MBB_标准测试流程.md**
- 开发迭代时的标准测试参考，含 6 路分支测试、Arnold 回归测试、Blender 集成测试

### 修改

| 文件 | 改动 |
|------|------|
| `mbb_maya/mbb_server.py` | 新增 `detect_material_types()`、`_write_prim_material_markers()`；`export_usd_from_maya()` 加入 6 路分支（无材质/纯 Arnold/纯 USD/混合/全未知/已知+未知混合）；新增 `EVAL` 命令；提取 `_KNOWN_SHADER_TYPES` 模块常量 |
| `__init__.py` | `parse_response()` 返回 3 元组，新增 `EXPORT_SUCCESS_USD_MAT:` 前缀；`IMPORT_SELECTION_PROC` 根据 `use_usd_materials` 分支选择导入参数 |

### 修复

- `cmds.nodeType('usdPreviewSurface')` 返回小写 `'u'`，`KNOWN_MAT_TYPES` 统一为 `'usdPreviewSurface'`
- `detect_material_types()` 递归展开子 mesh（`allDescendents`），修复嵌套 Group 场景漏检
- `cmds.nodeType()` 在 shader 节点异常时 try-except 保护
- `_write_prim_material_markers()` 失败日志加 `⚠` 前缀

### 测试

- 环境：Maya 2025 + MayaUSD 0.27.0，Blender 5.1.2
- 场景：长枪兵 Rig（11 个 UsdPreviewSurface 材质，6 个 mesh 物体）
- 结果：全部 11 个材质成功导入，Principled BSDF 节点树完整（含 Image Texture、Normal Map、UV Map、Separate Color），多材质物体正确分配

---

## v2.0 — USD 迁移 + 材质重建 (2026-07-06)

### 新增功能

**FBX → USD 传输**
- Blender → Maya / Maya → Blender 传输格式从 FBX 二进制改为 USDC
- 声明式单位转换（`convert_scene_units='CENTIMETERS'`），不再手动改 `scene.unit_settings.scale_length`

**Arnold 材质自动重建**
- Maya 端采集 `aiStandardSurface` 元数据（贴图路径→socket 映射、默认值、物体-材质关联）
- Blender 端从 JSON 重建 Principled BSDF 节点树（含 Normal Map 节点、色彩空间自动判定、面级材质分配）
- 贴图文件自动复制到 temp 目录，路径更新为相对路径

**USD prim 标记材质分配**
- 导出时在 prim 上写 `mbb_material` 自定义数据
- Blender 端读取标记按层级路径分配材质

### 修改

- 通信协议：命令名 `FBX` → `USD`，返回格式增加 JSON 路径
- 临时文件统一管理 + 自动清理（3600s 过期）

### 删除

- `fbx2maya.py` 独立脚本（功能已整合）
- 全部 MEL `FBXExport*` 预设
- namespace 创建逻辑
