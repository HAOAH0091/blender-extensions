# 计划：移除危险的兜底回退机制

## 1. 问题回顾

### 当前现状

MBB 插件在材质重建和分配过程中有三层兜底/回退机制，其中两层存在"失败时偷偷换目标"的风险：

**Blender 端 `assign_material_to_objects` 三层匹配**：

```
Tier 1: 对象路径精确匹配        ← 正确
Tier 2: proto collection 名匹配   ← 兼容无实例导入，合理
Tier 3: 赋给选中的无材质物体      ← 危险兜底
```

Tier 3 的逻辑：前两层都没匹配到时，遍历当前选中物体，把材质塞给"材质槽为空"的那个。如果路径匹配因为边界条件静默失败（比如 `bpy.context` 在 modal 中漂移），材质会被随机扔给一个不相关的物体。

**Maya 端 `_write_prim_material_markers` 叶子名 fallback**：

精确路径匹配失败时，退而用叶子名模糊匹配。如果 USD 中有两个不同路径的 prim 共享同一个叶子名（比如 `/GroupA/ren` 和 `/GroupB/ren`），后一个会覆盖前一个的 `mbb_material` 标签，导致 Blender 端读到错误的材质名。

### 核心矛盾

"失败了自动找备胎"这个设计哲学在边界条件下会产生静默错误。正确的做法是：**失败了就报出来，不替用户做决定**。

### 背景

2026-07-15 刚修了 `_assign_by_prim_metadata` 的同类问题：它读 USD 的 `mbb_material` 标签后执行 `obj.data.materials[0] = mat`，把 USD 导入时 GeomSubset 放在 Slot 0 的正确材质踢掉。修复方式是将该函数从"修改材质槽"改为"纯诊断日志"。

Tier 3 和叶子名 fallback 是同一哲学下的遗留问题，一并处理。

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|---------|
| 删除 `assign_material_to_objects` Tier 3 回退 | P0 | 路径匹配失败时打 `[MBB] ⚠` 警告，不写任何物体 |
| Maya 叶子名 fallback 加碰撞保护 | P0 | 叶子名冲突时打 `log()` 警告并跳过；无冲突时正常 fallback |
| 不影响正常导入流程 | P0 | Tier 1/Tier 2 路径不变，正常匹配不受影响 |

---

## 3. 设计方案

### 3.1 Tier 3 回退：删除 → 替换为警告日志

| | 当前实现 | 改造后 |
|--|---------|--------|
| 路径匹配成功 | `_assign_mat` 赋材质 | 不变 |
| proto 匹配成功 | `_assign_mat` 赋材质 | 不变 |
| 两层都失败 | 遍历选中物体，找空槽的塞进去 | 打 `[MBB] ⚠` 日志，跳过 |

**关键决策**：完全删除 Tier 3，不做"温和版"（如只对特定条件开放）。理由：
1. Tier 1 + Tier 2 已覆盖了所有正规匹配路径
2. 如果两层都失败，说明数据有问题，应该让用户看到警告，而不是掩盖错误
3. 之前的 `_assign_by_prim_metadata` 修复证明"砍掉兜底"不会影响正常流程

### 3.2 叶子名 fallback：碰撞检测 → 安全降级

| | 当前实现 | 改造后 |
|--|---------|--------|
| 精确路径匹配成功 | 写入 `mbb_material` | 不变 |
| 精确匹配失败 + 叶子名唯一 | fallback 写入 | 不变 |
| 精确匹配失败 + 叶子名冲突 | fallback 写入（危险） | 跳过，打 `log()` 警告 |

**为什么 Tier 1 的叶子匹配是安全的**：Blender 场景中对象名是唯一的（同名对象会被 Blender 自动加 `.001` 后缀），不会出现两个不同路径的物体共享同一个叶子名。但 USD stage 中 `leaf_to_prim` 字典在构建时已检测到冲突并打了日志——&quot;构建时看到冲突但 fallback 时照用&quot;就是 bug。

**关键决策**：保留唯一叶子名的 fallback，只拦截冲突场景。理由：
1. 精确匹配失败但叶子名唯一的情况很常见（Maya DAG 路径和 USD prim 路径格式差异）
2. 完全删除 fallback 会导致大量正常的单 object 场景写入失败
3. 碰撞检测需要在字典构建阶段新增一个 `collision_names` 集合来记录冲突名

---

## 4. 详细设计

### 4.1 Blender 端改动

**文件**：`__init__.py`

**位置**：`assign_material_to_objects` 函数，Tier 3 代码块（约第 1304-1309 行）

**改动前**：
```python
    # Fallback: 如果按名字没配上，只赋给还没材质的选中物体
    if matched == 0 and target_names:
        print(f"[MBB-DBG] assign_material_to_objects: proto 回退也未匹配，进入选中物体回退")
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH' and (not obj.data.materials or not obj.data.materials[0]):
                _assign_mat(obj, material)
                matched += 1
```

**改动后**：
```python
    # 所有匹配路径均失败：仅警告，不自行决定目标物体
    if matched == 0 and target_names:
        print(f"[MBB] ⚠ 面级分配未匹配: mat={mat_name}, targets={target_names}，材质未写入任何物体")
```

### 4.2 Maya 端改动

**文件**：`mbb_maya/mbb_server.py`

**改动点 A**：`_write_prim_material_markers` 函数，`leaf_to_prim` 字典构建处（约第 486-495 行）

新增一个 `collision_names` 集合，记录在构建时检测到的叶子名冲突：

**改动前**：
```python
        leaf_to_prim = {}
        for p in stage.Traverse():
            name = p.GetName()
            if name in leaf_to_prim:
                log(f"⚠ 叶子名冲突: {name} ({leaf_to_prim[name].GetPath()} vs {p.GetPath()})")
            else:
                leaf_to_prim[name] = p
```

**改动后**：
```python
        leaf_to_prim = {}
        collision_names = set()
        for p in stage.Traverse():
            name = p.GetName()
            if name in leaf_to_prim:
                log(f"⚠ 叶子名冲突: {name} ({leaf_to_prim[name].GetPath()} vs {p.GetPath()})")
                collision_names.add(name)
            else:
                leaf_to_prim[name] = p
```

**改动点 B**：叶子名 fallback 处（约第 508-510 行）

**改动前**：
```python
                    # 精确匹配
                    prim = stage.GetPrimAtPath(usd_path_str)
                    if not prim or not prim.IsValid():
                        # 叶子名 fallback
                        leaf_name = usd_path_str.rsplit('/', 1)[-1]
                        prim = leaf_to_prim.get(leaf_name)
```

**改动后**：
```python
                    # 精确匹配
                    prim = stage.GetPrimAtPath(usd_path_str)
                    if not prim or not prim.IsValid():
                        # 叶子名 fallback：仅在无歧义时使用
                        leaf_name = usd_path_str.rsplit('/', 1)[-1]
                        if leaf_name in collision_names:
                            log(f"⚠ 跳过叶子名冲突的 prim: {usd_path_str}（叶子名 {leaf_name} 存在冲突，不写入 mbb_material）")
                        elif leaf_name in leaf_to_prim:
                            prim = leaf_to_prim[leaf_name]
                        else:
                            log(f"⚠ 跳过: {usd_path_str}（叶子名 {leaf_name} 未在 USD 中找到对应 prim）")
```

### 4.3 不需要改动的部分

- Tier 1（路径匹配）和 Tier 2（proto 匹配）：逻辑不变
- Tier 1 中的叶子名匹配（`leaf == tname.split('/')[-1]`）：Blender 场景对象名唯一，不存在同名碰撞风险，保持不动
- Blender 端 `_assign_mat`、`_assign_by_prim_metadata`：已在 2026-07-15 修复，本次不动
- `reconstruct_materials`、`_do_material_reconstruct`：不动

---

## 5. 实现步骤

| 步骤 | 操作 | 输入 | 输出 |
|------|------|------|------|
| 1 | 修改 `__init__.py`：删除 Tier 3 代码块，替换为警告日志 | 当前 `assign_material_to_objects` | 修改后的函数 |
| 2 | Python 语法检查 | 步骤 1 的输出 | 通过 |
| 3 | 修改 `mbb_maya/mbb_server.py` A：`leaf_to_prim` 构建处新增 `collision_names` 集合 | 当前 `_write_prim_material_markers` | 修改后的构建逻辑 |
| 4 | 修改 `mbb_maya/mbb_server.py` B：叶子名 fallback 处改用 `collision_names` + `leaf_to_prim` 分情况判断 | 步骤 3 的输出 | 修改后的 fallback 逻辑 |
| 5 | Python 语法检查 | 步骤 3、4 的输出 | 通过 |
| 6 | Blender 端验证：重新导入测试工程，确认 118SG10 正确分配 | 当前测试工程 | 无 `[MBB] ⚠` 警告出现 |
| 7 | 手动触发 fallback 条件（故意改错路径名），确认警告日志正确输出 | 修改后的代码 | 控制台有 `[MBB] ⚠` 输出 |

---

## 6. 测试策略

### 6.1 正常路径验证

| 场景 | 操作 | 预期结果 |
|------|------|---------|
| 导入三国弓箭兵工程 | MBB Import | 所有材质正确分配，包括 118SG10 在正确的面上 |
| 导入单材质物体 | MBB Import | Tier 1 匹配成功，材质正常 |
| 导入含 proto collection 的场景 | MBB Import | Tier 2 匹配成功 |

### 6.2 失败路径验证

| 场景 | 操作 | 预期结果 |
|------|------|---------|
| Tier 1 + Tier 2 都失败 | 临时改路径名后导入 | 控制台输出 `[MBB] ⚠ 面级分配未匹配`，材质不写入任何物体 |
| Maya 叶子名无冲突（精确匹配失败但 fallback 可用） | 正常导入 | Maya 端 `log()` 无冲突警告，`mbb_material` 通过 fallback 正常写入 |
| Maya 叶子名冲突 | 构造两个不同层级下同名叶子节点（如在 Maya 中两个 Group 下各有一个同名 mesh），导出后检查 | Maya 端 `log()` 输出"叶子名冲突"和"跳过叶子名冲突的 prim"；USD 文件中冲突 prim 的 `mbb_material` 标记缺失（对比修复前会被静默覆盖） |
| Maya 叶子名在 USD 中不存在 | 修改 DAG 到 prim 的路径使叶子名在 stage 中无对应 | Maya 端 `log()` 输出"未在 USD 中找到对应 prim" |

### 6.3 用户工作流变更验证

| 场景 | 操作 | 预期结果 |
|------|------|---------|
| 手动选中无材质物体并期望自动填充（旧 Tier 3 行为） | 删除某物体的材质后选中，导入 | 不再自动填充；用户需通过控制台警告定位后手动分配 |

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 删除 Tier 3 后某些老场景无法自动匹配 | 低 | 材质为空，用户需手动 | 警告日志明确指示哪个材质未匹配，用户可手动处理 |
| Maya 叶子名 fallback 收缩后写入率下降 | 低 | 少数 prim 无标记 | 不影响 Blender 面级分配（GeomSubset 和 JSON 已足够） |
| 代码被 Blender 重载但未生效 | 中 | 依旧使用旧代码 | `reload` 后验证函数签名变化 |
| 用户依赖 Tier 3 自动填充的工作流断裂 | 低 | 导入后某材质为空 | 警告日志可见，手动分配即可；Tier 3 原本就是低概率路径（需前两层同时失败） |

### 回退方案

所有改动在两个文件中共计约 15 行。回退只需：
1. `git checkout` 这两个文件
2. 或手动恢复改动的代码块

无需数据迁移，不改 JSON 或 USD 格式。

---

## 8. 参考

- `F:/desktop/BaiduSyncdisk/addons/mbb_blender/__init__.py`：`assign_material_to_objects`、`_assign_by_prim_metadata`
- `F:/desktop/BaiduSyncdisk/addons/mbb_blender/mbb_maya/mbb_server.py`：`_write_prim_material_markers`
- 2026-07-15 同类修复：`_assign_by_prim_metadata` 从"修改材质槽"改为"纯诊断"
