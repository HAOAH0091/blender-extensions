# MBB Maya 引用去重：执行计划

## 1. 问题回顾

### 当前现状

Maya 场景引用同一个源文件（如 `C07Changqiangbing_Rig.mb`）多次，每个 Maya 引用节点创建独立的 namespace。Maya USD 导出器（`mayaUSDExport`）的已知限制：**会将所有 Maya reference 扁平化展开**，不保留引用关系。

MBB 当前的导出导入链路：

```
Maya: cmds.mayaUSDExport(file=path, shd='useRegistry', ...)
  → 所有引用节点的内容被展开为独立 prim
  → USD 文件中出现 N 份完全相同的几何数据

Blender: bpy.ops.wm.usd_import(filepath=usd_path, ...)
  → 每个独立 prim 创建独立的 mesh data-block
  → data-block 数量 = 原始资产数 × 引用次数
```

实测场景：5 个 Maya 引用节点指向同一 `.mb` 文件，Blender 导入后产生 28+ 个独立 mesh data-block 和同等数量的独立 material data-block，其中大量是重复数据。几何体和材质都会重复——Blender 材质绑定在 mesh data-block 上，mesh 重复导入导致材质也被重复导入。

### 核心矛盾

Maya USD 导出器不会自动识别"同一源文件多次引用"并做实例化，而 MBB 当前没有机制在导出后、导入后做去重。

## 2. 改造目标

| # | 目标 | 优先级 | 验收标准 |
|---|------|--------|---------|
| 1 | Maya 导出时给 USD prim 打上源文件标记（户口） | P0 | 导出后的 USD 文件中，每个 mesh prim 和材质 prim 的 customData 包含 `mbb_source_file` 字段 |
| 2 | Blender 导入时将户口信息从 USD 传递到 Blender 对象和材质 | P0 | 导入后每个 MESH 对象和 MATERIAL 有 `mbb_source_file` 自定义属性 |
| 3 | Blender 导入后自动去重共享 mesh data-block | P0 | 同一源文件且几何完全相同的 mesh 共享一个 data-block，其余 data-block 被清理 |
| 4 | Blender 导入后自动去重共享 material data-block | P0 | 同一源文件且节点树内容相同的 material 共享一个 data-block，其余被清理；去重后材质的材质槽引用自动更新 |
| 5 | 无 source 标记的物体/材质不被静默跳过，而是打印调试日志 | P1 | 日志中明确列出哪些物体和材质缺少 source 标记 |
| 6 | 全程有足够细节的 debug 日志 | P1 | 每个处理阶段输出可追溯的调试信息 |

## 3. 设计方案

### 3.1 核心思路

```
Maya 导出           USD 文件            Blender 导入             Blender 去重
   │                   │                    │                      │
chaser 打标记    →  prim 自带户口    →  USDHook 传户口    →  按户口分组 + 几何比对
(customData)        (可独立读取)       (prim_map 桥接)       合并共享 data-block
```

### 3.2 关键设计决策

**决策 1：Maya 侧用 ExportChaser 而非导出后处理 USD 文件**

理由：ExportChaser 在导出过程中能访问 `GetDagToUsdMap()` 这个 Maya DAG → USD prim path 的精确映射。导出后靠猜测名称来关联，可靠性差。

**决策 2：Blender 侧用 USDHook.on_import 而非导入后手动匹配**

理由：`on_import` 回调接收 `get_prim_map()` 这个 USD prim path → Blender ID 的精确映射。不依赖名称匹配。

**决策 3：USDHook 直接从 import_context 获取 USD stage**

Blender 5.0 的 `USDSceneImportContext` 提供了 `get_stage()` 方法，返回已导入的 USD stage。hook 内部可以直接从 stage 读取 customData，无需重新打开文件，无需模块级变量传递路径。这个 API 从 Blender 4.4 起就存在。

**决策 4：去重放在 ASSIGN_PRIM 之后执行**

理由：若去重放在 MATERIAL_RECONSTRUCT 之前，两个共享 data-block 的物体可能被分配不同材质（如 Maya 中不同的 material override）。去重后 `obj.data.materials` 被共享，后处理的物体会覆盖前线处理的材质分配。将去重放在 ASSIGN_PRIM 之后：材质全部就位 → 合并几何体 → 共享 data-block 上的材质槽是最终正确状态。

**决策 5：材质也独立打户口标记，不从几何体继承**

理由：Maya 管线中存在"只引用材质库，不引用几何体"的场景（独立的 `materials_library.ma` 被引用后给本地建模的物体赋材质）。此时几何体和材质来自不同源文件，户口本不同。材质必须通过 chaser 独立打标，不能从所属几何体继承。

**决策 6：材质去重用"户口本分组 + 节点树内容比较"**

理由：与几何体去重的"户口本分组 + 顶点坐标比对"对称。同一源文件的材质在无 override 时节点树完全一致，可以被合并。有 override 的材质节点树不同，自动被筛掉。

**决策 7：材质 chaser 打标复用 `_write_prim_material_markers` 的遍历逻辑**

理由：这个函数已经在遍历所有 shadingEngine 并访问 USD stage。追加 source 标记的逻辑仅需在每个 SG 的循环中多加几行：`referenceQuery(sg) → 找到对应材质 prim → SetCustomDataByKey`。无需新建独立的遍历流程。

**决策 8：无 source 标记的物体/材质只打印调试信息，不尝试兜底**

理由：HAOAH 明确要求"兜底不用，打印到调试日志"。如果 source 信息漏了，说明 chaser 有问题，暴露出来比静默猜测更健康。

## 4. 详细设计

### 4.1 Maya 侧：ExportChaser

#### 文件位置

新建文件：`mbb_maya/mbb_chaser.py`

#### 类结构

```python
import mayaUsd.lib as mayaUsdLib
import maya.cmds as cmds
from pxr import Tf

class MBBReferenceChaser(mayaUsdLib.ExportChaser):
    """在 USD prim 上标记 Maya 引用源文件路径。"""
    
    name = "mbbReferenceSource"  # chaser 注册名
    
    def __init__(self, factoryContext, *args, **kwargs):
        super().__init__(factoryContext, *args, **kwargs)
        self._stage = factoryContext.GetStage()
        self._dag_to_usd = factoryContext.GetDagToUsdMap()
    
    def PostExport(self):
        """导出完成后，遍历所有 prim 打标记。"""
        # 步骤 1：构建 namespace → 源文件映射
        # 步骤 2：遍历 dag_to_usd，为每个 prim 查找源文件
        # 步骤 3：写入 customData
        pass
```

#### 核心逻辑

**Step 1：构建引用节点名 → 源文件映射**

```python
ref_node_source_map = {}
for ref_node in cmds.ls(type="reference"):
    try:
        fname = cmds.referenceQuery(ref_node, filename=True, withoutCopyNumber=True)
        ref_node_source_map[ref_node] = fname
        print(f"[MBB Chaser] 引用映射: ref_node='{ref_node}' → {fname}")
    except Exception as e:
        print(f"[MBB Chaser] 警告: 无法查询引用节点 {ref_node}: {e}")
```

**Step 2：遍历 dag_to_usd 打标记**

对每个 DAG 项，用 `cmds.referenceQuery(maya_path, referenceNode=True)` 反查引用节点名，再在 `ref_node_source_map` 中找到源文件。这个反查走 Maya 内部的引用层级树，无论 namespace 嵌套几层都能返回最直接的那个引用节点。

```python
def get_mbb_source_for_node(maya_dag_path_str, ref_node_source_map):
    try:
        ref_node = cmds.referenceQuery(maya_dag_path_str, referenceNode=True)
        return ref_node_source_map.get(ref_node) if ref_node else None
    except RuntimeError:
        return None

stats = {"total": 0, "tagged": 0, "no_ref": 0, "error": 0}
no_ref_samples = []

for item in self._dag_to_usd:
    maya_path = str(item.key())
    usd_path = item.data()
    stats["total"] += 1
    
    source = get_mbb_source_for_node(maya_path, ref_node_source_map)
    if source:
        prim = self._stage.GetPrimAtPath(usd_path)
        if prim:
            prim.SetCustomDataByKey("mbb_source_file", source)
            stats["tagged"] += 1
        else:
            stats["error"] += 1
            print(f"[MBB Chaser] prim 不存在: usd_path={usd_path}")
    else:
        stats["no_ref"] += 1
        if len(no_ref_samples) < 20:
            no_ref_samples.append(maya_path)
```

**Step 3：打印汇总**

```
[MBB Chaser] namespace 映射表:
[MBB Chaser]   C07Changqiangbing_Rig29RN → F:/desktop/C07Changqiangbing_Rig.mb
[MBB Chaser]   C07Changqiangbing_Rig30RN → F:/desktop/C07Changqiangbing_Rig.mb
[MBB Chaser]   ...
[MBB Chaser] 总 dag_to_usd 项: 150
[MBB Chaser] 已打标: 120 个 prim
[MBB Chaser] 非引用物体: 10 个 prim
[MBB Chaser] 处理失败（prim 找不到）: 0 个
[MBB Chaser] 非引用物体路径样本（前 20 个）:
[MBB Chaser]   |defaultLightSet
[MBB Chaser]   |defaultObjectSet
[MBB Chaser]   ...
```

#### 集成到 mbb_server.py

**Chaser 注册时机**：在 `mbb_server.py` 模块顶层做 try/except 注册，不等待 `export_usd_from_maya()` 调用时才注册。这样无论是手动测试还是通过 MBB 网络触发，chaser 都是就绪的。

```python
# mbb_server.py 顶部
_has_chaser = False
try:
    from mbb_chaser import MBBReferenceChaser
    import mayaUsd.lib as mayaUsdLib
    mayaUsdLib.ExportChaser.Register(MBBReferenceChaser, "mbbReferenceSource")
    _has_chaser = True
    print("[MBB Server] ExportChaser 'mbbReferenceSource' 已注册")
except Exception as e:
    print(f"[MBB Server] ExportChaser 注册失败: {e}")
    print("[MBB Server] 引用去重功能不可用，但不影响其他功能")
```

在 `export_usd_from_maya()` 中，`cmds.mayaUSDExport()` 调用时添加 chaser 参数（仅在 chaser 可用时）：

```python
export_kwargs = {
    'file': path,
    'sl': selected_only,
    'shd': 'useRegistry',
    'convertMaterialsTo': ['UsdPreviewSurface'],
}
if _has_chaser:
    export_kwargs['chaser'] = ['mbbReferenceSource']

cmds.mayaUSDExport(**export_kwargs, **anim_kwargs)
```

#### 材质 prim 打标（在 chaser `PostExport()` 内部实现，不修改 `_write_prim_material_markers`）

材质不在 `GetDagToUsdMap()` 中（材质是 DG 节点，不是 DAG 节点），需要在 chaser 内部单独处理。chaser 的 `PostExport()` 已有 `self._stage` 和已构建好的 `ref_node_source_map`，直接遍历 stage 中所有 Material 类型的 prim，通过 prim 名称反查 Maya SG 的引用归属：

```python
# 在 PostExport() 中，DAG 打标循环之后追加：
from pxr import UsdShade

material_stats = {"total": 0, "tagged": 0, "no_ref": 0}
no_ref_mat_prims = []

for prim in self._stage.Traverse():
    if not prim.IsA(UsdShade.Material):
        continue
    material_stats["total"] += 1
    
    # prim 名称在 USD 中与 Maya SG 名的对应关系：
    # shd='useRegistry' 导出时，材质 prim 路径为 /root_prim/mtl/{sg_name}
    # namespace 冒号被 _normalize_material_name 转为下划线
    prim_name = prim.GetName()
    # 尝试在 Maya 中反查对应的 SG 节点
    try:
        ref_node = cmds.referenceQuery(prim_name, referenceNode=True)
    except RuntimeError:
        ref_node = None
    
    if ref_node and ref_node in ref_node_source_map:
        source = ref_node_source_map[ref_node]
        prim.SetCustomDataByKey("mbb_source_file", source)
        material_stats["tagged"] += 1
    else:
        material_stats["no_ref"] += 1
        if len(no_ref_mat_prims) < 10:
            no_ref_mat_prims.append(prim_name)
```

遍历方式与现有 `_write_prim_material_markers` 的 `stage.Traverse()` + 叶子名匹配策略一致，不依赖硬编码的 prim 路径结构。

材质打标的汇总日志：

```
[MBB Chaser] 材质打标: 总计 {total_sg} 个 SG, 打标 {tagged} 个材质 prim
[MBB Chaser] 材质引用映射:
[MBB Chaser]   lambert1SG → F:/desktop/C07Changqiangbing_Rig.mb
[MBB Chaser]   aiStandardSurface1SG → F:/desktop/C07Changqiangbing_Rig.mb
[MBB Chaser]   ...
[MBB Chaser] 材质无引用（本地材质）: {non_ref_sg} 个
```

#### 调试信息

- 开始标记时的摘要（总 prim 数）
- 每个 namespace→源文件的映射表
- 无法匹配 source 的 prim 列表（前 10 个完整列出，超过 10 个截断）
- 打标成功/失败计数
- 任何异常打印完整 traceback

### 4.2 Blender 侧：USDHook

#### 文件位置

新建文件：`usd_hook.py`（放在 addon 根目录）

#### 类结构

```python
import bpy

class MBBSourcePropagationHook(bpy.types.USDHook):
    bl_idname = "mbb.source_propagation"
    bl_label = "MBB Source Propagation"
    
    def on_import(self, import_context):
        """导入完成后，从 USD stage 读取 source 标记，写入 Blender 对象。"""
        # import_context.get_stage() 返回已导入的 USD stage（Blender 4.4+ 支持）
        # import_context.get_prim_map() 返回 {prim_path: [blender_id_list]}
        pass
```

#### 核心逻辑

```python
def on_import(self, import_context):
    """从 USD stage 读取 mbb_source_file customData，写入 Blender 对象。
    
    使用 import_context.get_stage() 直接访问已导入的 USD stage，
    无需重新打开文件。如果 hook 内部异常，打印 traceback 后返回 True
    （不阻断导入流程）。
    """
    stats = {"prim_map_size": 0, "mesh_tagged": 0, "mat_tagged": 0,
             "no_source": 0, "no_prim": 0, "errors": 0}
    no_source_prims = []
    error_details = []
    
    try:
        stage = import_context.get_stage()
        prim_map = import_context.get_prim_map()
        stats["prim_map_size"] = len(prim_map)
        
        print(f"[MBB Hook] on_import 触发, prim_map 共 {len(prim_map)} 项")
        
        for prim_path, blender_ids in prim_map.items():
            try:
                prim = stage.GetPrimAtPath(prim_path)
                if not prim:
                    stats["no_prim"] += 1
                    continue
                
                source = prim.GetCustomDataByKey("mbb_source_file")
                if not source:
                    stats["no_source"] += 1
                    if len(no_source_prims) < 20:
                        no_source_prims.append(prim_path)
                    continue
                
                for bl_id in blender_ids:
                    # MESH 类型
                    if hasattr(bl_id, 'type') and bl_id.type == 'MESH':
                        bl_id["mbb_source_file"] = source
                        stats["mesh_tagged"] += 1
                    # MATERIAL 类型
                    elif isinstance(bl_id, bpy.types.Material):
                        bl_id["mbb_source_file"] = source
                        stats["mat_tagged"] += 1
            except Exception as item_error:
                stats["errors"] += 1
                error_details.append(f"{prim_path}: {item_error}")
        
        # 打印汇总
        print(f"[MBB Hook] 汇总: prim_map={stats['prim_map_size']}, "
              f"mesh已传={stats['mesh_tagged']}, mat已传={stats['mat_tagged']}, "
              f"无source={stats['no_source']}, 无prim={stats['no_prim']}, 异常={stats['errors']}")
    except Exception as hook_error:
        import traceback
        print(f"[MBB Hook] 严重异常: {hook_error}")
        traceback.print_exc()
        print(f"[MBB Hook] 状态: 失败（已处理 mesh={stats['mesh_tagged']} mat={stats['mat_tagged']} 个对象）")
    
    return True  # 永不阻断导入流程
```

#### 集成到 __init__.py

**注册**：在 `register()` 中 `bpy.utils.register_class(MBBSourcePropagationHook)`

**卸载**：在 `unregister()` 中 `bpy.utils.unregister_class(MBBSourcePropagationHook)`

**无需路径传递**：由于 `import_context.get_stage()` 可以直接访问 stage，不需要模块级变量传递 USD 文件路径，不需要修改 `_do_usd_import()` 中的任何代码。

#### 调试信息

- hook 是否被触发（入口打印 `prim_map` 大小）
- mesh 和 material 各自的处理计数
- 最终状态标志（完全成功 / 部分完成 / 失败）
- 无 source 标记的 prim 列表（前 20 个）
- 任何异常（单项异常 ≤10 条、全局异常）均打印完整 traceback

### 4.3 Blender 侧：去重函数

#### 文件位置

新建文件：`reference_dedup.py`（放在 addon 根目录）

#### 核心逻辑

去重函数 `deduplicate_mesh_and_material_datablocks()` 分为两个阶段：

**阶段一：材质去重**（必须在 mesh 去重之前执行）

如果先做 mesh 去重再做材质去重，共享 data-block 后两个物体的材质槽指向不同的 material（如 `mat_Rig29` vs `mat_Rig30`），`_materials_identical` 校验会不通过，mesh 去重被材质差异挡住。材质先去重，材质槽统一指向同一个 mat 后，mesh 去重的材质校验自然通过。

**阶段二：mesh 去重**

和之前设计一致：户口本分组 + 几何比对 + 材质槽校验 + 合并。
    # 步骤 3：每组只保留一个 data-block，其余物体 remap
    # 步骤 4：清理被遗弃的 data-block
    pass
```

#### 阶段一：材质去重

**Step M1：收集所有有 source 标记的 material，按 source 分组**

```python
material_source_groups = defaultdict(list)
no_source_materials = []

for mat in bpy.data.materials:
    source = mat.get("mbb_source_file")
    if source:
        material_source_groups[source].append(mat)
    else:
        no_source_materials.append(mat)
```

**Step M2：组内节点树比对**

```python
def material_node_tree_hash(mat):
    """计算材质节点树的指纹哈希。
    
    对材质的所有节点按名称排序后，遍历节点类型、输入值和连接关系
    计算哈希。由于 Blender 中每个 material 的 node_tree 独立，节点名
    不会跨 material 冲突，排序结果的稳定性有保证。
    """
    if not mat.node_tree:
        return "__no_tree__"
    h = hashlib.sha256()
    for node in sorted(mat.node_tree.nodes, key=lambda n: n.name):
        h.update(node.bl_idname.encode())
        # 遍历输入 socket 的值
        for inp in node.inputs:
            if inp.is_linked:
                # 记录链接目标节点名 + socket 名
                for link in inp.links:
                    h.update(link.from_node.name.encode())
                    h.update(link.from_socket.name.encode())
            elif hasattr(inp, 'default_value'):
                try:
                    h.update(str(inp.default_value).encode())
                except Exception:
                    pass
    return h.hexdigest()
```

**Step M3：合并 + 更新引用者**

```python
mat_stats = {"merged": 0, "skipped_no_source": len(no_source_materials)}

for source, materials in material_source_groups.items():
    hash_groups = defaultdict(list)
    for mat in materials:
        mh = material_node_tree_hash(mat)
        hash_groups[mh].append(mat)
    
    for mh, identical_mats in hash_groups.items():
        if len(identical_mats) <= 1:
            continue
        
        keeper_mat = identical_mats[0]
        for old_mat in identical_mats[1:]:
            # 遍历场景中所有物体，把材质槽中的旧材质替换为新材质
            swap_count = 0
            for obj in bpy.data.objects:
                if obj.type != 'MESH':
                    continue
                for i, slot in enumerate(obj.data.materials):
                    if slot == old_mat:
                        obj.data.materials[i] = keeper_mat
                        swap_count += 1
            
            mat_stats["merged"] += 1
            print(f"[MBB Dedup Mat] 合并材质: '{old_mat.name}' → '{keeper_mat.name}' "
                  f"(source={os.path.basename(source)}, 更新 {swap_count} 个材质槽)")

if no_source_materials:
    names = [m.name for m in no_source_materials[:20]]
    print(f"[MBB Dedup Mat] 无 source 标记的材质 ({mat_stats['skipped_no_source']} 个): {names}")

print(f"[MBB Dedup Mat] 完成: 合并 {mat_stats['merged']} 个材质")
```

**Step M4：清理被遗弃的 material data-block**

```python
removed_mat = 0
for mat in list(bpy.data.materials):
    if mat.users == 0 and not mat.use_fake_user:
        try:
            bpy.data.materials.remove(mat)
            removed_mat += 1
        except Exception as e:
            print(f"[MBB Dedup Mat] 无法删除材质 '{mat.name}': {e}")

print(f"[MBB Dedup Mat] 清理: 删除 {removed_mat} 个冗余材质")
```

#### 阶段二：mesh 去重

#### 详细步骤

**Step 1：按 source 分组**

```python
from collections import defaultdict

source_groups = defaultdict(list)
no_source_objects = []

for obj in bpy.data.objects:
    if obj.type != 'MESH':
        continue
    source = obj.get("mbb_source_file")
    if source:
        source_groups[source].append(obj)
    else:
        no_source_objects.append(obj)
```

**Step 2：组内几何比对**

几何指纹 = `(vertex_count * 1000000 + polygon_count)`，相同指纹的进同组。快速指纹筛掉不同拓扑的 mesh 后，同拓扑的 mesh 用"前 100 顶点坐标 + 面索引"做轻量预比对，同源文件的 mesh 在比特层面完全一致，不需要加密级哈希。最后才做全顶点精确比对。

```python
def mesh_fast_hash(mesh):
    """快速哈希：前 100 顶点坐标 + 面索引。
    
    同源文件的重复 mesh 在比特层面完全一致，这个级别的比较足以区分。
    """
    h = hashlib.sha256()
    # 顶点数 + 面数
    h.update(struct.pack("ii", len(mesh.vertices), len(mesh.polygons)))
    # 前 100 个顶点坐标
    for v in list(mesh.vertices)[:100]:
        h.update(struct.pack("fff", v.co.x, v.co.y, v.co.z))
    # 前 100 个面索引
    for p in list(mesh.polygons)[:100]:
        h.update(struct.pack(f"{len(p.vertices)}i", *p.vertices))
    return h.hexdigest()

def mesh_full_hash(mesh):
    """全量哈希：所有顶点坐标 + 所有面索引。仅在 fast_hash 冲突时使用。"""
    h = hashlib.sha256()
    for v in mesh.vertices:
        h.update(struct.pack("fff", v.co.x, v.co.y, v.co.z))
    for p in mesh.polygons:
        h.update(struct.pack(f"{len(p.vertices)}i", *p.vertices))
    return h.hexdigest()
```

**Step 3：材质校验 + 合并**

合并前必须校验材质槽分配一致，防止抹掉 Maya 中的 material override。材质不一致的跳过合并且打印日志。

```python
def _materials_identical(mesh_a, mesh_b):
    """检查两个 mesh data-block 的材质分配是否完全一致。"""
    mats_a = [m.name if m else '' for m in mesh_a.materials]
    mats_b = [m.name if m else '' for m in mesh_b.materials]
    if mats_a != mats_b:
        return False
    if len(mesh_a.polygons) != len(mesh_b.polygons):
        return False
    for pa, pb in zip(mesh_a.polygons, mesh_b.polygons):
        if pa.material_index != pb.material_index:
            return False
    return True

# 在主去重循环中：
stats = {"merged": 0, "skipped_mat_mismatch": 0, "skipped_no_source": 0}

for source, objects in source_groups.items():
    # 快速指纹分组
    fp_groups = defaultdict(list)
    for obj in objects:
        vc = len(obj.data.vertices)
        pc = len(obj.data.polygons)
        fp_groups[(vc, pc)].append(obj)
    
    for (vc, pc), objs in fp_groups.items():
        if len(objs) <= 1:
            continue
        
        # fast_hash 分组
        fast_groups = defaultdict(list)
        for obj in objs:
            fh = mesh_fast_hash(obj.data)
            fast_groups[fh].append(obj)
        
        for fh, fast_objs in fast_groups.items():
            if len(fast_objs) <= 1:
                continue
            
            # full_hash 最终确认
            full_groups = defaultdict(list)
            for obj in fast_objs:
                fh_full = mesh_full_hash(obj.data)
                full_groups[fh_full].append(obj)
            
            for fh_full, identical_objs in full_groups.items():
                if len(identical_objs) <= 1:
                    continue
                
                # 材质校验
                keeper = identical_objs[0]
                mergable = [keeper]
                skipped_mat = []
                for obj in identical_objs[1:]:
                    if _materials_identical(keeper.data, obj.data):
                        mergable.append(obj)
                    else:
                        skipped_mat.append(obj.name)
                        stats["skipped_mat_mismatch"] += 1
                
                if skipped_mat:
                    print(f"[MBB Dedup] 跳过合并（材质不一致）: "
                          f"keeper={keeper.name}, 跳过={skipped_mat}")
                
                # 执行合并
                keeper_data = mergable[0].data
                for obj in mergable[1:]:
                    old_name = obj.data.name
                    obj.data = keeper_data
                    stats["merged"] += 1
                    print(f"[MBB Dedup] 合并: {obj.name}.data "
                          f"{old_name} → {keeper_data.name}")
```

**Step 4：清理**

遍历 `bpy.data.meshes`，删除 `users == 0` 且 `use_fake_user == False` 的 mesh data-block。

```python
def cleanup_orphan_meshes():
    """删除无用户且无伪用户标记的 mesh data-block。"""
    removed = 0
    skipped_fake_user = 0
    skipped_has_users = 0
    
    for mesh in list(bpy.data.meshes):  # list() 避免迭代中修改集合
        if mesh.users > 0:
            skipped_has_users += 1
            continue
        if mesh.use_fake_user:
            skipped_fake_user += 1
            continue
        try:
            bpy.data.meshes.remove(mesh)
            removed += 1
        except Exception as e:
            print(f"[MBB Dedup] 无法删除 mesh '{mesh.name}': {e}")
    
    print(f"[MBB Dedup] 清理完毕: 删除 {removed} 个, "
          f"跳过伪用户 {skipped_fake_user} 个, "
          f"跳过有用户 {skipped_has_users} 个")
```

#### 集成到 MBB 导入流程

在 `IMPORT_SELECTION_PROC` 状态机中，`ASSIGN_PRIM` 之后插入新状态 `REFERENCE_DEDUP`：

```
USD_IMPORT → MATERIAL_RECONSTRUCT → ASSIGN_PRIM → REFERENCE_DEDUP → FINISHED
```

时序决策原因：材质全部分配完毕后，先做材质去重（统一材质槽），再做 mesh 去重（材质槽已一致，`_materials_identical` 自动通过）。

状态机取消处理同步更新：`_cancel_flag` 检查阶段列表中增加 `REFERENCE_DEDUP`：

```python
elif self._state in ('USD_IMPORT', 'MATERIAL_RECONSTRUCT', 'ASSIGN_PRIM', 'REFERENCE_DEDUP'):
    self._cancel_after_done = True
```

#### 调试信息

- 按 source 分组的结果（每个源文件有多少物体）
- 无 source 标记的物体列表（前 20 个完整列出）
- 每组内的几何指纹分布
- 哪些 data-block 被合并了（旧名 → 保留名）
- 清理了多少个 data-block
- 每一步的耗时（方便发现性能瓶颈）
- 任何异常打印完整 traceback

### 4.4 涉及的文件和改动点

| 文件 | 操作 | 说明 |
|------|------|------|
| `mbb_maya/mbb_chaser.py` | **新建** | Maya ExportChaser 实现（DAG 打标 + 材质打标） |
| `mbb_maya/mbb_server.py` | **修改** | 模块顶层注册 chaser + mayaUSDExport 添加 chaser 参数 + `_write_prim_material_markers` 追加材质 source 标记 |
| `usd_hook.py` | **新建** | Blender USDHook 实现（mesh + material 双重户口传递） |
| `reference_dedup.py` | **新建** | 去重函数实现（阶段一材质去重 + 阶段二 mesh 去重 + 清理） |
| `__init__.py` | **修改** | register() 中注册 hook + unregister() 中卸载 hook + 状态机 ASSIGN_PRIM 后插入 REFERENCE_DEDUP |

### 4.5 不需要改动的部分

- Maya → Blender 网络通信协议（TCP socket / EVAL 命令）
- 材质采集和重建逻辑（`collect_material_metadata` / `reconstruct_materials`）
- prim 材质标记逻辑（`_write_prim_material_markers`）
- UDIM 处理、贴图复制、动画导出
- 取消机制（Cancel）
- Import 和 Export 的状态机核心框架

## 5. 实现步骤

| 步骤 | 描述 | 输入 | 输出 | 
|------|------|------|------|
| 1 | 创建 Maya ExportChaser（`mbb_chaser.py`） | `mbb_server.py` 导出流程 | 可独立测试的 chaser 脚本 |
| 2 | 集成 chaser 到 `mbb_server.py` | chaser 脚本 + 现有导出函数 | 修改后的 `export_usd_from_maya()` |
| 3 | 创建 Blender USDHook（`usd_hook.py`） | Blender USDHook API | 可独立注册的 hook 类 |
| 4 | 创建去重函数（`reference_dedup.py`） | Blender data-block API | `deduplicate_mesh_and_material_datablocks()` |
| 5 | 修改 `__init__.py`：注册 hook + 集成去重 | 新模块 + 现有状态机 | 修改后的 `register()` 和状态机 |
| 6 | 端到端测试：Maya 多引用导出 → Blender 导入验证 | 测试场景（多引用同一文件的 Maya 场景） | 验证 data-block 数量减少 |
| 7 | 回归测试：不含引用的普通导出 和 Arnold 材质路径 | 现有测试场景 | 验证不引入回归 |

## 6. 测试策略

### 6.1 测试场景

| 场景 | 预期 |
|------|------|
| Maya 场景有 5 个引用指向同一源文件（含材质），导出导入 | mesh data-block 从 25+ 降至 5 个；material data-block 从 25+ 降至 5 个 |
| Maya 场景有 5 个引用指向同一源文件，其中一个引用有材质 override | 有 override 的材质不合并（节点树不同），其余材质正常合并 |
| Maya 场景无任何引用，导出导入 | chaser 打印"无引用物体"，去重跳过，原流程不受影响 |
| Maya 场景有多个引用指向不同源文件 | 各源文件的物体和材质独立成组，互不干扰 |
| Maya 场景引用了一个材质库文件 + 本地建模物体 | 材质来自材质库（有 source）、mesh 来自本地（无 source），材质去重正常执行，mesh 无 source 被打印到调试日志 |
| chaser 因异常退出 | 日志打印错误信息，导出仍然完成（USD 文件缺少 source 标记），Blender 侧打印无 source 的物体和材质列表 |
| 同名 mesh 在不同引用下有编辑差异 | 几何比对检测到差异，不合并 |
| Arnold 材质场景 | 材质重建走原流程，去重放在 ASSIGN_PRIM 之后不受影响；材质去重处理的是 USD 导入的占位材质，重建的高保真材质有独立 source |

### 6.2 手动测试 checklist

**Maya 侧：**
- [ ] chaser 脚本能在 Maya Script Editor 中独立运行（不依赖 MBB 服务器）
- [ ] 导出后的 USD 文件用 `usdcat` 查看，确认 prim customData 包含 `mbb_source_file`
- [ ] chaser 日志输出完整（总 prim 数、成功/失败数、无法匹配的列表）

**Blender 侧：**
- [ ] hook 在导入时自动触发，打印日志
- [ ] 每个 MESH 物体检查 `obj.get("mbb_source_file")` 有值
- [ ] 去重后 bpy.data.meshes 数量显著减少
- [ ] 去重后物体依然正确显示（位置、材质、层级关系不变）
- [ ] 无 source 标记的物体被打印到日志而非报错

**回归：**
- [ ] 不涉及引用场景的普通导出导入正常工作
- [ ] Arnold 材质重建正常
- [ ] Cancel 按钮仍正常工作

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| Maya 版本差异导致 chaser API 不可用 | 低 | 高 | 注册 chaser 时包 try/except，失败时打印警告但不阻塞导出 |
| Blender USDHook 在 5.1 版本中的行为与文档不一致 | 低 | 高 | 实现后用探测脚本验证 `get_prim_map()` 和 `get_stage()` 的实际行为 |
| `referenceQuery(node, referenceNode=True)` 反查不到引用节点（节点不在任何引用中） | 低 | 低 | 这是正常情况，chaser 打印"非引用物体/材质"日志后跳过，不影响导出 |
| 材质 prim 在 USD stage 中反查失败（prim 名与 Maya SG 名不匹配） | 中 | 中 | 使用 `stage.Traverse()` + `UsdShade.Material` 类型筛选，prim 名与 SG 名的对应关系由 Maya USD 导出器保证（`shd='useRegistry'`）。实现时打印前 10 个材质 prim 路径供人工验证 |
| 材质节点树哈希因 Blender 默认节点差异导致漏检 | 低 | 中 | USD 导入的材质含 Principled BSDF 节点树，节点树独立不会跨 material 冲突。哈希比较节点类型、输入值和连接拓扑 |
| 材质去重后 `bpy.data.materials.remove` 在 users > 0 时抛异常 | 低 | 低 | 删除前先检查 users 计数和 use_fake_user，操作包 try/except |
| 去重后物体材质 slot 被 Blender 自动重映射导致材质丢失 | 低 | 低 | 材质先去重（统一材质槽），再 mesh 去重（`_materials_identical` 自然通过）。材质槽在被合并 mesh 之间已是一致的 |
| `mesh_fast_hash` 在大 mesh 上耗时过长 | 低 | 低 | 只采样前 100 顶点和前 100 面；打印每个阶段耗时，超过阈值输出警告 |
| 嵌套 namespace（引用文件含子引用）导致 chaser `referenceQuery` 反查结果不正确 | 低 | 中 | `referenceQuery(..., referenceNode=True)` 返回最内层 child reference 节点，用日志打印前 10 个映射结果供人工抽查 |
| Blender 导入时自动给同名物体加 `.001` 后缀 | 低 | 低 | 去重不依赖物体名（按 source 分组）；hook 的 prim_map 使用 USD 原始路径，不受重命名影响 |

### 回退方案

如果去重引入问题，只需跳过去重步骤：状态机从 `USD_IMPORT` 直接进入 `MATERIAL_RECONSTRUCT`（即回到改造前的行为）。chaser 和 hook 的标记行为不影响后续流程，仅增加少量处理时间。

## 8. 参考

- Maya USD Export Chaser 示例：https://gist.github.com/BigRoy/5dbe94ae66b33c206ef21b9a66411a8e
- Blender USDHook API：`bpy.types.USDHook`（Blender Python API 文档）
- Autodesk 官方讨论（Maya reference 扁平化证据）：https://github.com/Autodesk/maya-usd/discussions/2192
- MBB 混合材质执行计划：`临时中转区/Dev/MBB_混合材质支持_执行计划.md`
- Blender USD 导入材质关键参数：`Blender_base/04-概念库/综合/Blender-USD-导入材质关键参数.md`
