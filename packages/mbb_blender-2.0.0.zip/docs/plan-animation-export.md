# MBB 动画导出支持：执行计划

> 版本：FINAL（已批准）
> 日期：2026-07-09
> 状态：已批准

---

## 1. 问题回顾

### 当前现状

MBB 的 Blender → Maya 导出和 Maya → Blender 导入，在动画方面都是"拍照片"：无论 Maya 里选中了怎样的动画资产，到 Blender 只得到当前帧的静态几何体。

导出调用链（Maya → Blender 方向，用户点 Import Selection 时）：

```
Blender IMPORT_SELECTION_PROC（Modal）
  → 发 TCP: "EXPORT_SELECTED C:\temp\xxx.usdc"
  → Maya mbb_server.process_message()
    → export_usd_from_maya(path, selected_only=True)
      → cmds.mayaUSDExport(file=path, sl=True, shd='none')  ← 没有任何动画参数
      → 返回 EXPORT_SUCCESS:...
  → Blender 解析响应 → 导入 USD → 重建材质
```

当前 `mayaUSDExport` 的调用没有传 `frameRange`、`exportSkels`、`exportSkin` 任一动画相关参数，默认行为：导出当前帧的静态网格。

Blender 面板上只有一个 `temp_work_dir`（临时目录）和一个连接端口可配置。Maya 端 UI 也只有端口号。

### 核心矛盾

Maya 侧 `mayaUSDExport` 功能上完全支持动画导出（骨骼动画和顶点缓存两条路都支持），MBB 只是没有把这个能力"接到" Blender 的面板上，也没有通过协议传递参数。问题不在能力缺口，在接口没打通。

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|---------|
| Blender 面板新增动画导出设置区 | P0 | 面板上可看到动画模式、帧范围、帧步长三个可配置项，默认全部关闭/空，保持向后兼容 |
| Maya 端 `export_usd_from_maya` 支持骨骼动画导出 | P0 | "Skeletal"模式导出后，Blender 导入得到 Armature + skinned mesh |
| Maya 端 `export_usd_from_maya` 支持顶点缓存导出 | P0 | "Cache"模式导出后，Blender 导入得到带 Mesh Sequence Cache modifier 的 mesh，能逐帧播放 |
| 协议扩展：Blender → Maya 传递动画配置 | P0 | JSON 参数通过 EXPORT_SELECTED 命令一并发送，Maya 解析无报错 |
| 动画相关错误处理和用户通知 | P1 | 用户选了动画模式但时间滑条范围无效时，有明确的错误提示 |
| 导出时间估算提示 | P2 | Cache 模式在面板上显示预计帧数（只读），让用户对等待时长有预期 |

---

## 3. 设计方案

### 核心思路

不改动当前的模态状态机框架，新增一个 `MBB_ANIM_CONFIG` PropertyGroup 存放动画设置，面板在 Export/Import 按钮上方增加一个可折叠的"Animation"区域。通信协议从纯文本扩展为"命令 + JSON 载荷"格式，Maya 端用 `json.loads` 解析，字段缺失时走默认值。

### 当前 vs 改造后

| 层面 | 当前实现 | 改造后 |
|------|---------|--------|
| Blender 设置存储 | `MBB_CONFIG(connection_port)` + `MBB_ADDON_PREF(temp_work_dir)` | 新增 `MBB_ANIM_CONFIG`：anim_mode、frame_start、frame_end、frame_step |
| Blender 面板 | 直接画三个按钮 | 新增折叠区"Animation Settings"，动画模式下拉 + 帧范围（整数输入） |
| 通信协议 | `"EXPORT_SELECTED C:\path.usdc"` | `"EXPORT_SELECTED {\"path\":\"...\",\"anim_config\":{...}}"` 单行 JSON |
| Maya 导出函数签名 | `export_usd_from_maya(path, selected_only=True)` | `export_usd_from_maya(path, selected_only=True, anim_config=None)` |
| Maya `mayaUSDExport` 调用 | 固定参数：`file, sl, shd` | 根据 anim_config 动态加入 frameRange、exportSkels、exportSkin、frameStride |

### 关键设计决策

**决策 1：动画配置放 Blender 面板还是 Addon Preferences？**

放面板。动画设置是每次操作都不同的（场景不同、需求不同），不是全局偏好。放在 `MBB_CONFIG`（Scene 级 PropertyGroup）下，跟随场景保存。Addon Preferences 只保留"不常变"的设置（如 temp_work_dir）。

**决策 2：通信协议用分隔符还是 JSON？**

用 JSON 字符串嵌入命令参数位，即 `EXPORT_SELECTED {"path":"...","anim_config":{...}}` 单行。理由是：
- 帧范围等参数天然结构化，不需要自己写分隔符解析
- Maya 端 `handle_client` 是逐行读取、逐行 dispatch——如果用多行，第一行处理完就会返回响应、Blender 端关闭连接，第二行永远丢在 buffer 里
- 单行 JSON 嵌入参数位，与现有逐行 dispatch 架构完全兼容
- 向后兼容：Maya 端先尝试 `json.loads(arg)` 解析，失败则把 `arg` 当旧协议纯路径处理
- 可扩展：以后加新参数不改协议格式

**决策 3：Import 操作（Maya Export → Blender Import）要不要也加动画设置？**

要。因为动画导出发生在 Maya 端，设置虽然在 Blender 面板上配，但实际执行是 Maya 的 `export_usd_from_maya`。所以 Import 和 Export 两个方向的动画设置在同一个面板、同一次 Maya 导出中生效。Export（Blender → Maya）方向暂不涉及动画，不在本次范围内。

**决策 4：Blender 侧的 Import 操作要不要额外处理动画的 USD 导入？**

不用。Blender 的 `bpy.ops.wm.usd_import` 从 4.0 开始已支持动画数据（骨骼/缓存）的自动识别和导入。MBB 只要确保 Maya 导出的 USD 包含动画数据，Blender 导入时就会自动处理。

---

## 4. 详细设计

### 4.1 状态机（不变）

当前两个 Modal Operator 的状态机不新增状态。动画配置在 `invoke()` 阶段就读取并序列化为协议消息，不参与 Modal 循环。

### 4.2 涉及的文件和改动点

#### 文件 A：`F:/desktop/BaiduSyncdisk/addons/mbb_blender/__init__.py`

| 改动 | 说明 |
|------|------|
| 新增 `MBB_ANIM_CONFIG` PropertyGroup | 4 个属性：anim_mode（枚举）、frame_start（整数，无 min 限制）、frame_end（整数）、frame_step（整数，min=1，default=1） |
| 注册 `MBB_ANIM_CONFIG` | 挂到 `bpy.types.Scene.mbb_anim_config` |
| 修改 `MAYA_BRIDGE_PANEL.draw()` | 新增折叠区 "Animation"，画三个控件。anim_mode 为 NONE 时帧范围控件灰掉 |
| 修改 `IMPORT_SELECTION_PROC._do_send_maya_export()` | 从 `mbb_anim_config` 构建载荷：NONE 模式发送纯路径（旧协议），非 NONE 模式发送 JSON（新协议） |
| 新增辅助函数 `_build_export_message(temp_path, context)` | anim_mode == 'NONE' → 纯路径（旧协议兼容）；anim_mode != 'NONE' → JSON 字符串 `{"path":"...","anim_config":{...}}` |

#### 文件 B：`F:/desktop/BaiduSyncdisk/addons/mbb_blender/mbb_maya/mbb_server.py`

| 改动 | 说明 |
|------|------|
| 修改 `export_usd_from_maya(path, selected_only=True, anim_config=None)` | 新增 `anim_config` 参数，dict 或 None |
| 在函数内加入动画参数分支逻辑 | 根据 anim_config 的 mode 字段，构建不同的 `mayaUSDExport` kwargs |
| 修改 `process_message()` 的 `export_selected` 分支 | 先尝试 `json.loads(arg)` 解析：成功则提取 `path` + `anim_config`；失败则把 `arg` 当旧协议纯路径处理 |

#### 文件 C：`F:/desktop/BaiduSyncdisk/addons/mbb_blender/mbb_maya/mbb_ui.py`

| 改动 | 说明 |
|------|------|
| 无强制改动 | 当前 Maya UI 只有端口号，不涉及动画设置。可在后续迭代中加入状态显示 |

#### 文件 D：`F:/desktop/BaiduSyncdisk/addons/mbb_blender/maya_bridge.py`

| 改动 | 说明 |
|------|------|
| 无强制改动 | 当前 `IMPORT_SELECTION_PROC` 直接通过 socket 连接 Maya，不经过 `Maya` 类。`Maya.export_usd()` 走的是 `eval()` 路径，用于独立测试脚本，不在面板流程中。本次不改动。如果未来统一两条路径，作为独立架构债务处理 |

### 4.3 不需要改动的部分

- `EXPORT_SELECTION_PROC`（Blender → Maya 方向）：本次不涉及
- `reconstruct_materials()`：材质重建逻辑不变
- `_assign_by_prim_metadata()`：材质分配不变
- `mbb_server.start_server()` / `stop_server()`：服务器生命周期不变
- `mbb_plugin.py`：插件注册不变

---

## 5. 实现步骤

### 步骤 0：前提验证（Blender UsdSkel 导入能力确认）

**输入**：Blender 5.0.0 环境
**输出**：确认骨骼动画导入路径可用
**操作**：
1. 在 Maya 中创建一个简单骨骼蒙皮立方体动画，手动导出为 USD（骨骼 + 蒙皮）
2. 在 Blender 中用 `bpy.ops.wm.usd_import` 导入，确认：
   - Armature 对象是否正确创建
   - Armature Modifier 是否自动添加到 mesh 上
   - 骨骼朝向与 Maya 的偏差程度（截图比对）
3. 判定标准：

| 验证项 | 通过条件 | 有条件通过（标注实验性） | 失败条件 |
|--------|---------|---------------------|---------|
| Armature 对象创建 | 正常创建，层级与 Maya 一致 | 创建但有警告 | 未创建 |
| Armature Modifier | 自动添加，skinned mesh 正确变形 | 需手动添加 | 无法添加 |
| 骨骼朝向 | 与 Maya 偏差在视角可忽略范围 | 偏差明显但可手动修正 | 骨骼翻转/错位 |
| 动画播放 | 逐帧播放流畅 | 有跳帧但整体可辨认 | 无法播放 |

4. 有任一失败项 → Skeletal 模式标注为"实验性"，Cache 模式作为推荐

### 步骤 1：Blender 侧 PropertyGroup + 面板

**输入**：`__init__.py`
**输出**：面板上可见动画设置区
**操作**：
1. 在 `__init__.py` 中新增 `MBB_ANIM_CONFIG` 类（4 个属性）
2. 在 `register()` 中注册并挂到 `bpy.types.Scene`
3. 修改 `MAYA_BRIDGE_PANEL.draw()`，在 Cancel 按钮前插入折叠式 "Animation" 区
4. 测试：启动 Blender，确认面板显示新控件，默认值为 None

### 步骤 2：Blender 侧协议拼接

**输入**：步骤 1 的 PropertyGroup
**输出**：`_do_send_maya_export()` 能根据 anim_mode 选择发送旧协议纯路径或新协议 JSON 消息
**操作**：
1. 新增 `_build_export_message(temp_path, context)`：
   - `anim_mode == 'NONE'` → 返回纯文本路径（旧协议：`"C:\temp\xxx.usdc"`），与当前版本完全一致，旧版 Maya MBB 无障碍
   - `anim_mode != 'NONE'` → 返回 JSON 字符串（新协议，需新版 Maya）
   - 该函数仅返回载荷字符串，不包含 `EXPORT_SELECTED ` 前缀和换行符
2. 修改 `_do_send_maya_export()`：`payload = _build_export_message(...)` → `s.sendall(f"EXPORT_SELECTED {payload}\n"...)`
3. 逻辑：`anim_mode == 'NONE'` → 纯路径（旧协议，旧版 Maya 兼容）；`anim_mode != 'NONE'` → JSON（新协议，需新版 Maya）

### 步骤 3：Maya 侧协议解析

**输入**：MBB 协议消息（单行 JSON）
**输出**：`export_usd_from_maya` 能接收动画配置
**操作**：
1. 修改 `process_message()` 的 `export_selected` 分支：
   - 先尝试 `json.loads(arg)` 解析 → 成功则验证包含 `\"path\"` 键（缺失返回 `EXPORT_FAILED`），提取 `path` 和可选的 `anim_config`
   - `json.loads(arg)` 抛出 JSONDecodeError → `arg` 是旧协议纯路径，直接使用
2. 修改 `export_usd_from_maya` 签名，增加 `anim_config=None`

### 步骤 4：Maya 侧导出逻辑

**输入**：anim_config dict
**输出**：正确的 `mayaUSDExport` 调用
**操作**：
1. **前提**：先在 Maya 中执行 `cmds.help("mayaUSDExport")` 确认当前版本的 `frameRange` 参数格式。Maya 2024+ 支持 Python 关键字 `frameRange=(start, end)`（两个 float）；Maya 2022/2023 可能需通过 `-options` 字符串传 `startTime/endTime`
2. 在 `export_usd_from_maya` 开头解析 anim_config，按 Maya 版本选择参数格式
3. 分支：
   - `mode == 'CACHE'`：加入 `frameRange=(start, end)` + `frameStride=step`，不传 `exportSkels`/`exportSkin`
   - `mode == 'SKELETAL'`：加入 `exportSkels='auto'` + `exportSkin='auto'` + `exportBlendShapes=True` + `frameRange=(start, end)`
4. 错误处理：
   - 帧范围缺失（None）→ 自动用 `cmds.playbackOptions(q=True, min=True/max=True)` 获取
   - 帧范围无效（start > end）→ 返回 `EXPORT_FAILED` 并说明原因

### 步骤 5：端到端测试

**输入**：完整的 MBB 插件（两端更新）
**输出**：测试报告
**操作**：
1. Cache 模式：Maya 创建简单球体动画（位移关键帧），导入 Blender，验证有 Mesh Sequence Cache
2. Skeletal 模式：Maya 创建简单骨骼蒙皮动画，导入 Blender，验证有 Armature + Armature Modifier
3. None 模式（默认）：确认行为与当前版本一致
4. 帧范围自动获取：Maya 时间滑条设 10~50，面板留空，验证导出 10~50

---

## 6. 测试策略

### 测试场景

| 场景 | 操作 | 预期结果 |
|------|------|---------|
| T1：默认不动 | 不修改面板，直接 Import | 行为与 v2.0 完全一致，只导出静帧 |
| T2：Cache 模式 + 简单位移动画 | Maya 球体 1~30 帧位移，面板选 Cache，帧范围留空 | 导入 Blender 后球体有 30 帧位移动画，Mesh Sequence Cache modifier |
| T3：Cache 模式 + 蒙皮动画 | Maya 蒙皮角色走路动画，面板选 Cache，帧范围留空 | 导入后角色有动画，每帧顶点正确变形 |
| T4：Skeletal 模式 + 简单骨骼 | Maya 两节骨骼 + 蒙皮立方体 + 旋转动画，选 Skeletal | 导入后有 Armature 对象 + 立方体带 Armature Modifier，可播放骨骼动画 |
| T5：Skeletal 模式 + 复杂绑定 | Maya 多关节角色 + 控制器动画，选 Skeletal | 导入后骨骼层级基本正确，动画可播放（允许轻微的骨骼朝向偏差） |
| T6：手动帧范围 | 面板填帧范围 10~60，帧步长 2 | Maya 导出帧 10,12,14...60 |
| T7：帧范围无效 | start > end（10~1） | Maya 返回 EXPORT_FAILED，Blender 面板显示错误 |
| T8：旧版 Maya MBB | 新版 Blender（含动画面板）连接旧版 Maya MBB 服务端，发送 `EXPORT_SELECTED {\"path\":\"...\",\"anim_config\":{...}}` | 旧版 Maya `process_message` 将整个 JSON 字符串当路径传给 `export_usd_from_maya`，因路径无效返回 `EXPORT_FAILED`。此为预期行为——旧版 Maya 必须更新才能支持动画导出。新版 Maya MBB 的 `process_message` 通过 `json.loads` 分支正确解析 |
| T9：取消操作 | Cache 模式导出中途点 Cancel | 与当前 Cancel 行为一致，临时文件清理 |
| T10：高面数 Cache 压力测试（P2） | 50K+ 顶点 mesh × 100+ 帧 Cache 导出 | 导出不加时出错，内存不溢出，临时文件正常清理 |
| T11：多骨骼 Skeletal 测试（P2） | 50+ 骨骼角色动画 Skeletal 导出 | 骨骼层级完整，动画可播放 |

### 手动测试 checklist

- [ ] 面板折叠/展开正常，控件对齐
- [ ] anim_mode 切换时相关控件显示/隐藏（None 时帧范围灰掉）
- [ ] 默认值持久化（切换场景后设置保持）
- [ ] 导出完成后临时 USD 文件被 `_cleanup_temp` 清理
- [ ] Enum 值变更不触发导出（纯 UI 交互）

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| Blender 导入骨骼动画时骨骼朝向偏差 | 中 | 中 | 步骤 0 的前提验证中实测确认偏差程度；如可接受则文档说明限制，偏差超出可接受范围则 Skeletal 模式标注为"实验性"并提供回退到 Cache 模式的指引 |
| Cache 模式导出时间过长，用户以为卡死 | 中 | 低 | 在 Blender 面板显示估算帧数（只读计算：frame_end - frame_start + 1），让用户有心理预期 |
| 复杂绑定在 Skeletal 模式导出失败 | 中 | 中 | 如果 Skeletal 失败，提供一个"回退到 Cache 模式"的提示流程 |
| Maya USD 插件版本差异导致动画参数行为不一致 | 低 | 高 | 在 Maya 端增加 Maya 版本检测，不同版本走不同的参数分支（如 Maya 2023 用 `-options` 字符串格式传参）；首版仅支持 Maya 2024+ |
| 协议变更导致 Blender 新版和 Maya 旧版通信异常 | 低 | 高 | Maya 端 `process_message` 先尝试 `json.loads` 解析参数位，失败则当旧协议纯路径处理。Blender 端 \`anim_mode == 'NONE'\` 时发送纯文本路径（完全与旧协议一致），旧版 Maya \`process_message\` 的 \`json.loads\` 尝试失败后走纯路径回退分支 |

### 回退方案

- 所有动画相关改动都在 `anim_config` 这个分支内，不修改任何现有逻辑路径
- 如果出现严重问题：将 `anim_mode` 默认值锁定为 `'NONE'`，后续代码完全不执行
- Maya 端：`export_usd_from_maya` 的 `anim_config=None` 为默认值，走完全相同的旧逻辑

---

## 8. 参考

| 资料 | 链接 |
|------|------|
| Maya `mayaUSDExport` 完整参数列表 | `cmds.help("mayaUSDExport")` 在 Maya 脚本编辑器中执行 |
| Autodesk maya-usd GitHub Issue #2763（动画导出示例） | https://github.com/Autodesk/maya-usd/issues/2763 |
| Autodesk maya-usd Discussion #3664（Skin/Skel 导出约束） | https://github.com/Autodesk/maya-usd/discussions/3664 |
| Blender USD Import 文档（4.5 LTS） | https://docs.blender.org/manual/en/4.5/files/import_export/usd.html |
| Blender PR #110912（UsdSkel 导入实现） | https://projects.blender.org/blender/blender/pulls/110912 |
| 本分析的前置讨论 | 本会话 2026-07-09 动画分析 |   - `json.loads(arg)` 成功 → 检查 `"path"` 键（缺失返回 `EXPORT_FAILED`），提取 path + 可选 anim_config
   - Armature 对象是否正确创建
   - Armature Modifier 是否自动添加到 mesh 上
   - 骨骼朝向与 Maya 的偏差程度（截图比对）
3. 判定标准：

| 验证项 | 通过条件 | 有条件通过（标注实验性） | 失败条件 |
|--------|---------|---------------------|---------|
| Armature 对象创建 | 正常创建，层级与 Maya 一致 | 创建但有警告 | 未创建 |
| Armature Modifier | 自动添加，skinned mesh 正确变形 | 需手动添加 | 无法添加 |
| 骨骼朝向 | 与 Maya 偏差在视角可忽略范围 | 偏差明显但可手动修正 | 骨骼翻转/错位 |
| 动画播放 | 逐帧播放流畅 | 有跳帧但整体可辨认 | 无法播放 |

4. 有任一失败项 → Skeletal 模式标注为"实验性"，Cache 模式作为推荐

### 步骤 1：Blender 侧 PropertyGroup + 面板

**输入**：`__init__.py`
**输出**：面板上可见动画设置区
**操作**：
1. 在 `__init__.py` 中新增 `MBB_ANIM_CONFIG` 类（4 个属性）
2. 在 `register()` 中注册并挂到 `bpy.types.Scene`
3. 修改 `MAYA_BRIDGE_PANEL.draw()`，在 Cancel 按钮前插入折叠式 "Animation" 区
4. 测试：启动 Blender，确认面板显示新控件，默认值为 None

### 步骤 2：Blender 侧协议拼接

**输入**：步骤 1 的 PropertyGroup
**输出**：`_do_send_maya_export()` 能根据 anim_mode 选择发送旧协议纯路径或新协议 JSON 消息
**操作**：
1. 新增 `_build_export_message(temp_path, context)`：
   - `anim_mode == 'NONE'` → 返回纯文本路径（旧协议：`"C:\temp\xxx.usdc"`），与当前版本完全一致，旧版 Maya MBB 无障碍
   - `anim_mode != 'NONE'` → 返回 JSON 字符串（新协议，需新版 Maya）
   - 该函数仅返回载荷字符串，不包含 `EXPORT_SELECTED ` 前缀和换行符
2. 修改 `_do_send_maya_export()`：`payload = _build_export_message(...)` → `s.sendall(f"EXPORT_SELECTED {payload}\n"...)`
3. 逻辑：`anim_mode == 'NONE'` → 纯路径（旧协议，旧版 Maya 兼容）；`anim_mode != 'NONE'` → JSON（新协议，需新版 Maya）

### 步骤 3：Maya 侧协议解析

**输入**：MBB 协议消息（单行 JSON）
**输出**：`export_usd_from_maya` 能接收动画配置
**操作**：
1. 修改 `process_message()` 的 `export_selected` 分支：
   - 先尝试 `json.loads(arg)` 解析 → 成功则验证包含 `\"path\"` 键（缺失返回 `EXPORT_FAILED`），提取 `path` 和可选的 `anim_config`
   - `json.loads(arg)` 抛出 JSONDecodeError → `arg` 是旧协议纯路径，直接使用
2. 修改 `export_usd_from_maya` 签名，增加 `anim_config=None`

### 步骤 4：Maya 侧导出逻辑

**输入**：anim_config dict
**输出**：正确的 `mayaUSDExport` 调用
**操作**：
1. **前提**：先在 Maya 中执行 `cmds.help("mayaUSDExport")` 确认当前版本的 `frameRange` 参数格式。Maya 2024+ 支持 Python 关键字 `frameRange=(start, end)`（两个 float）；Maya 2022/2023 可能需通过 `-options` 字符串传 `startTime/endTime`
2. 在 `export_usd_from_maya` 开头解析 anim_config，按 Maya 版本选择参数格式
3. 分支：
   - `mode == 'CACHE'`：加入 `frameRange=(start, end)` + `frameStride=step`，不传 `exportSkels`/`exportSkin`
   - `mode == 'SKELETAL'`：加入 `exportSkels='auto'` + `exportSkin='auto'` + `exportBlendShapes=True` + `frameRange=(start, end)`
4. 错误处理：
   - 帧范围缺失（None）→ 自动用 `cmds.playbackOptions(q=True, min=True/max=True)` 获取
   - 帧范围无效（start > end）→ 返回 `EXPORT_FAILED` 并说明原因

### 步骤 5：端到端测试

**输入**：完整的 MBB 插件（两端更新）
**输出**：测试报告
**操作**：
1. Cache 模式：Maya 创建简单球体动画（位移关键帧），导入 Blender，验证有 Mesh Sequence Cache
2. Skeletal 模式：Maya 创建简单骨骼蒙皮动画，导入 Blender，验证有 Armature + Armature Modifier
3. None 模式（默认）：确认行为与当前版本一致
4. 帧范围自动获取：Maya 时间滑条设 10~50，面板留空，验证导出 10~50

---

## 6. 测试策略

### 测试场景

| 场景 | 操作 | 预期结果 |
|------|------|---------|
| T1：默认不动 | 不修改面板，直接 Import | 行为与 v2.0 完全一致，只导出静帧 |
| T2：Cache 模式 + 简单位移动画 | Maya 球体 1~30 帧位移，面板选 Cache，帧范围留空 | 导入 Blender 后球体有 30 帧位移动画，Mesh Sequence Cache modifier |
| T3：Cache 模式 + 蒙皮动画 | Maya 蒙皮角色走路动画，面板选 Cache，帧范围留空 | 导入后角色有动画，每帧顶点正确变形 |
| T4：Skeletal 模式 + 简单骨骼 | Maya 两节骨骼 + 蒙皮立方体 + 旋转动画，选 Skeletal | 导入后有 Armature 对象 + 立方体带 Armature Modifier，可播放骨骼动画 |
| T5：Skeletal 模式 + 复杂绑定 | Maya 多关节角色 + 控制器动画，选 Skeletal | 导入后骨骼层级基本正确，动画可播放（允许轻微的骨骼朝向偏差） |
| T6：手动帧范围 | 面板填帧范围 10~60，帧步长 2 | Maya 导出帧 10,12,14...60 |
| T7：帧范围无效 | start > end（10~1） | Maya 返回 EXPORT_FAILED，Blender 面板显示错误 |
| T8：旧版 Maya MBB | 新版 Blender（含动画面板）连接旧版 Maya MBB 服务端，发送 `EXPORT_SELECTED {\"path\":\"...\",\"anim_config\":{...}}` | 旧版 Maya `process_message` 将整个 JSON 字符串当路径传给 `export_usd_from_maya`，因路径无效返回 `EXPORT_FAILED`。此为预期行为——旧版 Maya 必须更新才能支持动画导出。新版 Maya MBB 的 `process_message` 通过 `json.loads` 分支正确解析 |
| T9：取消操作 | Cache 模式导出中途点 Cancel | 与当前 Cancel 行为一致，临时文件清理 |
| T10：高面数 Cache 压力测试（P2） | 50K+ 顶点 mesh × 100+ 帧 Cache 导出 | 导出不加时出错，内存不溢出，临时文件正常清理 |
| T11：多骨骼 Skeletal 测试（P2） | 50+ 骨骼角色动画 Skeletal 导出 | 骨骼层级完整，动画可播放 |

### 手动测试 checklist

- [ ] 面板折叠/展开正常，控件对齐
- [ ] anim_mode 切换时相关控件显示/隐藏（None 时帧范围灰掉）
- [ ] 默认值持久化（切换场景后设置保持）
- [ ] 导出完成后临时 USD 文件被 `_cleanup_temp` 清理
- [ ] Enum 值变更不触发导出（纯 UI 交互）

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| Blender 导入骨骼动画时骨骼朝向偏差 | 中 | 中 | 步骤 0 的前提验证中实测确认偏差程度；如可接受则文档说明限制，偏差超出可接受范围则 Skeletal 模式标注为"实验性"并提供回退到 Cache 模式的指引 |
| Cache 模式导出时间过长，用户以为卡死 | 中 | 低 | 在 Blender 面板显示估算帧数（只读计算：frame_end - frame_start + 1），让用户有心理预期 |
| 复杂绑定在 Skeletal 模式导出失败 | 中 | 中 | 如果 Skeletal 失败，提供一个"回退到 Cache 模式"的提示流程 |
| Maya USD 插件版本差异导致动画参数行为不一致 | 低 | 高 | 在 Maya 端增加 Maya 版本检测，不同版本走不同的参数分支（如 Maya 2023 用 `-options` 字符串格式传参）；首版仅支持 Maya 2024+ |
| 协议变更导致 Blender 新版和 Maya 旧版通信异常 | 低 | 高 | Maya 端 `process_message` 先尝试 `json.loads` 解析参数位，失败则当旧协议纯路径处理。Blender 端 \`anim_mode == 'NONE'\` 时发送纯文本路径（完全与旧协议一致），旧版 Maya \`process_message\` 的 \`json.loads\` 尝试失败后走纯路径回退分支 |

### 回退方案

- 所有动画相关改动都在 `anim_config` 这个分支内，不修改任何现有逻辑路径
- 如果出现严重问题：将 `anim_mode` 默认值锁定为 `'NONE'`，后续代码完全不执行
- Maya 端：`export_usd_from_maya` 的 `anim_config=None` 为默认值，走完全相同的旧逻辑

---

## 8. 参考

| 资料 | 链接 |
|------|------|
| Maya `mayaUSDExport` 完整参数列表 | `cmds.help("mayaUSDExport")` 在 Maya 脚本编辑器中执行 |
| Autodesk maya-usd GitHub Issue #2763（动画导出示例） | https://github.com/Autodesk/maya-usd/issues/2763 |
| Autodesk maya-usd Discussion #3664（Skin/Skel 导出约束） | https://github.com/Autodesk/maya-usd/discussions/3664 |
| Blender USD Import 文档（4.5 LTS） | https://docs.blender.org/manual/en/4.5/files/import_export/usd.html |
| Blender PR #110912（UsdSkel 导入实现） | https://projects.blender.org/blender/blender/pulls/110912 |
| 本分析的前置讨论 | 本会话 2026-07-09 动画分析 |
