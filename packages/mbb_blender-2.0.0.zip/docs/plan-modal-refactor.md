# MBB Modal Operator 改造执行计划

> 目标：解决 Import/Export 操作卡死 UI、Cancel 按钮失效的问题
> 验收人：代码审查官（agent-mpj3kvf3）

---

## 1. 问题回顾

### 现状

```
用户点击 Import → IMPORT_SELECTION_PROC.execute() 占据主线程
                   → send_to_maya() socket 阻塞等待（最长 60 秒）
                   → bpy.ops.wm.usd_import()
                   → reconstruct_materials() + _assign_by_prim_metadata()
                   → execute() 返回，事件循环恢复
```

`execute()` 返回前，Blender 的事件循环被完全阻塞。Cancel 按钮 (`CANCEL_PROC.execute()`) 依赖事件循环处理点击事件才能设置 `_cancel_flag = True`，但事件循环被 Import 占住了，所以 Cancel 按钮永远不会被处理。

**核心矛盾**：取消机制依赖它自己不能运行的事件循环。

### 同样的问题也存在于 Export

`EXPORT_SELECTION_PROC.execute()` → `bpy.ops.wm.usd_export()` + `send_to_maya()` → 同理阻塞 UI。

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| Import 操作不阻塞 UI 事件循环 | P0 | 点击 Import 后界面不冻结，可以旋转视图、切换面板 |
| Cancel 按钮在 Import 期间可点击且生效 | P0 | Import 过程中点击 Cancel，操作中止，场景回退干净 |
| Export 操作不阻塞 UI 事件循环 | P1 | 同上 |
| Cancel 按钮在 Export 期间可点击且生效 | P1 | 同上 |
| 错误处理完整（Maya 离线、超时、文件缺失） | P0 | 每种异常能正确提示用户，不留下僵尸 socket 或临时文件 |
| 现有功能不受影响 | P0 | 正常 Import/Export 结果与改造前一致 |

---

## 3. 设计方案：Modal Operator

### 3.1 核心思路

将 `IMPORT_SELECTION_PROC` 和 `EXPORT_SELECTION_PROC` 从标准 Operator（`execute()`）改为 Modal Operator（`invoke()` + `modal()` + 状态机）。

Modal Operator 通过 `modal_handler_add()` 注册到事件循环，每次 `modal()` 调用只做一小步工作后立即返回 `{'RUNNING_MODAL'}`，把控制权还给事件循环。这样 UI 在所有步骤之间都能正常响应。

关键变化：

| 项目 | 当前实现 | Modal 实现 |
|------|---------|-----------|
| 入口 | `execute()` | `invoke()` + `modal()` |
| 执行模型 | 全部在一个函数调用里完成 | 状态机，每步拆到独立的 `modal()` 调用 |
| socket 等待 | 阻塞式 recv() + 0.5s 超时循环 | 非阻塞 recv() + Timer 驱动轮询 |
| 取消机制 | `_do_send()` 内部检查 `_cancel_flag` | `modal()` 入口检查 `_cancel_flag`，立即中止 |
| 状态管理 | 无状态（局部变量） | 实例属性缓存（`self._xxx`） |
| 事件循环 | 全程阻塞 | 仅每个 micro-step 短暂占用 |
| 撤销支持 | 无显式 `bl_options` | `bl_options = {'REGISTER', 'UNDO'}` |

**`bl_options = {'REGISTER', 'UNDO'}` 是必选项**。Blender API 明确要求任何修改场景数据的 Operator 必须设置 `UNDO`，否则撤销栈会被损坏，极端情况下导致数据损坏或崩溃。Import 和 Export 都修改场景数据（创建/删除物体、材质、修改属性），两个 Operator 都要加。

**Socket connect 超时**：`connect()` 在 Maya 防火墙拦截或端口不可达时可能被 TCP 层阻塞到 OS 默认超时（Windows 可达 21 秒+）。必须在 `connect()` 前设置 socket 超时（5 秒），超时后转入 ERROR 状态。详细见 3.3 节。

### 3.2 取消机制设计

**保留全局 `_cancel_flag` 方案**，原因：
- 对现有 `CANCEL_PROC` 改动最小（只需确认其 `execute()` 在 Modal 运行时能被事件循环调度到）
- 与 Export 和 Port Test 的兼容性最好（它们也会用到取消标志）
- Compify 的模态系统中也是用类似的标记位方案

#### 取消基础机制

- `CANCEL_PROC.execute()` **不修改**——它的工作就是设 `_cancel_flag = True`
- Modal Operator 在每次 `modal()` 入口检查 `_cancel_flag`
- 检测到取消后，Modal 转入 CANCELLED / CLEAN_AFTER_CANCEL 状态，执行清理
- `_cancel_flag` 必须在 `invoke()` 第一行重置：`global _cancel_flag; _cancel_flag = False`，防止前一次操作的取消标记泄漏到下一次
- 增加 `_operation_in_progress` 互斥锁，防止导入/导出期间重复点击

#### 取消对 Maya 的通知

Blender 端取消后不能直接关闭 socket 了事——Maya 端可能正在执行 `EXPORT_SELECTED`（USD 导出写文件、收集材质元数据），Blender 突然断连可能导致 Maya 留下僵尸临时文件或处于异常状态。

**取消路径中必须主动通知 Maya**：

```
检测到 _cancel_flag
  → 发送 "CANCEL\n" 到 Maya（用现有的 socket）
  → 设置短超时 1s，等待 Maya 确认（非阻塞读取）
  → 关闭 socket
  → 清理临时文件
  → 转入 CANCELLED
```

Maya 端（`mbb_server.py`）需要增加 `CANCEL` 命令处理器：中止当前操作、清理临时文件、回复确认。由于 Maya 端不在本次改造范围，此项列为实施阶段的验证项（见风险表）。

**NOTIFY_CANCEL 的 socket 模式**：取消通知时 socket 已经被 `setblocking(False)`，要等 Maya 确认需要临时切回阻塞模式：

```
socket.setblocking(True)       # 切回阻塞
socket.settimeout(1.0)         # 1 秒超时
socket.sendall(b'CANCEL\n')    # 发送取消指令
try:
    ack = socket.recv(256)     # 等待 Maya 确认
except socket.timeout:
    pass                       # 超时未确认 → 视为已不可达，直接关闭
socket.close()
```

1 秒阻塞发生在用户已点 Cancel 之后，不影响操作体验。即使 Maya 端暂未实现 CANCEL 处理器，`sendall()` 也能正常写入 TCP 缓冲区，不会抛异常。

#### 取消后的数据一致性（关键设计决策）

当用户在以下阶段点击 Cancel，操作无法被立即中断：
- `bpy.ops.wm.usd_import()` 正在执行（已向场景写入物体）
- `reconstruct_materials()` 正在执行（已创建材质和节点树）
- `_assign_by_prim_metadata()` 正在执行（已修改材质 slot）

**决策**：这些阶段取消后**不尝试删除已导入的数据**（diff 场景物体列表再删除的实现复杂度高、边界条件多），而是返回 `{'FINISHED'}` 并让 Blender 的 UNDO 系统接管。

具体做法：
- USD 导入后检测到取消标记 → 设置 `self._cancel_after_done = True`
- 跳过后续材质重建和 prim 分配步骤
- 直接进入 `CLEAN_AFTER_CANCEL` 状态
- `CLEAN_AFTER_CANCEL` 清理 socket/timer/临时文件后，**返回 `{'FINISHED'}` 而非 `{'CANCELLED'}`**
- Blender 为 `FINISHED` + `UNDO` 创建撤销步骤，用户可按 Ctrl+Z 回退
- 报告用户："操作在导入完成后被取消，几何体已导入但材质未应用，可用 Ctrl+Z 撤销"

这样避免了三个问题：
1. 返回 `CANCELLED` 时 Blender 不创建 undo 步骤，导入的物体成为不可撤销的"幽灵物体"
2. 手动 diff 和删除物体逻辑脆弱（场景可能在导入过程中有其他变化）
3. 用户对场景状态有完全的控制权（想留就留，想撤就撤）

**Cancel 检测的实际时序**：由于 `_cancel_flag` 只在 `modal()` 入口被检查，取消信号有一个 TIMER 周期（最多 0.05s）的固有延迟。在执行阶段（USD_IMPORT / MATERIAL_RECONSTRUCT / ASSIGN_PRIM），当前步骤会完整执行完毕后，下一个步骤入口才能检测到取消标志。这符合预期——检测到的时刻比用户点击晚了一整个 modal() 周期，但不会错过检测。

建议的实现：上述三个状态的入口也先检查 `self._cancel_after_done`，如果已标记则跳过执行直接进入 `CLEAN_AFTER_CANCEL`，避免无效的材质重建或 prim 分配。

**取消边界总表**：

| Modal 所处阶段 | 取消是否生效 | 退出方式 | 清理内容 |
|---------------|------------|---------|---------|
| CLEANUP | 是 | 返回 `CANCELLED` | 无（未产生任何场景修改） |
| SEND_MAYA_EXPORT | 是 | 通知 Maya → 关闭 socket → 返回 `CANCELLED` | socket 已创建但 Maya 可能未开始处理 |
| WAIT_PROCESSING / WAIT_RESULT | 是 | 通知 Maya → 关闭 socket → 返回 `CANCELLED` | socket + 临时文件 |
| USD_IMPORT | 部分（完成后检测） | 标记 `_cancel_after_done` → 跳过后处理 → `CLEAN_AFTER_CANCEL` → 返回 `FINISHED` | 不删除已导入物体，UNDO 接管 |
| MATERIAL_RECONSTRUCT | 部分（步骤间检测） | 同上 | 已创建的材质节点树残留（UNDO 可撤销） |
| ASSIGN_PRIM | 部分（步骤间检测） | 同上 | 同上 |

### 3.3 网络通信适配

当前 `send_to_maya` / `_do_send` 使用阻塞 socket，不能在 Modal Operator 中原样使用。

改造策略：**非阻塞 socket + 状态机轮询**。

```
Modal 调用时序：

modal() call #1（Timer 触发）
  → 状态: SEND_MAYA_EXPORT
  → 创建 socket
  → socket.settimeout(5.0)     ← 先设超时（确保 connect 不会无限阻塞）
  → socket.connect((HOST, port))
  → socket.sendall(指令)
  → socket.setblocking(False)  ← connect 成功后切非阻塞
  → 记录 self._start_time = time.time()
  → 转入 WAIT_PROCESSING
  → return {'RUNNING_MODAL'}

modal() call #2（0.05s 后）
  → 检查 _cancel_flag → 若已取消则转入 CANCELLED
  → 状态: WAIT_PROCESSING
  → try: self._socket.recv(8192)  ← 用 8192 而非 256
  → BlockingIOError → 还没收到，return {'RUNNING_MODAL'}
  → 收到 "PROCESSING" → 转入 WAIT_RESULT

modal() call #3 ~ #N
  → 同上，尝试 recv(8192) 积累数据
  → 收到 '\n' 终止符 → 关闭 socket → 转入 PARSE_RESPONSE

modal() call #N+1
  → 解析响应 → 转入 USD_IMPORT
  → 执行 bpy.ops.wm.usd_import()（短暂阻塞）
  → 转入 MATERIAL_RECONSTRUCT 或 ASSIGN_PRIM
```

**socket 生命周期**：
- 创建：在首个涉及网络的 state 中完成 connect 和 sendall
- 保持：作为 `self._socket` 实例属性跨 state 保持
- 关闭：在进入非网络 state 后立即关闭（`self._socket.close()`），或在 CANCELLED/ERROR 清理时
- 取消路径中：先发 `CANCEL` 命令再关闭（见 3.2 节）

**timeout 处理**：
- 连接超时：`s.settimeout(5.0)` 在 `connect()` 前设置，确保 5 秒内连接不上则抛出异常 → 转入 ERROR
- 总超时 60 秒：`self._start_time` 在 socket 创建时记录，每次 `modal()` 检查 `time.time() - self._start_time > 60`
- 阶段超时：PROCESSING 阶段 5 秒（用 `self._processing_start` 跟踪）
- 非阻塞 socket 无需设置 socket 级 timeout（连接已建立后），超时由 `modal()` 中的时间检查控制

**recv 缓冲区大小**：使用 8192（与原 `_do_send` 一致），确保本地回环下可在一次 recv 调用中拿到完整响应，减少轮询次数。

**取消通知协议**：取消路径中通过现有 socket 发送 `CANCEL\n`，等待 1 秒确认后再关闭。Maya 端需新增 CANCEL 命令处理器。

### 3.4 Timer 注册

```python
def invoke(self, context, event):
    # ... 初始化状态 ...
    wm = context.window_manager
    self._timer = wm.event_timer_add(0.05, window=context.window)
    wm.modal_handler_add(self)
    return {'RUNNING_MODAL'}

def modal(self, context, event):
    if event.type != 'TIMER':
        return {'PASS_THROUGH'}
    # ... 状态机调度 ...
```

**Timer 间隔为什么选 0.05 秒**：
- 0.05s（50ms）在人类感知阈值以下，UI 响应感觉是即时的
- Compify 模态烘焙也使用 0.05s
- 对 socket 轮询而言，50ms 粒度意味着取消延迟最坏情况 ~100ms（一次错过 + 下一次），体验更好
- `modal()` 在 WAIT_PROCESSING / WAIT_RESULT 阶段几乎空转（一次非阻塞 recv 调用），CPU 开销可忽略

**清理保护**：退出路径中 `self._timer` 需加 None 检查：

```python
if self._timer:
    wm.event_timer_remove(self._timer)
    self._timer = None
```

`invoke()` 中的异常路径也要确保不会引用未赋值的 `self._timer`。

### 3.5 Context 缓存

Compify 的经验教训：在模态操作中，长时间运行后 `context` 参数可能失效，`bpy.context` 在不同窗口之间切换时可能指向与 Modal 启动时不一致的上下文。关键数据必须在进入模态循环前缓存。

```python
def invoke(self, context, event):
    # 常规配置
    self._port = context.scene.mbb_config.connection_port
    self._prefs = bpy.context.preferences.addons[__name__].preferences
    self._temp_work_dir = self._prefs.temp_work_dir
    
    # 场景引用（防止 bpy.context.session 在 Modal 期间漂移）
    self._scene = context.scene
    
    # 导入/导出时的选中物体列表快照
    self._selected_objects = list(context.selected_objects)
    # ...
```

**`_scene` 引用的用途**：后续材质分配阶段（`assign_material_to_objects`、`_assign_by_prim_metadata`）需要遍历场景物体，使用 `self._scene.objects` 而非 `bpy.context.scene.objects`，避免因用户切换窗口导致的上下文不一致。

**注意**：某些 Blender API 调用（如 `bpy.context.selected_objects`）依赖当前上下文，在 Modal 的 `modal()` 方法中通过 `event` 参数获取的上下文最可靠。`bpy.context` 的稳定性需在实施阶段实际验证。

---

## 4. 状态机详细设计

### 4.1 IMPORT_SELECTION_PROC 状态机

```
  ┌──────────────────────────────────────────────────────────┐
  │ bl_options = {'REGISTER', 'UNDO'}                        │
  └──────────────────────────────────────────────────────────┘

INIT
  │  初始化、缓存 context、重置 _cancel_flag
  │  检查 _operation_in_progress（已有操作则返回 CANCELLED）
  │  设置 _operation_in_progress = True
  │  注册 timer、注册 modal handler
  ▼
CLEANUP ────────────────────────── cancel ──→ CANCELLED(#1)
  │  清理旧临时文件
  │  生成 temp_usd_path 和时间戳文件名
  ▼
SEND_MAYA_EXPORT ──────────────── cancel ──→ NOTIFY_CANCEL(#2)
  │  创建 socket
  │  socket.settimeout(5.0) ← 连接超时保护
  │  socket.connect((HOST, port))
  │  socket.sendall(指令)                                        
  │  记录 self._start_time
  │  socket.setblocking(False)  ← 连接成功后切非阻塞
  │── socket.connect 失败 ──→ ERROR(#10)
  ▼
WAIT_PROCESSING ──────────────── cancel ──→ NOTIFY_CANCEL(#2)
  │  非阻塞 recv(8192) 等 "PROCESSING"
  │── 超时 5s ──→ ERROR(#10)
  │── socket 异常 ──→ ERROR(#10)
  ▼
WAIT_RESULT ────────────────── cancel ──→ NOTIFY_CANCEL(#2)
  │  非阻塞 recv(8192) 积累数据，直到 '\n'
  │── 超时 60s ──→ ERROR(#10)
  │── socket 异常 ──→ ERROR(#10)
  ▼
PARSE_RESPONSE
  │  parse_response() 提取 usd_path / json_path / use_usd_materials
  │  关闭 socket
  │── parse 失败 ──→ ERROR(#10)
  ▼
┌────────────────────────────────────────────────┐
│  执行阶段（以下步骤完成后检查 _cancel_flag）      │
└────────────────────────────────────────────────┘

USD_IMPORT ──────── 完成后检测取消 ──→ CLEAN_AFTER_CANCEL(#3)
  │  bpy.ops.wm.usd_import()
  │  执行后检查 self._cancel_after_done
  │── 导入异常 ──→ ERROR(#10)
  ▼
MATERIAL_RECONSTRUCT ── 完成后检测取消 ──→ CLEAN_AFTER_CANCEL(#3)
  │  reconstruct_materials(json_path)  (仅 Arnold 模式)
  │  执行后检查 self._cancel_after_done
  │── 执行异常 ──→ ERROR(#10)
  ▼
ASSIGN_PRIM ────── 完成后检测取消 ──→ CLEAN_AFTER_CANCEL(#3)
  │  _assign_by_prim_metadata(temp_usd_path)
  │  执行后检查 self._cancel_after_done
  │── 执行异常（当前代码内部 try/except 吃掉异常）─→ 记录日志，仍继续
  ▼
FINISHED
  │  移除 timer，释放 _operation_in_progress
  │  report SUCCESS
  │  return {'FINISHED'}

╔══════════════════════════════════════════════════════╗
║                    退出路径                          ║
╚══════════════════════════════════════════════════════╝

#1 CANCELLED — 未产生任何场景修改的取消
  │  清除临时文件（若已生成）
  │  移除 timer，释放 _operation_in_progress
  │  report "操作已取消"
  │  return {'CANCELLED'}

#2 NOTIFY_CANCEL — 网络阶段的取消
  │  向 Maya 发送 "CANCEL\n"（通过现有 socket）
  │  socket.settimeout(1.0)，等待确认
  │  关闭 socket
  │  清除临时文件
  │  移除 timer，释放 _operation_in_progress
  │  report "操作已取消"
  │  return {'CANCELLED'}

#3 CLEAN_AFTER_CANCEL — 已修改场景数据后的取消
  │  场景已被 bpy.ops.wm.usd_import() 修改
  │  关闭 socket（若未关闭）
  │  清除临时文件
  │  移除 timer，释放 _operation_in_progress
  │  report "操作在导入完成后被取消，几何体已导入但材质未应用，可用 Ctrl+Z 撤销"
  │  return {'FINISHED'}  ← 关键：返回 FINISHED 让 UNDO 创建撤销步骤

#10 ERROR — 异常退出
  │  关闭 socket（若有）
  │  清除临时文件
  │  移除 timer，释放 _operation_in_progress
  │  report ERROR 详情
  │  return {'CANCELLED'}
```

**每个 state 的可取消性和清理动作汇总**：

| 状态 | 用户可取消？ | 取消后调用 | 需要特别清理 |
|------|------------|-----------|-------------|
| INIT | — | — | 不适用 |
| CLEANUP | 是 | #1 CANCELLED | 无（尚未产生副作用） |
| SEND_MAYA_EXPORT | 是 | #2 NOTIFY_CANCEL | socket 已创建，需先通知 Maya 再关闭 |
| WAIT_PROCESSING | 是 | #2 NOTIFY_CANCEL | socket 保持中，需通知 Maya |
| WAIT_RESULT | 是 | #2 NOTIFY_CANCEL | socket 保持中，可能已有部分数据 |
| PARSE_RESPONSE | 否（瞬间完成） | #10 ERROR 处理解析异常 | 无 |
| USD_IMPORT | 执行完成后检测 | #3 CLEAN_AFTER_CANCEL | 场景已改，UNDO 接管 |
| MATERIAL_RECONSTRUCT | 步骤间检测 | #3 CLEAN_AFTER_CANCEL | 材质节点树已创建，UNDO 接管 |
| ASSIGN_PRIM | 步骤间检测 | #3 CLEAN_AFTER_CANCEL | 材质 slot 已分配，UNDO 接管 |

### 4.2 EXPORT_SELECTION_PROC 状态机

```
  ┌──────────────────────────────────────────────────────────┐
  │ bl_options = {'REGISTER', 'UNDO'}                        │
  └──────────────────────────────────────────────────────────┘

INIT
  │  初始化、缓存 context、重置 _cancel_flag
  │  检查 _operation_in_progress
  │  设置 _operation_in_progress = True
  │  注册 timer、注册 modal handler
  ▼
CLEANUP ────────────────────────── cancel ──→ CANCELLED(#1)
  │  清理旧临时文件
  │  生成时间戳文件名（仅命名，不创建文件）
  ▼
USD_EXPORT ──────────────────── cancel(完成后检测) ──→ CANCELLED
  │  bpy.ops.wm.usd_export()
  │  导出选中的 Blender 物体为 .usdc
  │── 导出失败 ──→ ERROR(#10)
  ▼
SEND_MAYA_IMPORT ───────────── cancel ──→ NOTIFY_CANCEL(#2)
  │  创建 socket、connect、send IMPORT_USD 指令
  │  socket.setblocking(False)
  │── connect 失败 ──→ ERROR(#10)
  ▼
WAIT_PROCESSING ────────────── cancel ──→ NOTIFY_CANCEL(#2)
  │  非阻塞 recv(8192) 等 "PROCESSING"
  │── 超时 5s ──→ ERROR(#10)
  ▼
WAIT_RESULT ────────────────── cancel ──→ NOTIFY_CANCEL(#2)
  │  非阻塞 recv(8192) 等最终结果
  │── 超时 60s ──→ ERROR(#10)
  ▼
FINISHED
  │  移除 timer，释放 _operation_in_progress
  │  report SUCCESS
  │  return {'FINISHED'}

── 退出路径与 Import 一致（见 4.1 节 #1/#2/#10）──
```

注意：Export 的 `USD_EXPORT` 阶段取消后不需要 `CLEAN_AFTER_CANCEL` 路径，因为 `bpy.ops.wm.usd_export()` 写入的是临时文件（不在场景中），取消后清理临时文件即可。

### 4.3 CANCEL_PROC

**不修改** `CANCEL_PROC.execute()` 的代码逻辑（仍然设置 `_cancel_flag = True`）。但以下两点需要补充：

1. **`_operation_in_progress` 检查（可选增强）**：如果用户在无操作进行时误点 Cancel，`_cancel_flag` 被设为 True 但没有任何 Modal 在运行。下一次 Import 的 `invoke()` 第一行已经重置了 `_cancel_flag = False`，所以不会误拦截。仍按"不改逻辑"处理。

2. **`_cancel_flag` 在 `invoke()` 中重置**：在 Modal Operator 的 `invoke()` 第一行：

```python
def invoke(self, context, event):
    global _cancel_flag
    _cancel_flag = False  # 清空前一次操作的取消标记
    # ...
```

取消的含义扩展：

| Modal 所处阶段 | 取消是否生效 | 退出方式 | 关键清理 |
|---------------|------------|---------|---------|
| CLEANUP | 是 | 返回 `CANCELLED` | 无 |
| SEND_MAYA_EXPORT → WAIT_RESULT | 是 | 通知 Maya → 关闭 socket → 返回 `CANCELLED` | Maya 端 cancel 处理（需验证） |
| USD_IMPORT → ASSIGN_PRIM | 步骤间检测 | 标记 → 跳过后续 → `CLEAN_AFTER_CANCEL` → 返回 `FINISHED` | UNDO 接管 |

### 4.4 互斥保护

防止 Import 和 Export 同时运行（使用同一 socket 端口和临时目录会产生冲突）：

**统一的 `_cleanup()` 方法**：所有退出路径（CANCELLED / NOTIFY_CANCEL / CLEAN_AFTER_CANCEL / ERROR）都应通过一个统一的 `_cleanup()` 方法释放资源，避免遗漏。`_cleanup()` 设计为幂等的，每个资源做了 None 检查或标志检查，可安全地多次调用。职责清单：

```python
def _cleanup(self, context):
    """统一清理。幂等设计，可多次安全调用。"""
    wm = context.window_manager
    # 1. 移除 timer
    if self._timer:
        try:
            wm.event_timer_remove(self._timer)
        except RuntimeError:
            pass
        self._timer = None

    # 2. 关闭 socket
    if self._socket:
        try:
            self._socket.close()
        except OSError:
            pass
        self._socket = None

    # 3. 清理临时文件
    if self._temp_usd_path and os.path.exists(self._temp_usd_path):
        try:
            os.remove(self._temp_usd_path)
        except OSError:
            pass

    # 4. 释放互斥锁
    global _operation_in_progress
    if _operation_in_progress:
        _operation_in_progress = False
```

```python
# 全局互斥锁
_operation_in_progress = False

# Modal invoke() 入口检查
if _operation_in_progress:
    self.report({'WARNING'}, "已有操作在进行中")
    return {'CANCELLED'}
_operation_in_progress = True

# 初始化语句（timer 注册等）
try:
    wm = context.window_manager
    self._timer = wm.event_timer_add(0.05, window=context.window)
    wm.modal_handler_add(self)
except Exception:
    _operation_in_progress = False  # 初始化失败时必须释放锁
    raise

# 所有退出点（FINISHED / CANCELLED / ERROR）都必须释放
# 放在 _cleanup() 中统一执行
```

**安全要点**：
- `_operation_in_progress = True` 必须在任何可能失败的操作之前设置
- `try/except` 包裹初始化语句，确保异常时锁被释放
- 所有退出路径集中到 `_cleanup()` 方法中统一释放，避免遗漏

**限制**：如果用户有多个 Blender 窗口或 Area，互斥锁基于进程内全局变量，对于同一 Blender 实例的所有窗口有效（这是正确的——socket 端口和临时目录是进程级的资源）。不同 Blender 实例不受此限制。

---

## 5. 涉及的文件和改动范围

### 5.1 只涉及一个文件

`__init__.py` — 所有改动都在此文件中。

### 5.2 具体改动点

| 改动 | 类型 | 说明 |
|------|------|------|
| 新增 `_operation_in_progress` | 全局变量 | Import/Export 互斥锁 |
| `IMPORT_SELECTION_PROC` | **重写** | 从 `execute()` 改为 `invoke()` + `modal()` + 状态机 |
| `EXPORT_SELECTION_PROC` | **重写** | 同上 |
| `CANCEL_PROC` | 检查确认 | 逻辑不变（设 `_cancel_flag = True`），需验证 `execute()` 在 Modal 运行期间能被调度 |
| `MAYA_BRIDGE_PANEL.draw()` | 可选优化 | 条件显示 Cancel 按钮（仅在操作进行中时显示） |
| `send_to_maya()` | **重写** | 仅保留 `PING` 快捷路径（3s timeout 阻塞调用），移除耗时命令的支持 |
| `_do_send()` | **重写** | 精简为只处理 PING。耗时命令的 socket 操作移入 Modal Operator |
| `mbb_server.py`（Maya 端） | **新增 CANCEL 命令处理器** | 可选但推荐。Blender 发送 `CANCEL` 后 Maya 立即中止操作、清理临时文件、回复确认。如果暂不改 Maya 端，风险表中标注已验证断连行为 |

### 5.3 不需要改动的

- `parse_response()` — 纯解析函数，独立于执行模型
- `reconstruct_materials()` — 纯材质处理，调用方式不变
- `_assign_by_prim_metadata()` — 纯分配逻辑，调用方式不变
- `_assign_mat()` / `assign_material_to_objects()` / `_get_faces()` / `_object_to_path()` — 辅助函数
- `_cleanup_temp()` — 清理逻辑不变
- `MBB_CONFIG` / `MBB_ADDON_PREF` — 属性组不涉及执行模型
- `PORT_TEST_PROC` — PING 仍然是快速操作，不需要 Modal
- Maya 端 `mbb_server.py` — 协议不变，服务器端无需修改（CANCEL 命令作为可选增强，如果暂不改需确保断连处理正确）

---

## 6. 实现步骤（按执行顺序）

### Step 1：准备全局变量

添加 `_operation_in_progress` 互斥锁。

### Step 2：重构 send_to_maya / _do_send

- 将 `_do_send` 中的轮询逻辑提取出来
- 保留 `PING` 的简单路径（3 秒 timeout 的阻塞调用）
- 耗时命令（IMPORT_USD / EXPORT_SELECTED）的 socket 创建和发送逻辑提炼为可被 Modal 逐段调用的方法
- 移除 `_do_send` 中的 `_cancel_flag` 检查和超时逻辑（这些由 Modal Operator 管理）

### Step 3：重写 IMPORT_SELECTION_PROC

- 添加 `invoke()` 方法：缓存 context 数据、注册 timer、注册 modal handler
- 添加 `modal()` 方法：Timer 事件过滤、取消标志检查、状态机调度
- 实现状态机方法 `_state_machine(context)`
- 实现各个状态的执行方法 (`_do_cleanup()`, `_do_send_maya_export()`, `_do_wait_processing()`, ...)
- 实现清理方法 `_cleanup()`
- 实现 `CANCELLED` / `ERROR` 路径

### Step 4：重写 EXPORT_SELECTION_PROC

- 与 Step 3 相同的模式，状态机略简单（没有 material_reconstruct 等步骤）

### Step 5：验证 CANCEL_PROC

- 在 Import/Export Modal 正在运行时手动验证 Cancel 按钮可点击
- 验证取消后场景状态正确（无残留物体、无僵尸 socket、临时文件已清理）

### Step 6：面板 UI 优化（可选）

- 在 `MAYA_BRIDGE_PANEL.draw()` 中根据 `_operation_in_progress` 状态，条件显示 Cancel 按钮或改变 Import/Export 按钮状态

---

## 7. 测试策略

### 7.1 单元测试项

| 测试场景 | 操作 | 预期结果 |
|---------|------|---------|
| 正常 Import | 选择 Maya 物体 → 点 Import | 物体导入 Blender，材质正确，UI 全程不卡 |
| Import 中途点 Cancel（网络阶段） | Import 进行中（等待 Maya）→ 点 Cancel | 操作中止，无残留物体/文件，Maya 收到 CANCEL |
| Import 中途点 Cancel（导入阶段） | USD 导入进行中 → 点 Cancel | 导入完成后停止，返回 FINISHED，场景可 Ctrl+Z 撤销 |
| Import 超时 | Maya 不响应 → 等 60s | 显示超时提示，清理临时文件 |
| Maya 离线时点 Import | Maya 未启动 → 点 Import | 连接失败提示（≤5s），不卡 UI |
| Maya 崩溃后点 Import | Maya 运行中崩溃 → 点 Import | socket 异常处理，清理临时文件 |
| 正常 Export | 选择 Blender 物体 → 点 Export | 物体在 Maya 中出现，UI 全程不卡 |
| Export 中途点 Cancel | Export 进行中 → 点 Cancel | 操作中止，清理临时文件 |
| 连续点两次 Import | 迅速点两次 Import | 第二次被拦截，"已有操作在进行"提示 |
| Import → Cancel → 立即再 Import | Cancel 后马上再点 Import | 第二次 Import 正常执行（_cancel_flag 已重置） |
| Port Test | 点 Port Test | 不受 Modal 改造影响，正常工作 |
| 插件在 Modal 运行中被禁用 | Import 进行中 → 在插件设置中禁用插件 | 下次启用插件后无僵尸 timer/socket |
| 超大数据集 Import Cancel | 100+ 物体的场景 Import → 中途 Cancel | Cancel 响应及时，场景干净 |

### 7.2 手动测试 checklist

- [ ] Import 操作中能否旋转 3D 视图
- [ ] Import 操作中能否切换 Blender 标签页
- [ ] Cancel 按钮在 Import 过程中是否可点
- [ ] Cancel 后 Maya 的操作是否被正确通知（服务器端日志检查）
- [ ] 多次 Import-Cancel-Import 循环，场景和临时目录无泄漏
- [ ] Cancel 后 USD_IMPORT/CLEAN_AFTER_CANCEL 状态下是否可按 Ctrl+Z 撤销
- [ ] Arnold 模式材质重建是否正常
- [ ] UsdPreviewSurface 模式材质导入是否正常
- [ ] 大场景（多物体、多材质）的 Import 响应
- [ ] Maya 未启动时点 Import，5 秒内提示错误

---

## 8. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| socket 在跨 state 中泄漏 | 中 | 高 | 每个退出路径都显式 `socket.close()` + `self._socket = None` |
| Timer 未正确移除导致持续空跑 | 低 | 中 | 每个退出路径 `wm.event_timer_remove(self._timer)` 加 None 检查 |
| bpy.ops.wm.usd_import() 在大文件时自身卡顿 | 中 | 中 | 文档说明此阶段短暂阻塞无法避免，但网络等待阶段已解卡 |
| Maya 端协议不兼容 | 低 | 高 | Maya 端不修改，但取消通知新增 CANCEL 命令需验证 Maya 服务端能正确处理断连 |
| Modal 初始化异常时 `_operation_in_progress` 泄漏 | 低 | 中 | try/except 包裹初始化语句，确保异常时锁释放 |
| ERROR 在场景已修改后返回 CANCELLED（undo 不可用） | 低 | 低 | 现有行为保持。如果要细化，可在实现时按阶段区分返回值：网络阶段 ERROR → CANCELLED，执行阶段 ERROR → FINISHED（UNDO 接管） |
| **取消时 Maya 端未收到通知** | 中 | 中 | **新增风险**。Blender 端取消后发 CANCEL 指令，但 Maya 端 `mbb_server.py` 当前可能未处理此命令。实施阶段必须：1) 验证 Maya 端的断连行为；2) 如果 Maya 端需新增 CANCEL 处理器，将其纳入本次改造范围的备选方案 |
| Context 在长时间 Modal 后过期 | 低 | 中 | invoke() 中缓存 `self._scene` 等关键引用，modal() 中使用缓存的引用 |
| `_cancel_flag` 泄漏到下一次操作 | 低 | 中 | invoke() 第一行重置 `_cancel_flag = False` |

### 回退方案

如果 Modal 改造出现问题，只需：
1. 注释或删除新增的 Modal Operator 类
2. 取消注释旧的 `execute()` 实现
3. 恢复 `send_to_maya()` / `_do_send()` 的原代码
4. 重新注册插件

所有改动集中在一个文件，回退代价低。

---

## 9. 参考

- Blender 官方文档：[Modal Operator](https://docs.blender.org/api/current/bpy.types.Operator.html#modal-execution)
- Compify 模态烘焙模式：`Dev/compify/04-技术笔记/光照烘焙实现细节.md` — Timer + 状态标志 + 清理模式
- 本文件路径：`plan-mbb-modal-refactor.md`
