# MBB 引用资产材质重复创建 Bug 修复计划

## 1. 问题回顾

### 当前现状

MBB 的材质链路涉及四个命名节点：

```
Maya SG 名 ──→ JSON key ──→ Blender USD 导入材质名 ──→ Blender 重建材质名
```

在 Maya 引用资产场景下，SG 名含命名空间冒号（如 `Rig33:FBXASC...SG`）。链路中三个节点各自对冒号做了不同处理：

| 节点 | 名字格式 | 冒号 |
|------|----------|------|
| Maya SG 名 | `Rig33:FBXASC...SG` | `:` |
| JSON key（collect_material_metadata） | `Rig33:FBXASC...SG` | `:` |
| USD 材质 prim 名（mayaUSDExport 自动生成） | `Rig33_FBXASC...SG` | `_` |
| Blender USD 导入后材质名 | `Rig33_FBXASC...SG` | `_` |
| Blender 重建材质名（reconstruct_materials） | `Rig33:FBXASC...SG` | `:` |

JSON key 与 Blender 中存在的材质名不一致，导致 `bpy.data.materials.get()` 找不到已有材质，每个引用材质被创建了两次：一次是 USD 导入器创建的空壳 UsdPreviewSurface，一次是 metadata JSON 重建的完整 Principled BSDF。

### 核心矛盾

**Maya 端和 Blender 端对同一个"材质身份"使用了不同的命名规则**（一个保留冒号，一个用下划线），且没有任何环节做归一化桥接。`_write_prim_material_markers` 原本是第二道防线（通过 prim 自定义数据绑定材质名），但在引用资产场景下完全失效。

### 为什么部分材质"看起来正常"

所有引用材质都产生了重复。单材质物体的空壳版本 users=0 不挂在任何物体上，肉眼不可见。面级多材质物体的空壳版本因为分配逻辑竞争，部分面挂到了空壳上，才暴露问题。

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| 消除引用资产导入后的重复材质球 | P0 | 引用场景导入后，每类材质只有一个数据块，有完整的节点树和贴图 |
| 面级多材质物体正确显示所有面 | P0 | `b` 物体的所有面使用正确材质，无全黑面 |
| Maya 端源头归一化命名 | P1 | JSON key 和 USD 材质 prim 名使用相同的命名规则 |
| 恢复 prim marker 机制 | P1 | USD 文件中 mbb_material 自定义数据非空，`_assign_by_prim_metadata` 可正常工作 |
| 统一 Maya 端路径转换 | P2 | 所有生成 USD prim 路径的代码使用同一个函数 |

---

## 3. 设计方案

### 核心思路：源头归一化 + 消费者兼容

**方案选择**：在 Maya 端做冒号→下划线替换（源头归一化），同时在 Blender 端加上变体查找（消费者兼容）。

为什么不在 Blender 端单向修复：

- 只在 `reconstruct_materials()` 中加变体查找可以立即消除重复材质球，但 JSON key 和 prim marker 仍然不一致，`_assign_by_prim_metadata` 第二道防线无法恢复
- 在 Maya 端源头归一化后，JSON key、USD prim 名、Blender 导入材质名全部一致，消除整条链路的名字分歧
- Blender 端的变体查找作为防御性措施保留，处理历史遗留 JSON 或未来可能的命名差异

### 关键设计决策

**D1：归一化方向选择 `:` → `_` 而非反向**

Maya USD 导出器（`mayaUSDExport`）的行为不可控，它会自动替换冒号。反过来要求它不替换做不到。所以只能让自己的代码向 USD 规范对齐。

**D2：在 `collect_material_metadata()` 中归一化，而非 `export_usd_from_maya()` 中后处理**

早归一化 > 晚归一化。在数据采集时就把名字定好，后续所有环节（copy_texture_files、write_material_json、_write_prim_material_markers）拿到就是正确的名字。

**D3：Blender 端做防御性变体查找**

处理两种情况：
1. 历史遗留 JSON（未归一化的冒号版名字）
2. 非引用资产的 SG 名不含冒号，`replace(':', '_')` 是空操作，不产生负面影响

**D4：`_write_prim_material_markers` 改用 stage 遍历 fallback**

不再依赖 `GetPrimAtPath` 做精确路径匹配（引用资产下不可靠），改为先尝试精确匹配，失败后遍历 stage 所有 prim 做叶子名匹配。

---

## 4. 详细设计

### 4.1 涉及的文件

| 文件 | 改动范围 |
|------|----------|
| `mbb_maya/mbb_server.py` | `collect_material_metadata()` 材质名归一化 + 对象路径归一化；新增 `_maya_dag_to_usd_prim_path()` 工具函数；`_write_prim_material_markers()` prim 查找改写；`_write_prim_material_markers()` 使用统一函数 |
| `__init__.py` | `reconstruct_materials()` 增加变体查找；`assign_material_to_objects()` 可选接受 scene 参数 |

### 4.2 Maya 端：新增统一路径转换函数

```python
def _maya_dag_to_usd_prim_path(maya_long_name):
    """将 Maya DAG 长名转换为 USD prim 路径。

    行为与 mayaUSDExport 内部转换一致：
    - 去掉前导 | 
    - 用 / 替换路径分隔符
    - 用 _ 替换命名空间冒号
    - 末段如果是 Shape 节点则去掉
    """
    path = '/' + maya_long_name.lstrip('|').replace('|', '/').replace(':', '_')
    parts = path.rsplit('/', 1)
    if len(parts) == 2 and 'Shape' in parts[1]:
        path = parts[0]
    return path


def _normalize_material_name(sg_name):
    """将 Maya SG 名转换为与 USD 材质 prim 一致的名称。"""
    return sg_name.replace(':', '_')
```

### 4.3 Maya 端：collect_material_metadata 改动

**改动点 1**：第 163 行

```python
# 当前
mat_name = sg

# 改为
mat_name = _normalize_material_name(sg)
```

**改动点 2**：第 220-228 行（对象路径构造）

```python
# 当前
long_name = cmds.ls(tf_name, long=True)
if long_name:
    path = '/' + long_name[0].lstrip('|').replace('|', '/')
    ...

# 改为
long_name = cmds.ls(tf_name, long=True)
if long_name:
    path = _maya_dag_to_usd_prim_path(long_name[0])
    ...
```

### 4.4 Maya 端：_write_prim_material_markers 改动

**改动点 1**：材质名归一化

```python
# 当前
mat_name = sg

# 改为
mat_name = _normalize_material_name(sg)
```

**改动点 2**：prim 路径构造使用统一函数

```python
# 当前
usd_path_str = '/' + full_path[0].lstrip('|').replace('|', '/').replace(':', '_')

# 改为
usd_path_str = _maya_dag_to_usd_prim_path(full_path[0])
```

**改动点 3**：增加叶子名 fallback 查找

预建叶子名→prim 字典（一次遍历 O(n)），精确匹配失败时 O(1) 查找。检测同名冲突时打日志。

```python
# 预建字典
leaf_to_prim = {}
for p in stage.Traverse():
    name = p.GetName()
    if name in leaf_to_prim:
        log(f"⚠ 叶子名冲突: {name} ({leaf_to_prim[name].GetPath()} vs {p.GetPath()})")
    else:
        leaf_to_prim[name] = p

# Fallback 查找
if not prim or not prim.IsValid():
    leaf_name = usd_path_str.rsplit('/', 1)[-1]
    prim = leaf_to_prim.get(leaf_name)
```

**改动点 4**：写入后确保持久化

```python
# 当前
layer.Save()

# 改为
stage.GetRootLayer().Save()
```

**改动点 5**：删除无效参数

```python
# 当前
def _write_prim_material_markers(usd_path, selected_objects=None):

# 改为
def _write_prim_material_markers(usd_path):
```

调用方 `export_usd_from_maya()` 中同步更新。

### 4.5 Blender 端：reconstruct_materials 改动

**改动点**：第 1008-1010 行，增加变体查找

```python
# 当前
mat = bpy.data.materials.get(mat_name)
if mat is None:
    mat = bpy.data.materials.new(name=mat_name)

# 改为
mat = bpy.data.materials.get(mat_name)
if mat is None:
    alt_name = mat_name.replace(':', '_')
    mat = bpy.data.materials.get(alt_name)
    if mat is not None:
        mat.name = mat_name
if mat is None:
    mat = bpy.data.materials.new(name=mat_name)
```

### 4.6 Blender 端：reconstruct_materials 和 assign_material_to_objects 改动（可选 P3）

调用链：`_do_material_reconstruct()`（持有 `self._scene`）→ `reconstruct_materials()` → `assign_material_to_objects()`。

```python
# reconstruct_materials 增加 scene 参数
def reconstruct_materials(json_path, scene=None):
    ...
    assign_material_to_objects(mat, target_objects, face_map, scene=scene)

# assign_material_to_objects 增加 scene 参数
def assign_material_to_objects(material, target_names=None, face_map=None, scene=None):
    target_scene = scene if scene is not None else bpy.context.scene
    for obj in target_scene.objects:
        ...
```

调用方 `_do_material_reconstruct()` 中传入 `self._scene`。

### 4.7 不需要改动的部分

- `detect_material_types()` — 不涉及命名
- `copy_texture_files()` — 只处理文件路径，不处理材质名
- `write_material_json()` — 只做序列化，数据来源已在上游归一化
- Blender 端 `_assign_by_prim_metadata()` — 修复 marker 写入后自动恢复功能
- Blender 端 `_object_to_path()` — Blender 内部路径构造，不涉及 Maya 命名空间
- UDIM 相关逻辑 — 不涉及命名空间问题

---

## 5. 实现步骤

### Step 1：Maya 端新增工具函数（5 分钟）

文件：`mbb_maya/mbb_server.py`

在文件顶部（`detect_material_types` 之前）添加 `_maya_dag_to_usd_prim_path()` 和 `_normalize_material_name()`。

输出：两个可复用的工具函数。

### Step 2：Maya 端 collect_material_metadata 归一化（5 分钟）

文件：`mbb_maya/mbb_server.py`

- 材质名：`mat_name = _normalize_material_name(sg)`
- 对象路径：使用 `_maya_dag_to_usd_prim_path(long_name[0])`

输出：JSON 中所有材质名和路径与 USD 格式一致。

### Step 3：Maya 端 _write_prim_material_markers 修复（15 分钟）

文件：`mbb_maya/mbb_server.py`

- 材质名归一化
- prim 路径使用统一函数
- 增加叶子名 fallback
- `layer.Save()` → `stage.GetRootLayer().Save()`
- 删除死参数

输出：USD 文件中 mbb_material 标记正确写入。

### Step 4：Blender 端 reconstruct_materials 防御性变体查找（5 分钟）

文件：`__init__.py`

- 增加 `:` → `_` 变体查找

输出：历史 JSON 和未来 JSON 都能正确匹配材质。

### Step 5：Maya 端同步回 mbb_maya 目录（1 分钟）

将修改后的 `mbb_server.py` 同步到 Maya 插件加载路径：
`C:\Users\Administrator\Documents\maya\2025\plug-ins\mbb_server.py`

### Step 6：测试验证（15 分钟）

见测试策略章节。

---

## 6. 测试策略

### 测试场景

| 场景 | 预期结果 | 验证方法 |
|------|----------|----------|
| 引用资产场景导入（原始 Bug 场景） | 每个材质只有一个数据块，有完整节点树，`b` 物体所有面正常 | Blender 材质列表检查 + 视口截图 |
| 双命名空间嵌套引用 | 多段冒号（`NS1:NS2:Object`）全部替换为下划线，不产生重复 | 验证 `replace(':', '_')` 对任意数量冒号正确 |
| 原资产直接导入（非引用） | 行为不变，材质正常显示 | Blender 材质列表检查 |
| 面级多材质物体 | 每个面的材质对应正确，无全黑面 | 视口逐面检查 |
| 单材质物体 | 材质正确显示 | 视口检查 |
| UDIM 贴图材质 | 贴图加载正常 | 节点编辑器检查 |
| 历史遗留 JSON（含冒号 key） | 变体查找命中，不产生重复 | 用旧 JSON 文件测试 |
| 大型场景 leaf fallback 性能 | 不出现明显卡顿 | 百级以上 prim 场景导入时间可接受 |

### 验证脚本（Blender 端）

```python
import bpy

# 重复检测：同类型材质是否出现两次（冒号版 + 下划线版）
names = [m.name for m in bpy.data.materials]
pairs = {}
for n in names:
    base = n.replace(':', '_')
    if base != n and base in names:
        print(f"重复: {n} / {base}")
```

### 验证脚本（USD 端）

```python
from pxr import Usd
stage = Usd.Stage.Open('C:/temp/xxx.usdc')
count = 0
for prim in stage.Traverse():
    val = prim.GetCustomDataByKey('mbb_material')
    if val:
        print(f"{prim.GetPath()} → {val}")
        count += 1
print(f"共 {count} 个有效标记")
```

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| Maya 端通用路径转换函数与 mayaUSDExport 行为不完全一致 | 低 | prim marker 仍无法正确写入 | 叶子名 fallback 作为兜底 |
| 历史 JSON 文件（冒号 key）与新代码产生的新 JSON（下划线 key）同时存在 | 中 | 场景混用新旧 JSON 时仍可能产生重复 | Blender 端变体查找已覆盖此情况 |
| 非引用资产的冒号字符（非命名空间用途）被误转换 | 极低 | 材质名意外改变 | 非引用资产 SG 名不含冒号，`replace` 为空操作 |
| 面级材质分配逻辑本身有独立 bug | 低 | 修复重复后仍可能面显示错误 | 本计划不涉及面分配逻辑改动，若有独立 bug 另起修复 |
| stage.GetRootLayer().Save() 写入失败 | 低 | marker 写入不生效（已有外层 try-except 兜底） | 增加专门的错误日志 |
| 大型场景 stage.Traverse() 性能退化 | 低 | 百级以上 prim 遍历耗时 | 预建字典后只遍历一次，O(n) 可接受 |

### 回退方案

所有改动集中在 Maya 端一个文件和 Blender 端一个文件。回退只需 `git checkout` 这两个文件，或用备份覆盖。非破坏性改动，不涉及数据格式变更。

---

## 8. 参考

- 本任务讨论中代码审查官出具的审查报告
- 测试产物：`C:\temp\1784012668999_meta.json`、`C:\temp\1784012668999.usdc`
- Maya USD 导出行为文档：`https://help.autodesk.com/view/MAYAUL/2025/ENU/?guid=Maya_SDK_MERGED_cmd_mayaUSDExport_html`
