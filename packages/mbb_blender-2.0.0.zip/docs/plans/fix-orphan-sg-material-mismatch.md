# 执行计划：修复孤儿 Shading Group 导致的材质名不匹配

**日期**: 2026-07-18
**状态**: 已实现，待代码审查

---

## 1. 问题回顾

### 当前现状

Maya 场景中存在**同一 aiStandardSurface 连着两个 SG** 的普遍情况：

```
buliao2 (aiStandardSurface)
  ├── aiStandardSurface1SG    ← 0 个 mesh 成员（材质创建时自动生成的空壳）
  └── polySurface1908SG       ← 1 个 mesh 成员（实际被模型引用的 SG）
```

MBB 的 `collect_material_metadata()` 在遍历 aiStandardSurface 时，用 `listConnections` 的**第一个结果**作为材质 key。
由于字母序关系，`aiStandardSurface1SG` 排在 `polySurface1908SG` 前面，空壳被选中。

这导致 JSON 里记录的名字（`aiStandardSurface*SG`）和 USD 里实际导出的名字（`polySurface*SG`）不一致。
Blender 端的 `reconstruct_materials` 无法匹配 → 新建了独立材料但永远不赋给模型 → 贴图丢失。

### 核心矛盾

`collect_material_metadata` 选 SG 时只看连接关系，不看 SG 里是否有模型成员。
有内容的 SG 和无内容的 SG 被同等对待，字母序决定了谁被选中。

### 影响范围

13 个材质受此影响（当前测试场景 15 个材质中 14 个异常，其中 13 个是此根因）。

第 14 个异常材质（`buliao`）的根因不同：其 SG 名本身不包含空壳干扰，问题出在 Blender 端 `reconstruct_materials` 的名字匹配阶段，属于独立 bug，不在本次修复范围内，后续单独追踪。

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| 修复 SG 选择逻辑：优先选有 mesh 成员的 SG | P0 | 遍历所有 SG 候选，挑成员数 > 0 的那个；若都没有成员则保持原行为 |
| 增加调试日志：SG 选择过程可追踪 | P0 | 日志输出所有候选 SG 及其成员数，标注最终选中原因 |
| Blender 端增加 name lookup 调试日志 | P1 | `reconstruct_materials` 输出每个材料名的查找过程（命中 / 创建 / miss） |
| 不引入回归 | P0 | 现有正常工作的场景（如 `buliao` 只有一个 SG）不受影响 |

---

## 3. 设计方案

### 核心思路：选 SG 时加入"是否有成员"为权重

| 维度 | 当前实现 | 改造后 |
|------|----------|--------|
| SG 选择 | `sg = sg_list[0]`（取第一个） | 遍历 `sg_list`，选第一个 `members > 0` 的；全空则 fallback 到第一个 |
| 日志 | 无 SG 选择过程日志 | 输出所有候选 SG 及其成员数 + 选中结论 |
| Blender 端日志 | 无材料查找日志 | 输出每个材料名的 lookup 过程 |

### 关键决策

**Q: 为什么选 Maya 端修复而非 Blender 端？**

A: 问题根源在 Maya 端的数据采集。Maya 端选对了 SG，JSON 给出的名字自然和 USD 匹配，Blender 端不需要任何改动。Blender 端的 `reconstruct_materials` 设计上就是"按名匹配"，这个假设是对的。

**Q: 如果一个 shader 连了多个 SG 且都有成员怎么办？**

A: 取第一个有成员的即可。所有有成员的 SG 都指向同一个 shader，材质数据（贴图、默认值）完全一致。
选哪个 SG 名只影响"在 Blender 中用哪个名字去匹配"。只要有一个匹配上，材质就能正确重建。

**Q: 为什么不直接删除空 SG？**

A: 空 SG 是 Maya 正常行为的一部分，删除可能影响 Maya 场景的其他流程（如参考编辑、Hypershade 节点图完整性）。MBB 作为桥接工具，职责是"正确读取"而非"修复 Maya 场景"。保持读取侧鲁棒即可。

---

## 4. 详细设计

### 4.1 改动文件

| 文件 | 改动类型 | 说明 |
|------|----------|------|
| `mbb_maya/mbb_server.py` | 修改 | `collect_material_metadata()` 中 SG 选择逻辑 + 日志 |
| `__init__.py` | 修改 | `reconstruct_materials()` 中材料查找日志 |

### 4.2 Maya 端改动

**位置**: `mbb_server.py`，`collect_material_metadata()` 函数，约第 169-172 行。

**当前代码**:
```python
sg_list = cmds.listConnections(shader, type='shadingEngine')
if not sg_list:
    continue
sg = sg_list[0]
```

**改造后**:
```python
sg_list = cmds.listConnections(shader, type='shadingEngine')
if not sg_list:
    continue

# 优先选有 mesh 成员的 SG，避免拿到材质创建时自动生成但从未使用的空壳
sg = None
sg_has_members = False
candidate_info = []
for candidate in sg_list:
    members = cmds.sets(candidate, query=True) or []
    candidate_info.append(f"{candidate}({len(members)}m)")
    if members and sg is None:
        sg = candidate
        sg_has_members = True
if sg is None:
    sg = sg_list[0]

# 区分 fallback 场景：单候选全空（正常） vs 多候选全空（异常）
if sg_has_members:
    label = '(有成员)'
elif len(sg_list) == 1:
    label = '(单候选/空)'
else:
    label = '(多候选/全空→fallback)'
log(f"  SG 候选: {', '.join(candidate_info)} → 选中: {sg} {label}")
```

**日志输出示例**:
```
# 正常修复：多个候选，选中有成员的
采集材质: polySurface1908SG (shader: buliao2)
  SG 候选: aiStandardSurface1SG(0m), polySurface1908SG(1m) → 选中: polySurface1908SG (有成员)

# 回归安全：单候选无成员（材质刚创建未赋值）
采集材质: aiStandardSurface1SG (shader: buliao)
  SG 候选: aiStandardSurface1SG(0m) → 选中: aiStandardSurface1SG (单候选/空)

# 异常场景：多候选但全空
采集材质: aiStandardSurface1SG (shader: wall_mat)
  SG 候选: wall_mat1SG(0m), wall_mat2SG(0m) → 选中: wall_mat1SG (多候选/全空→fallback)
```

> **备注**: `cmds.sets(sg, query=True)` 返回 SG 中所有成员，当前不区分成员类型（假设 set 成员均为 geometry）。实际 Maya 工作流中几乎不会往 shading engine 里放非 geometry 对象，此假设安全。

### 4.3 Blender 端改动

**位置**: `__init__.py`，`reconstruct_materials()` 函数，约第 1059-1067 行。

**目的**: 增加材料名查找过程的调试日志，方便后续排查"为什么材质没匹配上"。

**改造后**（**替换**现有的 `print(f"[MBB-DBG] reconstruct_materials [{idx}/{len(metadata)}]: {mat_name}")` 行，不要追加，避免重复日志）:
```python
mat = bpy.data.materials.get(mat_name)
lookup_path = f"精确: {'✓' if mat else '✗'}"
if mat is None:
    alt1 = mat_name.replace('_', ':')
    mat = bpy.data.materials.get(alt1)
    lookup_path += f" → 下划线换冒号({alt1}): {'✓' if mat else '✗'}"
if mat is None:
    alt2 = mat_name.replace(':', '_')
    mat = bpy.data.materials.get(alt2)
    lookup_path += f" → 冒号换下划线({alt2}): {'✓' if mat else '✗'}"
if mat is None:
    mat = bpy.data.materials.new(name=mat_name)
    lookup_path += " → 新建材料"
else:
    lookup_path += " → 匹配到已有材料"
print(f"[MBB-DBG] reconstruct_materials [{idx}/{len(metadata)}]: {mat_name} | {lookup_path}")
```

### 4.4 不改动的部分

- `_normalize_material_name()` — 行为不变，SG 名 `:` → `_` 转换正确
- `parse_response()` — 响应解析不变
- `_write_prim_material_markers()` — prim 标记写入逻辑不变（它遍历所有 SG，空 SG 无成员自然不写入任何 prim）
- USD 导出流程 — 不变
- 其他材料类型（UsdPreviewSurface 等）— 不受影响

---

## 5. 实现步骤

| 步骤 | 内容 | 依赖 |
|------|------|------|
| 1 | 修改 `mbb_server.py`：SG 选择逻辑 + Maya 端调试日志 | 无 |
| 2 | 修改 `__init__.py`：`reconstruct_materials` 增加材料查找日志 | 无 |
| 3 | 将 `mbb_server.py` 同步到 Maya 加载路径 (`C:\Users\Administrator\Documents\maya\2025\plug-ins\mbb_server.py`) | 步骤 1 |
| 4 | 在 Maya 中 reload MBB | 步骤 3 |
| 5 | 在 Blender 中执行一次完整导入测试 | 步骤 2, 4 |
| 6 | 检查日志输出，确认 SG 选择正确 + 材质重建成功 | 步骤 5 |

---

## 6. 测试策略

### 测试场景

| 场景 | 前置条件 | 操作 | 预期结果 |
|------|----------|------|----------|
| 当前出问题的场景（多空壳） | Maya 加载原测试工程 | MBB 导出导入 | 所有材质正常显示贴图，JSON 日志显示选中有成员的 SG |
| 单 SG 场景（如 `buliao`） | 场景中只有不含空壳的材质 | MBB 导出导入 | 行为不变，SG 选择日志显示仅一个候选 |
| 全空 SG 场景（极端） | 所有 SG 均无成员（材质创建后未赋值） | MBB 导出导入 | 降级到原行为（取第一个 SG），不报错 |
| 多成员 SG（同一 shader 赋给多个 mesh） | 一个 aiStandardSurface 连两个各有成员的 SG | MBB 导出导入 | 选第一个有成员的 SG，材质正确分配到所有相关 mesh |
| 面级多材质（一个 mesh 不同面不同材质） | 一个 mesh 的 3 个面组各分配不同材质（每个材质都有空壳 SG） | MBB 导出导入 | 面级分配正确保留，各面显示对应贴图 |
| 命名空间下的 SG | Maya 场景含命名空间（如 `ns:aiStandardSurface1SG`） | MBB 导出导入 | SG 名经 `_normalize_material_name` 转换后与 USD 导出名一致，材质正常匹配 |

### 手动验证 checklist

- [ ] Maya 端日志：每个材质输出 `SG 候选: xxx(0m), yyy(1m) → 选中: yyy (有成员)`
- [ ] Blender 端日志：`reconstruct_materials` 输出每个材料名的 lookup 路径和匹配结果
- [ ] 所有 mesh 在 Blender 视口中显示正确贴图
- [ ] 新建场景 + 从 Hypershade 创建材质 + 赋给 mesh → 导回 Blender 正常
- [ ] 重复导入同一场景两次，材质不重复、贴图不丢失

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| `cmds.sets(sg, query=True)` 在极少数 Maya 版本中行为差异 | 低 | 可能选错 SG | 有 fallback 到 `sg_list[0]`，日志会暴露选中过程 |
| 增加 `cmds.sets()` 调用略微影响性能 | 低 | 大场景可能变慢 | 每材质遍历一次候选 SG（典型 2 个），相比原有 `listConnections` 调用增加有限，影响可忽略 |
| 空壳 SG 也有成员的情况（罕见） | 极低 | 可能选到非预期的 SG | 日志清晰标注选中原因，方便排查 |

### 回退方案

改回原来的 `sg = sg_list[0]` 一行即可恢复原行为。改动仅影响 `collect_material_metadata` 中的 SG 选择逻辑，不影响其他函数。

---

## 8. 参考

- 本诊断的分析数据来自 Maya 实际场景查询（通过 MBB EVAL 命令）
- 相关代码（行号为计划编写时快照，代码增减后可能漂移）：
  - `F:/desktop/BaiduSyncdisk/addons/mbb_blender/mbb_maya/mbb_server.py` L149-174
  - `F:/desktop/BaiduSyncdisk/addons/mbb_blender/__init__.py` L1045-1067
- Maya 官方文档：`cmds.sets` 查询 shading engine 成员
