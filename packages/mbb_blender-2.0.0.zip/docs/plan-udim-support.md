# MBB UDIM 贴图支持：执行计划

> 状态: 待审查（v1.1 修订版）
> 版本: v1.1
> 日期: 2026-07-13
>
> **v1.1 修订要点**：
> - S1 已验证：`bpy.ops.image.open(use_udim_detecting=True)` 在 headless 下正常工作
> - 决策 4 重写：Blender 端改用操作符路径（`bpy.ops.image.open`）
> - 补充 UVTILE → UDIM 编号的映射逻辑
> - 修正正则（UDIM token / 文件扩展名顺序）
> - 标注代码复制为已知技术债务
> - 补充测试场景（token 路径 os.path.exists 失败、跨平台路径、.blend 重开）

---

## 1. 问题回顾

### 当前现状

MBB 插件从 Maya 导出材质 → Blender 重建时，贴图处理链路如下：

```
Maya: _trace_textures_upstream()
  → 追踪 aiStandardSurface 各槽位连接的 file 节点
  → 读取 fileTextureName（贴图路径）
  → 写入 JSON 元数据：{"Base Color": {"texture": "C:/tex/body_diff.1001.png"}}

Maya: copy_texture_files()
  → 逐个检查 os.path.exists(src_path)
  → 复制单个文件到 temp/textures/

Blender: reconstruct_materials()
  → bpy.data.images.load(tex_abs)  ← 只加载单张图片
  → img.colorspace_settings.name = 'sRGB' / 'Non-Color'
  → tex_node.image = img
  → 连线到 Principled BSDF
```

### 核心矛盾

**整个贴图管线以"一张贴图 = 一个文件"为前提设计，没有任何 UDIM 多瓦片意识。** 具体表现为三个断点：

| 断点 | 位置 | 现象 |
|------|------|------|
| ① Maya 端不识别 UDIM 同族瓦片 | `copy_texture_files()` | 只复制了 JSON 里记录的那一个瓦片文件，其他瓦片丢失 |
| ② Maya 端 `<UDIM>` token 路径会导致文件不存在 | `copy_texture_files()` 第 428 行 `os.path.exists()` | token 路径不是真实文件，直接跳过，贴图丢失 |
| ③ Blender 端不设 `Image.source = 'TILED'` | `reconstruct_materials()` 第 906 行 | 加载后是普通单图节点，不是 UDIM 模式 |

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|----------|
| 识别 Maya 传来的 UDIM 贴图（`<UDIM>` token 路径和显式瓦片号两种格式） | P0 | `copy_texture_files()` 和 `reconstruct_materials()` 都能正确检测 |
| 自动扫描同目录下的同族瓦片并全部复制 | P0 | 所有瓦片文件出现在 `temp/textures/` 下 |
| Blender 端正确设置 Image 为 TILED 模式并注册所有瓦片 | P0 | 材质节点树中 Image Texture 节点的 `image.source` 为 `TILED`，所有 UV 空间都有对应纹理 |
| 不破坏非 UDIM 贴图的现有行为 | P0 | 单张贴图的流程完全不受影响 |
| 色彩空间仍然正确映射 | P1 | UDIM 瓦片继承相同的色彩空间设置 |

---

## 3. 设计方案

### 3.1 核心思路

**不改动数据协议（JSON 格式不变），只改"单文件"假设为"单文件或瓦片族"。**

在 Maya 端和 Blender 端各插入一个 UDIM 感知层：

```
Maya: copy_texture_files()
  → [新] 检测是否为 UDIM 纹理
  → [新] 如果是 UDIM：扫描同目录的同族瓦片，全部复制
  → 如果是普通贴图：现有逻辑不变

Blender: reconstruct_materials()
  → [新] 检测贴图路径是否为 UDIM 瓦片
  → [新] 如果是 UDIM：用 bpy.ops.image.open(use_udim_detecting=True) 加载为 TILED Image
  → 如果是普通贴图：现有逻辑不变
```

| 维度 | 当前实现 | 改造后实现 |
|------|----------|------------|
| 贴图文件模型 | 1 对 1（一个 socket 对应一个文件） | 1 对 N（一个 socket 可对应一个瓦片族） |
| Image.source | 始终 `'FILE'`（默认） | UDIM 时设为 `'TILED'` |
| 瓦片注册 | 无 | 操作符自动检测 + 注册 |
| 文件复制 | 单文件 `shutil.copy2` | UDIM 时 `glob` 扫描 + 批量复制 |

### 3.2 关键设计决策

**决策 1：UDIM 检测放独立函数，两端复用**

纯函数 `detect_udim_tiles(filepath)` 放在 Blender 端 `__init__.py`，Maya 端 `mbb_server.py` 复制一份。

> ⚠ 已知技术债务：两份代码需手动保持同步。后续可以提取为独立共享模块（当前架构不支持跨端代码共享）。

返回结构：
```python
{
    "is_udim": True/False,
    "tiles": {                                        # 找到的瓦片
        1001: "C:/tex/body_diff.1001.png",
        1002: "C:/tex/body_diff.1002.png",
        1003: "C:/tex/body_diff.1003.png",
    }
}
```

**决策 2：检测策略分三步**

第一步：检查路径中是否含 `<UDIM>` 或 `<UVTILE>` token。有 → 按 token 模板做 glob 匹配，`<UVTILE>` 格式的文件名需要通过反向映射转为 UDIM tile number。

第二步：没有 token 时，检查文件名中是否含 ≥1001 的 4 位数字瓦片号，且同目录下存在同基名但不同数字的兄弟文件。有 → 判定为 UDIM。

第三步：都不是 → `is_udim=False`，走现有单文件逻辑。

> 排除规则：4 位数字 < 1001 的不触发 UDIM 分支（如 `body.0001.png` 是序列帧，不是 UDIM）。

**决策 3：UVTILE 文件名 → UDIM 编号映射**

`<UVTILE>` token 生成的文件命名格式是 `u1_v2`，其中数字是从 1 开始的（u_tile + 1, v_tile + 1）。映射公式：

```
UDIM tile number = 1001 + (u - 1) + (v - 1) * 10
```

例如 `body.u1_v2.png` → u=1, v=2 → tile number = 1001 + 0 + 10 = 1011。

需要在 `detect_udim_tiles()` 中内置解析逻辑。

**决策 4：Blender 端用 bpy.ops.image.open(use_udim_detecting=True)**

S1 MCP 探测已验证此操作符在 headless 模式下正常可用。它接受显式的 `filepath`、`directory`、`files` 参数，不需要 UI context。

```python
# 加载 UDIM 贴图
bpy.ops.image.open(
    filepath=tiles[1001],        # 第一个瓦片的绝对路径
    directory=os.path.dirname(tiles[1001]),
    files=[{"name": os.path.basename(tiles[1001])}],
    use_udim_detecting=True,
    relative_path=False,
)
# 操作符会自动：
# 1. 扫描同目录的同族瓦片
# 2. 创建 TILED Image
# 3. 注册所有瓦片
# 4. 设置 filepath 为 UDIM 模板路径（如 body.<UDIM>.png）
```

加载后通过 `bpy.data.images` 找到新创建的 Image，然后设置色彩空间。

**决策 5：保持 JSON 格式不变**

JSON 中 `"texture"` 字段依然存第一个瓦片的相对路径（如 `textures/body_diff.1001.png`）。Blender 端从第一个瓦片反推 UDIM pattern 并扫描目录。不引入新的 JSON 字段，向后兼容。

> 可选优化（当前不做）：在 JSON 中增加 `"udim_tiles"` 字段传递 Maya 端的瓦片扫描结果，避免 Blender 端重复扫描。当前版本暂不引入新字段，保持协议最简。

---

## 4. 详细设计

### 4.1 UDIM 检测函数

```python
# 贴图路径中的 UDIM token 模式：匹配 <UDIM> 或 <UVTILE>
UDIM_TOKEN_PATTERN = re.compile(r'<(UDIM|UVTILE)>', re.IGNORECASE)

# UDIM 瓦片号模式：匹配 .1001.png 或 _1001.png 格式
# 注意 tiff 在 tif 前面，避免 tif 优先匹配截断 tiff
UDIM_TILE_PATTERN = re.compile(
    r'[._](1\d{3})\.(png|jpg|jpeg|tga|exr|tiff|tif|hdr|bmp)(?:[.][^.]+)?$',
    re.IGNORECASE
)

# UVTILE 文件名格式：u1_v1, u2_v3 等
UVTILE_FILE_PATTERN = re.compile(r'[._]u(\d+)_v(\d+)\.', re.IGNORECASE)


def _uvtile_to_udim_number(u_str, v_str):
    """将 UVTILE 坐标映射为 UDIM tile number。
    UVTILE 格式: u(u_tile+1)_v(v_tile+1)
    UDIM 编号:   1001 + u_tile + v_tile * 10
    """
    u = int(u_str) - 1  # UVTILE 从 1 开始，转为 0-based
    v = int(v_str) - 1
    return 1001 + u + v * 10


def detect_udim_tiles(filepath):
    """
    检测给定路径是否为 UDIM 纹理瓦片族的一部分。

    返回 dict:
      - is_udim: bool
      - tiles: {tile_number: absolute_path}  仅 is_udim=True 时有值
    """
    directory = os.path.dirname(filepath)
    basename = os.path.basename(filepath)

    # Step 1: 检查 <UDIM> / <UVTILE> token
    token_match = UDIM_TOKEN_PATTERN.search(filepath)
    if token_match:
        token_type = token_match.group(1).upper()  # UDIM 或 UVTILE
        # 将 token 替换为 glob pattern
        pattern = UDIM_TOKEN_PATTERN.sub('*', filepath)
        tiles = {}
        for match_path in glob.glob(pattern):
            fname = os.path.basename(match_path)
            if token_type == 'UDIM':
                # 从文件名提取 4 位数字
                m = re.search(r'[._](\d{4})\.', fname)
                if m:
                    tile_num = int(m.group(1))
                    if tile_num >= 1001:
                        tiles[tile_num] = match_path
            else:  # UVTILE
                m = UVTILE_FILE_PATTERN.search(fname)
                if m:
                    tile_num = _uvtile_to_udim_number(m.group(1), m.group(2))
                    tiles[tile_num] = match_path
        if len(tiles) > 1:
            return {"is_udim": True, "tiles": tiles}
        else:
            return {"is_udim": False, "tiles": {}}

    # Step 2: 检查显式瓦片号（文件名含 ≥1001 的 4 位数字）
    tile_match = UDIM_TILE_PATTERN.search(basename)
    if tile_match:
        tile_number = int(tile_match.group(1))
        if tile_number < 1001:
            return {"is_udim": False, "tiles": {}}

        # 检查同目录是否有同族瓦片
        prefix = basename[:tile_match.start(1)]   # "body_diff."
        suffix = basename[tile_match.end(1):]      # ".png"
        glob_pattern = os.path.join(directory, f"{prefix}*{suffix}")
        tiles = {}
        for match_path in glob.glob(glob_pattern):
            m = UDIM_TILE_PATTERN.search(os.path.basename(match_path))
            if m:
                num = int(m.group(1))
                if num >= 1001:
                    tiles[num] = match_path

        if len(tiles) > 1:
            return {"is_udim": True, "tiles": tiles}

    # Step 3: 不是 UDIM
    return {"is_udim": False, "tiles": {}}
```

### 4.2 Maya 端改造点

**文件**: `mbb_maya/mbb_server.py`

**改点 1**: 新增 `detect_udim_tiles()` 函数（含 `_uvtile_to_udim_number()` 辅助函数，约 70 行）

> 两端的 `detect_udim_tiles()` 逻辑完全相同。文件顶部加注释 `# UDIM 检测函数 — 与 Blender 端 __init__.py 保持同步`。

**改点 2**: 修改 `copy_texture_files()` 的贴图复制循环

当前逻辑：
```
for each texture_path in metadata:
    if not os.path.exists(path): skip
    copy single file
```

改造后逻辑：
```
for each texture_path in metadata:
    udim_info = detect_udim_tiles(texture_path)
    if udim_info["is_udim"]:
        # UDIM：复制所有同族瓦片
        for tile_num, tile_path in sorted(udim_info["tiles"].items()):
            copy tile_path → temp/textures/{filename}
        JSON 中 texture 改为第一个瓦片的相对路径（最小的 tile number）
    else:
        if not os.path.exists(path): skip
        copy single file
```

### 4.3 Blender 端改造点

**文件**: `__init__.py`

**改点 1**: 新增 `detect_udim_tiles()` 函数（含 `_uvtile_to_udim_number()`，约 70 行）

**改点 2**: 新增 `load_image_as_udim()` 函数（约 40 行）

```python
def load_image_as_udim(tiles_dict, colorspace_name):
    """
    以 UDIM 模式加载一组瓦片贴图。

    tiles_dict: {1001: "C:/tex/body_diff.1001.png", 1002: "..."}
    colorspace_name: 'sRGB' 或 'Non-Color'
    返回: bpy.types.Image（source='TILED'，已注册所有瓦片）
    """
    # 取第一个瓦片的路径作为操作符参数
    first_tile_num = min(tiles_dict.keys())
    first_tile_path = tiles_dict[first_tile_num]
    directory = os.path.dirname(first_tile_path)
    filename = os.path.basename(first_tile_path)

    # 用操作符加载并自动检测 UDIM
    bpy.ops.image.open(
        filepath=first_tile_path,
        directory=directory,
        files=[{"name": filename}],
        use_udim_detecting=True,
        relative_path=False,
    )

    # 找到操作符创建的 Image（名称格式为 "base.<UDIM>.ext"）
    base_name = re.sub(r'(\.\d{4}\.)|(\.u\d+_v\d+\.)', r'.<UDIM>.', filename)
    img = bpy.data.images.get(base_name)
    if img is None:
        # fallback：按第一个瓦片名模糊匹配
        for i in bpy.data.images:
            if os.path.basename(first_tile_path).split('.')[0] in i.name:
                img = i
                break

    if img:
        img.colorspace_settings.name = colorspace_name

    return img
```

**改点 3**: 修改 `reconstruct_materials()` 第 893~909 行的贴图加载段

当前逻辑：
```python
tex_rel = socket_info['texture']
tex_abs = ...
if not os.path.exists(tex_abs): continue
tex_node = nodes.new('ShaderNodeTexImage')
img = bpy.data.images.load(tex_abs)
img.colorspace_settings.name = ...
tex_node.image = img
```

改造后逻辑：
```python
tex_rel = socket_info['texture']
tex_abs = ...
if not os.path.exists(tex_abs): continue
tex_node = nodes.new('ShaderNodeTexImage')

udim_info = detect_udim_tiles(tex_abs)
if udim_info["is_udim"]:
    img = load_image_as_udim(udim_info["tiles"], colorspace_name)
else:
    img = bpy.data.images.load(tex_abs)
    img.colorspace_settings.name = colorspace_name

tex_node.image = img
```

### 4.4 不需要改动的地方

| 模块 | 原因 |
|------|------|
| `_trace_textures_upstream()` | 已经正确返回贴图路径，UDIM token 或显式瓦片号都原样传递 |
| `collect_material_metadata()` | 元数据采集逻辑不关心文件系统的瓦片结构 |
| `write_material_json()` | JSON 格式不变 |
| `_map_to_blender_socket()` | 贴图类型到 Blender socket 的映射无关 UDIM |
| 材质分配逻辑 (`assign_material_to_objects`, `_assign_mat`) | 材质分配不关心贴图是否为 UDIM |
| UI 层 (`mbb_ui.py`) | 无 UI 改动 |

---

## 5. 实现步骤

| 步骤 | 内容 | 涉及文件 | 预计改动量 |
|------|------|----------|-----------|
| S1 | ~~MCP 探测验证 API 方案~~ **已完成** | — | ✅ |
| S2 | 在 Blender 端 `__init__.py` 实现 `detect_udim_tiles()` + `_uvtile_to_udim_number()` | `__init__.py` | ~70 行 |
| S3 | 在 Blender 端 `__init__.py` 实现 `load_image_as_udim()` | `__init__.py` | ~40 行 |
| S4 | 修改 `reconstruct_materials()` 的贴图加载段，插入 UDIM 分支 | `__init__.py` | ~20 行 |
| S5 | 在 Maya 端 `mbb_server.py` 实现 `detect_udim_tiles()` + `_uvtile_to_udim_number()` | `mbb_maya/mbb_server.py` | ~70 行 |
| S6 | 修改 `copy_texture_files()` 的贴图复制循环 | `mbb_maya/mbb_server.py` | ~25 行 |
| S7 | 端到端测试（Maya → Blender 完整流程） | 手动测试 | 30 min |

---

## 6. 测试策略

### 6.1 测试场景

| 场景 | UDIM 格式 | 预期结果 |
|------|-----------|----------|
| 普通单张贴图（非 UDIM） | `body_diff.png` | 行为不变，正常加载 |
| Maya `<UDIM>` token 路径 | `body.<UDIM>.png` | 正确扫描并加载所有瓦片 |
| Maya 显式瓦片号路径 | `body.1001.png` | 检测到同族瓦片 `1002`, `1003`，全部加载 |
| 只有一个瓦片（无同族） | `body.1001.png`（目录仅此一文件） | 退化为普通单图加载 |
| 瓦片号不连续 | `1001`, `1003`（缺 `1002`） | 加载 `1001` 和 `1003`，`1002` 位置为空白槽位 |
| 法线贴图 UDIM | `body_normal.<UDIM>.png` | `source='TILED'` + `colorspace='Non-Color'` |
| 粗糙度贴图 UDIM | `body_roughness.<UDIM>.png` | 同上 |
| `<UVTILE>` token 格式 | `body.u1_v1.png` | 正确映射到 UDIM tile number 并加载 |
| `<UVTILE>` 多瓦片 | `body.u1_v1.png`, `body.u2_v1.png`, `body.u1_v2.png` | 所有文件正确映射到对应 tile number |
| 4 位数字 < 1001（序列帧） | `body.0001.png`, `body.0002.png` | 不触发 UDIM 分支，走单文件加载 |
| Maya 端 token 路径 `os.path.exists()` 失败 | `body.<UDIM>.png`（token 路径不存在） | `detect_udim_tiles()` 跳过 `os.path.exists`，直接 glob 扫描后复制 |
| 跨平台路径（Maya Windows → temp 目录） | `C:\tex\body.1001.png` | 路径分隔符自动处理 |
| .blend 保存重开后 UDIM 贴图关联 | 保存 → 关闭 → 重新打开 | 贴图仍正确关联到 temp 目录中的瓦片文件 |

### 6.2 手动测试 checklist

1. [ ] Maya 中创建含 UDIM 贴图的 aiStandardSurface 材质（至少 3 个瓦片：1001/1002/1003）
2. [ ] 通过 MBB 导出到 Blender
3. [ ] 检查 `temp/textures/` 下是否所有瓦片文件都被复制
4. [ ] 检查材质节点树中 Image Texture 节点的 `image.source` 是否为 `TILED`
5. [ ] 检查 `image.tiles` 中是否注册了所有瓦片号
6. [ ] 在 Blender 视口中切换不同 UV 空间查看贴图是否正确显示
7. [ ] 保存 .blend → 关闭 → 重新打开，确认 UDIM 贴图关联正常
8. [ ] 重复测试：单张非 UDIM 贴图，确认不受影响
9. [ ] 重复测试：混合场景（部分材质 UDIM、部分单图）
10. [ ] Maya 端用 `<UDIM>` token 路径（而非显式瓦片号）导出，确认 Blender 端正确处理
11. [ ] Maya 端用 `<UVTILE>` token 路径导出，验证 UVTILE → UDIM 编号映射正确

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| ~~`bpy.data.images.load()` 方案不可用~~ → **已解决** | — | — | S1 验证 `bpy.ops.image.open()` 在 headless 下正常工作 ✅ |
| Maya 的 `<UDIM>` token 格式在 `copy_texture_files` 中 `os.path.exists()` 返回 False | 高 | 贴图不复制 | `detect_udim_tiles()` 在 token 格式下跳过 `os.path.exists()` 检查，直接按 pattern glob |
| `bpy.ops.image.open()` 创建的 Image 命名规则变化导致 `load_image_as_udim()` 找不到 Image | 中 | UDIM 加载失败 | 设计中包含 fallback 模糊匹配逻辑；如果操作符行为随版本变化，用 MCP 探测确认 |
| Blender 加载 UDIM 后 filepath 不一致导致贴图路径紊乱 | 低 | 后续保存/重开场景找不到贴图 | 操作符自动设置 filepath 为模板路径，Blender 根据模板路径查找瓦片 |
| 瓦片号超出 Blender 支持范围（非标准 UDIM 编号） | 低 | 部分瓦片无法注册 | 仅注册匹配标准 UDIM 编号（1001+）的瓦片，非标准的 log 警告后跳过 |
| 两端 `detect_udim_tiles()` 逻辑不一致（代码复制维护债务） | 低 | 两端的 UDIM 检测行为不同 | 两端文件顶部加同步注释；后续提取为共享模块 |

### 回退方案

改动集中在 `reconstruct_materials()` 和 `copy_texture_files()` 两个函数的贴图处理段，且有 `is_udim` 分支判断。回退只需：
1. `git revert` 对应 commit
2. 或者手动删除 UDIM 分支，保留 else 路径的原始逻辑

---

## 8. 参考

| 文档 | 内容 |
|------|------|
| `Blender_base/Python-API-v5.2/bpy.types.Image.md` | `Image.source` 枚举（`'TILED'`）和 `Image.tiles` 属性 |
| `Blender_base/Python-API-v5.1/types/UDIMTiles/bpy.types.UDIMTiles.md` | `UDIMTiles.new()` / `.get()` / `.remove()` API |
| `Blender_base/Python-API-v5.1/types/UDIMTile/bpy.types.UDIMTile.md` | `UDIMTile` 属性（number, label 等） |
| `Blender_base/Python-API-v5.1/operators/image/bpy.ops.image.md` | `bpy.ops.image.open(use_udim_detecting=True)` 操作符 |
| `Blender_base/01-手册-v5.1/05-建模/网格/uv/workflows/udims.md` | UDIM 编号规则：`1001 + u + 10*v`，每行 10 个瓦片 |
| `F:/desktop/BaiduSyncdisk/addons/mbb_blender/__init__.py` | Blender 端材质重建代码 |
| `F:/desktop/BaiduSyncdisk/addons/mbb_blender/mbb_maya/mbb_server.py` | Maya 端材质采集 + 贴图复制代码 |

---

## 附录 A：S1 MCP 探测结果摘要

| 方案 | 结果 |
|------|------|
| `load()` → `source='TILED'` → `tiles.new()` | tiles 结构创建正确，但 `img.pixels` 切换 active_index 后数据显示异常（可能仅 API 层缓存问题） |
| `load()` → `source='TILED'` → 手动设 `img.filepath` 模板 | tiles 自动增加到正确数量，问题同上 |
| `bpy.ops.image.open(use_udim_detecting=True)` | **✅ 完全可用**，headless 下正常运行，Image name 为 `base.<UDIM>.ext`，source=TILED，tiles 正确 |
| 直接 `load()` `<UDIM>` token 路径 | ❌ 加载成功但 size=(0,0)，Blender 不解析 token |

**结论**：采用 `bpy.ops.image.open(use_udim_detecting=True)` 方案。
