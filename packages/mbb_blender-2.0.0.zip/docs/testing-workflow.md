# MBB 标准测试流程

> 适用：MBB 插件开发迭代中的自动化测试  
> 依赖：`maya_bridge.py`（项目根目录）  
> 环境：Maya 2025 + MayaUSD 0.27.0，Blender 5.1.2

---

## 一、环境准备

### 1.1 确保 Maya 端文件最新

修改 `mbb_server.py` 后，需同步到 Maya 插件目录：

```powershell
Copy-Item "F:\desktop\BaiduSyncdisk\addons\mbb_blender\mbb_maya\mbb_server.py" `
          "C:\Users\Administrator\Documents\maya\2025\plug-ins\mbb_server.py" -Force
```

### 1.2 确保 Blender 端已重载

修改 `__init__.py` 后，在 Blender 中：
```
编辑 → 偏好设置 → 插件 → 搜索 "Maya Bridge" → 取消勾选 → 重新勾选
```

---

## 二、启动测试环境

### 方式 A：脚本全自动（推荐）

```python
# 在项目根目录运行
from maya_bridge import Maya

# 启动 Maya + 打开测试场景 + 自动连接
m = Maya.launch_maya(scene_file=r'F:\desktop\C07Changqiangbing_Rig.mb')

# 测试连接
print(m.ping())  # → pong

# 选物体、测材质
m.select(['a', 'b', 'c', 'd', 'e', 'qiang'])
print(m.detect_material_types())  # → {'usdPreviewSurface'}
```

### 方式 B：手动连接（Maya 已在运行）

```python
from maya_bridge import Maya

m = Maya()
m.connect()
print(m.ping())
```

### 方式 C：一行测试

```python
python -c "from maya_bridge import Maya; m=Maya.launch_maya(scene_file=r'F:\desktop\C07Changqiangbing_Rig.mb'); print(m.detect_material_types())"
```

---

## 三、标准测试用例

### 3.1 材质类型检测（6 路分支）

```python
from maya_bridge import Maya

with Maya() as m:
    # 场景：长枪兵 Rig（全部 usdPreviewSurface）
    m.file_open(r'F:\desktop\C07Changqiangbing_Rig.mb')
    m.select(['a', 'b', 'c', 'd', 'e', 'qiang'])
    result = m.detect_material_types()
    assert result == {'usdPreviewSurface'}, f'Expected usdPreviewSurface, got {result}'
    print('✅ detect_material_types: usdPreviewSurface')

    # 无选中 → 空
    m.eval('cmds.select(clear=True)')
    assert m.detect_material_types() == set()
    print('✅ detect_material_types: empty (no selection)')

    # Arnold 场景（另行准备）
    # m.file_open(r'path/to/arnold_scene.mb')
    # ...
```

### 3.2 UsdPreviewSurface 导入测试

```python
from maya_bridge import Maya

with Maya() as m:
    m.file_open(r'F:\desktop\C07Changqiangbing_Rig.mb')
    m.select(['a', 'b', 'c', 'd', 'e', 'qiang'])

    # 从 Maya 端触发导出（模拟 Blender 的 EXPORT_SELECTED 命令）
    result = m.export_usd(r'C:\temp\auto_test.usdc')
    print(result)

# 然后在 Blender 中手动 wm.usd_import 验证材质
# 或用 Blender MCP：
#   bpy.ops.wm.usd_import(filepath=r'C:\temp\auto_test.usdc',
#       import_materials=True, import_usd_preview=True, import_all_materials=True)
```

### 3.3 Arnold 路径回归测试

确保现有 `aiStandardSurface` 路径不受影响：

```python
from maya_bridge import Maya

with Maya() as m:
    m.file_open(r'F:\path\to\arnold_scene.mb')
    m.select('some_arnold_object')
    result = m.detect_material_types()
    assert result == {'aiStandardSurface'}, f'Expected aiStandardSurface, got {result}'
    print('✅ Arnold path: still works')
```

### 3.4 未知材质类型拦截测试

```python
from maya_bridge import Maya

with Maya() as m:
    # 创建 lambert 材质物体
    m.eval("""
import maya.cmds as cmds
cmds.file(new=True, force=True)
cube = cmds.polyCube()[0]
mat = cmds.shadingNode('lambert', asShader=True)
sg = cmds.sets(renderable=True, noSurfaceShader=True, empty=True)
cmds.connectAttr(mat+'.outColor', sg+'.surfaceShader', force=True)
cmds.select(cube)
cmds.hyperShade(assign=mat)
""")
    m.select([cube])
    result = m.export_usd(r'C:\temp\test_unknown.usdc')
    assert 'EXPORT_FAILED' in result
    assert 'lambert' in result.lower()
    print('✅ Unknown material type: correctly rejected')
```

---

## 四、Blender 端集成测试

### 4.1 从 Blender MCP 触发导入

```python
# 在 Blender MCP execute_code 中
import bpy
bpy.ops.wm.usd_import(
    filepath=r'C:\temp\auto_test.usdc',
    import_materials=True,
    import_usd_preview=True,
    import_all_materials=True,
    apply_unit_conversion_scale=True,
)

# 验证材质
for mat in bpy.data.materials:
    print(f'{mat.name}: nodes={len(mat.node_tree.nodes)}')

# 验证分配
for obj in bpy.context.selected_objects:
    if obj.type == 'MESH':
        print(f'{obj.name}: materials={[s.name for s in obj.data.materials if s]}')
```

### 4.2 完整 Maya→Blender 往返测试

1. Maya 端：选中物体，准备好 MBB 服务器
2. Blender 端：点击 "Import Selection"
3. 检查：控制台输出 `[MBB] UsdPreviewSurface 模式：使用 USD 内置材质`
4. 验证：`bpy.data.materials` 中有导入的材质，物体上 material_slots 不为空

---

## 五、MBB EVAL 命令参考

所有通过 `maya_bridge` 发送的命令均经过 MBB 的 `EVAL` 处理器。

### 可用的预置变量

| 变量 | 说明 |
|------|------|
| `cmds` | `maya.cmds`（已自动导入） |
| `mel` | `maya.mel`（已自动导入） |

### 常用 EVAL 命令

```python
m.eval("cmds.select(['a', 'b'])")                    # 选中物体
m.eval("print(cmds.ls(selection=True))")             # 查看选中
m.eval("print(cmds.file(query=True, sceneName=True))")  # 当前场景路径
m.eval("cmds.file(new=True, force=True)")            # 新建场景
m.eval("cmds.file(r'path/to/file.mb', open=True)")   # 打开场景
```

### 带模块路径的 EVAL（导入非标准模块）

```python
m.eval("""
import sys
sys.path.insert(0, r'F:\\desktop\\BaiduSyncdisk\\addons\\mbb_blender\\mbb_maya')
import mbb_server
print(mbb_server.detect_material_types())
""")
```

---

## 六、故障排查

| 现象 | 可能原因 | 解决 |
|------|---------|------|
| `ConnectionRefusedError` | Maya 未启动或 MBB 服务器未运行 | `Maya.launch_maya(scene_file=...)` |
| `EVAL_ERROR: name 'cmds' is not defined` | MBB 版本未包含 cmds 预置 | 在代码中显式 `import maya.cmds as cmds` |
| `detect_material_types()` 返回空 set | 未选中物体 | `m.select(['a', 'b', ...])` 先选中 |
| Blender 导入无材质 | Maya 端 `mbb_server.py` 未更新 | 执行第一步的文件同步 |
| `EVAL_ERROR: invalid syntax` | 多行代码中的引号/转义问题 | 使用 `\\n` 替代真实换行，或精简为单行 |

---

## 七、开发迭代快速参考

```
修改 mbb_server.py
    │
    ▼
Copy-Item → Maya plug-ins 目录
    │
    ▼
from maya_bridge import Maya
with Maya() as m:
    m.reload_mbb()         # 重载服务器代码
    m.select([...])        # 选中测试物体
    m.detect_material_types()  # 运行检测
    m.export_usd(...)      # 测试导出
    │
    ▼
Blender 端 Import Selection → 验证材质
```

---

*本文件随 MBB 项目迭代更新。*
