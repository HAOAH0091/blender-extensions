# MBB 材质重建：单独处理手动导出的 USD

> 场景：你有一个从 Maya 手动导出的 USD（非 MBB socket 流程），想用 MBB 的材质重建功能给 Blender 里的模型挂上 Principled BSDF。

## 结论

**可行。** MBB 的 `reconstruct_materials()` 函数是自包含的，不依赖 MBB 的 socket 通信。只需要为这个 USD 配一份符合格式的 JSON，就能独立触发材质重建。

## 当前 MBB 的材质重建是怎么工作的

MBB 正常导入流程分三步：

```
Maya 导出 USD + JSON → Blender 导入 USD → reconstruct_materials(JSON) → 分配材质
```

核心函数 `reconstruct_materials(json_path)` 做的事：

- 读 JSON 获取每个材质的 socket → 贴图/默认值映射
- 创建 Principled BSDF 节点树，贴图自动设定色彩空间（sRGB / Non-Color）
- 法线贴图自动插入 Normal Map 节点
- 按 JSON 中的 `_objects` 和 `_face_map` 分配材质到物体

## 手动 USD 场景下的拆分流程

### Step 1：Maya 侧生成 JSON

在 Maya 中运行扫描脚本，从场景里的 aiStandardSurface 提取材质元数据，输出为 MBB 格式的 JSON。格式示例：

```json
{
  "my_material": {
    "Base Color": {
      "texture": "textures/my_diffuse.png",
      "connect": true
    },
    "Roughness": {
      "texture": "textures/my_roughness.png",
      "connect": true
    },
    "Metallic": {
      "value": 0.0
    },
    "Normal": {
      "texture": "textures/my_normal.png",
      "connect": true
    },
    "_objects": ["my_mesh"],
    "_face_map": {}
  }
}
```

JSON 中各字段说明：

| 字段 | 含义 |
|------|------|
| `texture` | 贴图相对路径（相对于 JSON 所在目录）或绝对路径 |
| `value` | 标量默认值 |
| `color` | RGB 颜色默认值 |
| `connect` | 贴图是否自动连线到 BSDF socket（false = 贴图放在节点树里但不连线，手动处理） |
| `_objects` | 材质应分配到的物体名列表 |
| `_face_map` | 面级分配：`{"obj名": [面索引列表]}` |

### Step 2：Blender 侧导入 USD

用 Blender 原生导入器导入手动导出的 USD：

```python
bpy.ops.wm.usd_import(
    filepath="C:/path/to/your.usdc",
    import_materials=False,      # 不走 USD 自带材质
    apply_unit_conversion_scale=True,
)
```

### Step 3：触发材质重建

在 Blender Python 控制台：

```python
from your_addon_path import reconstruct_materials
reconstruct_materials("C:/path/to/material_metadata.json")
```

或者直接运行 MBB 的 `__init__.py` 中的 `reconstruct_materials` 函数。

### Step 4：材质分配

`reconstruct_materials` 会自动调用 `assign_material_to_objects` 把材质挂到物体上。分配逻辑：

- 按 `_objects` 列表中的名称匹配场景物体（支持 prim 路径格式）
- 支持 `_face_map` 面级分配
- 回退策略：匹配 proto 源网格名 → 选中无材质物体

如果名称匹配不上，材质建好了但没挂到模型上，手动拖一下就行。

## 限制与注意

| 项目 | 说明 |
|------|------|
| **JSON 格式依赖** | 必须符合 MBB 的格式，不是任意 JSON 都行。需要 Maya 端一个专门的提取脚本 |
| **贴图路径** | JSON 中的贴图路径相对 JSON 文件目录解析。手动场景需确认贴图在正确位置 |
| **物体名匹配** | `assign_material_to_objects` 靠名称匹配。手动导出的 USD 如果命名规则不同，可能匹配失败，需手动分配 |
| **复杂节点树** | `connect=False` 的槽位只放贴图不连线，复杂拓扑仍需手工处理 |
| **色彩空间** | `reconstruct_materials` 已内置 Non-Color socket 列表（Roughness、Metallic、Normal 等），自动设对 |

## 与其他方案的关系

| 方案 | 适用场景 | 自动化程度 |
|------|----------|-----------|
| **MBB 完整流程** | 日常 Maya ↔ Blender 工作流 | 全自动 |
| **手动 USD + 手动 JSON + reconstruct_materials** | 偶尔处理外部 USD / 不通过 MBB 导出的资产 | 半自动（需提前生成 JSON） |
| **MayaUSD Job Context 插件**（分析中） | 未来替代方案，让 MayaUSD 导出即带 UsdPreviewSurface | 全自动，无需 JSON |

## 后续可选动作

- 把 Maya 端材质元数据提取脚本从 `mbb_server.py` 里独立出来，做成无 socket 依赖的独立工具
- 加一个 Blender 端的简易操作符：选一个 JSON 文件 → 一键重建材质
