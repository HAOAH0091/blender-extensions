# MBB v2.5 — Maya Blender Bridge

几何体 + 材质 + 动画的 Maya ↔ Blender 双向传输工具。基于 USD 传输几何，Arnold 材质元数据通过 JSON 重建为 Blender Principled BSDF。

## 工作流程

**Blender → Maya**：选中物体导出为 USDC 到临时目录，通过 socket 通知 Maya 导入。
**Maya → Blender**：Maya 导出 USDC + 采集 Arnold 材质元数据（贴图→PBR socket 映射）。贴图复制到临时目录。Blender 导入 USDC 几何体并从 JSON 重建 Principled BSDF 材质。

Maya 作为 socket 服务端，Blender 作为客户端。

### 材质处理

Maya 的 Arnold Standard Surface 材质不走 Maya USD 材质管线（该管线在法线贴图和 Arnold 转换上存在已知 bug），而是：

1. Maya 扫描每个 `aiStandardSurface`，读取每个 PBR 槽位连接了哪个贴图文件
2. 将映射保存为 JSON，随 USD 一起发送
3. Blender 读取 JSON，创建 Principled BSDF + Image Texture 节点树，自动设置正确的色彩空间（Base Color → sRGB，Roughness/Metallic/Normal → Non-Color）
4. 法线贴图自动插入 Normal Map 节点
5. UDIM 多瓦片贴图自动检测并设为 TILED 模式

**已支持**：baseColor、roughness、metallic、emission、normal、coat、coatRoughness、specularColor、alpha、bumpMap
**不支持的**：复杂节点网络（ramp、multiplyDivide 等），这些材质保留 USD 导入结果

### 动画导出

支持三种模式（`MBB_ANIM_CONFIG` 面板配置）：
- **None**：仅当前帧
- **Cache**：逐帧烘焙顶点位置，Maya 写 Mesh Sequence Cache
- **Skeletal**：导出骨骼+蒙皮+动画曲线，Blender 重建 Armature

### Modal 操作

Import/Export 使用非阻塞 Modal Operator，操作期间 Blender UI 保持响应，可按 Cancel 中止。

## 要求

- **Blender 5.0+**，`io_scene_usd` 插件已启用（默认包含）
- **Maya 2022+**，`mayaUsdPlugin` 可用
- **MtoA**（Arnold for Maya）用于 `aiStandardSurface` 材质采集
- **Python**：Maya 端需 `pxr`（USD Python 绑定），用于写入 prim 材质标记

## 安装

### Maya：
1. 将 `mbb_maya/` 下的脚本复制到 `C:\Users\_\Documents\maya\2025\plug-ins\`，保持平铺（不要子文件夹），否则 Maya 无法识别
2. 打开 Plugin Manager，加载 `mbb_plugin.py`
3. MBB 窗口未出现时，在 Script Editor 运行：

```python
import mbb_ui
mbb_ui.show()
```

注意：修改 `mbb_server.py` 后需同步覆盖到 `C:\Users\Administrator\Documents\maya\2025\plug-ins\mbb_server.py` 才能生效。

### Blender：
1. 将 `mbb_blender` 文件夹打包为 zip
2. Blender Preferences → Add-ons → Install from Disk → 选择 zip
3. 启用插件，在偏好设置中配置临时工作目录
4. 确认 `io_scene_usd` 已启用（Preferences → Add-ons → 搜索 "USD"）

### Maya Bridge 远程控制（可选）：
`maya_bridge.py` 提供 Maya 远程控制类，支持 `with Maya() as m:` 上下文管理器、`m.eval()` 远程执行、`m.launch_maya()` 一键启动。

## Usage

1. Start Maya, load the MBB plugin, click **Start Server**
2. In Blender, open the Maya Bridge panel (N-panel in 3D View)
3. Verify connection with **Port Test**
4. **Export Selection**: send selected Blender objects to Maya
5. **Import Selection**: import selected Maya objects (with materials if applicable)
