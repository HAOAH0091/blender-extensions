"""数值验证：相机横移后，各顶点【投影 UV】与锁定时的差异。

结论判据（核心）：
  UV 变 → 图案相对网格滑动（错）
  UV 不变 → 图案钉在网格上（对）
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]


def uv_of(world, cam):
    """compify 风格的投影 UV（透视 NDC，x/z, y/z）。"""
    view = plock.get_camera_view_matrix(cam)
    cs = view.inverted() @ world
    if abs(cs.z) < 1e-9:
        return None
    return (-cs.x / cs.z, -cs.y / cs.z)


scene = bpy.context.scene
cam = bpy.data.objects["Camera"]
meshes = [o for o in scene.objects if o.type == "MESH"][:6]
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam.data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

start = tuple(cam.location)
bpy.context.view_layer.update()

# 取样本顶点（每个 mesh 的第 0、100 号顶点）
samples = []
for o in meshes:
    n = len(o.data.vertices)
    for idx in [0, min(100, n - 1)]:
        w = o.matrix_world @ o.data.vertices[idx].co
        samples.append((o.name, idx, w.copy(), uv_of(w, cam)))

print("样本数:", len(samples))

# 2) 未锁定，相机移动
cam.location.x += 2.0
bpy.context.view_layer.update()
d02 = []
for (nm, idx, w0, uv0) in samples:
    o = scene.objects[nm]
    w = o.matrix_world @ o.data.vertices[idx].co
    uv = uv_of(w, cam)
    d02.append(max(abs(uv[0] - uv0[0]), abs(uv[1] - uv0[1])))
print("02 未锁定   UV 最大变化: %.6f" % max(d02))

# 3) 当前实现：锁定 + 相机移动
cam.location = start
bpy.context.view_layer.update()
res = plock.lock_group(scene, cam)
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
d03 = []
for (nm, idx, w0, uv0) in samples:
    o = scene.objects[nm]
    w = o.matrix_world @ o.data.vertices[idx].co
    uv = uv_of(w, cam)
    d03.append(max(abs(uv[0] - uv0[0]), abs(uv[1] - uv0[1])))
print("03 当前实现 UV 最大变化: %.6f" % max(d03))

# 4) 冻结投影：网格不动
plock.reset_group(scene, cam)
plock.unlock_group(scene, cam)
cam.location = start
bpy.context.view_layer.update()
# 冻结 = 投影用锁定时的相机（这里就是 start 位置）
d04 = []
for (nm, idx, w0, uv0) in samples:
    o = scene.objects[nm]
    w = o.matrix_world @ o.data.vertices[idx].co
    uv = uv_of(w, cam)   # 用冻结相机
    d04.append(max(abs(uv[0] - uv0[0]), abs(uv[1] - uv0[1])))
print("04 冻结投影 UV 最大变化: %.6f" % max(d04))

print("\n===== 判定 =====")
print("02 未锁定      : %s" % ("滑动 ✗" if max(d02) > 1e-6 else "钉住"))
print("03 当前实现    : %s" % ("滑动 ✗" if max(d03) > 1e-6 else "钉住 ✓"))
print("04 冻结投影    : %s" % ("滑动 ✗" if max(d04) > 1e-6 else "钉住 ✓"))
print("NUM_DONE")
