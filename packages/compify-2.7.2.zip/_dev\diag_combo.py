"""六组合对照实验：网格变形 × 投影源 的正确搭配。

组合矩阵：
  A  网格不动    + 投影实时（现状）
  B  网格不动    + 投影冻结（方案4）
  C  网格跟相机  + 投影实时（方案2，SCROLL=0）
  D  网格滚动    + 投影实时（当前插件，SCROLL=1）
  E  网格滚动    + 投影冻结（← 用户提议的"叠加"）
  F  网格跟相机  + 投影冻结（另一种叠加）

判据：同一顶点的【投影 UV】变化量。0 = 图案钉住、不变形。
另外渲染每个组合在"相机右移"后的画面，肉眼确认变形与否。
"""
import bpy
import sys
import os
import math
import mathutils

sys.stdout.reconfigure(encoding="utf-8")

_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("C")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

specs = [(-5.0, 16.0, 0.0, 1.15), (-2.5, 16.0, 0.0, 1.15), (0.0, 16.0, 0.0, 1.15),
         (2.5, 16.0, 0.0, 1.15), (5.0, 16.0, 0.0, 1.15)]
for i, (x, y, z, r) in enumerate(specs):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
    bpy.ops.object.shade_smooth()
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()
ORIG = {o.name: [tuple(v.co) for v in o.data.vertices] for o in meshes}

# ── 图案：细密棋盘 + 中央红靶心 ──
W = H = 512
CELL = 32
img = bpy.data.images.new("Pat", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        c = ((x // CELL) + (y // CELL)) % 2
        v = 0.93 if c else 0.05
        R = G = B = v
        r = math.hypot(x - W / 2, y - H / 2)
        if r < 66:
            R, G, B = 0.95, 0.12, 0.10
        elif r < 74:
            R, G, B = 0.98, 0.98, 0.98
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
tc = nt.nodes.new("ShaderNodeTexCoord"); tc.object = cam
sep = nt.nodes.new("ShaderNodeSeparateXYZ")
m1 = nt.nodes.new("ShaderNodeMath"); m1.operation = "DIVIDE"
m2 = nt.nodes.new("ShaderNodeMath"); m2.operation = "DIVIDE"
n1 = nt.nodes.new("ShaderNodeMath"); n1.operation = "MULTIPLY"; n1.inputs[1].default_value = -1
n2 = nt.nodes.new("ShaderNodeMath"); n2.operation = "MULTIPLY"; n2.inputs[1].default_value = -1
comb = nt.nodes.new("ShaderNodeCombineXYZ")
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(tc.outputs["Object"], sep.inputs["Vector"])
nt.links.new(sep.outputs["X"], m1.inputs[0]); nt.links.new(sep.outputs["Z"], m1.inputs[1])
nt.links.new(sep.outputs["Y"], m2.inputs[0]); nt.links.new(sep.outputs["Z"], m2.inputs[1])
nt.links.new(m1.outputs[0], n1.inputs[0]); nt.links.new(m2.outputs[0], n2.inputs[0])
nt.links.new(n1.outputs[0], comb.inputs["X"]); nt.links.new(n2.outputs[0], comb.inputs["Y"])
nt.links.new(comb.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

scene.render.resolution_x = 760
scene.render.resolution_y = 320
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 20
scene.cycles.device = "CPU"

OUT = os.path.join(IDES_HOME, "workspace", "_plock_combo")
os.makedirs(OUT, exist_ok=True)

# 冻结投影源（落在锁定相机上）
frozen = bpy.data.objects.new("ProjFrozen", None)
scene.collection.objects.link(frozen)

MIN_DEPTH = 1e-4


def view_m(c):
    loc, rot, _ = c.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def uv(world, src):
    cs = view_m(src).inverted() @ world
    return (-cs.x / cs.z, -cs.y / cs.z) if abs(cs.z) > 1e-9 else (0.0, 0.0)


def samples(src):
    out = []
    for o in meshes:
        n = len(o.data.vertices)
        for idx in (0, n // 2, n - 1):
            out.append(uv(o.matrix_world @ o.data.vertices[idx].co, src))
    return out


def restore():
    for o in meshes:
        f = []
        for c in ORIG[o.name]:
            f.extend(c)
        o.data.vertices.foreach_set("co", f)
        o.data.update()
    bpy.context.view_layer.update()


def lock_base():
    vi = view_m(cam).inverted()
    base = {}
    ref = 0.0
    for o in meshes:
        lst = []
        for v in o.data.vertices:
            cs = vi @ (o.matrix_world @ v.co)
            d = -cs.z
            lst.append((cs.x, cs.y, d))
            ref = max(ref, d)
        base[o.name] = lst
    return base, ref, view_m(cam)


def deform(vl, base, ref, scroll):
    """网格变形：按 scroll 系数把顶点放回（保持相机空间/滚动）。"""
    vn = view_m(cam)
    cr = vn.to_3x3()
    eye = vn.translation - vl.translation
    dcs = cr.transposed() @ eye
    for o in meshes:
        mwi = o.matrix_world.inverted()
        f = []
        for (x0, y0, d) in base[o.name]:
            k = (d / ref) * scroll
            local = vn @ mathutils.Vector((x0 - dcs.x * k, y0 - dcs.y * k, -d))
            co = mwi @ local
            f.extend((co.x, co.y, co.z))
        o.data.vertices.foreach_set("co", f)
        o.data.update()


def render(path):
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)


X0 = cam.location.x
DX = 2.0
results = {}

COMBOS = [
    ("A_nofix_realtime",  None, False),
    ("B_nofix_frozen",    None, True),
    ("C_follow_realtime", 0.0,  False),
    ("D_scroll_realtime", 1.0,  False),
    ("E_scroll_frozen",   1.0,  True),
    ("F_follow_frozen",   0.0,  True),
]

for name, scroll, freeze in COMBOS:
    cam.location.x = X0
    bpy.context.view_layer.update()
    restore()
    base, ref, vl = lock_base()
    frozen.matrix_world = vl
    src = frozen if freeze else cam
    tc.object = src
    S0 = samples(src)

    cam.location.x = X0 + DX
    bpy.context.view_layer.update()
    if scroll is not None:
        deform(vl, base, ref, scroll)
    S1 = samples(src)
    d = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(S1, S0))
    results[name] = d
    render(os.path.join(OUT, name + "_moved.png"))
    # 再渲一帧"初始"（复位 + 相机回原位）
    cam.location.x = X0
    bpy.context.view_layer.update()
    restore()
    render(os.path.join(OUT, name + "_init.png"))
    print("DONE %s  UV变化=%.6f" % (name, d))

print("\n===== 六组合：相机右移 %.1f 后，投影 UV 最大变化 =====" % DX)
LABEL = {
    "A_nofix_realtime": "A 网格不动   + 投影实时  (现状)",
    "B_nofix_frozen":   "B 网格不动   + 投影冻结  (方案4)",
    "C_follow_realtime": "C 网格跟相机 + 投影实时  (方案2)",
    "D_scroll_realtime": "D 网格滚动   + 投影实时  (当前插件)",
    "E_scroll_frozen":  "E 网格滚动   + 投影冻结  ← 你说的叠加",
    "F_follow_frozen":  "F 网格跟相机 + 投影冻结  (另一种叠加)",
}
for k, lab in LABEL.items():
    d = results.get(k, -1)
    print("  %-42s %.6f  %s" % (lab, d, "图案钉住 ✓" if d < 1e-6 else "图案滑动 ✗"))
print("COMBO_DONE")
