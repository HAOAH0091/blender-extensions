"""自查：状态循环（锁定→解锁→重置→再锁定）有没有残留。

残留检查点：
  · mesh 顶点属性 BASE_ATTR / CAMPOS_ATTR 是否重复堆积
  · obj 自定义属性 OBJ_CAM_KEY
  · scene[GROUPS_KEY]
  · Camera Project 组的补丁（PATCH_KEY + Attribute 节点）
  · lens 节点的 driver 是否恢复
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = r"D:\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(n, cond, d=""):
    (P if cond else F).append(n)
    print("  [%s] %-46s %s" % ("PASS" if cond else "FAIL", n, d))

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
cd = bpy.data.cameras.new("C"); cd.lens = 50.0
cam = bpy.data.objects.new("C", cd)
scene.collection.objects.link(cam)
cam.location = (0, -6, 0); cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()
for i in range(3):
    bpy.ops.mesh.primitive_cube_add(size=2, location=(i * 3 - 3, 0, 0))
    o = bpy.context.active_object
    o.name = "Box%d" % i
    o.location = (i * 3 - 3, 16, 0)
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
lens_node = next((n for n in grp.nodes if n.type == "VALUE" and n.label == "Lens"), None)
# 真实场景里 mesh 有投影材质（引用该 Camera Project 组）—— 必须复现，否则 campos 不会被写
_mat = bpy.data.materials.new("Proj")
_mat.use_nodes = True
_nt = _mat.node_tree
_nt.nodes.clear()
_gn = _nt.nodes.new("ShaderNodeGroup"); _gn.node_tree = grp
_out = _nt.nodes.new("ShaderNodeOutputMaterial")
_nt.links.new(_gn.outputs["Vector"], _out.inputs["Surface"])
for o in meshes:
    o.data.materials.clear(); o.data.materials.append(_mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (o.data.name, cd.name), "ShaderNodeTree")


def attr_count(o, name):
    return len([a for a in o.data.attributes if a.name == name])


def snapshot():
    return {
        "base": sum(attr_count(o, plock.BASE_ATTR) for o in meshes),
        "campos": sum(attr_count(o, plock._campos_attr_name(cd.name)) for o in meshes),
        "objkey": sum(1 for o in meshes if o.get(plock.OBJ_CAM_KEY)),
        "groups": bool(plock.load_groups(scene)),   # 用解析后的 dict 判空（"{}" 是 truthy 字符串）
        "patch": bool(grp.get(plock.PATCH_KEY)),
        "attrnode": len([n for n in grp.nodes if n.type == "ATTRIBUTE"
                         and n.attribute_name == plock._campos_attr_name(cd.name)]),
        "lensdrv": bool(lens_node.outputs["Value"].driver_add
                        and lens_node.outputs["Value"].is_property_set("default_value") is not None),
    }


print("初始:", snapshot())

# 1 锁定
r = plock.lock_group(scene, cam)
s1 = snapshot()
chk("锁定成功", r["success"], r["message"][:40])
chk("锁定后：base 属性 = 3（每 mesh 1 个）", s1["base"] == 3, "→%d" % s1["base"])
chk("锁定后：campos 属性 = 3", s1["campos"] == 3, "→%d" % s1["campos"])
chk("锁定后：obj 标记 = 3", s1["objkey"] == 3, "→%d" % s1["objkey"])
chk("锁定后：组补丁在", s1["patch"])
chk("锁定后：Attribute 节点 = 1", s1["attrnode"] == 1, "→%d" % s1["attrnode"])

# 2 解锁
r = plock.unlock_group(scene, cam)
s2 = snapshot()
chk("解锁成功", r["success"])
chk("解锁后：enabled=False", not plock.is_locked(scene, cam))
chk("解锁后：补丁仍在（图案保持冻结）", s2["patch"])

# 3 再锁定（解锁后再锁）→ 不应堆积属性
r = plock.lock_group(scene, cam)
s3 = snapshot()
chk("再锁定成功", r["success"])
chk("再锁定：base 属性仍 = 3（无堆积）", s3["base"] == 3, "→%d" % s3["base"])
chk("再锁定：campos 仍 = 3", s3["campos"] == 3, "→%d" % s3["campos"])
chk("再锁定：Attribute 节点仍 = 1", s3["attrnode"] == 1, "→%d" % s3["attrnode"])

# 4 重置 → 应彻底清干净
r = plock.reset_group(scene, cam)
s4 = snapshot()
chk("重置成功", r["success"])
chk("重置后：base 属性 = 0", s4["base"] == 0, "→%d" % s4["base"])
chk("重置后：campos 属性 = 0", s4["campos"] == 0, "→%d" % s4["campos"])
chk("重置后：obj 标记 = 0", s4["objkey"] == 0, "→%d" % s4["objkey"])
chk("重置后：scene groups 清空", not s4["groups"])
chk("重置后：补丁清除", not s4["patch"])
chk("重置后：Attribute 节点移除", s4["attrnode"] == 0, "→%d" % s4["attrnode"])

# 5 重置后再锁定 → 仍能工作
r = plock.lock_group(scene, cam)
s5 = snapshot()
chk("重置后再锁定成功", r["success"])
chk("重置后再锁定：base=3", s5["base"] == 3, "→%d" % s5["base"])
chk("重置后再锁定：补丁重建", s5["patch"])

print("\nPASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("CYCLE_DONE")
