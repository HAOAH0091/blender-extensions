"""可视化：用户拖动锁定网格 → 画面钉住不变、但深度真的变了。

场景：相机 + 3 个不同深度的球（投影棋盘+靶心图案）
序列：
  1) 锁定 → 相机视图 + 顶视图
  2) 用户沿视线把最前面的球推远 5 单位 → 再拍两张
预期：相机视图【完全一样】（图案钉在画面原位）；顶视图里该球【明显后退】
"""
import bpy
import sys
import os
import math
import bmesh
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
PKG = "compify_plock_dev"
D = PKG_DIR
spec = importlib.util.spec_from_file_location(PKG, os.path.join(D, "__init__.py"),
                                              submodule_search_locations=[D])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

OUT = os.path.join(IDES_HOME, "workspace", "_plock_usermove")
os.makedirs(OUT, exist_ok=True)

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
sc.camera = cam
bpy.context.view_layer.update()

# 图案：棋盘 + 中央红靶心
W = H = 512
img = bpy.data.images.new("Footage", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        v = 0.93 if ((x // 32) + (y // 32)) % 2 else 0.06
        R = G = B = v
        d = math.hypot(x - W / 2, y - H / 2)
        if d < 66:
            R, G, B = 0.95, 0.10, 0.09
        elif d < 76:
            R, G, B = 0.98, 0.98, 0.98
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)


def make_material(name):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup")
    g.node_tree = grp
    t = nt.nodes.new("ShaderNodeTexImage")
    t.image = img
    e = nt.nodes.new("ShaderNodeEmission")
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], t.inputs["Vector"])
    nt.links.new(t.outputs["Color"], e.inputs["Color"])
    nt.links.new(e.outputs["Emission"], o.inputs["Surface"])
    return m


objs = []
for i, (x, depth) in enumerate([(-5.0, 9.0), (0.0, 16.0), (5.0, 24.0)]):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=1.5, location=(x, -6.0 + depth, 0.0))
    o = bpy.context.active_object
    o.name = "MK%d" % i
    bpy.ops.object.shade_smooth()
    o.data.materials.append(make_material("M%d" % i))
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (o.data.name, cd.name), "ShaderNodeTree")
    objs.append(o)
bpy.context.view_layer.update()

# 顶视图相机 + 相机替身
td = bpy.data.cameras.new("TopCam")
td.type = "ORTHO"
td.ortho_scale = 46.0
top = bpy.data.objects.new("TopCam", td)
sc.collection.objects.link(top)
top.location = (0.0, 0.0, 60.0)

pm = bpy.data.meshes.new("Proxy")
bm = bmesh.new()
bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=4,
                      radius1=0.0, radius2=2.2, depth=7.0)
bm.to_mesh(pm)
bm.free()
proxy = bpy.data.objects.new("Proxy", pm)
sc.collection.objects.link(proxy)
pmx = bpy.data.materials.new("Px")
pmx.use_nodes = True
b = pmx.node_tree.nodes["Principled BSDF"]
b.inputs["Base Color"].default_value = (1.0, 0.5, 0.0, 1)
b.inputs["Emission Color"].default_value = (1.0, 0.45, 0.0, 1)
b.inputs["Emission Strength"].default_value = 2.5
pm.materials.append(pmx)

if sc.world is None:
    sc.world = bpy.data.worlds.new("W")
sc.world.use_nodes = True
sc.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
sc.render.image_settings.media_type = "IMAGE"
sc.render.image_settings.file_format = "PNG"
sc.render.engine = "CYCLES"
sc.cycles.samples = 16
sc.cycles.device = "CPU"


def shot(name, camobj, proxy_on, rx=760, ry=340):
    _rx, _ry = sc.render.resolution_x, sc.render.resolution_y
    proxy.hide_render = not proxy_on
    sc.camera = camobj
    sc.render.resolution_x, sc.render.resolution_y = rx, ry
    sc.render.filepath = os.path.join(OUT, name + ".png")
    bpy.ops.render.render(write_still=True)
    sc.render.resolution_x, sc.render.resolution_y = _rx, _ry
    print("SHOT", name)


def sync_proxy():
    proxy.matrix_world = cam.matrix_world.copy()
    bpy.context.view_layer.update()


r = plock.lock_group(sc, cam)
print("LOCK:", r["success"], r["message"])
st = plock.get_state(sc, cam)
view = __import__("mathutils").Matrix(
    [__import__("mathutils").Vector(row) for row in st["locked_matrix"]])

shot("1_view_before", cam, False)
sync_proxy()
shot("1_top_before", top, True, 420, 760)

# ★ 用户拖动：把最前面的球沿视线推远 5
import mathutils
axis = view.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))
objs[0].location = objs[0].location + axis * 5.0
bpy.context.view_layer.update()
print("USER MOVE: MK0 拖动后 location =", tuple(round(v, 3) for v in objs[0].location))

plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("HANDLED : MK0 规范化后 location =", tuple(round(v, 3) for v in objs[0].location))
print("          MK0 scale =", tuple(round(v, 4) for v in objs[0].scale))

shot("2_view_after", cam, False)
sync_proxy()
shot("2_top_after", top, True, 420, 760)
print("RENDER_DONE", OUT)
