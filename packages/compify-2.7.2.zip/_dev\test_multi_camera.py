"""回归测试：多相机隔离 + 补丁刷新 + 错误消息（对应独立审查 S1~S4）。

S1  重置相机 A 不得清掉相机 B 的冻结坐标
S2  互斥迁移时，只要旧相机还留着别的网格，就不得撤它的补丁
S3  「锁定→解锁→改焦距→再锁定」必须刷新冻结的 lens 值
S4  全部因"顶点在相机后方"被跳过时，message 要说明真原因
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = r"D:\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(n, cond, d=""):
    (P if cond else F).append(n)
    print("  [%s] %-54s %s" % ("PASS" if cond else "FAIL", n, d))


def make_cam(name, x):
    cd = bpy.data.cameras.new(name); cd.lens = 50.0
    c = bpy.data.objects.new(name, cd)
    bpy.context.scene.collection.objects.link(c)
    c.location = (x, -6, 0); c.rotation_euler = (math.radians(90), 0, 0)
    bpy.context.view_layer.update()
    return c


def make_box(name, x, z):
    bpy.ops.mesh.primitive_cube_add(size=2, location=(x, 16, z))
    o = bpy.context.active_object
    o.name = name
    return o


def proj_mat(cam, tagname):
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    m = bpy.data.materials.new(tagname)
    m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], out.inputs["Surface"])
    return m


def has(o, attr):
    return o.data.attributes.get(attr) is not None


def grp_of(cam, key):
    return bpy.data.node_groups.get("Camera Project | " + cam.data.name).get(key)


def has_patch(cam):
    ng = bpy.data.node_groups.get("Camera Project | " + cam.data.name)
    return bool(ng and ng.get(plock.PATCH_KEY))


# ══ S1：两相机并行锁定，reset 一个不得动另一个 ══
print("\n=== S1 两相机隔离 ===")
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
camA = make_cam("CamA", 0.0)
camB = make_cam("CamB", 0.0)
camB.location = (0, -6, 0)
bpy.context.view_layer.update()
boxA = make_box("BoxA", -3, 0)
boxB = make_box("BoxB", 3, 0)
matA = proj_mat(camA, "MatA"); matB = proj_mat(camB, "MatB")
boxA.data.materials.append(matA)
boxB.data.materials.append(matB)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (boxA.data.name, camA.data.name), "ShaderNodeTree")
bpy.data.node_groups.new("UV Adjust | %s | %s" % (boxB.data.name, camB.data.name), "ShaderNodeTree")

chk("A 锁定", plock.lock_group(sc, camA)["success"])
chk("B 锁定", plock.lock_group(sc, camB)["success"])
chk("锁后：A/B 都有冻结坐标", has(boxA, plock._campos_attr_name(camA.data.name)) and has(boxB, plock._campos_attr_name(camB.data.name)))

r = plock.reset_group(sc, camA)
chk("重置 A 成功", r["success"])
chk("重置 A 后：A 的冻结坐标已清", not has(boxA, plock._campos_attr_name(camA.data.name)))
chk("重置 A 后：B 的冻结坐标【仍在】", has(boxB, plock._campos_attr_name(camB.data.name)),
    "← 关键：不能连坐")
chk("重置 A 后：B 补丁仍在", has_patch(camB))
chk("重置 A 后：B 仍为已锁定", plock.is_locked(sc, camB))
chk("重置 A 后：B 归属标记仍是 B", boxB.get(plock.CAMPOS_OWNER_KEY) == camB.data.name)

# ══ S2：互斥迁移不得撤掉旧相机的补丁（旧相机还有别的网格）══
print("\n=== S2 互斥迁移 ===")
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
camA = make_cam("CamA", 0.0)
camB = make_cam("CamB", 0.0)
box1 = make_box("Box1", -3, 0)
box2 = make_box("Box2", 0, 0)
box3 = make_box("Box3", 3, 0)
matA = proj_mat(camA, "MatA")
box1.data.materials.append(matA); box2.data.materials.append(matA)
for o in (box1, box2):
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (o.data.name, camA.data.name), "ShaderNodeTree")
# Box1 同时归 B 管（B 的 UV Adjust 组）
bpy.data.node_groups.new("UV Adjust | %s | %s" % (box1.data.name, camB.data.name), "ShaderNodeTree")
box1.data.materials.append(proj_mat(camB, "MatB"))

ra = plock.lock_group(sc, camA)
chk("A 锁定 2 个网格", ra["success"] and len(ra["locked"]) == 2, ra["message"][:34])
chk("A 补丁在", has_patch(camA))

rb = plock.lock_group(sc, camB)
chk("B 抢走 Box1 成功", rb["success"], rb["message"][:34])
chk("B 补丁在", has_patch(camB))
chk("A 仍留着 Box2 → A 补丁【必须还在】", has_patch(camA), "← 关键：判空才撤")
chk("A 组仍在锁定态", plock.is_locked(sc, camA))
stA = plock.get_state(sc, camA)
chk("A 组只剩 Box2", stA.get("objects") == [box2.name], "→%s" % stA.get("objects"))
chk("Box2 的冻结坐标仍在", has(box2, plock._campos_attr_name(camA.data.name)))

# ══ S3：解锁 → 改焦距 → 再锁定，冻结 lens 要刷新 ══
print("\n=== S3 再锁定刷新 lens ===")
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cam = make_cam("Cam", 0.0)
box = make_box("Box", 0, 0)
box.data.materials.append(proj_mat(cam, "Mat"))
bpy.data.node_groups.new("UV Adjust | %s | %s" % (box.data.name, cam.data.name), "ShaderNodeTree")
lens_node = next(n for n in bpy.data.node_groups["Camera Project | " + cam.data.name].nodes
                 if n.type == "VALUE" and n.label == "Lens")

cam.data.lens = 50.0; bpy.context.view_layer.update()
plock.lock_group(sc, cam)
chk("锁定后 lens 节点 = 50", abs(lens_node.outputs["Value"].default_value - 50.0) < 1e-4,
    "→%.2f" % lens_node.outputs["Value"].default_value)
plock.unlock_group(sc, cam)

cam.data.lens = 85.0; bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
chk("改焦距后再锁定成功", r["success"])
# 冻结值【保持】不变（外观契约：重新锁定不得改变画面）。
# 注意它与 state.locked_focal 是两个不同的东西：
#   组内冻结 lens = 冻结外观；locked_focal = 变焦/几何基准。
chk("再锁定后：组内冻结 lens 保持不变（不跳变）",
    abs(lens_node.outputs["Value"].default_value - 50.0) < 1e-4,
    "→%.2f" % lens_node.outputs["Value"].default_value)
st = plock.get_state(sc, cam)
chk("state.locked_focal = 相机当前焦距（变焦基准，保证锁定那刻 zoom=1）",
    abs(float(st["locked_focal"]) - 85.0) < 1e-4,
    "state=%.1f 相机=%.1f" % (st["locked_focal"], cam.data.lens))

# ══ S4：全在相机后方 → message 说明真原因 ══
print("\n=== S4 错误消息 ===")
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cam = make_cam("Cam", 0.0)
behind = make_box("Behind", 0, 0)          # 放在相机【后方】（相机朝 +Y，box 在 y<相机）
behind.location = (0, -20, 0)
bpy.context.view_layer.update()
behind.data.materials.append(proj_mat(cam, "Mat"))
bpy.data.node_groups.new("UV Adjust | %s | %s" % (behind.data.name, cam.data.name), "ShaderNodeTree")
r = plock.lock_group(sc, cam)
skipped_reasons = [x[1] for x in r.get("skipped", [])]
chk("锁定失败（预期）", r["success"] is False)
chk("message 不含误导性的'修改器/形态键'", "修改器" not in r["message"] and "形态键" not in r["message"],
    "message=%s" % r["message"][:60])
chk("message 反映了真原因", ("相机后方" in r["message"]) or (skipped_reasons and "相机后方" in skipped_reasons),
    "skipped=%s" % skipped_reasons)

# ══ S6：解锁之后仍必须能重置（UI 的重置按钮不能在解锁后消失）══
print("\n=== S6 解锁后仍可重置 ===")
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cam = make_cam("Cam", 0.0)
box = make_box("Box", 0, 0)
box.data.materials.append(proj_mat(cam, "Mat"))
bpy.data.node_groups.new("UV Adjust | %s | %s" % (box.data.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
_orig = [tuple(v.co) for v in box.data.vertices]

plock.lock_group(sc, cam)
chk("锁定后：is_locked=True 且 has_lock_record=True",
    plock.is_locked(sc, cam) and plock.has_lock_record(sc, cam))

# 移相机让网格变形，再解锁
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
_moved = [tuple(v.co) for v in box.data.vertices]
chk("移动相机后网格确实变形了", max(max(abs(_moved[i][j] - _orig[i][j]) for j in range(3))
                                    for i in range(len(_orig))) > 1e-4)

plock.unlock_group(sc, cam)
chk("解锁后：is_locked=False", not plock.is_locked(sc, cam))
chk("解锁后：has_lock_record 仍 True（→ UI 仍显示重置）", plock.has_lock_record(sc, cam),
    "← 关键：否则解锁后用户再也回不到原形")

cam.location.x -= 2.0
bpy.context.view_layer.update()
r = plock.reset_group(sc, cam)
chk("解锁后仍能重置", r["success"], r["message"][:34])
_back = [tuple(v.co) for v in box.data.vertices]
_err = max(max(abs(_back[i][j] - _orig[i][j]) for j in range(3)) for i in range(len(_orig)))
chk("重置后顶点恢复原形", _err < 1e-5, "max_err=%.2e" % _err)
chk("重置后：记录清空（UI 隐藏重置）", not plock.has_lock_record(sc, cam))

print("\nPASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("MULTICAM_DONE")
