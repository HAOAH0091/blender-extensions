"""诊断：相机移动时，图案相对【网格】到底变不变？

三组对比（相机横移 +2）：
  01_initial      初始（参照）
  02_nolock       网格不动 + 投影实时
  03_current      当前实现（网格形变适配 + 投影实时）
  04_frozen       投影冻结（网格不动，TexCoord 指向冻结物体）

判断标准：看"图案在网格上的分布"是否与 01 一致。
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]

scene = bpy.context.scene
cam = bpy.data.objects["Camera"]
meshes = [o for o in scene.objects if o.type == "MESH"]
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam.data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

# 图案：棋盘 + 同心环
W = H = 512
img = bpy.data.images.new("Pat", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        c = ((x // 32) + (y // 32)) % 2
        r = math.hypot(x - W / 2, y - H / 2)
        ring = 1.0 if int(r) // 40 % 2 == 0 else 0.0
        px[i] = c * 0.9
        px[i + 1] = ring
        px[i + 2] = 0.3
        px[i + 3] = 1.0
img.pixels.foreach_set(px)
img.pack()

# compify 风格透视投影材质：TexCoord.Object(=相机) → x/z, y/z → Image
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
tc = nt.nodes.new("ShaderNodeTexCoord")
tc.object = cam
sep = nt.nodes.new("ShaderNodeSeparateXYZ")
m1 = nt.nodes.new("ShaderNodeMath"); m1.operation = "DIVIDE"
m2 = nt.nodes.new("ShaderNodeMath"); m2.operation = "DIVIDE"
n1 = nt.nodes.new("ShaderNodeMath"); n1.operation = "MULTIPLY"; n1.inputs[1].default_value = -1.0
n2 = nt.nodes.new("ShaderNodeMath"); n2.operation = "MULTIPLY"; n2.inputs[1].default_value = -1.0
comb = nt.nodes.new("ShaderNodeCombineXYZ")
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(tc.outputs["Object"], sep.inputs["Vector"])
nt.links.new(sep.outputs["X"], m1.inputs[0]); nt.links.new(sep.outputs["Z"], m1.inputs[1])
nt.links.new(sep.outputs["Y"], m2.inputs[0]); nt.links.new(sep.outputs["Z"], m2.inputs[1])
nt.links.new(m1.outputs[0], n1.inputs[0])
nt.links.new(m2.outputs[0], n2.inputs[0])
nt.links.new(n1.outputs[0], comb.inputs["X"])
nt.links.new(n2.outputs[0], comb.inputs["Y"])
nt.links.new(comb.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

scene.render.resolution_x = scene.render.resolution_y = 512
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
scene.render.engine = "CYCLES"
scene.cycles.samples = 16
scene.cycles.device = "CPU"

OUT = os.path.join(IDES_HOME, "workspace", "_plock_diag")
os.makedirs(OUT, exist_ok=True)


def shot(n):
    scene.render.filepath = os.path.join(OUT, n)
    bpy.ops.render.render(write_still=True)
    print("SHOT %s" % n)


start = tuple(cam.location)
bpy.context.view_layer.update()
shot("01_initial.png")

cam.location.x += 2.0
bpy.context.view_layer.update()
shot("02_nolock.png")

cam.location = start
bpy.context.view_layer.update()
res = plock.lock_group(scene, cam)
print("LOCK", res["success"], res["message"])
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
shot("03_current.png")

plock.reset_group(scene, cam)
plock.unlock_group(scene, cam)
cam.location = start
bpy.context.view_layer.update()
frozen = bpy.data.objects.new("Frozen", None)
scene.collection.objects.link(frozen)
frozen.matrix_world = cam.matrix_world.copy()
tc.object = frozen
cam.location.x += 2.0
bpy.context.view_layer.update()
shot("04_frozen.png")

print("DIAG_DONE")
