"""端到端验证：6×Suzanne + 1 相机 的网格视差锁定。
自包含：没传入外部 blend 时自动构建场景（不依赖任何外部文件）。

验证：
  1. 目标识别（哪些 mesh 被判定为"带投射 UV"）
  2. 锁定 → 移相机 → 所有顶点屏幕位移一致（投影不变、整体滚动）
  3. 重置 → 顶点完全恢复
  4. （可选）相机旋转 / 变焦
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]

scene = bpy.context.scene


def _scene_ready(sc):
    """已经有一个可直接测的场景？（外部 blend 已由 --background <file> 载入）"""
    return (any(o.type == "CAMERA" for o in sc.objects)
            and len([o for o in sc.objects if o.type == "MESH"]) >= 6)


if not _scene_ready(scene):
    # 没传入外部 blend → 自建等价场景（6×Suzanne + 1 相机），做到【不依赖外部文件】，
    # 这样任何机器上都能跑（此前硬依赖 F:\desktop\test.blend）。
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    _cd = bpy.data.cameras.new("Camera")
    _cd.lens = 50.0
    _cam = bpy.data.objects.new("Camera", _cd)
    scene.collection.objects.link(_cam)
    _cam.location = (0.0, -18.0, 0.0)
    _cam.rotation_euler = (math.radians(90), 0.0, 0.0)
    bpy.context.view_layer.update()
    for _i in range(6):
        bpy.ops.mesh.primitive_monkey_add(
            size=2.0,
            location=((_i % 3 - 1) * 5.0, 0.5 * (_i // 3), (_i % 3 - 1) * 3.5))
        bpy.context.active_object.name = "Suzanne.%03d" % _i
    bpy.context.view_layer.update()
    print("BUILT_SUZANNE_SCENE (no external blend)")

print("scene:", scene.name)
cam = bpy.data.objects.get("Camera")
if cam is None:
    cam = next(o for o in scene.objects if o.type == "CAMERA")
print("camera:", cam.name, "loc=", tuple(round(x, 3) for x in cam.location),
      "rot=", tuple(round(math.degrees(x), 1) for x in cam.rotation_euler), "lens=", cam.data.lens)

meshes = [o for o in scene.objects if o.type == "MESH"]
print("meshes:", len(meshes), [o.name for o in meshes][:8])

# 模拟 compify 已生成 UV Adjust 组（名称符合约定）
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam.data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

targets = plock.get_lock_targets(scene, cam)
print("TARGETS=%d %s" % (len(targets), [o.name for o in targets]))

PASS, FAIL = [], []
def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %s %s" % ("PASS" if cond else "FAIL", name, detail))


def screen_all():
    vi = plock.get_camera_view_matrix(cam).inverted()
    out = []
    for o in meshes:
        mw = o.matrix_world
        for v in o.data.vertices:
            cs = vi @ (mw @ v.co)
            d = -cs.z
            out.append((cam.data.lens * cs.x / (d * cam.data.sensor_width),
                        cam.data.lens * cs.y / (d * cam.data.sensor_width)))
    return out


def world_all():
    out = []
    for o in meshes:
        mw = o.matrix_world
        for v in o.data.vertices:
            out.append(tuple(mw @ v.co))
    return out


res = plock.lock_group(scene, cam)
check("锁定成功", res["success"], res["message"])

S0 = screen_all()
W0 = world_all()

# 相机横移
cam.location.x += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
S1 = screen_all()
dx = [S1[i][0] - S0[i][0] for i in range(len(S0))]
dy = [S1[i][1] - S0[i][1] for i in range(len(S0))]
print("  Δx range: %.6f ~ %.6f (spread=%.2e)" % (min(dx), max(dx), max(dx) - min(dx)))
check("横移后屏幕位移一致", (max(dx) - min(dx)) < 1e-6, "spread=%.2e" % (max(dx) - min(dx)))
check("确实滚动", abs(dx[0]) > 1e-6, "Δx=%.5f" % dx[0])

# 旋转
cam.location.x -= 1.0
cam.rotation_euler.y += math.radians(15)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
S2 = screen_all()
drot = [abs(S2[i][0] - S0[i][0]) + abs(S2[i][1] - S0[i][1]) for i in range(len(S0))]
check("旋转后画面不动", max(drot) < 1e-5, "max=%.2e" % max(drot))

# 重置
cam.rotation_euler.y -= math.radians(15)
bpy.context.view_layer.update()
res2 = plock.reset_group(scene, cam)
W1 = world_all()
err = max(max(abs(W1[i][j] - W0[i][j]) for j in range(3)) for i in range(len(W0)))
check("重置完全恢复", err < 1e-5, "max_err=%.2e" % err)

print("\nPASS %d / FAIL %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("FAILED:", FAIL)
print("E2E_DONE")
