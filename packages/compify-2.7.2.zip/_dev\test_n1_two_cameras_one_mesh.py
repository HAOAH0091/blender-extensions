"""N1 回归：一块 mesh 同时被两个相机投影时，两边的冻结坐标必须互不干扰。

场景（独立审查 N1 的不对称构造）：
  Z = A 的锁定目标（有 UV Adjust | Z | A），且材质里**也**引用了 B 的 Camera Project 组
  W = B 的锁定目标
  → 锁 B 时，B 会按 objects_using_projection 全局给 Z 写冻结坐标。
    旧实现：属性共用一个名字 → 直接覆盖 A 写的那份 → A 在 Z 上的投影静默读错坐标。
    修复后：属性名按相机区分 → Z 同时持有两份，各读各的。
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = r"D:\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(n, cond, d=""):
    (P if cond else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", n, d))


def mkcam(n, x):
    cd = bpy.data.cameras.new(n); cd.lens = 50.0; cd.sensor_width = 36.0
    o = bpy.data.objects.new(n, cd)
    bpy.context.scene.collection.objects.link(o)
    o.location = (x, -6.0, 0.0); o.rotation_euler = (math.radians(90), 0, 0)
    return o


def add_proj_mat(o, c):
    grp = ng.ensure_camera_project_group(c, default_aspect=1.0)
    m = bpy.data.materials.new("M_%s_%s" % (o.name, c.data.name)); m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], out.inputs["Surface"])
    o.data.materials.append(m)


def add_uvadj(o, c):
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (o.data.name, c.data.name), "ShaderNodeTree")


def mkmesh(n, x):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=1.0, location=(x, 16.0, 0.0))
    o = bpy.context.active_object; o.name = n
    return o


def campos(o, camname):
    a = o.data.attributes.get(plock._campos_attr_name(camname))
    if a is None:
        return None
    v = [0.0] * (len(o.data.vertices) * 3)
    a.data.foreach_get("vector", v)
    return v


bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
camA = mkcam("CamA", 0.0)
camB = mkcam("CamB", 8.0)
Z = mkmesh("Z", 0.0)
W = mkmesh("W", 8.0)
add_proj_mat(Z, camA); add_uvadj(Z, camA)     # Z 是 A 的锁定目标
add_proj_mat(Z, camB)                          # Z 也引用 B 的投影（但不是 B 的锁定目标）
add_proj_mat(W, camB); add_uvadj(W, camB)     # W 是 B 的锁定目标
bpy.context.view_layer.update()

chk("前提：Z 是 A 的锁定目标", Z.name in [o.name for o in plock.get_lock_targets(scene, camA)])
chk("前提：Z 也在 B 的投影用户里", Z.name in
    [o.name for o in plock.objects_using_projection(camB.data.name)])

rA = plock.lock_group(scene, camA)
zA = campos(Z, camA.data.name)
chk("A 锁定成功且 Z 有 A 的冻结坐标", rA["success"] and zA is not None)

rB = plock.lock_group(scene, camB)
chk("B 锁定成功", rB["success"], rB["message"][:34])

zA2 = campos(Z, camA.data.name)      # A 那份
zB2 = campos(Z, camB.data.name)      # B 那份
chgA = max(abs(zA[i] - zA2[i]) for i in range(len(zA))) if (zA and zA2) else -1
stA = plock.get_state(scene, camA)

chk("锁 B 后：A 那份冻结坐标【未被改动】", chgA >= 0 and chgA < 1e-6, "改动量=%.6f" % chgA)
chk("锁 B 后：Z 另有 B 的那份冻结坐标", zB2 is not None,
    "← 两份并存，各相机读各的")
chk("锁 B 后：A 仍锁定 Z 且坐标有效", stA.get("enabled") and Z.name in stA.get("objects", []))

# A 的补丁设备必须指向 A 那份属性名
ngA = bpy.data.node_groups["Camera Project | " + camA.data.name]
attrA = [n for n in ngA.nodes if n.type == "ATTRIBUTE"]
chk("A 组的 Attribute 节点指向 A 的属性名",
    bool(attrA) and attrA[0].attribute_name == plock._campos_attr_name(camA.data.name),
    "→%s" % (attrA[0].attribute_name if attrA else None))
ngB = bpy.data.node_groups["Camera Project | " + camB.data.name]
attrB = [n for n in ngB.nodes if n.type == "ATTRIBUTE"]
chk("B 组的 Attribute 节点指向 B 的属性名",
    bool(attrB) and attrB[0].attribute_name == plock._campos_attr_name(camB.data.name),
    "→%s" % (attrB[0].attribute_name if attrB else None))
chk("A/B 的属性名不同", attrA and attrB and attrA[0].attribute_name != attrB[0].attribute_name)

# 重置 A：只清 A 那份，B 的必须留着
plock.reset_group(scene, camA)
chk("重置 A 后：Z 的 A 份已清", campos(Z, camA.data.name) is None)
chk("重置 A 后：Z 的 B 份【仍在】", campos(Z, camB.data.name) is not None)
chk("重置 A 后：B 仍锁定", plock.is_locked(scene, camB))

print("\nPASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("N1_DONE")
