"""三方案对比：相机横移时，「图案相对网格」与「网格相对画面」的表现。

  A) 未锁定           网格不动（现状问题）
  B) 完全冻结 SCROLL=0  网格保持相机空间坐标不变 → 网格钉在画面里
  C) 滚动   SCROLL=1    网格在画面里滚动（当前实现）

判据：同一顶点的【投影 UV】（= 采样到的图案内容）变化量。
      UV 不变 = 图案钉住 ✓ ； UV 变 = 图案滑动 ✗
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]

scene = bpy.context.scene
cam = bpy.data.objects["Camera"]
meshes = [o for o in scene.objects if o.type == "MESH"]
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam.data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

# ── 图案 + 投影材质（等价 compify 的 x/z 透视投影）──
W = H = 512
img = bpy.data.images.new("Pat", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        px[i] = (((x // 32) + (y // 32)) % 2) * 0.9
        r = math.hypot(x - W / 2, y - H / 2)
        px[i + 1] = 1.0 if int(r) // 40 % 2 == 0 else 0.0
        px[i + 2] = 0.3
        px[i + 3] = 1.0
img.pixels.foreach_set(px)
img.pack()

mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
tc = nt.nodes.new("ShaderNodeTexCoord")
tc.object = cam
sep = nt.nodes.new("ShaderNodeSeparateXYZ")
m1 = nt.nodes.new("ShaderNodeMath"); m1.operation = "DIVIDE"
m2 = nt.nodes.new("ShaderNodeMath"); m2.operation = "DIVIDE"
n1 = nt.nodes.new("ShaderNodeMath"); n1.operation = "MULTIPLY"; n1.inputs[1].default_value = -1
n2 = nt.nodes.new("ShaderNodeMath"); n2.operation = "MULTIPLY"; n2.inputs[1].default_value = -1
comb = nt.nodes.new("ShaderNodeCombineXYZ")
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(tc.outputs["Object"], sep.inputs["Vector"])
nt.links.new(sep.outputs["X"], m1.inputs[0]); nt.links.new(sep.outputs["Z"], m1.inputs[1])
nt.links.new(sep.outputs["Y"], m2.inputs[0]); nt.links.new(sep.outputs["Z"], m2.inputs[1])
nt.links.new(m1.outputs[0], n1.inputs[0]); nt.links.new(m2.outputs[0], n2.inputs[0])
nt.links.new(n1.outputs[0], comb.inputs["X"]); nt.links.new(n2.outputs[0], comb.inputs["Y"])
nt.links.new(comb.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

scene.render.resolution_x = scene.render.resolution_y = 512
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
scene.render.engine = "CYCLES"
scene.cycles.samples = 16
scene.cycles.device = "CPU"
OUT = os.path.join(IDES_HOME, "workspace", "_plock_abc")
os.makedirs(OUT, exist_ok=True)


def uv_of(world):
    cs = plock.get_camera_view_matrix(cam).inverted() @ world
    return (-cs.x / cs.z, -cs.y / cs.z) if abs(cs.z) > 1e-9 else (0.0, 0.0)


def snapshot():
    out = []
    for o in meshes:
        n = len(o.data.vertices)
        for idx in (0, min(100, n - 1)):
            out.append((o.name, idx, o.matrix_world @ o.data.vertices[idx].co))
    return out


def uv_all():
    return [uv_of(w) for (_, _, w) in snapshot()]


def shot(n):
    scene.render.filepath = os.path.join(OUT, n)
    bpy.ops.render.render(write_still=True)
    print("SHOT %s" % n)


start = tuple(cam.location)
cam.location = start
bpy.context.view_layer.update()
UV0 = uv_all()
shot("01_initial.png")

def moved(name):
    cam.location = (start[0] + 3.0, start[1], start[2])
    bpy.context.view_layer.update()

# A) 未锁定
cam.location = start
bpy.context.view_layer.update()
moved("A")
UVa = uv_all()
shot("02_A_nolock.png")

# B) 完全冻结 SCROLL=0
cam.location = start
bpy.context.view_layer.update()
plock.SCROLL_SCALE = 0.0
plock.lock_group(scene, cam)
moved("B")
plock.parallax_lock_update_handler(scene)
UVb = uv_all()
shot("03_B_freeze_SCROLL0.png")
plock.reset_group(scene, cam)
plock.unlock_group(scene, cam)

# C) 滚动 SCROLL=1
cam.location = start
bpy.context.view_layer.update()
plock.SCROLL_SCALE = 1.0
plock.lock_group(scene, cam)
moved("C")
plock.parallax_lock_update_handler(scene)
UVc = uv_all()
shot("04_C_scroll_SCROLL1.png")

def maxchange(a):
    return max(max(abs(a[i][0] - UV0[i][0]), abs(a[i][1] - UV0[i][1])) for i in range(len(UV0)))

print("\n===== 图案滑动量（投影 UV 最大变化）=====")
print("A 未锁定        : %.6f  %s" % (maxchange(UVa), "滑动" if maxchange(UVa) > 1e-6 else "钉住"))
print("B 冻结 SCROLL=0 : %.6f  %s" % (maxchange(UVb), "滑动" if maxchange(UVb) > 1e-6 else "钉住 ✓"))
print("C 滚动 SCROLL=1 : %.6f  %s" % (maxchange(UVc), "滑动" if maxchange(UVc) > 1e-6 else "钉住"))
print("ABC_DONE")
