"""自查：面板 draw 里调用的 plock 函数在各种边界下不崩。
（draw 里抛异常会让整个面板消失，是最脆弱的调用点）
"""
import bpy
import sys
import os
import json
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = r"D:\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]

P, F = [], []
def chk(n, cond, d=""):
    (P if cond else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", n, d))

scene = bpy.context.scene

# 1) None 相机
try:
    r = plock.is_locked(scene, None); chk("is_locked(scene, None) 不崩", r is False, "→%s" % r)
except Exception as e:
    chk("is_locked(scene, None) 不崩", False, str(e))

# 2) 相机对象但没有 data
try:
    o = bpy.data.objects.new("NoData", None)
    r = plock.is_locked(scene, o); chk("is_locked(无 data 对象) 不崩", r is False, "→%s" % r)
except Exception as e:
    chk("is_locked(无 data 对象) 不崩", False, str(e))

# 3) 有相机、无 groups
cd = bpy.data.cameras.new("C1")
c1 = bpy.data.objects.new("C1", cd); scene.collection.objects.link(c1)
try:
    r = plock.is_locked(scene, c1); chk("未锁定的相机 → False", r is False, "→%s" % r)
except Exception as e:
    chk("未锁定的相机 → False", False, str(e))

# 4) groups JSON 损坏
scene[plock.GROUPS_KEY] = "{这不是合法json"
try:
    r = plock.is_locked(scene, c1); chk("groups JSON 损坏 → 不崩", r is False, "→%s" % r)
    g = plock.load_groups(scene); chk("load_groups 损坏 → {}", isinstance(g, dict) and g == {}, "→%s" % g)
except Exception as e:
    chk("groups JSON 损坏 → 不崩", False, str(e))

# 5) groups 是 JSON 但非 dict（如数组）
scene[plock.GROUPS_KEY] = "[1,2,3]"
try:
    g = plock.load_groups(scene); chk("groups 为数组 → {}", g == {}, "→%s" % g)
except Exception as e:
    chk("groups 为数组 → {}", False, str(e))

# 6) 相机 data 名在 groups 里但 enabled 缺失
scene[plock.GROUPS_KEY] = json.dumps({"C1": {}})
try:
    r = plock.is_locked(scene, c1); chk("enabled 缺失 → False", r is False, "→%s" % r)
except Exception as e:
    chk("enabled 缺失 → False", False, str(e))

# 7) 空场景（无任何物体）→ get_lock_targets
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
try:
    t = plock.get_lock_targets(scene, None); chk("空场景 get_lock_targets(None) → []", t == [], "→%s" % t)
except Exception as e:
    chk("空场景 get_lock_targets(None) → []", False, str(e))

# 8) 空场景锁定 → 应优雅失败
try:
    res = plock.lock_group(scene, None); chk("lock_group(None 相机) 优雅失败", res["success"] is False, res["message"][:40])
except Exception as e:
    chk("lock_group(None 相机) 优雅失败", False, str(e))

# 9) 相机存在但没有任何 mesh → 优雅失败
cd2 = bpy.data.cameras.new("C2"); c2 = bpy.data.objects.new("C2", cd2)
scene.collection.objects.link(c2); c2.location = (0, -5, 0)
bpy.context.view_layer.update()
try:
    res = plock.lock_group(scene, c2); chk("无目标网格 → 优雅失败", res["success"] is False, res["message"][:40])
except Exception as e:
    chk("无目标网格 → 优雅失败", False, str(e))

scene.pop(plock.GROUPS_KEY, None)
print("\nPASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("EDGE_DONE")
