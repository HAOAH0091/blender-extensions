"""
Compify 网格视差锁定（Grid Parallax Lock）

相机移动时：
  ① 网格逐顶点变形，适配视锥体（保持构图）—— 用户已确认想要的"网格变形"
  ② 投影 UV 冻结在锁定那一刻 —— 图案死死长在网格表面：不滑动、不变形

② 的机制（关键）：
  compify 的 Camera Project 组数学是 `UV = Affine(相机空间坐标)`，
  第一个节点是 `TexCoord(object=相机)` → 输出"顶点在相机空间的坐标"。
  ⇒ 把【锁定那一刻的相机空间坐标】冻成顶点属性、喂给投影组，
    投影算出来就【永远】等于锁定时的 UV ⇒ 图案完美跟随网格变形。

  （对比：把 TexCoord 的 object 换成"冻结的相机物体"= 只冻结了投影源，
    网格一变形，坐标照样变 → 图案还会滑（残差约 0.0094）——不彻底。）

存储：
  · mesh attribute "compify_plock_base"     FLOAT_VECTOR  — 变形用（相机空间坐标，剥离相机 scale）
  · mesh attribute "compify_plock_campos"   FLOAT_VECTOR  — 图案冻结用（相机空间坐标，含 scale，与 TexCoord 语义一致）
  · scene["compify_plock_groups"]           JSON          — 每相机的锁定状态
  · obj["compify_plock_camera"]             str           — 该 obj 被哪个相机锁定（互斥）
  · Camera Project 组的自定义属性 "compify_plock_patch"    — 组内补丁的还原记录
"""

import bpy
import json
import mathutils
from bpy.app.handlers import persistent

MIN_DEPTH = 1e-4
CAMERA_CHANGE_THRESHOLD = 1e-4
SCROLL_SCALE = 1.0

# 变焦时"优先移动相机"：
#   True  = 变焦时自动沿视线推拉相机（相机真的会动），网格只补偿剩余部分
#   False = 相机不动，全靠网格变形（旧行为）
# 两种模式下「构图冻结」都成立；差别只在【相机是否物理移动】。
CAMERA_DOLLY_ZOOM = True

# 用户拖动锁定网格 → 按「视差语义」重新锚定（对齐 PSD 拖图层的语义）：
#   · 屏幕坐标保持不变（网格钉在画面原位，横向拖动被拉回）
#   · 深度取用户拖出来的那个 → 改变该网格的视差滚动（= 调"间距"）
#   · 同步缩放，保持画面里的尺寸不变
#   · 新状态【写回基准】—— 否则之后一动相机网格又弹回（PSD v3.12.5 修过的坑）
LAYER_MOVE_ENABLED = True
MATRIX_KEY = "compify_plock_last_matrix"   # 每 mesh：上次"正确位姿"（世界矩阵 16 个 float）
MOVE_THRESHOLD = 1e-6
# 拖动累积的「相机空间缩放」。用**标量**记录，而不是把 base 顶点属性逐个 ×k ——
# 拖动时每帧都会跑到这里，遍历几十万顶点会卡死（用户实测很卡）。
DRAG_SCALE_KEY = "compify_plock_drag_scale"
# 网格局部形心缓存：局部形心只随顶点变化、不随物体位姿变化，
# 避免每次拖动都遍历顶点求形心。
CENTER_KEY = "compify_plock_center"

BASE_ATTR = "compify_plock_base"
CAMPOS_ATTR = "compify_plock_campos"
GROUPS_KEY = "compify_plock_groups"
OBJ_CAM_KEY = "compify_plock_camera"
# 冻结坐标属性是「按物体一份」的，所以必须记录它归哪个相机写。
# 否则重置相机 A 时会把相机 B 的冻结坐标一起删掉（B 的补丁还在 → 读到空属性 → 投影损坏）。
CAMPOS_OWNER_KEY = "compify_plock_campos_owner"


def _campos_attr_name(cam_data_name):
    """冻结坐标属性名 —— **按相机区分**。

    ⚠️ 为什么不能共用一个名字（独立审查 N1）：
    CAMPOS 是"每 mesh 一份"的属性，而一块 mesh 可能同时被【多个相机】投影
    （材质里引用了两个相机的 Camera Project 组）。若共用一个属性名，后锁的相机
    会直接覆盖前一个的冻结坐标 —— 而前一个相机的锁定状态/补丁都没变，
    于是它在同一块 mesh 上的投影会【静默读错坐标】（UI 还显示已锁定，用户看不出）。
    按相机分名字后，每个相机读写自己那一份，互不干扰。
    """
    safe = "".join(c if (c.isalnum() or c == "_") else "_"
                   for c in (cam_data_name or "cam"))
    return "%s__%s" % (CAMPOS_ATTR, safe[:24])
PATCH_KEY = "compify_plock_patch"
ATTR_NODE_NAME = "compify_plock_attr"
UV_ADJUST_PREFIX = "UV Adjust | "
CAM_PROJECT_PREFIX = "Camera Project | "

# 投影组里被 driver 绑到相机数据、会随变焦/移轴变化的 Value 节点
# （节点 label → camera.data 上的对应属性名）—— 锁定后必须一起冻结，
#  否则变焦时投影 UV 仍会变（lens 卡在 zoom_1 = lens/sensor_width 这一步）。
FROZEN_VALUE_LABELS = {
    "Lens": "lens",
    "Sensor Width": "sensor_width",
    "Lens Shift X": "shift_x",
    "Lens Shift Y": "shift_y",
}

_last_view = {}
_base_cache = {}


# ──────────────────────────── 基础工具 ────────────────────────────

def get_camera_view_matrix(camera):
    """相机视图矩阵：只含位置 + 朝向，剥离对象 scale（相机 scale 不参与渲染，但会污染 matrix_world）。"""
    loc, rot, _scale = camera.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def find_camera(scene, cam_data_name):
    for o in scene.objects:
        if o.type == "CAMERA" and o.data and o.data.name == cam_data_name:
            return o
    return None


def get_lock_targets(scene, camera):
    """该相机下所有「带投射 UV」的 mesh 对象（按 UV Adjust 组名反查）。"""
    if camera is None or camera.data is None:
        return []
    cam_data_name = camera.data.name
    suffix = " | " + cam_data_name
    obj_data_names = set()
    for ng in bpy.data.node_groups:
        if ng.name.startswith(UV_ADJUST_PREFIX) and ng.name.endswith(suffix):
            mid = ng.name[len(UV_ADJUST_PREFIX):len(ng.name) - len(suffix)]
            if mid:
                obj_data_names.add(mid)
    out = []
    for o in scene.objects:
        if o.type == "MESH" and o.data and o.data.name in obj_data_names:
            out.append(o)
    return out


def objects_using_projection(cam_data_name):
    """所有材质里引用了该相机 Camera Project 组的 mesh 对象（图案冻结要覆盖它们）。

    ⚠️ 为什么扫 bpy.data.objects（全局）而非 scene.objects：
    Camera Project 节点组是【全局 datablock】—— 补丁一打，凡是引用了它的材质
    在所有场景里都立刻走冻结坐标。所以每一个可能用到它的 mesh 都必须有
    冻结坐标属性，否则 Attribute 节点读不到 → 该物体投影糊成常量。
    """
    gname = CAM_PROJECT_PREFIX + cam_data_name
    out = []
    for o in bpy.data.objects:
        if o.type != "MESH" or o.data is None:
            continue
        hit = False
        for m in o.data.materials:
            nt = getattr(m, "node_tree", None)
            if nt is None:
                continue
            stack = [nt]
            seen = set()
            while stack and not hit:
                t = stack.pop()
                ptr = t.as_pointer()
                if ptr in seen:
                    continue
                seen.add(ptr)
                for n in t.nodes:
                    if n.type == "GROUP" and n.node_tree is not None:
                        if n.node_tree.name == gname:
                            hit = True
                            break
                        stack.append(n.node_tree)
        if hit:
            out.append(o)
    return out


def has_modifier_or_shapekey(obj):
    """返回阻塞原因或 None。"""
    if len(obj.modifiers) > 0:
        return "修改器"
    if obj.data is None:
        return "无网格数据"
    if obj.data.shape_keys is not None:
        return "形态键"
    if obj.data.users > 1:
        return "共享网格"
    return None


# ──────────────────────────── 状态存取 ────────────────────────────

def load_groups(scene):
    raw = scene.get(GROUPS_KEY)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_groups(scene, groups):
    scene[GROUPS_KEY] = json.dumps(groups)


def get_state(scene, camera):
    if camera is None or camera.data is None:
        return None
    return load_groups(scene).get(camera.data.name)


def is_locked(scene, camera):
    st = get_state(scene, camera)
    return bool(st and st.get("enabled"))


def has_lock_record(scene, camera):
    """该相机是否还留有一条锁定记录（无论当前是否启用）。

    用途：面板决定是否显示「重置」按钮。
    「解锁」= 停止跟随但**不回退**（网格与图案保持当前状态），所以解锁之后
    仍然必须能重置 —— 否则用户一解锁就永远回不到原形了。—— 独立审查 S6
    """
    if camera is None or camera.data is None:
        return False
    return load_groups(scene).get(camera.data.name) is not None


# ──────────────────────────── 顶点属性 ────────────────────────────

def _new_vec_attr(mesh, name):
    old = mesh.attributes.get(name)
    if old is not None:
        mesh.attributes.remove(old)
    return mesh.attributes.new(name=name, type="FLOAT_VECTOR", domain="POINT")


def _write_base_attribute(obj, cam_space_list):
    """变形用基准（相机空间坐标，剥离 scale）。"""
    mesh = obj.data
    attr = _new_vec_attr(mesh, BASE_ATTR)
    flat = []
    for (x0, y0, d) in cam_space_list:
        flat.extend((x0, y0, d))
    attr.data.foreach_set("vector", flat)
    mesh.update()
    _base_cache.clear()


def _write_campos_attribute(obj, camera, cam_data_name, mw_inv=None):
    """图案冻结用：相机空间坐标（含相机 scale），与 TexCoord 的 Object 输出语义一致。

    属性名按相机区分（见 `_campos_attr_name`），所以锁相机 B 不会覆盖相机 A 的那份。
    """
    if mw_inv is None:
        mw_inv = camera.matrix_world.inverted()
    mesh = obj.data
    attr = _new_vec_attr(mesh, _campos_attr_name(cam_data_name))
    mwo = obj.matrix_world
    flat = []
    for v in mesh.vertices:
        c = mw_inv @ (mwo @ v.co)
        flat.extend((c.x, c.y, c.z))
    attr.data.foreach_set("vector", flat)
    mesh.update()
    obj[CAMPOS_OWNER_KEY] = cam_data_name      # 归属诊断用


def _campos_is_valid(obj, cam_data_name):
    """该物体是否已有一份可用的冻结坐标属性（顶点数匹配）。"""
    a = obj.data.attributes.get(_campos_attr_name(cam_data_name))
    return a is not None and len(a.data) == len(obj.data.vertices)


def _remove_attr(obj, name):
    mesh = obj.data
    a = mesh.attributes.get(name)
    if a is not None:
        mesh.attributes.remove(a)


def _read_base_attribute(obj):
    mesh = obj.data
    attr = mesh.attributes.get(BASE_ATTR)
    if attr is None:
        return None
    n = len(mesh.vertices)
    if len(attr.data) != n:
        return None
    key = (obj.name, mesh.as_pointer(), n)
    hit = _base_cache.get(key)
    if hit is not None:
        return hit
    flat = [0.0] * (n * 3)
    attr.data.foreach_get("vector", flat)
    out = [(flat[i * 3], flat[i * 3 + 1], flat[i * 3 + 2]) for i in range(n)]
    _base_cache[key] = out
    return out


# ──────────────────────────── 投影组补丁（图案冻结）────────────────────────────

def is_patched(cam_data_name):
    """该相机的投影组当前是否处于「已冻结」状态（补丁在 = 图案正被冻结）。"""
    ng = bpy.data.node_groups.get(CAM_PROJECT_PREFIX + cam_data_name)
    return bool(ng and ng.get(PATCH_KEY))


def patch_camera_project_group(cam_data_name):
    """在 Camera Project 组里，把 TexCoord 的输出替换成冻结坐标属性。

    改法：TexCoord(Object) → [Attribute] → 下游
    ⇒ 投影 UV 恒等于锁定那一刻的值。
    """
    gname = CAM_PROJECT_PREFIX + cam_data_name
    ng = bpy.data.node_groups.get(gname)
    if ng is None:
        return None
    if ng.get(PATCH_KEY):
        # 已打过补丁 → **保持原样**（不要刷新冻结的 lens/sensor/shift）。
        #
        # ⚠️ 曾经按独立审查 S3 的建议「先撤再重打」以刷新冻结值，但那会让
        #    「锁定 → 变焦 → 解锁 → 再锁定」时图案按新焦距缩放 = 用户看到的**跳变**
        #    （图案已经粘在网格上，它的外观必须保持不变）。
        #
        # 冻结值与 state.locked_focal 是【两个不同的东西】：
        #   · 组内冻结的 lens  = 「冻结外观」的参数（决定图案长什么样）
        #   · locked_focal     = 「变焦/几何」的基准（决定 zoom 补偿 = 相机镜头/该值）
        # 各自正确、互不矛盾；锁定那一刻 zoom 恒为 1，不会凭空触发推拉。
        # （S3 的另一半担心「reset 会还原成错误焦距」不成立：unpatch 会重建
        #   driver 并绑回 camera.data，节点会自动跟随相机。）
        return ng
    tc = None
    for n in ng.nodes:
        if n.type == "TEX_COORD" and getattr(n, "object", None) is not None:
            tc = n
            break
    if tc is None:
        return None
    src = None
    for s in tc.outputs:
        if s.links:
            src = s
            break
    if src is None:
        return None
    dests = [[lk.to_node.name, lk.to_socket.identifier] for lk in src.links]
    if not dests:
        return None

    attr = ng.nodes.new("ShaderNodeAttribute")
    attr.attribute_name = _campos_attr_name(cam_data_name)   # 每相机一份（见 _campos_attr_name）
    attr.label = "Plock: Frozen Cam-Space Pos"
    attr.name = ATTR_NODE_NAME
    attr.location = (tc.location.x + 200.0, tc.location.y - 240.0)

    for lk in list(src.links):
        ng.links.remove(lk)
    for nname, ident in dests:
        node = ng.nodes.get(nname)
        if node is None:
            continue
        sock = node.inputs.get(ident)
        if sock is not None:
            ng.links.new(attr.outputs["Vector"], sock)

    # ── 冻结 lens / sensor / shift（否则变焦时 UV 仍会变）──
    cam_data = bpy.data.cameras.get(cam_data_name)
    frozen = []
    if cam_data is not None:
        for n in ng.nodes:
            if n.type == "VALUE" and n.label in FROZEN_VALUE_LABELS:
                out = n.outputs["Value"]
                path = FROZEN_VALUE_LABELS[n.label]
                val = float(getattr(cam_data, path, out.default_value))
                try:
                    out.driver_remove("default_value")
                except Exception:
                    pass
                out.default_value = val
                frozen.append({"node": n.name, "path": path, "value": val})

    ng[PATCH_KEY] = json.dumps({"tc": tc.name, "src": src.identifier,
                                "attr": attr.name, "dests": dests,
                                "frozen": frozen})
    return ng


def unpatch_camera_project_group(cam_data_name):
    gname = CAM_PROJECT_PREFIX + cam_data_name
    ng = bpy.data.node_groups.get(gname)
    if ng is None:
        return
    raw = ng.get(PATCH_KEY)
    if not raw:
        return
    try:
        info = json.loads(raw)
    except Exception:
        return
    attr = ng.nodes.get(info.get("attr", ""))
    if attr is not None:
        for o in attr.outputs:
            for lk in list(o.links):
                ng.links.remove(lk)
        ng.nodes.remove(attr)
    tc = ng.nodes.get(info.get("tc", ""))
    if tc is not None:
        src = tc.outputs.get(info.get("src", ""))
        if src is not None:
            for nname, ident in info.get("dests", []):
                node = ng.nodes.get(nname)
                if node is None:
                    continue
                sock = node.inputs.get(ident)
                if sock is not None:
                    ng.links.new(src, sock)

    # 还原 lens / sensor / shift 的 driver（让变焦重新生效）
    cam_data = bpy.data.cameras.get(cam_data_name)
    for f in info.get("frozen", []):
        n = ng.nodes.get(f.get("node", ""))
        if n is None:
            continue
        out = n.outputs["Value"]
        out.default_value = float(f.get("value", out.default_value))
        if cam_data is None:
            continue
        try:
            drv = out.driver_add("default_value").driver
            drv.type = "SUM"
            var = drv.variables.new()
            var.type = "SINGLE_PROP"
            var.targets[0].id_type = "CAMERA"
            var.targets[0].id = cam_data
            var.targets[0].data_path = f.get("path", "lens")
        except Exception:
            pass

    try:
        del ng[PATCH_KEY]
    except Exception:
        pass


# ──────────────────────────── 变焦 → 相机推拉 ────────────────────────────

def _locked_axis(state):
    """锁定时的光轴（指向场景内）。"""
    view_locked = mathutils.Matrix([mathutils.Vector(r) for r in state["locked_matrix"]])
    return view_locked.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))


def world_to_parent_local(camera, world_vec):
    """世界向量 → 相机【父级空间】向量。

    ⚠️ camera.location 是相对父级的（父级空间），不是世界的。
    相机被父级（空物体 / 骨架等）带着时，把世界向量直接加到 location 上会错位
    （除非父级恰好是 identity）。—— 独立审查发现
    """
    if camera.parent is None:
        return world_vec
    return camera.parent.matrix_world.inverted().to_3x3() @ world_vec


def auto_dolly_vector(state, zoom):
    """变焦补偿中【由相机承担】的那段位移。

    取基准层（ref_depth）为锚点：相机沿光轴移动 ref·(1-k)，
    使基准层靠"相机移动"就能保持构图；其余深度由网格补偿。
    这样：变焦时相机真的在动，而构图仍精确冻结。
    """
    if not CAMERA_DOLLY_ZOOM:
        return mathutils.Vector((0.0, 0.0, 0.0))
    ref = float(state.get("ref_depth", 0.0))
    # k>1（拉长焦=放大）→ 相机后退（负号 = 逆光轴）
    return _locked_axis(state) * (-ref * (float(zoom) - 1.0))


# ──────────────────── 用户拖动锁定网格 → 重新锚定 ────────────────────

def _mesh_center_local(obj):
    """网格顶点在【局部空间】的形心（拖动换算的参考点）。

    ⚠️ 带缓存：局部形心只随**顶点**变化，不随物体位姿变化；而拖动时位姿每帧都变。
    不缓存的话，每次拖动都要遍历全部顶点求形心 —— 几十万顶点 × 每帧 = 卡死。
    （缓存由 adapt_object 失效，因为只有它会改顶点。）

    ⚠️ 别用 `obj.location` 代替：物体原点可能不在网格上（网格有偏移时），
    用它算深度会偏。
    """
    c = obj.get(CENTER_KEY)
    if c is not None and len(c) == 3:
        return mathutils.Vector((c[0], c[1], c[2]))
    mesh = obj.data
    n = len(mesh.vertices)
    if n == 0:
        return mathutils.Vector((0.0, 0.0, 0.0))
    buf = [0.0] * (n * 3)
    mesh.vertices.foreach_get("co", buf)
    v = mathutils.Vector((sum(buf[0::3]) / n,
                          sum(buf[1::3]) / n,
                          sum(buf[2::3]) / n))
    obj[CENTER_KEY] = [v.x, v.y, v.z]
    return v


def _view_depth(view_inv, world_pos):
    """世界点 → 相对相机的深度（正值）。"""
    return -((view_inv @ world_pos).z)


def _mat_close(A, B, eps=MOVE_THRESHOLD):
    for i in range(4):
        for j in range(4):
            if abs(A[i][j] - B[i][j]) > eps:
                return False
    return True


def _read_matrix_key(obj):
    v = obj.get(MATRIX_KEY)
    if not v or len(v) != 16:
        return None
    return mathutils.Matrix([mathutils.Vector(v[i * 4:i * 4 + 4]) for i in range(4)])


def _write_matrix_key(obj, M):
    obj[MATRIX_KEY] = [float(x) for row in M for x in row]


def apply_user_move(obj, camera, view_now):
    """把「用户拖出来的新位置」翻译成视差语义（对齐 PSD 拖图层）。

    `view_now` 必须是【当前】相机的视图矩阵（不是锁定那一刻的）——
    用户是看着当前画面拖的，深度与视线都要按当前相机算。

    推导：要让「屏幕坐标不变 + 深度变 k 倍」同时成立，等价于
    **在相机空间里把整个网格缩放 k 倍** —— 每个顶点沿**自己的视线**移动
    （深的移动多、浅的移动少），即「按视锥体变形」（非刚性）。

    实现要点（性能 + 正确性）：
      · **O(1)**：只改物体位姿 + 一个标量，**不遍历顶点** —— 拖动时每帧都会
        跑到这里，遍历几十万顶点会卡死（用户实测很卡）。
      · **完全不碰 UV**：投影 UV 来自冻结的 `campos` 属性，网格怎么变形都与它无关
        （相机移动时的 adapt_object 也从不动它）。改它会破坏投影 —— 实测踩过。
    返回是否真的处理了。
    """
    if not LAYER_MOVE_ENABLED:
        return False
    M_prev = _read_matrix_key(obj)
    if M_prev is None:
        _write_matrix_key(obj, obj.matrix_world.copy())      # 首次：只记录基准
        return False
    M_cur = obj.matrix_world.copy()
    if _mat_close(M_cur, M_prev):
        return False

    view_inv = view_now.inverted()
    c_local = _mesh_center_local(obj)          # 有缓存，O(1)
    d_prev = _view_depth(view_inv, M_prev @ c_local)
    d_cur = _view_depth(view_inv, M_cur @ c_local)

    if d_prev <= MIN_DEPTH:
        _write_matrix_key(obj, M_cur)          # 基准不可用 → 重新采用当前
        return False
    if d_cur <= MIN_DEPTH:
        # 拖到相机后方/平面上：按锁定语义拉回（否则深度翻负会把场景弄坏）
        obj.matrix_world = M_prev
        bpy.context.view_layer.update()
        _write_matrix_key(obj, obj.matrix_world.copy())
        return False

    k = d_cur / d_prev
    if abs(k - 1.0) <= 1e-9:
        # 纯横向拖动：深度没变 ⇒ 按锁定语义把网格【拉回原位】（画面里拖不动）。
        # ⚠️ 必须真的拉回：否则用户的横向拖动会"看起来自由"，但之后一动相机
        #    就被抹掉（那正是这个功能要修的毛病）。—— 自测发现
        obj.matrix_world = M_prev
        bpy.context.view_layer.update()
        _write_matrix_key(obj, obj.matrix_world.copy())
        return False

    # O(1)：累积「相机空间缩放」标量（供 adapt_object 用），位姿一次设好。
    # UV 属性（campos）**完全不动** —— 网格变形与投影 UV 无关。
    obj[DRAG_SCALE_KEY] = float(obj.get(DRAG_SCALE_KEY, 1.0)) * k
    M_new = view_now @ mathutils.Matrix.Scale(k, 4) @ view_inv @ M_prev
    _write_matrix_key(obj, M_new)      # ★ 先记基准再改位姿：即使重入也不会重复累乘
    obj.matrix_world = M_new
    bpy.context.view_layer.update()
    _write_matrix_key(obj, obj.matrix_world.copy())   # 位姿可能被约束/父级微调，再同步一次
    return True


def recompute_ref_depth(scene, st):
    """重算基准深度 = 所有锁定网格里【最深顶点】的深度。

    拖动改变了深度 ⇒ 基准层可能换人 ⇒ 必须重算，否则各网格的
    视差系数 k=d/ref 全错、滚动速度不对。
    """
    best = 0.0
    for name in st.get("objects", []):
        o = scene.objects.get(name)
        if o is None or o.type != "MESH" or o.data is None:
            continue
        b = _read_base_attribute(o)
        if not b:
            continue
        drag = float(o.get(DRAG_SCALE_KEY, 1.0))     # 拖动改过深度，要算进去
        m = max(d for (_x, _y, d) in b) * drag
        if m > best:
            best = m
    if best > MIN_DEPTH:
        st["ref_depth"] = float(best)
    return float(st.get("ref_depth", 0.0))


# ──────────────────────────── 核心：适配 ────────────────────────────

def adapt_object(obj, camera, state, view_now=None):
    base = _read_base_attribute(obj)
    if base is None:
        return False
    if view_now is None:
        view_now = get_camera_view_matrix(camera)
    view_locked = mathutils.Matrix([mathutils.Vector(r) for r in state["locked_matrix"]])
    ref_depth = float(state["ref_depth"])
    focal_locked = float(state["locked_focal"]) or MIN_DEPTH

    focal_now = camera.data.lens
    zoom = (focal_now / focal_locked) if focal_locked > MIN_DEPTH else 1.0
    zoom = max(zoom, MIN_DEPTH)

    # ⚠️ 归因：变焦时自动施加给相机的那段 dolly 必须【排除】在相机位移之外，
    #    否则它会和 zoom 重复计算（depth 变成 d·k²）。
    eye_now = view_now.translation
    eye_user = eye_now - auto_dolly_vector(state, zoom)

    cur_rot = view_now.to_3x3()
    eye_delta = eye_user - view_locked.translation
    delta_cs = cur_rot.transposed() @ eye_delta

    axis0 = view_locked.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))
    axial = eye_delta.dot(axis0)
    dolly = (ref_depth - axial) / ref_depth if ref_depth > MIN_DEPTH else 1.0
    dolly = max(dolly, MIN_DEPTH)

    # 用户拖动累积的「相机空间缩放」（拖动时记录，见 apply_user_move）
    drag = float(obj.get(DRAG_SCALE_KEY, 1.0))

    mw_inv = obj.matrix_world.inverted()
    mesh = obj.data
    flat = []
    ap = flat.append
    for (x0, y0, d) in base:
        xd = x0 * drag
        yd = y0 * drag
        dd = d * drag
        k = (dd / ref_depth) if ref_depth > MIN_DEPTH else 1.0
        depth = max(dd * dolly * zoom, MIN_DEPTH)
        local = view_now @ mathutils.Vector(
            (xd - delta_cs.x * k * SCROLL_SCALE,
             yd - delta_cs.y * k * SCROLL_SCALE,
             -depth))
        co = mw_inv @ local
        ap(co.x); ap(co.y); ap(co.z)
    mesh.vertices.foreach_set("co", flat)
    mesh.update()
    # ⚠️ 顶点被改了 ⇒ 局部形心缓存失效（下次拖动要重算）
    try:
        del obj[CENTER_KEY]
    except Exception:
        pass
    return True


# ──────────────────────────── 锁定 / 解锁 / 重置 ────────────────────────────

def lock_group(scene, camera):
    targets = get_lock_targets(scene, camera)
    if not targets:
        return {"success": False, "message": "该相机下没有带投射 UV 的网格",
                "locked": [], "skipped": []}

    view = get_camera_view_matrix(camera)
    view_inv = view.inverted()
    mw_inv_cam = camera.matrix_world.inverted()

    locked, skipped = [], []
    per_obj_cam_space = {}
    ref_depth = 0.0
    for obj in targets:
        reason = has_modifier_or_shapekey(obj)
        if reason:
            skipped.append((obj, reason))
            continue
        mw = obj.matrix_world
        cs_list = []
        ok = True
        for v in obj.data.vertices:
            cs = view_inv @ (mw @ v.co)
            depth = -cs.z
            if depth <= MIN_DEPTH:
                ok = False
                break
            cs_list.append((cs.x, cs.y, depth))
            if depth > ref_depth:
                ref_depth = depth
        if not ok:
            skipped.append((obj, "顶点在相机后方"))
            continue
        per_obj_cam_space[obj.name] = cs_list
        locked.append(obj)

    if not locked:
        # 把真原因并进 message（原来写死成"修改器/形态键"，会把"顶点在相机后方"
        # 等其它原因也误报成修改器问题）—— 独立审查 S4
        reasons = []
        for _o, _r in skipped:
            if _r not in reasons:
                reasons.append(_r)
        detail = ("（原因：" + "、".join(reasons) + "）") if reasons else ""
        return {"success": False,
                "message": "没有可锁定的网格" + detail,
                "locked": [], "skipped": skipped}
    if ref_depth <= MIN_DEPTH:
        return {"success": False, "message": "基准深度异常（网格可能在相机后方）",
                "locked": [], "skipped": skipped}

    cam_data_name = camera.data.name

    # 多相机互斥
    groups = load_groups(scene)
    for obj in locked:
        prev = obj.get(OBJ_CAM_KEY)
        if prev and prev != cam_data_name:
            old = groups.get(prev)
            if old:
                old["objects"] = [n for n in old.get("objects", []) if n != obj.name]
                groups[prev] = old
                if not old["objects"]:
                    # 该相机已无任何网格 → 才撤补丁 + 关锁定。
                    # ⚠️ 必须判空：若它还留着别的网格，撤补丁会让那些网格的图案冻结
                    #    一起失效（组是共享的）。—— 独立审查 S2
                    old["enabled"] = False
                    unpatch_camera_project_group(prev)

    # ① 变形基准
    for obj in locked:
        _write_base_attribute(obj, per_obj_cam_space[obj.name])
        _write_matrix_key(obj, obj.matrix_world.copy())   # 拖动检测的「上次正确位姿」
        obj[DRAG_SCALE_KEY] = 1.0                          # 拖动缩放归 1
        obj[CENTER_KEY] = [c for c in _mesh_center_local(obj)]  # 顺便把形心缓存填上
        obj[OBJ_CAM_KEY] = cam_data_name

    # ② 图案冻结：给所有用该投影材质的网格写"冻结坐标" + 打组补丁
    #    （并上 locked —— 二者判定口径不同，取并集才不漏）
    _frozen_targets = list(objects_using_projection(cam_data_name))
    _seen = {o.as_pointer() for o in _frozen_targets}
    for o in locked:
        if o.as_pointer() not in _seen:
            _frozen_targets.append(o)
    # ⚠️ 若该相机原本就处于「已冻结」状态（补丁在），则【保留】已有冻结坐标，别重算 ——
    #    锁定期间图案一直粘在网格上（用的是旧冻结坐标），重算成当前世界位置会让图案
    #    突然滑动 = 用户报的「重新锁定后投影 UV 跳变」。
    #    只在「全新锁定」或「网格数变了」时才重写。
    _already_frozen = is_patched(cam_data_name)
    for obj in _frozen_targets:
        if _already_frozen and _campos_is_valid(obj, cam_data_name):
            continue
        _write_campos_attribute(obj, camera, cam_data_name, mw_inv_cam)
    patch_camera_project_group(cam_data_name)

    groups[cam_data_name] = {
        "enabled": True,
        "ref_depth": ref_depth,
        "locked_matrix": [[float(x) for x in row] for row in view],
        "locked_focal": float(camera.data.lens),
        "locked_sensor_w": float(camera.data.sensor_width),
        "locked_sensor_h": float(camera.data.sensor_height),
        "applied_zoom": 1.0,          # 已经施加到相机上的变焦 dolly 对应的 zoom
        "objects": [o.name for o in locked],
    }
    save_groups(scene, groups)
    _last_view[(scene.name, cam_data_name)] = (view.copy(), float(camera.data.lens))

    return {"success": True,
            "message": "已锁定 %d 个网格（基准深度 %.3f，跳过 %d）"
                       % (len(locked), ref_depth, len(skipped)),
            "locked": locked, "skipped": skipped}


def unlock_group(scene, camera):
    """解锁：停止跟随（网格停在当前位置、图案保持冻结 —— 关掉不回退）。"""
    groups = load_groups(scene)
    st = groups.get(camera.data.name)
    if not st:
        return {"success": False, "message": "该相机未锁定"}
    st["enabled"] = False
    groups[camera.data.name] = st
    save_groups(scene, groups)
    _last_view.pop((scene.name, camera.data.name), None)
    # 解锁 = 停止跟随，但【不回退】：网格与图案都保持当前状态（设计如此）。
    # 副作用要讲清：投影组的 lens/sensor/shift 仍处于冻结态，所以解锁后改焦距
    # 不会反映到投影上（要完全回到实时，需点「重置」）。—— 独立审查 N3
    return {"success": True,
            "message": "已解锁（网格/图案保持当前状态；改焦距暂不影响投影，"
                       "点「重置」可完全还原并恢复实时投影）"}


def reset_group(scene, camera):
    """重置：撤销所有锁定造成的改动 + 解除锁定（一步到位）。"""
    cam_data_name = camera.data.name
    st = load_groups(scene).get(cam_data_name)
    if not st:
        return {"success": False, "message": "该相机没有锁定记录"}
    view_locked = mathutils.Matrix([mathutils.Vector(r) for r in st["locked_matrix"]])

    n = 0
    for name in st.get("objects", []):
        obj = scene.objects.get(name)
        if obj is None or obj.type != "MESH":
            continue
        base = _read_base_attribute(obj)
        if base is None:
            continue
        mw_inv = obj.matrix_world.inverted()
        mesh = obj.data
        flat = []
        ap = flat.append
        for (x0, y0, d) in base:
            world = view_locked @ mathutils.Vector((x0, y0, -d))
            co = mw_inv @ world
            ap(co.x); ap(co.y); ap(co.z)
        mesh.vertices.foreach_set("co", flat)
        mesh.update()
        n += 1

    # 撤销变焦时施加到相机上的 dolly（把相机位置还回去）
    if CAMERA_DOLLY_ZOOM:
        az = float(st.get("applied_zoom", 1.0))
        if abs(az - 1.0) > 1e-6:
            ref = float(st.get("ref_depth", 0.0))
            camera.location = camera.location + world_to_parent_local(
                camera, _locked_axis(st) * (ref * (az - 1.0)))

    # 撤补丁 + 清属性（扫全局，与写入侧口径一致 —— 补丁是全局生效的）
    unpatch_camera_project_group(cam_data_name)
    for obj in bpy.data.objects:
        if obj.type != "MESH" or obj.data is None:
            continue
        # 冻结坐标属性名【按相机区分】→ 只清本相机那一份，天然不会动别的相机。
        # （独立审查 S1 / N1）
        _remove_attr(obj, _campos_attr_name(cam_data_name))
        if obj.get(CAMPOS_OWNER_KEY) == cam_data_name:
            try:
                del obj[CAMPOS_OWNER_KEY]
            except Exception:
                pass
        if obj.get(OBJ_CAM_KEY) == cam_data_name:
            _remove_attr(obj, BASE_ATTR)
            try:
                del obj[OBJ_CAM_KEY]
            except Exception:
                pass
            for _k in (MATRIX_KEY, DRAG_SCALE_KEY, CENTER_KEY):   # 拖动相关状态一并清
                try:
                    del obj[_k]
                except Exception:
                    pass

    groups = load_groups(scene)
    groups.pop(cam_data_name, None)
    save_groups(scene, groups)
    _base_cache.clear()
    _last_view.pop((scene.name, cam_data_name), None)
    return {"success": True, "message": "已重置 %d 个网格 + 解除锁定" % n}


# ──────────────────────────── handler ────────────────────────────

# 防重入：我们自己在 handler 里移动相机，会再次触发 depsgraph
_dolly_guard = False


def _apply_zoom_dolly(scene, camera, st, zoom, cam_data_name, groups):
    """变焦增量 → 移动相机（增量式，保留用户自己的相机位移）。"""
    global _dolly_guard
    prev = float(st.get("applied_zoom", 1.0))
    delta = float(zoom) - prev
    if abs(delta) <= 1e-6:
        return False
    ref = float(st.get("ref_depth", 0.0))
    v = _locked_axis(st)
    _dolly_guard = True
    try:
        camera.location = camera.location + world_to_parent_local(camera, v * (-ref * delta))
        st["applied_zoom"] = float(zoom)
        groups[cam_data_name] = st
        save_groups(scene, groups)
        bpy.context.view_layer.update()
    finally:
        _dolly_guard = False
    return True


# 防重入总闸：handler 自己会改网格顶点 / 物体位姿 / 相机位置 / 场景属性
# → 每次都触发 depsgraph → 又调回本 handler。
# ⚠️ 没有这道闸，拖动时「拖动缩放」会在**同一次拖动里被反复累乘**
#    （k → k² → k³ …，因为位姿已改、而记录基准还没写回）——
#    网格被推到极远处 = 用户看到的「对象消失」。
_handler_guard = False


@persistent
def parallax_lock_update_handler(scene):
    global _handler_guard
    if _dolly_guard or _handler_guard:
        return
    _handler_guard = True
    try:
        groups = load_groups(scene)
        if not groups:
            return

        # 第一步：变焦检测 → 移动相机（相机真的动起来）
        # ⚠️ 不 return：必须紧接着在同一轮里做网格适配，否则本轮只有相机动、网格不动
        for cam_data_name, st in groups.items():
            if not st.get("enabled"):
                continue
            camera = find_camera(scene, cam_data_name)
            if camera is None:
                continue
            lf = float(st.get("locked_focal", 0.0)) or MIN_DEPTH
            zoom = float(camera.data.lens) / lf
            _apply_zoom_dolly(scene, camera, st, zoom, cam_data_name, groups)

        # 第二步：用户拖动锁定网格 → 重新锚定（对齐 PSD「拖图层」语义）
        #   ⚠️ 必须排在网格适配【之前】：重锚会改 base 与位姿，适配要用新值。
        _moved_any = False
        for cam_data_name, st in groups.items():
            if not st.get("enabled"):
                continue
            camera = find_camera(scene, cam_data_name)
            if camera is None:
                continue
            # ⚠️ 用【当前】相机矩阵，不是锁定那一刻的 —— 用户是看着当前的相机画面拖的，
            #    深度/视线必须按当前相机算；用锁定帧会让「拖不动的方向」「深度比」全错
            #    （相机移动/旋转后尤其明显）。—— 用户报的第 2 个问题
            view_now = get_camera_view_matrix(camera)
            n_moved = 0
            for name in st.get("objects", []):
                obj = scene.objects.get(name)
                if obj is None or obj.type != "MESH" or obj.data is None:
                    continue
                if apply_user_move(obj, camera, view_now):
                    n_moved += 1
            if n_moved:
                recompute_ref_depth(scene, st)
                groups[cam_data_name] = st
                _moved_any = True
        if _moved_any:
            save_groups(scene, groups)

        # 第三步：网格逐顶点适配
        for cam_data_name, st in groups.items():
            if not st.get("enabled"):
                continue
            camera = find_camera(scene, cam_data_name)
            if camera is None:
                continue
            view = get_camera_view_matrix(camera)
            lens_now = float(camera.data.lens)
            key = (scene.name, cam_data_name)
            last = _last_view.get(key)
            if last is not None and _matrices_close(last[0], view, CAMERA_CHANGE_THRESHOLD) \
                    and abs(lens_now - last[1]) <= 1e-6:
                continue
            _last_view[key] = (view.copy(), lens_now)
            for name in st.get("objects", []):
                obj = scene.objects.get(name)
                if obj is None or obj.type != "MESH":
                    continue
                adapt_object(obj, camera, st, view_now=view)
    except Exception:
        import traceback
        traceback.print_exc()
    finally:
        _handler_guard = False


def _matrices_close(a, b, tol):
    for i in range(4):
        for j in range(4):
            if abs(a[i][j] - b[i][j]) > tol:
                return False
    return True


# ──────────────────────────── 注册 ────────────────────────────

def register_handlers():
    h = bpy.app.handlers.depsgraph_update_post
    if parallax_lock_update_handler not in h:
        h.append(parallax_lock_update_handler)


def unregister_handlers():
    h = bpy.app.handlers.depsgraph_update_post
    if parallax_lock_update_handler in h:
        h.remove(parallax_lock_update_handler)
    _last_view.clear()
    _base_cache.clear()
