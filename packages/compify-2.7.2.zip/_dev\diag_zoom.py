"""变焦测试（真实渲染）：锁定后变焦，图案是否变。

序列：
  1_lock_t50   锁定后·lens=50
  2_lock_t85   锁定后·lens=85（当前实现：只冻 TexCoord）
  3_lockfrz_t85 锁定后·lens=85（额外冻结 lens 值）
  4_nolock_t85  未锁定·lens=85（对照）
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("Cam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

specs = [(-5.0, 16.0, 0.0, 1.15), (-2.5, 16.0, 0.0, 1.15), (0.0, 16.0, 0.0, 1.15),
         (2.5, 16.0, 0.0, 1.15), (5.0, 16.0, 0.0, 1.15)]
for i, (x, y, z, r) in enumerate(specs):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
    bpy.ops.object.shade_smooth()
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()
ORIG = {o.name: [tuple(v.co) for v in o.data.vertices] for o in meshes}

# 图案
W = H = 512
img = bpy.data.images.new("Footage", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        v = 0.93 if ((x // 32) + (y // 32)) % 2 else 0.05
        R = G = B = v
        d = math.hypot(x - W / 2, y - H / 2)
        if d < 72:
            R, G, B = 0.95, 0.12, 0.10
        elif d < 80:
            R, G, B = 0.98, 0.98, 0.98
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear(); o.data.materials.append(mat)
    nm = "UV Adjust | %s | %s" % (o.data.name, cam_data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

lens_node = next((n for n in grp.nodes if n.type == "VALUE" and n.label == "Lens"), None)
print("LENS_NODE:", lens_node.label if lens_node else None)

scene.render.resolution_x = 760
scene.render.resolution_y = 320
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 16
scene.cycles.device = "CPU"
OUT = os.path.join(IDES_HOME, "workspace", "_plock_zoom")
os.makedirs(OUT, exist_ok=True)


def shot(n):
    scene.render.filepath = os.path.join(OUT, n + ".png")
    bpy.ops.render.render(write_still=True)
    print("SHOT", n)


def restore():
    for o in meshes:
        f = []
        for c in ORIG[o.name]:
            f.extend(c)
        o.data.vertices.foreach_set("co", f)
        o.data.update()
    bpy.context.view_layer.update()


# ── 1 锁定 + lens 50 ──
cam_data.lens = 50.0; bpy.context.view_layer.update(); restore()
r = plock.lock_group(scene, cam)
print("LOCK:", r["success"], r["message"])
shot("1_lock_t50")

# ── 2 变焦 85（当前实现）──
cam_data.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
shot("2_lock_t85")

# ── 3 额外冻结 lens ──
sock = lens_node.outputs["Value"]
try:
    sock.driver_remove("default_value")
    print("DRIVER_REMOVED")
except Exception as e:
    print("DRIVER_REMOVE_FAIL", e)
sock.default_value = 50.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
shot("3_lockfrozen_t85")

# 还原 driver
drv = sock.driver_add("default_value").driver
var = drv.variables.new(); var.name = "lens"; var.type = "SINGLE_PROP"
var.targets[0].id = cam_data; var.targets[0].data_path = "lens"
print("DRIVER_RESTORED")

# ── 4 未锁定对照 ──
plock.reset_group(scene, cam)
restore()
cam_data.lens = 85.0
bpy.context.view_layer.update()
shot("4_nolock_t85")
print("ZOOM_DONE", OUT)
