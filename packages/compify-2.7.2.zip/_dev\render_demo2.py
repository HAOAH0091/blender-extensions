"""渲染方案对比序列 v2：干净可控场景（球体组）+ 高对比大色块图案。

4 方案 × 9 相机位置。判据：图案相对网格是否滑动。
"""
import bpy
import sys
import os
import math
import json
import mathutils

sys.stdout.reconfigure(encoding="utf-8")

_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
_SYNC = os.path.dirname(os.path.dirname(PKG_DIR))
IDES_HOME = os.path.join(_SYNC, "IDES")

scene = bpy.context.scene

# ── 清场，建干净演示场景 ──
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

# 相机：朝 +Y 看（rot 90,0,0）
cam_data = bpy.data.cameras.new("DemoCam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("DemoCamera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0.0, 0.0)
bpy.context.view_layer.update()
scene.camera = cam


def add_sphere(name, x, y, z, r):
    m = bpy.data.meshes.new(name)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    o = bpy.context.active_object
    o.name = name
    return o


# 不同深度摆放（越远越小、投影图案越细）
specs = [(-3.0, 16.0, 0.0, 1.6), (0.0, 16.0, 0.0, 1.6), (3.0, 16.0, 0.0, 1.6),
         (-1.5, 24.0, 0.0, 2.0), (1.5, 24.0, 0.0, 2.0)]
for i, (x, y, z, r) in enumerate(specs):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    o = bpy.context.active_object
    o.name = "Ball%d" % i
    bpy.ops.object.shade_smooth()
spheres = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()

meshes = spheres

# 记录原始顶点坐标（每方案前复位）
_ORIG = {o.name: [tuple(v.co) for v in o.data.vertices] for o in meshes}


def restore_all():
    for o in meshes:
        flat = []
        for c in _ORIG[o.name]:
            flat.extend(c)
        o.data.vertices.foreach_set("co", flat)
        o.data.update()
    bpy.context.view_layer.update()

# ── 图案：细密棋盘（滑动时明显流动）+ 中央红靶心 ──
W = H = 512
CELL = 32          # 16×16 格
img = bpy.data.images.new("Pat", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        c = ((x // CELL) + (y // CELL)) % 2
        v = 0.93 if c else 0.05
        R = G = B = v
        r = math.hypot(x - W / 2, y - H / 2)
        if r < 66:
            R, G, B = 0.95, 0.12, 0.10      # 中央红靶心
        elif r < 74:
            R, G, B = 0.98, 0.98, 0.98      # 白圈
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

# ── 投影材质（等价 compify x/z 透视投影）──
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
tc = nt.nodes.new("ShaderNodeTexCoord"); tc.object = cam
sep = nt.nodes.new("ShaderNodeSeparateXYZ")
m1 = nt.nodes.new("ShaderNodeMath"); m1.operation = "DIVIDE"
m2 = nt.nodes.new("ShaderNodeMath"); m2.operation = "DIVIDE"
n1 = nt.nodes.new("ShaderNodeMath"); n1.operation = "MULTIPLY"; n1.inputs[1].default_value = -1
n2 = nt.nodes.new("ShaderNodeMath"); n2.operation = "MULTIPLY"; n2.inputs[1].default_value = -1
comb = nt.nodes.new("ShaderNodeCombineXYZ")
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(tc.outputs["Object"], sep.inputs["Vector"])
nt.links.new(sep.outputs["X"], m1.inputs[0]); nt.links.new(sep.outputs["Z"], m1.inputs[1])
nt.links.new(sep.outputs["Y"], m2.inputs[0]); nt.links.new(sep.outputs["Z"], m2.inputs[1])
nt.links.new(m1.outputs[0], n1.inputs[0]); nt.links.new(m2.outputs[0], n2.inputs[0])
nt.links.new(n1.outputs[0], comb.inputs["X"]); nt.links.new(n2.outputs[0], comb.inputs["Y"])
nt.links.new(comb.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

scene.render.resolution_x = 760
scene.render.resolution_y = 320
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 24
scene.cycles.device = "CPU"

OUT = os.path.join(IDES_HOME, "workspace", "_plock_demo2")
os.makedirs(OUT, exist_ok=True)

# ── 视差锁定逻辑（内联，避免依赖插件包）──
MIN_DEPTH = 1e-4
BASE_ATTR = "demo_base"


def view_matrix(c):
    loc, rot, _ = c.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def lock(cam, scroll):
    view = view_matrix(cam)
    vi = view.inverted()
    base = {}
    ref = 0.0
    for o in meshes:
        lst = []
        for v in o.data.vertices:
            cs = vi @ (o.matrix_world @ v.co)
            d = -cs.z
            lst.append((cs.x, cs.y, d))
            ref = max(ref, d)
        base[o.name] = lst
    return view, base, ref, scroll


def adapt(cam, view_locked, base, ref, scroll):
    view = view_matrix(cam)
    cur_rot = view.to_3x3()
    eye_delta = view.translation - view_locked.translation
    dcs = cur_rot.transposed() @ eye_delta
    for o in meshes:
        mwi = o.matrix_world.inverted()
        flat = []
        for (x0, y0, d) in base[o.name]:
            k = (d / ref) * scroll
            local = view @ mathutils.Vector((x0 - dcs.x * k, y0 - dcs.y * k, -d))
            co = mwi @ local
            flat.extend((co.x, co.y, co.z))
        o.data.vertices.foreach_set("co", flat)
        o.data.update()


CAM0 = tuple(cam.location)
N = 9
SPAN = 2.0
xs = [round(-SPAN + 2 * SPAN * k / (N - 1), 4) for k in range(N)]


def set_cam(x):
    cam.location = (CAM0[0] + x, CAM0[1], CAM0[2])
    bpy.context.view_layer.update()


def render(path):
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)


manifest = {}

# ── 1 现状 ──
set_cam(0.0); restore_all()
fr = []
for k, x in enumerate(xs):
    set_cam(x)
    p = os.path.join(OUT, "1_nolock_%d.png" % k); render(p); fr.append(os.path.basename(p))
manifest["1_nolock"] = fr; print("DONE 1")

# ── 2 网格跟相机 SCROLL=0 ──
set_cam(0.0); restore_all()
vl, base, ref, _ = lock(cam, 0.0)
fr = []
for k, x in enumerate(xs):
    set_cam(x); adapt(cam, vl, base, ref, 0.0)
    p = os.path.join(OUT, "2_camfreeze_%d.png" % k); render(p); fr.append(os.path.basename(p))
manifest["2_camfreeze"] = fr; print("DONE 2")

# ── 3 网格滚动 SCROLL=1 ──
set_cam(0.0); restore_all()
vl, base, ref, _ = lock(cam, 1.0)
fr = []
for k, x in enumerate(xs):
    set_cam(x); adapt(cam, vl, base, ref, 1.0)
    p = os.path.join(OUT, "3_scroll_%d.png" % k); render(p); fr.append(os.path.basename(p))
manifest["3_scroll"] = fr; print("DONE 3")

# ── 4 投影冻结 ──
set_cam(0.0); restore_all()
frozen = bpy.data.objects.new("ProjFrozen", None)
scene.collection.objects.link(frozen)
frozen.matrix_world = view_matrix(cam)
tc.object = frozen
fr = []
for k, x in enumerate(xs):
    set_cam(x)
    p = os.path.join(OUT, "4_projfreeze_%d.png" % k); render(p); fr.append(os.path.basename(p))
manifest["4_projfreeze"] = fr; print("DONE 4")

with open(os.path.join(OUT, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump({"xs": xs, "frames": manifest}, f)
print("ALL_DONE")
