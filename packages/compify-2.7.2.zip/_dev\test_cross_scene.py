"""跨场景回归：投影节点组是【全局 datablock】，补丁会影响到所有场景。

如果只给"当前场景"的物体写冻结坐标，别的场景里用同一投影材质的物体会读到
空属性 → Attribute 节点输出常量 → 投影糊掉。

本测试：
  1. 场景 A：相机 + 网格 + 投影材质 + UV Adjust 组
  2. 场景 B：另一个 mesh，用【同一个】投影材质
  3. 在场景 A 锁定 → 场景 B 的 mesh 也必须拿到冻结坐标属性
  4. 重置 → 两侧属性都清干净
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = r"D:\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(n, cond, d=""):
    (P if cond else F).append(n)
    print("  [%s] %-50s %s" % ("PASS" if cond else "FAIL", n, d))

bpy.ops.wm.read_factory_settings(use_empty=True)

# ── 场景 A ──
scA = bpy.context.scene
scA.name = "SceneA"
cd = bpy.data.cameras.new("C"); cd.lens = 50.0
cam = bpy.data.objects.new("C", cd)
scA.collection.objects.link(cam)
cam.location = (0, -6, 0); cam.rotation_euler = (math.radians(90), 0, 0)
scA.camera = cam
bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 16, 0))
boxA = bpy.context.active_object
boxA.name = "BoxA"

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("SharedProj")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], outn.inputs["Surface"])
boxA.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (boxA.data.name, cd.name), "ShaderNodeTree")

# ── 场景 B（同一材质！）──
scB = bpy.data.scenes.new("SceneB")
boxB = bpy.data.objects.new("BoxB", boxA.data.copy())
scB.collection.objects.link(boxB)
boxB.location = (0, 16, 0)
boxB.data.materials.append(mat)     # 用同一个投影材质
bpy.context.view_layer.update()

print("场景数:", len(bpy.data.scenes), "| 用该投影材质的物体:",
      sorted(o.name for o in plock.objects_using_projection(cd.name)))

# 在【场景 A】锁定
res = plock.lock_group(scA, cam)
chk("场景 A 锁定成功", res["success"], res["message"][:40])


def has_campos(o):
    return o.data.attributes.get(plock._campos_attr_name(cd.name)) is not None


chk("场景 A 物体拿到冻结坐标属性", has_campos(boxA))
chk("场景 B 物体也拿到冻结坐标属性（跨场景不漏）", has_campos(boxB),
    "← 补丁是全局的，漏了就投影糊掉")

# 场景 B 的 mesh 不应被当成本次锁定的变形目标（它没 UV Adjust 组）
chk("场景 B 物体不在 locked 列表", boxB.name not in
    [n for n in plock.get_state(scA, cam).get("objects", [])])
chk("场景 B 物体没有变形基准属性", boxB.data.attributes.get(plock.BASE_ATTR) is None)

# 重置 → 两侧属性都清
r2 = plock.reset_group(scA, cam)
chk("重置成功", r2["success"])
chk("重置后场景 A 属性清除", not has_campos(boxA))
chk("重置后场景 B 属性也清除（跨场景）", not has_campos(boxB))

print("\nPASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("CROSS_DONE")
