"""验证：用户拖动锁定网格 → 按视差语义重新锚定（对齐 PSD「拖图层」）。

验证项：
  1. 沿视线拖动 ⇒ 深度改变，但【屏幕坐标不变】（网格钉在画面原位）
  2. 纯横向拖动 ⇒ 被拉回原位（锁定语义：画面里拖不动）
  3. 顶点按【各自的视线】移动（各顶点位移不同 = 非刚性 = 按视锥体变形）
  4. 投影 UV 不变（图案不滑动）
  5. 位姿写回基准 ⇒ 之后一动相机【不会弹回】
  6. 深度变了 ⇒ 之后移相机时该网格的视差滚动确实不同（= 调了"间距"）
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
D = r"D:\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(PKG, os.path.join(D, "__init__.py"),
                                              submodule_search_locations=[D])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-50s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("C")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("C", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, -6.0, 0.0)
    cam.rotation_euler = (math.radians(90), 0, 0)
    sc.camera = cam
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup")
    g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    objs = []
    for i, (x, depth) in enumerate([(-4.0, 10.0), (0.0, 16.0), (4.0, 22.0)]):
        bpy.ops.mesh.primitive_monkey_add(size=2.0, location=(x, -6.0 + depth, 0.0))
        ob = bpy.context.active_object
        ob.name = "MK%d" % i
        ob.rotation_euler = (math.radians(90), 0, 0)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
        objs.append(ob)
    bpy.context.view_layer.update()
    return sc, cam, objs


def view_of(st):
    return mathutils_matrix(st)


def mathutils_matrix(st):
    import mathutils
    return mathutils.Matrix([mathutils.Vector(r) for r in st["locked_matrix"]])


def center_world(obj):
    import mathutils
    n = len(obj.data.vertices)
    buf = [0.0] * (n * 3)
    obj.data.vertices.foreach_get("co", buf)
    c = mathutils.Vector((sum(buf[0::3]) / n, sum(buf[1::3]) / n, sum(buf[2::3]) / n))
    return obj.matrix_world @ c


def screen_norm(obj, view_inv):
    """归一化屏幕坐标（x/d, y/d）——锁定语义的核心判据。"""
    cs = view_inv @ center_world(obj)
    d = -cs.z
    return (cs.x / d, cs.y / d), d


def proj_uvs(obj, cam_data_name, lens, sensor_w):
    """投影 UV（用冻结坐标属性手算）——图案是否滑动看它。"""
    attr = obj.data.attributes.get(plock._campos_attr_name(cam_data_name))
    if attr is None:
        return None
    n = len(attr.data)
    buf = [0.0] * (n * 3)
    attr.data.foreach_get("vector", buf)
    out = []
    for i in range(0, n * 3, 3):
        x, y, z = buf[i], buf[i + 1], buf[i + 2]
        d = -z
        if abs(d) < 1e-9:
            out.append((0.0, 0.0))
        else:
            out.append((x / d * (lens / sensor_w), y / d * (lens / sensor_w)))
    return out


# ══ 场景 A：沿视线拖动 ══
print("=" * 64)
print("A) 沿【视线】拖动 MK0（推远 4 单位）")
sc, cam, objs = build()
r = plock.lock_group(sc, cam)
chk("锁定成功", r["success"], r["message"][:38])
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
view_inv = view.inverted()
target = objs[0]

s0, d0 = screen_norm(target, view_inv)
uv0 = proj_uvs(target, cam.data.name, cam.data.lens, cam.data.sensor_width)
w0 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
_cb = target.data.attributes.get(plock._campos_attr_name(cam.data.name))
campos_before = [0.0] * (len(_cb.data) * 3)
_cb.data.foreach_get("vector", campos_before)

# 沿光轴推远
axis = view.to_3x3() @ __import__("mathutils").Vector((0.0, 0.0, -1.0))
target.location = target.location + axis * 4.0
bpy.context.view_layer.update()
w_user = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
print("   用户拖动：顶点0 世界 =", tuple(round(v, 3) for v in w_user[0]))

plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

s1, d1 = screen_norm(target, view_inv)
uv1 = proj_uvs(target, cam.data.name, cam.data.lens, cam.data.sensor_width)
w1 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]

print("   屏幕坐标 %.5f,%.5f → %.5f,%.5f" % (s0[0], s0[1], s1[0], s1[1]))
print("   形心深度 %.3f → %.3f   (k=%.4f)" % (d0, d1, d1 / d0))
chk("① 屏幕坐标不变（钉在画面原位）",
    abs(s1[0] - s0[0]) < 1e-6 and abs(s1[1] - s0[1]) < 1e-6,
    "Δ=%.2e" % max(abs(s1[0] - s0[0]), abs(s1[1] - s0[1])))
chk("① 深度确实变了（推远了）", d1 > d0 + 1.0, "%.3f → %.3f" % (d0, d1))

# 非刚性：各顶点位移不同
import mathutils
disp = [mathutils.Vector(w1[i]) - mathutils.Vector(w0[i]) for i in range(len(w0))]
mags = [d.length for d in disp]
chk("③ 各顶点位移【不同】（非刚性 = 按视锥体变形）",
    max(mags) - min(mags) > 1e-3,
    "位移范围 %.4f ~ %.4f" % (min(mags), max(mags)))

# 投影 UV 不变（★ 修复后：冻结坐标属性**完全不被动过**）
campos_after = None
_a = target.data.attributes.get(plock._campos_attr_name(cam.data.name))
if _a:
    _n = len(_a.data); campos_after = [0.0] * (_n * 3)
    _a.data.foreach_get("vector", campos_after)
if uv0 and uv1:
    e = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(uv0, uv1))
    chk("④ 投影 UV 不变（图案不滑动）", e < 1e-5, "max=%.2e" % e)
else:
    chk("④ 投影 UV 不变（图案不滑动）", False, "属性缺失")
chk("④b 冻结坐标属性值与锁定时刻完全一致",
    campos_after is not None and campos_before is not None and
    campos_after == campos_before,
    "（网格变形不应改动 UV）")
chk("④c 记录了拖动缩放标量（O(1) 方案）",
    abs(float(target.get(plock.DRAG_SCALE_KEY, 1.0)) - d1 / d0) < 1e-6,
    "drag=%.5f  k=%.5f" % (float(target.get(plock.DRAG_SCALE_KEY, 1.0)), d1 / d0))

# 写回基准：再动相机不应弹回
cam.location.x += 1.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s2, d2 = screen_norm(target, view_inv)
chk("⑤ 之后动相机：网格不再弹回原深度", abs(d2 - d1) < 1e-3,
    "深度 %.3f → %.3f" % (d1, d2))

# ══ 场景 B：横向拖动应被拉回 ══
print()
print("=" * 64)
print("B) 纯【横向】拖动 MK0（+3 单位）→ 应被拉回原位")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
view_inv = view.inverted()
target = objs[0]
w0 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
target.location.x += 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
w1 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
import mathutils as mu
err = max((mu.Vector(w1[i]) - mu.Vector(w0[i])).length for i in range(len(w0)))
chk("② 横向拖动被拉回（网格回原位）", err < 1e-4, "max_err=%.2e" % err)

# ══ 场景 C：深度变了 ⇒ 之后移相机的视差不同 ══
print()
print("=" * 64)
print("C) 深度改变后，该网格的视差滚动应与「没拖动」时不同")


def scroll_after_unlock(do_drag):
    """解锁后的视差：世界坐标固定，相机横移 → 屏幕位移 ∝ 1/深度。

    ⚠️ 为什么不能在「锁定态」量这个：锁定态各网格**严格同步滚动**（那正是
    "构图冻结"的定义），深度不参与滚动量 ⇒ 量不出差异。深度改变的效果
    要在【解锁后】的自由视差里才看得到。
    """
    sc, cam, objs = build()
    plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    view = mathutils_matrix(st)
    tgt = objs[0]
    if do_drag:
        axis = view.to_3x3() @ mu.Vector((0.0, 0.0, -1.0))
        tgt.location = tgt.location + axis * 4.0
        bpy.context.view_layer.update()
        plock.parallax_lock_update_handler(sc)
        bpy.context.view_layer.update()
    plock.unlock_group(sc, cam)          # 解锁 → 网格世界坐标固定，恢复自然视差
    bpy.context.view_layer.update()
    v0 = plock.get_camera_view_matrix(cam)
    cs0 = v0.inverted() @ center_world(tgt)
    s0 = cs0.x / -cs0.z
    cam.location.x += 1.0
    bpy.context.view_layer.update()
    v1 = plock.get_camera_view_matrix(cam)
    cs1 = v1.inverted() @ center_world(tgt)
    s1 = cs1.x / -cs1.z
    d = -cs0.z
    return s0, s1, d


s0a, s1a, da = scroll_after_unlock(False)
s0b, s1b, db = scroll_after_unlock(True)
print("   未拖动：深度 %.3f  屏 %.5f → %.5f  (视差位移 %.5f)"
      % (da, s0a, s1a, s1a - s0a))
print("   已拖动：深度 %.3f  屏 %.5f → %.5f  (视差位移 %.5f)"
      % (db, s0b, s1b, s1b - s0b))
chk("⑥ 拖动后深度变了 ⇒ 解锁后的视差位移不同（= 调了'间距'）",
    abs((s1a - s0a) - (s1b - s0b)) > 1e-3,
    "差 %.5f" % abs((s1a - s0a) - (s1b - s0b)))

# ══ D) 性能：拖动过程不应遍历顶点 ══
print()
print("=" * 64)
print("D) 性能：拖动时不遍历顶点（O(1)）")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
MU = importlib.import_module("mathutils")
axis = view.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
tgt = objs[0]
_cnt = {"call": 0, "miss": 0}
_oc = plock._mesh_center_local


def _cc(o):
    _cnt["call"] += 1
    if o.get(plock.CENTER_KEY) is None:
        _cnt["miss"] += 1
    return _oc(o)


plock._mesh_center_local = _cc
tgt.location = tgt.location + axis * 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
plock._mesh_center_local = _oc
print("   形心计算调用 %d 次，其中未命中缓存 %d 次" % (_cnt["call"], _cnt["miss"]))
chk("拖动时形心走缓存、不遍历顶点",
    _cnt["call"] > 0 and _cnt["miss"] == 0,
    "%d/%d 命中缓存" % (_cnt["call"] - _cnt["miss"], _cnt["call"]))

# ══ E) 模拟 depsgraph 重入：拖动缩放不得被反复累乘 ══
print()
print("=" * 64)
print("E) 模拟 depsgraph 连锁重入")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
axis = view.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
tgt = objs[0]
_re = []
_ow = plock._write_matrix_key


def _rw(obj, M):
    r = _ow(obj, M)
    if len(_re) < 3:
        _re.append(obj.name)
        plock.parallax_lock_update_handler(sc)     # 模拟 depsgraph 连锁重入
    return r


plock._write_matrix_key = _rw
tgt.location = tgt.location + axis * 4.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
plock._write_matrix_key = _ow
ds = float(tgt.get(plock.DRAG_SCALE_KEY, 1.0))
print("   重入 %d 次后 drag = %.5f（单次应为 ~1.40）" % (len(_re), ds))
chk("重入不累积（drag 只乘一次，未被 k²、k³ 放大）",
    1.2 < ds < 1.6, "drag=%.5f" % ds)

# ══ F) 拖动后动相机：所有对象仍在画面合理位置（不消失）══
print()
print("=" * 64)
print("F) 拖动 + 动相机后，所有对象位置合理（不消失）")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
axis = view.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
objs[0].location = objs[0].location + axis * 5.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
for _ in range(3):                     # 多次连锁（模拟 GUI）
    cam.location.x += 0.5
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
ok = True
detail = []
for ob in objs:
    cs = plock.get_camera_view_matrix(cam).inverted() @ center_world(ob)
    depth = -cs.z
    inside = depth > 0.1 and abs(cs.x / depth) < 20 and abs(cs.y / depth) < 20
    ok = ok and inside
    detail.append("%s d=%.1f" % (ob.name, depth))
chk("拖动 + 动相机后所有对象仍在相机前方、画面附近", ok, " | ".join(detail))

# ══ G) 重新锁定不得让投影 UV 跳变 ══


def frozen_lens(camname):
    """投影组里【冻结】的 lens 值（决定图案外观；与 state.locked_focal 不同）。"""
    g = bpy.data.node_groups.get("Camera Project | " + camname)
    for n in g.nodes:
        if n.type == "VALUE" and n.label == "Lens":
            return n.outputs["Value"].default_value
    return None


print()
print("=" * 64)
print("G) 锁定 → 移相机 → 解锁 → 再锁定：投影 UV 不跳变")
sc, cam, objs = build()
plock.lock_group(sc, cam)
tgt = objs[0]
uv_lock = proj_uvs(tgt, cam.data.name, frozen_lens(cam.data.name), cam.data.sensor_width)
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
plock.unlock_group(sc, cam)
uv_unlock = proj_uvs(tgt, cam.data.name, frozen_lens(cam.data.name), cam.data.sensor_width)
plock.lock_group(sc, cam)
uv_relock = proj_uvs(tgt, cam.data.name, frozen_lens(cam.data.name), cam.data.sensor_width)
e1 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(uv_unlock, uv_relock))
e0 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(uv_lock, uv_relock))
print("   锁定→再锁定 UV 差 %.2e ; 解锁→再锁定 UV 差 %.2e" % (e0, e1))
chk("G1 再锁定不改变投影 UV（不跳变）", e1 < 1e-6, "Δ=%.2e" % e1)
chk("G2 再锁定后 UV 仍等于最初锁定值", e0 < 1e-6, "Δ=%.2e" % e0)

# G3：锁定 → 变焦（相机推拉）→ 解锁 → 再锁定，同样不得跳变
sc, cam, objs = build()
plock.lock_group(sc, cam)
tgt = objs[0]
cam.data.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
uv_z = proj_uvs(tgt, cam.data.name, frozen_lens(cam.data.name), cam.data.sensor_width)
plock.unlock_group(sc, cam)
plock.lock_group(sc, cam)
uv_z2 = proj_uvs(tgt, cam.data.name, frozen_lens(cam.data.name), cam.data.sensor_width)
e2 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(uv_z, uv_z2))
print("   变焦后 冻结lens=%.1f 相机lens=%.1f" % (frozen_lens(cam.data.name), cam.data.lens))
chk("G3 变焦后重新锁定也不跳变", e2 < 1e-6, "Δ=%.2e" % e2)

# ══ H) 相机移动/旋转后，拖动约束要按【当前】相机 ══
print()
print("=" * 64)
print("H) 移动+旋转相机后再拖动：约束按当前相机算")
sc, cam, objs = build()
plock.lock_group(sc, cam)
cam.location.x += 3.0
cam.rotation_euler = (math.radians(90), 0.0, math.radians(25))
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
tgt = objs[0]
view_cur = plock.get_camera_view_matrix(cam)
vinv = view_cur.inverted()
s0, d0 = screen_norm(tgt, vinv)

axis = view_cur.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
tgt.location = tgt.location + axis * 4.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s1, d1 = screen_norm(tgt, vinv)
ds = float(tgt.get(plock.DRAG_SCALE_KEY, 1.0))
print("   屏幕 (%.5f, %.5f) → (%.5f, %.5f)  深度 %.3f → %.3f  drag=%.5f"
      % (s0[0], s0[1], s1[0], s1[1], d0, d1, ds))
chk("H1 沿当前相机光轴拖动：屏幕坐标不变",
    abs(s1[0] - s0[0]) < 1e-5 and abs(s1[1] - s0[1]) < 1e-5,
    "Δ=(%.2e, %.2e)" % (s1[0] - s0[0], s1[1] - s0[1]))
chk("H2 深度比 = 记录的拖动缩放（按当前相机算）",
    abs(d1 / d0 - ds) < 1e-4, "d1/d0=%.5f drag=%.5f" % (d1 / d0, ds))

# 横向拖动（相对当前相机）→ 应被拉回
sc, cam, objs = build()
plock.lock_group(sc, cam)
cam.location.x += 3.0
cam.rotation_euler = (math.radians(90), 0.0, math.radians(25))
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
tgt = objs[0]
view_cur = plock.get_camera_view_matrix(cam)
w0 = [tuple(tgt.matrix_world @ v.co) for v in tgt.data.vertices]
right = view_cur.to_3x3() @ MU.Vector((1.0, 0.0, 0.0))
tgt.location = tgt.location + right * 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
w1 = [tuple(tgt.matrix_world @ v.co) for v in tgt.data.vertices]
err = max((MU.Vector(w1[i]) - MU.Vector(w0[i])).length for i in range(len(w0)))
chk("H3 横向拖动（相对当前相机）被拉回原位", err < 1e-4, "max_err=%.2e" % err)

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("USERMOVE_DONE")
