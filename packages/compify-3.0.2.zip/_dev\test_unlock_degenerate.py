"""验证退化检查：只挡真正的退化，不碰正常场景"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-50s %s" % ("PASS" if c else "FAIL", n, d))


def build(tilt=0.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 3; h = 2.0
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -h+2*h*ix/ns
            y = -h+2*h*iy/ns
            verts.append((x, y, tilt*x))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def sc_vals(cd):
    nodes = plock._find_delta_nodes(cd.name)
    return (nodes[0].inputs["Scale"].default_value,
            tuple(nodes[1].inputs[1].default_value)[:2])


def run(tag, tilt, move, expect_ok):
    sc, cam, cd, ob = build(tilt)
    plock.lock_group(sc, cam)
    move(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    r = plock.unlock_group(sc, cam)
    S, C = sc_vals(cd)
    msg = r["message"]
    committed = "构图已落实" in msg
    print("   消息: %s" % msg[:78])
    print("   S=%.8f C=(%+.6f,%+.6f)" % (S, C[0], C[1]))
    if expect_ok:
        chk("%s 正常落实" % tag, committed)
        chk("%s S 在合理范围" % tag, 1e-3 <= abs(S) <= 1e3, "S=%.6f" % S)
    else:
        chk("%s 如实报告未落实" % tag, not committed)
        chk("%s S 保持恒等(1.0)" % tag, abs(S - 1.0) < 1e-9, "S=%.8f" % S)
    return S


print("=" * 82)
print("退化检查：正常场景必须照常通过")
print("=" * 82)
run("平移x+2", 0.0, lambda cam, cd: setattr(cam.location, "x", 2.0), True)
run("变焦85", 0.0, lambda cam, cd: setattr(cd, "lens", 85.0), True)
run("缩焦32", 0.0, lambda cam, cd: setattr(cd, "lens", 32.0), True)
run("旋转15°", 0.0, lambda cam, cd: setattr(cam.rotation_euler, "z", math.radians(15)), True)
run("倾斜+平移", 0.3, lambda cam, cd: setattr(cam.location, "x", 2.0), True)


def combo(cam, cd):
    cam.location.x = 1.5
    cam.rotation_euler.z = math.radians(10)
    cd.lens = 68.0


run("组合", 0.3, combo, True)

print()
print("=" * 82)
print("退化检查：真正退化的场景必须被挡住")
print("=" * 82)
run("相机在网格平面上", 0.0, lambda cam, cd: setattr(cam.location, "z", 0.0), False)
run("相机穿到网格后方", 0.0, lambda cam, cd: setattr(cam.location, "z", -1.0), False)

print()
print("=" * 82)
print("边界不误伤：半穿过（S=1/3，画面本来就正确）应放行")
print("=" * 82)
s = run("倾斜部分穿过", 0.5, lambda cam, cd: setattr(cam.location, "z", 1.0), True)

print()
print("=" * 82)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("DEGEN_DONE")
