import bpy
import mathutils
import math
import time
from bpy.app.handlers import persistent
from bpy_extras import view3d_utils
from bpy.app.translations import pgettext_iface as iface_
from .state import (_session, HANDLE_SELECT_RADIUS, HANDLE_HOLLOW_PICK_RADIUS,
               KEYFRAME_PICK_PRIORITY_RADIUS,
                    SAFE_LIMIT, HANDLE_ZERO_EPS, get_addon_prefs, addon_pref,
                    purge_stale_app_handlers)
from .cache import collect_animation_curves, get_writable_fcurves, is_position_animation, resolve_parent_transform, refresh_position_store, frame_has_keyframe
from .drawing import (compute_handle_display_factors, attach_render_callback,
                      detach_render_callback, handle_is_zero_length,
                      world_eps_for_screen, _endpoint_is_hidden_side)
from . import handles as hd
from . import time_domain as td
from . import transform_domain as xf

try:
    from . import modal_edit as _modal
except Exception:
    _modal = None

try:
    from . import overlay as _ov
except Exception as _e:
    print("RealTimeMotionPath: overlay 模块导入失败 -> %r" % (_e,))
    _ov = None


# 悬停：鼠标离关键帧多近才显示速度三角
SPEED_HOVER_RADIUS = 90.0
# 命中三角的半径
SPEED_TRI_PICK_RADIUS = 22.0

# ⚠️ 帧号匹配容差。
#
# 曾经到处用 `< 0.5`（"同帧"的直觉判断），但关键帧**可以只相隔 0.4 帧**
# （agent 实测：`keyframe_insert(frame=14.4)` 能建出独立关键帧）。
# 此时 `abs(14.4 - 14.0) = 0.4 < 0.5` → **误选/误改相邻的关键帧**
# → 用户看到"只选了一个点却动了两个"或"完全没反应"（实测复现）。
#
# 帧号在场景数据里是 float32，误差约 1e-6，所以 1e-3 足够精确匹配。
FRAME_EPS = 1e-3

# ---------------------------------------------------------------------------
# (t,v) 平面直线外推的【安全值域上限】
#
# `update_linked_handle` 是兼容层，走的是老算法：`slope = dv / dt` 然后沿直线
# 把对侧手柄外推到 `dt_opp` 处。**dt 在分母上**，所以速度编辑把 dt 压小之后
# 外推会失控（实测炸到 -5766）。
#
# 两道保护：dt ≤ `xf.DT_EPS` 放弃；外推结果偏离 co 超过本上限也放弃。
# 放弃不是丢功能 —— 紧随其后的 `xf.finish_linked_handle` 会走三维通路
# （方向 + 臂长，全程不除 dt）把对侧摆正。
_MAX_TV_EXTRAP = 100.0


# ---------------------------------------------------------------------------
# 速度手柄：悬停 / 命中 / 拖拽（供给 path_point_drag 使用）
# ---------------------------------------------------------------------------

def _hit_sampled_point(context, region, rv3d, mouse_pos):
    """在所有【采样点】里找离鼠标最近、且在选中半径内的那个。

    返回 (world_pos, frame, bone) 或 None。

    ⚠️ 必要性：`cached_positions` 只缓存关键帧；而插件画的是每帧一个采样点。
       不补这一层，绝大多数画出来的点都点不中（实测 40 个点里只有 4 个能点）。
    """
    try:
        frame_start = context.scene.frame_start
    except Exception:
        return None
    obj = context.active_object
    best = None
    try:
        for (pname, pbone), pts in _session.path_point_sequence.items():
            draw_obj = bpy.data.objects.get(pname)
            if draw_obj is None:
                continue
            # POSE 模式下只考虑可交互的骨骼
            if pbone is not None:
                if obj is None or obj.mode != 'POSE':
                    continue
                if pbone not in set(_session.cached_positions.get(pname, {}).keys()):
                    continue
            else:
                if obj is not None and obj.name != pname:
                    continue
            try:
                pm = resolve_parent_transform(draw_obj, pbone)
            except Exception:
                continue
            for i, local_pos in enumerate(pts):
                world_pos = pm @ local_pos
                sp = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                if sp is None:
                    continue
                dist = (mouse_pos - sp).length
                if dist < HANDLE_SELECT_RADIUS and (best is None or dist < best[0]):
                    best = (dist, world_pos, float(frame_start + i), pbone, pname)
    except Exception:
        return None
    if best is None:
        return None
    _session.drag_target_object = best[4]
    return best[1], best[2], best[3]


def _position_keyframe_frames(action, obj, bone_name=None):
    """位移动画上所有关键帧的帧号（升序）。"""
    out = set()
    try:
        for fc in collect_animation_curves(action, obj):
            if is_position_animation(fc, bone_name):
                for kp in fc.keyframe_points:
                    out.add(float(kp.co[0]))
    except Exception:
        pass
    return sorted(out)


def _nearest_keyframe_frame(action, obj, frame, bone_name=None):
    """离 frame 最近的关键帧帧号。

    ⚠️ 为什么需要它（用户 2026-09-15 实测反馈"R/S 没反应"）：
       插件画出来的路径点是【每帧一个采样点】（40 个），
       而"移动/旋转/缩放"实际作用的对象是【关键帧】（可能只有 4 个）。
       原来的代码是 `if abs(kp.co[0] - hit_frame) < FRAME_EPS` ——
       点中非关键帧的采样点 → 什么都不选中 → 按 R/S 自然"没反应"。
       实测：点 f7/f20 → 选中集合为空；点 f1/f14/f27 → 才选中。
       改成吸附到最近关键帧后，点哪里都能选中。
    """
    frames = _position_keyframe_frames(action, obj, bone_name)
    if not frames:
        return None
    return min(frames, key=lambda f: abs(f - float(frame)))


def _all_speed_handles(context, obj, region, rv3d):
    """当前视图下所有可编辑的速度手柄。"""
    if _modal is None or obj is None or not obj.animation_data or not obj.animation_data.action:
        return []
    try:
        return _modal.collect_speed_handles(obj.animation_data.action, obj, region, rv3d)
    except Exception:
        return []


def _update_speed_hover(context, obj, region, rv3d, mouse_pos):
    """刷新悬停状态 + 覆盖层显示内容。"""
    handles = _all_speed_handles(context, obj, region, rv3d)

    # 悬停：找最近的关键帧（任一三角所属）
    hover_frame = None
    if handles:
        kf_screens = {}
        for h in handles:
            kf_screens.setdefault(h['frame'], h['kf_screen'])
        hover_frame = hd.keyframe_hit(kf_screens, mouse_pos, SPEED_HOVER_RADIUS)

    _session.hover_frame = hover_frame

    # ★ 用户 2026-09-16：**精确**到哪一个三角。
    #   与"点击选中三角"共用**同一个** `_triangle_under_cursor`（含关键帧保护）
    #   ⇒ 「看到的 = 能抓的」，两处口径不会漂移。
    #   用途：光标停在三角上时按 Backspace = 恢复该三角的默认速度（匀速 1.00x）。
    #   ⚠️ 必须在这里（MOUSEMOVE 通路）刷新 —— 否则鼠标移开后本字段会残留旧值，
    #      按 Backspace 会误重置"上一次悬停过的三角"。
    _hit_tri = _triangle_under_cursor(handles, mouse_pos)
    _session.hover_speed_tri = ((_hit_tri['frame'], _hit_tri['tri'])
                                if _hit_tri is not None else None)

    # 要画哪些：悬停关键帧的所有三角 + **所有已选中的三角**（多选时都常显）
    sel_set = list(getattr(_session, "selected_speed_handles", None) or [])
    visible = []
    for h in handles:
        keep = (hover_frame is not None and h['frame'] == hover_frame)
        if _session.is_speed_handle_selected(h['frame'], h['tri']):
            keep = True
        if keep:
            visible.append(h)
    _session.hover_handles = visible

    if sel_set:
        # ★ 多选时**每个选中三角各自的路径段都高亮**（用户 2026-09-16）
        #   长度 = 该段离匀速的极端程度；颜色 = 方向（变疏橙 / 变密蓝）
        groups = []
        for (f_, t_) in sel_set:
            side_ = hd.SIDE_BY_TRI.get(t_)
            if side_ is None:
                continue
            rec_ = None
            for h in handles:
                if h['frame'] == f_ and h['tri'] == t_:
                    rec_ = h
                    break
            tval = rec_.get('extremeness', 0.0) if rec_ else 0.0
            dense = bool(rec_ and rec_.get('s') is not None and rec_['s'] > td.S_LIN)
            groups.append((f_, side_, tval, dense))
        _ov and _ov.set_segment_highlights(groups)
        _ov and _ov.get_overlay().set_handles(
            visible, list(sel_set), dragging=_session.speed_drag_active,
            split_frames=make_split_frames(obj, handles))
    else:
        _ov and _ov.clear_segment_highlight()
        _ov and _ov.get_overlay().set_handles(
            visible, [], dragging=_session.speed_drag_active,
            split_frames=make_split_frames(obj, handles))
    return handles


def _apply_speed_d(context, obj, frame, side, d):
    """把 d（屏幕像素当量）写下去。d 越大 = 该侧越疏。**无硬限制**。"""
    if obj is None:
        return None
    act = obj.animation_data.action if obj.animation_data else None
    if act is None:
        return None
    kf_map, span = td.resolve_target(act, obj, frame, side)
    if not kf_map or span is None:
        return None
    # d 不再钳到 >= 0：允许"拖过关键帧继续变密"（用户要求去掉极值限制）
    s = td.d_to_s(float(d))
    # 传 act/obj：write_s 需要它们来冻结【邻居关键帧】（否则对侧路径会变形）
    written = td.write_s(kf_map, side, s, span, act=act, obj=obj)
    for ax in kf_map:
        fc = td.fcurve_of(act, obj, ax)
        if fc:
            fc.update()
    try:
        refresh_position_store(context)
    except Exception:
        pass
    return written


def _reset_speed_handle_default(context, obj, frame, tri):
    """把一个速度三角恢复成【默认值】= 匀速 1.00x（s = td.S_LIN）。

    ★ 用户 2026-09-16：光标悬停在三角上时按 Backspace 触发。

    为什么"默认值"没有歧义（实测 `_s_default.py`，Blender 5.x）：
      `read_s()` = `|co[0] − handle[0]| / span`，而 Blender 默认手柄
      （AUTO_CLAMPED / FREE / VECTOR，**无论关键帧是否等距**）解析出来的
      这个比值**恒等于 1/3 = `td.S_LIN`**。
      ⇒ "恢复默认"与"恢复到未编辑过的状态"是同一个值，不存在二义性。

    返回 True 表示确实写入了。
    """
    side = hd.SIDE_BY_TRI.get(tri)
    if side is None:
        return False
    written = _apply_speed_d(context, obj, float(frame), side,
                             td.s_to_d(td.S_LIN))
    return written is not None


def try_reset_hovered_speed(context, event):
    """光标悬停在某个速度三角上时，按 Backspace 的处理（用户 2026-09-16）。

    返回 True = 已消费该按键（调用方应返回 RUNNING_MODAL）；
    返回 False = 不处理（调用方应 PASS_THROUGH，不影响原生 Backspace）。

    三条边界：
      ① 只认【精确命中】的三角（`_session.hover_speed_tri`，22px 命中，
         与点击选中共用同一判定 ⇒ 看到的 = 能抓的）。
      ② 拖拽中不响应（那是在连续写值，语义冲突）。
      ③ G/R/S（含数字输入）模态运行时本函数收不到事件 ——
         `RTMP_OT_KeyboardTransform.modal` 末尾统一 `return {'RUNNING_MODAL'}`。

    ⚠️ 抽成独立函数（而不是内联在 modal 里）是为了**可被 headless 测试直接调用**。
    """
    ht = getattr(_session, "hover_speed_tri", None)
    if ht is None or _session.speed_drag_active:
        return False
    obj = _get_drag_obj(context)
    if not _reset_speed_handle_default(context, obj, ht[0], ht[1]):
        return False
    bpy.ops.ed.undo_push(message=iface_("Adjust Motion Path Speed"))
    # 重算悬停记录：三角的 s/d 变了，覆盖层的倍数标签与高亮要跟着更新
    try:
        _reg, _sp, _lm, _ar = find_region_under_mouse(context, event)
        if _reg and _sp:
            _update_speed_hover(context, obj, _reg, _sp.region_3d, _lm)
        _a = _ar if _ar else getattr(context, "area", None)
        if _a is not None and _a.type == 'VIEW_3D':
            _a.tag_redraw()
    except Exception:
        pass
    return True


# ---------------------------------------------------------------------------
# ★★ 双击三角 ⇒ 复制【同关键帧另一个三角】的速度值（用户 2026-09-17 需求）
#
#   每个关键帧有【两个】速度三角（见 handles.py）：
#       ▼ up   （在关键帧上方）→ 负责【左段】
#       ▲ down （在关键帧下方）→ 负责【右段】
#   需求原文：
#       "当用户双击三角手柄时，可以把当前双击的三角手柄所负责速度分布值
#        改为同关键帧的另外一个三角手柄相同的值"
#   ⇒ 双击 (frame, tri) ⇒ 该三角的值 := 同帧**相反那个**三角的值。
# ---------------------------------------------------------------------------

def _speed_dblclick_window(context):
    """双击判定的时间窗（秒）：取 Blender 偏好 `mouse_double_click_time`（ms）。"""
    try:
        ms = context.preferences.inputs.mouse_double_click_time
        return max(0.05, min(1.0, float(ms) / 1000.0))
    except Exception:
        return 0.35          # 偏好拿不到时的兜底（实测 Blender 默认 350ms）


def clear_speed_click_chain():
    """断掉"双击链"（下一次点击不会算作双击）。"""
    _session.speed_click_info = None


def speed_double_click_hit(frame, tri, mouse_xy, now=None, window=None,
                           radius=None):
    """纯逻辑：本次点击是否构成对**同一个三角**的双击；并维护"上次点击"记录。

    ★ 为什么不用 `event.value == 'DOUBLE_CLICK'`（2026-09-17 决定）：
      那个值由 Blender 事件系统按 keymap 生成，在**常驻 modal** 里能否收到
      **不确定**；而"双击"本身就是【时间 + 位置】两个**可测量**的量
      ⇒ 自己判：行为确定、可复现、且能被 headless 测试直接驱动（喂 now/window）。

    四个参数全可注入（now / window / radius）⇒ 测试不必真等时间过去。

    返回 True = 双击（并且**消费**掉记录 ⇒ 三击不会连触发）。
    """
    if now is None:
        now = time.monotonic()
    if window is None:
        window = _speed_dblclick_window(bpy.context)
    if radius is None:
        radius = SPEED_TRI_PICK_RADIUS
    prev = getattr(_session, "speed_click_info", None)
    hit = False
    if prev is not None:
        try:
            same_tri = (abs(float(prev.get('frame')) - float(frame)) < 1e-3
                        and prev.get('tri') == tri)
            in_time = (float(now) - float(prev.get('t'))) <= float(window)
            dx = float(mouse_xy[0]) - float(prev['pos'][0])
            dy = float(mouse_xy[1]) - float(prev['pos'][1])
            near = (dx * dx + dy * dy) <= float(radius) ** 2
            hit = bool(same_tri and in_time and near)
        except Exception:
            hit = False
    if hit:
        _session.speed_click_info = None       # 消费掉（防三击再触发）
    else:
        _session.speed_click_info = {
            'frame': float(frame), 'tri': tri, 't': float(now),
            'pos': (float(mouse_xy[0]), float(mouse_xy[1]))}
    return hit


def _read_side_s(kf_map, span, side):
    """读某侧当前的 s —— 与 `modal_edit.collect_speed_handles` 用**同一口径**。

    ⚠️ `td.read_s` 收的是**单个关键帧对象**（不是 map）——
       各轴的时间分量由 `write_s` 统一写入、彼此相同，取任一个轴即可。
       （实测踩过：直接传 `kf_map` 会 `AttributeError: 'dict' object has no
         attribute 'handle_right'`。）
    """
    if not kf_map or span is None:
        return None
    try:
        return td.read_s(next(iter(kf_map.values())), span, side)
    except Exception:
        return None


def _copy_speed_value(context, obj, frame, tri):
    """把同关键帧【另一个三角】的速度分布值复制到本三角。

    复制的是**归一化值 `s`**（= 该侧 dt / span），不是像素量 `d` ——
    因为界面显示的倍数 = `S_LIN / s`，只与 `s` 有关
    ⇒ 复制 `s` 能让两边的**显示倍数完全一致**，与两侧 span 是否相等无关。
    （若复制 `d`，两侧 span 不同时倍数会不一样。）

    返回 `(ok, s_copied, reason)`：
      · ok=True  ⇒ 已写入；s_copied = 复制过来的 s
      · ok=False ⇒ reason 供状态栏提示
    """
    side = hd.SIDE_BY_TRI.get(tri)
    other_tri = hd.TRI_DOWN if tri == hd.TRI_UP else hd.TRI_UP
    other_side = hd.SIDE_BY_TRI.get(other_tri)
    if side is None or other_side is None:
        return (False, None, "unknown_tri")
    if obj is None or not obj.animation_data or not obj.animation_data.action:
        return (False, None, "no_action")
    act = obj.animation_data.action
    kf_map_o, span_o = td.resolve_target(act, obj, float(frame), other_side)
    if not kf_map_o or span_o is None:
        # ⚠️ 对侧是【端点段】（首帧的左段 / 末帧的右段）⇒ 那个三角**根本不存在**
        #    （`handles.collect_handles` 不生成）⇒ 没有可复制的值。
        return (False, None, "no_opposite")
    s_other = _read_side_s(kf_map_o, span_o, other_side)
    if s_other is None:
        return (False, None, "read_failed")
    written = _apply_speed_d(context, obj, float(frame), side,
                             td.s_to_d(float(s_other)))
    if written is None:
        return (False, None, "write_failed")
    return (True, float(s_other), None)


def _align_opposite_speed(context, obj, frame, tri):
    """★ 双击 → 让该关键帧在 Graph Editor 里的两根手柄共线 / 镜像。

    用户 2026-09-18 需求：双击不再"复制对侧疏密"，而是**对齐 GE 手柄**。
    语义（替换旧的 `_copy_speed_value`）：
      · **保持被双击侧的疏密 dt 不动**
      · 按公式算【对侧】的新 dt 并写入

    公式（令两侧斜率的**绝对值相等**）：
        dt_对侧 = dt_本侧 × |值_对侧| / |值_本侧|

    其中 A = co[1] − handle_left[1]（左段值分量）、B = handle_right[1] − co[1]：
      · A、B **同号** ⇒ 两侧斜率同号且相等 ⇒ **共线**（曲线平滑穿过关键帧）
      · A、B **异号** ⇒ 斜率反号、绝对值相等 ⇒ **镜像**（对称尖峰）

    为什么这能"保形状"：只改 handle[0]（时间分量），A / B（值分量）原样不动
    ⇒ 3D 视图的路径形状不变，变的只是采样点疏密（三角位置）。

    三轴：按【主用轴】（array_index 最小者，通常 X）算比率，三轴共用同一个 dt。
      实测（_axis_ratio.py）：Blender 自动手柄下 A/B 三轴**天然恒等**
      （≈ dtL/dtR，与轴、与值无关）⇒ 一个 dt 比率天然同时满足三轴。
      仅当有人工精修过手柄（三轴 A/B 互不相同）时以主用轴为准，其余轴顺其自然。

    返回 `(ok, info, reason)`：
      · ok=True  ⇒ info = {"dt", "s", "same_sign", "clamped"}
      · ok=False ⇒ reason 供状态栏提示
    """
    side = hd.SIDE_BY_TRI.get(tri)
    other_tri = hd.TRI_DOWN if tri == hd.TRI_UP else hd.TRI_UP
    other_side = hd.SIDE_BY_TRI.get(other_tri)
    if side is None or other_side is None:
        return (False, None, "unknown_tri")
    act = _action_of(obj)
    if act is None:
        return (False, None, "no_action")

    # 被双击侧（保持不动）—— 拿它的 dt + 值分量
    kf_map_s, span_s = td.resolve_target(act, obj, float(frame), side)
    if not kf_map_s or span_s is None:
        return (False, None, "no_source")
    # 对侧（要被改）—— 端点段没有三角 ⇒ 不可改
    kf_map_o, span_o = td.resolve_target(act, obj, float(frame), other_side)
    if not kf_map_o or span_o is None:
        return (False, None, "no_opposite")

    # ★ 主用轴（array_index 最小）= 决定三轴共用的 dt 比率
    primary = sorted(kf_map_s.keys())[0]
    kp_s = kf_map_s[primary]
    A = kp_s.co[1] - kp_s.handle_left[1]        # 左段值分量
    B = kp_s.handle_right[1] - kp_s.co[1]       # 右段值分量

    if side == 'left':
        dt_src = abs(kp_s.co[0] - kp_s.handle_left[0])
        val_src, val_other = A, B
    else:
        dt_src = abs(kp_s.handle_right[0] - kp_s.co[0])
        val_src, val_other = B, A

    # 值分量为 0 ⇒ 该侧手柄是水平的（斜率 0），定不出比率（数学退化）
    if abs(val_src) < 1e-12 or abs(val_other) < 1e-12:
        return (False, None, "degenerate")

    dt_new = dt_src * abs(val_other) / abs(val_src)
    s_new = dt_new / span_o
    clamped = s_new > td.S_HARD_MAX
    written = td.write_s(kf_map_o, other_side, s_new, span_o, act=act, obj=obj)
    if written is None:
        return (False, None, "write_failed")
    for ax in kf_map_o:
        fc = td.fcurve_of(act, obj, ax)
        if fc:
            fc.update()
    try:
        refresh_position_store(context)
    except Exception:
        pass
    return (True, {"dt": dt_new, "s": float(written),
                   "same_sign": (A * B) > 0, "clamped": clamped}, None)


# ---------------------------------------------------------------------------
# ★★ 2026-09-18：三角「一体 / 分离」的辅助（用户需求）
#
#   一体（默认）：同一关键帧的两个三角**联动** —— 单击选中两个、拖动两边同值。
#   分离        ：两个三角各自独立 —— 可单边选中、单边调整。
#
#   ⚠️ "该帧有哪些三角" 是**查询**来的（端点段不生成三角），不是假设出来的：
#      首帧只有 right 三角（左段无邻居）/ 末帧只有 left 三角。
# ---------------------------------------------------------------------------

def _action_of(obj):
    """取 obj 当前 action（没有就 None）。"""
    try:
        return obj.animation_data.action if obj and obj.animation_data else None
    except Exception:
        return None


def _tris_present_for_frame(s_handles, frame):
    """该关键帧**实际存在**的三角列表（从已收集的手柄记录里查）。

    ⚠️ 必须按实际记录查 —— 端点上只有一个三角，硬写 [(up),(down)] 会
       选中一个**不存在**的三角，之后拖动对它写值必然失败（静默）。
    """
    out = []
    for h in (s_handles or []):
        try:
            if abs(float(h.get('frame')) - float(frame)) < FRAME_EPS:
                t = h.get('tri')
                if t is not None and t not in out:
                    out.append(t)
        except Exception:
            continue
    # 稳定顺序：与 TRI_KINDS 一致（上 → 下）
    return [t for t in hd.TRI_KINDS if t in out]


def is_frame_locked(obj, frame):
    """该关键帧的三角是否处于「一体」（未记录 ⇒ True = 默认一体）。"""
    act = _action_of(obj)
    if act is None:
        return True
    try:
        return bool(xf.is_tri_locked(act, frame))
    except Exception:
        return True


def make_split_frames(obj, s_handles):
    """当前视图里**处于分离状态**的帧号集合（供覆盖层画空心三角）。

    只收"确实有两个三角"的帧 —— 端点上分离没有意义（本来就只有一个）。
    """
    act = _action_of(obj)
    if act is None:
        return set()
    frames = set()
    for h in (s_handles or []):
        try:
            frames.add(round(float(h.get('frame')), 4))
        except Exception:
            continue
    out = set()
    for f in frames:
        try:
            if xf.is_tri_locked(act, f):
                continue
        except Exception:
            continue
        if len(_tris_present_for_frame(s_handles, f)) >= 2:
            out.add(f)
    return out


def _triangle_under_cursor(s_handles, mouse_pos):
    """★★【唯一的】"鼠标下的三角" 查询 —— 带**关键帧点保护**。

    用户在 2026-09-18 反馈："关键帧点和三角控制柄容易误触，
    用户想选择关键帧点时容易误触选择三角控制器"。

    根因（实测，不是感觉）：三角的拾取盘半径 22 > 三角尖端离关键帧的 18.5
    ⇒ 拾取盘覆盖了 **[4, 18.5] 这段什么都没画的空白区**，
       用户瞄关键帧点往上偏一点点就被判成"点中三角"。

    判据：鼠标离该三角所属**关键帧点**的距离 < `KEYFRAME_PICK_PRIORITY_RADIUS`
          ⇒ 这个三角**不参与命中**（把机会让给关键帧）。

    ⚠️ **必须唯一**：点击 / 悬停 / 双击 / 恢复默认，四处都得走这里，
       否则会出现"看得见的状态与点得中的状态不一致"（历史上栽过）。
    """
    hit = hd.hit_test(s_handles, mouse_pos, SPEED_TRI_PICK_RADIUS)
    if hit is None:
        return None
    kf_screen = hit.get('kf_screen')
    if kf_screen is not None:
        # ⚠️ 用**闭区间**（<=）：半径上的点也算关键帧的地盘 —— 与 `hd.hit_test`
        #    内部的 `d2 <= r2` 保持同一口径，避免"刚好在边界上"行为不确定。
        if hd.dist2(kf_screen, mouse_pos) <= (KEYFRAME_PICK_PRIORITY_RADIUS ** 2):
            # 离关键帧点很近 ⇒ 用户想选的是**关键帧**，不是三角
            return None
    return hit


def apply_speed_click_selection(obj, s_handles, hit_tri, shift=False):
    """★ 单击（或 Shift+单击）一个三角 ⇒ 更新选中集。

    返回 `(一体化, 该帧实际存在的三角列表)`：
      · 一体化=True  ⇒ 这次点击把该帧的**两个三角都选中了**（拖动要用"一个旋钮"语义）
      · 一体化=False ⇒ 只选中单边（分离态 / Shift 多选 / 端点）

    语义（用户 2026-09-18）：
      · **一体（默认）**：单击任一个三角 ⇒ 两个一起选中（"两个三角是一体的"）
      · **分离**        ：只选被点的那个（用户要"只调整单边"）
      · Shift          ：多选累加/取消（保留 2026-09-16 语义，**不做**自动配对）

    ⚠️ 抽成模块级函数（不是内联在 modal 里）⇒ headless 测试能驱动**真入口**。
    """
    frame = hit_tri['frame']
    tris = _tris_present_for_frame(s_handles, frame)
    if shift:
        _session.toggle_speed_handle(frame, hit_tri['tri'])
        return (False, tris)
    locked = is_frame_locked(obj, frame) and len(tris) >= 2
    if locked:
        _session.set_locked_pair_speed_handle(frame, tris)
        return (True, tris)
    _session.set_single_speed_handle(frame, hit_tri['tri'])
    return (False, tris)


def toggle_frame_lock(context, obj, frame, s_handles, local_mouse_pos,
                      region=None, rv3d=None):
    """★ 双击一个三角 ⇒ **切换该帧的「一体 / 分离」**。返回 `(ok, message)`。

    语义（用户 2026-09-18）：
      · 当前是一体 → 切成**分离**（可单边操作）
      · 当前是分离 → **锁回一体**，并把**对侧的值同步到被双击的这个三角**
                     （= 旧的双击"复制值"行为，保留在锁定这一步）

    ⚠️ 两个三角必须都在才谈得上"切换"；端点上返回 `no_pair`。
    """
    act = _action_of(obj)
    if act is None:
        return (False, "no_action")
    tris = _tris_present_for_frame(s_handles, frame)
    if len(tris) < 2:
        # 首/末帧：只有一个三角 ⇒ 无所谓一体分离，保持原样（不报错、不写数据）
        return (False, "no_pair")

    locked_now = is_frame_locked(obj, frame)
    if locked_now:
        # 一体 → 分离
        try:
            xf.set_tri_locked(act, frame, False)
        except Exception:
            return (False, "write_failed")
        # ★★ 2026-09-19：补一个 undo 点 —— 与「分离 → 锁回一体」分支对称。
        #    缺它时，一次 Ctrl+Z 会【越过】这次分离：实测（真双击入口 + 真 undo）
        #      · 无 push ⇒ undo 退到了更早的状态，严重时连对象一起消失；
        #      · 有 push ⇒ undo 回到「一体」、redo 回到「分离」，完美往返。
        #    原因：锁定状态写在 action 的 custom property 上，属于**脚本级写入**；
        #    它不会自己形成 undo 步，必须显式推一个（作者在锁回一体分支已有先例）。
        try:
            bpy.ops.ed.undo_push(message=iface_("Split Handles"))
        except Exception:
            pass          # 后台/无撤销上下文时忽略（不影响写入本身）
        # 分离后鼠标停在哪个三角，就只选那个（单边操作的起点）
        _session.set_single_speed_handle(frame, tris[0])
        try:
            if rv3d is not None and local_mouse_pos is not None:
                hit = _triangle_under_cursor(s_handles, local_mouse_pos)
                if hit is not None:
                    _session.set_single_speed_handle(hit['frame'], hit['tri'])
        except Exception:
            pass
        msg = iface_("Handles split - you can now adjust each side on its own")
        return (True, msg)

    # 分离 → 锁回一体。
    # ★ 2026-09-18：这里的数据行为从「复制对侧疏密 s」改成「对齐 GE 手柄」——
    #   保持被双击侧的疏密不动，按公式算对侧的新疏密（共线 / 镜像）。
    hit = None
    try:
        hit = _triangle_under_cursor(s_handles, local_mouse_pos)
    except Exception:
        hit = None
    tri_clicked = hit['tri'] if hit is not None else tris[0]
    try:
        xf.set_tri_locked(act, frame, True)
    except Exception:
        return (False, "write_failed")

    ok, info, reason = _align_opposite_speed(context, obj, frame, tri_clicked)
    if ok:
        try:
            bpy.ops.ed.undo_push(message=iface_("Lock Handles Together"))
        except Exception:
            pass          # 后台/无撤销上下文时忽略（不影响写入本身）
    # 锁定 → 两个三角一起选中（"一体"的视觉与行为）
    _session.set_locked_pair_speed_handle(frame, tris)
    if ok:
        # 两条独立完整文案（便于 i18n 直接映射，不拼词）
        if info.get("same_sign"):
            msg = iface_("Handles locked together - GE handles aligned (smooth)")
        else:
            msg = iface_("Handles locked together - GE handles mirrored (symmetric peak)")
    elif reason == "no_opposite":
        msg = iface_("Handles locked together (no opposite handle to match)")
    elif reason == "degenerate":
        msg = iface_("Handles locked together (handle is flat, cannot align)")
    else:
        msg = iface_("Handles locked together")
    return (True, msg)


def try_toggle_tri_lock_click(context, obj, s_handles, local_mouse_pos,
                              region=None, rv3d=None):
    """双击三角的处理入口。返回 `(consumed, message)`。

      · consumed=True ⇒ 调用方 `return {'RUNNING_MODAL'}`（不要顺势进入拖拽）
      · message 非空   ⇒ 调用方 `self.report({'INFO'}, message)`

    ★ 2026-09-18：语义从"双击=复制值"升级为"双击=**切换一体/分离**"。
      复制的效果被保留在"分离 → 锁回一体"那一步里（用户需求原话：
      "插件会把同关键帧的另一个三角控制柄的数值同步到双击的三角控制柄，
       并同时锁定三角控制柄"）。

    ⚠️ 抽成独立函数（与 `try_reset_hovered_speed` 同思路）⇒ 可被 headless 测试
       直接调用，不必模拟真 modal。
    """
    hit = _triangle_under_cursor(s_handles, local_mouse_pos)
    if hit is None:
        # 点到别处 ⇒ 断掉双击链（避免"隔一会儿点同一三角"被误判成双击）
        clear_speed_click_chain()
        return (False, None)
    frame, tri = hit['frame'], hit['tri']
    if not speed_double_click_hit(frame, tri, local_mouse_pos):
        return (False, None)

    # ---- 双击命中：切换锁定 ----
    ok, msg = toggle_frame_lock(context, obj, frame, s_handles, local_mouse_pos,
                                region, rv3d)
    if not ok and msg == "no_pair":
        # 端点上没有"一对"⇒ 不消费（让调用方按普通单击处理）
        clear_speed_click_chain()
        return (False, None)
    # 值 / 状态变了 ⇒ 悬停记录（倍数标签 / 段高亮）要跟着更新
    try:
        if region is not None and rv3d is not None:
            _update_speed_hover(context, obj, region, rv3d, local_mouse_pos)
        _a = getattr(context, "area", None)
        if _a is not None and _a.type == 'VIEW_3D':
            _a.tag_redraw()
    except Exception:
        pass
    return (True, msg)


# 旧名保留（v1.3.2 及以前的测试/调用方用）—— 行为已升级为"切换锁定"。
try_copy_other_speed_click = try_toggle_tri_lock_click


def _apply_speed_from_drag(context, obj, mouse_pos):
    """按【相对拖拽量】更新疏密 —— **支持多选同时滑移**。

    用户 2026-09-16：
      · ① Shift+点击可多选三角，拖拽时**所有选中的三角一起滑移**
      · ③ 拖拽中按住 Shift = 精度模式（位移 ×0.1）

    每个三角按**自己的疏密方向**解释同一个鼠标位移：
      上三角（在关键帧上方）往上拖 = 远离关键帧 = 变疏
      下三角（在关键帧下方）往上拖 = 靠近关键帧 = 变密
    —— 即"鼠标往哪拖、三角就往哪动"，物理直觉一致。

    ⚠️ `mouse_pos` 必须【由调用方传入】（不能从 session 读）。
    """
    handles = list(getattr(_session, "selected_speed_handles", None) or [])
    if not handles:
        # 兼容：没有多选集合时退回单值字段
        f, t = _session.selected_speed_frame, _session.selected_speed_tri
        if f is not None and t is not None:
            handles = [(f, t)]
    if not handles or mouse_pos is None:
        return None

    # ---- ③ 增量累积的竖直位移（精度模式只影响【此后】的移动）----
    last = _session.speed_drag_last_mouse
    if last is None:
        # 第一次调用：只记起点，不产生位移
        _session.speed_drag_last_mouse = mouse_pos
        return None
    dy_raw = float(mouse_pos[1]) - float(last[1])
    _session.speed_drag_last_mouse = mouse_pos
    # 微小抖动（投影噪声）忽略，避免累积漂移
    if abs(dy_raw) > 1e-9:
        scale = xf.PRECISION_FACTOR if _session.speed_drag_precision else 1.0
        # ★ 2026-09-17（用户拍板 120~150px 打满全程）：鼠标像素 → d 再乘
        #   DRAG_PX_SCALE（<1），等效"拖更远才打满"，手感更可控。
        #   ⚠️ 缩放放在这里（像素→d），不动 time_domain 的几何映射
        #      （那两个速率决定 d↔s 的对应，改了会把三角画到视口外）。
        _session.speed_drag_effective_px += dy_raw * scale * td.DRAG_PX_SCALE

    eff = _session.speed_drag_effective_px
    # ⚠️ 2026-09-17 记录一次【未成立】的尝试：
    #   我曾在这里加"首次拖动时把超范围的 s 规范化写回"，以为是 GE 卡死的解药。
    #   bug 注入 3 组全部抓不住 ⇒ 回去推演才发现：
    #     · s 超范围时，往超限方向拖到 1.0 就不动 —— 那是**物理上限**（正确行为）
    #     · 规范化只是把 s 从 2.0 写回 1.0，**不改变"能动范围"**
    #   ⇒ 它是多余的，已回退。真正的根因是**拖拽速率太陡**（拖 30px 打满全程），
    #     修在 `td.DRAG_PX_SCALE`（135px 打满），不在这里。
    # ★★ 2026-09-18（用户拍板乙方案）：**「一体」拖动 = 一个旋钮**
    #
    #   选中集恰好是"同一个锁定帧的两个三角"时，两侧必须写**同一个 s**
    #   （一起变快 / 一起变慢），而不是各按自己的 d0 起算 ——
    #   后者因为两侧 span 不同，会让左边变快、右边变慢（手感变成"剪刀"）。
    #
    #   ⚠️ `eff` 是**净像素位移**（已经由每个三角各自的 DIR 换算过吗？没有 ——
    #      `eff` 是原始竖直位移）。一体时统一按"往上 = 更疏"约定一次方向，
    #      不能用各三角的 DIR（那会让两边一个变疏一个变密）。
    is_group = (_session.speed_drag_group_origin_s is not None
                and _session.speed_drag_locked_frame is not None)
    results = []
    for (frame, tri) in handles:
        side = hd.SIDE_BY_TRI.get(tri)
        if side is None:
            continue
        # ★ 起点 = **按下时记录的固定 d**（unclamped）。
        #   ⚠️⚠️ 不能每帧现读"当前值"：`eff` 是【累积】位移，
        #     "当前值 + 累积位移"会**双重累加** ⇒ 拖得越久加得越多 ⇒ 指数漂移
        #     （= 用户零容忍的"跳变"）。2026-09-19 实测抓到一次。
        d0 = _session.speed_drag_origins.get((frame, tri))
        if d0 is None:
            d0 = _session.speed_drag_origin_d
        if is_group:
            # ★★ 2026-09-19（用户拍板，语义修正）：
            #   **一体 = 两侧各加减【同一个增量】，差异保留**
            #   （推翻旧语义"一个旋钮 / 两侧始终同值"）。
            #
            #   用户原话：「双击锁定三角后拖动一体化的三角，三角的数值会被强行同步
            #   为相同数值；一体化锁定的定义应该是可以同时做增量调整，不是改变稀疏
            #   数值为相同」。
            #
            #   方向：统一取 UP（上=更疏）—— 不能用各三角自己的 DIR，
            #         否则两侧一个变疏一个变密；但**数值各按各自的起点** ⇒ 差异保留。
            delta_px = eff * hd.DIR_BY_TRI.get(hd.TRI_UP, 1.0)
        else:
            # 每个三角按【自己的疏密方向】解释同一个竖直位移
            delta_px = eff * hd.DIR_BY_TRI.get(tri, 1.0)
        results.append(_apply_speed_d(context, obj, frame, side, d0 + delta_px))
    return results[-1] if results else None


def flush_pending_speed_drag(context, obj):
    """★★★ 2026-09-18（性能修复配套）：把手柄拖拽**被节流跳过**的那段位移补写进去。

    ⚠️ 为什么必须有它（否则就是跳变）：
      节流会跳掉一部分 MOUSEMOVE。因为写值是**增量法**，跳过的位移会在
      **下一次**事件里被一并补上 —— 但"松手"之后就没有下一次了，
      最后 ≤1 帧（默认 16ms）的位移**会永久丢掉** ⇒ 松手瞬间画面与鼠标位置
      差一截（跳变）。所以 RELEASE 时必须强制补一次。

    做法：拿"上一次真正写入时的鼠标位置"与"当前鼠标位置"再算一次增量，
    `_apply_speed_from_drag` 内部是增量法 ⇒ 多余的位移是 0（幂等安全）。

    返回 True 表示**确实补了一次**（调用方据此决定要不要额外 tag_redraw）。
    """
    try:
        if not _session.speed_drag_active:
            return False
        last = _session.speed_drag_last_mouse
        cur = _session.speed_drag_pending_mouse
        if last is None or cur is None:
            return False
        # 位移为 0 ⇒ 无需补（避免无意义写入 + 多算一遍缓存）
        if abs(float(cur[1]) - float(last[1])) < 1e-9 \
                and abs(float(cur[0]) - float(last[0])) < 1e-9:
            return False
        _apply_speed_from_drag(context, obj, cur)
        return True
    except Exception:
        return False


def _apply_speed_from_mouse(context, obj, handle, mouse_pos):
    """[兼容旧接口] 按鼠标绝对位置写疏密（离关键帧越远越疏）。"""
    if obj is None or handle is None:
        return False
    d = hd.d_from_mouse(handle['kf_screen'], handle['tri'], mouse_pos)
    written = _apply_speed_d(context, obj, handle['frame'], handle['side'], d)
    if written is None:
        return False
    handle['s'] = written
    handle['d'] = td.s_to_d(written)
    return True


def _get_drag_obj(context):
    global _session
    if _session.drag_target_object:
        try:
            obj = bpy.data.objects.get(_session.drag_target_object)
            if obj:
                return obj
        except Exception:
            pass
    return context.active_object


@persistent
def on_depsgraph_update(scene, depsgraph):
    global _session
    
    if _session.drag_in_progress or _session.handle_edit_in_progress:
        return

    wm = bpy.context.window_manager
    # ★ 2026-09-17：更新模式已迁到插件偏好设置（AddonPreferences）——
    #   WindowManager 属性不写入文件（改完重启就丢），故换存储。
    if not wm.rtmp_path_display_enabled or addon_pref('refresh_strategy', 'SMART') != 'SMART':
        return

    is_object_updated = depsgraph.id_type_updated('OBJECT')
    is_action_updated = depsgraph.id_type_updated('ACTION')
    
    if is_object_updated or is_action_updated:
        if bpy.context.screen and bpy.context.screen.is_animation_playing:
            return

        try:
            has_relevant_objects = (bpy.context.active_object or bpy.context.selected_objects)
            if has_relevant_objects:
                is_interaction_update = is_object_updated and not is_action_updated
                
                if is_interaction_update:
                    return

                refresh_position_store(bpy.context)
                
                for window in wm.windows:
                    for area in window.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()
        except Exception as e:
            print(f"Error in smart update: {e}")


class RTMP_OT_PathRefreshDaemon(bpy.types.Operator):
    bl_idname = "rtmp.path_refresh_daemon"
    bl_label = "Auto Update Motion Paths"
    bl_description = "Real time update motion paths"
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    _last_keyframe_values = None
    _needs_update = False
    
    @classmethod
    def poll(cls, context):
        return True
    
    def invoke(self, context, event):
        wm = context.window_manager
        self._last_keyframe_values = self._collect_keyframe_snapshot(context)
        self._last_active_obj_name = context.active_object.name if context.active_object else None
        self._last_selected_obj_names = self._collect_selected_names(context)
        self._last_bone_selection = self._collect_bone_selection(context)
        self._needs_update = False
        
        # ★★ 2026-09-17：改成"先按包名清干净、再加当前的"。
        #    原来的 `if on_depsgraph_update not in bpy.app.handlers.xxx` 比的是
        #    **函数对象身份** —— 跨模块重载后那是**新对象**，与列表里残留的
        #    旧对象不相等 ⇒ 判重失效 ⇒ 每次重载再叠一个
        #    （实测 `depsgraph_update_post` 叠了 3 个；其中旧模块那个还在读
        #      已删除的 WindowManager 属性 ⇒ 每次 depsgraph 更新抛 AttributeError）。
        purge_stale_app_handlers()
        bpy.app.handlers.depsgraph_update_post.append(on_depsgraph_update)
            
        interval = 1.0 / max(1, addon_pref('poll_frequency', 10))
        self._timer = wm.event_timer_add(interval, window=context.window)
        
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
        wm = context.window_manager

        active_obj = context.active_object
        current_obj_name = active_obj.name if active_obj else None
        if current_obj_name != self._last_active_obj_name:
            self._last_active_obj_name = current_obj_name
            _session.active_path_point = None
            _session.active_frame_number = None
            _session.active_handle_direction = None
            _session.active_bone_identifier = None
            _session.active_handle_index = None
            _session.active_handle_info = None
            _session.drag_in_progress = False
            _session.handle_edit_in_progress = False
            _session.drag_target_object = None
            _session.clear_speed_handle()
            self._needs_update = True

        current_selected = self._collect_selected_names(context)
        if current_selected != self._last_selected_obj_names:
            self._last_selected_obj_names = current_selected
            self._needs_update = True

        current_bone_selection = self._collect_bone_selection(context)
        if current_bone_selection != self._last_bone_selection:
            self._last_bone_selection = current_bone_selection
            if current_bone_selection is None:
                _session.active_bone_identifier = None
            self._needs_update = True
        
        if addon_pref('refresh_strategy', 'SMART') == 'TIMER' and event.type == 'TIMER':
            current_values = self._collect_keyframe_snapshot(context)
            if current_values != self._last_keyframe_values:
                self._needs_update = True
                self._last_keyframe_values = current_values
                
        if self._needs_update:
            try:
                refresh_position_store(context)
            except Exception as e:
                print("Error updating position cache:", e)
            self._needs_update = False
            for window in wm.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
        
        if not wm.rtmp_auto_refresh_active:
            self.cancel(context)
            return {'CANCELLED'}
        
        return {'PASS_THROUGH'}
    
    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None
            
        if on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(on_depsgraph_update)
    
    def _collect_object_keyframes(self, obj):
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return []
        action = obj.animation_data.action
        values = []
        for fcurve in collect_animation_curves(action, obj):
            for keyframe in fcurve.keyframe_points:
                values.append((
                    keyframe.co[0], keyframe.co[1],
                    keyframe.handle_left[0], keyframe.handle_left[1],
                    keyframe.handle_right[0], keyframe.handle_right[1],
                    keyframe.select_control_point
                ))
        return values

    def _collect_keyframe_snapshot(self, context):
        all_values = []
        
        active_object = context.active_object
        if active_object and active_object.mode == 'POSE':
            all_values.extend(self._collect_object_keyframes(active_object))
        else:
            seen = set()
            for obj in (context.selected_objects or []):
                if obj.name in seen:
                    continue
                seen.add(obj.name)
                all_values.extend(self._collect_object_keyframes(obj))
                parent = obj.parent
                while parent:
                    if parent.name not in seen:
                        seen.add(parent.name)
                        all_values.extend(self._collect_object_keyframes(parent))
                    parent = parent.parent
            if active_object and active_object.name not in seen:
                all_values.extend(self._collect_object_keyframes(active_object))
            
        return tuple(all_values) if all_values else None
    
    def _collect_selected_names(self, context):
        return tuple(sorted(obj.name for obj in context.selected_objects)) if context.selected_objects else ()
    
    def _collect_bone_selection(self, context):
        active_object = context.active_object
        if not active_object or active_object.mode != 'POSE':
            return None
            
        active_bone_name = context.active_pose_bone.name if context.active_pose_bone else None
        selected_bone_names = tuple(sorted([b.name for b in context.selected_pose_bones])) if context.selected_pose_bones else ()
        
        return (active_bone_name, selected_bone_names)


class RTMP_OT_ChangeHandleMode(bpy.types.Operator):
    bl_idname = "rtmp.change_handle_mode"
    bl_label = "Set Handle Type"
    bl_options = {'REGISTER', 'UNDO'}
    
    handle_type: bpy.props.StringProperty()
    
    def execute(self, context):
        handle_type = self.handle_type
        if not handle_type:
            handle_type = context.window_manager.rtmp_handle_type
        apply_handle_mode(context, handle_type)
        refresh_position_store(context)
        return {'FINISHED'}


class RTMP_OT_ToggleEditMode(bpy.types.Operator):
    bl_idname = "rtmp.toggle_edit_mode"
    bl_label = "Toggle Direct Manipulation"
    bl_description = "Enable/Disable Motion Path Editing"
    
    def execute(self, context):
        global _session
        wm = context.window_manager
        
        if not wm.rtmp_edit_mode_active:
            wm.rtmp_edit_mode_active = True
            bpy.ops.rtmp.path_point_drag('INVOKE_DEFAULT')
            wm.rtmp_auto_refresh_active = True
            bpy.ops.rtmp.path_refresh_daemon('INVOKE_DEFAULT')
            # 注：G/R/S 的接管由 rtmp_edit_mode_active 的 update 回调负责
            #     （见 modal_edit.update_edit_mode_active），此处不必显式调用。
            self.report({'INFO'}, iface_("Enable Direct Path Editing"))
        else:
            wm.rtmp_edit_mode_active = False
            wm.rtmp_auto_refresh_active = False
            # 注：归还 G/R/S 同样由属性回调负责。
            if context.area:
                context.area.tag_redraw()
            self.report({'INFO'}, iface_("Disable Direct Path Editing"))
        
        return {'FINISHED'}


def _speed_drag_mouse_local(context, event):
    """★★★ 速度三角拖拽的鼠标坐标 —— 必须**与 PRESS 时的起点同源**。

    ★ 2026-09-17 修「拖三角时数值立刻打满 + 卡死」（真机日志定位）：

      PRESS 时起点来自 `find_region_under_mouse()`（3D 视图**局部**坐标，实测 600,800）。
      而旧代码的 MOUSEMOVE 用 `event.mouse_region_x/y` —— 它在
      **鼠标不在任何 Blender 区域上时返回 `-1`**！
        实测日志：mouse_region_* = [-1, -1]
        ⇒ dy_raw = -1 - 800 = -801 ⇒ eff = -332 ⇒ **s 立刻打满**
        ⇒ 之后 last_mouse 恒为 (-1,-1) ⇒ dy=0 ⇒ **继续拖也不动（卡死）**

    本函数：
      · 优先 `find_region_under_mouse`（与起点同一来源，最一致）
      · 拿不到就用「绝对坐标 − 按下时记住的 region 偏移」（鼠标拖出视图也连续）
      · 两者都无效 ⇒ 返回 None（**调用方必须跳过本次移动**）
      · **显式拒绝 `-1`** 这类哨兵值 / 区域外的坐标
    """
    # ★ 核心要求只有两条：
    #   ① 拒收 `-1` 哨兵值（**这就是"立刻打满 + 卡死"的真凶**）——
    #      鼠标不在任何 Blender 区域上时，`mouse_region_*` 就是 -1，
    #      而起点是几百的正常值 ⇒ 假位移 ⇒ 打满；之后恒为 -1 ⇒ dy=0 ⇒ 卡死。
    #   ② 与起点尽量同源。
    #
    # 顺序：先用 `event.mouse_region_*`（它就是"当前鼠标位置"，Blender 原生语义），
    #      无效再退回 `find_region_under_mouse`（3D 视图内时两者等价）。
    for _get in (
        lambda: (event.mouse_region_x, event.mouse_region_y),
        lambda: (lambda t: (t[2] if t[2] is not None else (None, None)))(
            find_region_under_mouse(context, event)),
    ):
        try:
            xy = _get()
            if xy and xy[0] is not None and xy[1] is not None:
                if float(xy[0]) > -0.5 and float(xy[1]) > -0.5:
                    return (float(xy[0]), float(xy[1]))
        except Exception:
            continue
    return None


def _is_usable_mouse(xy):
    """鼠标坐标是否可用（拒绝 None 与 `-1` 哨兵值）。"""
    if xy is None:
        return False
    try:
        return float(xy[0]) > -0.5 and float(xy[1]) > -0.5
    except Exception:
        return False


def find_region_under_mouse(context, event):
    mouse_x = event.mouse_x
    mouse_y = event.mouse_y

    windows_to_check = [context.window] if context.window else []
    for win in context.window_manager.windows:
        if win not in windows_to_check:
            windows_to_check.append(win)
            
    for window in windows_to_check:
        screen = window.screen
        if not screen: continue
        
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
                
            if (area.x <= mouse_x < area.x + area.width and
                area.y <= mouse_y < area.y + area.height):
                
                for region in area.regions:
                    if region.type == 'WINDOW':
                        if (region.x <= mouse_x < region.x + region.width and
                            region.y <= mouse_y < region.y + region.height):
                            
                            local_x = mouse_x - region.x
                            local_y = mouse_y - region.y
                            space_data = area.spaces.active
                            return region, space_data, (local_x, local_y), area

    return None, None, None, None


# ---------------------------------------------------------------------------
# 同比例手柄缩放（UNIFORM）—— 用户拍板 2026-09-17
#
# 语义：拖 3D 手柄 ⇒ **手柄变长/变短，而关键帧处的速度不变**
#       （= Graph Editor 里「以各自中心 + S 缩放」的等价物）。
#
# 数学（唯一实现在 `transform_domain.scale_handle_uniform` / `handle_scale_k`）：
#     手柄(3D) = (dv_x, dv_y, dv_z)；关键帧处速度 = |(dv_a / dt_a)|
#     dv、dt 同乘 k ⇒ 速度 = (k·|dv|)/(k·dt) = 原速度 ⇒ 不变 ✓
#
# ⚠️ k 必须用「值分量 3D 模长比」（整体 k），**不是**逐轴的 dv_a新/dv_a旧：
#    逐轴 k_a 在某个轴被拖到过零时会变负 / 除零 ⇒ dt 被钳到极小 ⇒ 速度爆炸
#    ⇒ 手柄「飞走 / 缩成一点锁死」（2026-09-17 实测踩坑，那条路已废弃）。
#    整体 k 对所有轴相同 ⇒ 手柄方向 ∝ dv 不变 ⇒ **始终与路径相切** ✓
# ---------------------------------------------------------------------------

def _is_endpoint_inner_handle(action, obj, frame, side, bone_name=None):
    """判断 (frame, side) 是不是**端点处的内侧手柄**。

    内侧 = 朝曲线内部那一侧（**首帧的 right / 末帧的 left**）——
    用户拖"端点手柄"拖的就是这一侧（外侧朝外、没有曲线，拖它没意义）。

    ⚠️ **不能**用 `td.resolve_target` 的 `span is None` 判断 —— 实测
       f55 的**左手柄**（内侧）返回 `span = 30.0`（有段），
       `span is None` 对应的是**朝外**那一侧，正好相反（2026-09-17 踩坑：
       我第一版就是这么写的，结果修复完全没生效）。
    """
    try:
        frames = sorted({float(k.co[0])
                         for fc in collect_animation_curves(action, obj)
                         if is_position_animation(fc, bone_name)
                         for k in fc.keyframe_points})
        if not frames:
            return False
        f = float(frame)
        e = 1e-4
        if abs(f - frames[0]) < e and side == 'right':
            return True
        if abs(f - frames[-1]) < e and side == 'left':
            return True
        return False
    except Exception:
        return False


def _path_tangent_unit(action, obj, frame, side, bone_name=None):
    """求路径在 `frame` 处的**单位切向**（朝该侧手柄伸出的方向）。

    · side='right' → 朝时间【更晚】的方向（曲线前进方向）
    · side='left'  → 朝时间【更早】的方向（来路）

    用途：**零长手柄拖出时把方向锁到切线**（见 `_apply_one_handle_offset`
    里 `_dir_lock` 的说明）。用户 2026-09-17 实测：零长端点手柄拖出来
    方向 = 纯鼠标方向 ⇒ 与路径不相切、且朝不同方向拖结果完全不同（难复现）。

    ⚠️ 必须用**曲线微分**（`fc.evaluate` 求值后作差），**不能**用"相邻关键帧
       的弦方向" —— 实测弦方向与真实切向差 **17.11°**（用户会看到明显折角）。

    ★★ **自适应步长（2026-09-17 实测踩坑，必须这样写）**：
       端点处曲线常"减速到停"（该侧手柄 dv ≈ 0，例如 AUTO_CLAMPED 的缓出）
       ⇒ 位移 ∝ eps² 量级**极小**。实测 f55：
           eps=0.001 → |位移| 1e-6 ；eps=0.01 → 2e-6   ← **纯浮点噪声**
           eps=0.05  → 9.9e-5 ；eps=0.5  → 9.9e-3 ；eps=1.0 → 3.9e-2
       固定用 0.01 ⇒ 方向**随机**（实测与真值差 19.5°！）；0.05~5.0 之间
       彼此差 < 1°。⇒ 从够**小**的步长开始试，**取第一个位移已脱离噪声的**，
       得到的才是**视觉上的真实走向**（实测与曲线采样 f52→f55 差 < 0.5°）。

    任何异常 / 取不到几何 ⇒ 返回 None（调用方退回原行为，不崩）。
    """
    try:
        curves = {}
        for fc in collect_animation_curves(action, obj):
            if is_position_animation(fc, bone_name):
                curves[fc.array_index] = fc
        if len(curves) < 3:
            return None
        f = float(frame)
        sign = (1.0 if side == 'right' else -1.0)

        def _delta(eps):
            v = []
            for ax in (0, 1, 2):
                fc = curves.get(ax)
                if fc is None:
                    return None, 0.0
                v.append(float(fc.evaluate(f + sign * eps))
                         - float(fc.evaluate(f)))
            n = math.sqrt(sum(x * x for x in v))
            return v, n

        # 用最大步长估"宏观尺度" ⇒ 定"脱离噪声"的阈值（相对判据，适配任意场景尺度）
        _vmax, _nmax = _delta(5.0)
        if _vmax is None:
            return None
        tol = max(_nmax * 1e-3, 1e-9)

        for eps in (0.05, 0.1, 0.5, 1.0, 2.0, 5.0):
            v, n = _delta(eps)
            if v is None:
                return None
            if n >= tol:
                return [x / n for x in v]
        return None
    except Exception:
        return None


def _mouse_world_ref(region, rv3d, local_mouse_pos, ref_point):
    """把【鼠标按下位置】投影成 3D 点，作为拖拽的**位移基准**。

    深度参考用 `ref_point`（关键帧 / 手柄末端的位置）⇒ 落在"过 ref_point 且
    垂直于视线"的平面上，与 modal 里
        `new_3d_pos = region_2d_to_location_3d(region, rv3d, 鼠标当前, _session.world_origin)`
    用的是**同一个平面**（因为 world_origin 就在该平面上）。

    ★ 为什么必须用鼠标位置当基准（2026-09-17 用户实测 bug）：
        `total_offset = new_3d_pos - world_origin`
      若 world_origin 取【关键帧位置】，第一次移动时
        `total_offset ≈ 鼠标位置 - 关键帧位置 ≈ 手柄向量`
      而写入是 `手柄 = 基线 + total_offset` ⇒ **手柄跳到 2 倍长度**。
      跳幅 ≈ 手柄长度 ⇒ 端点（0 长度）看不出、越长的柄跳得越狠
      （用户实测最长的 f25 右手柄 |dv|=10.55 最明显）。

      基准换成鼠标位置后：鼠标不动时 `total_offset = 0` ⇒ 按下不跳 ✓
      ⇒ 之后恒等于鼠标位移量 ⇒ **相对拖动、严格跟手**。

    拿不到 region/rv3d（如后台/异常）⇒ 退回 `ref_point`（= 旧行为，安全兜底）。
    """
    try:
        if region is None or rv3d is None or local_mouse_pos is None:
            return ref_point
        return view3d_utils.region_2d_to_location_3d(
            region, rv3d, mathutils.Vector(local_mouse_pos), ref_point)
    except Exception:
        return ref_point


def _uniform_mode(context):
    """偏好：是否启用同比例缩放模式。拿不到偏好时保守返回 False（= 原行为）。"""
    try:
        prefs = get_addon_prefs(context)
        return getattr(prefs, 'handle_scale_mode', 'UNIFORM') == 'UNIFORM'
    except Exception:
        return False


def _uniform_plan(context, action, obj, frame, side, bone_name, factors,
                  total_offset_local_scaled, frame_kf_map):
    """【唯一实现】同比例模式的**预演**（只读，必须在任何写入之前调用）。

    做两件事：
      ① 补齐 `handle_start_values` 基线（多端点拖拽时其他端点可能没预先记录）
      ② 算出整体 k 与各轴的 dv_new

    返回 `(k, k_raw, {ax: dv_new}, span)`；未启用 / 端点段 / 手柄零长 → None。

    ⚠️ 基线一律取 `_session.handle_start_values`（**按下时**的值）。
       若改用"当前值"，每次 MOUSEMOVE 都会在已改过的值上再改一次
       ⇒ 指数增长 ⇒ 手柄飞走（2026-09-17 实测踩过的坑）。
    ⚠️ `span` 用现成的 `td.resolve_target`（别再手写一份段长计算）。
    """
    if not _uniform_mode(context):
        return None
    # ① 补齐基线
    for _ax, _kp in frame_kf_map.items():
        if _session.handle_start_values.get((frame, _ax)) is None:
            _h = _kp.handle_left if side == 'left' else _kp.handle_right
            _session.handle_start_values[(frame, _ax)] = (float(_h[0]), float(_h[1]))
    # ② span（端点段返回 None ⇒ 不做时间缩放）
    try:
        _kf2, span = td.resolve_target(action, obj, frame, side, bone_name)
    except Exception:
        span = None
    if not span:
        return None
    dv_base, dv_new, dt_base = {}, {}, {}
    for ax, kp in frame_kf_map.items():
        init = _session.handle_start_values.get((frame, ax))
        if init is None:
            continue
        fac = (factors.get(ax, 1.0) if factors else 1.0) or 1.0
        dv0 = float(init[1]) - float(kp.co[1])
        dv_base[ax] = dv0
        dv_new[ax] = dv0 + float(total_offset_local_scaled[ax]) / float(fac)
        dt_base[ax] = float(init[0]) - float(kp.co[0])
    if not dv_base:
        return None
    axes = sorted(dv_base)
    ks = xf.handle_scale_k([dv_base[a] for a in axes],
                           [dv_new[a] for a in axes],
                           [dt_base[a] for a in axes], span)
    if ks is None:
        return None
    return (ks[0], ks[1], dv_new, span)


def _write_uniform(keyframe, side, init, dv_new_a, k, k_raw, span):
    """【唯一实现】把同比例缩放写进**一个轴**。返回 (dv, dt)。"""
    dv_b = float(init[1]) - float(keyframe.co[1])
    dt_b = float(init[0]) - float(keyframe.co[0])
    return xf.scale_handle_uniform(keyframe, side, dv_b, dt_b,
                                   dv_new_a, k, k_raw, span)


class RTMP_OT_PathPointDrag(bpy.types.Operator):
    bl_idname = "rtmp.path_point_drag"
    bl_label = "Direct Motion Path Manipulation"
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    _mouse_pos = None
    _is_active = False
    _redraw_count = 0
    _last_frame = None
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._timer = None
        self._mouse_pos = None
        self._is_active = False
        self._redraw_count = 0
        self._last_frame = None
        self._last_draw_time = 0.0
        # ★★ 2026-09-18（性能修复）：**速度手柄拖拽**的节流时钟。
        #
        #   为什么要单独一个（不能复用 `_last_draw_time`）：
        #     速度拖拽分支在帧率限制**之前**就 `return` 了（用户 2026-09-18
        #     报"大幅高频拖动手柄 GPU 利用率快速升高"）⇒
        #        鼠标动多快就重绘多少次（高刷鼠标几百 Hz），
        #        每次都要重画一整屏（实测 4K 视口 = 540 万像素，3.87ms/次）。
        #     ⇒ 这里给它**同样的节流**，但用独立时钟（避免与路径点拖拽互相干扰）。
        self._last_speed_draw_time = 0.0
    
    def prepare_handles_for_edit(self, frame_kf_map):
        # ★★ P1 修复（2026-09-16）：改成【返回原类型】，让调用方在结束时写回。
        #
        # 旧实现只改不存 → 调用方读 `handle_left_type` 当"原类型"时读到的已是 FREE
        # → 结束时"恢复"成 FREE → **VECTOR 类型被永久破坏**（实测确认）。
        #
        # 返回 {array_index: (hl_type, hr_type)}，供调用方恢复。
        #
        # ⚠️ 现状（2026-09-16 code review 记录）：
        #    1. 下面那个 `两侧都是 VECTOR → 都转 FREE` 的分支**已不可达** ——
        #       两个调用点（1147/1317 附近）都在 `xf.prepare_handles_for_drag`
        #       **之后**，那时 VECTOR 早已被按原生语义转成 FREE。
        #       保留它只作防御（万一将来有路径不先调 prepare_handles_for_drag）。
        #    2. 因此它返回的"原类型"其实是**转换后**的类型；调用方那两处
        #       "写回原类型"等于把同一个值写回去（no-op）。
        #    3. 类型接管的**唯一入口**是 `xf.prepare_handles_for_drag`；
        #       本函数今后只当"读取当前类型"用，不要再往这里加类型规则。
        prev = {}
        for array_index, keyframe in frame_kf_map.items():
            prev[array_index] = (str(keyframe.handle_left_type),
                                 str(keyframe.handle_right_type))
            if (keyframe.handle_left_type == 'VECTOR' and 
                keyframe.handle_right_type == 'VECTOR'):
                
                original_left = keyframe.handle_left.copy()
                original_right = keyframe.handle_right.copy()
                
                keyframe.handle_left_type = 'FREE'
                keyframe.handle_right_type = 'FREE'
                
                keyframe.handle_left = original_left
                keyframe.handle_right = original_right
        return prev
    
    def modal(self, context, event):
        global _session

        wm = context.window_manager
        if not wm.rtmp_edit_mode_active or not self._is_active:
            return self.cancel(context)
        
        if event.type == 'MOUSEMOVE':
            # ⚠️⚠️ 2026-09-17 修「拖三角时数值立刻打满 + 卡死」（真机日志定位）：
            #   旧代码用 `event.mouse_region_x/y` 当鼠标坐标喂给拖拽。
            #   但**鼠标不在任何 Blender 区域上时，这两个字段是 `-1`**！
            #   实测日志（用户真机复现）：
            #       PRESS 起点 last_mouse = [600, 800]（3D 视图局部坐标）
            #       第一次 MOUSEMOVE 的 mouse_region_* = [-1, -1]
            #       ⇒ dy_raw = -1 - 800 = **-801** ⇒ eff = -332
            #       ⇒ **s 立刻顶到上限（打满）**
            #       之后 last_mouse 恒为 (-1,-1) ⇒ dy=0 ⇒ **继续拖也不动（卡死）**
            #   （"动过 GE 手柄后更容易出现"：那时 s 已在边界附近，一点假位移就撞满。）
            #   ⇒ 坐标必须**与起点同源**（都用 3D 视图局部坐标），且拿到 `-1`
            #     这类哨兵值/B 区域外的坐标时**跳过本次**，宁可不动也不跳变。
            _loc = _speed_drag_mouse_local(context, event)
            if _loc is not None:
                self._mouse_pos = _loc

            # ---- 速度手柄拖拽（优先于路径点拖拽：这是在调疏密）----
            if _session.speed_drag_active:
                # 相对拖拽：三角固定，用鼠标位移增量驱动（不依赖三角屏幕坐标）
                # ③ 拖拽中按住 Shift = 精度模式（×0.1，增量法不跳变）
                # ★★★ 2026-09-18（性能修复）：**帧率限制** —— 本分支此前绕过了它。
                #
                #   用户报"大幅高频拖动手柄时 GPU 利用率快速升高"。实测根因：
                #     这个分支在帧率限制**之前**就 `return` 了（旧代码这里没节流）
                #     ⇒ 鼠标动多快就重写 + 重绘多少次。高刷鼠标 125~1000Hz，
                #       而每次都要重画一整屏（实测 4K 视口 540 万像素、3.87ms/次）
                #     ⇒ GPU 被"逼着反复重画一整屏"。
                #
                #   ⚠️⚠️ **节流之所以安全（务必看懂，否则会引入跳变）**：
                #     `_apply_speed_from_drag` 是**增量法** —— 位移 = 本次鼠标 −
                #     上次鼠标，且**只有真正写入时才把 last_mouse 更新成本次鼠标**。
                #     ⇒ 被跳过的事件**不丢位移**：下一次事件算出的 delta 会自动
                #       把跳过那段的位移**一并带上**（累积）。
                #     ⇒ 松手时**必须强制补最后一次**（见 RELEASE 分支），
                #       否则最后 ≤1 帧（默认 16ms）的位移会丢 —— 那就是跳变
                #       （用户的零容忍底线）。
                #
                #   ⚠️ Shift 精度模式走同一节流：它作用在**增量**上
                #      （函数内 `dy_raw * scale`），跳过的增量下次照样补 ⇒ 手感不变。
                _sp_target = 1.0 / max(1, addon_pref('max_interaction_fps', 60))
                _sp_now = time.time()
                if _loc is not None:
                    # ★ 无论是否节流，都记住"最新鼠标位置" —— 松手时要用它
                    #   补上被跳过的最后一段位移（见 `flush_pending_speed_drag`）。
                    _session.speed_drag_pending_mouse = _loc
                if (_sp_now - self._last_speed_draw_time) < _sp_target:
                    # 本帧跳过：**不更新 last_mouse**（位移留给下次一并计入）
                    return {'PASS_THROUGH'}
                self._last_speed_draw_time = _sp_now
                _session.speed_drag_precision = bool(getattr(event, "shift", False))
                area0 = None
                region0, space0, local0, area0 = find_region_under_mouse(context, event)
                obj0 = _get_drag_obj(context)
                # ★ 只有拿到有效坐标才更新（否则保持上一次，避免 -1 造成的假位移）
                if _loc is not None:
                    _apply_speed_from_drag(context, obj0, _loc)
                if region0 and space0:
                    _update_speed_hover(context, obj0, region0, space0.region_3d, local0)
                a = area0 if area0 else context.area
                if a and a.type == 'VIEW_3D':
                    a.tag_redraw()
                return {'PASS_THROUGH'}

            target_interval = 1.0 / max(1, addon_pref('max_interaction_fps', 60))
            current_time = time.time()
            if (current_time - self._last_draw_time) < target_interval:
                return {'PASS_THROUGH'}
            self._last_draw_time = current_time
            
            region, space_data, local_mouse_pos, target_area = find_region_under_mouse(context, event)
            if not region or not space_data:
                return {'PASS_THROUGH'}

            rv3d = space_data.region_3d

            if _session.drag_in_progress:
                mouse_coord = mathutils.Vector(local_mouse_pos)
                new_3d_pos = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse_coord, _session.world_origin)

                if _session.active_handle_direction is None:
                    offset = new_3d_pos - _session.world_origin
                    self.apply_point_offset(context, offset)
                    _session.world_origin = new_3d_pos
                else:
                    total_offset = new_3d_pos - _session.world_origin
                    self.apply_handle_offset(context, total_offset, _session.active_handle_direction)

                try:
                    refresh_position_store(context)
                except Exception:
                    pass

                area_to_redraw = target_area if target_area else context.area
                if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                    area_to_redraw.tag_redraw()
                    
            elif _session.handle_edit_in_progress and _session.active_handle_index is not None:
                mouse_coord = mathutils.Vector(local_mouse_pos)
                
                new_3d_pos = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse_coord, _session.world_origin)
                total_offset = new_3d_pos - _session.world_origin
                
                if _session.active_handle_info:
                    handle_point = _session.active_handle_info
                    self.apply_handle_point_offset(context, total_offset, handle_point)
                elif _session.active_handle_index is not None and _session.active_handle_index < len(_session.handle_control_points):
                    handle_point = _session.handle_control_points[_session.active_handle_index]
                    self.apply_handle_point_offset(context, total_offset, handle_point)
                
                try:
                    refresh_position_store(context)
                except Exception:
                    pass

                area_to_redraw = target_area if target_area else context.area
                if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                    area_to_redraw.tag_redraw()

            else:
                # 空闲移动：刷新速度手柄的【悬停】显示（平时三角不出现）
                if not _session.drag_in_progress and not _session.handle_edit_in_progress:
                    obj_h = _get_drag_obj(context)
                    _update_speed_hover(context, obj_h, region, rv3d, local_mouse_pos)
                    area_to_redraw = target_area if target_area else context.area
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()

            return {'PASS_THROUGH'}
        
        elif event.type == 'RIGHTMOUSE':
            if event.value == 'PRESS':
                region, space_data, local_mouse_pos, target_area = find_region_under_mouse(context, event)
                if not region or not space_data:
                    return {'PASS_THROUGH'}
                rv3d = space_data.region_3d

                hit_point, hit_frame, hit_bone = self.locate_point_under_cursor(context, event, region, rv3d, local_mouse_pos)
                if hit_frame is not None:
                    _session.active_path_point = hit_point
                    _session.active_frame_number = hit_frame
                    
                    if context.mode == 'POSE':
                        _session.active_bone_identifier = hit_bone.name if hit_bone else None
                    else:
                        _session.active_bone_identifier = None
                    
                    obj = _get_drag_obj(context)
                    if obj and obj.animation_data and obj.animation_data.action:
                        action = obj.animation_data.action
                        bone_name = _session.active_bone_identifier if context.mode == 'POSE' else None
                        
                        hit_keyframe_already_selected = is_keyframe_selected(action, bone_name, hit_frame, obj)
                        
                        if not hit_keyframe_already_selected:
                            for fc in collect_animation_curves(action, obj):
                                for kp in fc.keyframe_points:
                                    kp.select_control_point = False
                        
                        for fc in collect_animation_curves(action, obj):
                            if is_position_animation(fc, bone_name):
                                for kp in fc.keyframe_points:
                                    if abs(kp.co[0] - hit_frame) < FRAME_EPS:
                                        kp.select_control_point = True
                                        break
                    
                    area_to_redraw = target_area if target_area else context.area
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()
                    
                    bpy.ops.wm.call_menu(name="RTMP_MT_context_menu")
                    return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        elif event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                region, space_data, local_mouse_pos, target_area = find_region_under_mouse(context, event)
                if not region or not space_data:
                    return {'PASS_THROUGH'}
                rv3d = space_data.region_3d
                area_to_redraw = target_area if target_area else context.area

                # ---- ① 速度三角命中（优先级最高）----
                obj_s = _get_drag_obj(context)
                s_handles = _update_speed_hover(context, obj_s, region, rv3d, local_mouse_pos)
                hit_tri = _triangle_under_cursor(s_handles, local_mouse_pos)
                if hit_tri is not None:
                    # ★★ 2026-09-18（用户需求）：**双击三角 ⇒ 切换「一体 / 分离」**
                    #    （v1.3.2 的双击是"复制对侧值"；现在升级为切换锁定，
                    #      复制保留在"分离 → 锁回一体"那一步 —— 见 `toggle_frame_lock`）
                    #    必须放在"选中 + 启动拖拽"**之前** —— 双击要优先于单选的拖拽启动。
                    #    （判定/执行都抽在 `try_toggle_tri_lock_click` 里，可 headless 测试。）
                    _consumed, _msg = try_toggle_tri_lock_click(
                        context, obj_s, s_handles, local_mouse_pos, region, rv3d)
                    if _consumed:
                        if _msg:
                            self.report({'INFO'}, _msg)
                        # 双击是"一次性动作"，不要顺势进入拖拽
                        _session.speed_drag_active = False
                        _session.speed_drag_pending_mouse = None
                        if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                            area_to_redraw.tag_redraw()
                        return {'RUNNING_MODAL'}

                    # ★ 用户 2026-09-16：Shift+点击 = 多选（累加/取消）
                    # ★★ 2026-09-18（用户需求）：**一体**状态下单击任一个三角
                    #   ⇒ 两个一起选中；分离态只选单边。逻辑抽在模块级函数里
                    #   （`apply_speed_click_selection`）⇒ headless 能测到真入口。
                    _hit_frame = hit_tri['frame']
                    _locked_here, _tris_here = apply_speed_click_selection(
                        obj_s, s_handles, hit_tri, shift=bool(event.shift))
                    _session.speed_drag_active = True
                    # ★ 2026-09-17：超范围的 s 规范化挪到【首次真正拖动】时做
                    #   （见 `_apply_speed_from_drag`）—— 这样"纯点击"不改动画。
                    _session.speed_drag_normalized = False
                    _session.speed_drag_precision = False
                    # 每个选中的三角各自记录按下时的 d（多选一起滑移用）
                    # ★★ 2026-09-19：起点一律用 **unclamped** d（保持可逆）。
                    #   ① `h['d']` 是钳制版（`s_to_d`）—— 当 s 越过
                    #      [S_EPS, S_HARD_MAX]（用户在 GE 里拖过手柄）时会丢信息
                    #      ⇒ "一动就打满 / 拖不动"（2026-09-17 用户实测报告）。
                    #   ② 必须是**按下时的固定起点**：`eff` 是【累积】位移，
                    #      若每帧现读"当前值"再加累积位移 ⇒ **双重累加** ⇒ 拖久了
                    #      指数漂移（用户零容忍的"跳变"）。实测抓到一次。
                    _session.speed_drag_origins = {
                        (h['frame'], h['tri']): td.s_to_d_unclamped(h.get('s'))
                        for h in s_handles
                        if _session.is_speed_handle_selected(h['frame'], h['tri'])}
                    _session.speed_drag_origin_d = td.s_to_d_unclamped(hit_tri.get('s'))

                    # ★★ 2026-09-18（用户拍板乙方案）：**一体拖动 = 一个旋钮**
                    #   记录"共用的 s 基准"；两侧 span 不同 ⇒ 必须用数据层的 s，
                    #   否则同一个像素位移会让两边速度分道扬镳（见 `td.group_drag_s`）。
                    #   基准取**被点击那个三角**的 s（用户抓哪个就以哪个为准）。
                    if (not event.shift and _locked_here
                            and _session.is_locked_pair_selected(_hit_frame)):
                        _s0 = hit_tri.get('s')
                        _session.speed_drag_group_origin_s = (
                            float(_s0) if _s0 is not None else None)
                        _session.speed_drag_locked_frame = _hit_frame
                    else:
                        _session.speed_drag_group_origin_s = None
                        _session.speed_drag_locked_frame = None
                    _session.speed_drag_origin_mouse = local_mouse_pos
                    # ★★ 2026-09-17：记下**按下时 3D 视图 region 的偏移**，
                    #   供 `_speed_drag_mouse_local` 在鼠标拖出视图时换算坐标
                    #   （保证拖拽全程坐标连续、不跳变）。
                    _session.speed_drag_region = (float(region.x), float(region.y))
                    # 增量累积的重置（精度模式用它算"此后"的位移）
                    _session.speed_drag_effective_px = 0.0
                    _session.speed_drag_last_mouse = local_mouse_pos
                    _session.speed_drag_pending_mouse = local_mouse_pos
                    # ★ 2026-09-18：节流时钟清零 —— 让**第一次移动立刻生效**
                    #   （否则要在原地等满一帧，按下瞬间会感觉"迟钝"）。
                    self._last_speed_draw_time = 0.0
                    # 三角拖拽期间，不要同时拖路径点
                    _session.drag_in_progress = False
                    _session.handle_edit_in_progress = False
                    _session.active_path_point = None
                    _session.active_frame_number = None
                    _session.active_handle_index = None
                    _session.active_handle_info = None
                    _update_speed_hover(context, obj_s, region, rv3d, local_mouse_pos)
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()
                    return {'RUNNING_MODAL'}

                # 点空白处：清掉三角选中态
                if hit_tri is None and _session.selected_speed_handles:
                    _session.clear_speed_handle()

                if not event.shift:
                    _session.active_handle_index = None
                    _session.active_handle_info = None
                    _session.active_path_point = None
                    _session.active_frame_number = None
                
                handle_index, handle_point = get_handle_at_cursor(context, event, region, rv3d, local_mouse_pos)
                if handle_index is not None:
                    # ★★ 用户 2026-09-16：端点可【单独选中】。
                    #     原生曲线编辑里，控制点与手柄是各自独立的可变换对象；
                    #     所以点端点时【不再】顺带选中关键帧点，
                    #     否则 RGS 会作用到关键帧点而不是端点。
                    hf = handle_point.get('frame')
                    hs = handle_point.get('side')
                    if hf is not None and hs is not None:
                        if event.shift:
                            _session.toggle_endpoint(hf, hs)
                        else:
                            _session.clear_endpoints()
                            _session.toggle_endpoint(hf, hs)
                        # 端点选中 → 清掉关键帧点的选中（两者互斥，与原生一致）
                        obj_e = _get_drag_obj(context)
                        if obj_e and obj_e.animation_data and obj_e.animation_data.action:
                            for fc in collect_animation_curves(obj_e.animation_data.action, obj_e):
                                for kp in fc.keyframe_points:
                                    kp.select_control_point = False
                        _session.active_frame_number = None
                        _session.active_path_point = None
                    _session.active_handle_index = handle_index
                    _session.active_handle_info = handle_point
                    _session.handle_edit_in_progress = True
                    # ★★ 位移基准 = 【鼠标按下位置的 3D 投影】，不是手柄末端。
                    #    原来写的是 `handle_point['position']`（手柄末端）：虽然端点为
                    #    0 长度时它≈关键帧、看不出问题，但语义上仍是"绝对参考"——
                    #    鼠标没按在末端正中就会让第一次移动带上一个非零位移。
                    #    统一成鼠标基准后，`total_offset` 恒等于**鼠标位移量** ⇒ 严格跟手。
                    _session.world_origin = _mouse_world_ref(
                        region, rv3d, local_mouse_pos, handle_point['position'])
                    _session.item_initial_pos = handle_point['position']
                    _session.mouse_origin = local_mouse_pos
                    
                    hp_obj_name = handle_point.get('obj_name')
                    _session.drag_target_object = hp_obj_name or None
                    
                    self.record_handle_baseline(context, handle_point['frame'], handle_point.get('bone_name'), handle_point['side'])
                    
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()
                    return {'RUNNING_MODAL'}

                # 没点中端点 → 清掉端点选中（Shift 时保留，便于累加）
                if not event.shift:
                    _session.clear_endpoints()

                hit_side, hit_handle_pos, hit_frame, point_3d, hit_bone = self.locate_handle_under_cursor(context, event, region, rv3d, local_mouse_pos)
                if hit_frame is not None:
                    _session.active_path_point = point_3d
                    _session.active_frame_number = hit_frame
                    _session.active_handle_direction = hit_side
                    # ★★★ 2026-09-17（用户实测："拖出结尾帧手柄后，再拖上一个关键帧的
                    #     右手柄会跳变，其他手柄没这情况"）——**真因在这里**。
                    #
                    #   `point_3d` 是【关键帧位置】（已核实 cached_positions 与之逐位一致），
                    #   而 modal 里 `total_offset = new_3d_pos - world_origin`。
                    #   于是第一次移动时：
                    #       total_offset ≈ (鼠标位置 - 关键帧位置) ≈ 手柄向量
                    #   而写入是 `手柄 = 基线 + total_offset`
                    #       ⇒ 手柄 ≈ 2 × 手柄向量  ⇒ **跳到 2 倍长度**
                    #
                    #   ⇒ **跳幅 ≈ 手柄长度**：端点（0 长度）看不出；越长的柄跳得越狠
                    #     （用户实测最长的 f25 右手柄 |dv|=10.55 跳得最明显）。
                    #
                    #   修法：基准取【鼠标按下位置的 3D 投影】（深度用关键帧位置所在的
                    #   平面 ⇒ 与后续 `region_2d_to_location_3d(..., world_origin)` 同平面）。
                    #   ⇒ `total_offset` 恒等于鼠标位移量 ⇒ 相对拖动、永不跳。
                    _session.world_origin = _mouse_world_ref(
                        region, rv3d, local_mouse_pos, point_3d)
                    _session.item_initial_pos = hit_handle_pos
                    _session.mouse_origin = local_mouse_pos
                    
                    self.record_handle_baseline(context, hit_frame, hit_bone.name if hit_bone else None, hit_side)
                    
                    if context.mode == 'POSE':
                        _session.active_bone_identifier = hit_bone.name if hit_bone else None
                    else:
                        _session.active_bone_identifier = None
                    
                    obj = _get_drag_obj(context)
                    if obj and obj.animation_data and obj.animation_data.action:
                        action = obj.animation_data.action
                        bone_name = _session.active_bone_identifier if context.mode == 'POSE' else None
                        
                        for fc in collect_animation_curves(action, obj):
                            if is_position_animation(fc, bone_name):
                                for kp in fc.keyframe_points:
                                    if abs(kp.co[0] - hit_frame) < FRAME_EPS:
                                        kp.select_control_point = True
                                        break
                    
                    _session.drag_in_progress = True
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()
                    return {'RUNNING_MODAL'}
                
                hit_point, hit_frame, hit_bone = self.locate_point_under_cursor(context, event, region, rv3d, local_mouse_pos)
                if hit_frame is not None:
                    _session.active_path_point = hit_point
                    _session.active_frame_number = hit_frame
                    _session.active_handle_direction = None  
                    _session.world_origin = hit_point
                    _session.item_initial_pos = hit_point
                    _session.mouse_origin = local_mouse_pos
                    
                    if context.mode == 'POSE':
                        _session.active_bone_identifier = hit_bone.name if hit_bone else None
                    else:
                        _session.active_bone_identifier = None
                    
                    obj = _get_drag_obj(context)
                    if obj and obj.animation_data and obj.animation_data.action:
                        action = obj.animation_data.action
                        bone_name = _session.active_bone_identifier if context.mode == 'POSE' else None
                        
                        hit_keyframe_already_selected = is_keyframe_selected(action, bone_name, hit_frame, obj)
                        
                        if not hit_keyframe_already_selected and not event.shift and not event.ctrl:
                            for fc in collect_animation_curves(action, obj):
                                for kp in fc.keyframe_points:
                                    kp.select_control_point = False
                        
                        if event.ctrl:
                            kf_frame_set = []
                            for fc in collect_animation_curves(action, obj):
                                if is_position_animation(fc, bone_name):
                                    for kp in fc.keyframe_points:
                                        if kp.select_control_point:
                                            kf_frame_set.append(kp.co[0])
                            kf_frame_set.append(hit_frame)
                            if len(kf_frame_set) >= 2:
                                min_f = min(kf_frame_set)
                                max_f = max(kf_frame_set)
                                for fc in collect_animation_curves(action, obj):
                                    if is_position_animation(fc, bone_name):
                                        for kp in fc.keyframe_points:
                                            if min_f <= kp.co[0] <= max_f:
                                                kp.select_control_point = True
                        else:
                            # ⚠️ 吸附到【最近的关键帧】：
                            #    路径点有 40 个（每帧一个），关键帧可能只有 4 个。
                            #    原来只在 hit_frame 恰好等于关键帧帧号时才选中
                            #    → 点其它采样点"什么都没选中" → 按 R/S 无反应（实测确认）。
                            pick_f = _nearest_keyframe_frame(action, obj, hit_frame, bone_name)
                            if pick_f is None:
                                pick_f = hit_frame
                            for fc in collect_animation_curves(action, obj):
                                if is_position_animation(fc, bone_name):
                                    for kp in fc.keyframe_points:
                                        if abs(kp.co[0] - pick_f) < FRAME_EPS:
                                            kp.select_control_point = True
                                            break
                            _session.active_frame_number = pick_f
                    
                    _session.drag_in_progress = True
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()
                    return {'RUNNING_MODAL'}
                
                if context.mode == 'POSE':
                    obj = context.active_object
                    if obj and obj.animation_data and obj.animation_data.action:
                        action = obj.animation_data.action
                        obj_cache = _session.cached_positions.get(obj.name, {})
                        for bone_name in obj_cache.keys():
                            for fc in collect_animation_curves(action, obj):
                                if is_position_animation(fc, bone_name):
                                    for kp in fc.keyframe_points:
                                        kp.select_control_point = False
                else:
                    for obj_name in _session.cached_positions.keys():
                        obj = bpy.data.objects.get(obj_name)
                        if obj and obj.animation_data and obj.animation_data.action:
                            action = obj.animation_data.action
                            for fc in collect_animation_curves(action, obj):
                                for kp in fc.keyframe_points:
                                    kp.select_control_point = False
                
                if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                    area_to_redraw.tag_redraw()
                    
            elif event.value == 'RELEASE':
                # ---- 速度三角拖拽结束：提交，但【保留选中】（可继续拖 / 按 J 进模态）----
                if _session.speed_drag_active:
                    # ★★★ 2026-09-18（性能修复配套）：**松手前补上被节流跳过的
                    #   最后一段位移** —— 否则最后 ≤1 帧的位移会丢（= 跳变）。
                    #   必须在 `speed_drag_active = False` **之前**做，
                    #   因为补写函数靠这个标志判断"拖拽还在进行"。
                    _flushed = flush_pending_speed_drag(context, _get_drag_obj(context))
                    bpy.ops.ed.undo_push(message=iface_("Adjust Motion Path Speed"))
                    _session.speed_drag_active = False
                    _session.speed_drag_pending_mouse = None
                    try:
                        refresh_position_store(context)
                    except Exception:
                        pass
                    _, _, _, rel_area = find_region_under_mouse(context, event)
                    a = rel_area if rel_area else context.area
                    if a and a.type == 'VIEW_3D':
                        a.tag_redraw()
                    return {'RUNNING_MODAL'}

                if _session.drag_in_progress:
                    bpy.ops.ed.undo_push(message=iface_("Move Motion Path Points"))
                    _session.drag_in_progress = False
                    _session.active_handle_direction = None
                    _session.item_initial_pos = None
                    _session.drag_target_object = None
                    # ⚠️ 这里【不再】清 active_path_point / active_frame_number：
                    #    用户要求路径点有"选中状态" —— 松开鼠标后仍保持选中，
                    #    之后可以按 G/J 等进入模态继续操作。
                    
                    try:
                        refresh_position_store(context)
                    except Exception:
                        pass
                    
                    _, _, _, release_area = find_region_under_mouse(context, event)
                    area_to_redraw = release_area if release_area else context.area
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()
                    return {'RUNNING_MODAL'}
                elif _session.handle_edit_in_progress:
                    bpy.ops.ed.undo_push(message=iface_("Move Motion Path Handle"))
                    _session.handle_edit_in_progress = False
                    # ⚠️ 这里【不再】清 active_handle_index：
                    #    用户要求手柄端点有"选中状态" —— 松开鼠标后保持选中，
                    #    之后可以继续拖 / 进入模态操作。
                    #    （原来清了它，导致高亮条件 handle_edit_in_progress 变 False，
                    #     选中态立即消失，正是用户报告的"松开就取消选中"。）
                    _session.item_initial_pos = None
                    _session.drag_target_object = None
                    
                    try:
                        refresh_position_store(context)
                    except Exception:
                        pass
                    
                    _, _, _, release_area = find_region_under_mouse(context, event)
                    area_to_redraw = release_area if release_area else context.area
                    if area_to_redraw and area_to_redraw.type == 'VIEW_3D':
                        area_to_redraw.tag_redraw()
                    return {'RUNNING_MODAL'}
        
        elif event.type == 'BACK_SPACE' and event.value == 'PRESS':
            # ★ 用户 2026-09-16：光标悬停在速度三角上时按 Backspace = 恢复该三角的默认速度。
            #   逻辑在 `try_reset_hovered_speed`（抽出来是为了可 headless 测试）。
            if try_reset_hovered_speed(context, event):
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        elif event.type == 'ESC':
            return {'PASS_THROUGH'}
        
        elif event.type == 'TIMER':
            if context.area and context.area.type == 'VIEW_3D':
                context.area.tag_redraw()
            return {'PASS_THROUGH'}
        
        return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        # context.area 在非区域上下文（timer 回调、后台运行、全局脚本）中为 None，
        # 直接访问 .type 会抛 AttributeError。与 cancel()/modal() 的写法保持一致。
        if context.area and context.area.type == 'VIEW_3D':
            refresh_position_store(context)
            self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
            context.window_manager.modal_handler_add(self)
            self._is_active = True
            attach_render_callback()
            # 覆盖层（速度手柄三角 + 轴约束线）；平时不显示任何手柄
            _session.clear_speed_handle()
            # 双击链也要清（否则上次会话残留的"上次点击"可能凑成一次假双击）
            clear_speed_click_chain()
            if _ov is not None:
                o = _ov.get_overlay()
                o.start(session=None)
                o.set_handles([], None, dragging=False)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, iface_("View3D not found, cannot run operator"))
            return {'CANCELLED'}
    
    def cancel(self, context):
        global _session
        
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        
        _session.reset()
        self._is_active = False
        detach_render_callback()
        # 撤掉覆盖层 draw handler（否则泄漏）
        if _ov is not None:
            _ov.get_overlay().stop()
        
        if context.area:
            context.area.tag_redraw()
        
        return {'CANCELLED'}
    
    def apply_point_offset(self, context, offset):
        if not all(math.isfinite(c) and abs(c) < SAFE_LIMIT for c in offset):
            return

        obj = _get_drag_obj(context)
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        action = obj.animation_data.action
        bone_name = _session.active_bone_identifier if (obj and obj.mode == 'POSE') else None
        bone = (obj.pose.bones.get(bone_name) if (bone_name and obj.mode == 'POSE' and obj.pose) else None)
        
        parent_matrix = resolve_parent_transform(obj, bone)
        parent_rot_inv = parent_matrix.to_3x3().inverted()
        
        local_kf_delta = parent_rot_inv @ offset
        
        kf_frame_set = set()
        for fcurve in collect_animation_curves(action, obj):
            if 'location' not in fcurve.data_path:
                continue
            if bone_name and not is_position_animation(fcurve, bone_name):
                continue
            for kp in fcurve.keyframe_points:
                if kp.select_control_point:
                    kf_frame_set.add(int(kp.co[0]))
        
        for frame in kf_frame_set:
            for fcurve in collect_animation_curves(action, obj):
                if 'location' not in fcurve.data_path:
                    continue
                if bone_name and not is_position_animation(fcurve, bone_name):
                    continue
                
                axis = fcurve.array_index
                for kp in fcurve.keyframe_points:
                    if abs(kp.co[0] - frame) < FRAME_EPS:
                        kp.co[1] += local_kf_delta[axis]
                        kp.handle_left[1] += local_kf_delta[axis]
                        kp.handle_right[1] += local_kf_delta[axis]
                        break
        
        for fcurve in collect_animation_curves(action, obj):
            if 'location' in fcurve.data_path and (not bone_name or is_position_animation(fcurve, bone_name)):
                fcurve.update()
    
    def apply_handle_offset(self, context, total_offset_world, side):
        if not all(math.isfinite(c) and abs(c) < SAFE_LIMIT for c in total_offset_world):
            return

        obj = _get_drag_obj(context)
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        action = obj.animation_data.action
        frame = _session.active_frame_number
        global_scale = context.window_manager.rtmp_handle_scale
        bone_name = _session.active_bone_identifier if (obj and obj.mode == 'POSE') else None
        bone = (obj.pose.bones.get(bone_name) if (bone_name and obj.mode == 'POSE' and obj.pose) else None)
        
        parent_matrix = resolve_parent_transform(obj, bone)
        rotation_matrix = parent_matrix.to_3x3()
        
        total_offset_local = rotation_matrix.inverted() @ total_offset_world
        total_offset_local_scaled = total_offset_local / global_scale

        # ★ 多端点一起拖拽（用户 2026-09-16）
        #   之前只处理 `active_frame_number` 那一个端点；
        #   现在把同一个位移应用到【所有选中的端点】。
        eps_sel = list(getattr(_session, "selected_handle_endpoints", None) or [])
        targets = [(f, s) for (f, s) in eps_sel] if eps_sel else []
        if not targets and _session.active_frame_number is not None:
            targets = [(_session.active_frame_number,
                        _session.active_handle_direction or 'right')]

        for (tf, tside) in targets:
            self._apply_one_handle_offset(
                obj, action, tf, tside, total_offset_local_scaled,
                global_scale, bone_name, rotation_matrix, context=context)
        return

    def _apply_one_handle_offset(self, obj, action, frame, side,
                                 total_offset_local_scaled, global_scale,
                                 bone_name, rotation_matrix, context=None):
        """把位移应用到一个端点（内部实现，供多端点循环调用）。"""
        # ★★ 按 Blender【原生语义】接管手柄类型（见 xf.prepare_handles_for_drag）：
        #      AUTO / AUTO_CLAMPED → ALIGNED   （手册："convert to Align when moved"）
        #      VECTOR              → FREE      （手册："convert to Free when moved"）
        #      **两侧都接管** —— 只转被拖侧的话，对侧 AUTO_CLAMPED 会被 Blender
        #      重算：臂长突变（用户看到"跳"）+ 永久不共线（实测 dev 0.832）。
        #    不接管则更糟：默认工程下拖手柄位移 = 0.0000（完全没反应）。
        xf.prepare_handles_for_drag(action, obj, [(frame, side)], bone_name)

        frame_kf_map = {}
        for fcurve in collect_animation_curves(action, obj):
            if not is_position_animation(fcurve, bone_name):
                continue
            for keyframe in fcurve.keyframe_points:
                if abs(keyframe.co[0] - frame) < FRAME_EPS:
                    frame_kf_map[fcurve.array_index] = keyframe
                    break
        
        # ★ P1：用 prepare 返回的【原类型】（它内部会把 VECTOR 临时改成 FREE）
        prev_types = self.prepare_handles_for_edit(frame_kf_map) or {}

        factors_left, factors_right = compute_handle_display_factors(frame_kf_map)

        # ★ 同比例模式：预演（只读）—— 必须在下面任何写入之前
        _uni = _uniform_plan(context, action, obj, frame, side, bone_name,
                             (factors_left if side == 'left' else factors_right),
                             total_offset_local_scaled, frame_kf_map)

        # ★★★ 2026-09-17 用户实测：「拖尾部端点的手柄出来时，手柄不会和路径
        #      相切，也没有和路径有预期交互」——**零长端点手柄拖出 ⇒ 方向锁切线**。
        #
        #   实测（磁盘干净起点、只改拖动方向，该处来路方向 [-0.91,-0.087,0.406]）：
        #       沿 +X 拖 → 手柄 [1,0,0]     与来路夹角 **155.4°**
        #       沿 +Y 拖 → 手柄 [0,1,0]     夹角 **95.0°**
        #       沿 +Z 拖 → 手柄 [0,0,1]     夹角 **66.0°**
        #       斜 X+Y   → 手柄 [.707,.707,0] 夹角 **134.8°**
        #   ⇒ 零长手柄的基线是 0 ⇒ 同比例"无定义" ⇒ 走退化分支（只写鼠标位移）
        #     ⇒ **手柄方向 = 纯鼠标拖动方向**。碰巧沿切线拖时才看着正常
        #     ⇒ 用户"有时对有时不对、难复现"。
        #
        #   修法：方向 = 该点**路径切线**（端点内侧朝曲线内部），长度 = 鼠标位移长度
        #   ⇒ 拖出来**一定相切**，长度仍然跟手。
        #   ⚠️ 只在「端点内侧（span is None）+ 基线零长」时生效：
        #      一旦有了长度就走同比例（正常路径）；中间帧手柄正常不为零长，不受影响。
        _dir_lock = None
        _dir_lock_len = 0.0
        if _uni is None and _is_endpoint_inner_handle(
                action, obj, frame, side, bone_name):
            _base3 = []
            for _ax in (0, 1, 2):
                _kfx = frame_kf_map.get(_ax)
                if _kfx is None:
                    _base3 = []
                    break
                _iv = _session.handle_start_values.get((frame, _ax))
                _bv = (float(_iv[1]) if _iv is not None
                       else float(_kfx.handle_left[1] if side == 'left'
                                  else _kfx.handle_right[1]))
                _base3.append(_bv - float(_kfx.co[1]))
            # 基线短到"同比例无意义"（与 handle_scale_k 的阈值同口径）
            if _base3 and math.sqrt(sum(x * x for x in _base3)) <= xf.UNIFORM_LEN_MIN:
                _dir_lock = _path_tangent_unit(action, obj, frame, side, bone_name)
                if _dir_lock is not None:
                    _dir_lock_len = mathutils.Vector(
                        total_offset_local_scaled).length

        for array_index, keyframe in frame_kf_map.items():
            original_left_type, original_right_type = prev_types.get(
                array_index, ('FREE', 'FREE'))
            
            initial_val = _session.handle_start_values.get((frame, array_index))
            if initial_val is None:
                # ★ 多端点拖拽：其他端点没有预先记录基线 → 惰性记录（此时尚未被改）
                _h = keyframe.handle_left if side == 'left' else keyframe.handle_right
                _session.handle_start_values[(frame, array_index)] = (
                    float(_h[0]), float(_h[1]))
                initial_val = _session.handle_start_values[(frame, array_index)]
            
            initial_pos_2d = mathutils.Vector(initial_val)
            
            if side == 'left':
                factor = factors_left.get(array_index, 1.0)
            else:
                factor = factors_right.get(array_index, 1.0)
            delta_val = total_offset_local_scaled[array_index] / factor

            if _uni is not None:
                # ★★ 同比例模式：值分量 + 时间分量一起按 k 缩放 ⇒ 关键帧处速度不变
                _k, _kraw, _dvmap, _span = _uni
                _write_uniform(keyframe, side, initial_val,
                               _dvmap.get(array_index,
                                          (initial_pos_2d[1] - keyframe.co[1]) + delta_val),
                               _k, _kraw, _span)
            elif _dir_lock is not None:
                # ★★ 零长端点手柄：方向锁**切线**、长度跟鼠标（见上方 _dir_lock 说明）。
                #    基准用 keyframe.co（手柄从关键帧点长出来），不用 initial_pos_2d
                #    —— 后者的值分量在"零长"时才是 ≈ co，用 co 语义更干净。
                _nv = float(keyframe.co[1]) + _dir_lock[array_index] * _dir_lock_len
                if side == 'left':
                    keyframe.handle_left[1] = _nv
                else:
                    keyframe.handle_right[1] = _nv
            elif side == 'left':
                keyframe.handle_left[1] = initial_pos_2d[1] + delta_val
            else:
                keyframe.handle_right[1] = initial_pos_2d[1] + delta_val
            
            temp_handle_vector_local = mathutils.Vector((0.0, 0.0, 0.0))
            if side == 'left':
                temp_handle_vector_local[array_index] = keyframe.co[1] - keyframe.handle_left[1]
            else:
                temp_handle_vector_local[array_index] = keyframe.handle_right[1] - keyframe.co[1]
            
            self.update_linked_handle(keyframe, side, temp_handle_vector_local, array_index)
            
            keyframe.handle_left_type = original_left_type
            keyframe.handle_right_type = original_right_type
        
        for fcurve in collect_animation_curves(action, obj):
            if is_position_animation(fcurve, bone_name):
                fcurve.update()
    
        # ★★ P2.1（2026-09-16）：加权收尾。
        #    老逻辑 update_linked_handle 只逐轴按 (t,v) 斜率写对侧的【值分量】、没有加权，
        #    实测在各轴手柄时间比例 λ 不同时 3D 折角**修不动**（5.237 → 4.457）。
        #    ⚠️ 必须在上面那句 fc.update() 【之后】：update 会让 Blender 按它自己的
        #       (t,v) 规则重算对侧，写在前面会被覆盖。
        self.finish_linked_handle(action, obj, frame, side, bone_name, context=context)

    def update_linked_handle(self, keyframe, moved_handle_side, handle_vector_local, array_index):
        # ★★ 2026-09-16 重构：判据收敛到 `xf._link_mode`（**【唯一】定义**，两条路径共用）。
        #
        #  旧实现在这里**手写了一份判断**（both_free + is_frozen 两段拼起来），
        #  与端点模态路径 `xf.maintain_linked_handle` 的判据**语义不一致**：
        #
        #    · 端点模态：对侧是 FREE → return（不联动）
        #    · 鼠标路径：两侧都 FREE 且【已登记】→ 联动
        #    ⇒ 同一个关键帧（速度编辑过的），模态操作时对侧**不动**、
        #      鼠标拖拽时对侧**动** → 用户看到「只能作用于一端 + 之后再拖跳变」。
        #
        #  `_link_mode` 已统一包含（**只有三个返回值，没有 'auto'**）：
        #     ALIGNED / AUTO* / 插件冻的或接管的 FREE → 'link'（绕 co 旋转保持共线）
        #     用户手动 FREE                            → 'free'（完全独立，绝不动）
        #     VECTOR                                   → 'vector'（对侧贴到控制点）
        mode = xf._link_mode(keyframe, moved_handle_side)

        if mode == 'free':
            return

        if mode == 'vector':
            if moved_handle_side == 'left':
                keyframe.handle_right[1] = keyframe.co[1]
            else:
                keyframe.handle_left[1] = keyframe.co[1]
            return

        # mode == 'link'（ALIGNED，或插件自己冻的 FREE）
        co = mathutils.Vector(keyframe.co)

        if moved_handle_side == 'left':
            handle_active = mathutils.Vector(keyframe.handle_left)
            handle_opposite = mathutils.Vector(keyframe.handle_right)
            target_handle_attr = 'handle_right'
        else:
            handle_active = mathutils.Vector(keyframe.handle_right)
            handle_opposite = mathutils.Vector(keyframe.handle_left)
            target_handle_attr = 'handle_left'

        dx_active = handle_active.x - co.x       # = dt（时间分量）
        dy_active = handle_active.y - co.y
        dx_opposite = handle_opposite.x - co.x

        # ⚠️⚠️ 两道数值保护（2026-09-16 实测踩坑）——
        #     这里是 `slope = dv / dt`，**dt 在分母上**，而且外推还要再乘对侧 dt。
        #     **速度编辑能把 dt 压到 ~1e-3 帧**（旧阈值 0.0001 拦不住 0.001）：
        #
        #         实测：拖被速度编辑过的一侧 → 斜率 = dv/0.001 = 上千
        #               → 对侧沿 (t,v) 直线外推 → 手柄炸到 (-5766, -8652)
        #
        #     ① dt 低于可分辨下限 → 斜率**无定义**，直接放弃
        #     ② 外推结果超出安全值域 → 配置病态，直接放弃
        #     两种放弃都**不是丢功能**：紧随其后的 `xf.finish_linked_handle`
        #     会走三维通路（方向 + 臂长，全程不除 dt）把对侧摆正。
        if abs(dx_active) <= xf.DT_EPS:
            return
        slope = dy_active / dx_active
        new_y_opposite = co.y + (slope * dx_opposite)
        if (not math.isfinite(new_y_opposite)
                or abs(new_y_opposite - co.y) > _MAX_TV_EXTRAP):
            return

        if target_handle_attr == 'handle_right':
            keyframe.handle_right[1] = new_y_opposite
        else:
            keyframe.handle_left[1] = new_y_opposite
    
    def apply_handle_point_offset(self, context, total_offset_world, handle_point):
        if not all(math.isfinite(c) and abs(c) < SAFE_LIMIT for c in total_offset_world):
            return

        obj = _get_drag_obj(context)
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        action = obj.animation_data.action
        frame = handle_point['frame']
        side = handle_point['side']
        bone_name = handle_point.get('bone_name')
        bone = (obj.pose.bones.get(bone_name) if (bone_name and obj.mode == 'POSE' and obj.pose) else None)
        global_scale = context.window_manager.rtmp_handle_scale
        
        parent_matrix = resolve_parent_transform(obj, bone)
        rotation_matrix = parent_matrix.to_3x3()
        
        total_offset_local = rotation_matrix.inverted() @ total_offset_world
        total_offset_local_scaled = total_offset_local / global_scale
        
        frame_kf_map = {}
        for fcurve in collect_animation_curves(action, obj):
            if not is_position_animation(fcurve, bone_name):
                continue
            for keyframe in fcurve.keyframe_points:
                if abs(keyframe.co[0] - frame) < FRAME_EPS:
                    frame_kf_map[fcurve.array_index] = keyframe
                    break
        
        # ★★ 修复（2026-09-16，P1）：**先记录原类型，再 prepare**。
        #
        # 旧顺序：prepare_handles_for_edit() 先把 VECTOR 改成 FREE（永久），
        #         然后循环里才读 handle_left_type 当"原类型"
        #         → 读到的已是 FREE → 结束时"恢复"成 FREE
        #         → **VECTOR 类型被永久破坏**（实测确认）。
        #
        # 实测基线（修复前，拖手柄后的类型）：
        #     AUTO_CLAMPED / AUTO / ALIGNED / FREE → 类型不变 ✓
        #     VECTOR                              → ★被改成 FREE
        # ★★ 同上：按原生语义接管类型（两侧都接管）。
        xf.prepare_handles_for_drag(action, obj, [(frame, side)], bone_name)

        # ★ P1：用 prepare 返回的【原类型】
        original_types = self.prepare_handles_for_edit(frame_kf_map) or {}

        factors_left, factors_right = compute_handle_display_factors(frame_kf_map)

        # ★ 同比例模式：预演（只读）—— 必须在下面任何写入之前
        _uni = _uniform_plan(context, action, obj, frame, side, bone_name,
                             (factors_left if side == 'left' else factors_right),
                             total_offset_local_scaled, frame_kf_map)

        # ★★★ 2026-09-17 用户实测：「拖尾部端点的手柄出来时，手柄不会和路径
        #      相切，也没有和路径有预期交互」——**零长端点手柄拖出 ⇒ 方向锁切线**。
        #
        #   实测（磁盘干净起点、只改拖动方向，该处来路方向 [-0.91,-0.087,0.406]）：
        #       沿 +X 拖 → 手柄 [1,0,0]     与来路夹角 **155.4°**
        #       沿 +Y 拖 → 手柄 [0,1,0]     夹角 **95.0°**
        #       沿 +Z 拖 → 手柄 [0,0,1]     夹角 **66.0°**
        #       斜 X+Y   → 手柄 [.707,.707,0] 夹角 **134.8°**
        #   ⇒ 零长手柄的基线是 0 ⇒ 同比例"无定义" ⇒ 走退化分支（只写鼠标位移）
        #     ⇒ **手柄方向 = 纯鼠标拖动方向**。碰巧沿切线拖时才看着正常
        #     ⇒ 用户"有时对有时不对、难复现"。
        #
        #   修法：方向 = 该点**路径切线**（端点内侧朝曲线内部），长度 = 鼠标位移长度
        #   ⇒ 拖出来**一定相切**，长度仍然跟手。
        #   ⚠️ 只在「端点内侧（span is None）+ 基线零长」时生效：
        #      一旦有了长度就走同比例（正常路径）；中间帧手柄正常不为零长，不受影响。
        _dir_lock = None
        _dir_lock_len = 0.0
        if _uni is None and _is_endpoint_inner_handle(
                action, obj, frame, side, bone_name):
            _base3 = []
            for _ax in (0, 1, 2):
                _kfx = frame_kf_map.get(_ax)
                if _kfx is None:
                    _base3 = []
                    break
                _iv = _session.handle_start_values.get((frame, _ax))
                _bv = (float(_iv[1]) if _iv is not None
                       else float(_kfx.handle_left[1] if side == 'left'
                                  else _kfx.handle_right[1]))
                _base3.append(_bv - float(_kfx.co[1]))
            # 基线短到"同比例无意义"（与 handle_scale_k 的阈值同口径）
            if _base3 and math.sqrt(sum(x * x for x in _base3)) <= xf.UNIFORM_LEN_MIN:
                _dir_lock = _path_tangent_unit(action, obj, frame, side, bone_name)
                if _dir_lock is not None:
                    _dir_lock_len = mathutils.Vector(
                        total_offset_local_scaled).length

        for array_index, keyframe in frame_kf_map.items():
            # ★ 用【prepare 之前】记录的类型（不是当场读）
            original_left_type, original_right_type = original_types.get(
                array_index, ('FREE', 'FREE'))
            
            # ⛔ 已删除（2026-09-16 code review）：这里原来有一份手写的
            #    `AUTO* → ALIGNED` 转换，但它**永远不可达** —— 上面 1317 行的
            #    `xf.prepare_handles_for_drag` 已经按原生语义把 AUTO* 转掉了，
            #    而 `original_types` 正是在那之后记录的，不可能再含 AUTO*。
            #    实测：注释掉这段后全套 649 用例零差异。
            #    （类型接管请统一走 `xf.prepare_handles_for_drag`，别再手写第二份。）

            initial_val = _session.handle_start_values.get((frame, array_index))
            if initial_val is None:
                # ★ 多端点拖拽：其他端点没有预先记录基线 → 惰性记录（此时尚未被改）
                _h = keyframe.handle_left if side == 'left' else keyframe.handle_right
                _session.handle_start_values[(frame, array_index)] = (
                    float(_h[0]), float(_h[1]))
                initial_val = _session.handle_start_values[(frame, array_index)]
            
            initial_pos_2d = mathutils.Vector(initial_val)
            
            factor = ((factors_left if side == 'left' else factors_right)
                      .get(array_index, 1.0))
            delta_val = total_offset_local_scaled[array_index] / factor

            if _uni is not None:
                # ★★ 同比例模式：值分量 + 时间分量一起按 k 缩放 ⇒ 关键帧处速度不变
                _k, _kraw, _dvmap, _span = _uni
                _write_uniform(keyframe, side, initial_val,
                               _dvmap.get(array_index,
                                          (initial_pos_2d[1] - keyframe.co[1]) + delta_val),
                               _k, _kraw, _span)
            elif _dir_lock is not None:
                # ★★ 零长端点手柄：方向锁**切线**、长度跟鼠标
                #    （见 `_dir_lock` 的说明；这条路径是**拖端点空心圆**的入口）
                _nv = float(keyframe.co[1]) + _dir_lock[array_index] * _dir_lock_len
                if side == 'left':
                    if hasattr(keyframe, 'handle_left'):
                        keyframe.handle_left[1] = _nv
                else:
                    if hasattr(keyframe, 'handle_right'):
                        keyframe.handle_right[1] = _nv
            elif side == 'left':
                if hasattr(keyframe, 'handle_left'):
                    keyframe.handle_left[0] = initial_pos_2d[0]
                    keyframe.handle_left[1] = initial_pos_2d[1] + delta_val
            else:
                if hasattr(keyframe, 'handle_right'):
                    keyframe.handle_right[0] = initial_pos_2d[0]
                    keyframe.handle_right[1] = initial_pos_2d[1] + delta_val
            
            temp_handle_vector_local = mathutils.Vector((0.0, 0.0, 0.0))
            if side == 'left':
                temp_handle_vector_local[array_index] = keyframe.co[1] - keyframe.handle_left[1]
            else:
                temp_handle_vector_local[array_index] = keyframe.handle_right[1] - keyframe.co[1]

            self.update_linked_handle(keyframe, side, temp_handle_vector_local, array_index)
            
            # ★★ P1：恢复【全部】类型，不再只处理 {'VECTOR','FREE'}。
            #    （旧写法漏了 AUTO 系与 ALIGNED —— 虽然实测它们恰好没被改坏，
            #      但那是"因为 prepare/临时改类型恰好没影响它们"，不是设计保证。
            #      现在无条件写回，语义明确、不依赖巧合。）
            keyframe.handle_left_type = original_left_type
            keyframe.handle_right_type = original_right_type
        
        for fcurve in collect_animation_curves(action, obj):
            if is_position_animation(fcurve, bone_name):
                fcurve.update()
    
        # ★★ P2.1（2026-09-16）：加权收尾（同上，数学在 xf.finish_linked_handle）。
        #    ⚠️ 必须在上面那句 fc.update() 【之后】。
        self.finish_linked_handle(action, obj, frame, side, bone_name, context=context)

    def resolve_handle_anchor_pos(self, context, handle_point):
        global _session
        obj = _get_drag_obj(context)
        frame = handle_point['frame']
        bone_name = handle_point.get('bone_name')
        
        if not obj:
            return mathutils.Vector((0, 0, 0))
        
        obj_cache = _session.cached_positions.get(obj.name, {})
        cache_key = bone_name if bone_name else None
        sub_cache = obj_cache.get(cache_key, {})
        cache_data = sub_cache.get(frame)
        if cache_data:
            return cache_data['position']
        
        return mathutils.Vector((0, 0, 0))
    
    def record_endpoint_snapshot(self, action, obj, frame_num, handle_side, bone_name):
        """★ P2.1（2026-09-16）：记录被拖端点（含多选）的【三点快照】。

        用途：加权收尾要取"对侧手柄的**原始** 3D 长度"。
        ⚠️ 必须在任何写入**之前**记录 —— `fc.update()` 之后 Blender 会按它自己的
           (t,v) 规则把对侧长度改掉，那时再读就是错的（会每帧漂移）。
        """
        try:
            eps = [(float(frame_num), str(handle_side))]
            for (ef, es) in (getattr(_session, "selected_handle_endpoints", None) or []):
                pair = (float(ef), str(es))
                if pair not in eps:
                    eps.append(pair)
            _session.endpoint_snapshot = xf.snapshot_endpoints(action, obj, eps, bone_name)
        except Exception as exc:
            # ⚠️ 不静默：出错就降级为"无快照"（加权收尾会自己跳过），但要把原因打出来
            _session.endpoint_snapshot = {}
            print("[RTMP] record_endpoint_snapshot failed:", exc)

    def finish_linked_handle(self, action, obj, frame, side, bone_name,
                             context=None, zero_eps=None):
        """★ P2.1（2026-09-16）：鼠标拖手柄路径的**三维收尾**。

        数学在 `xf.finish_linked_handle`（复用 `maintain_linked_handle`）。
        老逻辑 `update_linked_handle` 只逐轴按 (t,v) 斜率写对侧的**值分量**，
        实测在各轴手柄时间比例 λ 不同时 3D 折角**修不动**：
            初始 5.237 → 拖后 4.457（三维通路是 0.0000）。

        ⚠️ 2026-09-16（第十轮）起，收尾**只摆三维方向 + 臂长，不再改对侧 dt**
           —— 用户拍板 3D 视图优先、Graph Editor 不需要共线，
           改 dt 会把速度分布抹掉（对 3D 零收益）。见 `xf._apply_weight` 的 docstring。
        """
        try:
            snap = getattr(_session, "endpoint_snapshot", None) or {}
            # ★★ 2026-09-17：把「视觉零」的【世界】阈值换算好传下去。
            #    封口闸门（`xf._ARM_EPS = 1e-9` 世界）与空心圆判据（屏幕 6px）
            #    原本差 6 个数量级 ⇒ 用户把两侧缩到关键帧点后一拖，
            #    对侧 ALIGNED 就被封口成 FREE（实测反馈）。
            #    现在两处共用同一语义：屏幕上 ≤ 6px 就算零。
            if zero_eps is None and context is not None:
                try:
                    ref = None
                    if obj is not None:
                        _c = _session.cached_positions.get(obj.name)
                        if _c:
                            for _bkey, _fr in _c.items():
                                _e = _fr.get(int(round(frame)))
                                if _e and _e.get("position") is not None:
                                    ref = _e["position"]
                                    break
                    if ref is None:
                        ref = getattr(_session, "world_origin", None)
                    if ref is not None:
                        zero_eps = world_eps_for_screen(context, ref)
                except Exception:
                    zero_eps = None
            if zero_eps is None:
                return xf.finish_linked_handle(action, obj, snap, frame, side, bone_name)
            return xf.finish_linked_handle(action, obj, snap, frame, side, bone_name,
                                           zero_eps=zero_eps)
        except Exception as exc:
            print("[RTMP] finish_linked_handle failed:", exc)
            return False

    def record_handle_baseline(self, context, frame_num, selected_bone_name, handle_side):
        global _session
        _session.handle_start_values = {}
        # ⚠️ 一并清掉旧快照：若下面提前 return（frame_kf_map 为空），
        #    残留的上一轮快照会让加权收尾取到**错的**对侧原始长度。
        _session.endpoint_snapshot = {}
        
        obj = _get_drag_obj(context)
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        action = obj.animation_data.action
        fcurves = collect_animation_curves(action, obj)
        
        frame_kf_map = {}
        for i, fcurve in enumerate(fcurves):
            if is_position_animation(fcurve, selected_bone_name):
                for kp in fcurve.keyframe_points:
                    if abs(kp.co[0] - frame_num) < 0.001:
                        array_index = fcurve.array_index
                        frame_kf_map[array_index] = kp
                        break
        
        if not frame_kf_map:
            return
        
        for array_index, kp in frame_kf_map.items():
            if handle_side == 'left':
                _session.handle_start_values[(frame_num, array_index)] = (kp.handle_left[0], kp.handle_left[1])
            else:
                _session.handle_start_values[(frame_num, array_index)] = (kp.handle_right[0], kp.handle_right[1])

        # ★★ P2.1（2026-09-16）：再记一份【三点快照】（必须在拖拽写入之前）
        self.record_endpoint_snapshot(action, obj, frame_num, handle_side,
                                      selected_bone_name)

    def locate_handle_under_cursor(self, context, event, region=None, rv3d=None, local_mouse_pos=None):
        if not region or not rv3d:
            if not context.space_data or context.space_data.type != 'VIEW_3D':
                 return None, None, None, None, None
            region = context.region
            rv3d = context.space_data.region_3d
        
        if local_mouse_pos:
            mouse_pos = mathutils.Vector(local_mouse_pos)
        else:
            mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))

        obj = context.active_object
        
        if not obj:
            return None, None, None, None, None
        
        def check_handles_at_frame(bone_name, frame_num, point_3d, parent_matrix, check_action, check_obj=None):
            if not frame_has_keyframe(collect_animation_curves(check_action, check_obj), frame_num, bone_name):
                return None
            
            frame_kf_map = {}
            for fcurve in collect_animation_curves(check_action, check_obj):
                if is_position_animation(fcurve, bone_name):
                    for keyframe in fcurve.keyframe_points:
                        if abs(keyframe.co[0] - frame_num) < FRAME_EPS:
                            frame_kf_map[fcurve.array_index] = keyframe
                            break
            
            if not frame_kf_map:
                return None
            
            # ★ 2026-09-18（盲审 S2）：算出"本帧是不是首/末关键帧"，供外侧守卫用。
            #   与绘制侧同一口径：在所有位移曲线里取 min/max 帧号。
            #   单关键帧时首=末 ⇒ 两侧都是外侧（与 drawing 的 H 组测试一致）。
            _all_frames = [kp.co[0] for _fc in collect_animation_curves(check_action, check_obj)
                           if is_position_animation(_fc, bone_name)
                           for kp in _fc.keyframe_points]
            _f_lo = min(_all_frames) if _all_frames else None
            _f_hi = max(_all_frames) if _all_frames else None
            is_first = (_f_lo is not None and abs(frame_num - _f_lo) < FRAME_EPS)
            is_last = (_f_hi is not None and abs(frame_num - _f_hi) < FRAME_EPS)

            factors_left, factors_right = compute_handle_display_factors(frame_kf_map)
            
            handle_vector_left = mathutils.Vector((0.0, 0.0, 0.0))
            handle_vector_right = mathutils.Vector((0.0, 0.0, 0.0))
            
            for array_index, keyframe in frame_kf_map.items():
                factor_l = factors_left.get(array_index, 1.0)
                factor_r = factors_right.get(array_index, 1.0)
                
                diff = (keyframe.handle_left[1] - keyframe.co[1]) * factor_l
                handle_vector_left[array_index] = diff
                diff = (keyframe.handle_right[1] - keyframe.co[1]) * factor_r
                handle_vector_right[array_index] = diff
            
            rotation_matrix = parent_matrix.to_3x3()
            world_vector_left = rotation_matrix @ handle_vector_left
            world_vector_right = rotation_matrix @ handle_vector_right
            
            global_scale = context.window_manager.rtmp_handle_scale
            
            # ⚠️ 守卫与绘制侧共用【唯一】判据 `drawing.handle_is_zero_length`
            #    （**屏幕像素**口径，见其 docstring）——**严格互补**：
            #    绘制侧判「空心态」的那一侧，这里【不做】几何命中，
            #    改由 `get_handle_at_cursor` 按「空心圆抓取点」的偏移位置去命中。
            #    本处【不再】自带第二份判据（世界长度 1e-4 / 别的阈值都不行）——
            #    两边判据一旦漂移，就会出现"几何拾取不认、空心态也不认"的缝 ⇒ 误触。
            # ★★ 2026-09-18（盲审 S2）：**外侧手柄必须不命中** —— 与绘制侧严格对称。
            #   绘制侧 `drawing.py:739` 对「首帧 left / 末帧 right」是
            #   `continue`（不画手柄线、不登记抓取点），其注释原文写着
            #   「拖了也没效果」；而这里原先**没有任何对应守卫** ⇒ 用户能点到
            #   一根**看不见的线**、拖了还不动（体验断档）。
            #
            #   ※ 盲审原文称"拖动会改变动画"，实测**不成立**：
            #     `tests/gui_endpoint_hollow_check.py:11` 记载
            #     「外侧手柄不参与任何曲线段，值分量/时间分量对曲线影响
            #       都是 0.00000000」⇒ 拖了曲线不会变，只是**白拖**。
            #     所以本条是"体验/对称性"修复，不是"数据被改坏"的修复。
            #
            #   ⚠️ 判据必须**复用** `drawing._endpoint_is_hidden_side`（唯一来源），
            #     不能在这里重写一份 —— 两边判据一旦漂移就会出现"缝"。
            if not _endpoint_is_hidden_side(is_first, is_last, 'left'):
                if not handle_is_zero_length(context, point_3d, world_vector_left,
                                             global_scale, region, rv3d):
                    handle_left_pos = point_3d + (world_vector_left * global_scale)
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_left_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        return 'left', handle_left_pos

            if not _endpoint_is_hidden_side(is_first, is_last, 'right'):
                if not handle_is_zero_length(context, point_3d, world_vector_right,
                                             global_scale, region, rv3d):
                    handle_right_pos = point_3d + (world_vector_right * global_scale)
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_right_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        return 'right', handle_right_pos
            
            return None

        if obj.mode == 'POSE':
            if not obj.animation_data or not obj.animation_data.action:
                return None, None, None, None, None
            action = obj.animation_data.action
            obj_cache = _session.cached_positions.get(obj.name, {})
            
            bones_to_check = list(context.selected_pose_bones or [])
            active_bone = context.active_pose_bone
            if active_bone and active_bone not in bones_to_check:
                bones_to_check.append(active_bone)
                
            for bone in bones_to_check:
                bone_name = bone.name
                if bone_name not in obj_cache:
                    continue
                
                parent_matrix = resolve_parent_transform(obj, bone)
                
                for frame_num, cache_data in obj_cache[bone_name].items():
                    point_3d = parent_matrix @ cache_data['position']
                    
                    result = check_handles_at_frame(bone_name, frame_num, point_3d, parent_matrix, action, obj)
                    if result:
                        side, handle_pos = result
                        return side, handle_pos, frame_num, point_3d, bone
            
            return None, None, None, None, None
            
        else:
            for cache_obj_name, cache_obj_data in _session.cached_positions.items():
                draw_obj = bpy.data.objects.get(cache_obj_name)
                if not draw_obj or None not in cache_obj_data:
                    continue
                draw_action = draw_obj.animation_data.action if draw_obj.animation_data else None
                if not draw_action:
                    continue
                parent_matrix = resolve_parent_transform(draw_obj)
                for frame_num, cache_data in cache_obj_data[None].items():
                    point_3d = parent_matrix @ cache_data['position']
                    result = check_handles_at_frame(None, frame_num, point_3d, parent_matrix, draw_action, draw_obj)
                    if result:
                        side, handle_pos = result
                        _session.drag_target_object = draw_obj.name
                        return side, handle_pos, frame_num, point_3d, None
        
        return None, None, None, None, None
    
    def locate_point_under_cursor(self, context, event, region=None, rv3d=None, local_mouse_pos=None):
        if not region or not rv3d:
            if not context.space_data or context.space_data.type != 'VIEW_3D':
                return None, None, None
            region = context.region
            rv3d = context.space_data.region_3d

        if local_mouse_pos:
            mouse_pos = mathutils.Vector(local_mouse_pos)
        else:
            mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
            
        obj = context.active_object
        
        if not obj:
            return None, None, None
        
        obj_cache = _session.cached_positions.get(obj.name, {})
        
        if obj.mode == 'POSE':
            bones_to_check = list(context.selected_pose_bones or [])
            active_bone = context.active_pose_bone
            if active_bone and active_bone not in bones_to_check:
                bones_to_check.append(active_bone)
            
            for bone in bones_to_check:
                if bone.name not in obj_cache:
                    continue
                
                parent_matrix = resolve_parent_transform(obj, bone)
                
                for frame_num, cache_data in obj_cache[bone.name].items():
                    local_pos = cache_data['position']
                    world_pos = parent_matrix @ local_pos
                    
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        return world_pos, frame_num, bone

            # ⚠️ 同上：cached_positions 只含关键帧；补上对全部采样点的命中检测
            hit = _hit_sampled_point(context, region, rv3d, mouse_pos)
            if hit is not None:
                return hit

            return None, None, None
        else:
            for cache_obj_name, cache_obj_data in _session.cached_positions.items():
                draw_obj = bpy.data.objects.get(cache_obj_name)
                if not draw_obj or None not in cache_obj_data:
                    continue
                parent_matrix = resolve_parent_transform(draw_obj)
                for frame_num, cache_data in cache_obj_data[None].items():
                    local_pos = cache_data['position']
                    world_pos = parent_matrix @ local_pos
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        _session.drag_target_object = draw_obj.name
                        return world_pos, frame_num, None

            # ⚠️ 上面的 cached_positions 只含【关键帧】的缓存。
            #    但插件在视口里画的是【每帧一个采样点】（path_point_sequence）。
            #    实测：`cached_positions` 帧号 = [1,14,27,40]，而画出来 40 个点
            #    → 36 个点【点不中】（既不选中也不能拖），
            #      用户反馈的"R/S 没反应"正是点到了这些点。
            #    这里补上对【全部采样点】的命中检测。
            hit = _hit_sampled_point(context, region, rv3d, mouse_pos)
            if hit is not None:
                return hit

        return None, None, None


def get_handle_at_cursor(context, event, region=None, rv3d=None, local_mouse_pos=None):
    global _session
    
    if not region or not rv3d:
        if not context.space_data or context.space_data.type != 'VIEW_3D':
            return None, None
        region = context.region
        rv3d = context.space_data.region_3d

    if local_mouse_pos:
        mouse_pos = mathutils.Vector(local_mouse_pos)
    else:
        mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
    
    for i, handle_point in enumerate(_session.handle_control_points):
        screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_point['position'])
        if not screen_pos:
            continue
        # ★ 空心圆抓取点用【更小】的独立拾取半径（state.HANDLE_HOLLOW_PICK_RADIUS）
        #   否则它的 20px 盘会与关键帧的 20px 盘重叠（圆心距仅 32px）⇒
        #   点关键帧盘边缘仍被手柄抢走（code review 2026-09-17 实测的重叠区）。
        radius = HANDLE_HOLLOW_PICK_RADIUS if handle_point.get('hollow') else HANDLE_SELECT_RADIUS
        if (mouse_pos - screen_pos).length < radius:
            return i, handle_point
    return None, None


def is_keyframe_selected(action, bone_name, frame, obj=None):
    for fc in collect_animation_curves(action, obj):
        if is_position_animation(fc, bone_name):
            for kp in fc.keyframe_points:
                if abs(kp.co[0] - frame) < FRAME_EPS:
                    return kp.select_control_point
    return False


def _xf_mod():
    """惰性拿 transform_domain 模块（避免顶层循环导入）。"""
    try:
        from . import transform_domain as xf
    except Exception:
        import transform_domain as xf
    return xf


def current_feel_label(context):
    """返回选中关键帧的【体感手柄类型】标签（供右键菜单显示/高亮）。

    ★ 方案 A：体感类型是权威数据。返回：
        'LINK' / 'VECTOR' / 'FREE'  —— 选中帧体感一致时
        None                        —— 没选中 / 混合 / 未记录（透传原始类型）
    """
    try:
        from . import transform_domain as xf
    except Exception:
        import transform_domain as xf
    seen = set()
    try:
        targets = _collect_handle_targets(context)
    except Exception:
        return None
    for obj, bone_name in targets:
        act = obj.animation_data.action if obj and obj.animation_data else None
        if act is None:
            continue
        for fc in xf._position_curves(act, obj, bone_name):
            for kp in fc.keyframe_points:
                if not kp.select_control_point:
                    continue
                # 两侧都取，看体感是否一致（未记录 ⇒ 透传原始类型）
                for side in ('left', 'right'):
                    v = xf.feel_type(kp, side)
                    if v is None:
                        v = str(kp.handle_left_type if side == 'left'
                                else kp.handle_right_type)
                        # 透传时把原生语义折成体感口径
                        v = {'ALIGNED': 'LINK', 'AUTO': 'LINK',
                             'AUTO_CLAMPED': 'CLAMPED'}.get(v, v)
                    seen.add(v)
    if len(seen) == 1:
        return seen.pop()
    return None


def _collect_handle_targets(context):
    """收集 (obj, bone_name) 目标 —— 与 `apply_handle_mode` 同一口径。"""
    targets = []
    if context.mode == 'POSE':
        obj = context.active_object
        if obj and obj.type == 'ARMATURE':
            for bone in (context.selected_pose_bones or []):
                targets.append((obj, bone.name))
    else:
        obj = context.active_object
        if obj and obj.animation_data and obj.animation_data.action:
            targets.append((obj, None))
    return targets


def apply_handle_mode(context, handle_type):
    """设置【体感手柄类型】（方案 A）。

    ★ 2026-09-17 改造：
      · `handle_type` 现在理解为**体感类型**（'LINK'/'FREE'/'VECTOR'/'AUTO'/'AUTO_CLAMPED'）
      · 体感**独立记录**（`mark_feel`）—— 权威
      · 原始手柄类型**按需**写（'FREE' 或原生值）—— 实现细节，别让 Blender 重算
    """
    targets = []

    if context.mode == 'POSE':
        obj = context.active_object
        if obj and obj.type == 'ARMATURE':
            selected_bones = list(context.selected_pose_bones or [])
            if selected_bones:
                for bone in selected_bones:
                    targets.append((obj, bone.name))
            elif context.active_pose_bone:
                targets.append((obj, context.active_pose_bone.name))
    else:
        selected_objects = list(context.selected_objects or [])
        if selected_objects:
            for obj in selected_objects:
                if obj.animation_data and obj.animation_data.action:
                    targets.append((obj, None))
        else:
            obj = context.active_object
            if obj and obj.animation_data and obj.animation_data.action:
                targets.append((obj, None))

    # ---- 口径换算（★ 方案 A） ----
    #   入参 handle_type 是**体感口径**：
    #     'LINK'  = 保持一条直线（对应原来的 Aligned / Auto / AutoClamped）
    #     'FREE'  = 不动
    #     'VECTOR'= 贴到控制点
    #     旧接口的 'ALIGNED'/'AUTO'/'AUTO_CLAMPED' 也接受，一律折成 'LINK'。
    _ht = str(handle_type or '').upper()
    if _ht == 'AUTO_CLAMPED':
        feel_value = 'CLAMPED'          # ★ 与 LINK 行为相同（联动），但原始类型不同
    elif _ht in ('ALIGNED', 'AUTO', 'LINK'):
        feel_value = 'LINK'
    elif _ht == 'VECTOR':
        feel_value = 'VECTOR'
    else:
        feel_value = 'FREE'

    # 原始手柄类型（实现细节）—— 唯一来源在 transform_domain.orig_type_for_feel
    try:
        orig_type = _xf_mod().orig_type_for_feel(feel_value)
    except Exception:
        orig_type = 'ALIGNED' if feel_value == 'LINK' else 'FREE'

    for obj, bone_name in targets:
        action = obj.animation_data.action
        for fcurve in collect_animation_curves(action, obj):
            if not is_position_animation(fcurve, bone_name):
                continue
            for keyframe in fcurve.keyframe_points:
                if keyframe.select_control_point:
                    # ---- ① 记录【体感类型】（权威） ----
                    try:
                        xf = _xf_mod()
                        for _side in ('left', 'right'):
                            xf.mark_feel(keyframe, _side, feel_value)
                    except Exception:
                        pass

                    # ---- ② 原始手柄类型（按需写） ----
                    #   · 体感 LINK   → 写 'ALIGNED'（让原生共线保持，符合"对齐"语义）
                    #   · 体感 FREE   → 写 'FREE'（定住，Blender 不重算）
                    #   · 体感 VECTOR → 写 'VECTOR'
                    #   · AUTO 系     → 写原生 'AUTO_CLAMPED'
                    keyframe.handle_left_type = orig_type
                    keyframe.handle_right_type = orig_type

                    if feel_value in ('LINK', 'AUTO', 'AUTO_CLAMPED'):
                        vec = mathutils.Vector(keyframe.co) - mathutils.Vector(keyframe.handle_left)
                        len_right = (mathutils.Vector(keyframe.handle_right) - mathutils.Vector(keyframe.co)).length
                        if vec.length > 0.0001:
                            vec.normalize()
                            keyframe.handle_right = mathutils.Vector(keyframe.co) + vec * len_right
                    elif feel_value == 'VECTOR':
                        keyframe.handle_left[1] = keyframe.co[1]
                        keyframe.handle_right[1] = keyframe.co[1]
            fcurve.update()


def ensure_location_keyframes(context, obj):
    if not obj or not obj.animation_data or not obj.animation_data.action:
        return

    action = obj.animation_data.action
    
    targets = []
    if obj.mode == 'POSE':
        if context.selected_pose_bones:
            for bone in context.selected_pose_bones:
                 targets.append((f'pose.bones["{bone.name}"].location', bone.name))
    else:
        targets.append(('location', None))

    fcurves_collection = collect_animation_curves(action, obj)
    if isinstance(fcurves_collection, list) and not fcurves_collection:
        return

    for data_path_base, bone_name in targets:
        all_frames = set()
        frame_indices = {} 
        
        target_fcurves = []
        for fc in fcurves_collection:
            if fc.data_path == data_path_base:
                target_fcurves.append(fc)
                for kp in fc.keyframe_points:
                    frame = int(round(kp.co[0]))
                    all_frames.add(frame)
                    if frame not in frame_indices:
                        frame_indices[frame] = set()
                    frame_indices[frame].add(fc.array_index)
        
        if not target_fcurves:
            continue

        # 仅在确实需要新建曲线时才去取可写集合（惰性）
        writable_fcurves = None
        writable_checked = False

        sorted_frames = sorted(list(all_frames))
        
        modified = False
        
        for frame in sorted_frames:
            existing_indices = frame_indices.get(frame, set())
            missing_indices = {0, 1, 2} - existing_indices
            
            if missing_indices:
                for axis_index in missing_indices:
                    fc = next((f for f in target_fcurves if f.array_index == axis_index), None)
                    
                    if fc:
                        val = fc.evaluate(frame)
                        fc.keyframe_points.insert(frame, val)
                    else:
                        # collect_animation_curves() 返回的是 list 快照，没有 .new()；
                        # 新建曲线必须用可写集合 get_writable_fcurves()。
                        if not writable_checked:
                            writable_fcurves = get_writable_fcurves(action, obj)
                            writable_checked = True
                        try:
                            if writable_fcurves is not None:
                                fc = writable_fcurves.new(data_path=data_path_base, index=axis_index)
                                target_fcurves.append(fc)
                                
                                if bone_name:
                                    val = obj.pose.bones[bone_name].location[axis_index]
                                else:
                                    val = obj.location[axis_index]
                                    
                                fc.keyframe_points.insert(frame, val)
                            else:
                                print("RealTimeMotionPath: Cannot create new F-Curve (no writable collection)")
                        except Exception as e:
                            print(f"RealTimeMotionPath: Error creating fcurve for {data_path_base}[{axis_index}]: {e}")
                    
                    modified = True
        
        if modified:
             for fc in target_fcurves:
                 fc.update()


def update_custom_path_active(self, context):
    wm = context.window_manager
    if wm.rtmp_path_display_enabled:
        try:
            ensure_location_keyframes(context, context.active_object)
        except Exception as e:
            print(f"Motion Path Pro: Error ensuring keyframes: {e}")
        if not _find_and_start_motion_path_operators(context):
            print("Motion Path Pro: Enabled, but no 3D View found for interaction.")
    else:
        _stop_motion_path_operators(context)

    if context.area:
        context.area.tag_redraw()


def _find_and_start_motion_path_operators(context):
    wm = context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                if region:
                    with context.temp_override(window=window, area=area, region=region):
                        if not wm.rtmp_edit_mode_active:
                            wm.rtmp_edit_mode_active = True
                            bpy.ops.rtmp.path_point_drag('INVOKE_DEFAULT')
                        if not wm.rtmp_auto_refresh_active:
                            wm.rtmp_auto_refresh_active = True
                            bpy.ops.rtmp.path_refresh_daemon('INVOKE_DEFAULT')
                    return True
    return False


def _stop_motion_path_operators(context):
    wm = context.window_manager
    wm.rtmp_edit_mode_active = False
    wm.rtmp_auto_refresh_active = False
