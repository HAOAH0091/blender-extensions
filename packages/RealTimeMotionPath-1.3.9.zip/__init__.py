bl_info = {
    "name" : "RealTimeMotionPath",
    "author" : "HAOAH",
    "description" : "Display and edit motion paths in real time in the 3D Viewport, with direct handle editing and Graph Editor sync",
    "blender" : (5, 0, 0),
    "version": (1, 3, 9),
    "location" : "3D Viewport › Header",
    "warning" : "",
    "doc_url" : "",
    "tracker_url" : "",
    "category" : "Animation"
}


import bpy
from . import translations
from .ui import (
    RTMP_OT_ToggleCustomDraw,
    RTMP_OT_ResetPreferences,
    RTMP_PT_header_settings,
    RTMP_AddonPreferences,
    RTMP_MT_context_menu,
    RTMP_OT_OpenDebugLog,
    RTMP_OT_ClearDebugLog,
    draw_header_button
)
from .interaction import (
    RTMP_OT_PathPointDrag,
    RTMP_OT_ToggleEditMode,
    RTMP_OT_PathRefreshDaemon,
    RTMP_OT_ChangeHandleMode,
    update_custom_path_active
)
from .modal_edit import (
    RTMP_OT_ModalEdit,
    RTMP_OT_KeyboardTransform,
    register_keymaps as register_modal_keymaps,
    unregister_keymaps as unregister_modal_keymaps,
    unregister_transform_keys as release_transform_keys,
    update_edit_mode_active,
)


classes = (
    RTMP_OT_ToggleCustomDraw,
    RTMP_OT_ResetPreferences,
    RTMP_PT_header_settings,
    RTMP_AddonPreferences,
    RTMP_MT_context_menu,
    RTMP_OT_OpenDebugLog,
    RTMP_OT_ClearDebugLog,
    
    RTMP_OT_PathPointDrag,
    RTMP_OT_ToggleEditMode,
    RTMP_OT_PathRefreshDaemon,
    RTMP_OT_ChangeHandleMode,

    # 模态交互（第一条线：G/R/S 变换；第二条线：采样点疏密）
    RTMP_OT_ModalEdit,
    RTMP_OT_KeyboardTransform,
)


# （`refresh_strategy_items` 已随性能设置迁到 `ui.RTMP_AddonPreferences` ——
#   那里是属性的唯一定义处，items 内联在该属性上。2026-09-17）


handle_mode_items = [
    ('FREE', "Free", "Handles can be adjusted independently"),
    ('ALIGNED', "Aligned", "Handles are aligned to maintain smoothness"),
    ('VECTOR', "Vector", "Creates linear interpolation"),
    ('AUTO', "Auto", "Automatic smooth handles"),
    ('AUTO_CLAMPED', "Auto Clamped", "Automatic handles with clamped values"),
]


def register():
    translations.register(__package__)
    for cls in classes:
        bpy.utils.register_class(cls)

    # ★★ 2026-09-17：注册时**先清一遍孤儿绘制回调**（"先清后建"）。
    #    兜住"上一次卸载没走 detach"的历史遗留 —— 否则新旧回调会同时绘制，
    #    表现为路径上出现残留直线（用户实测："开关插件开关后绘制残留"）。
    #    正常情况下这里是 no-op（没有孤儿可清）。
    try:
        from .drawing import purge_stale_draw_handlers
        _rm, _fa = purge_stale_draw_handlers()
        if _rm:
            print("[RealTimeMotionPath] 已清理 %d 个遗留绘制回调" % len(_rm))
    except Exception:
        pass
    # 同理清 `bpy.app.handlers` 里的遗留（旧模块的 on_depsgraph_update 等）
    try:
        from .state import purge_stale_app_handlers
        _rh = purge_stale_app_handlers()
        if _rh:
            print("[RealTimeMotionPath] 已清理 %d 个遗留 app handler: %s"
                  % (len(_rh), ", ".join(_rh)))
    except Exception:
        pass

    # ★★ 2026-09-19：撤销 / 重做后让内存缓存失效。
    #    根因：锁定 / 体感 / FREE 登记 / 冻结这四张表都是「内存镜像 +
    #    custom property 持久化」，查询走「先查内存、命中即返回」；
    #    而 Blender 全局 undo 只回滚 main database，**碰不到 Python 模块变量**
    #    ⇒ 撤销后 property 已回滚、内存仍是旧值 ⇒ 用户看到「撤销没生效」
    #    （用户本次报：双击三角锁定后 Ctrl+Z 撤不掉锁定状态）。
    #    ⚠️ 顺序：放在 `purge_stale_app_handlers()` 【之后】挂。
    #       另外 `state._PURGE_PROTECTED` 已把这两个 handler 排除在清理之外
    #       —— 因为守护进程（进编辑模式时 invoke）会反复调 purge，
    #       否则本钩子**上线即失效**（v1.3.6 的教训，用户实机复现）。
    try:
        from .undo_guard import register_undo_handlers
        register_undo_handlers()
    except Exception:
        pass

    # 模态编辑的进入键（默认 J；实测 Object/Pose 模式下的 3D View 中零绑定）
    register_modal_keymaps()
    

    bpy.types.WindowManager.rtmp_path_display_enabled = bpy.props.BoolProperty(
        name="Enable Motion Path",
        description="Enable custom motion path drawing",
        default=False,
        update=update_custom_path_active
    )
    
    bpy.types.WindowManager.rtmp_edit_mode_active = bpy.props.BoolProperty(
        name="Direct Edit Active",
        description="Enable real-time direct editing of motion path control points",
        default=False,
        # 开关一变就接管/归还 G/R/S（第一条线）。
        # 挂在属性上而非某个 operator 里：这个开关有多个写入点。
        update=update_edit_mode_active
    )
    bpy.types.WindowManager.rtmp_auto_refresh_active = bpy.props.BoolProperty(
        name="Auto Update Active",
        default=False
    )
    
    # ★★ 2026-09-17（用户要求）：性能设置（更新模式 / 交互帧率 / 轮询频率）
    #    从 WindowManager 迁到 AddonPreferences（UI 也挪进偏好设置面板）。
    #    原因（实测）：**WindowManager 上的属性不写入文件** ——
    #    设 TIMER/33/7 → 保存 → 重开变回 SMART/60/10；RNA 的 `is_runtime` 为 True。
    #    用户"改完重启就丢"，不符合偏好设置的语义。
    #    ⇒ 现定义在 `ui.RTMP_AddonPreferences`，读取走 `state.addon_pref()`。
    #    （原来这里注册的 rtmp_refresh_strategy / rtmp_max_interaction_fps /
    #      rtmp_poll_frequency 已移除。）

    bpy.types.WindowManager.rtmp_handle_type = bpy.props.EnumProperty(
        name="Keyframe Handle Type",
        description="Handle type used when editing keyframes on the motion path",
        items=handle_mode_items,
        default='ALIGNED'
    )
    bpy.types.WindowManager.rtmp_snap = bpy.props.BoolProperty(
        name="Snap to Grid",
        description="Snap handles to grid while dragging",
        default=False
    )
    bpy.types.WindowManager.rtmp_snap_step = bpy.props.FloatProperty(
        name="Snap Step",
        description="Grid step size for handle snapping",
        default=0.1,
        min=0.01,
        max=10.0
    )
    bpy.types.WindowManager.rtmp_handle_scale = bpy.props.FloatProperty(
        name="Handle Scale",
        description="Visual scale multiplier for handle display in viewport",
        default=1.0,
        min=0.1,
        max=10.0
    )
    
    if hasattr(bpy.types, "VIEW3D_HT_header"):
        bpy.types.VIEW3D_HT_header.append(draw_header_button)


def unregister():
    if hasattr(bpy.types, "VIEW3D_HT_header"):
        bpy.types.VIEW3D_HT_header.remove(draw_header_button)

    unregister_modal_keymaps()
    # 若编辑模式还开着就卸载插件，务必把原生 G/R/S 还回去
    release_transform_keys()
    # 视口覆盖层的绘制回调也要撤掉，否则泄漏
    try:
        from .overlay import stop_overlay
        stop_overlay()
    except Exception:
        pass
    # ★★ 2026-09-17：运动路径的绘制回调也必须撤 —— 原来这里**漏了**
    #    （只撤了 overlay）。漏掉的后果（用户实测："开关插件开关后绘制残留"）：
    #      draw_handler 的句柄只存在 `_session.render_callback_id` 里，
    #      不 detach ⇒ 回调仍留在注册表里、闭包引用旧模块 ⇒ GC 收不走
    #      ⇒ 下次注册后**两个回调同时画** ⇒ 路径上出现黑色残留直线。
    try:
        from .drawing import detach_render_callback, purge_stale_draw_handlers
        detach_render_callback()
        # 兜底：连历史遗留（旧版本漏掉 detach 攒下的）一起清掉
        purge_stale_draw_handlers()
    except Exception:
        pass
    # ★★ 2026-09-17：`bpy.app.handlers` 里的回调同样要清（同类泄漏）。
    #    实测 `depsgraph_update_post` 里叠了 3 个 `on_depsgraph_update`
    #    （全是本插件的，其中旧模块的每帧抛 AttributeError）——
    #    根因：注册判据比"函数对象身份"，跨模块重载必失效。
    #
    # ★★ 2026-09-19：撤销/重做 handler **必须在这里显式摘掉**。
    #    ⚠️ 不能指望下面的 `purge_stale_app_handlers()` 兜底 —— 它现在
    #       **跳过** `_PURGE_PROTECTED`（undo_post / redo_post），
    #       因为它们会被自动刷新守护进程反复调用清逻辑误伤（v1.3.6 上线即失效的
    #       教训：用户一进编辑模式，undo_post handler 就被 purge 清掉了）。
    try:
        from .undo_guard import unregister_undo_handlers
        unregister_undo_handlers()
    except Exception:
        pass
    try:
        from .state import purge_stale_app_handlers
        purge_stale_app_handlers()
    except Exception:
        pass

    for cls in classes:
        bpy.utils.unregister_class(cls)
        

    del bpy.types.WindowManager.rtmp_path_display_enabled
    del bpy.types.WindowManager.rtmp_edit_mode_active
    del bpy.types.WindowManager.rtmp_auto_refresh_active
    # （性能 3 项已迁到 AddonPreferences，见 register() 的说明 ⇒ 不再 del）
    del bpy.types.WindowManager.rtmp_handle_type
    del bpy.types.WindowManager.rtmp_snap
    del bpy.types.WindowManager.rtmp_snap_step
    del bpy.types.WindowManager.rtmp_handle_scale
    
    translations.unregister(__package__)
