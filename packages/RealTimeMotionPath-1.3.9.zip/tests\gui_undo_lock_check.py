# -*- coding: utf-8 -*-
"""撤销 / 重做 之后「锁定状态」与其它内存缓存的一致性（用户 2026-09-19 报）。

症状
----
    双击三角锁定 / 解锁后，**Ctrl+Z 撤销时锁定状态本身不会撤销**。

根因（已在真 GUI 里实测钉死，见 A 组注释）
-----------------------------------------
    锁定状态等 4 张表都是「**内存镜像 + action custom property** 两层存储」，
    查询走「**先查内存、命中即返回**」；而 Blender 的全局 undo 是
    「整个 main database 的快照回滚」——它会正确恢复 property，
    **但碰不到 Python 模块变量** ⇒ 撤销后 property 已回滚、内存还是旧值
    ⇒ 查询返回陈旧结果 ⇒ 用户看到「撤销没生效」。

    真机实测（GUI 里真按 Ctrl+Z）：
        prop_after_undo  : None        ← Blender 确实恢复了
        query_after_undo : False       ← 却仍读内存旧值  ★ 症状复现
        mem_after_undo   : {...False}  ← 内存纹丝不动（真凶）

    四张表（模式完全相同，本次一并收口 —— 只修看得见的那处，切一次就打回原形）：
      · `transform_domain._TRILOCK`            三角「一体 / 分离」 ← 用户本次报的
      · `transform_domain._FEEL`               手柄体感类型
      · `transform_domain._plugin_owned_free`  插件接管的 FREE 名单
      · `time_domain._FROZEN`                  速度编辑冻结登记

解法
----
    挂 `undo_post` / `redo_post`（`undo_guard.py`）⇒ 撤销 / 重做后清空内存缓存，
    下次查询重新从 custom property 惰性 warm 回来。

    为什么「清」是安全的：四张表的 setter 都是「内存 + property **双写**」对称的
    ⇒ 清掉内存不丢数据。

另外修了一处**不对称**（B）
---------------------------
    `toggle_frame_lock` 的「分离 → 锁回一体」分支有显式 `undo_push`，
    「一体 → 分离」分支**没有** ⇒ 分离这一步不形成 undo 步，
    一次 Ctrl+Z 会**越过**它。真机实测：
        · 无 push ⇒ undo 退到更早状态，严重时**连对象一起消失**；
        · 有 push ⇒ undo 回到「一体」、redo 回到「分离」，完美往返。
    已补上对称的 push。

本测试的口径（⚠️ headless 里 `bpy.ops.ed.undo()` 的 poll 会失败，跑不了真 undo）
--------------------------------------------------------------------------------
    用「**模拟 Blender 的 property 回滚 + 调真 undo_post handler**」代替真撤销。
    真撤销本身已在 GUI 里实测（见记忆 / 提交信息），本文件负责**回归保护**。

    A 组：锁定状态 —— 撤销后查询必须反映 **property**，而不是内存
    B 组：另三张表同源覆盖（体感 / 冻结 / FREE 登记）
    C 组：handler 注册 / 注销 / 幂等 / 签名
    D 组：静态契约（register/unregister 接线；分离分支必须有 undo_push）
    E 组：行为 —— 真双击入口确实推了 undo 点（打桩 `bpy.ops.ed.undo_push`）
    F 组：bug 注入必须被抓（含「注入是否真生效」的自检，防打在空气上）
"""
import os
import sys
import json
import inspect
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, interaction as it
from RealTimeMotionPath import time_domain as td, handles as hd, undo_guard as ug
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_undo_lock_result.json")
steps = []

KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))
F0, FM, F1 = 1.0, 25.0, 55.0
UP, DOWN = hd.TRI_UP, hd.TRI_DOWN


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:900]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


def build(name):
    sc = bpy.context.scene
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in KFS:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(1)
    a = o.animation_data.action
    for c in xf._position_curves(a, o, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        c.update()
    bpy.context.view_layer.objects.active = o
    for ob in bpy.data.objects:
        ob.select_set(ob is o)
    return o, a


def mk_handles(frame):
    return [hd.make_handle(frame=float(frame), tri=t, span=24.0, s=td.S_LIN,
                           d=td.s_to_d(td.S_LIN), kf_screen=(100.0, 100.0),
                           kf_world=(0.0, 0.0, 0.0)) for t in (UP, DOWN)]


def center(hs, frame, tri):
    return hd.find_handle(hs, frame, tri)['tri_screen']


def reset_interaction():
    """只清**交互态**（选中 / 双击链），不碰被测的数据。"""
    _session.speed_click_info = None
    _session.clear_speed_handle()


def first_kp(o, frame):
    act = o.animation_data.action
    for c in xf._position_curves(act, o, None):
        for k in c.keyframe_points:
            if abs(float(k.co[0]) - float(frame)) < 1e-3:
                return k
    return None


def sim_undo_rollback(act, prop):
    """模拟 Blender 全局 undo 对 **custom property** 的回滚（删掉该 property）。

    ⚠️ 关键：**只动 property，不动 Python 模块变量** —— 这正是真 undo 的行为，
       也正是 bug 的来源。
    """
    try:
        if prop in act:
            del act[prop]
    except Exception:
        pass


try:
    # ==================================================== A 组：锁定状态
    o, a = build("_UL_A")
    act = o.animation_data.action
    PROP = xf._TRILOCK_PROP

    step("A0 基线：未记录 ⇒ 一体（默认）",
         xf.is_tri_locked(act, FM) is True,
         "is_tri_locked=%s" % xf.is_tri_locked(act, FM))

    hs = mk_handles(FM)
    pos = center(hs, FM, UP)
    reset_interaction()
    it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)            # 第 1 击
    c, m = it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)     # 第 2 击 = 双击
    step("A1 真双击入口 ⇒ 切成「分离」，且持久化写入 property",
         c is True and xf.is_tri_locked(act, FM) is False
         and ("SPLIT" in "".join(str(x) for x in (act.get(PROP) or []))),
         "consumed=%s prop=%s" % (c, list(act.get(PROP) or [])))

    # ---- ★★★ 只回滚 property、**不调任何 handler** ⇒ 查询必须立刻跟上 ----
    #  （v1.3.8 起改为「读之前对账」，不再依赖钩子是否挂在场 —— 见 G 组）
    sim_undo_rollback(act, PROP)
    q2a = xf.is_tri_locked(act, FM)
    step("A2 ★★★【对账】只回滚 property、不调 handler ⇒ 查询立刻回到「一体」",
         q2a is True and (str(act.name), FM) not in xf._TRILOCK,
         "property=%s 查询=%s 内存=%s" % (act.get(PROP), q2a, xf._TRILOCK))

    # ---- A3：走「清缓存」那条路（hook 在场时的路径）同样正确 ----
    act[PROP] = ["%.4f|SPLIT" % FM]
    cleared = ug.clear_all_state_caches()
    q = xf.is_tri_locked(act, FM)
    step("A3 ★★ 清缓存（hook 那条路）之后也正确 ⇒ 回到「分离」",
         q is False, "cleared=%s 查询=%s" % (cleared, q))

    # ---- 反向：property 明写 SPLIT、内存空 ⇒ 清缓存后应 warm 回「分离」----
    act[PROP] = ["%.4f|SPLIT" % FM]
    ug.clear_all_state_caches()
    q2 = xf.is_tri_locked(act, FM)
    step("A4 ★★ 反向（redone 态）：property 有 SPLIT、内存空 ⇒ warm 回「分离」",
         q2 is False, "查询=%s" % q2)

    # ---- 幂等 ----
    ok_idem = True
    try:
        for _ in range(3):
            ug.clear_all_state_caches()
        _ = xf.is_tri_locked(act, FM)
    except Exception:
        ok_idem = False
    step("A5 清缓存幂等（连清 3 次不抛、结果稳定）", ok_idem)

    # ==================================================== B 组：另三张表
    # B1 体感类型
    o2, a2 = build("_UL_B1")
    act2 = o2.animation_data.action
    kp2 = first_kp(o2, FM)
    base_feel = xf.feel_type(kp2, 'left')
    xf.mark_feel(kp2, 'left', 'LINK')
    mid_feel = xf.feel_type(kp2, 'left')
    sim_undo_rollback(act2, xf._FEEL_PROP)
    ug.clear_all_state_caches()
    after_feel = xf.feel_type(kp2, 'left')
    step("B1 ★★ 体感类型（_FEEL）同源：回滚 + 清缓存 ⇒ 回到回滚前的值",
         mid_feel == 'LINK' and after_feel == base_feel,
         "基线=%s 写入后=%s 回滚+清后=%s" % (base_feel, mid_feel, after_feel))

    # B2 冻结登记
    o3, a3 = build("_UL_B2")
    act3 = o3.animation_data.action
    td.mark_frozen(act3, FM)
    froz_mid = td.is_frozen(act3, FM)
    sim_undo_rollback(act3, td._FROZEN_PROP)
    ug.clear_all_state_caches()
    froz_after = td.is_frozen(act3, FM)
    step("B2 ★★ 冻结登记（_FROZEN）同源：回滚 + 清缓存 ⇒ 回到「未冻结」",
         froz_mid is True and froz_after is False,
         "写入后=%s 回滚+清后=%s" % (froz_mid, froz_after))

    # B3 插件接管的 FREE 名单
    o4, a4 = build("_UL_B3")
    act4 = o4.animation_data.action
    kp4 = first_kp(o4, FM)
    xf.mark_owned_free(kp4, 'left')
    own_mid = xf._is_plugin_owned_free(kp4, 'left')
    sim_undo_rollback(act4, xf._OWNED_PROP)
    ug.clear_all_state_caches()
    own_after = xf._is_plugin_owned_free(kp4, 'left')
    step("B3 ★★ FREE 登记（_plugin_owned_free）同源：回滚 + 清缓存 ⇒ 回到未登记",
         own_mid is True and own_after is False,
         "写入后=%s 回滚+清后=%s" % (own_mid, own_after))

    # ==================================================== C 组：handler 接线
    def count_ours(attr):
        lst = getattr(bpy.app.handlers, attr, [])
        if not isinstance(lst, list):
            return -1
        return sum(1 for h in lst
                   if str(getattr(h, "__module__", "")).startswith("RealTimeMotionPath"))

    ug.unregister_undo_handlers()
    ug.register_undo_handlers()
    n_u, n_r = count_ours("undo_post"), count_ours("redo_post")
    step("C1 ★★ register 后本插件在 undo_post / redo_post 各挂 **恰好 1 个**",
         n_u == 1 and n_r == 1, "undo_post=%d redo_post=%d" % (n_u, n_r))

    ug.register_undo_handlers()
    ug.register_undo_handlers()
    n_u2, n_r2 = count_ours("undo_post"), count_ours("redo_post")
    step("C2 ★★ 重复 register 不叠积（跨模块重载也不会）",
         n_u2 == 1 and n_r2 == 1, "undo_post=%d redo_post=%d" % (n_u2, n_r2))

    try:
        nargs = [len(inspect.signature(f).parameters)
                 for f in bpy.app.handlers.undo_post
                 if str(getattr(f, "__module__", "")).startswith("RealTimeMotionPath")]
        sig_ok = all(n >= 1 for n in nargs)
    except Exception:
        sig_ok = False
    step("C3 handler 签名能吃下 Blender 传的 scene 参数（≥1 个形参）",
         sig_ok, "形参个数=%s" % nargs)

    ug.unregister_undo_handlers()
    n_u3 = count_ours("undo_post")
    ug.register_undo_handlers()
    n_u4 = count_ours("undo_post")
    step("C4 ★★ unregister 摘干净 / 再 register 能恢复",
         n_u3 == 0 and n_u4 == 1, "卸载后=%d 重挂后=%d" % (n_u3, n_u4))

    # ★★★ C6 —— 本次的**真凶**回归保护。
    #
    #    `RTMP_OT_PathRefreshDaemon.invoke()`（自动刷新守护进程，进入编辑模式时
    #    被 invoke）里会调 `purge_stale_app_handlers()`；而它无差别地按
    #    `__module__` 前缀扫**所有** handler 列表 ⇒ 把 undo_guard 挂的两个
    #    handler 一并删掉 ⇒ 修复**上线即失效**（用户实机复现：「还是不能撤销」）。
    #
    #    实测（未修时）：purge 一次 ⇒ removed=['redo_post._on_redo_post',
    #                                        'undo_post._on_undo_post']，双双归零。
    from RealTimeMotionPath.state import purge_stale_app_handlers
    ug.register_undo_handlers()
    b_pu, b_pr = count_ours("undo_post"), count_ours("redo_post")
    removed_p = purge_stale_app_handlers()
    a_pu, a_pr = count_ours("undo_post"), count_ours("redo_post")
    hit = [x for x in removed_p if x.startswith(("undo_post", "redo_post"))]
    step("C6 ★★★ `purge_stale_app_handlers()`（守护进程每次 invoke 都调）"
         "**不会**清掉 undo/redo handler —— 防「修复上线即失效」",
         b_pu == 1 and b_pr == 1 and a_pu == 1 and a_pr == 1 and not hit,
         "清前=%s/%s 清后=%s/%s 误删=%s" % (b_pu, b_pr, a_pu, a_pr, hit))

    # C7 连清多次（守护进程反复 invoke）也不掉
    for _ in range(3):
        purge_stale_app_handlers()
    a2_pu, a2_pr = count_ours("undo_post"), count_ours("redo_post")
    step("C7 ★★ 连清 4 次（守护进程反复 invoke）handler 仍恰好各 1 个",
         a2_pu == 1 and a2_pr == 1, "%s/%s" % (a2_pu, a2_pr))

    # C8 unregister 仍能摘干净（证明保护不是「摘不掉」）
    ug.unregister_undo_handlers()
    u_pu, u_pr = count_ours("undo_post"), count_ours("redo_post")
    ug.register_undo_handlers()
    step("C8 ★★ 保护归保护：`unregister_undo_handlers()` 仍能摘干净（0/0）",
         u_pu == 0 and u_pr == 0, "%s/%s" % (u_pu, u_pr))

    step("C5 handler 模块名在包内（⇒ 兜底清理逻辑找得到它们）",
         all(str(getattr(f, "__module__", "")).startswith("RealTimeMotionPath")
             for f in bpy.app.handlers.undo_post
             if str(getattr(f, "__module__", "")).startswith("RealTimeMotionPath")),
         "")

    # ==================================================== D 组：静态契约
    init_src = open(os.path.join(REPO, "__init__.py"), encoding="utf-8").read()
    it_src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()

    i_reg = init_src.find("def register():")
    i_unreg = init_src.find("def unregister():")
    seg_reg = init_src[i_reg:i_unreg] if (i_reg >= 0 and i_unreg > i_reg) else ""
    seg_unreg = init_src[i_unreg:] if i_unreg >= 0 else ""
    step("D1 ★★ `register()` 里挂了 undo handler，且排在 `purge_stale_app_handlers` **之后**",
         "register_undo_handlers()" in seg_reg
         and seg_reg.find("purge_stale_app_handlers()") < seg_reg.find("register_undo_handlers()"),
         "")
    step("D2 ★★ `unregister()` 里摘了 undo handler",
         "unregister_undo_handlers()" in seg_unreg, "")

    # 「一体 → 分离」分支里必须有 undo_push（B 的回归保护）
    # ⚠️ 锚点必须落在**代码**上：函数 docstring 里也写着「一体 → 分离」，
    #    直接 find 那个短语会命中 docstring（实测踩坑：片段只有 179 字符）。
    i_fn = it_src.find("def toggle_frame_lock")
    i_split = it_src.find("xf.set_tri_locked(act, frame, False)", i_fn)
    # ⚠️ 锚点带 `# ` 前缀：否则会命中**新增注释里**引用的同一短语
    #    （实测踩坑：注释「与「分离 → 锁回一体」分支对称」把片段截断成 146 字符）。
    i_lock = it_src.find("# 分离 → 锁回一体", i_split)
    seg_split = it_src[i_split:i_lock] if (0 <= i_split < i_lock) else ""
    step("D3 ★★★ 「一体 → 分离」分支里有 `undo_push`（与锁回一体分支对称）",
         "undo_push" in seg_split,
         "片段长度=%d" % len(seg_split))

    # ==================================================== E 组：行为（真双击确实推了 undo 点）
    o5, a5 = build("_UL_E1")
    act5 = o5.animation_data.action
    hs5 = mk_handles(FM)
    pos5 = center(hs5, FM, UP)
    # ⚠️ 不能直接给 `bpy.ops.ed.undo_push` 赋值 —— 实测（`_diag_push.py`）
    #    `bpy.ops.ed.undo_push = fake` 之后 `is` 判等为 **False**，
    #    即 bpy 的 ops 子模块**不接受属性赋值**，打桩会静默失效。
    #    ⇒ 改用「替换 `it.bpy` 为代理对象」：产品在 interaction 模块里
    #      读的是模块全局 `bpy`，换成代理即可拦到 `ops.ed.undo_push`。
    _calls = []

    class _FakeEd(object):
        def __init__(self, real):
            self._real = real

        def __getattr__(self, name):
            if name == "undo_push":
                def _hook(*args, **kw):
                    _calls.append(kw)
                    return {'FINISHED'}
                return _hook
            return getattr(self._real, name)

    class _FakeOps(object):
        def __init__(self, real):
            self._real = real

        def __getattr__(self, name):
            if name == "ed":
                return _FakeEd(self._real.ed)
            return getattr(self._real, name)

    class _FakeBpy(object):
        def __init__(self, real):
            self._real = real

        def __getattr__(self, name):
            if name == "ops":
                return _FakeOps(self._real.ops)
            return getattr(self._real, name)

    _orig_bpy = it.bpy
    patched = True
    it.bpy = _FakeBpy(bpy)
    try:
        reset_interaction()
        it.try_toggle_tri_lock_click(bpy.context, o5, hs5, pos5)
        it.try_toggle_tri_lock_click(bpy.context, o5, hs5, pos5)
    finally:
        it.bpy = _orig_bpy
    split_happened = (xf.is_tri_locked(act5, FM) is False)
    step("E1 ★★★ 真双击「一体 → 分离」确实推了 undo 点（拦到 `ops.ed.undo_push`）",
         split_happened and len(_calls) == 1,
         "已分离=%s 调用次数=%d kw=%s" % (split_happened, len(_calls), _calls[:1]))

    # ==================================================== F 组：bug 注入
    def _scen_split_rollback():
        _o, _a = build("_UL_F1")
        _act = _o.animation_data.action
        _hs = mk_handles(FM)
        _pos = center(_hs, FM, UP)
        reset_interaction()
        it.try_toggle_tri_lock_click(bpy.context, _o, _hs, _pos)
        it.try_toggle_tri_lock_click(bpy.context, _o, _hs, _pos)
        sim_undo_rollback(_act, xf._TRILOCK_PROP)
        ug.clear_all_state_caches()
        return xf.is_tri_locked(_act, FM) is True

    # F1 ★★（原「注入清缓存失效」如今已失效：**对账**机制接住了它）
    #    ⇒ 改成正面断言：让「清缓存」彻底不干活，结果仍必须正确。
    #      这正说明 hook 不再是**正确性**的依赖（只影响快路径）。
    _orig_cac = ug.clear_all_state_caches
    try:
        ug.clear_all_state_caches = lambda: []
        f1_ok = _scen_split_rollback()
    except Exception:
        f1_ok = False
    finally:
        ug.clear_all_state_caches = _orig_cac
    step("F1 ★★ 「清缓存」完全失效时结果仍正确（对账兜底，hook 非正确性依赖）",
         f1_ok, "")

    def _mk_purge_unprotect():
        """注入②：purge **不排除** undo/redo handler = 本次真凶原样复现"""
        from RealTimeMotionPath import state as _st
        _orig = _st._PURGE_PROTECTED
        return (lambda: setattr(_st, "_PURGE_PROTECTED", ()),
                lambda: setattr(_st, "_PURGE_PROTECTED", _orig),
                "F2 purge 无差别清掉 undo handler（本次真凶）")

    def _scen_purge():
        from RealTimeMotionPath.state import purge_stale_app_handlers
        ug.register_undo_handlers()
        purge_stale_app_handlers()
        return count_ours("undo_post") == 1 and count_ours("redo_post") == 1

    for mk, scen in ((_mk_purge_unprotect, _scen_purge),):
        do, undo, label = mk()
        try:
            do()
            injected = scen()
            undo()
            baseline = scen()
            caught = (not injected) and baseline
            if not injected and not baseline:
                label += "（⚠️ 基线本身失败，无法判断）"
            elif injected:
                label += "（⚠️ 注入未生效 = 打在空气上）"
        except Exception:
            caught = True
            label += "（异常也算抓住）"
            try:
                undo()
            except Exception:
                pass
        step("★ %s ⇒ 测试抓住" % label, caught, "")

    # ==================================================== G 组：★★★ 不依赖 hook 也能对账
    # ★ 用户现场实况（2026-09-19 实测）：会话里 `undo_post` 列表**为空**
    #   ⇒ "挂 hook 清缓存"的方案**失效** —— 用户复现「Ctrl+Z 撤销不了锁定状态」。
    # ⇒ 断言：**撤掉 hook**，只回滚 property，四张表的查询也必须立刻跟上。
    #    这条就是本次真凶的防线（只靠 hook 的方案已证明不够）。
    ug.unregister_undo_handlers()
    step("G0 前提：hook 已撤掉（模拟用户现场）",
         count_ours("undo_post") == 0 and count_ours("redo_post") == 0, "")

    def _no_hook_probe():
        outs = []
        # ① 锁定（走真双击入口）
        o1, a1 = build("_UL_G1")
        hs1 = mk_handles(FM)
        p1 = center(hs1, FM, UP)
        reset_interaction()
        it.try_toggle_tri_lock_click(bpy.context, o1, hs1, p1)
        it.try_toggle_tri_lock_click(bpy.context, o1, hs1, p1)
        w1 = (xf.is_tri_locked(a1, FM) is False)
        sim_undo_rollback(a1, xf._TRILOCK_PROP)
        outs.append(("tri_lock", w1, xf.is_tri_locked(a1, FM) is True))
        # ② 体感
        o2, a2 = build("_UL_G2")
        kp2 = first_kp(o2, FM)
        xf.mark_feel(kp2, 'left', 'LINK')
        w2 = (xf.feel_type(kp2, 'left') == 'LINK')
        sim_undo_rollback(a2, xf._FEEL_PROP)
        outs.append(("feel", w2, xf.feel_type(kp2, 'left') is None))
        # ③ 冻结
        o3, a3 = build("_UL_G3")
        td.mark_frozen(a3, FM)
        w3 = (td.is_frozen(a3, FM) is True)
        sim_undo_rollback(a3, td._FROZEN_PROP)
        outs.append(("frozen", w3, td.is_frozen(a3, FM) is False))
        # ④ 接管名单
        o4, a4 = build("_UL_G4")
        kp4 = first_kp(o4, FM)
        xf.mark_owned_free(kp4, 'left')
        w4 = (xf._is_plugin_owned_free(kp4, 'left') is True)
        sim_undo_rollback(a4, xf._OWNED_PROP)
        outs.append(("owned_free", w4, xf._is_plugin_owned_free(kp4, 'left') is False))
        return outs

    res_g = _no_hook_probe()
    bad_g = [n for n, w, ok in res_g if not (w and ok)]
    step("G1 ★★★【核心·防本次真凶复发】hook 不在场时，回滚 property 后四张表查询全部跟上",
         not bad_g,
         "; ".join("%s(写入=%s,回滚后对=%s)" % t for t in res_g))

    ug.register_undo_handlers()

    # ---- G2 bug 注入：把「对账」打桩成空操作 ⇒ 必须退化回旧 bug，测试要抓住 ----
    def _scen_sync_off():
        """不调 handler、也不清缓存，只回滚 property —— 全靠「对账」兜。"""
        _o, _a = build("_UL_G2i")
        _hs = mk_handles(FM)
        _p = center(_hs, FM, UP)
        reset_interaction()
        it.try_toggle_tri_lock_click(bpy.context, _o, _hs, _p)
        it.try_toggle_tri_lock_click(bpy.context, _o, _hs, _p)
        sim_undo_rollback(_a, xf._TRILOCK_PROP)
        return xf.is_tri_locked(_a, FM) is True

    _orig_sync = xf._trilock_sync
    note = ""
    try:
        xf._trilock_sync = lambda *a, **k: None       # 注入：对账失效
        injected = _scen_sync_off()
        xf._trilock_sync = _orig_sync
        baseline = _scen_sync_off()
        caught = (not injected) and baseline
        if injected:
            note = "（⚠️ 注入未生效 = 打在空气上）"
        elif not baseline:
            note = "（⚠️ 基线失败，无法判断）"
    except Exception:
        caught = True
        note = "（异常也算抓住）"
        try:
            xf._trilock_sync = _orig_sync
        except Exception:
            pass
    step("★ G2 注入「对账失效（_trilock_sync 打桩成空）」 ⇒ 测试抓住 %s" % note, caught, "")

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-1500:])
finally:
    try:
        reset_interaction()
    except Exception:
        pass

try:
    for n in ("_UL_A", "_UL_B1", "_UL_B2", "_UL_B3", "_UL_E1", "_UL_F1",
              "_UL_G1", "_UL_G2", "_UL_G3", "_UL_G4", "_UL_G2i"):
        x = bpy.data.objects.get(n)
        if x:
            bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
