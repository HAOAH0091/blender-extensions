"""RTMP 模态交互骨架（路线 B：自己写 modal）

两条线共用这一套骨架：

    第一条线（变换）：MOVE / ROTATE / SCALE
    第二条线（速度手柄）：SPEED   ← 本版实现

架构
----
    进入键 (J)  →  operator.invoke()  →  modal() 循环  →  确认/取消
                     ↓ 解目标            ↓ 每帧应用          ↓ 收尾

硬限制（实测，见设计存档 §2）
-----------------------------
插件**不能自建 modal keymap**（Blender 报 "Modal key-maps not supported for
add-on key-config"）。因此模态内部子键（X/Y/Z/数字/回车）只能在 modal() 里
手写 `if event.type == ...` 判断，无法开放给用户在偏好设置里改。
触发键（G/R/S/J）用**普通 keymap** 注册，这部分是允许的。

第二线交互（C 模式，2026-09-15 定稿，见设计存档 §16）
---------------------------------------------------
    三角钉在关键帧的【屏幕上下方】；用户沿视口 Y 轴上下拖。
      离路径越远 = 该侧越疏
      离路径越近 = 该侧越密
      停在 1.00x 匀速基准 = 匀速
"""

import bpy
import math

import mathutils
from bpy_extras import view3d_utils

from . import time_domain as td
from . import transform_domain as xf
from . import handles as hd
# ⚠️ 模块级导入（state 只依赖 bpy/mathutils，不会循环）
from .state import _session

try:
    from . import overlay as ov
except Exception as _e:      # 覆盖层缺失不应影响交互本身
    # ⚠️ 必须打印出来：曾经这里静默吞掉一个 ImportError，
    #    结果「覆盖层整个失效」却毫无提示，排查了很久。
    print("RealTimeMotionPath: overlay 模块导入失败 -> %r" % (_e,))
    ov = None

try:
    from .cache import resolve_parent_transform as _resolve_parent_transform
except Exception:      # headless / 依赖缺失时退化
    _resolve_parent_transform = None


def _parent_transform(obj, bone_name=None):
    """关键帧 location 值所在的【父级空间】-> 世界 的变换。

    ⚠️ 不能用 obj.matrix_world —— 它【已包含】物体自身的 location，
       再乘一遍等于把位置加两次（实测踩过：f14 返回了 f40 的值）。
    """
    if _resolve_parent_transform is not None:
        try:
            bone = obj.pose.bones.get(bone_name) if (bone_name and obj.mode == 'POSE') else None
            return _resolve_parent_transform(obj, bone)
        except Exception:
            pass
    if obj.parent is None:
        return mathutils.Matrix.Identity(4)
    return obj.parent.matrix_world @ obj.matrix_parent_inverse


# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

MODE_ITEMS = [
    ('MOVE', "移动", "移动路径点（第一条线）"),
    ('ROTATE', "旋转", "旋转路径点群（第一条线）"),
    ('SCALE', "缩放速度", "缩放速度（第一条线；现有拖拽已具备）"),
    ('SPEED', "采样点疏密", "调整采样点疏密分布（第二条线）"),
]

# 鼠标离关键帧多远以内算"选中"（屏幕像素）
PICK_RADIUS = 80.0

# 旋转 / 缩放的【参考半径】（屏幕像素）
# ⚠️ 不用"支点→鼠标"的实际距离当杠杆：支点（选中点中位点）可能离鼠标很远，
#    鼠标动一百像素只转几度 → 用户以为"没效果"（实测只有 4.45°）。
#    改用切向/径向位移 ÷ 本常量 → 手感与支点距离无关、恒定可预测。
#
# ★★ 2026-09-16 修订：**R（旋转）已不再用这个常量**！
#    用户实测反馈「鼠标只转 5°，手柄却转更多、虚线没紧跟」——
#    根因正是"切向位移 ÷ 150"这个【像素口径】：鼠标绕支点转 θ 时，
#    angle ≈ (R/150)·θ（R = 支点→鼠标屏幕距离），倍率 R/150。
#    实测 R=800px → 5° 被放大成 26.6°。
#    ⇒ R 已改回**角度式**（angle = 鼠标绕支点转过的角，1:1），见 RotateSession.update。
#    本常量现在**只被 S（缩放）与 SPEED（采样点疏密）使用**。
REF_RADIUS = 150.0

# R（旋转）用：鼠标离支点小于这个距离（像素）时，atan2 会剧烈抖动
#   → 该帧不累加角度（虚线端点照常更新）。
_MIN_LEVER_PX = 4.0


# ---------------------------------------------------------------------------
# 模态光标（复刻 Blender 原生体验）—— 2026-09-16
# ---------------------------------------------------------------------------
#
# ▎原生 G/R/S 用什么光标（**实测**，非查源码/推测）
#
#   `_cur_native.py` / `_cur_bmp.py` / `_cur_axis.py` / `_cur_verify.py`
#   —— 用 Windows GetCursorInfo + 位图形状指纹（句柄不稳，见下）测得：
#
#     | 场景                    | 原生光标                  |
#     |-------------------------|---------------------------|
#     | G（自由移动）           | **SCROLL_XY**（四向箭头）  |
#     | G + 按 X/Y/Z锁轴        | **SCROLL_XY（不变）**      |
#     | R（旋转）               | **NONE（隐藏）**           |
#     | S（缩放，op=resize）    | **NONE（隐藏）**           |
#     | 退出模态                | 自动恢复默认（183px 箭头） |
#
#   ⚠️ 「锁轴不改光标」反直觉，所以做了**按键有效性验证**才敢下结论：
#      自由移动 Δ=(-0.343, 0.151, 0.752)；按 X 后 Δ=(-2.279, 0.000, 0.000)
#      → Y/Z 严格归零证明 X 真生效 → 锁轴确实发生了，而光标全程同一个。
#
#   ⚠️ 别用「光标句柄」当指纹：Blender 用的是**自绘光标**，每次 CreateCursor
#      都产出**新句柄**（实测同一名字连设两次 → 句柄完全不同）。
#      稳定特征是**位图内容**（实心像素数 + 重心）。
#
# ▎`cursor_modal_set` / `cursor_modal_restore` 的确切语义（实测 `_cur_sem.py`）
#
#     · set SCROLL_XY → set MOVE_X → **restore** ⇒ 回到"**第一次 set 之前**"
#       （不是回到上一次 set）
#     · 再 restore ×N ⇒ **停住、不报错**（幂等）
#     · 没 set 过就 restore ⇒ **无害**
#     · set NONE（隐藏）→ restore ⇒ 正确恢复
#     ⇒ 所以「进入时 set 一次、退出时 restore 一次」就够；
#       且 restore 幂等 → `_finish` 与 `cancel` 都调也不会出问题。
#
# ▎为什么用 `cursor_modal_*` 而不是 `cursor_set`
#
#   `cursor_modal_*` 是**模态专用**：Blender 自己记着"进入模态前是什么"，
#   restore 时会还原 —— 实测退出后自动回到 DEFAULT 就是这个机制。
#   `cursor_set` 会**永久**改掉用户的光标，不适用。
_CURSOR_FOR_KIND = {
    'MOVE':   'SCROLL_XY',   # 复刻原生 G（四向箭头）
    # ★★ 2026-09-16 修正：R/S **不是** NONE！
    #
    #   我最初的探针测出 R/S 时 GetCursorInfo 的 h=0（系统光标"隐藏"），
    #   就误判成"什么都不显示"，映射写成 NONE。**用户截图推翻了它**：
    #     · R 旋转 → **垂直**双向箭头 ↑↓ + 一条虚线
    #     · S 缩放 → **水平**双向箭头 ←→ + 一条虚线
    #
    #   真相（重新取证，`_shot_S.png` 与 GetCursorInfo 同一时刻）：
    #     **Blender 隐藏系统光标（h=0），然后自己在屏幕上自绘箭头 + 虚线。**
    #   ⇒ 所以"h=0"没错，是我把它的含义读错了。
    #
    #   箭头方向：**旋转 ⊥ 连线（切向）、缩放 ∥ 连线（径向）** —— 即"有效拖动方向"。
    #   实测用户提供的原生截图：R 的虚线 ≈ −15°、箭头 ≈ 75°（垂直）；
    #                            S 的虚线 0°、箭头 0°（平行）。
    #
    #   ★★ 2026-09-16 二次修正（用户反馈：「原生旋转模态的光标会跟随旋转操作一起旋转，
    #      我们的一直保持 Y 轴方向」）—— 系统光标 `MOVE_Y` 是**固定方向**的，
    #      **做不到跟着转**。原生是**隐藏系统光标 + 自绘**（实测 h=0）。
    #      ⇒ R 改为 `'NONE'`（隐藏系统光标），箭头由 `overlay.draw_double_arrow_2d` 自绘，
    #        方向由 `mouse_guide='tangent'` 驱动 → 鼠标绕支点转，箭头跟着转。
    #
    #   ★★ 2026-09-16 三次修正（用户：「确实S也要旋转的，一起做了吧」）——
    #      S 原来用系统光标 `MOVE_X`，它**也不会转**（同样是固定方向），
    #      与 R 现在"自绘会转的箭头"不一致；原生里两者都是自绘。
    #      ⇒ S 一并改为 `'NONE'`（隐藏系统光标）+ `mouse_guide='radial'`（自绘径向箭头）。
    'ROTATE': 'NONE',        # 隐藏系统光标 + 自绘「切向」箭头（⊥ 连线，随鼠标转）
    'SCALE':  'NONE',        # 隐藏系统光标 + 自绘「径向」箭头（∥ 连线，随鼠标转）
    # ★ 插件自有：J / 选中速度三角后按 G,S ——「上下拖调采样点疏密」
    #   原生没有对应物（我们自己的功能），选用语义最贴的**垂直**双向箭头。
    'SPEED':  'MOVE_Y',
}


def _cursor_kind_of(session):
    """从会话对象推导「光标类别」—— **唯一判据**。

    ⚠️ 这里用 `type(x).__name__`（**精确类名**），不用 `isinstance`。
       原因（实测 2026-09-16）：`ScaleSession` 继承自 `RotateSession`，于是

         isinstance(ScaleSession('SCALE'), RotateSession)  ->  **True**   ← 有陷阱
         type(ScaleSession('SCALE')).__name__              ->  'ScaleSession'  ← 无陷阱

       ⇒ 用 `isinstance` 判「是不是 RotateSession」会把**缩放误判成旋转**；
         用精确类名就没这个问题 —— 所以下面的分支**顺序不影响结果**
         （实测：把 Scale/Rotate 两行对调，测试仍全绿）。

       （📌 此处原注释写"判断顺序要紧"是**错的**，已更正 —— 那是 `isinstance`
         才有的问题。若将来有人把这里改成 isinstance，必须先判 Scale。）
    """
    if session is None:
        return None
    cn = type(session).__name__
    if cn == 'ScaleSession':
        return 'SCALE'
    if cn == 'RotateSession':
        return 'ROTATE'
    if cn == 'MoveSession':
        return 'MOVE'
    # ModalSession 自带 mode（'SPEED' / 'MOVE' / ...）
    return str(getattr(session, 'mode', '') or '')


def set_modal_cursor(context, session):
    """进入模态后设置光标。返回是否设置成功。

    失败**静默**：背景模式（--background）没有 window，
    或将来某版 Blender 移除该 API，都不应让模态起不来。
    """
    name = _CURSOR_FOR_KIND.get(_cursor_kind_of(session))
    if not name:
        return False                     # 未定义的类别 → 保持 Blender 默认
    try:
        win = getattr(context, 'window', None)
        if win is None:
            return False
        win.cursor_modal_set(cursor=name)
        return True
    except Exception:
        return False


def restore_modal_cursor(context):
    """退出模态时恢复光标。

    **幂等**（实测：没 set 过也安全、重复调用无副作用），
    所以 `_finish` 与 `cancel` 都调没有风险。失败静默。
    """
    try:
        win = getattr(context, 'window', None)
        if win is None:
            return False
        win.cursor_modal_restore()
        return True
    except Exception:
        return False


# 屏幕垂直方向的"侧"判定：鼠标在关键帧下方 -> 下三角 -> 右侧段
SIDE_BELOW = 'right'
SIDE_ABOVE = 'left'


# ---------------------------------------------------------------------------
# 目标解析（可 headless 测试的部分放 time_domain，这里只做视图相关）
# ---------------------------------------------------------------------------

def _keyframes_of(act, obj, bone_name=None):
    frames = set()
    for fc in td._collect_position_curves(act, obj, bone_name):
        for kp in fc.keyframe_points:
            frames.add(round(float(kp.co[0]), 4))
    return sorted(frames)


def keyframe_world_pos(act, obj, frame, bone_name=None):
    """关键帧对应的世界位置（仅 OBJECT 模式；骨骼留待后续）"""
    vals = {}
    for fc in td._collect_position_curves(act, obj, bone_name):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - frame) < 1e-3:
                vals[fc.array_index] = kp.co[1]
                break
    if len(vals) < 3:
        return None
    local = mathutils.Vector((vals[0], vals[1], vals[2]))
    return _parent_transform(obj, bone_name) @ local


def _screen_pos(region, rv3d, world):
    return view3d_utils.location_3d_to_region_2d(region, rv3d, world)


def resolve_speed_target(context, obj, act, mouse_x, mouse_y):
    """按鼠标屏幕位置找目标：最近的【关键帧】+ 由上下位置决定的【侧】。

    返回 dict 或 None：
        {frame, side, kf_map, span, screen_x, screen_y, dist}
    """
    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None:
        return None

    mouse = mathutils.Vector((mouse_x, mouse_y))
    best = None
    for f in _keyframes_of(act, obj):
        wp = keyframe_world_pos(act, obj, f)
        if wp is None:
            continue
        sp = _screen_pos(region, rv3d, wp)
        if sp is None:
            continue
        d = (sp - mouse).length
        if best is None or d < best[0]:
            # ⚠️ 必须把 wp 一起存进 best。
            #    只存 (d, f, sp) 再在循环外用 wp，会拿到【最后一次迭代】的值
            #    （即最后一个关键帧），标记就会画到错误的位置。
            best = (d, f, sp, wp)
    if best is None or best[0] > PICK_RADIUS:
        return None

    dist, frame, sp, wp = best
    # Blender 的 mouse_region_y 向上为正：鼠标 y 小于关键帧 y => 在下方
    side = SIDE_BELOW if mouse_y < sp.y else SIDE_ABOVE

    kf_map, span = td.resolve_target(act, obj, frame, side)
    err = None if (kf_map and span is not None) else "端点段没有相邻关键帧，无法调整"
    return make_target(frame, side, span, kf_map, sp.x, sp.y, dist, wp, err)


# ---------------------------------------------------------------------------
# 目标描述（所有解析路径【必须】经由 make_target 构造，保证 dict 同构）
# ---------------------------------------------------------------------------

TARGET_KEYS = ("frame", "side", "span", "kf_map",
               "screen_x", "screen_y", "dist", "bone_name", "world", "error")


def make_target(frame, side, span, kf_map, screen_x, screen_y,
                dist=0.0, world=None, error=None, bone_name=None):
    """构造"模态目标"描述。

    ⚠️ **唯一构造入口**。`resolve_speed_target`（按鼠标找）与
       `_resolve_target_preferring_selection`（用选中的三角）都必须走这里，
       否则两条路径的 dict 形状会漂移 ——
       实测踩过：选中三角那条路径漏了 `kf_map`，一按 G 就 KeyError。
    """
    return {
        "frame": frame,
        "side": side,
        "span": span,
        "kf_map": kf_map,
        "screen_x": screen_x,
        "screen_y": screen_y,
        "dist": dist,
        "bone_name": bone_name,
        "world": world,
        "error": error,
    }


def handle_endpoint_world_pos(act, obj, frame, side, bone_name=None):
    """某关键帧【某一侧手柄端点】的世界位置。

    手柄端点在"值空间"的坐标 = 该轴手柄的值分量（handle_left[1] / handle_right[1]）。
    三个轴各取一个值 → 组成三维点 → 过父级变换 → 世界坐标。
    """
    vals = {}
    for fc in td._collect_position_curves(act, obj, bone_name):
        for kp in fc.keyframe_points:
            if abs(kp.co[0] - float(frame)) < 1e-3:
                h = kp.handle_left if side == 'left' else kp.handle_right
                vals[fc.array_index] = float(h[1])
                break
    if not vals:
        return None
    v = [0.0, 0.0, 0.0]
    for a, val in vals.items():
        if 0 <= a <= 2:
            v[a] = val
    return _parent_transform(obj, bone_name) @ mathutils.Vector(v)


def _transform_targets(obj, act, bone_name=None):
    """决定 G/R/S 作用在【手柄端点】还是【关键帧点】。

    原生曲线编辑的语义：**控制点与手柄是各自独立**的可选中/可变换对象
    （见 Blender 手册 Curve Editing："both control points and handles"）。
    所以：用户选中了端点 → 就变换端点；否则变换关键帧点。

    返回 (frames, endpoints, only_handles)
    """
    eps = list(getattr(_session, "selected_handle_endpoints", None) or [])
    if eps:
        return {}, eps, True
    frames = xf.collect_selected_frames(act, obj, bone_name)
    return frames, [], False


def _zero_eps_for_session(session):
    """把「屏幕视觉零」换算成【世界】长度，供封口闸门用 —— 见 `drawing.world_eps_for_screen`。

    ★★ 2026-09-17：端点模态（G/R/S）路径原本**没接这个口径**，于是沿用
    `xf._ARM_EPS`(1e-9 世界)，与空心圆判据（屏幕 6px）差 6 个数量级：
    用户把两侧手柄缩到关键帧点（长度 ~1e-3 世界）后一拖，对侧 ALIGNED
    就被封口成 FREE（用户实测反馈"还是会自动改成 free"）。

    ⚠️ 会话上优先用 `session.context`（modal 每个事件都刷新它）；
    没有就退回 `bpy.context`。拿不到视图时返回 None ⇒ 调用方走默认 `_ARM_EPS`。
    """
    try:
        from .drawing import world_eps_for_screen
        ctx = getattr(session, "context", None) or bpy.context
        obj = getattr(session, "obj", None)
        ref = None
        if obj is not None:
            try:
                ref = obj.matrix_world.translation.copy()
            except Exception:
                ref = None
        if ref is None:
            ref = mathutils.Vector((0.0, 0.0, 0.0))
        return world_eps_for_screen(ctx, ref)
    except Exception:
        return None


def _apply_xf(session, fn=None, delta=None, only_handles=None, time_scale=None):
    """统一的变换派发（G/R/S 共用）。

    `time_scale`：手柄时间分量（dt）的缩放因子（None = 不动，历史行为）。
                  仅 S 的单点缩放传入，用来**保速**（见 apply_point_transform）。

    ★ 端点模式走 `apply_endpoint_transform`：
        · 只变换【选中的那些端点】，不碰对侧
        · 并按原生语义维护对侧手柄（ALIGNED 共线 / FREE 不动 / AUTO 交给 Blender）
      —— 修的是用户实测的两个问题：
         「G 移动后本来 aligned 的手柄有折角了」
         「S 旋转选中的端点，旋转的却是对向的端点」

    非端点模式（关键帧点）走原来的通路。
    """
    only = (bool(getattr(session, "only_handles", False))
            if only_handles is None else bool(only_handles))
    if only:
        eps = list(getattr(session, "endpoints", None) or [])
        if not eps:
            return False

        def _fn(_f, v):
            return fn(_f, v) if fn is not None else (v + delta)

        ok = xf.apply_endpoint_transform(
            session.act, session.obj, session.snapshot, _fn, eps, session.bone_name,
            zero_eps=_zero_eps_for_session(session), time_scale=time_scale)
        # ★ D1：收走"为可写而临时转 FREE 的类型"，供 restore 时恢复
        conv = xf.take_converted_types()
        if conv:
            session._converted_types = conv
        return ok
    if fn is not None:
        return xf.apply_point_transform(session.act, session.obj, session.snapshot,
                                        fn, session.bone_name,
                                        time_scale=time_scale)
    return xf.apply_translation(session.act, session.obj, session.snapshot,
                                delta, session.bone_name)


def _target_pivot(act, obj, frames, endpoints, bone_name=None):
    """变换支点 = 目标物的中位点。"""
    pts = []
    if endpoints:
        # ⚠️ 端点模式的支点用【对应的控制点 co】(2026-09-16)
        #    若用"端点自身"：单端点旋转 = 绕自己转 = 恒等变换（用户会觉得"没反应"）
        #    用 co 作支点：单端点 R 就是"把这个手柄绕它的关键帧点转" —— 正是用户要的
        for (f, _s) in endpoints:
            wp = keyframe_world_pos(act, obj, f, bone_name)
            if wp is not None:
                pts.append(wp)
    else:
        for f in sorted(frames.keys()) if isinstance(frames, dict) else frames:
            wp = keyframe_world_pos(act, obj, f, bone_name)
            if wp is not None:
                pts.append(wp)
    if not pts:
        return None
    acc = mathutils.Vector((0.0, 0.0, 0.0))
    for p in pts:
        acc += p
    return acc / len(pts)


def _clear_point_drag_state():
    """模态接管时，把 path_point_drag 的临时拖拽状态清干净。

    否则 `speed_drag_active` 可能残留为 True，导致模态结束后
    鼠标一动就继续改疏密（"卡住"类 bug）。
    """
    try:
        from .state import _session
        _session.speed_drag_active = False
        _session.drag_in_progress = False
        _session.handle_edit_in_progress = False
    except Exception:
        pass


def _selected_speed_handle():
    """读"已被选中的速度三角"（由 path_point_drag 维护在 _session 上）。

    这样用户先点选三角、再把鼠标移开按 J，模态仍作用在那个三角上。
    """
    try:
        from .state import _session
        f = getattr(_session, "selected_speed_frame", None)
        t = getattr(_session, "selected_speed_tri", None)
        if f is None or t is None:
            return None
        return f, t
    except Exception:
        return None


def _resolve_target_preferring_selection(context, obj, act, mouse_x, mouse_y):
    """优先用【已选中的三角】作为模态目标（**支持多选**）；没有选中才按鼠标位置找。

    返回：单个 target dict，或 **target 列表**（多选时）——
          `ModalSession.begin` 两种都接受。

    ⚠️ 返回的 dict 必须与 `resolve_speed_target` **完全同构** ——
       调用方会直接取 `kf_map` / `span` / `side` / `world`。
       少一个键就是 KeyError（实测踩过：漏了 `kf_map`，一选中三角按 G 就崩）。
    """
    sels = list(getattr(_session, "selected_speed_handles", None) or [])
    if not sels:
        one = _selected_speed_handle()
        if one is not None:
            sels = [one]
    if sels:
        out = []
        region = getattr(context, "region", None)
        rv3d = getattr(context, "region_data", None)
        for (frame, tri) in sels:
            side = hd.SIDE_BY_TRI.get(tri)
            if not side:
                continue
            kf_map, span = td.resolve_target(act, obj, frame, side)
            if not kf_map or span is None:
                continue
            wp = keyframe_world_pos(act, obj, frame)
            sp = None
            if region is not None and rv3d is not None and wp is not None:
                sp = _screen_pos(region, rv3d, wp)
            out.append(make_target(frame, side, span, kf_map,
                                   sp.x if sp else mouse_x,
                                   sp.y if sp else mouse_y,
                                   0.0, wp, None))
        if out:
            # 单目标 → 返回 dict（保持向后兼容）；多目标 → 返回列表
            return out[0] if len(out) == 1 else out
    return resolve_speed_target(context, obj, act, mouse_x, mouse_y)


def keyframe_screens(act, obj, region, rv3d, bone_name=None):
    """{frame: (screen_x, screen_y)} —— 用于悬停/命中检测。"""
    if region is None or rv3d is None:
        return {}
    out = {}
    for f in _keyframes_of(act, obj, bone_name):
        wp = keyframe_world_pos(act, obj, f, bone_name)
        if wp is None:
            continue
        sp = _screen_pos(region, rv3d, wp)
        if sp is not None:
            out[f] = (sp.x, sp.y)
    return out


def _refresh_session_handles(context, obj, act, session):
    """让覆盖层显示【当前模态正在操作的所有三角】（多选时全部显示）。"""
    targets = getattr(session, "targets", None) or ([session.target] if session.target else [])
    if ov is None or session is None or not targets:
        return
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return
    try:
        recs = collect_speed_handles(act, obj, region, rv3d)
    except Exception:
        return
    keys = set()
    for t in targets:
        tri = hd.TRI_BY_SIDE.get(t.get("side"))
        if tri is not None:
            keys.add((t.get("frame"), tri))
    vis = [r for r in recs if (r["frame"], r["tri"]) in keys]
    running = getattr(session, "state", None) == STATE_RUNNING
    # ★ 2026-09-18：把"分离"帧一起传下去（空心三角的外观）
    splits = set()
    for r in recs:
        try:
            f = round(float(r.get("frame")), 4)
        except Exception:
            continue
        if f in splits:
            continue
        try:
            if not xf.is_tri_locked(act, f):
                splits.add(f)
        except Exception:
            continue
    ov.get_overlay().set_handles(vis, list(keys), dragging=running,
                                 split_frames=splits)
    # ★ 多选时每个目标的路径段都高亮（用户 2026-09-16）
    groups = []
    for tgt in targets:
        side_ = tgt.get("side")
        if side_ is None:
            continue
        km = td.collect_frame_keyframes(act, obj, tgt.get("frame"),
                                        tgt.get("bone_name"))
        s_now = None
        if km:
            try:
                s_now = td.read_s(next(iter(km.values())), tgt["span"], side_)
            except Exception:
                s_now = None
        groups.append((tgt.get("frame"), side_, td.extremeness(s_now),
                       bool(s_now is not None and s_now > td.S_LIN)))
    ov.set_segment_highlights(groups)


def collect_speed_handles(act, obj, region, rv3d, bone_name=None):
    """当前视图下所有【可编辑】的速度手柄记录（已带 ratio，供绘制/命中）。"""
    if region is None or rv3d is None:
        return []

    def resolve(f, side):
        return td.resolve_target(act, obj, f, side, bone_name)

    def read_s(kf_map, span, side):
        return td.read_s(next(iter(kf_map.values())), span, side)

    def project(wp):
        return _screen_pos(region, rv3d, wp)

    def world_of(f):
        return keyframe_world_pos(act, obj, f, bone_name)

    recs = hd.collect_handles(_keyframes_of(act, obj, bone_name),
                              resolve, read_s, td.s_to_d, project, world_of)
    for r in recs:
        r['ratio'] = hd.ratio_of(r['s'], td.S_LIN)
        r['extremeness'] = td.extremeness(r['s'])
        # 供覆盖层"每帧现算世界位置"用 —— 否则拖动关键帧后三角会留在原地
        r['obj_name'] = obj.name
        r['bone_name'] = bone_name
    return recs


# ---------------------------------------------------------------------------
# 会话（纯逻辑，可 headless 测试；operator 只是薄壳）
# ---------------------------------------------------------------------------

STATE_IDLE = 'IDLE'
STATE_RUNNING = 'RUNNING'
STATE_DONE = 'DONE'


def snapshot_handles(kf_map):
    snap = {}
    for ax, kp in kf_map.items():
        snap[ax] = {
            'hl': tuple(kp.handle_left),
            'hr': tuple(kp.handle_right),
            'hlt': kp.handle_left_type,
            'hrt': kp.handle_right_type,
        }
    return snap


class ModalSession:
    """模态编辑会话状态机。

    begin() -> RUNNING -> (confirm | cancel) -> DONE
    """

    def __init__(self, mode='SPEED'):
        self.mode = mode
        self.state = STATE_IDLE
        self.obj = None
        self.act = None
        self.bone_name = None       # ★ 供 write_s 找邻居关键帧用（缺了会 AttributeError）
        self.target = None
        self.targets = []           # ★ 多目标（多选三角 → 一起滑移）
        self.tri = None
        self.d_start = td.CV_MID
        self.snapshot = None
        self.start_mouse = (0.0, 0.0)
        self.px_offset = 0.0
        self.precision = False        # Shift 精度（增量累积）
        self._last_raw_px = 0.0
        self.numeric = ""
        self.last_s = None
        self.message = ""
        self.marker_world = None      # 目标关键帧世界位置（供覆盖层画标记）
        # 三角【固定不动】→ 拖拽改为【相对量】：从当前值起算（用户 2026-09-15）
        self.tri = None
        self.d_start = td.CV_MID
        self.numeric = ""          # 数字输入缓冲（显示用）
        # ★★ 2026-09-18（乙方案）："一体"模态下两侧共用的 s 基准（见 begin/apply）
        self.group_s_base = None
        self.group_frame = None

    # ---------------- begin ----------------

    def begin(self, obj, act, mouse_x, mouse_y, target_resolver,
              drag_mode='vertical'):
        """target_resolver(mx, my) -> target dict | None"""
        self.obj = obj
        self.act = act
        self.start_mouse = (mouse_x, mouse_y)
        self.px_offset = 0.0
        self._last_raw_px = 0.0
        self.precision = False
        self.last_s = None
        self.message = ""

        if self.mode != 'SPEED':
            self.message = "模式 '%s' 尚未实现（骨架已就绪）" % self.mode
            self.state = STATE_IDLE
            return False

        resolved = target_resolver(mouse_x, mouse_y)
        # ★ 支持**多目标**（用户 2026-09-16：多选三角后一起滑移）
        targets = resolved if isinstance(resolved, list) else ([resolved] if resolved else [])
        targets = [t for t in targets if t and not t.get("error")]
        if not targets:
            err = None
            if isinstance(resolved, dict):
                err = resolved.get("error")
            self.message = err or "鼠标附近没有关键帧"
            self.state = STATE_IDLE
            return False
        # 记录骨骼名（POSE 模式下才非空）——write_s 找邻居关键帧要用
        self.bone_name = targets[0].get("bone_name")

        # ★★ 2026-09-18（用户拍板乙方案）：**「一体」模态 = 一个旋钮**
        #
        #   选中集恰好是"同一个锁定帧的两个三角" ⇒ 两边必须写**同一个 s**
        #   （一起变快 / 一起变慢）。否则两侧 span 不同会让速度分道扬镳。
        #   判定与 `interaction` 侧共用同一套（`xf.is_tri_locked` + 实际三角数）。
        self.group_s_base = None
        self.group_frame = None
        _frames = {}
        for t in targets:
            try:
                _frames.setdefault(round(float(t.get("frame")), 4), []).append(t)
            except Exception:
                continue
        for _f, _ts in _frames.items():
            if len(_ts) < 2:
                continue
            try:
                if not xf.is_tri_locked(act, _f):
                    continue
            except Exception:
                continue
            # 两个三角都在 + 该帧是一体 ⇒ 记录共用 s 基准（取第一个目标的当前 s）
            _s0 = td.read_s(next(iter(_ts[0]["kf_map"].values())),
                            _ts[0]["span"], _ts[0]["side"])
            if _s0 is not None:
                self.group_s_base = float(_s0)
                self.group_frame = _f
            break

        self.targets = []
        for t in targets:
            s0 = td.read_s(next(iter(t["kf_map"].values())), t["span"], t["side"])
            # ★★ 2026-09-19：起点用 **unclamped** d（保持可逆；钳制版会让
            #   "GE 里拖过手柄后一动就打满/拖不动"—— 2026-09-17 用户实测报告）。
            self.targets.append(
                dict(t,
                     d_start=(td.s_to_d_unclamped(s0) if s0 is not None else td.CV_MID),
                     tri=hd.TRI_BY_SIDE.get(t.get("side"))))
        self.target = self.targets[0]          # 兼容：主目标
        self.snapshot = snapshot_handles(self.targets[0]["kf_map"])
        self.last_s = td.read_s(next(iter(self.targets[0]["kf_map"].values())),
                                self.targets[0]["span"], self.targets[0]["side"])
        # 供覆盖层画标记（关键帧世界位置）
        self.marker_world = self.targets[0].get("world")
        self.tri = self.targets[0].get("tri")
        self.d_start = self.targets[0]["d_start"]

        # ★ 拖拽语义（用户 2026-09-16）
        #   · 'vertical'（按 G）：上下拖 —— 每个三角按各自疏密方向滑移
        #   · 'radial'  （按 S）：径向拖 —— 往外 = 放大 = 变疏（橙线扩散）
        #                                       往里 = 缩小 = 变密（蓝线聚拢）
        self.drag_mode = drag_mode
        self.start_dist = None
        if drag_mode == 'radial':
            pts = [(t.get("screen_x"), t.get("screen_y")) for t in self.targets]
            pts = [(a, b) for (a, b) in pts if a is not None and b is not None]
            if pts:
                self.pivot_screen = (sum(p[0] for p in pts) / len(pts),
                                     sum(p[1] for p in pts) / len(pts))
                self.start_dist = math.hypot(mouse_x - self.pivot_screen[0],
                                             mouse_y - self.pivot_screen[1])
            # ⚠️ 只在"完全拿不到 pivot"时才降级。
            #    曾经用"start_dist < 20 就降级"→ 但按 S 时鼠标本来就点在三角附近
            #    （三角距关键帧仅 26px），会被误判 → 缩放语义失效（实测抓到）。
            #    且 `raw = cur - start` 在 start≈0 时依然稳定（= 距离本身）。
            if self.start_dist is None:
                self.drag_mode = 'vertical'
        self.state = STATE_RUNNING
        return True

    # ---------------- update ----------------

    def update(self, mouse_x, mouse_y):
        """返回 True 表示有改动。

        三角【固定不动】→ 用【相对位移】驱动：
        往"远离关键帧"的方向拖 = 更疏（见 handles.drag_delta_px）。
        """
        if self.state != STATE_RUNNING:
            return False
        # 位移量：竖直（G）或径向（S，缩放语义）
        if getattr(self, "drag_mode", 'vertical') == 'radial' and self.start_dist is not None:
            cur = math.hypot(mouse_x - self.pivot_screen[0],
                             mouse_y - self.pivot_screen[1])
            raw = cur - self.start_dist          # 往外为正 = 放大 = 变疏
        else:
            raw = float(mouse_y) - float(self.start_mouse[1])
        # ⚠️ 精度模式必须【增量累积】：总量法下按 Shift 会把已走过的位移也乘 0.1 → 跳变
        delta = raw - self._last_raw_px
        self._last_raw_px = raw
        if abs(delta) > 1e-9:
            scale = xf.PRECISION_FACTOR if self.precision else 1.0
            self.px_offset += delta * scale
        return self.apply()

    def set_precision(self, on):
        """Shift 精度（用户 2026-09-16 要求 ③：三角也支持 Shift 精度）。"""
        self.precision = bool(on)

    def reset_numeric(self):
        """数字输入"重置"：位移归零（回到进入模态时的状态）。"""
        self.px_offset = 0.0
        self._last_raw_px = 0.0
        return self.apply()

    def _fresh_kf_map(self):
        """每次写操作都【重新收集】关键帧。

        ⚠️ 必须这样做：实测发现，缓存下来的 keyframe 对象在一次写入之后就
           「钝」了 —— 后续再对着同一个对象赋值，Python 侧读回是新值，
           但场景数据纹丝不动（表现为「取消后无法恢复」的诡异 bug）。
           每次重新收集拿到的才是活对象。
        """
        tgt = self.target
        if not tgt:
            return {}
        return td.collect_frame_keyframes(self.act, self.obj,
                                          tgt["frame"], tgt.get("bone_name"))

    def apply(self):
        """对**所有目标**应用当前位移（多选三角 → 一起滑移，用户 2026-09-16）。"""
        targets = getattr(self, "targets", None) or ([self.target] if self.target else [])
        if not targets:
            return False
        # ★★ 2026-09-19（用户拍板，语义修正）：一体模态 ⇒ **统一方向**，
        #   但各目标按**自己的 s** 起算 ⇒ 两侧各加减同一个增量、**差异保留**。
        #   （旧行为「所有目标写同一个 s」= 抹平差异，已被用户推翻。）
        _gbase = getattr(self, "group_s_base", None)
        _is_radial = (getattr(self, "drag_mode", 'vertical') == 'radial')
        # 方向约定：竖直（G）用"上=更疏"；径向（S）往外 = 放大 = 变疏。
        # ⚠️ 不能用各目标自己的 DIR —— 那会让两侧一个变疏一个变密。
        _group_delta = None
        if _gbase is not None:
            _group_delta = (self.px_offset if _is_radial
                            else self.px_offset * hd.DIR_BY_TRI.get(hd.TRI_UP, 1.0))

        ok_any = False
        for tgt in targets:
            # ⚠️ 每次写操作都【重新收集】关键帧（缓存的包装对象会「钝」）
            kf_map = td.collect_frame_keyframes(self.act, self.obj,
                                               tgt["frame"], tgt.get("bone_name"))
            if not kf_map:
                continue
            if _group_delta is not None:
                # ★ 一体：**统一增量**，基准 = 按下时的固定 `d_start`（unclamped）。
                #   ⚠️ 不能每帧现读"当前值"：`px_offset` 是【累积】位移，
                #     那样会双重累加 ⇒ 拖久了漂移（用户零容忍的"跳变"）。
                d = tgt.get("d_start", self.d_start) + _group_delta
            else:
                # 位移解释：
                #   vertical（G）→ 各目标按【自己的三角方向】解释同一个竖直位移
                #   radial  （S）→ 径向位移对所有三角【同向】：往外 = 放大 = 变疏
                if _is_radial:
                    delta = self.px_offset
                else:
                    delta = self.px_offset * hd.DIR_BY_TRI.get(tgt.get("tri"), 1.0)
                d = tgt.get("d_start", self.d_start) + delta
            s = td.d_to_s(d)
            # 传 act/obj：write_s 需要它们冻结【邻居关键帧】（否则对侧路径会变形）
            written = td.write_s(kf_map, tgt["side"], s, tgt["span"],
                                 act=self.act, obj=self.obj, bone_name=self.bone_name)
            if written is not None:
                ok_any = True
            self._refresh_curves(kf_map)
        # last_s 取主目标（供状态栏）
        first = targets[0]
        km0 = td.collect_frame_keyframes(self.act, self.obj, first["frame"],
                                        first.get("bone_name"))
        if km0:
            self.last_s = td.read_s(next(iter(km0.values())), first["span"], first["side"])
        return ok_any

    def _refresh_curves(self, kf_map=None):
        if not self.target:
            return
        axes = kf_map if kf_map else (self.target.get("kf_map", {}) or {})
        for ax in axes:
            fc = td.fcurve_of(self.act, self.obj, ax)
            if fc:
                fc.update()
        try:
            self.obj.update_tag()
        except Exception:
            pass

    # ---------------- finish ----------------

    def confirm(self):
        self.state = STATE_DONE
        return True

    def cancel(self):
        self.restore()
        self.state = STATE_DONE
        return True

    def restore(self):
        if not self.snapshot or not self.target:
            return
        kf_map = self._fresh_kf_map()      # ⚠️ 必须重新收集（见 _fresh_kf_map）
        for ax, snap in self.snapshot.items():
            kp = kf_map.get(ax)
            if kp is None:
                continue
            kp.handle_left = snap['hl']
            kp.handle_right = snap['hr']
            kp.handle_left_type = snap['hlt']
            kp.handle_right_type = snap['hrt']
        self._refresh_curves(kf_map)

    # ---------------- 状态栏 ----------------

    def status_text(self):
        if self.mode != 'SPEED':
            return self.mode
        multi = ""
        n = len(getattr(self, "targets", []) or [])
        if n > 1:
            multi = "  [多选 %d 个]  " % n
        howto = ("往外拖放大(变疏) · 往里拖缩小(变密)"
                 if getattr(self, "drag_mode", 'vertical') == 'radial'
                 else "上下拖调整")
        if self.state == STATE_RUNNING and self.target and self.last_s:
            ratio = td.S_LIN / self.last_s
            side_name = "左段" if self.target["side"] == 'left' else "右段"
            return ("采样点%s%s | 关键帧 %s %s | s=%.3f  相对匀速 %.2fx   |  "
                    "%s · Shift 精度 · 左键/回车 确认 · 右键/ESC 取消"
                    % ("缩放" if getattr(self, "drag_mode", 'vertical') == 'radial'
                       else "疏密",
                       multi, int(self.target["frame"]), side_name,
                       self.last_s, ratio, howto))
        return ("采样点疏密%s | %s · Shift 精度 · "
                "左键/回车 确认 · 右键/ESC 取消" % (multi, howto))


# ---------------------------------------------------------------------------
# 变换会话（第一条线：G 移动 / R 旋转 / S 缩放）
# ---------------------------------------------------------------------------

class MoveSession:
    """G：移动【选中的路径点】。

    与 ModalSession（SPEED）的关键差别：

        SPEED  改 handle[0]（时间分量）→ **不改路径形状**
        MOVE   改关键帧位置（值分量）  → **改路径形状**（这本就是 G 的语义）

    两者是独立的两条线，互不干涉。

    跟手原理（与 Blender 原生一致）：
        把鼠标起始点与当前点，分别投影到【过 pivot、且平行于屏幕】的平面上，
        两者的世界空间差值 = 要施加的平移量。
    """

    def __init__(self, mode='MOVE'):
        self.mode = mode               # MOVE / ROTATE / SCALE
        self.state = STATE_IDLE
        self.obj = None
        self.act = None
        self.bone_name = None
        self.region = None
        self.rv3d = None
        self.parent_matrix = None

        self.frames = {}               # {frame: {axis: fcurve}}
        self.endpoints = []            # 手柄端点模式（原生：端点可独立变换）
        self.only_handles = False
        self.snapshot = None           # 起始位置（供 apply / restore）
        self.pivot_world = None
        self.start_world = None
        self.last_world = None         # ★ 上一帧的鼠标世界位置（增量法用）
        self.start_mouse = (0.0, 0.0)

        # ★ 原始累积位移（未施加精度 / 未约束）。
        #   精度只作用在【每帧增量】上并累积 —— 不能对总量乘系数，
        #   否则一按 Shift 就把之前的位移也砍到 10% → 物体跳回（实测抓到的 bug）。
        self.accum = mathutils.Vector((0.0, 0.0, 0.0))
        self.offset = mathutils.Vector((0.0, 0.0, 0.0))   # 实际生效的世界偏移
        self.axis_lock = None          # 'X' / 'Y' / 'Z'
        self.plane_lock = None         # ('X','Y') 等
        self.precision = False         # Shift 精度
        self.message = ""

    # ---------------- begin ----------------

    def begin(self, obj, act, region, rv3d, mouse_x, mouse_y, bone_name=None):
        self.obj = obj
        self.act = act
        self.bone_name = bone_name
        self.region = region
        self.rv3d = rv3d
        self.start_mouse = (mouse_x, mouse_y)
        self.message = ""
        self.axis_lock = None
        self.plane_lock = None
        self.axis_orientation = 'GLOBAL'   # 原生：按两次同轴键 → 全局 ↔ 局部
        self.precision = False
        self.offset = mathutils.Vector((0.0, 0.0, 0.0))

        if self.mode != 'MOVE':
            self.message = "模式 '%s' 尚未实现（骨架已就绪）" % self.mode
            self.state = STATE_IDLE
            return False

        if region is None or rv3d is None:
            self.message = "需要在 3D 视图中使用"
            self.state = STATE_IDLE
            return False

        # 1. 变换目标：优先【手柄端点】；没有则用【关键帧点】
        #    （原生语义：两者是各自独立的可选中对象）
        self.frames, self.endpoints, self.only_handles = _transform_targets(obj, act, bone_name)
        if not self.frames and not self.endpoints:
            self.message = "没有选中的路径点或端点"
            self.state = STATE_IDLE
            return False

        # 2. 起始位置快照
        if self.only_handles:
            self.snapshot = xf.snapshot_endpoints(act, obj, self.endpoints, bone_name)
        else:
            self.snapshot = xf.snapshot_positions(act, obj, self.frames, bone_name)

        # 3. pivot（目标物中位点）—— 屏幕投影平面的参考点
        pivot = _target_pivot(act, obj, self.frames, self.endpoints, bone_name)
        if pivot is None:
            self.message = "无法解析目标的世界位置"
            self.state = STATE_IDLE
            return False
        self.pivot_world = pivot

        # 4. 鼠标起始位置对应的世界点
        self.start_world = view3d_utils.region_2d_to_location_3d(
            region, rv3d, mathutils.Vector((mouse_x, mouse_y)), self.pivot_world)
        if self.start_world is None:
            self.message = "无法解析鼠标世界位置"
            self.state = STATE_IDLE
            return False
        self.last_world = self.start_world.copy()
        self.accum = mathutils.Vector((0.0, 0.0, 0.0))
        self.offset = mathutils.Vector((0.0, 0.0, 0.0))

        self.parent_matrix = _parent_transform(obj, bone_name)
        self.state = STATE_RUNNING
        return True

    # ---------------- update ----------------

    def update(self, mouse_x, mouse_y):
        """鼠标移动 -> 应用平移（**增量累积**，与 Blender 原生一致）。

        为什么要增量而不是"总量 × 系数"：

            总量法：offset = (cur - start) * (0.1 if precision else 1.0)
                    → 一按 Shift，【之前走过的位移】也被乘 0.1 → 物体跳回起点附近 ❌

            增量法：accum += (cur - last) * (0.1 if precision else 1.0)
                    → Shift 只影响【此后】的移动速度，已累积的位移原样保留 ✅
                      （正是原生表现：从当前位置继续，不跳回）

        同时，增量法天然满足"切换精度不动鼠标 → 位置不变"（delta=0）。
        """
        if self.state != STATE_RUNNING:
            return False

        cur = view3d_utils.region_2d_to_location_3d(
            self.region, self.rv3d, mathutils.Vector((mouse_x, mouse_y)), self.pivot_world)
        if cur is None:
            return False

        delta = cur - self.last_world
        self.last_world = cur

        # 微小抖动（投影数值噪声）直接忽略，避免累积漂移
        if delta.length < 1e-9:
            return True

        if self.precision:
            delta = delta * xf.PRECISION_FACTOR
        self.accum = self.accum + delta

        # 约束作用在【累积量】上（锁轴 / 锁平面）
        offset = xf.apply_axis_lock(self.accum, self.axis_lock, self.plane_lock)
        self.offset = offset

        local = xf.world_offset_to_local(offset, self.parent_matrix)
        return _apply_xf(self, delta=local)

    # ---------------- 约束（按键） ----------------

    def set_axis(self, axis):
        """按 X/Y/Z：未锁 → 锁该轴；已锁同轴 → 解锁。"""
        if self.axis_lock == axis and self.plane_lock is None:
            self.axis_lock = None
        else:
            self.axis_lock = axis
            self.plane_lock = None
        return self.axis_lock

    def set_plane(self, axis):
        """Shift+X/Y/Z：锁定【垂直于该轴】的平面（保留另两轴）。"""
        others = tuple(a for a in ('X', 'Y', 'Z') if a != axis)
        if self.plane_lock == others:
            self.plane_lock = None
        else:
            self.plane_lock = others
            self.axis_lock = None
        return self.plane_lock

    def set_precision(self, on):
        self.precision = bool(on)

    def apply_numeric(self, value):
        """数字输入：沿锁定轴精确移动 value（世界单位）。

        未锁轴时默认沿 **X 轴**（并在状态栏提示）。
        """
        axis = self.axis_lock or 'X'
        base = {'X': (1.0, 0.0, 0.0), 'Y': (0.0, 1.0, 0.0),
                'Z': (0.0, 0.0, 1.0)}[axis]
        local = xf.world_offset_to_local(mathutils.Vector(base) * value,
                                         self.parent_matrix)
        ok = _apply_xf(self, delta=local)
        if ok:
            self.offset = mathutils.Vector(base) * value
        return ok

    def reset_numeric(self):
        """数字输入被"重置"：位移归零。"""
        zero = mathutils.Vector((0.0, 0.0, 0.0))
        self.accum = zero.copy()
        self.offset = zero.copy()
        return _apply_xf(self, delta=zero)

    # ---------------- finish ----------------

    def confirm(self):
        self.state = STATE_DONE
        return True

    def cancel(self):
        self.restore()
        self.state = STATE_DONE
        return True

    def restore(self):
        if self.snapshot:
            xf.restore_positions(self.act, self.obj, self.snapshot, self.bone_name)
        # 恢复手柄类型（begin 时为了能写入而转成了 FREE）
        # ⚠️ 用 getattr 取到局部变量：MoveSession（G）不参与这个机制，不会有该属性
        # ★ D1：恢复"为写入而临时转 FREE"的类型
        conv = getattr(self, "_converted_types", None)
        if conv:
            xf.restore_converted_types(self.act, self.obj, conv, self.bone_name)
            self._converted_types = None
        # ★ 端点模式：还原后【再写一遍】手柄值（Blender 的 ALIGNED 会在 update 时改它们）
        if getattr(self, "only_handles", False) and self.snapshot:
            xf.reapply_snapshot_handles(self.act, self.obj, self.snapshot,
                                        list(getattr(self, "endpoints", None) or []),
                                        self.bone_name)
        prev_ht = getattr(self, "_prev_handle_types", None)
        if prev_ht:
            xf.restore_handle_types(self.act, self.obj,
                                    getattr(self, "_target_map", None) or self.frames,
                                    prev_ht, self.bone_name)
            for _fc in xf._position_curves(self.act, self.obj, self.bone_name):
                _fc.update()

    # ---------------- 状态栏 ----------------

    MODE_LABEL = {'MOVE': "移动", 'ROTATE': "旋转", 'SCALE': "缩放"}

    def status_text(self):
        label = self.MODE_LABEL.get(self.mode, self.mode)
        if self.state != STATE_RUNNING:
            return "%s | 移动鼠标 · 左键/回车 确认 · 右键/ESC 取消" % label
        o = self.offset
        lock = ""
        if self.plane_lock:
            lock = "  [%s 平面]" % "".join(self.plane_lock)
        elif self.axis_lock:
            lock = "  [%s 轴]" % self.axis_lock
        prec = "  [精度 ×0.1]" if self.precision else ""
        return ("%s | D: %.4f  (X: %.4f  Y: %.4f  Z: %.4f)%s%s%s   |  "
                "X/Y/Z 锁轴 · Shift+X/Y/Z 锁平面 · 数字输入 · Shift 精度 · "
                "左键/回车 确认 · 右键/ESC 取消"
                % (label, o.length, o.x, o.y, o.z, lock, prec, _numeric_suffix(self)))


# ---------------------------------------------------------------------------
# 数字输入（原生 G/R/S 的"敲数字"）
# ---------------------------------------------------------------------------

# Blender event.type -> 字符
_NUM_CHARS = {
    'ZERO': '0', 'ONE': '1', 'TWO': '2', 'THREE': '3', 'FOUR': '4',
    'FIVE': '5', 'SIX': '6', 'SEVEN': '7', 'EIGHT': '8', 'NINE': '9',
    'NUMPAD_0': '0', 'NUMPAD_1': '1', 'NUMPAD_2': '2', 'NUMPAD_3': '3',
    'NUMPAD_4': '4', 'NUMPAD_5': '5', 'NUMPAD_6': '6', 'NUMPAD_7': '7',
    'NUMPAD_8': '8', 'NUMPAD_9': '9',
    'PERIOD': '.', 'NUMPAD_PERIOD': '.', 'COMMA': '.',
    'MINUS': '-', 'NUMPAD_MINUS': '-',
}
_NUM_BACKSPACE = {'BACK_SPACE', 'DEL'}


def _numeric_suffix(session):
    """状态栏里显示"正在输入的数字"（统一格式，避免各处手拼）。"""
    txt = getattr(session, "numeric", "") or ""
    return ("   [输入 %s]" % txt) if txt else ""


class NumericInput:
    """数字输入缓冲（对齐 Blender 原生，见官方手册 *Numeric Input*）。

    原生行为：
      · 敲数字 / `-` / `.`     → 累积输入
      · `/`  **倒数**          → `2/` 得 0.5；`20/` 得 0.05
      · Backspace **两段行为** → 删光后再按一次「重置到初始值」，
                                 再按一次「取消数字编辑、回到鼠标控制」
      · 回车/Tab               → 确认（Tab = 下一个分量，本插件暂不做多轴输入）

    这里只做"缓冲 + 解析"，具体语义（移动距离 / 角度 / 比例）交给各 Session 的
    `apply_numeric` / `reset_numeric`。
    """

    def __init__(self):
        self.buf = ""
        self.reset_requested = False    # 删空后再按 Backspace：请求重置
        self.cancel_requested = False   # 再按一次：请求退出数字编辑
        self.multiplier = None          # 记下"输入前的基础值"（供 / 运算）

    @property
    def active(self):
        return len(self.buf) > 0

    def key(self, event_type):
        """喂一个按键。返回 True 表示这个键被数字输入消费了。"""
        if event_type in _NUM_CHARS:
            ch = _NUM_CHARS[event_type]
            # 只允许一个负号（且必须在最前）
            if ch == '-' and self.buf:
                return True
            if ch == '.' and '.' in self.buf:
                return True
            self.buf += ch
            self.reset_requested = False
            self.cancel_requested = False
            return True

        if event_type in _NUM_BACKSPACE:
            if not self.buf:
                # ★ 原生两段行为
                if not self.reset_requested:
                    self.reset_requested = True
                else:
                    self.cancel_requested = True
                return True
            self.buf = self.buf[:-1]
            self.reset_requested = False
            self.cancel_requested = False
            return True

        if event_type in ('SLASH', 'NUMPAD_SLASH'):
            # ★ 倒数：2/ → 0.5
            v = self.value()
            if v not in (None, 0.0):
                inv = 1.0 / v
                self.buf = ("%g" % inv)
            return True

        return False

    def clear(self):
        self.buf = ""
        self.reset_requested = False
        self.cancel_requested = False

    def value(self):
        """解析为 float；无效返回 None。"""
        t = self.buf.strip()
        if not t or t in ('-', '.', '-.'):
            return None
        try:
            return float(t)
        except Exception:
            return None

    def __str__(self):
        return self.buf


# ---------------------------------------------------------------------------
# 旋转 / 缩放会话（第一条线：R / S）
# ---------------------------------------------------------------------------

class RotateSession:
    """R：绕【选中点中位点】旋转路径点群（pivot = 中位点）。

    旋转轴 = **屏幕法线**（视图方向）—— 这样在视口里看到的就是"点群原地转"。
    Shift 精度 ×1/30（见 设计存档 §11 的规格）。

    与 S 共用「以 pivot 变换点群」的模型，只是 fn 不同（见 xf.apply_point_transform）。
    """

    def __init__(self, mode='ROTATE'):
        self.mode = mode                  # ROTATE（预留 SCALE 复用同一套 begin/update 骨架）
        self.state = STATE_IDLE
        self.obj = None
        self.act = None
        self.bone_name = None
        self.region = None
        self.rv3d = None
        self.parent_matrix = None

        self.frames = {}
        self._target_map = {}             # {frame: {axis: fc}} 实际作用目标
        self.endpoints = []               # 手柄端点模式（原生语义：端点可独立变换）
        self.only_handles = False
        self.snapshot = None
        self.pivot_world = None
        self.pivot_local = None
        self.axis_local = None
        # ★ 鼠标引导（复刻原生 R/S 的"支点→鼠标"虚线 + 双向箭头，2026-09-16）
        #   由 overlay._draw_mouse_guide 读取；ScaleSession 继承本类 → 自动获得。
        #   取值：
        #     'tangent' → 画虚线 + **切向**双向箭头（旋转 R：箭头 ⊥ 连线，随鼠标绕支点转）
        #     'radial'  → 画虚线 + **径向**双向箭头（缩放 S，若将来统一时切换）
        #     True      → 只画虚线（旧语义，向后兼容）
        self.mouse_guide = 'tangent'
        self.mouse_screen = None          # 当前鼠标（region 坐标），update() 里刷新
        self.start_vec = None             # 起始鼠标向量（屏幕空间，相对 pivot）
        # ★★ 旋转角度（2026-09-16 改为「鼠标绕支点转过的角」，1:1 复刻原生）
        #
        #   `angle_raw` = **累加的原始角度**（唯一真值）
        #   `angle`     = `angle_raw × 精度系数`（派生值；_apply / 状态栏 / _apply 都读它）
        #   用累加而不是"当前角 - 起始角"：atan2 的差跨 ±180° 会翻转，
        #   累加（每帧取归一化增量）能连续转多圈、也不会因鼠标瞬移跳变。
        self.angle_raw = 0.0
        self.angle = 0.0
        self._last_mouse_angle = None     # 上一帧「鼠标相对支点」的角度（算增量用）
        self.precision = False
        self.message = ""
        # 锁轴（原生 R 按 X/Y/Z 指定旋转轴；S 限制缩放轴）
        self.axis_lock = None             # 'X' / 'Y' / 'Z'，None = 屏幕法线 / 全轴
        self.plane_lock = None            # ('Y','Z') 等：保留的轴
        self.axis_orientation = 'GLOBAL'  # 原生：按两次同轴键 → 全局 ↔ 局部
        self.numeric = ""                 # 数字输入缓冲（显示用）
        # 手柄类型备份（取消时恢复原类型用）
        self._prev_handle_types = None
        # ★ D1：端点模式"为写入临时转 FREE"的类型（取消时恢复）
        self._converted_types = None

    # ---- begin ----

    def begin(self, obj, act, region, rv3d, mouse_x, mouse_y, bone_name=None):
        self.obj, self.act, self.bone_name = obj, act, bone_name
        self.region, self.rv3d = region, rv3d
        self.message = ""
        self.precision = False
        self._set_angle_raw(0.0)                 # ★ 角度真值归零（angle 随之归零）
        self._last_mouse_angle = None            # ★ 增量累加的基准，首帧建立
        self.drag_mode = 'vertical'
        self.mouse_screen = (mouse_x, mouse_y)   # ★ 引导虚线的起点（鼠标端）

        if region is None or rv3d is None:
            self.message = "需要在 3D 视图中使用"
            self.state = STATE_IDLE
            return False

        # 变换目标：优先【手柄端点】（原生：端点与控制点各自独立可选）
        self.frames, self.endpoints, self.only_handles = _transform_targets(obj, act, bone_name)
        if not self.frames and not self.endpoints:
            self.message = ("没有选中的路径点或端点 —— 先点一下再按 %s"
                            "（Shift+点击可多选）"
                            % ('R' if self.mode == 'ROTATE' else 'S'))
            self.state = STATE_IDLE
            return False

        # ⚠️ 单点**不再被拒绝**（2026-09-16 修正）
        #    原生语义：co 和两侧手柄是三个独立的顶点，
        #    pivot 取中位点时，单个点旋转 = **它的手柄绕它自己转**
        #    （co 不动、手柄转 → 切线方向变 → 形状变）。
        if self.only_handles:
            self.snapshot = xf.snapshot_endpoints(act, obj, self.endpoints, bone_name)
        else:
            self.snapshot = xf.snapshot_positions(act, obj, self.frames, bone_name)

        pivot = _target_pivot(act, obj, self.frames, self.endpoints, bone_name)
        if pivot is None:
            self.message = "无法解析目标的世界位置"
            self.state = STATE_IDLE
            return False
        self.pivot_world = pivot

        self.parent_matrix = _parent_transform(obj, bone_name)

        # pivot -> 局部
        try:
            self.pivot_local = self.parent_matrix.inverted() @ self.pivot_world
        except Exception:
            self.message = "无法解析 pivot"
            self.state = STATE_IDLE
            return False

        # 旋转轴 = 屏幕法线（视图方向），转到局部空间
        try:
            axis_world = rv3d.view_rotation @ mathutils.Vector((0.0, 0.0, 1.0))
            self.axis_local = self.parent_matrix.to_3x3().inverted() @ axis_world
        except Exception:
            self.axis_local = mathutils.Vector((0.0, 0.0, 1.0))

        # ★ 把选中关键帧的手柄转成 FREE（保留坐标）
        #   否则 AUTO_CLAMPED（Blender 新建关键帧的默认类型）会**吞掉写入**：
        #   实测单点旋转 30° 时 Δhandle = 0.000000（完全没反应）；
        #   多点旋转时手柄只平移不旋转（形状错）。
        #   见 xf.make_handles_editable 的 docstring。
        # 端点模式下 self.frames 为空 —— 用端点推导出 {frame: {axis: fc}} 映射
        if self.only_handles:
            # ★ 端点模式【不】把手柄转 FREE（2026-09-16）
            #   旧实现转 FREE → ALIGNED 共线丢失 → 用户看到"折角"
            #   （原生语义：移动端点时 ALIGNED 的对侧绕 co 旋转保持共线，
            #     由 xf.maintain_linked_handle 负责维护）
            self._target_map = {}
            self._prev_handle_types = None
        else:
            self._target_map = self.frames
            self._prev_handle_types = xf.make_handles_editable(
                act, obj, self._target_map, bone_name)
        for _fc in xf._position_curves(act, obj, bone_name):
            _fc.update()
        # 转类型可能触发了重算 → 用 snapshot 把值写回，保证起点一致
        xf.restore_positions(act, obj, self.snapshot, bone_name)

        self.start_vec = self._mouse_vec(mouse_x, mouse_y)
        if self.start_vec is None or self.start_vec.length < 1e-6:
            self.start_vec = mathutils.Vector((1.0, 0.0))
        # ★ 增量累加的基准角 = 起始鼠标方向（首帧 update 即从这里开始量增量）
        self._last_mouse_angle = math.atan2(self.start_vec.y, self.start_vec.x)
        self.state = STATE_RUNNING
        return True

    def _pivot_screen(self):
        try:
            return _screen_pos(self.region, self.rv3d, self.pivot_world)
        except Exception:
            return None

    def _mouse_vec(self, mouse_x, mouse_y):
        sp = self._pivot_screen()
        if sp is None:
            return None
        return mathutils.Vector((mouse_x - sp.x, mouse_y - sp.y))

    def _prec_scale(self):
        """精度系数（按 Shift）。R 的规格是 ×1/30（见 设计存档 §11）。"""
        return (1.0 / 30.0) if self.precision else 1.0

    def _set_angle_raw(self, raw):
        """设**原始角度**并同步派生值 —— 所有改角度的地方都走这里（唯一入口）。

        `angle_raw` 是唯一真值；`angle` = raw × 精度系数（_apply / 状态栏读它）。
        """
        self.angle_raw = float(raw)
        self.angle = self.angle_raw * self._prec_scale()

    # ---- update ----

    def update(self, mouse_x, mouse_y):
        """鼠标移动 -> 旋转。

        ★★ 2026-09-16 修正（用户实测反馈：「光标只转 5°，手柄却转更多、
            虚线也没紧跟」）—— 两个现象是**同一个根因**：

        ▎旧实现（像素口径）：
              `angle = 切向位移(px) / REF_RADIUS`
            鼠标绕支点转 θ 时，切向位移 ≈ R·θ（R = 支点→鼠标的屏幕距离），
            于是 `angle ≈ (R/150)·θ` —— **倍率就是 R/150**。
            实测（`_rot.py`，逐档量过）：

              | 支点离鼠标 R | 鼠标转 5° → 手柄转 | 倍率 |
              |---|---|---|
              | 150 px  |  4.99° |  1.0  |
              | 400 px  | 13.32° |  2.66 |
              | 800 px  | 26.63° |  5.33 |
              | 1500 px | 49.94° |  9.99 |

            于是用户看到「虚线（它的方向 = 鼠标绕支点的**真实角度**）只转了
            5°，3D 手柄却转了 26°」—— 视觉与数值对不上，感觉线没跟上。

        ▎现实现（**角度式**，1:1 复刻原生）：
            `angle` = **鼠标绕支点转过的角**（每帧取归一化增量后累加）
              · 鼠标转 5° → 手柄转 5°（**严格 1:1**）
              · 虚线方向同步转 5° → 视觉与数值一致
              · 与原生 Blender 的旋转语义相同

        ⚠️ 取舍（必须知道）：角度式下支点离鼠标越远，**同样的鼠标位移转的角度
           越小**（几何必然，原生亦然）。像素口径当初正是为绕开这点而引入的，
           但它牺牲了"1:1 对等"。用户 2026-09-16 明确要「对等」→ 改回角度式。
           想"支点远也省力"就把鼠标拖近一点 —— 原生就是这么用的。
        """
        if self.state != STATE_RUNNING:
            return False
        sp = self._pivot_screen()
        if sp is None:
            return False
        v1 = mathutils.Vector((mouse_x - sp.x, mouse_y - sp.y))
        self.mouse_screen = (mouse_x, mouse_y)   # ★ 引导虚线跟随鼠标
        # 鼠标太贴近支点时 atan2 抖动剧烈 → 本帧不动角度（虚线端点仍更新）
        if v1.length < _MIN_LEVER_PX:
            return False
        a1 = math.atan2(v1.y, v1.x)
        if self._last_mouse_angle is None:
            self._last_mouse_angle = a1
            return self._apply()
        # 归一化增量到 (-π, π]：跨 ±180° 不翻转、可连续转多圈
        d = a1 - self._last_mouse_angle
        while d > math.pi:
            d -= 2.0 * math.pi
        while d <= -math.pi:
            d += 2.0 * math.pi
        self._last_mouse_angle = a1
        self._set_angle_raw(self.angle_raw + d)
        return self._apply()

    def set_precision(self, on):
        self.precision = bool(on)
        # ★ 精度切换要重算派生值（角度式下 angle 由 angle_raw 派生）
        self._set_angle_raw(self.angle_raw)

    def set_axis(self, axis):
        """按 X/Y/Z 锁轴 —— 复刻原生语义（官方手册 *Axis Locking*）。

        > "A single key press constrains movement to the current transform
        >  orientation selection. A second key press of the same key constrains
        >  movement to the corresponding **Global** axis (except if the transform
        >  orientation is set to Global, in which case the **Local** orientation
        >  is used)"

        即：**按一次 = 全局朝向；再按同轴 = 切成局部朝向**（不是"解除"）。
        按另一个轴键则切到该轴（并回到全局朝向）。
        """
        if self.axis_lock == axis:
            # 第二次按同轴 → 切换 全局 ↔ 局部
            self.axis_orientation = ('LOCAL' if self.axis_orientation == 'GLOBAL'
                                     else 'GLOBAL')
        else:
            self.axis_lock = axis
            self.axis_orientation = 'GLOBAL'
        self.plane_lock = None
        return self.axis_lock

    def set_plane(self, axis):
        """Shift+X/Y/Z：锁定到【垂直于该轴】的平面（= 绕该轴）。"""
        others = tuple(a for a in ('X', 'Y', 'Z') if a != axis)
        self.plane_lock = None if self.plane_lock == others else others
        self.axis_lock = axis            # 绕该轴 = 在另两轴构成的平面内旋转
        return self.plane_lock

    def _world_axis_local(self, axis_name):
        """轴键 -> 局部空间的方向向量。

        · GLOBAL 朝向：世界轴（转到关键帧所在的局部空间表示）
        · LOCAL  朝向：物体自身的轴（局部空间里的基向量，无需变换）

        复刻原生"按两次同轴键切朝向"的语义（见 `set_axis`）。
        """
        base = {'X': (1.0, 0.0, 0.0), 'Y': (0.0, 1.0, 0.0),
                'Z': (0.0, 0.0, 1.0)}.get(axis_name)
        if base is None:
            return None
        if getattr(self, "axis_orientation", 'GLOBAL') == 'LOCAL':
            return mathutils.Vector(base)          # 局部朝向：直接用基向量
        try:
            return self.parent_matrix.to_3x3().inverted() @ mathutils.Vector(base)
        except Exception:
            return mathutils.Vector(base)

    def _current_axis(self):
        if self.axis_lock:
            a = self._world_axis_local(self.axis_lock)
            if a is not None:
                return a
        return self.axis_local

    def _apply(self):
        fn = xf.rotation_fn(self.pivot_local, self._current_axis(), self.angle)
        if fn is None:
            return False
        ok = _apply_xf(self, fn=fn)
        # 写入被拒时给明确提示（不静默 —— agent 实测：1e7× 缩放曾静默失效）
        if getattr(xf, "last_skip_reason", None):
            self.message = xf.last_skip_reason
        return ok

    def apply_numeric(self, value):
        """数字输入：旋转 value 度（绕当前轴）。

        ⚠️ 方向按原生约定：**正值为顺时针**（官方手册 *Numeric Input*：
           "The rotation is in clockwise direction for positive values"）。
           我们的 `angle` 内部约定是"+ = 屏幕逆时针"，所以这里取负。
        """
        # 走 _set_angle_raw 保持"raw 是真值"的不变式：angle = raw × 精度系数
        self._set_angle_raw(math.radians(-float(value)) / self._prec_scale())
        return self._apply()

    def reset_numeric(self):
        """数字输入被"重置"（Backspace 两段行为的第一段）：本轴归零。"""
        self._set_angle_raw(0.0)
        return self._apply()

    # ---- finish ----

    def confirm(self):
        self.state = STATE_DONE
        return True

    def cancel(self):
        self.restore()
        self.state = STATE_DONE
        return True

    def restore(self):
        if self.snapshot:
            xf.restore_positions(self.act, self.obj, self.snapshot, self.bone_name)
        # 恢复手柄类型（begin 时为了能写入而转成了 FREE）
        # ⚠️ 用 getattr 取到局部变量：MoveSession（G）不参与这个机制，不会有该属性
        # ★ D1：恢复"为写入而临时转 FREE"的类型
        conv = getattr(self, "_converted_types", None)
        if conv:
            xf.restore_converted_types(self.act, self.obj, conv, self.bone_name)
            self._converted_types = None
        # ★ 端点模式：还原后【再写一遍】手柄值（Blender 的 ALIGNED 会在 update 时改它们）
        if getattr(self, "only_handles", False) and self.snapshot:
            xf.reapply_snapshot_handles(self.act, self.obj, self.snapshot,
                                        list(getattr(self, "endpoints", None) or []),
                                        self.bone_name)
        prev_ht = getattr(self, "_prev_handle_types", None)
        if prev_ht:
            xf.restore_handle_types(self.act, self.obj,
                                    getattr(self, "_target_map", None) or self.frames,
                                    prev_ht, self.bone_name)
            for _fc in xf._position_curves(self.act, self.obj, self.bone_name):
                _fc.update()

    # ---- 状态栏 ----

    def status_text(self):
        if self.state != STATE_RUNNING:
            return "旋转 | 移动鼠标 · 左键/回车 确认 · 右键/ESC 取消"
        prec = "  [精度 ×1/30]" if self.precision else ""
        return ("旋转 %.2f°%s%s   |  移动鼠标 · X/Y/Z 锁轴 · 数字输入(度) · "
                "Shift 精度 · 左键/回车 确认 · 右键/ESC 取消"
                % (math.degrees(self.angle), prec, _numeric_suffix(self)))


class ScaleSession(RotateSession):
    """S：以【选中点中位点】为中心缩放路径点群。

    用户语义（设计存档 §11）：缩放会**同时改变路径几何与采样点分布**
    —— 这正是"让点散开 / 聚拢"，与第二条线「不改形状」是两条独立的线。
    """

    def __init__(self, mode='SCALE'):
        super().__init__(mode)
        self.start_len = 1.0
        self.factor = 1.0
        # ★ 覆盖父类的 'tangent' —— S 要用**径向**箭头（∥ 连线），不是切向（⊥ 连线）。
        #   实测（用户提供的原生截图）：S 的箭头与虚线**平行**（0° vs 0°），
        #   而 R 的箭头与虚线**垂直**（−74.7° vs +15.3°）。
        #   直觉上也自洽：缩放的"有效拖动方向"就是径向（往外拖=放大）。
        #
        #   ⚠️ 必须显式覆盖：本类继承 RotateSession，不覆盖就会拿到 'tangent'
        #      → S 模态画出与方向语义相反的箭头。
        self.mouse_guide = 'radial'

    def begin(self, obj, act, region, rv3d, mouse_x, mouse_y, bone_name=None):
        ok = super().begin(obj, act, region, rv3d, mouse_x, mouse_y, bone_name)
        if ok:
            self.start_len = max(self.start_vec.length, 1e-6)
        return ok

    def update(self, mouse_x, mouse_y):
        """鼠标移动 -> 缩放。

        与 R 同理：用【径向位移 ÷ 参考半径】而不是"距离比"，
        这样支点很远时也不会"拖了半天没反应"。

            factor = 1 + 径向位移 / REF_RADIUS
            拖出 REF_RADIUS 像素 → 2 倍；拖进 REF_RADIUS 像素 → 接近 0
        """
        if self.state != STATE_RUNNING:
            return False
        sp = self._pivot_screen()
        if sp is None:
            return False
        v0 = self.start_vec
        if v0 is None or v0.length < 1e-6:
            return False
        v1 = mathutils.Vector((mouse_x - sp.x, mouse_y - sp.y))
        self.mouse_screen = (mouse_x, mouse_y)   # ★ 引导虚线跟随鼠标
        radial_dir = v0.normalized()
        radial = (v1 - v0).dot(radial_dir)
        raw = 1.0 + radial / REF_RADIUS
        # 精度：让"缩放变化量"缩到 1/10（原生 S 的 Shift 语义）
        if self.precision:
            raw = 1.0 + (raw - 1.0) * 0.1
        self.factor = max(1e-4, raw)
        return self._apply()

    def _axis_mask(self):
        """返回 (mx, my, mz)：哪些轴【允许】缩放。

        按 X/Y/Z        → 只在该轴缩放
        Shift+X/Y/Z     → 在【另两轴】缩放（= 锁定垂直于该轴的平面）

        ⚠️ `plane_lock` 的语义与 MoveSession 一致：里面装的是
           **要保留的轴**（例如 Shift+Y → plane_lock=('X','Z') → mask=(1,0,1)）。
           早期版本把这里写成"plane_lock 里的轴不缩放"，语义正好相反（实测抓到）。
        """
        if self.plane_lock:
            return tuple(1.0 if a in self.plane_lock else 0.0 for a in ('X', 'Y', 'Z'))
        if self.axis_lock:
            return tuple(1.0 if a == self.axis_lock else 0.0 for a in ('X', 'Y', 'Z'))
        return (1.0, 1.0, 1.0)

    def _apply(self):
        mask = self._axis_mask()
        if mask == (1.0, 1.0, 1.0):
            fn = xf.scale_fn(self.pivot_local, self.factor)
        else:
            fn = xf.scale_fn_masked(self.pivot_local, self.factor, mask)
        # ★★ 单点缩放【保速】（用户 2026-09-17 拍板）
        #
        #   速度 = |dv / dt|。原来只缩值分量 dv、dt 不动 ⇒ **速度 ×factor**
        #   （实测 k=1.5 时 0.170833 → 0.25625）。让 dt 也 ×factor ⇒ 速度不变
        #   （= 在「值-时间」平面上等比缩放，形状相似 ⇒ 各关键帧处速度恒定）。
        #
        #   判据：**只选中 1 个关键帧点** ⇒ 支点就是它自己（co 不动）、手柄绕它缩。
        #   ⚠️ 多点缩放不缩 dt —— 那时支点是中位点，各点位移不同，
        #      "保速"没有统一语义（保持历史行为）。
        #   ⚠️ 轴锁定（mask ≠ 全 1）时不缩 —— 各轴手柄的时间分量彼此独立，
        #      混着缩会把**未参与缩放的轴**的速度也带偏。
        #   ★ 端点模式（only_handles）走 `apply_endpoint_transform`，
        #     它自己也接 `time_scale`（见下方的分支）。
        ts = None
        if mask == (1.0, 1.0, 1.0):
            if getattr(self, "only_handles", False):
                # ★ 端点模式（选中【手柄端点】）：只选【1 个】端点时才缩 dt。
                #   理由：支点 = 选中关键帧点的**中位点**（见 `_target_pivot`）——
                #      · 1 个端点 ⇒ 支点就是它那一帧的 co ⇒ 手柄绕自己的 co 等比缩
                #        ⇒ dv 与 dt 同缩 ⇒ **速度不变** ✓
                #      · 多个端点 ⇒ 支点是各帧的均值，各手柄的缩放比例不同，
                #        "保速"无统一语义 ⇒ 不缩（与"多点不缩 dt"同一口径）。
                #   ⚠️ 实测附带发现（未修，非本功能范围）：同帧【两侧手柄都选中】时，
                #      既有多端点通路**连值分量都不缩**（dv 分毫不变）——
                #      与 dt 缩不缩无关，属另一条独立的既有行为。
                _eps = list(getattr(self, "endpoints", None) or [])
                if len(_eps) == 1:
                    ts = self.factor
            elif len(self.snapshot or {}) == 1:
                # 关键帧点：只选中 1 个 ⇒ 支点就是它自己（co 不动）
                ts = self.factor
        return _apply_xf(self, fn=fn, time_scale=ts)

    def apply_numeric(self, value):
        """数字输入：缩放到 value 倍（相对起始状态）。"""
        self.factor = max(1e-4, float(value))
        return self._apply()

    def reset_numeric(self):
        """数字输入被"重置"：恢复 1.0×（= 进入模态时的状态）。"""
        self.factor = 1.0
        return self._apply()

    def status_text(self):
        if self.state != STATE_RUNNING:
            return "缩放 | 移动鼠标 · 左键/回车 确认 · 右键/ESC 取消"
        prec = "  [精度 ×0.1]" if self.precision else ""
        lock = ""
        if self.plane_lock:
            lock = "  [%s 平面]" % "".join(self.plane_lock)
        elif self.axis_lock:
            lock = "  [%s 轴]" % self.axis_lock
        return ("缩放 %.4f×%s%s%s   |  移动鼠标 · X/Y/Z 限制轴 · 数字输入(倍) · "
                "Shift 精度 · 左键/回车 确认 · 右键/ESC 取消"
                % (self.factor, lock, prec, _numeric_suffix(self)))


# ---------------------------------------------------------------------------
# Operator（薄壳：把 Blender 事件桥接到 ModalSession）
# ---------------------------------------------------------------------------

def _get_target_obj(context):
    obj = context.active_object
    if obj is not None and obj.animation_data and obj.animation_data.action:
        return obj
    for o in context.selected_objects:
        if o.animation_data and o.animation_data.action:
            return o
    return None


class RTMP_OT_ModalEdit(bpy.types.Operator):
    """RTMP 模态编辑（骨架）"""

    bl_idname = "rtmp.modal_edit"
    bl_label = "RTMP Modal Edit"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(items=MODE_ITEMS, default='SPEED')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._session = None

    # ---------------- invoke ----------------

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "请在 3D 视图中使用")
            return {'CANCELLED'}

        obj = _get_target_obj(context)
        if obj is None:
            self.report({'WARNING'}, "没有可编辑的位移动画（请选中一个有动画的物体）")
            return {'CANCELLED'}

        mx = getattr(event, 'mouse_region_x', None)
        my = getattr(event, 'mouse_region_y', None)
        if mx is None or my is None:
            return {'CANCELLED'}

        act = obj.animation_data.action
        session = ModalSession(self.mode)
        ok = session.begin(
            obj, act, mx, my,
            lambda x, y: _resolve_target_preferring_selection(context, obj, act, x, y))
        if not ok:
            self.report({'WARNING'}, session.message)
            return {'CANCELLED'}

        self._session = session
        context.window_manager.modal_handler_add(self)
        # 视口覆盖层：在目标关键帧处画对应的速度三角
        if ov is not None:
            ov.start_overlay(session)
        _refresh_session_handles(context, obj, act, session)
        self._set_status(context, session.status_text())
        self._redraw(context)
        # ★ 模态光标（复刻原生体验）：进入成功后再设，失败静默不影响模态
        set_modal_cursor(context, session)
        return {'RUNNING_MODAL'}

    # ---------------- modal ----------------

    def modal(self, context, event):
        s = self._session
        if s is None or s.state != STATE_RUNNING:
            return {'CANCELLED'}

        # ★ 2026-09-17：把当前 context 挂到会话上 —— `_apply_xf` 要拿 3D 视图
        #   把「屏幕视觉零(6px)」换算成世界长度（封口闸门的口径，见
        #   `_zero_eps_for_session`）。没有它就会退化成 `_ARM_EPS`(1e-9)，
        #   让用户缩到关键帧点的 ALIGNED 手柄被误封口成 FREE。
        try:
            s.context = context
        except Exception:
            pass

        if event.type == 'MOUSEMOVE':
            s.update(event.mouse_region_x, event.mouse_region_y)
            _refresh_session_handles(context, s.obj, s.act, s)
            self._set_status(context, s.status_text())
            self._redraw(context)
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'RETURN', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            s.confirm()
            return self._finish(context, 'FINISHED')

        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            s.cancel()
            return self._finish(context, 'CANCELLED')

        return {'RUNNING_MODAL'}

    def _set_status(self, context, txt):
        try:
            context.workspace.status_text_set(txt)
        except Exception:
            pass

    def _redraw(self, context):
        area = context.area
        if area is not None:
            area.tag_redraw()

    def _finish(self, context, result):
        if ov is not None:
            # ⚠️ 只撤【轴约束线】的 3D handler；pixel handler 归 path_point_drag，
            #    一起删掉会让速度三角【永久消失】（用户反馈的 bug）。
            ov.get_overlay().stop_view_only()
            ov.clear_segment_highlight()
        self._set_status(context, None)
        self._redraw(context)
        # ★ 恢复模态前的光标（幂等：即使这里没设过也安全）
        restore_modal_cursor(context)
        return {result}

    def cancel(self, context):
        """模态被外部取消（插件卸载等）时的兜底清理。"""
        if ov is not None:
            # ⚠️ 只撤【轴约束线】的 3D handler；pixel handler 归 path_point_drag，
            #    一起删掉会让速度三角【永久消失】（用户反馈的 bug）。
            ov.get_overlay().stop_view_only()
            ov.clear_segment_highlight()
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        # ★ 恢复模态前的光标（同 _finish；幂等所以两处都调没有风险）
        restore_modal_cursor(context)


class RTMP_OT_KeyboardTransform(bpy.types.Operator):
    """G/R/S：键盘模态变换（第一条线）。

    ⚠️ 只在【直接编辑模式】开启时接管（`rtmp_edit_mode_active`）：
       关闭时 G/R/S 仍归 Blender 原生（移动/旋转/缩放物体），
       **不替换用户的日常操作**。
    """

    bl_idname = "rtmp.keyboard_transform"
    bl_label = "RTMP Keyboard Transform"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(items=MODE_ITEMS, default='MOVE')

    @classmethod
    def poll(cls, context):
        wm = getattr(context, "window_manager", None)
        if wm is None:
            return False
        return bool(getattr(wm, "rtmp_edit_mode_active", False))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._session = None
        self._last_mouse = (0.0, 0.0)
        self._numeric = None

    # ---------------- invoke ----------------

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "请在 3D 视图中使用")
            return {'CANCELLED'}

        obj = _get_target_obj(context)
        if obj is None:
            self.report({'WARNING'}, "没有可编辑的位移动画（请选中一个有动画的物体）")
            return {'CANCELLED'}

        mx = getattr(event, 'mouse_region_x', None)
        my = getattr(event, 'mouse_region_y', None)
        if mx is None or my is None:
            return {'CANCELLED'}
        self._last_mouse = (mx, my)

        act = obj.animation_data.action

        # ★ 路由（用户 2026-09-15）：
        #   如果当前【选中了速度三角】，按 G 就进入"采样点疏密"模态，
        #   而不是移动路径点。这样就不需要专门的 J 键了。
        sel = _selected_speed_handle()
        # ★ 用户 2026-09-16：**按 G 或 S 都进入"疏密滑移"模态**（选中三角时）。
        #   S 原本是"缩放路径点群"，但既然用户选中了速度三角，
        #   意图显然是调疏密（速度 = Speed，S 也符合直觉）。
        if sel is not None and self.mode in ('MOVE', 'SCALE'):
            sp = ModalSession('SPEED')
            # ★ 语义区分（用户 2026-09-16）：
            #   G → 上下拖（滑移）；S → 径向拖（放大=疏 / 缩小=密）
            _dm = 'radial' if self.mode == 'SCALE' else 'vertical'
            ok = sp.begin(obj, act, mx, my,
                          lambda x, y: _resolve_target_preferring_selection(
                              context, obj, act, x, y),
                          drag_mode=_dm)
            if ok:
                _clear_point_drag_state()      # 避免 path_point_drag 仍在拖点
                self._session = sp
                context.window_manager.modal_handler_add(self)
                if ov is not None:
                    ov.get_overlay().start(sp)
                _refresh_session_handles(context, obj, act, sp)
                self._set_status(context, sp.status_text())
                self._redraw(context)
                # ★ 选中速度三角 → SPEED 会话 → MOVE_Y（上下拖调疏密）
                set_modal_cursor(context, sp)
                return {'RUNNING_MODAL'}

        # R / S：绕中位点旋转 / 缩放选中的路径点群
        if self.mode == 'ROTATE':
            sess = RotateSession('ROTATE')
        elif self.mode == 'SCALE':
            sess = ScaleSession('SCALE')
        else:
            sess = MoveSession(self.mode)
        ok = sess.begin(obj, act, context.region, context.region_data, mx, my)
        if not ok:
            self.report({'WARNING'}, sess.message)
            return {'CANCELLED'}

        self._session = sess
        self._numeric = NumericInput()
        context.window_manager.modal_handler_add(self)
        # 视口覆盖层（轴约束指示线）—— 仿原生 transform 的 UI
        if ov is not None:
            ov.start_overlay(sess)
        self._set_status(context, sess.status_text())
        self._redraw(context)
        # ★ MOVE→SCROLL_XY（复刻原生 G）/ ROTATE,SCALE→NONE（复刻原生隐藏）
        set_modal_cursor(context, sess)
        return {'RUNNING_MODAL'}

    # ---------------- modal ----------------

    def modal(self, context, event):
        s = self._session
        if s is None or s.state != STATE_RUNNING:
            return {'CANCELLED'}

        # ★ 2026-09-17：同另一个 modal —— 供 `_zero_eps_for_session` 换算「视觉零」。
        try:
            s.context = context
        except Exception:
            pass

        # 两种会话：MoveSession（G/R/S 变换）与 ModalSession（采样点疏密）
        is_speed = isinstance(s, ModalSession)

        # ---- 数字输入（G/R/S 都支持：敲数字 → 精确应用）----
        if not is_speed and hasattr(s, "apply_numeric"):
            if event.value in {'PRESS', 'REPEAT'}:
                ni = getattr(self, "_numeric", None)
                if ni is not None and ni.key(event.type):
                    # ★ 复刻原生 Backspace 的两段行为（官方手册 *Numeric Input*）
                    if ni.cancel_requested:
                        # 第二次：取消数字编辑，回到鼠标控制
                        ni.clear()
                        s.numeric = ""
                        if hasattr(s, "reset_numeric"):
                            s.reset_numeric()
                        self._set_status(context, s.status_text())
                        self._redraw(context)
                        return {'RUNNING_MODAL'}
                    if ni.reset_requested:
                        # 第一次：把当前值重置到初始状态
                        s.numeric = ""
                        if hasattr(s, "reset_numeric"):
                            s.reset_numeric()
                        self._set_status(context, s.status_text())
                        self._redraw(context)
                        return {'RUNNING_MODAL'}
                    s.numeric = str(ni)
                    v = ni.value()
                    if v is not None:
                        s.apply_numeric(v)
                    self._set_status(context, s.status_text())
                    self._redraw(context)
                    return {'RUNNING_MODAL'}

        # 鼠标移动
        if event.type == 'MOUSEMOVE':
            self._last_mouse = (event.mouse_region_x, event.mouse_region_y)
            # ⚠️ 正在数字输入时，鼠标移动【不改变数值】（与原生一致）
            if not is_speed and getattr(self, "_numeric", None) is not None \
                    and self._numeric.active:
                return {'RUNNING_MODAL'}
            # ★ SPEED 模态也支持 Shift 精度（用户 2026-09-16 要求 ③）
            if hasattr(s, "set_precision"):
                s.set_precision(event.shift)
            s.update(event.mouse_region_x, event.mouse_region_y)
            if is_speed:
                _refresh_session_handles(context, s.obj, s.act, s)
            self._set_status(context, s.status_text())
            self._redraw(context)
            return {'RUNNING_MODAL'}

        # 以下按键只对变换模态有意义（速度模态不处理）
        if not is_speed:
            # Shift 按下/抬起 -> 精度切换（不移动鼠标也要重算）
            if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
                s.set_precision(event.value == 'PRESS')
                s.update(*self._last_mouse)
                self._set_status(context, s.status_text())
                self._redraw(context)
                return {'RUNNING_MODAL'}

            # X/Y/Z 锁轴；Shift+X/Y/Z 锁平面
            if event.type in {'X', 'Y', 'Z'} and event.value == 'PRESS':
                if event.shift:
                    s.set_plane(event.type)
                else:
                    s.set_axis(event.type)
                s.update(*self._last_mouse)
                self._set_status(context, s.status_text())
                self._redraw(context)
                return {'RUNNING_MODAL'}

        # 确认
        if event.type in {'LEFTMOUSE', 'RETURN', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            s.confirm()
            return self._finish(context, 'FINISHED')

        # 取消（恢复原位）
        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            s.cancel()
            return self._finish(context, 'CANCELLED')

        return {'RUNNING_MODAL'}

    def _set_status(self, context, txt):
        try:
            context.workspace.status_text_set(txt)
        except Exception:
            pass

    def _redraw(self, context):
        area = context.area
        if area is not None:
            area.tag_redraw()

    def _finish(self, context, result):
        # ⚠️ 必须先撤掉绘制回调，否则模态结束后仍在画（handler 泄漏）
        if ov is not None:
            # ⚠️ 只撤【轴约束线】的 3D handler；pixel handler 归 path_point_drag，
            #    一起删掉会让速度三角【永久消失】（用户反馈的 bug）。
            ov.get_overlay().stop_view_only()
            ov.clear_segment_highlight()
        self._set_status(context, None)
        self._redraw(context)
        # ★ 恢复模态前的光标（幂等：即使这里没设过也安全）
        restore_modal_cursor(context)
        return {result}

    def cancel(self, context):
        """模态被外部取消（插件卸载 / 窗口关闭 / 被抢占）时的兜底清理。

        ⚠️ 2026-09-16 新增：本类此前**没有 cancel** ——
           模态被外部取消时 `_finish` 不会被调用，
           光标会**卡在模态光标上**。这里补上恢复。
        """
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        restore_modal_cursor(context)


# ---------------------------------------------------------------------------
# keymap 注册（普通 keymap，允许；modal keymap 不允许自建 —— 见模块 docstring）
# ---------------------------------------------------------------------------

_addon_keymaps = []

DEFAULT_ENTRY_KEY = 'J'

# 第一条线：G/R/S -> mode
TRANSFORM_KEYS = (('G', 'MOVE'), ('R', 'ROTATE'), ('S', 'SCALE'))

# ⚠️ 原生 G/R/S 定义在「模式型 keymap」里（space_type='EMPTY'），实测确认：
#     [Object Mode] G -> transform.translate
#     [Pose]        G -> transform.translate
#    插件要接管就必须注册到同名 keymap，否则永远匹配不到。
MODE_KEYMAPS = ("Object Mode", "Pose")


def register_keymaps(entry_key=None):
    """注册【常驻】进入键。

    ⚠️ 用户 2026-09-15：**不再需要专门的速度手柄快捷键**。
       速度三角可以点选，选中后直接按 **G** 进入模态即可
       （见 RTMP_OT_KeyboardTransform.invoke 的路由）。
       因此这里不再注册 J。

    全部交互键（G/R/S）都改为【直接编辑模式开启期间】动态接管
    —— 它们会抢占原生 transform 快捷键，不能常驻注册。
    """
    return True


def unregister_keymaps():
    for km, kmi in _addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _addon_keymaps.clear()


# ---------------------------------------------------------------------------
# G/R/S 的动态接管（只在【直接编辑模式】开启期间）
# ---------------------------------------------------------------------------

_transform_keymaps = []      # 动态注册的 (km, kmi)
_suppressed_native = []      # [(kmi, 原始 active)] —— 退出时恢复


def _active_keyconfig():
    wm = bpy.context.window_manager
    kcs = getattr(wm, "keyconfigs", None)
    return getattr(kcs, "active", None) if kcs is not None else None


def find_native_transform_items():
    """当前 keyconfig 里 Object Mode / Pose 的原生 G/R/S 条目。

    ⚠️ 必须主动**禁用**它们：keymap 条目的匹配顺序不由插件控制，
       如果 Blender 先匹配到原生 `transform.translate`，插件永远轮不到
       —— 这就是"接管"要显式处理的第 1 步。
    """
    out = []
    kc = _active_keyconfig()
    if kc is None:
        return out
    for km in kc.keymaps:
        if km.name not in MODE_KEYMAPS:
            continue
        for kmi in km.keymap_items:
            if kmi.type not in ("G", "R", "S"):
                continue
            if kmi.shift or kmi.ctrl or kmi.alt:
                continue
            if not str(kmi.idname).startswith("transform."):
                continue
            out.append(kmi)
    return out


def suppress_native_transform():
    """临时禁用原生 G/R/S（记录原状态）。"""
    for kmi in find_native_transform_items():
        _suppressed_native.append((kmi, bool(kmi.active)))
        kmi.active = False


def restore_native_transform():
    """恢复原生 G/R/S。"""
    for kmi, was in _suppressed_native:
        try:
            kmi.active = was
        except Exception:
            pass
    _suppressed_native.clear()


def register_transform_keys():
    """注册插件 G/R/S 并抑制原生 —— 进入直接编辑模式时调用。"""
    if _transform_keymaps:
        return True                      # 已在位
    wm = bpy.context.window_manager
    kc = getattr(wm, "keyconfigs", None)
    addon_kc = getattr(kc, "addon", None) if kc is not None else None
    if addon_kc is None:
        return False

    for km_name in MODE_KEYMAPS:
        km = addon_kc.keymaps.new(name=km_name, space_type='EMPTY')
        for k, mode_name in TRANSFORM_KEYS:
            kmi = km.keymap_items.new(RTMP_OT_KeyboardTransform.bl_idname, k, 'PRESS')
            try:
                kmi.properties.mode = mode_name
            except Exception:
                pass
            _transform_keymaps.append((km, kmi))

    suppress_native_transform()
    return True


def unregister_transform_keys():
    """注销插件 G/R/S 并恢复原生 —— 退出直接编辑模式时调用。"""
    for km, kmi in _transform_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _transform_keymaps.clear()
    restore_native_transform()


def update_edit_mode_active(self, context):
    """`window_manager.rtmp_edit_mode_active` 的 update 回调。

    挂在属性上（而不是某个 operator 里）是关键：
    `rtmp_edit_mode_active` 有**多个**写入点 ——
      ① `RTMP_OT_ToggleEditMode`
      ② `interaction._find_and_start_motion_path_operators`（打开路径显示时自动开）
      ③ 脚本 / UI 直接赋值
    挂在属性上才能全覆盖，不会漏。
    """
    if getattr(self, "rtmp_edit_mode_active", False):
        register_transform_keys()
    else:
        unregister_transform_keys()


classes = (
    RTMP_OT_ModalEdit,
    RTMP_OT_KeyboardTransform,
)
