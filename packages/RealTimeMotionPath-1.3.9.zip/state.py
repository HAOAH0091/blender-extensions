import bpy
import mathutils

# ⚠️ handles 是纯几何模块（不 import bpy，也不 import 本模块）⇒ 不会循环导入。
from . import handles as hd


def get_addon_prefs(context):
    return context.preferences.addons[__package__].preferences


# ★★ 2026-09-19：**不参与**「清残留」的 handler 列表。
#    它们由 `undo_guard` 独立、幂等地管理；且本函数会被自动刷新守护进程
#    反复调用（`RTMP_OT_PathRefreshDaemon.invoke()`），一并清掉会让
#    「撤销后清缓存」的钩子失效（用户实机复现的 bug）。
_PURGE_PROTECTED = ("undo_post", "redo_post")


def purge_stale_app_handlers():
    """移除**所有属于本插件**的 `bpy.app.handlers` 回调 —— 防叠积 / 防残留。

    ⚠️ 例外：`_PURGE_PROTECTED`（undo_post / redo_post）会被**跳过**——
       它们由 `undo_guard` 独立幂等地管理，且本函数会被守护进程反复调用，
       无差别清掉会误伤「撤销后清缓存」的钩子（2026-09-19 实测踩坑，见下）。

    ★ 2026-09-17（用户报"绘制残留"后顺藤摸瓜抓到的同类问题）：
      实测 `depsgraph_update_post` 里叠了 **3 个** `on_depsgraph_update`
      （全是本插件的），其中**旧模块**那个还在读已删除的 WindowManager 属性
      ⇒ 每次 depsgraph 更新都抛 `AttributeError`（控制台刷屏、白耗性能）。

    ▎机理（与 draw_handler 泄漏同源）
      · 注册判据是 `if on_depsgraph_update not in bpy.app.handlers.xxx`
        —— 比的是**函数对象身份**。跨模块重载后那是**新对象**，
        与列表里残留的旧对象不相等 ⇒ 判重失效 ⇒ 再 append 一个 ⇒ **叠积**。
      · `unregister()` 不清 app handlers ⇒ 插件卸载后它们还留着。

    ▎判据
      `getattr(h, "__module__", "").startswith(__package__)`
      —— 跨模块重载后旧函数的 `__module__` 仍是包名（可靠）；
        而"函数对象身份"跨重载就断了（这正是原判据失效的原因）。

    返回被移除的 `"<handler 列表名>.<函数名>"` 列表。
    """
    removed = []
    pkg = __package__
    try:
        items = [(a, getattr(bpy.app.handlers, a)) for a in dir(bpy.app.handlers)
                 if not a.startswith("_")]
    except Exception:
        return removed
    for attr, lst in items:
        # ★★ 2026-09-19：**跳过** undo_post / redo_post —— 它们由 `undo_guard`
        #    独立、幂等地管理（`register_undo_handlers` / `unregister_undo_handlers`）。
        #
        #    ⚠️ 踩坑实录：本函数会在 `RTMP_OT_PathRefreshDaemon.invoke()` 里被
        #       **反复调用**（自动刷新守护进程每次启动都调）—— 而无差别地按
        #       `__module__` 前缀清，会把 `undo_guard` 挂的两个 handler 一并删掉。
        #       后果：撤销后清内存缓存的钩子失效 ⇒ 用户报「双击锁定后 Ctrl+Z
        #       撤不掉锁定状态」的修复**上线即失效**（用户实机复现）。
        #       实测：purge 一次 ⇒ removed=['redo_post._on_redo_post',
        #       'undo_post._on_undo_post']，两个列表双双归零。
        if attr in _PURGE_PROTECTED:
            continue
        # `bpy.app.handlers` 里有的属性不是列表（如 persistent 是个函数）⇒ 过滤
        if not isinstance(lst, list):
            continue
        for h in list(lst):
            try:
                if str(getattr(h, "__module__", "")).startswith(pkg):
                    lst.remove(h)
                    removed.append("%s.%s" % (attr, getattr(h, "__name__", "?")))
            except Exception:
                continue
    return removed


def addon_pref(name, default=None):
    """安全读取插件**偏好设置**里的属性（拿不到就返回 default）。

    ★ 2026-09-17：性能设置（更新模式 / 交互帧率 / 轮询频率）从
      `WindowManager` 属性迁到 `AddonPreferences` 属性 —— 因为
      **WindowManager 上的属性不写入文件**（实测：设 TIMER/33/7 → 保存 → 重开
      变成默认的 SMART/60/10；RNA 的 `is_runtime` 也为 True），
      用户「改完重启就丢」，不符合"偏好设置"的语义。
      AddonPreferences 属性存进 userpref ⇒ 全局且持久。

    ⚠️ 在 handler / modal / 后台线程里 `context` 可能不完整，或者插件尚未
      加载完 ⇒ 本函数吞掉异常并返回 `default`（调用方必须给出与注册默认值
      一致的 default，避免行为漂移）。
    """
    try:
        return getattr(bpy.context.preferences.addons[__package__].preferences, name)
    except Exception:
        return default


class MotionPathSession:
    """管理运动路径编辑会话的状态"""
    
    def __init__(self):
        self._initialize_defaults()
    
    def _initialize_defaults(self):
        """初始化所有状态变量"""
        self.drag_in_progress = False
        self.mouse_origin = None
        self.world_origin = None
        self.item_initial_pos = None
        self.active_path_point = None
        self.active_frame_number = None
        self.active_handle_direction = None
        self.active_bone_identifier = None
        self.handle_control_points = []
        self.active_handle_index = None
        self.active_handle_info = None
        self.handle_edit_in_progress = False
        self.drag_target_object = None
        self.cached_positions = {}
        self.handle_start_values = {}
        # ★ P2.1（2026-09-16）：鼠标拖手柄时记录的【三点快照】(co/hl/hr + 类型)。
        #   加权收尾要取"对侧手柄的原始 3D 长度"，必须用【拖拽开始时】的值 ——
        #   `fc.update()` 之后 Blender 会按 (t,v) 规则改掉它。
        #   结构同 transform_domain.snapshot_endpoints()。
        self.endpoint_snapshot = {}
        self.render_callback_id = None
        self.path_point_sequence = {}

        # ---- 速度手柄（关键帧上下两个三角）----
        # ★ 盲审 S1（2026-09-18）：本插件按整数帧建模，非整数帧关键帧会被
        #   `int(kp.co[0])` 静默合并掉。用户已拍板"不支持子帧"，
        #   故这里只记数量 + 示例帧号，供 UI 明确提示（不静默吞）。
        self.subframe_keyframe_count = 0
        self.subframe_keyframe_examples = []

        self.hover_frame = None            # 鼠标正悬停的关键帧（None = 无）
        self.hover_handles = []            # 该关键帧的三角记录（供覆盖层绘制）
        # ★ 用户 2026-09-16：**精确**悬停到哪一个三角 —— (frame, tri) 或 None。
        #   与 `hover_frame`（关键帧级、半径 90px）不同，本字段用
        #   `SPEED_TRI_PICK_RADIUS`（22px）命中三角本身的屏幕位置，
        #   与「点击选中三角」共用同一个 `hd.hit_test` ⇒ 看到的 = 能抓的。
        #   用途：光标停在三角上时按 Backspace = 恢复该三角的默认值（匀速）。
        self.hover_speed_tri = None
        # ★ 多选（用户 2026-09-16）：Shift+点击可累加多个三角，一起滑移
        self.selected_speed_handles = []   # [(frame, tri), ...] 选中的三角集合
        # 下面两个 = "最后选中的那个"（供 G/S 路由、状态栏显示用）
        self.selected_speed_frame = None
        self.selected_speed_tri = None
        self.speed_drag_active = False     # 是否正在拖拽三角
        self.speed_drag_precision = False  # 拖拽中是否按住 Shift（精度 ×0.1）
        # 多选：每个三角各自记录按下时的 d（相对拖拽用） → {(frame, tri): d}
        self.speed_drag_origins = {}
        self.speed_drag_origin_d = 0.0     # 兼容：主选中三角的 d
        self.speed_drag_origin_mouse = None
        # ⚠️ 精度模式必须用【增量累积】（用户 2026-09-16 要求 ③）
        #    总量法下，一按 Shift 会把【此前走过的位移】也乘 0.1 → 三角跳回起点附近。
        #    这里累积"已按灵敏度缩放过的"竖直位移，Shift 只影响【此后】的移动。
        self.speed_drag_effective_px = 0.0
        self.speed_drag_last_mouse = None
        # ★ 2026-09-17：按下时所在 3D 视图 region 的偏移 (x, y)；
        #   拖拽期间用它换算鼠标局部坐标，保证拖出视图时坐标连续。
        self.speed_drag_region = None

        # ★ 2026-09-17（用户需求）：**双击三角 = 复制同关键帧另一个三角的速度值**。
        #   上次点击三角的记录，用于自判双击：
        #       {'frame': float, 'tri': str, 't': float(monotonic), 'pos': (x, y)}
        #   ⚠️ 不用 Blender 的 `event.value == 'DOUBLE_CLICK'`
        #      （modal 里能否收到不确定）⇒ 用【时间 + 位置】自己判，
        #      行为确定、且可被 headless 测试直接驱动。
        #   ★ 2026-09-18：语义升级为「**切换一体 / 分离**」（不再是"复制值"，
        #      复制只发生在"锁回去"那一刻）—— 见 `interaction.toggle_tri_lock_click`。
        self.speed_click_info = None

        # ★★ 2026-09-18（用户需求）：三角「一体」拖动时，**两侧共用同一个 s 基准**。
        #
        #   乙方案（用户拍板"先按乙做"）：一体 = 一个旋钮，两边速度**始终相同**、
        #   同向变（一起变快 / 一起变慢）。与"两边各自从自己的 d0 起算"（甲）不同：
        #   甲会让两侧 s 分道扬镳（左边变快、右边变慢）。
        #
        #   ⚠️ 必须是**数据层**的 s（不是像素 d0）：两侧的 span 不同 ⇒ 同一个像素
        #      位移对应的 s 增量不同；要以"两边 s 相等"为准，就得从 s 基准换算。
        #   见 `interaction._apply_speed_from_drag` / `modal_edit.ModalSession.apply`。
        self.speed_drag_group_origin_s = None
        # 本次拖动是否处于「一体」语义（选中集是否来自同一个锁定帧的两个三角）
        self.speed_drag_locked_frame = None

        # ★★ 2026-09-18（性能修复）：手柄拖拽被**帧率节流跳过**时的收尾用。
        #   记录"最新鼠标位置"（无论是否节流都更新）——
        #   松手时用它补写最后一段位移，防"跳变"。
        #   见 `interaction.flush_pending_speed_drag`。
        self.speed_drag_pending_mouse = None

        # ---- 手柄端点选中（用户 2026-09-16）----
        # 原生曲线编辑里，**手柄端点**与**关键帧点**是各自独立的可选中对象；
        # 用户可以只选端点，然后对端点做 G/R/S。
        self.selected_handle_endpoints = []   # [(frame, side), ...]

    # ---- 速度三角：多选集合操作 ----

    def is_speed_handle_selected(self, frame, tri):
        for (f, t) in self.selected_speed_handles:
            if abs(float(f) - float(frame)) < 1e-3 and t == tri:
                return True
        return False

    def add_speed_handle(self, frame, tri):
        if not self.is_speed_handle_selected(frame, tri):
            self.selected_speed_handles.append((float(frame), tri))
        self.selected_speed_frame = float(frame)
        self.selected_speed_tri = tri

    def remove_speed_handle(self, frame, tri):
        self.selected_speed_handles = [
            (f, t) for (f, t) in self.selected_speed_handles
            if not (abs(float(f) - float(frame)) < 1e-3 and t == tri)]
        if not self.selected_speed_handles:
            self.selected_speed_frame = None
            self.selected_speed_tri = None
        else:
            self.selected_speed_frame, self.selected_speed_tri = self.selected_speed_handles[-1]

    def toggle_speed_handle(self, frame, tri):
        if self.is_speed_handle_selected(frame, tri):
            self.remove_speed_handle(frame, tri)
            return False
        self.add_speed_handle(frame, tri)
        return True

    def set_single_speed_handle(self, frame, tri):
        self.selected_speed_handles = [(float(frame), tri)]
        self.selected_speed_frame = float(frame)
        self.selected_speed_tri = tri

    def set_locked_pair_speed_handle(self, frame, present_tris=None):
        """★ 2026-09-18：选中**同一个关键帧的两个三角**（"一体"状态）。

        `present_tris`：该帧**实际存在**的三角（端点上只有一个 ——
        首帧没有左段三角 / 末帧没有右段三角）。缺省 = 两个都有。

        只有**两个都选中**才算"一体"—— 所以这里不叫 set_single。
        """
        tris = list(present_tris) if present_tris else [hd.TRI_UP, hd.TRI_DOWN]
        self.selected_speed_handles = [(float(frame), t) for t in tris]
        self.selected_speed_frame = float(frame)
        # 主三角（供状态栏 / 旧接口）：优先"上"（左段）
        self.selected_speed_tri = tris[0] if tris else None

    def is_locked_pair_selected(self, frame):
        """★ 2026-09-18：该帧**两个三角**是否都被选中（= "一体"手柄被抓住）。"""
        try:
            f = float(frame)
        except Exception:
            return False
        got = {t for (ff, t) in self.selected_speed_handles
               if abs(float(ff) - f) < 1e-3}
        return got == {hd.TRI_UP, hd.TRI_DOWN}

    # ---- 手柄端点：多选集合操作 ----

    def is_endpoint_selected(self, frame, side):
        for (f, s) in self.selected_handle_endpoints:
            if abs(float(f) - float(frame)) < 1e-3 and s == side:
                return True
        return False

    def toggle_endpoint(self, frame, side):
        if self.is_endpoint_selected(frame, side):
            self.selected_handle_endpoints = [
                (f, s) for (f, s) in self.selected_handle_endpoints
                if not (abs(float(f) - float(frame)) < 1e-3 and s == side)]
            return False
        self.selected_handle_endpoints.append((float(frame), side))
        return True

    def clear_endpoints(self):
        self.selected_handle_endpoints = []

    def frame_has_selected_endpoint(self, frame):
        """该关键帧是否有端点被选中。

        ⚠️ 为什么 drawing 需要知道这个（2026-09-16 实测 bug）

        `drawing.render_keyframe_marker` 里，端点是在
        `if is_selected_keyframe:` 分支里收集/绘制的。
        而"只选中端点"时我们会清掉关键帧点的 `select_control_point`
        → `is_selected_keyframe` 变 False → **端点下一帧不再被收集**
        → 端点从视口消失，且 `handle_control_points` 为空导致**再点也命中不了**
        （用户实测："点击后直接消失了，应该没选中判定"）。

        修法：端点绘制条件加入本判定，让"端点选中"时仍然绘制端点。
        """
        for (f, _s) in self.selected_handle_endpoints:
            if abs(float(f) - float(frame)) < 1e-3:
                return True
        return False

    def clear_speed_handle(self):
        """清掉速度手柄的选中/悬停状态。"""
        self.hover_frame = None
        self.hover_handles = []
        self.hover_speed_tri = None
        self.selected_speed_handles = []
        self.selected_speed_frame = None
        self.selected_speed_tri = None
        self.speed_drag_active = False
        self.speed_drag_precision = False
        self.speed_drag_origins = {}
        self.speed_drag_origin_d = 0.0
        self.speed_drag_origin_mouse = None
        self.speed_drag_effective_px = 0.0
        self.speed_drag_last_mouse = None
        self.speed_drag_normalized = False  # ★ 本次拖拽是否已规范化超范围的 s

    def reset(self):
        """重置会话状态"""
        self._initialize_defaults()
    
    def clear_handles(self):
        """清除手柄控制点"""
        self.handle_control_points = []


_session = MotionPathSession()

_cache_update_lock = False

HANDLE_SELECT_RADIUS = 20


# ★★ 2026-09-18（用户反馈"关键帧点和三角控制柄容易误触"）：
#   关键帧点的**保护半径** —— 鼠标离关键帧点这么近时，**不许**被三角抢走。
#
#   为什么要它（实测数据，不是感觉）：
#     关键帧点可见半径 = keyframe_point_size/2 = **5px**
#     三角画在距关键帧 [18.5, 33.5]（尖端 18.5、本体中心 26）
#     而三角的拾取盘是「以三角中心 26 为圆心、半径 22」⇒ 覆盖 [4, 48]  ⇐ 根因
#     ⇒ [4, 18.5] 这段**什么都没画**的空白区也被算成三角，
#       用户瞄着关键帧点往上偏一点点就掉进这块虚拟领地。
#
#   取值 14 的依据（两个方向都量过）：
#     · 下界：> 可见半径 5，且要给"手不稳"留余量 ⇒ 比原来的 4 大得多
#     · 上界：< 三角尖端 18.5（用户瞄三角时**先够到的是三角，不是关键帧**）
#     ⇒ 14 落在 [5, 18.5] 中间偏上，两边都稳。
#
#   ⚠️ 只作用于**三角命中判定**（`interaction._triangle_under_cursor`）；
#      端点手柄的既有优先级不受影响（见 `get_handle_at_cursor`）。
KEYFRAME_PICK_PRIORITY_RADIUS = 14.0

# ★ 空心圆抓取点（手柄长度为 0 时的抓取点）的【独立】拾取半径。
#
# 为什么必须【小于】HANDLE_SELECT_RADIUS(20)：
#   `locate_point_under_cursor` 命中关键帧 / 路径采样点用的也是 20px。
#   若空心圆盘也用 20px，则圆心距 = `drawing.ENDPOINT_PICK_OFFSET_PX` < 20 + 20
#   ⇒ 两盘必然重叠 ⇒ 用户点关键帧盘内（离中心 20px 内）时会被手柄抢走。
#   实测（code review 2026-09-17）：偏移 28px 时重叠区 = [8, 20]px，
#   关键帧安全区只剩中心 ±8px；停顿段（相邻关键帧值相同 ⇒ 手柄长度 0）
#   的中间帧 100% 复现误触。
#
# 取值依据：偏移 32 ≥ 20(关键帧盘) + 12(空心盘) ⇒ 两盘【相切不重叠】，
#   且两边都是严格小于判定 ⇒ 至少留 1px 空档。
HANDLE_HOLLOW_PICK_RADIUS = 12

# ★ 「手柄长度 = 0」的【屏幕】判据阈值（像素）。
#
# ⚠️ 口径必须是【屏幕像素】，不能是【世界长度】—— 实测（2026-09-17）：
#   1 世界单位 ≈ 49px ⇒ `HANDLE_ZERO_EPS(1e-4)` 世界单位 ≈ **0.005px**。
#   用户用手拖出来的"很短"（屏幕上还有 1~20px）**永远达不到 1e-4**
#   ⇒ 存在一个「短但不为零」的死区：既不画空心圆、抓取点又落回关键帧上（误触回归）。
#   用户实测反馈："中间帧手柄缩小至关键帧点处后，空心圆有时会不出现"。
#
# 取值依据：关键帧点默认直径 `keyframe_point_size = 10`（半径 5px）
#   ⇒ 手柄末端进到关键帧点圆内（屏幕距离 < 5px）时视觉上已被盖住
#   ⇒ 取 6px（= 5 + 1px 余量）。比它小会在"视觉已重合"时仍不判零；
#      比它大会让**明显可见的**手柄线（>6px）被判成零长度。
#
# ⚠️ 本阈值由 `drawing.handle_is_zero_length()` 单点使用，绘制侧与交互侧共用，
#    【不得】再写第二份判据（否则两边判据漂移 ⇒ 一边画圆环、一边还按几何命中 ⇒ 打架）。
HANDLE_ZERO_SCREEN_PX = 6.0

SAFE_LIMIT = 1000000.0
MIN_HANDLE_SCALE = 0.1
MAX_HANDLE_SCALE = 100.0

# ★ 「手柄长度为 0」的【世界长度】阈值。
#
# ⚠️ 2026-09-17 起它【不再是主判据】—— 主判据是屏幕像素口径的
#    `HANDLE_ZERO_SCREEN_PX`（见上），由 `drawing.handle_is_zero_length()` 统一使用。
#    本常量现仅作该函数的**降级路径**：拿不到视图上下文（后台 / 无 region）时兜底。
#
# （历史）它曾与 `interaction.locate_handle_under_cursor` 的 `world_vector.length > 1e-4`
#    守卫配套、严格互补。改为屏幕口径后，那处守卫改为调用同一个 `handle_is_zero_length()`，
#    仍是严格互补 —— 只是判据本体换了口径。
#
# ⚠️ 下面这条仍然成立（换口径后更容易踩）：比较时【不得】用乘过 `handle_scale` 的量，
#    否则判据会随用户调 `rtmp_handle_scale` 而漂移。
HANDLE_ZERO_EPS = 1e-4
