"""undo_guard.py — 撤销 / 重做之后，让插件的**内存缓存**失效（快路径）。

⚠️⚠️ v1.3.8 起：**本模块不再是正确性的依赖**。
    正确性已由「读之前对账」（`transform_domain._xxx_sync` /
    `time_domain._frozen_sync`）保证 —— property 是唯一真相，缓存只是派生。

    为什么改（v1.3.6 / v1.3.7 两次"上线即失效"的血泪）：
      实测发现**用户现场会话里 `undo_post` / `redo_post` 列表是空的**
      （加载时序 / 被别的清理逻辑扫掉 / 第三方插件 / 本来就没挂上）。
      "挂 hook 清缓存"一旦 hook 不在场 ⇒ 缓存永久失真 ⇒ 用户复现
      「Ctrl+Z 撤销不了锁定状态」。
      ⇒ 结论：**正确性不能依赖"某个钩子是否挂上了"**。

    本模块保留的价值：hook 在场时可以直接清缓存，省掉下一次的重建（快路径）；
    即使它没挂上 / 被清掉，读侧的对账也会兜住。


★★ 2026-09-19（用户报：「双击三角锁定或解锁后，Ctrl+Z 撤销时锁定状态本身不会撤销」）

▎根因：两层存储 + 「先查内存、命中即返回」

  插件里有一类状态被存成**两层**：

    ① Python 模块级字典（内存镜像）—— 供高频查询，快
    ② action 的 custom property  —— 真正**随文件持久化**的那份

  查询函数走【先查内存，命中就返回】（见 `xf.is_tri_locked`）。
  而 Blender 的**全局 undo 是「整个 main database 的快照回滚」**——
  它会正确恢复 ②，但**碰不到 Python 模块变量** ①。

  ⇒ 撤销之后：property 已回到旧值，内存还记着新值
  ⇒ 查询返回**陈旧**结果 ⇒ 用户看到「撤销没生效」。

▎实测证据（2026-09-19，真 GUI 里按真 Ctrl+Z）

    before_undo_query : False                        （双击 → 分离）
    prop_after_undo   : None                         ★ Blender 确实恢复了 property
    query_after_undo  : False                        ★ 仍读内存旧值 ⇒ 症状复现
    mem_after_undo    : {('...', 14.0): False}       ★ 内存纹丝不动（真凶）

▎解法

  挂 `bpy.app.handlers.undo_post` / `redo_post`：撤销 / 重做之后
  **清空全部内存缓存 + 「已恢复」标记**，让下一次查询重新从 custom property
  惰性 warm（这套惰性恢复机制本来就在，且天然覆盖「刚打开文件」）。

  ⚠️ 为什么「清」是安全的：四张表的 setter 都是
     「内存 + property **双写**」对称的（`set_tri_locked` / `mark_feel` /
     `mark_owned_free` / `mark_frozen`）⇒ 清掉内存不丢数据，下次查询 warm 回来。

▎一并覆盖的 4 张表（模式完全相同，同一颗雷）

    · `transform_domain._TRILOCK`          三角「一体 / 分离」 ← 用户本次报的
    · `transform_domain._FEEL`             手柄体感类型
    · `transform_domain._plugin_owned_free` 插件接管的 FREE 名单
    · `time_domain._FROZEN`                速度编辑冻结登记

  这四张表都是「内存镜像 + `_xxxx_warmed` 惰性恢复」，全都会被 undo 架空。
  只修看得见的那一处 ⇒ 切一次就打回原形（同类问题一次性收口）。

▎注册 / 注销

  `register()` 里在 `purge_stale_app_handlers()` **之后**调用
  `register_undo_handlers()`；
  `unregister()` 调 `unregister_undo_handlers()`。

  ⚠️⚠️ 但**光这样不够**（v1.3.6 上线即失效的教训）：

  `state.purge_stale_app_handlers()` 会按 `__module__` 前缀无差别扫**所有**
  handler 列表 —— 它会把本模块挂的两个 handler 一起删掉。而这个函数
  **不是只在注册时跑一次**：`RTMP_OT_PathRefreshDaemon.invoke()`（自动刷新
  守护进程，用户**进入编辑模式**时被 invoke）里**每次都调它**。

  ⇒ 插件注册时挂上 → 用户一进编辑模式就被清掉 → 撤销又不生效。
    实测：`purge` 一次 ⇒ removed=['redo_post._on_redo_post',
                              'undo_post._on_undo_post']，双双归零。

  解法：`state._PURGE_PROTECTED = ("undo_post", "redo_post")` —— purge 跳过它们。
  （因此 `unregister()` 里的 `unregister_undo_handlers()` 是**必需**的，
    不能再指望 purge 兜底。）
"""

import bpy


def clear_all_state_caches():
    """清空本插件**全部**「内存镜像 + 已恢复标记」，强制下次从 property 重读。

    幂等、无副作用（理由见模块 docstring：所有 setter 双写对称）。
    返回被清的表名列表，便于日志 / 断言。
    """
    cleared = []
    # ① 三角锁定 / 体感类型 / 插件接管的 FREE 名单（都在 transform_domain）
    try:
        from . import transform_domain as xf
        xf.clear_tri_lock()
        cleared.append("tri_lock")
        xf.clear_feel()
        cleared.append("feel")
        xf.clear_owned_free()
        cleared.append("owned_free")
    except Exception:
        pass
    # ② 速度编辑冻结登记（time_domain）
    try:
        from . import time_domain as td
        td.clear_frozen()
        cleared.append("frozen")
    except Exception:
        pass
    return cleared


def _on_undo_post(scene):
    """`bpy.app.handlers.undo_post` 回调（签名：收一个 scene 参数）。"""
    clear_all_state_caches()


def _on_redo_post(scene):
    """`bpy.app.handlers.redo_post` 回调（同上）。"""
    clear_all_state_caches()


_HANDLER_ATTRS = ("undo_post", "redo_post")


def _remove_ours(attr):
    """按 `__module__` 前缀移除本插件在该 handler 列表里的全部回调（防叠积）。"""
    lst = getattr(bpy.app.handlers, attr, None)
    if not isinstance(lst, list):
        return 0
    n = 0
    for h in list(lst):
        try:
            if str(getattr(h, "__module__", "")).startswith(__package__):
                lst.remove(h)
                n += 1
        except Exception:
            continue
    return n


def register_undo_handlers():
    """挂 `undo_post` / `redo_post`（幂等：先按模块名清旧的，再加）。

    ⚠️ 判据用 `__module__` 前缀而非函数对象身份 —— 跨模块重载后
       对象身份会变（这正是历史上 handler 叠积的根因，见 state.py）。
    """
    fns = {"undo_post": _on_undo_post, "redo_post": _on_redo_post}
    for attr, fn in fns.items():
        lst = getattr(bpy.app.handlers, attr, None)
        if not isinstance(lst, list):
            continue
        _remove_ours(attr)
        lst.append(fn)


def unregister_undo_handlers():
    """摘掉本插件挂的 `undo_post` / `redo_post`。"""
    for attr in _HANDLER_ATTRS:
        _remove_ours(attr)
