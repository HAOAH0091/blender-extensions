# 开发历史记录

## 2026-09-19 (Behavior — 一体拖动改为「两侧各加减同一增量」) → v1.3.9

### Context
用户反馈：**"双击锁定三角后拖动一体化的三角，三角的数值会被强行同步为相同数值，
一体化锁定的定义应该是可以同时做增量调整，不是改变稀疏数值为相同"**。

### 语义变更（用户拍板）
| | 旧（2026-09-18 拍板） | 新（2026-09-19 拍板） |
|---|---|---|
| 一体拖动 | 两侧写**同一个 s**（"一个旋钮"，速度始终相同） | 两侧**各加减同一增量**，**差异保留** |
| 实测 | 1.33x / 0.83x → **0.74x / 0.74x** | 1.33x / 0.83x → **0.74x / 0.46x** |

方向仍**统一取 UP**（上=更疏）—— 不能用各三角自己的 DIR，
否则两侧一个变疏一个变密。变的只是"数值各算各的"。

### 改动
- `interaction._apply_speed_from_drag`：一体分支不再算"共用的 s"，
  改为「每侧自己的 d + 同一个 signed_px」（两分支合并，语义显式）。
- `modal_edit.SpeedDragModal.apply`：同样改法（G/S 模态路径必须同步，
  否则两路手感不一致 —— 测试 G5 守这条）。
- `time_domain.group_drag_s`：标注**已废弃**（保留兼容，产品不再调用）。

### ★ 实装时踩到的真问题（顺手修掉）
1. **双重累加 ⇒ 跳变**（本次差点引入）
   第一版实现"每帧现读当前 s + 累积位移"，但 `speed_drag_effective_px`
   与 `px_offset` 都是**【累积】**位移 ⇒ 越拖加得越多 ⇒ 指数漂移。
   是既有测试 D4 的判据把它逼出来的。
   ⇒ 修正：起点必须取**按下时记录的固定 d**。
   ⇒ 新增断言 **D7「多步拖动 ≡ 单步同位移」**（8 步 vs 1 步）防回归。
2. **拖拽起点口径：clamped → unclamped**
   `speed_drag_origins` 原取 `h['d']`（`s_to_d`，**钳制版**）；当用户在 GE 里
   拖手柄让 s 越过 [S_EPS, S_HARD_MAX] 时会丢信息 ⇒ "一动就打满 / 拖不动"
   （2026-09-17 用户实测报告过）。⇒ 改用 `s_to_d_unclamped`。
   ⚠️ 这**同时影响非一体（多选/分离）分支**，属行为修正（与既有注释的设计意图一致）。

### 测试判据的精度问题（实测钉死）
`abs(Δd_左 − Δd_右) < 1e-6` 会假失败 —— Blender 把手柄坐标存成 **float32**：
```
s = 0.677 写入后读回 0.6770000457763672  ⇒ d 残差 1.8e-06
（纯数学 d→s→d 往返误差为 0，说明不是映射问题）
```
⇒ 容差放宽到 **1e-4**（亚像素，视觉不可见），并在测试里注明来源。

### 验证
- `gui_tri_lock_check.py` **48 项 ALL PASS**（含新增 D7）；
  D1/D4 判据改为「Δd 相等 + 差值不变」；H 组注入场景同步改为"差异保留"，
  注入也换成"退回旧语义（两侧同值）"。
- 视觉验收：`group_drag_delta.png` —— 左图两条**平行线**（间距恒 10.58）、
  右图两侧同向变（一起慢/一起快）+ 旧行为对照箭头。已用 vision 复核（无重叠/乱码）。
- 全量回归 **276 项断言 / 0 失败**；3 个存量探针失败与基线一致。
- 真 GUI 多步拖动：结果与单步**完全一致**（71.9109 / 62.2889）。

### 已知边界（数学必然，非缺陷）
一侧触到物理极限（s → S_EPS 或 S_HARD_MAX）后会被钳住，该侧 d 不再变化
⇒ 极值区间内"差异"会缩小。实测：拖 +60px 时左侧先触下限，故 Δ 左 23.93 < Δ 右 24.89。

---

## 2026-09-19 (Bugfix³ — 撤销修复彻底换机制：从「挂 hook」改成「读前对账」) → v1.3.8

### Context
用户实测：**"撤销只是撤销了 GE 的共线操作，3D 视图的三角控制柄的一体锁定解算的状态
本身没有撤销"**，并给了许可在他的工程（`F:\desktop\test2.blend`，Suzanne +
SuzanneAction，关键帧 1/37/88，手柄全 AUTO_CLAMPED）里实测。

### 真凶（在用户现场实测钉死）
用户会话里 **`undo_post` / `redo_post` 列表是空的**：
```
handlers 实测: {"undo_post": [], "redo_post": []}
```
⇒ v1.3.6/v1.3.7 的「挂 hook 清缓存」方案**根本没在场** ⇒ 缓存永久失真
⇒ 撤销后 property 已回滚、内存仍是旧值 ⇒ 用户看到"锁定状态没撤销"。

复现（撤掉 hook，用户工程里）：
```
双击      : prop=["37.0000|SPLIT"]  mem={(Suzanne,37):False}  locked=false
Ctrl+Z    : FINISHED
撤销后    : prop=null   ← property 撤销了
            mem={(Suzanne,37):False}  ← 内存没清
            locked=false  ★ 症状
```

### 结论：**"挂 hook"这条路本身不够**
只要钩子没挂在场（加载时序 / 被别的清理逻辑扫掉 / 第三方插件 / 会话里本来就没挂上），
正确性就崩。**正确性不能依赖"某个钩子是否挂上了"**。

### 改动：改成「读之前对账」（property 是唯一真相，缓存只是派生）
四张表全部改造（`_TRILOCK` / `_FEEL` / `_plugin_owned_free` / `_FROZEN`）：

| 新增 | 作用 |
|---|---|
| `_XXX_SRC = {action 名: property 原文}` | 记"缓存是从哪份 property 推出来的" |
| `_xxx_sync(act)` | 每次查询前比一次原文；不一致就**整表重建** |
| （读侧）`is_tri_locked` / `feel_type` / `_is_plugin_owned_free` / `is_frozen` | 查询前先 `sync` |

撤销 / 重做改的就是 property ⇒ **天然被感知，不依赖任何 handler**。
hook（`undo_guard`）保留为"清缓存快路径"，但**不再是正确性的依赖**
（实测：把 `clear_all_state_caches` 打桩成空操作，结果仍正确 —— 见测试 F1）。

### ★★ 二重判据（既有测试替我抓到的坑）
第一版只比 `SRC`，**13 个既有断言失败**：外部若**只清空内存镜像**
（模拟"重开文件" / 别的模块 reset），`SRC` 还留着 ⇒ 误判"缓存有效" ⇒ **永远不恢复**。
⇒ 快路径补第二重判据：**`raw` 非空时，缓存必须仍有该 action 的条目**，
否则也重建（`_cache_has_entries` / `_td_cache_has_entries`）。

### 三处保护
1. **读不了 property 就别动缓存**：鸭子类型假对象（`gui_frozen_link_check` U13 用的）
   读不到 property ⇒ 若按"空"处理会清掉同名真缓存。⇒ 先 `act.get(PROP)` 探一次，
   抛异常就 `return`（保持缓存不动）。
2. 写入路径（`set_*` / `mark_*` / `unmark_*`）写完后**同步 SRC**，避免下次白重建。
3. `clear_*` 清缓存时**连 SRC 一起清**。

### 验证（全部在**用户那个工程**里做，真 GUI + 真 Ctrl+Z）
```
t0 一体 → 双击 → 分离  → Ctrl+Z → 一体 ✓ → Ctrl+Shift+Z → 分离 ✓
撤销后 mem 被清、prop=null、locked=true
```
- 四张表在**撤掉 hook**（模拟用户现场）下逐项验证：tri_lock / feel / frozen /
  owned_free **全部**跟上 property。
- 新增 `gui_undo_lock_check.py` **G 组（G0/G1/G2）**专门守这条：
  hook 不在场时也必须正确；并注入「对账失效」确保测试抓得住。
- 全量回归：**275 项断言 / 0 失败**；3 个存量探针失败（mouse_sentinel 1 / real_path 2）
  与 v1.3.7 基线一致。
- 用户工程数据完好（关键帧 / 手柄值 / 类型与备份逐位一致）。
- 既有测试有 3 处断言的是**旧优化语义**（"每 action 只读一次 property"），
  按新语义更新：`gui_frozen_link_check` T4/T10、`gui_endpoint_hollow_check` S11。

### 教训
**"挂上钩子"不等于"机制生效"**。修复的正确性如果依赖"某处注册成功"，
就必须：① 先**实测**它在真实会话里到底在不在场；② 尽量把正确性做成
**不依赖注册时序**的形式（本例：让缓存在读时自查）。

---

## 2026-09-19 (Bugfix² — v1.3.6 的撤销修复「上线即失效」，本次修好) → v1.3.7

### Context
用户实测反馈：**"我测试了一下好像锁定和解锁还是不能撤销啊"** —— v1.3.6 的修复没生效。

### 真凶：清残留逻辑把 undo 钩子一起清掉了（而它**每次进编辑模式都跑**）

v1.3.6 挂的 `undo_post` / `redo_post` handler，被这一行清掉了：

```python
# RTMP_OT_PathRefreshDaemon.invoke()   ← 自动刷新守护进程
purge_stale_app_handlers()            # ← 它按 __module__ 前缀无差别扫【所有】handler 列表
bpy.app.handlers.depsgraph_update_post.append(on_depsgraph_update)
```

`undo_guard` 挂的 handler，`__module__` 就是 `RealTimeMotionPath.undo_guard`
⇒ **一并被删**。而这个 daemon 不是只在注册时跑一次 ——
**用户"进入编辑模式"时就会被 invoke**（`interaction.py:1118` / `3147`）。

⇒ 完整用户流程：
```
插件注册 → undo handler 挂上 ✓
用户进入编辑模式（按 J / 点工具栏）→ daemon invoke → purge → handler 被删 ✗
双击分离 → 写 property
Ctrl+Z → 没有 handler ⇒ 内存缓存没清 ⇒ 撤销不生效 ✗
```

**实测（未修时）**：
```
purge 一次 ⇒ removed = ['redo_post._on_redo_post', 'undo_post._on_undo_post']
清前 undo_post=1 / redo_post=1 → 清后 0 / 0
```

### ★ 我上一轮为什么没抓到（教训）
v1.3.6 的验证是「disable/enable 插件 → **立刻**测 undo」——
**跳过了"进编辑模式 → daemon invoke"这个真实时序**。
handler 那时确实还在，所以测出来是 PASS。
⇒ **测试台本身骗人**：不是断言写错，是**验证时机不真实**。
（同类：只测"刚装好"，没测"跑一会儿之后"。）

### 改动
- `state.py`：新增 `_PURGE_PROTECTED = ("undo_post", "redo_post")`，
  `purge_stale_app_handlers()` **跳过**这两个列表（它们由 `undo_guard` 独立幂等管理）。
- `__init__.py`：`unregister()` 里的 `unregister_undo_handlers()` 从"双保险"升格为
  **必需**（purge 不再兜底，不显式摘就会残留）。
- 修正 v1.3.6 里写错的两处注释（把"会被 purge 清掉"当成优点）。

### 验证（这次走**真实时序**）
- 真 GUI：`enable → daemon('INVOKE_DEFAULT') 返回 RUNNING_MODAL →`
  `handler 仍 [1,1]` → `purge_removed=['depsgraph_update_post.on_depsgraph_update']`
  （只清该清的）→ 双击 → 真 Ctrl+Z：
  `prop_after_undo=null`、`mem_after_undo={}`、**`locked_after_undo=True`** ✓
- 新增断言（防再犯）：
  - **C6 ★★★** `purge_stale_app_handlers()` 不会清掉 undo/redo handler
  - **C7 ★★** 连清 4 次（守护进程反复 invoke）仍恰好各 1 个
  - **C8 ★★** 保护归保护：`unregister_undo_handlers()` 仍能摘干净（0/0）
  - **F2** bug 注入：把 `_PURGE_PROTECTED` 置空 ⇒ 测试抓住 ✓
- `gui_undo_lock_check.py` 23 项 ALL PASS；全量回归 **272 项 / 0 失败**。

---

## 2026-09-19 (Bugfix — 撤销后锁定状态不跟着回滚) → v1.3.6

> ⚠️ **本版修复上线即失效**（被测出"还是不能撤销"）—— 根因与修正见 v1.3.7。
>    保留完整记录：机理与真机证据都是对的，只是**漏了"守护进程会清 handler"**这一层。

### Context
用户反馈：**"用户双击三角锁定或者解锁后，ctrl z 撤销时锁定状态本身不会撤销"**。

### 根因（真机实测钉死，非推断）
锁定状态存**两层**：

| 存储 | 是什么 | Blender 全局 undo 管不管 |
|---|---|---|
| `_TRILOCK` | Python 模块级字典（内存镜像） | ❌ **碰不到** |
| `act["rtmp_tri_lock"]` | action 的 custom property（真正持久化） | ✅ 会恢复 |

`is_tri_locked` 的规则是「**先查内存，命中即返回**」；而 Blender 的全局 undo 是
「整个 main database 的快照回滚」——**它不知道 Python 模块变量是个什么**。
⇒ 撤销后 property 已回滚、内存仍是旧值 ⇒ 查询返回陈旧结果 ⇒ 界面看着"没撤销"。

**真 GUI 实测（真按 Ctrl+Z）：**
```
before_undo_query : False                        （双击 → 分离）
prop_after_undo   : null                         ★ Blender 确实恢复了 property
query_after_undo  : False                        ★ 仍读内存旧值 ⇒ 症状复现
mem_after_undo    : {('...', 14.0): False}       ★ 内存纹丝不动（真凶）
```

### ★ 同类地雷：一共 **4 张表**都是这个模式（同一颗雷）
- `transform_domain._TRILOCK` → 三角「一体 / 分离」（用户本次报的）
- `transform_domain._FEEL` → 手柄体感类型
- `transform_domain._plugin_owned_free` → 插件接管的 FREE 名单
- `time_domain._FROZEN` → 速度编辑冻结登记

全都是「内存镜像 + `_xxxx_warmed` 惰性恢复」⇒ 全都会被 undo 架空。
**只修看得见的那一处，切一次就打回原形** ⇒ 本次一次性收口。

### 改动
**新增 `undo_guard.py`**：
- `clear_all_state_caches()` —— 清空上述 4 张表的内存镜像 + 「已恢复」标记，
  让下次查询重新从 custom property 惰性 warm。
  （安全前提：4 张表的 setter 都是「内存 + property **双写**」对称的 ⇒ 清内存不丢数据。）
- 挂 `bpy.app.handlers.undo_post` / `redo_post`；注册判据用 `__module__` 前缀
  （跨模块重载后函数对象身份会变 —— 这正是历史上 handler 叠积的根因）。

**`__init__.py`**：`register()` 里挂（**必须排在 `purge_stale_app_handlers()` 之后**，
否则会被它清掉）、`unregister()` 里摘。

**`interaction.py`**：修一处**不对称** —— `toggle_frame_lock` 的
「分离 → 锁回一体」分支有显式 `undo_push`，「一体 → 分离」分支**没有**。

**`translations.py`**：新增 `"Split Handles" → "分离三角手柄"`。

### ★★ 第二部分实测：缺 `undo_push` 到底有没有后果？（用户要求"实测后再判断"）
走**真双击入口** + 真 undo 对比：

| | 双击分离后一次 Ctrl+Z | redo |
|---|---|---|
| **不补 push**（原状） | **越过了这一步** —— 实测退到更早状态，严重时**对象整体消失** | 回不到分离态 |
| **补 push**（修后） | 回到「一体」✓ | 回到「分离」✓ 完美往返 |

⇒ 结论：**缺 push 是真的有问题，不是洁癖**。已补上与锁回一体分支对称的 push。

### 验证
- 新增 `tests/gui_undo_lock_check.py`（19 项 ALL PASS）：覆盖 4 张表同源、
  handler 注册/注销/幂等/签名、静态契约（含"分离分支必须有 undo_push"）、
  「真双击确实推了 undo 点」的行为断言（拦 `ops.ed.undo_push`）、bug 注入。
- 真 GUI 端到端：修复后 `mem_after_undo = {}`、`query_after_undo = True`；
  补 push 后 undo/redo 完美往返。
- 全量回归 **50 文件 / 268 项断言 / 0 失败**（含主回归 15 PASS / 0 FAIL / 2 NOTE）。

### 踩坑记录（下次省一轮）
1. **`bpy.ops.ed.undo_push = fake` 打桩无效** —— bpy 的 ops 子模块**不接受属性赋值**
   （实测 `is` 判等为 False，静默失效）。改用「替换模块全局 `bpy` 为代理对象」。
2. **静态契约的锚点别用自然语言短语** —— 本次连栽两次：`"一体 → 分离"` 命中了
   docstring；`"分离 → 锁回一体"` 命中了**我自己新写的注释**（把片段截断成 146 字符）。
   ⇒ 锚点要落在**代码**上（如 `xf.set_tri_locked(act, frame, False)`、`# 分离 → 锁回一体`）。
3. **background 里跑不了真 undo**（`bpy.ops.ed.undo.poll()` 失败）⇒ 真撤销只能上 GUI；
   headless 测试用「模拟 property 回滚 + 调真 handler」代替。

---

## 2026-09-18 (Behavior — 双击三角改为「对齐 GE 手柄」) → v1.3.5

### Context
用户反馈：**"双击三角现在似乎只是把两个三角的速度分布值强行同步了而已，
我希望让强行对齐同步关键帧速度本身，也就是对齐 GE 里的控制柄，让 GE 控制柄共线"**
（附 Graph Editor 截图：曲线在关键帧处有明显折角）。

### 语义变更（用户拍板，四条）
| | 决定 |
|---|---|
| 替换 or 新增 | **替换** —— 双击不再"复制对侧疏密" |
| 哪些轴 | **所有轴**（X/Y/Z 各自对齐） |
| 代价 | **保形状**（3D 路径不动）⇒ 改疏密；**双击哪侧就改对端三角** |
| 罕见情况 | A、B 异号（人工拖歪）⇒ 走**镜像**，不报错不跳过 |

### 数学（唯一公式，共线与镜像通吃）
```
dt_对侧 = dt_本侧 × |值_对侧| / |值_本侧|
```
其中 `A = co[1] − handle_left[1]`、`B = handle_right[1] − co[1]`。
两侧斜率 `A/dtL`、`B/dtR` 的**绝对值相等**：
- **A、B 同号** ⇒ 斜率同号且相等 ⇒ **共线**（曲线平滑穿过关键帧）
- **A、B 异号** ⇒ 斜率反号、绝对值相等 ⇒ **镜像**（对称尖峰）

保形状成立的原因：只写 `handle[0]`（时间分量），A / B（值分量）原样不动。

### 实测（真机，Blender 5.2.2）
- **折角本来就是"插件改疏密"造成的**：Blender 原生手柄共线 `0.000°`，
  调速改了 dt 后出现 `8.65°` —— 用户截图里的折角正是这个。
- **纯用插件调永远到不了"异号"**：拖三角只写时间分量，拖 3D 手柄的联动
  本就是"绕关键帧旋转保共线"；120 条随机曲线 / 274 个中间帧，**异号 0 次**。
  异号只可能来自**人工在 GE 手动拖手柄**。
- **三轴 A/B 天然恒等**（≈ `dtL/dtR`，与轴、与值无关）⇒ 一个 dt 比率天然
  同时满足三轴。仅人工精修过（三轴 A/B 互不相同）时以**主用轴**为准、其余顺其自然。
- 极值点（峰/谷）：Blender 自动钳位把手柄拉平（A=B=0）⇒ **任意 dt 都共线**（平凡解）。

### 改动
`interaction.py`：
1. 新增 `_align_opposite_speed(context, obj, frame, tri)` —— 统一公式，返回
   `(ok, info, reason)`，`info.same_sign` 决定文案走"共线 / 镜像"。
2. `toggle_frame_lock` 的「分离 → 锁回一体」调用点从 `_copy_speed_value`
   换成 `_align_opposite_speed`。
   （`_copy_speed_value` **保留**，其单测继续有效。）
`translations.py`：下线旧"速度 %.2fx"文案，新增"已共线（平滑过渡）/
已镜像（对称尖峰）/手柄是水平的，无法对齐"三条。

### 验证
| 项 | 结果 |
|---|---|
| 真机调用链验证（`_align_verify.py`）| **16/16 PASS** |
| E2E 真机（真实 modal 入口，`tests/gui_ge_align_check.py`）| **8/8 PASS** |
| `gui_tri_lock_check.py` | 47/47 |
| `gui_dblclick_copy_speed_check.py` | 38/38 |
| 全量回归（49 文件）| **250 PASS / 0 FAIL** |
| 核心 `regression.py` | 15/15 |

### ⚠️ 两个坑（测试台本身的，重要）
1. **bug 注入打在空气上（假阳性）**：I6 原来注入 `_copy_speed_value`，
   而产品已改走对齐路径 ⇒ 注入根本没打中，测试却"抓住"了。
   已改成注入 `_align_opposite_speed`，并给所有注入项加**"注入是否真生效"自检**。
2. **判据口径**：原生手柄本来就共线 ⇒ 双击算出来"不变"是**正确**行为。
   要测出"确实改了"必须先**把疏密拖歪**（= 用户真实场景）。

### 两个探针脚本的存量失败（**非本次引入**）
`gui_mouse_sentinel_check.py`（1 项）、`gui_real_path_check.py`（2 项）
在 **v1.3.4（改动前发布点）** 上重跑，失败**完全一致** ⇒ 存量问题。

## 2026-09-18 (Perf — 手柄拖拽帧率节流) → v1.3.4

### Context
用户反馈：**"我在大幅度高频率拖动手柄时，GPU 利用率会快速升高，这是为什么？
有办法优化性能吗"** —— 要求**先分析、不动手**，用大白话解释。

### 分析（全部真机实测，test.blend：250 帧 / 4K 视口 3031x1798）

| 项目 | 实测 |
|---|---|
| 一次整屏重绘 | **3.87 ms** |
| 视口像素 | **5,449,738**（近 4K） |
| 采样点 | 250 个/帧 |
| 插件自身绘制 | 1.78 ms（draw call 仅 3 次，**不是瓶颈**） |
| 写值计算 | 1.46 ms |
| 悬停刷新 | 0.14 ms |
| **CPU 侧合计** | **2.94 ms/次** |

### 根因（一句话）
**不是"算得慢"，是"被逼着反复重画一整屏"。**

`interaction.py` 的速度拖拽分支在行 1372 命中后，于 1387 **无条件 `return`**
—— 而帧率限制（`max_interaction_fps`，默认 60）在 **1389 行**
⇒ **这个分支从来走不到节流**。鼠标动多快就重写 + 重绘多少次
（高刷鼠标 125~1000Hz），每次都要付 3.87ms 的整屏重绘。

### 改动（只做节流这一项 —— 用户拍板"只做这个试试"）
`interaction.py`：
1. 速度拖拽分支加**同样的帧率限制**（用独立的 `_last_speed_draw_time` 时钟，
   避免与路径点拖拽互相干扰）。
2. 按下时把节流时钟清零 —— 让**第一次移动立刻生效**（否则会有"迟钝"感）。
3. 新增 `flush_pending_speed_drag()`：松手时**强制补写**被跳过的最后一段位移。

⚠️⚠️ **节流为什么是安全的（关键，别把前提丢掉）**：
  写值是**增量法**（位移 = 本次鼠标 − 上次鼠标，且**只有真正写入时才更新
  `last_mouse`**）⇒ 被跳过的事件**不丢位移**（下一次自动把跳过那段一并带上）。
  但松手后没有"下一次"了 ⇒ 最后 ≤1 帧的位移会丢 = **跳变**（用户零容忍）
  ⇒ 所以 RELEASE **必须**补写，且必须在 `speed_drag_active = False` **之前**
  （补写函数靠这个标志判断"拖拽还在进行"）。

### 真机实测（500 次高频 MOUSEMOVE，4ms 间隔 = 250Hz 鼠标）

| | 修复前 | 修复后 | 变化 |
|---|---|---|---|
| 写入 + 重绘次数 | **500** | **100** | **↓80%** |
| CPU 耗时 | 483.5 ms | 94.7 ms | **↓5.1×** |
| 最终值 | 0.283563 | 0.283563 | **完全一致（不跳变）** |

### 测试
新增 `tests/gui_speed_throttle_check.py`（21 项，全过）：
- A 组节流生效（写入次数受 fps 限制，而非等于事件数）
- **B 组防跳变（核心）**：松手后最终值必须与不节流**逐位一致**；
  且**单独验证"少了补写值就会不同"**（证明补写不是摆设）
- C 组 Shift 精度模式与节流共存（最终值一致）
- D 组边界：微小位移不丢 / 补写**幂等** / 无位移不做事 / 非拖拽态安全
- E 组静态契约：节流真的在分支里、补写在标志清零**之前**、两个时钟分开
- **F 组 bug 注入（3 组全部被抓住）**：
  - I1 补写"打瘸"（不做事）⇒ 防跳变断言抓到最终值偏离
  - I2 帧率限制放开（阈值≈0 = 退回不节流）⇒ 写入次数回到事件数
  - I3 补写挪到标志清零之后 ⇒ 静态契约抓到位置错误

⚠️ 测试过程中我自己踩了 4 个坑（都已修，值得记）：
  1. 轨迹太长 ⇒ s 打到下限**饱和**，"补写/不补写"结果一样 ⇒ 假失败
  2. 轨迹末尾恰好落在写入点 ⇒ pending == last ⇒ 补写无事可做 ⇒ 假失败
  3. bug 注入设 `fps=0`，但代码有 `max(1, ...)` 保护 ⇒ 变成 1 秒（方向反了）
  4. 注入 patch 了 `it.addon_pref`，而回放器读的是**顶层 import 的名字副本**
     ⇒ 注入打到空气上（必须让回放器也走 `it.addon_pref`）

### 回归
全量 **49 文件 / 248 项 / FAIL 0**。


## 2026-09-18 (Feature — 三角「一体/分离」+ Fix 误触) → v1.3.3

### Context
用户反馈：**"关键帧点和三角控制柄容易误触，想选关键帧点时容易误触选中三角控制器，
可以保关键帧点的识别范围适当扩大一点点"**。

### 根因（实测数据，不是感觉）
在真实工程里扫描（`Suzanne`，关键帧 1/25/55，沿"关键帧 → 三角"连线逐像素采样）：

```
关键帧点可见半径 = keyframe_point_size / 2 = 5px
三角画在距关键帧 [18.5, 33.5]（尖端 TRI_FIXED_D-TRI_HEIGHT_PX=18.5，中心 26）
三角拾取盘 = 以【中心 26】为圆心、半径 SPEED_TRI_PICK_RADIUS=22 ⇒ 覆盖 [4, 48]
```

⇒ **[4, 18.5] 这段"什么都没画"的空白区也被算成三角**。
用户瞄着关键帧点往上偏 >4px 就掉进这块虚拟领地 —— 这就是误触的根因。
实测扫描确认：**偏移 4~18px 全部命中三角**。

⚠️ 注意这**不是"半径设大了"**：三角的拾取盘应该覆盖它的**本体**（[18.5, 33.5]），
   22 是合理的；问题在于它同时往关键帧方向**多伸了 14.5px**。

### 改动
新增 `state.KEYFRAME_PICK_PRIORITY_RADIUS = 14.0`（**关键帧点保护半径**）
+ `interaction._triangle_under_cursor()` 作为**唯一**的三角命中查询：
鼠标离该三角所属关键帧点的距离 **≤ 14px** 时，这个三角**不参与命中**（让给关键帧）。

取值依据（两个方向都量过）：
- **下界**：> 可见半径 5（并给手抖留余量）—— 比原来的 4 大得多
- **上界**：< 三角尖端 18.5 —— 用户瞄三角时**先够到的是三角，不是关键帧**
⇒ 14 落在 [5, 18.5] 中间偏上，两边余量都够（下 9.0 / 上 4.5）。

修复前后（同一工程实测扫描）：

| 距关键帧偏移 | 0..13px | 14px | 16..38px |
|---|---|---|---|
| 修复前 | **误判为三角**（根因） | 三角 | 三角 |
| 修复后 | **正确地给关键帧** | 分界 | 三角（含整个本体） |

⚠️ 副作用其实是**改善**：三角可抓区从 [4, 48] 变成 [14, 48]，
   而现在**完整覆盖三角本体** [18.5, 33.5] —— 之前"点三角根部偏外"反而够不着。

### 为什么是"保护半径"而不是"调小三角半径"
点击链路的顺序是 `三角 → 端点手柄 → 关键帧`，其中**端点手柄刻意优先于关键帧**
（2026-09-16 的设计，不能动）。所以不能把"关键帧优先"插到最前面 ——
只能让**三角这一步**自己尊重关键帧区。这样端点优先级完全不受影响。

### 口径唯一（这一条是硬约束）
四处使用者**必须**共用 `_triangle_under_cursor`：点击 / 悬停 / 双击 / 恢复默认。
否则会出现"看得见的状态与点得中的状态不一致"（历史上反复栽过）。
测试里加了静态契约钉住它（`C1`：全仓已无裸 `hd.hit_test(..., SPEED_TRI_PICK_RADIUS)`）。

### 测试
新增 `tests/gui_tri_kf_misclick_check.py`（24 项，全过）：
- **A 组扫描式判据**：保护区内 **0..14px 每一档**都不得命中三角
  （⚠️ 不"只点一个点"——命中是"盘"不是"点"，只点中心会漏掉整个重叠区）
- **B 组反方向**：瞄三角本体 19~33px **仍必须**命中（防修过头）
- **C 组口径唯一**：点击/悬停/双击/恢复默认四处都走同一查询
- **D 组几何契约**：保护半径必须落在 `(可见半径 5, 三角尖端 18.5)` 内
- **E 组 bug 注入**（3 组，全部被抓住）：
  - I1 保护半径归零（退回旧行为）⇒ 扫描抓到误触档 [4..11]
  - I2 保护半径过大（26 > 尖端）⇒ 瞄三角扫描抓到漏判 [19, 22]
  - I3 唯一查询换成裸 `hit_test` ⇒ 扫描 + 悬停**都**出问题

⚠️ 过程中发现并修掉一个**假测试**：早先写了 `step(..., True, "由 C3/C4 覆盖")`
   —— 永远为 True 的断言是假测试，已换成真注入（I3）。

### 回归
全量 **48 文件 / 227 项 / FAIL 0**。
顺带修了 2 个测试的**锚点过时**：它们锚在裸 `hd.hit_test(...)` 字符串上来定位
"modal 里的三角处理段"，本轮把裸调用收敛后锚点失效 ⇒ 改成锚语义稳定点，
并在注释里写明"别锚具体命中调用"。


## 2026-09-18 (Fix — 独立盲审后的 4 项修复) → v1.3.2

### Context
用户要求"请一个不知情的子代理做全面 review，且以插件功能正常为前提、不引入新问题"。
盲审（独立子代理、只读、不知情）跑完后，**逐条实测复核**，结论如下。

> ⚠️ 盲审报告**不能照单全收**：它有一条假阳性（C-2，被实测推翻），
>   还有一条影响描述被夸大（S2）。复核记录见
>   `IDES\workspace\_review_verified.md`，盲审原文 `_blind_review.md`。

### 修复项

#### S1 子帧关键帧被**静默吞掉** → 改为**显式提示**
- **实测复现**：F-Curve 上是 `[1.0, 14.0, 14.4, 27.0]` 四个关键帧，
  cache 只拿到 `[1, 14, 27]` —— `14.4` 被 `int(kp.co[0])` 截成 `14` 后与 `14.0` 合并。
- **根因**：插件**按整数帧建模**（4 处独立截断点：
  `cache.py:181`、`cache.py:206`、`drawing.py:906`、`interaction.py:1667`；
  写入路径同样按整数帧匹配 `abs(kp.co[0]-frame) < FRAME_EPS`）。
- **用户拍板（2026-09-18）**："不用支持子帧" ⇒ 那就**不能静默吞**。
- **改动**：新增 `cache.detect_subframe_keyframes()`，
  在 `refresh_position_store()` 里记录数量与示例帧号到 session；
  `ui.py` 的 3D 视图 popover 在**检测到**时显示一行提示（正常时不占位置）。
  ⚠️ 行为本身不变（仍是整数帧建模），只是**不再让用户对着少了一个关键帧的路径猜原因**。

#### S2 端点【外侧】手柄：交互侧能点中，绘制侧却不画 → 两侧对齐
- **实测证据**：`_endpoint_is_hidden_side` 只在 `drawing.py:739` 被调用
  （跳过外侧，注释原文"拖了也没效果"），**`interaction.py` 里 0 次调用**。
- **用户 2026-09-16 早已拍板**："只做内侧 2 个；外侧不画不抓" —— 上半句做到了，下半句漏了。
- ⚠️ **盲审称"拖动会改动画"，实测不成立**：
  `tests/gui_endpoint_hollow_check.py:11` 记载外侧对曲线影响 = `0.00000000`
  ⇒ 是"能点到看不见的线、拖了白拖"的**体验断档**，不是数据被改坏。
- **改动**：`interaction.locate_handle_under_cursor` 增加外侧守卫，
  **复用 `drawing._endpoint_is_hidden_side`**（唯一判据来源，避免两边漂移）。
- 新增 `tests/gui_endpoint_outer_hit_check.py`（13 项）
  + **bug 注入验证**：去掉守卫后 4 项立刻失败（A2/A3/D2/E1）⇒ 测试确实有效。

#### L5 `drawing.py` 硬编码包名 → 改用 `__package__`
- `drawing.py:1178` 原为 `startswith("RealTimeMotionPath")`，
  而 `state.py:31` 用的是 `__package__`。
- **风险**：以 Blender **Extension** 形式安装时模块名由 `blender_manifest.toml` 的 id
  决定 ⇒ 不匹配 ⇒ `purge_stale_draw_handlers()` **静默什么都不清**
  ⇒ v1.2.1 刚修好的"绘制残留"回归。
- **改动**：改用 `__package__`（含 docstring 同步），与 `state.py` 口径统一。

#### R7 i18n 自测**覆盖面是虚的** → 扩到全目录（**立刻揭露 2 处真漏翻**）
- 原实现只扫 4 个文件（`__init__/ui/interaction/drawing`）
  ⇒ 另外 8 个模块的界面字符串**完全不在覆盖内**，
  于是"109/109 覆盖"这个数字**是假的**。
- **改动**：改为扫全部源码模块。结果立刻暴露：
  - `modal_edit.py` 的 `bl_label = "RTMP Modal Edit"` / `"RTMP Keyboard Transform"`
    **从未被发现漏翻** → 已补翻译
  - ⚠️ 实现时踩了一个坑：用 `not f.startswith("_")` 过滤会把 `__init__.py` 也滤掉
    （僵尸数虚增 13）⇒ 改为只排除 dunder 文件。
- **现在**：覆盖 **112/112，僵尸 0**（且这个数字名副其实）。

#### S3/S4 `handle_scale_k` 的文档与实现冲突 + 接口口径陷阱（只改注释）
- `docstring` 写着 `k_max = span / max|dt_base|`，而实现是常量 `UNIFORM_K_SAFETY`
  （用户 2026-09-17 已拍板"取消拉长上限"）⇒ **文档在骗后人**。
- 且 `span` 形参**完全未被使用**。⚠️ 不能删（3 个测试用位置传参调它）
  ⇒ 保留形参，但显式标注"**已废弃、不再使用**"并更正 docstring。
- 顺带标注接口口径：`handle_scale_k` 收**序列**，相邻的 `scale_handle_uniform`
  收**标量** —— 名字相近口径不同，调用时别混（S4）。

### 未修（有意保留，需用户拍板）
- **M1**：`modal_edit.py` 有 **20+ 处硬编码中文**状态栏文案（`iface_` 计数 = 0）。
  英文用户会看到中文状态栏。⚠️ 风险中等：有 5+ 个既有测试断言中文文案
  （`"疏密" in status_text()`、`"[多选 2 个]"`、`"[输入 2.5]"` 等），
  改文案要连测试一起改 ⇒ 留待专门一轮处理。

### Tests
- 新增 `tests/gui_endpoint_outer_hit_check.py`（13 项，含 bug 注入验证）
- regression：i18n **112/112，僵尸 0**（扫描面从 4 文件 → 13 文件）；PASS 15 / FAIL 0
- **全量回归：44 文件 / 253 项 / PASS 253 / FAIL 0**
- 真机验收（headless）：含子帧场景检测数 = 1、干净场景 = 0（不误报）；
  cache 行为不变（`[1,14,27]`）；S2 守卫在位；L5 用 `__package__` ✓

---

## 2026-09-17 (Fix — 手柄拖拽模式文案：3 轮迭代定稿) → v1.3.1

> 本条目记录了文案的**三次迭代**（用户连提三次反馈才收敛）。
> 最终版：只描述功能效果、用用户的词、每个按钮一句话。
> 迭代过程本身是留给后续开发的教训，故保留不删。

### Context
用户反馈（配 3D 视图 popover 截图）：
> "关于插件的这个设置描述，有点过于笼统，而且两个模式名称也不够直观，
>  意思也有点难明白，你重新改一遍表述吧"
> 续："你这有点写的太啰嗦了，详细的内容可以写到悬停描述"

旧文案：
```
「控制柄」[改变速度] [缩放手柄]
  · desc: "Change the speed at the keyframe" / "Keep the speed, only change the handle length"
```
**问题**：① 名字只说"改什么"、不说"什么会跟着变" ⇒ 看不出该选哪个；
② `expand=True` 的按钮**不显示 description** ⇒ 那两句解释等于白写。

### Changes
1. `ui.py` 枚举项文案重写（命名原则：**说清它保住了什么 + 代价是什么**）：
   - `name`: `Change Speed` / `Keep Speed`（"Scale Handle" 名不副实 —— 它保的是速度）
   - `description`（= tooltip，可多行）：各自的**完整后果**
2. `ui.py` draw：`prop(..., expand=True)` → **`row.prop_enum(...)` ×2**
   - 原因：`prop_enum` 的 **tooltip 取该 enum item 的 description**
     ⇒ 并排两按钮 + 悬停看详细说明（用户要求"详细内容写到悬停描述"）
3. `translations.py`：按钮短名（改速度 / 保速度）+ 详细悬停说明（含公式级解释）

### ⚠️ 两个实测踩坑（已验证并写进注释）
1. **popover 宽度只有 ≈186px**：第一版按钮写成「改速度（疏密不变）」被截断成
   「改速度（疏密不...」，底下一行「改形状时，速度和疏密只能保住一个」也被截断。
   ⇒ 按钮名**最多 ~5 个中文字**；详细内容只能进 tooltip。
2. **界面字符串不能跨行拼接**（`"abc " "def"`）：
   `tests/regression.py` 的 i18n 检查用正则按**片段**提取，
   拼接串只抓到第一段 ⇒ 报「漏翻 + 僵尸」。
   ⇒ 必须写成**单个完整字面量**。

### 最终文案
```
拖动手柄 = 做什么
[ 改速度 ] [ 保速度 ]

悬停「改速度」：
  拖动只改变关键帧处的速度。
  三角疏密保持你设定好的值不变（想调形状又不想动疏密时用它）。
悬停「保速度」：
  拖动只改变手柄长度，关键帧处的速度保持不变。
  代价：三角疏密会跟着手柄一起变（想调形状又不想动速度时用它）。
悬停标题「拖动手柄 = 做什么」：
  拖动关键帧手柄时，保住「速度」还是保住「三角疏密」。
  两者数学上只能保住一个（速度 = 手柄长度 ÷ 时间跨度，
  疏密 = 时间跨度 ÷ 段长，而时间跨度只有一个位置可站）。
```

### Tests
- i18n 覆盖 **109/109，僵尸 0**（`regression.py` PASS 15 / FAIL 0）
- 全量回归：**43 文件 / 221 项 / PASS 221 / FAIL 0**
- **真机视觉验收**（在 Blender 进程内抓屏，绕开抓屏被其它窗口抢占的问题）：
  面板显示「拖动手柄 = 做什么 / [改速度][保速度]」，**文字完整不截断** ✓
  tooltip 内容经 `bl_rna...enum_items[].description` + `pgettext_iface` 核对 ✓

---

## 2026-09-17 (Feature — 双击三角手柄 ⇒ 复制同关键帧另一个三角的速度值) → v1.3.0

### Context
用户需求原文：
> "当用户双击三角手柄时，可以把当前双击的三角手柄所负责速度分布值
>  改为同关键帧的另外一个三角手柄相同的值"

每个关键帧有**两个**速度三角（见 `handles.py`）：
`▼ up`（在关键帧上方，负责**左段**）/ `▲ down`（在关键帧下方，负责**右段**）
⇒ "另一个三角" = **相反的那个**（up ↔ down）。

### Changes
1. `interaction._copy_speed_value(context, obj, frame, tri)`：把对侧的值复制过来。
   - **复制的是归一化值 `s`（= 该侧 dt/span），不是像素量 `d`** ——
     界面显示的倍数只与 `s` 有关 ⇒ 复制后两边**倍数完全一致**，
     与两侧 span 是否相等无关（实测两侧 span 24 / 30 不同，倍数仍精确相同）。
   - 新增 `_read_side_s(kf_map, span, side)`：与 `modal_edit.collect_speed_handles`
     用**同一口径**读 `s`。
2. `interaction.speed_double_click_hit(frame, tri, xy, now, window, radius)`：
   双击判定（时间 + 位置 + 同一个三角），四个参数全可注入 ⇒ 可 headless 测试。
3. `interaction.try_copy_other_speed_click(...)`：点击入口，返回 `(consumed, message)`。
4. 接入 `PathRefreshDaemon.modal` 的 `LEFTMOUSE PRESS`（**在"选中+启动拖拽"之前**）。
5. `state.MotionPathSession.speed_click_info`：上次点击记录（双击链）。
6. `invoke` 里清双击链；点空白处也断链。
7. `translations.py` 新增 4 条（i18n 覆盖 109/109）。

### 关键设计决定
- **不用 `event.value == 'DOUBLE_CLICK'`**：那个值由 Blender 事件系统按 keymap
  生成，在**常驻 modal** 里能否收到**不确定**；而"双击"本身就是
  【时间 + 位置】两个**可测量**的量 ⇒ 自己判：行为确定、可复现、可测试。
  时间窗取偏好 `mouse_double_click_time`（实测默认 350ms），拿不到兜底 0.35s。
- **端点是正常边界**：首帧的左段 / 末帧的右段**没有三角**（`collect_handles` 不生成）
  ⇒ 双击那里得到"无可复制"提示，**不是错误**，且**值不变**。
- **双击要优先于拖拽启动**：判定放在"选中 + `speed_drag_active=True`"之前，
  双击后不进入拖拽（`speed_drag_active = False`）。

### Tests
新增 `tests/gui_dblclick_copy_speed_check.py`：**32 项 ALL PASS**
- A 组 9 项：双击判定（窗内/超窗/远距/异三角/异帧/消费防三击/断链/缺省参数）
- B 组 8 项：复制动作（双向、倍数一致、端点边界、只改本侧、幂等）
- C 组 5 项：入口（点空白断链、真双击、消息带倍数、选中态、长间隔不复制）
- D 组 静态契约 6 项（modal 接入点、函数存在、state 字段、代码里不用 DOUBLE_CLICK）
- E 组 2 组注入（"另一个三角"映射搞反 / 忽略时间窗）⇒ 全部 CAUGHT

⚠️ 读 `s` 的**测试口径**刻意独立（自己从 F-Curve 算 `|手柄时间−帧号|/相邻跨度`），
   不调产品函数 —— 否则产品读法错了测试也会跟着错。

### 真机验收
| | 左段倍数 | 右段倍数 |
|---|---|---|
| 双击前 | 0.556x | **1.667x** |
| **双击 up 三角后** | **1.667x** ✓ | 1.667x |
| （反向）双击 down 三角后 | 2.222x | **2.222x** ✓ |

- 状态栏消息（中文）：`已复制对侧手柄速度 1.67x`
- 截图确认：双击后该三角变为**选中**外观（视觉反馈在位）
- （倍数数字标签是 2026-09-15 用户要求移除的，本版不涉及）

### 全量回归
**43 文件 / 221 项 / PASS 221 / FAIL 0**

---

## 2026-09-17 → v1.2.1（Bug 修复版：拖拽/端点/泄漏/持久化）

本版**无新功能**，全是实测出来的真 bug 修复 + 一处 UI 位置调整。

| # | 问题（用户视角） | 根因 | 提交 |
|---|---|---|---|
| 1 | 拖长手柄时按下瞬间跳变（≈2 倍长） | 位移基准取成了**关键帧位置**而非**鼠标按下位置** | `79b88c2` |
| 2 | 端点手柄拖出来不相切；先拖很短一截再拖则"路径几乎不动"（dt 被算爆） | ① 零长手柄走退化分支 ⇒ 方向=鼠标方向；② `k = 新长/原长`，基线极短 ⇒ `dt = dt_base·k` 爆炸 | `aa77012` |
| 3 | 开关插件开关后绘制残留（多余直线），关开关也消不掉 | `unregister()` 漏了 `detach_render_callback()` ⇒ 回调留在 C 层注册表、闭包持有旧模块、GC 收不走 | `7e76f84` |
| 4 | 性能设置"改完重启就丢" | 属性注册在 `WindowManager` 上 ⇒ **不写入文件**（实测 + `is_runtime==True`） | `29987d7` |
| 5 | （诊断 #3 时顺带发现）控制台每帧刷 `AttributeError` | `depsgraph_update_post` 里叠了 **3 个** 同插件 handler（注册判据比"函数对象身份"，跨重载必失效） | `a4d7920` |

**UI 调整**：「性能」设置 ↔「手柄拖拽模式」**对调展示位置**
（性能 → 偏好设置；手柄拖拽模式 → 3D 视图 HEADER popover），
属性容器随之从 `WindowManager` 迁到 `AddonPreferences`（真持久化）。

**测试**：新增 3 个测试文件（`gui_drag_baseline_check` 13 项 /
`gui_draw_handler_leak_check` 24 项 / `gui_endpoint_tangent_check` 21 项），
并按新语义更新 `gui_endpoint_hollow_check` 的 F3 判据。
全量回归：**42 文件 / 189 项 / PASS 189 / FAIL 0**。

**回滚**：`git reset --hard v1.2.0`

---

## 2026-09-17 (Feature — 保速体系完善 + 手柄端点体验定型) → v1.2.0

### Context
用户对"编辑动画时不破坏原有节奏"的要求很高，核心诉求是**保速**：
在 3D 视口里直接调手柄、按 S 缩放关键帧点时，**关键帧处的速度不能变**。
（速度 = |dv / dt|，dv = 手柄值分量偏移，dt = 手柄时间分量偏移。）

### Changes
1. **手柄同比例缩放（Handle Scale）保速**：拖手柄改长度时，值分量与时间分量
   同比例缩放 ⇒ 速度恒定。默认拖拽模式改为 `Scale Handle`。
2. **取消手柄"拉长上限"**：手柄线可以一直跟手变长（原来超过阈值后被钳制，
   手感会"顶住不动"）。
3. **单点 S 缩放保速**（`df6fc15`）：选中**一个关键帧点**按 S 缩放时，
   dt 也 ×factor ⇒ 速度不变。
   - `apply_point_transform(...)` 新增 `time_scale` 参数；
   - **时间分量必须从 snapshot 读**（模态里每帧 `_apply`，从当前值读会累乘 k^n）；
   - 边界：多点缩放 / 轴锁定 时**不缩 dt**（无统一语义）。
4. **手柄端点 S 缩放保速**（`94c28ec`）：端点模式走 `apply_endpoint_transform`
   （只写值分量），补上 `time_scale` 支持 + `_scale_handle_time()` 辅助。
   - 边界：只选**单个端点**时才缩 dt（支点 = 选中关键帧点的中位点）；
   - `dv=0` 的端点不缩 dt（无速度可保，缩了只会把曲线压平）。

### 手柄端点拖动 —— 现状（方案丁，经用户实测确认可接受）
端点手柄新建时为 **0 长度**，两道机制会挡住"同比例"：
  ① `_uniform_plan` 在**端点段**（`span=None`）直接返回 None；
  ② `handle_scale_k` 在 **|dv_base| ≈ 0**（手柄零长）时返回 None。
⇒ 落到退化分支：只改值分量、dt 不动。

实测行为（用户确认"这个体验也还行"）：
| 阶段 | 端点长度 | 速度 |
|---|---|---|
| 初始 | 0.0 | 0.0 |
| **第一次拖**（把端点手柄拖出来） | 0.3 → 0.6 → 0.9 | 0.0375 → 0.075 → 0.1125（随长度涨） |
| **放手后**（已有长度） | 0.9 | 0.1125 |
| **第二次拖** | 1.1 → 1.3 → 1.5 | **0.1125 恒定** ✓ |

即：**第一次"拖出"相当于给端点安上手柄（不保速，从静止起步），
此后再拖就是正常手柄、完全保速。**

### Status
- **Done**: 关键帧点 S 缩放、手柄端点 S 缩放 —— 均保速。
- **Done**: 拖手柄（中间帧）保速；拖端点手柄"第一次不保速、之后保速"。
- **Known**: 拖端点手柄的**第一次**不保速（数学死结：端点原速度为 0，
  "保持原速度"要求速度恒为 0 ⇒ 手柄拖不动）。若要保速需先给端点一个
  非零基准长度，代价是路径在该端变形。已与用户确认保持现状。

### Tests
- 新增 `tests/gui_point_scale_keepspeed_check.py`（29 项），含 4 组 bug 注入：
  「不缩 dt」「时间分量从 kp 读（累乘）」「多点也缩 dt」「端点模式不缩 dt」。
- 全量回归：38 文件 / 112 项 / ALL PASS。

### Fix — 手柄拖动的位移基准（用户实测"拖长手柄第一次跳变"）
详见下方 `2026-09-17 (Fix — 拖动位移基准)` 条目。

### Fix — 端点手柄拖出：方向锁切线 + 极短基线不再让 dt 爆炸

**用户报告**
> "我关闭重开工程，然后拖尾部端点的手柄出来时，尾部端点的手柄不会和路径相切，
>  也没有和路径有预期交互"

**定位方法（重要）**：先查磁盘 `test.blend` 的修改时间 = **09-15**（用户从未保存）
⇒ 他"重开工程"加载的是**磁盘干净状态**（末帧内侧手柄 = 0 长、AUTO_CLAMPED）
⇒ **以磁盘状态为复现起点**，而不是我当时的内存状态（那是被拖过的中间态）。

由此分离出**两个独立问题**（都有硬数据）：

**A：方向 = 纯鼠标方向（不相切）**
零长手柄基线是 0 ⇒ 同比例"无定义" ⇒ 走退化分支（只写鼠标位移）
⇒ 手柄方向 = 鼠标拖动方向。实测（干净起点、只改拖动方向，该处来路 [-0.91,-0.087,0.406]）：
```
沿 +X 拖 → 手柄 [1,0,0]     与来路夹角 155.4°
沿 +Y 拖 → 手柄 [0,1,0]     夹角  95.0°
沿 +Z 拖 → 手柄 [0,0,1]     夹角  66.0°
斜 X+Y   → 手柄 [.707,.707,0] 夹角 134.8°
```
⇒ 碰巧沿切线拖时才看着正常 ⇒ 用户"有时对有时不对、难复现"。

**B：极短基线 ⇒ dt 爆炸**
`k = |dv_new| / |dv_base|` ⇒ 基线越短 k 越大 ⇒ `dt = dt_base·k` 爆掉。
实测（磁盘干净起点模拟"拖出端点手柄、松手、再拖"）：
```
L0 = 0.0242 → 拖到 3.96 → k=164.6 → dt = 1646.3   ← 用户实测 1634 同源
L0 = 0.05   → 拖到 3.96 → k= 80.2 → dt =  802.0
```
dt 过大（> span）后曲线该段饱和 ⇒ **拖手柄路径几乎不动**（"没有预期交互"）、
手柄与路径偏离 10°+（"不相切"）、且**永久锁死**。

**Changes**
1. **A**：零长（≤ `UNIFORM_LEN_MIN`）**端点内侧**手柄拖出时，
   方向锁到**路径切向**（新增 `interaction._path_tangent_unit`），长度仍跟鼠标。
   - 两条拖拽路径（`_apply_one_handle_offset` / `apply_handle_point_offset`）都接上。
   - `_is_endpoint_inner_handle`：判据 = **首帧 right / 末帧 left**。
2. **B**：`transform_domain.handle_scale_k` 在 `L0 <= UNIFORM_LEN_MIN(1.0)` 时返回 None
   ⇒ 退回"只写 dv、dt 不变"（与"端点第一次拖出"的既定行为一致）。

**⚠️ 两个踩坑（已写进代码注释 + skill）**
1. **eps 必须自适应**：端点处曲线常"减速到停"（dv≈0）⇒ 位移 ∝ eps²。
   实测 f55：eps=0.01 时 |位移| = **2e-6（纯浮点噪声）** ⇒ 方向随机（差 19.5°）；
   eps ≥ 0.05 才稳定（0.05~5.0 彼此差 < 1°）。
   ⇒ 实现改成"从小步长起试，取第一个位移脱离噪声的"（相对阈值）。
2. **"端点内侧"不能用 `td.resolve_target` 的 `span is None` 判断**：
   实测 f55 的**左手柄**（内侧）返回 `span = 30.0`；`span is None` 对应
   **朝外**那一侧 —— **正好相反**。第一版就是这么写的，修复完全没生效。

**实测 / 验收**
- 新增 `tests/gui_endpoint_tangent_check.py`：**21 项 ALL PASS**
  A 组（方向锁定 + 与两个独立参照相切：宏观差分 0.37° / PCA 1.10° + 长度跟手 + 首帧内侧）
  B 组（不误伤：中间帧零长不锁 / 端点已有长度不锁 / 判据语义）
  C 组（dt 不爆 + 正常基线仍保速 + 阈值边界）
  D 组（静态契约，含"判据代码不用 span"）
  E 组（3 组注入：方向锁失效 / 固定 eps=0.01 / 基线判据退回 EPS ⇒ 全部 CAUGHT）
- **视觉验收**（截图对比）：修复前末端曲线**拐了个钩**；修复后**平滑顺着弧线延伸** ✓
- 既有测试 `gui_endpoint_hollow_check.py` 的 **F3 判据按新语义更新**
  （旧判据"每轴增量各自恒定"隐含"方向跟鼠标"，已不成立 ⇒
   改为"合成模长增量恒定 + 各步方向一致"，实测 模长偏差 0.0055 / 方向偏差 1e-06）。
- 全量回归：**42 文件 / 189 项 / PASS 189 / FAIL 0**。

### Fix — 绘制回调泄漏：修「开关插件开关后绘制残留」

**用户报告**
> "我打开工程后开启运动路径…重载插件后我直接用，然后发现重开插件开关后，
>  会有绘制残留"（截图上：红色路径上多出**黑色长直线**）

**真因（诊断数据）**
`unregister()` **只撤了 overlay，漏了运动路径的绘制回调**
（`drawing.detach_render_callback()` 没被调用）。

诊断（用户当前会话实测）：
```
3 个 MotionPathSession 存活
其中 2 个持有非 None 的 render_callback_id   ← 两个回调同时注册着
```

机理：
```
draw_handler 一旦注册，句柄只存在 _session.render_callback_id 里
⇒ 不 detach ⇒ 回调仍留在 C 层注册表里运行
⇒ 其闭包引用着【旧模块】⇒ GC 也收不走
⇒ 新模块再注册一个 ⇒ 两个回调同时绘制
⇒ 路径上出现残留（旧回调用旧数据又画了一遍），且关开关也消不掉
```

**Changes（三层防护）**
1. **主修**：`unregister()` 补 `detach_render_callback()`（原来只有 `stop_overlay()`）。
2. **健壮**：`detach_render_callback()` 对失效句柄 `try/except`，
   且无论如何都把 `render_callback_id` 置 None（不留死句柄、不中断卸载）。
3. **兜底**：新增 `drawing.purge_stale_draw_handlers()` —— 扫 GC 找出插件会话
   /覆盖层对象，移除它们**还持有**的 handler。
   - `register()` 里"先清后建"；`unregister()` 里也清一遍。
   - 兜住"绕过 unregister 的强制重载"（如热重载脚本删 `sys.modules`）。
   - 判据用 `type(o).__module__.startswith("RealTimeMotionPath")` 而非类名 ——
     跨模块重载后旧类是另一个类对象，但 `__module__` 仍是包名（可靠）。

**★ 顺藤摸瓜抓到的同类泄漏：`bpy.app.handlers` 也叠了 3 个**

诊断 draw handler 时发现控制台每次 depsgraph 更新都抛：
```
AttributeError: 'WindowManager' object has no attribute 'rtmp_refresh_strategy'
   在 on_depsgraph_update（旧模块的）   ← depsgraph_update_post[3]
```
实测 `depsgraph_update_post` 里叠了 **3 个** `on_depsgraph_update`（全是本插件的）：
```
i=3,4,5  module=RealTimeMotionPath.interaction   ← 3 个！
```
根因（与 draw handler 同源）：
- 注册判据 `if on_depsgraph_update not in bpy.app.handlers.xxx` 比的是
  **函数对象身份** —— 跨模块重载后那是**新对象**，与列表里残留的旧对象不等
  ⇒ 判重失效 ⇒ 每次重载再叠一个。
- `unregister()` 不清 app handlers ⇒ 卸载后残留。

修法：
- 新增 `state.purge_stale_app_handlers()`：按 **`__module__` 前缀**（而非对象身份）
  移除所有属于本插件的 app handler —— 跨模块重载后旧函数的 `__module__`
  仍是包名（可靠）。会**跳过非列表属性**（如 `handlers.persistent` 是函数）。
- `interaction.py` 的注册处改为"**先清后建**"：`purge_stale_app_handlers()` 再 append。
- `unregister()` / `register()` 两端都调用（与 draw handler 同一套路）。

**验证**
- 新增 `tests/gui_draw_handler_leak_check.py`：**24 项 ALL PASS**
  · A 组 purge 语义（清孤儿 / 不动 keep / 幂等 / 返回值）
  · B 组 detach 健壮性（失效句柄不抛 / 重复调用 no-op / 真能移除）
  · C 组 静态契约（unregister 与 register 都接上了）
  · **F 组 app handler**：能清本插件的 / **不误伤别的插件**（判据按包名）/
    幂等 / 跳过非列表属性 / 注册处已改先清后建 / 两端都接上
  · D 组 **端到端**：真实 `unregister()` 后存活句柄 = **0**
  · E 组 注入：detach 失效 ⇒ purge 兜住（0 残留）；
    detach+purge 都失效 ⇒ 残留 1（证明测试确实在度量泄漏）
- 全量回归：**41 文件 / 168 项 / PASS 168 / FAIL 0**。
- 真机重载实测：`depsgraph_update_post` 里插件 handler 3 个 → **0 个**；
  开关切换 3 轮后仍为 1 个（不叠积）。

### Feature — UI 布局：性能设置 ↔ 手柄拖拽模式 对调

**用户要求**
> "运动路径曲线的 UI 在 3D 视图右上角…点开下拉后是性能更新模式的设置，
>  我想把这个设置挪到插件偏好设置里去，然后把现在偏好设置里的手柄拖拽模式
>  的设置挪到 3D 视图的 UI 里"

**Changes**
1. **性能（更新模式 / 交互帧率 / 轮询频率）→ 偏好设置面板**（置于顶部，紧随"恢复默认值"）。
2. **手柄拖拽模式 → 3D 视图 HEADER popover**（标题保持 `Motion Path Settings`）。
   属性本体没动（它本来就是 AddonPreferences 属性），只换展示位置。

**★ 顺带修掉一个真问题：性能设置原来「改完重启就丢」**

这 3 个设置原为 `WindowManager` 属性 —— 而 **WindowManager 上的属性不写入文件**。
实测（复现记录）：
```
进程1：设 TIMER / 33 / 7  →  保存到文件
进程2：重开该文件        →  变回 SMART / 60 / 10
RNA: bpy.types.WindowManager.bl_rna.properties['rtmp_refresh_strategy'].is_runtime == True
```
⇒ 移植到 `AddonPreferences`（存 userpref ⇒ **全局 + 持久**），
读取统一走 `state.addon_pref(name, default)`（异常安全，拿不到返回默认值）。
- `__init__.py`：移除 3 个 WindowManager 属性注册 / 注销。
- `interaction.py`：4 处 `wm.rtmp_*` → `addon_pref(...)`。
- `translations.py`：删除僵尸词条 `Max FPS Limit`（属性改名后失效），
  新增 `Addon preferences unavailable`。

**实测 / 验收**
- 偏好设置面板截图：性能区块（两按钮 + 帧率）显示正常、无挤压。
- 3D popover 截图：「控制柄」+「改变速度 / 缩放手柄」，默认高亮 UNIFORM。
- 新增 `tests/gui_ui_layout_check.py`：**19 项 ALL PASS**
  （A 属性落位 / B UI 归属 / C 无旧引用残留 / D addon_pref 兜底 / E Reset 覆盖）。
- 全量回归：**40 文件 / 144 项 / ALL PASS**；i18n 覆盖 105/105、僵尸 0。

### Tests（当日合计）
- 新增 `tests/gui_drag_baseline_check.py`（13 项）、`tests/gui_ui_layout_check.py`（19 项）。
- 全量回归：**40 文件 / 144 项 / PASS 144 / FAIL 0**。

---

## 2026-09-17 (Fix — 拖动位移基准：修「拖长手柄第一次跳变」)

### Context
用户实测：
> "我打开工程后开启运动路径，然后拖出结尾帧的手柄，然后再去上一个关键帧的
>  右手柄进行拖动时，右手柄发生了跳变，但是其他手柄却没有类似情况"

### Root Cause
`invoke`（PRESS）把 `_session.world_origin` 设成了**关键帧位置**（`point_3d`）。
（已核实 `cached_positions[obj][None][frame]['position']` 与关键帧 co 逐位一致。）

modal 里 `total_offset = 投影(鼠标) - world_origin`，写入是 `手柄 = 基线 + total_offset`
⇒ 第一次移动时 `total_offset ≈ 鼠标位置 − 关键帧位置 ≈ 手柄向量`
⇒ **手柄 ≈ 2 × 手柄向量** ⇒ 跳变。**跳幅 ≈ 手柄长度**：
端点（0 长度）看不出（用户："其他手柄没这情况"），最长的 f25 右手柄（|dv|=10.55）最明显。

### Changes
位移基准改为**鼠标按下位置的 3D 投影**（新增 `_mouse_world_ref()`）：
- 深度参考仍取关键帧位置 ⇒ 与 modal 的投影**同平面**（world_origin 就在该平面上）。
- 两处 PRESS（普通手柄 / 端点手柄）统一口径（原来两者语义不同）。
- 取不到 region/rv3d 或投影抛异常 ⇒ 退回原 ref 点（安全兜底）。
⇒ `total_offset` 恒等于鼠标位移量 ⇒ 按下不跳、之后相对跟手。

### Tests
- 新增 `tests/gui_drag_baseline_check.py`：**13 项 ALL PASS**
  含 **旧行为对照**（鼠标一动不动却 offset=31.11、|dv| 10.55→32.85）把该 bug 钉成回归。
  ⚠️ 测试里的假投影**必须幂等**（首版写成平移模型，不幂等 ⇒ 测试自己假失败）。

---

## 2026-03-01 (Feature — 手柄时间归一化与稳定性修复)

### Context
1. **视觉缺陷**：用户反馈当 F-Curve 手柄的时间长度（X轴持续时间）不一致时，3D 运动路径手柄会出现“折角”（不相切）的现象。
2. **崩溃问题**：初步修复后，Blender 因垂直手柄导致的数值爆炸而崩溃。

### Changes
1. **时间归一化算法**：
   - 实现 `get_handle_correction_factors`：计算缩放系数 $Factor = S / dt$（其中 $S$ 为平均持续时间）。
   - 将系数应用到 `draw_motion_path_handles`，使 3D 手柄代表速度方向（切线），而不仅仅是数值差。
   - 在 `move_selected_handles` 中进行反向修正，确保 3D 交互时 F-Curve 数据更新正确。

2. **崩溃修复 (数值稳定性)**：
   - 增加 `MIN_HANDLE_SCALE` (0.1) 和 `MAX_HANDLE_SCALE` (100.0) 钳制，防止 $dt \to 0$ 时数值无限增大。
   - 增强 `draw_batched_billboard_circles` 鲁棒性，使用显式 `float()` 转换和单点 `try...except` 保护，防止 `EXCEPTION_ACCESS_VIOLATION`。

3. **文档更新**：
   - 更新 `motion_path_fix_plan.md`，增加了通俗解释、流程图、风险分析及崩溃修复细节。

### Status
- **Done**: 即使 F-Curve 手柄长度不一致，3D 手柄现在也能在视觉上与路径曲线保持对齐（平滑相切）。
- **Fixed**: 修复了由垂直手柄（零时间持续时间）导致的崩溃问题。

---

## 2026-02-28 (Fix — 空白区域取消选中漏洞)

### Context
修复空白区域点击无法取消选中的漏洞：当用户选中了关键帧但**未选中对应对象/骨骼**时，点击空白区域无法清除关键帧的选中状态。

### Root Cause
- Object 模式：空白区域清除逻辑只遍历 `context.selected_objects`
- Pose 模式：空白区域清除逻辑只遍历 `context.selected_pose_bones`
- 如果对象/骨骼没有被选中，它的关键帧选中状态就不会被清除

### Changes
- 修改 Object 模式空白区域清除逻辑，遍历 `_state.position_cache` 而非 `selected_objects`
- 修改 Pose 模式空白区域清除逻辑，遍历 `position_cache` 中的骨骼而非 `selected_pose_bones`
- 使用 `bpy.data.objects.get()` 安全获取对象，处理已删除对象的情况
- 确保只要运动路径在显示，就能清除其关键帧选中状态

### Status
- **Fixed**: 无论对象/骨骼是否被选中，点击空白区域都能清除关键帧选中状态

---

## 2026-02-28 (Feature — 关键帧多选后操作优化)

### Context
用户希望在使用 Shift/Ctrl 复选多个关键帧后，无需继续按住 Shift/Ctrl 即可对这些关键帧进行操作（移动、设置手柄类型等）。同时修复了实现过程中出现的回归问题。

### Changes

1. **保留多选状态逻辑**（LEFTMOUSE 关键帧点击）：
   - 添加 `hit_keyframe_already_selected` 检查
   - 只有未按住 Shift/Ctrl 且点击未选中的关键帧时才清除其他选中状态
   - 复选后点击已选中的关键帧可拖拽移动所有选中关键帧

2. **保留多选状态逻辑**（RIGHTMOUSE 右键菜单）：
   - 右键点击已选中的关键帧时不清除其他选中状态
   - 支持批量设置手柄类型

3. **手柄点击优化**：
   - 删除手柄点击时操作关键帧选中状态的代码
   - 复选后操作手柄时保持关键帧多选状态不变

4. **空白区域点击检测**：
   - 添加空白区域点击检测，清除所有选中状态
   - 支持 Object 模式和 Pose 模式

5. **`set_handle_type` 函数重构**：
   - 支持多对象/多骨骼批量设置手柄类型
   - 遍历所有选中对象（Object 模式）或所有选中骨骼（Pose 模式）

6. **代码优化**：
   - 提取 `is_keyframe_selected()` 辅助函数，消除重复代码
   - 优化空白区域检测注释，明确列出所有检测条件

### Status
- **Done**: 复选后无需按住 Shift/Ctrl 即可操作多个关键帧
- **Done**: 手柄操作时保持多选状态
- **Done**: 空白区域点击清除所有选中
- **Done**: 多对象/多骨骼批量设置手柄类型

---

## 2026-02-26 (Feature — 圆点自定义着色器抗锯齿)

### Context
POLYLINE 粗线圆持续出现星形/花瓣状，改用自定义片段着色器实现抗锯齿。

### Changes

1. **`_get_circle_aa_shader()`**：模块级缓存，`GPUShaderCreateInfo` 定义 quad 着色器，顶点 `pos`+`uv`，片段中用 `smoothstep` 实现软边缘 alpha。

2. **`draw_billboard_circle`**：由 POLYLINE 改为 quad（4 顶点）+ 自定义着色器，`feather=0.1`。

3. **`draw_batched_billboard_circles`**：由 POLYLINE 改为 quad 批量，每批最多 500 圆，共享同一着色器。

4. **unregister**：清空 `_circle_aa_shader` 缓存。

### Status
- **Done**: 圆点使用 quad + smoothstep 软边缘，像素级抗锯齿
- **Segment**: 线段/环仍用 POLYLINE

---

## 2026-02-26 (Fix — 圆点花花样式 + 移除 TRI_FAN 回退)

### Context
POLYLINE 粗线圆使用 `lineWidth = 2×radius` 时出现星形/花瓣状（花花）样式；用户建议 `lineWidth = radius` 以刚好填满。同时移除不再需要的 TRI_FAN 回退机制。

### Changes

1. **lineWidth 调整**：`draw_billboard_circle` 与 `draw_batched_billboard_circles` 中，`lineWidth` 从 `2.0 * radius_in_pixels` 改为 `radius_in_pixels`，减轻顶点处过度扩展导致的星形感。

2. **移除 TRI_FAN 回退**：
   - 删除 `MotionPathStyleSettings.use_polyline_antialiasing` 属性
   - 删除 `draw_billboard_circle` / `draw_batched_billboard_circles` 中的 `use_polyline` 判断及 TRI_FAN 分支
   - 删除偏好设置中的「Rendering / Anti-aliasing」开关
   - 删除 `translations.py` 中对应翻译

### Status
- **Fixed**: 圆点应显示为实心圆，不再呈星形
- **Simplified**: 仅保留 POLYLINE 路径，无回退逻辑

---

## 2026-02-26 (Feature — Unified POLYLINE Anti-aliasing)

### Context
运动路径 UI 绘制改用 Blender 内置 POLYLINE 着色器，实现像素级抗锯齿；统一使用 POLYLINE，不引入自定义着色器。

### Changes

1. **线段类改用 POLYLINE**：
   - 路径主线：`UNIFORM_COLOR` + `line_width_set` → `POLYLINE_UNIFORM_COLOR`，传入 `viewportSize`、`lineWidth`、`color`
   - 手柄连线：`SMOOTH_COLOR` → `POLYLINE_SMOOTH_COLOR`，保留顶点色（选中/未选中双色）
   - 原点环（RING/RING_DOT）：`LINE_LOOP` + `UNIFORM_COLOR` → `POLYLINE_UNIFORM_COLOR`

2. **圆点改用粗 LINE_LOOP + POLYLINE**：
   - `draw_billboard_circle`、`draw_batched_billboard_circles`：由 TRI_FAN/TRIS 改为 LINES（圆周边） + `POLYLINE_UNIFORM_COLOR`，`lineWidth = 2 × radius` 实现实心圆抗锯齿
   - 关键帧点、帧点、手柄端点、原点 DOT 均走新路径

3. **TRI_FAN 回退**：
   - 新增 `MotionPathStyleSettings.use_polyline_antialiasing`（默认 True）
   - 关闭后圆点回退为原 TRI_FAN 绘制，便于在粗 LINE_LOOP 效果不佳时切换

4. **翻译**：新增 "Rendering"、"Anti-aliasing" 等条目

### Status
- **Done**: 所有绘制统一 POLYLINE，抗锯齿生效
- **Fallback**: 偏好设置中可关闭抗锯齿，圆点回退 TRI_FAN

---

## 2026-02-26 (Bug Fix — Skeleton Object Keyframe Drag After Pose→Object Switch)

### Context
用户测试发现：骨架对象有位移动画，开启运动路径后在物体模式显示与交互正常；进入 Pose 模式后显示骨骼运动路径，交互也正常；切回物体模式时路径正确切换回骨架对象路径，但**无法对关键帧点进行拖拽操作**，手柄点拖拽则正常。开关按钮刷新后可恢复，但重复上述流程会再次复现。

### Root Cause Analysis

1. **`move_selected_points` / `move_selected_handles` 未按模式解析 `bone_name`**：  
   两函数使用 `bone_name = _state.selected_bone_name`，未根据 `obj.mode` 判断。Pose→Object 切换后 `selected_bone_name` 仍保留骨骼名，导致过滤 `pose.bones["X"].location` 而忽略对象级 `location` fcurve，`selected_frames` 为空，拖拽无效果。

2. **`selected_bone_name` 未在模式切换时清空**：  
   Modal 仅在活动对象变化时清空状态，Pose→Object 时未重置。`_get_bone_selection_state` 虽会触发缓存重建，但不会清空 `selected_bone_name`。

3. **手柄拖拽正常的原因**：  
   `move_handle_point` 使用 `handle_point.get('bone_name')`，来源为绘制时写入，对象模式下手柄的 `bone_name` 为 `None`，故行为正确。

### Changes

1. **`move_selected_points` / `move_selected_handles` 按模式解析**：  
   `bone_name = _state.selected_bone_name if (obj and obj.mode == 'POSE') else None`，确保物体模式下始终使用 `bone_name = None` 以匹配对象级 location fcurve。

2. **Pose→Object 时清空 `selected_bone_name`**：  
   在 `MOTIONPATH_AutoUpdateMotionPaths.modal` 的 `current_bone_selection != self._last_bone_selection` 分支中，当 `current_bone_selection is None` 时清空 `_state.selected_bone_name`。

3. **关键帧/手柄/右键命中时显式清空（防御性）**：  
   LEFTMOUSE 关键帧点命中、`get_motion_path_handle_at_mouse` 手柄命中、RIGHTMOUSE 右键菜单分支中，在 Object 模式下均增加 `else: _state.selected_bone_name = None`，避免残留骨骼名影响交互。

### Status
- **Fixed**: 骨架对象 Pose→Object 切换后，关键帧点可正常拖拽。
- **No Regression**: Pose 模式骨骼交互、手柄拖拽行为不变。

---

## 2026-02-26 (Feature — Multi-Object/Multi-Bone Path Display)

### Context
用户需求：开启运动路径后，希望同时显示**所有选中对象**的运动路径，而非仅活动对象。原先选中第二个对象时，路径会切换为只显示第二个对象的路径。

### Changes

1. **`_state` 数据结构重构**：
   - `position_cache`：由单对象键改为 `{obj_name: {cache_key: {frame: {...}}}}`，`cache_key` 为 `None`（对象模式）或骨骼名（Pose 模式）。
   - `path_vertices`：由单一路径列表改为 `{(obj_name, bone_name_or_None): [Vector, ...]}`，支持多对象/多骨骼路径线。

2. **`build_position_cache` 多目标构建**：
   - 物体模式：遍历 `context.selected_objects`，为每个有动作的对象构建稀疏关键帧缓存和稠密路径线。
   - Pose 模式：遍历所有选中骨骼 + 活动骨骼，为每个骨骼分别构建缓存；`path_vertices` 按 `(obj_name, bone_name)` 存储。

3. **`draw_motion_path_overlay` 多路径绘制**：
   - 路径线：遍历 `_state.path_vertices`，按 `pv_obj_name` 解析对象、按 `pv_bone_name` 解析骨骼，各自计算 `parent_matrix` 后绘制。
   - 增强路径（关键帧点 + 手柄）：`draw_enhanced_path` 新增 `obj_name` 参数，在物体模式下按 `obj_name` 从 `position_cache` 取数据；Pose 模式下遍历 `bones_to_draw` 逐骨骼绘制。

4. **AutoUpdate modal 选中对象变化检测**：
   - 新增 `_get_selected_obj_names`、`_last_selected_obj_names`，当选中对象集合变化时触发缓存重建。

### Status
- **New Feature**: 物体模式下可同时显示多条运动路径；Pose 模式下可同时显示多骨骼路径。
- **No Regression**: 单对象/单骨骼行为保持不变。

---

## 2026-02-26 (Feature — Pose Mode Full Path Lines for All Selected Bones)

### Context
多骨骼路径显示初期，Pose 模式出现异常：非活动骨骼仅显示关键帧点，不显示路径线，而活动骨骼显示完整路径。用户期望所有选中骨骼都显示完整路径（线 + 点）。

### Root Cause Analysis
`build_position_cache` 在 Pose 模式下只为活动骨骼构建 `path_vertices`，其他选中骨骼只进入 `position_cache`（稀疏关键帧），未生成稠密路径线数据。

### Changes
- Pose 模式下，对 `bones_to_cache` 中每个骨骼均调用 `calculate_path_from_fcurves(..., frames_range, ...)` 生成稠密路径，并写入 `_state.path_vertices[(obj_name, bone_name)]`。
- `draw_motion_path_overlay` 中路径线循环已支持按 `(obj_name, bone_name)` 迭代，无需额外修改。

### Status
- **Fixed**: Pose 模式下所有选中骨骼均显示完整路径线与关键帧点。

---

## 2026-02-26 (Feature — Interaction Extension to All Displayed Paths)

### Context
多路径显示后，用户希望关键帧点、手柄的点击与拖拽交互能作用于**所有已显示路径**，而非仅活动对象/骨骼的路径。

### Changes

1. **命中检测扩展**：
   - `get_motion_path_point_at_mouse`（物体模式）：遍历 `_state.position_cache` 中所有对象，命中时设置 `_state.selected_drag_object_name = draw_obj.name`。
   - `get_motion_path_handle_at_mouse`（物体模式）：遍历所有 `position_cache` 对象，命中手柄时设置 `_state.selected_drag_object_name = draw_obj.name`。
   - `get_handle_point_at_mouse`：基于 `_state.handle_points` 中每条记录的 `obj_name` 判断所属对象。

2. **拖拽目标解析**：
   - `move_selected_points`、`move_selected_handles`、`move_handle_point`、`capture_initial_handle_values`、`get_keyframe_position_for_handle` 等统一使用 `_state.selected_drag_object or context.active_object` 作为操作目标，实现非活动对象的拖拽。（后续崩溃修复中将该引用改为名称字符串并引入 `_get_drag_obj`。）

3. **手柄数据传递**：
   - `draw_motion_path_handles` 为每个 `handle_point` 增加 `obj_name` 字段，供命中与拖拽时识别所属对象。

### Status
- **New Feature**: 物体模式与 Pose 模式下，均可对任意显示路径的关键帧点和手柄进行选中与拖拽。

---

## 2026-02-26 (Bug Fix — Non-Active Object First/Last Frame Handle Interaction)

### Context
多路径交互测试发现：非活动对象的**首尾帧手柄**无法拖拽，即便手柄与关键帧点视觉上距离较远；且拖拽非活动对象首尾帧手柄时，有时会误操作活动对象的其它关键帧手柄。Pose 模式无此问题。

### Root Cause Analysis

**Bug 1 — 零偏移手柄拦截点击**  
首尾帧使用 AUTO 手柄时，切线可能为零，导致手柄世界坐标与关键帧点重合。`get_motion_path_handle_at_mouse` 先于 `get_motion_path_point_at_mouse` 执行，会错误命中该“退化手柄”，进入手柄拖拽分支，而非关键帧拖拽，视觉上表现为无法移动位置。

**Bug 2 — 手柄数据缺少对象上下文**  
`_state.handle_points` 中仅存 `position`、`side`、`frame`、`bone`，无 `obj_name`。手柄命中后若 `selected_drag_object` 尚未设置，LEFTMOUSE 处理器会以 `context.active_object` 作为操作目标；若活动对象在该帧也有关键帧，则会错误操作活动对象的手柄。

### Changes

1. **`check_handles_at_frame` 跳过零偏移手柄**：
   - 在左右手柄命中检测前增加 `world_vector_left.length > 1e-4`、`world_vector_right.length > 1e-4` 判断，位移接近零时跳过该手柄，避免退化手柄拦截点击。

2. **`handle_points` 增加 `obj_name`**：
   - `draw_motion_path_handles` 写入 `handle_point` 时增加 `obj_name`（及后续的 `bone_name`），供命中与拖拽使用。

3. **手柄命中时设置拖拽目标**：
   - LEFTMOUSE 处理器中，`get_handle_point_at_mouse` 命中后，根据 `handle_point.get('obj_name')` 设置 `_state.selected_drag_object_name`，再调用 `capture_initial_handle_values` 与后续拖拽逻辑，确保操作正确的对象。

### Status
- **Fixed**: 非活动对象首尾帧手柄可正常拖拽。
- **Fixed**: 拖拽非活动对象手柄时不再误操作活动对象。

---

## 2026-02-26 (Crash Stability Fix — Stale RNA Reference Elimination)

### Context
用户反馈在完成“多对象/多骨骼路径显示与交互”后，Blender 崩溃频率显著上升。三份崩溃日志显示为 `EXCEPTION_ACCESS_VIOLATION`，并集中出现在绘制回调和交互路径相关调用链。

### Root Cause Analysis

根因是 `_state` 中长期保存了 Blender RNA 直接引用（对象/骨骼）。当底层 C++ 数据被删除或重建后，Python 侧旧引用变为悬空引用，后续在 draw / hit-test / drag 过程中访问这些引用会触发底层访问冲突。

### Changes

1. **状态字段改为名称字符串（避免悬空 RNA）**：
   - `selected_drag_object` → `selected_drag_object_name`
   - `selected_bone` → `selected_bone_name`
   - `handle_points` 内 `bone` 引用改为 `bone_name` 字符串

2. **新增安全对象解析函数**：
   - 增加 `_get_drag_obj(context)`，统一通过 `bpy.data.objects.get(name)` 动态查找拖拽目标，找不到时回退 `context.active_object`。

3. **多处交互流程改为“按名称临时解析”**：
   - 关键帧拖拽、手柄拖拽、命中检测、初值捕获等路径统一使用 `obj_name / bone_name` 解析，移除对持久 RNA 对象的依赖。

4. **绘制与缓存热路径增强异常防护**：
   - `get_current_parent_matrix`、`draw_motion_path_overlay`、`build_position_cache` 的关键循环补充异常防护，遇到失效对象/骨骼时跳过当前项，避免整条绘制链中断。

5. **Code Review 后续修正（本次同步落实）**：
   - 修复 POSE 命中检测中 `list(context.selected_pose_bones)` 的空值风险，改为 `list(context.selected_pose_bones or [])`。
   - `handle_point` 路径中 `_state.selected_drag_object_name` 改为显式赋值 `hp_obj_name or None`，避免残留旧对象名。
   - 统一异常写法为 `except Exception`，并补充注释说明：Python 层异常可兜底，C++ 级访问冲突需靠“消除悬空引用”从根源解决。

### Decisions
- **主修复优先级放在“去引用化”**：`try/except` 只能兜住 Python 层异常，无法保证拦截 C++ 崩溃；将 `_state` 改为字符串键是决定性修复。
- **绘制阶段实时查找对象/骨骼**：以轻微查找成本换取生命周期安全，适配对象删除、重命名、切换选择等高频编辑场景。
- **Review 问题与稳定性修复合并落地**：同一批改动集中清理，减少后续二次回归测试成本。

### Status
- **Fixed**: `_state` 不再持有对象/骨骼的长期 RNA 直接引用。
- **Fixed**: 多对象/多骨骼拖拽路径中的目标解析一致性提升，降低误命中风险。
- **Fixed**: POSE 命中检测空选择边界条件修复。
- **Stabilized**: 绘制与缓存流程对失效数据容错能力增强，崩溃风险显著下降。

---

## 2026-02-26 (Bug Fix — Parent-Child Path Offset in Object & Pose Mode)

### Context
用户测试发现：当选中对象有父级时，运动路径会偏移到父级的原点位置，而不是显示在子级的实际位置。问题同时存在于物体模式（Object Mode）和 Pose 模式（子骨骼）。

### Root Cause Analysis

**两个独立的坐标空间计算错误**：

#### 1. 物体模式 — 缺少 `matrix_parent_inverse`

Blender 对象的世界变换公式为：
```
matrix_world = parent.matrix_world @ matrix_parent_inverse @ matrix_basis
```
其中 `matrix_parent_inverse` 是绑定父级那一刻存储的补偿矩阵（等于父级当时世界矩阵的逆），用于防止子级在绑定时跳变。

原代码 `get_current_parent_matrix` 对有父级的对象只返回 `parent.matrix_world`，遗漏了 `matrix_parent_inverse`。绘制时：
- **错误**：`parent.matrix_world @ fcurve_values` → 路径出现在父级原点
- **正确**：`parent.matrix_world @ matrix_parent_inverse @ fcurve_values` → 路径在子级实际位置

#### 2. Pose 模式 — 子骨骼矩阵公式错误

原子骨骼公式为：
```python
obj.matrix_world @ bone.parent.matrix @ bone.bone.matrix_local
```
`bone.parent.matrix`（父骨骼当前姿态，骨架空间）和 `bone.bone.matrix_local`（子骨骼静止矩阵，同样是骨架空间）**都是骨架空间的矩阵，直接相乘没有几何意义**，等于将父骨骼的静止位置多叠加了一次，导致即使父骨骼无动画路径也会偏移。

正确的转换链：子骨骼本地偏移 → 父骨骼本地空间（`parent.bone.matrix_local.inverted() @ child.bone.matrix_local`）→ 骨架空间（`bone.parent.matrix @`）→ 世界空间（`obj.matrix_world @`）：
```python
obj.matrix_world @ bone.parent.matrix @ bone.parent.bone.matrix_local.inverted() @ bone.bone.matrix_local
```
当父骨骼无动画时（`parent.matrix == parent.bone.matrix_local`），中间两项抵消为 Identity，退化为根骨骼公式。

### Changes

1. **`get_current_parent_matrix` — 物体模式父级分支**：
   - 将 `return parent_mat` 改为 `return parent_mat @ obj.matrix_parent_inverse`。
   - 同时覆盖普通对象父级和骨骼父级（`parent_type == 'BONE'`）两种情况。
   - 为 BONE 父级查找失败的降级路径补充注释说明。

2. **`get_current_parent_matrix` — Pose 模式子骨骼分支**：
   - 在 `bone.parent.matrix` 与 `bone.bone.matrix_local` 之间插入 `bone.parent.bone.matrix_local.inverted()`。
   - 提取局部变量 `parent_to_child_rest` 提升可读性。

3. **Code Review 后续清理**：
   - 删除 `_state.path_batch` 死代码（`MotionPathState.__init__`、`build_position_cache` 重置处、路径构建处共 3 处）：该 batch 在缓存阶段构建但绘制阶段从未使用，白白浪费一次 GPU 上传。
   - 移除 `get_current_parent_matrix` 的 `context` 参数（函数体内从未使用），同步更新全部 10 处调用点。

### Decisions
- **`matrix_parent_inverse` 而非重新推导**：直接使用 Blender 已存储的 `obj.matrix_parent_inverse` 是最简洁、最准确的方式，无需重新计算或依赖 `frame_set`，与插件"不调用 frame_set、不修改场景状态"的设计原则完全一致。
- **不在缓存阶段处理父级**：父级矩阵在绘制阶段实时乘以缓存的本地值，使路径能实时跟随父级移动，无需在父级变换时重建缓存。
- **子骨骼公式的几何推导**：关键在于 `bone.bone.matrix_local` 是骨架空间矩阵，不能与同空间的 `parent.matrix` 直接链式相乘；必须先用 `parent.bone.matrix_local.inverted()` 将其还原到父骨骼本地空间，再由 `parent.matrix` 带回骨架空间。

### Status
- **Fixed**: 物体模式下有父级的对象运动路径现在显示在子级正确位置。
- **Fixed**: Pose 模式下子骨骼运动路径偏移问题修复，父骨骼有无动画均正确。
- **Removed**: `path_batch` 死代码已清除。
- **Cleaned**: `get_current_parent_matrix` 接口精简，移除未使用的 `context` 参数。

---

## 2026-02-25 (Bug Fix — Object Mode Path Not Updating on Selection Switch)

### Context
用户测试发现：物体模式下，打开运动路径后选中一个对象能正常显示路径，但切换选中另一个对象时，路径不更新，仍显示第一个对象的运动路径。骨骼模式无此问题。新场景可稳定复现。

### Root Cause Analysis

**双重失效**：

1. **`on_depsgraph_update` 误判**：用户点击切换选中对象时，depsgraph 触发 `is_object_updated=True, is_action_updated=False`。handler 将此判定为"交互移动"（`is_interaction_update = True`）并直接 `return`，`build_position_cache` 从未被调用。该判断的原意是避免 G/R/S 变换时卡顿，但对象选择切换与 G/R/S 移动对 depsgraph 的信号完全相同，无法区分。

2. **modal 缺少对象切换检测**：`MOTIONPATH_AutoUpdateMotionPaths.modal` 仅跟踪骨骼选择变化（Pose 模式），没有等价的"活动对象切换检测"（Object 模式）。因此即便 handler 跳过，modal 也不会补充触发重建。骨骼模式之所以正常，是因为 modal 的 `_get_bone_selection_state` 检测了骨骼切换并主动触发更新。

### Changes

1. **`invoke` 初始化 `_last_active_obj_name` 和 `_last_bone_selection`**：
   - 在 `invoke` 中与 `_last_keyframe_values` 同级初始化两个状态变量，消除 `modal` 热路径中原有的 `hasattr` 检查（性能改善）。

2. **`modal` 新增活动对象切换检测**：
   - 在骨骼选择检测之前，插入对 `context.active_object.name` 的比对逻辑。
   - 当活动对象名称变化时：清除 `_state` 中 8 个过时的选择/拖拽状态字段（防止新对象渲染时显示旧对象遗留的选中高亮），并设 `_needs_update = True` 触发缓存重建。

3. **`modal` 重绘范围扩展**：
   - 将触发重绘从仅刷新 `context.area` 改为遍历所有窗口的全部 `VIEW_3D` 区域，与 `on_depsgraph_update` 保持一致，修复多视口场景下可能不刷新的问题。

### Decisions
- **修复位置选在 modal 而非 depsgraph handler**：在 handler 中区分"对象切换"和"G/R/S 移动"在技术上极为困难（两者 depsgraph 信号相同）。在 modal 中追踪活动对象名称变化是最小侵入、最稳定的方案，且与骨骼模式已有的检测模式完全对称。
- **清除 `_state` 选择状态**：对象切换后如不清理，旧对象的 `selected_frame`、`selected_bone` 等字段可能使新对象的路径出现错误的高亮渲染，需要主动重置。

### Status
- **Fixed**: 物体模式下切换活动对象，运动路径即时更新为新对象的路径。
- **Fixed**: 多视口场景下切换对象后所有 3D 视图正确刷新。
- **No Regression**: Pose 模式骨骼切换行为不变；G/R/S 交互避让逻辑不变。

---

## 2026-02-25 (Code Review — Comprehensive Optimization)

### Context
对插件代码进行全面 Code Review，识别性能热点、死代码、代码重复、异常处理问题，并在不破坏现有功能的前提下系统性优化。

### Changes

**P1 — 高优先级**

1. **绘制热路径 O(n×m) → O(n+m) 优化**：
   - **Issue**: 原 `draw_enhanced_object_path` / `draw_enhanced_bone_path` 对每一帧都调用 `get_fcurves(action)` 遍历全部 fcurve，复杂度为 O(帧数 × fcurve数)，每次重绘都执行。
   - **Fix**: 合并两函数为 `draw_enhanced_path(…, bone=None)`，进入帧循环前预先构建 `{frame_int: {array_index: keyframe}}` 字典及 `frame_selected` 集合，帧循环内直接 O(1) 查找，复杂度降至 O(n+m)。

2. **清理 modal 死代码块**：
   - **Issue**: `MOTIONPATH_DirectManipulation.modal` 的 MOUSEMOVE 分支中，点拖拽逻辑存在一个带大量误导性注释的 `pass` 分支，真正的点拖拽实现在下方重复判断，造成逻辑混乱（约15行死代码）。
   - **Fix**: 删除无效 `pass` 分支和冗余注释，将双重 `if selected_handle_side is None` 合并为清晰的 `if/else` 结构。

3. **裸 `except:` → `except Exception:`**：
   - **Issue**: 全文16处裸 `except:`，会吞噬 `KeyboardInterrupt`、`SystemExit` 等系统异常。
   - **Fix**: 全部替换为 `except Exception:`。

**P2 — 中优先级**

4. **`auto_sapty_active` 拼写错误修正**：
   - 全文 11 处将拼写错误的 `auto_sapty_active` 统一重命名为 `auto_update_active`。

5. **提取 `_find_and_start_motion_path_operators` / `_stop_motion_path_operators`**：
   - **Issue**: `MOTIONPATH_ToggleCustomDraw.execute` 与 `update_custom_path_active` 中的启用/禁用逻辑几乎完全重复（共约60行），后者还含有无效的 `if found_view3d: pass` 死代码。
   - **Fix**: 提取为两个模块级辅助函数，两处共用；同时移除无效死代码。

6. **合并 `draw_enhanced_object_path` / `draw_enhanced_bone_path`**：
   - **Issue**: 两函数除 cache key 和 bone_name 参数外逻辑完全一致，违反 DRY 原则。
   - **Fix**: 合并为单一 `draw_enhanced_path(context, obj, parent_matrix, collector, bone=None)`（已与 P1-1 合并实现）。

7. **提取 `_build_ring_vertices` 辅助函数**：
   - **Issue**: `draw_origin_indicator` 中 `RING` 与 `RING_DOT` 样式的环形顶点生成循环代码完全重复（约20行）。
   - **Fix**: 提取为 `_build_ring_vertices(px, py, pz, scale, rx, ry, rz, ux, uy, uz, segments=32)`，两个样式分支共用。

8. **删除两个从未调用的死方法**：
   - `MOTIONPATH_AutoUpdateMotionPaths._has_selected_keyframes_changed` 和 `_get_selected_keyframes_state`（约25行）从未在 `modal` 中调用，直接删除。

**P3 — 低优先级**

9. **修复重复导入**：删除冗余的 `import bpy_extras` 和 `import bpy_extras.view3d_utils`，只保留 `from bpy_extras import view3d_utils`。

10. **`iface_` 简化**：从2行函数定义改为1行别名 `from bpy.app.translations import pgettext_iface as iface_`。

11. **删除 `HANDLE_SIZE = 10`**：定义后从未引用的死常量。

12. **同步 `bl_info` 版本号**：`(2, 0, 1)` → `(2, 1, 0)`，与 `blender_manifest.toml` 保持一致。

13. **清理过时注释**：移除 `# New: Path Drawing Data` 等开发期注释。

### Decisions
- **P1-1 在绘制函数重构中一并完成**：合并函数（P2-6）与 O(n×m) 优化（P1-1）在同一函数上操作，一次改完避免二次重构。
- **不修改 depsgraph handler 的交互避让逻辑**：该逻辑对 G/R/S 交互平滑度至关重要，修改风险高；对象选择切换问题通过 modal 检测解决（见上方 Bug Fix 条目）。

### Status
- **Improved**: 绘制热路径复杂度从 O(n×m) 降至 O(n+m)，关键帧多的场景性能显著提升。
- **Removed**: 约 60 行死代码/重复代码已删除。
- **Cleaned**: 全文异常处理、导入声明、常量定义、注释均已规范化。
- **No Regression**: 所有现有功能行为不变。

---

## 2026-02-25 23:00:00 (Origin Indicator Overlay)

### Context
用户反馈：插件绘制的运动路径会遮挡选中对象的原点 UI，导致用户在操作时难以定位对象原点。需要在运动路径层之上额外补充绘制一个当前选中对象/骨骼的原点指示器，并允许用户在插件首选项中自定义样式。

### Changes

1. **`MotionPathStyleSettings` 新增原点指示器属性**：
   - `show_origin_indicator`（BoolProperty）：整体开关，默认开启。
   - `origin_indicator_style`（EnumProperty）：样式选择，三选一：
     - `RING`：空心圆环（LINE_LOOP）
     - `DOT`：实心圆点（TRI_FAN）
     - `RING_DOT`：外环 + 中心实心小圆（默认，类似 Blender 原生原点样式）
   - `origin_indicator_size`（FloatProperty）：尺寸，4~40px，默认 12px。
   - `origin_indicator_color`（FloatVectorProperty RGBA）：外环/主体颜色，默认白色（0.9 透明度）。
   - `origin_indicator_inner_color`（FloatVectorProperty RGBA）：内点颜色，默认橙色，仅在 DOT / RING_DOT 样式下显示。

2. **新增 `draw_origin_indicator()` 函数**：
   - 插入在 `draw_motion_path_overlay()` 之前。
   - 坐标计算：
     - 对象模式：`obj.matrix_world.translation`（当前帧世界原点，实时跟随变换）。
     - 姿态模式（活动骨骼）：`(obj.matrix_world @ bone.matrix).translation`（骨骼头部世界坐标）。
   - 绘制逻辑：
     - `RING`：32 段 `LINE_LOOP`，线宽 2px，颜色使用 `origin_indicator_color`。
     - `DOT`：复用现有 `draw_billboard_circle()`，颜色使用 `origin_indicator_inner_color`。
     - `RING_DOT`：先绘制 32 段外环，再绘制 1/3 大小的中心实心圆。
   - 包含完整的数值合法性检查（`SAFE_LIMIT` / `math.isfinite`），防止 GPU 驱动崩溃。

3. **`draw_motion_path_overlay()` 追加调用**：
   - 在 `collector.draw(context)` 之后追加 `draw_origin_indicator()` 调用。
   - 确保原点指示器始终渲染在路径、关键帧点、手柄等所有元素之上。

4. **`MOTIONPATH_AddonPreferences.draw()` 新增 UI 分区**：
   - 在首选项末尾追加"Origin Indicator"分区。
   - 开关关闭时折叠所有子选项；样式为 RING 时隐藏内点颜色（不相关）。

### Decisions
- **实时坐标而非缓存坐标**：原点指示器使用 `matrix_world.translation`（当前帧实时值），而非位置缓存中的某帧数据，确保指示器始终反映对象在当前帧的真实位置。
- **绘制顺序保证**：通过在 `collector.draw()` 之后调用，利用 GPU 绘制顺序保证叠加在路径之上，无需额外深度测试控制。
- **RING_DOT 为默认样式**：外环 + 内点的组合与 Blender 原生原点显示风格一致，用户认知成本最低。

### Status
- **New Feature**: 原点指示器正常绘制于运动路径之上，对象模式和姿态模式均已支持。
- **Configurable**: 首选项中可自定义样式、大小、颜色，默认值开箱即用。
- **No Regression**: 未修改任何现有绘制逻辑，无回归风险。

---

## 2026-02-25 21:00:00 (Code Review — Docstring & Comment Cleanup)

### Context
对全面 Fast Path 迁移后的代码进行 Code Review，发现三处非功能性缺陷并修复。

### Issues Fixed

1. **`get_current_parent_matrix` 骨骼模式 docstring 与实现不符**：
   - **Issue**: POSE 骨骼模式的注释仍描述旧行为（"仍用 post-constraint 的 `bone.matrix` 计算"，"骨骼约束问题留待以后处理"），与已实现的新公式完全脱节。
   - **Fix**: 重写该注释，准确描述新公式语义：`bone.bone.matrix_local`（REST 姿态，稳定）× `bone.parent.matrix`（父骨骼 pose，含父骨骼约束），并说明对 drag 操作（`parent_rot_inv @ world_offset`）同样正确有效。

2. **`build_position_cache` 内注释编号重复**：
   - **Issue**: 函数内部有两个 `# 1.` 标注——原子锁和关键帧缓存分别都是 `# 1.`，与随后的 `# 2.`（路径线）形成逻辑混乱。
   - **Fix**: 将原子锁注释的 `# 1.` 前缀去掉，原子锁不是逻辑步骤，不参与编号。`# 1. Build Keyframe Cache` 和 `# 2. Build Path Line Batch` 现在连续清晰。

3. **`sorted(list(set(...)))` 中多余的 `list()` 包裹（历史遗留）**：
   - **Issue**: `sorted()` 直接接受任意可迭代对象，`list(set(...))` 的 `list()` 是无意义的转换开销。
   - **Fix**: `sorted(list(set(...)))` → `sorted(set(...))`。

### Status
- **No functional change**: 以上三处均为文档和注释层面，不影响运行逻辑。
- **Improved**: 代码可读性和注释准确性提升；docstring 与实现完全同步。

---

## 2026-02-25 20:00:00 (Unified Fast Path — Slow Path Removed)

### Context
经过对 Slow Path 实际作用的深入分析，发现其从根本上无法达成原始设计目标（捕获约束对位置的影响），因为它读取的是 `matrix_basis.translation`（约束介入前的数据），与直接读 F-Curve 等价。在此基础上，决定彻底废弃 Slow Path，统一走 Fast Path。

### Changes

1. **全面迁移到 Fast Path（`build_position_cache`）**：
   - **OBJECT 模式**：删除 `has_constraints`/`has_drivers`/`use_fast_path` 判断逻辑，直接调用 `calculate_path_from_fcurves`。
   - **POSE 模式关键帧缓存**：删除 `fast_bones`/`slow_bones` 分类逻辑及整个 Slow Path 处理块，所有骨骼统一调用 `calculate_path_from_fcurves`。
   - **路径线（path line）**：删除两套路径线的约束检查和 Slow Path 分支，统一使用 `calculate_path_from_fcurves`。

2. **删除 `frame_changed` 标志及帧恢复逻辑**：
   - `scene.frame_set()` 不再被调用，`frame_changed`、`current_frame`、`view_layer` 变量也一并移除。

3. **修复骨骼模式 `get_current_parent_matrix`**：
   - **Issue**: 旧公式 `(obj.matrix_world @ bone.matrix) @ bone.matrix_basis.inverted()` 与 Object 模式旧公式有相同问题——`bone.matrix` 含约束旋转，产生残差。
   - **Fix**: 改为从父级链推导：
     - 子骨骼：`obj.matrix_world @ bone.parent.matrix @ bone.bone.matrix_local`
     - 根骨骼：`obj.matrix_world @ bone.bone.matrix_local`
   - `bone.bone.matrix_local` 是 REST 姿态矩阵（不含约束），`bone.parent.matrix` 是父骨骼的 pose 矩阵（包含父骨骼自身的约束，符合预期）。

4. **更新 `build_position_cache` docstring**：清晰描述统一 Fast Path 的坐标系契约。

### Decisions
- **彻底废弃 Slow Path 的理由**：Slow Path 读 `matrix_basis.translation`（约束前），与 Fast Path 读 F-Curve 结果等价，没有实质差异，但有大量性能开销和交互干扰风险。
- **无 location F-Curve 的骨骼（IK 等）**：`frames` 集合为空，`continue` 跳过，不显示路径——行为正确。
- **bone.bone.matrix_local 的稳定性**：该矩阵是 REST 姿态数据，不随帧变化，不含约束，是正确推导骨骼父矩阵的基础。

### Status
- **Removed**: Slow Path 完全移除，`frame_set` 永远不再被调用。
- **Fixed**: 带旋转约束骨骼的路径不再偏转（骨骼 parent_matrix 修复）。
- **Improved**: 代码净减少约 70 行，逻辑大幅简化。
- **Maintained**: 所有 Fast Path 原有行为不变；Smart Interaction 缓存复用机制不变。

## 2026-02-25 18:00:00 (Constraint Coordinate Space Fix)

### Context
用户在测试中发现：对象（以圆锥 + 阻尼跟踪约束为例）启用约束后，尽管约束只改变旋转，运动路径也会跟随旋转，表现得像是以对象自身为父级。深入分析后还发现 Slow Path 读取的坐标与其设计意图不符。

### Root Cause Analysis

1. **`get_current_parent_matrix` 中的旋转污染**：
   - 旧公式：`parent_matrix = obj.matrix_world @ obj.matrix_basis.inverted()`
   - 问题：`obj.matrix_world` 已包含约束叠加的旋转，而 `obj.matrix_basis` 不含约束旋转，二者相除后产生"旋转残差"。
   - 后果：所有缓存路径点被这个残差矩阵错误旋转，路径看起来随物体旋转。
   - 本质：无父级对象 `matrix_world @ matrix_basis.inverted()` 理想情况下应等于 `Identity`，但有旋转约束时 `matrix_world ≠ matrix_basis`，结果不再是 `Identity`。

2. **Slow Path 读取的是约束前坐标（`matrix_basis`）**：
   - 旧行为：Slow Path 切帧后读 `obj.matrix_basis.translation`，这是约束介入**之前**的原始 F-Curve 值。
   - 后果：Slow Path 对位置约束（Copy Location、Follow Path）与 Fast Path 读 F-Curve 的效果完全相同，完全无法表现约束对位移的影响——Slow Path 的设计初衷被架空。

### Changes

1. **重写 `get_current_parent_matrix` 的 OBJECT 模式逻辑**：
   - **Fix**: 改为直接从父级链推导，不再依赖对象自身的 `matrix_world`。
   - 无父级 → 返回 `Identity`（F-Curve 坐标即世界坐标）。
   - 有父级 → 返回 `obj.parent.matrix_world`（含骨骼父级修正）。
   - **Effect**: 彻底消除旋转约束（阻尼跟踪、Look At 等）造成的路径偏转。

2. **修复 Slow Path 位置读取（对象关键帧缓存与路径线缓存）**：
   - **Fix**: `obj.matrix_basis.translation` → 读 `obj.matrix_world.translation`（无父级）或 `(parent_inv @ obj.matrix_world).translation`（有父级）。
   - **Effect**: Slow Path 现在能正确捕获 Copy Location、Follow Path 等位置约束的效果；旋转约束只改旋转，不改 `matrix_world.translation`，所以旋转约束不再对路径位置产生影响。

3. **坐标系契约（Coordinate Space Contract）统一**：
   - 所有缓存坐标均存储在"父级本地空间"：无父级 = 世界空间，有父级 = 相对于 `parent.matrix_world`。
   - `get_current_parent_matrix` 返回值含义与此保持一致。
   - 绘制公式 `point_3d = parent_matrix @ cached_pos` 在任何情况下都能得到正确的世界坐标。

### Decisions
- **为何不改骨骼模式**：骨骼的坐标系更复杂（`matrix_basis` 在骨骼父空间，需要整条骨骼链变换），本次变更聚焦在对象模式，骨骼模式留作后续专项优化。
- **Slow Path 的存在价值重新确认**：修复后，Slow Path 的 `matrix_world.translation` 读取方式终于能正确表现位置约束的效果，相较于 Fast Path 具有实质差异，本次保留合理。
  > **后记（2026-02-25 20:00）**：经进一步分析，即便修复后的 Slow Path 在理论上可捕获位置约束，其性能代价（`frame_set` 逐帧切换）和交互干扰风险依然存在，且对动画师的实际工作流收益有限。最终决定全面废弃 Slow Path，统一使用 Fast Path，详见 20:00 条目。
- **Fast Path 不受影响**：Fast Path 对象没有约束，`matrix_world = parent_world @ matrix_basis`，旧公式和新公式等价（Identity / parent_world），无回归风险。

### Status
- **Fixed**: 带旋转约束（阻尼跟踪等）的对象路径不再随旋转偏转。
- **Fixed**: Slow Path 现在正确捕获位置约束效果（Copy Location、Follow Path 等）。
- **Maintained**: Fast Path 对象行为不变。
- **Maintained**: 骨骼模式行为不变（骨骼模式的约束坐标问题留后续处理）。
- **Superseded**: Slow Path 于 20:00 条目中被完全废弃。

## 2026-02-25 14:00:00 (Smart Mode Interaction & Slow Path Fixes)

### Context
用户反馈在 **Smart Mode** 下，当对象（尤其是带有位移动画或约束的对象）进行交互操作（如 G 键移动）时，会出现“锁死”或路径消失的问题。而在 Timer Mode 下则正常。

### Changes
1.  **修复“对象锁死”问题 (Recursive Lock)**:
    -   **Issue**: `build_position_cache` 中的 `frame_set()` 操作会触发 `depsgraph_update`，进而再次调用 `on_depsgraph_update`，形成递归死循环或高频阻塞，导致对象无法移动。
    -   **Fix**: 引入原子锁机制 (`_is_updating_cache`)。将锁的管理逻辑下沉到 `build_position_cache` 内部，确保函数具有原子性，任何递归调用都会被直接拦截。

2.  **修复“交互时位置重置”问题 (Fast Path)**:
    -   **Issue**: `build_position_cache` 即使在 Fast Path（只读 F-Curve）下，函数末尾也无条件执行了 `view_layer.update()` 和 `frame_current` 恢复。这会强制刷新场景，导致 G 键操作产生的临时变换状态被重置，对象“一动不动”。
    -   **Fix**: 引入 `frame_changed` 标志。只有在真正执行了 `frame_set`（Slow Path）的情况下，才会在计算结束后恢复帧并刷新视图。对于 Fast Path，函数变为纯只读，不再干扰场景状态。

3.  **优化“智能交互避让”策略 (Smart Interaction Detection)**:
    -   **Issue**: Slow Path 对象（带约束）在交互时必须切帧计算，这必然会打断用户的交互操作。如果为了避免打断而跳过计算（罢工），路径线会消失。
    -   **Fix**:
        -   在 `on_depsgraph_update` 中检测更新来源：如果只有 `OBJECT` 更新而 `ACTION`（关键帧数据）未变，判定为“正在交互”（G 键移动中）。
        -   此时直接 `return`，完全不调用 `build_position_cache`。
        -   **Result**: 利用 `_state.position_cache` 的持久性，在交互期间直接复用上一帧的缓存数据进行绘制。
        -   **Effect**: 无论是 Fast Path 还是 Slow Path，交互时对象移动丝般顺滑，路径线保持静止（显示移动前的状态），待用户确认操作（Action 更新）后，路径自动刷新。

4.  **代码审查与清理 (Refactoring)**:
    -   移除未使用的导入 (`re`)。
    -   简化 `build_position_cache` 的入口检查逻辑。
    -   添加详细文档字符串，解释新的智能交互逻辑。

### Decisions
-   **Cache Reuse Strategy**: 相比于在交互期间尝试计算（可能导致卡顿或状态冲突），直接复用旧缓存是最高效且体验最好的方案。用户在移动物体时，通常关注的是物体本身的位置，路径线暂时不动是可以接受的（且符合逻辑，因为关键帧数据确实还没变）。
-   **Atomic Lock Placement**: 将锁放在计算函数内部比放在 Handler 里更安全，能防止任何来源的调用导致递归。

### Status
-   **Fixed**: Smart Mode 下对象不再锁死。
-   **Fixed**: Fast Path 和 Slow Path 对象在交互时均不再卡顿或重置。
-   **Optimized**: 代码结构更清晰，文档更完善。
-   **Verified**: 用户确认功能修复并接受代码审查优化。

## 2026-02-25 10:00:00 (i18n & Registration Fixes)

### Context
用户反馈在 Blender 5.0 中插件无法加载（注册错误）以及界面无法显示中文翻译。

### Changes
1.  **修复 EnumProperty 注册错误**:
    -   **Issue**: `motion_path_update_mode` 和 `handle_type` 的 `items` 参数使用了动态回调函数 `get_update_mode_items`，但在插件注册阶段，Blender 的翻译系统可能尚未完全初始化，导致 `EnumProperty` 注册失败。
    -   **Fix**: 将 `items` 改回静态列表定义 `motion_path_update_mode_items` 和 `handle_type_items`。
    -   **Result**: 插件可以正常加载，无报错。

2.  **修复国际化 (i18n) 问题**:
    -   **Issue**: 插件虽然使用了 `bpy.app.translations`，但在 Blender Extension 环境下（包名动态变化），原有的 `msgctxt=__package__` 导致上下文匹配失败，中文翻译无法显示。
    -   **Fix**:
        -   **Universal Context**: 在 `translations.py` 中，将所有翻译字典的键从 `("Context", "Original")` 或 `"Original"` 统一修改为 `("*", "Original")`。通配符 `*` 确保翻译在任何上下文下都能生效。
        -   **Remove msgctxt**: 在 `__init__.py` 的 `iface_` 辅助函数中，移除了 `msgctxt` 参数，直接调用 `pgettext_iface(msg)`，使其匹配通用上下文。
    -   **Result**: 插件界面（包括 Header 菜单、下拉选项、Operator 描述）现在能正确跟随 Blender 的语言设置显示中文。

### Decisions
-   **Static vs Dynamic Enum Items**: 虽然动态 Items 更灵活，但在不需要动态改变选项内容的情况下，静态列表更稳定，且能利用 Blender 的自动翻译机制。
-   **Universal Translation Context**: 针对 Blender Extension 这种包名不确定的环境，使用 `*` 上下文是最稳健的翻译策略，避免了硬编码包名带来的维护成本和兼容性问题。

### Status
-   **Fixed**: 插件加载错误已修复。
-   **Fixed**: 中文翻译已完全恢复。
-   **Verified**: 用户确认插件功能正常且界面已显示中文。

## 2026-02-24 22:00:00 (UI Optimization: Header Menu & Preferences Migration)

### Context
用户希望优化插件的 UI 布局，减少侧边栏（N-Panel）的占用，并将设置项根据使用频率进行重新分类和安置。

### Changes

1. **新增 Header 菜单入口**：
   - 在 Graph Editor / 3D Viewport 的 Header 菜单中增加插件快捷入口，用户无需打开 N-Panel 即可启停路径显示和切换更新模式。
   - 降低了高频操作的点击层级。

2. **设置项迁移到 Preferences**：
   - 将不常用的配置选项（颜色、线宽、点大小、帧间距等风格参数）从 N-Panel 移入插件的 Blender Preferences 面板。
   - N-Panel 仅保留核心开关和当前帧范围等高频参数，界面更简洁。

3. **设置项分类重组**：
   - 按"使用频率"重新分组：高频操作（启停、更新模式）放顶层；风格调整（颜色、粗细）放 Preferences；高级选项（FPS、缓存策略）也归入 Preferences。

### Decisions
- **Header vs N-Panel**：Header 菜单适合"一次性开关"类操作，N-Panel 适合需要长期可见的参数。遵循 Blender 自身的 UI 规范。
- **Preferences 作为低频设置的归宿**：Blender 的 Preferences 系统提供了持久化存储，适合风格类参数；同时减少了 N-Panel 的信息密度，降低认知负担。

### Status
- **Improved**: N-Panel 内容精简，操作路径更短。
- **Maintained**: 所有原有功能均可访问，无功能退化。
