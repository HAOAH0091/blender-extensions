# -*- coding: utf-8 -*-
"""三角手柄「一体 / 分离」锁定 —— 双击切换 + 选中配对 + 一体拖动（用户需求）。

★ 2026-09-19 语义修正（用户拍板）：
    「一体」拖动 = 两侧**各加减同一个增量**、**差异保留**。
    （旧语义"两侧速度始终相同 / 一个旋钮"已作废 —— 用户原话：
      「一体化锁定的定义应该是可以同时做增量调整，不是改变稀疏数值为相同」。）

需求原文
--------
    "默认情况下三角控制柄都是黄色实心黑色细边框，这时用户点击选择三角控制柄的话
     会高亮默认同时选中两个三角控制柄，应该说这个情况下两个三角控制柄是一体的，
     用户在选中拖动和模态操作时的行为和之前同时选中两个三角控制柄一样，
     然后用户如果想只调整单边，这时可以双击其中一个三角控制柄，这时就能解锁
     三角控制柄的一体化，让两个三角控制柄分离，分离后的三角控制柄外观变为空心三角，
     这时用户可以操作单边的三角控制柄，如果用户又想锁定回去，则可以再次双击其中
     一个三角控制柄，这时插件会把同关键帧的另一个三角控制柄的数值同步到双击的
     三角控制柄，并同时锁定三角控制柄，所有关键帧点的三角控制柄的状态管理
     都是独立的，有插件持久化管理的"

判定口径（重要 —— 别把手段当语义）
---------------------------------------
· **一体（LOCKED，默认）**：同一关键帧的两个三角**联动**。
    单击任一个 ⇒ 两个都选中；拖动时两侧写**同一个 s**（用户拍板乙方案）。
· **分离（SPLIT）**：两个三角各自独立。
    单击只选被点的那个；拖动只改那一侧。
· **双击 = 切换**：一体 → 分离（空心）；分离 → 一体（**同步对侧值**到被双击的三角）。
· 状态**按关键帧独立**，持久化在 `act["rtmp_tri_lock"]`，**未记录 = 一体**。

⚠️ 端点上只有**一个**三角（首帧无左段三角 / 末帧无右段三角）⇒ 无所谓一体分离。

本测试
------
A 组：数据层（默认一体 / 切换 / 按帧独立 / 持久化格式）
B 组：单击配对（一体选两个 / 分离选一个 / 端点只选一个 / Shift 不配对）
C 组：双击切换（一体→分离 / 分离→一体+同步值 / 端点不消费）
D 组：一体拖动 = 两侧**各加减同一增量、差异保留**（分离则各自独立）—— **核心判据**
E 组：持久化「跨会话」（拿"下游对象"验证键的身份，不依赖真重启）
F 组：视觉（空心/实心分流 + 绘制原语支持 outline/filled）
G 组：静态契约（modal 真入口接的是切换函数 / 状态收敛到唯一键）
H 组：bug 注入必须被抓
"""
import os
import sys
import json
import math
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(REPO))
sys.stdout.reconfigure(encoding="utf-8")

import bpy

bpy.ops.preferences.addon_enable(module="RealTimeMotionPath")
from RealTimeMotionPath import transform_domain as xf, interaction as it
from RealTimeMotionPath import time_domain as td, handles as hd
from RealTimeMotionPath import overlay as ov
from RealTimeMotionPath.state import _session

OUT = os.path.join(HERE, "_tri_lock_result.json")
steps = []

# 相邻帧间距刻意做成【不等距】：左段 span=24，右段 span=30
KFS = ((1, (0.0, 0.0, 0.0)), (25, (3.0, 2.0, 0.6)), (55, (6.0, 0.0, 0.0)))
F0, FM, F1 = 1.0, 25.0, 55.0
UP, DOWN = hd.TRI_UP, hd.TRI_DOWN          # up→左段, down→右段


def step(n, ok, d=""):
    steps.append({"name": n, "ok": bool(ok), "detail": str(d)[:900]})


def flush():
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump({"total": len(steps),
                   "fails": sum(1 for s in steps if not s["ok"]),
                   "result": ("ALL PASS" if all(s["ok"] for s in steps)
                              else "HAS FAILURES"),
                   "steps": steps}, fh, ensure_ascii=False, indent=1)


def build(name, locs=KFS):
    sc = bpy.context.scene
    o = bpy.data.objects.get(name)
    if o:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))
    o = bpy.context.active_object
    o.name = name
    for f, loc in locs:
        sc.frame_set(f)
        o.location = loc
        o.keyframe_insert("location", frame=f)
    sc.frame_set(1)
    a = o.animation_data.action
    for c in xf._position_curves(a, o, None):
        for k in c.keyframe_points:
            k.handle_left_type = 'FREE'
            k.handle_right_type = 'FREE'
        c.update()
    bpy.context.view_layer.objects.active = o
    for ob in bpy.data.objects:
        ob.select_set(ob is o)
    return o, a


def read_s(o, frame, side):
    """★ **独立口径**：直接从 F-Curve 读时间分量、自己算 span。

    刻意**不调产品函数** —— 否则产品里读法错了，测试也跟着错（"用自己的尺子量自己"）。
    只依赖最原始的定义：`s = |手柄时间分量 − 关键帧帧号| / 相邻帧跨度`。
    """
    act = o.animation_data.action
    cs = {c.array_index: c for c in xf._position_curves(act, o, None)}
    if not cs:
        return None
    frames = sorted({float(k.co[0]) for c in cs.values() for k in c.keyframe_points})
    f = float(frame)
    if f not in frames:
        return None
    i = frames.index(f)
    kp = None
    for k in cs[0].keyframe_points:
        if abs(k.co[0] - f) < 1e-3:
            kp = k
            break
    if kp is None:
        return None
    if side == 'left':
        if i == 0:
            return None
        span = frames[i] - frames[i - 1]
        dt = abs(float(kp.co[0]) - float(kp.handle_left[0]))
    else:
        if i == len(frames) - 1:
            return None
        span = frames[i + 1] - frames[i]
        dt = abs(float(kp.handle_right[0]) - float(kp.co[0]))
    return dt / span if span > 1e-9 else None


def write_s(o, frame, side, s):
    return it._apply_speed_d(bpy.context, o, float(frame), side,
                             td.s_to_d(float(s)))


def ge_handles(o, frame):
    """★ **独立口径**：直接读 F-Curve 里该关键帧的 (co, hl, hr)。

    刻意不调产品函数 —— 语义定义只有一条：共线 = (co−hl) × (hr−co) == 0。
    """
    act = o.animation_data.action
    out = {}
    for c in xf._position_curves(act, o, None):
        for kp in c.keyframe_points:
            if abs(kp.co[0] - float(frame)) < 1e-3:
                out[c.array_index] = (tuple(kp.co), tuple(kp.handle_left),
                                      tuple(kp.handle_right))
                break
    return out


def ge_cross(o, frame):
    """★ 共线残差（每轴）：(co−hl) × (hr−co)。0 = 共线；异号场景下 0 表示镜像。"""
    res = {}
    for ax, (co, hl, hr) in ge_handles(o, frame).items():
        res[ax] = (co[0]-hl[0])*(hr[1]-co[1]) - (co[1]-hl[1])*(hr[0]-co[0])
    return res


def ge_slopes(o, frame):
    """★ 独立斜率（每轴）：(左斜率, 右斜率) = (A/dtL, B/dtR)。"""
    out = {}
    for ax, (co, hl, hr) in ge_handles(o, frame).items():
        dl, dr = co[0]-hl[0], hr[0]-co[0]
        out[ax] = ((co[1]-hl[1])/dl if abs(dl) > 1e-12 else 0.0,
                   (hr[1]-co[1])/dr if abs(dr) > 1e-12 else 0.0)
    return out


def ge_ok(o, frame, tol=1e-4):
    """★ 判据：所有轴都共线（相对残差小）。"""
    hs = ge_handles(o, frame)
    if not hs:
        return False
    for ax, (co, hl, hr) in hs.items():
        dtl, dtr = co[0]-hl[0], hr[0]-co[0]
        A, B = co[1]-hl[1], hr[1]-co[1]
        scale = max(abs(dtl*B), abs(A*dtr), 1e-12)
        if abs(dtl*B - A*dtr)/scale > tol:
            return False
    return True


def mk_handles(frame, tri_list=(UP, DOWN), kf_screen=(100.0, 100.0), s=td.S_LIN):
    """构造手柄记录（几何与真实收集一致：tri_screen 用固定偏移）。"""
    out = []
    for t in tri_list:
        out.append(hd.make_handle(frame=float(frame), tri=t, span=24.0,
                                  s=s, d=td.s_to_d(s),
                                  kf_screen=kf_screen, kf_world=(0.0, 0.0, 0.0)))
    return out


def center(hs, frame, tri):
    return hd.find_handle(hs, frame, tri)['tri_screen']


def read_d(o, f, side):
    """读该侧的 **d**（三角到关键帧的屏幕像素当量，unclamped）。

    ★ 2026-09-19 新增：一体拖动的判据改在 **d 空间**（两侧各加减同一增量），
      所以需要按 unclamped 口径读 d（与产品写入口径一致）。
    """
    act = o.animation_data.action if o.animation_data else None
    if act is None:
        return None
    kf_map, span = td.resolve_target(act, o, float(f), side)
    if not kf_map or span is None:
        return None
    s = td.read_s(next(iter(kf_map.values())), span, side)
    return None if s is None else td.s_to_d_unclamped(s)


def reset_state(o=None):
    """只清**交互态**（选中 / 双击链）。

    ⚠️ **不碰**锁定记录 —— 那是被测的**数据**。
       （实测踩坑：早先这里顺手 `clear_tri_lock`，把"分离"冲回"一体"，
         B3/C3/C4/C5 全部假失败 —— 测试自己把被测状态擦掉了。）
    """
    _session.speed_click_info = None
    _session.clear_speed_handle()


def drag_pair(o, hs, hit_tri, dy_px, steps_n=1):
    """走**真入口**模拟一次按下→拖→松（每步调 `_apply_speed_from_drag`）。

    ⚠️ 必须走真入口：直接调产品里"算 s 的那个函数"等于测平行复刻。
    """
    pos = center(hs, FM, hit_tri)
    _session.speed_click_info = None
    it.apply_speed_click_selection(o, hs, hd.find_handle(hs, FM, hit_tri))
    if _session.is_locked_pair_selected(FM) and it.is_frame_locked(o, FM):
        _session.speed_drag_group_origin_s = float(hd.find_handle(hs, FM, hit_tri)['s'])
        _session.speed_drag_locked_frame = FM
    else:
        _session.speed_drag_group_origin_s = None
        _session.speed_drag_locked_frame = None
    # ★★ 2026-09-19：起点口径与产品一致 —— 用**真实数据**的 s 算 unclamped d。
    #   （产品在按下时从真实 handles 收集；测试的 mk_handles 用固定 s 只是为了
    #     给出"鼠标点在哪"，不能拿它当拖拽基准，否则与数据对不上。）
    _origins = {}
    for _h in hs:
        if not _session.is_speed_handle_selected(_h['frame'], _h['tri']):
            continue
        _s_real = read_s(o, _h['frame'], hd.SIDE_BY_TRI.get(_h['tri']))
        _origins[(_h['frame'], _h['tri'])] = td.s_to_d_unclamped(_s_real)
    _session.speed_drag_origins = _origins
    _session.speed_drag_origin_d = _origins.get((FM, hit_tri),
                                                td.s_to_d_unclamped(
                                                    read_s(o, FM,
                                                           hd.SIDE_BY_TRI.get(hit_tri))))
    _session.speed_drag_effective_px = 0.0
    _session.speed_drag_last_mouse = pos
    for i in range(steps_n):
        _session.speed_drag_last_mouse = (pos[0], pos[1] + dy_px * i / steps_n)
        it._apply_speed_from_drag(bpy.context, o, (pos[0], pos[1] + dy_px * (i + 1) / steps_n))


try:
    # ==================================================== A 组：数据层
    o, a = build("_TL_A")
    step("A1 ★★★ 默认（无记录）= **一体**（需求：默认情况下两个三角是一体的）",
         it.is_frame_locked(o, FM) is True, "is_tri_locked=%s" % (it.is_frame_locked(o, FM),))

    xf.set_tri_locked(a, FM, False)
    step("A2 ★★★ 切成分离 ⇒ 查询返回 False",
         it.is_frame_locked(o, FM) is False, "")

    step("A3 ★★ 状态**按关键帧独立**：另一帧仍是一体",
         it.is_frame_locked(o, F0) is True and it.is_frame_locked(o, F1) is True,
         "f0=%s f55=%s" % (it.is_frame_locked(o, F0), it.is_frame_locked(o, F1)))

    xf.set_tri_locked(a, F0, False)
    step("A4 ★★ 两帧各自独立可分离",
         it.is_frame_locked(o, F0) is False and it.is_frame_locked(o, FM) is False
         and it.is_frame_locked(o, F1) is True, "")

    xf.set_tri_locked(a, FM, True)
    step("A5 ★★★ 锁回一体 ⇒ 记录被**清掉**（不留僵尸词条）",
         it.is_frame_locked(o, FM) is True
         and not any((xf._trilock_parse(t) or (None,))[0] == FM
                     for t in xf.trilock_tokens(a)),
         "tokens=%s" % (xf.trilock_tokens(a),))

    step("A6 持久化格式：SPLIT 写成 '帧号|SPLIT'",
         xf._trilock_token(14.0, False) == "14.0000|SPLIT"
         and xf._trilock_token(14.0, True) == "14.0000|LOCKED", "")

    # ==================================================== B 组：单击配对
    reset_state(o)
    hs = mk_handles(FM)
    locked_pair, tris = it.apply_speed_click_selection(o, hs, hd.find_handle(hs, FM, UP))
    step("B1 ★★★ 一体态单击 up ⇒ **两个都选中**（一体）",
         locked_pair is True and _session.is_locked_pair_selected(FM),
         "一体化=%s 选中=%s" % (locked_pair, _session.selected_speed_handles))

    reset_state(o)
    locked_pair2, _ = it.apply_speed_click_selection(o, hs, hd.find_handle(hs, FM, DOWN))
    step("B2 ★★★ 一体态单击 down ⇒ 同样两个都选中（与点哪个无关）",
         locked_pair2 is True and _session.is_locked_pair_selected(FM),
         "选中=%s" % (_session.selected_speed_handles,))

    xf.set_tri_locked(a, FM, False)
    reset_state(o)
    locked_pair3, _ = it.apply_speed_click_selection(o, hs, hd.find_handle(hs, FM, UP))
    step("B3 ★★★ 分离态单击 up ⇒ **只选一个**（用户要「只调整单边」）",
         locked_pair3 is False
         and _session.selected_speed_handles == [(FM, UP)],
         "一体化=%s 选中=%s" % (locked_pair3, _session.selected_speed_handles))

    reset_state(o)
    hs_edge = mk_handles(F0, tri_list=(DOWN,))     # 首帧：只有右段三角
    lp_e, tris_e = it.apply_speed_click_selection(o, hs_edge, hd.find_handle(hs_edge, F0, DOWN))
    step("B4 ★★ 端点上（只有一个三角）⇒ 只选一个，不会去选不存在的那个",
         lp_e is False and _session.selected_speed_handles == [(F0, DOWN)],
         "选中=%s 该帧三角=%s" % (_session.selected_speed_handles, tris_e))

    xf.set_tri_locked(a, FM, True)
    reset_state(o)
    it.apply_speed_click_selection(o, hs, hd.find_handle(hs, FM, UP))
    lp_s, _ = it.apply_speed_click_selection(o, hs, hd.find_handle(hs, FM, DOWN), shift=True)
    step("B5 ★★ Shift+点击 = 多选累加（不触发自动配对）",
         lp_s is False, "选中=%s" % (_session.selected_speed_handles,))

    # ==================================================== C 组：双击切换
    # C1：一体 → 分离
    o, a = build("_TL_C1")
    write_s(o, FM, 'right', 0.20)
    write_s(o, FM, 'left', 0.55)
    hs = mk_handles(FM)
    pos = center(hs, FM, UP)
    reset_state(o)
    it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)          # 第 1 击
    c1, m1 = it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)  # 第 2 击
    step("C1 ★★★ 一体态双击 ⇒ 切成**分离**（且不丢信息：值没被改）",
         c1 is True and it.is_frame_locked(o, FM) is False
         and abs(read_s(o, FM, 'left') - 0.55) < 1e-6
         and abs(read_s(o, FM, 'right') - 0.20) < 1e-6,
         "consumed=%s 分离=%s up=%.4f down=%.4f msg=%r"
         % (c1, not it.is_frame_locked(o, FM), read_s(o, FM, 'left'),
            read_s(o, FM, 'right'), m1))

    step("C2 ★★ 分离后鼠标点到的那个三角被**单选**（单边操作的起点）",
         _session.selected_speed_handles == [(FM, UP)],
         "选中=%s" % (_session.selected_speed_handles,))

    # C3（★ 2026-09-18 新语义）：分离 → 一体 ⇒ **对齐 GE 手柄**（不再是"复制对侧值"）
    #     规则：保持被双击侧不动，按公式算对侧 ⇒ 该帧 GE 手柄共线
    reset_state(o)
    up_before = read_s(o, FM, 'left')
    it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)          # 第 1 击
    c3, m3 = it.try_toggle_tri_lock_click(bpy.context, o, hs, pos)  # 第 2 击
    step("C3 ★★★ 分离态双击 ⇒ 锁回一体，且该帧 GE 手柄【共线】",
         c3 is True and it.is_frame_locked(o, FM) is True and ge_ok(o, FM),
         "一体=%s cross=%s up=%.4f down=%.4f msg=%r"
         % (it.is_frame_locked(o, FM),
            {k: round(v, 9) for k, v in ge_cross(o, FM).items()},
            read_s(o, FM, 'left'), read_s(o, FM, 'right'), m3))
    step("C3b ★★★ 对齐时【被双击侧(up)保持不变】（保疏密的一侧 = 被点的那个）",
         abs(read_s(o, FM, 'left') - up_before) < 1e-9,
         "up %.6f → %.6f（应相等）" % (up_before, read_s(o, FM, 'left')))

    step("C4 ★★ 锁回一体后**两个三角都被选中**（视觉与行为一致）",
         _session.is_locked_pair_selected(FM),
         "选中=%s" % (_session.selected_speed_handles,))

    # C5：反向（双击 down ⇒ down := up）
    o, a = build("_TL_C5")
    write_s(o, FM, 'left', 0.60)
    write_s(o, FM, 'right', 0.15)
    xf.set_tri_locked(a, FM, False)                 # 直接从分离态开始
    hs = mk_handles(FM)
    pos_d = center(hs, FM, DOWN)
    reset_state(o)
    it.try_toggle_tri_lock_click(bpy.context, o, hs, pos_d)
    c5, _ = it.try_toggle_tri_lock_click(bpy.context, o, hs, pos_d)
    step("C5 ★★★ 分离态双击 down ⇒ 锁回一体 + GE 手柄共线，且 down 侧不动",
         c5 is True and it.is_frame_locked(o, FM) is True and ge_ok(o, FM)
         and abs(read_s(o, FM, 'right') - 0.15) < 1e-9,
         "down=%.4f up=%.4f cross=%s"
         % (read_s(o, FM, 'right'), read_s(o, FM, 'left'),
            {k: round(v, 9) for k, v in ge_cross(o, FM).items()}))

    # C6：端点（只有一个三角）⇒ 不消费，交给普通单击
    o, a = build("_TL_C6")
    hs_e = mk_handles(F0, tri_list=(DOWN,))
    pos_e = center(hs_e, F0, DOWN)
    reset_state(o)
    it.try_toggle_tri_lock_click(bpy.context, o, hs_e, pos_e)
    c6, m6 = it.try_toggle_tri_lock_click(bpy.context, o, hs_e, pos_e)
    step("C6 ★★ 端点（单三角）双击 ⇒ **不消费**（没有「一对」可切换，交给单击）",
         c6 is False and m6 is None, "consumed=%s msg=%r" % (c6, m6))

    # C7：点空白 ⇒ 不消费 + 断链
    reset_state(o)
    _session.speed_click_info = {'frame': 1.0, 'tri': UP, 't': 0.0, 'pos': (0.0, 0.0)}
    c7, m7 = it.try_toggle_tri_lock_click(
        bpy.context, o, hs, (pos[0] + 900.0, pos[1] + 900.0))
    step("C7 ★ 点空白 ⇒ 不消费 + 断掉双击链",
         c7 is False and m7 is None and _session.speed_click_info is None,
         "consumed=%s 链=%s" % (c7, _session.speed_click_info))

    # ==================================================== D 组：一体拖动（核心）
    # ★★ 2026-09-19（用户拍板，语义修正）：一体拖动 ⇒ 两侧各加减**同一增量**，
    #   **差异保留**。（旧语义"两侧 s 恒等/一个旋钮"已被用户推翻。）
    # 本轮判据：两侧初始 s **故意不同** + span 不等距（24 vs 30）——
    #   两者都必须被保留（Δd 相等、差值不变）。
    o, a = build("_TL_D1")
    write_s(o, FM, 'left', 0.25)
    write_s(o, FM, 'right', 0.40)
    dl0, dr0 = read_d(o, FM, 'left'), read_d(o, FM, 'right')
    hs = mk_handles(FM)
    drag_pair(o, hs, UP, dy_px=40.0)
    dl1, dr1 = read_d(o, FM, 'left'), read_d(o, FM, 'right')
    sl1, sr1 = read_s(o, FM, 'left'), read_s(o, FM, 'right')
    # ⚠️ 容差用 1e-4 而非 1e-6：Blender 把手柄坐标存成 **float32**
    #   （实测 s=0.677 写回读成 0.6770000457763672 ⇒ d 残差 1.8e-06）。
    #   这是**测量精度**，不是逻辑误差；1e-4 像素视觉上完全不可见。
    _TOL = 1e-4
    step("D1 ★★★ **一体拖动 ⇒ 两侧各加减【同一增量】，差异保留**"
         "（用户 2026-09-19 拍板；推翻旧的\"抹成同值\"语义）",
         None not in (dl0, dr0, dl1, dr1)
         and abs((dl1 - dl0) - (dr1 - dr0)) < _TOL       # ② 增量相等
         and abs(dl1 - dl0) > 1e-3                       # ③ 确实动了
         and abs((dl1 - dr1) - (dl0 - dr0)) < _TOL,      # ④ 差异保留
         "左 d %.4f→%.4f (Δ%+.4f) 右 d %.4f→%.4f (Δ%+.4f)；"
         "两侧差值 %.4f→%.4f；s 左=%.4f 右=%.4f"
         % (dl0, dl1, dl1 - dl0, dr0, dr1, dr1 - dr0,
            dl0 - dr0, dl1 - dr1, sl1, sr1))

    step("D2 ★★★ 一体拖动确实**改变了**值（不是恒等但没动）",
         abs(dl1 - dl0) > 1e-3, "Δd(左) = %+.4f" % (dl1 - dl0))

    # D3：方向 —— 上三角往上拖 = 远离关键帧 = 变疏（s 变小）
    o, a = build("_TL_D3")
    write_s(o, FM, 'left', 0.50)
    write_s(o, FM, 'right', 0.50)
    hs = mk_handles(FM, s=0.50)
    drag_pair(o, hs, UP, dy_px=40.0)
    s_up_dir = read_s(o, FM, 'left')
    step("D3 ★★ 往上拖 = 更疏（s 变小；上三角远离关键帧）",
         s_up_dir < 0.50, "0.5 → %.6f" % s_up_dir)

    # D4：往下拖 = **两侧都变密**（s 都变大），且增量仍相等
    o, a = build("_TL_D4")
    write_s(o, FM, 'left', 0.30)
    write_s(o, FM, 'right', 0.45)
    dl4a, dr4a = read_d(o, FM, 'left'), read_d(o, FM, 'right')
    hs = mk_handles(FM, s=0.30)
    drag_pair(o, hs, UP, dy_px=-40.0)
    dl4b, dr4b = read_d(o, FM, 'left'), read_d(o, FM, 'right')
    sl4, sr4 = read_s(o, FM, 'left'), read_s(o, FM, 'right')
    step("D4 ★★ 往下拖 = 两侧**都变密**（s 都变大），增量仍相等",
         None not in (dl4a, dr4a, dl4b, dr4b)
         and sl4 > 0.30 and sr4 > 0.45
         and dl4b < dl4a and dr4b < dr4a
         and abs((dl4b - dl4a) - (dr4b - dr4a)) < _TOL,
         "d 左 %.4f→%.4f 右 %.4f→%.4f；s 左=%.4f 右=%.4f"
         % (dl4a, dl4b, dr4a, dr4b, sl4, sr4))

    # D5：分离态拖动 ⇒ **只改被拖的那一侧**，另一侧纹丝不动
    o, a = build("_TL_D5")
    write_s(o, FM, 'left', 0.50)
    write_s(o, FM, 'right', 0.30)
    xf.set_tri_locked(a, FM, False)
    hs = mk_handles(FM, s=0.50)
    drag_pair(o, hs, UP, dy_px=40.0)
    sl5, sr5 = read_s(o, FM, 'left'), read_s(o, FM, 'right')
    step("D5 ★★★ 分离态拖动 ⇒ **只改被拖的那侧**，对侧原样不动",
         abs(sl5 - 0.50) > 1e-3 and abs(sr5 - 0.30) < 1e-9,
         "左 %.6f（应变化）右 %.6f（应不动）" % (sl5, sr5))

    # D6：两个**不同帧**各自分离时，互不干扰
    o, a = build("_TL_D6")
    write_s(o, FM, 'left', 0.40)
    write_s(o, FM, 'right', 0.40)
    hs6 = mk_handles(FM)
    xf.set_tri_locked(a, FM, False)
    drag_pair(o, hs6, UP, dy_px=40.0)
    step("D6 ★★ 分离态拖动后该帧仍保持分离（状态不被拖动改掉）",
         it.is_frame_locked(o, FM) is False, "")

    # D7 ★★★ 多步拖动 ≡ 单步同位移 —— 防「双重累加」回归
    #   `eff`（`speed_drag_effective_px`）是【累积】位移 ⇒ 拖拽起点必须是
    #   **按下时的固定 d**。若每帧现读"当前值"再加累积位移 ⇒ 越拖漂移越大
    #   （= 用户零容忍的"跳变"）。2026-09-19 实装时真踩过一次，故立此断言。
    o, a = build("_TL_D7a")
    write_s(o, FM, 'left', 0.35)
    write_s(o, FM, 'right', 0.55)
    drag_pair(o, mk_handles(FM), UP, dy_px=60.0, steps_n=1)
    one = (read_d(o, FM, 'left'), read_d(o, FM, 'right'))

    o, a = build("_TL_D7b")
    write_s(o, FM, 'left', 0.35)
    write_s(o, FM, 'right', 0.55)
    drag_pair(o, mk_handles(FM), UP, dy_px=60.0, steps_n=8)
    many = (read_d(o, FM, 'left'), read_d(o, FM, 'right'))

    step("D7 ★★★ **多步拖动 ≡ 单步同位移**"
         "（防\"累积位移 + 当前值\"双重累加 ⇒ 漂移/跳变）",
         None not in one + many
         and abs(one[0] - many[0]) < 1e-3
         and abs(one[1] - many[1]) < 1e-3,
         "1 步 vs 8 步：左 d %.4f / %.4f；右 d %.4f / %.4f"
         % (one[0], many[0], one[1], many[1]))

    # ==================================================== E 组：跨会话持久化
    # 用「同名但不是同一实例」的假 action —— 精确复现"重开文件后的那个对象"：
    #   · 键用 action 名 ⇒ 命中（等价于重开文件）
    #   · 键用内存地址 ⇒ 必然落空
    o, a = build("_TL_E1")
    xf.set_tri_locked(a, FM, False)
    xf.set_tri_locked(a, F0, False)
    xf._TRILOCK.clear()                 # 清内存镜像（模拟"进程重启后内存是空的"）
    xf._trilock_warmed.clear()
    step("E1 ★★★ 清掉内存镜像后（= 重开文件）仍能从 action 恢复",
         it.is_frame_locked(o, FM) is False and it.is_frame_locked(o, F0) is False
         and it.is_frame_locked(o, F1) is True,
         "tokens=%s" % (xf.trilock_tokens(a),))

    class _FakeAct:
        """与真 action **同名**、但**不是同一个实例**（= 重开文件后的那个）。"""
        def __init__(self, name, getter):
            self.name = name
            self._get = getter

        def get(self, k, default=None):
            return self._get(k, default)

        def __contains__(self, k):
            return self._get(k, None) is not None

    fake = _FakeAct(str(a.name), lambda k, d=None: a.get(k, d))
    step("E2 ★★★★ 键的身份是 **action 名**（不是内存地址）—— 用下游假对象验证",
         xf.is_tri_locked(fake, FM) is True or xf.is_tri_locked(fake, FM) is False,
         "键=%r（名字键才能被同名异实例命中）" % (xf._trilock_key_of(fake, FM),))

    # 严谨版：清内存后，用假对象查 —— 内存里没有 ⇒ 走 warm(假对象) ⇒ 从真 action 读 tokens
    xf._TRILOCK.clear()
    xf._trilock_warmed.clear()
    got_fake = xf.is_tri_locked(fake, FM)
    step("E3 ★★★★ 同名异实例（模拟重开文件）能恢复出**分离**状态",
         got_fake is False,
         "假对象查询=%s（键=%r）" % (got_fake, xf._trilock_key_of(fake, FM)))

    # E4：键里**不含内存地址**（地址会让跨会话失效）
    k = xf._trilock_key_of(a, FM)
    step("E4 ★★ 键是 (action 名, 帧号) 两元组、不含指针",
         isinstance(k, tuple) and len(k) == 2 and k[0] == str(a.name)
         and abs(k[1] - FM) < 1e-6, "键=%r" % (k,))

    # ==================================================== F 组：视觉
    step("F1 ★★ 默认色 = **黄色**（用户：默认情况下三角控制柄都是黄色实心）",
         ov.HANDLE_COLOR[0] > 0.8 and ov.HANDLE_COLOR[1] > 0.6
         and ov.HANDLE_COLOR[2] < 0.3,
         "HANDLE_COLOR=%r" % (ov.HANDLE_COLOR,))

    step("F2 ★★ 一体态描边 = **黑色细边**（且与填充色**不同**）",
         ov.HANDLE_OUTLINE_COLOR[0] < 0.2 and ov.HANDLE_OUTLINE_COLOR[1] < 0.2
         and ov.HANDLE_OUTLINE_COLOR[2] < 0.2
         and tuple(ov.HANDLE_OUTLINE_COLOR[:3]) != tuple(ov.HANDLE_COLOR[:3]),
         "outline=%r width=%s" % (ov.HANDLE_OUTLINE_COLOR, ov.HANDLE_OUTLINE_WIDTH))

    _dmax = max(abs(ov.HANDLE_DRAG_COLOR[i] - ov.HANDLE_COLOR[i]) for i in range(3))
    step("F3 ★ 拖拽色与默认黄**明显不同**（默认色改成黄之后的新隐患）",
         _dmax > 0.25,
         "drag=%r default=%r 最大通道差=%.3f" % (ov.HANDLE_DRAG_COLOR, ov.HANDLE_COLOR, _dmax))

    # F4：绘制原语真支持「空心 + 独立描边色」（真调一次，验证不抛）
    try:
        import gpu
        gpu.init()
    except Exception:
        pass
    try:
        ov.draw_triangle_2d(400.0, 300.0, 'down', ov.HANDLE_COLOR, filled=True,
                            outline_color=ov.HANDLE_OUTLINE_COLOR,
                            outline_width=ov.HANDLE_OUTLINE_WIDTH)
        ov.draw_triangle_2d(450.0, 300.0, 'up', ov.HANDLE_COLOR, filled=False,
                            outline_color=ov.HANDLE_COLOR, outline_width=1.6)
        _f4 = True
        _f4d = "两种调用都不抛"
    except Exception as e:
        _f4, _f4d = False, str(e)[:200]
    step("F4 ★★ 绘制原语支持 filled=False（空心）+ 独立描边色", _f4, _f4d)

    # F5：overlay 真按 split_frames 分流（真调 set_handles + 读回内部状态）
    o, a = build("_TL_F5")
    hs = mk_handles(FM)
    xf.set_tri_locked(a, FM, False)
    sysmod = ov.get_overlay()
    sysmod.set_handles(hs, [], dragging=False,
                       split_frames=it.make_split_frames(o, hs))
    step("F5 ★★★ split_frames 真的传到了 overlay（分离帧被标出）",
         round(FM, 4) in sysmod._split_frames,
         "split_frames=%s（该帧锁定=%s）"
         % (sysmod._split_frames, it.is_frame_locked(o, FM)))

    sysmod.set_handles(hs, [], dragging=False,
                       split_frames=it.make_split_frames(o, hs))
    xf.set_tri_locked(a, FM, True)
    sysmod.set_handles(hs, [], dragging=False,
                       split_frames=it.make_split_frames(o, hs))
    step("F6 ★★★ 锁回一体后**不再**算作分离帧（空心回实心）",
         round(FM, 4) not in sysmod._split_frames,
         "split_frames=%s" % (sysmod._split_frames,))

    # ==================================================== G 组：静态契约
    src = open(os.path.join(REPO, "interaction.py"), encoding="utf-8").read()
    # ⚠️ 锚点用【语义稳定点】：三角处理段的第一行。
    # 别锚定具体的命中调用（裸 hd.hit_test 会被重构掉）。
    i_modal = src.find("hit_tri = _triangle_under_cursor(s_handles, local_mouse_pos)")
    _seg = src[i_modal:i_modal + 2500] if i_modal > 0 else ""
    step("G1 ★★★ modal 里在【选中/拖拽之前】接的是 `try_toggle_tri_lock_click`",
         i_modal > 0 and "try_toggle_tri_lock_click(" in _seg, "")

    step("G2 ★★ modal 里走的是 `apply_speed_click_selection`（真入口，非内联复刻）",
         "apply_speed_click_selection(" in _seg, "")

    # G3：锁定判据**唯一**（全仓只有 transform_domain 定义、interaction 只是转发）
    def _defs(name):
        hits = []
        for fn in os.listdir(REPO):
            if not fn.endswith(".py"):
                continue
            s = open(os.path.join(REPO, fn), encoding="utf-8").read()
            for ln in s.splitlines():
                if ln.strip().startswith("def ") and name in ln:
                    hits.append(fn)
        return hits
    d_is = _defs("is_tri_locked")
    d_set = _defs("set_tri_locked")
    step("G3 ★★★ 锁定判据**唯一**（is_tri_locked / set_tri_locked 只在 transform_domain 定义）",
         d_is == ["transform_domain.py"] and d_set == ["transform_domain.py"],
         "is=%s set=%s" % (d_is, d_set))

    # G4：唯一键（set / clear / query 都走 _trilock_key_of）
    td_src = open(os.path.join(REPO, "transform_domain.py"), encoding="utf-8").read()
    n_keyof = td_src.count("_trilock_key_of(")
    step("G4 ★★★ 键只有**一个来源** `_trilock_key_of`（def + 查询 + 写入 = 3）",
         n_keyof >= 3, "调用/定义处=%d" % n_keyof)

    # G5：ModalSession 也接了一体语义（G/R/S 模态路径）
    # ★ 2026-09-19：语义已改成「统一方向 + 各按自己的 s 起算」——
    #   旧的 `td.group_drag_s`（写同一个 s）被用户推翻。
    me_src = open(os.path.join(REPO, "modal_edit.py"), encoding="utf-8").read()
    step("G5 ★★★ 模态（G/R/S）路径也走**同一**一体语义"
         "（统一方向 + 各按自己的 s，否则两路手感不一致）",
         "group_s_base" in me_src and "_group_delta" in me_src
         and "s_to_d_unclamped" in me_src, "")

    # ==================================================== H 组：bug 注入
    def _scen_pair():
        """一体态单击 ⇒ 两个都选中。"""
        reset_state(o)
        _hs = mk_handles(FM)
        lp, _ = it.apply_speed_click_selection(o, _hs, hd.find_handle(_hs, FM, UP))
        return lp is True and _session.is_locked_pair_selected(FM)

    def _scen_delta_kept():
        """★ 2026-09-19 新语义：一体拖动 ⇒ 两侧**各加减同一增量**，差异保留。"""
        _o, _a = build("_TL_H1")
        write_s(_o, FM, 'left', 0.50)
        write_s(_o, FM, 'right', 0.30)          # ★ 故意不同，才谈得上"保留差异"
        _dl0, _dr0 = read_d(_o, FM, 'left'), read_d(_o, FM, 'right')
        _hs = mk_handles(FM, s=0.50)
        drag_pair(_o, _hs, UP, dy_px=40.0)
        _dl1, _dr1 = read_d(_o, FM, 'left'), read_d(_o, FM, 'right')
        if None in (_dl0, _dr0, _dl1, _dr1):
            return False
        return (abs((_dl1 - _dl0) - (_dr1 - _dr0)) < 1e-4        # 增量相等（float32 容差）
                and abs(_dl1 - _dl0) > 1e-3                      # 确实动了
                and abs((_dl1 - _dr1) - (_dl0 - _dr0)) < 1e-4)   # 差异保留

    def _scen_split_only():
        """分离态拖动 ⇒ 对侧不动。"""
        _o, _a = build("_TL_H2")
        write_s(_o, FM, 'left', 0.50)
        write_s(_o, FM, 'right', 0.30)
        xf.set_tri_locked(_a, FM, False)
        _hs = mk_handles(FM, s=0.50)
        drag_pair(_o, _hs, UP, dy_px=40.0)
        return abs(read_s(_o, FM, 'right') - 0.30) < 1e-9

    def _scen_default_locked():
        """默认（无记录）= 一体。"""
        _o, _a = build("_TL_H3")
        try:
            xf.clear_tri_lock(_a)
        except Exception:
            pass
        return it.is_frame_locked(_o, FM) is True

    def _scen_persist():
        """清内存后仍能恢复。"""
        _o, _a = build("_TL_H4")
        xf.set_tri_locked(_a, FM, False)
        xf._TRILOCK.clear()
        xf._trilock_warmed.clear()
        return it.is_frame_locked(_o, FM) is False

    base = (_scen_pair(), _scen_delta_kept(), _scen_split_only(),
            _scen_default_locked(), _scen_persist())
    step("H0 基线：5 个场景在未注入时全部通过（否则注入实验无意义）",
         all(base), "pair/delta_kept/split/default/persist = %s" % (base,))

    # I1：一体态单击退化成"只选单边"（= 回到旧行为）
    def _mk_single():
        _orig = it.apply_speed_click_selection

        def patched(obj, s_handles, hit_tri, shift=False):
            tris = it._tris_present_for_frame(s_handles, hit_tri['frame'])
            _session.set_single_speed_handle(hit_tri['frame'], hit_tri['tri'])
            return (False, tris)
        return (lambda: setattr(it, "apply_speed_click_selection", patched),
                lambda: setattr(it, "apply_speed_click_selection", _orig),
                "I1 ★一体态单击退化成只选单边 ⇒ 配对检查应抓")

    # I2：一体拖动退回**旧语义**（两侧写同一个 s）⇒ 差异被抹平，应被抓
    #
    # ★ 2026-09-19：注入目标变了 —— 旧版注入的是"各按自己 d0 起算"，
    #   而**那正是现在要的正确行为**（用户 2026-09-19 拍板）。
    #   现在要注入的是**旧语义**（两侧同值）。
    def _mk_same_s():
        """I2：把"各按自己的 s 起算"打掉 ⇒ 退回**旧语义**（两侧写同一个 d/s）。

        ⚠️ 真注入：强制两侧都写"第一次算出的那个 d" ⇒ 两侧必然同值
           ⇒ D1/H1 的"差异保留"判据必然失败（抓得住）。
        """
        _orig = it._apply_speed_d
        _first = {"d": None}

        def bad(context, obj, frame, side, d):
            if _first["d"] is None:
                _first["d"] = float(d)
            return _orig(context, obj, frame, side, _first["d"])

        def _do():
            _first["d"] = None
            it._apply_speed_d = bad
        return (_do,
                lambda: setattr(it, "_apply_speed_d", _orig),
                "I2 ★一体拖动退回旧语义（两侧写同值）⇒ 差异保留检查应抓")

    # I3：默认值翻转（未记录 ⇒ 分离）
    def _mk_default_split():
        _orig = xf.is_tri_locked

        def bad(action, frame):
            k = xf._trilock_key_of(action, frame)
            v = xf._TRILOCK.get(k) if k else None
            return (bool(v) if v is not None else False)
        return (lambda: setattr(xf, "is_tri_locked", bad),
                lambda: setattr(xf, "is_tri_locked", _orig),
                "I3 ★默认翻成「分离」⇒ 默认一体检查应抓")

    # I4：分离态拖动波及对侧
    def _mk_leak():
        _orig = it._apply_speed_from_drag

        def bad(context, obj, mouse_pos):
            r = _orig(context, obj, mouse_pos)
            # 拖动后再给对侧写一个值 ⇒ 分离的"单边"语义被破坏
            try:
                write_s(obj, FM, 'right', 0.99)
            except Exception:
                pass
            return r
        return (lambda: setattr(it, "_apply_speed_from_drag", bad),
                lambda: setattr(it, "_apply_speed_from_drag", _orig),
                "I4 ★分离态拖动波及对侧 ⇒ 单边检查应抓")

    # I5：持久化键改成内存地址 ⇒ 跨会话失效
    def _mk_ptr_key():
        _orig = xf._trilock_key_of

        def bad(action, frame):
            return (str(id(action)), round(float(frame), 4))
        return (lambda: setattr(xf, "_trilock_key_of", bad),
                lambda: setattr(xf, "_trilock_key_of", _orig),
                "I5 ★持久化键换成内存地址 ⇒ 跨会话恢复检查应抓")

    # I6：锁回一体时【不】对齐 GE 手柄（把对齐函数打桩成"什么都不做"）
    #      ⚠️ 注入必须打在【产品真正调用的函数】上（`_align_opposite_speed`）。
    #      旧版注入的是 `_copy_speed_value` —— 而 2026-09-18 起产品已改走
    #      对齐路径，那个注入会**打在空气上**（假阳性：测试"抓住"了，
    #      其实产品根本没执行被注入的代码）。
    def _mk_no_align():
        _orig = it._align_opposite_speed

        def bad(context, obj, frame, tri):
            return (True, {"dt": 0.0, "s": None, "same_sign": True, "clamped": False}, None)
        return (lambda: setattr(it, "_align_opposite_speed", bad),
                lambda: setattr(it, "_align_opposite_speed", _orig),
                "I6 ★锁回一体时【不】对齐 GE 手柄 ⇒ 共线检查应抓")

    def _scen_c3():
        # ★ 判据改成【独立共线残差】—— 对着"用户要的效果"写，不是对着实现写
        _o, _a = build("_TL_H5")
        write_s(_o, FM, 'left', 0.55)
        write_s(_o, FM, 'right', 0.20)
        xf.set_tri_locked(_a, FM, False)
        _hs = mk_handles(FM)
        _pos = center(_hs, FM, UP)
        reset_state(_o)
        it.try_toggle_tri_lock_click(bpy.context, _o, _hs, _pos)
        ok, _ = it.try_toggle_tri_lock_click(bpy.context, _o, _hs, _pos)
        return (ok is True and ge_ok(_o, FM))

    for mk, chk in ((_mk_single, _scen_pair),
                    (_mk_same_s, _scen_delta_kept),
                    (_mk_default_split, _scen_default_locked),
                    (_mk_leak, _scen_split_only),
                    (_mk_ptr_key, _scen_persist),
                    (_mk_no_align, _scen_c3)):
        do, undo, label = mk()
        try:
            do()
            # ★ 自检：注入是否【真的改变了产品行为】—— 防"打在空气上"的假阳性。
            #   若注入后被测场景结果与基线完全一致，说明根本没打中。
            injected = chk()
            undo()            # 先还原，避免影响下一项
            baseline = chk()
            caught = not injected and baseline
            if not injected and not baseline:
                label += "（⚠️ 基线本身就失败，无法判断）"
            elif injected and not baseline:
                label += "（⚠️ 注入反而让结果变好？可疑）"
            elif injected:
                label += "（⚠️ 注入未生效 = 打在空气上）"
        except Exception:
            caught = True
            label += "（异常也算抓住）"
            try:
                undo()
            except Exception:
                pass
        step("★ %s ⇒ 测试抓住" % label, caught, "")

except Exception:
    step("EXCEPTION", False, traceback.format_exc()[-1500:])
finally:
    try:
        _session.clear_speed_handle()
        _session.speed_click_info = None
    except Exception:
        pass

try:
    for n in ("_TL_A", "_TL_C1", "_TL_C5", "_TL_C6", "_TL_D1", "_TL_D3",
              "_TL_D4", "_TL_D5", "_TL_D6", "_TL_E1", "_TL_F5",
              "_TL_H1", "_TL_H2", "_TL_H3", "_TL_H4", "_TL_H5"):
        x = bpy.data.objects.get(n)
        if x:
            bpy.data.objects.remove(x, do_unlink=True)
except Exception:
    pass

flush()
fails = [s for s in steps if not s["ok"]]
print("=" * 72)
for s in steps:
    print("%s %s%s" % ("PASS" if s["ok"] else "FAIL", s["name"],
                       ("  | " + s["detail"]) if s["detail"] else ""))
print("=" * 72)
print("总计 %d 项 | PASS %d | FAIL %d | %s"
      % (len(steps), len(steps) - len(fails), len(fails),
         "ALL PASS" if not fails else "HAS FAILURES"))
sys.exit(1 if fails else 0)
