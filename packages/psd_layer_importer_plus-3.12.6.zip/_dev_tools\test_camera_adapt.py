"""相机适配（视差锁定）自测：核心数学 + 独立投影验证。

在 Blender 后台进程运行：
    blender --background --factory-startup --python test_camera_adapt.py

验证目标（用户需求）：
  锁定状态下移动相机 → 整叠图层按各自深度适配 ⇒
    · 横移  → 画面【滚动】到长图其它位置，构图保持
    · 推拉  → 画面【整体缩放】，各层比例一致（无视差）
    · 旋转  → 各层【跟随相机】转，构图保持
    · 变焦  → 画面【保持不变】（距离按焦距同比补偿）

判据：所有层的屏幕位移必须**一致**（dispread≈0）—— 这就是"构图保持"的充要条件。
      对照组（不调用适配）应当**不一致**（视差），否则说明测试本身没测到东西。

⚠️ 投影用 Blender 自带的 bpy_extras.object_utils.world_to_camera_view，
   不用插件自己的 world_to_screen_coords —— 避免"自己验证自己"。
"""
import sys
import os
import math

_HERE = os.path.dirname(os.path.abspath(__file__))     # _dev_tools
_PKG = os.path.dirname(_HERE)                          # psd_layer_importer_plus
ADDONS = os.path.dirname(_PKG)                         # addons
sys.path.insert(0, ADDONS)

import bpy
import mathutils
from bpy_extras.object_utils import world_to_camera_view

from psd_layer_importer_plus import parallax_utils as P
from psd_layer_importer_plus.constants import ATTR_LAYER_ID, ATTR_INITIAL_TRANSFORM

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("[%s] %-42s %s" % ("PASS" if ok else "FAIL", name, detail))


# ────────────────────────── 场景 ──────────────────────────
LAYER_SPECS = [
    # (z, 尺寸, 中心 xy)  —— 从相机看：彼此错开、屏幕尺寸一致（size/depth 相同）
    (-6.0, 1.0, (-0.5, 0.2)),
    (-9.0, 1.5, (0.0, 0.0)),
    (-12.0, 2.0, (0.6, -0.3)),
]


def add_plane(name, size, loc):
    """手工建方形平面（顶点 ±0.5），不依赖 bpy.ops —— 后台模式更稳。"""
    mesh = bpy.data.meshes.new(name)
    h = 0.5
    mesh.from_pydata(
        [(-h, -h, 0.0), (h, -h, 0.0), (h, h, 0.0), (-h, h, 0.0)],
        [],
        [(0, 1, 2, 3)],
    )
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    obj.scale = (size, size, 1.0)
    obj.location = loc
    return obj


def build_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080

    cam_data = bpy.data.cameras.new("Cam")
    cam = bpy.data.objects.new("Cam", cam_data)
    cam.location = (0.0, 0.0, 0.0)
    cam.rotation_euler = (0.0, 0.0, 0.0)          # 朝 -Z
    cam_data.lens = 50.0
    scene.collection.objects.link(cam)
    scene.camera = cam

    coll = bpy.data.collections.new("PSDLayers")
    scene.collection.children.link(coll)

    layers = []
    for i, (z, size, loc) in enumerate(LAYER_SPECS):
        obj = add_plane("Layer_%d" % i, size, (loc[0], loc[1], z))
        obj[ATTR_LAYER_ID] = "layer_%d" % i
        coll.objects.link(obj)
        layers.append(obj)

    bpy.context.view_layer.update()
    return scene, cam, coll, layers


def set_cam(cam, loc=(0.0, 0.0, 0.0), rot_y_deg=0.0, rot_x_deg=0.0, lens=50.0):
    cam.location = loc
    cam.rotation_euler = (math.radians(rot_x_deg), math.radians(rot_y_deg), 0.0)
    cam.data.lens = lens
    bpy.context.view_layer.update()


def measure(scene, cam, layers):
    """各层的 [屏幕x, 屏幕y, 屏幕宽]，全部走 Blender 官方投影。"""
    out = []
    for obj in layers:
        mw = obj.matrix_world
        center = mathutils.Vector((0.0, 0.0, 0.0))
        for corner in obj.bound_box:
            center += mw @ mathutils.Vector(corner)
        center /= 8.0
        co = world_to_camera_view(scene, cam, center)
        p0 = world_to_camera_view(scene, cam, mw @ mathutils.Vector((-0.5, -0.5, 0.0)))
        p1 = world_to_camera_view(scene, cam, mw @ mathutils.Vector((0.5, -0.5, 0.0)))
        out.append((co.x, co.y, abs(p1.x - p0.x)))
    return out


def spread(vals):
    return max(vals) - min(vals)


def cam_space_normals(scene, cam, layers):
    """各层法线在【相机空间】的方向 —— 判据：相机转，图层要【相对相机】不转。

    图层始终正对相机时，这个值应当恒定不变（不随相机旋转而变）。
    """
    view = P.get_camera_view_matrix(cam)
    inv = view.to_3x3().inverted()
    out = []
    for o in layers:
        world_n = o.matrix_world.to_quaternion() @ mathutils.Vector((0.0, 0.0, 1.0))
        out.append(inv @ world_n)
    return out


def similarity_ratios(before, after):
    """各层【两两屏幕距离】的比值。

    ★ 这是"整体是相似变换（平移+均匀缩放）= 无视差"的判据：
      · 纯横移 / 旋转 → 比值全 = 1（各层相对位置不变）
      · 推拉          → 比值全 = 同一个数（各层一起缩放、无相对错位）
    ⚠️ 别拿"屏幕位移一致"当推拉的判据 —— 各层错开时，整体缩放**必然**让位移各不相同
       （离画面中心远的层移动更多），那是对的，不是 bug（我第一版就栽在这）。
    """
    ratios = []
    for i in range(len(before)):
        for j in range(i + 1, len(before)):
            b = math.hypot(before[i][0] - before[j][0], before[i][1] - before[j][1])
            a = math.hypot(after[i][0] - after[j][0], after[i][1] - after[j][1])
            if b > 1e-9:
                ratios.append(a / b)
    return ratios


def run_case(scene, cam, layers, ref_depth, name, setup, adapt=True, tol=1e-5):
    """复位 → 取基线 → 改相机 → （可选）适配 → 取结果。"""
    set_cam(cam)                                   # 相机回锁定位置
    for o in layers:
        P.apply_camera_adapt_to_obj(o, cam, ref_depth)   # 图层回锁定位置
    bpy.context.view_layer.update()
    base = measure(scene, cam, layers)

    setup(cam)                                     # 施加目标相机变化
    bpy.context.view_layer.update()
    if adapt:
        for o in layers:
            P.apply_camera_adapt_to_obj(o, cam, ref_depth)
        bpy.context.view_layer.update()
    after = measure(scene, cam, layers)

    dx = [a[0] - b[0] for a, b in zip(after, base)]
    dy = [a[1] - b[1] for a, b in zip(after, base)]
    w_ratio = [a[2] / b[2] for a, b in zip(after, base)]
    ratios = similarity_ratios(base, after)
    return {
        "name": name, "dx": dx, "dy": dy, "w_ratio": w_ratio, "ratios": ratios,
        "spread_xy": max(spread(dx), spread(dy)),
        "spread_ratio": spread(ratios) if ratios else 0.0,
        "ratio_mean": sum(ratios) / len(ratios) if ratios else 1.0,
        "spread_w": spread(w_ratio) if adapt else None,
    }


def _feel_diagnostic(scene, cam, layers):
    """手感诊断：相机横移 1.0 时，各层的屏幕位移（px）。

    这是"飞不飞"的直接量化：位移越大越"飞"。
    对比三种基准取法（最深 = 原实现 / 中间 = 新实现 / 最浅）。
    """
    set_cam(cam)
    ref_any = P.get_parallax_reference_depth(layers)
    for o in layers:
        P.apply_camera_adapt_to_obj(o, cam, ref_any)
    bpy.context.view_layer.update()
    base = measure(scene, cam, layers)

    depths = sorted(o["locked_depth"] for o in layers)
    strats = [("最深(=当前实现)", P.get_parallax_reference_depth(layers)),
              ("中位", depths[len(depths) // 2]),
              ("最浅", depths[0])]

    print("\n### 手感诊断：相机横移 1.0，各层屏幕位移")
    print("###   各层深度 = %s" % [round(d, 2) for d in depths])
    for label, ref in strats:
        set_cam(cam)
        for o in layers:
            P.apply_camera_adapt_to_obj(o, cam, ref)
        bpy.context.view_layer.update()
        set_cam(cam, loc=(1.0, 0.0, 0.0))
        for o in layers:
            P.apply_camera_adapt_to_obj(o, cam, ref)
        bpy.context.view_layer.update()
        after = measure(scene, cam, layers)
        dx = [(a[0] - b[0]) * scene.render.resolution_x for a, b in zip(after, base)]
        print("###   %-14s 基准=%6.2f  每层: %-26s 最大=%.0f px"
              % (label, ref, " ".join("%+.0f" % v for v in dx),
                 max(abs(v) for v in dx)))

    # 滚动系数（PARALLAX_CAMERA_SCROLL_SCALE）对滚速的影响
    ref = P.get_parallax_reference_depth(layers)
    saved = P.PARALLAX_CAMERA_SCROLL_SCALE
    print("###   滚动系数 scale（1.0=标准；越小画面滚得越慢）:")
    try:
        for scale in (1.0, 0.5, 0.25):
            P.PARALLAX_CAMERA_SCROLL_SCALE = scale
            set_cam(cam)
            for o in layers:
                P.apply_camera_adapt_to_obj(o, cam, ref)
            bpy.context.view_layer.update()
            b0 = measure(scene, cam, layers)
            set_cam(cam, loc=(1.0, 0.0, 0.0))
            for o in layers:
                P.apply_camera_adapt_to_obj(o, cam, ref)
            bpy.context.view_layer.update()
            b1 = measure(scene, cam, layers)
            dx = [(a[0] - b[0]) * scene.render.resolution_x for a, b in zip(b1, b0)]
            print("###     scale=%.2f  →  每层 %-22s 最大=%.0f px"
                  % (scale, " ".join("%+.0f" % v for v in dx),
                     max(abs(v) for v in dx)))
    finally:
        P.PARALLAX_CAMERA_SCROLL_SCALE = saved
        set_cam(cam)


def _orientation_test():
    """朝向：相机旋转时，图层要【跟着一起转】（保持相对相机的朝向不变）。

    网页 demo 里是 L.rot = R · d.lr —— 插件最初只设了 location/scale、漏了 rotation，
    导致"位置跟了、朝向没跟"（用户实测反馈）。
    """
    scene, cam, coll, layers = build_scene()
    P.record_parallax_lock_state(coll, cam)
    ref_depth = P.get_parallax_reference_depth(layers)

    base_n = cam_space_normals(scene, cam, layers)
    base_screen = measure(scene, cam, layers)

    # ── 只旋转相机 ──
    set_cam(cam, rot_y_deg=30.0, rot_x_deg=10.0)
    for o in layers:
        P.apply_camera_adapt_to_obj(o, cam, ref_depth)
    bpy.context.view_layer.update()
    after_n = cam_space_normals(scene, cam, layers)

    dmax = max((a - b).length for a, b in zip(base_n, after_n))
    check("9.1 旋转相机 → 图层在【相机空间】的朝向不变（跟随旋转）",
          dmax < 1e-5, "最大朝向偏差=%.2e" % dmax)

    # 朝向确实变了（否则说明根本没转，测试自身要能分辨）
    view_now = P.get_camera_view_matrix(cam).to_3x3()
    world_n = layers[0].matrix_world.to_quaternion() @ mathutils.Vector((0.0, 0.0, 1.0))
    check("9.2 图层的【世界】朝向确实跟着转了",
          (world_n - mathutils.Vector((0.0, 0.0, 1.0))).length > 0.1,
          "世界法线=%s" % [round(v, 3) for v in world_n])

    # 构图仍保持（旋转不位移屏幕内容）
    after_screen = measure(scene, cam, layers)
    ratios = similarity_ratios(base_screen, after_screen)
    check("9.3 旋转时构图仍保持", ratios and spread(ratios) < 1e-5,
          "间距比=%s" % [round(v, 6) for v in ratios])

    # ── 旋转 + 横移：朝向仍应保持不变，构图保持 ──
    set_cam(cam, loc=(1.2, 0.0, 0.0), rot_y_deg=25.0)
    for o in layers:
        P.apply_camera_adapt_to_obj(o, cam, ref_depth)
    bpy.context.view_layer.update()
    after_n2 = cam_space_normals(scene, cam, layers)
    dmax2 = max((a - b).length for a, b in zip(base_n, after_n2))
    check("9.4 旋转+横移 → 朝向仍保持", dmax2 < 1e-5, "最大偏差=%.2e" % dmax2)


def _drag_after_rotate_test():
    """回归：相机转过之后，再【拖图层】应仍保持锁定时的屏幕坐标（原有语义）。

    引入"朝向跟随"后，图层朝向会随相机转过 ⇒ center_offset（世界偏移）也得跟着转。
    ② 分支若仍用原始 center_offset，图层会被放到偏离屏幕目标的位置。
    ⚠️ 必须让图层几何中心【偏离原点】(center_offset≠0) 才测得出这个偏差。
    ⚠️ 必须走【注册插件 + file_record + handler】的真实入口 —— 否则 scene.psd_import_tool
       不存在，handler 会抛异常并被静默吞掉（测试就测了个寂寞，踩过一次）。
    """
    import psd_layer_importer_plus as addon

    addon.register()
    try:
        scene, cam, coll, layers = build_scene()
        coll.name = "test_drag"
        rec = scene.psd_import_tool.file_records.add()
        rec.filepath = os.path.join(_HERE, "test_drag.psd")
        rec.collection = coll
        rec.parallax_maybe_locked = True
        _drag_after_rotate_body(scene, cam, coll, layers)
    finally:
        try:
            addon.unregister()
        except Exception:                                     # noqa: BLE001
            pass


def _drag_after_rotate_body(scene, cam, coll, layers):
    # 让 0 号层的几何中心偏离对象原点 —— 否则 center_offset=0，测不出问题
    me = layers[0].data
    for v in me.vertices:
        v.co.x += 0.30
        v.co.y += 0.20
    me.update()
    bpy.context.view_layer.update()

    P.record_parallax_lock_state(coll, cam)
    # ⚠️ 锁定后必须重设账本（真实插件的"锁定"操作符会做：rec.parallax_maybe_locked =
    #    psd_has_locked_layers(rec)）。因为自愈机制在"尚未锁定"时会把账本清零，
    #    不重设的话 handler 永远走 O(1) 短路 —— 相机适配完全不生效。
    for _r in scene.psd_import_tool.file_records:
        _r.parallax_maybe_locked = True
    ref = P.get_parallax_reference_depth(layers)
    off0 = mathutils.Vector(layers[0]["center_offset"])
    check("11.0 前置：0 号层 center_offset ≠ 0", off0.length > 0.1,
          "center_offset=%s" % [round(v, 3) for v in off0])
    locked_cam_m = P.get_camera_view_matrix(cam)      # 此刻相机 == 锁定相机

    # 相机旋转并适配 → 图层朝向被转过
    # ⚠️ 必须同步更新"上次适配锚点"（handler 走完 ① 会做这件事）。否则下一步 handler
    #    仍判定"相机变了"、继续走 ① 分支，② 分支根本没机会执行，测试就测了个寂寞。
    set_cam(cam, rot_y_deg=30.0)
    for o in layers:
        P.apply_camera_adapt_to_obj(o, cam, ref)
        o["last_camera_matrix"] = [
            list(row) for row in P.get_camera_view_matrix(cam)
        ]
        o["last_camera_focal"] = cam.data.lens
    bpy.context.view_layer.update()

    # 模拟用户拖动该层（改位置，并把 last_location 设成旧值让 handler 认定"变了"）
    obj = layers[0]
    for o in layers:
        o.select_set(o is obj)
    dragged_from = obj.location.copy()
    obj["last_location"] = list(dragged_from)
    obj["last_scale"] = list(obj.scale)
    obj.location = dragged_from + mathutils.Vector((0.25, 0.15, 0.05))
    bpy.context.view_layer.update()

    P.parallax_scene_update_handler(scene)
    bpy.context.view_layer.update()

    center = P.get_object_center_world_pos(obj)
    # ⚠️ 判据必须用【锁定时的相机矩阵】：② 分支的语义是保持"锁定视角下的屏幕坐标"。
    #    用当前相机测会把自己绕晕 —— 相机已转 30°，同一世界点在新视角下屏幕坐标本就不同。
    cs = locked_cam_m.inverted() @ center
    depth_l = max(abs(cs.z), 1e-9)
    sx = cs.x * obj["locked_camera_focal_length"] / (depth_l * obj["locked_camera_sensor_width"])
    sy = cs.y * obj["locked_camera_focal_length"] / (depth_l * obj["locked_camera_sensor_height"])
    ex, ey = abs(sx - obj["locked_screen_x"]), abs(sy - obj["locked_screen_y"])
    # ② 分支确实执行了（写 last_plugin_location 是它的副作用）—— 否则本测试没测到东西
    check("11.1 ② 分支确实被执行（测试有效性）",
          "last_plugin_location" in obj)
    check("11.2 旋转后拖图层 → 锁定视角下屏幕坐标仍保持（未偏）",
          ex < 1e-4 and ey < 1e-4,
          "偏差 dx=%.2e dy=%.2e" % (ex, ey))


def _zoom_trigger_test():
    """变焦：只改 lens（不动 matrix_world），也必须被判定为「相机变了」并适配。

    最初 camera_changed_since_last_adapt 只比 matrix_world ⇒ 变焦整个漏掉
    （handler 一行不执行 ⇒ 画面自然放大，用户实测反馈"变焦和网页不一样"）。
    """
    scene, cam, coll, layers = build_scene()
    P.record_parallax_lock_state(coll, cam)
    ref_depth = P.get_parallax_reference_depth(layers)
    base = measure(scene, cam, layers)

    set_cam(cam, lens=85.0)
    check("10.1 只改焦距 → 判定为「相机变了」",
          all(P.camera_changed_since_last_adapt(o, cam) for o in layers))

    for o in layers:
        P.apply_camera_adapt_to_obj(o, cam, ref_depth)
    bpy.context.view_layer.update()
    after = measure(scene, cam, layers)
    dmax = max(max(abs(a[0] - b[0]), abs(a[1] - b[1]))
               for a, b in zip(after, base))
    wdiff = max(abs(a[2] / b[2] - 1.0) for a, b in zip(after, base))
    check("10.2 变焦 → 屏幕位置不变（视图不变）", dmax < 1e-5, "最大位置偏差=%.2e" % dmax)
    check("10.3 变焦 → 屏幕尺寸不变", wdiff < 1e-4, "最大尺寸偏差=%.2e" % wdiff)

    # 锚点写回后再判：不应再算"变过"（幂等）
    for o in layers:
        o["last_camera_focal"] = cam.data.lens
    check("10.4 写完锚点后不再判为「变过」（幂等）",
          not any(P.camera_changed_since_last_adapt(o, cam) for o in layers))


def _initial_transform_invariance_test():
    """★ 视差锁定全程【不得影响】 initial_transform（PSD 原始相对位置记录）。

    用户诉求：插件应有一份稳定的"PSD 原始相对位置"信息，
    任何操作（手改位置 / 视差锁定 / 相机适配 / 解锁 / 匹配至相机）都不该破坏它。

    实测覆盖：手改位置 → 锁定 → 移相机适配 → 旋转适配 → 变焦适配 → 解锁。
    """
    import copy

    scene, cam, coll, layers = build_scene()
    for i, o in enumerate(layers):
        o[ATTR_INITIAL_TRANSFORM] = {
            "location": [-0.5 + i * 0.5, 0.2 - i * 0.2, i * 0.01],
            "scale": [1.0, 1.0, 1.0],
            "rotation": [0.0, 0.0, 0.0],
        }
    # ⚠️ 不能用 copy.deepcopy —— Blender 的 IDPropertyArray 不可 pickle
    _K = ("location", "scale", "rotation")
    snap = {o.name: {k: [float(x) for x in o[ATTR_INITIAL_TRANSFORM][k]] for k in _K}
            for o in layers}
    loc0 = {o.name: o.location.copy() for o in layers}

    # ① 用户手改位置
    for o in layers:
        o.location = o.location + mathutils.Vector((3.0, -2.0, 0.5))
    bpy.context.view_layer.update()

    # ② 视差锁定 + ③ 相机适配（移 / 转 / 变焦）
    P.record_parallax_lock_state(coll, cam)
    ref = P.get_parallax_reference_depth(layers)
    for loc, rot_y, lens in [((1.5, 0.0, 0.0), 0.0, 50.0),
                             ((1.5, 0.0, 0.0), 25.0, 50.0),
                             ((1.5, 0.0, 0.0), 25.0, 85.0)]:
        set_cam(cam, loc=loc, rot_y_deg=rot_y, lens=lens)
        for o in layers:
            P.apply_camera_adapt_to_obj(o, cam, ref)
        bpy.context.view_layer.update()

    # ④ 解锁
    P.restore_parallax_lock_state(coll)
    bpy.context.view_layer.update()

    # ── 比对 initial_transform ──
    diffs = []
    for o in layers:
        now = o[ATTR_INITIAL_TRANSFORM]
        old = snap[o.name]
        for k in ("location", "scale", "rotation"):
            a, b = list(now[k]), list(old[k])
            diffs.append(max(abs(x - y) for x, y in zip(a, b)))
    check("12.1 全程后 initial_transform 完全未变（原始构图记录稳定）",
          max(diffs) < 1e-9, "最大差异=%.2e" % max(diffs))

    moved = [o for o in layers if (o.location - loc0[o.name]).length > 1e-3]
    check("12.2 反证：图层位置确实被改过（说明流程没空转）",
          len(moved) == len(layers),
          "被改动的层=%d/%d" % (len(moved), len(layers)))

    check("12.3 解锁后 initial_transform 仍在（可继续用作构图基准）",
          all(ATTR_INITIAL_TRANSFORM in o for o in layers))

    # ⑤「匹配至相机也不改 initial_transform」在 test_match_camera.py 里测（那边有真 PSD）


def _stale_lock_test():
    """回归：老工程锁定记录缺 `locked_world_rotation`（本版新增属性）时不能崩。

    实测事故（review 发现）：早于本版锁定的 .blend 里没有该属性 → apply 下标读取
    KeyError → 被 handler except 吞掉 → 该层**永不适配**，且 PSD_DEBUG 打开时每帧重抛刷屏。
    修法：缺失时用「当前朝向」兜底并**补写**（自愈，下次不再走兜底）。
    """
    scene, cam, coll, layers = build_scene()
    P.record_parallax_lock_state(coll, cam)
    ref = P.get_parallax_reference_depth(layers)

    for o in layers:
        del o["locked_world_rotation"]
    check("13.0 前置：属性已删除（模拟老工程锁定记录）",
          all("locked_world_rotation" not in o for o in layers))

    base_n = cam_space_normals(scene, cam, layers)
    set_cam(cam, rot_y_deg=30.0)

    err = None
    try:
        for o in layers:
            P.apply_camera_adapt_to_obj(o, cam, ref)
        bpy.context.view_layer.update()
    except Exception as e:                                    # noqa: BLE001
        err = e
    check("13.1 缺 locked_world_rotation 时 apply 不抛异常", err is None, repr(err))
    check("13.2 属性被兜底补写（自愈）",
          all("locked_world_rotation" in o for o in layers))

    after_n = cam_space_normals(scene, cam, layers)
    dmax = max((a - b).length for a, b in zip(base_n, after_n))
    check("13.3 朝向仍正确跟随（相机空间法线不变）", dmax < 1e-5, "最大偏差=%.2e" % dmax)

    # handler 级：老工程记录下也不能每帧抛异常（修前 handler 每帧 KeyError 被吞）
    for o in layers:
        del o["locked_world_rotation"]
    set_cam(cam, rot_y_deg=0.0)
    bpy.context.view_layer.update()
    ok = True
    try:
        for k in range(5):
            cam.rotation_euler = (0.0, math.radians(5.0 * (k + 1)), 0.0)
            bpy.context.view_layer.update()
            P.parallax_scene_update_handler(scene)
    except Exception as e:                                    # noqa: BLE001
        ok = False
        print("   handler 抛异常:", repr(e))
    check("13.4 handler 连跑 5 帧不抛异常", ok)


def _rotation_mode_test():
    """边界：图层 rotation_mode 为 QUATERNION / AXIS_ANGLE 时，朝向跟随也必须正确。

    实测事故（review 发现）：`Quaternion.to_axis_angle()` 返回 **(axis, angle)**，
    而 Blender 的 `obj.rotation_axis_angle` 是 **(angle, x, y, z)** —— 两者顺序刻意不同。
    原代码写反 → float 被当 axis → `axis.x` 抛 AttributeError → 被 handler 吞掉 →
    该层朝向永不跟随。本用例锁死三种 mode。
    """
    for mode in ("XYZ", "QUATERNION", "AXIS_ANGLE"):
        scene, cam, coll, layers = build_scene()
        for o in layers:
            o.rotation_mode = mode
        P.record_parallax_lock_state(coll, cam)
        ref = P.get_parallax_reference_depth(layers)

        base_n = cam_space_normals(scene, cam, layers)
        set_cam(cam, rot_y_deg=30.0, rot_x_deg=10.0)
        err = None
        try:
            for o in layers:
                P.apply_camera_adapt_to_obj(o, cam, ref)
            bpy.context.view_layer.update()
        except Exception as e:                                # noqa: BLE001
            err = e
        after_n = cam_space_normals(scene, cam, layers)
        dmax = max((a - b).length for a, b in zip(base_n, after_n))
        check("14.%s rotation_mode=%s 朝向跟随正确" % (mode, mode),
              err is None and dmax < 1e-5,
              ("异常=%r" % err) if err else "偏差=%.2e" % dmax)


def _adjust_then_camera_move_test():
    """回归（2026-10-09 用户实测）：**锁定期调整图层间距后移相机，图层不得跳回调整前**。

    原 bug：用户在锁定期拖图层（= 改各层深度），但 locked_depth 仍是"按下锁定那一刻"的旧值
            ⇒ 随后一移动相机，① 分支用**旧基准**反算 ⇒ 图层被拉回调整前 ——
            用户看到"一动相机全跳回去"。
            （"关锁再开锁"之所以正常，正是因为那一步会重记基准 = 手动刷新。）
    修法：② 分支末尾把新状态写回基准（locked_depth / original_scale / center_offset 三样）。

    ⚠️ 必须走【注册插件 + file_record + handler】真实入口 —— 否则 scene.psd_import_tool
       不存在，handler 抛异常被静默吞掉，测试就测了个寂寞（同 11 组，踩过一次）。
    """
    import psd_layer_importer_plus as addon

    addon.register()
    try:
        scene, cam, coll, layers = build_scene()
        coll.name = "test_adjust_move"
        rec = scene.psd_import_tool.file_records.add()
        rec.filepath = os.path.join(_HERE, "test_adjust_move.psd")
        rec.collection = coll
        rec.parallax_maybe_locked = True
        _adjust_then_camera_move_body(scene, cam, coll, layers)
    finally:
        try:
            addon.unregister()
        except Exception:                                     # noqa: BLE001
            pass


def _adjust_then_camera_move_body(scene, cam, coll, layers):
    P.record_parallax_lock_state(coll, cam)
    # ⚠️ 锁定后必须重设账本（同 11 组）：否则自愈机制会把账本清零，
    #    handler 永远走 O(1) 短路 —— 相机适配完全不生效。
    for _r in scene.psd_import_tool.file_records:
        _r.parallax_maybe_locked = True

    obj = layers[0]
    locked_cam = P.get_camera_view_matrix(cam)

    def depth_of(o):
        bpy.context.view_layer.update()
        c = P.get_object_center_world_pos(o)
        return abs((locked_cam.inverted() @ c).z)

    d0 = depth_of(obj)
    check("15.0 前置：锁定基准深度 > 0", d0 > 0.1, "depth=%.3f" % d0)

    # ── 模拟用户「调整各图层间距」：把 0 号层推远 ──
    for o in layers:
        o.select_set(o is obj)
    obj["last_location"] = list(obj.location)          # 让 handler 认定"变了"
    obj["last_scale"] = list(obj.scale)
    obj.location = obj.location + mathutils.Vector((0.0, 0.0, -4.0))
    bpy.context.view_layer.update()

    P.parallax_scene_update_handler(scene)
    bpy.context.view_layer.update()

    check("15.1 ② 分支确实执行了（测试有效性）", "last_plugin_location" in obj)
    d1 = depth_of(obj)
    bpy.context.view_layer.update()
    m1 = measure(scene, cam, [obj])[0][2]              # 拖动后、移相机前的屏幕宽
    check("15.2 前置：深度确实被调整了", abs(d1 - d0) > 1.0,
          "调整前 %.3f → 调整后 %.3f" % (d0, d1))

    # ★ 核心断言 1：基准已随拖动对齐到当前状态（修复点本身）
    check("15.3 ★ 拖动后 locked_depth 已对齐当前深度",
          abs(obj["locked_depth"] - d1) < 1e-4,
          "locked_depth=%.4f  实际深度=%.4f" % (obj["locked_depth"], d1))

    # ── 移动相机 ──
    cam.location.x += 2.0
    bpy.context.view_layer.update()
    P.parallax_scene_update_handler(scene)
    bpy.context.view_layer.update()

    d2 = depth_of(obj)
    # ★ 核心断言 2：移相机后深度保持"调整后"的值，不得跳回调整前
    check("15.4 ★ 移相机后深度保持调整后的值（不跳回调整前）",
          abs(d2 - d1) < 1e-3,
          "调整后 %.3f → 移相机后 %.3f（若跳回则≈%.3f）" % (d1, d2, d0))

    # ★ 附加断言 3：屏幕大小也要保持 —— 这条专门锁住「三样必须一起更新」。
    #    若只改了 locked_depth 而漏了 original_scale：移相机后 ① 分支算
    #    scale_factor = current_depth/locked_depth ≈ 1，会把 scale 退回旧值 ⇒ 图层缩水。
    bpy.context.view_layer.update()
    m2 = measure(scene, cam, [obj])[0][2]
    check("15.5 ★ 移相机后屏幕大小保持（验证 original_scale 也一起更新了）",
          abs(m2 - m1) / max(m1, 1e-9) < 1e-2,
          "拖动后屏宽 %.5f → 移相机后 %.5f（相对差 %.2e）"
          % (m1, m2, abs(m2 - m1) / max(m1, 1e-9)))


def _camera_scale_test():
    """回归：相机对象带 scale 时（实测事故：用户工程相机 scale=38.9465）。

    scale 不影响渲染，但会污染 matrix_world.inverted()，把所有距离缩小同样倍数
    ⇒ locked_depth 算错 ⇒ 画面滚动量放大 38.95 倍（用户："稍微动一下就飞走"）。
    修法：用 get_camera_view_matrix（剥离 scale）。
    """
    scene, cam, coll, layers = build_scene()
    cam.scale = (38.9465, 38.9465, 38.9465)
    bpy.context.view_layer.update()
    P.record_parallax_lock_state(coll, cam)
    ref_depth = P.get_parallax_reference_depth(layers)

    depths = [o["locked_depth"] for o in layers]
    check("8.1 相机带 scale 时 depth 仍正确（未被缩小）",
          abs(depths[0] - 6.0) < 1e-3 and abs(depths[-1] - 12.0) < 1e-3,
          "depths=%s（期望≈[6, 9, 12]）" % [round(d, 4) for d in depths])
    check("8.2 基准深度正确", abs(ref_depth - 12.0) < 1e-3, "ref=%.4f" % ref_depth)

    base = measure(scene, cam, layers)
    base_world = [o.matrix_world.translation.copy() for o in layers]
    set_cam(cam, loc=(1.5, 0.0, 0.0))
    for o in layers:
        P.apply_camera_adapt_to_obj(o, cam, ref_depth)
    bpy.context.view_layer.update()
    after = measure(scene, cam, layers)

    ratios = similarity_ratios(base, after)
    check("8.3 相机带 scale 时构图仍保持",
          ratios and spread(ratios) < 1e-5,
          "间距比=%s" % [round(v, 6) for v in ratios])

    # 世界位移要直接读对象世界坐标（measure 只返回屏幕量：tuple (屏幕x, 屏幕y, 宽)）
    dw = [(layers[i].matrix_world.translation - base_world[i]).length
          for i in range(len(layers))]
    check("8.4 图层未被扔到远处（世界位移合理量级）",
          max(dw) < 5.0, "最大世界位移=%.4f（1.5 单位横移）" % max(dw))

    cam.scale = (1.0, 1.0, 1.0)


def _integration_test():
    """handler 级集成：走真实入口（scene.psd_import_tool + depsgraph handler）。

    前面的用例直接调 apply_camera_adapt_to_obj（核心数学），这里补上
    「插件注册后，相机移动 → handler 真的会跑并适配」这条链路。
    """
    import psd_layer_importer_plus as addon

    try:
        addon.register()
    except Exception as e:                                    # noqa: BLE001
        check("7.0 插件注册", False, repr(e))
        return
    try:
        scene, cam, coll, layers = build_scene()
        coll.name = "test_basic"
        rec = scene.psd_import_tool.file_records.add()
        rec.filepath = os.path.join(_HERE, "test_basic.psd")
        rec.collection = coll
        rec.parallax_maybe_locked = True

        P.record_parallax_lock_state(coll, cam)
        base = measure(scene, cam, layers)

        # 移相机 → 调 handler（等价于场景更新回调）
        set_cam(cam, loc=(1.5, 0.0, 0.0))
        P.parallax_scene_update_handler(scene)
        bpy.context.view_layer.update()
        after = measure(scene, cam, layers)

        ratios = similarity_ratios(base, after)
        dx = [a[0] - b[0] for a, b in zip(after, base)]
        check("7.1 集成：相机移动后 handler 自动适配（构图保持）",
              ratios and (max(ratios) - min(ratios)) < 1e-5,
              "间距比=%s" % [round(v, 5) for v in ratios])
        check("7.2 集成：画面确实滚动了", abs(dx[0]) > 1e-3, "层0 dx=%.4f" % dx[0])

        # 幂等：相机没动，再跑一次 handler 不该改动图层
        P.parallax_scene_update_handler(scene)
        bpy.context.view_layer.update()
        again = measure(scene, cam, layers)
        d2 = max(abs(a[0] - b[0]) for a, b in zip(again, after))
        check("7.3 集成：相机没动时 handler 幂等（不反复改图层）",
              d2 < 1e-9, "最大变化=%.2e" % d2)

        # 变焦（只改 lens，不动 matrix_world）→ handler 也必须适配
        set_cam(cam)
        P.parallax_scene_update_handler(scene)
        bpy.context.view_layer.update()
        before_zoom = measure(scene, cam, layers)
        set_cam(cam, lens=80.0)
        P.parallax_scene_update_handler(scene)
        bpy.context.view_layer.update()
        after_zoom = measure(scene, cam, layers)
        dz = max(max(abs(a[0] - b[0]), abs(a[1] - b[1]))
                 for a, b in zip(after_zoom, before_zoom))
        check("7.4b 集成：变焦时 handler 也适配（视图不变）", dz < 1e-5,
              "最大位置偏差=%.2e" % dz)

        # 旋转（只改 rotation）→ handler 也必须适配，且图层朝向跟着转
        set_cam(cam, lens=50.0)
        P.parallax_scene_update_handler(scene)
        bpy.context.view_layer.update()
        n_before = cam_space_normals(scene, cam, layers)
        set_cam(cam, rot_y_deg=25.0)
        P.parallax_scene_update_handler(scene)
        bpy.context.view_layer.update()
        n_after = cam_space_normals(scene, cam, layers)
        dn = max((a - b).length for a, b in zip(n_before, n_after))
        check("7.4c 集成：旋转时 handler 适配且朝向保持", dn < 1e-5,
              "最大朝向偏差=%.2e" % dn)

        # 相机移回锁定位置 → 图层应回到锁定时的位置
        set_cam(cam)
        P.parallax_scene_update_handler(scene)
        bpy.context.view_layer.update()
        back = measure(scene, cam, layers)
        d3 = max(abs(a[0] - b[0]) for a, b in zip(back, base))
        check("7.4 集成：相机移回 → 图层回到锁定构图", d3 < 1e-5,
              "最大偏差=%.2e" % d3)

        # 解锁 → 属性清干净（含新增的 last_camera_matrix）
        P.restore_parallax_lock_state(coll)
        left = [k for o in layers for k in ("last_camera_matrix", "locked_camera_matrix",
                                            "locked_screen_x") if k in o]
        check("7.5 解锁后锁定属性清干净", not left, "残留=%s" % left)
        check("7.6 解锁后不再判定为已锁定",
              not any(P.is_obj_parallax_locked(o) for o in layers))
    except Exception as e:                                    # noqa: BLE001
        import traceback
        check("7.x 集成测试异常", False, repr(e))
        print(traceback.format_exc())
    finally:
        try:
            addon.unregister()
        except Exception:                                     # noqa: BLE001
            pass


def main():
    scene, cam, coll, layers = build_scene()
    P.record_parallax_lock_state(coll, cam)
    ref_depth = P.get_parallax_reference_depth(layers)

    print("### 环境：Blender %s" % bpy.app.version_string)
    print("### 锁定深度：%s" % [round(o["locked_depth"], 4) for o in layers])
    print("### 基准深度 ref_depth = %.4f（= 最深锁定层）" % ref_depth)

    # ── 0. 锁定状态自检 ──
    check("0.1 全部图层已锁定", all(P.is_obj_parallax_locked(o) for o in layers))
    check("0.2 last_camera_matrix 已写入",
          all("last_camera_matrix" in o for o in layers))
    check("0.3 刚锁定时不算「相机变过」",
          not any(P.camera_changed_since_last_adapt(o, cam) for o in layers))

    # ── 1. 横移：构图保持 + 画面滚动 ──
    r = run_case(scene, cam, layers, ref_depth, "横移+1.5",
                 lambda c: set_cam(c, loc=(1.5, 0.0, 0.0)))
    check("1.1 横移 → 各层屏幕位移一致（构图保持）",
          r["spread_xy"] < 1e-5 and r["spread_ratio"] < 1e-5,
          "位移离散=%.2e 间距比=%s" % (r["spread_xy"], [round(v, 6) for v in r["ratios"]]))
    check("1.2 横移 → 画面确实滚动了（不是冻住）",
          abs(r["dx"][0]) > 1e-3, "层0 dx=%.4f" % r["dx"][0])

    r2 = run_case(scene, cam, layers, ref_depth, "横移+竖直",
                  lambda c: set_cam(c, loc=(1.5, 1.0, 0.0)))
    check("1.3 横移+竖直 → 构图保持", r2["spread_xy"] < 1e-5 and r2["spread_ratio"] < 1e-5,
          "位移离散=%.2e 间距比离散=%.2e" % (r2["spread_xy"], r2["spread_ratio"]))

    # ── 2. 推拉：整体缩放、各层比例一致（无视差） ──
    r = run_case(scene, cam, layers, ref_depth, "推近Z-2",
                 lambda c: set_cam(c, loc=(0.0, 0.0, -2.0)))
    check("2.1 推近 → 整体相似变换（各层一起缩放、无相对错位）",
          r["spread_ratio"] < 1e-5, "间距比=%s" % [round(v, 5) for v in r["ratios"]])
    check("2.2 推近 → 各层缩放比例一致（无视差）",
          r["spread_w"] is not None and r["spread_w"] < 1e-5,
          "宽度比=%s 离散=%.2e" % ([round(v, 4) for v in r["w_ratio"]], r["spread_w"] or 0))
    check("2.3 推近 → 画面确实放大了", r["w_ratio"][0] > 1.05,
          "层0 宽度比=%.4f" % r["w_ratio"][0])

    # ── 3. 旋转：各层跟随相机，构图保持 ──
    r = run_case(scene, cam, layers, ref_depth, "绕Y转20°",
                 lambda c: set_cam(c, rot_y_deg=20.0))
    check("3.1 旋转（相机位置不动）→ 构图完全冻结",
          max(abs(v) for v in r["dx"] + r["dy"]) < 1e-5,
          "最大位移=%.2e" % max(abs(v) for v in r["dx"] + r["dy"]))

    # 绕自身旋转后再横移 —— 各层位移必须仍一致（这里最考验"逐层重算"）
    r = run_case(scene, cam, layers, ref_depth, "转25°+横移1.2",
                 lambda c: set_cam(c, loc=(1.2, 0.0, 0.0), rot_y_deg=25.0))
    check("3.2 旋转+横移 → 构图保持（各层位移一致）",
          r["spread_xy"] < 1e-5 and r["spread_ratio"] < 1e-5,
          "位移离散=%.2e 间距比离散=%.2e" % (r["spread_xy"], r["spread_ratio"]))

    # ── 4. 变焦：画面保持不变 ──
    r = run_case(scene, cam, layers, ref_depth, "变焦50→85mm",
                 lambda c: set_cam(c, lens=85.0))
    check("4.1 变焦 → 屏幕位置不变",
          max(abs(v) for v in r["dx"] + r["dy"]) < 1e-5,
          "最大位移=%.2e" % max(abs(v) for v in r["dx"] + r["dy"]))
    check("4.2 变焦 → 屏幕尺寸不变",
          abs(r["w_ratio"][0] - 1.0) < 1e-4, "宽度比=%.6f" % r["w_ratio"][0])

    # ── 5. 组合：横移 + 旋转 + 推拉 ──
    r = run_case(scene, cam, layers, ref_depth, "横移+旋转+推拉",
                 lambda c: set_cam(c, loc=(1.0, 0.5, -1.0), rot_y_deg=15.0))
    check("5.1 组合操作 → 整体相似变换（无相对错位）",
          r["spread_ratio"] < 1e-4, "间距比=%s 离散=%.2e"
          % ([round(v, 4) for v in r["ratios"]], r["spread_ratio"]))

    # ── 6. 对照组：不调用适配（图层钉在世界）→ 必须出现视差 ──
    r = run_case(scene, cam, layers, ref_depth, "对照：横移但不适配",
                 lambda c: set_cam(c, loc=(1.5, 0.0, 0.0)), adapt=False)
    check("6.1 对照（不适配）→ 各层位移不一致 = 视差确实存在",
          r["spread_xy"] > 1e-3, "离散=%.4f" % r["spread_xy"])

    # ── 手感诊断（不看 PASS/FAIL，只看数字）──
    _feel_diagnostic(scene, cam, layers)

    # ── 9. 朝向跟随（相机转，图层跟着转）──
    _orientation_test()

    # ── 10. 变焦触发（只改 lens 也要适配）──
    _zoom_trigger_test()

    # ── 11. 旋转后拖图层的回归 ──
    _drag_after_rotate_test()

    # ── 12. initial_transform 不变性（PSD 原始相对位置记录）──
    _initial_transform_invariance_test()

    # ── 13. 老工程锁定记录缺新属性（review 发现的阻断级回归）──
    _stale_lock_test()

    # ── 14. rotation_mode 边界（review 发现的 AXIS_ANGLE 顺序 bug）──
    _rotation_mode_test()

    # ── 15. 锁定期调间距后移相机（用户实测 bug：图层跳回调整前）──
    _adjust_then_camera_move_test()

    # ── 8. 相机带 scale 的回归（实测事故，防复发）──
    _camera_scale_test()

    # ── 7. handler 级集成：真实场景更新回调里，相机一动是否自动适配 ──
    _integration_test()

    # ── 汇总 ──
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    total = len(RESULTS)
    print("\n#### 结果 %d/%d PASS" % (passed, total))
    for name, ok, detail in RESULTS:
        if not ok:
            print("####  FAIL: %s  %s" % (name, detail))
    print("SELFTEST_RESULT %d/%d" % (passed, total))
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
