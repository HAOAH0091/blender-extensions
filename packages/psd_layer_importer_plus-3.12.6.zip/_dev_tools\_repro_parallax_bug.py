# -*- coding: utf-8 -*-
"""复现：锁定期调整图层间距后，移动相机 → 图层跳回调整前。

用户操作序列：
  ① 锁定
  ② 调整各图层间距（拖动 = 改深度/位置）
  ③ 移动相机  →  BUG：所有图层跳回「调整前」
对照：② 之后「关锁再开锁」→ 移相机 → 正常
"""
import os
import sys
import bpy
import mathutils

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
# 相对推（去硬编码）：_dev_tools/ 的上级的上级 = addons 目录
_HERE = os.path.dirname(os.path.abspath(__file__))
ADDONS = os.path.dirname(os.path.dirname(_HERE))
sys.path.insert(0, ADDONS)

import psd_layer_importer_plus as addon          # noqa: E402
addon.register()
from psd_layer_importer_plus import parallax_utils as P                     # noqa: E402
from psd_layer_importer_plus.constants import ATTR_LAYER_ID, ATTR_INITIAL_TRANSFORM  # noqa: E402

OUT = []
def p(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    OUT.append(s)

# ── 摘掉自动 handler（避免 view_layer.update 重复触发，我们只显式调用）──
H = bpy.app.handlers.depsgraph_update_post
auto = [h for h in H if getattr(h, "__name__", "") == "parallax_scene_update_handler"]
for h in auto:
    H.remove(h)
p("摘掉自动 handler: %d 个" % len(auto))

scene = bpy.context.scene
scene.render.resolution_x, scene.render.resolution_y = 1920, 1080

# ── 相机 ──
cd = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cd)
scene.collection.objects.link(cam)
scene.camera = cam
cam.location = (0.0, 0.0, 0.0)
cam.rotation_euler = (0.0, 0.0, 0.0)          # 朝 -Z 看
p("相机 lens=%.1fmm sensor=%.1f  scale=%s" % (cd.lens, cd.sensor_width, tuple(round(s,3) for s in cam.scale)))

# ── 集合 + 3 个图层平面 ──
coll = bpy.data.collections.new("TestPSD")
scene.collection.children.link(coll)

def make_layer(name, z, x=0.0, size=1.0):
    me = bpy.data.meshes.new(name + "_m")
    me.from_pydata([(-size,-size,0),(size,-size,0),(size,size,0),(-size,size,0)], [], [(0,1,2,3)])
    me.update()
    o = bpy.data.objects.new(name, me)
    o.location = (x, 0.0, z)
    o[ATTR_LAYER_ID] = name
    o[ATTR_INITIAL_TRANSFORM] = {"location": [x, 0.0, z], "scale": [1,1,1], "rotation": [0,0,0]}
    coll.objects.link(o)
    return o

layers = [make_layer("L%d" % i, z) for i, z in enumerate([-6.0, -9.0, -12.0])]
bpy.context.view_layer.update()          # ★ 必须：否则 matrix_world / bound_box 未刷新

bpy.context.view_layer.update()
_bb = P.get_object_center_world_pos(layers[0])
p("   自检 L0 中心(世界): %s  (应约 (0,0,-6))" % [round(v,3) for v in _bb])

tool = scene.psd_import_tool
rec = tool.file_records.add()
rec.collection = coll
rec.filepath = "//TestPSD.psd"

def depth_of(o):
    bpy.context.view_layer.update()      # ★ 每次读之前刷新
    c = P.get_object_center_world_pos(o)
    return abs((P.get_camera_view_matrix(cam).inverted() @ c).z)

def select_only(o):
    for x in bpy.data.objects:
        x.select_set(False)
    if o is not None:
        o.select_set(True)
        bpy.context.view_layer.objects.active = o

# ══════ ① 锁定 ══════
p("\n" + "═"*64)
p("① 锁定")
P.record_parallax_lock_state(coll, cam)
p("   locked_depth : %s" % [round(o["locked_depth"], 3) for o in layers])
p("   实际深度     : %s" % [round(depth_of(o), 3) for o in layers])

# ══════ ② 用户「调整各图层间距」：把 L0 推远 ══════
p("\n" + "═"*64)
p("② 用户调整间距：L0 从 z=-6 推到 z=-12（深度 6 → 12）")
tgt = layers[0]
select_only(tgt)
tgt.location.z -= 6.0
bpy.context.view_layer.update()
p("   调整后实际深度 : %.3f" % depth_of(tgt))
P.parallax_scene_update_handler(scene)
p("   handler 后实际深度 : %.3f   （拖图层分支：保持屏幕坐标，深度按拖后算）" % depth_of(tgt))
p("   handler 后 locked_depth : %.3f   ★ 关键：基准有没有跟着更新？" % tgt["locked_depth"])
p("   L0 在场景里的位置 : %s" % [round(v,3) for v in tgt.location])

# ══════ ③ 移动相机 ══════
p("\n" + "═"*64)
p("③ 移动相机 Δx=+2")
cam.location.x += 2.0
bpy.context.view_layer.update()
P.parallax_scene_update_handler(scene)
d_after = depth_of(tgt)
p("   移相机后 L0 实际深度 : %.3f" % d_after)
p("   L0 在场景里的位置   : %s" % [round(v,3) for v in tgt.location])
jumped_back = abs(d_after - 6.0) < 0.5
p("   ▶ 判定：深度回到 ~6（调整前）？ %s" % ("是 ⇒ 复现 BUG ✗" if jumped_back else "否 ⇒ 未复现"))

# ══════ ④ 对照：关锁再开锁 ══════
p("\n" + "═"*64)
p("④ 对照：把 L0 摆回「用户调好」的深度 12，再关锁 → 开锁 → 移相机")
P.restore_parallax_lock_state(coll)          # 关锁
select_only(tgt)
tgt.location.z = -12.0                        # 用户调好的状态（上一轮被③拉回了 6）
bpy.context.view_layer.update()
P.record_parallax_lock_state(coll, cam)      # 开锁（重记基准）
p("   重锁后 locked_depth : %s" % [round(o["locked_depth"], 3) for o in layers])
cam.location.x += 2.0
bpy.context.view_layer.update()
P.parallax_scene_update_handler(scene)
d2 = depth_of(tgt)
p("   移相机后 L0 实际深度 : %.3f" % d2)
p("   ▶ 判定：深度保持 ~12（调整后）？ %s" % ("是 ⇒ 正常 ✓" if abs(d2 - 12.0) < 0.5 else "否"))

p("\n" + "═"*64)
with open(r"F:\desktop\BaiduSyncdisk\IDES\workspace\_parallax_repro.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(OUT))
print("REPRO_DONE")
