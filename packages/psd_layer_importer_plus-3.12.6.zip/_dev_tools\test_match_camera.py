"""匹配至相机（match_layers_to_camera）自测：构图基准 = PSD 原始位置。

用户诉求：
  用户自行改过图层对象导入后的位置后，再用「匹配至相机」——
  相机视图里呈现的**应该是 PSD 原始相对位置构图**（忽略手改），而不是被手改搞乱的构图。

数学判据（很干净）：
  match 后，图层在【相机空间】的 xy = relative.xy * viewport_scale
  而 relative.xy = base.xy（base = initial_transform 位置，center.xy = 0）
  ⇒  cs_i.xy / base_i.xy  对【所有层】都相等（= viewport_scale 这个常数）
  ⇒ 即"相机视图里的构图 ∝ PSD 原始构图"

z 判据（保留实际深度）：
  cs_i.z 的相对差 ∝ (actual_z_i - actual_z_0) * viewport_scale

在 Blender 后台进程运行：
    blender --background --factory-startup --python test_match_camera.py
"""
import sys
import os
import math

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG = os.path.dirname(_HERE)
sys.path.insert(0, os.path.dirname(_PKG))

import bpy
import mathutils

import psd_layer_importer_plus as addon
from psd_layer_importer_plus import parallax_utils as P
from psd_layer_importer_plus.constants import (
    ATTR_LAYER_ID, ATTR_INITIAL_TRANSFORM, ATTR_PRE_MATCH_TRANSFORM,
)

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("[%s] %-46s %s" % ("PASS" if ok else "FAIL", name, detail))


def add_plane(name, size, loc):
    mesh = bpy.data.meshes.new(name)
    h = 0.5
    mesh.from_pydata([(-h, -h, 0.0), (h, -h, 0.0), (h, h, 0.0), (-h, h, 0.0)], [],
                     [(0, 1, 2, 3)])
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    obj.scale = (size, size, 1.0)
    obj.location = loc
    return obj


# PSD 原始布局（模拟导入后的 initial_transform）
BASE_LOCS = [
    (-0.50, 0.30, 0.00),
    (0.00, -0.40, 0.01),
    (0.80, 0.10, 0.02),
]
# 用户手改后的当前位置（0 号挪得最远；z 是"视差深度"）
ACTUAL_LOCS = [
    (5.00, 3.00, -2.00),
    (0.00, -0.40, 0.50),
    (-3.00, 2.00, 1.50),
]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080

    cam_data = bpy.data.cameras.new("Cam")
    cam = bpy.data.objects.new("Cam", cam_data)
    cam.location = (2.0, 1.0, 4.0)
    cam.rotation_euler = (math.radians(75.0), 0.0, math.radians(20.0))
    cam_data.lens = 50.0
    scene.collection.objects.link(cam)
    scene.camera = cam

    coll = bpy.data.collections.new("PSD_Layers")
    scene.collection.children.link(coll)

    layers = []
    for i in range(3):
        obj = add_plane("Layer_%d" % i, 1.0, ACTUAL_LOCS[i])
        obj[ATTR_LAYER_ID] = "layer_%d" % i
        obj[ATTR_INITIAL_TRANSFORM] = {
            "location": list(BASE_LOCS[i]),
            "scale": [1.0, 1.0, 1.0],
            "rotation": [0.0, 0.0, 0.0],
        }
        coll.objects.link(obj)
        layers.append(obj)

    bpy.context.view_layer.update()

    # 测试用 PSD（只为提供画布尺寸）
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "make_test_psd", os.path.join(_HERE, "make_test_psd.py"))
    mk = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mk)
    psd_path = os.path.join(_HERE, "test_match.psd")
    if not os.path.exists(psd_path):
        mk.make_psd(psd_path)

    rec = scene.psd_import_tool.file_records.add()
    rec.filepath = psd_path
    rec.collection = coll
    rec.camera = cam
    return scene, cam, coll, layers, rec


def cam_space_xy(scene, cam, layers):
    """各层中心在【相机空间】的坐标。

    ⚠️ 必须先 view_layer.update()：matrix_world 是懒更新的，改完 location 不 update
       读到的还是旧值（我第一次就栽在这，测出的全是匹配前的位置）。
    """
    bpy.context.view_layer.update()
    R = cam.matrix_world.to_quaternion().to_matrix()
    Ri = R.transposed()
    out = []
    for o in layers:
        cs = Ri @ (o.matrix_world.translation - cam.matrix_world.translation)
        out.append(cs)
    return out


def ratios(vals, bases):
    """逐分量比值（跳过近 0 的分量）。"""
    out = []
    for v, b in zip(vals, bases):
        for k in range(2):
            if abs(b[k]) > 1e-3:
                out.append(v[k] / b[k])
    return out


def _operator_toggle_test():
    """operator 级：可预测的双态 —— 点1 匹配（PSD 原始构图）、点2 还原、点3 再匹配。

    回归锁：旧版判据是"相机是否移动"（用户不可见），同样的点击会时而匹配时而还原。
    新版判据 = 集合里有没有 pre_match_transform（按钮文字也同步变），可预测。
    """
    scene, cam, coll, layers, rec = build()
    for o in layers:
        o.location = o.location + mathutils.Vector((2.0, -1.5, 0.0))
    bpy.context.view_layer.update()
    idx = list(scene.psd_import_tool.file_records).index(rec)

    def has_pre():
        return any(ATTR_PRE_MATCH_TRANSFORM in o for o in layers)

    def click():
        r = bpy.ops.psd.match_to_camera(file_index=idx)
        bpy.context.view_layer.update()
        return r

    pre_pos = [o.location.copy() for o in layers]

    # ── 点 1 次 → 匹配 ──
    check("5.0 初始为「未匹配」态（按钮应显示「匹配至相机」）", not has_pre())
    click()
    bases = [mathutils.Vector(o[ATTR_INITIAL_TRANSFORM]["location"]) for o in layers]
    rs1 = ratios(cam_space_xy(scene, cam, layers), bases)
    check("5.1 点1次 → 匹配（构图 ∝ PSD 原始位置）",
          rs1 and (max(rs1) - min(rs1)) < 1e-5, "离散=%.2e" % (max(rs1) - min(rs1)))
    check("5.2 点1次后进入「已匹配」态（按钮应变成「恢复匹配前」）", has_pre())

    # ── 点 2 次 → 还原到匹配前 ──
    click()
    d_back = max((layers[i].location - pre_pos[i]).length for i in range(len(layers)))
    check("5.3 点2次 → 还原到匹配前的位置", d_back < 1e-6, "最大偏差=%.2e" % d_back)
    check("5.4 还原后回到「未匹配」态", not has_pre())

    # ── 点 3 次 → 再次匹配（可预测、可重复） ──
    click()
    rs3 = ratios(cam_space_xy(scene, cam, layers), bases)
    check("5.5 点3次 → 再次匹配（与点1结果一致）",
          rs3 and (max(rs3) - min(rs3)) < 1e-5, "离散=%.2e" % (max(rs3) - min(rs3)))


def _operator_selected_toggle_test():
    """选中行版 operator（`psd.match_selected_to_camera`）双态。

    review 指出：此前只测了卡片版（`psd.match_to_camera`），选中行版路径无测试覆盖。
    """
    scene, cam, coll, layers, rec = build()
    psd_tool = scene.psd_import_tool
    psd_tool.selected_camera = cam
    # "归管"判据 = identifier 在 record.imported_layer_ids 里（否则会被 _drop_unmanaged 滤掉）
    rec.imported_layer_ids = ",".join(o[ATTR_LAYER_ID] for o in layers)

    for o in layers:
        o.location = o.location + mathutils.Vector((2.0, -1.5, 0.0))
    bpy.context.view_layer.update()

    for o in bpy.data.objects:
        o.select_set(False)
    for o in layers:
        o.select_set(True)
    bpy.context.view_layer.update()

    def has_pre():
        return any(ATTR_PRE_MATCH_TRANSFORM in o for o in layers)

    pre_pos = [o.location.copy() for o in layers]
    bases = [mathutils.Vector(o[ATTR_INITIAL_TRANSFORM]["location"]) for o in layers]

    r = bpy.ops.psd.match_selected_to_camera()
    bpy.context.view_layer.update()
    check("6.0 选中行 operator 可调用", "FINISHED" in set(r), str(set(r)))
    rs = ratios(cam_space_xy(scene, cam, layers), bases)
    check("6.1 点1次 → 匹配（构图 ∝ PSD 原始位置）",
          rs and (max(rs) - min(rs)) < 1e-5, "离散=%.2e" % (max(rs) - min(rs)))
    check("6.2 进入已匹配态（按钮应变「恢复匹配前」）", has_pre())

    r = bpy.ops.psd.match_selected_to_camera()
    bpy.context.view_layer.update()
    d = max((layers[i].location - pre_pos[i]).length for i in range(len(layers)))
    check("6.3 点2次 → 还原到匹配前的位置", d < 1e-6, "最大偏差=%.2e" % d)
    check("6.4 回到未匹配态（按钮应变「匹配至相机」）", not has_pre())


def main():
    addon.register()
    try:
        scene, cam, coll, layers, rec = build()

        # 前置：确实模拟了"用户手改过"
        moved = [i for i in range(3)
                 if (mathutils.Vector(ACTUAL_LOCS[i])
                     - mathutils.Vector(BASE_LOCS[i])).length > 1e-3]
        check("0.1 前置：确实模拟了用户手改位置（base ≠ actual）",
              len(moved) == 3, "改动层=%s" % moved)

        _K = ("location", "scale", "rotation")
        init_snap = {o.name: {k: [float(x) for x in o[ATTR_INITIAL_TRANSFORM][k]]
                              for k in _K} for o in layers}

        P.match_layers_to_camera(coll, cam, rec)

        # 匹配至相机只【读】initial_transform，不得改动它（它是稳定的构图基准）
        d_init = []
        for o in layers:
            now, old = o[ATTR_INITIAL_TRANSFORM], init_snap[o.name]
            for k in ("location", "scale", "rotation"):
                d_init.append(max(abs(a - b) for a, b in zip(list(now[k]), list(old[k]))))
        check("1.0 匹配至相机不改动 initial_transform（构图基准保持稳定）",
              max(d_init) < 1e-9, "最大差异=%.2e" % max(d_init))

        cs = cam_space_xy(scene, cam, layers)
        bases = [mathutils.Vector(b) for b in BASE_LOCS]

        # ── 核心判据：cs.xy ∝ base.xy（构图 = PSD 原始） ──
        rs = ratios(cs, bases)
        spread = max(rs) - min(rs) if rs else 1.0
        check("1.1 匹配后 相机空间xy ∝ PSD原始位置（构图还原）",
              spread < 1e-5,
              "各层比值=%s 离散=%.2e（应全等）"
              % ([round(v, 5) for v in rs], spread))

        # 判别力：若按【实际位置】布局，比值应明显不一致
        rs_bad = ratios(cs, [mathutils.Vector(a) for a in ACTUAL_LOCS])
        check("1.2 反证：这些 cs 与【实际位置】不成比例（说明确实用的原始位置）",
              (max(rs_bad) - min(rs_bad)) > 1e-2,
              "与实际位置的比值离散=%.4f（应明显>0）"
              % (max(rs_bad) - min(rs_bad)))

        # 逐层细看：第 0 层被用户挪到 (5,3)，匹配后应回到 base.xy 方向
        k = rs[0]
        err = max(abs(cs[0].x / (bases[0].x * k) - 1.0),
                  abs(cs[0].y / (bases[0].y * k) - 1.0))
        check("1.3 被手改最远的第0层：匹配后回到 PSD 原始构图",
              err < 1e-5, "相对误差=%.2e" % err)

        # ── z：保留用户摆的实际深度 ──
        z_rels = [(cs[i].z - cs[0].z) for i in range(3)]
        z_actual = [ACTUAL_LOCS[i][2] - ACTUAL_LOCS[0][2] for i in range(3)]
        kr = z_rels[1] / z_actual[1] if abs(z_actual[1]) > 1e-6 else 1.0
        zerr = max(abs(z_rels[i] / (z_actual[i] * kr) - 1.0) for i in range(1, 3))
        check("2.1 z 保留【实际深度】（视差间距未被抹平）", zerr < 1e-5,
              "各层 z 相对差=%s（∝ 实际 z 差 %s）"
              % ([round(v, 4) for v in z_rels], z_actual))

        # ── 恢复：restore_pre_match_transform 应回到用户手改后的位置 ──
        P.restore_pre_match_transform(coll)
        back = [o.matrix_world.translation.copy() for o in layers]
        # 用 pre_match 里的 matrix_world 判断（恢复的是"匹配前"，含手改）
        ok_restore = all("pre_match_transform" not in o for o in layers)
        check("3.1 恢复后 pre_match_transform 属性已清除", ok_restore)

        # ── 无 initial_transform（旧工程）→ 回退实际位置，行为不变 ──
        for o in layers:
            if ATTR_INITIAL_TRANSFORM in o:
                del o[ATTR_INITIAL_TRANSFORM]
        for o, a in zip(layers, ACTUAL_LOCS):
            o.location = a
        bpy.context.view_layer.update()
        P.match_layers_to_camera(coll, cam, rec)
        cs2 = cam_space_xy(scene, cam, layers)
        rs2 = ratios(cs2, [mathutils.Vector(a) for a in ACTUAL_LOCS])
        spread2 = max(rs2) - min(rs2) if rs2 else 1.0
        check("4.1 无 initial_transform 时回退实际位置（旧行为不变）",
              spread2 < 1e-5,
              "比值=%s 离散=%.2e" % ([round(v, 5) for v in rs2], spread2))

        # ── 5. operator 级双态（卡片版）──
        _operator_toggle_test()

        # ── 6. operator 级双态（选中行版）──
        _operator_selected_toggle_test()
    except Exception as e:                                    # noqa: BLE001
        import traceback
        check("x 异常", False, repr(e))
        print(traceback.format_exc())
    finally:
        try:
            addon.unregister()
        except Exception:                                     # noqa: BLE001
            pass

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    total = len(RESULTS)
    print("\n#### 结果 %d/%d PASS" % (passed, total))
    print("SELFTEST_RESULT %d/%d" % (passed, total))
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
