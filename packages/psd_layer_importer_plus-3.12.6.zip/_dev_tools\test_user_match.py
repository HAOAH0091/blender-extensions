"""用户工程实测：匹配至相机后，构图是否还原为 PSD 原始相对位置。

在隔离副本上跑：
    blender --background --factory-startup <副本.blend> --python test_user_match.py

判据：匹配后各层在【相机空间】的 xy ∝ initial_transform 的 xy（PSD 原始构图），
      而不是 ∝ 用户手改后的实际位置。
"""
import sys
import os
import math

sys.path.insert(
    0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)  # addons 目录（相对推，别硬编码本机路径）

import bpy
import mathutils

import psd_layer_importer_plus as addon
from psd_layer_importer_plus import parallax_utils as P
from psd_layer_importer_plus.constants import ATTR_LAYER_ID, ATTR_INITIAL_TRANSFORM

OUT = []


def p(*a):
    line = " ".join(str(x) for x in a)
    OUT.append(line)
    print(line)


def main():
    addon.register()
    try:
        scene = bpy.context.scene
        cam = scene.camera
        layers = [o for o in bpy.data.objects if ATTR_LAYER_ID in o]
        p("### 图层数 :", len(layers))
        if not layers:
            p("!! 没有图层，退出")
            return

        # 所属集合
        coll = layers[0].users_collection[0]
        p("### 集合 :", coll.name)

        # file_records
        recs = list(scene.psd_import_tool.file_records)
        p("### file_records :", len(recs))
        rec = None
        for r in recs:
            p("   - filepath=%s  collection=%s"
              % (r.filepath, r.collection.name if r.collection else None))
            if r.collection == coll:
                rec = r
        if rec is None:
            p("   （无匹配记录，构造临时 record）")
            rec = scene.psd_import_tool.file_records.add()
            rec.filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "test_match.psd")
            rec.collection = coll
        if not os.path.exists(rec.filepath):
            p("   PSD 不存在，改用自带 test_match.psd")
            rec.filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "test_match.psd")
            if not os.path.exists(rec.filepath):
                import importlib.util
                spec = importlib.util.spec_from_file_location(
                    "mk", os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                       "make_test_psd.py"))
                mk = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mk)
                mk.make_psd(rec.filepath)

        # 匹配至相机
        P.match_layers_to_camera(coll, cam, rec)
        bpy.context.view_layer.update()

        R = cam.matrix_world.to_quaternion().to_matrix()
        Ri = R.transposed()
        cam_loc = cam.matrix_world.translation

        ks = []
        p("\n%-26s %-22s %-22s %-16s" % ("层名", "PSD原始xy(base)", "匹配后相机空间xy", "比值"))
        for o in layers[:34]:
            cs = Ri @ (o.matrix_world.translation - cam_loc)
            base = mathutils.Vector(o[ATTR_INITIAL_TRANSFORM]["location"]) \
                if ATTR_INITIAL_TRANSFORM in o else o.location
            rr = []
            for k in range(2):
                if abs(base[k]) > 1e-2:
                    rr.append(cs[k] / base[k])
                    ks.append(cs[k] / base[k])
            p("%-26s %-22s %-22s %s"
              % (o.name[:26],
                 "(%+.3f,%+.3f)" % (base.x, base.y),
                 "(%+.3f,%+.3f)" % (cs.x, cs.y),
                 " ".join("%.4f" % v for v in rr)))

        if ks:
            spread = max(ks) - min(ks)
            p("\n### 比值：n=%d  min=%.5f  max=%.5f  离散=%.2e"
              % (len(ks), min(ks), max(ks), spread))
            p("### 结论：%s"
              % ("✓ 构图 = PSD 原始（比值恒定）" if spread < 1e-3
                 else "✗ 比值不一致，构图未还原"))

        p("=" * 74)
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "_user_match_out.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(OUT))
    finally:
        try:
            addon.unregister()
        except Exception:                                     # noqa: BLE001
            pass


main()
