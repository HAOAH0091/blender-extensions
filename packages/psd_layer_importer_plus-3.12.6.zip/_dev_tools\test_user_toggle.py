"""用户工程：operator 双态验证（匹配 → 还原 → 再匹配）。

走真实按钮路径 bpy.ops.psd.match_to_camera。
"""
import sys
import os
import math

sys.path.insert(
    0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)  # addons 目录（相对推，别硬编码本机路径）

import bpy
import mathutils

import psd_layer_importer_plus as addon
from psd_layer_importer_plus import parallax_utils as P
from psd_layer_importer_plus.constants import (
    ATTR_LAYER_ID, ATTR_INITIAL_TRANSFORM, ATTR_PRE_MATCH_TRANSFORM,
)

addon.register()

OUT = []


def p(*a):
    s = " ".join(str(x) for x in a)
    OUT.append(s)
    print(s)


def mesh_center_world(obj):
    mw = obj.matrix_world
    pts = [mw @ v.co for v in obj.data.vertices]
    c = mathutils.Vector((0, 0, 0))
    for q in pts:
        c += q
    return c / len(pts)


scene = bpy.context.scene
cam = scene.camera
coll, idx = None, 0
for i, r in enumerate(scene.psd_import_tool.file_records):
    if r.collection:
        coll, idx = r.collection, i
        break
layers = [o for o in bpy.data.objects
          if ATTR_LAYER_ID in o and coll.name in [c.name for c in o.users_collection]]
p("### 图层 %d" % len(layers))


def spread():
    R = cam.matrix_world.to_quaternion().to_matrix()
    Ri = R.transposed()
    cl = cam.matrix_world.translation
    ks = []
    for o in layers:
        base = mathutils.Vector(o[ATTR_INITIAL_TRANSFORM]["location"]) \
            if ATTR_INITIAL_TRANSFORM in o else o.location
        cs = Ri @ (mesh_center_world(o) - cl)
        for k in range(2):
            if abs(base[k]) > 1e-2:
                ks.append(cs[k] / base[k])
    return (max(ks) - min(ks)) if ks else 0.0, len(ks)


def has_pre():
    return any(ATTR_PRE_MATCH_TRANSFORM in o for o in layers)


p("\n初始: 已匹配态=%s  构图离散=%.4f" % (has_pre(), spread()[0]))
pre_pos = [o.location.copy() for o in layers]

for n in (1, 2, 3):
    res = bpy.ops.psd.match_to_camera(file_index=idx)
    bpy.context.view_layer.update()
    d, nk = spread()
    p("\n[点%d次] 返回=%s  已匹配态=%s  构图离散=%.4f (n=%d)  %s"
      % (n, set(res), has_pre(), d, nk, "✓还原" if d < 1e-3 else "✗乱"))
    if n == 2:
        dd = max((layers[i].location - pre_pos[i]).length for i in range(len(layers)))
        p("         点2次后 vs 匹配前位置: 最大偏差=%.2e  %s"
          % (dd, "✓已还原" if dd < 1e-6 else "✗未还原"))

p("\n" + "=" * 74)
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_user_toggle.txt"),
          "w", encoding="utf-8") as f:
    f.write("\n".join(OUT))
