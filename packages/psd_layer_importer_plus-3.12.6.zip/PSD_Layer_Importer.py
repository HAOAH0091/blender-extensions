import bpy
from bpy.props import (
    StringProperty,
    PointerProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    FloatProperty,
)
from bpy.types import Panel, Operator, PropertyGroup, UIList
from bpy.types import AddonPreferences
import os
import hashlib
import subprocess
import sys
import threading
import json
import queue
import mathutils
import re
from typing import Optional, Tuple, List, Dict, Any

# 子模块导入
from .constants import (
    _psd_log, PSD_DEBUG, ATTR_LAYER_ID, ATTR_LAYER_BBOX,
    MESH_SCALE_FACTOR, LAYER_Z_OFFSET, MAX_FILENAME_LENGTH,
    PNG_COMPRESS_LEVEL, MIN_LAYER_SIZE, MIN_DEPTH, DEFAULT_ALPHA,
    TRANSFORM_CHANGE_THRESHOLD,
    UV_BOTTOM_LEFT, UV_TOP_LEFT, UV_TOP_RIGHT, UV_BOTTOM_RIGHT,
    ATTR_INITIAL_TRANSFORM, ATTR_PRE_MATCH_TRANSFORM,
    ATTR_PARALLAX_LOCKED, ATTR_LAYER_PRIMARY, UV_ADJUST_NODEGROUP_PREFIX,
    ensure_dependencies, open_psd,
)
from . import constants  # 模块对象引用，供 AddonPreferences 的 update 回调使用
from .psd_utils import (
    build_layer_list_json, parse_layer_list_json, get_imported_id_set,
    get_visible_layers, extract_layer_hierarchy, ensure_collection_tree,
    find_layer_object_in_tree, find_all_layer_objects, serialize_hierarchy_snapshot,
    get_target_collection_for_layer, sync_collection_structure,
    move_layer_object_to_collection, sanitize_filename,
    get_cache_root, get_cache_png_path, cleanup_cache_files,
    _get_layer_bbox, render_layer_rgba, compute_image_md5,
    save_image_png, save_layer_to_png_and_checksum,
    check_packed_image_validity, load_or_update_image_from_cache,
    create_layer_identifier,
)
from .parallax_utils import (
    get_collection_from_record, get_all_objects_recursive,
    get_mesh_dimensions, match_layers_to_camera,
    restore_pre_match_transform, record_parallax_lock_state,
    restore_parallax_lock_state, parallax_scene_update_handler,
    is_obj_parallax_locked, psd_has_locked_layers,
)


# ==================== 常量定义 ====================

# 缩放和尺寸相关

# 最近一次异步启动失败的原因（由 launch_async_job 写入，供选中刷新等 UI 读取大白话提示）
_last_async_error = ""

# 图层选择导入：本次要导入的图层 identifier 集合（None=全选，保持旧行为）
_import_selected_ids = None
# 追加导入时，已导入过的图层如何处理："NEW"（追加为新图层，重名加序号）/ "UPDATE"（更新已有图层）
_import_append_mode = "NEW"

# 将用户站点包路径加入 sys.path（兼容手动安装场景）
# ---------------- 数据模型 ----------------


class LayerChecksum(PropertyGroup):
    value: StringProperty(default="")
    # 图层唯一标识（PSD 图层自带 ID）。旧记录此字段为空，回退用 name 匹配。
    identifier: StringProperty(default="")


class PendingLayerItem(PropertyGroup):
    """图层选择弹窗中的一项（图层或文件夹）。

    identifier 对图层=PSD 图层自带 ID；对文件夹="GRP:<组路径>"。
    """
    identifier: StringProperty(default="")
    display_name: StringProperty(default="")
    depth: IntProperty(default=0)
    is_group: BoolProperty(default=False)
    selected: BoolProperty(default=True)
    is_imported: BoolProperty(default=False)
    is_new: BoolProperty(default=False)
    is_changed: BoolProperty(default=False)
    # 文件夹是否展开（默认折叠）；仅文件夹有意义
    is_expanded: BoolProperty(default=False)
    # 可见视图项 → 指向 pending_all 的下标（-1 = 无）
    src_index: IntProperty(default=-1)


def _poll_camera_object(self, obj) -> bool:
    """PointerProperty poll：只接受相机对象。

    防止把方块/灯光/图层等拖进「相机」框 —— 否则下游会用
    camera.data.lens / camera.data.type 等相机专有属性而抛 AttributeError。
    """
    return obj is None or getattr(obj, "type", None) == "CAMERA"


def _find_record_index(record):
    """反查 record 在 file_records 中的下标（找不到返回 -1）。"""
    try:
        tool = bpy.context.scene.psd_import_tool
    except Exception:
        return -1
    for i, r in enumerate(tool.file_records):
        if r == record:
            return i
    return -1


def _on_layer_search_changed(self, context):
    """搜索框内容变化 → 立刻重建显示行（边打字边出结果）。"""
    try:
        idx = _find_record_index(self)
        if idx >= 0:
            _rebuild_layer_items(self, idx)
    except Exception as ex:
        _psd_log(f"[PSD-列表] 搜索过滤失败: {type(ex).__name__}: {ex}")


def _on_layer_active_changed(self, context):
    """列表控件的"活动行"：本列表不支持"行光标"这种语义，一律复位。

    为什么必须复位：点击行的空白处时，控件会把 active 设成该行，并画一条
    **整行蓝底**。但我们表达"选中"用的是行名的按下态（depress）——
    两种蓝同时出现会让人分不清哪套才是选中。所以这里直接压回 -1。
    """
    if self.layer_active >= 0:
        self.layer_active = -1


class PSDCardLayerItem(PropertyGroup):
    """卡片图层列表的**显示行**（视图层，由 _rebuild_layer_items 重建）。

    权威状态不在这里：勾选看 record.imported_layer_ids、选中看 record.layer_list_sel、
    组折叠看 record.layer_collapsed_groups。本结构只是把「该显示哪些行、长什么样」摊平，
    供 template_list 绘制（带来内部滚动条）。
    """

    rec_index: IntProperty(default=0)
    identifier: StringProperty(default="")
    name: StringProperty(default="")
    depth: IntProperty(default=0)
    is_group: BoolProperty(default=False)
    expanded: BoolProperty(default=True)
    checked: BoolProperty(default=False)
    selected: BoolProperty(default=False)
    has_object: BoolProperty(default=False)
    mark: StringProperty(default="")


class PSD_UL_CardLayers(bpy.types.UIList):
    """卡片图层列表的绘制器：组（可折叠）/ 图层（勾选框 + 名字 + 标记 + ✕）。"""

    def draw_item(self, context, layout, data, item, icon,
                  active_data, active_propname, index):
        # 单行绘制失败不该拖垮整个面板：捕获 + 留痕（静默失效不可接受）
        try:
            self._draw_inner(context, layout, data, item, icon,
                             active_data, active_propname, index)
        except Exception as ex:
            _psd_log(f"[PSD-列表] 绘制行失败: {type(ex).__name__}: {ex}")
            layout.label(text="!err", icon="ERROR")

    def _draw_inner(self, context, layout, data, item, icon,
                    active_data, active_propname, index):
        ri = item.rec_index
        # split 必须是行的**第一个**元素：分割线的位置就只取决于行宽，
        # 与前面放了多少个图标无关。否则文件夹行（多一个折叠箭头 + 文件夹图标）
        # 的名字灰框右边缘会比图层行更靠右 —— 两列的灰框不在一条竖线上。
        row = layout.row(align=True)
        sp = row.split(factor=0.75, align=True)

        left = sp.row(align=True)
        for _ in range(item.depth):
            left.label(text="", icon="BLANK1")

        if item.is_group:
            arrow = "TRIA_DOWN" if item.expanded else "TRIA_RIGHT"
            eop = left.operator("psd.toggle_group_expand", text="", icon=arrow,
                                emboss=False)
            eop.rec_index = ri
            eop.identifier = item.identifier
            left.label(text="", icon="FILE_FOLDER")

        # 组行 = 批量勾选（组内所有图层）；图层行 = 自身勾选
        cb = left.operator(
            "psd.toggle_layer_checked", text="",
            icon="CHECKBOX_HLT" if item.checked else "CHECKBOX_DEHLT",
        )
        cb.rec_index = ri
        cb.item_index = index

        # 名字点选区撑满左区（宽度随列表自适应）
        namebox = left.row(align=True)
        if not item.is_group:
            namebox.enabled = item.checked   # 未勾选的图层名不可点（保持原行为）
        namebox.alignment = "EXPAND"
        sop = namebox.operator(
            "psd.select_layer_row", text=item.name,
            depress=item.selected, emboss=True,
        )
        sop.rec_index = ri
        sop.item_index = index

        # 「已改/新图层」标记 + ✕ 一律右对齐（各行落在同一条竖线上）
        rrow = sp.row(align=True)
        rrow.alignment = "RIGHT"
        if item.mark:
            rrow.label(text=item.mark, icon="INFO")
        if item.has_object:
            dop = rrow.operator("psd.delete_layer_object", text="", icon="X")
            dop.rec_index = ri
            dop.item_index = index


class PSDFileRecord(PropertyGroup):
    filepath: StringProperty(name="文件路径", default="")
    layer_checksums: CollectionProperty(type=LayerChecksum)
    layer_order: StringProperty(default="")
    # 已导入图层清单：存 identifier（逗号分隔）。初次导入写入、追加时并入；
    # 刷新/强制刷新以此为基准过滤图层（空=旧行为·按全量刷新）。
    imported_layer_ids: StringProperty(default="")
    camera: PointerProperty(
        type=bpy.types.Object,
        name="相机",
        description="该 PSD 使用的相机（视差锁定 / 匹配至相机）",
        poll=_poll_camera_object,
    )
    collection: PointerProperty(
        type=bpy.types.Collection, name="集合", description="关联的Blender集合"
    )
    parallax_locked: BoolProperty(default=False)
    # 内部性能闸门：该 PSD「可能」有锁定图层（宁多勿漏，失败安全）。
    # 供视差 handler 做 O(1) 短路，避免每次场景更新都全量扫描；
    # 确认扫不到锁定对象时自动归零（自愈）。默认 True 以兼容旧 .blend。
    parallax_maybe_locked: BoolProperty(default=True)
    last_camera_transform: StringProperty(default="")
    # 文件修改时间。注意：**不能用 FloatProperty** —— Blender 的 float 是 32 位，
    # 在 Unix 时间戳这个量级（1.8e9）只能精确到 128 秒一格，会误报"文件已变化"。
    # 用字符串存精确值（空 = 未知）。
    file_mtime: StringProperty(default="")

    # === 卡片内嵌图层列表（默认折叠常驻）===
    # 缓存：扁平图层列表 JSON（[{i:identifier,n:name,d:depth,g:is_group,m:mark}]）。
    # 导入/追加/重新扫描时写入；展开卡片时直接读它，不再现读 PSD（避免卡顿）。
    layer_list_json: StringProperty(default="")
    # 卡片列表是否展开（默认折叠）
    layer_list_open: BoolProperty(default=False)
    # 列表中被选中的行（identifier，逗号分隔）。注意：「选中」≠「勾选」——
    # 勾选看 imported_layer_ids（归不归插件管），选中只是界面上的高亮/操作对象。
    layer_list_sel: StringProperty(default="")
    # Shift 范围选择的锚点（列表行号；-1 表示尚未点过）
    layer_list_anchor: IntProperty(default=-1)
    # 组（文件夹）的折叠状态：收起组的 identifier（逗号分隔）
    layer_collapsed_groups: StringProperty(default="")
    # template_list 的显示数据（视图层，见 PSDCardLayerItem 说明）
    layer_items: CollectionProperty(type=PSDCardLayerItem)
    # 列表控件的"活动行"下标。恒为 -1：本表不用它的行光标（见 _on_layer_active_changed）
    layer_active: IntProperty(default=-1, update=_on_layer_active_changed)
    # 图层搜索关键词（空 = 不过滤）。命中的图层 + 其祖先组会显示出来
    layer_search: StringProperty(
        name="搜索图层", default="", update=_on_layer_search_changed
    )
    # 「重新扫描」的内容比对进度（结构级是即时的，内容级才需要进度）
    layer_list_scanning: BoolProperty(default=False)
    layer_list_scan_progress: FloatProperty(default=0.0, min=0.0, max=1.0)

    # 刷新控制选项
    refresh_update_texture: BoolProperty(
        name="更新贴图", description="刷新时更新图像贴图数据", default=True
    )
    refresh_update_mesh: BoolProperty(
        name="更新网格", description="刷新时更新网格顶点尺寸", default=False
    )
    refresh_update_transform: BoolProperty(
        name="更新变换",
        description="刷新时重置对象变换（位置/旋转/缩放）",
        default=False,
    )
    # 刷新时是否补建集合结构（与全局设置同一语义）
    refresh_update_structure: BoolProperty(
        name="更新结构",
        description="刷新时按 PSD 文件夹层级补建缺失的集合。不删除已有集合，也不移动已导入的图层对象",
        default=False,
    )
    # 层级结构快照（JSON字符串），用于刷新时检测PSD文件夹结构是否变化
    group_hierarchy: StringProperty(
        name="组层级快照",
        description="PSD文件图层组结构的序列化快照，用于刷新时检测结构变化",
        default="",
    )


class PSDImportProperties(PropertyGroup):
    file_records: CollectionProperty(type=PSDFileRecord)

    # === 全局设置（「⚙ 设置」子面板）===
    # v3.11.0 起：刷新选项由「每张卡片各一份」收归「全局统管」。
    refresh_update_texture: BoolProperty(
        name="更新贴图", description="刷新时更新图像贴图数据", default=True
    )
    refresh_update_mesh: BoolProperty(
        name="更新网格", description="刷新时更新网格顶点尺寸", default=False
    )
    refresh_update_transform: BoolProperty(
        name="更新变换",
        description="刷新时重置对象变换（位置/旋转/缩放）",
        default=False,
    )
    refresh_update_structure: BoolProperty(
        name="更新结构",
        description="刷新时按 PSD 文件夹层级补建缺失的集合。不删除已有集合，也不移动已导入的图层对象",
        default=False,
    )
    # 扫描/导入时是否包含 PSD 里隐藏（关闭眼睛）的图层与文件夹
    include_hidden_layers: BoolProperty(
        name="包含隐藏图层/文件夹",
        description="扫描/导入时，把 PSD 里隐藏的图层和文件夹也一并收进来",
        default=False,
    )

    # === 性能 / 存储（v3.12.0）===
    # PNG 压缩等级：越低越快（写盘 CPU 少）、文件越大；越高越慢、文件越小。
    # 实测（46 层 / 1.38 亿像素）：6 → 7.7s，1 → 2.95s，0 → 更快但体积更大。
    png_compress_level: IntProperty(
        name="PNG 压缩等级",
        description="0~9，默认 1。越低越快、文件越大（0 写盘最快）；越高越慢、文件越小",
        default=1, min=0, max=9,
    )
    # 贴图存放方式：打包进 .blend（自包含）或 外放到工程根目录 PSD_texture（工程小）
    texture_store_mode: EnumProperty(
        name="贴图存放",
        description="贴图存到哪里：打包进 .blend（工程自包含），还是外放成 PSD_texture 文件夹",
        items=[
            ("PACK", "打包进工程", "贴图打包进 .blend 文件：工程自包含，好拷贝，但 .blend 体积大"),
            ("EXTERNAL", "外放 PSD_texture 文件夹", "贴图放到工程根目录的 PSD_texture 文件夹：.blend 体积小，但拷贝工程要连带贴图"),
        ],
        default="PACK",
    )

    # === 异步刷新进度（面板进度条 + 状态栏双保险）===
    refresh_active: BoolProperty(
        name="异步处理中",
        description="是否有后台 PSD 任务正在运行",
        default=False,
    )
    refresh_progress: FloatProperty(
        name="进度",
        description="后台任务进度 0~1",
        min=0.0,
        max=1.0,
        default=0.0,
    )
    refresh_status: StringProperty(
        name="状态",
        description="后台任务当前状态文本",
        default="",
    )

    # === 图层选择导入（弹窗用）===
    pending_layers: CollectionProperty(type=PendingLayerItem)  # 可见视图（UIList 绑定）
    pending_all: CollectionProperty(type=PendingLayerItem)     # 完整树：选择/展开的唯一真源
    pending_mode: StringProperty(
        name="选择模式",
        description='导入模式："IMPORT"（首次导入）或 "APPEND"（追加导入）',
        default="",
    )
    pending_file_index: IntProperty(default=-1)
    pending_filepath: StringProperty(default="")
    pending_append_mode: EnumProperty(
        name="追加方式",
        description="已导入过的图层如何处理",
        items=[
            ("NEW", "追加为新图层", "重名时自动加序号，不覆盖已有对象"),
            ("UPDATE", "更新已有图层", "就地更新对应的已有对象，不新建"),
        ],
        default="NEW",
    )
    pending_total_layers: IntProperty(default=0)
    pending_imported_count: IntProperty(default=0)
    pending_new_count: IntProperty(default=0)
    # 后台内容比对（弹窗内进度提示）
    pending_analysis_active: BoolProperty(default=False)
    pending_analysis_progress: FloatProperty(default=0.0, min=0.0, max=1.0)
    pending_analysis_status: StringProperty(default="")
    pending_active_index: IntProperty(default=0)

    # === 选中行操作：专用相机（「匹配选中图层至相机」使用）===
    selected_camera: PointerProperty(
        name="相机",
        description="「匹配选中图层至相机」使用的相机",
        type=bpy.types.Object,
        poll=_poll_camera_object,
    )
    last_selected_camera_transform: StringProperty(default="")


def build_pending_items(psd_tool, hierarchy_tree, imported_ids=None, changed_ids=None):
    """把 extract_layer_hierarchy 的 tree 填入 psd_tool.pending_layers（含文件夹）。

    默认勾选规则：
    - imported_ids=None（首次导入）→ 全选
    - imported_ids 给定（追加导入）→ 已导入的默认不勾；未导入/新增/内容变更的默认勾

    Returns: 统计 dict {total_layers, groups, imported, new}
    """
    is_append = imported_ids is not None
    imported_ids = imported_ids or set()
    changed_ids = changed_ids or set()
    # 作废上一个弹窗的在途内容比对，避免旧结果按旧下标串写到新列表
    _analysis_lock["queue"] = None
    _analysis_lock["gen"] = _analysis_lock.get("gen", 0) + 1
    # 同步复位进度标志：否则"取消→重开"后进度框会永久卡在"比对内容改动中…"
    psd_tool.pending_analysis_active = False
    psd_tool.pending_analysis_progress = 0.0
    psd_tool.pending_analysis_status = ""
    psd_tool.pending_all.clear()
    psd_tool.pending_layers.clear()
    stats = {"total_layers": 0, "groups": 0, "imported": 0, "new": 0}

    def _walk(branch, depth, path):
        for node in branch:
            if node.get("type") == "group":
                gpath = path + [node["name"]]
                it = psd_tool.pending_all.add()
                it.identifier = "GRP:" + "/".join(gpath)
                it.display_name = node["name"]
                it.depth = depth
                it.is_group = True
                it.selected = True
                stats["groups"] += 1
                _walk(node.get("children", []), depth + 1, gpath)
            else:
                ident = node.get("identifier", "")
                it = psd_tool.pending_all.add()
                it.identifier = ident
                it.display_name = node.get("name", "")
                it.depth = depth
                it.is_group = False
                it.is_imported = ident in imported_ids
                it.is_new = is_append and (ident not in imported_ids)
                it.is_changed = ident in changed_ids
                if is_append:
                    it.selected = (not it.is_imported) or it.is_changed
                else:
                    it.selected = True
                stats["total_layers"] += 1
                if it.is_imported:
                    stats["imported"] += 1
                if it.is_new:
                    stats["new"] += 1

    _walk(hierarchy_tree, 0, [])
    _rebuild_visible(psd_tool)
    return stats


def _group_state_master(coll, index):
    """返回组项在【完整树】上的显示态：2=全选 1=半选 0=未选。基于其后代图层。"""
    base = coll[index]
    n = 0
    sel = 0
    for j in range(index + 1, len(coll)):
        it = coll[j]
        if it.depth <= base.depth:
            break
        if not it.is_group:
            n += 1
            if it.selected:
                sel += 1
    if n == 0:
        return 2 if base.selected else 0
    if sel == n:
        return 2
    if sel == 0:
        return 0
    return 1


def _rebuild_visible(psd_tool, anchor_src=None):
    """按各组的展开状态，从 pending_all（完整树）重建可见列表 pending_layers。

    折叠的组：只画组自身，跳过其整个子树（后代 depth 更大）。
    """
    allc = psd_tool.pending_all
    vis = psd_tool.pending_layers

    # 1) 先算出新的可见序列（主表下标 src_index 的有序列表）
    new_seq = []
    n = len(allc)
    i = 0
    while i < n:
        it = allc[i]
        new_seq.append(i)
        if it.is_group and not it.is_expanded:
            i += 1
            while i < n and allc[i].depth > it.depth:
                i += 1
            continue
        i += 1

    # 2) 就地改写（**不 clear**）：逐位置更新已有项，不足则追加、多余则删尾。
    #    用 clear() 会让 UIList 的滚动位置被重置（展开/折叠时跳回列表顶部）。
    cur = len(vis)
    for k, si in enumerate(new_seq):
        v = vis[k] if k < cur else vis.add()
        it = allc[si]
        v.identifier = it.identifier
        v.display_name = it.display_name
        v.depth = it.depth
        v.is_group = it.is_group
        v.selected = it.selected
        v.is_imported = it.is_imported
        v.is_new = it.is_new
        v.is_changed = it.is_changed
        v.is_expanded = it.is_expanded
        v.src_index = si
    while len(vis) > len(new_seq):
        vis.remove(len(vis) - 1)

    # 3) active_index：优先锚定到被操作的项（anchor_src），让列表停在那附近；
    #    否则夹紧到合法区间，绝不无脑跳回 0。
    pos = None
    if anchor_src is not None:
        pos = next((k for k, si in enumerate(new_seq) if si == anchor_src), None)
    if pos is not None:
        psd_tool.pending_active_index = pos
    elif psd_tool.pending_active_index >= len(vis):
        psd_tool.pending_active_index = max(0, len(vis) - 1)


# ---------------- UI 面板 ----------------


class PSD_PT_ImportPanel(Panel):
    bl_label = "PSD图层导入工具"
    bl_idname = "PSD_PT_ImportPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "PSD图层导入工具"

    def draw(self, context):
        layout = self.layout
        psd_tool = context.scene.psd_import_tool

        missing = check_dependencies()
        if missing:
            layout.label(text="缺少以下依赖库:", icon="ERROR")
            layout.label(text=", ".join(missing))
            layout.operator(
                "psd.check_dependencies", text="安装依赖库", icon="FILE_SCRIPT"
            )
            return

        layout.operator("psd.import_layers")
        layout.separator()

        # 异步进度条：只有在后台任务运行时才显示
        if psd_tool.refresh_active:
            box = layout.box()
            row = box.row(align=True)
            row.alignment = "CENTER"
            row.label(text="后台处理中", icon="PROPERTIES")
            # 浮点 slider 当作进度条（Blender 面板无原生进度条控件）
            box.prop(psd_tool, "refresh_progress", text="", slider=True)
            box.label(text=psd_tool.refresh_status or "…", icon="ARROW_LEFTRIGHT")
            layout.separator()

        box = layout.box()
        # 标题单独一行
        box.label(text="选中图层操作")
        # 三个功能按钮单独一行
        sub_row = box.row(align=True)
        sub_row.scale_x = 0.8
        sub_row.scale_y = 0.8
        self.draw_selected_layer_buttons(sub_row)
        # 匹配至相机栏：文字按钮 + 相机框 + 锁定
        # 布局顺序很关键：**先给锁定按钮切出固定份额**，再在剩余空间里分
        # 「文字按钮 / 相机框」。否则相机框（搜索框有较大固有宽度）会把锁定
        # 按钮挤出可视区（窄面板下尤其明显）。
        lock_icon = "LOCKED" if _selected_parallax_locked(context) else "UNLOCKED"
        lock_split = box.split(factor=0.90, align=True)
        cam_area = lock_split.row(align=True)
        lock_area = lock_split.row(align=True)
        cam_inner = cam_area.split(factor=0.35, align=True)
        # 双态按钮：文字跟着状态变（已匹配 → 「恢复匹配前」），用户看得见、可预测；
        # 混合选中（部分已匹配）时显示中性文案，避免「点了恢复却有些层被匹配」的误导。
        _sel_text, _sel_icon = _selected_match_label(context)
        cam_inner.row(align=True).operator(
            "psd.match_selected_to_camera", text=_sel_text, icon=_sel_icon,
        )
        cam_inner.row(align=True).prop(psd_tool, "selected_camera", text="")
        lock_area.operator(
            "psd.toggle_parallax_lock_selected", text="", icon=lock_icon
        )

        layout.separator()
        layout.label(text="PSD文件列表:")
        for i, record in enumerate(psd_tool.file_records):
            self.draw_file_record(layout, record, i)

    def draw_file_record(self, layout, record, index):
        box = layout.box()
        # 标题行：文件名 + 删除按钮（同一行，删除靠右）
        title_row = box.row()
        title_row.label(text=os.path.basename(record.filepath))
        op = title_row.operator("psd.delete_psd_file", text="", icon="X")
        op.file_index = index
        # 按钮行：两组（第二组右对齐面板）
        sub_row = box.row(align=True)
        self.draw_file_buttons(sub_row, index)

        # 刷新选项已收归「⚙ 设置」子面板（全局统管），卡片上不再放

        parallax_box = box.box()
        # 同选中行：先切出锁定按钮的份额，再分按钮/相机框
        pl_lock_split = parallax_box.split(factor=0.90, align=True)
        pl_cam_area = pl_lock_split.row(align=True)
        pl_lock_area = pl_lock_split.row(align=True)
        pl_inner = pl_cam_area.split(factor=0.35, align=True)
        _card_matched = _card_has_pre_match(record)
        pl_inner.row(align=True).operator(
            "psd.match_to_camera",
            text="恢复匹配前" if _card_matched else "匹配至相机",
            icon="LOOP_BACK" if _card_matched else "CAMERA_DATA",
        ).file_index = index
        pl_inner.row(align=True).prop(record, "camera", text="")
        pl_lock_area.operator(
            "psd.toggle_parallax_lock",
            text="",
            icon="LOCKED" if _card_parallax_locked(record) else "UNLOCKED",
        ).file_index = index

        # 图层列表（默认折叠常驻）
        self.draw_layer_list(box, record, index)

    def draw_layer_list(self, box, record, index):
        """卡片内嵌图层列表（默认折叠）。

        - 结构数据 = record.layer_list_json（导入/重新扫描时的缓存）
        - 显示行 = record.layer_items（视图层，由 _rebuild_layer_items 重建）
          ⇒ 用 template_list 绘制，**自带内部滚动条**，长列表不再撑长卡片
        """
        tree = parse_layer_list_json(record.layer_list_json)
        if not tree:
            return  # 还没读过图层（未导入过）→ 不显示列表区

        imported = get_imported_id_set(record)
        sel_set = _sel_set(record)
        layers = [it for it in tree if not it["g"]]
        n_checked = sum(1 for it in layers if it["i"] in imported)
        stale = _file_is_newer(record)

        lbox = box.box()
        arrow = "TRIA_DOWN" if record.layer_list_open else "TRIA_RIGHT"
        head = lbox.row()
        hop = head.operator("psd.toggle_layer_list", text="", icon=arrow, emboss=False)
        hop.file_index = index
        head.label(text="图层列表")
        stat = head.row()
        stat.alignment = "RIGHT"
        if stale:
            stat.label(text="文件已变化", icon="ERROR")
        stat.label(text=f"{len(layers)} 层 · 已导入 {n_checked}")

        if not record.layer_list_open:
            return

        body = lbox.box()

        # 工具条
        bar = body.row(align=True)
        bar.operator("psd.change_filepath", text="改路径", icon="FILE_FOLDER").file_index = index
        bar.separator(factor=0.4)
        bar.operator("psd.select_all_layers", text="全选", icon="CHECKBOX_HLT").file_index = index
        bar.separator(factor=0.4)
        bar.operator("psd.invert_layer_selection", text="反选", icon="ARROW_LEFTRIGHT").file_index = index
        bar.separator(factor=0.4)
        bar.operator("psd.rescan_layers", text="重新扫描", icon="FILE_REFRESH").file_index = index

        # 搜索框（搜图层名；命中的层连同其所在组一起显示）
        srow = body.row(align=True)
        srow.prop(record, "layer_search", text="", icon="VIEWZOOM")
        if record.layer_search:
            cop = srow.operator("psd.clear_layer_search", text="", icon="X")
            cop.file_index = index

        # 内容比对进度
        if record.layer_list_scanning:
            prow = body.row(align=True)
            prow.label(text="比对内容改动中…", icon="TIME")
            prow.prop(record, "layer_list_scan_progress", text="", slider=True)

        # 追加条：有选中行时出现
        if sel_set:
            abar = body.row(align=True)
            aop = abar.operator(
                "psd.append_selected_layers", icon="ADD",
                text=f"追加为图层对象（{len(sel_set)} 个选中）",
            )
            aop.file_index = index

        # 图层列表（原生可滚控件 → 自带内部滚动条）
        body.template_list(
            "PSD_UL_CardLayers", f"psd_layers_{index}",
            record, "layer_items", record, "layer_active",
            rows=12,
        )
        if record.layer_search and not record.layer_items:
            body.label(text="没有匹配的图层", icon="INFO")

    def draw_file_buttons(self, row, index):
        # v3.10.0 起：追加导入 / 更改路径 已整编进卡片内嵌的「图层列表」，
        # 卡片外侧只保留这 4 个常用按钮。
        for op, icon in (
            ("psd.refresh_layers", "FILE_REFRESH"),
            ("psd.force_refresh_layers", "ERROR"),
            ("psd.toggle_texture_extension", "TEXTURE"),
            ("psd.toggle_blend_mode", "MATERIAL"),
        ):
            o = row.operator(op, text="", icon=icon, emboss=True)
            o.file_index = index
            row.separator(factor=0.2)

    def draw_selected_layer_buttons(self, row):
        operators = [
            ("psd.refresh_selected_layers", "FILE_REFRESH", "刷新选中图层"),
            ("psd.toggle_texture_extension_selected", "TEXTURE", "切换选中图层纹理外插方式"),
            ("psd.toggle_blend_mode_selected", "MATERIAL", "切换选中图层混合模式"),
        ]
        for op, icon, _ in operators:
            row.operator(op, text="", icon=icon, emboss=True)
            row.separator(factor=1.5)


# ---------------- 工具函数 ----------------






def process_layer_from_cache(
    context: Any,
    layer: Any,
    image_name: str,
    collection: Any,
    psd_width: int,
    psd_height: int,
    layer_index: int,
    cache_png: str,
    existing_obj: Any = None,
    is_new: bool = False,
    expected_checksum: Optional[str] = None,
    force: bool = False,
    force_suffix: bool = False,
    independent: bool = False,
    is_primary: bool = False,
    identifier: Optional[str] = None,
    pack: bool = True,
) -> Any:
    # 先创建/更新几何体，保证即使图像加载失败也能看到对象
    obj = create_or_update_mesh_object(
        context,
        existing_obj,
        image_name,
        collection,
        layer,
        psd_width,
        psd_height,
        layer_index,
        is_new,
        force_suffix=force_suffix,
        is_primary=is_primary,
        identifier=identifier,
    )
    # 「完全独立」模式（追加）：贴图名跟随**对象实际名**（唯一）→ 每次追加拿到独立的
    # image 数据块，不会和已有副本共用同一张贴图（问题4）。
    img_name_eff = image_name
    if independent and obj is not None:
        img_name_eff = f"{obj.name}_img"
    try:
        blender_image = load_or_update_image_from_cache(
            img_name_eff, cache_png, pack=pack, expected_checksum=expected_checksum,
            force=force, check_existing=not independent,
        )
        if is_new:
            update_material(obj, blender_image)
    except (AttributeError, TypeError, RuntimeError, OSError, IOError) as e:
        # 图像加载失败时，仍然保留对象，但记录警告
        print(f"[PSD导入警告] 图层 '{image_name}' 的图像或材质加载失败: {e}")
    return obj


def _unique_suffixed_name(base: str) -> str:
    """给对象基名加上数字后缀，返回第一个未被占用的名字（base.001 / base.002 ...）。
    用于追加导入：强制新对象带后缀，和已有对象一眼区分开。"""
    n = 1
    while bpy.data.objects.get(f"{base}.{n:03d}") is not None:
        n += 1
    return f"{base}.{n:03d}"


def create_or_update_mesh_object(
    context: Any,
    existing_obj: Any,
    image_name: str,
    collection: Any,
    layer: Any,
    psd_width: int,
    psd_height: int,
    layer_index: int,
    is_new: bool,
    force_suffix: bool = False,
    is_primary: bool = False,
    identifier: Optional[str] = None,
) -> Any:
    # 计算网格实际尺寸（保留 0.01 系数）
    mesh_scale = MESH_SCALE_FACTOR
    mesh_width = layer.width * mesh_scale
    mesh_height = layer.height * mesh_scale
    half_w = mesh_width / 2
    half_h = mesh_height / 2

    if existing_obj:
        # 更新现有对象：修改网格顶点而不是缩放
        mesh = existing_obj.data
        if mesh and len(mesh.vertices) >= 4:
            mesh.vertices[0].co = (-half_w, -half_h, 0.0)
            mesh.vertices[1].co = (-half_w, half_h, 0.0)
            mesh.vertices[2].co = (half_w, half_h, 0.0)
            mesh.vertices[3].co = (half_w, -half_h, 0.0)
            mesh.update()

        # 缩放保持为 (1, 1, 1)
        existing_obj.scale = (1, 1, 1)

        # 确保旧对象存在标准UV，避免显示为单色
        try:
            if mesh and not mesh.uv_layers:
                uv_layer = mesh.uv_layers.new(name="UVMap")
                if len(uv_layer.data) >= 4:
                    # 旧对象沿用旧 face winding (0,1,2,3)，UV 顺序保持原样
                    uv_layer.data[0].uv = UV_BOTTOM_LEFT
                    uv_layer.data[1].uv = UV_TOP_LEFT
                    uv_layer.data[2].uv = UV_TOP_RIGHT
                    uv_layer.data[3].uv = UV_BOTTOM_RIGHT
        except (AttributeError, TypeError, RuntimeError):
            pass
        # 刷新初始变换并立即应用位置/旋转/缩放
        update_initial_transform(
            existing_obj, layer, psd_width, psd_height, layer_index
        )
        set_object_transform(existing_obj, layer, psd_width, psd_height, layer_index)
        return existing_obj

    # 纯数据方式创建平面，避免依赖操作符上下文
    # 顶点基于实际尺寸计算
    mesh = bpy.data.meshes.new(name=f"{image_name}_mesh")
    verts = [
        (-half_w, -half_h, 0.0),
        (-half_w, half_h, 0.0),
        (half_w, half_h, 0.0),
        (half_w, -half_h, 0.0),
    ]
    faces = [(0, 3, 2, 1)]  # 从 +Z 俯视顺时针，法线指向 -Z（朝向默认相机）
    mesh.from_pydata(verts, [], faces)
    mesh.update()

    # 创建标准UV映射，确保图像正确显示
    try:
        uv_layer = mesh.uv_layers.new(name="UVMap")
        uv_data = uv_layer.data
        # 单个四边形的4个loop，顺序与faces一致
        if len(uv_data) >= 4:
            # UV 顺序跟随 face winding (0,3,2,1)
            uv_data[0].uv = UV_BOTTOM_LEFT    # vertex 0: 左下
            uv_data[1].uv = UV_BOTTOM_RIGHT   # vertex 3: 右下
            uv_data[2].uv = UV_TOP_RIGHT      # vertex 2: 右上
            uv_data[3].uv = UV_TOP_LEFT       # vertex 1: 左上
    except (AttributeError, TypeError, RuntimeError):
        pass

    obj_name = f"{image_name}_object"
    if force_suffix:
        # 追加导入：强制带 .NNN 后缀（首次导入不受影响）
        obj_name = _unique_suffixed_name(obj_name)
    obj = bpy.data.objects.new(obj_name, mesh)
    # 链接到目标集合并确保在场景中
    if collection is not None:
        collection.objects.link(obj)
    else:
        context.scene.collection.objects.link(obj)

    set_object_transform(obj, layer, psd_width, psd_height, layer_index)
    # 用调用方传入的 identifier（与「勾选过滤」「checksum」同一真源），保证三处一致；
    # 未传时才回退本地重算（必须带 display_index，否则缺 layer_id 的 PSD 会得到 -1）
    obj[ATTR_LAYER_ID] = identifier if identifier else create_layer_identifier(layer, layer_index)
    # 首次导入的「原始对象」打标记：追加产生的副本不打。
    # 行尾 ✕ 删除时凭它认出原始那份，避免误删追加副本。
    if is_primary:
        try:
            obj[ATTR_LAYER_PRIMARY] = True
        except Exception:
            pass
    # 存储图层边界信息，用于UV调整计算
    obj[ATTR_LAYER_BBOX] = {
        "left": layer.left,
        "top": layer.top,
        "width": layer.width,
        "height": layer.height,
    }
    return obj


def update_initial_transform(
    obj: Any, layer: Any, psd_width: int, psd_height: int, layer_index: int
) -> None:
    """写入「PSD 原始相对位置」记录（obj["initial_transform"]）。

    构图基准的权威来源：位置按【画布像素相对画布中心】换算，
    与用户后续的任何移动无关；z 是导入时的层序（layer_index * LAYER_Z_OFFSET）。

    消费方：match_layers_to_camera（匹配至相机以此还原 PSD 原始构图）。
    写方：仅"导入 / 刷新图层"；视差锁定等操作只读不写。
    """
    mesh_scale = MESH_SCALE_FACTOR
    # 初始缩放改为 (1, 1, 1)，尺寸由网格顶点控制
    initial_scale = (1, 1, 1)

    center_x = layer.left + layer.width / 2
    center_y = layer.top + layer.height / 2

    x = (center_x - psd_width / 2) * mesh_scale
    y = (psd_height / 2 - center_y) * mesh_scale
    z = layer_index * LAYER_Z_OFFSET

    initial_location = (x, y, z)
    initial_rotation = (0, 0, 0)

    obj[ATTR_INITIAL_TRANSFORM] = {
        "scale": initial_scale,
        "location": initial_location,
        "rotation": initial_rotation,
    }


def set_object_transform(
    obj: Any, layer: Any, psd_width: int, psd_height: int, layer_index: int
) -> None:
    update_initial_transform(obj, layer, psd_width, psd_height, layer_index)
    # 强制设置为 (1, 1, 1)，尺寸由网格顶点控制
    obj.scale = (1, 1, 1)
    obj.location = obj[ATTR_INITIAL_TRANSFORM]["location"]
    obj.rotation_euler = obj[ATTR_INITIAL_TRANSFORM]["rotation"]


def update_material(obj: Any, blender_image: Any) -> None:
    mat_name = f"{obj.name}_material"
    mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    setup_material_nodes(mat, blender_image)


def setup_material_nodes(mat: Any, blender_image: Any) -> None:
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    texture_node = nodes.new("ShaderNodeTexImage")
    mix_shader = nodes.new("ShaderNodeMixShader")
    transparent_bsdf = nodes.new("ShaderNodeBsdfTransparent")
    emission_shader = nodes.new("ShaderNodeEmission")
    output_node = nodes.new("ShaderNodeOutputMaterial")

    texture_node.location = (-600, 0)
    emission_shader.location = (-300, 100)
    transparent_bsdf.location = (-300, -100)
    mix_shader.location = (0, 0)
    output_node.location = (300, 0)

    texture_node.image = blender_image
    # 对常规颜色图层使用sRGB，避免全图发灰或单色
    if hasattr(texture_node, "image_user"):
        pass
    try:
        texture_node.colorspace_settings.name = "sRGB"
    except (AttributeError, TypeError, RuntimeError):
        try:
            if hasattr(texture_node, "color_space"):
                texture_node.color_space = "sRGB"
        except (AttributeError, TypeError, RuntimeError):
            pass

    links.new(texture_node.outputs["Color"], emission_shader.inputs["Color"])
    links.new(emission_shader.outputs["Emission"], mix_shader.inputs[2])
    # 某些PSD层可能没有Alpha通道，连接前做保护
    try:
        links.new(texture_node.outputs["Alpha"], mix_shader.inputs[0])
    except (AttributeError, KeyError, TypeError, RuntimeError):
        mix_shader.inputs[0].default_value = DEFAULT_ALPHA
    links.new(transparent_bsdf.outputs["BSDF"], mix_shader.inputs[1])
    links.new(mix_shader.outputs["Shader"], output_node.inputs["Surface"])

    mat.blend_method = "BLEND"
    mat.use_backface_culling = False
    emission_shader.inputs["Strength"].default_value = 1.0


def calculate_adjusted_uv(
    obj: Any, layer: Any
) -> Optional[Tuple[float, float, float, float]]:
    """
    计算调整后的UV坐标，使旧内容区域在新贴图中正确显示

    当只更新贴图而不更新网格时，新旧图层可能尺寸/位置不同，
    需要通过调整UV使旧网格区域正确采样新贴图中对应的内容区域。

    Returns:
        tuple: (u_min, v_min, u_max, v_max) 或 None（无需调整时）
    """
    obj_name = obj.name if obj is not None else "(None)"
    old_bbox = obj.get(ATTR_LAYER_BBOX) if obj is not None else None
    if not old_bbox:
        _psd_log(f"[PSD-UV] {obj_name}: 无旧bbox(ATTR_LAYER_BBOX)记录 → 无需调整返回None")
        return None

    # 旧图层（上次同步）的画布位置与尺寸
    old_left = old_bbox.get("left", layer.left)
    old_top = old_bbox.get("top", layer.top)
    old_width = old_bbox.get("width", layer.width)
    old_height = old_bbox.get("height", layer.height)

    # 新图层（本次PSD读取）的画布位置与尺寸
    new_left, new_top = layer.left, layer.top
    new_width, new_height = layer.width, layer.height

    _psd_log(
        f"[PSD-UV] {obj_name}: 旧bbox=({old_left},{old_top},{old_width}x{old_height}) "
        f"新bbox=({new_left},{new_top},{new_width}x{new_height})"
    )

    # 避免除以零
    if new_width <= 0 or new_height <= 0:
        _psd_log(f"[PSD-UV] {obj_name}: 新bbox尺寸非正({new_width}x{new_height}) → 无需调整返回None")
        return None

    # 尺寸和位置都没变，无需调整
    if (
        old_left == new_left
        and old_top == new_top
        and old_width == new_width
        and old_height == new_height
    ):
        _psd_log(f"[PSD-UV] {obj_name}: 新旧bbox完全一致 → 无需调整返回None")
        return None

    # 计算UV坐标
    # u方向：旧图层区域在新贴图中的水平位置
    u_min = (old_left - new_left) / new_width
    u_max = u_min + (old_width / new_width)

    # v方向：需要考虑UV坐标系（原点在左下）与图层坐标系（原点在左上）的转换
    v_max = (new_top + new_height - old_top) / new_height
    v_min = v_max - (old_height / new_height)

    # scale/offset 供节点组使用
    scale_x = u_max - u_min
    scale_y = v_max - v_min
    offset_x = u_min
    offset_y = v_min

    # 记录可疑范围：UV 缩放/偏移超出正常范围(0~1)时提示，可能是换算出错
    if scale_x < 0 or scale_y < 0 or scale_x > 3 or scale_y > 3:
        _psd_log(
            f"[PSD-UV] {obj_name}: !! scale/offset 超出常见范围 "
            f"scale=({scale_x:.4f},{scale_y:.4f}) offset=({offset_x:.4f},{offset_y:.4f}) "
            f"u=({u_min:.4f},{u_max:.4f}) v=({v_min:.4f},{v_max:.4f}) → 疑似换算出错/内容布局异常"
        )

    _psd_log(
        f"[PSD-UV] {obj_name}: 计算结果 u=({u_min:.4f},{u_max:.4f}) v=({v_min:.4f},{v_max:.4f}) "
        f"→ scale=({scale_x:.4f},{scale_y:.4f}) offset=({offset_x:.4f},{offset_y:.4f})"
    )
    return (u_min, v_min, u_max, v_max)



def create_uv_adjustment_nodegroup(
    name: str, scale_x: float, scale_y: float, offset_x: float, offset_y: float
) -> Any:
    """
    创建UV调整节点组
    内部结构：UV输入 → Multiply(缩放) → Add(偏移) → Vector输出

    Args:
        name: 节点组名称
        scale_x, scale_y: UV缩放参数
        offset_x, offset_y: UV偏移参数

    Returns:
        节点组对象
    """
    # 检查是否已存在同名节点组，存在则更新参数
    ng = bpy.data.node_groups.get(name)
    if ng is None:
        ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    else:
        # 清除现有节点重新创建
        ng.nodes.clear()

    nodes = ng.nodes
    links = ng.links

    # 创建输入输出接口
    # Blender 4.0+ 使用 interface，旧版本使用 inputs/outputs
    try:
        # Blender 4.0+
        if not ng.interface.items_tree.get("Vector"):
            ng.interface.new_socket(
                name="Vector", in_out="INPUT", socket_type="NodeSocketVector"
            )
        if (
            not ng.interface.items_tree.get("Vector", None)
            or len([i for i in ng.interface.items_tree if i.name == "Vector"]) < 2
        ):
            ng.interface.new_socket(
                name="Vector", in_out="OUTPUT", socket_type="NodeSocketVector"
            )
    except AttributeError:
        # Blender 3.x
        if not ng.inputs.get("Vector"):
            ng.inputs.new("NodeSocketVector", "Vector")
        if not ng.outputs.get("Vector"):
            ng.outputs.new("NodeSocketVector", "Vector")

    # 创建节点
    group_input = nodes.new("NodeGroupInput")
    group_input.location = (-400, 0)

    group_output = nodes.new("NodeGroupOutput")
    group_output.location = (400, 0)

    # Separate XYZ - 分离UV分量
    separate_xyz = nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.location = (-200, 0)

    # Multiply X (缩放U)
    multiply_x = nodes.new("ShaderNodeMath")
    multiply_x.operation = "MULTIPLY"
    multiply_x.location = (0, 100)
    multiply_x.inputs[1].default_value = scale_x

    # Multiply Y (缩放V)
    multiply_y = nodes.new("ShaderNodeMath")
    multiply_y.operation = "MULTIPLY"
    multiply_y.location = (0, -100)
    multiply_y.inputs[1].default_value = scale_y

    # Add X (偏移U)
    add_x = nodes.new("ShaderNodeMath")
    add_x.operation = "ADD"
    add_x.location = (150, 100)
    add_x.inputs[1].default_value = offset_x

    # Add Y (偏移V)
    add_y = nodes.new("ShaderNodeMath")
    add_y.operation = "ADD"
    add_y.location = (150, -100)
    add_y.inputs[1].default_value = offset_y

    # Combine XYZ - 合并UV分量
    combine_xyz = nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.location = (300, 0)

    # 连接节点
    links.new(group_input.outputs[0], separate_xyz.inputs[0])
    links.new(separate_xyz.outputs["X"], multiply_x.inputs[0])
    links.new(separate_xyz.outputs["Y"], multiply_y.inputs[0])
    links.new(multiply_x.outputs[0], add_x.inputs[0])
    links.new(multiply_y.outputs[0], add_y.inputs[0])
    links.new(add_x.outputs[0], combine_xyz.inputs["X"])
    links.new(add_y.outputs[0], combine_xyz.inputs["Y"])
    links.new(combine_xyz.outputs[0], group_output.inputs[0])

    return ng


def apply_uv_adjustment_to_material(
    mat: Any,
    scale_x: float,
    scale_y: float,
    offset_x: float,
    offset_y: float,
    nodegroup_name: str,
) -> None:
    """
    在材质中插入UV调整节点组
    智能检测现有连接：
    - 如果 Image Texture.Vector 已有连接，在现有连接链中插入节点组
    - 如果无连接，创建 Texture Coordinate 节点并连接

    Args:
        mat: 材质对象
        scale_x, scale_y: UV缩放参数
        offset_x, offset_y: UV偏移参数
        nodegroup_name: 节点组名称
    """
    if not mat or not mat.use_nodes:
        _psd_log(f"[PSD-材质] apply_uv_adjustment: 跳过(无材质或无节点)")
        return

    _psd_log(f"[PSD-材质] >> apply_uv_adjustment: nodegroup='{nodegroup_name}', scale=({scale_x:.4f},{scale_y:.4f}), offset=({offset_x:.4f},{offset_y:.4f})")

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # 查找 Image Texture 节点
    texture_node = None
    for node in nodes:
        if node.type == "TEX_IMAGE":
            texture_node = node
            break

    if not texture_node:
        _psd_log(f"[PSD-材质] apply_uv_adjustment: 跳过(无TEX_IMAGE节点)")
        return

    # 检查是否已存在UV调整节点组实例（本插件创建的）
    existing_uv_group = None
    for node in nodes:
        if (
            node.type == "GROUP"
            and node.node_tree
            and node.node_tree.name == nodegroup_name
        ):
            existing_uv_group = node
            break

    # 检查 Image Texture.Vector 是否已有连接
    existing_source_node = None
    existing_source_socket = None
    for link in links:
        if link.to_node == texture_node and link.to_socket.name == "Vector":
            # 如果连接来自我们的UV更新节点组，需要找到更上游的连接
            if link.from_node == existing_uv_group:
                # 查找UV更新节点组的输入连接
                for inner_link in links:
                    if (
                        inner_link.to_node == existing_uv_group
                        and inner_link.to_socket == existing_uv_group.inputs[0]
                    ):
                        existing_source_node = inner_link.from_node
                        existing_source_socket = inner_link.from_socket
                        break
            else:
                existing_source_node = link.from_node
                existing_source_socket = link.from_socket
            break

    # 创建或更新节点组
    ng = create_uv_adjustment_nodegroup(
        nodegroup_name, scale_x, scale_y, offset_x, offset_y
    )

    if existing_uv_group is None:
        group_node = nodes.new("ShaderNodeGroup")
        group_node.location = (texture_node.location.x - 150, texture_node.location.y)
    else:
        group_node = existing_uv_group

    group_node.node_tree = ng
    group_node.label = nodegroup_name

    # 断开 Image Texture.Vector 的现有连接
    for link in list(links):
        if link.to_node == texture_node and link.to_socket.name == "Vector":
            links.remove(link)

    # 根据是否有现有连接来决定输入源
    if existing_source_node and existing_source_socket:
        # 有现有连接：插入到现有连接链中
        # 断开节点组输入的旧连接
        for link in list(links):
            if link.to_node == group_node and link.to_socket == group_node.inputs[0]:
                links.remove(link)
        # 连接：现有源节点 → UV更新节点组
        links.new(existing_source_socket, group_node.inputs[0])
    else:
        # 无现有连接：创建或获取 Texture Coordinate 节点
        tex_coord = None
        for node in nodes:
            if node.type == "TEX_COORD":
                tex_coord = node
                break
        if tex_coord is None:
            tex_coord = nodes.new("ShaderNodeTexCoord")
            tex_coord.location = (
                texture_node.location.x - 300,
                texture_node.location.y,
            )
            # 标记这个节点是插件创建的，方便后续清理
            tex_coord["psd_plugin_created"] = True
        # 连接：Texture Coordinate.UV → UV更新节点组
        links.new(tex_coord.outputs["UV"], group_node.inputs[0])

    # 连接：UV更新节点组 → Image Texture.Vector
    links.new(group_node.outputs[0], texture_node.inputs["Vector"])
    _psd_log(f"[PSD-材质] apply_uv_adjustment 完成: 源={'外部连接(' + existing_source_node.name + ')' if existing_source_node else '新建TexCoord'}, 目标=TEX_IMAGE.Vector")


def remove_uv_adjustment_from_material(
    mat: Any, nodegroup_name: Optional[str] = None
) -> None:
    """
    从材质中移除UV调整节点组，恢复原有连接

    智能恢复：
    - 记录UV更新节点组的输入连接（来源节点）
    - 移除节点组后，恢复原来的连接：源节点 → Image Texture.Vector
    - 只删除插件创建的 Texture Coordinate 节点

    Args:
        mat: 材质对象
        nodegroup_name: 节点组名称（可选，不指定则移除所有UV调整节点组）
    """
    if not mat or not mat.use_nodes:
        _psd_log(f"[PSD-材质] remove_uv_adjustment: 跳过(无材质或无节点)")
        return

    _psd_log(f"[PSD-材质] >> remove_uv_adjustment: mat='{mat.name}', nodegroup='{nodegroup_name if nodegroup_name else '(所有UV更新_xxx)'}'")

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # 查找 Image Texture 节点
    texture_node = None
    for node in nodes:
        if node.type == "TEX_IMAGE":
            texture_node = node
            break

    if not texture_node:
        return

    # 查找 UV调整节点组实例，并记录其输入连接
    nodes_to_remove = []
    restore_source_node = None
    restore_source_socket = None

    for node in nodes:
        if node.type == "GROUP" and node.node_tree:
            if nodegroup_name is None or node.node_tree.name == nodegroup_name:
                if node.node_tree.name.startswith("UV更新_"):
                    # 记录这个节点组的输入连接（用于恢复）
                    for link in links:
                        if link.to_node == node and link.to_socket == node.inputs[0]:
                            restore_source_node = link.from_node
                            restore_source_socket = link.from_socket
                            break
                    nodes_to_remove.append(node)

    # 如果没有找到UV更新节点组，直接返回
    if not nodes_to_remove:
        return

    # 查找插件创建的 Texture Coordinate 节点（有标记的才删除）
    tex_coord_to_remove = None
    if restore_source_node and restore_source_node.type == "TEX_COORD":
        if restore_source_node.get("psd_plugin_created"):
            tex_coord_to_remove = restore_source_node
            restore_source_node = None  # 不恢复连接，因为源节点也要删除
            restore_source_socket = None

    # 断开 Image Texture.Vector 的现有连接
    for link in list(links):
        if link.to_node == texture_node and link.to_socket.name == "Vector":
            links.remove(link)

    # 删除节点
    for node in nodes_to_remove:
        # 断开节点的所有连接
        for link in list(links):
            if link.from_node == node or link.to_node == node:
                links.remove(link)
        # 删除节点组数据
        ng_name = node.node_tree.name if node.node_tree else None
        nodes.remove(node)
        # 清理未使用的节点组数据
        if ng_name:
            ng = bpy.data.node_groups.get(ng_name)
            if ng and ng.users == 0:
                bpy.data.node_groups.remove(ng)

    # 删除插件创建的 Texture Coordinate 节点
    if tex_coord_to_remove:
        nodes.remove(tex_coord_to_remove)

    # 恢复原有连接：源节点 → Image Texture.Vector
    if restore_source_node and restore_source_socket:
        links.new(restore_source_socket, texture_node.inputs["Vector"])


def update_existing_layer_object(
    context: Any,
    obj: Any,
    layer: Any,
    psd_width: int,
    psd_height: int,
    layer_index: int,
    update_texture: bool,
    update_mesh: bool,
    update_transform: bool,
    cache_png: Optional[str] = None,
    expected_checksum: Optional[str] = None,
    collection: Any = None,
    force: bool = False,
    pack: bool = True,
) -> None:
    """
    根据控制选项更新现有图层对象

    Args:
        context: Blender上下文
        obj: 要更新的对象
        layer: PSD图层数据
        psd_width, psd_height: PSD画布尺寸
        layer_index: 图层索引
        update_texture: 是否更新贴图
        update_mesh: 是否更新网格
        update_transform: 是否更新变换
        cache_png: 缓存PNG路径（update_texture=True时需要）
        expected_checksum: 预期校验和（update_texture=True时需要）
        collection: 集合（备用）
    """
    # 更新贴图
    if update_texture and cache_png:
        try:
            image_name = obj.name.replace("_object", "")
            _psd_log(f"[PSD-图像] 更新贴图: obj='{obj.name}' → image='{image_name}'")
            blender_image = load_or_update_image_from_cache(
                image_name, cache_png, pack=pack, expected_checksum=expected_checksum,
                force=force,
            )
        except (AttributeError, TypeError, RuntimeError) as e:
            _psd_log(f"[PSD图像更新] 异常: '{obj.name}' → {e}")

    # UV调整逻辑：只更新贴图而不更新网格时，通过材质节点组调整UV
    if update_texture and not update_mesh:
        _psd_log(f"[PSD-UV] {obj.name}: 进入UV调整分支 (只更新贴图, 不更新网格)")
        # 防御：对比 mesh 实际尺寸 vs bbox 记录尺寸，判断网格是否被手动改过
        try:
            mesh_w = mesh_height = None
            mesh = obj.data
            if mesh and len(mesh.vertices) >= 4:
                # 网格顶点尺寸(单位为Blender单位，*1/MESH_SCALE_FACTOR 还原为像素)
                vs = mesh.vertices
                min_x = min(v.co.x for v in vs)
                max_x = max(v.co.x for v in vs)
                min_y = min(v.co.y for v in vs)
                max_y = max(v.co.y for v in vs)
                mesh_w = (max_x - min_x) / MESH_SCALE_FACTOR
                mesh_h = (max_y - min_y) / MESH_SCALE_FACTOR
            old_bbox = obj.get(ATTR_LAYER_BBOX)
            if mesh_w is not None and old_bbox:
                bbox_w = old_bbox.get("width")
                bbox_h = old_bbox.get("height")
                tol = 1.0  # 像素容差
                if bbox_w and bbox_h and (
                    abs(mesh_w - bbox_w) > tol or abs(mesh_h - bbox_h) > tol
                ):
                    _psd_log(
                        f"[PSD-UV] {obj.name}: !! 网格尺寸与bbox记录不一致 "
                        f"网格={mesh_w:.1f}x{mesh_h:.1f}px, bbox={bbox_w}x{bbox_h}px "
                        f"→ 疑似网格被手动修改, UV校正基准不可靠"
                    )
        except Exception as e:
            _psd_log(f"[PSD-UV] {obj.name}: 网格尺寸校验异常: {type(e).__name__}: {e}")

        uv_coords = calculate_adjusted_uv(obj, layer)
        mat = obj.data.materials[0] if obj.data.materials else None

        if uv_coords:
            u_min, v_min, u_max, v_max = uv_coords
            # 转换为缩放和偏移参数
            scale_x = u_max - u_min
            scale_y = v_max - v_min
            offset_x = u_min
            offset_y = v_min

            # 生成节点组名称（简化命名：序号_PSD文件名前缀）
            # 对象名格式：{序号}_{PSD文件名}_{图层名}_object
            name_parts = obj.name.replace("_object", "").split("_")
            # 取序号和PSD文件名的第一部分，避免名称过长
            short_name = (
                "_".join(name_parts[:2]) if len(name_parts) >= 2 else name_parts[0]
            )
            nodegroup_name = f"UV更新_{short_name}"

            # 获取对象材质并应用UV调整节点组
            if mat:
                _psd_log(
                    f"[PSD-UV] {obj.name}: 应用UV调整 scale=({scale_x:.4f},{scale_y:.4f}) "
                    f"offset=({offset_x:.4f},{offset_y:.4f}) nodegroup='{nodegroup_name}'"
                )
                apply_uv_adjustment_to_material(
                    mat, scale_x, scale_y, offset_x, offset_y, nodegroup_name
                )
            else:
                _psd_log(f"[PSD-UV] {obj.name}: 无材质, 无法应用UV调整")
        else:
            # 新旧尺寸一致，不需要UV调整，移除现有的UV调整节点组（如果存在）
            if mat:
                _psd_log(f"[PSD-UV] {obj.name}: 新旧一致, 移除UV调整节点组")
                remove_uv_adjustment_from_material(mat)
            else:
                _psd_log(f"[PSD-UV] {obj.name}: 新旧一致, 无材质可清理")

    # 记录旧的初始变换（用于保持相对位置）
    old_initial_location = None
    current_location = None
    if update_mesh and not update_transform:
        # 需要保持相对位置时，先记录旧的初始位置和当前位置
        if ATTR_INITIAL_TRANSFORM in obj:
            try:
                old_initial_location = mathutils.Vector(
                    obj[ATTR_INITIAL_TRANSFORM]["location"]
                )
                current_location = obj.location.copy()
            except (KeyError, ValueError, TypeError):
                pass

    # 更新网格顶点
    if update_mesh:
        try:
            mesh = obj.data
            if mesh and len(mesh.vertices) >= 4:
                mesh_scale = MESH_SCALE_FACTOR
                mesh_width = layer.width * mesh_scale
                mesh_height = layer.height * mesh_scale
                half_w = mesh_width / 2
                half_h = mesh_height / 2
                mesh.vertices[0].co = (-half_w, -half_h, 0.0)
                mesh.vertices[1].co = (-half_w, half_h, 0.0)
                mesh.vertices[2].co = (half_w, half_h, 0.0)
                mesh.vertices[3].co = (half_w, -half_h, 0.0)
                mesh.update()
        except (AttributeError, TypeError, RuntimeError):
            pass

        # 更新网格时，移除UV调整节点组（恢复默认状态）
        mat = obj.data.materials[0] if obj.data.materials else None
        if mat:
            remove_uv_adjustment_from_material(mat)

        # 更新网格时同步更新 layer_bbox
        obj[ATTR_LAYER_BBOX] = {
            "left": layer.left,
            "top": layer.top,
            "width": layer.width,
            "height": layer.height,
        }

    # 始终更新 initial_transform 记录 —— 它是「PSD 原始相对位置」的权威记录：
    #   · 「匹配至相机」以它为构图基准（用户手改位置后仍能还原 PSD 原始构图）
    #   · 视差锁定 / 相机适配 / 解锁全程【只读不写】，所以它始终稳定、不被污染
    #   · 只有「导入 / 刷新图层」会重写它（用 PSD 原始数据重写，不是用户当前位置）
    update_initial_transform(obj, layer, psd_width, psd_height, layer_index)

    # 处理变换更新
    if update_transform:
        # 完全重置变换
        set_object_transform(obj, layer, psd_width, psd_height, layer_index)
    elif (
        update_mesh
        and old_initial_location is not None
        and current_location is not None
    ):
        # 更新了网格但不更新变换：保持相对位置
        try:
            # 计算用户的位置偏移量（相对于旧的图层中心）
            offset = current_location - old_initial_location
            # 应用偏移到新的初始位置
            new_initial_location = mathutils.Vector(
                obj[ATTR_INITIAL_TRANSFORM]["location"]
            )
            obj.location = new_initial_location + offset
        except (AttributeError, TypeError, RuntimeError):
            pass

    # === 材质完整性诊断（只读，不改任何数据）===
    try:
        _psd_log(f"[PSD-材质] >> 材质诊断: obj='{obj.name}'")
        mat = obj.data.materials[0] if obj.data.materials else None
        if mat is None:
            _psd_log(f"[PSD-材质] 对象无材质: obj='{obj.name}'")
        else:
            _psd_log(f"[PSD-材质] 材质存在: mat='{mat.name}', use_nodes={mat.use_nodes}")
            if mat.use_nodes and mat.node_tree:
                node_count = len(mat.node_tree.nodes)
                tex_nodes = [n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE']
                _psd_log(f"[PSD-材质] 节点树: {node_count}个节点, {len(tex_nodes)}个TEX_IMAGE")
                for tn in tex_nodes:
                    img_ref = tn.image.name if tn.image else '(无)'
                    _psd_log(f"[PSD-材质] TEX_IMAGE节点: label='{tn.label}', image='{img_ref}'")
                if update_texture and cache_png:
                    image_name = obj.name.replace("_object", "")
                    updated_img = bpy.data.images.get(image_name)
                    if updated_img and tex_nodes:
                        for tn in tex_nodes:
                            if tn.image and tn.image != updated_img:
                                _psd_log(f"[PSD-材质] 图像引用不一致: 纹理节点='{tn.image.name}', 本次更新='{updated_img.name}'")
                            elif tn.image and tn.image == updated_img:
                                _psd_log(f"[PSD-材质] 图像引用一致: '{tn.image.name}'")
                uv_groups = [n for n in mat.node_tree.nodes if n.type == 'GROUP' and n.node_tree and n.node_tree.name.startswith(UV_ADJUST_NODEGROUP_PREFIX)]
                if uv_groups:
                    _psd_log(f"[PSD-材质] UV调整节点组存在: {[ng.node_tree.name for ng in uv_groups]}")
                else:
                    _psd_log(f"[PSD-材质] 无UV调整节点组")
            else:
                _psd_log(f"[PSD-材质] 材质无节点树或use_nodes=False")
    except Exception as e:
        _psd_log(f"[PSD-异常] 材质诊断异常: obj='{obj.name}', 异常={type(e).__name__}: {e}")


# ---------------- 图层选择导入（弹窗）----------------


def _collect_imported_ids(record):
    """从该 PSD 的集合树里收集已导入图层的 identifier（对象身上的 layer_identifier）。"""
    ids = set()
    try:
        col = get_collection_from_record(record) if record is not None else None
        if col is None and record is not None and record.filepath:
            base = bpy.path.display_name_from_filepath(record.filepath)
            col = bpy.data.collections.get(base)
        if col is not None:
            for obj in get_all_objects_recursive(col):
                v = obj.get(ATTR_LAYER_ID)
                if v:
                    ids.add(v)
    except Exception as ex:
        # 失败会让追加弹窗把所有层都当"新增"（默认全勾），必须留痕
        _psd_log(f"[PSD-比对] 收集已导入 identifier 失败: {type(ex).__name__}: {ex}")
    return ids


# ---- 图层选择：后台内容比对（追加导入时高亮"内容改过"的图层）----

# ---- 卡片图层列表：重新扫描后的内容比对（复用 _AnalyzeWorker）----

# 每个卡片的「重新扫描」各占一个槽（key=file_index），支持多张卡片同时比对。
# 旧版是单槽：第二张卡一扫描就覆盖第一张的队列 → 第一张永远卡在"比对中"、
# "已改"标记永远写不回去（P0-2）。
_card_scan_locks = {}


def _card_scan_tick():
    """主线程消费各卡片重新扫描的结果，把「已改」写回 record.layer_list_json。

    支持多张卡片并行比对：遍历所有活跃槽，各自消费自己的队列。
    """
    if not _card_scan_locks:
        return None
    scene = getattr(bpy.context, "scene", None)
    tool = getattr(scene, "psd_import_tool", None) if scene is not None else None
    if tool is None:
        _card_scan_locks.clear()
        return None
    any_active = False
    for fi in list(_card_scan_locks.keys()):
        lock = _card_scan_locks.get(fi)
        q = lock.get("queue") if lock else None
        if q is None or not (0 <= fi < len(tool.file_records)):
            _card_scan_locks.pop(fi, None)
            continue
        rec = tool.file_records[fi]
        done = False
        changed = set()
        while True:
            try:
                msg = q.get_nowait()
            except queue.Empty:
                break
            t = msg.get("type")
            if t == "item":
                if msg.get("changed"):
                    changed.add(msg.get("identifier"))
            elif t == "progress":
                total = max(1, int(msg.get("total", 1) or 1))
                rec.layer_list_scan_progress = min(1.0, int(msg.get("done", 0)) / total)
            elif t == "done":
                done = True
        if changed:
            try:
                items = parse_layer_list_json(rec.layer_list_json)
                for it in items:
                    if it["i"] in changed:
                        it["m"] = "已改"
                rec.layer_list_json = json.dumps(items, ensure_ascii=False)
            except Exception as ex:
                _psd_log(f"[PSD-列表] 写回内容改动标记失败: {type(ex).__name__}: {ex}")
        if done:
            rec.layer_list_scanning = False
            rec.layer_list_scan_progress = 1.0
            try:
                _rebuild_layer_items(rec, fi)   # 让「已改」标记立刻显示
            except Exception:
                pass
            _card_scan_locks.pop(fi, None)
        else:
            any_active = True
    return 0.2 if any_active else None


_analysis_lock = {"queue": None, "timer": False, "gen": 0}


class PSD_PT_Settings(Panel):
    """全局设置（默认折叠）：刷新选项 + 隐藏层开关。

    刷新选项原先是每张 PSD 卡片各一份，v3.11.0 起收归这里全局统管。
    """
    bl_label = "⚙ 设置"
    bl_idname = "PSD_PT_Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "PSD图层导入工具"
    bl_parent_id = "PSD_PT_ImportPanel"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        tool = context.scene.psd_import_tool

        # 布局原则：**说明一律走属性的 description（鼠标悬停可见），面板上不再外显**。
        # 早前每项下面挂一行说明，还要用空 label 凑缩进 —— 又长又不齐，还和 tooltip 重复。
        # 三个刷新开关各自独立（曾排成一排 toggle，看着像"三选一"，已改回纵向勾选）。

        # ---- ① 刷新时更新什么 ----
        box = layout.box()
        box.label(text="刷新时更新什么", icon="FILE_REFRESH")
        box.prop(tool, "refresh_update_texture", text="贴图")
        box.prop(tool, "refresh_update_mesh", text="网格")
        box.prop(tool, "refresh_update_structure", text="结构")

        # ---- ② 扫描 / 导入 ----
        box = layout.box()
        box.label(text="扫描 / 导入", icon="FILE_FOLDER")
        box.prop(tool, "include_hidden_layers", text="包含隐藏图层和文件夹")

        # ---- ③ 性能 / 存储 ----
        box = layout.box()
        box.label(text="性能 / 存储", icon="IMAGE_DATA")
        box.prop(tool, "png_compress_level")
        box.prop(tool, "texture_store_mode")


class _AnalyzeWorker(threading.Thread):
    """后台线程：逐层渲染 + 指纹，与旧 checksum 比对，判定内容是否变化。不碰 bpy。"""

    def __init__(self, entries, old_checksums, out_queue, gen=0):
        super().__init__(daemon=True)
        self.entries = entries        # [{"identifier", "layer", "old"}]
        self.old = old_checksums      # 兼容参数（已改由 entry["old"] 提供）
        self.out_queue = out_queue
        self.gen = gen

    def run(self):
        total = len(self.entries)
        try:
            for i, e in enumerate(self.entries):
                changed = False
                try:
                    layer = e["layer"]
                    img = render_layer_rgba(layer)
                    pixel_hash = compute_image_md5(img) or ""
                    l, t, r, b = _get_layer_bbox(layer)
                    meta = hashlib.md5(f"{layer.name}{l}{t}{r}{b}".encode()).hexdigest()
                    cur = f"{meta}_{pixel_hash}" if (meta and pixel_hash) else ""
                    old = e.get("old", "")
                    if old and cur and old != cur:
                        changed = True
                except Exception as ex:
                    _psd_log(f"[PSD-比对] 图层比对失败 identifier={e.get('identifier')!r}: {type(ex).__name__}: {ex}")
                self.out_queue.put({"type": "item", "identifier": e["identifier"],
                                    "changed": changed, "gen": self.gen})
                if i % 3 == 2 or i == total - 1:
                    self.out_queue.put({"type": "progress", "done": i + 1, "total": total})
        except Exception as ex:
            _psd_log(f"[PSD-比对] 后台比对线程异常: {type(ex).__name__}: {ex}")
        self.out_queue.put({"type": "done", "gen": self.gen})


def _start_content_analysis(psd_tool, entries, old_checksums):
    """启动后台内容比对；结果由 _analysis_tick 在主线程消费。"""
    q = queue.Queue()
    _analysis_lock["queue"] = q
    gen = _analysis_lock.get("gen", 0)
    _AnalyzeWorker(entries, old_checksums, q, gen).start()
    psd_tool.pending_analysis_active = True
    psd_tool.pending_analysis_progress = 0.0
    psd_tool.pending_analysis_status = "比对内容改动中…"
    if not _analysis_lock.get("timer"):
        _analysis_lock["timer"] = True
        bpy.app.timers.register(_analysis_tick, first_interval=0.15)


def _analysis_tick():
    q = _analysis_lock.get("queue")
    if q is None:
        _analysis_lock["timer"] = False
        return None
    scene = getattr(bpy.context, "scene", None)
    tool = getattr(scene, "psd_import_tool", None) if scene is not None else None
    if tool is None:
        _analysis_lock["queue"] = None
        _analysis_lock["timer"] = False
        return None
    done = False
    while True:
        try:
            msg = q.get_nowait()
        except queue.Empty:
            break
        t = msg.get("type")
        if t == "item":
            # 丢弃过期结果（弹窗已重开/换批）——按 identifier 回写而非旧下标
            if msg.get("gen") != _analysis_lock.get("gen"):
                continue
            ident = msg.get("identifier")
            idx = next((k for k, it in enumerate(tool.pending_all)
                        if it.identifier == ident), None)
            if idx is not None:
                it = tool.pending_all[idx]
                it.is_changed = msg["changed"]
                if msg["changed"] and not it.selected:
                    it.selected = True   # 内容改过的自动补勾
                # 同步到可见视图（若该项当前可见）
                for v in tool.pending_layers:
                    if v.src_index == idx:
                        v.is_changed = it.is_changed
                        v.selected = it.selected
                        break
        elif t == "progress":
            tool.pending_analysis_progress = msg["done"] / max(1, msg["total"])
        elif t == "done":
            if msg.get("gen") != _analysis_lock.get("gen"):
                continue
            done = True
    if done:
        tool.pending_analysis_active = False
        tool.pending_analysis_status = "内容比对完成"
        _analysis_lock["queue"] = None
        _analysis_lock["timer"] = False
        return None
    return 0.15


class PSD_UL_LayerList(UIList):
    bl_idname = "PSD_UL_LayerList"

    def draw_item(self, context, layout, data, item, icon,
                  active_data, active_propname, index):
        row = layout.row(align=True)
        for _ in range(item.depth):
            row.label(text="", icon="BLANK1")
        if item.is_group:
            state = _group_state_master(data.pending_all, item.src_index)
            if state == 2:
                ic = "CHECKBOX_HLT"
            elif state == 1:
                ic = "LAYER_USED"
            else:
                ic = "CHECKBOX_DEHLT"
            # 折叠/展开箭头（默认折叠 → TRIA_RIGHT；展开 → TRIA_DOWN）
            arrow = "TRIA_DOWN" if item.is_expanded else "TRIA_RIGHT"
            eo = row.operator("psd.toggle_layer_expand", text="", icon=arrow, emboss=False)
            eo.src_index = item.src_index
            op = row.operator("psd.toggle_layer_group", text="", icon=ic, emboss=False)
            op.src_index = item.src_index
            row.label(text=item.display_name, icon="FILE_FOLDER")
        else:
            ic = "CHECKBOX_HLT" if item.selected else "CHECKBOX_DEHLT"
            cb = row.operator("psd.toggle_layer_check", text="", icon=ic, emboss=False)
            cb.src_index = item.src_index
            row.label(text=item.display_name)
            if item.is_new:
                row.label(text="新增", icon="ADD")
            elif item.is_changed:
                row.label(text="已改", icon="MODIFIER")


class PSD_OT_ToggleLayerGroup(Operator):
    bl_idname = "psd.toggle_layer_group"
    bl_label = "切换图层组勾选"
    bl_options = {"INTERNAL"}

    src_index: IntProperty(default=-1)

    def execute(self, context):
        tool = context.scene.psd_import_tool
        coll = tool.pending_all
        i = self.src_index
        if not (0 <= i < len(coll)):
            return {"CANCELLED"}
        base = coll[i]
        target = _group_state_master(coll, i) != 2  # 非全选 → 全选；全选 → 清空
        for j in range(i, len(coll)):
            it = coll[j]
            if j > i and it.depth <= base.depth:
                break
            it.selected = target
        _rebuild_visible(tool, anchor_src=self.src_index)
        return {"FINISHED"}


class PSD_OT_ToggleLayerExpand(Operator):
    bl_idname = "psd.toggle_layer_expand"
    bl_label = "折叠/展开图层组"
    bl_options = {"INTERNAL"}

    src_index: IntProperty(default=-1)

    def execute(self, context):
        tool = context.scene.psd_import_tool
        coll = tool.pending_all
        i = self.src_index
        if not (0 <= i < len(coll)):
            return {"CANCELLED"}
        coll[i].is_expanded = not coll[i].is_expanded
        _rebuild_visible(tool, anchor_src=self.src_index)
        return {"FINISHED"}


class PSD_OT_ToggleLayerCheck(Operator):
    bl_idname = "psd.toggle_layer_check"
    bl_label = "勾选/取消图层"
    bl_options = {"INTERNAL"}

    src_index: IntProperty(default=-1)

    def execute(self, context):
        tool = context.scene.psd_import_tool
        coll = tool.pending_all
        i = self.src_index
        if not (0 <= i < len(coll)):
            return {"CANCELLED"}
        coll[i].selected = not coll[i].selected
        for v in tool.pending_layers:
            if v.src_index == i:
                v.selected = coll[i].selected
                break
        return {"FINISHED"}


class PSD_OT_SelectLayers(Operator):
    bl_idname = "psd.select_layers"
    bl_label = "选择要导入的图层"
    bl_description = "勾选要导入的 PSD 图层"
    bl_options = {"INTERNAL"}

    file_index: IntProperty(default=-1)
    mode: StringProperty(default="IMPORT")  # IMPORT / APPEND
    pending_filepath: StringProperty(default="")

    def invoke(self, context, event):
        psd_tool = context.scene.psd_import_tool
        rec = None
        if 0 <= self.file_index < len(psd_tool.file_records):
            rec = psd_tool.file_records[self.file_index]
        fp = self.pending_filepath or (rec.filepath if rec is not None else "")
        if not fp:
            self.report({"ERROR"}, "未指定 PSD 文件")
            return {"CANCELLED"}
        # 分析 PSD（结构级，瞬时）
        try:
            psd = open_psd(fp)
            tree, flat = extract_layer_hierarchy(psd, _include_hidden_layers())
        except Exception as e:
            self.report({"ERROR"}, f"分析 PSD 失败：{e}")
            return {"CANCELLED"}
        # 追加模式：收集已导入的 identifier（用于默认不勾 + 标记新增）
        imported_ids = None
        if self.mode == "APPEND" and rec is not None:
            imported_ids = _collect_imported_ids(rec)
        stats = build_pending_items(psd_tool, tree, imported_ids=imported_ids)
        psd_tool.pending_mode = self.mode
        psd_tool.pending_file_index = self.file_index
        psd_tool.pending_filepath = fp
        psd_tool.pending_total_layers = stats["total_layers"]
        psd_tool.pending_imported_count = stats["imported"]
        psd_tool.pending_new_count = stats["new"]
        psd_tool.pending_append_mode = "NEW"
        # 追加模式：后台比对内容改动（秒开后逐步高亮），带弹窗内进度提示
        if self.mode == "APPEND" and rec is not None:
            # 旧 checksum：优先按图层 ID 匹配（同名图层不会互相覆盖）；旧记录无 ID 时回退按名字
            old_by_id = {}
            old_by_name = {}
            try:
                for cs in rec.layer_checksums:
                    if cs.identifier:
                        old_by_id[cs.identifier] = cs.value
                    else:
                        old_by_name[cs.name] = cs.value
            except Exception:
                pass
            id_to_pi = {it.identifier: i for i, it in enumerate(psd_tool.pending_all)}
            entries = []
            for e in flat:
                pi = id_to_pi.get(e["identifier"])
                if pi is None or psd_tool.pending_all[pi].is_new:
                    continue
                ident = e["identifier"]
                old_val = old_by_id.get(ident) or old_by_name.get(e["name"], "")
                entries.append({"identifier": ident, "layer": e["layer"], "old": old_val})
            if entries:
                _start_content_analysis(psd_tool, entries, None)
        return context.window_manager.invoke_props_dialog(
            self, width=520, confirm_text="导入"
        )

    def draw(self, context):
        psd_tool = context.scene.psd_import_tool
        layout = self.layout
        # 顶部：追加方式（仅 APPEND 显示）
        if self.mode == "APPEND":
            box = layout.box()
            box.label(text="已经导入过的图层，怎么处理？")
            layout.separator()
        layout.label(text=f"PSD文件：{os.path.basename(psd_tool.pending_filepath)}")
        layout.template_list(
            "PSD_UL_LayerList", "", psd_tool, "pending_layers",
            psd_tool, "pending_active_index",
            rows=12,
        )
        if psd_tool.pending_analysis_active:
            abox = layout.box()
            abox.label(text=psd_tool.pending_analysis_status or "比对中…", icon="TIME")
            abox.prop(psd_tool, "pending_analysis_progress", text="", slider=True)
        # 统计行
        n_sel = sum(1 for it in psd_tool.pending_all
                    if (not it.is_group) and it.selected)
        row = layout.row()
        row.label(text=f"共 {psd_tool.pending_total_layers} 个图层，已勾选 {n_sel} 个")
        if self.mode == "APPEND":
            row.label(text=f"（其中新增 {psd_tool.pending_new_count}）")

    def execute(self, context):
        global _import_selected_ids, _import_append_mode
        psd_tool = context.scene.psd_import_tool
        selected = [it.identifier for it in psd_tool.pending_all
                    if (not it.is_group) and it.selected]
        if not selected:
            if not psd_tool.pending_total_layers:
                # 不是"用户没勾"，是这份 PSD 里根本没有可导入的层
                self.report({"ERROR"}, "该 PSD 里没有可导入的可见图层")
            else:
                self.report({"ERROR"}, "没有勾选任何图层")
            return {"CANCELLED"}
        from .async_runner import launch_async_job
        _import_selected_ids = set(selected)
        if psd_tool.pending_mode == "IMPORT":
            _import_append_mode = "NEW"
            ok = launch_async_job(context, "IMPORT", -1, psd_tool.pending_filepath)
        else:
            # v3.10.0：追加只剩「新建」一种（更新已有交给刷新的职责，不再重复）
            _import_append_mode = "NEW"
            ok = launch_async_job(context, "APPEND", psd_tool.pending_file_index)
        if not ok:
            self.report({"ERROR"}, _last_async_error or "启动导入失败")
            return {"CANCELLED"}
        return {"FINISHED"}


# ---------------- 操作符：导入/刷新/重置 等 ----------------


class PSD_OT_ImportLayers(Operator):
    bl_idname = "psd.import_layers"
    bl_label = "导入PSD图层"
    bl_description = "选择并导入PSD文件"

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        if not self.filepath:
            self.report({"ERROR"}, "未选择PSD文件")
            return {"CANCELLED"}
        # 选择导入：先弹出图层选择窗，用户确认后再走异步导入
        return bpy.ops.psd.select_layers(
            "INVOKE_DEFAULT",
            file_index=-1,
            mode="IMPORT",
            pending_filepath=self.filepath,
        )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class PSD_OT_RefreshLayers(Operator):
    bl_idname = "psd.refresh_layers"
    bl_label = "刷新图层"
    bl_description = "刷新并更新修改过的PSD图层"

    file_index: IntProperty()

    def invoke(self, context, event):
        # 检查视差锁定状态
        psd_tool = context.scene.psd_import_tool
        if self.file_index >= 0 and self.file_index < len(psd_tool.file_records):
            psd_file = psd_tool.file_records[self.file_index]
            if psd_file.parallax_locked or psd_has_locked_layers(psd_file):
                # 视差锁定状态下弹出警告
                return context.window_manager.invoke_props_dialog(self, width=350)
        # 非视差锁定状态直接执行
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="警告：视差锁定已启用", icon="ERROR")
        layout.separator()
        layout.label(text="在视差锁定状态下刷新图层可能导致：")
        layout.label(text="• 对象变换属性与视差数据不同步")
        layout.label(text="• 视差效果计算错误")
        layout.separator()
        layout.label(text="建议：先关闭视差锁定再进行刷新操作")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}
        # 异步：后台解析渲染，主线程逐层应用（不冻结界面）
        from .async_runner import launch_async_job
        ok = launch_async_job(context, "REFRESH", self.file_index)
        if not ok:
            self.report({"ERROR"}, "启动后台刷新失败，请检查依赖与文件")
            return {"CANCELLED"}
        return {"FINISHED"}

class PSD_OT_ChangeFilepath(Operator):
    bl_idname = "psd.change_filepath"
    bl_label = "更改PSD文件路径"
    bl_description = "更改指定PSD文件的文件路径"

    file_index: IntProperty()
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的件索引")
            return {"CANCELLED"}

        rec = psd_tool.file_records[self.file_index]

        # 先验证、通过才改 —— 指向坏文件时不能把旧路径改坏（否则用户以为成功，
        # 实际卡片已指向一个读不了的文件）。和「改状态前先校验」是同一条纪律。
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({"ERROR"}, f"文件不存在，路径未更改：{self.filepath}")
            return {"CANCELLED"}
        try:
            psd = open_psd(self.filepath)
            tree, flat = extract_layer_hierarchy(psd, _include_hidden_layers())
        except Exception as e:
            self.report({"ERROR"}, f"无法读取该文件，路径未更改：{e}")
            return {"CANCELLED"}

        # 换了文件路径 = 这个 PSD 指向的图层可能全变了：
        # 必须和「重新扫描」用同一把尺子 —— 重读文件、重建列表，
        # 并清掉指向"新文件里已不存在图层"的旧勾选（否则列表会与文件对不上账）。
        # 注意：文件只是挪了位置（内容不变）时，图层 id 不变 → 勾选自然全部保留。
        rec.filepath = self.filepath
        try:
            rec.file_mtime = repr(os.path.getmtime(self.filepath))
        except (OSError, IOError, TypeError):
            rec.file_mtime = ""

        rec.layer_list_json = build_layer_list_json(tree)
        valid = set(f["identifier"] for f in flat if f.get("identifier"))
        imported = get_imported_id_set(rec) & valid
        rec.imported_layer_ids = ",".join(sorted(imported))
        _set_sel(rec, _sel_set(rec) & valid)

        rec.layer_list_scanning = False
        rec.layer_list_scan_progress = 0.0
        _rebuild_layer_items(rec, self.file_index)
        self.report({"INFO"},
                    f"已更新文件路径并刷新图层列表（{len(valid)} 层）")
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class PSD_OT_ToggleLayerList(Operator):
    """展开 / 折叠卡片内嵌的图层列表（默认折叠）。"""

    bl_idname = "psd.toggle_layer_list"
    bl_label = "图层列表"
    bl_description = "展开 / 折叠该 PSD 的图层列表"
    bl_options = {"INTERNAL"}

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}
        rec = psd_tool.file_records[self.file_index]
        rec.layer_list_open = not rec.layer_list_open
        if rec.layer_list_open:
            # 展开时重建显示行（保证视图与权威状态一致）
            _rebuild_layer_items(rec, self.file_index)
        return {"FINISHED"}


class PSD_OT_ToggleLayerChecked(Operator):
    """勾选 / 取消勾选卡片列表里的某个图层。

    勾选 = 「归插件管」（写进 record.imported_layer_ids，与刷新基准同一份数据）。
    取消勾选**不删除**场景里的对象，只是不再管理它。
    """

    bl_idname = "psd.toggle_layer_checked"
    bl_label = "勾选图层"
    bl_options = {"INTERNAL"}

    rec_index: IntProperty(default=0)
    item_index: IntProperty(default=0)

    def execute(self, context):
        tool = context.scene.psd_import_tool
        if not (0 <= self.rec_index < len(tool.file_records)):
            return {"CANCELLED"}
        rec = tool.file_records[self.rec_index]
        if not (0 <= self.item_index < len(rec.layer_items)):
            return {"CANCELLED"}
        item = rec.layer_items[self.item_index]
        ident = item.identifier
        if not ident:
            return {"CANCELLED"}

        imported = get_imported_id_set(rec)
        if item.is_group:
            # 组 = 批量：组内所有叶子统一勾上 / 统一取消。
            # 用「统一目标状态」判定（全勾→全取消，否则→全勾）——混合态下
            # 逐个 toggle 等于没点，是坑。
            leaves = _group_leaf_idents(rec, ident)
            if not leaves:
                return {"CANCELLED"}
            target_on = not all(x in imported for x in leaves)
            for x in leaves:
                if target_on:
                    imported.add(x)
                else:
                    imported.discard(x)
            rec.imported_layer_ids = ",".join(sorted(imported))
            sel = _sel_set(rec)
            if not target_on:
                sel -= set(leaves)
            _set_sel(rec, sel)
            _rebuild_layer_items(rec, self.rec_index)
            return {"FINISHED"}
        if ident in imported:
            imported.discard(ident)
        else:
            imported.add(ident)
        rec.imported_layer_ids = ",".join(sorted(imported))

        # 选中状态跟着勾选走：
        # - 取消勾选 → 不再选中（未勾选的行不允许被选中）
        # - 勾选「场景里还没有对象」的层 → 默认选中它（方便立刻点追加）
        sel = _sel_set(rec)
        if ident not in imported:
            sel.discard(ident)
        elif ident not in _existing_layer_ids(rec):
            sel.add(ident)
        _set_sel(rec, sel)

        _rebuild_layer_items(rec, self.rec_index)
        return {"FINISHED"}


class PSD_OT_ClearLayerSearch(Operator):
    """清空图层搜索框。"""

    bl_idname = "psd.clear_layer_search"
    bl_label = "清空搜索"
    bl_options = {"INTERNAL"}

    file_index: IntProperty()

    def execute(self, context):
        tool = context.scene.psd_import_tool
        if not (0 <= self.file_index < len(tool.file_records)):
            return {"CANCELLED"}
        rec = tool.file_records[self.file_index]
        rec.layer_search = ""      # update 回调会重建列表
        return {"FINISHED"}


class PSD_OT_ToggleGroupExpand(Operator):
    """展开 / 折叠卡片列表里的一个组。"""

    bl_idname = "psd.toggle_group_expand"
    bl_label = "展开/折叠组"
    bl_options = {"INTERNAL"}

    rec_index: IntProperty(default=0)
    identifier: StringProperty()

    def execute(self, context):
        tool = context.scene.psd_import_tool
        if not (0 <= self.rec_index < len(tool.file_records)):
            return {"CANCELLED"}
        rec = tool.file_records[self.rec_index]
        if not self.identifier:
            return {"CANCELLED"}
        cur = {x for x in (rec.layer_collapsed_groups or "").split(",") if x}
        if self.identifier in cur:
            cur.discard(self.identifier)
        else:
            cur.add(self.identifier)
        rec.layer_collapsed_groups = ",".join(sorted(cur))
        _rebuild_layer_items(rec, self.rec_index)
        return {"FINISHED"}


class PSD_OT_SelectLayerRow(Operator):
    """选中卡片列表里的一行（界面高亮 + 后续操作的依据）。

    规则：
    - 只能选中**已勾选**的行（保持"选中 ⊆ 勾选"）
    - 点击未选中的行 → 选中它（单选）；**再次点击已选中的行 → 取消选中**
    - Ctrl + 点 = 加减选；Shift + 点 = 按范围选
    """

    bl_idname = "psd.select_layer_row"
    bl_label = "选中图层行"
    bl_options = {"INTERNAL"}

    rec_index: IntProperty(default=0)
    item_index: IntProperty(default=0)
    # 修饰键（0=无, 1=Ctrl, 2=Shift）。invoke 从鼠标事件读；也从这里读，
    # 这样脚本 / 非鼠标触发也能表达同样的意图。
    modifier: IntProperty(default=0)

    def invoke(self, context, event):
        return self._apply(context, ctrl=event.ctrl, shift=event.shift)

    def execute(self, context):
        return self._apply(context, ctrl=(self.modifier == 1),
                           shift=(self.modifier == 2))

    def _apply(self, context, ctrl, shift):
        tool = context.scene.psd_import_tool
        if not (0 <= self.rec_index < len(tool.file_records)):
            return {"CANCELLED"}
        rec = tool.file_records[self.rec_index]
        if not (0 <= self.item_index < len(rec.layer_items)):
            return {"CANCELLED"}
        item = rec.layer_items[self.item_index]
        ident = item.identifier
        if item.is_group:
            # 组行选中 → 大纲视图里对应**集合**高亮（没有对应集合才回退选组内对象，
            # 见 _sync_scene_selection）。组不支持 Shift 范围选，按单选处理。
            sel = _sel_set(rec)
            if ctrl:
                if ident in sel:
                    sel.discard(ident)
                else:
                    sel.add(ident)
            else:
                if ident in sel:
                    sel.discard(ident)
                else:
                    sel = {ident}
            _set_sel(rec, sel)
            _refresh_selection_rows(rec)
            _sync_scene_selection(context, rec, sel)
            return {"FINISHED"}
        imported = get_imported_id_set(rec)
        if ident not in imported:
            # 未勾选的行不可选中（保持"选中 ⊆ 勾选"这条不变式）
            return {"CANCELLED"}

        # 可选中行 = 当前**可见**的已勾选图层行（组行与折叠隐藏的层都不参与）
        sel_list = [
            it.identifier for it in rec.layer_items
            if (not it.is_group) and it.checked
        ]
        try:
            my_pos = sel_list.index(ident)
        except ValueError:
            my_pos = -1

        sel = _sel_set(rec)
        if shift and rec.layer_list_anchor >= 0 and sel_list:
            a = min(rec.layer_list_anchor, len(sel_list) - 1)
            b = min(max(my_pos, 0), len(sel_list) - 1)
            lo, hi = min(a, b), max(a, b)
            sel = set(sel_list[lo:hi + 1])
        elif ctrl:
            if ident in sel:
                sel.discard(ident)
            else:
                sel.add(ident)
            rec.layer_list_anchor = my_pos
        else:
            # 普通点击 = 切换：
            #   点未选中的 → 单选它；再点已选中的 → 取消选中
            if ident in sel:
                sel.discard(ident)
            else:
                sel = {ident}
            rec.layer_list_anchor = my_pos

        _set_sel(rec, sel)
        _refresh_selection_rows(rec)   # 只改选中 → 轻量刷新，不整表重建（P1-4）
        # Q1：列表选中 → 同步到场景选中（方案 A：替换）。这样那排「选中图层操作」
        # （读 context.selected_objects）才会认列表里点蓝的行。
        _sync_scene_selection(context, rec, sel)
        return {"FINISHED"}


class PSD_OT_DeleteLayerObject(Operator):
    """删除场景中该图层对应的对象（破坏性操作，可 Ctrl+Z 撤销）。

    与「取消勾选」的区别：取消勾选只是不再管理它，这个是真的把对象从场景删掉。
    """

    bl_idname = "psd.delete_layer_object"
    bl_label = "删除图层对象"
    bl_description = "从场景中删除该图层对象（可 Ctrl+Z 撤销）"

    rec_index: IntProperty(default=0)
    item_index: IntProperty(default=0)

    def execute(self, context):
        tool = context.scene.psd_import_tool
        if not (0 <= self.rec_index < len(tool.file_records)):
            return {"CANCELLED"}
        rec = tool.file_records[self.rec_index]
        if not (0 <= self.item_index < len(rec.layer_items)):
            return {"CANCELLED"}
        item = rec.layer_items[self.item_index]
        ident = item.identifier
        col = get_collection_from_record(rec)
        if not col:
            self.report({"ERROR"}, "找不到该 PSD 的集合（可能已被删除）")
            return {"CANCELLED"}
        if item.is_group:
            # 组 = 删「集合 + 组内所有对象」：整个文件夹从场景消失
            leaves = _group_leaf_idents(rec, ident)
            n_del = 0
            for lid in leaves:
                for o in find_all_layer_objects(col, lid):
                    _delete_object_with_datablocks(o)
                    n_del += 1
            gcol = _find_collection_for_group(rec, ident)
            if gcol is not None:
                try:
                    bpy.data.collections.remove(gcol)
                except Exception:
                    pass
            imported = get_imported_id_set(rec)
            for lid in leaves:
                imported.discard(lid)
            rec.imported_layer_ids = ",".join(sorted(imported))
            sel = _sel_set(rec)
            sel -= set(leaves)
            sel.discard(ident)
            _set_sel(rec, sel)
            _rebuild_layer_items(rec, self.rec_index)
            self.report({"INFO"}, f"已删除文件夹「{item.name}」及其中 {n_del} 个图层对象")
            return {"FINISHED"}
        # 同一图层可能因「追加」在场景里有多个副本：只删「原始第一次导入」那份，
        # 追加出来的副本不动（用户约定）。
        objs = find_all_layer_objects(col, ident)
        if not objs:
            self.report({"WARNING"}, "该图层在场景里没有对象可删")
            return {"CANCELLED"}
        obj = _pick_primary_layer_object(objs)
        name = obj.name
        # 连它**独占**的数据块一起删（mesh / 材质 / 贴图）—— 这才是"彻底删除"，
        # 否则残留同名数据块会让下次追加被迫加 .001。users==0 才删，共享的不动。
        _delete_object_with_datablocks(obj)
        # 对象没了 → 它不再"已导入"：取消勾选（列表里变灰）+ 从选中移除
        imported = get_imported_id_set(rec)
        imported.discard(ident)
        rec.imported_layer_ids = ",".join(sorted(imported))
        sel = _sel_set(rec)
        sel.discard(ident)
        _set_sel(rec, sel)
        self.report({"INFO"}, f"已删除图层对象「{name}」（可 Ctrl+Z 撤销）")
        _rebuild_layer_items(rec, self.rec_index)
        return {"FINISHED"}


class PSD_OT_AppendSelectedLayers(Operator):
    """把列表里**选中**的图层追加为新对象（重名自动加序号）。

    统一语义：追加的就是"选中的层"——
    - 选中的是「还没导入过」的层 → 相当于导入这些新层
    - 选中的是「已导入」的层 → 重复追加一份（Blender 自动 .001 重命名）
    """

    bl_idname = "psd.append_selected_layers"
    bl_label = "追加为图层对象"
    bl_description = "把选中的图层追加为新对象（已存在的会重名自动加序号）"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if not (0 <= self.file_index < len(psd_tool.file_records)):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}
        rec = psd_tool.file_records[self.file_index]
        sel = _sel_set(rec)
        if not sel:
            self.report({"ERROR"}, "没有选中任何图层")
            return {"CANCELLED"}
        from .async_runner import launch_async_job
        global _import_selected_ids, _import_append_mode
        _import_selected_ids = set(sel)
        _import_append_mode = "NEW"
        ok = launch_async_job(context, "APPEND", self.file_index)
        if not ok:
            self.report({"ERROR"}, _last_async_error or "启动追加失败")
            return {"CANCELLED"}
        self.report({"INFO"}, f"正在追加 {len(sel)} 个图层…")
        return {"FINISHED"}


class PSD_OT_SelectAllLayers(Operator):
    """选中该 PSD 里**所有已勾选**的图层行（= 批量「选中」，不再改勾选）。

    口径（用户拍板 A）：全选/反选都作用于「选中」而非「勾选」——
    勾选代表"归不归插件管"，不该被这两个按钮顺手改掉。
    受"选中 ⊆ 勾选"不变式约束：未勾选的行不参与。
    """

    bl_idname = "psd.select_all_layers"
    bl_label = "全选"
    bl_description = "选中该 PSD 里所有已勾选的图层（不改变勾选）"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if not (0 <= self.file_index < len(psd_tool.file_records)):
            return {"CANCELLED"}
        rec = psd_tool.file_records[self.file_index]
        imported = get_imported_id_set(rec)
        ids = [it["i"] for it in parse_layer_list_json(rec.layer_list_json)
               if not it["g"] and it["i"] and it["i"] in imported]
        if not ids:
            self.report({"WARNING"}, "没有已勾选的图层（先在列表里勾选，或点「重新扫描」）")
            return {"CANCELLED"}
        sel = set(ids)
        _set_sel(rec, sel)
        _rebuild_layer_items(rec, self.file_index)
        _sync_scene_selection(context, rec, sel)   # 同步场景选中（那排"选中操作"才认）
        return {"FINISHED"}


class PSD_OT_InvertLayerSelection(Operator):
    """反选：在**已勾选**的图层范围内，把「选中 / 未选中」逐个取反。

    同样只动「选中」，不改勾选；未勾选的行不参与（保持"选中 ⊆ 勾选"）。
    """

    bl_idname = "psd.invert_layer_selection"
    bl_label = "反选"
    bl_description = "在已勾选的图层里，把选中/未选中取反（不改变勾选）"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if not (0 <= self.file_index < len(psd_tool.file_records)):
            return {"CANCELLED"}
        rec = psd_tool.file_records[self.file_index]
        imported = get_imported_id_set(rec)
        ids = [it["i"] for it in parse_layer_list_json(rec.layer_list_json)
               if not it["g"] and it["i"] and it["i"] in imported]
        if not ids:
            self.report({"WARNING"}, "没有已勾选的图层（先在列表里勾选，或点「重新扫描」）")
            return {"CANCELLED"}
        # 只取"已勾选范围内"的当前选中，再整体取反（组行等不参与）
        cur = _sel_set(rec) & set(ids)
        sel = {i for i in ids if i not in cur}
        _set_sel(rec, sel)
        _rebuild_layer_items(rec, self.file_index)
        _sync_scene_selection(context, rec, sel)   # 同步场景选中
        return {"FINISHED"}


class PSD_OT_RescanLayers(Operator):
    """重新扫描卡片列表：重读 PSD，标出「新图层」与「内容已改」的图层。

    结构变化（新增/删除/改名）当场标出；内容比对慢（逐层渲染），丢后台 + 进度条。
    """

    bl_idname = "psd.rescan_layers"
    bl_label = "重新扫描"
    bl_description = "重新读取该 PSD，刷新图层列表并标出变化"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if not (0 <= self.file_index < len(psd_tool.file_records)):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}
        rec = psd_tool.file_records[self.file_index]
        fp = rec.filepath
        if not fp or not os.path.exists(fp):
            self.report({"ERROR"}, f"找不到 PSD 文件：{fp}")
            return {"CANCELLED"}
        try:
            psd = open_psd(fp)
            tree, flat = extract_layer_hierarchy(psd, _include_hidden_layers())
        except Exception as e:
            self.report({"ERROR"}, f"读取 PSD 失败：{e}")
            return {"CANCELLED"}

        # ---- 结构级（即时）：对比 identifier 集合，新增的标「新图层」----
        old_ids = {it["i"] for it in parse_layer_list_json(rec.layer_list_json)
                   if not it["g"]}
        new_items = parse_layer_list_json(build_layer_list_json(tree))
        new_ids = {it["i"] for it in new_items if not it["g"]}
        added = new_ids - old_ids
        for it in new_items:
            it["m"] = "新图层" if it["i"] in added else ""
        rec.layer_list_json = json.dumps(new_items, ensure_ascii=False)
        rec.layer_list_scanning = False
        rec.layer_list_scan_progress = 0.0
        try:
            rec.file_mtime = repr(os.path.getmtime(fp))
        except OSError:
            pass

        # ---- 内容级（后台）：只比对「场景里已有对象 + 已勾选」的层 ----
        imported = get_imported_id_set(rec)
        by_id = {f["identifier"]: f for f in flat if f.get("identifier")}
        old_ck = {}
        for cs in rec.layer_checksums:
            key = getattr(cs, "identifier", "") or getattr(cs, "name", "")
            if key:
                old_ck[key] = getattr(cs, "value", "")
        entries = []
        for it in new_items:
            if it["g"] or not it["i"] or it["i"] not in imported:
                continue
            e = by_id.get(it["i"])
            if e is None:
                continue
            entries.append({
                "identifier": it["i"],
                "layer": e["layer"],
                "old": old_ck.get(it["i"], ""),
            })
        if entries:
            q = queue.Queue()
            _card_scan_locks[self.file_index] = {"queue": q}
            _AnalyzeWorker(entries, [], q, 0).start()
            rec.layer_list_scanning = True
            rec.layer_list_scan_progress = 0.0
            if not bpy.app.timers.is_registered(_card_scan_tick):
                bpy.app.timers.register(_card_scan_tick, first_interval=0.2)

        # 结构变了 → 立刻重建显示行（含"新图层"标记）
        _rebuild_layer_items(rec, self.file_index)

        msg = f"重新扫描完成：{len(new_ids)} 层"
        if added:
            msg += f"，新增 {len(added)} 层"
        if entries:
            msg += "，正在比对内容改动…"
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class PSD_OT_ToggleBlendMode(Operator):
    bl_idname = "psd.toggle_blend_mode"
    bl_label = "切换混合模式"
    bl_description = "在混合和抖动模式之切换PSD文件的所有图层材质"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}

        psd_file = psd_tool.file_records[self.file_index]
        base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
        collection = get_collection_from_record(psd_file)
        if not collection:
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        # Q2：整份操作与「刷新」同一口径 —— 只作用于**已勾选（归插件管）**的层
        imported = get_imported_id_set(psd_file)
        changed_count = 0
        for obj in get_all_objects_recursive(collection):
            if ATTR_LAYER_ID in obj and obj.type == "MESH" and obj.get(ATTR_LAYER_ID) in imported:
                for mat in obj.data.materials:
                    if mat and mat.blend_method == "BLEND":
                        mat.blend_method = "HASHED"
                    elif mat and mat.blend_method == "HASHED":
                        mat.blend_method = "BLEND"
                    changed_count += 1

        self.report(
            {"INFO"},
            f"已切换 {base_name} 的所有图层材质混合模式，共处理 {changed_count} 个材质",
        )
        return {"FINISHED"}


class PSD_OT_ToggleTextureExtension(Operator):
    bl_idname = "psd.toggle_texture_extension"
    bl_label = "切换纹理外插方式"
    bl_description = "在Clip、Mirror、Repeat之间轮切PSD文件所有图层材质的纹理外插方式"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}

        psd_file = psd_tool.file_records[self.file_index]
        collection = get_collection_from_record(psd_file)
        if not collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        # Q2：整份操作与「刷新」同一口径 —— 只作用于**已勾选（归插件管）**的层
        imported = get_imported_id_set(psd_file)
        changed_count = 0
        new_extension = None

        for obj in get_all_objects_recursive(collection):
            if ATTR_LAYER_ID in obj and obj.type == "MESH" and obj.get(ATTR_LAYER_ID) in imported:
                for mat in obj.data.materials:
                    if mat and mat.use_nodes:
                        for node in mat.node_tree.nodes:
                            if node.type == "TEX_IMAGE":
                                current = node.extension
                                if new_extension is None:
                                    # 根据第一个节点的状态决定目标状态
                                    if current == "CLIP":
                                        new_extension = "MIRROR"
                                    elif current == "MIRROR":
                                        new_extension = "REPEAT"
                                    else:
                                        new_extension = "CLIP"
                                node.extension = new_extension
                                changed_count += 1

        extension_names = {"CLIP": "Clip", "MIRROR": "Mirror", "REPEAT": "Repeat"}
        ext_name = (
            extension_names.get(new_extension, new_extension) if new_extension else "无"
        )
        self.report(
            {"INFO"},
            f"已切换纹理外插方式为 {ext_name}，共处理 {changed_count} 个纹理节点",
        )
        return {"FINISHED"}


class PSD_OT_CheckDependencies(Operator):
    bl_idname = "psd.check_dependencies"
    bl_label = "检查依赖库"
    bl_description = "检查并安装所需的Python依赖库"

    def execute(self, context):
        missing = check_dependencies()
        if not missing:
            self.report({"INFO"}, "所有依赖库已安装。")
            return {"FINISHED"}

        try:
            pybin = (
                getattr(bpy.app, "binary_path_python", sys.executable) or sys.executable
            )
            for package in missing:
                subprocess.check_call([pybin, "-m", "pip", "uninstall", "-y", package])
                subprocess.check_call(
                    [pybin, "-m", "pip", "install", "--no-cache-dir", package]
                )

            self.report({"INFO"}, "成功安装缺失的依赖库。请重新启用插件。")
        except Exception as e:
            self.report({"ERROR"}, f"安装依赖库时出错: {str(e)}")
        return {"FINISHED"}


class PSD_OT_ForceRefreshLayers(Operator):
    bl_idname = "psd.force_refresh_layers"
    bl_label = "强制刷新图层"
    bl_description = "强制刷新并重新载入PSD图层"

    file_index: IntProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout

        # 检查视差锁定状态并显示警告
        psd_tool = context.scene.psd_import_tool
        if self.file_index >= 0 and self.file_index < len(psd_tool.file_records):
            psd_file = psd_tool.file_records[self.file_index]
            if psd_file.parallax_locked or psd_has_locked_layers(psd_file):
                layout.label(text="警告：视差锁定已启用", icon="ERROR")
                layout.separator()
                layout.label(text="在视差锁定状态下刷新图层可能导致：")
                layout.label(text="• 对象变换属性与视差数据不同步")
                layout.label(text="• 视差效果计算错误")
                layout.separator()
                layout.label(text="建议：先关闭视差锁定再进行刷新操作")
                layout.separator()

        layout.label(text="强制刷新所有图层需要消耗比较多的时间，请确认是否执行？")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}
        # 异步：后台解析渲染，主线程逐层应用（不冻结界面）
        from .async_runner import launch_async_job
        ok = launch_async_job(context, "FORCE_REFRESH", self.file_index)
        if not ok:
            self.report({"ERROR"}, "启动后台强制刷新失败，请检查依赖与文件")
            return {"CANCELLED"}
        return {"FINISHED"}
class PSD_OT_DeletePSDFile(Operator):
    bl_idname = "psd.delete_psd_file"
    bl_label = "删除PSD文件信息"
    bl_description = "删除与此PSD文件相关的信息"

    file_index: IntProperty()
    delete_type: EnumProperty(
        items=[
            ("PROPERTIES", "只删除属性", "只删除自定义属性和重命名集合"),
            ("COMPLETE", "彻底删除", "完全删除所有相关信息"),
        ],
        name="删除型",
        description="选择删除的范围",
        default="PROPERTIES",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(text="确定要删除此PSD文件信息吗？")
        layout.prop(self, "delete_type")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}

        psd_file = psd_tool.file_records[self.file_index]
        collection = get_collection_from_record(psd_file)
        # base_name 提前算：集合可能不存在（被手动删 / 导入失败留的幽灵卡片），
        # 而末尾提示语无条件要用它 —— 放在 if collection 内会 UnboundLocalError 崩溃。
        base_name = bpy.path.display_name_from_filepath(psd_file.filepath)

        if collection:
            if self.delete_type == "PROPERTIES":
                for obj in get_all_objects_recursive(collection):
                    if ATTR_LAYER_ID in obj:
                        del obj[ATTR_LAYER_ID]
                    if ATTR_INITIAL_TRANSFORM in obj:
                        del obj[ATTR_INITIAL_TRANSFORM]
                collection.name = f"{collection.name}_delete_{self.file_index}"
            elif self.delete_type == "COMPLETE":
                # 先收集该集合下对象【实际引用】的贴图（按引用删）。
                # 不能用 f"_{base_name}_" in image.name 这种子串匹配：当两个 PSD 的文件名
                # 互为前缀（如 test_basic 与 test_basic_b）时，会连带删掉另一个 PSD 的贴图。
                imgs_to_remove = set()
                for obj in get_all_objects_recursive(collection):
                    for slot in getattr(obj, "material_slots", []):
                        mat = slot.material
                        if mat and getattr(mat, "use_nodes", False) and mat.node_tree:
                            for node in mat.node_tree.nodes:
                                if node.type == "TEX_IMAGE" and node.image:
                                    imgs_to_remove.add(node.image)
                for obj in list(get_all_objects_recursive(collection)):
                    bpy.data.objects.remove(obj, do_unlink=True)
                bpy.data.collections.remove(collection)
                # 删掉该 PSD 对象引用的贴图（这些图名带本 PSD 的 base_name，属本 PSD 独有）
                for img in imgs_to_remove:
                    try:
                        bpy.data.images.remove(img)
                    except Exception:
                        pass

        psd_tool.file_records.remove(self.file_index)

        self.report({"INFO"}, f"已删除PSD文件 '{base_name}' 的相关信息")
        return {"FINISHED"}


class PSD_OT_RefreshSelectedLayers(Operator):
    bl_idname = "psd.refresh_selected_layers"
    bl_label = "刷新选中图层"
    bl_description = "刷新选中的PSD图层对象"

    def invoke(self, context, event):
        # 检查选中对象所属的PSD文件是否有视差锁定
        selected_objects = context.selected_objects
        psd_layers = [obj for obj in selected_objects if ATTR_LAYER_ID in obj]

        if psd_layers:
            psd_tool = context.scene.psd_import_tool
            for obj in psd_layers:
                collection = obj.users_collection[0] if obj.users_collection else None
                if collection:
                    psd_file = next(
                        (
                            file
                            for file in psd_tool.file_records
                            if hasattr(file, "collection")
                            and file.collection == collection
                        ),
                        None,
                    )
                    if psd_file and (
                        psd_file.parallax_locked or psd_has_locked_layers(psd_file)
                    ):
                        # 发现视差锁定状态，弹出警告
                        return context.window_manager.invoke_props_dialog(
                            self, width=350
                        )

        # 无视差锁定直接执行
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="警告：视差锁定已启用", icon="ERROR")
        layout.separator()
        layout.label(text="在视差锁定状态下刷新图层可能导致：")
        layout.label(text="• 对象变换属性与视差数据不同步")
        layout.label(text="• 视差效果计算错误")
        layout.separator()
        layout.label(text="建议：先关闭视差锁定再进行刷新操作")

    def execute(self, context):
        selected_objects = context.selected_objects
        psd_layers = [obj for obj in selected_objects if obj.get("layer_identifier")]
        # Q3：只处理**归插件管**的图层（identifier 在该 PSD 已导入清单里）；
        # 未勾选的从场景选中里摘掉，保证后续异步任务不会碰到它们。
        psd_layers = _drop_unmanaged(context, psd_layers)
        if not psd_layers:
            self.report({"WARNING"}, "没有选中归本插件管的PSD图层对象（未勾选的层不参与）")
            return {"CANCELLED"}
        # 选中刷新：异步后台渲染，主线程逐层应用（不冻结界面）
        from .async_runner import launch_async_job
        ok = launch_async_job(context, "REFRESH_SELECTED", -1)
        if not ok:
            # 大白话提示 + 具体失败原因（模块级全局 _last_async_error 由 launch_async_job 写入）
            err = _last_async_error or "未知原因"
            self.report(
                {"ERROR"},
                f"选中刷新启动失败：{err}。请查看 Blender 控制台日志 ([PSD-异常]) 确认原因。",
            )
            return {"CANCELLED"}
        return {"FINISHED"}


def _collection_ancestor_chain(col):
    """返回集合链 [col, 父集合, ..., 根]，用于反查 record（对象可能落在按 PSD 文件夹建的子集合里）。"""
    chain = []
    seen = set()
    cur = col
    while cur is not None and cur.name not in seen:
        seen.add(cur.name)
        chain.append(cur)
        parent = None
        for pc in bpy.data.collections:
            # children 是 bpy_prop_collection，__contains__ 按名字判断
            if cur.name in pc.children:
                parent = pc
                break
        cur = parent
    return chain


def _record_for_object(psd_tool, obj):
    """从对象反查其所属 PSD record（沿集合祖先链匹配 record.collection；名称回退）。"""
    for col in obj.users_collection:
        for c in _collection_ancestor_chain(col):
            for f in psd_tool.file_records:
                if getattr(f, "collection", None) == c:
                    return f
            for f in psd_tool.file_records:
                if bpy.path.display_name_from_filepath(f.filepath) == c.name:
                    return f
    return None


class PSD_OT_ToggleTextureExtensionSelected(Operator):
    bl_idname = "psd.toggle_texture_extension_selected"
    bl_label = "切换选中图层纹理外插方式"
    bl_description = "在Clip、Mirror、Repeat之间轮切选中图层材质的纹理外插方式"

    def execute(self, context):
        selected = [
            o for o in context.selected_objects
            if o.get(ATTR_LAYER_ID) and o.type == "MESH"
        ]
        selected = _drop_unmanaged(context, selected)   # Q3：只作用归管的层
        if not selected:
            self.report({"WARNING"}, "没有选中归本插件管的PSD图层对象（未勾选的层不参与）")
            return {"CANCELLED"}
        changed_count = 0
        new_extension = None
        for obj in selected:
            for mat in obj.data.materials:
                if mat and mat.use_nodes:
                    for node in mat.node_tree.nodes:
                        if node.type == "TEX_IMAGE":
                            current = node.extension
                            if new_extension is None:
                                if current == "CLIP":
                                    new_extension = "MIRROR"
                                elif current == "MIRROR":
                                    new_extension = "REPEAT"
                                else:
                                    new_extension = "CLIP"
                            node.extension = new_extension
                            changed_count += 1
        extension_names = {"CLIP": "Clip", "MIRROR": "Mirror", "REPEAT": "Repeat"}
        ext_name = (
            extension_names.get(new_extension, new_extension) if new_extension else "无"
        )
        self.report(
            {"INFO"},
            f"已切换选中图层纹理外插方式为 {ext_name}，共处理 {changed_count} 个纹理节点",
        )
        return {"FINISHED"}


class PSD_OT_ToggleBlendModeSelected(Operator):
    bl_idname = "psd.toggle_blend_mode_selected"
    bl_label = "切换选中图层混合模式"
    bl_description = "在混合和抖动模式之切换选中图层的材质"

    def execute(self, context):
        selected = [
            o for o in context.selected_objects
            if o.get(ATTR_LAYER_ID) and o.type == "MESH"
        ]
        selected = _drop_unmanaged(context, selected)   # Q3：只作用归管的层
        if not selected:
            self.report({"WARNING"}, "没有选中归本插件管的PSD图层对象（未勾选的层不参与）")
            return {"CANCELLED"}
        changed_count = 0
        for obj in selected:
            for mat in obj.data.materials:
                if mat and mat.blend_method == "BLEND":
                    mat.blend_method = "HASHED"
                elif mat and mat.blend_method == "HASHED":
                    mat.blend_method = "BLEND"
                changed_count += 1
        self.report(
            {"INFO"},
            f"已切换选中图层材质混合模式，共处理 {changed_count} 个材质",
        )
        return {"FINISHED"}


class PSD_OT_MatchSelectedToCamera(Operator):
    bl_idname = "psd.match_selected_to_camera"
    bl_label = "匹配选中图层至相机"
    bl_description = "将选中的图层对象匹配到选中行指定的相机视图，或恢复原始状态"

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        camera = psd_tool.selected_camera
        if not camera:
            self.report({"ERROR"}, "请先在选中行选择一个相机")
            return {"CANCELLED"}
        if getattr(camera, "type", None) != "CAMERA":
            self.report({"ERROR"}, "选择的不是相机对象，请重新选择相机")
            return {"CANCELLED"}
        selected = [o for o in context.selected_objects if o.get(ATTR_LAYER_ID)]
        # Q3：只作用归管的层。⚠️ 判据须与 `_managed_selected`（UI 按钮文字用）保持一致 ——
        # 二者都是「identifier ∈ record.imported_layer_ids」，只是本处多了
        # "把未归管的从选中里摘掉"的副作用（UI 侧不能有副作用）。
        selected = _drop_unmanaged(context, selected)
        if not selected:
            self.report({"WARNING"}, "没有选中归本插件管的PSD图层对象（未勾选的层不参与）")
            return {"CANCELLED"}
        # 按所属 collection 分组（key 用对象身份，避免同名集合被合并）
        groups = {}
        for obj in selected:
            col = obj.users_collection[0] if obj.users_collection else None
            if not col:
                continue
            groups.setdefault(id(col), {"col": col, "objs": []})["objs"].append(obj)
        if not groups:
            _psd_log(
                f"[PSD-匹配] '匹配至相机'(选中行) 早退: "
                f"选中 {len(selected)} 个对象，但都不在 PSD 集合中"
            )
            self.report({"WARNING"}, "选中的对象不在任何集合中")
            return {"CANCELLED"}
        # ★ 同卡片版：可预测的双态切换（已匹配 → 还原；未匹配 → 匹配到 PSD 原始构图）。
        #   判据只看【选中的这些对象】，不牵连集合里其它图层。
        _psd_log(
            f"[PSD-匹配] '匹配至相机'(选中行) 选中 {len(selected)} 个, "
            f"分 {len(groups)} 组"
        )
        for grp in groups.values():
            col = grp["col"]
            objs = grp["objs"]
            rec = _record_for_object(psd_tool, objs[0])
            if rec is None or not rec.filepath:
                continue
            _has_pre = any(ATTR_PRE_MATCH_TRANSFORM in o for o in objs)
            _psd_log(
                f"[PSD-匹配] 分组 '{col.name}' ({len(objs)} 层) → "
                f"走【{'恢复匹配前' if _has_pre else '匹配'}】分支"
                f"（判据: {'有' if _has_pre else '无'} pre_match_transform）"
            )
            if _has_pre:
                restore_pre_match_transform(col, target_objects=objs)
            else:
                match_layers_to_camera(
                    col, camera, rec, target_objects=objs, update_state=False
                )
        # 仅留痕（判据已改为「是否有 pre_match_transform」，运行时不再读它）
        psd_tool.last_selected_camera_transform = str(camera.matrix_world)
        self.report({"INFO"}, f"已处理 {len(selected)} 个选中图层")
        return {"FINISHED"}


def _sel_set(record) -> set:
    """卡片列表中「被选中」的行（identifier 集合）。注意：选中 ≠ 勾选。"""
    return set(x for x in (record.layer_list_sel or "").split(",") if x)


def _set_sel(record, ids) -> None:
    record.layer_list_sel = ",".join(sorted(x for x in ids if x))


def _existing_layer_ids(record) -> set:
    """场景里实际存在的图层对象 identifier 集合（一次遍历，供 draw/判断复用）。"""
    col = get_collection_from_record(record)
    if not col:
        return set()
    out = set()
    for obj in get_all_objects_recursive(col):
        lid = obj.get(ATTR_LAYER_ID)
        if lid:
            out.add(lid)
    return out


def _include_hidden_layers() -> bool:
    """全局「包含隐藏图层/文件夹」开关（⚙ 设置面板）。"""
    try:
        return bool(getattr(bpy.context.scene.psd_import_tool, "include_hidden_layers", False))
    except Exception:
        return False


def _has_blender_suffix(name: str) -> bool:
    """名字是否带 Blender 自动序号后缀（.001 / .012 ...）。"""
    if "." not in name:
        return False
    tail = name.rsplit(".", 1)[1]
    return len(tail) == 3 and tail.isdigit()


def _pick_primary_layer_object(objs):
    """从同 identifier 的多个对象里挑出「原始第一次导入」那份。

    优先：带 ATTR_LAYER_PRIMARY 标记的（新导入都会打）；
    回退：名字不带 .NNN 后缀的（兼容打标记之前导入的旧工程）；
    兜底：第一个。
    """
    for o in objs:
        try:
            if o.get(ATTR_LAYER_PRIMARY):
                return o
        except Exception:
            pass
    for o in objs:
        if not _has_blender_suffix(o.name):
            return o
    return objs[0]


def _delete_object_with_datablocks(obj) -> None:
    """删对象 + 它**独占**的数据块（mesh / 材质 / 贴图；users==0 才删）。"""
    obj_name = getattr(obj, "name", "?")
    mesh_data = getattr(obj, "data", None)
    mesh_name = getattr(mesh_data, "name", None)
    mats = [sl.material for sl in getattr(obj, "material_slots", []) if sl.material]
    imgs = []
    for mat in mats:
        try:
            if mat.use_nodes and mat.node_tree:
                for node in mat.node_tree.nodes:
                    if node.type == "TEX_IMAGE" and node.image:
                        imgs.append(node.image)
        except Exception:
            pass
    # 记账用：哪些数据块真被删了、哪些因为还有别的用户而保留
    removed_mats = []
    removed_imgs = []
    removed_mesh = False
    bpy.data.objects.remove(obj, do_unlink=True)
    for mat in mats:
        try:
            if mat.users == 0:
                # ⚠️ 先取名字再 remove —— 删掉之后这个引用就失效了，读 .name 会抛
                _mat_name = mat.name
                bpy.data.materials.remove(mat)
                removed_mats.append(_mat_name)
        except Exception:
            pass
    try:
        if mesh_data is not None and mesh_data.users == 0:
            bpy.data.meshes.remove(mesh_data)
            removed_mesh = True
    except Exception:
        pass
    for img in imgs:
        try:
            if img.users == 0:
                _img_name = img.name
                bpy.data.images.remove(img)
                removed_imgs.append(_img_name)
        except Exception:
            pass

    # 不可逆操作，必须留痕：删了哪个对象、哪些数据块跟着走了、哪些被别的对象共用而保留。
    # （「删了一层，另一层的贴图也空了」= 共用数据块被误删，这一行能直接看出来）
    _psd_log(
        f"[PSD-删除] 对象 '{obj_name}' 已删除 | mesh="
        f"{('删 ' + str(mesh_name)) if removed_mesh else '保留(仍被引用)'} | "
        f"材质 {len(removed_mats)}/{len(mats)} 删 {removed_mats} | "
        f"贴图 {len(removed_imgs)}/{len(imgs)} 删 {removed_imgs}"
    )


def _group_leaf_idents(record, group_ident) -> list:
    """取该组（文件夹）下**所有叶子图层**的 identifier（含子组里的）。

    用原始 layer_list_json 的 depth 关系：组之后、depth 更大且更深的行都属于它。
    """
    items = parse_layer_list_json(record.layer_list_json)
    out = []
    gd = None
    for it in items:
        if gd is None:
            if it.get("i") == group_ident and it.get("g"):
                gd = it.get("d", 0)
            continue
        if it.get("d", 0) <= gd:
            break
        if not it.get("g"):
            out.append(it["i"])

    # 「点了文件夹却毫无反应」的头号嫌疑：组标识在列表里没匹配上 → 收到 0 个叶子。
    # ⚠️ 只在**异常路径**打：本函数同时被 _rebuild_layer_items（列表重建）调用，
    #    列表里有多少组就会调多少次，无条件打会刷屏。
    if gd is None:
        _psd_log(
            f"[PSD-组] 组 '{group_ident}' 在图层列表里没匹配到"
            f"（标识不符或列表已过期）→ 收到 0 个叶子图层"
        )
    return out


def _find_collection_for_group(record, group_ident):
    """组（GRP:<路径>）→ 对应的 Blender 集合（按路径逐级查 children）。"""
    if not group_ident.startswith("GRP:"):
        return None
    path = [s for s in group_ident[4:].split("/") if s]
    # 提前拼好，避免在 f-string 里嵌套同类引号（Blender 用的 Python < 3.12 不支持）
    path_str = "/".join(path)
    col = get_collection_from_record(record)
    for idx, seg in enumerate(path):
        if col is None:
            _psd_log(
                f"[PSD-组] 集合查找中断: '{group_ident}' (路径 '{path_str}') "
                f"在第 {idx} 级 '{seg}' 之前就已断，找不到对应集合"
            )
            return None
        nxt = None
        for ch in col.children:
            if ch.name == seg:
                nxt = ch
                break
        col = nxt
    if col is None and path:
        _psd_log(
            f"[PSD-组] 集合查找失败: '{group_ident}' (路径 '{path_str}') "
            f"末级子集合不存在"
        )
    return col




def _select_only_objects(context, objs) -> None:
    """清掉场景原有选中，只选中给定的这些对象（并设 active）。方案 A：替换。"""
    try:
        for o in list(context.selected_objects):
            try:
                o.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    first = None
    for o in objs:
        try:
            o.select_set(True)
            if first is None:
                first = o
        except Exception:
            pass
    if first is not None:
        try:
            context.view_layer.objects.active = first
        except Exception:
            pass


def _sync_scene_selection(context, record, idents) -> None:
    """把「列表选中」同步到场景选中（方案 A：替换）。

    - 图层行 → 选中它对应的对象（含追加出来的副本）
    - 组行   → 选中该组下**所有图层**对应的对象

    ⚠️ 为什么不"选中大纲里的集合"：Blender 的大纲「集合选中」是纯 UI 状态，
    `SpaceOutliner` 没有对脚本开放的接口 —— 实测 `outliner.select_all`（确实选中了
    物体但集合蓝底不变）/ `select_box` / 改 `active_layer_collection` 都无法改变它。
    所以组选中落到"它包含的对象"上：动作在 3D 视图里有可见反馈，面板顶部的
    「选中图层操作」（读 context.selected_objects）也认。
    """
    col = get_collection_from_record(record)
    objs = []
    for ident in idents:
        if ident.startswith("GRP:"):
            if col:
                for lid in _group_leaf_idents(record, ident):
                    objs.extend(find_all_layer_objects(col, lid))
        elif col:
            objs.extend(find_all_layer_objects(col, ident))
    _select_only_objects(context, objs)


def _drop_unmanaged(context, objs):
    """滤掉「不归插件管」的对象，并把它们从场景选中里摘掉。

    "归管" = identifier 在**该对象所属 PSD 的已导入清单**里（与列表勾选同一把尺子）。
    未勾选的层不归管 → 「选中操作」不该碰它们（Q3）。
    返回保留下来的（归管的）对象列表。
    """
    try:
        psd_tool = context.scene.psd_import_tool
    except Exception:
        return list(objs)
    managed, skipped = [], []
    for o in objs:
        rec = _record_for_object(psd_tool, o)
        ident = o.get(ATTR_LAYER_ID)
        if rec is not None and ident and ident in get_imported_id_set(rec):
            managed.append(o)
        else:
            skipped.append(o)
    for o in skipped:
        try:
            o.select_set(False)
        except Exception:
            pass
    return managed


def _file_is_newer(record) -> bool:
    """磁盘上的 PSD 是否比记录里的时间更新（用于提示「文件已变化」）。

    用容差 1 秒：避免文件系统时间精度 / 极小抖动造成误报；
    同时因为存的是字符串（精确 double），不存在 float32 那种几十秒的误差。
    """
    raw = getattr(record, "file_mtime", "") or ""
    if not raw or not record.filepath:
        return False
    try:
        stored = float(raw)
    except (TypeError, ValueError):
        return False
    try:
        if not os.path.exists(record.filepath):
            return False
        return os.path.getmtime(record.filepath) > stored + 1.0
    except OSError:
        return False


def _display_order(items):
    """把 psd_tools 的「底→顶」顺序整成 PS 面板的「顶→底」显示顺序。

    PSD 文件里图层是自下而上存的（psd_tools 也按这个顺序遍历），
    而 Photoshop 面板是自上而下显示 —— 所以每层的兄弟顺序都要反过来。
    组与其子项的相对位置不变（父在前、子在后）。
    """
    def _walk(start, depth):
        groups = []
        i = start
        n = len(items)
        while i < n:
            if items[i]["d"] < depth:
                break
            if items[i]["d"] == depth:
                j = i + 1
                while j < n and items[j]["d"] > depth:
                    j += 1
                groups.append((items[i], i + 1, j))
                i = j
            else:
                i += 1
        out = []
        for it, cs, ce in reversed(groups):
            out.append(it)
            if ce > cs:
                out.extend(_walk(cs, depth + 1))
        return out

    return _walk(0, 0)


def _filter_items_by_search(items, keyword):
    """按关键词过滤「显示项」（在 _display_order 之后、建行之前调用）。

    规则（大小写不敏感的子串匹配）：
    - 图层名命中 → 显示该图层 + 它的所有祖先组（保证看得出层级）
    - 组名命中 → 显示该组 + 它的整棵子树
    """
    n = len(items)
    if n == 0:
        return items

    # 1) 每项的祖先 identifier 链（利用 depth 做栈）
    ancestors = []
    stack = []
    for it in items:
        d = it["d"]
        while stack and stack[-1][0] >= d:
            stack.pop()
        ancestors.append([a[1] for a in stack])
        stack.append((d, it["i"]))

    index_of = {it["i"]: i for i, it in enumerate(items)}
    hit = [keyword in (it["n"] or "").lower() for it in items]
    show = [False] * n

    # 2) 组命中 → 整棵子树
    for i, it in enumerate(items):
        if hit[i] and it["g"]:
            d0 = it["d"]
            j = i + 1
            while j < n and items[j]["d"] > d0:
                show[j] = True
                j += 1

    # 3) 命中项 + 其祖先组
    for i, it in enumerate(items):
        if hit[i]:
            show[i] = True
            for a in ancestors[i]:
                k = index_of.get(a)
                if k is not None:
                    show[k] = True

    return [it for i, it in enumerate(items) if show[i]]


def _refresh_selection_rows(record) -> None:
    """只按「选中」状态刷新现有行的高亮（不重建结构、不遍历场景对象）。

    用于「选中行」这类只改选中、不改勾选/结构的操作 —— 避免每次点击都整表
    重建（P1-4）。若勾选/结构/折叠变了，仍须走 _rebuild_layer_items。
    """
    sel = _sel_set(record)
    for it in record.layer_items:
        it.selected = it.identifier in sel
    record.layer_active = -1


def _rebuild_layer_items(record, rec_index: int) -> None:
    """按权威状态重建卡片列表的显示行（含组折叠过滤）。

    - 图层结构 & 标记 → record.layer_list_json
    - 勾选 → record.imported_layer_ids
    - 选中 → record.layer_list_sel
    - 组折叠 → record.layer_collapsed_groups

    所有改动状态的操作都应在最后调它，保证 views 与权威数据一致（唯一入口）。
    """
    record.layer_items.clear()
    raw_items = parse_layer_list_json(record.layer_list_json)
    items = _display_order(raw_items)   # 顶→底（与 PS 面板一致）

    # 搜索过滤：有关键词时只显示命中项 + 其祖先组（组名命中则显示该组子树）
    keyword = (record.layer_search or "").strip().lower()
    if keyword:
        items = _filter_items_by_search(items, keyword)
    imported = get_imported_id_set(record)
    sel = _sel_set(record)
    # 搜索时忽略折叠：命中的层可能在收起的组里，不展开就看不到结果
    collapsed = (set() if keyword else
                 {x for x in (record.layer_collapsed_groups or "").split(",") if x})
    existing = _existing_layer_ids(record)

    skip_depth = None
    for it in items:
        d = it["d"]
        if skip_depth is not None:
            if d > skip_depth:
                continue
            skip_depth = None
        row = record.layer_items.add()
        row.rec_index = rec_index
        row.identifier = it["i"]
        row.name = it["n"]
        row.depth = d
        row.is_group = it["g"]
        row.mark = it["m"]
        if it["g"]:
            row.expanded = it["i"] not in collapsed
            if not row.expanded:
                skip_depth = d
            # 组行也带勾选 / 选中 / 对象状态（组 = 批量语义）：
            #   勾选 = 组内叶子**全部**已勾（否则空框）；✕ 依据 = 组内是否还有对象
            _leaves = _group_leaf_idents(record, it["i"])
            if _leaves:
                row.checked = all(x in imported for x in _leaves)
                row.has_object = any(x in existing for x in _leaves)
            row.selected = it["i"] in sel
        else:
            row.checked = it["i"] in imported
            row.selected = it["i"] in sel
            row.has_object = it["i"] in existing

    # 关掉列表控件自带的"活动行"高亮（-1 = 不高亮）：它会画一整条蓝底，
    # 和我们用来表示"选中"的按下态（蓝底名字）是两回事，同时出现会让人分不清。
    # 本列表的选中状态完全由 layer_list_sel 决定，不需要这个额外光标。
    record.layer_active = -1


def _card_parallax_locked(record) -> bool:
    """卡片 🔒 判据（图标与卡片按钮共用，避免两把尺子）。

    - 开关关着 → False（O(1) 短路；局部锁定不点亮卡片，见 v3.9.3 约定）
    - 开关开着但锁定对象已被删光 → False（不再"说谎"）
    """
    if not record.parallax_locked:
        return False
    return psd_has_locked_layers(record)


def _collection_has_pre_match(coll) -> bool:
    """集合里是否有图层带 pre_match_transform（= 已「匹配至相机」过、可恢复）。

    判定「匹配 / 恢复」双态的**唯一判据** —— 它可预测（按钮文字会跟着变），
    不再依赖旧版的"相机是否移动"（用户看不见、同一操作结果会跳变）。
    """
    if coll is None:
        return False
    for obj in get_all_objects_recursive(coll):
        if ATTR_LAYER_ID in obj and ATTR_PRE_MATCH_TRANSFORM in obj:
            return True
    return False


def _card_has_pre_match(record) -> bool:
    """卡片版：该 PSD 是否处于「已匹配至相机」状态。"""
    return _collection_has_pre_match(get_collection_from_record(record))


def _managed_selected(context):
    """选中对象里「**归管** 且在 **PSD 集合**中」的那些（**无副作用**）。

    这是「匹配至相机（选中行）」的**唯一判据来源** —— UI 按钮文字与 operator 分支
    都用它，保证「显示什么 = 点什么会发生什么」。

    为什么要单独抽出来（而非复用 `_drop_unmanaged`）：后者有副作用（会把不归管的
    对象 `select_set(False)`），而 draw 函数里绝不能改选中状态。故这里只做只读过滤，
    判据与 `_drop_unmanaged` 完全一致（identifier ∈ record.imported_layer_ids）。
    """
    try:
        psd_tool = context.scene.psd_import_tool
    except Exception:                                         # noqa: BLE001
        return []
    out = []
    for o in context.selected_objects:
        ident = o.get(ATTR_LAYER_ID)
        if not ident or not o.users_collection:
            continue
        rec = _record_for_object(psd_tool, o)
        if rec is not None and ident in get_imported_id_set(rec):
            out.append(o)
    return out


def _selected_match_label(context):
    """选中行版的按钮「文字 + 图标」：双态 + **混合态**兜底。

    ⚠️ 为什么不能只看"任一层有 pre"：operator 是【逐组】处理的（不同 PSD 组能力不同）。
    混合选中（A 组有 pre、B 组没有）时点下去 A 组还原、B 组匹配，
    若按 any 显示「恢复匹配前」会误导用户。故状态不一致时显示中性文案。

    返回 (text, icon)：
      全部已匹配 → 「恢复匹配前」；全部未匹配 → 「匹配至相机」；混合 → 中性文案。
    """
    # 用与 operator 完全同源的判据（归管 + 在 PSD 集合中），避免"显示的态"与
    # "点下去实际处理的层"不是同一批（review 指出）。
    objs = _managed_selected(context)
    if not objs:
        return "匹配至相机", "CAMERA_DATA"
    n_pre = sum(1 for o in objs if ATTR_PRE_MATCH_TRANSFORM in o)
    if n_pre == len(objs):
        return "恢复匹配前", "LOOP_BACK"
    if n_pre == 0:
        return "匹配至相机", "CAMERA_DATA"
    # 混合：文字说明"部分恢复部分匹配"，用户不会误会
    return "匹配/恢复至相机", "ARROW_LEFTRIGHT"


def _selected_parallax_locked(context):
    """选中的图层是否处于「选中行局部锁定」状态（决定选中行 🔒 图标）。

    与卡片「整份锁定」互斥、不同步：
    - 若所属 PSD 处于「整份锁定」（卡片级）→ 视为**未局部锁定**（图标显示 🔓）；
    - 否则：选中图层全都带锁定属性 → True（🔒），只要有一个没锁 → False（🔓）。
    """
    psd_tool = context.scene.psd_import_tool
    objs = [o for o in context.selected_objects if o.get(ATTR_LAYER_ID)]
    if not objs:
        return False
    for obj in objs:
        rec = _record_for_object(psd_tool, obj)
        if rec is not None and rec.parallax_locked:
            return False
    return all(is_obj_parallax_locked(o) for o in objs)


class PSD_OT_ToggleParallaxLockSelected(Operator):
    bl_idname = "psd.toggle_parallax_lock_selected"
    bl_label = "锁定视差"
    bl_description = "锁定/解锁选中的图层的视差（用选中行相机；全部已锁则解锁，否则全部锁定）"

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        # 相机取自「选中行」自己的相机框，不依赖 PSD 卡片的相机
        camera = psd_tool.selected_camera
        if not camera:
            self.report({"ERROR"}, "请先在选中行选择一个相机")
            return {"CANCELLED"}
        if getattr(camera, "type", None) != "CAMERA":
            self.report({"ERROR"}, "选择的不是相机对象，请重新选择相机")
            return {"CANCELLED"}
        objs = [o for o in context.selected_objects if o.get(ATTR_LAYER_ID)]
        objs = _drop_unmanaged(context, objs)   # Q3：只作用归管的层
        if not objs:
            self.report({"WARNING"}, "没有选中归本插件管的PSD图层对象（未勾选的层不参与）")
            return {"CANCELLED"}
        # 统一目标状态（与选中行图标同一判据）：当前不是"局部锁定"→ 本次锁定；
        # 已是局部锁定 → 本次解锁。整份锁定（卡片级）时视为"未局部锁定"→ 本次建立局部锁定。
        target_locked = not _selected_parallax_locked(context)
        # 按所属 PSD 分组（只处理选中的对象）
        groups = {}
        for obj in objs:
            rec = _record_for_object(psd_tool, obj)
            if rec is None:
                continue
            groups.setdefault(id(rec), {"rec": rec, "objs": []})["objs"].append(obj)
        if not groups:
            self.report({"ERROR"}, "找不到选中图层所属的PSD记录")
            return {"CANCELLED"}
        done = 0
        for g in groups.values():
            rec = g["rec"]
            gobjs = g["objs"]
            collection = get_collection_from_record(rec)
            if not collection:
                base = bpy.path.display_name_from_filepath(rec.filepath)
                self.report({"ERROR"}, f"找不到名为 {base} 的集合")
                continue
            # 互斥：该 PSD 若正处于「整份锁定」（卡片级），先自动解除，
            # 避免"整份锁 + 局部锁"两套状态并存造成矛盾。
            if rec.parallax_locked:
                restore_parallax_lock_state(collection)
                rec.parallax_locked = False
            if target_locked:
                record_parallax_lock_state(collection, camera, target_objects=gobjs)
            else:
                restore_parallax_lock_state(collection, target_objects=gobjs)
            # 账本更新必须在循环内：跨多个 PSD 时每个 record 都要维护
            rec.parallax_maybe_locked = psd_has_locked_layers(rec)
            done += len(gobjs)
        if done:
            action = "锁定" if target_locked else "解锁"
            self.report({"INFO"}, f"已{action} {done} 个选中图层")
        return {"FINISHED"}


def check_dependencies():
    required_imports = {"psd_tools": "psd-tools", "PIL": "Pillow"}
    missing = []
    for import_name, install_name in required_imports.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(install_name)
    return missing


# ---------------- 相机匹配与视差锁定 ----------------




class PSD_OT_MatchToCamera(Operator):
    bl_idname = "psd.match_to_camera"
    bl_label = "匹配至相机"
    bl_description = "将PSD图层对象匹配到选定的相机视图或恢复原始状态"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        psd_file = psd_tool.file_records[self.file_index]

        if not psd_file.camera:
            self.report({"ERROR"}, "请先选择一个相机")
            return {"CANCELLED"}
        if getattr(psd_file.camera, "type", None) != "CAMERA":
            self.report({"ERROR"}, "选择的不是相机对象，请重新选择相机")
            return {"CANCELLED"}

        collection = get_collection_from_record(psd_file)
        if not collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            _psd_log(f"[PSD-匹配] '匹配至相机'(卡片) 早退: 找不到集合 '{base_name}'")
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        # ★「匹配至相机」= 可预测的双态切换：
        #     未匹配 → 匹配到 PSD 原始构图（并记 pre_match_transform 供还原）；
        #     已匹配 → 还原到匹配前的位置。
        #   判据 = 集合里有没有 pre_match_transform，且**按钮文字会同步变成「恢复匹配前」**，
        #   所以用户看得见、可预测。旧版判据是"相机是否移动"（用户不可见）——
        #   同样的点击会时而匹配、时而还原，用户实测"匹配至相机没还原原始相对位置"。
        #   （实测复现见 git 历史 _dev_tools/e2e_match.py：点击1次✓还原、点击2次✗变乱。）
        # ⚠️ 此字段现仅作**留痕**：判据已改为「是否存在 pre_match_transform」，
        #    handle 时不再读它（旧版靠它判"相机是否移动"，是不可预测的根源）。
        psd_file.last_camera_transform = str(psd_file.camera.matrix_world)
        # 记录走了哪条分支 + 判据 —— 排查「为什么这次是恢复而不是匹配」时最有用
        _has_pre = _collection_has_pre_match(collection)
        _psd_log(
            f"[PSD-匹配] '匹配至相机'(卡片) 集合='{collection.name}' → "
            f"走【{'恢复匹配前' if _has_pre else '匹配'}】分支"
            f"（判据: 集合内{'有' if _has_pre else '无'} pre_match_transform）"
        )
        if _has_pre:
            restore_pre_match_transform(collection)
            self.report({"INFO"}, "已还原到匹配前的位置")
        else:
            match_layers_to_camera(collection, psd_file.camera, psd_file)
            self.report({"INFO"}, "已将图层匹配至相机（PSD 原始构图）")

        return {"FINISHED"}


class PSD_OT_ToggleParallaxLock(Operator):
    bl_idname = "psd.toggle_parallax_lock"
    bl_label = "锁定视差"
    bl_description = "切换视差锁定状态"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        psd_file = psd_tool.file_records[self.file_index]

        if not psd_file.camera:
            self.report({"ERROR"}, "请先选择一个相机")
            return {"CANCELLED"}
        if getattr(psd_file.camera, "type", None) != "CAMERA":
            self.report({"ERROR"}, "选择的不是相机对象，请重新选择相机")
            return {"CANCELLED"}

        collection = get_collection_from_record(psd_file)
        if not collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        # 统一判据（与卡片图标同一把尺子）：实际未锁定 → 本次锁定
        # 赋值放在校验**之后**，避免中途失败却已改了开关（半途状态）
        target_locked = not _card_parallax_locked(psd_file)
        psd_file.parallax_locked = target_locked

        if target_locked:
            record_parallax_lock_state(collection, psd_file.camera)
            self.report({"INFO"}, "视差锁定已启用")
        else:
            restore_parallax_lock_state(collection)
            self.report({"INFO"}, "视差锁定已禁用")

        psd_file.parallax_maybe_locked = psd_has_locked_layers(psd_file)

        return {"FINISHED"}


# ---------------- 注册与反注册 ----------------


class PSD_AddonPreferences(AddonPreferences):
    bl_idname = __package__

    log_to_text: BoolProperty(
        name="写入文本块",
        description="将调试日志写入Blender文本数据块（_PSD_Importer_Debug_Log），随.blend文件保存",
        default=False,
        update=lambda self, ctx: (
            setattr(constants, "LOG_TO_TEXT", self.log_to_text)
            if hasattr(constants, "LOG_TO_TEXT") else None
        ),
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "log_to_text")


classes = (
    PSD_AddonPreferences,
    LayerChecksum,
    PendingLayerItem,
    PSDCardLayerItem,
    PSD_UL_CardLayers,
    PSDFileRecord,
    PSDImportProperties,
    PSD_PT_ImportPanel,
    PSD_PT_Settings,
    PSD_OT_ImportLayers,
    PSD_OT_RefreshLayers,
    PSD_OT_ChangeFilepath,
    PSD_OT_ToggleBlendMode,
    PSD_OT_ToggleLayerList,
    PSD_OT_ToggleGroupExpand,
    PSD_OT_ClearLayerSearch,
    PSD_OT_ToggleLayerChecked,
    PSD_OT_SelectLayerRow,
    PSD_OT_AppendSelectedLayers,
    PSD_OT_SelectAllLayers,
    PSD_OT_InvertLayerSelection,
    PSD_OT_RescanLayers,
    PSD_OT_DeleteLayerObject,
    PSD_OT_ToggleTextureExtension,
    PSD_OT_CheckDependencies,
    PSD_OT_ForceRefreshLayers,
    PSD_OT_DeletePSDFile,
    PSD_OT_RefreshSelectedLayers,
    PSD_OT_ToggleTextureExtensionSelected,
    PSD_OT_ToggleBlendModeSelected,
    PSD_OT_MatchSelectedToCamera,
    PSD_OT_ToggleParallaxLockSelected,
    PSD_OT_MatchToCamera,
    PSD_OT_ToggleParallaxLock,
    PSD_UL_LayerList,
    PSD_OT_ToggleLayerGroup,
    PSD_OT_ToggleLayerExpand,
    PSD_OT_ToggleLayerCheck,
    PSD_OT_SelectLayers,
)


def register():
    try:
        unregister()
    except (AttributeError, TypeError, RuntimeError):
        pass

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            try:
                bpy.utils.unregister_class(cls)
                bpy.utils.register_class(cls)
            except (AttributeError, TypeError, RuntimeError, ValueError):
                pass
    bpy.types.Scene.psd_import_tool = PointerProperty(type=PSDImportProperties)

    # 注册异步执行器（延迟导入，避免模块加载时的循环依赖）
    try:
        from .async_runner import PSD_OT_AsyncJob
        bpy.utils.register_class(PSD_OT_AsyncJob)
    except (ImportError, AttributeError, TypeError, RuntimeError, ValueError) as e:
        print(f"[PSD] 注册异步执行器失败: {e}")

    try:
        if parallax_scene_update_handler not in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.append(parallax_scene_update_handler)
    except (AttributeError, TypeError, RuntimeError):
        pass

    try:
        for scene in bpy.data.scenes:
            if hasattr(scene, "psd_import_tool"):
                for psd_file in scene.psd_import_tool.file_records:
                    if psd_file.camera:
                        if not psd_file.last_camera_transform:
                            psd_file.last_camera_transform = str(
                                psd_file.camera.matrix_world
                            )
                        if "last_camera_position" not in psd_file:
                            psd_file["last_camera_position"] = list(
                                psd_file.camera.matrix_world.translation
                            )
    except AttributeError:
        pass
    except (TypeError, RuntimeError):
        pass

    # 同步偏好设置中的 LOG_TO_TEXT 到模块变量（偏好从文件恢复时 update 回调可能不触发）
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        constants.LOG_TO_TEXT = prefs.log_to_text
    except (KeyError, AttributeError):
        pass


def unregister():
    try:
        if parallax_scene_update_handler in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(parallax_scene_update_handler)
    except (AttributeError, TypeError, RuntimeError):
        pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except (AttributeError, TypeError, RuntimeError):
            pass

    # 注销异步执行器
    try:
        from .async_runner import PSD_OT_AsyncJob
        bpy.utils.unregister_class(PSD_OT_AsyncJob)
    except (ImportError, AttributeError, TypeError, RuntimeError, ValueError):
        pass

    try:
        del bpy.types.Scene.psd_import_tool
    except (AttributeError, TypeError, KeyError):
        pass


if __name__ == "__main__":
    register()
