"""PSD 视差锁定：端到端（走真实 handler 入口）。

验证 `parallax_scene_update_handler` 这条真实路径：
  ① 变焦后 handler 会把相机 dolly 到位（相机真的移动）
  ② 同时把各层适配好（构图冻结）
  ③ 相机视图渲染 —— 变焦前后画面应完全一致
  ④ 顶视图渲染 —— 应能看到相机明显后退
"""
import bpy
import sys
import os
import math
import importlib
import tempfile

sys.stdout.reconfigure(encoding="utf-8")
# 路径自己推 —— 别硬编码某台机器的绝对路径（换机器/换盘符就跑不起来，
# 而且报错看不出是路径问题）。_dev_tools/ 在插件包内，往上两级 = addons。
_HERE = os.path.dirname(os.path.abspath(__file__))   # .../psd_layer_importer_plus/_dev_tools
_PKG = os.path.dirname(_HERE)                        # .../psd_layer_importer_plus
ADDONS = os.path.dirname(_PKG)                       # .../addons
sys.path.insert(0, ADDONS)

# ⚠️ 顺序：先 read_factory_settings（它会重置 addons 列表），再启用插件，
#    否则刚启用的插件会被重置掉 → scene 上没有 psd_import_tool。
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.preferences.addon_enable(module="psd_layer_importer_plus")
pu = importlib.import_module("psd_layer_importer_plus.parallax_utils")
C = importlib.import_module("psd_layer_importer_plus.constants")

P, F = [], []
def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-44s %s" % ("PASS" if c else "FAIL", n, d))

OUT = os.path.join(tempfile.gettempdir(), "_psd_dolly")
os.makedirs(OUT, exist_ok=True)

scene = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0.0, 0.0)
scene.camera = cam
coll = bpy.data.collections.new("PSD")
scene.collection.children.link(coll)

# 三层：不同深度 + 不同颜色（便于看图）
for i, (x, depth, col) in enumerate([(-4.0, 10.0, (0.9, 0.2, 0.2, 1)),
                                     (0.0, 16.0, (0.2, 0.8, 0.3, 1)),
                                     (4.0, 22.0, (0.2, 0.4, 0.9, 1))]):
    # ⚠️ 用【薄立方体】而不是 plane：plane 默认躺在 XY 平面、侧对相机 → 渲出来是全黑，
    #    会制造"变焦前后像素差 0"的**假阳性**（空对空）。薄块两个视图都能看到。
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=(x, cam.location.y + depth, 0.0))
    o = bpy.context.active_object
    o.scale = (3.0, 0.06, 3.0)
    o.name = "Layer%d" % i
    o[C.ATTR_LAYER_ID] = o.name
    m = bpy.data.materials.new("M%d" % i); m.use_nodes = True
    m.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = col
    o.data.materials.append(m)
    scene.collection.objects.unlink(o)
    coll.objects.link(o)
bpy.context.view_layer.update()

# file_records（handler 入口）
tool = scene.psd_import_tool
rec = tool.file_records.add()
rec.collection = coll
rec.parallax_maybe_locked = True

# 顶层正交相机（顶视图，看相机位置）
td = bpy.data.cameras.new("TopCam"); td.type = "ORTHO"
td.ortho_scale = 56.0            # 覆盖 y ∈ [-22, +18]（相机后退后仍在画面内）
top = bpy.data.objects.new("TopCam", td)
scene.collection.objects.link(top)
top.location = (0.0, -2.0, 60.0)

# 相机替身（渲染里相机对象不显示，用锥体代表）
import bmesh
pm = bpy.data.meshes.new("Proxy")
bm = bmesh.new()
bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=4,
                      radius1=0.0, radius2=2.4, depth=7.0)
bm.to_mesh(pm); bm.free()
proxy = bpy.data.objects.new("Proxy", pm)
scene.collection.objects.link(proxy)
mat = bpy.data.materials.new("Px"); mat.use_nodes = True
b = mat.node_tree.nodes["Principled BSDF"]
b.inputs["Base Color"].default_value = (1.0, 0.5, 0.0, 1)
b.inputs["Emission Color"].default_value = (1.0, 0.45, 0.0, 1)
b.inputs["Emission Strength"].default_value = 2.0
pm.materials.append(mat)

if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
scene.render.engine = "CYCLES"
scene.cycles.samples = 16
scene.cycles.device = "CPU"


def shot(name, camobj, proxy_on, rx=760, ry=320):
    # ⚠️ 渲染会改 render.resolution，而 calculate_camera_sensor_dimensions() 依赖它，
    #    进而改变 world_to_screen_coords() 的归一化口径 → 会污染后面的构图断言。
    #    故渲染前后把分辨率还原（测量前提必须一致）。
    _rx, _ry = scene.render.resolution_x, scene.render.resolution_y
    proxy.hide_render = not proxy_on
    scene.camera = camobj
    scene.render.resolution_x, scene.render.resolution_y = rx, ry
    scene.render.filepath = os.path.join(OUT, name + ".png")
    bpy.ops.render.render(write_still=True)
    scene.render.resolution_x, scene.render.resolution_y = _rx, _ry
    print("SHOT", name)


def sync_proxy():
    proxy.matrix_world = cam.matrix_world.copy()
    bpy.context.view_layer.update()


# ── 锁定 + 拍"变焦前" ──
pu.record_parallax_lock_state(coll, cam)
locked = [o for o in pu.get_all_objects_recursive(coll) if pu.is_obj_parallax_locked(o)]
chk("锁定 3 层", len(locked) == 3, "→%d" % len(locked))
cam0 = cam.location.copy()
shot("A70_view_t50", cam, False)
# 顶视图用竖幅：ortho_scale 作用于宽度方向，竖幅才能让它的长边覆盖世界 Y 轴
sync_proxy(); shot("B70_top_t50", top, True, 420, 760)

# ── 变焦 → 真实 handler ──
cam.data.lens = 85.0
bpy.context.view_layer.update()
pu.parallax_scene_update_handler(scene)      # ★ 真实入口
cam1 = cam.location.copy()

shot("C70_view_t85", cam, False)
sync_proxy(); shot("D70_top_t85", top, True, 420, 760)

shift = (cam1 - cam0).length
ref = pu.get_parallax_reference_depth(locked)
print("\n  相机 %.3f,%.3f,%.3f → %.3f,%.3f,%.3f" % (tuple(cam0) + tuple(cam1)))
print("  位移=%.4f  理论=%.4f" % (shift, ref * 0.7))
chk("handler 让相机移动了", shift > 1e-3, "→%.4f" % shift)
chk("位移 = ref×(k−1)", abs(shift - ref * 0.7) < 1e-3, "%.4f vs %.4f" % (shift, ref * 0.7))
chk("applied_zoom 已更新", abs(float(cam.get(pu.APPLIED_ZOOM_KEY, -1)) - 1.7) < 1e-4,
    "→%.4f" % float(cam.get(pu.APPLIED_ZOOM_KEY, -1)))

# 构图冻结：各层屏幕坐标
errs = []
for o in locked:
    sx, sy, _ = pu.world_to_screen_coords(pu.get_object_center_world_pos(o), cam)
    errs.append(max(abs(sx - o["locked_screen_x"]), abs(sy - o["locked_screen_y"])))
chk("构图精确冻结（屏幕坐标不变）", max(errs) < 1e-5, "max=%.2e" % max(errs))

print("\nPASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("PSD_E2E_DONE", OUT)
