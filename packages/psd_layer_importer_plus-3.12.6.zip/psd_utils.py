"""PSD Layer Importer PLUS — PSD解析、缓存、图像加载"""
import bpy
import os
import hashlib
import re
import json
from typing import Optional, Tuple, List, Dict, Any
from .constants import (
    _psd_log, PSD_DEBUG, ATTR_LAYER_ID, ATTR_LAYER_BBOX,
    MESH_SCALE_FACTOR, LAYER_Z_OFFSET, MAX_FILENAME_LENGTH,
    PNG_COMPRESS_LEVEL, MIN_LAYER_SIZE, DEFAULT_ALPHA,
    UV_BOTTOM_LEFT, UV_TOP_LEFT, UV_TOP_RIGHT, UV_BOTTOM_RIGHT,
    ATTR_INITIAL_TRANSFORM, UV_ADJUST_NODEGROUP_PREFIX,
)

def get_visible_layers(psd, include_hidden: bool = False) -> List[Tuple[int, int, Any, str]]:
    """
    获取PSD文件中所有可见的非组图层

    Args:
        psd: PSDImage对象

    Returns:
        列表，每项为 (原始索引, 显示索引, 图层对象, 图层标识符)
    """
    visible_layers = []
    display_index = 0
    # 跳过原因分类计数：出「怎么少收了几层」这类问题时，一眼能看出卡在哪一类
    n_total = 0
    n_group = 0
    n_hidden = 0
    n_zero = 0

    for i, layer in enumerate(psd.descendants()):
        n_total += 1
        # 跳过组图层（is_group 是方法，需要调用）
        if hasattr(layer, "is_group") and callable(layer.is_group) and layer.is_group():
            n_group += 1
            continue

        # 跳过不可见图层（含祖先组不可见——与 extract_layer_hierarchy 口径一致）
        if not _is_effectively_visible(layer, include_hidden):
            n_hidden += 1
            continue

        # 跳过尺寸为0的图层
        left, top, right, bottom = _get_layer_bbox(layer)
        if right - left <= MIN_LAYER_SIZE or bottom - top <= MIN_LAYER_SIZE:
            n_zero += 1
            continue

        layer_identifier = create_layer_identifier(layer, display_index)
        visible_layers.append((i, display_index, layer, layer_identifier))
        display_index += 1

    # 汇总一行（本函数每次解析只调用一次，逐层打会刷屏，故只报合计）
    _psd_log(
        f"[PSD结构] get_visible_layers: descends={n_total} → 收 {len(visible_layers)} 层 "
        f"| 跳过：组 {n_group} / 隐藏 {n_hidden} / 零尺寸 {n_zero} "
        f"| include_hidden={include_hidden}"
    )
    return visible_layers


# ---------------- PSD层级结构处理 ----------------


def extract_layer_hierarchy(psd, include_hidden: bool = False) -> Tuple[List[dict], List[dict]]:
    """
    递归遍历PSD的图层树，提取层级结构。

    Args:
        psd: PSDImage对象

    Returns:
        (tree, flat_list) 元组：
        - tree: 层级树结构，每项为 {"type": "group"/"layer", "name": str, ...}
        - flat_list: 扁平列表，每项为 {
            "layer": PSD图层对象,
            "identifier": str,
            "group_path": List[str],  # 从根到叶的组名称路径，根图层为[]
            "display_index": int,
          }
    """
    _psd_log("[PSD结构] >> extract_layer_hierarchy: 开始提取PSD层级结构")

    display_index = 0  # 全局显示序号（闭包变量，通过 nonlocal 修改）

    def _recursive_build(nodes, group_path):
        """递归构建层级树"""
        nonlocal display_index
        tree_children = []
        path_str = "/".join(group_path) if group_path else "(根目录)"
        for layer in nodes:
            is_group = (
                hasattr(layer, "is_group")
                and callable(layer.is_group)
                and layer.is_group()
            )

            if is_group:
                if (not include_hidden) and hasattr(layer, "visible") and not bool(layer.visible):
                    _psd_log(f"[PSD结构]   - 跳过不可见图层组: {layer.name} (路径: {path_str})")
                    continue

                _psd_log(f"[PSD结构]   - 进入图层组: {layer.name} (路径: {path_str})")
                child_tree = _recursive_build(layer, group_path + [layer.name])
                if not child_tree:
                    _psd_log(f"[PSD结构]   - 跳过空组: {layer.name} (无可见图层)")
                    continue

                _psd_log(f"[PSD结构]   - 组 {layer.name} 包含 {len(child_tree)} 个子项")
                tree_children.append({
                    "type": "group",
                    "name": layer.name,
                    "children": child_tree,
                })
            else:
                if (not include_hidden) and hasattr(layer, "visible") and not bool(layer.visible):
                    _psd_log(f"[PSD结构]   - 跳过不可见图层: {layer.name} (路径: {path_str})")
                    continue
                left, top, right, bottom = _get_layer_bbox(layer)
                if right - left <= MIN_LAYER_SIZE or bottom - top <= MIN_LAYER_SIZE:
                    _psd_log(f"[PSD结构]   - 跳过零尺寸图层: {layer.name} ({right-left}x{bottom-top})")
                    continue

                identifier = create_layer_identifier(layer, display_index)
                entry = {
                    "type": "layer",
                    "name": layer.name,
                    "layer": layer,
                    "identifier": identifier,
                    "group_path": list(group_path),
                    "display_index": display_index,
                }
                _psd_log(f"[PSD结构]   - 图层 #{display_index}: {layer.name} (路径: {path_str}, id: {identifier[-40:]}...)")
                tree_children.append(entry)
                display_index += 1

        return tree_children

    # psd 本身是可迭代的（根级图层列表）
    tree = _recursive_build(psd, [])
    _psd_log(f"[PSD结构] << extract_layer_hierarchy: 树构建完成，共 {display_index} 个可见图层")

    # 从树中提取扁平列表
    flat_list = []

    def _flatten(branch, out_list):
        for item in branch:
            if item["type"] == "layer":
                out_list.append(item)
            elif item["type"] == "group":
                _flatten(item["children"], out_list)

    _flatten(tree, flat_list)
    _psd_log(f"[PSD结构] << extract_layer_hierarchy: 扁平列表 {len(flat_list)} 项，层级树 {len(tree)} 个根级条目")

    return tree, flat_list


def filter_hierarchy_by_ids(hierarchy_tree, active_ids):
    """
    按「已导入清单」裁剪层级树：只保留 identifier ∈ active_ids 的图层；
    组仅在含有保留图层时保留（避免建出空文件夹集合）。不修改入参。

    Args:
        hierarchy_tree: extract_layer_hierarchy 返回的 tree
        active_ids: 要保留的 layer identifier 集合

    Returns:
        裁剪后的新树
    """
    out = []
    for item in hierarchy_tree:
        if item["type"] == "layer":
            if item["identifier"] in active_ids:
                out.append(dict(item))
        else:
            kids = filter_hierarchy_by_ids(item["children"], active_ids)
            if kids:
                g = dict(item)
                g["children"] = kids
                out.append(g)
    return out


def build_layer_list_json(hierarchy_tree) -> str:
    """层级树 → 卡片图层列表用的扁平 JSON（只存显示所需的最小字段）。

    每项：{"i": identifier, "n": name, "d": depth, "g": is_group, "m": 变化标记}
    - 组用 "GRP:<组路径>" 作 identifier（与图层选择弹窗口径一致）
    - m（mark）暂留空串，供「重新扫描」写 "new"/"changed"
    """
    items = []

    def _walk(branch, depth, path):
        for node in branch:
            if node.get("type") == "group":
                gpath = path + [node.get("name", "")]
                items.append({
                    "i": "GRP:" + "/".join(gpath),
                    "n": node.get("name", ""),
                    "d": depth,
                    "g": True,
                    "m": "",
                })
                _walk(node.get("children", []), depth + 1, gpath)
            else:
                items.append({
                    "i": node.get("identifier", ""),
                    "n": node.get("name", ""),
                    "d": depth,
                    "g": False,
                    "m": "",
                })

    _walk(hierarchy_tree, 0, [])
    return json.dumps(items, ensure_ascii=False)


def parse_layer_list_json(raw) -> list:
    """解析卡片图层列表 JSON → list[dict]（缺失/损坏时返回 []，不抛）。"""
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return []
    if not isinstance(data, list):
        return []
    out = []
    for it in data:
        if not isinstance(it, dict):
            continue
        out.append({
            "i": it.get("i", ""),
            "n": it.get("n", ""),
            "d": int(it.get("d", 0) or 0),
            "g": bool(it.get("g", False)),
            "m": it.get("m", "") or "",
        })
    return out


def get_imported_id_set(record) -> set:
    """读出「已导入清单」（勾选基准）。唯一来源 = record.imported_layer_ids。"""
    raw = getattr(record, "imported_layer_ids", "") or ""
    return set(x for x in raw.split(",") if x)


def ensure_collection_tree(
    parent_collection, hierarchy_tree, base_name
) -> None:
    """
    根据层级树，在 parent_collection 下递归创建子集合。
    对于已存在的同名集合，直接复用。

    Args:
        parent_collection: 父级Blender集合
        hierarchy_tree: extract_layer_hierarchy 返回的 tree
        base_name: PSD文件名（用于集合名前缀，避免同名冲突）
    """
    _psd_log(f"[PSD结构] >> ensure_collection_tree: 在集合 '{parent_collection.name}' 下构建层级树")
    created_count = 0
    reused_count = 0

    def _build(branch, current_collection, depth=0):
        nonlocal created_count, reused_count
        indent = "  " * depth
        # 组集合顺序：psd_tools 正序遍历是"从底层到顶层"(面板的反序)。
        # 要让集合与 PSD 面板"顶对顶"，需按面板顺序(即 reversed)处理组。
        # 只调整组的 link 先后，不影响图层对象的归组(那走 get_target_collection_for_layer，
        # 不依赖集合 link 顺序)，也不影响图层 Z 轴/命名(由 display_index 决定)。
        groups_in_panel = [item for item in reversed(branch) if item["type"] == "group"]
        for item in groups_in_panel:
            # 创建或查找同名子集合
            # 安全说明：只遍历 children（不修改），找到后才 link，不会触发迭代时修改异常
            group_col = None
            for child in current_collection.children:
                if child.name == item["name"]:
                    group_col = child
                    break
            if group_col is None:
                group_col = bpy.data.collections.new(item["name"])
                current_collection.children.link(group_col)
                created_count += 1
                _psd_log(f"[PSD结构] {indent}创建集合 '{item['name']}'")
            else:
                reused_count += 1
                _psd_log(f"[PSD结构] {indent}复用集合 '{item['name']}'")
            _build(item["children"], group_col, depth + 1)
        # layer 类型不需要在这里处理，由导入循环负责创建对象并放入正确集合

    _build(hierarchy_tree, parent_collection)
    _psd_log(f"[PSD结构] << ensure_collection_tree: 创建 {created_count} 个集合，复用 {reused_count} 个集合")


def find_layer_object_in_tree(
    collection, layer_identifier: str
) -> Optional[Any]:
    """
    在集合树中递归查找指定标识符的图层对象。

    Args:
        collection: 起始集合
        layer_identifier: 图层唯一标识符

    Returns:
        找到的Blender对象，或None
    """
    _psd_log(f"[PSD结构] find_layer_object_in_tree: 在集合 '{collection.name}' 中查找 id={layer_identifier[-40:]}...")
    for obj in collection.objects:
        if obj.get(ATTR_LAYER_ID) == layer_identifier:
            _psd_log(f"[PSD结构] find_layer_object_in_tree: 找到对象 '{obj.name}'")
            return obj
    for child_collection in collection.children:
        result = find_layer_object_in_tree(child_collection, layer_identifier)
        if result is not None:
            return result
    _psd_log(f"[PSD结构] find_layer_object_in_tree: 未找到 id={layer_identifier[-40:]}...")
    return None


def find_all_layer_objects(collection, layer_identifier: str) -> list:
    """找出集合树里**所有**带该标识符的图层对象。

    追加导入会产生多个同 identifier 的副本，行尾 ✕ 需要能区分「原始那份」
    和后续追加的副本 —— 单找第一个（find_layer_object_in_tree）会误删。
    """
    out = []

    def _walk(col):
        for obj in col.objects:
            try:
                if obj.get(ATTR_LAYER_ID) == layer_identifier:
                    out.append(obj)
            except Exception:
                pass
        for child in col.children:
            _walk(child)

    try:
        _walk(collection)
    except Exception:
        pass
    return out


def serialize_hierarchy_snapshot(hierarchy_tree) -> str:
    """
    将层级树序列化为JSON字符串，用于存储快照。
    只保留结构信息（组路径），不保留图层细节。

    Args:
        hierarchy_tree: extract_layer_hierarchy 返回的 tree

    Returns:
        JSON字符串
    """
    paths = []

    def _collect_paths(branch, current_path):
        for item in branch:
            if item["type"] == "group":
                path = current_path + [item["name"]]
                paths.append("/".join(path))
                _collect_paths(item["children"], path)

    _collect_paths(hierarchy_tree, [])
    snapshot = json.dumps(paths, ensure_ascii=False, sort_keys=True)
    _psd_log(f"[PSD结构] serialize_hierarchy_snapshot: 快照路径数={len(paths)}, 内容={snapshot[:200]}")
    return snapshot


def get_target_collection_for_layer(
    parent_collection, group_path
) -> Any:
    """
    根据 group_path 获取图层对象应该放入的目标集合。
    路径上的每个组都会查找或创建对应的Blender子集合。

    Args:
        parent_collection: PSD主集合
        group_path: 组路径列表（可能为空）

    Returns:
        目标Blender集合
    """
    if not group_path:
        _psd_log(f"[PSD结构] get_target_collection_for_layer: 根图层 -> 集合 '{parent_collection.name}'")
        return parent_collection
    current = parent_collection
    path_so_far = parent_collection.name
    for group_name in group_path:
        found = None
        for child in current.children:
            if child.name == group_name:
                found = child
                break
        if found is None:
            found = bpy.data.collections.new(group_name)
            current.children.link(found)
            _psd_log(f"[PSD结构] get_target_collection_for_layer: 创建集合 '{group_name}' (路径: {path_so_far}/{group_name})")
        else:
            _psd_log(f"[PSD结构] get_target_collection_for_layer: 复用集合 '{group_name}' (路径: {path_so_far}/{group_name})")
        current = found
        path_so_far = f"{path_so_far}/{group_name}"
    return current


def sync_collection_structure(
    psd, psd_file, parent_collection, base_name, active_ids=None
) -> Tuple[dict, List[dict]]:
    """
    刷新时同步集合结构：对比当前PSD的层级与存储的快照，
    按需创建/删除集合，移动对象。
    此函数内部调用 extract_layer_hierarchy，调用方无需重复提取。

    Args:
        psd: PSDImage对象
        psd_file: PSDFileRecord
        parent_collection: PSD主集合
        base_name: PSD文件名

    Returns:
        (id_to_path, flat_list) 元组：
        - id_to_path: {layer_identifier: group_path} 映射
        - flat_list: 包含所有图层的扁平列表
    """
    _psd_log(f"[PSD结构] >> sync_collection_structure: 开始同步集合结构 (集合: '{parent_collection.name}')")

    # 读取旧快照
    old_snapshot = psd_file.group_hierarchy if psd_file.group_hierarchy else "[]"
    _psd_log(f"[PSD结构] sync_collection_structure: 旧快照 = {old_snapshot[:200]}")

    # 提取当前PSD的层级结构（只做一次）
    hierarchy_tree, flat_list = extract_layer_hierarchy(psd)
    # 「清单基准」：只保留已导入的图层（active_ids=None = 无清单，沿用全量=旧行为）
    if active_ids is not None:
        hierarchy_tree = filter_hierarchy_by_ids(hierarchy_tree, active_ids)
        flat_list = [e for e in flat_list if e["identifier"] in active_ids]
    new_snapshot = serialize_hierarchy_snapshot(hierarchy_tree)
    _psd_log(f"[PSD结构] sync_collection_structure: 新快照 = {new_snapshot[:200]}")

    # 对比快照，判断结构是否变化
    if old_snapshot == new_snapshot:
        _psd_log(f"[PSD结构] sync_collection_structure: 结构未变化，跳过重建")
    else:
        _psd_log(f"[PSD结构] sync_collection_structure: 结构已变化，重建集合树")
        ensure_collection_tree(parent_collection, hierarchy_tree, base_name)

    # 构建 {identifier: group_path} 映射
    id_to_path = {}
    for entry in flat_list:
        id_to_path[entry["identifier"]] = entry["group_path"]
    _psd_log(f"[PSD结构] sync_collection_structure: 映射了 {len(id_to_path)} 个图层到对应集合")

    # 更新快照
    psd_file.group_hierarchy = new_snapshot
    _psd_log(f"[PSD结构] << sync_collection_structure: 完成")

    return id_to_path, flat_list


def move_layer_object_to_collection(obj, target_collection) -> bool:
    """
    将对象从当前集合移到目标集合。
    如果已在目标集合中，不做任何操作。

    Returns:
        bool: 是否执行了移动
    """
    if not obj or not target_collection:
        _psd_log(f"[PSD结构] move_layer_object_to_collection: 跳过移动（obj={obj}, target={target_collection}）")
        return False

    old_cols = [c.name for c in obj.users_collection]

    # 检查是否已经在目标集合中
    if obj.name in target_collection.objects:
        _psd_log(f"[PSD结构] move_layer_object_to_collection: '{obj.name}' 已在集合 '{target_collection.name}' 中，无需移动")
        return False

    # 从所有当前集合中移除
    for col in list(obj.users_collection):
        col.objects.unlink(obj)

    # 链接到目标集合
    target_collection.objects.link(obj)
    _psd_log(f"[PSD结构] move_layer_object_to_collection: '{obj.name}' 从 {old_cols} -> '{target_collection.name}'")
    return True


# ---------------- 性能优化：缓存与并行 ----------------


def sanitize_filename(name: str) -> str:
    """
    将字符串转换为安全的文件名

    移除非字母数字字符（保留下划线、连字符和点），
    并截断到最大文件名长度。

    Args:
        name: 原始字符串

    Returns:
        安全的文件名
    """
    safe = re.sub(r"[^\w\-\.]+", "_", name)
    return safe[:MAX_FILENAME_LENGTH]


# 贴图存放相关的「变化才打」日志哨兵。
# ⚠️ get_texture_store_mode / get_cache_root 在导入/刷新时会被**逐层**调用
#    （经 get_cache_png_path），无条件打日志会刷屏（46 层 = 46 条）。
#    但「模式/目录变了」是必须留痕的事件 —— 用户「切了外放却没生效」时，
#    唯一能查的就是这几行。所以：值没变不打，变了才打。
_last_store_mode = None
_last_cache_root = None


def get_texture_store_mode() -> str:
    """读「⚙ 设置 → 贴图存放」：返回 "PACK"（默认）或 "EXTERNAL"。

    EXTERNAL 需要「工程已保存」才有根目录放贴图；**未保存的工程没有根目录**，
    这时统一回退成 PACK —— 否则贴图无处可落，等于功能坏掉。
    异常安全：读不到设置一律按 PACK。
    """
    reason = ""
    try:
        mode = bpy.context.scene.psd_import_tool.texture_store_mode
    except Exception as e:
        mode = None
        reason = "读取设置失败(%s)，回退打包" % type(e).__name__

    result = "PACK"
    if mode == "EXTERNAL":
        try:
            if bpy.data.filepath:
                result = "EXTERNAL"
                reason = "设置=外放，工程已保存"
            else:
                reason = "设置=外放，但工程未保存(没有放置根目录)，回退打包"
        except Exception as e:
            reason = "读取工程路径失败(%s)，回退打包" % type(e).__name__
    elif not reason:
        reason = "设置=%r（打包进工程）" % (mode,)

    # 哨兵比的是「设置值 + 生效值」的组合，不是只比生效值 ——
    # 否则用户把设置切到外放、但因工程未保存而回退打包时，
    # 生效值没变 → 不打日志 → 恰好漏掉了最该看到的那一行。
    global _last_store_mode
    key = (mode, result)
    if key != _last_store_mode:
        _psd_log(f"[PSD-存储] 贴图存放模式: 设置={mode!r} → 生效={result} | {reason}")
        _last_store_mode = key
    return result


def get_cache_root() -> str:
    """
    获取 PSD 贴图/缓存的根目录路径。

    · 「打包进工程」(PACK)：项目已保存 → <项目目录>/psd_cache；未保存 → 系统临时目录。
    · 「外放 PSD_texture」(EXTERNAL)：<项目目录>/PSD_texture（工程必须已保存）。
      外放时贴图不打包进 .blend，工程体积小，但拷贝工程要连贴图一起拷。

    Returns:
        根目录的绝对路径
    """
    reason = ""
    try:
        import tempfile
        blend_filepath = bpy.data.filepath
        if get_texture_store_mode() == "EXTERNAL":
            # 外放：贴图落到工程根目录的 PSD_texture 文件夹
            cache_root = os.path.join(os.path.dirname(blend_filepath), "PSD_texture")
            reason = "外放 → 工程目录/PSD_texture"
        elif blend_filepath:
            # 打包进工程：中间产物仍放 psd_cache（随后 pack 进 .blend）
            project_dir = os.path.dirname(blend_filepath)
            cache_root = os.path.join(project_dir, "psd_cache")
            reason = "打包 → 工程目录/psd_cache（随后 pack 进 .blend）"
        else:
            # 工程未保存：临时目录
            cache_root = os.path.join(tempfile.gettempdir(), "blender_psd_cache")
            reason = "工程未保存 → 系统临时目录"
    except (OSError, IOError) as e:
        import tempfile
        cache_root = os.path.join(tempfile.gettempdir(), "blender_psd_cache")
        reason = "路径读取异常(%s) → 系统临时目录" % type(e).__name__

    os.makedirs(cache_root, exist_ok=True)

    # 同样「变化才打」：一次导入里本函数被逐层调用，无条件打会刷屏
    global _last_cache_root
    if cache_root != _last_cache_root:
        _psd_log(f"[PSD-存储] 贴图根目录 = {cache_root} | {reason}")
        _last_cache_root = cache_root
    return cache_root


def get_cache_png_path(
    psd_filepath: str, index: int, layer_identifier: str, layer_name: str
) -> str:
    """
    生成图层缓存PNG文件的完整路径

    Args:
        psd_filepath: PSD文件路径
        index: 图层序号（用于排序）
        layer_identifier: 图层唯一标识符
        layer_name: 图层名称

    Returns:
        缓存PNG文件的完整路径
    """
    base = bpy.path.display_name_from_filepath(psd_filepath)
    folder = os.path.join(get_cache_root(), sanitize_filename(base))
    os.makedirs(folder, exist_ok=True)
    filename = f"{index:05d}_{sanitize_filename(layer_identifier)}_{sanitize_filename(layer_name)}.png"
    return os.path.join(folder, filename)


def cleanup_cache_files(psd_filepath: str) -> bool:
    """
    清理指定PSD文件的外部缓存文件和文件夹

    Args:
        psd_filepath: PSD文件路径

    Returns:
        bool: 清理是否成功
    """
    # ⚠️ 本函数会**真删文件**，且外放模式(EXTERNAL)下删的是 PSD_texture/ 里的
    #    **贴图资产**（不是可重建的缓存）。所以每一步都留痕，出问题能追溯。
    #    原来这里用 print() 且无 [PSD-] 标签 —— 混在几百行长日志里搜不到，
    #    也不会写进「_PSD_Importer_Debug_Log」文本块。
    try:
        # 获取PSD文件对应的缓存文件夹
        base = bpy.path.display_name_from_filepath(psd_filepath)
        mode = get_texture_store_mode()
        # 同一操作内只取一次根目录（原来调了两次，存在中途状态漂移的余地）
        cache_root = get_cache_root()
        cache_folder = os.path.join(cache_root, sanitize_filename(base))
        _psd_log(
            f"[PSD-清理] >> cleanup_cache_files: psd='{psd_filepath}', "
            f"存放模式={mode}, 目标目录='{cache_folder}'"
        )

        # 检查缓存文件夹是否存在
        if not os.path.exists(cache_folder):
            _psd_log(f"[PSD-清理] << 目录不存在，无需清理: '{cache_folder}'")
            return True  # 文件夹不存在，认为清理成功

        # 安全检查：确保这是一个缓存文件夹
        if not cache_folder.startswith(cache_root):
            _psd_log(
                f"[PSD-清理] 路径安全检查未通过(不在根目录 '{cache_root}' 下)，"
                f"跳过清理: '{cache_folder}'"
            )
            return False

        # 删除文件夹中的所有PNG文件
        deleted_files = 0
        failed_files = 0
        for filename in os.listdir(cache_folder):
            if filename.lower().endswith(".png"):
                file_path = os.path.join(cache_folder, filename)
                try:
                    os.remove(file_path)
                    deleted_files += 1
                except Exception as e:
                    failed_files += 1
                    _psd_log(
                        f"[PSD-清理] 删除单个文件失败: '{file_path}', "
                        f"异常={type(e).__name__}: {e}"
                    )

        # 检查文件夹是否为空，如果为空则删除文件夹
        try:
            remaining_files = os.listdir(cache_folder)
            if not remaining_files:
                os.rmdir(cache_folder)
                _psd_log(
                    f"[PSD-清理] << 已清理并删除目录: '{cache_folder}'，"
                    f"删除 {deleted_files} 个PNG（失败 {failed_files}）"
                )
            else:
                _psd_log(
                    f"[PSD-清理] << 已清理 {deleted_files} 个PNG（失败 {failed_files}），"
                    f"目录仍有 {len(remaining_files)} 个其他文件，保留目录: '{cache_folder}'"
                )
        except Exception as e:
            _psd_log(
                f"[PSD-清理] 删除目录失败: '{cache_folder}', "
                f"异常={type(e).__name__}: {e}"
            )

        return True

    except (OSError, IOError, PermissionError) as e:
        _psd_log(
            f"[PSD-清理] << 清理出错: psd='{psd_filepath}', "
            f"异常={type(e).__name__}: {e}"
        )
        return False


def _get_layer_bbox(layer: Any) -> Tuple[int, int, int, int]:
    try:
        left, top, right, bottom = (
            int(layer.left),
            int(layer.top),
            int(layer.right),
            int(layer.bottom),
        )
    except (AttributeError, TypeError, ValueError):
        try:
            # 兼容 psd_tools 的 bbox 接口
            b = layer.bbox
            left, top, right, bottom = int(b.x1), int(b.y1), int(b.x2), int(b.y2)
        except (AttributeError, TypeError):
            left = top = 0
            right = int(getattr(layer, "width", 0))
            bottom = int(getattr(layer, "height", 0))
    return left, top, right, bottom


def render_layer_rgba(layer: Any) -> Optional[Any]:
    try:
        try:
            img = layer.topil()
        except (AttributeError, NotImplementedError):
            img = layer.composite()
        if img.mode != "RGBA":
            img = img.convert("RGBA")
        # 基于图层边界裁剪到画布区域尺寸
        l, t, r, b = _get_layer_bbox(layer)
        bbox_w, bbox_h = max(r - l, 0), max(b - t, 0)
        try:
            if (
                bbox_w > 0
                and bbox_h > 0
                and (img.size[0] != bbox_w or img.size[1] != bbox_h)
            ):
                img = img.crop((l, t, r, b))
        except (OSError, IOError, ValueError):
            pass

        # Alpha边缘清理：将透明像素RGB设为黑，避免白边
        try:
            import numpy as np

            img_array = np.array(img)
            alpha_channel = img_array[:, :, 3]
            transparent_mask = alpha_channel == 0
            img_array[transparent_mask, 0:3] = 0
            from PIL import Image

            img = Image.fromarray(img_array, "RGBA")
            _psd_log(f"[PSD-渲染] Alpha清理(numpy): 图层='{layer.name}'")
        except ImportError:
            try:
                pixels = img.load()
                width, height = img.size
                for y in range(height):
                    for x in range(width):
                        r, g, b, a = pixels[x, y]
                        if a == 0:
                            pixels[x, y] = (0, 0, 0, 0)
                _psd_log(f"[PSD-渲染] Alpha清理(像素循环): 图层='{layer.name}'")
            except (AttributeError, TypeError):
                _psd_log(f"[PSD-渲染] Alpha清理跳过(不可用): 图层='{layer.name}'")
                pass
        _psd_log(f"[PSD-渲染] << 渲染成功: 图层='{layer.name}', 尺寸={img.size[0]}x{img.size[1]}")
        return img
    except (OSError, IOError, ValueError, AttributeError) as e:
        _psd_log(f"[PSD-渲染] << 渲染失败: 图层='{layer.name}', 异常={type(e).__name__}: {e}")
        return None


def compute_image_md5(img: Any) -> str:
    try:
        return hashlib.md5(img.tobytes()).hexdigest()
    except (OSError, IOError, ValueError, AttributeError):
        return ""


def save_image_png(img: Any, target_png_path: str, compress_level: Optional[int] = None) -> None:
    """把图层图像写成 PNG。

    compress_level：PNG 压缩等级 0~9。**越低越快、文件越大**。
    None 时回落到模块常量 PNG_COMPRESS_LEVEL（保持旧调用行为）。
    等级由「⚙ 设置 → PNG 压缩等级」提供，主线程读出来传给后台线程。
    """
    level = PNG_COMPRESS_LEVEL if compress_level is None else int(compress_level)
    _psd_log(f"[PSD-缓存] >> save_image_png: path='{target_png_path}', compress_level={level}")
    try:
        os.makedirs(os.path.dirname(target_png_path), exist_ok=True)
    except (OSError, IOError) as e:
        _psd_log(f"[PSD-缓存] 创建缓存目录失败: '{target_png_path}', 异常={type(e).__name__}: {e}")
        raise
    try:
        img.save(target_png_path, format="PNG", compress_level=level)
        file_size = os.path.getsize(target_png_path) if os.path.exists(target_png_path) else -1
        _psd_log(f"[PSD-缓存] << PNG写入成功: path='{target_png_path}', size={file_size} bytes")
    except (OSError, IOError, ValueError) as e:
        _psd_log(f"[PSD-缓存] compress_level={level} 写入失败: {e}，尝试无压缩写入")
        try:
            img.save(target_png_path, format="PNG")
            file_size = os.path.getsize(target_png_path) if os.path.exists(target_png_path) else -1
            _psd_log(f"[PSD-缓存] << PNG回退写入成功: path='{target_png_path}', size={file_size} bytes")
        except Exception as e2:
            _psd_log(f"[PSD-缓存] << PNG写入完全失败: path='{target_png_path}', 异常={type(e2).__name__}: {e2}")


def save_layer_to_png_and_checksum(layer: Any, target_png_path: str) -> str:
    _psd_log(f"[PSD-缓存] >> save_layer_to_png_and_checksum: 图层='{layer.name}', path='{target_png_path}'")
    try:
        img = render_layer_rgba(layer)
        if img is None:
            _psd_log(f"[PSD-缓存] << 渲染返回None，跳过PNG写入: 图层='{layer.name}'")
            return ""
        save_image_png(img, target_png_path)
        checksum = compute_image_md5(img)
        _psd_log(f"[PSD-校验] save_layer: 图层='{layer.name}', pixel_hash={checksum[:20] if checksum else '(空)'}...")
        return checksum
    except (OSError, IOError, ValueError, AttributeError) as e:
        _psd_log(f"[PSD-缓存] << 异常: 图层='{layer.name}', 异常={type(e).__name__}: {e}")
        return ""


def check_packed_image_validity(
    image_name: str, expected_checksum: Optional[str] = None
) -> Tuple[bool, Any]:
    """
    检查Blender中是否已存在有效的已打包图像；
    当提供期望校验和时，仅当与图像上记录的校验和一致才视为有效。
    """
    _psd_log(f"[PSD-图像] check_packed_image_validity: image='{image_name}', expected_checksum={'有' if expected_checksum else '无'}")
    image = bpy.data.images.get(image_name)
    if image is None:
        _psd_log(f"[PSD-图像] 图像不存在 bpy.data.images 中: '{image_name}' → 需创建")
        return False, None

    # 若图像已打包但没有校验和可比较，无法判定有效性，需重新加载
    if image.packed_file is not None and not expected_checksum:
        _psd_log(f"[PSD-图像] 已打包但无校验和: '{image_name}' → 强制重载")
        return False, None

    # 当提供了期望校验和时，用自定义属性进行快速比较
    if image.packed_file is not None and expected_checksum:
        try:
            stored = image.get("checksum")
            if stored and stored == expected_checksum:
                _psd_log(f"[PSD-图像] << 校验命中: '{image_name}' 校验一致，跳过重载")
                return True, image
            _psd_log(f"[PSD-图像] 校验失效: '{image_name}', 存储={stored[:20] if stored else 'None'}... != 期望={expected_checksum[:20]}...")
            return False, None
        except (AttributeError, KeyError, TypeError):
            return False, None

    # 未打包或无法校验，走重新加载路径
    _psd_log(f"[PSD-图像] 未打包或无法校验: '{image_name}' → 需从文件加载")
    return False, None


def load_or_update_image_from_cache(
    image_name: str,
    cache_png: str,
    pack: bool = True,
    expected_checksum: Optional[str] = None,
    force: bool = False,
    check_existing: bool = True,
) -> Any:
    """加载/更新贴图图像。

    check_existing=False 时**强制新建独立数据块**（即使 bpy.data 里已有指向同一
    PNG 文件的图像，也不复用）—— 用于「每次追加都要完全独立对象」的场景，
    否则同图层多次追加会共用同一张 image（改一个的贴图会波及其他）。
    """
    _psd_log(f"[PSD-图像] >> load_or_update_image_from_cache: image='{image_name}', cache='{os.path.basename(cache_png)}', force={force}, pack={pack}, check_existing={check_existing}, checksum={'有' if expected_checksum else '无'}")

    # check_existing=False：跳过复用，直接建独立数据块
    if not check_existing:
        image = bpy.data.images.load(cache_png, check_existing=False)
        image.name = image_name
        try:
            image.colorspace_settings.name = "sRGB"
        except (AttributeError, TypeError, RuntimeError):
            pass
        if pack:
            try:
                image.pack()
            except (AttributeError, TypeError, RuntimeError):
                pass
        try:
            if expected_checksum:
                image["checksum"] = expected_checksum
        except (TypeError, KeyError, RuntimeError):
            pass
        _psd_log(f"[PSD-图像] << 独立新建返回: name='{image.name}', size={image.size[0]}x{image.size[1]}, users={image.users}")
        return image

    # ---- 存放模式一致性检查（v3.12.1）----
    # check_packed_image_validity 只看「是否已打包 + 校验和」，不看「当前设置要求的
    # 存放模式」。于是切换「贴图存放」后刷新时，图会保持旧模式：
    #   · 打包 → 切外放：image 仍打包、校验命中 → 直接复用 → **不解包**（.blend 仍大）
    # 这里在复用前先比对「实际打包状态」与「设置要求」，不一致就不复用，
    # 强制走重载路径（重载里会按 pack 正确 unpack / pack）。
    if check_existing:
        _ex = bpy.data.images.get(image_name)
        if _ex is not None:
            _is_packed = _ex.packed_file is not None
            if _is_packed != bool(pack):
                force = True
                _psd_log(
                    f"[PSD-图像] 存放模式不一致（当前={'已打包' if _is_packed else '未打包'}，"
                    f"需要={'打包' if pack else '外放'}）→ 强制重载: '{image_name}'"
                )

    # 优先检查是否已存在且校验一致的打包图像
    if not force:
        _psd_log(f"[PSD-图像] force=False，执行校验检查")
        is_valid, existing_image = check_packed_image_validity(
            image_name, expected_checksum
        )
        if is_valid and existing_image:
            _psd_log(f"[PSD-图像] << 校验命中，跳过重载: '{image_name}'")
            try:
                existing_image.colorspace_settings.name = "sRGB"
            except (AttributeError, TypeError, RuntimeError):
                pass
            return existing_image
        _psd_log(f"[PSD-图像] 校验未命中，将重新加载")
    else:
        _psd_log(f"[PSD-图像] force=True，跳过校验检查")

    # 无效或未命中校验，重新从缓存加载
    image = bpy.data.images.get(image_name)
    if image is None:
        _psd_log(f"[PSD-图像] bpy.data.images 中未找到 '{image_name}'，从文件新建")
        image = bpy.data.images.load(cache_png, check_existing=True)
        _psd_log(f"[PSD-图像] load 后 name='{image.name}', requested='{image_name}', size={image.size[0]}x{image.size[1]}")
        image.name = image_name
        _psd_log(f"[PSD-图像] 设置 name 后: actual_name='{image.name}', 匹配={'是' if image.name == image_name else '否(可能有.001后缀)'}")
    else:
        _psd_log(f"[PSD-图像] bpy.data.images 中找到 '{image_name}': source={image.source}, packed={'是' if image.packed_file else '否'}, users={image.users}, size={image.size[0]}x{image.size[1]}")
        image.filepath_raw = cache_png
        _psd_log(f"[PSD-图像] 设置 filepath_raw='{cache_png}'")
        if image.packed_file is not None:
            _psd_log(f"[PSD-图像] 解除打包: '{image_name}'")
            try:
                image.unpack(method='REMOVE')
                image.source = 'FILE'
                _psd_log(f"[PSD-图像] unpack 成功: source={image.source}, packed={'是' if image.packed_file else '否'}")
            except Exception as e:
                _psd_log(f"[PSD-图像] unpack 失败: '{image_name}', 异常={type(e).__name__}: {e}")
        else:
            _psd_log(f"[PSD-图像] 图像未打包，直接 reload")
        try:
            image.reload()
            _psd_log(f"[PSD-图像] reload() 成功: '{image.name}', size={image.size[0]}x{image.size[1]}")
        except (AttributeError, RuntimeError, OSError, IOError) as e:
            _psd_log(f"[PSD-图像] reload() 失败: '{image_name}', 异常={type(e).__name__}: {e}，重新创建")
            image = bpy.data.images.load(cache_png, check_existing=True)
            image.name = image_name
            _psd_log(f"[PSD-图像] 重新创建后: name='{image.name}', size={image.size[0]}x{image.size[1]}")

    # 关键：确保使用sRGB色彩空间（避免单色/灰阶问题）
    try:
        image.colorspace_settings.name = "sRGB"
        _psd_log(f"[PSD-图像] colorspace=sRGB: '{image.name}'")
    except (AttributeError, TypeError, RuntimeError) as e:
        _psd_log(f"[PSD-图像] colorspace 设置失败: '{image.name}', 异常={type(e).__name__}")

    if pack:
        try:
            image.pack()
            packed_size = len(image.packed_file.data) if image.packed_file else 0
            _psd_log(f"[PSD-图像] pack() 完成: '{image.name}', size={packed_size} bytes")
        except (AttributeError, TypeError, RuntimeError) as e:
            _psd_log(f"[PSD-图像] pack() 失败: '{image.name}', 异常={type(e).__name__}")

    # 记录校验和，以便后续刷新比对
    try:
        if expected_checksum:
            image["checksum"] = expected_checksum
            _psd_log(f"[PSD-图像] checksum 已写入图像属性: '{image.name}' = {expected_checksum[:20]}...")
    except (TypeError, KeyError, RuntimeError) as e:
        _psd_log(f"[PSD-图像] checksum 写入失败: '{image.name}', 异常={type(e).__name__}")

    _psd_log(f"[PSD-图像] << 返回: name='{image.name}', size={image.size[0]}x{image.size[1]}, users={image.users}")
    return image


def _is_effectively_visible(layer: Any, include_hidden: bool = False) -> bool:
    """沿祖先链检查可见性：任一层（含祖先组）不可见 → 整体不可见。

    必须与 extract_layer_hierarchy 的递归跳过语义一致：后者遇到不可见的组会
    跳过整棵子树，而扁平遍历 descendants() 若不查祖先组，就会把"隐藏组里的
    可见层"误当可见 → 两条路径的 display_index 不同 → 刷新按 identifier
    反查对象时整体错位（对象内容错乱 / 凭空多出重复对象）。
    """
    if include_hidden:
        return True   # 开关打开：隐藏的层/组也当"要收的"（不查可见性）
    node = layer
    guard = 0
    while node is not None and guard < 10000:
        try:
            if hasattr(node, "visible") and not bool(node.visible):
                return False
        except Exception:
            pass
        node = getattr(node, "parent", None)
        guard += 1
    return True


def create_layer_identifier(layer: Any, display_index: Optional[int] = None) -> str:
    """图层唯一标识。

    优先用 PSD 图层自带的 layer_id（>=0）。但 psd_tools 对部分 PSD 会返回
    -1 / None（此时所有图层 id 相同，会导致「勾选一层导全部」「checksum 互相
    覆盖」等静默错误）。这种缺失情况回退到稳定的显示序号 "d{display_index}"，
    保证同一 PSD 内唯一、两次解析一致。
    """
    lid = getattr(layer, "layer_id", None)
    if isinstance(lid, int) and lid >= 0:
        return str(lid)
    if display_index is not None:
        return f"d{display_index}"
    return str(lid)