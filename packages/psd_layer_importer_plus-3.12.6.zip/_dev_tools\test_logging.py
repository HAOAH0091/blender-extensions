"""验证新功能的调试日志：[PSD-视差] / [PSD-匹配] 输出且【不刷屏】。

关注点：
  1. 锁定 / 解锁 / 匹配 / 恢复 各出**一条**汇总
  2. 相机适配（handler 每帧触发）**必须节流** —— 连续 30 帧只记极少条
  3. 分支判据日志能说清「走了匹配还是恢复、为什么」
"""
import sys
import os
import io
import math
import contextlib

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))   # addons 父目录

import bpy
import mathutils

import psd_layer_importer_plus as addon
from psd_layer_importer_plus import parallax_utils as P

addon.register()

LOG = io.StringIO()


def captured(fn, *a, **kw):
    LOG.seek(0)
    LOG.truncate(0)
    with contextlib.redirect_stdout(LOG):
        fn(*a, **kw)
    return LOG.getvalue()


def add_plane(name, size, loc):
    me = bpy.data.meshes.new(name)
    h = 0.5
    me.from_pydata([(-h, -h, 0), (h, -h, 0), (h, h, 0), (-h, h, 0)], [], [(0, 1, 2, 3)])
    me.update()
    o = bpy.data.objects.new(name, me)
    o.scale = (size, size, 1)
    o.location = loc
    return o


bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.render.resolution_x = 1920
scene.render.resolution_y = 1080

cd = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cd)
cam.location = (0, 0, 0)
cd.lens = 50
scene.collection.objects.link(cam)
scene.camera = cam

coll = bpy.data.collections.new("PSD_L")
scene.collection.children.link(coll)
from psd_layer_importer_plus.constants import ATTR_LAYER_ID, ATTR_INITIAL_TRANSFORM  # noqa: E402

layers = []
for i, z in enumerate([-6, -9, -12]):
    o = add_plane("Layer_%d" % i, 1.0 + i * 0.5, (0, 0, z))
    o[ATTR_LAYER_ID] = "layer_%d" % i
    o[ATTR_INITIAL_TRANSFORM] = {"location": [(-0.4 + i * 0.4), 0.2, i * 0.01],
                                 "scale": [1, 1, 1], "rotation": [0, 0, 0]}
    coll.objects.link(o)
    layers.append(o)

rec = scene.psd_import_tool.file_records.add()
rec.filepath = os.path.join(_HERE, "test_basic.psd")
rec.collection = coll
rec.camera = cam
bpy.context.view_layer.update()

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("[%s] %-44s %s" % ("PASS" if ok else "FAIL", name, detail))


# ── 1. 锁定 ──
out = captured(P.record_parallax_lock_state, coll, cam)
n_lock = out.count("[PSD-视差] 锁定记录")
check("1.1 锁定输出 1 条汇总", n_lock == 1, "条数=%d" % n_lock)
print("      | " + out.strip().replace("\n", "\n      | ")[:200])

# 重设账本（真实插件由「锁定」操作符做）
for r in scene.psd_import_tool.file_records:
    r.parallax_maybe_locked = True
    r.parallax_locked = True

# ── 2. 相机适配节流（连续 30 帧）──
# ⚠️ 插件注册后 handler 已挂在 depsgraph_update_post，view_layer.update() 会自动触发它，
#    在 captured 之外打印 → 干扰计数。测试里先摘掉自动 handler，只显式调用。
try:
    for _h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(_h, "__name__", "") == "parallax_scene_update_handler":
            bpy.app.handlers.depsgraph_update_post.remove(_h)
except Exception as _e:                                       # noqa: BLE001
    print("  (摘 handler 失败:", repr(_e), ")")

ref = P.get_parallax_reference_depth(layers)
P._adapt_log_state.clear()        # 重置节流门（按 集合|相机 分键），让第一条一定能出
total = 0
for k in range(30):
    cam.location = (0.05 * (k + 1), 0.0, 0.0)
    bpy.context.view_layer.update()
    out = captured(P.parallax_scene_update_handler, scene)
    total += out.count("[PSD-视差] 相机适配")
check("2.1 相机适配日志【节流】（连 30 帧 ≤ 2 条）", total <= 2,
      "30 帧共 %d 条（未节流会是几十条）" % total)

# 等一个节流周期，应能再出一条
import time
time.sleep(P.PARALLAX_ADAPT_LOG_INTERVAL + 0.05)
cam.location = (3.0, 0.0, 0.0)
bpy.context.view_layer.update()
out = captured(P.parallax_scene_update_handler, scene)
check("2.2 超过节流周期后能再输出", out.count("[PSD-视差] 相机适配") == 1,
      "条数=%d" % out.count("[PSD-视差] 相机适配"))
print("      | " + out.strip().replace("\n", "\n      | ")[:200])

# ── 3. 解锁 ──
out = captured(P.restore_parallax_lock_state, coll)
check("3.1 解锁输出 1 条汇总", out.count("[PSD-视差] 解除锁定") == 1)
print("      | " + out.strip()[:200])

# ── 4. 匹配（走「匹配」分支）──
for o in layers:
    if "pre_match_transform" in o:
        del o["pre_match_transform"]
out = captured(P.match_layers_to_camera, coll, cam, rec)
check("4.1 匹配输出 1 条汇总", out.count("[PSD-匹配] 匹配至相机") == 1)
print("      | " + out.strip()[:220])

# ── 5. operator 双态日志（判据）──
idx = list(scene.psd_import_tool.file_records).index(rec)
out = captured(bpy.ops.psd.match_to_camera, file_index=idx)
bpy.context.view_layer.update()
check("5.1 卡片 operator 记录分支判据",
      "走【恢复匹配前】分支" in out and "判据" in out)
print("      | " + "\n      | ".join(l for l in out.splitlines() if "PSD-匹配" in l)[:260])

out = captured(bpy.ops.psd.match_to_camera, file_index=idx)
bpy.context.view_layer.update()
check("5.2 再点一次 → 走【匹配】分支", "走【匹配】分支" in out)

passed = sum(1 for _, ok, _ in RESULTS if ok)
print("\n#### 结果 %d/%d PASS" % (passed, len(RESULTS)))
print("SELFTEST_RESULT %d/%d" % (passed, len(RESULTS)))
sys.exit(0 if passed == len(RESULTS) else 1)
