"""PSD 视差锁定：变焦时「优先移动相机」验证。

场景：3 个不同深度的平面（PSD 图层）+ 1 台 50mm 相机。
流程：锁定 → 变焦到 85mm → 调 handler 的核心步骤 → 检查：
  ① 相机真的移动了（位移量 = ref_depth × (k−1)）
  ② 构图仍精确冻结（各层屏幕坐标不变）
对照：关掉 PARALLAX_CAMERA_DOLLY_ZOOM → 相机不动、构图同样冻结（旧行为）。
"""
import bpy
import sys
import os
import math
import importlib

sys.stdout.reconfigure(encoding="utf-8")
# 路径自己推 —— 别硬编码某台机器的绝对路径（换机器/换盘符就跑不起来，
# 而且报错看不出是路径问题）。_dev_tools/ 在插件包内，往上两级 = addons。
_HERE = os.path.dirname(os.path.abspath(__file__))   # .../psd_layer_importer_plus/_dev_tools
_PKG = os.path.dirname(_HERE)                        # .../psd_layer_importer_plus
ADDONS = os.path.dirname(_PKG)                       # .../addons
sys.path.insert(0, ADDONS)
pu = importlib.import_module("psd_layer_importer_plus.parallax_utils")
C = importlib.import_module("psd_layer_importer_plus.constants")

P, F = [], []


def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-46s %s" % ("PASS" if cond else "FAIL", name, detail))


def build_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, -6.0, 0.0)
    cam.rotation_euler = (math.radians(90), 0.0, 0.0)
    sc.camera = cam
    coll = bpy.data.collections.new("PSD")
    sc.collection.children.link(coll)
    objs = []
    for i, (x, depth) in enumerate([(-4.0, 10.0), (0.0, 16.0), (4.0, 22.0)]):
        bpy.ops.mesh.primitive_plane_add(size=2.0, location=(x, cam.location.y + depth, 0.0))
        o = bpy.context.active_object
        o.name = "Layer%d" % i
        o[C.ATTR_LAYER_ID] = o.name
        sc.collection.objects.unlink(o)
        coll.objects.link(o)
        objs.append(o)
    bpy.context.view_layer.update()
    return sc, cam, coll, objs


def screen_of(o, cam):
    sx, sy, d = pu.world_to_screen_coords(pu.get_object_center_world_pos(o), cam)
    return (sx, sy, d)


def run_case(dolly_on):
    pu.PARALLAX_CAMERA_DOLLY_ZOOM = dolly_on
    sc, cam, coll, objs = build_scene()
    pu.record_parallax_lock_state(coll, cam)

    locked = [o for o in pu.get_all_objects_recursive(coll) if pu.is_obj_parallax_locked(o)]
    if len(locked) != 3:
        print("  !! 锁定层数异常:", len(locked))
    ref_depth = pu.get_parallax_reference_depth(locked)
    s0 = {o.name: screen_of(o, cam) for o in locked}
    cam0 = cam.location.copy()
    applied0 = float(cam.get(pu.APPLIED_ZOOM_KEY, -1.0))

    # ── 变焦 50 → 85 ──
    cam.data.lens = 85.0
    bpy.context.view_layer.update()

    # handler 的核心两步：① 相机 dolly ② 图层适配
    pu.maybe_zoom_dolly(locked, sc, set())
    cam1 = cam.location.copy()
    for o in locked:
        pu.apply_camera_adapt_to_obj(o, cam, ref_depth)
    bpy.context.view_layer.update()

    s1 = {o.name: screen_of(o, cam) for o in locked}
    shift = (cam1 - cam0).length
    k = 85.0 / 50.0
    max_err = max(max(abs(s1[n][0] - s0[n][0]), abs(s1[n][1] - s0[n][1])) for n in s0)

    return {
        "ref_depth": ref_depth, "shift": shift, "theory": ref_depth * (k - 1.0),
        "max_err": max_err, "applied0": applied0,
        "applied1": float(cam.get(pu.APPLIED_ZOOM_KEY, -1.0)),
        "cam0": tuple(cam0), "cam1": tuple(cam1),
    }


print("=" * 62)
print("① 开启 PARALLAX_CAMERA_DOLLY_ZOOM（优先移动相机）")
r = run_case(True)
print("   相机 %.3f,%.3f,%.3f → %.3f,%.3f,%.3f" % (r["cam0"] + r["cam1"]))
print("   位移=%.4f  理论 ref×0.7=%.4f  构图误差=%.2e" % (r["shift"], r["theory"], r["max_err"]))
chk("相机确实移动了（位移 > 1e-4）", r["shift"] > 1e-4, "→%.4f" % r["shift"])
chk("位移量 = ref_depth×(k−1)", abs(r["shift"] - r["theory"]) < 1e-3,
    "实测 %.4f vs 理论 %.4f" % (r["shift"], r["theory"]))
chk("构图仍精确冻结（屏幕坐标不变）", r["max_err"] < 1e-5, "max=%.2e" % r["max_err"])
chk("锁定基准归零（applied=1.0）", abs(r["applied0"] - 1.0) < 1e-6, "→%.3f" % r["applied0"])
chk("施加后 applied == zoom(1.7)", abs(r["applied1"] - 1.7) < 1e-4, "→%.4f" % r["applied1"])

print()
print("=" * 62)
print("② 关闭 PARALLAX_CAMERA_DOLLY_ZOOM（旧行为：相机不动）")
r2 = run_case(False)
print("   相机位移=%.6f  构图误差=%.2e" % (r2["shift"], r2["max_err"]))
chk("相机【没有】移动（旧行为）", r2["shift"] < 1e-9, "→%.6f" % r2["shift"])
chk("构图同样精确冻结", r2["max_err"] < 1e-5, "max=%.2e" % r2["max_err"])

print()
print("=" * 62)
print("③ 幂等 + 可逆：重复调用不叠加；变焦回原值相机回到原位")
pu.PARALLAX_CAMERA_DOLLY_ZOOM = True
sc, cam, coll, objs = build_scene()
pu.record_parallax_lock_state(coll, cam)
locked = [o for o in pu.get_all_objects_recursive(coll) if pu.is_obj_parallax_locked(o)]
origin = cam.location.copy()
cam.data.lens = 85.0
bpy.context.view_layer.update()
pu.maybe_zoom_dolly(locked, sc, set())
p1 = cam.location.copy()
for _ in range(5):
    pu.maybe_zoom_dolly(locked, sc, set())
p2 = cam.location.copy()
chk("重复调用不再移动相机（幂等）", (p2 - p1).length < 1e-9, "额外位移=%.2e" % (p2 - p1).length)

cam.data.lens = 50.0
bpy.context.view_layer.update()
pu.maybe_zoom_dolly(locked, sc, set())
chk("变焦回 50 → 相机【回到原位】（可逆）", (cam.location - origin).length < 1e-5,
    "偏差=%.2e" % (cam.location - origin).length)

print()
print("=" * 62)
print("④ 相机带父级：dolly 按父级空间换算（世界位移仍正确）")
sc, cam, coll, objs = build_scene()
pivot = bpy.data.objects.new("Pivot", None)
sc.collection.objects.link(pivot)
pivot.location = (2.0, 3.0, 1.0)
pivot.rotation_euler = (0.0, 0.0, math.radians(30))
bpy.context.view_layer.update()
cam.parent = pivot
cam.matrix_parent_inverse = pivot.matrix_world.inverted()
bpy.context.view_layer.update()
pu.record_parallax_lock_state(coll, cam)
locked = [o for o in pu.get_all_objects_recursive(coll) if pu.is_obj_parallax_locked(o)]
ref_depth = pu.get_parallax_reference_depth(locked)
w0 = cam.matrix_world.translation.copy()
cam.data.lens = 85.0
bpy.context.view_layer.update()
pu.maybe_zoom_dolly(locked, sc, set())
w1 = cam.matrix_world.translation.copy()
world_shift = (w1 - w0).length
chk("带父级时世界位移 = ref×(k−1)", abs(world_shift - ref_depth * 0.7) < 1e-3,
    "实测 %.4f vs 理论 %.4f" % (world_shift, ref_depth * 0.7))

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("PSD_DOLLY_DONE")
