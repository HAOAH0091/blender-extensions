import os
import sys
import tempfile
from PIL import Image, ImageDraw, ImageFont

D = os.path.join(tempfile.gettempdir(), '_psd_dolly')


def load(n):
    return Image.open(os.path.join(D, n + '.png')).convert('RGB')


def diffstat(i1, i2, thr=8, step=2):
    p1, p2 = i1.load(), i2.load()
    W, H = i1.size
    s = n = bad = 0
    for y in range(0, H, step):
        for x in range(0, W, step):
            a, b = p1[x, y], p2[x, y]
            d = abs(a[0]-b[0]) + abs(a[1]-b[1]) + abs(a[2]-b[2])
            s += d; n += 1
            if d > thr:
                bad += 1
    return s / n / 3, bad / n * 100


def bright_count(im, thr=40):
    """亮像素数 —— 用来确认【画面不是空的】（空对空会让像素差恒为 0，制造假阳性）。"""
    px = im.load()
    W, H = im.size
    n = 0
    for y in range(0, H, 3):
        for x in range(0, W, 3):
            if max(px[x, y]) > thr:
                n += 1
    return n


va, vb = load('A70_view_t50'), load('C70_view_t85')
ba, bb = bright_count(va), bright_count(vb)
print('相机视图 亮像素数: 50mm=%d  85mm=%d  → %s' %
      (ba, bb, '画面非空 ✓' if min(ba, bb) > 200 else '★ 画面几乎是空的（结论不可信）'))
m, pct = diffstat(va, vb)
print('相机视图 变焦前后: 平均像素差 %.3f  显著不同 %.3f%%' % (m, pct))
tb0 = load('B70_top_t50')
print('顶视图   亮像素数: %d → %s' % (bright_count(tb0, 30),
      '画面非空 ✓' if bright_count(tb0, 30) > 200 else '★ 空'))
ta, tb = load('B70_top_t50'), load('D70_top_t85')
m2, pct2 = diffstat(ta, tb, thr=12)
print('顶视图   变焦前后: 平均像素差 %.3f  显著不同 %.3f%%' % (m2, pct2))

FW = 470
def rs(im):
    return im.resize((FW, int(im.size[1] * FW / im.size[0])), Image.LANCZOS)
ia, ib, ta2, tb2 = rs(va), rs(vb), rs(ta), rs(tb)
try:
    f = ImageFont.truetype(r'C:\Windows\Fonts\msyh.ttc', 15)
except Exception:
    f = ImageFont.load_default()
h = 28 + ia.size[1] + 30 + ta2.size[1] + 12
c = Image.new('RGB', (FW * 2 + 30, h), (10, 11, 15))
d = ImageDraw.Draw(c)
d.text((10, 6), '相机视图 · 50mm（锁定后）', font=f, fill=(255, 220, 120))
d.text((FW + 20, 6), '相机视图 · 85mm（变焦后）', font=f, fill=(255, 220, 120))
c.paste(ia, (10, 28)); c.paste(ib, (FW + 20, 28))
y = 28 + ia.size[1] + 8
d.text((10, y), '顶视图 · 50mm（橙锥=相机）', font=f, fill=(120, 200, 255))
d.text((FW + 20, y), '顶视图 · 85mm ← 相机应已后退 15.4', font=f, fill=(120, 200, 255))
c.paste(ta2, (10, y + 22)); c.paste(tb2, (FW + 20, y + 22))
out = os.path.join(D, '_dolly_cmp.png')
c.save(out)
print('SAVED', out, c.size)
