"""用户工程实测：视差锁定的「滚动量」到底多大？

在隔离副本上跑（绝不动原文件）：
    blender --background --factory-startup <副本.blend> --python test_user_scene.py

输出：
  · 相机朝向 / 图层深度分布
  · 相机横移 Δ 时，各层的【世界位移】与【屏幕位移】
  · 三种基准取法（最深 / 中位 / 最浅）的滚动量对比
"""
import sys
import os
import math

sys.path.insert(
    0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)  # addons 目录（相对推，别硬编码本机路径）

import bpy
import mathutils
from bpy_extras.object_utils import world_to_camera_view

from psd_layer_importer_plus import parallax_utils as P
from psd_layer_importer_plus.constants import ATTR_LAYER_ID, ATTR_INITIAL_TRANSFORM

OUT = []


def p(*a):
    line = " ".join(str(x) for x in a)
    OUT.append(line)
    print(line)


def unit_dir(mat, axis):
    v = mat.to_3x3() @ mathutils.Vector(axis)
    return v.normalized()


def measure(scene, cam, layers):
    """各层中心：相机空间坐标 + 归一化屏幕坐标（用 Blender 官方投影）。"""
    m = cam.matrix_world.inverted()
    res = []
    for o in layers:
        world_c = P.get_object_center_world_pos(o)
        cs = m @ world_c
        sc = world_to_camera_view(scene, cam, world_c)
        res.append({"world": world_c, "cs": cs, "sx": sc.x, "sy": sc.y})
    return res


def main():
    scene = bpy.context.scene
    cam = scene.camera
    RX, RY = scene.render.resolution_x, scene.render.resolution_y

    p("=" * 78)
    p("### 相机")
    p("  loc            :", [round(v, 3) for v in cam.location])
    p("  rotation_euler :", [round(math.degrees(v), 2) for v in cam.rotation_euler])
    fwd = unit_dir(cam.matrix_world, (0.0, 0.0, -1.0))
    right = unit_dir(cam.matrix_world, (1.0, 0.0, 0.0))
    p("  视线方向       :", [round(v, 4) for v in fwd])
    p("  右向           :", [round(v, 4) for v in right])
    p("  lens           :", round(cam.data.lens, 2), "mm   sensor:",
      round(cam.data.sensor_width, 2))
    p("  resolution     : %dx%d" % (RX, RY))

    layers = [o for o in bpy.data.objects if ATTR_LAYER_ID in o]
    p("### 图层数 :", len(layers))

    # 找它们所属的顶层集合
    colls = []
    for o in layers:
        for c in o.users_collection:
            if c not in colls:
                colls.append(c)
    p("### 所属集合 :", [c.name for c in colls])

    # 直接用一个包含全部图层的集合（record 会递归；这里取真实集合）
    root_coll = colls[0]
    for c in colls:
        if len(c.objects) == len(layers):
            root_coll = c
            break
    p("### 用于锁定的集合 :", root_coll.name, "（含 %d 个直接对象）" % len(root_coll.objects))

    # ── 锁定 ──
    P.record_parallax_lock_state(root_coll, cam)
    locked = [o for o in layers if P.is_obj_parallax_locked(o)]
    p("### 锁定成功 :", len(locked), "/", len(layers))

    depths = sorted(o["locked_depth"] for o in locked)
    p("### 深度分布（沿视线距离）:")
    p("  min=%.3f  median=%.3f  max=%.3f" % (depths[0], depths[len(depths) // 2], depths[-1]))
    p("  各层: %s" % [round(d, 2) for d in depths])

    # ── 基线 ──
    base_cam_loc = cam.location.copy()
    base_cam_rot = cam.rotation_euler.copy()
    base_cam_lens = cam.data.lens
    base = measure(scene, cam, locked)

    def cam_space_normals():
        view = P.get_camera_view_matrix(cam)
        inv = view.to_3x3().inverted()
        out = []
        for o in locked:
            wn = o.matrix_world.to_quaternion() @ mathutils.Vector((0.0, 0.0, 1.0))
            out.append(inv @ wn)
        return out

    def reset_cam():
        cam.location = base_cam_loc
        cam.rotation_euler = base_cam_rot
        cam.data.lens = base_cam_lens
        bpy.context.view_layer.update()

    def reset_and_shift(dist):
        """相机复位 → 沿【右向】横移 dist → 用指定基准适配 → 测量。"""
        cam.location = base_cam_loc
        bpy.context.view_layer.update()
        cam.location = base_cam_loc + right * dist
        bpy.context.view_layer.update()

    def ratio_px(before, after, i):
        return (after[i]["sx"] - before[i]["sx"]) * RX

    # ── 三种基准取法 ──
    strats = [
        ("最深(max=当前实现)", depths[-1]),
        ("中位", depths[len(depths) // 2]),
        ("最浅(min)", depths[0]),
    ]
    for label, ref in strats:
        for dist in (1.0, 5.0):
            reset_and_shift(dist)
            for o in locked:
                P.apply_camera_adapt_to_obj(o, cam, ref)
            bpy.context.view_layer.update()
            after = measure(scene, cam, locked)
            px = [ratio_px(base, after, i) for i in range(len(locked))]
            spread = max(px) - min(px)
            p("  %-18s ref=%7.3f  Δ=%4.1f  → 屏幕滚动 %+7.1f px （各层离散 %.2e）"
              % (label, ref, dist, abs(px[0]), spread))

    # ── 世界位移 vs 屏幕位移（验证"两个飞"） ──
    p("\n### 【世界位移 vs 屏幕位移】Δ=5.0，基准=最深=%.3f" % depths[-1])
    reset_and_shift(5.0)
    for o in locked:
        P.apply_camera_adapt_to_obj(o, cam, depths[-1])
    bpy.context.view_layer.update()
    after = measure(scene, cam, locked)
    p("  层名(截断)                    深度   世界位移(dfwd,dright)      屏幕位移px")
    for i, o in enumerate(locked):
        dw = after[i]["world"] - base[i]["world"]
        dw_f = dw.dot(fwd)
        dw_r = dw.dot(right)
        px = (after[i]["sx"] - base[i]["sx"]) * RX
        p("  %-28s %6.2f  (%+8.3f, %+8.3f)  %+8.1f"
          % (o.name[:28], o["locked_depth"], dw_f, dw_r, px))

    # ── 旋转：图层朝向应跟随相机（相机空间法线不变） ──
    ref = P.get_parallax_reference_depth(locked)
    reset_cam()
    for o in locked:
        P.apply_camera_adapt_to_obj(o, cam, ref)
    bpy.context.view_layer.update()
    base_n = cam_space_normals()
    base_m = measure(scene, cam, locked)

    # ⚠️ 这台相机朝 +Y：绕 Y 轴转只是【滚转】(roll)，法线本就不变、证明力弱。
    #    要测"转头"得绕 Z 轴(pan) 与 X 轴(tilt)。
    p("\n### 【旋转】相机 pan +20° / tilt -15°（基准=最深=%.3f）" % ref)
    reset_cam()
    cam.rotation_euler = (base_cam_rot.x + math.radians(-15.0),
                          base_cam_rot.y,
                          base_cam_rot.z + math.radians(20.0))
    bpy.context.view_layer.update()
    for o in locked:
        P.apply_camera_adapt_to_obj(o, cam, ref)
    bpy.context.view_layer.update()
    after_n = cam_space_normals()
    after_m = measure(scene, cam, locked)
    dn = max((a - b).length for a, b in zip(base_n, after_n))
    px = [(after_m[i]["sx"] - base_m[i]["sx"]) * RX for i in range(len(locked))]
    world_n_after = (locked[0].matrix_world.to_quaternion()
                     @ mathutils.Vector((0.0, 0.0, 1.0)))
    p("  【相机空间】法线 旋转前/后 : %s / %s   ← ≈0 偏差 = 跟着相机转"
      % ([round(v, 3) for v in base_n[0]], [round(v, 3) for v in after_n[0]]))
    p("  【世界】法线 旋转后        : %s   ← 已随相机转过（≠ 原来的 (0,0,1)）"
      % [round(v, 3) for v in world_n_after])
    p("  相机空间朝向最大偏差       : %.2e" % dn)
    p("  屏幕位移离散               : %.2e px （≈0 = 构图保持）" % (max(px) - min(px)))

    # ── 变焦：视图应保持不变 ──
    p("\n### 【变焦】50mm → 85mm")
    reset_cam()
    for o in locked:
        P.apply_camera_adapt_to_obj(o, cam, ref)
    bpy.context.view_layer.update()
    bz = measure(scene, cam, locked)
    cam.data.lens = 85.0
    bpy.context.view_layer.update()
    p("  变焦后 handler 判据   : %s"
      % ("会触发适配" if P.camera_changed_since_last_adapt(locked[0], cam)
         else "!! 不会触发（漏掉）"))
    for o in locked:
        P.apply_camera_adapt_to_obj(o, cam, ref)
    bpy.context.view_layer.update()
    az = measure(scene, cam, locked)
    dz = max(abs(az[i]["sx"] - bz[i]["sx"]) * RX for i in range(len(locked)))
    p("  屏幕位置最大变化     : %.2e px （≈0 = 视图不变）" % dz)

    # ── initial_transform（PSD 原始相对位置）在整条操作链后是否完好 ──
    _K = ("location", "scale", "rotation")
    snap = {o.name: {k: [float(x) for x in o[ATTR_INITIAL_TRANSFORM][k]] for k in _K}
            for o in locked if ATTR_INITIAL_TRANSFORM in o}
    p("\n### 【initial_transform 不变性】覆盖 %d 层" % len(snap))

    reset_cam()
    P.record_parallax_lock_state(root_coll, cam)
    ref2 = P.get_parallax_reference_depth(locked)
    # 移 + 转 + 变焦 各来一遍
    for loc, roty, lens in [((1.5, 0.0, 0.0), 0.0, 50.0),
                            ((1.5, 0.0, 0.0), 25.0, 50.0),
                            ((1.5, 0.0, 0.0), 25.0, 85.0)]:
        reset_cam()
        cam.location = base_cam_loc + right * loc[0]
        cam.rotation_euler = (base_cam_rot.x, base_cam_rot.y + math.radians(roty),
                              base_cam_rot.z)
        cam.data.lens = lens
        bpy.context.view_layer.update()
        for o in locked:
            P.apply_camera_adapt_to_obj(o, cam, ref2)
        bpy.context.view_layer.update()
    P.restore_parallax_lock_state(root_coll)
    bpy.context.view_layer.update()

    dmax, nbad = 0.0, 0
    for o in locked:
        if o.name not in snap:
            continue
        now = o[ATTR_INITIAL_TRANSFORM]
        old = snap[o.name]
        d = max(abs(a - b) for k in _K
                for a, b in zip([float(x) for x in now[k]], old[k]))
        dmax = max(dmax, d)
        if d > 1e-9:
            nbad += 1
    p("  最大差异 = %.2e   受影响层数 = %d / %d" % (dmax, nbad, len(snap)))
    p("  结论：%s" % ("✓ PSD 原始相对位置记录完好、未被任何操作污染"
                     if dmax < 1e-9 else "✗ 被改动了！"))

    # 相机复位
    reset_cam()

    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_user_scene_out.txt"),
              "w", encoding="utf-8") as f:
        f.write("\n".join(OUT))
    p("=" * 78)


main()
