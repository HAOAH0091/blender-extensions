"""AutoSway — 操作符

5 个 Operator：
  1. AddGroup      — 新建摆动组
  2. RemoveGroup   — 删除摆动组
  3. AddBones      — 添加选中骨骼到组
  4. RemoveBone    — 从组中移除单根骨骼
  5. ReorderBones  — 调整骨骼在组内的顺序
"""

import bpy
from bpy.props import StringProperty, IntProperty, EnumProperty

from .constants import COMPOSITE_MODE_REPLACE
from .core import (
    register_handler,
    unregister_handler,
    strip_sway_from_bone,
    strip_sway_from_group,
)
from .utils import (
    unique_group_name,
    bone_exists,
)
from .properties import _on_param_update


# ==================== 1. 新建摆动组 ====================

class AUTOSWAY_OT_AddGroup(bpy.types.Operator):
    """创建一个新的摆动组"""

    bl_idname = "autosway.add_group"
    bl_label = "新建摆动组"
    bl_description = "创建一个新的摆动组"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        groups = context.scene.autosway_groups
        group = groups.add()

        # 确保组名唯一
        base_name = f"摆动组 {len(groups)}"
        group.name = unique_group_name(groups, base_name)

        context.scene.autosway_active_group_index = len(groups) - 1

        # 如果是第一个组，注册 handler
        if len(groups) == 1:
            register_handler()

        return {'FINISHED'}


# ==================== 2. 删除摆动组 ====================

class AUTOSWAY_OT_RemoveGroup(bpy.types.Operator):
    """删除当前选中的摆动组，同时剥离组内骨骼的摆动值"""

    bl_idname = "autosway.remove_group"
    bl_label = "删除摆动组"
    bl_description = "删除该摆动组，同时剥离组内骨骼的摆动值"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        return len(context.scene.autosway_groups) > 0

    def execute(self, context):
        groups = context.scene.autosway_groups
        idx = self.group_index

        if idx < 0 or idx >= len(groups):
            self.report({'ERROR'}, "无效的组索引")
            return {'CANCELLED'}

        # 先剥离该组所有骨骼的摆动
        strip_sway_from_group(context.scene, groups[idx])

        groups.remove(idx)

        # 更新活动索引
        if len(groups) == 0:
            context.scene.autosway_active_group_index = -1
            # 没有组了，注销 handler
            unregister_handler()
        else:
            context.scene.autosway_active_group_index = min(idx, len(groups) - 1)

        return {'FINISHED'}


# ==================== 3. 添加选中骨骼 ====================

class AUTOSWAY_OT_AddBones(bpy.types.Operator):
    """将当前选中的姿态骨骼加入摆动组"""

    bl_idname = "autosway.add_bones"
    bl_label = "添加选中骨骼"
    bl_description = "将当前选中的姿态骨骼加入该摆动组"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty(default=-1)

    @classmethod
    def poll(cls, context):
        # 必须在姿态模式，且至少选中一根骨骼
        return (context.mode == 'POSE'
                and len(context.selected_pose_bones) > 0)

    def invoke(self, context, event):
        """检查重复添加时的冲突。

        v1.3.0：允许同一骨骼进多个组（用于叠加/覆盖摆动）。
        冲突提示只在"目标组是覆盖模式且该骨已在其他覆盖组"时弹出，
        避免覆盖模式的组在用户不知情的情况下盖掉别的组的贡献。
        叠加模式下直接放行（默认允许重复）。
        """
        groups = context.scene.autosway_groups
        if self.group_index < 0 or self.group_index >= len(groups):
            return self.execute(context)

        current_group = groups[self.group_index]

        # 收集所有其他组中的骨骼（用 bone_name + armature_name 联合键）
        existing_elsewhere = {}
        for i, g in enumerate(groups):
            if i == self.group_index:
                continue
            for item in g.bones:
                key = (item.bone_name, item.armature_name)
                existing_elsewhere[key] = g.name

        # 检查选中骨骼是否有冲突
        armature_name = context.active_object.name if context.active_object else ""
        conflicts = []
        for pb in context.selected_pose_bones:
            key = (pb.name, armature_name)
            if key in existing_elsewhere:
                conflicts.append(
                    f"{pb.name} → 已在「{existing_elsewhere[key]}」中"
                )

        # 仅当目标组是覆盖模式时，跨组重复才需要确认（因为会真正覆盖别的组的摆动）
        if conflicts and current_group.composite_mode == COMPOSITE_MODE_REPLACE:
            self._conflict_msg = "\n".join(conflicts)
            return context.window_manager.invoke_props_dialog(self, width=400)

        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="以下骨骼已在其他组中，且本组为「覆盖」模式：", icon='ERROR')
        layout.separator()
        for line in self._conflict_msg.split("\n"):
            layout.label(text=f"  {line}")
        layout.separator()
        layout.label(text="覆盖会替代这些骨骼在其他组的摆动，是否继续？")

    def execute(self, context):
        groups = context.scene.autosway_groups
        if self.group_index < 0 or self.group_index >= len(groups):
            self.report({'ERROR'}, "无效的组索引")
            return {'CANCELLED'}

        group = groups[self.group_index]

        # 获取当前骨架对象
        armature = context.active_object
        if armature is None or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "需要选中骨架对象")
            return {'CANCELLED'}

        # 记录已存在的骨骼（用 bone_name + armature_name 联合键），避免重复添加
        existing = {(item.bone_name, item.armature_name) for item in group.bones}

        added = 0
        for pose_bone in context.selected_pose_bones:
            key = (pose_bone.name, armature.name)
            if key in existing:
                continue

            item = group.bones.add()
            item.bone_name = pose_bone.name
            item.armature_name = armature.name
            existing.add(key)
            added += 1

        if added > 0:
            self.report({'INFO'}, f"已添加 {added} 根骨骼")
            # 触发 handler 重新计算
            _on_param_update(group, context)
        else:
            self.report({'WARNING'}, "选中的骨骼已在组内")

        return {'FINISHED'}


# ==================== 4. 移除单根骨骼 ====================

class AUTOSWAY_OT_RemoveBone(bpy.types.Operator):
    """从摆动组中移除该骨骼，并剥离其摆动值"""

    bl_idname = "autosway.remove_bone"
    bl_label = "移除骨骼"
    bl_description = "从摆动组中移除该骨骼，并剥离其摆动值"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty(default=-1)
    bone_name: StringProperty(default="")
    armature_name: StringProperty(default="")

    def execute(self, context):
        groups = context.scene.autosway_groups
        if self.group_index < 0 or self.group_index >= len(groups):
            self.report({'ERROR'}, "无效的组索引")
            return {'CANCELLED'}

        group = groups[self.group_index]

        # 先剥离该骨骼的摆动
        strip_sway_from_bone(context.scene, self.armature_name, self.bone_name)

        # 从列表中移除（用 bone_name + armature_name 联合匹配）
        for i, item in enumerate(group.bones):
            if item.bone_name == self.bone_name and item.armature_name == self.armature_name:
                group.bones.remove(i)
                # 更新活动骨骼索引
                if group.active_bone_index >= len(group.bones):
                    group.active_bone_index = max(0, len(group.bones) - 1)
                break

        return {'FINISHED'}


# ==================== 5. 调整骨骼顺序 ====================

class AUTOSWAY_OT_ReorderBones(bpy.types.Operator):
    """上移或下移骨骼在组内的顺序（影响递增角度和错帧量的分配）"""

    bl_idname = "autosway.reorder_bones"
    bl_label = "调整骨骼顺序"
    bl_description = "上移或下移骨骼的顺序"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty(default=-1)
    bone_index: IntProperty(default=-1)
    direction: EnumProperty(
        items=[
            ('UP', "上移", ""),
            ('DOWN', "下移", ""),
        ],
        default='UP',
    )

    def execute(self, context):
        groups = context.scene.autosway_groups
        if self.group_index < 0 or self.group_index >= len(groups):
            return {'CANCELLED'}

        group = groups[self.group_index]
        bones = group.bones
        i = self.bone_index

        if i < 0 or i >= len(bones):
            return {'CANCELLED'}

        if self.direction == 'UP' and i > 0:
            bones.move(i, i - 1)
            group.active_bone_index = i - 1
        elif self.direction == 'DOWN' and i < len(bones) - 1:
            bones.move(i, i + 1)
            group.active_bone_index = i + 1

        # 触发 handler 重新计算（顺序变了，每根骨骼的序号也变了）
        _on_param_update(group, context)

        return {'FINISHED'}
