"""AutoSway — 数据模型

定义 PropertyGroup 和 Scene 级属性。
所有摆动参数的 update 回调也定义在此模块，
回调内部通过延迟导入 core.py 来避免循环依赖。
"""

import bpy
from bpy.props import (
    StringProperty,
    FloatProperty,
    BoolProperty,
    EnumProperty,
    IntProperty,
    CollectionProperty,
    PointerProperty,
)

from .constants import (
    DEFAULT_SWAY_ANGLE,
    DEFAULT_INCREMENTAL_ANGLE,
    DEFAULT_LOOP_FRAMES,
    DEFAULT_STAGGERED_FRAMES,
    DEFAULT_OFFSET_FRAME,
    DEFAULT_AXIS,
    DEFAULT_AXIS_TILT_Y,
    DEFAULT_COMPOSITE_MODE,
    COMPOSITE_MODE_OVERLAY,
    COMPOSITE_MODE_REPLACE,
)


# ==================== Update 回调 ====================
# 延迟导入 core.py，避免 properties ↔ core 循环依赖

def _on_param_update(self, context):
    """摆动参数变更时，触发 depsgraph 刷新让 handler 重新计算。"""
    # view_layer.update() 触发 depsgraph_update_post，handler 随即响应
    if context.view_layer:
        context.view_layer.update()


def _on_enable_toggle(self, context):
    """组的启用/禁用切换。"""
    from .core import strip_sway_from_group

    if self.enabled:
        # 启用：触发 handler 重新计算
        _on_param_update(self, context)
    else:
        # 禁用：剥离该组所有骨骼的摆动值，恢复基础旋转
        strip_sway_from_group(context.scene, self)


# ==================== 骨骼条目 ====================

class SwayBoneItem(bpy.types.PropertyGroup):
    """摆动组中的单个骨骼条目。"""

    bone_name: StringProperty(
        name="骨骼名称",
        description="姿态骨骼的名称",
    )

    armature_name: StringProperty(
        name="骨架名称",
        description="该骨骼所属的骨架对象名称（多骨架场景下精确定位）",
    )

    # UI 折叠状态（仅层级模式下使用）
    expanded: BoolProperty(
        name="展开",
        default=True,
    )


# ==================== 摆动组 ====================

class SwayGroup(bpy.types.PropertyGroup):
    """一个独立的摆动组，包含一组骨骼和共享的摆动参数。"""

    # === 标识 ===
    name: StringProperty(
        name="组名",
        default="新摆动组",
    )

    # === 骨骼列表 ===
    bones: CollectionProperty(type=SwayBoneItem)
    active_bone_index: IntProperty(default=-1)

    # === 摆动参数 ===
    sway_angle: FloatProperty(
        name="摆动角度",
        description="第一根骨骼的基础振幅（度）",
        default=DEFAULT_SWAY_ANGLE,
        soft_min=-360.0,
        soft_max=360.0,
        update=_on_param_update,
    )

    incremental_angle: FloatProperty(
        name="递增角度",
        description="每多一根骨骼，振幅增加的角度（度）",
        default=DEFAULT_INCREMENTAL_ANGLE,
        soft_min=-10.0,
        soft_max=10.0,
        update=_on_param_update,
    )

    loop_frames: FloatProperty(
        name="循环帧数",
        description="完整摆动周期所需的帧数",
        default=DEFAULT_LOOP_FRAMES,
        min=1.0,
        soft_max=240.0,
        update=_on_param_update,
    )

    staggered_frames: FloatProperty(
        name="错帧量",
        description="相邻骨骼间的动画延迟帧数",
        default=DEFAULT_STAGGERED_FRAMES,
        soft_min=-50.0,
        soft_max=50.0,
        update=_on_param_update,
    )

    offset_frame: FloatProperty(
        name="帧偏移",
        description="全局动画起始偏移帧",
        default=DEFAULT_OFFSET_FRAME,
        soft_min=-240.0,
        soft_max=240.0,
        update=_on_param_update,
    )

    # === 轴向 ===
    axis: EnumProperty(
        name="摆动轴向",
        description="选择绕哪根轴摆动",
        items=[
            ('X', "X", "绕 X 轴摆动"),
            ('Y', "Y", "绕 Y 轴摆动"),
            ('Z', "Z", "绕 Z 轴摆动"),
        ],
        default=DEFAULT_AXIS,
        update=_on_param_update,
    )

    # === 摆动轴倾斜 ===
    # 让摆动轴在选了主轴之后，还能在空间里微微偏转。
    # 轴倾斜 = 绕 Y 转 axis_tilt_y（作用于主轴向量）。
    # 0 度时行为与旧版本完全一致（纯绕主轴摆动）。
    # v1.3.1：只保留绕 Y 倾斜（绕 Z 倾斜已移除），范围扩展为 ±360°。
    axis_tilt_y: FloatProperty(
        name="倾斜角度",
        description="让摆动轴绕 Y 轴偏转的角度（度）。0 表示不倾斜，只绕所选主轴摆动",
        default=DEFAULT_AXIS_TILT_Y,
        soft_min=-360.0,
        soft_max=360.0,
        update=_on_param_update,
    )

    # === 叠加/覆盖模式 ===
    # 当同一根骨骼被多个组共同管理时，决定各组摆动是叠加还是后者覆盖。
    composite_mode: EnumProperty(
        name="叠加/覆盖",
        description="同一骨骼被多个组共同管理时的处理方式",
        items=[
            (COMPOSITE_MODE_OVERLAY, "叠加", "多个组的摆动叠加生效（默认）"),
            (COMPOSITE_MODE_REPLACE, "覆盖", "后一组覆盖前一组，只保留最后一组摆动"),
        ],
        default=DEFAULT_COMPOSITE_MODE,
        update=_on_param_update,
    )

    # === 状态 ===
    enabled: BoolProperty(
        name="启用",
        description="启用/禁用该组的摆动效果",
        default=True,
        update=_on_enable_toggle,
    )

    # === UI 折叠状态 ===
    expanded: BoolProperty(
        name="展开",
        default=True,
    )


# ==================== Scene 级属性注册 ====================

def register_scene_props():
    """在 Scene 上注册插件所需的属性。"""
    bpy.types.Scene.autosway_groups = CollectionProperty(type=SwayGroup)
    bpy.types.Scene.autosway_active_group_index = IntProperty(
        name="活动摆动组索引",
        default=-1,
    )


def unregister_scene_props():
    """注销 Scene 上的插件属性。"""
    if hasattr(bpy.types.Scene, "autosway_groups"):
        del bpy.types.Scene.autosway_groups
    if hasattr(bpy.types.Scene, "autosway_active_group_index"):
        del bpy.types.Scene.autosway_active_group_index
