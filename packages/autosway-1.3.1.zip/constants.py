"""AutoSway — 常量定义

集中管理所有硬编码值：自定义属性键名、阈值、默认值。
其他模块统一从此导入，避免魔法数字散落各处。
"""

# ==================== 骨骼运行时自定义属性键名 ====================
# 这些属性写在每根被管理的骨骼上，用于 handler 的状态追踪

ASWAY_KEY_BASE_ROT = "_asway_base_rot"      # 用户的基础旋转值（弧度，Euler XYZ 三元组）
ASWAY_KEY_LAST_SWAY = "_asway_last_sway"    # 上一轮计算的摆动增量（弧度，Euler XYZ 三元组）
ASWAY_KEY_AXIS_INDEX = "_asway_axis_index"  # 摆动轴向索引（0/1/2）
ASWAY_KEY_HAS_MULTI = "_asway_has_multi"    # 该骨骼是否被多个组共同管理（叠加/覆盖模式）

# 所有运行时属性的集合，用于清除时批量删除
ASWAY_ALL_KEYS = (
    ASWAY_KEY_BASE_ROT,
    ASWAY_KEY_LAST_SWAY,
    ASWAY_KEY_AXIS_INDEX,
    ASWAY_KEY_HAS_MULTI,
)

# ==================== 数值阈值 ====================
# 注：旋转比较阈值已在 core.py 定义为 ROTATION_CHANGE_THRESHOLD（四元数角度差，弧度）。
# 旧版的单轴 float ROTATION_THRESHOLD（1e-6）已在 v1.3.0 弃用并移除。

# ==================== 默认值 ====================

DEFAULT_SWAY_ANGLE = 10.0       # 度
DEFAULT_INCREMENTAL_ANGLE = 5.0  # 度
DEFAULT_LOOP_FRAMES = 40.0
DEFAULT_STAGGERED_FRAMES = 3.0
DEFAULT_OFFSET_FRAME = 0.0
DEFAULT_AXIS = 'Z'
DEFAULT_AXIS_TILT_Y = 0.0       # 度：绕 Y 轴倾斜摆动轴（v1.3.1 只保留这一个，放弃绕Z）

# ==================== 叠加/覆盖模式 ====================
# OVERLAY：多组摆动叠加生效，最终旋转 = 基础姿态 ⊗ 组1 ⊗ 组2 ...（默认）
# REPLACE：后一组覆盖前一组，只保留生效的最后一组摆动

COMPOSITE_MODE_OVERLAY = 'OVERLAY'
COMPOSITE_MODE_REPLACE = 'REPLACE'
DEFAULT_COMPOSITE_MODE = COMPOSITE_MODE_OVERLAY

# ==================== UI 常量 ====================

UI_LIST_ROWS = 6  # 骨骼列表默认显示行数
