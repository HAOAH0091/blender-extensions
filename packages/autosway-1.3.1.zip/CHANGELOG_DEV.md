# AutoSway 开发者变更日志

本文件面向插件开发者，记录每个版本的代码变更、修复的 bug、架构调整等。

格式遵循 [Keep a Changelog](https://keepachangelog.com/)，版本号遵循 [SemVer](https://semver.org/)。

---

## [1.3.1] - 2026-08-09

### 变更

- **摆动轴倾斜收敛为单一滑块**：
  - `properties.py`：删除 `axis_tilt_z` 字段，`axis_tilt_y` 更名为"倾斜角度"，`soft_min/soft_max` 从 ±90 扩展到 ±360
  - `constants.py`：删除 `DEFAULT_AXIS_TILT_Z`
  - `core.py`：`sway_axis_vector()` 只保留绕 Y 倾斜（绕 Z 已移除）；docstring 注明主轴为 Y 时倾斜无效
  - `ui.py`：把"摆动轴倾斜"移到轴向选择正下方，改单滑块；主轴为 Y 时显示"（Y轴无效）"提示
- **迁移说明**：旧的 `axis_tilt_z` 属性在旧 .blend 存档中已定义，v1.3.1 移除该 PropertyGroup 字段后，
  旧存档里该字段会被自动丢弃（PropertyGroup 字段删除时，已存的该属性值随数据块失效），
  不影响 `axis_tilt_y`。若旧存档曾设 `axis_tilt_z`，升级后该旋转会丢失（因字段已删），
  需用户重设一次倾斜角。

### 说明

- 倾斜角范围扩到 ±360°，但主轴为 Y 时绕 Y 倾斜无效（几何上 Y 绕自身转不改变方向），UI 已提示。

### 测试

- 语法检查通过；`sway_axis_vector` 绕 Y 倾斜数学验证（主轴 X 绕 Y 30° → 精确单位向量）。
- 回归脚本 `autosway_regression.py` 同步更新（去掉 `axis_tilt_z` 参数），5 个边界测试仍通过。

---

## [1.3.0] - 2026-08-08

### 新增

- **可倾斜摆动轴**：
  - `constants.py`：新增 `DEFAULT_AXIS_TILT_Y` / `DEFAULT_AXIS_TILT_Z`（倾斜角默认 0）
  - `properties.py`：`SwayGroup` 新增 `axis_tilt_y` / `axis_tilt_z` 字段（FloatProperty，带 update 回调）
  - `core.py`：新增 `sway_axis_vector()`，把主轴 + 两个倾斜角合成单位摆动轴向量；
    新增 `compute_sway_quaternion()`，把摆动角度 + 倾斜轴组合成四元数
  - 倾斜角为 0 时行为与旧版本完全一致（返回标准主轴）

- **多组叠加/覆盖**：
  - `constants.py`：新增 `COMPOSITE_MODE_OVERLAY` / `COMPOSITE_MODE_REPLACE` / `DEFAULT_COMPOSITE_MODE`
  - `properties.py`：`SwayGroup` 新增 `composite_mode` 枚举字段（叠加/覆盖，默认叠加）
  - `core.py`：handler 重构为"按骨骼聚合所有作用组的摆动贡献 → 统一反推基础姿态 → 一次性写回"；
    新增 `_is_bone_multi`、`_process_aggregated_bone`，删除了旧的单组 `_process_bone` 和 `_process_bone_aggregate`
  - `operators.py`：`AddBones.invoke` 放宽跨组重复限制——叠加模式直接放行，仅覆盖模式跨组重复才弹窗确认

### 架构调整

- **摆动写入从欧拉单分量 → 四元数组合**：
  原 `compute_sway` 直接写 `rotation_euler[axis]`，只能表达绕标准轴的摆动。
  现在改为 `q_sway @ q_base`（摆动四元数在左、基础姿态在右），再 `to_euler('XYZ')` 写回。
  这样倾斜轴摆动也可以用四元数精确表达，且标准轴、零倾斜时与旧版本等价。
- **基础姿态追踪从单轴 float → 欧拉 XYZ 三元组**：
  `_asway_base_rot` / `_asway_last_sway` 由单轴 float 升级为 3 元组，
  以支持倾斜轴摆动下三个旋转分量的联合追踪。新增 `_asway_has_multi` 标记骨骼多组状态。
  兼容旧存档：读取到单 float 时做兼容转换。
- **状态机单组/多组统一**：
  `_process_aggregated_bone` 是唯一的写回函数，通过 `is_multi` 参数区分单组/多组，
  避免多组叠加时基础姿态被多个组误判反推（导致抖动）。

### 修复（复审阶段）

- **M1（用户改动反推方向错误）**：反向推理基础姿态原本用右乘逆 `cur_q @ last_sway_q.inverted()`，
  与写入约定 `sway @ base`（左乘）不一致，导致用户手动旋转轴 ≠ 摆动轴时重新注入跳变。
  改为左乘逆 `base_q = last_sway_q.inverted() @ cur_q`。
- **M2（单组→多组切换摆动翻倍）**：切换多组状态时原本把合成值 `rotation_euler[:]` 当基础，
  会把上一组摆动烘焙进基础再叠一遍。改为保留原 `base_rot`（纯基础），仅在从未建立时初始化。
- **跨帧误判（帧变化被当作"用户改动"）**：用户改动检测原本用本帧 `final_sway_q` 当期望值，
  因它随帧号变化，导致每帧摆动变化都被误判为用户改动而污染基础。
  改为用上一帧快照 `last_sway_q` 做检测与反推（与旧版"减 last_sway"语义一致）。
- **问题 A（首次建立基础污染，依赖触发时序）**：首次建立基础姿态时原本用
  `final_sway_q.inverted() @ cur_q` 剥离摆动，但骨骼尚未注入摆动时（cur_q 仍是纯基础）
  会剥掉不存在的摆动污染 base。改为**直接用 `base_q = cur_q`**（首次进入聚合时骨骼必然未注入摆动）。
- **m1（多组判断性能/正确性）**：删除每帧全量扫描的 `_is_bone_multi`，改用 `len(sway_list) > 1`
  直接判断是否多组——更准确且正确处理链接复制体。
- **m2（欧拉序回归）**：`ensure_euler_rotation` 由"只处理 QUATERNION/AXIS_ANGLE"改为
  强制归一化到 'XYZ'（`if bone.rotation_mode != 'XYZ'`），避免非 XYZ 欧拉序下写入三元组错序。
- **m5（死代码清理）**：删除死常量 `ROTATION_THRESHOLD`、死函数 `get_axis_index`、`AXIS_MAP`；
  `operators.py` 用 `COMPOSITE_MODE_REPLACE` 常量替代硬编码 `'REPLACE'`。
- **m4（死分支）**：`linked_cache` 的 else 死分支改为防御性 `[arm_name] + list(cached)`；
  复审确认 `_find_linked_armatures` 恒含源骨架自身，else 不可达，已合并为单行赋值。

> **已知兼容局限**：旧版（v1.2.0 及以前）的 `base_rot` 存单个轴 float，且未记录当时是哪根轴。
> `_base_rot_to_quaternion` 对旧单 float 按"绕 X 轴"兜底转换。若旧存档某骨骼曾绕 Y/Z 轴摆动，
> 升级到 v1.3.0 时该骨骼的基础姿态可能被转错轴。**影响面**：仅限从旧存档读取、且曾用非 X 轴摆动
> 的骨骼。建议升级后用该骨骼的首帧核对基础姿态；如异常，重新手动设一次基础姿态即可（后续都按
> XYZ 三元组正确追踪）。

### 测试

- 倾斜轴数学验证通过：主轴 X 经绕 Y 30° 倾斜 → `[0.866, 0, -0.5]`，精确单位向量
- 四元数往返零漂移：`base_rot → quaternion → euler` 误差 0°
- 同轴摆动四元数相乘 = 角度相加：绕 Z 10°+25° → 35°Z
- 多组叠加验证：两组件用同一骨骼（绕Z 10° + 绕X 8°）叠加 → `[-8, 0, -10]` 双轴同时生效
- 多组覆盖验证：覆盖模式只保留后一组 → `[-8, 0, 0]`，与单组 g3 一致
- 用户手动旋转验证：叠加模式下用户把骨骼转到 45°Y，handler 正确反推并保留基础姿态
- 首帧捕获验证：用户提前转好骨骼（0/40/15°），首帧 handler 正确记录为基础姿态，后续摆动不污染基础
- 端到端集成验证：真注册插件、两组管理同一骨骼、调用真实 handler，叠加生效且 `has_multi=true`
- **M1 修复验证**：用户手动旋转轴 ≠ 摆动轴（绕 X 补转 20°），重新注入后 X 分量精确保留 20°，
  无跳变；纯数学验证左乘逆重新注入与用户姿态误差 0°
- **M2 修复验证**：单组跑若干帧后加入第二组，摆动不翻倍——A 的 Z 摆动与 B 的 X 摆动正叠加，
  基础姿态保持 0 不被污染；跨帧不误判（此前帧变化被误判导致摆动只剩 1/8，修复后满幅）
- **问题 A 修复验证**：底层路径（绕过 operator）首次建立基础，base_rot 正确为纯用户姿态 [0,40,0]°，
  不依赖 final_sway⁻¹ 剥离，不污染
- **5 个边界测试（真实 operator 路径，`--factory-startup` 干净环境）全部通过**：
  链接复制体+多组叠加不翻倍、禁用叠加组 base 保留、删除叠加组自愈、倾斜角 0 度回标准主轴、
  覆盖模式只保留最后一组。详见 `autosway_regression.py`

---

## [1.2.0] - 2026-07-20

### 新增

- **Alt+D 链接复制骨架自动继承摆动动画**：
  - `core.py`：新增 `_find_linked_armatures()`，通过 `data` 指针匹配链接复制体
  - handler 循环：首次初始化复制体的追踪状态并同步旋转值，规避伪用户修改检测
  - `strip_sway_from_bone`：连锁剥离所有链接复制体的摆动值
  - `ui.py`：`_get_visible_group_indices` 加入 `data` 指针匹配，链接复制体面板可见
  - Shift+D 完整复制不受影响（独立 data 块天然隔离）

- **摆动组管理 UI 按当前骨架过滤显示**：
  - `ui.py`：`draw()` 新增 `_get_visible_group_indices()` 过滤层
  - 有骨骼的组按 `armature_name` 匹配当前活动骨架，空组始终可见
  - 防御性兜底：无活动骨架时返回全部组
  - 仅 `ui.py` 单文件改动，不影响 operators/core/properties

### 变更

- `__init__.py`：`bl_info["version"]` 更新为 `(1, 2, 0)`
- `VERSION.md` / `CHANGELOG_DEV.md`：同步归档本次更新

### 测试

- 链接复制体同步摆动验证通过（Alt+D 创建复制体后参数同步、摆动同步）
- 不双倍叠加验证通过（原骨架与复制体各自独立计算，不出现摆动翻倍）
- 参数同步验证通过（修改原骨架参数后复制体同步变化）
- 删除连锁验证通过（删除摆动组后复制体骨骼的摆动同步剥离）
- UI 过滤 3 场景验证通过：两骨架切换显示、空组始终可见、过滤态增删骨骼正常

---

## [1.1.0] - 2026-07-03

### 新增

- **父子级传导模式**：摆动传导改为按骨骼实际父子级深度计算（`compute_bone_depth`）。
  handler 通过 `has_parent_child_in_group` 自动检测组内是否有父子关系，有则使用深度，
  无则回退到列表序号。
- **层级模式 UI**：有父子关系的骨骼组以树形缩进结构显示，带折叠/展开功能。
  使用 `split(factor=0.92)` 递归嵌套实现缩进（经 Blender 5.1 验证可行）。
- **平铺模式保留**：无父子关系时保持原有平铺列表 + 上下移动按钮。
- **混合场景检测**：当一个组同时包含有父子关系的骨骼和独立骨骼时，
  独立骨骼作为根节点（depth=0），UI 添加提示说明。
- **SwayBoneItem.expanded**：新增属性存储骨骼树节点的折叠状态。

### 变更

- **默认参数优化**：摆动角度 20→10、递增角度 1→5、循环帧数 24→40、错帧量 5→3。
- **__init__.py**：`bl_info["version"]` 更新为 `(1, 1, 0)`。

### 修复

- **__init__.py**：移除 `autosway_handler` 未使用导入（S4）。
- **ui.py**：`_draw_bone_node` 递归深度保护，depth > 50 时终止并打出警告日志（W4）。

### 代码优化

- **ui.py**：`group_bones_map` 和 `group_bones_set` 合并为一次遍历构建（S1）。
- **core.py**：handler 中预构建 `group_bones_set`，传递给 `compute_bone_depth`
  和 `has_parent_child_in_group`，避免重复构建（S2）。
- **utils.py**：`get_children_in_group` 接收预构建的 `group_bones_map` 字典，
  O(1) 查找替代 O(n) 内循环（W2）。

### 测试

- 18 根骨骼（多层分叉）的深度计算全部通过，精确匹配理论深度
- 同深度骨骼的 sway 值完全一致（Bone.001 vs Bone.004 偏差 0.00°）
- 平铺模式回归验证通过（无父子关系时行为与 v1.0.0 一致）
- 全功能回归验证通过（手动操控、参数调整、轴向切换、禁用/启用、删除组）

---

## [1.0.0] - 2026-07-02

### 新增

- **初始版本**，从零开发，替代原 autosway_v0.5 插件
- 采用 Handler + 状态追踪模式（借鉴 Parallax Locker），弃用原插件的驱动器方案
- `depsgraph_update_post` + `frame_change_post` 双 handler 驱动摆动计算
- 三段式状态追踪状态机：检测用户修改 → 反推基础旋转 → 重新注入摆动
- 骨骼自定义属性追踪 `_asway_base_rot` / `_asway_last_sway` / `_asway_axis_index`
- 5 个 Operator：新建组、删除组、添加骨骼、移除骨骼、调整顺序
- 多摆动组管理（CollectionProperty），每组独立参数和骨骼列表
- 面板参数 update 回调，修改即触发 handler 重新计算
- 组的启用/禁用，禁用时自动剥离摆动值恢复基础旋转
- 轴向切换检测：自动清理旧轴摆动 + 重置新轴追踪状态
- 跨组骨骼冲突检测（invoke 弹窗确认）
- `load_post` handler：文件加载后自动恢复运行时 handler
- 骨骼缺失检测：UI 标记"缺失"图标，handler 跳过不报错

### 架构决策

- **弃用驱动器方案**：驱动器占有属性导致用户无法手动旋转骨骼和 K 帧，且参数写死在表达式字符串中无法实时更新
- **弃用 NLA 叠加方案**：NLA 的 Action Track 对其定义的属性通道是替换模式，用户一旦 K 帧就覆盖了 NLA 摆动贡献；且 NLA 仅在播放时求值，交互式 Pose Mode 下看不到效果
- **弃用约束代理方案**：需要在场景中生成空物体，视觉干扰大；多骨骼错帧需要多个空物体
- **选择 Handler + 状态追踪**：不占有属性、不生成额外对象、实时响应、实现复杂度低。核心模式直接复用 Parallax Locker 的成熟验证

### 开发中修复的问题

1. **`_asway_base_rot` 首次初始化 bug**：原逻辑仅在检测到用户变化时才写入 base_rot，导致首轮处理后属性不存在，第二轮误判。修复为首轮跳过检测 + 始终持久化 base_rot
2. **`depsgraph_update_post` 在 MCP 脚本执行时不触发**：改为同时注册 `frame_change_post` + `depsgraph_update_post` 双 handler，前者保证帧变化必定触发，后者捕获用户手动旋转
3. **`_RestrictContext` 报错**：`register()` 中访问 `bpy.context.scene` 在插件管理器启用时会失败。移除该访问，改为完全依赖 `load_post` handler 和 `AddGroup` 操作触发 handler 注册
4. **轴向切换时旧轴残留**：handler 检测 `axis_index` 变化时自动清理旧轴并重置新轴追踪状态

### 代码审查后修复（审查官：agent-mpj3kvf3）

#### MAJOR

- `__init__.py`：裸 `except Exception: pass` 改为精确捕获 `ValueError`（已注册），其余异常 print + raise
- `operators.py`：RemoveBone / AddBones 冲突检测 / AddBones 去重检查，全部从只比 `bone_name` 改为 `(bone_name, armature_name)` 联合键
- `core.py`：handler 内自定义属性写入（`base_rot`、`last_sway`、`axis_index`）加 `if bone.get(key) != value` 变化检测，减少不必要的 depsgraph 重复触发
- `core.py` + `constants.py`：删除 `ASWAY_KEY_GROUP` 死写入（定义后只在 handler 中赋值，从未被读取）

#### MINOR

- `utils.py`：删除 3 个未调用的死函数（`find_armature`、`degrees_to_radians`、`has_sway_props`）
- `utils.py`：`ensure_euler_rotation` 删除永远为 True 的 `return` 语句
- `utils.py`：`clear_sway_props` 中的延迟导入改为顶部 import
- `properties.py`：`unregister_scene_props` 加 `hasattr` 存在性检查
- `core.py`：handler 异常分类处理，`AttributeError` 静默跳过，其余异常加 `traceback.print_exc()`
- `core.py`：清理对 `find_armature` 的无用 import

### 测试

- 9 项功能测试全部通过（基础摆动、手动旋转叠加、参数实时调整、轴向切换、禁用/启用、移除骨骼、重排序、删除组、多组独立管理）
- 4 项边界情况测试通过（空组、loop_frames=1、sway_angle=0、删除骨骼后 handler）
- 正弦波 11 帧采样点全部与理论值精确匹配
- 错帧量验证通过
- Blender 5.1 实际环境验证通过
