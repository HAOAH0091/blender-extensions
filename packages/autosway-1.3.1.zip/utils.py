"""AutoSway — 工具函数

提供骨骼查找、轴向映射、旋转模式处理等基础能力。
不依赖 core.py 和 operators.py，只依赖 constants.py。
"""

import bpy
from .constants import ASWAY_ALL_KEYS, ASWAY_KEY_BASE_ROT


# ==================== 骨骼查找 ====================

def find_bone_in_scene(scene, armature_name, bone_name):
    """在指定骨架对象中查找姿态骨骼。

    Args:
        scene: 当前场景
        armature_name: 骨架对象名称
        bone_name: 骨骼名称

    Returns:
        bpy.types.PoseBone | None
    """
    armature = scene.objects.get(armature_name)
    if armature is None or armature.type != 'ARMATURE':
        return None
    return armature.pose.bones.get(bone_name)


def bone_exists(scene, armature_name, bone_name):
    """检查骨骼是否仍然存在于场景中（未被删除或改名）。"""
    return find_bone_in_scene(scene, armature_name, bone_name) is not None


# ==================== 旋转模式处理 ====================

def ensure_euler_rotation(bone):
    """确保骨骼使用 'XYZ' 欧拉旋转模式。

    v1.3.0 起，插件的摆动计算用四元数，写回时统一用 `to_euler('XYZ')`。
    因此骨骼必须处于 'XYZ' 欧拉序才能正确读写三元组。
    如果当前是四元数（QUATERNION）、轴角（AXIS_ANGLE），
    或任何非 'XYZ' 的欧拉变体（XZY, YXZ, ZXY 等），都强制切换为 'XYZ'。
    Blender 会自动做转换，旋转方向保留。

    Args:
        bone: PoseBone 实例
    """
    if bone.rotation_mode != 'XYZ':
        bone.rotation_mode = 'XYZ'


# ==================== 自定义属性管理 ====================

def clear_sway_props(bone):
    """清除骨骼上所有 AutoSway 运行时自定义属性。"""
    for key in ASWAY_ALL_KEYS:
        if key in bone:
            del bone[key]


# ==================== 层级深度计算 ====================

def compute_bone_depth(scene, group_bones_set, bone_item):
    """计算骨骼在组内的层级深度。

    从该骨骼沿父级链向上走，每经过一个在组内的父级 +1。
    直到父级不在组内（或无父级），返回步数。

    Args:
        scene: 当前场景
        group_bones_set: 组内骨骼的 (bone_name, armature_name) 集合
        bone_item: SwayBoneItem 实例

    Returns:
        int: 组内深度（0 = 组内根骨骼）
    """
    bone = find_bone_in_scene(scene, bone_item.armature_name, bone_item.bone_name)
    if bone is None:
        return 0

    depth = 0
    current = bone.parent
    while current is not None:
        if (current.name, bone_item.armature_name) in group_bones_set:
            depth += 1
            current = current.parent
        else:
            break

    return depth


# ==================== 层级关系检测 ====================

def has_parent_child_in_group(scene, group_bones_set, group):
    """检测组内是否存在任何父子级关系。

    遍历组内每根骨骼，检查其父级是否也在组内。
    只要找到一对就返回 True。

    Args:
        scene: 当前场景
        group_bones_set: 组内骨骼的 (bone_name, armature_name) 集合
        group: SwayGroup 实例

    Returns:
        bool: True 表示组内至少有一对父子关系
    """
    for item in group.bones:
        bone = find_bone_in_scene(scene, item.armature_name, item.bone_name)
        if bone is None:
            continue
        if bone.parent is not None:
            if (bone.parent.name, item.armature_name) in group_bones_set:
                return True

    return False


# ==================== 层级遍历 ====================

def get_root_bones_in_group(group, group_bones_set, scene):
    """获取组内所有根骨骼（父级不在组内 或 无父级）。

    Args:
        group: SwayGroup 实例
        group_bones_set: 组内骨骼的 (bone_name, armature_name) 集合
        scene: 当前场景

    Returns:
        list[SwayBoneItem]: 根骨骼条目列表（保持列表中的出现顺序）
    """
    roots = []
    for item in group.bones:
        bone = find_bone_in_scene(scene, item.armature_name, item.bone_name)
        if bone is None:
            roots.append(item)
            continue

        parent = bone.parent
        if parent is None:
            roots.append(item)
        elif (parent.name, item.armature_name) not in group_bones_set:
            roots.append(item)

    return roots


def get_children_in_group(scene, group_bones_map, bone_item):
    """获取某骨骼在组内的直接子级列表。

    Args:
        scene: 当前场景
        group_bones_map: (bone_name, armature_name) → SwayBoneItem 的字典
        bone_item: 父骨骼条目

    Returns:
        list[SwayBoneItem]: 在组内且是 bone_item 直接子级的条目列表
    """
    bone = find_bone_in_scene(scene, bone_item.armature_name, bone_item.bone_name)
    if bone is None:
        return []

    children = []
    for child_bone in bone.children:
        item = group_bones_map.get((child_bone.name, bone_item.armature_name))
        if item is not None:
            children.append(item)

    return children


# ==================== 组名唯一性 ====================

def unique_group_name(groups, base_name):
    """确保组名在 groups 集合中唯一。

    如果名称已存在，追加数字后缀（2, 3, 4...）。
    """
    existing = {g.name for g in groups}
    if base_name not in existing:
        return base_name

    i = 2
    while f"{base_name} {i}" in existing:
        i += 1
    return f"{base_name} {i}"
