# -*- coding: utf-8 -*-
"""AutoSway v1.3.0 边界情况反向功能验证 —— 用真实 Operator 路径（用户实际使用流程）。

运行方式（干净环境）：
  & "G:\steam\steamapps\common\Blender\blender.exe" --background --factory-startup --python autosway_regression.py

验证流程贴近用户真实操作：
  - AddGroup operator 创建组（内部触发 register_handler）
  - 手动向组添加骨骼条目（模拟 AddBones）
  - 切帧触发 frame_change handler
  - test3 用 RemoveGroup operator 语义删除组
每个测试输出一行 JSON。
"""

import bpy
import math
import json
import sys
from mathutils import Vector, Quaternion, Euler

sys.path.insert(0, r"F:\desktop\BaiduSyncdisk\addons")
import autosway
from autosway import core, constants


TOL_DEG = 0.5  # 度


def reset_scene():
    """清场：清组、删物体、清 handler（贴近 RemoveGroup 删光 + unregister）。"""
    try:
        core.unregister_handler()
    except Exception:
        pass
    scene = bpy.context.scene
    while len(scene.autosway_groups) > 0:
        try:
            scene.autosway_groups.remove(0)
        except Exception:
            break
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    for arm in list(bpy.data.armatures):
        bpy.data.armatures.remove(arm)


def make_armature(name="Rig", bone_name="Bone", base_deg=(0, 0, 0)):
    arm_data = bpy.data.armatures.new(name)
    ob = bpy.data.objects.new(name, arm_data)
    bpy.context.scene.collection.objects.link(ob)
    bpy.context.view_layer.objects.active = ob
    ob.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    eb = arm_data.edit_bones.new(bone_name)
    eb.head = (0, 0, 0)
    eb.tail = (0, 1, 0)
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.mode_set(mode='POSE')
    pb = ob.pose.bones[bone_name]
    pb.rotation_mode = 'XYZ'
    if base_deg != (0, 0, 0):
        pb.rotation_euler = tuple(math.radians(x) for x in base_deg)
    return ob, pb


def add_group(name, bone_name="Bone", arm_name="Rig", **params):
    """用真实 AddGroup operator 创建组，再追加骨骼条目（模拟 AddBones）。"""
    bpy.ops.autosway.add_group()
    g = bpy.context.scene.autosway_groups[-1]
    g.name = name
    item = g.bones.add()
    item.bone_name = bone_name
    item.armature_name = arm_name
    for k, v in params.items():
        setattr(g, k, v)
    return g


def read_bone(pb):
    e = pb.rotation_euler
    props = {}
    for key in constants.ASWAY_ALL_KEYS:
        if key in pb:
            v = pb[key]
            try:
                v = tuple(round(x, 6) for x in v)
            except TypeError:
                v = v
            props[key] = v
    return {
        "euler_deg": [round(math.degrees(x), 4) for x in (e.x, e.y, e.z)],
        "base_rot": props.get(constants.ASWAY_KEY_BASE_ROT),
        "last_sway": props.get(constants.ASWAY_KEY_LAST_SWAY),
        "has_multi": props.get(constants.ASWAY_KEY_HAS_MULTI),
    }


def expected_deg(sway_q, base_deg):
    bq = Euler([math.radians(x) for x in base_deg], 'XYZ').to_quaternion()
    return [round(math.degrees(a), 4) for a in (sway_q @ bq).to_euler('XYZ')]


def deg_close(actual, expected, tol=TOL_DEG):
    return all(abs(a - b) <= tol for a, b in zip(actual, expected))


# =====================================================================
# 测试 1：链接复制体（Alt+D）+ 多组叠加
# =====================================================================
def test_linked_dup_overlay():
    scene = bpy.context.scene
    ob, pb = make_armature("Rig", "Bone", base_deg=(0, 0, 0))
    dup = ob.copy()
    dup.name = "Rig.001"
    scene.collection.objects.link(dup)
    dpb = dup.pose.bones["Bone"]
    dpb.rotation_mode = 'XYZ'

    add_group("G1", bone_name="Bone", arm_name="Rig", sway_angle=10.0,
              loop_frames=40.0, axis='Y', composite_mode='OVERLAY')
    add_group("G2", bone_name="Bone", arm_name="Rig", sway_angle=20.0,
              loop_frames=40.0, axis='X', composite_mode='OVERLAY')

    scene.frame_set(10)

    q1 = core.compute_sway_quaternion(scene.autosway_groups[0], 0, 10)
    q2 = core.compute_sway_quaternion(scene.autosway_groups[1], 0, 10)
    exp = expected_deg(q1 @ q2, (0, 0, 0))

    r_src = read_bone(pb)
    r_dup = read_bone(dpb)

    src_ok = deg_close(r_src["euler_deg"], exp)
    dup_ok = deg_close(r_dup["euler_deg"], exp)
    links_match = deg_close(r_src["euler_deg"], r_dup["euler_deg"])
    base_polluted = (r_src["base_rot"] is not None and
                     any(abs(x) > 0.05 for x in r_src["base_rot"]))
    passed = src_ok and dup_ok and links_match and (not base_polluted)

    return json.dumps({
        "test": "1_linked_dup_overlay",
        "src_deg": r_src["euler_deg"], "dup_deg": r_dup["euler_deg"],
        "exp_deg": exp,
        "src_base": r_src["base_rot"], "src_has_multi": r_src["has_multi"],
        "src_ok": src_ok, "dup_ok": dup_ok, "links_match": links_match,
        "base_polluted": bool(base_polluted),
        "passed": bool(passed),
    }, ensure_ascii=False)


# =====================================================================
# 测试 2：禁用一个叠加组
# =====================================================================
def test_disable_overlay_group():
    scene = bpy.context.scene
    ob, pb = make_armature("Rig", "Bone", base_deg=(17.1887, 5.7296, 0))

    add_group("G_A", bone_name="Bone", arm_name="Rig", sway_angle=10.0,
              loop_frames=40.0, axis='Y', composite_mode='OVERLAY')
    add_group("G_B", bone_name="Bone", arm_name="Rig", sway_angle=20.0,
              loop_frames=40.0, axis='X', composite_mode='OVERLAY')

    scene.frame_set(10)
    combined = read_bone(pb)

    idxB = scene.autosway_groups.find("G_B")
    scene.autosway_groups[idxB].enabled = False
    scene.frame_set(14)
    after_disable = read_bone(pb)

    scene.autosway_groups[idxB].enabled = True
    scene.frame_set(16)
    after_reenable = read_bone(pb)

    expected_base = (0.3, 0.1, 0.0)
    base_kept = (combined["base_rot"] is not None and
                 abs(combined["base_rot"][0] - expected_base[0]) < 0.01 and
                 abs(combined["base_rot"][1] - expected_base[1]) < 0.01)
    combined_wrote = deg_close(combined["euler_deg"],
                               expected_deg(
                                   core.compute_sway_quaternion(scene.autosway_groups[0], 0, 10) @
                                   core.compute_sway_quaternion(scene.autosway_groups[1], 0, 10),
                                   (17.1887, 5.7296, 0)))
    broken = not base_kept or not combined_wrote or combined["has_multi"] is not True
    passed = not broken

    return json.dumps({
        "test": "2_disable_overlay_group",
        "combined_deg": combined["euler_deg"],
        "after_disable_deg": after_disable["euler_deg"],
        "after_reenable_deg": after_reenable["euler_deg"],
        "combined_base": combined["base_rot"],
        "combined_has_multi": combined["has_multi"],
        "base_kept": bool(base_kept),
        "combined_wrote": bool(combined_wrote),
        "passed": bool(passed),
    }, ensure_ascii=False)


# =====================================================================
# 测试 3：删除一个叠加组（自愈性）— 用 RemoveGroup operator 语义
# =====================================================================
def test_remove_overlay_group():
    scene = bpy.context.scene
    ob, pb = make_armature("Rig", "Bone", base_deg=(11.4592, 0, 0))
    B3 = (0.2, 0.0, 0.0)

    add_group("G_A", bone_name="Bone", arm_name="Rig", sway_angle=8.0,
              loop_frames=40.0, axis='Y', composite_mode='OVERLAY')
    add_group("G_B", bone_name="Bone", arm_name="Rig", sway_angle=15.0,
              loop_frames=40.0, axis='X', composite_mode='OVERLAY')

    scene.frame_set(10)
    combined = read_bone(pb)

    # 用真实 RemoveGroup operator（设 group_index），内部会 strip + remove + unregister
    from autosway.operators import AUTOSWAY_OT_RemoveGroup
    idxA = scene.autosway_groups.find("G_A")
    # 直接调用 execute 核心逻辑（在 headless 无 context.window_manager 时需模拟）
    from autosway.core import strip_sway_from_group
    strip_sway_from_group(scene, scene.autosway_groups[idxA])
    scene.autosway_groups.remove(idxA)
    scene.autosway_active_group_index = 0

    scene.frame_set(10)
    after_remove = read_bone(pb)

    base_kept = (after_remove["base_rot"] is not None and
                 abs(after_remove["base_rot"][0] - B3[0]) < 0.01)
    moved = not all(abs(a) < 1.0 for a in after_remove["euler_deg"])
    passed = base_kept and moved and len(scene.autosway_groups) == 1

    return json.dumps({
        "test": "3_remove_overlay_group",
        "combined_deg": combined["euler_deg"],
        "after_remove_deg": after_remove["euler_deg"],
        "combined_base": combined["base_rot"],
        "after_base": after_remove["base_rot"],
        "remaining_groups": len(scene.autosway_groups),
        "base_kept": bool(base_kept), "moved": bool(moved),
        "passed": bool(passed),
    }, ensure_ascii=False)


# =====================================================================
# 测试 4：倾斜角 0 度兼容性（标准主轴）
# =====================================================================
def test_tilt_zero():
    scene = bpy.context.scene
    ob, pb = make_armature("Rig", "Bone", base_deg=(0, 0, 0))
    add_group("G", bone_name="Bone", arm_name="Rig", sway_angle=12.0,
              loop_frames=40.0, axis='X', axis_tilt_y=0.0,
              composite_mode='OVERLAY')

    scene.frame_set(10)

    axis_vec = core.sway_axis_vector(scene.autosway_groups[0])
    axis_ok = (axis_vec - Vector((1.0, 0.0, 0.0))).length <= 1.0e-6
    q = core.compute_sway_quaternion(scene.autosway_groups[0], 0, 10)
    r = read_bone(pb)
    exp = expected_deg(q, (0, 0, 0))
    pure_x = deg_close(r["euler_deg"], exp, tol=0.05)
    base_kept = (r["base_rot"] is None or all(abs(x) < 0.01 for x in r["base_rot"]))
    passed = axis_ok and pure_x and base_kept

    return json.dumps({
        "test": "4_tilt_zero",
        "axis_vec": [round(v, 6) for v in axis_vec],
        "axis_ok": bool(axis_ok),
        "euler_deg": r["euler_deg"], "exp_deg": exp,
        "base": r["base_rot"],
        "pure_x": pure_x, "base_kept": bool(base_kept),
        "passed": bool(passed),
    }, ensure_ascii=False)


# =====================================================================
# 测试 5：覆盖模式（REPLACE）
# =====================================================================
def test_replace_mode():
    scene = bpy.context.scene
    ob, pb = make_armature("Rig", "Bone", base_deg=(0, 0, 0))

    add_group("G1", bone_name="Bone", arm_name="Rig", sway_angle=10.0,
              loop_frames=40.0, axis='Y', composite_mode='OVERLAY')
    add_group("G2", bone_name="Bone", arm_name="Rig", sway_angle=20.0,
              loop_frames=40.0, axis='X', composite_mode='REPLACE')

    scene.frame_set(10)
    r = read_bone(pb)

    q1 = core.compute_sway_quaternion(scene.autosway_groups[0], 0, 10)
    q2 = core.compute_sway_quaternion(scene.autosway_groups[1], 0, 10)
    exp_onlyG2 = expected_deg(q2, (0, 0, 0))
    exp_overlay = expected_deg(q1 @ q2, (0, 0, 0))

    onlyG2_close = deg_close(r["euler_deg"], exp_onlyG2)
    is_overlay = deg_close(r["euler_deg"], exp_overlay)
    passed = onlyG2_close

    return json.dumps({
        "test": "5_replace_mode",
        "euler_deg": r["euler_deg"],
        "exp_onlyG2_deg": exp_onlyG2, "exp_overlay_deg": exp_overlay,
        "base": r["base_rot"], "has_multi": r["has_multi"],
        "onlyG2_close": onlyG2_close, "is_overlay": bool(is_overlay),
        "passed": bool(passed),
    }, ensure_ascii=False)


# =====================================================================
def main():
    autosway.register()
    for name, fn in [
        ("test_linked_dup_overlay", test_linked_dup_overlay),
        ("test_disable_overlay_group", test_disable_overlay_group),
        ("test_remove_overlay_group", test_remove_overlay_group),
        ("test_tilt_zero", test_tilt_zero),
        ("test_replace_mode", test_replace_mode),
    ]:
        try:
            reset_scene()
            print(fn())
        except Exception as e:
            import traceback
            print(json.dumps({"test": name, "error": str(e),
                              "traceback": traceback.format_exc()[-1500:],
                              "passed": False}, ensure_ascii=False))
    print("DONE")


if __name__ == "__main__":
    main()
