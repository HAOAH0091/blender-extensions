"""AutoSway — 核心算法

摆动公式计算 + 状态追踪 + depsgraph_update_post handler。

核心设计借鉴 Parallax Locker 的"检测变化 → 反推用户意图 → 重新注入"模式：
  1. 读取骨骼当前旋转值
  2. 与"基础旋转 + 上次摆动"对比，判断用户是否手动修改过
  3. 如果用户改了，反推出新的基础旋转
  4. 用当前帧号和参数计算新摆动值
  5. 组合写入：基础旋转 + 新摆动
  6. 更新追踪状态

v1.3.0 改动（倾斜轴 + 多组叠加/覆盖）：
  - 摆动从"写入单个欧拉分量"升级为"用四元数组合后写回欧拉"，
    以支持任意倾斜轴（主轴 + 两个倾斜角）的摆动。
  - 状态机改为"按骨骼聚合所有作用组的摆动"再统一写回（_process_aggregated_bone），
    以支持同一骨骼被多组叠加/覆盖管理。
"""

import bpy
import math
from mathutils import Vector, Quaternion, Euler
from bpy.app.handlers import persistent

from .constants import (
    ASWAY_KEY_BASE_ROT,
    ASWAY_KEY_LAST_SWAY,
    ASWAY_KEY_HAS_MULTI,
    COMPOSITE_MODE_REPLACE,
)
from .utils import (
    find_bone_in_scene,
    ensure_euler_rotation,
    clear_sway_props,
    compute_bone_depth,
    has_parent_child_in_group,
)


# ==================== 旋转比较阈值 ====================
# 四元数角度差的阈值（弧度）。欧拉往返有 float32 精度损失，
# 1e-6 太严格会导致反复判断"用户改动了"。用 1e-4 弧度（约 0.0057°）比较合理。
ROTATION_CHANGE_THRESHOLD = 1e-4


# ==================== 摆动公式 ====================

def compute_sway(group, bone_index, frame):
    """计算单根骨骼在当前帧的摆动角度（弧度）。

    公式：-角度 × sin(2π × (帧数 + 偏移 - 延迟) / 周期)
    其中角度 = 基础角度 + 递增角度 × 骨骼序号
         延迟 = 错帧量 × 骨骼序号

    Args:
        group: SwayGroup 实例
        bone_index: 骨骼在组内的序号（0-based）
        frame: 当前场景帧号

    Returns:
        float: 摆动角度（弧度）
    """
    angle_deg = group.sway_angle + group.incremental_angle * bone_index
    delay = group.staggered_frames * bone_index
    effective_frame = frame + group.offset_frame - delay

    loop = group.loop_frames
    if loop <= 0:
        return 0.0

    sway_deg = -angle_deg * math.sin(2 * math.pi * effective_frame / loop)
    return math.radians(sway_deg)


# ==================== 摆动轴向量（倾斜支持） ====================

def sway_axis_vector(group):
    """计算该组的摆动轴单位向量，支持倾斜角。

    基于所选主轴（X/Y/Z），再绕 Y 轴偏转 axis_tilt_y，得到摆动方向。
    倾斜角为 0 时，返回标准主轴（与旧版本行为完全一致）。

    注意：主轴为 Y 时绕 Y 倾斜不改变方向（Y 绕自身转），此时倾斜无效。

    Args:
        group: SwayGroup 实例

    Returns:
        mathutils.Vector: 单位向量，指向摆动轴的朝向
    """
    axis_vec = {
        'X': Vector((1.0, 0.0, 0.0)),
        'Y': Vector((0.0, 1.0, 0.0)),
        'Z': Vector((0.0, 0.0, 1.0)),
    }.get(group.axis, Vector((0.0, 0.0, 1.0)))

    # 倾斜角为 0 时直接返回主轴，避免引入不必要的浮点计算。
    # v1.3.1：只保留绕 Y 倾斜（绕 Z 已移除）。
    if abs(group.axis_tilt_y) < 1e-6:
        return axis_vec

    # 摆动轴 = 主轴向量 绕 Y 轴倾斜 axis_tilt_y。
    # 注意：主轴为 Y 时，绕 Y 倾斜不改变向量方向（Y 绕自身转），此时倾斜无效，
    # 会退化回主轴 Y。这是单自由度倾斜的几何必然。
    tilt = Quaternion((0.0, 1.0, 0.0), math.radians(group.axis_tilt_y))
    return (tilt @ axis_vec).normalized()


def compute_sway_quaternion(group, bone_index, frame):
    """计算单根骨骼在当前帧的摆动四元数。

    相比 compute_sway（返回单轴弧度），这个函数把倾斜轴和摆动幅度
    组合成一个四元数，可以直接参与最终旋转的四元数乘法。

    组合顺序约定（重要）：
      最终旋转 = 摆动四元数 ⊗ 基础姿态四元数  （即 q_sway @ q_base）
      这样当摆动轴是标准轴时，基础姿态的欧拉分量不受污染，
      与旧版本"单独写一个欧拉分量"的行为等价。

    Args:
        group: SwayGroup 实例
        bone_index: 骨骼在组内的序号（0-based）
        frame: 当前场景帧号

    Returns:
        mathutils.Quaternion: 摆动旋转四元数
    """
    sway_rad = compute_sway(group, bone_index, frame)
    if abs(sway_rad) < 1e-9:
        return Quaternion((1.0, 0.0, 0.0, 0.0))  # 单位四元数（无旋转）

    axis_n = sway_axis_vector(group)
    return Quaternion(axis_n, sway_rad)


# ==================== 基础姿态与旋转的四元数读写 ====================

def _base_rot_to_quaternion(base_rot):
    """把存储的 base_rot（Euler XYZ 三元组）转成四元数。

    兼容旧版本：旧版本只存单个轴的分量（float），
    新版本存 Euler XYZ 三元组。为兼容，这里对 float 做兼容处理。
    """
    if isinstance(base_rot, (int, float)):
        # 旧的单轴存储：包装成绕对应轴的欧拉。但缺省轴信息时无法还原，
        # 这里按"绕 X 轴"兜底，正常情况下不会被新代码触发。
        return Euler((float(base_rot), 0.0, 0.0), 'XYZ').to_quaternion()
    try:
        return Euler(tuple(base_rot), 'XYZ').to_quaternion()
    except (TypeError, ValueError):
        return Quaternion((1.0, 0.0, 0.0, 0.0))


def _quaternion_to_base_rot(q):
    """把基础姿态四元数转成可存储的 Euler XYZ 三元组。"""
    return tuple(q.to_euler('XYZ'))


# ==================== 链接复制体扫描 ====================

def _find_linked_armatures(scene, armature_name):
    """找到所有共享同一骨骼数据块的骨架物体名列表。

    扫描场景中所有 ARMATURE 类型的物体，data 指针相等即为链接复制体。
    Alt+D 复制共享数据块，Shift+D 复制创建独立数据块，天然区分。
    返回列表包含源骨架自身。

    Args:
        scene: 当前场景
        armature_name: 源骨架物体名

    Returns:
        list[str]: 所有链接复制体的物体名。源骨架不存在则返回空列表
    """
    armature = scene.objects.get(armature_name)
    if armature is None or armature.type != 'ARMATURE':
        return []

    data = armature.data
    return [obj.name for obj in scene.objects
            if obj.type == 'ARMATURE' and obj.data == data]


# ==================== 单骨骼处理（状态机核心） ====================

def _process_aggregated_bone(scene, bone_item, sway_quats, is_multi, armature_name=None):
    """按骨骼聚合完成后，统一反推基础姿态并写回。

    这是多组叠加/覆盖模式的核心写回函数。
    它接收该骨骼所有作用组的摆动四元数列表；
    在覆盖模式下，只保留最后一个（后组覆盖前组）；
    在叠加模式下，全部按顺序相乘。

    Args:
        sway_quats: list[Tuple[Quaternion, str]]，每项是 (摆动四元数, composite_mode)
        is_multi: bool，该骨骼是否被多个组共同管理（决定 HAS_MULTI 标记）
        armature_name: 可选，覆盖 bone_item.armature_name 的骨架查找名。
    """
    if armature_name is None:
        armature_name = bone_item.armature_name

    bone = find_bone_in_scene(scene, armature_name, bone_item.bone_name)
    if bone is None:
        return

    ensure_euler_rotation(bone)

    # 合并摆动贡献：叠加=全部相乘，覆盖=只取最后一个
    final_sway_q = Quaternion((1.0, 0.0, 0.0, 0.0))
    if sway_quats:
        for q, mode in sway_quats:
            if mode == COMPOSITE_MODE_REPLACE:
                final_sway_q = q  # 覆盖：后组替换前组
            else:
                final_sway_q = final_sway_q @ q  # 叠加：按序相乘

    # === 读取追踪状态 ===
    # 首次处理时不存在追踪属性，此时 base_rot = 当前旋转（纯基础，因尚无摆动注入）
    cur_q = bone.rotation_euler.to_quaternion()
    is_first_pass = ASWAY_KEY_BASE_ROT not in bone
    base_rot = bone.get(ASWAY_KEY_BASE_ROT, tuple(bone.rotation_euler[:]))
    last_sway = bone.get(ASWAY_KEY_LAST_SWAY, tuple((0.0, 0.0, 0.0)))
    stored_is_multi = bone.get(ASWAY_KEY_HAS_MULTI, False)

    base_q = _base_rot_to_quaternion(base_rot)

    # === 多组标记同步 ===
    # 骨骼的多组状态改变了：要么"首次进入聚合模式"，要么"从多组回到单组"。
    # 关键：基础姿态 base_rot 是"纯用户意图、不含摆动"，它在单组阶段已被正确维护。
    # 因此切换多组状态时**必须保留原 base_rot**，绝不能拿合成值 rotation_euler[:] 
    # 当基础——那会把上一组摆动烘焙进基础导致摆动翻倍（M2）。
    # 只有 base 从未建立（首次）时才从当前值初始化。
    if stored_is_multi != is_multi:
        bone[ASWAY_KEY_HAS_MULTI] = is_multi
        is_first_pass = True
        if ASWAY_KEY_BASE_ROT not in bone:
            # 首次建立基础：此时骨骼尚未被本系统注入过摆动（正常流程总是先存 base_rot
            # 再注入摆动），因此当前旋转 cur_q 就是纯基础姿态，应直接采用，不得剥离摆动。
            # 若在此处用 final_sway⁻¹ @ cur_q 剥离，会剥掉一个本不存在的摆动，
            # 把 base 污染成 final_sway⁻¹ @ cur_q（问题 A：依赖触发时序的健壮性缺陷）。
            base_q = cur_q
            base_rot = _quaternion_to_base_rot(base_q)
        # 若 base 已存在，保留原值（纯基础），不计入摆动。
        # 注意：是_first_pass=True 使下面的检测块必然跳过，故此处除设置 is_first_pass 外
        # 不需重置 last_sway（局部 last_sway 在跳过检测时不参与结果）。

    # === 第一步：检测用户是否修改了骨骼 ===
    # 用户改动检测必须基于"handler 上次离开时的状态快照"，即 last_sway_q @ base_q。
    # 原因：handler 每帧都会重新计算摆动（final_sway_q 随帧号变化），
    # 如果拿本帧 final_sway_q 当期望值，会导致每一帧的摆动变化都被误判为用户改动，
    # 从而污染基础姿态。上一帧写入的 last_sway_q 才是"无用户改动时骨骼应有的状态"。
    # 反推方向也要用 last_sway_q 的左乘逆（last_sway_q.inverted() @ cur_q），
    # 与写入约定 "sway @ base" 一致：当前姿态 = last_sway ⊗ 新基础 ⇒ 新基础 = last_sway⁻¹ ⊗ 当前姿态。
    if not is_first_pass and sway_quats:
        last_sway_q = _base_rot_to_quaternion(last_sway)
        expected_q = last_sway_q @ base_q
        if expected_q.rotation_difference(cur_q).angle > ROTATION_CHANGE_THRESHOLD:
            # 用户动了骨骼：新基础 = 上次摆动逆 ⊗ 当前姿态（左乘逆剥摆动）
            base_q = last_sway_q.inverted() @ cur_q
            base_rot = _quaternion_to_base_rot(base_q)

    # 持久化 base_rot（仅在值变化时写入，避免不必要的 depsgraph 触发）
    new_base_rot = _quaternion_to_base_rot(base_q)
    if _tuple_diff(bone.get(ASWAY_KEY_BASE_ROT, ()), new_base_rot):
        bone[ASWAY_KEY_BASE_ROT] = new_base_rot

    # === 第二步：组合写入 ===
    target_q = final_sway_q @ base_q
    if target_q.rotation_difference(cur_q).angle > ROTATION_CHANGE_THRESHOLD:
        bone.rotation_euler = target_q.to_euler('XYZ')

    # === 第三步：更新追踪状态 ===
    new_last = _quaternion_to_base_rot(final_sway_q)
    if _tuple_diff(bone.get(ASWAY_KEY_LAST_SWAY, ()), new_last):
        bone[ASWAY_KEY_LAST_SWAY] = new_last


def _tuple_diff(a, b):
    """比较两个可迭代浮点序列（欧拉三元组）是否有差异。

    容忍 float32 往返误差，用相对较大的阈值判断"是否真的变了"。
    """
    try:
        if len(a) != len(b):
            return True
        for x, y in zip(a, b):
            if abs(x - y) > 1e-4:
                return True
        return False
    except (TypeError, AttributeError):
        return True


# ==================== 摆动剥离 ====================

def strip_sway_from_bone(scene, armature_name, bone_name):
    """从单根骨骼上剥离摆动值，恢复纯基础旋转，并清除追踪属性。

    自动连锁剥离所有链接复制体上的同名骨骼。

    注意：v1.3.0 开始 base_rot 存 Euler XYZ 三元组（而非旧版的单轴 float）。
    剥离时直接把欧拉三元组写回 rotation_euler 即可。
    """
    linked = _find_linked_armatures(scene, armature_name)
    for arm_name in linked:
        bone = find_bone_in_scene(scene, arm_name, bone_name)
        if bone is None:
            continue

        base_rot = bone.get(ASWAY_KEY_BASE_ROT)

        if base_rot is not None:
            # base_rot 可能是三元组（新）或旧版单 float（旧存档兼容）
            if isinstance(base_rot, (int, float)):
                bone.rotation_euler = (float(base_rot), 0.0, 0.0)
            else:
                try:
                    bone.rotation_euler = tuple(base_rot)
                except (TypeError, ValueError):
                    pass

        clear_sway_props(bone)


def strip_sway_from_group(scene, group):
    """从组内所有骨骼上剥离摆动值。"""
    for bone_item in group.bones:
        strip_sway_from_bone(scene, bone_item.armature_name, bone_item.bone_name)


# ==================== Handler ====================

@persistent
def autosway_handler(scene):
    """depsgraph_update_post / frame_change_post 回调。

    遍历所有启用的摆动组，为每根骨骼计算并注入摆动。
    使用状态追踪区分"用户的改动"和"处理器自己的改动"。

    v1.3.0 多组聚合：如果一根骨骼被多个组管理（叠加/覆盖），
    先收集所有组的摆动贡献，再一次性写回，避免多个组各自反推基础姿态造成冲突。
    """
    try:
        groups = scene.autosway_groups
        if len(groups) == 0:
            return

        frame = scene.frame_current

        # 缓存链接复制体扫描结果（key: armature_name，value: 浅拷贝后的 list）
        linked_cache = {}

        # 收集每根骨骼的所有作用组摆动贡献
        # key: (bone_name, armature_name)，value: list[(Quaternion, composite_mode)]
        aggregated = {}

        # 记录哪些骨骼被多个组管理（用于决定单组/聚合路径）
        for group in groups:
            if not group.enabled:
                continue
            if len(group.bones) == 0:
                continue

            # 构建组内骨骼集合（每帧只构建一次，全组共用）
            group_bones_set = {(item.bone_name, item.armature_name) for item in group.bones}

            # 检测是否存在父子关系，决定使用深度还是列表序号
            use_depth = has_parent_child_in_group(scene, group_bones_set, group)

            for idx, bone_item in enumerate(group.bones):
                if use_depth:
                    bone_index = compute_bone_depth(scene, group_bones_set, bone_item)
                else:
                    bone_index = idx

                arm_name = bone_item.armature_name

                # 找到所有链接复制体（优先从缓存取）
                if arm_name not in linked_cache:
                    linked_cache[arm_name] = _find_linked_armatures(scene, arm_name)
                cached = linked_cache[arm_name]

                # 重组为以源骨架为首的列表，确保源骨架始终在首位。
                # _find_linked_armatures 恒包含源骨架自身，所以 arm_name 必然在 cached 里。
                linked = [arm_name] + [n for n in cached if n != arm_name]

                # 为每个链接复制体收集本组摆动贡献
                for arm_actual in linked:
                    bone_actual = find_bone_in_scene(scene, arm_actual, bone_item.bone_name)
                    if bone_actual is None:
                        continue
                    ensure_euler_rotation(bone_actual)
                    sway_q = compute_sway_quaternion(group, bone_index, frame)
                    key = (bone_item.bone_name, arm_actual)
                    if key not in aggregated:
                        aggregated[key] = []
                    aggregated[key].append((sway_q, group.composite_mode))

        # === 逐骨骼写回 ===
        # 对每根骨骼，根据管理它的组数决定是否走聚合路径。
        for key, sway_list in aggregated.items():
            bone_name, arm_name = key
            bone = find_bone_in_scene(scene, arm_name, bone_name)
            if bone is None:
                continue

            # 判断该骨骼是否被多个组管理：直接看 collected 的贡献条数。
            # len > 1 表示被多个组共同管理（叠加/覆盖）。这比全量扫描更准确，
            # 也正确处理链接复制体（aggregated 按实际骨架名构建）。
            is_multi = len(sway_list) > 1

            # 统一走聚合写回：单组（is_multi=False）和多组（is_multi=True）
            _process_aggregated_bone(scene, _bone_item_from_key(bone_name, arm_name),
                                     sway_list, is_multi, arm_name)

    except AttributeError:
        # 场景属性不可用（插件部分卸载等），静默跳过
        pass
    except Exception as e:
        import traceback
        print(f"[AutoSway] Handler 异常: {e}")
        traceback.print_exc()


def _bone_item_from_key(bone_name, arm_name):
    """构造一个轻量骨骼条目用于聚合写回。

    聚合写回只需要 bone_name + armature_name 来定位骨骼，因此构造一个
    轻量对象即可（不需要真实 PropertyGroup 实例）。
    """
    class _BoneItem:
        pass
    item = _BoneItem()
    item.bone_name = bone_name
    item.armature_name = arm_name
    return item


# ==================== Handler 注册/注销 ====================
# 注册两个 handler：
#   frame_change_post  → 帧变化后必定触发，负责时间驱动的摆动计算
#   depsgraph_update_post → 任何依赖变化时触发，负责检测用户手动旋转骨骼
# 两者共用同一个 autosway_handler 函数，该函数天然幂等，重复调用无副作用。

def register_handler():
    """注册 frame_change_post 和 depsgraph_update_post handler（防重复）。"""
    fc_handlers = bpy.app.handlers.frame_change_post
    if autosway_handler not in fc_handlers:
        fc_handlers.append(autosway_handler)

    dg_handlers = bpy.app.handlers.depsgraph_update_post
    if autosway_handler not in dg_handlers:
        dg_handlers.append(autosway_handler)


def unregister_handler():
    """注销两个 handler。"""
    for handler_list in (
        bpy.app.handlers.frame_change_post,
        bpy.app.handlers.depsgraph_update_post,
    ):
        while autosway_handler in handler_list:
            handler_list.remove(autosway_handler)


# ==================== 文件加载恢复 ====================

@persistent
def autosway_load_handler(dummy):
    """加载 .blend 文件后，如果场景中有摆动组，注册运行时 handler。"""
    scene = bpy.context.scene
    if hasattr(scene, "autosway_groups") and len(scene.autosway_groups) > 0:
        register_handler()


def register_load_handler():
    """注册 load_post handler。"""
    handlers = bpy.app.handlers.load_post
    if autosway_load_handler not in handlers:
        handlers.append(autosway_load_handler)


def unregister_load_handler():
    """注销 load_post handler。"""
    handlers = bpy.app.handlers.load_post
    while autosway_load_handler in handlers:
        handlers.remove(autosway_load_handler)
