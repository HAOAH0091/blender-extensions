"""边界：视口/handler 更新后的画面 vs **真正渲染（F12）**出来的画面是否一致？

风险：
  handler 挂在 depsgraph_update_post。**渲染**时会另建求值上下文，
  如果渲染前没有触发 handler（或触发顺序不同），渲染出来的图案可能与视口不一致。
  用户看到视口没问题、一按 F12 图案就错了 —— 这是最坑的类型。

判据：同一场景，用 render 出的图与 viewport 求值后的 UV 探针对比。
同时测：锁定态 / 解锁态 / 渲染动画序列。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
RES = 64


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-46s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    ns = 4
    h = 14.0          # 铺满画面：边缘不可见，像素均值只反映图案本身
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def render_uv(tag):
    """真渲染（F12 路径），返回解码 UV"""
    _seq[0] += 1
    p = os.path.join(HERE, "_rv_%s_%02d.png" % (tag, _seq[0]))
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def group_uv(ob, cam, cd):
    """不渲染，直接按「组的逻辑」算 UV（视口会看到的）"""
    if plock.is_patched(cd.name):
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            return np.array([(a.data[i].vector[0] / a.data[i].vector[2],
                              a.data[i].vector[1] / a.data[i].vector[2])
                             for i in range(len(a.data))])
    m = cam.matrix_world.inverted()
    nodes = plock._find_delta_nodes(cd.name)
    S, C = 1.0, (0.0, 0.0)
    if nodes is not None:
        S = nodes[0].inputs["Scale"].default_value
        C = tuple(nodes[1].inputs[1].default_value)[:2]
    return np.array([((lambda p: (p.x / p.z * S + C[0], p.y / p.z * S + C[1]))(
        m @ (ob.matrix_world @ v.co))) for v in ob.data.vertices])


print("=" * 84)
print("渲染路径（F12）与 handler 配合是否正确")
print("=" * 84)
print("判据说明：网格铺满画面（边缘不可见），所以渲染图的 UV 均值只反映图案本身。")
print("  锁定期间图案应冻结 ⇒ 移相机前后渲染图应相同。")

sc, cam, cd, ob = build()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_a = render_uv("lockA")

print("\n[1] 锁定期间移相机（不跑 handler 直接渲染）")
cam.location.x = 3.5
bpy.context.view_layer.update()
u_b = render_uv("lockB_nohandler")
d1 = float(np.abs(u_a - u_b).mean())
print("   渲染图差异 = %.6f" % d1)
chk("锁定期间图案冻结（渲染路径也吃到 patch）", d1 < 2e-3, "Δ=%.6f" % d1)

print("\n[2] 再跑 handler 后渲染（相机没动）")
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_c = render_uv("lockC_handler")
d2 = float(np.abs(u_b - u_c).mean())
print("   渲染图差异 = %.6f" % d2)
chk("handler 不改变已冻结的画面", d2 < 2e-3, "Δ=%.6f" % d2)

print("\n[3] 解锁：解锁瞬间渲染")
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
u_d = render_uv("unlock")
d3 = float(np.abs(u_c - u_d).mean())
print("   渲染图差异 = %.6f" % d3)
chk("解锁那一帧不跳（渲染路径）", d3 < 2e-3, "Δ=%.6f" % d3)

print("\n[4] 解锁后移相机：图案应滑动")
cam.location.x = 4.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_e = render_uv("after")
d4 = float(np.abs(u_d - u_e).mean())
print("   渲染图差异 = %.6f" % d4)
chk("解锁后图案滑动", d4 > 5e-3, "Δ=%.6f" % d4)

print("\n[5] 锁定 → 移相机 → 【完全不跑 handler】→ 解锁 → 渲染")
print("    （模拟：用户操作很快，handler 没来得及跑就点了解锁）")
sc2, cam2, cd2, ob2 = build()
plock.lock_group(sc2, cam2)
cam2.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc2)
bpy.context.view_layer.update()
u_f = render_uv("fast_locked")
cam2.location.x = 3.0
bpy.context.view_layer.update()          # 不跑 handler
plock.unlock_group(sc2, cam2)
bpy.context.view_layer.update()
u_g = render_uv("fast_unlocked")
u_h = render_uv("fast_unlocked2")
print("   解锁后连续两次渲染差异 = %.6f（应为 0，说明渲染稳定）"
      % float(np.abs(u_g - u_h).mean()))
chk("解锁后渲染稳定可重复", float(np.abs(u_g - u_h).mean()) < 1e-4)

print()
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("RENDER_VP_DONE")
