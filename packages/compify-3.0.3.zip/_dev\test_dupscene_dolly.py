"""验证：复制场景后 dolly 是否还会被施加两次

对照 = 同样操作但不复制场景。
判据：
  · 复制场景后相机位置应与不复制时相同（Δ < 1e-6）
  · 重置后两种情形都能把相机收回原位
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-50s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 2; h = 1.2
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name),
                             "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def run(dup):
    sc, cam, cd, ob = build()
    plock.lock_group(sc, cam)
    if dup:
        bpy.context.scene.name = "A"
        bpy.ops.scene.new(type="LINK_COPY")
        bpy.context.scene.name = "B"
        cam = bpy.data.objects.get("Cam")
    cd.lens = 85.0
    if dup:
        for nm in ("A", "B"):
            s = bpy.data.scenes[nm]
            for _ in range(2):
                bpy.context.view_layer.update()
                plock.parallax_lock_update_handler(s)
    else:
        for _ in range(2):
            bpy.context.view_layer.update()
            plock.parallax_lock_update_handler(sc)
    z = cam.location.z
    cur = bpy.context.scene
    r = plock.reset_group(cur, cam)
    return z, cam.location.z, r.get("message", "")[:40]


print("=" * 82)
print("复制场景后 dolly 是否被施加两次")
print("=" * 82)
z1, za1, m1 = run(False)
z2, za2, m2 = run(True)
print("  不复制场景：变焦 50->85 后 相机 z = %.4f（初始 8.0）" % z1)
print("  复制场景后：变焦 50->85 后 相机 z = %.4f" % z2)
print("  差 = %.6f" % (z2 - z1))
chk("复制场景不会让 dolly 推两次", abs(z2 - z1) < 1e-6, "Δz=%.6f" % (z2 - z1))
print()
print("  不复制场景：重置后 z = %.4f" % za1)
print("  复制场景后：重置后 z = %.4f" % za2)
chk("重置能把相机收回原位（不复制）", abs(za1 - 8.0) < 1e-6, "Δ=%.6f" % (za1 - 8.0))
chk("重置能把相机收回原位（复制场景）", abs(za2 - 8.0) < 1e-6, "Δ=%.6f" % (za2 - 8.0))

print()
print("=" * 82)
print("不复制场景的常规变焦行为不能被改坏")
print("=" * 82)
sc, cam, cd, ob = build()
plock.lock_group(sc, cam)
print("  锁定后 z = %.4f" % cam.location.z)
z_at = {}
for lens in (85.0, 50.0, 32.0, 50.0):
    cd.lens = lens
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    z_at[lens] = cam.location.z
    print("    lens=%-5.1f  z = %.4f" % (lens, cam.location.z))
# 判据：镜头回到锁定值(50)时，相机必须回到锁定位置(8.0)
chk("回到锁定焦距时相机回到原位", abs(z_at[50.0] - 8.0) < 1e-6,
    "z=%.6f" % z_at[50.0])
# 判据：长焦相机后移、广角相机前移（方向正确）
chk("变长焦时相机后移", z_at[85.0] > 8.0 + 1e-6, "z=%.4f" % z_at[85.0])
chk("变广角时相机前移", z_at[32.0] < 8.0 - 1e-6, "z=%.4f" % z_at[32.0])

print()
print("=" * 82)
print("带拖动时 dolly 与拖动的归因仍正确")
print("=" * 82)
sc, cam, cd, ob = build()
plock.lock_group(sc, cam)
cd.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
z_after_zoom = cam.location.z
try:
    _vw = plock.get_camera_view_matrix(cam)
    # 用户把网格拖近 0.5（先挪物体再让插件按视差语义适配）
    ob.location.z = -0.5
    bpy.context.view_layer.update()
    _vw = plock.get_camera_view_matrix(cam)
    ok = plock.apply_user_move(ob, cam, _vw)
    print("  变焦后 z = %.4f" % z_after_zoom)
    print("  拖动网格后 apply_user_move 返回:", ok)
except Exception as e:
    print("  拖动调用异常:", type(e).__name__, e)
chk("拖动后相机没被意外移动", abs(cam.location.z - z_after_zoom) < 1e-6,
    "Δz=%.6f" % (cam.location.z - z_after_zoom))

print()
print("=" * 82)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("DOLLY_DONE")
