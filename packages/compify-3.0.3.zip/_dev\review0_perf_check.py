"""复核 sub E 的 E-1：locked_objects 的名字兜底是否 O(N²)"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(n):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    # 极简网格（2x2），只测扫描开销
    for i in range(n):
        mesh = bpy.data.meshes.new("M%d" % i)
        mesh.from_pydata([(-.2,-.2,0),(.2,-.2,0),(.2,.2,0),(-.2,.2,0)], [], [(0,1,2,3)])
        mesh.update()
        ob = bpy.data.objects.new("G%03d" % i, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
    bpy.context.view_layer.update()
    return sc, cam, cd


def timeit(fn, reps=5):
    best = 1e9
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best * 1000.0


print("=" * 78)
print("E-1 复核：locked_objects 的耗时（含/不含名字兜底）")
print("=" * 78)
print("  %-8s %-22s %-22s %s" % ("对象数", "locked_objects(st) ms", "locked_objects(None) ms", "倍数"))
for n in (300, 1000, 3000):
    sc, cam, cd = build(n)
    r = plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    a = timeit(lambda: plock.locked_objects(sc, cd.name, st))
    b = timeit(lambda: plock.locked_objects(sc, cd.name, None))
    print("  %-8d %-22.2f %-22.2f %.1fx" % (n, a, b, a / max(b, 1e-9)))
    print("       （state 里记录的对象数 = %d，实际锁定 = %d）" % (
        len(st.get("objects") or []), len(plock.locked_objects(sc, cd.name, None))))

print()
print("=" * 78)
print("E-2 复核：相机静止时 handler 每帧耗时")
print("=" * 78)
print("  %-8s %s" % ("对象数", "handler 单帧 ms"))
for n in (200, 1000):
    sc, cam, cd = build(n)
    plock.lock_group(sc, cam)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)       # 预热
    bpy.context.view_layer.update()
    t0 = time.perf_counter()
    reps = 5
    for _ in range(reps):
        bpy.context.view_layer.update()
        plock.parallax_lock_update_handler(sc)
    dt = (time.perf_counter() - t0) / reps * 1000.0
    print("  %-8d %.2f" % (n, dt))
print("\nPERF_DONE")
