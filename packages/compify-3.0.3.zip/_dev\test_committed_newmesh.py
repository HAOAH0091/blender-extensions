"""回归：解锁「落实构图」后，新接入投影材质的网格必须与 A 同一构图层次

用户实测反馈（2026-10-19）：
  A 有投影材质 → 视差锁定 → 移相机 → 解锁（一切正常）；
  这时把 B 的材质换成和 A 同一个投影材质，
  B 呈现的是**未落实**的原始投射（= A 进入锁定前的状态），
  而不是锁定期间调整出来的构图。

★ 方案 D（C+k）的修法本质：
  构图落实的状态存在**投影组**里（UV = persp·S + C），不是每个网格的顶点上
  ⇒ 任何网格用了这个投影材质就自动共享同一份构图，**不需要任何补写/巡检**。
  （旧方案把状态逐顶点写在 mesh 属性上，所以新网格必须靠 handler 轮询补写。）

验证项
  1  B 一换材质就正确：UV == 「按锁定相机投射」，且不依赖 handler 补写
  2  A/B 接缝连续（判据有区分力：清掉 S/C 会错开）
  3  解锁后再移相机 → A/B 都滑动
  4  重锁 → B 图案不跳、锁定中冻结
  5  重置 → S/C 回恒等、旧逐顶点属性被清
"""
import bpy
import sys
import os
import math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
MU = __import__("mathutils")

P, F = [], []


def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-50s %s" % ("PASS" if cond else "FAIL", name, detail))


def uv_of(ob, cam, cd):
    """按投影组【当前】会给出的 UV"""
    if plock.is_patched(cd.name):
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            return np.array([(a.data[i].vector[0] / a.data[i].vector[2],
                              a.data[i].vector[1] / a.data[i].vector[2])
                             for i in range(len(a.data))])
    m = cam.matrix_world.inverted()
    nodes = plock._find_delta_nodes(cd.name)
    S, C = 1.0, (0.0, 0.0)
    if nodes is not None:
        S = nodes[0].inputs["Scale"].default_value
        C = tuple(nodes[1].inputs[1].default_value)[:2]
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x / p.z * S + C[0], p.y / p.z * S + C[1]))
    return np.array(out)


def persp_at(ob, cam_mw):
    m = cam_mw.inverted()
    return np.array([((lambda p: (p.x / p.z, p.y / p.z))(m @ (ob.matrix_world @ v.co)))
                     for v in ob.data.vertices])


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0)
    cam.rotation_euler = (0.0, 0.0, 0.0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def grid(name, x0, w):
        ns = 3
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 + 2 * w * ix / ns, -w + 2 * w * iy / ns, 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob

    A = grid("GridA", -2.4, 1.2)
    B = grid("GridB", 0.0, 1.2)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


def seam(ob, cam, cd):
    rows = []
    for i, v in enumerate(ob.data.vertices):
        w = ob.matrix_world @ v.co
        if abs(w.x) < 1e-6:
            rows.append((w.y, i))
    rows.sort()
    uv = uv_of(ob, cam, cd)
    return np.array([uv[i] for _, i in rows])


print("=" * 78)
print("解锁落实后，新接入投影材质的网格 B（方案 D：C+k）")
print("=" * 78)

sc, cam, cd, mat, A, B = build()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
r = plock.unlock_group(sc, cam)
print("\n  解锁:", r["message"])

# ★ 关键：换材质后**不跑 handler**，立刻检查（旧方案必须靠 handler 补写）
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()

ub = uv_of(B, cam, cd)
exp = persp_at(B, lock_mw)
chk("1 B 一换材质即正确（无需 handler 补写）",
    float(np.abs(ub - exp).max()) < 1e-6, "Δ=%.2e" % float(np.abs(ub - exp).max()))

sa = seam(A, cam, cd)
sb = seam(B, cam, cd)
gap = float(np.abs(sa - sb).max())
chk("2 A/B 接缝 UV 一致（同一构图层次）", gap < 1e-6, "最大差 %.8f" % gap)

# 判据区分力：把 S/C 复位（= 没落实）应当错开
nodes = plock._find_delta_nodes(cd.name)
_s_save = nodes[0].inputs["Scale"].default_value
_c_save = tuple(nodes[1].inputs[1].default_value)
plock.write_identity_delta(cd.name)
ns_ = seam(seam(B, cam, cd) * 0 + 1, cam, cd) if False else None
sb_plain = seam(B, cam, cd)
gap2 = float(np.abs(sa - sb_plain).max())
chk("2b 判据有区分力（清掉 S/C 后接缝错开）", gap2 > 1e-3, "错开 %.6f" % gap2)
plock.write_delta_params(cd.name, _s_save, _c_save[:2])
bpy.context.view_layer.update()

# 3 解锁后移相机 → A/B 都滑动
ua0, ub0 = uv_of(A, cam, cd), uv_of(B, cam, cd)
cam.location.x = 3.1
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
ua1, ub1 = uv_of(A, cam, cd), uv_of(B, cam, cd)
chk("3a A 图案滑动", float(np.abs(ua1 - ua0).max()) > 1e-3,
    "Δ=%.4f" % float(np.abs(ua1 - ua0).max()))
chk("3b B 图案滑动（同幅度）",
    abs(float(np.abs(ub1 - ub0).max()) - float(np.abs(ua1 - ua0).max())) < 1e-6,
    "A Δ=%.4f  B Δ=%.4f" % (float(np.abs(ua1 - ua0).max()),
                            float(np.abs(ub1 - ub0).max())))

# 4 重锁
ub_pre = uv_of(B, cam, cd)
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
ub_rl = uv_of(B, cam, cd)
chk("4a 重锁瞬间 B 图案不跳", float(np.abs(ub_rl - ub_pre).max()) < 1e-6,
    "Δ=%.2e" % float(np.abs(ub_rl - ub_pre).max()))
cam.location.x = 3.6
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
ub_rl2 = uv_of(B, cam, cd)
chk("4b 锁定中 B 图案冻结", float(np.abs(ub_rl2 - ub_rl).max()) < 1e-6,
    "Δ=%.2e" % float(np.abs(ub_rl2 - ub_rl).max()))

# 5 重置
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
nodes = plock._find_delta_nodes(cd.name)
S = nodes[0].inputs["Scale"].default_value if nodes else None
C = list(nodes[1].inputs[1].default_value)[:2] if nodes else None
chk("5a 重置回恒等（S=1, C=0）",
    nodes is not None and abs(S - 1.0) < 1e-9 and abs(C[0]) < 1e-9 and abs(C[1]) < 1e-9,
    "S=%s C=%s" % (S, C))
chk("5b 旧逐顶点属性已清除",
    A.data.attributes.get(plock.UV_DELTA_ATTR_LEGACY) is None
    and B.data.attributes.get(plock.UV_DELTA_ATTR_LEGACY) is None)

print()
print("=" * 78)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("NEWMESH_DONE")
