"""审查E-4：反复 锁定/解锁 200 次 —— 属性 / 节点组 / handler / 定时器 是否持续增长

同时量 RSS（Windows GetProcessMemoryInfo），看内存是否单调上升。
"""
import bpy, sys, os, time, ctypes, ctypes.wintypes
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


class PMC(ctypes.Structure):
    _fields_ = [("cb", ctypes.wintypes.DWORD), ("PageFaultCount", ctypes.wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


_psapi = ctypes.WinDLL("psapi.dll")


def rss_mb():
    pmc = PMC()
    pmc.cb = ctypes.sizeof(PMC)
    _psapi.GetProcessMemoryInfo(ctypes.windll.kernel32.GetCurrentProcess(),
                                ctypes.byref(pmc), pmc.cb)
    return pmc.WorkingSetSize / 1048576.0


NCAM = 3
NMESH = 3


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 12)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("ProjMat")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns, H = 3, 1.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    objs = []
    for i in range(NMESH):
        mesh = bpy.data.meshes.new("G%d" % i)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new("Grid%d" % i, mesh)
        sc.collection.objects.link(ob)
        ob.location = (i * 1.5 - 1.5, 0, 0)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        objs.append(ob)
    bpy.context.view_layer.update()
    return sc, cam, cd, objs


def snap(tag, objs):
    attrs = {}
    for o in objs:
        for a in o.data.attributes:
            attrs[a.name] = attrs.get(a.name, 0) + 1
    props = {}
    for o in objs:
        for k in o.keys():
            props[k] = props.get(k, 0) + 1
    print("%-10s attr=%-2d %-42s 对象自定义属性=%-2d 节点组=%-2d 材质=%-2d "
          "handler=%-2d timer=%-2d _proj=%-2d _base=%-2d _lastview=%-2d "
          "_popup_shown=%-2d _warned=%-2d RSS=%.1fMB" % (
              tag, len(attrs), str(sorted(attrs.items())), len(props),
              len(bpy.data.node_groups), len(bpy.data.materials),
              len(bpy.app.handlers.depsgraph_update_post),
              len(_timer_regs), len(plock._proj_cache), len(plock._base_cache),
              len(plock._last_view), len(plock._popup_shown),
              len(plock._backfill_warned), rss_mb()))


# 统计弹窗 timer 注册次数（headless 下 _popup_supported 为 False，先只统计真实注册）
_timer_regs = []


def _count_reg(fn, first_interval=0.0, persistent=False):
    _timer_regs.append(fn)
    return None


_orig_reg = bpy.app.timers.register
bpy.app.timers.register = _count_reg

sc, cam, cd, objs = build()
snap("初始", objs)

CYCLES = 200
t0 = time.perf_counter()
for i in range(CYCLES):
    cam.location.x += 0.02
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    plock.parallax_lock_update_handler(sc)
    plock.unlock_group(sc, cam)
print("%d 次 锁定+解锁 总耗时=%.1f ms 平均=%.2f ms/次" % (
    CYCLES, (time.perf_counter() - t0) * 1000.0, (time.perf_counter() - t0) * 1000.0 / CYCLES))
snap("200轮后", objs)

for i in range(200):
    plock.lock_group(sc, cam)
    plock.unlock_group(sc, cam)
snap("400轮后", objs)

# 只 unlock 不 reset：属性是否释放？
print("\n[BASE_ATTR / ORIG_ATTR 是否随解锁释放] 每网格 attr 名 = %s" % (
    [a.name for a in objs[0].data.attributes],))
plock.reset_group(sc, cam)
snap("reset后", objs)
