"""插桩：重锁时 delta 是否被并入 campos"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
MU = __import__("mathutils")

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

bpy.ops.mesh.primitive_cube_add(size=2, location=(-3.5, 8.0, 0.5))
ob = bpy.context.active_object
ob.name = "MK0"
ob.data.materials.clear(); ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()


def live():
    vi = plock.get_camera_view_matrix(cam).inverted()
    return np.array([((lambda p: (p.x/-p.z, p.y/-p.z))(vi @ (ob.matrix_world @ v.co)))
                     for v in ob.data.vertices])


def frozen():
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([(a.data[i].vector[0]/-a.data[i].vector[2],
                      a.data[i].vector[1]/-a.data[i].vector[2])
                     for i in range(len(a.data))])


def delta_attr():
    d = ob.data.attributes.get(plock.UV_DELTA_ATTR)
    if d is None or len(d.data) != len(ob.data.vertices):
        return None
    return np.array([(d.data[i].vector[0], d.data[i].vector[1]) for i in range(len(d.data))])


def shader_uv():
    if plock.is_patched(cd.name):
        f = frozen()
        return f
    l = live()
    d = delta_attr()
    return l if d is None else l + d


print("=" * 70)
plock.lock_group(sc, cam)
print("lock1: patched=%s UV[0]=%s" % (plock.is_patched(cd.name), np.round(shader_uv()[0], 5)))
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("移相机后 锁定中 UV[0]=%s" % np.round(shader_uv()[0], 5))

print("\nunlock:", plock.unlock_group(sc, cam)["message"])
bpy.context.view_layer.update()
print("  解锁后: patched=%s" % plock.is_patched(cd.name))
print("  live[0]=%s" % np.round(live()[0], 5))
print("  delta[0]=%s" % (None if delta_attr() is None else np.round(delta_attr()[0], 5)))
print("  shader UV[0]=%s" % np.round(shader_uv()[0], 5))

cam.location.x += 1.0
bpy.context.view_layer.update()
_st = plock.get_state(sc, cam)
print("\n  [debug] state.enabled =", None if not _st else _st.get("enabled"))
_before = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
print("\n再移相机 x+=1（解锁态）:")
# 手动跑一次 handler，看它会不会碰网格

print("  live[0]=%s" % np.round(live()[0], 5))
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
_after = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
print("  handler 后顶点世界坐标变化 max = %.6f %s" % (
    np.abs(_after-_before).max(),
    "【handler 仍在动网格】" if np.abs(_after-_before).max() > 1e-9 else "handler 没有动网格"))
print("  shader UV[0]=%s  ← 应随相机变" % np.round(shader_uv()[0], 5))
expect = shader_uv()

plock.lock_group(sc, cam)
bpy.context.view_layer.update()
print("\nrelock: patched=%s" % plock.is_patched(cd.name))
print("  campos[0]=%s" % (None if frozen() is None else np.round(
    [ob.data.attributes[plock._campos_attr_name(cd.name)].data[0].vector[i] for i in range(3)], 5)))
print("  delta: %s" % ("已清" if delta_attr() is None else np.round(delta_attr()[0], 5)))
got = shader_uv()
print("  重锁后 shader UV[0]=%s" % np.round(got[0], 5))
print("  重锁前 shader UV[0]=%s" % np.round(expect[0], 5))
print("  >>> 差 = %.8f  %s" % (np.abs(got-expect).max(),
      "不跳 ✓" if np.abs(got-expect).max() < 1e-6 else "跳 ✗"))
