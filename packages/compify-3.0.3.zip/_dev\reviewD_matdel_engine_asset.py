"""审查项 8 / 9 / 10：材质被删除后解锁、CYCLES 下冻结是否生效、
投影组被设为 asset / fake user 时解锁/重置是否残留补丁。

判据：异常是否冒出（真报告）+ UV 探针（EEVEE vs CYCLES 同场景对比）+ 组结构。
"""
import bpy
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
SCALE = 0.1


def scene(engine="BLENDER_EEVEE"):
    sc = C.reset(engine=engine)
    cam, cd = C.new_cam(sc)
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat, gn = C.probe_mat("Probe", grp, scale=SCALE)
    A = C.new_grid("A")
    A.data.materials.append(mat)
    C.uv_adjust_group(A, cd)
    bpy.context.view_layer.update()
    return sc, cam, cd, grp, mat, A


def uv_of(ob, tag, scale=SCALE):
    C.show(ob)
    uv, mask, sat = C.render_uv_masked(scale=scale, tag=tag)
    s = C.stats_masked(uv, mask)
    print("    %-14s x极差=%.4f y极差=%.4f 均值=(%+.3f,%+.3f) 钳位=%.1f%%"
          % (tag, s[0], s[1], s[3], s[4], sat * 100) if s else "    %-14s 空" % tag)
    return uv, mask


# ══════ 阶段 A（项8）：锁定期间把材质删掉，再解锁 ══════
print("\n=== A：锁定期间删材质（槽清空 + datablock 删除）再解锁 ===")
sc, cam, cd, grp, mat, A = scene()
print("  lock:", plock.lock_group(sc, cam)["message"][:40])
A.data.materials.clear()
bpy.data.materials.remove(mat)
cam.location.x += 2.0
bpy.context.view_layer.update()
err = None
try:
    r = plock.unlock_group(sc, cam)
    print("  解锁返回: success=%s msg=%s" % (r["success"], r["message"]))
except Exception as e:
    err = e
    print("  ★ 解锁抛异常: %r" % (e,))
err2 = None
try:
    r2 = plock.reset_group(sc, cam)
    print("  重置返回: %s" % (r2,))
except Exception as e:
    err2 = e
    print("  ★ 重置抛异常: %r" % (e,))
print("  组还在=%s PATCH_KEY 残留=%s" % (
    bpy.data.node_groups.get(plock.CAM_PROJECT_PREFIX + cd.name) is not None,
    (bpy.data.node_groups.get(plock.CAM_PROJECT_PREFIX + cd.name).get(plock.PATCH_KEY)
     if bpy.data.node_groups.get(plock.CAM_PROJECT_PREFIX + cd.name) else "组已无")))
C.report("A 删材质后解锁不抛异常", err is None, "%r" % (err,))
C.report("A 删材质后重置不抛异常", err2 is None, "%r" % (err2,))

# ══════ 阶段 B（项9）：CYCLES 下冻结是否同样生效 ══════
print("\n=== B：EEVEE vs CYCLES 同一锁定场景的 UV 场 ===")
sc, cam, cd, grp, mat, A = scene("BLENDER_EEVEE")
plock.lock_group(sc, cam)
print("  persp_source=%s" % C.persp_source(grp))
uvE, maskE = uv_of(A, "EEVEE 锁定")
sc.render.engine = "CYCLES"
sc.cycles.device = "CPU"
sc.cycles.samples = 8
sc.cycles.use_denoising = False
bpy.context.view_layer.update()
uvC, maskC = uv_of(A, "CYCLES 锁定")
d = float(np.abs(uvE - uvC).max()) if uvE.shape == uvC.shape else -1
d_mean = float(np.abs(uvE - uvC).mean())
print("  EEVEE/CYCLES 同场景 UV 最大差=%.4f 平均差=%.4f" % (d, d_mean))
C.report("B CYCLES 下冻结坐标同样生效", abs(d) < 0.05,
         "max|ΔUV|=%.4f（大 = Attribute 在 Cycles 没取到值）" % d)

# ══════ 阶段 C（项10）：asset + fake user，解锁/重置是否残留 ══════
print("\n=== C：投影组设为 asset + fake user，锁→解锁→重置 ===")
sc, cam, cd, grp, mat, A = scene()
try:
    grp.asset_mark()
    marked = grp.asset_data is not None
except Exception as e:
    marked = False
    print("  asset_mark 失败: %r" % (e,))
grp.use_fake_user = True
print("  锁定前: asset=%s fake_user=%s drivers=%d" % (
    marked, grp.use_fake_user, len(grp.animation_data.drivers if grp.animation_data else [])))
plock.lock_group(sc, cam)
print("  锁定中: drivers=%d（冻结会摘掉 lens/sensor/shift 的 driver）" % (
    len(grp.animation_data.drivers if grp.animation_data else [])))
plock.unlock_group(sc, cam)
n_drv = len(grp.animation_data.drivers if grp.animation_data else [])
print("  解锁后: drivers=%d PATCH_KEY=%s asset=%s fake_user=%s" % (
    n_drv, grp.get(plock.PATCH_KEY) is not None, grp.asset_data is not None, grp.use_fake_user))
plock.reset_group(sc, cam)
n_drv2 = len(grp.animation_data.drivers if grp.animation_data else [])
nodes = plock._find_delta_nodes(cd.name)
print("  重置后: drivers=%d PATCH_KEY=%s S/C=%s asset=%s fake_user=%s" % (
    n_drv2, grp.get(plock.PATCH_KEY) is not None,
    (nodes[0].inputs["Scale"].default_value, tuple(nodes[1].inputs[1].default_value)[:2])
    if nodes else None,
    grp.asset_data is not None, grp.use_fake_user))
print("  lens 节点上还有 driver = %s" % (
    any('Lens' in (getattr(n, 'label', '') or '') for n in grp.nodes)))
C.report("C 解锁后无补丁残留", grp.get(plock.PATCH_KEY) is None and n_drv == 4,
         "drivers=%d（应=4：lens/sensor/shiftX/shiftY）" % n_drv)
C.report("C asset / fake_user 未被破坏", grp.asset_data is not None and grp.use_fake_user,
         "asset=%s fake_user=%s" % (grp.asset_data is not None, grp.use_fake_user))

print("\nRD_MATEDEL_ENGINE_DONE")
