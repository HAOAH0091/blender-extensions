"""问题1 正确判据：变焦时 A（正常锁定）与 B（手换材质）行为是否一致"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_diag6"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cd)
scene.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
bpy.context.view_layer.update()
NG.ensure_camera_project_group(cam)

def make_grid(name, z, x, w=1.0):
    mesh = bpy.data.meshes.new(name)
    verts = [(x-w,-1,z),(x+w,-1,z),(x+w,1,z),(x-w,1,z)]
    mesh.from_pydata(verts, [], [(0,1,2,3)]); mesh.update()
    o = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(o)
    return o

def make_mat(name):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    return m

matP = make_mat("ProjMat")
objA = make_grid("GridA", 0.0, -1.2, w=0.8)   # A 用 UV Adjust 正常流程
objB = make_grid("GridB", 0.0,  1.2, w=0.8)   # B 只是手动换上同一材质
objA.data.materials.append(matP)
objB.data.materials.append(matP)              # ← 用户的操作
NG.create_uv_adjust_node_group(scene, cam, objA)

print("="*74)
print("【问题1】变焦判据")
print("  get_lock_targets        ->", [o.name for o in PL.get_lock_targets(scene, cam)])
print("  objects_using_projection->", [o.name for o in PL.objects_using_projection(cd.name)])
res = PL.lock_group(scene, cam)
print("  lock:", res.get("message"))
print("  locked ->", [o.name for o in res.get("locked", [])])
for o in (objA, objB):
    print("  %s: OBJ_CAM_KEY=%s  base=%s  campos=%s" % (
        o.name, o.get(PL.OBJ_CAM_KEY),
        o.data.attributes.get(PL.BASE_ATTR) is not None,
        PL._campos_is_valid(o, cd.name)))

def verts(o):
    return [tuple(round(x,6) for x in v.co) for v in o.data.vertices]

A0, B0 = verts(objA), verts(objB)
print("\n  变焦 50 -> 85mm（走完整 handler）：")
cd.lens = 85.0
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
A1, B1 = verts(objA), verts(objB)
dA = max(abs(p[i]-q[i]) for p,q in zip(A0,A1) for i in range(3))
dB = max(abs(p[i]-q[i]) for p,q in zip(B0,B1) for i in range(3))
print("    A 顶点最大变化: %.6f  (%s)" % (dA, "跟了=正常" if dA>1e-6 else "没跟"))
print("    B 顶点最大变化: %.6f  (%s)  <== 问题1 判据" % (dB, "跟了" if dB>1e-6 else "没跟=bug成立"))

# B 的图案是否被冻结（campos 在锁定后被相机变化影响吗）
cn = PL._campos_attr_name(cd.name)
a = objB.data.attributes.get(cn)
print("\n  B 的 campos 首顶点:", tuple(round(x,4) for x in a.data[0].vector) if a else None)
print("  （冻结=锁定时刻相机空间坐标，应恒定不变）")

# 再看：变焦后如果 B 不解锁，用户手动移动 B 会怎样
print("\n  用户手动移动 B（视差锁定本应拦下）：")
mB0 = objB.matrix_world.copy()
objB.location.x += 1.5
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
mB1 = objB.matrix_world.copy()
print("    B 位姿位移: %.4f  (%s)" % (
    (mB1.translation - mB0.translation).length,
    "被拦下=锁定生效" if (mB1.translation-mB0.translation).length < 1e-6 else "自由移动=锁定没生效"))

mA0 = objA.matrix_world.copy()
objA.location.x += 1.5
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
mA1 = objA.matrix_world.copy()
print("    A 位姿位移: %.4f  (%s)" % (
    (mA1.translation - mA0.translation).length,
    "被拦下=锁定生效" if (mA1.translation-mA0.translation).length < 1e-6 else "自由移动=锁定没生效"))
