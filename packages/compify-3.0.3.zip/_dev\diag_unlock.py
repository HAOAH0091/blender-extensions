"""复现新问题1：解锁后投影效果被破坏
+ 问题2：A 锁定→解锁→B 换同样材质，B 的投影 UV 坏
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_unlock"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    return scene, cam, cd

def make_mat(cd, name="ProjMat"):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    return m

def make_grid(name, x, z=0.0, w=0.8, ns=2):
    mesh = bpy.data.meshes.new(name)
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((x-w+2*w*ix/ns, -1+2*iy/ns, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    o = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(o)
    return o

def campos_state(obj, cdn):
    n = PL._campos_attr_name(cdn)
    a = obj.data.attributes.get(n)
    if a is None:
        return "缺失"
    return "存在 n=%d 首=%s" % (len(a.data),
        tuple(round(x,3) for x in a.data[0].vector) if len(a.data) else "-")

def proj_uv_ok(obj, cam, cdn):
    """投影 UV 是否有效：用材质链路算不现实，退而检查 campos 是否全零/缺失"""
    n = PL._campos_attr_name(cdn)
    a = obj.data.attributes.get(n)
    if a is None or len(a.data) == 0:
        return False
    vals = [tuple(a.data[i].vector) for i in range(len(a.data))]
    allzero = all(abs(v[0])<1e-9 and abs(v[1])<1e-9 and abs(v[2])<1e-9 for v in vals)
    return not allzero

# ══════ 问题1 ══════
print("="*78)
print("【新问题1】锁定 → 解锁 → 投影是否还在")
scene, cam, cd = build()
m = make_mat(cd)
A = make_grid("GridA", 0.0)
A.data.materials.append(m)
NG.create_uv_adjust_node_group(scene, cam, A)

print("  锁定前 campos:", campos_state(A, cd.name))
res = PL.lock_group(scene, cam)
print("  lock:", res.get("message"))
print("  锁定后 campos:", campos_state(A, cd.name))
print("  锁定后 A 属性列表:", [a.name for a in A.data.attributes])

res = PL.unlock_group(scene, cam)
print("\n  unlock:", res.get("message"))
print("  解锁后 campos:", campos_state(A, cd.name))
print("  解锁后 A 属性列表:", [a.name for a in A.data.attributes])
print("  >>> 投影可用:", proj_uv_ok(A, cam, cd.name))

# 解锁后跑几次 handler，看会不会被弄坏
for i in range(3):
    bpy.context.view_layer.update()
    PL.parallax_lock_update_handler(scene)
print("\n  解锁后跑 3 次 handler:")
print("    campos:", campos_state(A, cd.name))
print("    属性列表:", [a.name for a in A.data.attributes])
print("    >>> 投影可用:", proj_uv_ok(A, cam, cd.name))

# 移动相机再跑
cam.location = (1.0, 0, 5.0)
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
print("\n  解锁后移相机 + handler:")
print("    campos:", campos_state(A, cd.name))
print("    >>> 投影可用:", proj_uv_ok(A, cam, cd.name))

# ══════ 问题2 ══════
print("\n" + "="*78)
print("【新问题2】A 锁定→解锁→B 换同样材质，B 的投影 UV 是否正常")
scene, cam, cd = build()
m = make_mat(cd)
A = make_grid("GridA", 0.0)
A.data.materials.append(m)
NG.create_uv_adjust_node_group(scene, cam, A)
B = make_grid("GridB", 1.6)

print("  初始: A campos=%s | B campos=%s" % (campos_state(A, cd.name), campos_state(B, cd.name)))
print("  lock:", PL.lock_group(scene, cam).get("message"))
print("  锁定后: A campos=%s | B campos=%s" % (campos_state(A, cd.name), campos_state(B, cd.name)))
print("  unlock:", PL.unlock_group(scene, cam).get("message"))
print("  解锁后: A campos=%s | B campos=%s" % (campos_state(A, cd.name), campos_state(B, cd.name)))

# 现在 B 换同样材质
B.data.materials.clear()
B.data.materials.append(m)
print("\n  >>> B 换上同一投影材质后：")
print("    B campos:", campos_state(B, cd.name))
print("    B 属性列表:", [a.name for a in B.data.attributes])
print("    >>> B 投影可用:", proj_uv_ok(B, cam, cd.name))

# handler 会不会补
for i in range(3):
    bpy.context.view_layer.update()
    PL.parallax_lock_update_handler(scene)
print("\n    跑 3 次 handler 后：")
print("      B campos:", campos_state(B, cd.name))
print("      >>> B 投影可用:", proj_uv_ok(B, cam, cd.name))

# 再重新锁定会怎样
print("\n    重新锁定后：")
PL.lock_group(scene, cam)
print("      B campos:", campos_state(B, cd.name))
print("      >>> B 投影可用:", proj_uv_ok(B, cam, cd.name))
