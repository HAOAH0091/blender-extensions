"""决定性测试：C 方案（位姿跟手）走完整 handler，屏幕投影还保持不变吗？
如果 adapt_object 又从 base*drag 重算顶点，就会和「位姿已移动」重复计算。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_c"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]
from mathutils import Vector


def build(ns=3):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("M"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    mesh = bpy.data.meshes.new("G")
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-1+2*ix/ns, -1+2*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    obj = bpy.data.objects.new("GridA", mesh)
    scene.collection.objects.link(obj)
    obj.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    return scene, cam, cd, obj


def proj(cam, obj):
    v = PL.get_camera_view_matrix(cam)
    out = []
    for vv in obj.data.vertices:
        p = v @ (obj.matrix_world @ vv.co)
        z = -p.z
        out.append((p.x/z if z > 1e-6 else 0.0, p.y/z if z > 1e-6 else 0.0))
    return out


def psdstyle(obj, camera, view_now):
    if not PL.LAYER_MOVE_ENABLED:
        return False
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    M_lock = PL._read_matrix_key(obj)
    if M_lock is None:
        PL._write_matrix_key(obj, obj.matrix_world.copy()); return False
    M_cur = obj.matrix_world.copy()
    if PL._mat_close(M_cur, M_lock):
        return False
    view_inv = view_now.inverted()
    c_local = PL._mesh_center_local(obj)
    d_lock = PL._view_depth(view_inv, M_lock @ c_local)
    d_cur = PL._view_depth(view_inv, M_cur @ c_local)
    if d_lock <= PL.MIN_DEPTH or d_cur <= PL.MIN_DEPTH:
        return False
    obj[PL.DRAG_SCALE_KEY] = float(d_cur / d_lock)
    axis_w = view_now.to_3x3() @ Vector((0.0, 0.0, -1.0))
    M_new = M_lock.copy()
    M_new.translation = M_lock.translation + axis_w * (d_lock - d_cur)
    obj.matrix_world = M_new
    bpy.context.view_layer.update()
    return True


print("="*78)
print("C 方案走完整 handler：屏幕投影是否仍不变")
print("="*78)

for label, patched in [("A 现状（未打补丁）", False), ("C 位姿跟手", True)]:
    if patched:
        PL.apply_user_move = psdstyle
    scene, cam, cd, obj = build()
    PL.lock_group(scene, cam)
    M_lock = obj.matrix_world.copy()
    c_local = PL._mesh_center_local(obj)
    view = PL.get_camera_view_matrix(cam)
    d_lock = PL._view_depth(view.inverted(), M_lock @ c_local)
    axis_w = view.to_3x3() @ Vector((0, 0, -1))
    p0 = proj(cam, obj)

    print("\n--- %s ---" % label)
    print("  帧  鼠标拖  位姿移(距锁定)  跟手比    drag    屏幕最大变化")
    for f in range(8):
        step = 0.05 * (f + 1)
        Mtmp = M_lock.copy()
        Mtmp.translation = M_lock.translation + axis_w * step
        obj.matrix_world = Mtmp          # 用户拖到这
        bpy.context.view_layer.update()
        PL.parallax_lock_update_handler(scene)   # ← 完整 handler
        pose = (obj.matrix_world.translation - M_lock.translation).length
        drag = obj.get(PL.DRAG_SCALE_KEY)
        pf = proj(cam, obj)
        dp = max(max(abs(a[0]-b[0]), abs(a[1]-b[1])) for a, b in zip(p0, pf))
        print("  %2d  %+7.3f  %12.4f  %8.2f  %8.4f  %12.6f%s" %
              (f+1, step, pose, pose/step if step else 0, drag, dp,
               "  <== 投影跑偏!" if dp > 1e-3 else ""))
