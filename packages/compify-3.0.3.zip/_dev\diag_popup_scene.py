"""GUI 下真实场景验证：锁定期间给「带修改器」网格换投影材质 → 弹窗出现
截屏保存，供人工/视觉确认弹窗内容正确。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

SHOT = os.path.join(HERE, "_popup_shot.png")

# ⚠️ 启动时的 splash（欢迎屏）会盖住弹窗 —— 之前截图就被它挡过。
try:
    bpy.context.preferences.view.show_splash = False
except Exception:
    pass
state = {"phase": 0}


def _bye():
    """统一退出：先 flush 日志，再退出。避免 GUI 模式下 stdout 缓冲丢日志。"""
    try:
        print("  [bye]", flush=True)
        with open(os.path.join(HERE, "_ps_log.txt"), "a", encoding="utf-8") as f:
            f.write("  [bye]\n")
    except Exception:
        pass
    try:
        bpy.ops.wm.quit_blender()
        return None
    except Exception:
        # 最后兜底：用定时器强退，别再挂着
        try:
            bpy.app.timers.register(lambda: os._exit(0), first_interval=0.5)
        except Exception:
            pass
        return None


def log(*a):
    s = "  " + " ".join(str(x) for x in a)
    print(s, flush=True)
    try:
        with open(os.path.join(HERE, "_ps_log.txt"), "a", encoding="utf-8") as f:
            f.write(s + "\n")
    except Exception:
        pass


def setup():
    # ⚠️ GUI 下不能调 read_factory_settings：它会重置 screen/window，
    #    导致已注册的 timer 链断掉（实测 phase 0 之后就再没执行）。
    #    改为就地清空当前场景的对象。
    sc = bpy.context.scene
    for _ob in list(bpy.data.objects):
        bpy.data.objects.remove(_ob, do_unlink=True)
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0):
        ns = 3
        h = 1.5
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob

    A = mk("GridA", -3.5)
    B = mk("GridB", 0.0)
    C = mk("GridC", 3.5)
    D = mk("GridD", 7.0)
    # 让 D 与 C 共享同一份网格数据
    D.data = C.data
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B, C, D


def shot():
    """截整个窗口 —— ⚠️ 不能用 screenshot_area！
    弹窗（popup_menu）是**窗口级浮层**，不属于任何 area，
    screenshot_area 只会截到 3D 视口那块，弹窗根本不会被拍进去。"""
    try:
        bpy.ops.screen.screenshot(filepath=SHOT)
        log("截图已存（整窗）:", SHOT)
        return True
    except Exception as e:
        log("整窗截图失败:", type(e).__name__, e)
    try:
        area = None
        for a in bpy.context.window.screen.areas:
            if a.type == "VIEW_3D":
                area = a
                break
        with bpy.context.temp_override(area=area, window=bpy.context.window,
                                       screen=bpy.context.window.screen):
            bpy.ops.screen.screenshot_area(filepath=SHOT)
        log("回退到 area 截图:", SHOT)
        return True
    except Exception as e:
        log("截图失败:", type(e).__name__, e)
        return False


def step():
    p = state["phase"]
    state["phase"] += 1
    try:
        if p == 0:
            log("=== 1) 建场景：A 有投影材质，B 带修改器 ===")
            sc, cam, cd, mat, A, B, C, D = setup()
            state["ctx"] = (sc, cam, cd, mat, A, B, C, D)
            plock._backfill_warned.clear()
            plock._popup_shown.clear()
            plock._popup_queue.clear()
            B.modifiers.new("Subdiv", "SUBSURF")
            C.shape_key_add(name="K1", from_mix=False)
            log("B 修改器:", [m.type for m in B.modifiers])
            log("C 形态键:", len(C.data.shape_keys.key_blocks) if C.data.shape_keys else 0)
            log("D 与 C 共享网格:", D.data is C.data)
            plock.lock_group(sc, cam)
            log("已锁定")
            cam.location.x = 2.0
            bpy.context.view_layer.update()
            plock.parallax_lock_update_handler(sc)
            bpy.context.view_layer.update()
            log("相机已移动到 x=2")
            return 0.2
        if p == 1:
            sc, cam, cd, mat, A, B, C, D = state["ctx"]
            log("=== 2) 给 B/C/D 换上投影材质（应触发弹窗）===")
            for _o in (B, C, D):
                _o.data.materials.clear()
                _o.data.materials.append(mat)
            bpy.context.view_layer.update()
            plock.parallax_lock_update_handler(sc)
            log("队列:", plock._popup_queue)
            return 0.8
        if p == 2:
            log("=== 3) 截图确认弹窗已出现 ===")
            try:
                bpy.context.preferences.view.show_splash = False
            except Exception:
                pass
            shot()
            return 0.4
        if p == 3:
            log("=== 完成，退出 ===")
            log("POPUP_SHOT_DONE")
            return _bye()
    except Exception as e:
        import traceback
        traceback.print_exc()
        return _bye()
    return None


if bpy.app.background:
    log("!! background 模式，不测弹窗")
else:
    bpy.app.timers.register(step, first_interval=0.3)
