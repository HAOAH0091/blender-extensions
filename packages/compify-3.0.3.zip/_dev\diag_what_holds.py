"""决定性实验：锁定期间移相机，图案靠什么保持不动？
对比三种操作（横移 / 变焦 / 旋转）下：
  · 顶点世界坐标有没有变（几何是否被 adapt_object 变形）
  · frozen_uv（campos 的投影）是否恒定
  · live_uv（实时相机空间投影）是否恒定
判断：图案不变是靠 patch（frozen）还是靠几何变形（live 也恒定）
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0); cam.rotation_euler = (0.0, 0.0, 0.0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    mesh = bpy.data.meshes.new("G")
    ns = 2
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-2.0+4.0*ix/ns, -2.0+4.0*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def frozen_uv(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                      a.data[i].vector[1]/a.data[i].vector[2]) for i in range(len(a.data))])


def live_uv(cam, ob):
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


def world(ob):
    return np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])


def run_case(name, mutate):
    sc, cam, cd, ob = build()
    plock.lock_group(sc, cam)
    f0, l0, w0 = frozen_uv(ob, cd), live_uv(cam, ob), world(ob)
    print("\n=== %s ===" % name)
    print("  锁定瞬间: frozen[0]=%s live[0]=%s" % (np.round(f0[0],5), np.round(l0[0],5)))
    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    f1, l1, w1 = frozen_uv(ob, cd), live_uv(cam, ob), world(ob)
    print("  操作后:   frozen[0]=%s live[0]=%s" % (np.round(f1[0],5), np.round(l1[0],5)))
    print("  几何世界坐标变化 max = %.6f  %s" % (
        np.abs(w1-w0).max(), "【几何被变形】" if np.abs(w1-w0).max() > 1e-6 else "几何没动"))
    print("  frozen_uv 变化 = %.8f  (patch 是否让图案恒定)" % np.abs(f1-f0).max())
    print("  live_uv   变化 = %.8f  (几何变形是否让实时投影恒定)" % np.abs(l1-l0).max())
    d = f1 - l1
    print("  delta = frozen - live: 均值=%s  逐顶点极差=(%.6f, %.6f)" % (
        np.round(d.mean(axis=0), 5),
        d[:,0].max()-d[:,0].min(), d[:,1].max()-d[:,1].min()))
    return d


def move(cam, cd):
    cam.location.x = 2.0

def zoom(cam, cd):
    cd.lens = 85.0

def rot(cam, cd):
    cam.rotation_euler = (0.0, 0.0, math.radians(15))

def combo(cam, cd):
    cam.location.x = 1.5
    cd.lens = 85.0
    cam.rotation_euler = (0.0, 0.0, math.radians(10))


print("=" * 80)
print("锁定期间移相机：图案靠什么保持不动？")
print("=" * 80)
for nm, fn in [("横移 x+2", move), ("变焦 50→85", zoom),
               ("旋转 15°", rot), ("平移+变焦+旋转", combo)]:
    run_case(nm, fn)
