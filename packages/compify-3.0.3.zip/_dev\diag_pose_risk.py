"""位姿跟手带来的三个风险验证
1. 反复「锁定→拖→重置」是否指数累积（v2.7.4 修过的致命问题）
2. 拖动后子物体是否被一起带走
3. reset 后位姿与几何是否精确还原
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
MU = __import__("mathutils")


def build(with_child=False):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0); cam.rotation_euler = (0.0, 0.0, 0.0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    mesh = bpy.data.meshes.new("G")
    ns = 2
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-1+2*ix/ns, -1+2*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")

    child = None
    if with_child:
        cmesh = bpy.data.meshes.new("Child")
        cmesh.from_pydata([(0,0,2),(0.5,0,2),(0.5,0.5,2),(0,0.5,2)], [], [(0,1,2,3)])
        cmesh.update()
        child = bpy.data.objects.new("Child", cmesh)
        sc.collection.objects.link(child)
        child.parent = ob
        child.matrix_parent_inverse = ob.matrix_world.inverted()
    bpy.context.view_layer.update()
    return sc, cam, cd, ob, child


print("=" * 78)
print("风险1：反复「锁定→拖动→重置」是否指数累积")
print("=" * 78)
sc, cam, cd, ob, _ = build()
orig_verts = np.array([tuple(v.co) for v in ob.data.vertices])
orig_mat = ob.matrix_world.copy()
print("  初始: 位姿平移=%s  scale=%s" % (
    tuple(round(x,4) for x in orig_mat.translation),
    tuple(round(x,4) for x in orig_mat.to_scale())))
ok = True
for rnd in range(1, 6):
    plock.lock_group(sc, cam)
    ob.location = ob.location + MU.Vector((0, 0, 1.5))
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    if rnd == 1:
        print("    第%d轮拖动后: 位姿Z=%.4f  offset=%s" % (
            rnd, ob.matrix_world.translation.z, ob.get(plock.DRAG_OFFSET_KEY)))
    plock.reset_group(sc, cam)
    bpy.context.view_layer.update()
    cur_v = np.array([tuple(v.co) for v in ob.data.vertices])
    dv = np.abs(cur_v - orig_verts).max()
    dloc = (ob.matrix_world.translation - orig_mat.translation).length
    dscl = max(abs(a-b) for a, b in zip(ob.matrix_world.to_scale(), orig_mat.to_scale()))
    print("    第%d轮重置后: 顶点偏差=%.8f  位姿偏差=%.8f  scale偏差=%.8f  位姿Z=%+.4f" %
          (rnd, dv, dloc, dscl, ob.matrix_world.translation.z))
    if dv > 1e-6 or dloc > 1e-6 or dscl > 1e-6:
        ok = False
print("  >>> %s" % ("无累积，每次都精确还原" if ok else "【有累积/未还原】"))

print()
print("=" * 78)
print("风险2：拖动后子物体是否被一起带走")
print("=" * 78)
sc, cam, cd, ob, child = build(with_child=True)
c0 = child.matrix_world.translation.copy()
print("  拖动前: 父位姿Z=%.4f  子物体世界Z=%.4f" % (
    ob.matrix_world.translation.z, c0.z))
plock.lock_group(sc, cam)
ob.location = ob.location + MU.Vector((0, 0, 1.5))
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
c1 = child.matrix_world.translation.copy()
print("  拖动后: 父位姿Z=%.4f  子物体世界Z=%.4f" % (
    ob.matrix_world.translation.z, c1.z))
print("  >>> 子物体位移 %.4f  (%s)" % (
    (c1 - c0).length,
    "跟着走了" if (c1-c0).length > 1e-6 else "没动"))
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
c2 = child.matrix_world.translation.copy()
print("  重置后: 子物体世界Z=%.4f  偏差=%.8f" % (c2.z, (c2 - c0).length))

print()
print("=" * 78)
print("风险3：连拖多次后 reset 是否还原到最初")
print("=" * 78)
sc, cam, cd, ob, _ = build()
orig_verts = np.array([tuple(v.co) for v in ob.data.vertices])
orig_mat = ob.matrix_world.copy()
plock.lock_group(sc, cam)
for i in range(4):
    ob.location = ob.location + MU.Vector((0, 0, 0.4))
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    print("    拖%d: 位姿Z=%.4f offset=%s" % (
        i+1, ob.matrix_world.translation.z,
        (round(ob.get(plock.DRAG_OFFSET_KEY), 4))))
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
cur_v = np.array([tuple(v.co) for v in ob.data.vertices])
print("  重置后: 顶点偏差=%.8f  位姿偏差=%.8f  scale=%s" % (
    np.abs(cur_v - orig_verts).max(),
    (ob.matrix_world.translation - orig_mat.translation).length,
    tuple(round(x,4) for x in ob.matrix_world.to_scale())))
