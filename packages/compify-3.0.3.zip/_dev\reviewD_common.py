"""独立审查 D（材质与着色器节点组边界）共用 harness —— 只读产品代码，不改它。

加载方式与 _dev/test_ck_unlock_render.py 一致：importlib + 包名 compify_plock_dev。
判据一律走「UV 探针真渲染」：探针材质把投影组输出的 UV 直接当颜色渲染，
读回像素反算 UV（uv = pixel - 0.5，探针里 UV → u*1.0+0.5）。
"""
import bpy
import os
import sys
import math
import importlib.util
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
RES = 96


def load_plugin():
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
    mod = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = mod
    spec.loader.exec_module(mod)
    return (sys.modules[PKG + ".compify_parallax_lock"],
            sys.modules[PKG + ".node_groups"])


def reset(engine="BLENDER_EEVEE", res=RES):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = engine
    if engine == "CYCLES":
        sc.cycles.device = "CPU"
        sc.cycles.samples = 4
        sc.cycles.use_denoising = False
    else:
        try:
            sc.eevee.taa_render_samples = 1
        except Exception:
            pass
    sc.render.resolution_x = res
    sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.render.image_settings.color_depth = "16"   # 8-bit 会把 UV 钳位，读数被污染
    sc.view_settings.view_transform = "Standard"
    return sc


def new_cam(sc, loc=(0, 0, 5), rot=(0, 0, 0), lens=50.0):
    cd = bpy.data.cameras.new("Cam")
    cd.lens = lens
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = loc
    cam.rotation_euler = rot
    sc.camera = cam
    bpy.context.view_layer.update()
    return cam, cd


def new_grid(name, x0=0.0, shape="平面", ns=3, H=2.0, me=None):
    if me is not None:
        ob = bpy.data.objects.new(name, me)
        bpy.context.scene.collection.objects.link(ob)
        return ob
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            x = x0 + (-H + 2 * H * ix / ns)
            y = -H + 2 * H * iy / ns
            if shape == "平面":
                z = 0.0
            elif shape == "倾斜":
                z = 0.28 * x
            else:
                z = (iy - 1.5) * 0.5
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    me = bpy.data.meshes.new("G_" + name)
    me.from_pydata(verts, [], faces)
    me.update()
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    return ob


def probe_mat(name, grp, scale=1.0):
    """UV 探针材质：投影组输出 UV → 颜色 (u*scale+0.5, v*scale+0.5)。"""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = scale
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = scale
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    return mat, gn


def uv_adjust_group(ob, cam_data):
    """只为让 get_lock_targets 的 ① 检索源认得它（名字即身份）。"""
    nm = "UV Adjust | %s | %s" % (ob.data.name, cam_data.name)
    return bpy.data.node_groups.new(nm, "ShaderNodeTree")


_seq = [0]


def render_uv(scale=1.0, tag="x"):
    """渲染并把像素反算成 UV。返回 (h,w,2)。"""
    _seq[0] += 1
    p = os.path.join(HERE, "_rd_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    try:
        os.remove(p)
    except Exception:
        pass
    return (a - 0.5) / scale


def stats(uv):
    """UV 场统计：(x 极差, y 极差, 均值)。纯色 ⇒ 极差 0。"""
    x = uv[..., 0]
    y = uv[..., 1]
    return (float(x.max() - x.min()), float(y.max() - y.min()),
            float(x.mean()), float(y.mean()))


def render_uv_masked(scale=1.0, tag="m"):
    """渲染 UV 探针，用 alpha 掩膜只统计网格像素。返回 (uv, mask)。"""
    _seq[0] += 1
    sc = bpy.context.scene
    old_tr = sc.render.film_transparent
    sc.render.film_transparent = True
    p = os.path.join(HERE, "_rdm_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    sc.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4).copy()
    bpy.data.images.remove(im)
    sc.render.film_transparent = old_tr
    try:
        os.remove(p)
    except Exception:
        pass
    mask = a[..., 3] > 0.5
    rgb = a[..., :2]
    # 钳位像素占比：色彩落在 0 或 1 ⇒ UV 超出可表示范围，读数不可信，要报出来
    sat = float((((rgb <= 1e-4) | (rgb >= 1 - 1e-4)) & mask[..., None]).sum()) / max(1.0, float(mask.sum()) * 2)
    return (rgb - 0.5) / scale, mask, sat


def stats_masked(uv, mask):
    """只统计网格像素：返回 (x范围, y范围, 唯一值占比, 均值x, 均值y, 覆盖像素数)。"""
    if mask.sum() < 10:
        return None
    m = mask
    x = uv[..., 0][m]
    y = uv[..., 1][m]
    vals = np.round(np.stack([x, y], axis=1), 3)
    uniq = len({tuple(v) for v in vals})
    return (float(x.max() - x.min()), float(y.max() - y.min()),
            uniq / float(len(x)), float(x.mean()), float(y.mean()), int(m.sum()))


def only(objs):
    for o in objs:
        o.hide_render = True


def show(ob):
    for o in bpy.data.objects:
        if o.type == "MESH":
            o.hide_render = (o is not ob)
    bpy.context.view_layer.update()


def campos_ok(plock, ob, cam_data_name):
    a = ob.data.attributes.get(plock._campos_attr_name(cam_data_name))
    return a is not None and len(a.data) == len(ob.data.vertices)


def persp_source(grp):
    """透视链（Perspective 1 = SeparateXYZ）的输入被谁驱动 —— 冻结的硬判据。

    渲染像素受取景/裁剪影响（网格在屏幕上会移动），不能当冻结判据；
    这个结构事实才是「图案到底冻没冻」的真相。
    """
    cand = None
    for n in grp.nodes:
        if n.type in ("SEPXYZ", "SEPARATE_XYZ"):   # Blender 5.2 里是 'SEPXYZ'
            if n.label == "Perspective 1":
                cand = n
                break
            if cand is None:
                cand = n
    if cand is None:
        return "无 SeparateXYZ"
    lk = cand.inputs["Vector"].links
    if not lk:
        return "未连线"
    fn = lk[0].from_node
    return "%s [%s]" % (fn.name, fn.type)


def report(tag, ok, detail=""):
    print("  [%s] %-46s %s" % ("PASS" if ok else "FAIL", tag, detail))
    return ok
