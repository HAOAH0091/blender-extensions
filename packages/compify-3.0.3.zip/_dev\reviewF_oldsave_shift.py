"""审查 F-9：旧存档（state 里没有 locked_zoom_z / locked_shift）解锁时，
   若锁定期内改过 sensor_width 或 shift，落实施量只能退回「只看 lens」→ 仍会跳。
   （新版 lock_group 才写入这两个字段；旧 .blend 里没有。）
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 96
_seq = [0]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = sc.render.resolution_y = RES
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd); sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ"); comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission"); out = nt.nodes.new("ShaderNodeOutputMaterial")
    for ax in ("X", "Y"):
        m = nt.nodes.new("ShaderNodeMath"); m.operation = "MULTIPLY"; m.inputs[1].default_value = 0.25
        a = nt.nodes.new("ShaderNodeMath"); a.operation = "ADD"; a.inputs[1].default_value = 0.5
        nt.links.new(sep.outputs[ax], m.inputs[0]); nt.links.new(m.outputs["Value"], a.inputs[0])
        nt.links.new(a.outputs["Value"], comb.inputs[ax])
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns, H = 3, 2.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            x = -H + 2 * H * ix / ns
            verts.append((x, -H + 2 * H * iy / ns, 0.28 * x))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("G0"); mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid0", mesh); sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def uvarr():
    _seq[0] += 1
    p = os.path.join(HERE, "_rfz_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32); im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def run(old_save, mutate, tag):
    sc, cam, cd, ob = build()
    plock.lock_group(sc, cam)
    if old_save:
        groups = plock.load_groups(sc)
        st = groups["Cam"]
        for k in ("locked_zoom_z", "locked_shift"):
            st.pop(k, None)
        plock.save_groups(sc, groups)
        print("  %s：state 键 = %s" % (tag, sorted(plock.get_state(sc, cam).keys())))
    mutate(cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    u0 = uvarr()
    r = plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    u1 = uvarr()
    print("  %s：解锁瞬间 |ΔUV| 平均 = %.5f  (消息: %s)"
          % (tag, float(np.abs(u1 - u0).mean()), str(r.get("message"))[:60]))


print("=" * 84)
print("### 锁定期间改 sensor_width（36→24）后解锁")
run(False, lambda cd: setattr(cd, "sensor_width", 24.0), "新存档(有 locked_zoom_z)")
run(True, lambda cd: setattr(cd, "sensor_width", 24.0), "旧存档(无 locked_zoom_z)")
print("")
print("### 锁定期间改 shift_x（0→0.15）后解锁")
run(False, lambda cd: setattr(cd, "shift_x", 0.15), "新存档(有 locked_shift)")
run(True, lambda cd: setattr(cd, "shift_x", 0.15), "旧存档(无 locked_shift)")
print("RF_OLDSAVE_DONE")
