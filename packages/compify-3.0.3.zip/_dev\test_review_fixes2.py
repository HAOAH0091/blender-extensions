"""回归网（第二轮独立审查）：盯 R1 / R2 / R3 / R4 / R7 / R10 / R17 / R18。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL。
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]
MU = importlib.import_module("mathutils")

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-54s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene


def cam_at(sc, name="Cam", loc=(0.0, 0.0, 5.0), lens=50.0):
    cd = bpy.data.cameras.new(name); cd.lens = lens; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def planes(sc, cam, n, prefix="P", depth0=0.0):
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i in range(n):
        bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, depth0 - float(i)))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out


def lens_node(camname):
    nt = bpy.data.node_groups.get("Camera Project | " + camname)
    for n in (nt.nodes if nt else []):
        if n.type == "VALUE" and n.label == "Lens":
            return n
    return None


# ═══ R1 / R8：拖动后重置必须还原对象位姿；反复循环不得累积 ═══
print("=" * 68)
print("R1/R8  reset 还原对象位姿 + 反复循环不累积")
sc = fresh()
cam = cam_at(sc); sc.camera = cam
objs = planes(sc, cam, 3, "P")
tgt = objs[0]
v = plock.get_camera_view_matrix(cam)
axis = v.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
rows = []
for rd in range(3):
    plock.lock_group(sc, cam)
    tgt.location = tgt.location + axis * (-3.0)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    d_after_drag = (tuple(round(x, 4) for x in tgt.scale), float(tgt.get(plock.DRAG_SCALE_KEY, 1.0)))
    plock.reset_group(sc, cam)
    bpy.context.view_layer.update()
    rows.append((d_after_drag, tuple(round(x, 4) for x in tgt.scale),
                 tuple(round(x, 4) for x in tgt.location)))
    print("   第%d轮 拖动后 scale=%s drag=%.4f | reset 后 scale=%s loc=%s"
          % (rd + 1, d_after_drag[0], d_after_drag[1], rows[-1][1], rows[-1][2]))
chk("R1-a reset 后对象 scale = 1（位姿被还原）",
    all(abs(r[1][0] - 1.0) < 1e-6 for r in rows),
    str([r[1][0] for r in rows]))
chk("R1-b 反复 3 轮不累积（scale 恒定）",
    len({r[1][0] for r in rows}) == 1 and abs(rows[0][1][0] - 1.0) < 1e-6,
    "各轮 %s" % [r[1][0] for r in rows])
chk("R8-a k 只记一处：拖动不改变对象 scale",
    all(abs(r[0][0][0] - 1.0) < 1e-6 for r in rows),
    str([r[0][0][0] for r in rows]))

# ═══ R2：属性名不碰撞 ═══
print()
print("=" * 68)
print("R2  冻结坐标属性名不碰撞")
pairs = [("Cam.001", "Cam-001"),
         ("Cam_" + "A" * 25 + "_1", "Cam_" + "A" * 25 + "_2"),
         ("Camera.001", "Camera.002")]
for a, b in pairs:
    na, nb = plock._campos_attr_name(a), plock._campos_attr_name(b)
    print("   %-28s → %s" % (a, na))
    print("   %-28s → %s   %s" % (b, nb, "★碰撞" if na == nb else "ok"))
chk("R2-a 'Cam.001' 与 'Cam-001' 不碰撞",
    plock._campos_attr_name("Cam.001") != plock._campos_attr_name("Cam-001"))
chk("R2-b 长名截断后不碰撞",
    plock._campos_attr_name("Cam_" + "A" * 25 + "_1") !=
    plock._campos_attr_name("Cam_" + "A" * 25 + "_2"))

# ═══ R3：0 顶点网格不崩 ═══
print()
print("=" * 68)
print("R3  含 0 顶点网格不崩")
sc = fresh()
cam = cam_at(sc); sc.camera = cam
objs = planes(sc, cam, 2, "P")
me = bpy.data.meshes.new("EMPTYM")
empty = bpy.data.objects.new("EMPTYO", me)
sc.collection.objects.link(empty)
empty.data.materials.append(objs[0].data.materials[0])
bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock:", r.get("success"), "|", str(r.get("message"))[:70])
    chk("R3-a 不抛异常且锁定成功", bool(r.get("success")))
    chk("R3-b 空网格被记进 skipped（不是静默）",
        any(o.name == "EMPTYO" for o, _ in r.get("skipped", [])),
        str([(o.name, w) for o, w in r.get("skipped", [])]))
except Exception as e:
    chk("R3-a 不抛异常且锁定成功", False, "%s: %s" % (type(e).__name__, str(e)[:60]))

# ═══ R7：共享网格不得让图案静默错位 ═══
print()
print("=" * 68)
print("R7  共享网格：宁可不冻结，也不静默错位")
sc = fresh()
cam = cam_at(sc); sc.camera = cam
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("MS"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
o = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, 0.0))
SRC = bpy.context.active_object; SRC.name = "SRC"
SRC.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (SRC.data.name, cam.data.name), "ShaderNodeTree")
DUP = bpy.data.objects.new("DUP", SRC.data)      # 共享 mesh data
sc.collection.objects.link(DUP)
DUP.location = (4.0, 0.0, -2.0)
# 再放一个【可锁定】的独立网格 → 走"部分成功"路径（这才是 R7 真正危险的场景）
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(-4.0, 0.0, -1.0))
OK = bpy.context.active_object; OK.name = "OK"
OK.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (OK.data.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   lock:", r.get("success"), "| frozen =", r.get("frozen"))
print("   unsupported:", r.get("unsupported"))
chk("R7-a 检测到共享网格 → 不冻结（避免静默错位）",
    r.get("frozen") is False, "frozen=%s" % r.get("frozen"))
chk("R7-b 补丁未被打上（is_patched=False）",
    not plock.is_patched(cam.data.name), "is_patched=%s" % plock.is_patched(cam.data.name))
chk("R7-c 消息里报出了原因（用户看得见）",
    "冻结未启用" in str(r.get("message")), str(r.get("message"))[-60:])

# 反例：全部可冻结时，必须正常冻结
sc = fresh()
cam = cam_at(sc); sc.camera = cam
objs = planes(sc, cam, 2, "F")
r = plock.lock_group(sc, cam)
chk("R7-d 没有共享网格时正常冻结", r.get("frozen") is True and plock.is_patched(cam.data.name),
    "frozen=%s" % r.get("frozen"))

# ═══ R10：补丁节点被单删后，reset 仍要恢复 driver ═══
print()
print("=" * 68)
print("R10  补丁节点被删后 reset 仍恢复实时投影")
sc = fresh()
cam = cam_at(sc); sc.camera = cam
objs = planes(sc, cam, 2, "A")
plock.lock_group(sc, cam)
nt = bpy.data.node_groups.get("Camera Project | " + cam.data.name)
nt.nodes.remove(nt.nodes.get("compify_plock_attr"))     # 手动删补丁节点
r = plock.reset_group(sc, cam)
cam.data.lens = 170.0
bpy.context.view_layer.update()
ln = lens_node(cam.data.name)
chk("R10-a reset 后组内 Lens 恢复跟随相机",
    ln is not None and abs(ln.outputs["Value"].default_value - 170.0) < 1e-3,
    "Lens=%.2f" % (ln.outputs["Value"].default_value if ln else -1))

# ═══ R17：互斥迁移后旧相机 ref_depth 重算 ═══
print()
print("=" * 68)
print("R17  互斥迁移后旧相机 ref_depth 重算")
sc = fresh()
cA = cam_at(sc, "CamA"); sc.camera = cA
cB = cam_at(sc, "CamB")
grpA = ng.ensure_camera_project_group(cA, default_aspect=1.0)
grpB = ng.ensure_camera_project_group(cB, default_aspect=1.0)
mA = bpy.data.materials.new("MA"); mA.use_nodes = True
nA = mA.node_tree; nA.nodes.clear()
gA = nA.nodes.new("ShaderNodeGroup"); gA.node_tree = grpA
oA = nA.nodes.new("ShaderNodeOutputMaterial"); nA.links.new(gA.outputs["Vector"], oA.inputs["Surface"])
mB = bpy.data.materials.new("MB"); mB.use_nodes = True
nB = mB.node_tree; nB.nodes.clear()
gB = nB.nodes.new("ShaderNodeGroup"); gB.node_tree = grpB
oB = nB.nodes.new("ShaderNodeOutputMaterial"); nB.links.new(gB.outputs["Vector"], oB.inputs["Surface"])
for i, (z, useB) in enumerate([(0.0, False), (-2.0, True)]):
    bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, z))
    ob = bpy.context.active_object; ob.name = "P%d" % i
    ob.data.materials.append(mA)
    if useB:
        ob.data.materials.append(mB)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cA.data.name), "ShaderNodeTree")
    if useB:
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cB.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
plock.lock_group(sc, cA)
stA = plock.get_state(sc, cA)
d_before = stA["ref_depth"]
plock.lock_group(sc, cB)
stA = plock.get_state(sc, cA)
print("   锁 A ref=%.3f（P0=5,P1=7）→ 锁 B 抢走 P1 后 ref=%.3f" % (d_before, stA["ref_depth"]))
chk("R17-a 迁移后 ref_depth = 剩余成员最深（5.0）",
    abs(stA["ref_depth"] - 5.0) < 1e-3, "实际 %.3f" % stA["ref_depth"])

# ═══ R18：解锁清掉本相机的 _last_view 条目 ═══
print()
print("=" * 68)
print("R18  unlock 清 _last_view（key 口径一致）")
sc = fresh()
cam = cam_at(sc); sc.camera = cam
objs = planes(sc, cam, 2, "U")
plock._last_view.clear()
plock.lock_group(sc, cam)
plock.unlock_group(sc, cam)
chk("R18-a 解锁后本相机条目被清掉",
    (sc.as_pointer(), cam.data.name) not in plock._last_view,
    "残留 %d 条" % len(plock._last_view))

# ═══ R4：改数据名后重锁不被丢出锁定集 ═══
print()
print("=" * 68)
print("R4  改 mesh 数据名后重新锁定仍包含该网格")
sc = fresh()
cam = cam_at(sc); sc.camera = cam
objs = planes(sc, cam, 2, "P")
plock.lock_group(sc, cam)
objs[0].data.name = "RENAMED_DATA"          # ★ 改数据名
plock.unlock_group(sc, cam)
r = plock.lock_group(sc, cam)
names = sorted(o.name for o in r.get("locked", []))
print("   重锁后 locked =", names)
chk("R4-a 改数据名后重锁仍包含该网格（两个都在）",
    set(names) == {"P0", "P1"}, str(names))

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX2_DONE")
