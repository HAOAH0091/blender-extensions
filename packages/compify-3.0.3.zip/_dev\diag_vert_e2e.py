"""端到端验证：逐顶点 offset（PSD 顶点版）vs 当前全局比例
在 adapt_object 公式层面模拟，看深度误差、屏幕变化、形心位移。
"""
import bpy, sys, os, math
import numpy as np
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_e2e"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]
from mathutils import Vector


def build_tilted():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("M"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])

    mesh = bpy.data.meshes.new("Tilt")
    ns = 2
    verts, faces = [], []
    ang = math.radians(55)
    for iy in range(ns+1):
        for ix in range(ns+1):
            lx = -1 + 2*ix/ns
            ly = -1 + 2*iy/ns
            verts.append((lx, ly*math.cos(ang), ly*math.sin(ang)))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    obj = bpy.data.objects.new("TiltGrid", mesh)
    scene.collection.objects.link(obj)
    obj.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    return scene, cam, cd, obj


scene, cam, cd, obj = build_tilted()
PL.lock_group(scene, cam)
M_lock = obj.matrix_world.copy()
base = np.asarray(PL._read_base_attribute(obj), dtype=np.float64)
view = PL.get_camera_view_matrix(cam)
M_view_to_local = obj.matrix_world.inverted() @ view     # 相机空间 → 局部

print("="*84)
print("逐顶点 offset（PSD 顶点版）验证")
print("base (相机空间) =")
for i, (x, y, d) in enumerate(base):
    print("  顶点%d  x=%+.4f y=%+.4f  深度=%.4f" % (i, x, y, d))

OFFSET = 0.6      # 用户沿视线把物体推近/推远 0.6
print("\n用户拖动 offset = %.2f（所有顶点深度统一平移 %.2f）" % (OFFSET, OFFSET))

def cam_proj(x, y, d):
    return (x / d, y / d)

p0 = [cam_proj(*b) for b in base]
d0 = [b[2] for b in base]

# ── 现状：全局比例 k（按最远顶点定）──
d_min, d_max = min(d0), max(d0)
k_global = (d_min + OFFSET) / d_min
print("\n【现状】全局 k = (%.4f %+.2f)/%.4f = %.6f" % (d_min, OFFSET, d_min, k_global))
print("  顶点  原深度    期望深度   实际深度   深度误差   屏幕变化")
errs_g, dps_g = [], []
for i, (x, y, d) in enumerate(base):
    nd = d * k_global
    nxp, nyp = cam_proj(x*k_global, y*k_global, nd)
    err = nd - (d + OFFSET)
    dp = max(abs(nxp-p0[i][0]), abs(nyp-p0[i][1]))
    errs_g.append(abs(err)); dps_g.append(dp)
    print("   %d  %8.4f  %9.4f  %9.4f  %+9.4f  %11.8f" %
          (i, d, d+OFFSET, nd, err, dp))
print("  >>> 深度最大误差 %.6f   深度跨度 %.4f -> %.4f (变化 %+.2f%%)" % (
    max(errs_g), d_max-d_min, d_max*k_global-d_min*k_global,
    ((d_max*k_global-d_min*k_global)/(d_max-d_min)-1)*100))
print("  >>> 形心深度位移 %.4f  (期望 %.4f)" % (
    (sum(d*k_global for d in d0)/len(d0)) - (sum(d0)/len(d0)), OFFSET))

# ── 逐顶点 offset ──
print("\n【你的描述：逐顶点】每个顶点深度 = d + %.2f" % OFFSET)
print("  顶点  原深度    新深度    k_i       深度误差   屏幕变化")
errs_v, dps_v, kk = [], [], []
for i, (x, y, d) in enumerate(base):
    nd = d + OFFSET
    k_i = nd / d
    nxp, nyp = cam_proj(x*k_i, y*k_i, nd)
    err = nd - (d + OFFSET)
    dp = max(abs(nxp-p0[i][0]), abs(nyp-p0[i][1]))
    errs_v.append(abs(err)); dps_v.append(dp); kk.append(k_i)
    print("   %d  %8.4f  %8.4f  %9.6f  %+9.4f  %11.8f" %
          (i, d, nd, k_i, err, dp))
print("  >>> 深度最大误差 %.6f   深度跨度 %.4f -> %.4f (变化 %+.2f%%)" % (
    max(errs_v), d_max-d_min, (d_max+OFFSET)-(d_min+OFFSET), 0.0))
print("  >>> 形心深度位移 %.4f  (期望 %.4f)" % (
    (sum(d+OFFSET for d in d0)/len(d0)) - (sum(d0)/len(d0)), OFFSET))
print("  >>> 每个顶点 k_i 不同: %.6f ~ %.6f" % (min(kk), max(kk)))
