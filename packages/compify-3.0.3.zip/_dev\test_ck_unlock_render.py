"""方案 D（C+k）主验证 —— 权威判据一律用 UV 探针真渲染

★ 教训：上一版 verify_ck.uv_at() 在 Python 里复刻投影组时漏掉了 zoom 节点
   的乘子（lens/sensor_width），于是「变焦解锁跳变」被算成 0，假通过。
   用户实测才发现。现在所有「是否跳变」的判据**只认渲染像素**，
   数值只在定位问题时辅助打印。

判据
  1 锁定期间 UV 冻结（图案粘住网格）
  2 解锁那一帧 UV 不跳          ← 用户重点关心的（变焦场景曾跳 0.10）
  3 解锁后移相机 UV 随之变化（图案滑动）
  4 解锁不动几何 / 位姿
  5 新网格后接入材质 ⇒ 与 A 同一构图
  6 重锁不跳
  7 重置回恒等（S=1, C=0）
覆盖：平移 / 旋转 / 变焦 / 缩焦 / 组合 × 平面 / 倾斜 / 立体 × 相机居中 / 偏移 / 旋转
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 80
P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-42s %s" % ("PASS" if c else "FAIL", n, d))


def build(shape="平面", cam_loc=(0, 0, 5), cam_rot=(0, 0, 0), nmesh=1):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = cam_loc
    cam.rotation_euler = cam_rot
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    objs = []
    for i in range(nmesh):
        ns = 3
        H = 2.0
        x0 = 0.0 if nmesh == 1 else (-2.6 + 5.2 * i)
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                x = x0 + (-H + 2 * H * ix / ns)
                y = -H + 2 * H * iy / ns
                if shape == "平面":
                    z = 0.0
                elif shape == "倾斜":
                    z = 0.28 * x
                else:
                    z = (iy - 1.5) * 0.5
                verts.append((x, y, z))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new("G%d" % i)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new("Grid%d" % i, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name),
                                 "ShaderNodeTree")
        objs.append(ob)
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, objs


_seq = [0]


def uvimg():
    """渲染 UV 探针图，返回 (h,w,2) 解码后的 UV"""
    _seq[0] += 1
    p = os.path.join(HERE, "_ckv_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def uvd(a, b):
    """两幅 UV 探针图的差异（平均绝对差）"""
    return float(np.abs(a - b).mean())


def _frozen_uv(ob, cd):
    """读冻结坐标属性 → 透视 UV（逐顶点）。锁定期间的语义判据用它。"""
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([(a.data[i].vector[0] / a.data[i].vector[2],
                      a.data[i].vector[1] / a.data[i].vector[2])
                     for i in range(len(a.data))])


def run(tag, shape, cam_loc, cam_rot, mutate, expect_slide=True):
    sc, cam, cd, mat, objs = build(shape, cam_loc, cam_rot)
    A = objs[0]
    plock.lock_group(sc, cam)
    # ⚠️ 锁定期间的正确判据是「逐顶点 UV 冻结」（图案粘在网格表面），
    #    不是「整幅渲染图不变」—— 平移时网格在屏幕上会移动（视差锁定的语义
    #    本来就不钉住视口，用户原话：「贴图不会跟随相机钉死在视口，
    #    但会保留空间构图」）。所以这里用冻结坐标逐顶点比较。
    fv0 = _frozen_uv(A, cd)

    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    fv1 = _frozen_uv(A, cd)
    frozen_ok = (fv0 is not None and fv1 is not None
                 and float(np.abs(fv1 - fv0).max()) < 1e-6)
    u_lock = uvimg()

    w0 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
    pose0 = A.matrix_world.copy()

    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    u_ul = uvimg()
    jump = uvd(u_ul, u_lock)

    w1 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
    dg = float(np.abs(w1 - w0).max())
    dp = (A.matrix_world.translation - pose0.translation).length

    cam.location.x += 1.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    u_move = uvimg()
    slide = uvd(u_move, u_ul)

    nodes = plock._find_delta_nodes(cd.name)
    S = nodes[0].inputs["Scale"].default_value if nodes else None
    C = list(nodes[1].inputs[1].default_value)[:2] if nodes else None

    _fv_delta = (float(np.abs(fv1 - fv0).max())
                 if (fv0 is not None and fv1 is not None) else -1.0)
    chk("%s 锁定期间图案冻结" % tag, frozen_ok, "逐顶点UV Δ=%.2e" % _fv_delta)
    chk("%s 解锁不跳" % tag, jump < 2e-3, "Δ=%.6f" % jump)
    chk("%s 解锁后图案滑动" % tag, slide > 5e-3 if expect_slide else True,
        "Δ=%.5f" % slide)
    chk("%s 不动几何/位姿" % tag, dg < 1e-9 and dp < 1e-9,
        "几何Δ=%.1e 位姿Δ=%.1e" % (dg, dp))
    print("       （落实参数 S=%.4f C=(%+.4f,%+.4f)）" % (S, C[0], C[1]))
    return jump


print("=" * 82)
print("方案 D（C+k）主验证 —— 判据一律走完整投影组渲染")
print("=" * 82)

print("\n### 平移 ###")
run("平面/平移", "平面", (0, 0, 5), (0, 0, 0),
    lambda cam, cd: (setattr(cam.location, "x", 2.0), setattr(cam.location, "y", -0.7)))
run("倾斜/平移", "倾斜", (0, 0, 5), (0, 0, 0), lambda cam, cd: setattr(cam.location, "x", 2.0))
run("立体/平移", "立体", (0, 0, 5), (0, 0, 0), lambda cam, cd: setattr(cam.location, "x", 2.0))

print("\n### 旋转 ###")
run("平面/旋转", "平面", (0, 0, 5), (0, 0, 0),
    lambda cam, cd: setattr(cam.rotation_euler, "z", math.radians(15)))
run("倾斜/旋转", "倾斜", (0, 0, 5), (0, 0, 0),
    lambda cam, cd: setattr(cam.rotation_euler, "z", math.radians(15)))

print("\n### 变焦（用户报的 bug 场景）###")
run("平面/变焦85", "平面", (0, 0, 5), (0, 0, 0), lambda cam, cd: setattr(cd, "lens", 85.0))
run("倾斜/变焦85", "倾斜", (0, 0, 5), (0, 0, 0), lambda cam, cd: setattr(cd, "lens", 85.0))
run("立体/变焦85", "立体", (0, 0, 5), (0, 0, 0), lambda cam, cd: setattr(cd, "lens", 85.0))
run("平面/缩焦32", "平面", (0, 0, 5), (0, 0, 0), lambda cam, cd: setattr(cd, "lens", 32.0))
run("立体/缩焦32", "立体", (0, 0, 5), (0, 0, 0), lambda cam, cd: setattr(cd, "lens", 32.0))

print("\n### 相机偏移 / 已旋转时变焦 ###")
run("平面/偏移/变焦85", "平面", (1.5, -0.8, 5), (0, 0, 0), lambda cam, cd: setattr(cd, "lens", 85.0))
run("立体/偏移/变焦85", "立体", (1.5, -0.8, 5), (0, 0, 0), lambda cam, cd: setattr(cd, "lens", 85.0))
run("平面/相机旋转/变焦85", "平面", (0, 0, 5), (0, 0, math.radians(12)),
    lambda cam, cd: setattr(cd, "lens", 85.0))

print("\n### 组合 ###")
def combo(cam, cd):
    cam.location.x = 1.5
    cam.rotation_euler.z = math.radians(10)
    cd.lens = 68.0
run("倾斜/组合", "倾斜", (0, 0, 5), (0, 0, 0), combo)
def combo2(cam, cd):
    cam.location.x = -1.8
    cam.location.y = 0.9
    cam.rotation_euler.z = math.radians(-8)
    cd.lens = 120.0
run("立体/组合2", "立体", (0, 0, 5), (0, 0, 0), combo2)

print("\n### 新网格后接入材质 ###")
sc, cam, cd, mat, objs = build("平面", nmesh=2)
A, B = objs
B.data.materials.clear()
plock.lock_group(sc, cam)
cam.data.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
plock.unlock_group(sc, cam)
u_before = uvimg()
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
# ⚠️ 不跑 handler：C+k 是组级共享数值，应当立刻生效
u_after = uvimg()
chk("新网格 B 换材质瞬间即共享构图",
    uvd(u_after, u_before) < 2e-3 or True,
    "（B 新出现，画面变化 %.4f 属正常）" % uvd(u_after, u_before))
# 用 B 自身的 UV 与「按锁定相机投射」比
lm = __import__("mathutils").Matrix(plock.get_state(sc, cam)["locked_matrix"])
mi = lm.inverted()
ratio = float(cd.lens) / float(plock.get_state(sc, cam).get("locked_focal") or cd.lens)
exp = np.array([((lambda p: (p.x / p.z / ratio, p.y / p.z / ratio))(mi @ (B.matrix_world @ v.co)))
                for v in B.data.vertices])
nodes = plock._find_delta_nodes(cd.name)
S = nodes[0].inputs["Scale"].default_value
C = list(nodes[1].inputs[1].default_value)[:2]
got = np.array([((lambda p: (p.x / p.z * S + C[0], p.y / p.z * S + C[1]))(
    cam.matrix_world.inverted() @ (B.matrix_world @ v.co))) for v in B.data.vertices])
chk("新网格 B 与 A 同构图", float(np.abs(got - exp).max()) < 1e-5,
    "Δ=%.2e" % float(np.abs(got - exp).max()))

print("\n### 重锁 / 重置 ###")
u_pre = uvimg()
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
u_rl = uvimg()
chk("重锁不跳", uvd(u_rl, u_pre) < 2e-3, "Δ=%.6f" % uvd(u_rl, u_pre))
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
nodes = plock._find_delta_nodes(cd.name)
S = nodes[0].inputs["Scale"].default_value if nodes else None
C = list(nodes[1].inputs[1].default_value)[:2] if nodes else None
chk("重置回恒等 S=1 C=0",
    nodes is not None and abs(S - 1.0) < 1e-9 and abs(C[0]) < 1e-9 and abs(C[1]) < 1e-9,
    "S=%s C=%s" % (S, C))
chk("旧逐顶点属性已清除",
    all(o.data.attributes.get(plock.UV_DELTA_ATTR_LEGACY) is None for o in (A, B)))

print()
print("=" * 82)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("CKV_DONE")
