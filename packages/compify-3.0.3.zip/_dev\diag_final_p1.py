"""问题1 最终验证：同深度的 A（走 UV Adjust）与 B（手动换材质）
两者应表现完全一致。判据：
  ① 都进 locked
  ② 都有 base / campos
  ③ 手动移动都被拦下
  ④ 移相机后的屏幕投影变化一致（都保持）
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_final1"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cd)
scene.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
bpy.context.view_layer.update()
NG.ensure_camera_project_group(cam)

def make_grid(name, x, z=0.0, w=0.8, ns=2):
    mesh = bpy.data.meshes.new(name)
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((x-w+2*w*ix/ns, -1+2*iy/ns, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    o = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(o)
    return o

m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
nt = m.node_tree
for n in list(nt.nodes): nt.nodes.remove(n)
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
o2 = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o2.inputs[0])

A = make_grid("GridA", -1.2)     # 走 UV Adjust
B = make_grid("GridB",  1.2)     # 手动换材质
A.data.materials.append(m)
B.data.materials.append(m)
NG.create_uv_adjust_node_group(scene, cam, A)

print("="*72)
print("同深度 A(UV Adjust) vs B(手动换材质)")
print("  get_lock_targets ->", [o.name for o in PL.get_lock_targets(scene, cam)])
res = PL.lock_group(scene, cam)
print("  lock:", res.get("message"))
locked = res.get("locked", [])
print("  locked ->", [o.name for o in locked])
print()
for o in (A, B):
    print("  %s: 在locked=%s  OBJ_CAM_KEY=%s  base=%s  campos=%s" % (
        o.name, o in locked, o.get(PL.OBJ_CAM_KEY),
        o.data.attributes.get(PL.BASE_ATTR) is not None,
        PL._campos_is_valid(o, cd.name)))

def proj(cam, o):
    v = PL.get_camera_view_matrix(cam)
    out = []
    for vv in o.data.vertices:
        p = v @ (o.matrix_world @ vv.co)
        z = -p.z
        out.append((p.x/z if z > 1e-6 else 0, p.y/z if z > 1e-6 else 0))
    return out

pA0, pB0 = proj(cam, A), proj(cam, B)

print("\n  手动移动 B 1.5（应被拦下）：")
mB = B.matrix_world.copy(); B.location.x += 1.5
bpy.context.view_layer.update(); PL.parallax_lock_update_handler(scene)
print("    B 位姿位移 %.4f  (%s)" % ((B.matrix_world.translation-mB.translation).length,
      "被拦下" if (B.matrix_world.translation-mB.translation).length < 1e-6 else "自由移动=bug"))

print("\n  移相机 x+1.0，屏幕投影应保持不变：")
cam.location = (1.0, 0.0, 5.0)
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
pA1, pB1 = proj(cam, A), proj(cam, B)
dA = max(max(abs(a[0]-b[0]), abs(a[1]-b[1])) for a, b in zip(pA0, pA1))
dB = max(max(abs(a[0]-b[0]), abs(a[1]-b[1])) for a, b in zip(pB0, pB1))
print("    A 屏幕投影最大变化 %.8f" % dA)
print("    B 屏幕投影最大变化 %.8f" % dB)
print("    >>> 两者一致(差 < 1e-6): %s" % ("是" if abs(dA-dB) < 1e-6 else "否"))
print("    >>> 都保持(均 < 1e-3): %s" % ("是" if max(dA,dB) < 1e-3 else "否"))
