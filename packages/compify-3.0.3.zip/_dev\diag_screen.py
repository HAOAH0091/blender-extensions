"""检查锁定期间网格的【屏幕位置】是否冻结
对比：首次锁定 vs 重锁（解锁后再锁）
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def setup():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    Ns = 4; H = 12.0
    verts, faces = [], []
    for iy in range(Ns+1):
        for ix in range(Ns+1):
            verts.append((-H + 2*H*ix/Ns, -H + 2*H*iy/Ns, 0.0))
    for iy in range(Ns):
        for ix in range(Ns):
            a = iy*(Ns+1)+ix
            faces.append((a, a+1, a+Ns+2, a+Ns+1))
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def screen(cam, ob):
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        d = p.z
        out.append((p.x/d, p.y/d))
    return np.array(out)


def uv_frozen(cam, ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                      a.data[i].vector[1]/a.data[i].vector[2])
                     for i in range(len(a.data))])


print("=" * 70)
print("首次锁定：相机 x=0 → x=2，屏幕位置是否冻结")
print("=" * 70)
sc, cam, cd, ob = setup()
plock.lock_group(sc, cam)
s0 = screen(cam, ob); f0 = uv_frozen(cam, ob, cd)
print("  锁定后 屏幕[0]=%s 冻结UV[0]=%s" % (np.round(s0[0],4), np.round(f0[0],4)))
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s1 = screen(cam, ob); f1 = uv_frozen(cam, ob, cd)
print("  移相机 屏幕[0]=%s 冻结UV[0]=%s" % (np.round(s1[0],4), np.round(f1[0],4)))
print("  屏幕位置变化 max=%.6f  %s" % (
    np.abs(s1-s0).max(), "冻结✓" if np.abs(s1-s0).max() < 1e-5 else "【网格在屏幕上动了】"))
print("  冻结UV 变化 max=%.8f" % np.abs(f1-f0).max())

print()
print("=" * 70)
print("解锁 → 移相机 → 重锁 → 再移相机：屏幕位置是否冻结")
print("=" * 70)
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
cam.location.x = 3.0
bpy.context.view_layer.update()
print("  已解锁并移到 x=3")
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
s2 = screen(cam, ob); f2 = uv_frozen(cam, ob, cd)
print("  重锁后 屏幕[0]=%s 冻结UV[0]=%s" % (np.round(s2[0],4), np.round(f2[0],4)))
cam.location.x = 3.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s3 = screen(cam, ob); f3 = uv_frozen(cam, ob, cd)
print("  再移相机 屏幕[0]=%s 冻结UV[0]=%s" % (np.round(s3[0],4), np.round(f3[0],4)))
print("  屏幕位置变化 max=%.6f  %s" % (
    np.abs(s3-s2).max(), "冻结✓" if np.abs(s3-s2).max() < 1e-5 else "【网格在屏幕上动了】"))
print("  冻结UV 变化 max=%.8f" % np.abs(f3-f2).max())
print("  DRAG_OFFSET=%s  ref_depth=%s" % (
    ob.get(plock.DRAG_OFFSET_KEY), plock.get_state(sc, cam).get("ref_depth") if plock.get_state(sc, cam) else None))
print("SCREEN_DONE")
