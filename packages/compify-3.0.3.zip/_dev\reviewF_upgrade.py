"""审查 F-1：旧工程升级（投影组没有 S/C 节点）+ 旧逐顶点属性 compify_plock_uv_delta

判据一律用「完整投影组 UV 探针」真渲染像素，数值只用来定位。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 96
P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    for i, ax in enumerate(("X", "Y")):
        m = nt.nodes.new("ShaderNodeMath"); m.operation = "MULTIPLY"; m.inputs[1].default_value = 0.25
        a = nt.nodes.new("ShaderNodeMath"); a.operation = "ADD"; a.inputs[1].default_value = 0.5
        nt.links.new(sep.outputs[ax], m.inputs[0])
        nt.links.new(m.outputs["Value"], a.inputs[0])
        nt.links.new(a.outputs["Value"], comb.inputs[ax])
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    ns, H = 3, 2.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("G0")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid0", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, ob


_seq = [0]


def uvimg(tag=""):
    _seq[0] += 1
    p = os.path.join(HERE, "_rf_%02d%s.png" % (_seq[0], tag))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def uvd(a, b):
    return float(np.abs(a - b).mean())


def make_legacy_group(cam, use_delta_node=True, delta=(0.2, 0.0)):
    """把手造的「旧版投影组」改造成：没有 S/C 节点、没有版本键、带旧 uv_delta 节点。"""
    ng = bpy.data.node_groups[plock.CAM_PROJECT_PREFIX + cam.data.name]
    s = ng.nodes.get(plock.PLOCK_S_NODE)
    c = ng.nodes.get(plock.PLOCK_C_NODE)
    p4 = None
    z3 = None
    for n in ng.nodes:
        if n.label == "Perspective 4":
            p4 = n
        if n.label == "Zoom 3":
            z3 = n
    assert p4 is not None and z3 is not None, "找不到 perspective_4 / zoom_3"
    # 拆掉 S/C：persp4 → S → C → zoom3 变成 persp4 → zoom3
    if s is not None:
        ng.nodes.remove(s)
    if c is not None:
        ng.nodes.remove(c)
    if use_delta_node:
        attr = ng.nodes.new("ShaderNodeAttribute")
        attr.attribute_name = plock.UV_DELTA_ATTR_LEGACY
        attr.name = "legacy_uv_delta_attr"
        add = ng.nodes.new("ShaderNodeVectorMath")
        add.operation = "ADD"
        add.name = "legacy_uv_delta_add"
        ng.links.new(p4.outputs[0], add.inputs[0])
        ng.links.new(attr.outputs["Vector"], add.inputs[1])
        ng.links.new(add.outputs["Vector"], z3.inputs[0])
    else:
        ng.links.new(p4.outputs[0], z3.inputs[0])
    if ng.get(plock.PLOCK_DELTA_VERSION_KEY):
        del ng[plock.PLOCK_DELTA_VERSION_KEY]
    return ng


def write_legacy_attr(ob, delta=(0.2, 0.0, 0.0)):
    mesh = ob.data
    a = mesh.attributes.get(plock.UV_DELTA_ATTR_LEGACY)
    if a is None:
        a = mesh.attributes.new(plock.UV_DELTA_ATTR_LEGACY, "FLOAT_VECTOR", "POINT")
    vals = (list(delta) * len(mesh.vertices))
    a.data.foreach_set("vector", vals)
    mesh.update()


print("=" * 84)
print("### [1] 旧工程（组无 S/C + 旧逐顶点 delta）→ 点锁定，自动升级是否损坏画面")
print("=" * 84)
for tag, use_delta_node, delta in (("旧组+旧delta=0.2（真实旧工程）", True, (0.2, 0.0, 0.0)),
                                   ("旧组+旧delta=0（对照）", True, (0.0, 0.0, 0.0)),
                                   ("旧组无 delta 节点（对照）", False, (0.0, 0.0, 0.0))):
    sc, cam, cd, mat, A = build()
    u_ref = uvimg("ref")
    if use_delta_node:
        make_legacy_group(cam, True)
        write_legacy_attr(A, delta)
    else:
        make_legacy_group(cam, False)
    bpy.context.view_layer.update()
    u_old = uvimg("old")
    n_pre = plock._find_delta_nodes(cam.data.name)
    has_ver_pre = bool(bpy.data.node_groups[plock.CAM_PROJECT_PREFIX + cam.data.name]
                       .get(plock.PLOCK_DELTA_VERSION_KEY))
    r = plock.lock_group(sc, cam)
    bpy.context.view_layer.update()
    nodes = plock._find_delta_nodes(cam.data.name)
    has_ver = bool(bpy.data.node_groups[plock.CAM_PROJECT_PREFIX + cam.data.name]
                   .get(plock.PLOCK_DELTA_VERSION_KEY))
    legacy_left = A.data.attributes.get(plock.UV_DELTA_ATTR_LEGACY) is not None
    u_lock = uvimg("lock")
    jump = uvd(u_lock, u_old)
    print("  --- %s" % tag)
    print("      锁定前 _find_delta_nodes=%s / 版本键=%s" % (n_pre, has_ver_pre))
    chk("%s：锁定后自动补上 S/C 节点" % tag, nodes is not None and has_ver,
        "nodes=%s ver=%s" % (bool(nodes), has_ver))
    chk("%s：旧属性已清理" % tag, not legacy_left)
    chk("%s：升级瞬间画面不跳（Δ<0.002）" % tag, jump < 2e-3,
        "Δ=%.5f（旧外观 vs 锁定后）" % jump)
    # 解锁路径：再伪造一次「旧组」，验证 unlock 时的升级
    make_legacy_group(cam, True)
    bpy.context.view_layer.update()
    u_pre_ul = uvimg("preul")
    r2 = plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    u_ul = uvimg("ul")
    nodes2 = plock._find_delta_nodes(cam.data.name)
    chk("%s：解锁路径也自动补 S/C" % tag, nodes2 is not None)
    chk("%s：解锁瞬间画面不跳（Δ<0.002）" % tag, uvd(u_ul, u_pre_ul) < 2e-3,
        "Δ=%.5f" % uvd(u_ul, u_pre_ul))
    print("      锁定返回: %s" % str(r.get("message"))[:80])
    print("      解锁返回: %s" % str(r2.get("message"))[:80])
    print("")

print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("RF_UPGRADE_DONE")
