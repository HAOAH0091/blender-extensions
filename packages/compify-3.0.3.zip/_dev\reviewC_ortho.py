"""审查 C · 第 1 项：正交相机（camera.data.type = 'ORTHO'）

问题：投影组 UV = (x/z, y/z) · lens/sensor —— 这是**透视**公式；正交渲染的
取景由 ortho_scale 决定、与 z 无关。所以在 ORTHO 下「投影图案」本身就不在
相机看到的位置上。本脚本用真渲染探针量出这个偏差，并检查锁定/解锁契约。
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy
import mathutils

print("### 1a 正交相机：图案 vs 相机真实取景 ###")
sc, cam, cd, mat, ob = build(cam_type="ORTHO", ortho_scale=6.0, shape="平面")
p0 = render_uv("o")
dump("ORTHO 未锁定", p0)
table(sc, cam, ob, p0, n=5)
amx, amn, an = align_err(sc, cam, ob, p0)
chk("1a 正交下图案严重错位（应当 ~0.003）", amx < 5e-3,
    "对齐误差 max=%.4f mean=%.4f (n=%d)" % (amx, amn, an))

print("\n### 1b 正交下 锁定→移相机→解锁 的契约 ###")
plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pL = render_uv("ol")
iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
zr0 = [v.co.z for v in ob.data.vertices]
wgeo0 = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pL2 = render_uv("ol2")
iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
sm = np.intersect1d(iL, iL2)
glue = float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max()) if len(sm) else float("nan")
wgeo1 = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
dgeo = np.abs(wgeo1 - wgeo0)
print("  锁定中移相机 x+2：图案 glue=%.4f | 网格几何变化 max=%.4f（透视下这是刻意的适配变形）"
      % (glue, dgeo.max()))
chk("1b 正交下锁定期间图案粘住", glue < 5e-3, "glue=%.4f" % glue)
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
pU = render_uv("ou")
jump, jmx, jn = diff(pL2, pU)
print("  正交下解锁跳变 = %.4f" % jump)
chk("1b 正交下解锁不跳", jump < 2e-3, "jump=%.4f S/C=%s" % (jump, nodes_sc(cd)))

print("\n### 1b2 正交下沿视线推拉相机（正交取景与距离无关，图案却按 1/距离 变）###")
sc, cam, cd, mat, ob = build(cam_type="ORTHO", ortho_scale=6.0, shape="倾斜")
p0 = render_uv("do")
amx_0, _, _ = align_err(sc, cam, ob, p0)
cam.location.z = 7.0                      # 只沿视线后退 2，不改 ortho_scale
bpy.context.view_layer.update()
p1 = render_uv("do2")
amx_1, _, _ = align_err(sc, cam, ob, p1)
print("  未锁定：相机距离 5 → 7，图案对齐误差 %.4f → %.4f" % (amx_0, amx_1))
plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pL = render_uv("dl")
iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
cam.location.z = 4.0                      # 锁定期间再推近
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pL2 = render_uv("dl2")
iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
sm = np.intersect1d(iL, iL2)
glue = float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max()) if len(sm) else float("nan")
w0 = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
pU = render_uv("du")
jump = diff(pL2, pU)[0]
print("  正交下锁定中推拉相机：图案粘住=%.4f 解锁跳变=%.4f" % (glue, jump))
chk("1b2 正交下推拉相机：锁定/解锁契约仍成立", glue < 5e-3 and jump < 2e-3,
    "glue=%.4f jump=%.4f（但图案比例本身是错的，见 1a）" % (glue, jump))

print("\n### 1c 正交下改 ortho_scale（正交的『变焦』）—— 图案会不会跟着变 ###")
sc, cam, cd, mat, ob = build(cam_type="ORTHO", ortho_scale=6.0, shape="平面")
plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pA = render_uv("s1")
iA, uvA, _ = uv_at_verts(sc, cam, ob, pA)
cd.ortho_scale = 8.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pB = render_uv("s2")
iB, uvB, _ = uv_at_verts(sc, cam, ob, pB)
sm = np.intersect1d(iA, iB)
d = float(np.abs(uvA[np.isin(iA, sm)] - uvB[np.isin(iB, sm)]).max()) if len(sm) else float("nan")
print("  锁定中 ortho_scale 6→8：图案 UV 变化=%.4f（正交取景变了 33%%，图案一点没动）" % d)
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
pC = render_uv("s3")
print("  解锁跳变=%.4f" % diff(pB, pC)[0])
amx2, _, _ = align_err(sc, cam, ob, pC)
print("  解锁后图案与相机取景的偏差 = %.4f" % amx2)

report("审查 C · 正交相机")
