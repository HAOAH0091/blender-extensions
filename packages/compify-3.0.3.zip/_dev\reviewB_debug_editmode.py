"""调试：编辑模式加顶点之后，为什么整个相机的适配都停了。

跑法：blender --background --factory-startup --python _dev\\reviewB_debug_editmode.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy, bmesh

C.load()
plock = C.PL()

sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridB", cam, mat, ns=3)
CTRL = C.add_grid("GridCtrlB", cam, mat, ns=3, x0=2.6)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("lock:", r["success"], "frozen:", r.get("frozen"))
key = (sc.as_pointer(), cd.name)
print("_last_view 有 key:", key in plock._last_view)

bpy.context.view_layer.objects.active = A
bpy.ops.object.mode_set(mode="EDIT")
bm = bmesh.from_edit_mesh(A.data)
bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
bmesh.update_edit_mesh(A.data)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.context.view_layer.update()
print("顶点数 A=%d CTRL=%d" % (len(A.data.vertices), len(CTRL.data.vertices)))
print("A 的属性:", [a.name + "/%d" % len(a.data) for a in A.data.attributes])

C.run_handler(sc)
print("handler 后: _last_view 有 key:", key in plock._last_view)
st = plock.get_state(sc, cam)
print("state enabled=%s objects=%s" % (st.get("enabled"), st.get("objects")))
print("locked_objects(with st) =", [o.name for o in plock.locked_objects(sc, cd.name, st)])

cam.location.x = 2.0
bpy.context.view_layer.update()
view = plock.get_camera_view_matrix(cam)
last = plock._last_view.get(key)
print("cam_changed 判定 =", (last is None or not plock._matrices_close(last[0], view,
                                                                  plock.CAMERA_CHANGE_THRESHOLD)
                             or abs(cam.data.lens - last[1]) > 1e-6))
for ob in (A, CTRL):
    w0 = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
    ok = plock.adapt_object(ob, cam, st, view_now=view)
    w1 = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
    print("%-9s adapt_object 返回=%s  几何Δ=%.6f  base=%s  modifiers=%d"
          % (ob.name, ok, float(np.abs(w1 - w0).max()),
             ob.data.attributes.get(plock.BASE_ATTR) is not None, len(ob.modifiers)))
C.run_handler(sc)

# 再对比：把 A 的名字换个普通的，或者重新 lock 一次
print("\n重新 lock：")
r2 = plock.lock_group(sc, cam)
print("  ", r2["success"], r2["message"][:100])
w0 = np.array([tuple(CTRL.matrix_world @ v.co) for v in CTRL.data.vertices])
cam.location.x = 4.0
C.run_handler(sc)
w1 = np.array([tuple(CTRL.matrix_world @ v.co) for v in CTRL.data.vertices])
print("   重锁后 CTRL 几何Δ=%.6f" % float(np.abs(w1 - w0).max()))
print("DONE")
