"""审查 F-3/4/9：热重载后 handler 是否重复注册；禁用后是否仍有 handler 在跑；
             模块级全局变量是否在卸载时重置。

重载方式与 Blender「Reload Scripts(F8)」一致：清掉 sys.modules 里的包，再从磁盘重新导入
（得到**新的函数对象**，而那些函数对象仍留在 bpy.app.handlers 里）。
"""
import bpy, sys, os, math
import importlib.util
import mathutils

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if c else "FAIL", n, d))


def load_pkg():
    for k in [k for k in list(sys.modules) if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
    mod = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = mod
    spec.loader.exec_module(mod)
    return sys.modules[PKG + ".compify_parallax_lock"], sys.modules[PKG + ".node_groups"]


def ours():
    h = bpy.app.handlers.depsgraph_update_post
    return [f for f in h if "parallax_lock_update_handler" in getattr(f, "__qualname__", "")]


def build_scene(ng_mod):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam); cam.location = (0, 0, 5); sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    emi = nt.nodes.new("ShaderNodeEmission")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    mesh = bpy.data.meshes.new("G0"); mesh.from_pydata(
        [(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)], [], [(0, 1, 2, 3)]); mesh.update()
    ob = bpy.data.objects.new("Grid0", mesh); sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


print("=" * 84)
print("### [3-a] 首次加载：handler 注册数量")
bpy.ops.wm.read_factory_settings(use_empty=True)
plock, ng_mod = load_pkg()
plock.register_handlers()
n1 = len(ours())
chk("首次 register_handlers 后 handler 数量 = 1", n1 == 1, "count=%d" % n1)

print("")
print("### [3-b] 模拟「Reload Scripts(F8)」后再 register（新函数对象 vs 旧列表项）")
old_fn = ours()[0]
plock2, ng2 = load_pkg()          # 新模块对象、新函数对象
new_fn = plock2.parallax_lock_update_handler
plock2.register_handlers()
n2 = len(ours())
chk("重载后 handler 数量仍为 1（未重复注册）", n2 == 1,
    "count=%d  旧函数 is 新函数: %s" % (n2, old_fn is new_fn))

print("")
print("### [3-c] 同一次 depsgraph 更新里，每个 handler 是否都被调用")
cnt = {}


def _wrap(fn, idx):
    def _w(scene):
        cnt[idx] = cnt.get(idx, 0) + 1
        return fn(scene)
    return _w


h = bpy.app.handlers.depsgraph_update_post
for i, f in enumerate(list(h)):
    if "parallax_lock_update_handler" in getattr(f, "__qualname__", ""):
        h[h.index(f)] = _wrap(f, i)
bpy.context.view_layer.update()
print("  一次 view_layer.update() 后各 handler 调用次数: %s" % cnt)
chk("每次更新只调用 1 次", sum(cnt.values()) == 1, "总调用=%d" % sum(cnt.values()))

print("")
print("### [3-d] 重载后 unregister：能撤掉几个？（旧函数对象无法被移除）")
plock2.unregister_handlers()
h = bpy.app.handlers.depsgraph_update_post
left = [f for f in h if "parallax_lock_update_handler" in getattr(f, "__qualname__", "")]
print("  unregister 后仍留在 handlers 里的项数（含包装器）= %d" % len(left))

print("")
print("### [4] 禁用插件（unregister_handlers）后，锁定网格还会不会被继续改动")
plock3, ng3 = load_pkg()
plock3.register_handlers()
sc, cam, cd, ob = build_scene(ng3)
r = plock3.lock_group(sc, cam)
print("  锁定: %s" % r.get("message")[:40])
w0 = [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]
cam.location.x = 2.0
bpy.context.view_layer.update()
plock3.parallax_lock_update_handler(sc)
w1 = [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]
d1 = max(max(abs(a - b) for a, b in zip(p, q)) for p, q in zip(w0, w1))
print("  handler 跑一帧后几何最大位移 = %.4f（应 >0，说明适配生效）" % d1)
plock3.unregister_handlers()
still = len([f for f in bpy.app.handlers.depsgraph_update_post
             if "parallax_lock_update_handler" in getattr(f, "__qualname__", "")])
print("  调用 unregister_handlers 之后，handlers 里剩下的本项目项数 = %d" % still)
cam.location.x = 3.5
bpy.context.view_layer.update()
w2 = [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]
d2 = max(max(abs(a - b) for a, b in zip(p, q)) for p, q in zip(w1, w2))
chk("禁用后几何不再被改动（d≈0）", d2 < 1e-9, "禁用后一帧位移 = %.6f" % d2)

print("")
print("### [9] 卸载时模块级全局变量是否重置")
plock4, ng4 = load_pkg()
plock4.register_handlers()
sc, cam, cd, ob = build_scene(ng4)
plock4.lock_group(sc, cam)
cam.location.x = 1.0
bpy.context.view_layer.update()
plock4.parallax_lock_update_handler(sc)
print("  _proj_cache 条目 = %d, _backfill_tick = %d, _last_view = %d, _base_cache = %d"
      % (len(plock4._proj_cache), plock4._backfill_tick[0], len(plock4._last_view),
         len(plock4._base_cache)))
plock4.unregister_handlers()
print("  unregister 后：_proj_cache = %d（未清）, _backfill_tick = %d（未清）, "
      "_last_view = %d（已清）, _base_cache = %d（已清）, _popup_shown = %d"
      % (len(plock4._proj_cache), plock4._backfill_tick[0], len(plock4._last_view),
         len(plock4._base_cache), len(plock4._popup_shown)))
chk("_proj_cache 在卸载时被清空", len(plock4._proj_cache) == 0,
    "剩余 %d 条" % len(plock4._proj_cache))
chk("_backfill_tick 在卸载时归零", plock4._backfill_tick[0] == 0,
    "值 %d" % plock4._backfill_tick[0])

print("")
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("RF_RELOAD_DONE")
