"""审查 A-1c：10 轮「锁定→移相机→解锁」后，图案相对【真实实时投影】永久偏了多少
（渲染判据：UV 探针图；对照组 = 重置之后）
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import reviewA_lib as L

plock = L.plock
L.report("A-1c 反复 lock/unlock 之后图案相对真实投影的永久偏移")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
u_ref = L.uvimg("dr")          # 从未锁定过的真实实时投影
Cs = []
for i in range(10):
    plock.lock_group(sc, cam)
    cam.location.x += 0.4
    L.run_h(sc, times=1)
    plock.unlock_group(sc, cam)
    S, Cc = L.node_sc(cam)
    Cs.append(round(Cc[0], 4))
    cam.location.x -= 0.4
    L.run_h(sc, times=1)
u_now = L.uvimg("dr")
off = L.uvd(u_now, u_ref)
S, Cc = L.node_sc(cam)
print("  相机回到原位的 10 轮之后：C 逐轮 = %s" % Cs)
print("  末态 S=%.4f C=(%+.4f,%+.4f)" % (S, Cc[0], Cc[1]))
print("  图案与真实投影的渲染差（UV 探针均值）=%.6f" % off)
L.chk("反复 lock/unlock 后图案不相对真实投影漂移", off < 2e-3,
      "10 轮漂移=%.6f（每轮 ≈%.4f）" % (off, off / 10))
# 对照：重置后应回到真实投影
plock.reset_group(sc, cam)
u_reset = L.uvimg("dr")
L.info("对照：重置后与真实投影的差=%.6f（说明漂移确实来自 C+k 累积）"
       % L.uvd(u_reset, u_ref))
L.chk("重置能清掉这份漂移", L.uvd(u_reset, u_ref) < 2e-3,
      "Δ=%.6f" % L.uvd(u_reset, u_ref))

print()
L.report("A-1d 变焦循环（dolly 关掉，走纯 zoom 补偿路径）的 S 是否也会累积")
plock.CAMERA_DOLLY_ZOOM = False
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
Ss = []
for i in range(5):
    cam.data.lens = 50.0
    plock.lock_group(sc, cam)
    cam.data.lens = 85.0
    L.run_h(sc, times=1)
    plock.unlock_group(sc, cam)
    S, Cc = L.node_sc(cam)
    Ss.append(round(S, 5))
print("  每轮 50→85mm 后的 S = %s" % Ss)
L.chk("纯变焦循环 S 不累积", all(abs(s - Ss[0]) < 1e-6 for s in Ss),
      "S 序列=%s（末次=%.4f）" % (Ss, Ss[-1]))
plock.CAMERA_DOLLY_ZOOM = True
L.summary()
