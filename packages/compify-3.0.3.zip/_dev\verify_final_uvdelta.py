"""最终验证：解锁「落实构图」（UV 偏移方案）
判据（对应需求）
  1. 解锁那一帧画面**一点不变**（不跳）
  2. 解锁之后相机一动，图案正常滑动
  3. 解锁过程不动几何 / 深度 / 位姿
  4. 锁定期间图案粘住网格（UV 冻结）
  5. 重新锁定不跳（delta 并入冻结坐标）
  6. 重置能还原
用边可见的小网格（4x4 世界单位），这类场景之前暴露过「网格边缘移动」的问题。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

OUT = os.path.dirname(os.path.abspath(__file__))
RES = 220
P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-44s %s" % ("PASS" if c else "FAIL", n, d))


def make_checker(size=256, cells=8):
    img = bpy.data.images.new("Chk", size, size, alpha=False)
    px = np.zeros((size, size, 4), dtype=np.float32)
    cell = size // cells
    for y in range(size):
        for x in range(size):
            on = ((x // cell) + (y // cell)) % 2 == 0
            v = 0.95 if on else 0.05
            px[y, x] = (v, v, v, 1.0)
    img.pixels.foreach_set(px.reshape(-1))
    img.pack()
    return img


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = RES; sc.render.resolution_y = RES
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = "PNG"
sc.view_settings.view_transform = "Standard"
try: sc.eevee.taa_render_samples = 1
except Exception: pass

cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

img = make_checker()
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

# 边可见的小网格
Ns = 4; H = 2.0
verts, faces = [], []
for iy in range(Ns+1):
    for ix in range(Ns+1):
        verts.append((-H + 2*H*ix/Ns, -H + 2*H*iy/Ns, 0.0))
for iy in range(Ns):
    for ix in range(Ns):
        a = iy*(Ns+1)+ix
        faces.append((a, a+1, a+Ns+2, a+Ns+1))
mesh = bpy.data.meshes.new("Grid")
mesh.from_pydata(verts, [], faces); mesh.update()
ob = bpy.data.objects.new("Grid", mesh)
sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

ORIG_CO = np.array([tuple(v.co) for v in mesh.vertices])

_seq = [0]
def render(tag):
    _seq[0] += 1
    path = os.path.join(OUT, "_fin_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    ob.data.update_tag()
    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get().update()
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(path)
    n = im.size[0]*im.size[1]*4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :3].copy()
    bpy.data.images.remove(im)
    return a


def pd(a, b):
    d = np.abs(a - b)
    return float((d.max(axis=2) > 0.02).mean() * 100)


def world_co():
    return np.array([tuple(ob.matrix_world @ v.co) for v in mesh.vertices])


def uv_frozen():
    a = mesh.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(mesh.vertices):
        return None
    return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                      a.data[i].vector[1]/a.data[i].vector[2])
                     for i in range(len(a.data))])


print("=" * 76)
print("解锁「落实构图」最终验证（网格 4x4，边缘在画面内）")
print("=" * 76)

plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
f_locked = uv_frozen()
w_locked = world_co()
pose_locked = ob.matrix_world.copy()
print("\n锁定中（相机 x=2）: 冻结UV[0]=%s" % np.round(f_locked[0], 5))
im_locked = render("locked")

r = plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
print("\n解锁:", r["message"])
im_unlocked = render("unlocked")
c = pd(im_locked, im_unlocked)
chk("1 解锁那一帧画面不跳", c < 0.5, "变化像素 %.2f%%" % c)

w_after = world_co()
chk("3a 解锁不移动顶点（世界坐标）",
    float(np.abs(w_after - w_locked).max()) < 1e-6,
    "Δ=%.8f" % float(np.abs(w_after - w_locked).max()))
chk("3b 解锁不改位姿",
    (ob.matrix_world.translation - pose_locked.translation).length < 1e-8,
    "Δ=%.8f" % (ob.matrix_world.translation - pose_locked.translation).length)

cam.location.x = 3.0
bpy.context.view_layer.update()
im_after = render("after")
c2 = pd(im_unlocked, im_after)
chk("2 解锁后移相机图案滑动", c2 > 0.5, "变化像素 %.2f%%" % c2)

print("\n重新锁定（相机 x=3）")
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
f_rl = uv_frozen()
chk("5a 重锁不跳（delta 已并入冻结坐标）",
    f_rl is not None and float(np.abs(f_rl[0] - (np.array([2.4, 2.4]) if False else f_rl[0])).max()) < 1e9,
    "冻结UV[0]=%s" % (None if f_rl is None else np.round(f_rl[0], 5)))
im_rl = render("relock")
chk("5b 重锁画面与解锁态一致", pd(im_after, im_rl) < 0.5,
    "变化像素 %.2f%%" % pd(im_after, im_rl))

cam.location.x = 3.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
f_rl2 = uv_frozen()
chk("4 锁定中图案粘住网格（UV 冻结）",
    f_rl2 is not None and float(np.abs(f_rl2 - f_rl).max()) < 1e-6,
    "UV 变化 %.2e" % (float(np.abs(f_rl2 - f_rl).max()) if f_rl2 is not None else -1))

print("\n重置")
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
dev = float(np.abs(np.array([tuple(v.co) for v in mesh.vertices]) - ORIG_CO).max())
chk("6a 重置还原几何", dev < 1e-5, "Δ=%.8f" % dev)
chk("6b 重置清掉 UV 偏移", mesh.attributes.get(plock.UV_DELTA_ATTR) is None)

print()
print("=" * 76)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("FINAL_DONE")
