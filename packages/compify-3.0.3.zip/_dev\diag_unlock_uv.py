"""量化确认：解锁后「投射效果消失」= UV 恒定不再随相机变化
判据：移相机后 UV 是否变化。实时投影应变化，冻结则不变。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_uv"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]

import numpy as np


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata([(-1,-1,0),(1,-1,0),(1,1,0),(-1,1,0)], [], [(0,1,2,3)])
    mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    scene.collection.objects.link(ob)
    ob.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, ob)
    return scene, cam, cd, ob


def proj_uv(cam, obj):
    """按 Camera Project 组的语义算投影 UV：
       优先用 campos 属性（冻结）；没有属性则用实时相机空间坐标（=TexCoord Object）
       这里直接模拟「组当前会读到什么」
    """
    ng = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cam.data.name)
    patched = ng is not None and ng.get(PL.PATCH_KEY) is not None
    if patched:
        a = obj.data.attributes.get(PL._campos_attr_name(cam.data.name))
        if a is not None and len(a.data) == len(obj.data.vertices):
            src = np.array([tuple(a.data[i].vector) for i in range(len(a.data))])
        else:
            src = np.zeros((len(obj.data.vertices), 3))   # attribute 缺失 → 全 0
    else:
        # 实时：相机空间坐标
        mwi = cam.matrix_world.inverted()
        src = np.array([tuple(mwi @ (obj.matrix_world @ v.co)) for v in obj.data.vertices])
    # 投影：x/z, y/z
    z = src[:, 2]
    u = src[:, 0] / z
    v = src[:, 1] / z
    return np.stack([u, v], axis=1), patched


def show(tag, cam, obj):
    uv, patched = proj_uv(cam, obj)
    print("    %-26s patch=%-5s UV[0]=(%+.5f, %+.5f)" %
          (tag, patched, uv[0][0], uv[0][1]))
    return uv


print("="*80)
print("解锁后是否还有「投射效果」—— 判据：移相机时 UV 是否变化")
print("="*80)

scene, cam, cd, A = build()
print("\n  [锁定前]")
uv0 = show("初始", cam, A)

print("\n  " + PL.lock_group(scene, cam).get("message"))
uvL0 = show("锁定后", cam, A)
cam.location = (1.0, 0, 5.0); bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
uvL1 = show("锁定后+移相机", cam, A)
print("      >>> 移相机 UV 变化量: %.8f  (%s)" % (
    float(np.abs(uvL1-uvL0).max()),
    "冻结=锁定生效" if np.abs(uvL1-uvL0).max() < 1e-6 else "在变"))

print("\n  " + PL.unlock_group(scene, cam).get("message")[:22])
uvU0 = show("解锁后", cam, A)
cam.location = (2.0, 0, 5.0); bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
uvU1 = show("解锁后+移相机", cam, A)
d_unlock = float(np.abs(uvU1-uvU0).max())
print("      >>> 移相机 UV 变化量: %.8f  (%s)" % (
    d_unlock,
    "【UV 仍冻结 = 投射效果消失】" if d_unlock < 1e-6 else "UV 随相机变化 = 有投射效果"))

print("\n  --- 对照：重置后 ---")
PL.reset_group(scene, cam)
cam.location = (3.0, 0, 5.0); bpy.context.view_layer.update()
uvR0 = show("重置后", cam, A)
cam.location = (4.0, 0, 5.0); bpy.context.view_layer.update()
uvR1 = show("重置后+移相机", cam, A)
d_reset = float(np.abs(uvR1-uvR0).max())
print("      >>> 移相机 UV 变化量: %.8f  (%s)" % (
    d_reset,
    "有投射效果(实时)" if d_reset > 1e-6 else "UV 不变"))

print("\n" + "="*80)
print("结论")
print("="*80)
print("  解锁后 UV 变化量 = %.8f  → %s" % (
    d_unlock, "投射效果消失（组仍 patch，读冻结坐标）" if d_unlock < 1e-6 else "正常"))
print("  重置后 UV 变化量 = %.8f  → %s" % (
    d_reset, "投射效果正常（组已 unpatch，实时）" if d_reset > 1e-6 else "异常"))
