import bpy
m = bpy.data.materials.new('x')
m.use_nodes = True
for t in ('ShaderNodeSeparateXYZ', 'ShaderNodeTexCoord', 'ShaderNodeAttribute'):
    n = m.node_tree.nodes.new(t)
    print('NODETYPE %s -> %s' % (t, n.type))
