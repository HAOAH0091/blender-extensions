"""问题1 深挖：解锁后到底哪里失效？
测：解锁后移相机，网格是否还在跟着动（说明解锁没生效）
   解锁→重新锁定，投影是否还正常
   解锁→重置，投影是否恢复
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_ul2"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    return scene, cam, cd

def make_mat(cd):
    m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    return m

def make_grid(name, x, z=0.0, w=0.8, ns=2):
    mesh = bpy.data.meshes.new(name)
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((x-w+2*w*ix/ns, -1+2*iy/ns, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    o = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(o)
    return o

def verts(o): return [tuple(round(x,6) for x in v.co) for v in o.data.vertices]
def campos_txt(o, cdn):
    n = PL._campos_attr_name(cdn)
    a = o.data.attributes.get(n)
    if a is None: return "缺失"
    if len(a.data) == 0: return "存在但空"
    v = tuple(a.data[0].vector)
    zero = all(abs(x) < 1e-9 for x in v)
    return "首=%s%s" % (tuple(round(x,3) for x in v), " 【全零=投影坏】" if zero else "")
def proj_uv_ok(o, cdn):
    n = PL._campos_attr_name(cdn)
    a = o.data.attributes.get(n)
    if a is None or len(a.data) == 0: return False
    for i in range(len(a.data)):
        v = a.data[i].vector
        if abs(v[0])>1e-9 or abs(v[1])>1e-9 or abs(v[2])>1e-9:
            return True
    return False

scene, cam, cd = build()
m = make_mat(cd)
A = make_grid("GridA", 0.0)
A.data.materials.append(m)
NG.create_uv_adjust_node_group(scene, cam, A)

print("="*76)
print("锁定 -> 解锁 -> 移相机：网格是否还在跟？")
print("="*76)
print(PL.lock_group(scene, cam).get("message"))
v_lock = verts(A)
print("  锁定后 campos:", campos_txt(A, cd.name))

print("\n  " + PL.unlock_group(scene, cam).get("message"))
print("  解锁后 campos:", campos_txt(A, cd.name))
print("  解锁后 A.mode:", A.mode)

v_ul = verts(A)
print("  解锁前后顶点变化: %.6f" % max(abs(a[i]-b[i]) for a,b in zip(v_lock,v_ul) for i in range(3)))

# 解锁后移相机
print("\n  解锁后移相机 x+1：")
cam.location = (1.0, 0, 5.0)
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
v_after = verts(A)
d = max(abs(a[i]-b[i]) for a,b in zip(v_ul,v_after) for i in range(3))
print("    顶点变化 %.6f  (%s)" % (d, "还在跟=解锁失效" if d > 1e-6 else "不跟了=解锁生效"))
print("    campos:", campos_txt(A, cd.name))
print("    >>> 投影可用:", proj_uv_ok(A, cd.name))

# 解锁后再重新锁定
print("\n  重新锁定：")
res = PL.lock_group(scene, cam)
print("   ", res.get("message"))
print("    campos:", campos_txt(A, cd.name))
print("    >>> 投影可用:", proj_uv_ok(A, cd.name))

# 解锁 -> 重置
print("\n" + "="*76)
print("解锁 -> 重置：投影是否恢复")
print("="*76)
print("  ", PL.unlock_group(scene, cam).get("message"))
print("    campos:", campos_txt(A, cd.name))
print("  ", PL.reset_group(scene, cam).get("message"))
print("    campos:", campos_txt(A, cd.name))
print("    属性列表:", [a.name for a in A.data.attributes])
print("    >>> 投影可用:", proj_uv_ok(A, cd.name))
print("    >>> 材质还在吗:", [mm.name for mm in A.data.materials])
import bpy as _b
for mm in A.data.materials:
    if mm.use_nodes:
        for nd in mm.node_tree.nodes:
            print("       节点:", nd.bl_idname, nd.name)
