"""验证：孤儿锁定点「还原」后，投影组的 C+k 是否复位成恒等

造法：正常锁定+解锁（会落实 C=-0.4）→ 把相机删掉（制造孤儿）→ reset_orphan_locks
判据：组里的 S 应回到 1.0、C 应回到 (0,0)
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-50s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 2; h = 1.2
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name),
                             "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def sc_vals(cd_name):
    nodes = plock._find_delta_nodes(cd_name)
    if not nodes:
        return None, None
    return (nodes[0].inputs["Scale"].default_value,
            tuple(nodes[1].inputs[1].default_value)[:2])


print("=" * 84)
print("孤儿锁定还原后 C+k 是否复位")
print("=" * 84)
sc, cam, cd, ob = build()
cd_name = cd.name

plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
r = plock.unlock_group(sc, cam)
S, C = sc_vals(cd_name)
print("  锁定→移相机→解锁：S=%.6f C=(%+.6f, %+.6f)" % (S, C[0], C[1]))
chk("解锁后确实落实了偏移（C 非 0）", abs(C[0]) > 1e-6, "Cx=%+.6f" % C[0])

# 制造孤儿：删掉相机对象
bpy.data.objects.remove(cam, do_unlink=True)
bpy.context.view_layer.update()
orph = plock.find_orphan_locks(sc)
print("  删掉相机后，检测到孤儿网格：", [o.name if hasattr(o, "name") else str(o) for o in orph])
chk("确实检测到孤儿", len(orph) > 0)

r2 = plock.reset_orphan_locks(sc)
print("  还原消息：", str(r2.get("message", ""))[:70])
print("  success=%s count=%s" % (r2.get("success"), r2.get("count")))
chk("还原成功", r2.get("success"), "")

S2, C2 = sc_vals(cd_name)
print("\n  还原后：S=%.6f C=(%+.6f, %+.6f)" % (S2, C2[0], C2[1]))
chk("C+k 复位成恒等（S=1, C=0）",
    abs(S2 - 1.0) < 1e-9 and abs(C2[0]) < 1e-9 and abs(C2[1]) < 1e-9,
    "S=%.8f C=(%.8f, %.8f)" % (S2, C2[0], C2[1]))

print()
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("ORPHAN_DONE")
