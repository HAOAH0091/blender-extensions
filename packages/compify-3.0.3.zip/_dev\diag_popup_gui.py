"""在【GUI 模式】下验证弹窗链路（会短暂弹窗，用完自动退出）

验证顺序：
  1 bpy.app.background == False（守卫条件成立）
  2 timer 回调里 popup_menu 不报错
  3 popup_menu 的 draw 回调被调用（说明真画出来了）
  4 之后自动退出
"""
import bpy, sys, time

sys.stdout.reconfigure(encoding="utf-8")
LOG = []


def log(*a):
    s = " ".join(str(x) for x in a)
    LOG.append(s)
    print(s)


log("=== GUI 环境 ===")
log("  bpy.app.background =", bpy.app.background)
log("  bpy.context.window =", bpy.context.window)
log("  守卫条件 not background =", not bpy.app.background)

state = {"drawn": False, "err": None, "done": False}


def _tick():
    if state["done"]:
        return None
    state["done"] = True
    try:
        def draw(self, ctx):
            state["drawn"] = True
            col = self.layout.column()
            col.label(text="测试：不可冻结网格", icon="ERROR")
            col.label(text="带修改器 / 形态键 / 共享网格")

        bpy.context.window_manager.popup_menu(draw, title="Compify 视差锁定")
        log("  popup_menu 调用成功（未抛异常）")
    except Exception as e:
        state["err"] = "%s: %s" % (type(e).__name__, e)
        log("  popup_menu 异常:", state["err"])
    return None


if not bpy.app.background:
    bpy.app.timers.register(_tick, first_interval=0.2)
    log("  timer 已注册")
else:
    log("  !! 处于 background 模式，不弹窗")


def _finish():
    log("")
    log("=== 结果 ===")
    log("  draw 回调被调用 :", state["drawn"])
    log("  异常            :", state["err"])
    log("  => 弹窗可用:", state["drawn"] and state["err"] is None)
    log("POPUP_GUI_DONE")
    bpy.ops.wm.quit_blender()
    return None


if not bpy.app.background:
    bpy.app.timers.register(_finish, first_interval=2.0)
else:
    _finish()
