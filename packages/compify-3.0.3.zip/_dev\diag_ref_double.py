"""深挖：拖 A 之后 recompute_ref_depth 到底算出了什么

怀疑：adapt_object 会改写 base 属性（为了保持屏幕位置），
     于是 recompute 里的 `max(base_d) + offset` 会把 offset 算两遍。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(zA=0.0, zB=2.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns, -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("A", -1.5, zA)
    B = mk("B", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def dump(tag, sc, cd, A, B):
    st = plock.get_state(sc, sc.camera)
    print("\n  [%s] st['ref_depth'] = %.6f" % (tag, st.get("ref_depth", 0)))
    for o in (A, B):
        b = plock._read_base_attribute(o)
        off = o.get(plock.DRAG_OFFSET_KEY, 0.0)
        lg = o.get(plock.DRAG_SCALE_KEY, 1.0)
        dmax = max(d for (_x, _y, d) in b) if b else None
        print("     %s: base dmax=%.6f  offset=%+.6f  scale=%.6f  ⇒ max+off=%.6f"
              % (o.name, dmax, off, lg, dmax + off))
    # 手动调一次 recompute，看它算出什么
    st2 = dict(st)
    val = plock.recompute_ref_depth(sc, st2, cd.name)
    print("     手动 recompute ⇒ best=%.6f   (原值 %.6f)" % (val, st.get("ref_depth", 0)))
    return st.get("ref_depth", 0), val


print("=" * 96)
print("Setup：A 深度8（最深，=ref）/ B 深度6")
print("=" * 96)
sc, cam, cd, A, B = build()
plock.lock_group(sc, cam)
dump("锁定后", sc, cd, A, B)

cam.location.x = 1.2
step(sc)
dump("移到 1.2", sc, cd, A, B)

A.location.z += 1.5          # 拖 A 推远 1.5（深度 8 → 6.5 仍最深）
step(sc)
r_after_drag, calc_after_drag = dump("拖 A +1.5 后", sc, cd, A, B)

cam.location.x = 2.2
step(sc)
dump("移到 2.2", sc, cd, A, B)

print()
print("=" * 96)
print("分析")
print("=" * 96)
print("  拖 A 之后：state 里的 ref = %.6f" % r_after_drag)
print("  但用当前几何重算 = %.6f" % calc_after_drag)
if abs(r_after_drag - calc_after_drag) > 1e-6:
    print("  ⇒ 两者不一致！说明 adapt_object 改写过 base 属性，")
    print("     recompute 的 `max(base_d) + offset` 把位移算重了。")
else:
    print("  ⇒ 两者一致，问题不在这里")
print("DEEP_DONE")
