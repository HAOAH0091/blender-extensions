"""验证解锁修复：
A. 解锁后组不再 patch（投射效果恢复）
B. 解锁后 B 换同样材质，投影正常
C. 解锁 → 相机移动 → 重新锁定 → 投影正确（不沿用旧坐标）
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_v"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])

    def grid(name, x, w=0.8):
        mesh = bpy.data.meshes.new(name)
        ns = 2
        verts, faces = [], []
        for iy in range(ns+1):
            for ix in range(ns+1):
                verts.append((x-w+2*w*ix/ns, -1+2*iy/ns, 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy*(ns+1)+ix
                faces.append((a, a+1, a+ns+2, a+ns+1))
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        scene.collection.objects.link(ob)
        ob.data.materials.append(m)
        return ob
    A = grid("GridA", -1.2); B = grid("GridB", 1.2)
    NG.create_uv_adjust_node_group(scene, cam, A)
    return scene, cam, cd, m, A, B


def patched(cd):
    ng = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    return ng is not None and ng.get(PL.PATCH_KEY) is not None

def campos_val(o, cd):
    a = o.data.attributes.get(PL._campos_attr_name(cd.name))
    if a is None: return "无"
    if len(a.data) == 0: return "空"
    v = tuple(round(x,3) for x in a.data[0].vector)
    if all(abs(x) < 1e-9 for x in v): return "%s 全零【坏】" % (v,)
    return str(v)

print("="*78)
print("A. 解锁后是否恢复实时投影")
print("="*78)
scene, cam, cd, m, A, B = build()
PL.lock_group(scene, cam)
print("  锁定后 patch=%s  A.campos=%s" % (patched(cd), campos_val(A, cd)))
r = PL.unlock_group(scene, cam)
print("  unlock:", r["message"])
print("  解锁后 patch=%s  (%s)" % (patched(cd), "已恢复实时" if not patched(cd) else "仍冻结=没修好"))
print("  解锁后 A.campos=%s  (%s)" % (campos_val(A, cd), "已清理" if campos_val(A,cd)=="无" else "有残留"))

print("\n" + "="*78)
print("B. 解锁后 B 换同样材质")
print("="*78)
B.data.materials.clear(); B.data.materials.append(m)
print("  B 换材质后 patch=%s" % patched(cd))
print("  B.campos=%s  (实时链路不需要它)" % campos_val(B, cd))
mwi = cam.matrix_world.inverted()
uvB = np.array([tuple(mwi @ (B.matrix_world @ v.co)) for v in B.data.vertices])
print("  B 首顶点相机空间=%s  (非全零=投影正常)" %
      (tuple(round(x,3) for x in uvB[0]),))
print("  >>> B 投影: %s" % ("正常(实时)" if not patched(cd) else "未知"))

print("\n" + "="*78)
print("C. 解锁 → 移动相机 → 重新锁定 → 投影是否按新视角正确")
print("="*78)
scene, cam, cd, m, A, B = build()
PL.lock_group(scene, cam)
PL.unlock_group(scene, cam)
print("  解锁后 campos=%s" % campos_val(A, cd))
cam.location = (1.5, 0, 5.0)
bpy.context.view_layer.update()
print("  相机移到 x=1.5")
r = PL.lock_group(scene, cam)
print("  重新锁定:", r["message"])
print("  重锁后 patch=%s" % patched(cd))
print("  重锁后 campos=%s" % campos_val(A, cd))
# 期望：campos 反映新相机位置的相机空间坐标（x 会因相机右移而变小）
mwi = cam.matrix_world.inverted()
expect = mwi @ (A.matrix_world @ A.data.vertices[0].co)
a = A.data.attributes.get(PL._campos_attr_name(cd.name))
got = tuple(a.data[0].vector) if a else None
print("  期望首顶点(新视角相机空间)=%s" % (tuple(round(x,3) for x in expect),))
print("  实际 campos[0]            =%s" % (tuple(round(x,3) for x in got) if got else None,))
if got:
    err = max(abs(got[i]-expect[i]) for i in range(3))
    print("  >>> 误差 %.6f  (%s)" % (err, "按新视角正确采集" if err < 1e-4 else "沿用了旧坐标=错位"))
