"""验证：把 unlock 改成「unpatch + 还原几何」后
问题1（解锁后投射效果消失）与问题2（B 换材质投影坏）是否同时解决
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_fix12"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])

    def grid(name, x, w=0.8):
        mesh = bpy.data.meshes.new(name)
        ns = 2
        verts, faces = [], []
        for iy in range(ns+1):
            for ix in range(ns+1):
                verts.append((x-w+2*w*ix/ns, -1+2*iy/ns, 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy*(ns+1)+ix
                faces.append((a, a+1, a+ns+2, a+ns+1))
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        scene.collection.objects.link(ob)
        ob.data.materials.append(m)
        return ob

    A = grid("GridA", -1.2)
    B = grid("GridB", 1.2)
    NG.create_uv_adjust_node_group(scene, cam, A)
    return scene, cam, cd, m, A, B


def uv_of(cam, obj):
    ng = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cam.data.name)
    patched = ng is not None and ng.get(PL.PATCH_KEY) is not None
    if patched:
        a = obj.data.attributes.get(PL._campos_attr_name(cam.data.name))
        if a is not None and len(a.data) == len(obj.data.vertices):
            src = np.array([tuple(a.data[i].vector) for i in range(len(a.data))])
        else:
            src = np.zeros((len(obj.data.vertices), 3))
    else:
        mwi = cam.matrix_world.inverted()
        src = np.array([tuple(mwi @ (obj.matrix_world @ v.co)) for v in obj.data.vertices])
    z = src[:, 2]
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.stack([src[:, 0]/z, src[:, 1]/z], axis=1), patched


# ── 修补 unlock：unpatch + 还原几何 ──
_orig_unlock = PL.unlock_group
def unlock_fixed(scene, camera):
    res = _orig_unlock(scene, camera)
    if not res.get("success"):
        return res
    try:
        PL.unpatch_camera_project_group(camera.data.name)
    except Exception as e:
        print("     unpatch 失败:", e)
    res["message"] = "已解锁并恢复实时投影"
    return res
PL.unlock_group = unlock_fixed


print("="*80)
print("【问题1】解锁后投射效果")
print("="*80)
scene, cam, cd, m, A, B = build()
PL.lock_group(scene, cam)
cd.lens = 85.0
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
uv_lock, p = uv_of(cam, A)
print("  锁定+变焦: patch=%s UV[0]=(%+.5f,%+.5f)" % (p, uv_lock[0][0], uv_lock[0][1]))

print("  ", PL.unlock_group(scene, cam)["message"])
uv_u0, p2 = uv_of(cam, A)
print("  解锁后: patch=%s UV[0]=(%+.5f,%+.5f)" % (p2, uv_u0[0][0], uv_u0[0][1]))
cd.lens = 50.0
bpy.context.view_layer.update()
uv_u1, _ = uv_of(cam, A)
d = float(np.abs(uv_u1-uv_u0).max())
print("  解锁后变焦 85->50，UV 变化量: %.6f  (%s)" % (
    d, "有投射效果=修复" if d > 1e-6 else "仍冻结=没修好"))

print("\n" + "="*80)
print("【问题2】解锁后 B 换同样材质")
print("="*80)
scene, cam, cd, m, A, B = build()
PL.lock_group(scene, cam)
PL.unlock_group(scene, cam)
print("  解锁后 patch=%s" % uv_of(cam, A)[1])

B.data.materials.clear()
B.data.materials.append(m)
print("  B 换上同一投影材质")
uvb0, p3 = uv_of(cam, B)
print("  patch=%s  B UV[0]=(%+.5f,%+.5f)" % (p3, uvb0[0][0], uvb0[0][1]))
zero = "全零=B坏" if abs(uvb0[0][0]) < 1e-9 and abs(uvb0[0][1]) < 1e-9 else "正常"
print("  >>> B 投影: %s" % zero)
cam.location = (1.0, 0, 5.0)
bpy.context.view_layer.update()
uvb1, _ = uv_of(cam, B)
print("  移相机后 B UV 变化 %.6f (%s)" % (
    float(np.abs(uvb1-uvb0).max()),
    "有投射效果=修复" if np.abs(uvb1-uvb0).max() > 1e-6 else "冻结/坏"))
