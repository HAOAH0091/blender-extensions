"""审查E-10：真实链路测量（handler 真的挂在 depsgraph 上）

前面几个脚本都是「手工调用 handler」，不含它改完顶点后 Blender 的后续求值。
这里 register_handlers() 后只推相机、让 Blender 自己派发，量**真实每帧墙钟时间**；
同时统计 apply_user_move 是否在 handler 内部触发嵌套 view_layer.update()。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

NEST = {"update_calls": 0, "handler_calls": 0}
_orig_upd = bpy.context.view_layer.update if False else None


def build(nmesh):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 14)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("ProjMat")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns, H = 2, 0.4
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    cols = max(1, int(nmesh ** 0.5))
    for i in range(nmesh):
        me = bpy.data.meshes.new("G%d" % i)
        me.from_pydata(verts, [], faces)
        me.update()
        o = bpy.data.objects.new("Grid%d" % i, me)
        sc.collection.objects.link(o)
        o.location = ((i % cols) * 0.9 - cols * 0.45, (i // cols) * 0.9, 0.0)
        o.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cd.name),
                                 "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd


# 统计「handler 内部又调 view_layer.update()」的次数
_au = plock.apply_user_move


def au(obj, camera, view_now):
    r = _au(obj, camera, view_now)
    if r:
        NEST["update_calls"] += 1
    return r


plock.apply_user_move = au
plock.register_handlers()

print("%-8s %-14s %-16s %-16s %-12s" % (
    "网格数", "空闲帧(真实)_ms", "推近相机帧_ms", "横向拖动画框_ms", "handler/帧"))
for nmesh in (200, 1000, 3000):
    sc, cam, cd = build(nmesh)
    t0 = time.perf_counter()
    res = plock.lock_group(sc, cam)
    t_lock = (time.perf_counter() - t0) * 1000.0
    bpy.context.view_layer.update()
    plock._last_view.clear()
    bpy.context.view_layer.update()

    # 真实每帧：什么都不改，只让 depsgraph 跑一次
    idle = []
    for _ in range(5):
        t0 = time.perf_counter()
        bpy.context.view_layer.update()
        idle.append((time.perf_counter() - t0) * 1000.0)

    move = []
    for _ in range(8):
        cam.location.x += 0.01
        t0 = time.perf_counter()
        bpy.context.view_layer.update()
        move.append((time.perf_counter() - t0) * 1000.0)

    # 横向拖动（k==1 分支 → 内部会调 view_layer.update()）
    target = bpy.data.objects["Grid0"]
    NEST["update_calls"] = 0
    drag = []
    for _ in range(6):
        target.location.x += 0.02
        t0 = time.perf_counter()
        bpy.context.view_layer.update()
        drag.append((time.perf_counter() - t0) * 1000.0)

    print("%-8d %-14.1f %-16.1f %-16.1f 嵌套update=%d次" % (
        nmesh, sum(idle) / len(idle), sum(move) / len(move),
        sum(drag) / len(drag), NEST["update_calls"]))
    plock.unregister_handlers()
    sys.stdout.flush()
