"""审查项 5 / 6 / 7：用户自建同名投影组、组内缺 TexCoord、多个 TexCoord、
锁定期间编辑组（加接线）。判据：真实 UV 场 + 组结构事实 + patch 返回值。
"""
import bpy
import os
import sys
import json

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
SCALE = 0.1


def snap(ob, tag):
    C.show(ob)
    uv, mask, sat = C.render_uv_masked(scale=SCALE, tag=tag)
    s = C.stats_masked(uv, mask)
    if s is None:
        print("    %-22s 空" % tag)
        return None
    print("    %-22s x极差=%.4f y极差=%.4f 均值=(%+.3f,%+.3f)"
          % (tag, s[0], s[1], s[3], s[4]))
    return s


def base_scene(with_group=True):
    sc = C.reset()
    cam, cd = C.new_cam(sc)
    if with_group:
        grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
        mat, gn = C.probe_mat("Probe", grp, scale=SCALE)
        A = C.new_grid("A")
        A.data.materials.append(mat)
        C.uv_adjust_group(A, cd)
        bpy.context.view_layer.update()
        return sc, cam, cd, grp, mat, gn, A
    return sc, cam, cd, None, None, None, None


# ═══════ P1（项6）：用户自建的同名投影组 ═══════
print("\n=== P1：组名相同但内容是用户自己搭的 ===")
sc, cam, cd, grp, mat, gn, A = base_scene()
# 把自动生成的组改成「用户自己的组」：清空后只留一个自定义节点 + 一个 TexCoord
for n in list(grp.nodes):
    grp.nodes.remove(n)
tc = grp.nodes.new("ShaderNodeTexCoord")
tc.object = cam
mine = grp.nodes.new("ShaderNodeValue")
mine.name = "USER CUSTOM NODE"
mine.label = "我的自定义节点"
mine.outputs[0].default_value = 7.0
oin = grp.nodes.new("NodeGroupInput")
oout = grp.nodes.new("NodeGroupOutput")
grp.links.new(tc.outputs["Object"], oout.inputs["Vector"])
print("  锁定前: 节点数=%d 自定义节点在场=%s" % (len(grp.nodes), grp.nodes.get("USER CUSTOM NODE") is not None))
r = plock.lock_group(sc, cam)
print("  锁定: success=%s frozen=%s | %s" % (r["success"], r.get("frozen"), r["message"][:60]))
print("  锁定后: 节点数=%d 自定义节点在场=%s" % (len(grp.nodes), grp.nodes.get("USER CUSTOM NODE") is not None))
C.report("P1 用户自建的组内容被保留", grp.nodes.get("USER CUSTOM NODE") is not None,
         "锁定前后节点数 %d→%d（自定义节点被清空重建? %s）"
         % (4, len(grp.nodes), grp.nodes.get("USER CUSTOM NODE") is None))

# ═══════ P2（项6b）：组里没有 TexCoord（或它的输出没接线）→ 假成功 ═══════
print("\n=== P2：投影组里的 TexCoord 输出没有接线（用户改过接线）===")
sc, cam, cd, grp, mat, gn, A = base_scene()
for lk in list(grp.links):
    if lk.from_node.type == "TEX_COORD":
        grp.links.remove(lk)          # 用户把 UV 源断开了（改接线时遗留）
print("  patch_camera_project_group() 直接返回: %s" % (plock.patch_camera_project_group(cd.name),))
s0 = snap(A, "锁定前")
r = plock.lock_group(sc, cam)
print("  锁定: success=%s frozen=%s is_patched=%s" % (
    r["success"], r.get("frozen"), plock.is_patched(cd.name)))
print("  msg: %s" % r["message"][:80])
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s1 = snap(A, "锁定中(被破坏的组)")
print("  期间 UV 均值变化: (%.3f,%.3f) → (%.3f,%.3f)" % (s0[3], s0[4], s1[3], s1[4]))
C.report("P2 组内无可用 TexCoord 时锁定会报失败", not r.get("frozen"), "frozen=%s" % r.get("frozen"))
C.report("P2 该情况下画面仍是图案", s1 is not None and s1[0] > 0.05, "x极差=%.4f" % (0 if s1 is None else s1[0]))

# ═══════ P3（项7）：组里有两个 TexCoord（都绑相机）═══════
print("\n=== P3：组里有两个 TexCoord 节点（都 object=相机）===")
sc, cam, cd, grp, mat, gn, A = base_scene()
tc2 = grp.nodes.new("ShaderNodeTexCoord")
tc2.object = cam
tc2.label = "我的第二个 TexCoord"
dummy = grp.nodes.new("ShaderNodeVectorMath")
dummy.name = "USER BRANCH"
grp.links.new(tc2.outputs["Object"], dummy.inputs[0])   # 用户自己的支路
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
info = json.loads(grp.get(plock.PATCH_KEY) or "{}")
print("  锁定: frozen=%s ; patch 选中的 TexCoord 节点 = %r（原节点=%r，新节点=%r）"
      % (r.get("frozen"), info.get("tc"), "Texture Coordinate", tc2.name))
main_tc = None
for n in grp.nodes:
    if n.type == "TEX_COORD" and n is not tc2:
        main_tc = n
print("  主链 TexCoord(Object) 的连线数=%s ; 冻结 Attribute 节点在场=%s"
      % (len(main_tc.outputs["Object"].links), grp.nodes.get(plock.ATTR_NODE_NAME) is not None))
s0 = snap(A, "锁定中")
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s1 = snap(A, "移相机后")
moved = float(abs(s1[3] - s0[3]))
C.report("P3 两个 TexCoord 时主链仍被冻结", moved < 0.02, "UV 均值漂移=%.4f" % moved)

# ═══════ P4（项5）：锁定期间用户给组加接线，解锁后是否被删 ═══════
print("\n=== P4：锁定期间用户从 TexCoord.Object 拉一条新支路 ===")
sc, cam, cd, grp, mat, gn, A = base_scene()
plock.lock_group(sc, cam)
main_tc = [n for n in grp.nodes if n.type == "TEX_COORD"][0]
mynode = grp.nodes.new("ShaderNodeVectorMath")
mynode.name = "USER ADDED DURING LOCK"
grp.links.new(main_tc.outputs["Object"], mynode.inputs[0])
print("  锁定期间新增支路连线数=%d" % len(mynode.inputs[0].links))
plock.unlock_group(sc, cam)
print("  解锁后该支路连线数=%d（0 ⇒ 用户的接线被 unpatch 删掉）" % len(mynode.inputs[0].links))
C.report("P4 用户的接线在解锁后保留", len(mynode.inputs[0].links) > 0,
         "连线数 1→%d" % len(mynode.inputs[0].links))

print("\nRD_USERGROUP_DONE")
