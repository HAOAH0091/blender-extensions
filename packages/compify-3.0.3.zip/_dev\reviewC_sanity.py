"""审查 C · 基准自检 —— 证明夹具与尺子是对的，再谈 bug。

三条判据（后面所有场景都用它们）：
  align  未锁定时 真渲染探针 UV == Blender 自己的 world_to_camera_view
  glue   锁定期间 同一批顶点的探针 UV 不变（图案粘在网格表面；网格自身会移动，
         所以不能拿整图比）
  jump   解锁瞬间 整图逐像素一致
  slide  解锁后移相机，同一批顶点的探针 UV 必须变化（图案恢复实时）
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy

print("### 基准 A：透视 50mm / 1:1 / 无 shift · 未锁定 ###")
sc, cam, cd, mat, ob = build(shape="平面", cam_loc=(0, 0, 5), cam_rot=(0, 0, 0))
p0 = render_uv("base"); dump("no-lock", p0)
mx, mn, n = align_err(sc, cam, ob, p0)
print("  对齐误差 max=%.3e mean=%.3e (n=%d 顶点)" % (mx, mn, n))
chk("基准 A：图案 == 相机投影", mx < 5e-3, "max=%.2e (n=%d)" % (mx, n))

print("\n### 基准 B：锁定 → 平移 → 解锁 → 再移 ###")
plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pL = render_uv("lock"); dump("locked", pL)
iL, uvL, camL = uv_at_verts(sc, cam, ob, pL)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pL2 = render_uv("lock2"); dump("locked+moved", pL2)
iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
same = np.intersect1d(iL, iL2)
m1 = np.isin(iL, same); m2 = np.isin(iL2, same)
dglue = float(np.abs(uvL[m1] - uvL2[m2]).max()) if len(same) else float("nan")
print("  glue: 顶点处图案 UV 变化 max=%.3e (n=%d)" % (dglue, len(same)))
chk("基准 B：锁定期间图案粘住网格", dglue < 5e-3, "max=%.2e n=%d" % (dglue, len(same)))

plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
pU = render_uv("ul"); dump("unlocked", pU)
dj, dx, npix = diff(pL2, pU)
print("  jump: 整图变化 mean=%.3e max=%.3e (公共像素 %d)" % (dj, dx, npix))
chk("基准 B：平移解锁不跳", dj < 2e-3, "mean=%.2e n=%d" % (dj, npix))
print("  落实参数 S/C =", nodes_sc(cd))

iU, uvU, _ = uv_at_verts(sc, cam, ob, pU)
cam.location.x += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pM = render_uv("move"); dump("unlocked+moved", pM)
iM, uvM, _ = uv_at_verts(sc, cam, ob, pM)
sm = np.intersect1d(iU, iM)
dsl = float(np.abs(uvU[np.isin(iU, sm)] - uvM[np.isin(iM, sm)]).max()) if len(sm) else float("nan")
print("  slide: 顶点处图案 UV 变化 max=%.3e (n=%d)" % (dsl, len(sm)))
chk("基准 B：解锁后图案重新滑动", dsl > 5e-3, "max=%.3e n=%d" % (dsl, len(sm)))

print("\n### 基准 C：尺子的分辨率 —— 注入 0.004 UV 偏移 ###")
nt = bpy.data.materials["Probe"].node_tree
comb = nt.nodes["ProbeComb"]; emi = nt.nodes["ProbeEmi"]
addn = nt.nodes.new("ShaderNodeVectorMath"); addn.operation = "ADD"
addn.inputs[1].default_value = (0.001, 0.0, 0.0)   # 颜色 +0.001 = UV +0.004
nt.links.new(comb.outputs["Vector"], addn.inputs[0])
nt.links.new(addn.outputs["Vector"], emi.inputs["Color"])
pS = render_uv("shift"); dump("shift+0.004", pS)
iS, uvS, _ = uv_at_verts(sc, cam, ob, pS)
ss = np.intersect1d(iM, iS)
dv = float(np.abs(uvM[np.isin(iM, ss)] - uvS[np.isin(iS, ss)]).max()) if len(ss) else float("nan")
dsm2, _, _ = diff(pM, pS)
print("  注入 0.004 → 整图差 %.5f / 顶点处 UV 差 %.5f" % (dsm2, dv))
chk("基准 C：尺子能分辨 0.004 UV", abs(dv - 0.004) < 0.0015, "测得 %.4f" % dv)

report("审查 C 基准自检")
