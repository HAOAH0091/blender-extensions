"""审查 A-6：锁定中保存 .blend 再重新打开，状态是否恢复、解锁是否正常
   审查 A-7：锁定中切到别的场景 / 新建场景 / 复制场景，状态是否还在
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock
TMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_ra_save.blend")

L.report("A-6 锁定中保存 → 重新打开 → 解锁 / 重置")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
A.name = "Grid0"
cam.name = "Cam"
orig = L.lverts(A).copy()
plock.lock_group(sc, cam)
cam.rotation_euler.y = 0.35
cam.data.lens = 70.0
L.run_h(sc, times=2)
u_locked = L.uvimg("sv")
geo_locked = float(np.abs(L.lverts(A) - orig).max())
S0, C0 = L.node_sc(cam)
key0, st0, _ = plock._resolve_state(sc, cam)
print("  保存前：is_locked=%s 几何Δ=%.3f 冻结坐标=%s S=%.4f C=(%+.4f,%+.4f)"
      % (plock.is_locked(sc, cam), geo_locked, L.campos_ok(A, cam), S0, C0[0], C0[1]))

bpy.ops.wm.save_as_mainfile(filepath=TMP)
# 模拟「重新打开」：真实里插件会重新注册 handler、模块缓存清空
plock._last_view.clear()
plock._base_cache.clear()
bpy.ops.wm.open_mainfile(filepath=TMP)
sc = bpy.context.scene
cam = bpy.data.objects.get("Cam")
A = bpy.data.objects.get("Grid0")
cd = cam.data
sc.camera = cam
bpy.context.view_layer.update()
plock.register_handlers()
key1, st1, _ = plock._resolve_state(sc, cam)
print("  重开后：is_locked=%s 冻结坐标=%s 几何Δ=%.3f S=%s C=%s"
      % (plock.is_locked(sc, cam), L.campos_ok(A, cam),
         float(np.abs(L.lverts(A) - orig).max()),
         L.node_sc(cam)[0], L.node_sc(cam)[1]))
L.chk("重开后仍处于锁定态", bool(plock.is_locked(sc, cam)), "is_locked=%s" % plock.is_locked(sc, cam))
L.chk("重开后冻结坐标还在", L.campos_ok(A, cam), "campos=%s" % L.campos_ok(A, cam))
L.chk("重开后 C+k 仍是恒等（锁定中）", abs(L.node_sc(cam)[0] - 1) < 1e-9,
      "S=%s" % (L.node_sc(cam)[0],))

# 重开后继续动相机：图案必须仍冻结
L.run_h(sc, times=2)


def frozen(ob):
    a = ob.data.attributes.get(plock._campos_attr_name(cam.data.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([tuple(a.data[i].vector) for i in range(len(a.data))])


f0 = frozen(A)
cam.location.x += 0.5
L.run_h(sc, times=2)
f1 = frozen(A)
d = float(np.abs(f1 - f0).max()) if (f0 is not None and f1 is not None) else -1
L.chk("重开后锁定仍有效（动相机冻结坐标不变）", d >= 0 and d < 1e-6, "Δ=%.2e" % d)
u_after_move = L.uvimg("sv")
r = plock.unlock_group(sc, cam)
u_ul = L.uvimg("sv")
L.chk("重开后解锁不跳", L.uvd(u_ul, u_after_move) < 2e-3,
      "Δ=%.6f %s" % (L.uvd(u_ul, u_after_move), r.get("message", "")[:34]))
S1, C1 = L.node_sc(cam)
print("  重开后解锁：S=%.4f C=(%+.4f,%+.4f)" % (S1, C1[0], C1[1]))
r = plock.reset_group(sc, cam)
geo = float(np.abs(L.lverts(A) - orig).max())
L.chk("重开后重置回到原形", r.get("success") and geo < 1e-6,
      "Δ=%.2e (%s)" % (geo, r.get("message", "")[:40]))
plock.unregister_handlers()
if os.path.exists(TMP):
    os.remove(TMP)

print()
L.report("A-7a 锁定中新建场景 → 切过去 → 切回来")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
A.name = "Grid0"
orig = L.lverts(A).copy()
plock.lock_group(sc, cam)
cam.rotation_euler.y = 0.3
L.run_h(sc, times=2)
geo_locked = float(np.abs(L.lverts(A) - orig).max())
scA_name = sc.name
bpy.ops.scene.new(type="EMPTY")
scB = bpy.context.scene
print("  新场景=%s 当前场景=%s A 的记录数=%d"
      % (scB.name, bpy.context.scene.name, len(plock.load_groups(bpy.data.scenes[scA_name]))))
bpy.context.window.scene = bpy.data.scenes[scA_name]
sc = bpy.context.scene
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
cam.location.x += 0.4
L.run_h(sc, times=2)
print("  切回 A 后：is_locked=%s 几何Δ=%.3f 冻结坐标=%s"
      % (plock.is_locked(sc, cam), float(np.abs(L.lverts(A) - orig).max()),
         L.campos_ok(A, cam)))
L.chk("切场景回来后仍锁定且冻结坐标在",
      bool(plock.is_locked(sc, cam)) and L.campos_ok(A, cam),
      "is_locked=%s campos=%s" % (plock.is_locked(sc, cam), L.campos_ok(A, cam)))
L.chk("切场景回来后解锁正常", plock.unlock_group(sc, cam).get("success"), "")
plock.reset_group(sc, cam)

print()
L.report("A-7b 锁定中【复制场景】(LINK_COPY)：两条记录共用一个相机，会互相加码吗")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
plock.lock_group(sc, cam)
scA = bpy.context.scene
scA.name = "A"
bpy.ops.scene.new(type="LINK_COPY")
scB = bpy.context.scene
scB.name = "B"
print("  A 记录=%d B 记录=%d（相机对象 A/B 共用？%s）"
      % (len(plock.load_groups(bpy.data.scenes["A"])),
         len(plock.load_groups(bpy.data.scenes["B"])),
         bpy.data.scenes["A"].objects.get("Cam") is bpy.data.scenes["B"].objects.get("Cam")))
z0 = cam.location.z
cam.data.lens = 85.0
bpy.context.window.scene = scB
L.run_h(scB, times=2)
zB = cam.location.z
bpy.context.window.scene = scA
L.run_h(scA, times=2)
zA = cam.location.z
print("  变焦 50→85 后相机 z：初始 %.3f → 场景B 跑一轮后 %.3f → 再切回A跑一轮后 %.3f"
      % (z0, zB, zA))
L.chk("复制场景下标量变焦补偿只施加一次（相机不被推两遍）",
      abs(zA - zB) < 1e-6,
      "切场景后额外位移=%.3f（单次应为 %.3f）" % (zA - zB, zB - z0))
L.summary()
