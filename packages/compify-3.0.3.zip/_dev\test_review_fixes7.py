"""回归网（第八轮独立审查）：盯 🔴-1 / 🔴-2 / 🟡-1 / 🟡-2。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL。
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-56s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    plock._proj_cache.clear()
    return bpy.context.scene


def mkcam(sc, name="Cam", loc=(0.0, 0.0, 10.0)):
    cd = bpy.data.cameras.new(name); cd.lens = 50.0; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def mkobjs(sc, cam, n=3, prefix="P"):
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i in range(n):
        bpy.ops.mesh.primitive_plane_add(size=4.0, location=(0.0, 0.0, -float(i) * 2))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out, mat


def run(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def loc(ob):
    return [tuple(v.co) for v in ob.data.vertices]


def md(a, b):
    return max(max(abs(x[i] - y[i]) for i in range(3)) for x, y in zip(a, b)) if a and b else 0.0


# ═══ 🔴-1：相机数据块改名 → 不得误报孤儿（误报会导致救命通道反噬）═══
print("=" * 72)
print("🔴-1  相机数据块改名：不得误报孤儿（点还原会毁掉健康锁定）")
for tag, action in (("改数据块名", lambda c: setattr(c.data, "name", "Renamed")),
                    ("改对象名", lambda c: setattr(c, "name", "CamObjRenamed")),
                    ("改 mesh 数据名", None)):
    sc = fresh()
    cam = mkcam(sc); sc.camera = cam
    objs, _ = mkobjs(sc, cam, 3, "A")
    plock.lock_group(sc, cam)
    if action is not None:
        action(cam)
    else:
        objs[0].data.name = "MeshRenamed"
    bpy.context.view_layer.update()
    orph = plock.find_orphan_locks(sc)
    print("   [%s] orphan = %d" % (tag, len(orph)))
    chk("🔴-1 %s 后不误报孤儿" % tag, len(orph) == 0, "误报 %d" % len(orph))

# 若真误报，点还原会不会毁掉锁定
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs, _ = mkobjs(sc, cam, 3, "B")
plock.lock_group(sc, cam)
cam.data.name = "Renamed2"
bpy.context.view_layer.update()
plock.reset_orphan_locks(sc)              # 即使误点
bpy.context.view_layer.update()
p0 = loc(objs[0])
cam.location.x = 3.0
run(sc)
chk("🔴-1b 改名后即使误点「还原」，锁定也不被毁",
    md(p0, loc(objs[0])) > 1e-6 and objs[0].get(plock.OBJ_CAM_KEY) is not None,
    "几何变化 %.4f OBJ_CAM=%s" % (md(p0, loc(objs[0])), objs[0].get(plock.OBJ_CAM_KEY)))

# ═══ 🔴-2：reset_orphan_locks 不得连带删其它相机 ═══
print()
print("=" * 72)
print("🔴-2  reset_orphan_locks 只动真孤儿，不连带删其它相机")
sc = fresh()
cA = mkcam(sc, "CamA"); sc.camera = cA
cB = mkcam(sc, "CamB")
mkobjs(sc, cA, 1, "XA")
mkobjs(sc, cB, 1, "YB")
plock.lock_group(sc, cA)
plock.lock_group(sc, cB)
_A_NAME = cA.data.name                   # ★ 删对象后 cA.data 会变 None，先存名字
_B_NAME = cB.data.name
sc.collection.objects.unlink(cB)          # ★ CamB 暂时不在本场景
bpy.context.view_layer.update()
bpy.data.objects.remove(cA, do_unlink=True)   # 制造真孤儿
bpy.context.view_layer.update()
orph = plock.find_orphan_locks(sc)
print("   孤儿 =", [(o.name, w) for o, w in orph])
r = plock.reset_orphan_locks(sc)
bpy.context.view_layer.update()
gs = plock.load_groups(sc)
print("   还原后 groups =", sorted(gs.keys()), "| is_patched(B) =", plock.is_patched(cB.data.name))
chk("🔴-2a CamB 记录仍在", _B_NAME in gs, "groups=%s" % sorted(gs.keys()))
chk("🔴-2b CamB 补丁仍在", plock.is_patched(_B_NAME))
chk("🔴-2c 真孤儿的记录被清掉", _A_NAME not in gs, "groups=%s" % sorted(gs.keys()))

# 真孤儿仍要能被还原成原形
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs, _ = mkobjs(sc, cam, 3, "C")
orig = [loc(o) for o in objs]
plock.lock_group(sc, cam)
cam.data.lens = 100.0
run(sc)
cam.data = bpy.data.cameras.new("Swapped")
bpy.context.view_layer.update()
chk("🔴-2d 换数据块仍判为孤儿", len(plock.find_orphan_locks(sc)) >= 3,
    "%d 个" % len(plock.find_orphan_locks(sc)))
plock.reset_orphan_locks(sc)
bpy.context.view_layer.update()
chk("🔴-2e 孤儿仍能还原成原形",
    max(md(a, b) for a, b in zip(orig, [loc(o) for o in objs])) < 1e-4)
chk("🔴-2f 还原后记录被清掉", len(plock.load_groups(sc)) == 0,
    str(list(plock.load_groups(sc).keys())))

# ═══ 🟡-1：给已存在对象手工接入投影 → 有限帧内必须补上冻结坐标 ═══
print()
print("=" * 72)
print("🟡-1  给【已存在】对象手工接入投影：有限帧内补上冻结坐标")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
oX, _ = mkobjs(sc, cam, 1, "XX")
yMat = bpy.data.materials.new("YMat"); yMat.use_nodes = True
bpy.ops.mesh.primitive_plane_add(size=4.0, location=(1.0, 0.0, -1.0))
Y = bpy.context.active_object; Y.name = "Y"
Y.data.materials.append(yMat)
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
run(sc)                                   # 填缓存
nt = yMat.node_tree; nt.nodes.clear()
g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
oo = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(g.outputs["Vector"], oo.inputs["Surface"])
bpy.context.view_layer.update()
frames_to_fix = None
for i in range(24):
    cam.location.x = 0.1 * (i + 1)
    run(sc)
    if plock._campos_is_valid(Y, cam.data.name):
        frames_to_fix = i + 1
        break
print("   第 %s 轮拿到冻结坐标" % frames_to_fix)
chk("🟡-1a 手工接入后有限帧内被补上", frames_to_fix is not None,
    "24 轮内未补上" if frames_to_fix is None else "第 %d 轮" % frames_to_fix)

# ═══ 🟡-2：锁定后 Alt+D / 加修改器 → 降级必须被 UI 暴露 ═══
print()
print("=" * 72)
print("🟡-2  锁定后 Alt+D / 加修改器：降级必须暴露（不能静默）")
for tag, degrade in (("Alt+D 共享 mesh", "altd"), ("加修改器", "mod")):
    sc = fresh()
    cam = mkcam(sc); sc.camera = cam
    objs, _ = mkobjs(sc, cam, 4, "D%d" % (0 if degrade == "altd" else 1))
    plock.lock_group(sc, cam)
    # ⚠️ 降级【最深】那层（= 基准层，k=1，本来就不动），
    #    然后检查【最浅】那层（k=d/ref ≠ 1，一定会动）——
    #    否则会掉进"基准层陷阱"：拿锚点当尺子，量出 0 就误判成"没适配"。
    _deg_idx = len(objs) - 1
    if degrade == "altd":
        dup = objs[_deg_idx].copy()
        sc.collection.objects.link(dup)
    else:
        objs[_deg_idx].modifiers.new("SUBSURF", "SUBSURF")
    bpy.context.view_layer.update()
    stt = plock.lock_status(sc, cam)
    print("   [%s] lock_status.degraded = %s" % (tag, stt.get("degraded")))
    chk("🟡-2 %s 后 degraded 被报出" % tag, stt.get("degraded", 0) >= 1,
        "degraded=%s" % stt.get("degraded"))
    # 非降级、且非基准层的对象仍须正常适配
    p0 = loc(objs[0])
    cam.location.x = 2.0
    run(sc)
    chk("🟡-2 %s 时其它对象仍正常适配" % tag, md(p0, loc(objs[0])) > 1e-6,
        "变化 %.6f（非基准层，应 > 0）" % md(p0, loc(objs[0])))

# 反例：健康场景 degraded 必须为 0（否则 UI 会常亮 ⚠）
sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, 3, "E")
plock.lock_group(sc, cam)
stt = plock.lock_status(sc, cam)
chk("🟡-2d 健康场景 degraded = 0（不误亮 ⚠）", stt.get("degraded", -1) == 0,
    "degraded=%s" % stt.get("degraded"))

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX7_DONE")
