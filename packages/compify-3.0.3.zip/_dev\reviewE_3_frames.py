"""审查E-3：锁定状态下持续移动相机 300 帧 —— 总耗时 / 每帧均值 / 是否越跑越慢

同时打印模块级缓存与 scene 存档体积，看是否有线性增长。
"""
import bpy, sys, os, time, json
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

N = 200
FRAMES = 300


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 12)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("ProjMat")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns, H = 2, 0.5
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    cols = int(N ** 0.5)
    for i in range(N):
        mesh = bpy.data.meshes.new("G%d" % i)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new("Grid%d" % i, mesh)
        sc.collection.objects.link(ob)
        ob.location = ((i % cols) * 1.2 - cols * 0.6, (i // cols) * 1.2 - cols * 0.6, 0.0)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd


sc, cam, cd = build()
plock._proj_cache.clear()
plock._base_cache.clear()
plock._last_view.clear()
plock.lock_group(sc, cam)

ts = []
snaps = []
t_all0 = time.perf_counter()
for f in range(FRAMES):
    cam.location.x += 0.01
    cam.rotation_euler.z += 0.0005
    bpy.context.view_layer.update()
    t0 = time.perf_counter()
    plock.parallax_lock_update_handler(sc)
    ts.append((time.perf_counter() - t0) * 1000.0)
    if f % 60 == 0:
        snaps.append((f, len(plock._last_view), len(plock._proj_cache),
                      len(plock._base_cache), len(sc.get(plock.GROUPS_KEY) or "")))
t_all = (time.perf_counter() - t_all0) * 1000.0

a = ts[:50]
b = ts[-50:]
print("帧数=%d 总耗时=%.0f ms 每帧均值=%.2f ms 最大=%.2f ms" % (
    FRAMES, t_all, sum(ts) / len(ts), max(ts)))
print("前50帧均值=%.2f ms   后50帧均值=%.2f ms   变化=%+.1f%%" % (
    sum(a) / len(a), sum(b) / len(b), (sum(b) / len(b) - sum(a) / len(a)) / (sum(a) / len(a)) * 100))
print("min=%.2f max=%.2f" % (min(ts), max(ts)))
print("\n帧  _last_view  _proj_cache  _base_cache  groups_json_字节")
for s in snaps:
    print("%-4d %-11d %-12d %-12d %d" % s)
print("\n最终: _last_view=%d _proj_cache=%d _base_cache=%d" % (
    len(plock._last_view), len(plock._proj_cache), len(plock._base_cache)))
