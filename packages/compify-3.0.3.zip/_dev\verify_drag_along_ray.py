"""验证：拖动到底是「沿世界 Z」还是「沿相机视线」

用户指出（2026-10-20）：
  「PSD 导入工具进入视差锁定后无论拖动 A 或 B，应该都是沿相机视锥体移动，
    不是网页那种世界坐标的深度」

理论：
  compify  adapt_object：xd = x0*k_i, dd = d_base + offset
          ⇒ 相机空间 x 与深度【成正比】⇒ 点沿「从相机出发指向自己的射线」移动
  PSD     ：cam_space x = 屏幕x * 深度 * sensor/focal ⇒ 同样成正比

本脚本量：拖 A 前后，A 的【世界 x】和【世界 z】各变了多少。
  若「沿世界 Z」   ⇒ 世界 x 不变
  若「沿视线」     ⇒ 世界 x 也变（且 x/z 的比值恒定 = 落在射线上）
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    # Blender 相机默认朝 -Z。放在 z=10，看向 z=0 方向 ⇒ 深度 = 10 - z
    cam.location = (0, 0, 10); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    # A：一个【有厚度】的网格（深度 7~9），用来同时看「整体沿视线」和「逐顶点不同」
    # z = 1..3  ⇒  深度 = 10 - z = 9..7
    ns = 2; h = 1.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-1.5 - h + 2 * h * ix / ns,
                          -h + 2 * h * iy / ns,
                          1.0 + 2.0 * (ix / ns)))   # z 1..3 ⇒ 深度 9..7
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("A")
    mesh.from_pydata(verts, [], faces); mesh.update()
    A = bpy.data.objects.new("A", mesh)
    sc.collection.objects.link(A)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                             "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, A


def wv(ob):
    mw = ob.matrix_world
    return np.array([list(mw @ v.co) for v in ob.data.vertices])


sc, cam, cd, A = build()
r = plock.lock_group(sc, cam)
print("锁定：", str(r.get("message", ""))[:60])
st = plock.get_state(sc, cam)
print("ref_depth = %.4f" % st.get("ref_depth", 0))
_depths = [10.0 - v.co.z for v in A.data.vertices]
print("A 的 25 个顶点深度范围 = [%.3f, %.3f]" % (min(_depths), max(_depths)))

w0 = wv(A)
CAM_Z = 10.0
def proj(p):
    """真实屏幕投影：x / 深度，其中 深度 = CAM_Z - 世界z"""
    d = CAM_Z - p[2]
    return (p[0] / d, p[1] / d) if abs(d) > 1e-9 else (0.0, 0.0)
s0 = np.array([proj(p) for p in w0])

# 拖 A 靠近 2.0（模拟用户在视口里沿视线推近）
A.location.z += 2.0   # 朝相机方向推近 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
w1 = wv(A)
s1 = np.array([proj(p) for p in w1])

# 取一个远离中轴的顶点看清楚
idx = [i for i, v in enumerate(A.data.vertices)
       if abs(v.co.x + 1.5) > 0.5 and abs(v.co.y) > 0.5]
i0 = idx[0] if idx else 0
print()
print("=" * 82)
print("关键对比：某个顶点拖前 / 拖后 的世界坐标")
print("=" * 82)
print("  顶点 %d" % i0)
print("    拖前  世界 (x=%+.4f, y=%+.4f, z=%+.4f)" % tuple(w0[i0]))
print("    拖后  世界 (x=%+.4f, y=%+.4f, z=%+.4f)" % tuple(w1[i0]))
print("    Δx = %+.4f    Δz = %+.4f" % (w1[i0][0] - w0[i0][0], w1[i0][2] - w0[i0][2]))
print()
print("  → 若 Δx ≈ 0 ⇒ 沿世界 Z 竖直移动")
print("  → 若 Δx ≠ 0 ⇒ 沿相机视线（从相机指向该顶点的射线）移动")
print()
print("  射线检验：x/深度 的比值应该在拖前后【保持恒定】")
_d0 = CAM_Z - w0[i0][2]; _d1 = CAM_Z - w1[i0][2]
print("    拖前 x/深度 = %+.6f  (x=%+.4f, 深度=%.4f)" % (w0[i0][0]/_d0, w0[i0][0], _d0))
print("    拖后 x/深度 = %+.6f  (x=%+.4f, 深度=%.4f)" % (w1[i0][0]/_d1, w1[i0][0], _d1))
print("    差 = %.10f  ← 恒定即证明「落在同一射线上」" % abs(w0[i0][0]/_d0 - w1[i0][0]/_d1))

print()
print("=" * 82)
print("全部顶点：Δx 是否与深度成正比（越远移动越多 = 视锥体变形）")
print("=" * 82)
print("  %-6s %10s %10s %10s %12s" % ("顶点", "真实深度", "Δx", "Δz", "Δx/Δz"))
rows = []
for i in range(len(w0)):
    dz = w1[i][2] - w0[i][2]
    dx = w1[i][0] - w0[i][0]
    rows.append((i, CAM_Z - w0[i][2], dx, dz, (dx / dz) if abs(dz) > 1e-12 else 0))
rows.sort(key=lambda r: r[1])
for i, d, dx, dz, ratio in rows[:4] + rows[-4:]:
    print("  %-6d %10.4f %10.4f %10.4f %12.6f" % (i, d, dx, dz, ratio))

print()
print("=" * 82)
print("屏幕投影（画面位置）是否保持")
print("=" * 82)
print("  最大屏幕投影变化 = %.10f" % float(np.abs(s1 - s0).max()))
print()
print("  解释：屏幕 x = 世界x / 深度。沿视线移动时世界x与深度【同比例】变化，")
print("        所以比值不变 ⇒ 画面位置纹丝不动。这就是「拖图层」的语义。")
print("CAMRAY_DONE")
