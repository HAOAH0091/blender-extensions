"""审查E-9b：_base_cache 真实占用 / 解锁后是否释放 / 反复锁定是否单调上涨

与 E-9 的差别：这次**真的跑 handler**，让 `_read_base_attribute` 把基座缓存填起来
（E-9 没跑 handler，所以缓存是空的，量不到那块）。
"""
import bpy, sys, os, gc, ctypes, ctypes.wintypes
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


class PMC(ctypes.Structure):
    _fields_ = [("cb", ctypes.wintypes.DWORD), ("PageFaultCount", ctypes.wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


_k32 = ctypes.WinDLL("kernel32.dll")
_k32.GetCurrentProcess.restype = ctypes.wintypes.HANDLE
_ps = ctypes.WinDLL("psapi.dll")
_ps.GetProcessMemoryInfo.argtypes = [ctypes.wintypes.HANDLE, ctypes.POINTER(PMC),
                                     ctypes.wintypes.DWORD]
_ps.GetProcessMemoryInfo.restype = ctypes.wintypes.BOOL


def rss():
    p = PMC()
    p.cb = ctypes.sizeof(PMC)
    _ps.GetProcessMemoryInfo(_k32.GetCurrentProcess(), ctypes.byref(p), p.cb)
    return p.WorkingSetSize / 1048576.0


def cache_mb():
    tot = 0
    for k, v in plock._base_cache.items():
        tot += len(v) * (56 + 3 * 24)
    return tot / 1048576.0


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 12)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
bpy.ops.mesh.primitive_grid_add(x_subdivisions=550, y_subdivisions=550,
                                size=8.0, location=(0, 0, 0))
ob = bpy.context.object
ob.name = "Big"
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()
nv = len(ob.data.vertices)
print("顶点数=%d" % nv)
gc.collect()
print("起始                          RSS=%.1f MB" % rss())

plock.lock_group(sc, cam)
cam.location.x += 0.05
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)          # 让 adapt_object 读一次 base → 填缓存
print("锁定+跑一帧                     RSS=%.1f MB  _base_cache=%d 条 / 约 %.1f MB" % (
    rss(), len(plock._base_cache), cache_mb()))

plock.unlock_group(sc, cam)
gc.collect()
print("解锁后                          RSS=%.1f MB  _base_cache=%d 条 / 约 %.1f MB" % (
    rss(), len(plock._base_cache), cache_mb()))

plock.reset_group(sc, cam)
gc.collect()
print("重置后                          RSS=%.1f MB  _base_cache=%d 条 / 约 %.1f MB" % (
    rss(), len(plock._base_cache), cache_mb()))

print("\n[反复 10 轮 锁定→跑帧→解锁]（每轮看 RSS 是否单调上涨）")
for i in range(10):
    cam.location.x += 0.02
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    cam.location.x += 0.02
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    plock.unlock_group(sc, cam)
    gc.collect()
    print("  第%2d轮 RSS=%.1f MB  _base_cache=%d 条 / 约 %.1f MB" % (
        i + 1, rss(), len(plock._base_cache), cache_mb()))

print("\n[只解锁 → 删网格]：缓存里那 %d 条会留多久？" % len(plock._base_cache))
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
plock.unlock_group(sc, cam)
n_before = len(plock._base_cache)
keys = list(plock._base_cache.keys())
bpy.data.objects.remove(ob, do_unlink=True)
bpy.context.view_layer.update()
for _ in range(20):
    plock.parallax_lock_update_handler(sc)
gc.collect()
print("  删网格 + 跑 20 帧后 _base_cache=%d 条（删前 %d），RSS=%.1f MB，残留键=%s" % (
    len(plock._base_cache), n_before, rss(), keys[:1]))
