"""回归网（第九轮独立审查）：盯 🔴 F-1 / 🟡 F-2 / 🟡 F-3。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL。
⚠️ 本文件还额外守住两个「修复手段反噬」的坑（见 §21.4）：
   · 在 lock_group 里无条件 view_layer.update() ⇒ 会中途触发自己的 handler
   · 在删属性之后再读它 ⇒ 永远 None
"""
import bpy
import sys
import os
import math
import importlib.util
import mathutils as MU

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-56s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    plock._proj_cache.clear()
    return bpy.context.scene


def mkcam(sc, name="Cam", loc=(0.0, 0.0, 6.0)):
    cd = bpy.data.cameras.new(name); cd.lens = 50.0; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def mkobjs(sc, cam, n=3, prefix="P", extra_cam=None):
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    if extra_cam is not None:
        ng.ensure_camera_project_group(extra_cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i in range(n):
        bpy.ops.mesh.primitive_plane_add(size=4.0, location=(0.0, 0.0, -float(i) * 3))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        if extra_cam is not None:
            bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, extra_cam.data.name),
                                     "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out, mat


def run(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def loc(ob):
    return [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]


def md(a, b):
    return max(max(abs(x[i] - y[i]) for i in range(3)) for x, y in zip(a, b)) if a and b else 0.0


def screen(ob, view, lens, sensor=36.0):
    f = lens / sensor
    out = []
    for v in ob.data.vertices:
        cs = view.inverted() @ (ob.matrix_world @ v.co)
        d = -cs.z
        out.append(None if d <= 1e-6 else (cs.x / d * f, cs.y / d * f))
    return out


def dmax(a, b):
    return max(abs(x[0] - y[0]) + abs(x[1] - y[1]) for x, y in zip(a, b) if x and y)


# ═══ 🔴 F-1：孤儿还原必须真还原，不能销毁依据更不能谎报 ═══
print("=" * 72)
print("🔴 F-1  孤儿还原：真还原 / 不销毁依据 / 不谎报")
# (a) 旧存档（无 ORIG_ATTR，但 groups 里还有记录）→ 必须能还原
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs, _ = mkobjs(sc, cam, 3, "A")
orig = [loc(o) for o in objs]
plock.lock_group(sc, cam)
cam.data.lens = 120.0
run(sc)
d_adapt = max(md(a, b) for a, b in zip(orig, [loc(o) for o in objs]))
chk("前置：变焦确实造成变形（非空对空）", d_adapt > 1e-6, "%.6f" % d_adapt)
for o in objs:                      # 模拟 v2.7.5 及更早的存档
    if o.data.attributes.get(plock.ORIG_ATTR) is not None:
        o.data.attributes.remove(o.data.attributes[plock.ORIG_ATTR])
_cd = cam.data
bpy.data.objects.remove(cam, do_unlink=True)
bpy.context.view_layer.update()
r = plock.reset_orphan_locks(sc)
bpy.context.view_layer.update()
d_orig = max(md(a, b) for a, b in zip(orig, [loc(o) for o in objs]))
print("   返回: success=%s count=%s 偏差=%.6f" % (r.get("success"), r.get("count"), d_orig))
chk("F-1a 旧存档孤儿还原后 = 原形", d_orig < 1e-4, "偏差 %.6f" % d_orig)
chk("F-1b 还原成功才清记录", len(plock.load_groups(sc)) == 0,
    str(list(plock.load_groups(sc).keys())))

# (b) 彻底无法还原（ORIG 与 BASE 都没了）→ 必须保留、且不谎报
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs, _ = mkobjs(sc, cam, 2, "B")
plock.lock_group(sc, cam)
for o in objs:
    for _an in (plock.ORIG_ATTR, plock.BASE_ATTR):
        a = o.data.attributes.get(_an)
        if a is not None:
            o.data.attributes.remove(a)
_cd2 = cam.data
bpy.data.objects.remove(cam, do_unlink=True)
bpy.context.view_layer.update()
r = plock.reset_orphan_locks(sc)
print("   不可还原时返回: success=%s msg=%r" % (r.get("success"), str(r.get("message"))[:70]))
chk("F-1c 无法还原时不得谎报「已还原」",
    (not r.get("success")) or r.get("count", 0) == 0,
    "success=%s count=%s" % (r.get("success"), r.get("count")))
chk("F-1d 无法还原时记录要留着（那是线索）",
    len(plock.load_groups(sc)) > 0,
    "记录数 %d" % len(plock.load_groups(sc)))

# ═══ 🟡 F-2：互斥接管后 base 与几何必须同一把尺子 ═══
print()
print("=" * 72)
print("🟡 F-2  互斥接管后：base 与实际几何一致（微动相机不跳变）")
sc = fresh()
cA = mkcam(sc, "CamA", (0.0, 0.0, 12.0)); sc.camera = cA
cB = mkcam(sc, "CamB", (0.0, 0.0, 12.0))
objs, _ = mkobjs(sc, cA, 3, "C", extra_cam=cB)
orig2 = [loc(o) for o in objs]
plock.lock_group(sc, cA)
cA.location.x = 4.0
run(sc)
d_a = max(md(a, b) for a, b in zip(orig2, [loc(o) for o in objs]))
chk("前置：A 适配造成变形（非空对空）", d_a > 1e-6, "%.6f" % d_a)
plock.lock_group(sc, cB)                       # B 接管
bpy.context.view_layer.update()
geo0 = [loc(o) for o in objs]
chk("F-2a 接管瞬间几何被还原成原形",
    max(md(a, b) for a, b in zip(orig2, geo0)) < 1e-5,
    "偏差 %.6f" % max(md(a, b) for a, b in zip(orig2, geo0)))
cB.location.x = 0.01
run(sc)
geo1 = [loc(o) for o in objs]
jump = max(md(a, b) for a, b in zip(geo0, geo1))
print("   微动 B(0.01) 后世界位移跳变 = %.6f" % jump)
chk("F-2b 微动相机不产生大跳变（修前 1.336667）", jump < 0.05, "跳变 %.6f" % jump)

# ═══ 🟡 F-3：解锁后面板不得常亮 ⚠ ═══
print()
print("=" * 72)
print("🟡 F-3  面板图标三态：解锁是正常态，不得亮 ⚠")


def icon_of(st):
    """复刻 __init__.py 面板的判据。"""
    if st["locked"]:
        return "ERROR" if ((not st["patched"]) or st.get("degraded", 0) > 0) else "LOCKED"
    return "UNLOCKED"


sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, 3, "D")
plock.lock_group(sc, cam)
chk("F-3a 锁定中 = LOCKED", icon_of(plock.lock_status(sc, cam)) == "LOCKED")
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
chk("F-3b 解锁后 = UNLOCKED（不是 ⚠）",
    icon_of(plock.lock_status(sc, cam)) == "UNLOCKED",
    icon_of(plock.lock_status(sc, cam)))
# 对照：真实异常仍要报 ERROR
sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, 3, "E")
plock.lock_group(sc, cam)
ng.ensure_camera_project_group(cam, default_aspect=1.0)
bpy.context.view_layer.update()
chk("F-3c 对照：锁定中补丁被清 → ERROR",
    icon_of(plock.lock_status(sc, cam)) == "ERROR")
# 对照：降级仍要报 ERROR
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs3, _ = mkobjs(sc, cam, 4, "G")
plock.lock_group(sc, cam)
objs3[-1].modifiers.new("SUBSURF", "SUBSURF")
bpy.context.view_layer.update()
chk("F-3d 对照：降级 → ERROR", icon_of(plock.lock_status(sc, cam)) == "ERROR")

# ═══ ★ 反噬坑 1：lock_group 中间不得触发自己的 handler ═══
print()
print("=" * 72)
print("★ 反噬坑 1  lock_group 内部触发自己的 handler（会破坏构图冻结）")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs4, _ = mkobjs(sc, cam, 3, "H")
plock.lock_group(sc, cam)
plock.lock_group(sc, cam)
cam.rotation_euler = (0.0, math.radians(20.0), 0.0)
run(sc)
cam.rotation_euler = (0.0, 0.0, 0.0)
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
S4 = screen(objs4[0], plock.get_camera_view_matrix(cam), cam.data.lens)
cam.data.lens = 85.0
run(sc)
S5 = screen(objs4[0], plock.get_camera_view_matrix(cam), cam.data.lens)
dd = dmax(S4, S5)
print("   「锁定→旋转→再锁定→变焦」构图位移 = %.2e" % dd)
chk("★ 该路径构图冻结（修前 4.93e-01）", dd < 1e-6, "%.2e" % dd)

# ═══ ★ 反噬坑 2：清记录前必须先把 key 取出来 ═══
print()
print("=" * 72)
print("★ 反噬坑 2  孤儿清理：记录必须真被清掉（不是读到 None）")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs5, _ = mkobjs(sc, cam, 2, "I")
plock.lock_group(sc, cam)
cam.data.lens = 100.0
run(sc)
_cd3 = cam.data
bpy.data.objects.remove(cam, do_unlink=True)
bpy.context.view_layer.update()
r = plock.reset_orphan_locks(sc)
chk("★ 真孤儿的记录被清掉", len(plock.load_groups(sc)) == 0,
    "残留 %s" % str(list(plock.load_groups(sc).keys())))

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX8_DONE")
