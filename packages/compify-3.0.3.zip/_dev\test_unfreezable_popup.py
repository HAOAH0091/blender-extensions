"""回归：锁定期间「无法冻结」网格的弹窗提示逻辑

用户 2026-10-20 要求：带修改器 / 带形态键 / 共享网格这三类无法参与图案冻结，
需要**弹窗**告诉用户；普通网格能正常冻结，不弹窗。

本测试在 headless 下跑，验证的是**登记/去重/清理**逻辑。
真实弹窗链路另在 GUI 模式验证过（_dev/diag_popup_gui.py：draw 回调被调用、
无异常）。headless 下只要不崩溃，就说明弹窗 API 没被误碰。
"""
import bpy
import sys
import os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", name, detail))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, mesh=None):
        if mesh is None:
            ns = 2
            h = 1.2
            verts, faces = [], []
            for iy in range(ns + 1):
                for ix in range(ns + 1):
                    verts.append((x0 - h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
            for iy in range(ns):
                for ix in range(ns):
                    a = iy * (ns + 1) + ix
                    faces.append((a, a + 1, a + ns + 2, a + ns + 1))
            mesh = bpy.data.meshes.new(name)
            mesh.from_pydata(verts, [], faces)
            mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob

    A = mk("GridA", -1.6)
    B = mk("GridB", 1.6)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


def queued_names():
    return [n for n, _ in plock._popup_queue]


def queued_reasons():
    return dict(plock._popup_queue)


print("=" * 84)
print("锁定期间「无法冻结」网格 —— 弹窗提示逻辑")
print("=" * 84)

print("\n[0] 环境与安全")
chk("headless 下不注册弹窗 timer", not plock._popup_supported(),
    "bpy.app.background=%s" % bpy.app.background)

print("\n[1] 普通网格：不该弹窗（静默补写即可）")
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock._popup_shown.clear()
plock._popup_queue.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("普通网格不登记弹窗", queued_names() == [], "队列=%s" % queued_names())
a = B.data.attributes.get(plock._campos_attr_name(cd.name))
chk("普通网格照常补上冻结坐标", a is not None and len(a.data) == len(B.data.vertices))

print("\n[2] 带修改器：要弹窗")
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock._popup_shown.clear()
plock._popup_queue.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
B.modifiers.new("S", "SUBSURF")
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("登记了弹窗", "GridB" in queued_names(), "队列=%s" % queued_names())
chk("原因是「修改器」", "修改器" in (queued_reasons().get("GridB") or []),
    "%s" % queued_reasons())
chk("没有写冻结坐标（本就不该写）",
    B.data.attributes.get(plock._campos_attr_name(cd.name)) is None)

print("\n[3] 带形态键：要弹窗")
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock._popup_shown.clear()
plock._popup_queue.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
B.shape_key_add(name="K1", from_mix=False)
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("登记了弹窗", "GridB" in queued_names(), "队列=%s" % queued_names())
chk("原因是「形态键」", "形态键" in (queued_reasons().get("GridB") or []),
    "%s" % queued_reasons())

print("\n[4] 共享网格：要弹窗")
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock._popup_shown.clear()
plock._popup_queue.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
C = bpy.data.objects.new("GridC", B.data)     # 共享 mesh ⇒ users > 1
sc.collection.objects.link(C)
C.location = (5.0, 0, 0)
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("登记了弹窗", "GridB" in queued_names(), "队列=%s" % queued_names())
chk("原因是「共享网格」", "共享网格" in (queued_reasons().get("GridB") or []),
    "%s" % queued_reasons())

print("\n[5] 同一对象只登记一次（handler 多帧不刷屏）")
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock._popup_shown.clear()
plock._popup_queue.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
B.modifiers.new("S", "SUBSURF")
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
for _ in range(8):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
chk("队列里 GridB 只有 1 条", queued_names().count("GridB") == 1,
    "队列=%s" % queued_names())

print("\n[6] 变得可冻结后，记录被清掉（以后出问题还会再提示）")
bpy.context.view_layer.objects.active = B
B.select_set(True)
for md in list(B.modifiers):
    B.modifiers.remove(md)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("已从 _popup_shown 移除", "GridB" not in plock._popup_shown)
chk("已从 _backfill_warned 移除", "GridB" not in plock._backfill_warned)
chk("这次冻结坐标补上了",
    B.data.attributes.get(plock._campos_attr_name(cd.name)) is not None)

print("\n[7] 解锁后清空待弹队列（不弹过期提示）")
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock._popup_shown.clear()
plock._popup_queue.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
B.modifiers.new("S", "SUBSURF")
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("解锁前队列里有内容", len(plock._popup_queue) > 0)
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
chk("解锁后队列清空", plock._popup_queue == [], "队列=%s" % queued_names())

print("\n[8] 重置后也清空")
plock._popup_queue.append(("虚拟", "修改器"))
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
chk("重置后队列清空", plock._popup_queue == [])

print("\n[9] 弹窗文案：必须是「怎么做」，不是「为什么」")
lines = plock.unfreezable_popup_lines([
    ("GridB", "修改器"),
    ("GridC", "形态键"),
    ("GridD", "共享网格"),
])
texts = [x[0] for x in lines]
joined = "\n".join(texts)
print("     ---- 弹窗实际内容 ----")
for _t, _i in lines:
    print("     [%s] %s" % (_i or "", _t))
print("     ----------------------")

chk("首行点明问题并带 ERROR 图标",
    lines[0][1] == "ERROR" and "冻不住" in lines[0][0], lines[0][0])
chk("明确说「按步骤处理，会自动接上」",
    "自动接上" in lines[1][0] and "不用重新锁定" in lines[1][0], lines[1][0])

# --- 核心：每种原因都必须给出可操作步骤 ---
chk("修改器 → 给出「应用」的步骤",
    any("修改器" in x and "应用" in x for x in texts),
    [x for x in texts if "应用" in x][:1])
chk("形态键 → 给出「删除」的步骤",
    any("形态键" in x and "删" in x for x in texts),
    [x for x in texts if "删" in x][:1])
chk("共享网格 → 给出「使其独立化」的步骤",
    any("使其独立化" in x for x in texts),
    [x for x in texts if "使其独立化" in x][:1])

# --- 反面：不该出现原理式的技术解释 ---
chk("不出现「逐顶点」这类实现细节", "逐顶点" not in joined)
chk("不出现「Attribute」这类术语", "Attribute" not in joined)
chk("不出现「读取为 0」这类排查语", "读到 0" not in joined)

chk("列出了 GridB / GridC / GridD",
    all(any(n in x for x in texts) for n in ("GridB", "GridC", "GridD")))
chk("给了退路（点重置）", "重置" in joined)
chk("标题与常量一致", plock.POPUP_TITLE == "Compify 视差锁定", plock.POPUP_TITLE)

# 同一对象多个原因：合并到该对象下，不重复出现对象行
lines2 = plock.unfreezable_popup_lines([("GridX", "修改器"), ("GridX", "共享网格")])
obj_rows = [x for x in lines2 if x[0].startswith("▸")]
chk("同一对象只列一次（多个原因合在其下）", len(obj_rows) == 1, "%d 行" % len(obj_rows))
j2 = "\n".join(x[0] for x in lines2)
chk("两个原因的处理步骤都给出来了", "应用" in j2 and "使其独立化" in j2)

# ★ 一个网格同时有多个原因时，必须一次说全（否则用户要操作两轮）
lines4 = plock.unfreezable_popup_lines([("GridM", ["形态键", "共享网格"])])
j4 = "\n".join(x[0] for x in lines4)
chk("多原因：形态键步骤有", "删掉全部形态键" in j4)
chk("多原因：共享网格步骤也有", "使其独立化" in j4)
chk("多原因：同一条目下（只列一次对象）",
    len([x for x in lines4 if x[0].startswith("▸")]) == 1)

# 未知原因也不能崩
lines3 = plock.unfreezable_popup_lines([("GridY", "某种新原因")])
chk("未知原因不会崩溃且留痕",
    any("GridY" in x[0] for x in lines3) and "某种新原因" in "\n".join(x[0] for x in lines3))

print()
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("POPUP_TEST_DONE")
