"""边界分析：视差锁定【期间】把投影材质赋给新网格 B

与「解锁后换材质」完全不同：此时 patch 生效，UV 来自 Attribute(冻结坐标)，
新网格没有该属性 ⇒ Attribute 读 0 ⇒ UV 全塌到 (0,0)。

测五种情形：
  1 普通网格（无修改器）
  2 带修改器的网格      ← 代码里 `has_modifier_or_shapekey` 会 continue 跳过
  3 带形态键的网格
  4 两个对象共享同一个 mesh
  5 编辑模式下的网格
每种都测三态：
  a) 换材质后**立即**（handler 跑之前）—— 用户可能看到的那一帧
  b) handler 跑一帧之后
  c) 真渲染 UV 探针（画面到底坏没坏）
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 64
M = __import__("mathutils").Matrix


def build(shape="平面"):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    def mk(name, x0, mesh=None):
        if mesh is None:
            ns = 3
            H = 1.6
            verts, faces = [], []
            for iy in range(ns + 1):
                for ix in range(ns + 1):
                    x = x0 + (-H + 2 * H * ix / ns)
                    y = -H + 2 * H * iy / ns
                    z = 0.0
                    verts.append((x, y, z))
            for iy in range(ns):
                for ix in range(ns):
                    a = iy * (ns + 1) + ix
                    faces.append((a, a + 1, a + ns + 2, a + ns + 1))
            mesh = bpy.data.meshes.new(name)
            mesh.from_pydata(verts, [], faces)
            mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob

    A = mk("GridA", -2.0)
    B = mk("GridB", 2.0)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


_seq = [0]


def uvimg():
    _seq[0] += 1
    p = os.path.join(HERE, "_edge_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def has_campos(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    return a is not None and len(a.data) == len(ob.data.vertices)


def uv_of(ob, cam, cd):
    """按投影组当前会给出的 UV"""
    if plock.is_patched(cd.name):
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            return np.array([(a.data[i].vector[0] / a.data[i].vector[2],
                              a.data[i].vector[1] / a.data[i].vector[2])
                             for i in range(len(a.data))])
        # Attribute 读 0 ⇒ UV 全塌到 (0,0)
        return np.zeros((len(ob.data.vertices), 2))
    m = cam.matrix_world.inverted()
    nodes = plock._find_delta_nodes(cd.name)
    S, C = 1.0, (0.0, 0.0)
    if nodes is not None:
        S = nodes[0].inputs["Scale"].default_value
        C = tuple(nodes[1].inputs[1].default_value)[:2]
    return np.array([((lambda p: (p.x / p.z * S + C[0], p.y / p.z * S + C[1]))(
        m @ (ob.matrix_world @ v.co))) for v in ob.data.vertices])


def expect_locked_uv(ob, lock_mw):
    m = lock_mw.inverted()
    return np.array([((lambda p: (p.x / p.z, p.y / p.z))(m @ (ob.matrix_world @ v.co)))
                     for v in ob.data.vertices])


def report(tag, ob, cam, cd, lock_mw):
    has = has_campos(ob, cd)
    uv = uv_of(ob, cam, cd)
    exp = expect_locked_uv(ob, lock_mw)
    err = float(np.abs(uv - exp).max())
    print("     %-26s campos=%-5s UV误差=%.6f  %s" % (
        tag, has, err, "正确" if err < 1e-5 else "【错】图案会坏"))


print("=" * 90)
print("边界：视差锁定【期间】给新网格 B 赋予投影材质")
print("=" * 90)

# ---------- 情形 1：普通网格 ----------
print("\n[1] 普通网格（无修改器）")
sc, cam, cd, mat, A, B = build()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("   B 换材质前：B 无材质，参与不了投影")
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
report("换材质后【立即】(handler 前)", B, cam, cd, lock_mw)
u_bad = uvimg()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
report("handler 跑一帧后", B, cam, cd, lock_mw)
A_ref = uv_of(A, cam, cd)
report("对照 A（本来就是锁定目标）", A, cam, cd, lock_mw)

# ---------- 情形 2：带修改器 ----------
print("\n[2] 带修改器的网格")
sc, cam, cd, mat, A, B = build()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
m = B.modifiers.new("Subdiv", "SUBSURF")
m.levels = 1
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
report("换材质后【立即】", B, cam, cd, lock_mw)
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
report("handler 跑 3 帧后", B, cam, cd, lock_mw)

# ---------- 情形 3：形态键 ----------
print("\n[3] 带形态键的网格")
sc, cam, cd, mat, A, B = build()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
B.shape_key_add(name="Basis", from_mix=False)
B.shape_key_add(name="K1", from_mix=False)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
report("换材质后", B, cam, cd, lock_mw)

# ---------- 情形 4：共享 mesh ----------
print("\n[4] 两个对象共享同一个 mesh")
sc, cam, cd, mat, A, B = build()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
C = bpy.data.objects.new("GridC", B.data)     # 共享 B 的 mesh
sc.collection.objects.link(C)
C.location = (5.0, 0, 0)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
report("B（共享 mesh 的一方）", B, cam, cd, lock_mw)
report("C（另一方，也用了该材质）", C, cam, cd, lock_mw)

# ---------- 情形 5：编辑模式 ----------
print("\n[5] 编辑模式下的网格")
sc, cam, cd, mat, A, B = build()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
bpy.context.view_layer.objects.active = B
B.select_set(True)
bpy.ops.object.mode_set(mode="EDIT")
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
print("     （编辑模式下 mesh.attributes 数据在 BMesh 里，len 可能为 0）")
print("     atrib 存在:", B.data.attributes.get(plock._campos_attr_name(cd.name)) is not None)
try:
    print("     len(attr.data) =", len(B.data.attributes.get(plock._campos_attr_name(cd.name)).data)
          if B.data.attributes.get(plock._campos_attr_name(cd.name)) else "无")
except Exception as e:
    print("     读属性异常:", e)
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
bpy.ops.object.mode_set(mode="OBJECT")
bpy.context.view_layer.update()
report("退出编辑模式后", B, cam, cd, lock_mw)
print("EDGE_DONE")
