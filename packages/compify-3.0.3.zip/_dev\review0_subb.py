"""复核对 sub B 报的三条：fake user 误判 / 空网格拖垮全相机 / scale=0 崩溃"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-48s %s" % ("PASS" if c else "FAIL", n, d))


def build(nobj=1):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0):
        ns = 2; h = 1.2
        verts, faces = [], []
        for iy in range(ns+1):
            for ix in range(ns+1):
                verts.append((x0-h+2*h*ix/ns, -h+2*h*iy/ns, 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy*(ns+1)+ix
                faces.append((a, a+1, a+ns+2, a+ns+1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob
    objs = [mk("Grid%d" % i, -2.0 + 4.0 * i) for i in range(nobj)]
    for o in objs:
        o.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (o.data.name, cd.name),
                                 "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, objs


print("=" * 84)
print("B-2 复核：mesh 有 fake user（users=2）是否被误判成「共享网格」")
print("=" * 84)
sc, cam, cd, mat, objs = build(1)
A = objs[0]
print("  初始 data.users =", A.data.users)
chk("初始不阻塞", plock.block_reasons(A) == [], "reasons=%s" % plock.block_reasons(A))
A.data.use_fake_user = True
print("  开 fake user 后 data.users =", A.data.users)
rs = plock.block_reasons(A)
print("  block_reasons =", rs)
chk("开 fake user 后不该被判共享网格", "共享网格" not in rs, "reasons=%s" % rs)
r = plock.lock_group(sc, cam)
print("  锁定结果: success=%s frozen=%s msg=%s" % (
    r.get("success"), r.get("frozen"), str(r.get("message", ""))[:60]))
chk("开 fake user 后仍能锁定", r.get("success"), "")

print()
print("=" * 84)
print("B-1 复核：一个空网格是否把整个相机的图案冻结关掉")
print("=" * 84)
sc, cam, cd, mat, objs = build(2)
A, B = objs
r = plock.lock_group(sc, cam)
print("  首次锁定: frozen=%s locked=%d" % (r.get("frozen"), len(r.get("locked") or [])))
chk("首次锁定成功", r.get("frozen"))

# 把 B 的顶点全删（对象和材质还在）
B.data.clear_geometry()
B.data.update()
bpy.context.view_layer.update()
print("  B 顶点数 =", len(B.data.vertices))
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
r2 = plock.lock_group(sc, cam)
print("  有空格子时再锁: frozen=%s unsupported=%s" % (
    r2.get("frozen"), r2.get("unsupported")))
a = A.data.attributes.get(plock._campos_attr_name(cd.name))
has_campos = a is not None and len(a.data) == len(A.data.vertices)
chk("空网格不该拖垮正常网格的冻结", r2.get("frozen"), "")
chk("正常网格 A 仍有冻结坐标", has_campos)

print()
print("=" * 84)
print("B-4 复核：相机 scale=0 是否抛未捕获异常")
print("=" * 84)
sc, cam, cd, mat, objs = build(1)
cam.scale = (0.0, 0.0, 0.0)
bpy.context.view_layer.update()
try:
    r3 = plock.lock_group(sc, cam)
    print("  锁定返回: success=%s msg=%s" % (r3.get("success"), str(r3.get("message",""))[:70]))
    chk("scale=0 不抛异常，返回失败结果", r3.get("success") is False)
except Exception as e:
    print("  ✗ 抛出异常:", type(e).__name__, e)
    chk("scale=0 不抛异常", False, "%s" % type(e).__name__)

print()
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("SUBB_DONE")
