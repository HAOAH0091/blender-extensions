"""审查 F-5b：新进程打开存档 → 锁定状态 / 冻结坐标 / C+k / 弹窗记录 是否正确恢复"""
import bpy, sys, os, json
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
plock.register_handlers()

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-54s %s" % ("PASS" if c else "FAIL", n, d))


B = os.path.join(HERE, "_rfp_")
FP = json.load(open(B + "fingerprint.json", encoding="utf-8"))
_seq = [0]


def uvarr():
    _seq[0] += 1
    p = os.path.join(HERE, "_rfpb_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32); im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def openfile(tag):
    bpy.ops.wm.open_mainfile(filepath=B + tag + ".blend")
    sc = bpy.context.scene
    cam = bpy.data.objects.get("Cam")
    cd = cam.data
    objs = sorted([o for o in bpy.data.objects if o.type == "MESH"], key=lambda o: o.name)
    return sc, cam, cd, objs


def freeze_frame(tag):
    sc, cam, cd, objs = openfile(tag)
    ref = np.load(B + "%s.npy" % tag)
    d = FP[tag]
    st = plock.get_state(sc, cam) or {}
    nodes = plock._find_delta_nodes(cd.name)
    attrs = [[a.name for a in o.data.attributes if a.name.startswith("compify_plock")]
             for o in objs]
    print("  -- %s 打开后: enabled=%s S=%s C=%s patched=%s modes=%s"
          % (tag, st.get("enabled"),
             float(nodes[0].inputs["Scale"].default_value) if nodes else None,
             list(nodes[1].inputs[1].default_value)[:2] if nodes else None,
             plock.is_patched(cd.name), [o.mode for o in objs]))
    print("     冻结属性: %s" % [a for a in attrs])
    chk("%s 锁定/解锁状态恢复" % tag, bool(st.get("enabled")) == d["enabled"],
        "存档 %s → 现在 %s" % (d["enabled"], st.get("enabled")))
    if d["has_sc_nodes"]:
        s_now = float(nodes[0].inputs["Scale"].default_value) if nodes else None
        c_now = list(nodes[1].inputs[1].default_value)[:2] if nodes else None
        chk("%s C+k 数值恢复" % tag,
            nodes is not None and abs(s_now - d["S"]) < 1e-6
            and abs(c_now[0] - d["C"][0]) < 1e-6 and abs(c_now[1] - d["C"][1]) < 1e-6,
            "S %s→%s  C %s→%s" % (d["S"], s_now, d["C"], c_now))
    chk("%s 冻结坐标属性还在" % tag,
        all(any(n.startswith("compify_plock_campos") for n in a) for a in attrs if a) or
        d["attrs"][0] == [],
        "存档 %s → 现在 %s" % ([a for a in d["attrs"][0] if "campos" in a], attrs))
    u_now = uvarr()
    diff = float(np.abs(u_now - ref).mean())
    chk("%s 打开后画面与保存时一致" % tag, diff < 1e-5, "平均 |ΔUV| = %.2e" % diff)
    return sc, cam, cd, objs, u_now


print("=" * 84)
print("### [5] 新进程打开「锁定中」存档 p1")
sc, cam, cd, objs, u0 = freeze_frame("p1_locked")
plock.parallax_lock_update_handler(sc)          # 打开后跑一帧 handler
bpy.context.view_layer.update()
u1 = uvarr()
chk("p1 打开后 handler 跑一帧画面不漂移", float(np.abs(u1 - u0).mean()) < 2e-3,
    "Δ=%.2e" % float(np.abs(u1 - u0).mean()))
r = plock.lock_status(sc, cam) if hasattr(plock, "lock_status") else None
print("     锁定状态检查: %s" % (str(r)[:120] if r else "n/a"))
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
u2 = uvarr()
chk("p1 打开后解锁不跳", float(np.abs(u2 - u1).mean()) < 2e-3,
    "Δ=%.5f" % float(np.abs(u2 - u1).mean()))
cam.location.x += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u3 = uvarr()
chk("p1 解锁后图案正常滑动", float(np.abs(u3 - u2).mean()) > 5e-3,
    "Δ=%.5f" % float(np.abs(u3 - u2).mean()))

print("")
print("### [5] 新进程打开「已落实构图（解锁态）」存档 p2")
sc, cam, cd, objs, u0 = freeze_frame("p2_committed")
cam.location.x += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u1 = uvarr()
chk("p2 打开后移相机图案仍滑动", float(np.abs(u1 - u0).mean()) > 5e-3,
    "Δ=%.5f" % float(np.abs(u1 - u0).mean()))

print("")
print("### [6] 新进程打开「保存时网格在编辑模式」存档 p3")
bpy.ops.wm.open_mainfile(filepath=B + "p3_edit.blend")
sc = bpy.context.scene
cam = bpy.data.objects.get("Cam")
A = bpy.data.objects.get("Grid0")
cd = cam.data
st = plock.get_state(sc, cam) or {}
print("  打开后 obj.mode = %s，state.enabled = %s" % (A.mode, st.get("enabled")))
campos = [a for a in A.data.attributes if a.name.startswith("compify_plock_campos")]
print("  campos 属性存在 = %s，len(data) = %s，顶点数 = %d"
      % (bool(campos), [len(a.data) for a in campos], len(A.data.vertices)))
print("  _campos_is_valid = %s" % plock._campos_is_valid(A, cd.name))
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("  编辑模式下跑过 handler 后：顶点数 %d，campos len %s，mode=%s"
      % (len(A.data.vertices), [len(a.data) for a in A.data.attributes
                                if a.name.startswith("compify_plock_campos")], A.mode))
bpy.context.view_layer.objects.active = A
bpy.ops.object.mode_set(mode="OBJECT")
campos2 = [a for a in A.data.attributes if a.name.startswith("compify_plock_campos")]
print("  退出编辑模式后：campos len = %s" % [len(a.data) for a in campos2])
ref = np.load(B + "p3_edit.npy")
u = uvarr()
chk("p3 退出编辑模式后画面与保存时一致", float(np.abs(u - ref).mean()) < 2e-3,
    "Δ=%.2e" % float(np.abs(u - ref).mean()))
chk("p3 退出编辑模式后 campos 长度 == 顶点数",
    bool(campos2) and len(campos2[0].data) == len(A.data.vertices),
    "%s vs %d" % ([len(a.data) for a in campos2], len(A.data.vertices)))
chk("p3 打开后锁定状态仍在", bool(st.get("enabled")), "enabled=%s" % st.get("enabled"))

print("")
print("### [5] 弹窗记录是否跨会话保存")
bpy.ops.wm.open_mainfile(filepath=B + "p4_unfreezable.blend")
print("  打开后 _popup_shown = %s, _popup_queue = %d（模块级全局，不存盘）"
      % (sorted(plock._popup_shown), len(plock._popup_queue)))
print("  存档里 p4 的 popup 队列（保存时）= %d" % FP["p4_unfreezable"]["popup_queue"])

print("")
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("RF_PERSIST_B_DONE")
