"""独立审查 C —— 公共夹具（投影数学与相机/渲染边界）

★ 判据纪律（沿用 test_ck_unlock_render.py 的教训）：
  · 「是否跳」一律用 **真渲染 + UV 探针读像素反推 UV**，不在 Python 里复刻投影公式。
  · 独立参照用 Blender 自己的 `bpy_extras.object_utils.world_to_camera_view`
    （它自己处理 ortho / shift / sensor_fit / 像素宽高比），也不自己写公式。
  · 探针输出改用 **OpenEXR float**（不是 PNG）：
        - 不经 display view transform（Standard/Filmic/AgX 都不影响像素值）
        - 无 8bit 量化，UV 精度 ~1e-6（PNG 只有 ~6e-3）
    这样第 9 项（颜色管理）与「小跳变」都能量得准。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np
from bpy_extras.object_utils import world_to_camera_view

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
if PKG not in sys.modules:
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
    _mod = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = _mod
    spec.loader.exec_module(_mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES_X, RES_Y = 96, 96
FMT = "OPEN_EXR"
_seq = [0]
P, F = [], []


def chk(name, ok, detail=""):
    (P if ok else F).append(name)
    print("  [%s] %-46s %s" % ("PASS" if ok else "FAIL", name, detail))


def build(lens=50.0, sensor_width=36.0, sensor_height=24.0, sensor_fit="AUTO",
          shift=(0.0, 0.0), cam_type="PERSP", ortho_scale=6.0,
          cam_scale=(1.0, 1.0, 1.0), cam_loc=(0.0, 0.0, 5.0), cam_rot=(0.0, 0.0, 0.0),
          shape="平面", res=(192, 192), engine="BLENDER_EEVEE", aspect_input=1.0,
          view_transform="Standard", grid_h=2.0, nsub=6, fmt="OPEN_EXR"):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = engine
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    global FMT
    FMT = fmt
    sc.render.film_transparent = True
    sc.render.image_settings.file_format = fmt
    sc.render.image_settings.color_mode = "RGBA"
    try:
        sc.render.image_settings.color_depth = "32" if fmt == "OPEN_EXR" else "8"
    except Exception:
        pass
    sc.view_settings.view_transform = view_transform
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    try:
        sc.cycles.samples = 1
        sc.cycles.use_denoising = False
    except Exception:
        pass

    cd = bpy.data.cameras.new("Cam")
    cd.lens = lens
    cd.sensor_width = sensor_width
    cd.sensor_height = sensor_height
    cd.sensor_fit = sensor_fit
    cd.shift_x, cd.shift_y = shift
    cd.type = cam_type
    cd.ortho_scale = ortho_scale
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = cam_loc
    cam.rotation_euler = cam_rot
    cam.scale = cam_scale
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    try:                     # 用户真正改的是材质里那个**实例节点**的输入
        grp.interface.items_tree["Aspect Ratio"].default_value = aspect_input
    except Exception as e:
        print("  [warn] set aspect on interface: %s" % e)

    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    try:                     # 材质里的实例节点输入才是真正生效的值
        gn.inputs["Aspect Ratio"].default_value = aspect_input
    except Exception as e:
        print("  [warn] set aspect on instance: %s" % e)
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    comb.name = "ProbeComb"
    emi = nt.nodes.new("ShaderNodeEmission")
    emi.name = "ProbeEmi"
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    ns = nsub
    H = grid_h
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            x = -H + 2 * H * ix / ns
            y = -H + 2 * H * iy / ns
            if shape == "平面":
                z = 0.0
            elif shape == "倾斜":
                z = 0.28 * x
            else:                       # 立体：多层
                z = (iy - 1.5) * 0.5
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid0", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name),
                             "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, ob


def render_uv(tag="x"):
    """渲染探针图 → (uv[nx,ny,2], mask)。EXR 浮点，不经 display transform。"""
    _seq[0] += 1
    p = os.path.join(HERE, "_rc_%s_%02d.%s"
                     % (tag, _seq[0], "exr" if FMT == "OPEN_EXR" else "png"))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.scene.render.filepath = p
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    w, h = im.size
    buf = np.empty(w * h * 4, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(h, w, 4)
    uv = (a[..., :2].astype(np.float64) - 0.5) * 4.0
    mask = a[..., 3] > 0.999
    bpy.data.images.remove(im)
    try:
        os.remove(p)
    except Exception:
        pass
    return uv, mask


def dump(tag, probe):
    uv, mask = probe
    if not mask.any():
        print("  [%s] 无可见像素" % tag)
        return
    a, b = uv[..., 0][mask], uv[..., 1][mask]
    print("  [%-16s] 可见=%5d u[%.4f,%.4f] v[%.4f,%.4f] mean(%.4f,%.4f)"
          % (tag, mask.sum(), a.min(), a.max(), b.min(), b.max(), a.mean(), b.mean()))


def diff(a, b):
    """两幅探针 UV 的差异（仅公共可见区）。

    逐像素取 |du|,|dv| 的**较大者**再平均/取最大（不把两个分量平均掉，
    免得 0.4 的跳变被报成 0.2）。返回 (mean, max, npix)，单位 = UV。
    """
    u1, m1 = a
    u2, m2 = b
    m = m1 & m2
    if m.sum() < 10:
        return float("nan"), float("nan"), int(m.sum())
    per = np.abs(u1[m] - u2[m]).max(axis=1)
    return float(per.mean()), float(per.max()), int(m.sum())


def sample_bilinear(uv, x, y):
    """在探针 UV 场里做双线性采样（x,y 为像素坐标，浮点）。uv: (h,w,2)"""
    h, w = uv.shape[:2]
    x = min(max(x, 0.0), w - 1.001)
    y = min(max(y, 0.0), h - 1.001)
    x0, y0 = int(x), int(y)
    fx, fy = x - x0, y - y0
    return ((uv[y0, x0] * (1 - fx) * (1 - fy) + uv[y0, x0 + 1] * fx * (1 - fy)
             + uv[y0 + 1, x0] * (1 - fx) * fy + uv[y0 + 1, x0 + 1] * fx * fy))


def uv_at_verts(sc, cam, ob, probe, margin=0.03):
    """把**网格顶点**投到像素、取该像素的探针 UV。

    返回 (idx, uv_render[n,2], uv_cam[n,2])，只保留落在画面内（留边距）的顶点。
    · uv_render —— 真渲染读出来的图案 UV（图案实际贴在哪）
    · uv_cam    —— Blender 自己的 world_to_camera_view（相机「应该」看到哪）
    两者相等 ⇒ 图案正确对齐；两次调用之间不变 ⇒ 图案粘住了网格。
    """
    uv, mask = probe
    h, w = mask.shape
    idx, rr, cc = [], [], []
    for i, v in enumerate(ob.data.vertices):
        wp = ob.matrix_world @ v.co
        e = world_to_camera_view(sc, cam, wp)
        if not (margin < e.x < 1.0 - margin and margin < e.y < 1.0 - margin):
            continue
        px, py = e.x * w, e.y * h
        pi, pj = int(px), int(py)
        # ⚠️ 必须只采「4 邻域全在网格内」的点：网格边缘的双线性会把背景
        #    （alpha=0 → 颜色 0 → 解码 -2）混进来，造出 1~2 的假偏差。
        if not (0 <= pi - 1 and pi + 1 < w and 0 <= pj - 1 and pj + 1 < h):
            continue
        if not mask[pj - 1:pj + 2, pi - 1:pi + 2].all():
            continue
        idx.append(i)
        s = sample_bilinear(uv, px - 0.5, py - 0.5)     # 像素中心在 +0.5
        rr.append((s[0], s[1]))
        cc.append((e.x, e.y))
    return np.array(idx, dtype=int), np.array(rr), np.array(cc)


def table(sc, cam, ob, probe, n=5):
    """打印「相机应看到 (u,v)」vs「渲染读出 (u,v)」，只列网格内部的顶点。

    这是判断「图案是否真的贴在相机看到的位置」的原始证据。
    """
    idx, rr, cc = uv_at_verts(sc, cam, ob, probe)
    if len(idx) == 0:
        print("  （没有内部顶点可采）")
        return
    step = max(1, len(idx) // n)
    print("  %-24s %-18s %-18s %s" % ("顶点(世界)", "相机应看到", "渲染读出", "偏差"))
    for k in range(0, len(idx), step):
        i = idx[k]
        wp = ob.matrix_world @ ob.data.vertices[i].co
        print("  (%6.2f,%6.2f,%6.2f)  (%.4f,%.4f)     (%.4f,%.4f)     %.4f"
              % (wp.x, wp.y, wp.z, cc[k][0], cc[k][1], rr[k][0], rr[k][1],
                 max(abs(rr[k][0] - cc[k][0]), abs(rr[k][1] - cc[k][1]))))


def align_err(sc, cam, ob, probe):
    """图案对齐误差：|探针 UV − 相机应有的 UV|（逐顶点，画面外顶点已排除）。"""
    idx, rr, cc = uv_at_verts(sc, cam, ob, probe)
    if len(idx) == 0:
        return float("nan"), float("nan"), 0
    d = np.abs(rr - cc).sum(axis=1)
    return float(d.max()), float(d.mean()), int(len(idx))


def state(cam):
    return plock.get_state(bpy.context.scene, cam)


def nodes_sc(cd):
    n = plock._find_delta_nodes(cd.name)
    if not n:
        return None
    return (n[0].inputs["Scale"].default_value, tuple(n[1].inputs[1].default_value)[:2])


def report(title):
    print()
    print("=" * 78)
    print(title)
    print("PASS %d / FAIL %d" % (len(P), len(F)))
    if F:
        print("FAILED:", F)
    print("REVIEWC_DONE")
