"""用 Blender 官方投影做最终判据（唯一可信尺子）

⚠️ 之前踩过：手写屏幕度量（x/z、x/depth）各自漏东西、符号不一致、相机移动后忘减相机位置，
   导致同一现象算出互相矛盾的数。这里统一用 world_to_camera_view（含 lens/sensor/shift），
   它是渲染实际使用的投影。

判据：
  [A] 拖动当帧：没被拖的网格 NDC 变化 = 0
  [B] 拖动后移相机：所有网格 NDC 位移严格一致（构图保持）
  [C] 基准深度确实按当前几何重算
  [D] 滚动量 = 相机位移 / 基准深度 × 常数（常数与基准无关，可从两组数据反推验证）
"""
import bpy, sys, os
import importlib.util
import numpy as np
from bpy_extras.object_utils import world_to_camera_view

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    """A 深度8（最深）/ B 深度6 / C 深度4，同一屏幕位置"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.resolution_x = 960
    sc.render.resolution_y = 540
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 10); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    objs = {}
    for nm, dep in (("A", 8.0), ("B", 6.0), ("C", 4.0)):
        wx = 0.15 * dep
        z0 = 10.0 - dep
        h = 0.3
        verts = [(wx-h,-h,z0), (wx+h,-h,z0), (wx+h,h,z0), (wx-h,h,z0)]
        mesh = bpy.data.meshes.new(nm)
        mesh.from_pydata(verts, [], [(0,1,2,3)]); mesh.update()
        ob = bpy.data.objects.new(nm, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        objs[nm] = ob
    bpy.context.view_layer.update()
    return sc, cam, cd, objs


def ndc(ob, cam, sc):
    return np.array([list(world_to_camera_view(sc, cam, ob.matrix_world @ v.co))[:2]
                     for v in ob.data.vertices]).mean(axis=0)


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


print("=" * 94)
print("场景：A 深度8（基准）/ B 深度6 / C 深度4，三层在同一屏幕位置")
print("=" * 94)

sc, cam, cd, objs = build()
plock.lock_group(sc, cam)
ref0 = plock.get_state(sc, cam).get("ref_depth", 0)
print("  锁定：ref_depth = %.4f" % ref0)

print()
print("=" * 94)
print("[A] 拖动当帧：没被拖的网格 NDC 变化必须为 0")
print("=" * 94)
n0 = {k: ndc(o, cam, sc) for k, o in objs.items()}
cam.location.x = 0.6              # 先移一点相机（模拟用户实际操作顺序）
step(sc)
n0 = {k: ndc(o, cam, sc) for k, o in objs.items()}

objs["A"].location.z += 5.0       # 把 A 推近：深度 8 → 3
step(sc)
n1 = {k: ndc(o, cam, sc) for k, o in objs.items()}
for k in ("B", "C"):
    d = float(np.abs(n1[k] - n0[k]).max())
    chk("拖 A 时 %s 的画面位置不动" % k, d < 1e-9, "max Δ=%.8f" % d)
ref_after_drag = plock.get_state(sc, cam).get("ref_depth", 0)
print("  拖动后 ref_depth = %.4f（拖动当帧不该重算，应仍为 %.1f）"
      % (ref_after_drag, ref0))

print()
print("=" * 94)
print("[B] 拖动后移相机：所有层 NDC 位移必须严格一致（构图保持）")
print("=" * 94)
m0 = {k: ndc(o, cam, sc) for k, o in objs.items()}
cam.location.x += 1.0
step(sc)
m1 = {k: ndc(o, cam, sc) for k, o in objs.items()}
delta = {k: float(m1[k][0] - m0[k][0]) for k in objs}
ref_now = plock.get_state(sc, cam).get("ref_depth", 0)
for k in ("A", "B", "C"):
    print("    %s NDC 位移 = %+.10f" % (k, delta[k]))
spread = max(delta.values()) - min(delta.values())
chk("三层 NDC 位移严格一致", spread < 1e-6, "极差=%.10f" % spread)

print()
print("=" * 94)
print("[C] 基准深度按当前几何重算")
print("=" * 94)
print("    锁定 %.4f  →  拖动后(当帧) %.4f  →  移相机后 %.4f"
      % (ref0, ref_after_drag, ref_now))
chk("拖动当帧不重算基准", abs(ref_after_drag - ref0) < 1e-9,
    "%.6f vs %.6f" % (ref_after_drag, ref0))
chk("移相机后基准重算为 6（B 成最深）", abs(ref_now - 6.0) < 1e-6, "ref=%.4f" % ref_now)

print()
print("=" * 94)
print("[D] 基准稳定后，滚动量 = 相机位移 / 基准 × 常数")
print("=" * 94)
# ⚠️ 判据要点：ref 换人是【延迟生效】的 —— 拖动后第一次移相机，
#    位移里同时含「相机滚动」和「补上 ref 变化」两项，不能拿它测 1/ref。
#    必须先让 ref 落地（移一次相机），再测纯滚动。
# 先测「不拖 A」的基准滚动量与常数（k_no / d_no 供下文对比）
_sc0, _cm0, _cd0, _ob0 = build()
plock.lock_group(_sc0, _cm0)
_r_no = plock.get_state(_sc0, _cm0).get("ref_depth", 0)
_b0 = ndc(_ob0["B"], _cm0, _sc0)
_cm0.location.x += 1.0
step(_sc0)
_b1 = ndc(_ob0["B"], _cm0, _sc0)
d_no = abs(float(_b1[0] - _b0[0]))
k_no = d_no * _r_no
print("    不拖 A: ref=%.4f  滚动=%.10f  滚动×ref=%.10f" % (_r_no, d_no, k_no))

sc3, cam3, cd3, objs3 = build()
plock.lock_group(sc3, cam3)
objs3["A"].location.z += 5.0        # A 深度 8 → 3
step(sc3)
cam3.location.x += 0.5
step(sc3)                            # 这次移相机让 ref 生效（8 → 6）
ref_stable = plock.get_state(sc3, cam3).get("ref_depth", 0)
print("    让 ref 落地后：ref = %.4f" % ref_stable)

b0 = ndc(objs3["B"], cam3, sc3)
cam3.location.x += 1.0               # 纯滚动 Δ=1.0
step(sc3)
b1 = ndc(objs3["B"], cam3, sc3)
roll = abs(float(b1[0] - b0[0]))
c_const = roll * ref_stable
print("    纯滚动 Δ=1.0: 画面位移 = %.10f   滚动×ref = %.10f" % (roll, c_const))
print("    （不拖时 滚动×ref = %.10f，若两者一致则滚动严格 ∝ 1/ref）" % k_no)
chk("基准稳定后 滚动 ∝ 1/基准", abs(c_const - k_no) / max(k_no, 1e-12) < 1e-4,
    "%.8f vs %.8f" % (c_const, k_no))
chk("拖 A 变浅 ⇒ 滚动变快（对照不拖的 %.6f）" % d_no, roll > d_no,
    "%.6f vs %.6f" % (roll, d_no))

print()
print("=" * 94)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("FINAL_DONE")
