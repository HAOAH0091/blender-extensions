"""最终复核（针对当前工作区版本）：空网格、fake user、相机 scale=0。

跑法：blender --background --factory-startup --python _dev\\reviewB_final_confirm.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy, bmesh

C.load()
plock = C.PL()
print("=" * 94)
print("最终复核 1：真实流程「把某个网格的顶点全删掉」→ 整个相机的图案冻结被关掉")
print("=" * 94)

sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
B = C.add_grid("GridB", cam, mat, ns=3, x0=2.6)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("① 首次 lock: success=%s frozen=%s locked=%s"
      % (r["success"], r.get("frozen"), [o.name for o in r.get("locked", [])]))
plock.unlock_group(sc, cam)
# 用户把 B 的顶点全删了，但对象与材质还在（很常见：清空几何当占位/等重导）
bpy.context.view_layer.objects.active = B
bpy.ops.object.mode_set(mode="EDIT")
bm = bmesh.from_edit_mesh(B.data)
bmesh.ops.delete(bm, geom=bm.verts[:], context="VERTS")
bmesh.update_edit_mesh(B.data)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.context.view_layer.update()
print("② B 现在顶点数=%d，材质仍在=%s" % (len(B.data.vertices), len(B.data.materials) > 0))

r2 = plock.lock_group(sc, cam)
print("③ 再次 lock: success=%s frozen=%s locked=%s"
      % (r2["success"], r2.get("frozen"), [o.name for o in r2.get("locked", [])]))
print("    unsupported:", [(n if isinstance(n, str) else "<obj>", w) for n, w in r2.get("unsupported", [])])
print("    message:", r2["message"][:200])
st = plock.lock_status(sc, cam)
print("    lock_status: locked=%s patched=%s degraded=%s"
      % (st.get("locked"), st.get("patched"), st.get("degraded")))
fv0 = C.campos_uv(A, cd.name)
cam.location.x = 1.6
C.run_handler(sc)
fv1 = C.campos_uv(A, cd.name)
print("    A 的图案还冻结吗：campos 存在=%s  逐顶点 UV Δ=%s"
      % (fv0 is not None,
         ("%.2e" % float(np.abs(fv1 - fv0).max())) if (fv0 is not None and fv1 is not None)
         else "N/A（已不再冻结）"))
C.chk("空网格存在时，同一相机的正常网格仍能冻结图案（frozen=True）",
      r2.get("frozen") is True, "实测 frozen=%s" % r2.get("frozen"))
C.chk("空网格存在时正常网格仍有冻结坐标", fv0 is not None, "campos=%s" % (fv0 is not None))

print("\n" + "=" * 94)
print("最终复核 2：单个对象 + mesh 开 fake user → 被判「共享网格」而拒绝锁定")
print("=" * 94)
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridFake", cam, mat, ns=3)
A.data.use_fake_user = True
bpy.context.view_layer.update()
print("   mesh.users=%d  block_reasons=%s" % (A.data.users, plock.block_reasons(A)))
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s message=%s" % (r["success"], r.get("frozen"), r["message"][:100]))
C.chk("只 1 个对象用这块 mesh（+fake user）不应被拒锁", r.get("success") is True,
      "success=%s 原因=%s" % (r["success"], plock.block_reasons(A)))
# 对照：把 fake user 关掉
A.data.use_fake_user = False
r2 = plock.lock_group(sc, cam)
print("   关掉 fake user 后 batch: success=%s frozen=%s" % (r2["success"], r2.get("frozen")))

print("\n" + "=" * 94)
print("最终复核 3：相机 scale=0（动画/误输入）")
print("=" * 94)
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
cam.scale = (0.0, 0.0, 0.0)
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock 返回:", r["success"], r["message"][:80])
    exc = None
except Exception as e:
    exc = e
    print("   ✗ lock_group 抛异常:", type(e).__name__, ":", e)
C.chk("相机 scale=0 时 lock 不抛未捕获异常", exc is None, repr(exc))
if exc is None:
    st = plock.get_state(sc, cam)
    try:
        ru = plock.unlock_group(sc, cam)
        print("   unlock:", ru["success"], ru["message"][:80])
    except Exception as e:
        print("   ✗ unlock 抛异常:", type(e).__name__, e)
    try:
        rr = plock.reset_group(sc, cam)
        print("   reset:", rr["success"], rr["message"][:80])
    except Exception as e:
        print("   ✗ reset 抛异常:", type(e).__name__, e)

C.summary()
