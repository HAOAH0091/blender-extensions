"""跳变专项排查：多帧连续拖动，逐帧记录「屏幕轨迹」找不连续点

用户反馈：「同时还伴有不知道触发原因的跳变问题，我都不知道怎么复现」。

思路：真实拖动是多帧连续的。PSD 拖图层语义下：
  · 被拖动的 A —— 拖动过程中画面应该【几乎不动】（在调深度，不调画面位置）
  · 没被拖的 B —— 画面必须【完全不动】
任何一帧的突变 = 跳变。逐帧记录相邻帧的屏幕位移，突变帧会自己暴露。

覆盖：
  S1 单次拖动 10 帧（模拟真实拖动）
  S2 松手后再拖（两次拖动拼接）
  S3 拖到很浅 / 很深（极端深度）
  S4 拖动中途移动相机
  S5 三个网格，拖中间那个
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(specs):
    """specs = [(name, x0, z0), ...]"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    objs = {}
    for (name, x0, z0) in specs:
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns,
                              -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        objs[name] = ob
    bpy.context.view_layer.update()
    return sc, cam, cd, objs


def screen(ob, cam):
    inv = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = inv @ (ob.matrix_world @ v.co)
        out.append((p.x / p.z, p.y / p.z) if abs(p.z) > 1e-9 else (0.0, 0.0))
    return np.array(out)


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def analyze(tag, traj, watch_names):
    """traj: {name: [screen_array, ...]}，报告相邻帧最大跳变"""
    print("\n" + "-" * 82)
    print(tag)
    print("-" * 82)
    worst_all = 0.0
    for name in watch_names:
        frames = traj.get(name) or []
        if len(frames) < 2:
            continue
        deltas = [float(np.abs(frames[i + 1] - frames[i]).max())
                  for i in range(len(frames) - 1)]
        mx = max(deltas) if deltas else 0.0
        worst_all = max(worst_all, mx)
        # 中位数作为「正常速度」参照，突变 = 最大/中位数
        med = float(np.median(deltas)) if deltas else 0.0
        ratio = (mx / med) if med > 1e-12 else (float("inf") if mx > 1e-9 else 1.0)
        flag = ""
        if mx > 1e-6 and (ratio > 8.0 or med < 1e-12):
            flag = "  ←★可能跳变"
        print("  %-8s 帧间最大位移 %.8f | 中位 %.8f | 倍率 %.1f%s"
              % (name, mx, med, ratio if ratio != float("inf") else -1, flag))
    return worst_all


print("=" * 82)
print("S1 单次拖动 10 帧（A 最深，B 较浅，共用材质）")
print("=" * 82)
sc, cam, cd, objs = build([("A", -1.5, 0.0), ("B", 1.5, 2.0)])
A, B = objs["A"], objs["B"]
plock.lock_group(sc, cam)
cam.location.x = 1.2
step(sc)
traj = {"A": [], "B": []}
for i in range(11):
    A.location.z += 0.2
    step(sc)
    traj["A"].append(screen(A, cam))
    traj["B"].append(screen(B, cam))
w1 = analyze("拖动 A 共 10 帧（每帧 +0.2 深度）", traj, ["A", "B"])

print("\n" + "=" * 82)
print("S2 松手后再拖（两次拖动拼接，中间隔一帧）")
print("=" * 82)
sc, cam, cd, objs = build([("A", -1.5, 0.0), ("B", 1.5, 2.0)])
A, B = objs["A"], objs["B"]
plock.lock_group(sc, cam)
cam.location.x = 1.2
step(sc)
traj = {"A": [], "B": []}
for rnd in range(2):
    for i in range(5):
        A.location.z += 0.2
        step(sc)
        traj["A"].append(screen(A, cam))
        traj["B"].append(screen(B, cam))
    step(sc)   # 松手的一帧
w2 = analyze("两次拖动（每次 5 帧）", traj, ["A", "B"])

print("\n" + "=" * 82)
print("S3 拖到极端深度（推很近 / 推很远）")
print("=" * 82)
for tag, dz in [("推很近（-3.0）", -3.0), ("推很远（+15.0）", 15.0)]:
    sc, cam, cd, objs = build([("A", -1.5, 0.0), ("B", 1.5, 2.0)])
    A, B = objs["A"], objs["B"]
    plock.lock_group(sc, cam)
    cam.location.x = 1.2
    step(sc)
    traj = {"A": [], "B": []}
    n = 10
    for i in range(n):
        A.location.z += dz / n
        step(sc)
        traj["A"].append(screen(A, cam))
        traj["B"].append(screen(B, cam))
    analyze(tag, traj, ["A", "B"])

print("\n" + "=" * 82)
print("S4 拖动中途移动相机")
print("=" * 82)
sc, cam, cd, objs = build([("A", -1.5, 0.0), ("B", 1.5, 2.0)])
A, B = objs["A"], objs["B"]
plock.lock_group(sc, cam)
cam.location.x = 1.2
step(sc)
traj = {"A": [], "B": []}
for i in range(10):
    A.location.z += 0.2
    if i == 4:
        cam.location.x += 0.3      # 拖到一半动了相机
    step(sc)
    traj["A"].append(screen(A, cam))
    traj["B"].append(screen(B, cam))
w4 = analyze("拖动 10 帧，第 5 帧时相机 +0.3", traj, ["A", "B"])

print("\n" + "=" * 82)
print("S5 三个网格，拖中间深度的那个")
print("=" * 82)
sc, cam, cd, objs = build([("A", -2.4, 0.0), ("B", 0.0, 2.0), ("C", 2.4, 4.0)])
A, B, C = objs["A"], objs["B"], objs["C"]
plock.lock_group(sc, cam)
cam.location.x = 1.2
step(sc)
traj = {"A": [], "B": [], "C": []}
for i in range(8):
    B.location.z -= 0.3
    step(sc)
    for nm, ob in (("A", A), ("B", B), ("C", C)):
        traj[nm].append(screen(ob, cam))
analyze("三网格，拖中间的 B（深度 6→4.5）", traj, ["A", "B", "C"])

print()
print("=" * 82)
print("汇总")
print("=" * 82)
print("  若上面每一行「帧间最大位移」都很小且倍率不异常 ⇒ 没有跳变")
print("  若某处出现 ←★可能跳变 ⇒ 那里就是用户说的跳变源")
print("JUMP_DONE")
