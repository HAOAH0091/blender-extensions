"""审查项 7 / 5：组里有多个 TexCoord、多个已连线输出、用户自建支路时，
patch 会不会「改错对象」或把用户接线一起吃掉。

判据：persp_source（透视链被谁驱动 = 冻结的硬判据）+ 接线数 + patch 记录里的 tc。
"""
import bpy
import os
import sys
import json

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
SCALE = 0.1


def scene():
    sc = C.reset()
    cam, cd = C.new_cam(sc)
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat, gn = C.probe_mat("Probe", grp, scale=SCALE)
    A = C.new_grid("A")
    A.data.materials.append(mat)
    C.uv_adjust_group(A, cd)
    bpy.context.view_layer.update()
    return sc, cam, cd, grp, A


def tc_nodes(grp):
    return [n for n in grp.nodes if n.type == "TEX_COORD"]


# ══════ P3：两个 TexCoord（都 object=相机）══════
print("\n=== P3：组里有两个 TexCoord 节点（都绑相机）===")
sc, cam, cd, grp, A = scene()
tc2 = grp.nodes.new("ShaderNodeTexCoord")
tc2.object = cam
dummy = grp.nodes.new("ShaderNodeVectorMath")
grp.links.new(tc2.outputs["Object"], dummy.inputs[0])
bpy.context.view_layer.update()
print("  锁定前 persp_source = %s" % C.persp_source(grp))
r = plock.lock_group(sc, cam)
info = json.loads(grp.get(plock.PATCH_KEY) or "{}")
print("  锁定: frozen=%s ; 被 patch 的 TexCoord = %r" % (r.get("frozen"), info.get("tc")))
print("  锁定后 persp_source = %s" % C.persp_source(grp))
for n in tc_nodes(grp):
    print("    TC %-24r Object 输出连线=%d" % (n.name, len(n.outputs["Object"].links)))
frozen_ok = "ATTRIBUTE" in C.persp_source(grp) or "Plock" in C.persp_source(grp)
C.report("P3 两个 TexCoord 时主链仍被冻结", frozen_ok, "persp_source=%s" % C.persp_source(grp))

# ══════ P4：主 TexCoord 的 UV 输出也被接线（多输出）══════
print("\n=== P4：主 TexCoord 的 UV 输出额外接了支路（多输出同时有线）===")
sc, cam, cd, grp, A = scene()
tc = tc_nodes(grp)[0]
d2 = grp.nodes.new("ShaderNodeVectorMath")
grp.links.new(tc.outputs["UV"], d2.inputs[0])          # 用户加的分支，接在 UV 输出
print("  锁定前: Object 连线=%d UV 连线=%d persp_source=%s"
      % (len(tc.outputs["Object"].links), len(tc.outputs["UV"].links), C.persp_source(grp)))
r = plock.lock_group(sc, cam)
info = json.loads(grp.get(plock.PATCH_KEY) or "{}")
print("  锁定: frozen=%s ; patch 记录的源口=%r ; persp_source=%s"
      % (r.get("frozen"), info.get("src"), C.persp_source(grp)))
print("  主 TexCoord Object/UV 连线 = %d / %d"
      % (len(tc.outputs["Object"].links), len(tc.outputs["UV"].links)))
ok = "Plock" in C.persp_source(grp) or "ATTRIBUTE" in C.persp_source(grp)
C.report("P4 多输出时仍冻结了正确的 Object 链", ok,
         "源口=%r persp_source=%s" % (info.get("src"), C.persp_source(grp)))

# ══════ P5：锁定前用户从主 TexCoord 拉支路，解锁后被恢复吗 ══════
print("\n=== P5：用户在锁定【前】从主 TexCoord.Object 拉了支路 ===")
sc, cam, cd, grp, A = scene()
tc = tc_nodes(grp)[0]
mine = grp.nodes.new("ShaderNodeVectorMath")
mine.name = "USER BRANCH BEFORE LOCK"
grp.links.new(tc.outputs["Object"], mine.inputs[0])
print("  锁定前: 用户支路连线=%d" % len(mine.inputs[0].links))
plock.lock_group(sc, cam)
print("  锁定中: 用户支路连线=%d（patch 会断开源口所有线）" % len(mine.inputs[0].links))
plock.unlock_group(sc, cam)
n_after = len(mine.inputs[0].links)
print("  解锁后: 用户支路连线=%d ; TexCoord.Object 连线目标=%s"
      % (n_after, [lk.to_node.name for lk in tc.outputs["Object"].links]))
C.report("P5 用户支路在解锁后恢复", n_after > 0, "连线 1→0→%d" % n_after)

print("\nRD_TCPICK_DONE")
