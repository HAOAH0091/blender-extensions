"""「滚动速度」到底指什么？两种做法实测对比

澄清两个容易混淆的量：
  ① 拖动速度 = 用户拖物体时，物体跟手/画面变化的快慢
     ⇒ 与 ref_depth 无关。PSD 语义下「拖动瞬间物体钉在画面原位」，两边都是 0 变化。
        实测：拖动 10 帧，A 的屏幕位移 ≈ 0（不随 ref 变）
  ② 滚动速度 = 【相机移动】时，画面里的东西横向平移的快慢
     ⇒ 屏幕x = x0/d_base − delta_cs / ref_depth
        所以 相机移 delta，画面整体横移 delta/ref_depth —— ref 就是「滚多快」的分母。
        实测：ref=8 时移 1.0 ⇒ 横移 0.125；ref=7 时 ⇒ 0.143（快 14%）

对比两种做法（拖完 A 之后再移相机，看 B 的屏幕位移）：
  做法甲（我上一轮）：ref 冻结 ⇒ B 的滚动速度不变
  做法乙（PSD）：      ref 重算 ⇒ B 的滚动速度跟着变
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(zA=0.0, zB=2.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns,
                              -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("A", -1.5, zA)
    B = mk("B", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def screen(ob, cam):
    inv = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = inv @ (ob.matrix_world @ v.co)
        out.append((p.x / p.z, p.y / p.z) if abs(p.z) > 1e-9 else (0.0, 0.0))
    return np.array(out)


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


print("=" * 88)
print("① 「拖动速度」与 ref_depth 无关 —— 拖动瞬间画面不动（PSD 拖图层语义）")
print("=" * 88)
sc, cam, cd, A, B = build()
plock.lock_group(sc, cam)
cam.location.x = 1.2
step(sc)
ref0 = plock.get_state(sc, cam).get("ref_depth", 0)
sA0 = screen(A, cam)
for i in range(6):
    A.location.z += 0.3
    step(sc)
dA = float(np.abs(screen(A, cam) - sA0).max())
print("  ref_depth = %.4f" % ref0)
print("  拖 A 共 1.8 深度的过程中，A 的屏幕位置最大变化 = %.8f" % dA)
print("  ⇒ 拖动时物体钉在画面原位，跟手快慢与 ref_depth 无关")
print("  ⇒ 所以「滚动速度」【不是】拖动物体时的速度")

print()
print("=" * 88)
print("② 「滚动」= 相机移动时画面横向平移的快慢 = 相机位移 / ref_depth")
print("=" * 88)
for tri in ([("ref=8", 8.0), ("ref=7", 7.0), ("ref=6", 6.0)]):
    pass
sc, cam, cd, A, B = build()
plock.lock_group(sc, cam)
cam.location.x = 1.2
step(sc)
st = plock.get_state(sc, cam)
base_ref = st.get("ref_depth", 0)
print("  基线 ref_depth = %.4f" % base_ref)
print("\n  改 ref 后移相机 +1.0，测 B 的屏幕横移：")
print("  %8s %12s %14s %12s" % ("ref", "理论 1/ref", "实测横移", "偏差"))
for r in (8.0, 7.0, 6.0, 4.0):
    sc, cam, cd, A, B = build()
    plock.lock_group(sc, cam)
    cam.location.x = 1.2
    step(sc)
    st = plock.get_state(sc, cam)
    st["ref_depth"] = r
    plock.save_groups(sc, {cd.name: st})
    step(sc)
    s0 = screen(B, cam)
    cam.location.x += 1.0
    step(sc)
    s1 = screen(B, cam)
    measured = float(np.mean(s1[:, 0] - s0[:, 0]))
    theo = -1.0 / r
    print("  %8.1f %12.6f %14.6f %12.8f" % (r, theo, measured, measured - theo))

print()
print("=" * 88)
print("③ 两种做法对比：拖完 A 之后移相机，B 的横移差多少")
print("=" * 88)


def run(mode):
    """mode='freeze' 我上轮做法 / 'recompute' PSD 做法"""
    sc, cam, cd, A, B = build()      # A 深度8（最深），B 深度6
    plock.lock_group(sc, cam)
    cam.location.x = 1.2
    step(sc)
    ref_before = plock.get_state(sc, cam).get("ref_depth", 0)

    # 拖 A 变近（若 A 不再是最深，max 就换人）
    A.location.z += 2.0
    step(sc)

    st = plock.get_state(sc, cam)
    if mode == "recompute":
        # 模拟 PSD：把新深度写回基准 ⇒ ref 重算成「现在最深的那层」
        plock.recompute_ref_depth(sc, st, cd.name)
        plock.save_groups(sc, {cd.name: st})
        step(sc)

    ref_after = plock.get_state(sc, cam).get("ref_depth", 0)

    sB0 = screen(B, cam)
    sA0 = screen(A, cam)
    cam.location.x += 1.0
    step(sc)
    moveB = float(np.mean(screen(B, cam)[:, 0] - sB0[:, 0]))
    moveA = float(np.mean(screen(A, cam)[:, 0] - sA0[:, 0]))
    return ref_before, ref_after, moveB, moveA


for mode, label in [("freeze", "做法甲（我上轮：ref 冻结）"),
                    ("recompute", "做法乙（PSD：ref 重算）")]:
    rb, ra, mB, mA = run(mode)
    print("\n  %s" % label)
    print("    ref: 拖前 %.4f → 拖后 %.4f" % (rb, ra))
    print("    相机移 +1.0 后   B 横移 = %+.6f   A 横移 = %+.6f" % (mB, mA))

rb1, ra1, mB1, mA1 = run("freeze")
rb2, ra2, mB2, mA2 = run("recompute")
print()
print("=" * 88)
print("结论")
print("=" * 88)
print("  两种做法下，A（被拖的）的后续滚动：%.6f vs %.6f  差 %.8f" % (
    mA1, mA2, mA2 - mA1))
print("  两种做法下，B（没拖的）的后续滚动：%.6f vs %.6f  差 %.8f" % (
    mB1, mB2, mB2 - mB1))
if abs(mB2 - mB1) > 1e-9:
    print("  ⇒ 做法乙会让【没被拖的 B】的滚动速度也变（因为 ref 变了）")
    print("     相对变化 %.1f%%" % (abs(mB2 - mB1) / abs(mB1) * 100))
else:
    print("  ⇒ B 的滚动速度不受影响")
print("ROLL_DONE")
