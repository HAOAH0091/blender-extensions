"""如果解锁「只 unpatch、不还原几何」，图案会不会跳？
锁定 → 移相机（网格变形）→ 只 unpatch → 看 UV
对照：unpatch + 还原几何
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_unp"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    mesh = bpy.data.meshes.new("G")
    ns = 2
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-1+2*ix/ns, -1+2*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    scene.collection.objects.link(ob)
    ob.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, ob)
    return scene, cam, cd, ob


def uv_now(cam, obj):
    ng = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cam.data.name)
    patched = ng is not None and ng.get(PL.PATCH_KEY) is not None
    if patched:
        a = obj.data.attributes.get(PL._campos_attr_name(cam.data.name))
        if a is not None and len(a.data) == len(obj.data.vertices):
            src = np.array([tuple(a.data[i].vector) for i in range(len(a.data))])
        else:
            src = np.zeros((len(obj.data.vertices), 3))
    else:
        mwi = cam.matrix_world.inverted()
        src = np.array([tuple(mwi @ (obj.matrix_world @ v.co)) for v in obj.data.vertices])
    z = src[:, 2]
    return np.stack([src[:, 0]/z, src[:, 1]/z], axis=1), patched


scene, cam, cd, A = build()
uv_base, _ = uv_now(cam, A)
print("="*78)
print("场景：锁定 → 变焦 50→85mm（网格发生视差变形）→ 解锁")
print("="*78)
print("  锁定前 UV[0]: (%+.5f, %+.5f)" % (uv_base[0][0], uv_base[0][1]))
PL.lock_group(scene, cam)
cd.lens = 85.0
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
uv_lock, p = uv_now(cam, A)
print("\n  锁定+移相机后: patch=%s UV[0]=(%+.5f, %+.5f)" % (p, uv_lock[0][0], uv_lock[0][1]))
print("    >>> 相对初始 UV 最大变化: %.6f （应该≈0：图案没滑动）" %
      float(np.abs(uv_lock - uv_base).max()))

# 网格现在是什么形状
vs = [tuple(round(x,4) for x in v.co) for v in A.data.vertices]
zs = [v.co.z for v in A.data.vertices]
print("    网格 z 范围: [%+.4f, %+.4f]  (变形前应为 [0,0])" % (min(zs), max(zs)))

# ── 方案X：只 unpatch，不还原几何 ──
PL.unpatch_camera_project_group(cd.name)
uv_x, p2 = uv_now(cam, A)
print("\n  【只 unpatch、不还原几何】patch=%s" % p2)
print("    UV[0] = (%+.5f, %+.5f)" % (uv_x[0][0], uv_x[0][1]))
print("    >>> 图案跳变量: %.6f  (%s)" % (
    float(np.abs(uv_x - uv_lock).max()),
    "跳了=图案错位" if np.abs(uv_x - uv_lock).max() > 1e-4 else "没跳"))

# ── 方案Y：unpatch + 还原几何（=reset）──
scene2, cam2, cd2, B = build()
PL.lock_group(scene2, cam2)
cd2.lens = 85.0
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene2)
uv_l2, _ = uv_now(cam2, B)
PL.reset_group(scene2, cam2)
uv_y, p3 = uv_now(cam2, B)
bpy.context.view_layer.update()
print("\n  【unpatch + 还原几何 = 重置】patch=%s" % p3)
print("    UV[0] = (%+.5f, %+.5f)" % (uv_y[0][0], uv_y[0][1]))
print("    >>> 相对锁定态图案跳变: %.6f" % float(np.abs(uv_y - uv_l2).max()))
zs2 = [v.co.z for v in B.data.vertices]
print("    网格 z 范围: [%+.4f, %+.4f]  (应回到 [0,0])" % (min(zs2), max(zs2)))
print("    材质组 patch 状态: %s" % (bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd2.name).get(PL.PATCH_KEY) is not None))

print("\n" + "="*78)
print("对比：")
print("  只 unpatch  → 图案跳变 %.6f（网格还是变形的，实时投影打上去会错位）" %
      float(np.abs(uv_x - uv_lock).max()))
print("  unpatch+还原 → 图案跳变 %.6f（回到锁定前的原始状态）" %
      float(np.abs(uv_y - uv_l2).max()))
