"""审查E-9：解锁后逐顶点属性与 _base_cache 是否释放？内存是否回落？

量法：Windows GetProcessMemoryInfo 的 WorkingSetSize（真实 RSS）。
流程：空场景 → 建 30 万顶点网格 → 锁定 → 解锁 → 重置 → 删网格，逐步量。
"""
import bpy, sys, os, time, ctypes, ctypes.wintypes
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


class PMC(ctypes.Structure):
    _fields_ = [("cb", ctypes.wintypes.DWORD), ("PageFaultCount", ctypes.wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


_k32 = ctypes.WinDLL("kernel32.dll")
_k32.GetCurrentProcess.restype = ctypes.wintypes.HANDLE
_psapi = ctypes.WinDLL("psapi.dll")
_psapi.GetProcessMemoryInfo.argtypes = [ctypes.wintypes.HANDLE, ctypes.POINTER(PMC),
                                        ctypes.wintypes.DWORD]
_psapi.GetProcessMemoryInfo.restype = ctypes.wintypes.BOOL


def rss_mb():
    pmc = PMC()
    pmc.cb = ctypes.sizeof(PMC)
    ok = _psapi.GetProcessMemoryInfo(_k32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb)
    return pmc.WorkingSetSize / 1048576.0 if ok else -1.0


def attrs_of(o):
    return sorted([a.name for a in o.data.attributes if a.name.startswith("compify")])


def base_cache_bytes():
    tot = 0
    for k, v in plock._base_cache.items():
        tot += len(v) * (56 + 3 * 24)      # 粗估：tuple + 3 个 float
    return tot / 1048576.0


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 12)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

bpy.ops.mesh.primitive_grid_add(x_subdivisions=550, y_subdivisions=550,
                                size=8.0, location=(0, 0, 0))
ob = bpy.context.object
ob.name = "Big"
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()
nv = len(ob.data.vertices)

print("顶点数 = %d" % nv)
print("%-28s %-10s %-10s %s" % ("阶段", "RSS_MB", "_base_cache", "网格上的 compify 属性"))
print("%-28s %-10.1f %-10s %s" % ("建好网格（未锁定）", rss_mb(),
                                  len(plock._base_cache), attrs_of(ob)))
plock.lock_group(sc, cam)
print("%-28s %-10.1f %-10s %s" % ("锁定后", rss_mb(),
                                  len(plock._base_cache), attrs_of(ob)))
plock.unlock_group(sc, cam)
print("%-28s %-10.1f %-10s %s" % ("解锁后（不失焦重置）", rss_mb(),
                                  len(plock._base_cache), attrs_of(ob)))
plock.reset_group(sc, cam)
print("%-28s %-10.1f %-10s %s" % ("重置后", rss_mb(),
                                  len(plock._base_cache), attrs_of(ob)))

# 只解锁、然后删掉网格 → _base_cache 里那 30 万条是否留着？
plock.lock_group(sc, cam)
plock.unlock_group(sc, cam)
n_before = len(plock._base_cache)
ptr_key = [k for k in plock._base_cache]
bpy.data.objects.remove(ob, do_unlink=True)
bpy.context.view_layer.update()
print("%-28s %-10.1f %-10d %s" % ("删掉网格后（缓存仍在）", rss_mb(),
                                  len(plock._base_cache), ptr_key[:1]))
print("    估算 _base_cache 占用 ≈ %.1f MB" % base_cache_bytes())
plock._base_cache.clear()
print("%-28s %-10.1f %-10d" % ("手动 clear 缓存后", rss_mb(), len(plock._base_cache)))
