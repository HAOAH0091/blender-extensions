"""回归网（第六轮独立审查）：盯 🔴-1 / 🔴-2 / 🟡-1 / 🟡-3 / 🟡-5。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL。

★ 本文件的重点：
  🔴-1 「换相机数据块 / 删相机对象后，几何仍能被还原」——
       此前所有入口都按相机身份查找，那两条路径**不可逆**且无 UI。
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-58s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene


def mkcam(sc, name="Cam", loc=(0.0, 0.0, 6.0), lens=50.0):
    cd = bpy.data.cameras.new(name); cd.lens = lens; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def mkobjs(sc, cam, n, prefix="P"):
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i in range(n):
        bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, -float(i) * 2))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out


def loc(ob):
    return [tuple(v.co) for v in ob.data.vertices]


def md(a, b):
    return max(max(abs(x[i] - y[i]) for i in range(3)) for x, y in zip(a, b))


def run(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


# ═══ 🔴-1：换相机数据块后仍要能还原 ═══
print("=" * 72)
print("🔴-1  换相机【数据块】后：孤儿还原通道必须可用")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 3, "A")
orig = [loc(o) for o in objs]
plock.lock_group(sc, cam)
cam.data.lens = 100.0
run(sc)
adapted = [loc(o) for o in objs]
chk("A 前置：变焦后几何确实变形（非空对空）", max(md(o, a) for o, a in zip(orig, adapted)) > 1e-6,
    "%.6f" % max(md(o, a) for o, a in zip(orig, adapted)))
cam.data = bpy.data.cameras.new("SwappedData")          # ★ 换数据块
bpy.context.view_layer.update()
# 各入口都失联
chk("A 常规入口失联（has_lock_record=False）", not plock.has_lock_record(sc, cam))
chk("A reset_group 拒绝", not plock.reset_group(sc, cam).get("success"))
# ★ 新通道
orph = plock.find_orphan_locks(sc)
print("   find_orphan_locks → %s" % [(o.name, w) for o, w in orph])
chk("A-1 find_orphan_locks 能发现残留锁定", len(orph) >= 3, "%d 个" % len(orph))
r = plock.reset_orphan_locks(sc)
bpy.context.view_layer.update()
after = [loc(o) for o in objs]
d_orig = max(md(o, a) for o, a in zip(orig, after))
print("   还原后与【原始形状】差 = %.6f  | result=%s" % (d_orig, r.get("success")))
chk("A-2 reset_orphan_locks 能把几何还原成原形", d_orig < 1e-5, "偏差 %.6f" % d_orig)
chk("A-3 还原后痕迹被清掉（OBJ_CAM_KEY/ORIG/BASE）",
    all(o.get(plock.OBJ_CAM_KEY) is None
        and o.data.attributes.get(plock.ORIG_ATTR) is None
        and o.data.attributes.get(plock.BASE_ATTR) is None
        for o in objs),
    str([o.get(plock.OBJ_CAM_KEY) for o in objs]))
chk("A-4 再查已无孤儿", len(plock.find_orphan_locks(sc)) == 0)

# ═══ 🔴-1b：删相机对象 ═══
print()
print("=" * 72)
print("🔴-1b  删除相机对象后：孤儿还原通道必须可用")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 3, "B")
orig = [loc(o) for o in objs]
plock.lock_group(sc, cam)
cam.data.lens = 100.0
run(sc)
_cd = cam.data
bpy.data.objects.remove(cam, do_unlink=True)
bpy.context.view_layer.update()
orph = plock.find_orphan_locks(sc)
chk("B-1 find_orphan_locks 能发现（相机已删）", len(orph) >= 3, "%d 个" % len(orph))
r = plock.reset_orphan_locks(sc)
bpy.context.view_layer.update()
d_orig = max(md(o, a) for o, a in zip(orig, [loc(o) for o in objs]))
chk("B-2 几何被还原成原形", d_orig < 1e-5, "偏差 %.6f" % d_orig)
chk("B-3 残留记录被清掉", len(plock.load_groups(sc)) == 0,
    "残留 %s" % list(plock.load_groups(sc).keys()))

# ═══ 🔴-2：解锁期间的编辑必须被检测并明示 ═══
print()
print("=" * 72)
print("🔴-2  解锁期间的用户编辑：必须被检测到并明示")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 2, "C")
plock.lock_group(sc, cam)
plock.unlock_group(sc, cam)
objs[0].location.x += 5.0                                 # ★ 用户解锁后编辑
bpy.context.view_layer.update()
r = plock.reset_group(sc, cam)
print("   message=%r" % str(r.get("message"))[:110])
chk("C-1 检测到解锁后的编辑", bool(r.get("edited_after_unlock")),
    "edited=%s" % r.get("edited_after_unlock"))
chk("C-2 消息里明示（不再静默抹掉）",
    "解锁之后" in str(r.get("message")), str(r.get("message"))[-40:])

# 反例：解锁后【没有】编辑 → 不应误报
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 2, "D")
plock.lock_group(sc, cam)
plock.unlock_group(sc, cam)
cam.data.lens = 999.0                                     # 只动相机（不算编辑网格）
r = plock.reset_group(sc, cam)
chk("C-3 没编辑时不误报", not r.get("edited_after_unlock"),
    "edited=%s" % r.get("edited_after_unlock"))

# ═══ 🟡-1：相机静止时自愈 / 补写 ═══
print()
print("=" * 72)
print("🟡-1  相机静止时也要自愈 / 补写（不依赖移动相机）")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, 2, "E")
plock.lock_group(sc, cam)
ng.ensure_camera_project_group(cam, default_aspect=1.0)   # 真实「重新生成投影组」
bpy.context.view_layer.update()
for _ in range(10):
    run(sc)
chk("E-1 相机静止时补丁自愈", plock.is_patched(cam.data.name),
    "is_patched=%s" % plock.is_patched(cam.data.name))

sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 1, "F")
plock.lock_group(sc, cam)
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(1.0, 0.0, -1.5))
NEW = bpy.context.active_object; NEW.name = "NEW"
NEW.data.materials.append(objs[0].data.materials[0])
bpy.data.node_groups.new("UV Adjust | %s | %s" % (NEW.data.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
for _ in range(10):
    run(sc)
chk("E-2 相机静止时补写新接入对象的冻结坐标",
    plock._campos_is_valid(NEW, cam.data.name))

# ═══ 🟡-3：锁定后才加修改器 ═══
print()
print("=" * 72)
print("🟡-3  锁定后才加的修改器：不得再被逐顶点改写（双重变形）")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 3, "G")
plock.lock_group(sc, cam)
objs[0].modifiers.new("SUBSURF", "SUBSURF")               # ★ 锁定后加
bpy.context.view_layer.update()
b0 = loc(objs[0])
cam.location.x = 1.0
run(sc)
d0 = md(b0, loc(objs[0]))
chk("G-1 带修改器的对象不再被改写", d0 < 1e-9, "改动 %.2e" % d0)
# 反例：无修改器的照常被适配
b1 = loc(objs[1])
cam.location.x = 2.0
run(sc)
chk("G-2 无修改器的照常被适配（非空对空）", md(b1, loc(objs[1])) > 1e-6,
    "改动 %.6f" % md(b1, loc(objs[1])))

# ═══ 🟡-5：_last_view 回收（含已删场景） ═══
print()
print("=" * 72)
print("🟡-5  _last_view 不得残留指向已删场景的条目")
plock._last_view.clear()
for i in range(3):
    sc = fresh()
    cam = mkcam(sc, "Camera"); sc.camera = cam
    mkobjs(sc, cam, 1, "H%d" % i)
    plock.lock_group(sc, cam)
    run(sc)
alive = {s.as_pointer() for s in bpy.data.scenes}
dead = [k for k in plock._last_view if k[0] not in alive]
print("   条目 %d，其中指向已删场景 %d" % (len(plock._last_view), len(dead)))
chk("H-1 不残留已删场景的条目", len(dead) == 0, "残留 %d" % len(dead))

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX5_DONE")
