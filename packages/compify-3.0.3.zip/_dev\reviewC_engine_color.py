"""审查 C · 第 6 / 9 项：渲染引擎与颜色管理

6 引擎    EEVEE / CYCLES：图案与契约应完全一致；Workbench 不评估着色器节点 ⇒
          投影图案根本不会出现（Blender 限制，不是插件 bug —— 用「改 S 看画面变不变」验证）
9 色彩管理 Standard / Filmic / AgX：
          · 用 EXR（场景线性，绕过 view transform）量 UV，三档必须完全一致
          · 再用 PNG 直接看：AgX 下解锁那一刻画面是否逐像素相同（跳变与色彩管理无关）
          · 并且验证「亮度变了但图案位置没变」：把 AgX 解码值对 Standard 值做分箱残差，
            若箱内残差 ~0 说明 view transform 只是逐像素的单调映射，不会挪图案
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy


def lock_unlock(px, mutate=None):
    sc, cam, cd, mat, ob = build(**px.pop("kw"))
    p0 = render_uv("a")
    amx, amn, an = align_err(sc, cam, ob, p0)
    plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL = render_uv("l")
    iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL2 = render_uv("l2")
    iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
    sm = np.intersect1d(iL, iL2)
    glue = float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max()) if len(sm) else float("nan")
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    pU = render_uv("u")
    jump = diff(pL2, pU)[0]
    print("  %-28s 对齐=%.4f 粘住=%.4f JUMP=%.4f" % (px["tag"], amx, glue, jump))
    return amx, glue, jump, (sc, cam, cd, mat, ob, pL2, pU)


print("### 6 引擎差异（EXR 场景线性，排除色彩管理干扰）###")
r = {}
for eng in ("BLENDER_EEVEE", "CYCLES"):
    a, g, j, _ = lock_unlock({"tag": eng, "kw": {"engine": eng}})
    r[eng] = (a, g, j)
chk("6 EEVEE / CYCLES 图案一致（对齐误差均 <5e-3）",
    r["BLENDER_EEVEE"][0] < 5e-3 and r["CYCLES"][0] < 5e-3,
    "EEVEE=%.4f CYCLES=%.4f" % (r["BLENDER_EEVEE"][0], r["CYCLES"][0]))
chk("6 两种引擎解锁都不跳", r["BLENDER_EEVEE"][2] < 2e-3 and r["CYCLES"][2] < 2e-3,
    "EEVEE=%.4f CYCLES=%.4f" % (r["BLENDER_EEVEE"][2], r["CYCLES"][2]))

print("\n### 6b Workbench：不评估节点 ⇒ 投影图案根本不出现 ###")
sc, cam, cd, mat, ob = build(engine="BLENDER_WORKBENCH")
p1 = render_uv("wb1")
nodes = plock._find_delta_nodes(cd.name)
nodes[0].inputs["Scale"].default_value = 2.0        # 强行把 UV 缩放 2 倍
nodes[1].inputs[1].default_value = (0.3, 0.3, 0.0)  # 再平移
bpy.context.view_layer.update()
p2 = render_uv("wb2")
d = diff(p1, p2)[0]
print("  Workbench：把 S 改成 2、C 改成 0.3 后，画面差异 = %.6f" % d)
chk("6b Workbench 下图案与 UV 无关（节点不参与渲染）", d < 1e-6,
    "改 S/C 前后差异=%.2e ⇒ 投影材质在 Workbench 下不可用" % d)

print("\n### 9 色彩管理：EXR（绕开 view transform）三档必须一致 ###")
res = {}
for vt in ("Standard", "Filmic", "AgX"):
    a, g, j, _ = lock_unlock({"tag": "EXR " + vt, "kw": {"view_transform": vt}})
    res[vt] = (a, g, j)
chk("9 EXR 下三档 view transform 结果完全一致",
    max(abs(res[v][0] - res["Standard"][0]) for v in res) < 1e-3
    and max(abs(res[v][2] - res["Standard"][2]) for v in res) < 1e-3,
    "对齐 %s / 跳变 %s" % (["%.4f" % res[v][0] for v in res],
                          ["%.4f" % res[v][2] for v in res]))

print("\n### 9b PNG 直出：AgX 下解锁那一刻画面是否真的不动 ###")
a, g, j, imgs = lock_unlock({"tag": "PNG AgX", "kw": {"view_transform": "AgX", "fmt": "PNG"}})
chk("9b AgX（PNG 8bit）下解锁不跳", j < 3e-3, "JUMP=%.4f" % j)

print("\n### 9c view transform 是否只做逐像素映射（不挪图案）###")
sc, cam, cd, mat, ob = build(view_transform="Standard", fmt="PNG")
p_std = render_uv("std")
bpy.ops.wm.read_factory_settings(use_empty=True)
# 同场景重建，只换 view transform
sc2, cam2, cd2, mat2, ob2 = build(view_transform="AgX", fmt="PNG")
# 保证几何/相机完全一致（build 是确定性的）
p_agx = render_uv("agx")
u1, m1 = p_std
u2, m2 = p_agx
m = m1 & m2
x = u1[..., 0][m]
y = u2[..., 0][m]
order = np.argsort(x)
x, y = x[order], y[order]
nb = 20
spreads = []
for b in np.array_split(np.arange(len(x)), nb):
    if len(b) > 20:
        spreads.append(float(np.std(y[b])))
print("  Standard 解码值分 20 箱，箱内 AgX 值的标准差中位数 = %.5f" % float(np.median(spreads)))
print("  （若 view transform 会挪动图案，箱内就会出现系统性离散）")
med = float(np.median(spreads))
print("  1 个 8bit 码值 = 1/255 → 解码后约 %.4f UV；实测箱内离散是它的 %.2f 倍"
      % (4.0 / 255.0, med / (4.0 / 255.0)))
chk("9c AgX 只是逐像素映射：不改变图案位置", med < 2 * 4.0 / 255.0,
    "箱内标准差=%.4f（≤2 个 8bit 码值 %.4f 即纯量化噪声）" % (med, 2 * 4.0 / 255.0))

report("审查 C · 引擎 / 色彩管理")
