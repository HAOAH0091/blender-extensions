"""审查 C · 组合复核 + 补充边界

1 组合：锁定期间同时改 lens + sensor_width + shift_x/shift_y
  —— 独立复核工作树里那版「ratio = Z_now/Z_lock + shift_term」的修法在**组合**下是否精确
2 shift 大位移（0.5）时的对齐精度 —— 检查投影组对 shift 的处理有没有系统性偏差
3 渲染像素长宽比 render.pixel_aspect_x/y ≠ 1（非正方形像素）
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy


def run(tag, mutate, show_table=False, **kw):
    sc, cam, cd, mat, ob = build(**kw)
    p0 = render_uv("a")
    amx, amn, an = align_err(sc, cam, ob, p0)
    if show_table:
        table(sc, cam, ob, p0, n=4)
    plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL = render_uv("l")
    iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
    mutate(sc, cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL2 = render_uv("l2")
    iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
    sm = np.intersect1d(iL, iL2)
    glue = float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max()) if len(sm) else float("nan")
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    pU = render_uv("u")
    jump = diff(pL2, pU)[0]
    sc_ = nodes_sc(cd)
    print("  %-46s 对齐=%.4f 粘住=%.4f JUMP=%.4f  S=%.4f C=(%+.4f,%+.4f)"
          % (tag, amx, glue, jump, sc_[0], sc_[1][0], sc_[1][1]))
    return amx, glue, jump


def combo(sc, cam, cd):
    cd.lens = 85.0
    cd.sensor_width = 30.0
    cd.shift_x = 0.08
    cd.shift_y = 0.03


print("### 组合：锁定期间同时改 lens / sensor_width / shift_x / shift_y ###")
r1 = run("lens85 + sensor30 + shift(0.08,0.03)", combo)
r2 = run("lens32 + sensor40 + shift(-0.06,-0.04)",
         lambda sc, cam, cd: (setattr(cd, "lens", 32.0), setattr(cd, "sensor_width", 40.0),
                              setattr(cd, "shift_x", -0.06), setattr(cd, "shift_y", -0.04)))
r3 = run("lens85 + 同时移相机 + shift 0.05",
         lambda sc, cam, cd: (setattr(cd, "lens", 85.0), setattr(cd, "shift_x", 0.05),
                              setattr(cam.location, "x", 0.4)))
chk("组合1（lens+sensor+shift）解锁不跳", r1[2] < 2e-3, "JUMP=%.4f" % r1[2])
chk("组合2（缩焦+sensor+负 shift）解锁不跳", r2[2] < 2e-3, "JUMP=%.4f" % r2[2])
chk("组合3（变焦+移相机+shift）解锁不跳", r3[2] < 2e-3, "JUMP=%.4f" % r3[2])

print("\n### 大位移 shift 的对齐精度（投影组对 shift 的单位/符号是否正确）###")
a = run("shift=(0.5,0.3) 只移相机", lambda sc, cam, cd: setattr(cam.location, "x", 2.0),
        shift=(0.5, 0.3))
b = run("shift=(-0.5,-0.3) 只移相机", lambda sc, cam, cd: setattr(cam.location, "x", 2.0),
        shift=(-0.5, -0.3))
chk("大 shift 下图案仍对齐（说明单位/符号对）", a[0] < 6e-3 and b[0] < 6e-3,
    "shift(0.5,0.3) 对齐=%.4f  shift(-0.5,-0.3) 对齐=%.4f（基准 0.0025）" % (a[0], b[0]))

print("\n### 非正方形像素 render.pixel_aspect_x = 2 ###")


def pixel_aspect(scene, cam, cd):
    pass


sc, cam, cd, mat, ob = build()
sc.render.pixel_aspect_x = 2.0
bpy.context.view_layer.update()
p = render_uv("pa")
amx, amn, an = align_err(sc, cam, ob, p)
print("  pixel_aspect_x=2：对齐误差 max=%.4f（基准 0.0025）" % amx)
glue_jump = run("pixel_aspect_x=2 只移相机", lambda sc, cam, cd: setattr(cam.location, "x", 2.0))
chk("非正方形像素：解锁不跳", glue_jump[2] < 2e-3, "JUMP=%.4f" % glue_jump[2])

report("审查 C · 组合复核 / 补充边界")
