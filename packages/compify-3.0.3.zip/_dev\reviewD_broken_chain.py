"""审查项 4（自愈）：删/改名投影组关键节点后，插件是否「静默变坏」。

时序隔离：锁定 → 拍A → 破坏节点 → 立刻拍B（相机不动）→ 移相机+handler → 拍C
→ 解锁 → 拍D。渲染用 16-bit PNG + 0.1 缩放 UV 探针（8-bit 会钳位污染读数）。
判据：alpha 掩膜 UV 场的极差（图案还在？）+ 钳位像素占比（读数可信？）+ 结构事实。
"""
import bpy
import os
import sys
import json

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
SCALE = 0.1


def setup(tag):
    sc = C.reset()
    cam, cd = C.new_cam(sc)
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat, gn = C.probe_mat("Probe", grp, scale=SCALE)
    A = C.new_grid("A")
    A.data.materials.append(mat)
    C.uv_adjust_group(A, cd)
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    print("\n=== %s ===" % tag)
    return sc, cam, cd, grp, A


def snap(A, tag):
    C.show(A)
    uv, mask, sat = C.render_uv_masked(scale=SCALE, tag=tag)
    s = C.stats_masked(uv, mask)
    if s is None:
        print("    %-14s 渲染: 空" % tag)
        return None, 1.0
    print("    %-14s x极差=%.4f y极差=%.4f 唯一值=%5.1f%% 均值=(%+.3f,%+.3f) 钳位=%.1f%%"
          % (tag, s[0], s[1], s[2] * 100, s[3], s[4], sat * 100))
    return s, sat


def is_pattern(s, sat):
    """图案还在：UV 有真实分布，且不是钳位造成的假极差。"""
    return s is not None and s[0] > 0.05 and sat < 0.05


# ---------------- P1 删除 Attribute 节点 ----------------
sc, cam, cd, grp, A = setup("P1 删掉冻结坐标 Attribute 节点")
sa, _ = snap(A, "A 锁定中")
grp.nodes.remove(grp.nodes.get(plock.ATTR_NODE_NAME))
sb, sb_sat = snap(A, "B 删除后")
print("    is_patched=%s lock_status=%s" % (plock.is_patched(cd.name), plock.lock_status(sc, cam)))
cam.location.x += 2.0
bpy.context.view_layer.update()
for _ in range(4):
    plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
sc2, _ = snap(A, "C 移相机后")
print("    自愈重打补丁 patch_camera_project_group() 返回 %s" % (plock.patch_camera_project_group(cd.name),))
print("    PATCH_KEY 记录还在=%s（False ⇒ 已无法 unpatch 回填原接线）"
      % (grp.get(plock.PATCH_KEY) is not None))
r = plock.unlock_group(sc, cam)
print("    解锁消息: %s" % r["message"])
sd, sd_sat = snap(A, "D 解锁后")
C.report("P1 删节点后图案还在", is_pattern(sb, sb_sat),
         "UV x极差 %.4f→%.4f 钳位 %.0f%%" % (sa[0], sb[0], sb_sat * 100))
C.report("P1 解锁后投影恢复实时", is_pattern(sd, sd_sat),
         "x极差=%.4f 钳位=%.0f%% ⇒ 投影永久坏掉" % (sd[0], sd_sat * 100))

# ---------------- P2 改名 Attribute 节点 ----------------
sc, cam, cd, grp, A = setup("P2 把 Attribute 节点改名")
sa, _ = snap(A, "A 锁定中")
grp.nodes.get(plock.ATTR_NODE_NAME).name = "My Frozen Pos"
sb, sb_sat = snap(A, "B 改名后")
print("    is_patched=%s lock_status=%s" % (plock.is_patched(cd.name), plock.lock_status(sc, cam)))
cam.location.x += 2.0
bpy.context.view_layer.update()
for _ in range(4):
    plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
scc, scc_sat = snap(A, "C 移相机后")
r = plock.unlock_group(sc, cam)
print("    解锁消息: %s" % r["message"])
sd, sd_sat = snap(A, "D 解锁后")
left = grp.nodes.get("My Frozen Pos")
print("    解锁后残留节点在场=%s 输出线数=%d campos=%s" % (
    left is not None, 0 if left is None else len(left.outputs["Vector"].links),
    C.campos_ok(plock, A, cd.name)))
C.report("P2 改名后图案还在（锁定期间）", is_pattern(sb, sb_sat), "x极差=%.4f" % sb[0])
C.report("P2 解锁后投影恢复实时", is_pattern(sd, sd_sat),
         "x极差=%.4f 钳位=%.0f%%（残留节点仍接着+属性已删）" % (sd[0], sd_sat * 100))

# ---------------- P3 删除 S 节点 ----------------
sc, cam, cd, grp, A = setup("P3 删掉 C+k 链的 S 节点")
sa, _ = snap(A, "A 锁定中")
grp.nodes.remove(grp.nodes.get("PLock Delta S"))
sb, sb_sat = snap(A, "B 删除后")
cam.location.x += 2.0
bpy.context.view_layer.update()
for _ in range(4):
    plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
scc, scc_sat = snap(A, "C 移相机后")
print("    is_patched=%s（一直 True ⇒ 自愈分支不触发组重建）" % plock.is_patched(cd.name))
r = plock.unlock_group(sc, cam)
print("    解锁消息: %s" % r["message"])
sd, sd_sat = snap(A, "D 解锁后")
C.report("P3 删 S 节点后图案还在（锁定期间）", is_pattern(sb, sb_sat),
         "x极差 %.4f→%.4f 钳位 %.0f%%" % (sa[0], sb[0], sb_sat * 100))
C.report("P3 解锁后投影恢复实时", is_pattern(sd, sd_sat), "x极差=%.4f" % sd[0])

print("\nRD_CHAIN_DONE")
