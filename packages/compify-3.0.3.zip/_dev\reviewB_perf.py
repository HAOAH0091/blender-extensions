"""审查 B-3：大网格（10 万+ 顶点）锁定 / 每帧适配耗时。

跑法：blender --background --factory-startup --python _dev\\reviewB_perf.py
"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 90)
print("B-3 大网格性能")
print("=" * 90)


def big_grid(ns):
    """(ns+1)^2 顶点的平面。"""
    xs = np.linspace(-6, 6, ns + 1)
    X, Y = np.meshgrid(xs, xs)
    verts = np.stack([X.ravel(), Y.ravel(), np.zeros(X.size)], axis=1)
    idx = np.arange((ns + 1) ** 2).reshape(ns + 1, ns + 1)
    a = idx[:-1, :-1].ravel(); b = idx[:-1, 1:].ravel()
    c = idx[1:, 1:].ravel(); d = idx[1:, :-1].ravel()
    faces = np.stack([a, b, c, d], axis=1)
    return verts, faces


for ns in (150, 300, 500):
    sc, cam, cd, grp = C.setup()
    mat = C.probe_mat(grp)
    verts, faces = big_grid(ns)
    me = bpy.data.meshes.new("Big%d" % ns)
    me.vertices.add(verts.shape[0])
    me.vertices.foreach_set("co", verts.ravel())
    me.loops.add(faces.size)
    me.loops.foreach_set("vertex_index", faces.ravel())
    me.polygons.add(faces.shape[0])
    me.polygons.foreach_set("loop_start", np.arange(0, faces.size, 4))
    me.update()
    ob = bpy.data.objects.new("Big%d" % ns, me)
    sc.collection.objects.link(ob)
    me.materials.append(mat)
    C.attach(ob, cam)
    bpy.context.view_layer.update()
    n = len(me.vertices)
    t0 = time.perf_counter()
    r = plock.lock_group(sc, cam)
    t_lock = (time.perf_counter() - t0) * 1000
    # 移动相机 → handler 适配
    ts = []
    for i in range(6):
        cam.location.x = 0.15 * (i + 1)
        bpy.context.view_layer.update()
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)
        ts.append((time.perf_counter() - t0) * 1000)
        bpy.context.view_layer.update()
    # 变焦（走 dolly 分支）
    tz = []
    for i in range(4):
        cd.lens = 50 + 6 * (i + 1)
        bpy.context.view_layer.update()
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)
        tz.append((time.perf_counter() - t0) * 1000)
        bpy.context.view_layer.update()
    t0 = time.perf_counter()
    ru = plock.unlock_group(sc, cam)
    t_unlock = (time.perf_counter() - t0) * 1000
    t0 = time.perf_counter()
    plock.reset_group(sc, cam)
    t_reset = (time.perf_counter() - t0) * 1000
    nodes = plock._find_delta_nodes(cd.name)
    print("\n顶点数 %7d | lock %8.1f ms | unlock %8.1f ms | reset %8.1f ms"
          % (n, t_lock, t_unlock, t_reset))
    print("   移动相机 handler 每帧: 中位 %6.1f ms  最差 %6.1f ms"
          % (sorted(ts)[len(ts) // 2], max(ts)))
    print("   变焦   handler 每帧: 中位 %6.1f ms  最差 %6.1f ms"
          % (sorted(tz)[len(tz) // 2], max(tz)))
    print("   lock success=%s frozen=%s" % (r["success"], r.get("frozen")))
    C.chk("ns=%d（%d 顶点）lock 耗时标注 <3000ms" % (ns, n), t_lock < 3000, "%.0f ms" % t_lock)
    C.chk("ns=%d 移动相机每帧 <50ms（手感）" % ns,
          sorted(ts)[len(ts) // 2] < 50, "%.1f ms" % sorted(ts)[len(ts) // 2])
    C.chk("ns=%d 变焦每帧 <50ms" % ns, sorted(tz)[len(tz) // 2] < 50,
          "%.1f ms" % sorted(tz)[len(tz) // 2])

C.summary()
