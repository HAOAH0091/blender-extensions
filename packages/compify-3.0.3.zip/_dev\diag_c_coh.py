"""C 方案的网格/位姿一致性 + 后续相机移动是否正常
1. 拖动后：网格几何中心 vs 物体原点（位姿）偏移多少
2. 拖完再移相机：视差是否正常（投影不变）
3. 解锁 → 顶点是否回到原位
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_d"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]
from mathutils import Vector


def psdstyle(obj, camera, view_now):
    if not PL.LAYER_MOVE_ENABLED:
        return False
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    M_lock = PL._read_matrix_key(obj)
    if M_lock is None:
        PL._write_matrix_key(obj, obj.matrix_world.copy()); return False
    M_cur = obj.matrix_world.copy()
    if PL._mat_close(M_cur, M_lock):
        return False
    view_inv = view_now.inverted()
    c_local = PL._mesh_center_local(obj)
    d_lock = PL._view_depth(view_inv, M_lock @ c_local)
    d_cur = PL._view_depth(view_inv, M_cur @ c_local)
    if d_lock <= PL.MIN_DEPTH or d_cur <= PL.MIN_DEPTH:
        return False
    obj[PL.DRAG_SCALE_KEY] = float(d_cur / d_lock)
    axis_w = view_now.to_3x3() @ Vector((0.0, 0.0, -1.0))
    M_new = M_lock.copy()
    M_new.translation = M_lock.translation + axis_w * (d_lock - d_cur)
    obj.matrix_world = M_new
    bpy.context.view_layer.update()
    return True


PL.apply_user_move = psdstyle

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cd)
scene.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
bpy.context.view_layer.update()
NG.ensure_camera_project_group(cam)
m = bpy.data.materials.new("M"); m.use_nodes = True
nt = m.node_tree
for n in list(nt.nodes): nt.nodes.remove(n)
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
mesh = bpy.data.meshes.new("G")
mesh.from_pydata([(-1,-1,0),(1,-1,0),(1,1,0),(-1,1,0)], [], [(0,1,2,3)])
mesh.update()
obj = bpy.data.objects.new("GridA", mesh)
scene.collection.objects.link(obj)
obj.data.materials.append(m)
NG.create_uv_adjust_node_group(scene, cam, obj)

def center(o):
    vs = [o.matrix_world @ v.co for v in o.data.vertices]
    return sum(vs, Vector()) / len(vs)

def proj(cam, o):
    v = PL.get_camera_view_matrix(cam)
    out=[]
    for vv in o.data.vertices:
        p = v @ (o.matrix_world @ vv.co)
        z=-p.z
        out.append((p.x/z if z>1e-6 else 0, p.y/z if z>1e-6 else 0))
    return out

PL.lock_group(scene, cam)
M_lock = obj.matrix_world.copy()
orig0 = [tuple(v.co) for v in obj.data.vertices]
c_lock = center(obj)
p0 = proj(cam, obj)
view = PL.get_camera_view_matrix(cam)
axis_w = view.to_3x3() @ Vector((0,0,-1))

print("锁定后：网格中心 %s  原点 %s" %
      (tuple(round(x,3) for x in c_lock), tuple(round(x,3) for x in M_lock.translation)))

# 拖 0.3
Mtmp = M_lock.copy(); Mtmp.translation = M_lock.translation + axis_w*0.3
obj.matrix_world = Mtmp
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
c_after = center(obj)
pose = obj.matrix_world.translation
print("\n拖 0.3 后：")
print("  网格中心 %s" % (tuple(round(x,3) for x in c_after),))
print("  物体原点 %s" % (tuple(round(x,3) for x in pose),))
print("  >>> 网格中心-原点 偏移 %.4f  (0=完全一致，大=分离)" % (c_after-pose).length)
pf = proj(cam, obj)
print("  >>> 屏幕投影最大变化 %.6f" % max(max(abs(a[0]-b[0]),abs(a[1]-b[1])) for a,b in zip(p0,pf)))

# 拖完再移相机，看视差是否正常
print("\n拖完再移相机（x+1），投影应保持不变（视差锁定核心作用）：")
cam.location = (1.0, 0, 5.0)
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
pf2 = proj(cam, obj)
print("  >>> 屏幕投影最大变化 %.6f  (%s)" %
      (max(max(abs(a[0]-b[0]),abs(a[1]-b[1])) for a,b in zip(p0,pf2)),
       "视差锁定仍有效" if max(max(abs(a[0]-b[0]),abs(a[1]-b[1])) for a,b in zip(p0,pf2)) < 1e-3 else "失效!"))

# 解锁后是否回原位
print("\n解锁：")
res = PL.unlock_group(scene, cam)
print("  ", res.get("message"))
cur = [tuple(v.co) for v in obj.data.vertices]
d = max(abs(a[i]-b[i]) for a,b in zip(orig0,cur) for i in range(3))
print("  >>> 顶点相对最初的最大差 %.6f  (%s)" %
      (d, "完全还原" if d < 1e-4 else "没还原"))
