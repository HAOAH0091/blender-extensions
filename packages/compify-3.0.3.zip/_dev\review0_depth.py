"""边界：网格穿过相机平面（部分顶点 z≈0 / z<0）时，冻结坐标是否变成 inf/nan？

风险链：
  shader 里 perspective_2/3 是 x/z，use_clamp=False
  _write_campos_attribute 把相机空间坐标原样写进属性，**没有 z 保护**
  ⇒ z=0 的顶点 → inf；z<0 → 符号翻转
  ⇒ 冻结会把瞬时错误**永久固化**
  ⇒ 解锁时 fit_delta_params 用 lstsq，inf 会污染整个解
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-46s %s" % ("PASS" if c else "FAIL", n, d))


def build(shape):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    ns = 3
    h = 1.5
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            x = -h + 2 * h * ix / ns
            y = -h + 2 * h * iy / ns
            if shape == "cross":        # 网格沿 z 穿过相机平面(相机在 z=5, 网格 z 从 0 到 10)
                z = 10.0 * (iy / ns)
            elif shape == "at_plane":   # 某个顶点正好在相机平面上
                z = 5.0 if (ix == 0 and iy == 0) else 0.0
            elif shape == "behind":     # 部分顶点在相机背后
                z = 8.0 if iy >= ns - 1 else 0.0
            else:
                z = 0.0
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def inspect_attr(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None:
        return None
    n = len(a.data)
    buf = np.empty(n * 3, dtype=np.float64)
    a.data.foreach_get("vector", buf)
    v = buf.reshape(-1, 3)
    zs = v[:, 2]
    return {
        "n": n,
        "has_nan": bool(np.isnan(v).any()),
        "has_inf": bool(np.isinf(v).any()),
        "z_min": float(zs.min()),
        "z_max": float(zs.max()),
        "n_near_zero": int((np.abs(zs) < plock.MIN_DEPTH).sum()),
        "n_negative": int((zs < 0).sum()),
        "uv_absmax": float(np.abs(v[:, :2] / np.where(np.abs(zs) > 1e-12, zs[:, None], np.nan)).max())
        if n else 0.0,
    }


def run(tag, shape, mutate=None):
    print("\n[%s]" % tag)
    sc, cam, cd, ob = build(shape)
    print("   顶点 z 范围: %.3f ~ %.3f（相机在 z=5）" % (
        min(v.co.z for v in ob.data.vertices), max(v.co.z for v in ob.data.vertices)))
    _r = plock.lock_group(sc, cam)
    print("   锁定消息:", str(_r.get("message", ""))[:160])
    print("   frozen:", _r.get("frozen"), " skipped:", _r.get("skipped"))
    info = inspect_attr(ob, cd)
    if info is None:
        chk("%s 写了冻结坐标" % tag, False, "属性不存在")
        return
    print("   冻结坐标: n=%d  z∈[%.4f, %.4f]  z≈0 的顶点=%d  z<0 的顶点=%d" % (
        info["n"], info["z_min"], info["z_max"], info["n_near_zero"], info["n_negative"]))
    chk("%s 冻结坐标无 nan" % tag, not info["has_nan"])
    chk("%s 冻结坐标无 inf" % tag, not info["has_inf"])
    print("   UV 绝对值上限: %.3e" % info["uv_absmax"] if not math.isnan(info["uv_absmax"]) else "   UV 含 nan")

    if mutate:
        mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    r = plock.unlock_group(sc, cam)
    print("   解锁:", r["message"][:60])
    nodes = plock._find_delta_nodes(cd.name)
    if nodes:
        S = nodes[0].inputs["Scale"].default_value
        C = list(nodes[1].inputs[1].default_value)[:2]
        bad = (not math.isfinite(S)) or any(not math.isfinite(c) for c in C)
        print("   解锁后 S=%.6f C=(%.6f, %.6f)" % (S, C[0], C[1]))
        chk("%s 解锁参数 S/C 都是有限值" % tag, not bad)


print("=" * 84)
print("边界：网格穿过相机平面 / 顶点在相机背后")
print("=" * 84)
run("A 顶点正好在相机平面上", "at_plane", lambda cam, cd: setattr(cam.location, "x", 1.0))
run("B 部分顶点在相机背后", "behind", lambda cam, cd: setattr(cam.location, "x", 1.0))
run("C 网格沿 z 穿过相机平面", "cross", lambda cam, cd: setattr(cam.location, "x", 1.0))

print()
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("DEPTH_EDGE_DONE")
