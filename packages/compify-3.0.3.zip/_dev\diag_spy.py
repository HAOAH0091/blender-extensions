"""插桩诊断：实际调用 recompute_ref_depth / adapt_object 时用的 ref 是多少"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

# ===== 插桩 =====
_orig_recompute = plock.recompute_ref_depth
_orig_adapt = plock.adapt_object
TRACE = []

def spy_recompute(scene, st, cam_data_name=None):
    before = st.get("ref_depth")
    r = _orig_recompute(scene, st, cam_data_name)
    TRACE.append("  RECOMPUTE: st.ref %s -> %s (returned %s)  id(st)=%s"
                 % (before, st.get("ref_depth"), r, id(st)))
    return r

def spy_adapt(obj, camera, state, view_now=None):
    TRACE.append("  ADAPT %-4s with state.ref=%s  id(state)=%s"
                 % (obj.name, state.get("ref_depth"), id(state)))
    return _orig_adapt(obj, camera, state, view_now)

plock.recompute_ref_depth = spy_recompute
plock.adapt_object = spy_adapt


def build(zA=0.0, zB=2.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns, -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("A", -1.5, zA)
    B = mk("B", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def step(sc, tag):
    TRACE.clear()
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    print("\n  ── %s ──" % tag)
    if TRACE:
        for t in TRACE:
            print(t)
    else:
        print("  （handler 没调用 recompute / adapt）")


def wb(B):
    return float(np.array([list(B.matrix_world @ v.co) for v in B.data.vertices]).mean(axis=0)[0])


sc, cam, cd, A, B = build()
plock.lock_group(sc, cam)
print("=" * 96)
print("插桩跟踪（A 深度8 / B 深度6）")
print("=" * 96)

cam.location.x = 1.2
step(sc, "移到 1.2")
print("  B world x = %+.6f" % wb(B))

A.location.z += 1.5
step(sc, "拖 A +1.5（深度 8→6.5）")
print("  B world x = %+.6f" % wb(B))

cam.location.x = 2.2
step(sc, "移到 2.2")
print("  B world x = %+.6f" % wb(B))
st = plock.get_state(sc, cam)
print("  最终 st['ref_depth'] = %s" % st.get("ref_depth"))

print()
print("=" * 96)
print("对照：不拖 A 的路径")
print("=" * 96)
TRACE.clear()
sc, cam, cd, A, B = build()
plock.lock_group(sc, cam)
cam.location.x = 1.2
step(sc, "移到 1.2")
print("  B world x = %+.6f" % wb(B))
cam.location.x = 2.2
step(sc, "移到 2.2")
print("  B world x = %+.6f" % wb(B))
st = plock.get_state(sc, cam)
print("  最终 st['ref_depth'] = %s" % st.get("ref_depth"))
print("SPY_DONE")
