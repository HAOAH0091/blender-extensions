"""查：应用修改器后为什么图案还差 0.033
	关注点：应用后顶点数变了，冻结坐标属性是否被正确重算？
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, mesh=None):
        if mesh is None:
            ns = 3; h = 1.5
            verts, faces = [], []
            for iy in range(ns+1):
                for ix in range(ns+1):
                    verts.append((x0-h+2*h*ix/ns, -h+2*h*iy/ns, 0.0))
            for iy in range(ns):
                for ix in range(ns):
                    a = iy*(ns+1)+ix
                    faces.append((a, a+1, a+ns+2, a+ns+1))
            mesh = bpy.data.meshes.new(name)
            mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob
    A = mk("GridA", -2.0)
    B = mk("GridB", 2.0)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


sc, cam, cd, mat, A, B = build()
attr_name = plock._campos_attr_name(cd.name)
plock._backfill_warned.clear()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

a = B.data.attributes.get(attr_name)
print("换材质后（加修改器前）:")
print("  顶点数        :", len(B.data.vertices))
print("  campos 长度   :", len(a.data) if a else None)

# 加修改器
B.modifiers.new("Subdiv", "SUBSURF").levels = 1
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
a = B.data.attributes.get(attr_name)
print("\n加修改器后:")
print("  顶点数(基座)  :", len(B.data.vertices))
print("  campos 长度   :", len(a.data) if a else None)
print("  has_modifier  :", plock.has_modifier_or_shapekey(B))
print("  _campos_is_valid:", plock._campos_is_valid(B, cd.name))

# 应用修改器
bpy.ops.object.select_all(action="DESELECT")
B.select_set(True)
bpy.context.view_layer.objects.active = B
for md in list(B.modifiers):
    bpy.ops.object.modifier_apply(modifier=md.name)
bpy.context.view_layer.update()
a = B.data.attributes.get(attr_name)
print("\n应用修改器后:")
print("  顶点数        :", len(B.data.vertices))
print("  campos 长度   :", len(a.data) if a else None, " ← 与顶点数一致?",
      (a is not None and len(a.data) == len(B.data.vertices)))
print("  has_modifier  :", plock.has_modifier_or_shapekey(B))
print("  _campos_is_valid:", plock._campos_is_valid(B, cd.name),
      " ← False 才会重写")

if a is not None:
    # 比较 campos 与「按锁定位姿投影当前顶点」
    mi = lock_mw.inverted()
    n = min(len(a.data), len(B.data.vertices))
    bad = 0
    maxd = 0.0
    for i in range(n):
        cx, cy, cz = a.data[i].vector
        p = mi @ (B.matrix_world @ B.data.vertices[i].co)
        d = max(abs(cx - p.x), abs(cy - p.y), abs(cz - p.z))
        if d > 1e-5:
            bad += 1
        maxd = max(maxd, d)
    print("  campos 与锁定位姿投影不符的顶点数: %d / %d, 最大差 %.6f" % (bad, n, maxd))

plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
a2 = B.data.attributes.get(attr_name)
print("\n再跑一次 handler 后:")
print("  campos 长度   :", len(a2.data) if a2 else None)
if a2 is not None:
    mi = lock_mw.inverted()
    n = min(len(a2.data), len(B.data.vertices))
    bad = 0; maxd = 0.0
    for i in range(n):
        cx, cy, cz = a2.data[i].vector
        p = mi @ (B.matrix_world @ B.data.vertices[i].co)
        d = max(abs(cx-p.x), abs(cy-p.y), abs(cz-p.z))
        if d > 1e-5: bad += 1
        maxd = max(maxd, d)
    print("  不符顶点数: %d / %d, 最大差 %.6f" % (bad, n, maxd))
print("MODAPPLY_DIAG_DONE")
