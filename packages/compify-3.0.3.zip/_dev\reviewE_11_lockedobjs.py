"""审查E-11：锁定 3000 个网格时 locked_objects() 为什么 188 ms

怀疑点（行 3013-3021，`locked_objects` 的「老存档兼容」分支）：
    即便反向索引已经把对象全找到了，仍然对 state 里 **每个对象名** 做一次
    `scene.objects.get(nm)` —— O(N) 次 RNA 按名查找，结果全被 `seen` 丢弃。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

N = 3000
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 14)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
ns, H = 2, 0.4
verts, faces = [], []
for iy in range(ns + 1):
    for ix in range(ns + 1):
        verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy * (ns + 1) + ix
        faces.append((a, a + 1, a + ns + 2, a + ns + 1))
for i in range(N):
    me = bpy.data.meshes.new("G%d" % i)
    me.from_pydata(verts, [], faces)
    me.update()
    o = bpy.data.objects.new("Grid%d" % i, me)
    sc.collection.objects.link(o)
    o.location = ((i % 60) * 0.9 - 27, (i // 60) * 0.9, 0.0)
    o.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
st = plock.load_groups(sc)[cd.name]
names = list(st.get("objects") or [])
print("锁定 %d 个；state 里名字数 = %d" % (N, len(names)))


def bench(fn, n=4, label=""):
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        r = fn()
        ts.append((time.perf_counter() - t0) * 1000.0)
    print("  %-52s %7.2f ms   结果=%s" % (label, sum(ts) / len(ts), r))
    return sum(ts) / len(ts)


bench(lambda: len(plock.locked_objects(sc, cd.name, None)), 4,
      "locked_objects(st=None)  ← 只走反向索引")
bench(lambda: len(plock.locked_objects(sc, cd.name, st)), 4,
      "locked_objects(st)       ← 真实调用（含名字兜底）")


def name_lookup():
    c = 0
    for nm in names:
        if sc.objects.get(nm) is not None:
            c += 1
    return c


bench(name_lookup, 4, "只跑「名字兜底」循环：scene.objects.get() × %d" % len(names))
print("\n结论：兜底分支里 %d 次 scene.objects.get() 即使命中已被 seen 去重，"
      "也要付 RNA 查找成本。" % len(names))
