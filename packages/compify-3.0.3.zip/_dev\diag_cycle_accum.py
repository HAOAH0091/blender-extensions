"""判断「反复锁定/解锁 C 累积」是特性还是 bug

语义（用户原话）：「锁定时是调整，解锁后实现这个调整」
⇒ 重锁时冻结的应该是「用户此刻在视口里看到的样子」。

情形 1：图案已偏移(C=-0.4)，相机归零，再锁定
        → 重锁冻结"偏移后的图案" ⇒ C 变 -0.8 符合语义
情形 2：每轮先 reset（清掉落实），再锁定
        → C 应每轮都回到 -0.4（不累积）
情形 3：连续 100 轮，C 无界增长 → 数值隐患？画面还能用吗？
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 48


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns = 3; h = 2.0
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-h+2*h*ix/ns, -h+2*h*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def uvimg():
    _seq[0] += 1
    p = os.path.join(HERE, "_sem_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def sc_vals(cd):
    nodes = plock._find_delta_nodes(cd.name)
    return (nodes[0].inputs["Scale"].default_value,
            tuple(nodes[1].inputs[1].default_value)[:2])


print("=" * 88)
print("情形 1：图案已偏移后重锁（不 reset）—— 语义上应该在累积")
print("=" * 88)
sc, cam, cd, ob = build()
cams = []
for i in range(1, 6):
    cam.location = (0, 0, 5)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    S, C = sc_vals(cd)
    cam.location = (0, 0, 5)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    img = uvimg()
    cams.append((i, C[0], float(img[..., 0].mean())))
    print("  第%d轮: C=%+.6f   相机归零后画面 UV 均值=%+.6f" % (i, C[0], cams[-1][2]))

print()
print("=" * 88)
print("情形 2：每轮先 reset（清掉落实）再锁 —— C 应该每轮相同")
print("=" * 88)
sc, cam, cd, ob = build()
for i in range(1, 6):
    plock.reset_group(sc, cam)
    cam.location = (0, 0, 5)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    S, C = sc_vals(cd)
    print("  第%d轮: S=%.8f C=%+.8f" % (i, S, C[0]))

print()
print("=" * 88)
print("情形 3：连续 100 轮（不 reset）—— C 无界增长会不会出数值问题？")
print("=" * 88)
sc, cam, cd, ob = build()
for i in range(1, 101):
    cam.location = (0, 0, 5)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    if i in (1, 25, 50, 75, 100):
        S, C = sc_vals(cd)
        cam.location = (0, 0, 5)
        bpy.context.view_layer.update()
        plock.parallax_lock_update_handler(sc)
        bpy.context.view_layer.update()
        img = uvimg()
        finite = bool(np.isfinite(img).all())
        print("  第%3d轮: S=%.6f C=%+.4f  画面有限=%s  UV 均值=%+.3f" % (
            i, S, C[0], finite, float(img[..., 0].mean())))
print("\nSEM_DONE")
