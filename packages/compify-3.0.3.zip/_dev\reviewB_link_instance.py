"""审查 B-6：集合实例（collection instance）与外部 .blend 链接（link）的网格。

跑法：blender --background --factory-startup --python _dev\\reviewB_link_instance.py
"""
import sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 90)
print("B-6 集合实例 / 链接网格")
print("=" * 90)

# ══════════════════════════════════════════════════════════
print("\n### A. 集合实例：被实例化的网格（同一投影材质）###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3, x0=-2.6)
# 装配集合里的网格（不是 scene.objects 里的对象）
sub = bpy.data.collections.new("SubColl")
sc.collection.children.link(sub)
meB = C.grid_mesh("InstMesh", ns=3, H=2.0, x0=2.6)
meB.materials.append(mat)
obB = bpy.data.objects.new("InstSrc", meB)
sub.objects.link(obB)
# 实例化：空物体 + instance_collection
emp = bpy.data.objects.new("InstEmpty", None)
emp.instance_type = "COLLECTION"
emp.instance_collection = sub
sc.collection.objects.link(emp)
bpy.context.view_layer.update()
print("   scene.objects =", [o.name for o in sc.objects])
print("   objects_using_projection(cam) 覆盖:", [o.name for o in plock.objects_using_projection(cd.name)])

u0 = C.uvimg("inst")
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s locked=%s" % (r["success"], r.get("frozen"),
                                                 [o.name for o in r.get("locked", [])]))
print("   message:", r["message"][:140])
C.run_handler(sc)
u1 = C.uvimg("inst")
# 实例所在区域（画面右半）
h, w = u0.shape[:2]
reg = (slice(0, h), slice(w // 2, w))
sd0 = float(np.std(u0[reg]))
sd1 = float(np.std(u1[reg]))
print("   实例区域 红通道编码 UV 的标准差: 锁定前 %.4f → 锁定后 %.4f" % (sd0, sd1))
print("   实例区域 颜色均值: 锁定前 (%.3f,%.3f) 锁定后 (%.3f,%.3f)"
      % (u0[reg][..., 0].mean(), u0[reg][..., 1].mean(),
         u1[reg][..., 0].mean(), u1[reg][..., 1].mean()))
C.chk("A1 集合实例锁定后图案不塌成纯色（区域 UV 仍有梯度）",
      sd1 > sd0 * 0.5, "std %.4f → %.4f" % (sd0, sd1))
C.chk("A2 集合实例的网格被列入冻结目标", any(o.name == "InstSrc" for o in r.get("locked", [])),
      "locked=%s" % [o.name for o in r.get("locked", [])])

# ══════════════════════════════════════════════════════════
print("\n### B. 外部 .blend 链接（link）的网格数据 ###")
tmp = os.path.join(tempfile.gettempdir(), "reviewB_lib.blend")
# 先造库文件：只有 mesh
bpy.ops.wm.read_factory_settings(use_empty=True)
me = C.grid_mesh("LinkedMesh", ns=3, H=2.0)
bpy.context.scene.collection.objects.link(bpy.data.objects.new("Tmp", me))
bpy.ops.wm.save_as_mainfile(filepath=tmp, copy=True)
print("   库文件:", tmp, os.path.exists(tmp))

sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
# 链接 mesh 数据（只读）
with bpy.data.libraries.load(tmp, link=True) as (src, dst):
    dst.meshes = ["LinkedMesh"]
lme = dst.meshes[0]
print("   链接到的 mesh:", lme.name, "library=", lme.library)
lob = bpy.data.objects.new("LinkedObj", lme)
sc.collection.objects.link(lob)
lob.location = (0, 0, 0)
lme.materials.append(mat)
C.attach(lob, cam)
bpy.context.view_layer.update()
before = [a.name for a in lme.attributes]
print("   链接前属性:", before)
try:
    r = plock.lock_group(sc, cam)
    print("   lock 返回: success=%s frozen=%s message=%s"
          % (r["success"], r.get("frozen"), r["message"][:160]))
    exc = None
except Exception as e:
    exc = e
    import traceback
    print("   ✗ lock_group 抛异常:", type(e).__name__, e)
    traceback.print_exc()
C.chk("B1 链接网格 lock 不抛未捕获异常（应优雅跳过/提示）", exc is None,
      "%s: %s" % (type(exc).__name__, exc) if exc else "")
if exc is None:
    after = [a.name for a in lme.attributes]
    print("   链接后属性:", after)
    try:
        r2 = plock.lock_group(sc, cam)
        print("   再锁一次:", r2["success"], r2["message"][:120])
    except Exception as e:
        print("   ✗ 再锁抛异常:", type(e).__name__, e)

# 场景里「既有正常网格、又有链接网格」—— 链接那个会不会把整个锁定带崩？
print("\n### C. 正常网格 + 链接网格混在一起 ###")
for old in list(bpy.data.objects):
    if old.name in ("LinkedObj",):
        bpy.data.objects.remove(old)
A = C.add_grid("GridA2", cam, mat, ns=3)
lob = bpy.data.objects.new("LinkedObj2", lme)
sc.collection.objects.link(lob)
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock: success=%s locked=%s" % (r["success"], [o.name for o in r.get("locked", [])]))
    print("   message:", r["message"][:200])
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 抛异常:", type(e).__name__, e)
C.chk("C1 正常网格 + 链接网格：lock 不抛异常", exc is None,
      "%s: %s" % (type(exc).__name__, exc) if exc else "")
if exc is None and r.get("success"):
    fv0 = C.campos_uv(A, cd.name)
    cam.location.x = 2.0
    C.run_handler(sc)
    fv1 = C.campos_uv(A, cd.name)
    d = float(np.abs(fv1 - fv0).max()) if (fv0 is not None and fv1 is not None) else -1
    print("   正常网格冻结是否仍有效：逐顶点 UV Δ=%.3e（0=冻结）" % d)
    print("   frozen=%s" % r.get("frozen"))

C.summary()
