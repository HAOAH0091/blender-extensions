"""对照实验：禁掉「拖动后重算 ref_depth」，B 是否就不动了？

A 最深（z=0，深度8），B 较浅（z=2，深度6），ref 由 A 决定。
  · 对照组（现状）：拖 A → ref 重算 → B 被带动
  · 实验组（禁重算）：拖 A → ref 冻结 → B 应完全不动
  · 反证：拖**浅的** B（基准层不换人）→ A 本来就不该动
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

_REAL_RECOMPUTE = plock.recompute_ref_depth


def build(zA, zB):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns,
                              -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("GridA", -1.5, zA)
    B = mk("GridB", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def wverts(ob):
    mw = ob.matrix_world
    return np.array([list(mw @ v.co) for v in ob.data.vertices])


def screen(ob, cam):
    inv = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = inv @ (ob.matrix_world @ v.co)
        out.append((p.x / p.z, p.y / p.z) if abs(p.z) > 1e-9 else (0.0, 0.0))
    return np.array(out)


def trial(disable_recompute, drag_z_push, drag_which="A"):
    a_z, b_z = 0.0, 2.0          # A 深度8（最深）、B 深度6
    sc, cam, cd, A, B = build(a_z, b_z)
    plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    ref_lock = st.get("ref_depth", 0)

    # 移相机
    cam.location.x = 1.2
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()

    if disable_recompute:
        plock.recompute_ref_depth = lambda *a, **k: 0.0

    tgt = A if drag_which == "A" else B
    other = B if drag_which == "A" else A
    wO0 = wverts(other); sO0 = screen(other, cam)
    st = plock.get_state(sc, cam); ref0 = st.get("ref_depth", 0)

    tgt.location.z += drag_z_push
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()

    st = plock.get_state(sc, cam); ref1 = st.get("ref_depth", 0)
    wO1 = wverts(other); sO1 = screen(other, cam)
    plock.recompute_ref_depth = _REAL_RECOMPUTE
    return (ref0, ref1, float(np.abs(wO1 - wO0).max()),
            float(np.abs(sO1 - sO0).max()))


print("=" * 88)
print("A 最深(z=0,深度8) / B 较浅(z=2,深度6)")
print("=" * 88)
print("\n【对照组】现状（拖动后重算 ref_depth）")
for push, w in [(1.0, "A"), (-1.0, "A"), (1.0, "B")]:
    r0, r1, dv, ds = trial(False, push, w)
    print("  拖 %s  %+0.1f  | ref %.4f→%.4f | 另一网格顶点变化 %.8f | 屏幕变化 %.8f"
          % (w, push, r0, r1, dv, ds))

print("\n【实验组】禁掉「拖动后重算 ref_depth」")
res = []
for push, w in [(1.0, "A"), (-1.0, "A"), (1.0, "B")]:
    r0, r1, dv, ds = trial(True, push, w)
    res.append((w, push, r0, r1, dv, ds))
    print("  拖 %s  %+0.1f  | ref %.4f→%.4f | 另一网格顶点变化 %.8f | 屏幕变化 %.8f"
          % (w, push, r0, r1, dv, ds))

print()
print("=" * 88)
print("结论")
print("=" * 88)
allzero = all(abs(dv) < 1e-9 and abs(ds) < 1e-9 for (_, _, _, _, dv, ds) in res)
print("  实验组里「另一网格」是否完全不动：%s" % ("✓ 全部为 0" if allzero else "✗ 仍有变化"))
print("  若成立 ⇒ 根因唯一：拖动触发的 recompute_ref_depth 改写了全局共享基准")
print("CTRL_DONE")
