"""审查 F-1b：量化「旧 delta 被丢弃」的跳变幅度 + [2] 旧属性在新组下是否干扰计算"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
exec(open(os.path.join(HERE, "reviewF_upgrade.py"), encoding="utf-8").read().split('print("=" * 84)')[0]
     .split("sys.stdout.reconfigure")[1].split("\n", 1)[1], globals()) if False else None

RES = 96

# --- 复用 build / uvimg（直接内联，避免 import 副作用） ---
def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam); cam.location = (0, 0, 5); sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ"); comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission"); out = nt.nodes.new("ShaderNodeOutputMaterial")
    for ax in ("X", "Y"):
        m = nt.nodes.new("ShaderNodeMath"); m.operation = "MULTIPLY"; m.inputs[1].default_value = 0.25
        a = nt.nodes.new("ShaderNodeMath"); a.operation = "ADD"; a.inputs[1].default_value = 0.5
        nt.links.new(sep.outputs[ax], m.inputs[0]); nt.links.new(m.outputs["Value"], a.inputs[0])
        nt.links.new(a.outputs["Value"], comb.inputs[ax])
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns, H = 3, 2.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("G0"); mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid0", mesh); sc.collection.objects.link(ob)
    ob.data.materials.append(mat); bpy.context.view_layer.update()
    return sc, cam, cd, mat, ob


_seq = [0]


def uvimg(tag=""):
    _seq[0] += 1
    p = os.path.join(HERE, "_rfq_%02d%s.png" % (_seq[0], tag))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32); im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def legacy_group_and_attr(cam, ob, delta):
    ng = bpy.data.node_groups[plock.CAM_PROJECT_PREFIX + cam.data.name]
    s = ng.nodes.get(plock.PLOCK_S_NODE); c = ng.nodes.get(plock.PLOCK_C_NODE)
    p4 = [n for n in ng.nodes if n.label == "Perspective 4"][0]
    z3 = [n for n in ng.nodes if n.label == "Zoom 3"][0]
    if s: ng.nodes.remove(s)
    if c: ng.nodes.remove(c)
    attr = ng.nodes.new("ShaderNodeAttribute"); attr.attribute_name = plock.UV_DELTA_ATTR_LEGACY
    add = ng.nodes.new("ShaderNodeVectorMath"); add.operation = "ADD"
    ng.links.new(p4.outputs[0], add.inputs[0]); ng.links.new(attr.outputs["Vector"], add.inputs[1])
    ng.links.new(add.outputs["Vector"], z3.inputs[0])
    if ng.get(plock.PLOCK_DELTA_VERSION_KEY):
        del ng[plock.PLOCK_DELTA_VERSION_KEY]
    mesh = ob.data
    a = mesh.attributes.get(plock.UV_DELTA_ATTR_LEGACY) or mesh.attributes.new(
        plock.UV_DELTA_ATTR_LEGACY, "FLOAT_VECTOR", "POINT")
    a.data.foreach_set("vector", list(delta) * len(mesh.vertices))
    mesh.update()


print("=" * 84)
print("### [1b] 旧 delta=0.2 升级跳变的精确幅度（只统计「图案覆盖到的像素」）")
sc, cam, cd, mat, A = build()
legacy_group_and_attr(cam, A, (0.2, 0.0, 0.0))
bpy.context.view_layer.update()
u_old = uvimg("old")
mask = np.abs(u_old).max(axis=2) > 0.05       # 背景解码后是 (-2,-2)，图案区在 ±1 内
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
u_lock = uvimg("lock")
d = np.abs(u_lock - u_old)
print("  图案覆盖像素占比 %.1f%%" % (100.0 * mask.mean()))
print("  全图平均 |ΔUV| = %.4f" % d.mean())
print("  图案区内平均 |ΔUV| = %.4f   最大 = %.4f" % (d[mask].mean(), d[mask].max()))
print("  X 通道图案区平均 = %.4f   Y 通道 = %.4f" % (d[mask][:, 0].mean(), d[mask][:, 1].mean()))
print("  参照：0.2 UV × zoom(lens/sensor=50/36=1.389) = %.4f" % (0.2 * 50.0 / 36.0))

print("")
print("=" * 84)
print("### [2] 旧属性 compify_plock_uv_delta 留在「新组」网格上 → 是否干扰计算")
sc, cam, cd, mat, A = build()
# 新组（已含 S/C），手工塞一个 delta=0.5 的旧属性；没有旧 Attribute 节点引用它
mesh = A.data
a = mesh.attributes.new(plock.UV_DELTA_ATTR_LEGACY, "FLOAT_VECTOR", "POINT")
a.data.foreach_set("vector", [0.5, 0.5, 0.0] * len(mesh.vertices))
mesh.update()
u0 = uvimg("newgrp_before")
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
u1 = uvimg("newgrp_lock")
print("  锁定后旧属性是否还在: %s" % (A.data.attributes.get(plock.UV_DELTA_ATTR_LEGACY) is not None))
print("  锁定瞬间图案变化（应为 0，属性不参与计算）= %.5f" % np.abs(u1 - u0).mean())
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
print("  解锁后旧属性是否还在: %s" % (A.data.attributes.get(plock.UV_DELTA_ATTR_LEGACY) is not None))
nodes = plock._find_delta_nodes(cam.data.name)
print("  解锁后 C = %s" % (list(nodes[1].inputs[1].default_value)[:2] if nodes else None))

print("")
print("### [2b] 非锁定网格上的旧属性：lock 会不会顺手清理？")
sc, cam, cd, mat, A = build()
# 再造一个不参与投影的网格（无材质）
mesh2 = bpy.data.meshes.new("Other"); mesh2.from_pydata([(0, 0, 0), (1, 0, 0), (0, 1, 0)], [], [(0, 1, 2)])
mesh2.update()
B = bpy.data.objects.new("Other", mesh2); sc.collection.objects.link(B)
a2 = mesh2.attributes.new(plock.UV_DELTA_ATTR_LEGACY, "FLOAT_VECTOR", "POINT")
a2.data.foreach_set("vector", [0.5, 0.5, 0.0] * 3)
plock.lock_group(sc, cam)
print("  非投影网格上的旧属性 lock 后仍在: %s" % (B.data.attributes.get(plock.UV_DELTA_ATTR_LEGACY) is not None))

print("RF_QUANT_DONE")
