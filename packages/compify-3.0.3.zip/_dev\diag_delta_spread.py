"""直接回答：compify_plock_uv_delta 每个顶点的数值是否一样？

逐顶点 delta_i = 冻结透视坐标 - 实时透视坐标
如果所有 delta_i 相同 ⇒ 一个全局 vector 就够（方案 D 可行）
如果不同 ⇒ 必须逐顶点

测三种相机操作 × 三种网格形状。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(shape):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    ns = 3
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -1.5 + 3.0*ix/ns
            y = -1.5 + 3.0*iy/ns
            if shape == "平面":
                z = 0.0
            elif shape == "倾斜":
                z = 1.2 * x
            else:  # 立体分层
                z = (iy - 1.5) * 1.5
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def persp_of(cam, ob):
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


def run(shape, opname, mutate):
    sc, cam, cd, ob = build(shape)
    plock.lock_group(sc, cam)
    frozen = persp_of(cam, ob)          # 锁定瞬间 = 冻结图案
    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    live = persp_of(cam, ob)
    d = frozen - live                   # 逐顶点 delta

    depths = []
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    for i in range(len(ob.data.vertices)):
        depths.append(abs(a.data[i].vector[2]))
    depths = np.array(depths)

    spread_x = d[:, 0].max() - d[:, 0].min()
    spread_y = d[:, 1].max() - d[:, 1].min()
    spread = max(spread_x, spread_y)
    print("  %-6s %-8s 深度[%.2f,%.2f]  delta极差=(%.6f, %.6f)  %s" % (
        shape, opname, depths.min(), depths.max(), spread_x, spread_y,
        "每顶点相同 ✓" if spread < 1e-6 else "每顶点不同 ✗"))


print("=" * 82)
print("compify_plock_uv_delta 逐顶点数值是否一致？")
print("=" * 82)
print("  %-6s %-8s %s" % ("网格", "操作", "结论"))
for shape in ("平面", "倾斜", "立体"):
    run(shape, "平移", lambda cam, cd: setattr(cam.location, "x", 2.0))
    run(shape, "变焦", lambda cam, cd: setattr(cd, "lens", 85.0))
    run(shape, "旋转", lambda cam, cd: setattr(cam.rotation_euler, "z", math.radians(15)))
    print()
print("SPREAD_DONE")
