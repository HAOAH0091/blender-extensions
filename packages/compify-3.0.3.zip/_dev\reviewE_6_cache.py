"""审查E-6/E-7：_proj_cache 是否随「相机改名/删除」无限增长？
              弹窗队列与 timer 注册在「对象一直不可冻结」时是否重复堆积？

headless 下 _popup_supported() 恒 False（弹窗 API 会崩），所以这里：
  · 真实统计 _popup_queue / _backfill_warned / _popup_shown 的增长；
  · 用打桩把 _popup_supported 强制成 True + 打桩 bpy.app.timers.register 计数，
    只验证「注册逻辑」而不真的注册（避免 headless 崩溃）。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 12)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

ns, H = 3, 1.0
verts, faces = [], []
for iy in range(ns + 1):
    for ix in range(ns + 1):
        verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy * (ns + 1) + ix
        faces.append((a, a + 1, a + ns + 2, a + ns + 1))
mesh = bpy.data.meshes.new("G0")
mesh.from_pydata(verts, [], faces)
mesh.update()
ob = bpy.data.objects.new("Grid0", mesh)
sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

# ── A. 相机改名 20 次：_proj_cache 是否留下孤儿条目 ────────────────
print("[A] _proj_cache 与相机改名")
plock.lock_group(sc, cam)
plock.unlock_group(sc, cam)
rows = []
for i in range(20):
    cd.name = "CamR%d" % i
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    rows.append((i, len(plock._proj_cache)))
print("    改名后 _proj_cache 条目：%d → %d（%s）" % (
    rows[0][1], rows[-1][1], "增长" if rows[-1][1] > rows[0][1] else "不增长"))
print("    _proj_cache 键 = %s" % (list(plock._proj_cache.keys())[:6],))

# ── B. 相机被删除后条目是否回收 ────────────────────────────────
print("\n[B] 删相机后 _proj_cache")
n0 = len(plock._proj_cache)
cam2 = bpy.data.objects.new("Cam2", bpy.data.cameras.new("Cam2Data"))
sc.collection.objects.link(cam2)
bpy.context.view_layer.update()
plock.objects_using_projection_cached("Cam2Data")
n1 = len(plock._proj_cache)
bpy.data.objects.remove(cam2, do_unlink=True)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
n2 = len(plock._proj_cache)
print("    加相机前 %d，缓存后 %d，删相机+跑一帧后 %d" % (n0, n1, n2))
print("    仍留着的键 = %s" % ([k for k in plock._proj_cache.keys()],))

# ── C. 不可冻结对象一直存在：弹窗队列/timer 注册次数 ──────────────
print("\n[C] 弹窗队列 / timer 注册")
ob2 = bpy.data.objects.new("GridMod", mesh.copy())
sc.collection.objects.link(ob2)
ob2.data.materials.append(mat)
m = ob2.modifiers.new("Sub", "SUBSURF")
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
q0 = len(plock._popup_queue)
for i in range(60):
    plock.parallax_lock_update_handler(sc)
q1 = len(plock._popup_queue)
print("    跑 60 帧后 _popup_queue=%d（本轮新增 %d），_backfill_warned=%d，"
      "timer_on=%s" % (q1, q1 - q0, len(plock._backfill_warned), plock._popup_timer_on[0]))

_reg = []


def fake_reg(fn, first_interval=0.0, persistent=False):
    _reg.append(fn)
    return None


_orig_reg = bpy.app.timers.register
bpy.app.timers.register = fake_reg
plock._popup_supported = lambda: True
plock._popup_timer_on[0] = False
for i in range(60):
    plock._queue_unfreezable_popup("GridMod", ["修改器"])
print("    打桩下 60 次登记 → timers.register 调用 %d 次（_popup_timer_on=%s）" % (
    len(_reg), plock._popup_timer_on[0]))
bpy.app.timers.register = _orig_reg

# ── D. _popup_shown 对已删除对象是否清 ─────────────────────────
print("\n[D] _popup_shown 增长")
plock._popup_shown.add("Ghost1")
plock._popup_shown.add("Ghost2")
plock.unlock_group(sc, cam)
print("    解锁后 _popup_shown=%d, _popup_queue=%d, _backfill_warned=%d" % (
    len(plock._popup_shown), len(plock._popup_queue), len(plock._backfill_warned)))
