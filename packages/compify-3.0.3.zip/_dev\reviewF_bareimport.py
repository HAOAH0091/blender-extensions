"""审查 F-7b（精简）：裸模块导入时 `_ensure_delta_group` 静默返回 False
   —— 因为函数内部只写了 `from . import node_groups`（相对导入），没有绝对导入兜底。
   对照：同文件顶部的 names 导入有 try/except 兜底；node_groups.py 则完全没有兜底。
"""
import bpy, sys, os, inspect, importlib.util, traceback

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
sys.path.insert(0, PKG_DIR)

import compify_parallax_lock as bare
print("裸模块 __package__ = %r" % bare.__package__)

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
sc.camera = cam
# 造一个「名字正确但没有 S/C 节点」的投影组（= 旧工程）
ng = bpy.data.node_groups.new("Camera Project | Cam", "ShaderNodeTree")
print("组存在 =", bpy.data.node_groups.get("Camera Project | Cam") is not None)
print("裸模块 _ensure_delta_group ->", bare._ensure_delta_group(cam))
print("裸模块 _find_delta_nodes    ->", bare._find_delta_nodes("Cam"))
print("结论：返回 False ⇒ 锁定不写恒等 S/C、解锁不落实构图（只印一句『未能落实』），无异常无提示。")

# 复现被吞掉的那句异常（把同一个导入语句放到裸模块顶层执行）
try:
    exec("from . import node_groups", {"__package__": None})
except Exception as e:
    print("被吞掉的异常：%s: %s" % (type(e).__name__, e))

# 对照：node_groups.py 裸导入直接失败（没有兜底）
try:
    import node_groups
    print("node_groups 裸导入成功")
except Exception as e:
    print("node_groups 裸导入：%s: %s" % (type(e).__name__, e))

src = inspect.getsource(bare._ensure_delta_group)
print("函数内的导入语句：", [l.strip() for l in src.splitlines() if "import" in l])
print("RF_BARE_DONE")
