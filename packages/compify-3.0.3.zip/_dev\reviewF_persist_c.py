"""审查 F-5c：存档重开后连续跑 handler，几何/相机是否漂移（跨会话累积）"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
plock.register_handlers()

B = os.path.join(HERE, "_rfp_")
bpy.ops.wm.open_mainfile(filepath=B + "p1_locked.blend")
sc = bpy.context.scene
cam = bpy.data.objects.get("Cam")
A = bpy.data.objects.get("Grid0")
print("打开后 cam loc = %s, lens = %.2f, state.applied_dolly = %s"
      % ([round(x, 6) for x in cam.location], cam.data.lens,
         (plock.get_state(sc, cam) or {}).get("applied_dolly")))
v0 = [tuple(A.matrix_world @ v.co) for v in A.data.vertices]
c0 = tuple(cam.location)
m0 = [tuple(r) for r in A.matrix_world]
worst_v = worst_c = worst_m = 0.0
for i in range(20):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    v = [tuple(A.matrix_world @ v.co) for v in A.data.vertices]
    worst_v = max(worst_v, max(max(abs(a - b) for a, b in zip(p, q)) for p, q in zip(v0, v)))
    worst_c = max(worst_c, (cam.location - __import__("mathutils").Vector(c0)).length)
    m = [tuple(r) for r in A.matrix_world]
    worst_m = max(worst_m, max(max(abs(a - b) for a, b in zip(p, q)) for p, q in zip(m0, m)))
print("20 帧后（相机未动）：几何最大漂移 %.3e  相机最大漂移 %.3e  位姿最大漂移 %.3e"
      % (worst_v, worst_c, worst_m))
print("  注意：p1 存档是「锁定中 + 已变焦 70mm」→ 若这里漂移，说明每次打开文件都在推拉相机")

# 再验一次「打开文件后立即移相机」的适配是否与保存前一致
bpy.ops.wm.open_mainfile(filepath=B + "p1_locked.blend")
sc = bpy.context.scene
cam = bpy.data.objects.get("Cam")
A = bpy.data.objects.get("Grid0")
cam.location.x += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
v1 = [tuple(A.matrix_world @ v.co) for v in A.data.vertices]
print("移相机后几何最大位移 %.4f（应 >0）"
      % max(max(abs(a - b) for a, b in zip(p, q)) for p, q in zip(v0, v1)))
print("RF_DRIFT_DONE")
