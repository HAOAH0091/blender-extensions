# _dev 诊断脚本说明

本目录是排查过程留下的验证/诊断脚本。**不是回归网**（回归网是 test_*.py）。

## 结论可信的（可以作为依据）

| 脚本 | 用途 |
|---|---|
| `verify_psd_align.py` | **最终判据**：拖动当帧不动、拖动后移相机构图保持、基准按当前几何重算、滚动 ∝ 1/基准。统一用 Blender 官方 `world_to_camera_view` 做尺子。 |
| `verify_layers_adapt.py` | 三层同视线，世界位移 = Δ(1−k)，三层屏幕位移严格一致 |
| `verify_drag_along_ray.py` | 拖动沿【相机视线】而非世界 Z（x ÷ 深度 恒定） |
| `verify_cam_adapt3.py` | 世界位移 = Δ(1−k) 的两层验证 |
| `compare_ref_update.py` | 「冻结 ref」vs「对齐 PSD（相机变化时重算）」对比 |
| `diag_bcal.py` | 手算 vs 实测逐项对照（曾用它发现「顶点 ≠ 中心」的混淆） |
| `diag_spy.py` | 插桩跟踪 recompute/adapt 实际用的 ref（曾用它抓到 ref 未持久化） |

## 投影组「节点被删」相关（2026-10-20，**功能已撤销**）

> 用户判断：「用户不会进节点组内部删节点，这个问题可以忽略了」⇒ 选 B，整个功能撤销。
> 下面几个脚本**不再是回归网**，保留是因为它们记录的事实/方法有独立价值。

| 脚本 | 保留价值 |
|---|---|
| `repro_node_damage.py` | 复现了「删掉投影组内的 S 节点 ⇒ 点解锁时 `_ensure_delta_group` 会**清空整组重建**，把用户自定义节点一起推平」（实测 `USER_MARK` 在解锁瞬间消失）。这条产品行为是事实，以后再碰投影组重建时用得上。 |
| `diag_sc_sockets.py` | ★ 用它发现 **bpy 结构体不能用 `is` 比较** —— 同一个节点，`ng.nodes.get("PLock Delta S") is link.from_node` 返回 **False**（bpy 是 C 数据块的包装器，不保证 Python 单例）。这个坑有普适性，跟本次功能无关也该记住。 |
| `diag_panel_ui3.py` | **GUI 截图验证方法**。连踩 5 个坑才拍成，坑见下。它会因 `plock.projection_group_damage` 已删而报错，属预期。 |

### 已撤销的实现（git 历史 `d825536` 可查）

`compify_parallax_lock.py` 的 `projection_group_damage()` / `_find_node_by_label()` /
`repair_projection_group()`、`__init__.py` 的 `CompifyRepairProjectionGroup` 及面板按钮、
`test_repair_projection.py` / `test_repair_button_gate.py` 已全部移除。

## 已删除的（保留在 git 历史里）

| 脚本 | 为什么删 |
|---|---|
| `verify_cam_adapt.py` | 「刚性跟随视锥体」对照实现写错了（矩阵用反），测出「A 画面位置变化 2.69」是**错误结论**。正确判据见 `verify_psd_align.py`。 |
| `verify_cam_adapt2.py` | 同段错误对照；它的有效发现（同视线上不同深度的两点屏幕位移相同）已被 `verify_psd_align.py` 覆盖。 |
| `diag_ratio.py` | 同时用了两套屏幕度量（手写 x/depth 与另一套），其中一套在相机移动后忘了减相机位置，导致同一现象算出互相矛盾的数，结论不可信。 |

## 教训

**手写屏幕度量是坑**：x/z、x/depth、NDC 三者单位不同，符号容易搞反，相机移动后容易忘减相机位置。
所有「是否跳变 / 是否移动」的判据，**只用 `world_to_camera_view`**（渲染实际使用的投影，含 lens/sensor/shift）。
