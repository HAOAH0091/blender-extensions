"""审查 C · 第 3 项：sensor（sensor_width / sensor_height / sensor_fit）

现象：
  · 锁定期间改 **sensor_width** → 解锁跳 0.1112（和已修的「变焦跳 0.10」同源，
    但走的不是 lens 这条路）。根因：fit_delta_params 只除 lens_ratio：
        lens_ratio = lens_ul / lens_lock
    而投影组的 zoom_1 = lens / **sensor_width**，所以视场比应当是
        (lens_ul/sensor_ul) / (lens_lock/sensor_lock)
    sensor_width 一改，zoom 变了而 S 没跟着变 ⇒ 整幅图案按 UV 量级缩放。
  · sensor_fit = VERTICAL / 改 sensor_height：**不跳**（投影组根本不读这两个值），
    但图案本身就和相机取景错位（差 0.18~0.19 UV）。
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy


def run(tag, mutate, **kw):
    sc, cam, cd, mat, ob = build(**kw)
    p0 = render_uv("a")
    amx, amn, an = align_err(sc, cam, ob, p0)
    plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL = render_uv("l")
    iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL2 = render_uv("l2")
    iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
    sm = np.intersect1d(iL, iL2)
    glue = float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max()) if len(sm) else float("nan")
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    pU = render_uv("u")
    jump = diff(pL2, pU)[0]
    sc_ = nodes_sc(cd)
    print("  %-30s 未锁定对齐=%.4f 粘住=%.4f JUMP=%.4f  S=%.4f C=(%+.4f,%+.4f)"
          % (tag, amx, glue, jump, sc_[0], sc_[1][0], sc_[1][1]))
    return amx, glue, jump


print("### 3a 锁定期间改 sensor_width ###")
a1 = run("sensor_width 36→24", lambda cam, cd: setattr(cd, "sensor_width", 24.0))
a2 = run("sensor_width 36→48", lambda cam, cd: setattr(cd, "sensor_width", 48.0))
a3 = run("lens 50→85（已修，对照）", lambda cam, cd: setattr(cd, "lens", 85.0))

print("\n### 3b sensor_fit / sensor_height ###")
b1 = run("sensor_fit=VERTICAL 只移相机", lambda cam, cd: setattr(cam.location, "x", 2.0),
         sensor_fit="VERTICAL", sensor_height=24.0)
b2 = run("sensor_fit=VERTICAL 锁中改 height 24→48",
         lambda cam, cd: setattr(cd, "sensor_height", 48.0),
         sensor_fit="VERTICAL", sensor_height=24.0)
b3 = run("sensor_fit=VERTICAL 锁中改 fit→HORIZONTAL",
         lambda cam, cd: setattr(cd, "sensor_fit", "HORIZONTAL"),
         sensor_fit="VERTICAL", sensor_height=24.0)

chk("3a 锁中改 sensor_width 36→24：应不跳", a1[2] < 2e-3, "JUMP=%.4f（图案按 UV 量级缩放）" % a1[2])
chk("3a 锁中改 sensor_width 36→48：应不跳", a2[2] < 2e-3, "JUMP=%.4f" % a2[2])
chk("3a 对照 lens 50→85：不跳（已修）", a3[2] < 2e-3, "JUMP=%.4f" % a3[2])
chk("3b sensor_fit=VERTICAL：解锁不跳", b1[2] < 2e-3, "JUMP=%.4f" % b1[2])
chk("3b 锁中改 sensor_height：解锁不跳", b2[2] < 2e-3, "JUMP=%.4f" % b2[2])
chk("3b 锁中改 sensor_fit：解锁不跳", b3[2] < 2e-3, "JUMP=%.4f" % b3[2])
print("\n  注意：sensor_fit=VERTICAL 时『未锁定对齐』就有 %.4f 偏差（投影组只读 sensor_width，"
      "不读 sensor_height/fit）" % b1[0])

report("审查 C · sensor")
