"""审查 C · 第 4 项：镜头位移 shift_x / shift_y

现象（本脚本量出来的）：
  shift 静止不为 0 —— 锁定/解锁完全正常（跳 0）
  锁定期间**改** shift_x  —— 解锁跳 ≈ Δshift（0.100）
根因（读代码 + 实测对照）：
  patch 会把投影组里 Lens Shift X/Y 两个 Value 节点冻结（FROZEN_VALUE_LABELS），
  所以锁定期间图案确实粘住；但 unlock 的「落实」只把 (S, C) 拟合成
  target = frozen_persp / lens_ratio，**只除了 lens 的比**。
  而投影组里 shift 是 plock 节点**下游**的减法（b 项）：
      UV = f(persp·S + C)，f 里含 −shift
  解锁恢复 driver 后 f 的 b 变了 ⇒ 差一个 Δshift，必须并进 C 才算「不跳」。
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy


def run(tag, shift0, mutate):
    sc, cam, cd, mat, ob = build(shift=shift0)
    p0 = render_uv("a")
    amx, _, _ = align_err(sc, cam, ob, p0)
    plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL = render_uv("l")
    iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL2 = render_uv("l2")
    iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
    sm = np.intersect1d(iL, iL2)
    glue = float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max()) if len(sm) else float("nan")
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    pU = render_uv("u")
    jump, jmx, jn = diff(pL2, pU)
    sc_ = nodes_sc(cd)
    print("  %-24s 未锁定对齐=%.4f 锁定中粘住=%.4f 解锁 JUMP=%.4f  S/C=%.3f/%+.4f,%+.4f"
          % (tag, amx, glue, jump, sc_[0], sc_[1][0], sc_[1][1]))
    return jump


print("### 4 shift 镜头位移 ###")
j1 = run("shift0=(0,0) 只移相机", (0.0, 0.0), lambda cam, cd: setattr(cam.location, "x", 2.0))
j2 = run("shift0=(0.1,0.05) 只移相机", (0.1, 0.05), lambda cam, cd: setattr(cam.location, "x", 2.0))
j3 = run("锁定中 shift_x 0→0.100", (0.0, 0.0), lambda cam, cd: setattr(cd, "shift_x", 0.100))
j4 = run("锁定中 shift_y 0→0.050", (0.0, 0.0), lambda cam, cd: setattr(cd, "shift_y", 0.050))
j5 = run("锁定中 shift_x 0→0.010", (0.0, 0.0), lambda cam, cd: setattr(cd, "shift_x", 0.010))

chk("4 静态 shift：解锁不跳", j1 < 2e-3 and j2 < 2e-3, "%.4f / %.4f" % (j1, j2))
chk("4 锁中改 shift_x=0.100：解锁跳 ≈ 0.100", j3 < 2e-3, "JUMP=%.4f（应 ≈0）" % j3)
chk("4 锁中改 shift_y=0.050：解锁跳 ≈ 0.050", j4 < 2e-3, "JUMP=%.4f（应 ≈0）" % j4)
print("  小位移 0.010 也跳（说明不是大位移的数值问题）：JUMP=%.4f" % j5)

report("审查 C · shift")
