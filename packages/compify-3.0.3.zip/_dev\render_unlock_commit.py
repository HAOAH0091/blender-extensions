"""真渲染验证：解锁瞬间画面是否跳变（以像素为准，不信 UV 数学）

锁定 → 移相机 → 渲染 A；解锁 → 渲染 B。
A 与 B 的像素差 = 用户实际看到的跳变。

用法：blender --background --factory-startup --python render_unlock_commit.py -- <mode>
mode: plain | modifier
"""
import bpy
import sys
import os
import math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
argv = sys.argv
MODE = "plain"
if "--" in argv:
    rest = argv[argv.index("--") + 1:]
    if rest:
        MODE = rest[0]

PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
MU = __import__("mathutils")

OUT = os.path.dirname(os.path.abspath(__file__))
RES = 240


def make_checker(size=256, cells=8):
    """棋盘图 —— 图案边界清晰，任何滑动都看得见"""
    img = bpy.data.images.new("Checker", size, size, alpha=False)
    px = np.zeros((size, size, 4), dtype=np.float32)
    cell = size // cells
    for y in range(size):
        for x in range(size):
            on = ((x // cell) + (y // cell)) % 2 == 0
            v = 0.95 if on else 0.05
            px[y, x] = (v, v, v, 1.0)
    img.pixels.foreach_set(px.reshape(-1))
    img.pack()
    return img


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass

    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0)
    cam.rotation_euler = (0.0, 0.0, 0.0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

    img = make_checker()
    mat = bpy.data.materials.new("Proj")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
    nt.links.new(tex.outputs["Color"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    # 网格尺寸：plain=4x4（边缘在画面内） / big=14x14（边缘出画面，只看图案）
    HALF = 7.0 if MODE == "big" else 2.0
    mesh = bpy.data.meshes.new("Grid")
    ns = 4
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-HALF + 2.0 * HALF * ix / ns, -HALF + 2.0 * HALF * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)

    if MODE == "modifier":
        m = ob.modifiers.new("Subdiv", "SUBSURF")
        m.levels = 1
        m.render_levels = 1

    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def render_to(path):
    _seq[0] += 1
    root, ext = os.path.splitext(path)
    path = "%s_%02d%s" % (root, _seq[0], ext)      # 每次唯一，杜绝读到旧文件
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    dg.update()
    bpy.context.scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
    if not os.path.exists(path):
        raise RuntimeError("render 没产出: " + path)
    im = bpy.data.images.load(path)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    arr = buf.reshape(im.size[1], im.size[0], 4).copy()
    bpy.data.images.remove(im)
    return arr


def main():
    print("=" * 76)
    print("真渲染验证（mode=%s）" % MODE)
    print("=" * 76)
    sc, cam, cd, ob = build()

    r = plock.lock_group(sc, cam)
    print("  lock:", r.get("message", "")[:40])

    # 场景1：平移
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()

    a = render_to(os.path.join(OUT, "_render_locked_%s.png" % MODE))
    a_check = render_to(os.path.join(OUT, "_render_locked_%s_check.png" % MODE))
    print("  [debug] 锁定态重复渲染一致性: %.6f" %
          float(np.abs(a[..., :3] - a_check[..., :3]).max()))
    print("  已渲染：锁定中（移相机后）")

    def _fu():
        a_attr = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a_attr is None or len(a_attr.data) != len(ob.data.vertices):
            return None
        return np.array([(a_attr.data[i].vector[0] / a_attr.data[i].vector[2],
                          a_attr.data[i].vector[1] / a_attr.data[i].vector[2])
                         for i in range(len(a_attr.data))])

    def _lu():
        m = cam.matrix_world.inverted()
        out = []
        for v in ob.data.vertices:
            p = m @ (ob.matrix_world @ v.co)
            out.append((p.x / p.z, p.y / p.z))
        return np.array(out)

    _f0, _l0 = _fu(), _lu()
    print("  [debug] 解锁前 frozen[0]=%s live[0]=%s 差=%.6f" % (
        None if _f0 is None else np.round(_f0[0], 5),
        np.round(_l0[0], 5),
        -1 if _f0 is None else float(np.abs(_f0 - _l0).max())))

    r2 = plock.unlock_group(sc, cam)
    print("  unlock:", r2.get("message", "")[:60])
    bpy.context.view_layer.update()

    _f1, _l1 = _fu(), _lu()
    print("  [debug] 解锁后 frozen=%s live[0]=%s" % (
        "已清" if _f1 is None else "仍在", np.round(_l1[0], 5)))
    print("  [debug] 解锁后 实时UV vs 解锁前冻结UV 差=%.6f" % (
        -1 if _f0 is None else float(np.abs(_l1 - _f0).max())))
    print("  [debug] 顶点世界 x 前3 =", np.round([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices][:3], 4))

    b = render_to(os.path.join(OUT, "_render_unlocked_%s.png" % MODE))
    print("  已渲染：解锁后")

    d = np.abs(a[..., :3] - b[..., :3])
    maxd = float(d.max())
    meand = float(d.mean())
    changed = float((d.max(axis=2) > 0.02).mean()) * 100
    print()
    print("  >>> 解锁瞬间像素差：max=%.4f  mean=%.6f  变化像素 %.2f%%" %
          (maxd, meand, changed))
    print("  >>> %s" % ("画面没跳 ✓" if changed < 0.5 else "画面跳了 ✗"))

    # 场景2：解锁后再移相机，图案应滑动
    c = b  # 占位（不再覆写 locked 图）
    cam.location.x = 3.0
    bpy.context.view_layer.update()
    print("  [debug] 移相机后 live[0]=%s (解冻时应变化)" % (np.round(_lu()[0], 5),))
    print("  [debug] 组是否 patch: %s" % plock.is_patched(cd.name))
    d2arr = render_to(os.path.join(OUT, "_render_after_%s.png" % MODE))
    dd = np.abs(b[..., :3] - d2arr[..., :3])
    ch2 = float((dd.max(axis=2) > 0.02).mean()) * 100
    print("  >>> 解锁后再移相机：变化像素 %.2f%%  (%s)" %
          (ch2, "图案在滑动 ✓" if ch2 > 0.5 else "钉死 ✗"))
    print("RENDER_DONE")


main()
