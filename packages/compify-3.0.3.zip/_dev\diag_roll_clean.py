"""「滚动速度」干净测量（隔离 ref 的单一变量）

上一版有个缺陷：改 ref_depth 时会连带改 dolly（=(ref-axial)/ref）和静态位置，
所以测出来的横移混了好几个效应。这一版只用「同一 ref 下两个相机位置的差值」
= d(屏幕x)/d(相机x) = 1/(ref × dolly × zoom)，把静态项完全消掉。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(zA=0.0, zB=2.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns,
                              -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("A", -1.5, zA)
    B = mk("B", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def screen(ob, cam):
    inv = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = inv @ (ob.matrix_world @ v.co)
        out.append((p.x / p.z, p.y / p.z) if abs(p.z) > 1e-9 else (0.0, 0.0))
    return np.array(out)


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def measure_roll(sc, cam, objs, x_from, x_to):
    """在同一 ref 下，测相机从 x_from 移到 x_to 时各对象的屏幕横移"""
    cam.location.x = x_from
    step(sc)
    s0 = {n: screen(o, cam) for n, o in objs.items()}
    cam.location.x = x_to
    step(sc)
    s1 = {n: screen(o, cam) for n, o in objs.items()}
    return {n: float(np.mean(s1[n][:, 0] - s0[n][:, 0])) for n in objs}


print("=" * 88)
print("① 「滚动速度」= 相机移动 1.0 时画面横移多少（不变焦，dolly=1）")
print("=" * 88)
print("  公式推导：屏幕x = x0/(d_base·dolly·zoom) − delta_cs/(ref·dolly·zoom)")
print("            ⇒ d(屏幕x)/d(delta_cs) = 1/(ref·dolly·zoom)")
print("            ⇒ 不变焦时 dolly=zoom=1，所以滚动量 = 1/ref")
print()
print("  %8s %14s %16s %14s" % ("ref", "理论 1/ref", "实测（A）", "实测（B）"))
for target_ref in (8.0, 7.0, 6.0, 4.0):
    sc, cam, cd, A, B = build()
    plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    # 只改 ref，先把状态安置好（此时还不动相机）
    st["ref_depth"] = target_ref
    plock.save_groups(sc, {cd.name: st})
    step(sc)
    r = measure_roll(sc, cam, {"A": A, "B": B}, 1.0, 2.0)
    print("  %8.1f %14.6f %16.6f %14.6f" % (target_ref, 1.0 / target_ref,
                                            r["A"], r["B"]))

print()
print("=" * 88)
print("② 两种做法：拖 A 之后再移相机，B 的滚动量")
print("=" * 88)


def run(mode):
    sc, cam, cd, A, B = build()      # A 深度8（最深），B 深度6
    plock.lock_group(sc, cam)
    ref_lock = plock.get_state(sc, cam).get("ref_depth", 0)

    A.location.z += 2.0              # 拖 A 变近
    step(sc)

    if mode == "recompute":
        st = plock.get_state(sc, cam)
        plock.recompute_ref_depth(sc, st, cd.name)   # 模拟 PSD「写回基准」
        plock.save_groups(sc, {cd.name: st})
        step(sc)

    ref_after = plock.get_state(sc, cam).get("ref_depth", 0)
    r = measure_roll(sc, cam, {"A": A, "B": B}, 1.0, 2.0)
    return ref_lock, ref_after, r


print()
for mode, label in [("freeze", "做法甲：ref 冻结（我上一轮）"),
                    ("recompute", "做法乙：ref 重算（PSD 做法）")]:
    rl, ra, r = run(mode)
    print("  %s" % label)
    print("    ref: 锁定 %.4f → 拖后 %.4f" % (rl, ra))
    print("    相机移 1.0 后：A 横移 %+.6f   B 横移 %+.6f" % (r["A"], r["B"]))

rl1, ra1, r1 = run("freeze")
rl2, ra2, r2 = run("recompute")
print()
print("=" * 88)
print("结论")
print("=" * 88)
print("  A（被拖的）：甲 %+.6f  vs  乙 %+.6f   差 %+.8f" % (
    r1["A"], r2["A"], r2["A"] - r1["A"]))
print("  B（没拖的）：甲 %+.6f  vs  乙 %+.6f   差 %+.8f" % (
    r1["B"], r2["B"], r2["B"] - r1["B"]))
if abs(r2["B"] - r1["B"]) > 1e-9:
    print("  ⇒ 做法乙改变了【没被拖的 B】的滚动速度：%.1f%%" % (
        abs(r2["B"] - r1["B"]) / abs(r1["B"]) * 100))
    print("     （B 自己一点没动，但拖 A 之后它滚得更快了）")
print("CLEAN_DONE")
