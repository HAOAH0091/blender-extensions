"""验证根因假设：投影组在 persp*S+C 之后还有 zoom 乘子（lens/sensor）

锁定时刻最终 UV  = persp_lock * Z_lock
解锁时刻最终 UV  = (persp_ul * S + C) * Z_ul
要求两者相等 ⇒ persp_ul*S + C = persp_lock * (Z_lock/Z_ul) = persp_lock / lens_ratio

我当前代码让右边 = persp_lock（少了 1/lens_ratio）⇒ 这就是跳变的来源。

本脚本用 numpy 直接验证「目标 = persp_lock / lens_ratio」能否被 S/C 精确表达。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(shape="平面", cam_loc=(0, 0, 5), cam_rot=(0, 0, 0)):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = cam_loc
    cam.rotation_euler = cam_rot
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 3
    H = 2.0
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -H + 2*H*ix/ns
            y = -H + 2*H*iy/ns
            z = 0.0 if shape == "平面" else (0.35*x if shape == "倾斜" else (iy-1.5)*0.5)
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def persp_cam(cam_mw, ob):
    m = cam_mw.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


def persp_campos(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                      a.data[i].vector[1]/a.data[i].vector[2])
                     for i in range(len(a.data))])


def fit_SC(target, live):
    """最小二乘解 target ≈ live*S + C（S 标量、C 二维）"""
    n = target.shape[0]
    A = np.zeros((2*n, 3))
    b = np.zeros(2*n)
    for i in range(n):
        A[i, 0] = 1.0; A[i, 1] = 0.0; A[i, 2] = live[i, 0]
        b[i] = target[i, 0]
        A[n+i, 0] = 0.0; A[n+i, 1] = 1.0; A[n+i, 2] = live[i, 1]
        b[n+i] = target[i, 1]
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    Cx, Cy, S = sol
    pred = np.zeros_like(target)
    pred[:, 0] = S*live[:, 0] + Cx
    pred[:, 1] = S*live[:, 1] + Cy
    return S, (Cx, Cy), float(np.abs(pred - target).max())


def run(tag, shape, cam_loc, cam_rot, zoom_to):
    sc, cam, cd, ob = build(shape, cam_loc, cam_rot)
    lens_lock = float(cd.lens)
    plock.lock_group(sc, cam)
    frozen = persp_campos(ob, cd)          # 锁定时刻的 persp（= 冻结图案）
    cam.data.lens = zoom_to
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    live = persp_cam(cam.matrix_world, ob)
    ratio = float(cd.lens) / lens_lock

    # 假设 1（当前实现）：目标 = frozen
    S1, C1, e1 = fit_SC(frozen, live)
    # 假设 2（修正）：目标 = frozen / ratio
    S2, C2, e2 = fit_SC(frozen / ratio, live)

    print("  %-20s ratio=%.3f" % (tag, ratio))
    print("    假设1 目标=frozen        S=%.4f C=(%+.4f,%+.4f) 残差=%.8f" % (S1, C1[0], C1[1], e1))
    print("    假设2 目标=frozen/ratio  S=%.4f C=(%+.4f,%+.4f) 残差=%.8f  %s" % (
        S2, C2[0], C2[1], e2, "可精确表达 ✓" if e2 < 1e-5 else "【仍不行】"))


print("=" * 92)
print("根因验证：是否需要把 zoom 乘子（lens 比）算进去")
print("=" * 92)
run("平面/居中", "平面", (0, 0, 5), (0, 0, 0), 85)
run("倾斜/居中", "倾斜", (0, 0, 5), (0, 0, 0), 85)
run("立体/居中", "立体", (0, 0, 5), (0, 0, 0), 85)
run("平面/偏移", "平面", (1.5, -0.8, 5), (0, 0, 0), 85)
run("立体/偏移", "立体", (1.5, -0.8, 5), (0, 0, 0), 85)
run("平面/旋转", "平面", (0, 0, 5), (0, 0, math.radians(12)), 85)
run("平面/缩到32", "平面", (0, 0, 5), (0, 0, 0), 32)
print("HYPOTH_DONE")
