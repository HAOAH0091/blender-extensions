"""审查 A-10：重复点「解锁」（已解锁状态下再调用一次）会不会改坏状态/给出错误提示
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock
L.report("A-10 已解锁状态下再点一次解锁 / 再点一次重置")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
orig = L.lverts(A).copy()
plock.lock_group(sc, cam)
cam.location.x += 0.5
L.run_h(sc, times=1)
r1 = plock.unlock_group(sc, cam)
S1, C1 = L.node_sc(cam)
u1 = L.uvimg("du")
print("  第 1 次解锁：%s" % r1["message"][:60])
print("     S=%.4f C=(%+.4f,%+.4f) uv_delta_committed=%s"
      % (S1, C1[0], C1[1], plock.load_groups(sc)[cd.name].get("uv_delta_committed")))
r2 = plock.unlock_group(sc, cam)
S2, C2 = L.node_sc(cam)
g = plock.load_groups(sc)[cd.name]
u2 = L.uvimg("du")
print("  第 2 次解锁：success=%s" % r2.get("success"))
print("     message=%s" % r2["message"][:80])
print("     S=%.4f C=(%+.4f,%+.4f) uv_delta_committed=%s 画面Δ=%.6f"
      % (S2, C2[0], C2[1], g.get("uv_delta_committed"), L.uvd(u2, u1)))
L.chk("重复解锁不改变已落实的 C+k", abs(S2 - S1) < 1e-9
      and abs(C2[0] - C1[0]) < 1e-9 and abs(C2[1] - C1[1]) < 1e-9,
      "C 从 (%+.4f) 变成 (%+.4f)" % (C1[0], C2[0]))
L.chk("重复解锁不改画面", L.uvd(u2, u1) < 2e-3, "Δ=%.6f" % L.uvd(u2, u1))
L.info("注意 message：第 2 次点了之后说的是「%s」" % r2["message"][:70])
# 再锁一次，确认没被点坏
r3 = plock.lock_group(sc, cam)
u3 = L.uvimg("du")
L.chk("重复解锁后仍能正常重新锁定", r3.get("success"), r3["message"][:50])
r4 = plock.unlock_group(sc, cam)
u4 = L.uvimg("du")
L.chk("重复解锁后重新锁定再解锁仍然不跳", L.uvd(u4, u3) < 2e-3,
      "Δ=%.6f" % L.uvd(u4, u3))
# 重复重置
r5 = plock.reset_group(sc, cam)
r6 = plock.reset_group(sc, cam)
L.info("重复重置：第1次=%s | 第2次=%s" % (r5["message"][:34], r6["message"][:34]))
L.chk("重复重置不抛异常且几何仍是原形",
      float(np.abs(L.lverts(A) - orig).max()) < 1e-6, "Δ=%.2e" % float(np.abs(L.lverts(A) - orig).max()))
L.summary()
