"""审查 F-5a：造 4 个存档（锁定中 / 已落实构图 / 保存时处于编辑模式 / 有不可冻结网格）"""
import bpy, sys, os, json
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
plock.register_handlers()

RES = 96
_rec = {}


def build(nmesh=1, tilt=True):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = sc.render.resolution_y = RES
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd); sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ"); comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission"); out = nt.nodes.new("ShaderNodeOutputMaterial")
    for ax in ("X", "Y"):
        m = nt.nodes.new("ShaderNodeMath"); m.operation = "MULTIPLY"; m.inputs[1].default_value = 0.25
        a = nt.nodes.new("ShaderNodeMath"); a.operation = "ADD"; a.inputs[1].default_value = 0.5
        nt.links.new(sep.outputs[ax], m.inputs[0]); nt.links.new(m.outputs["Value"], a.inputs[0])
        nt.links.new(a.outputs["Value"], comb.inputs[ax])
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    objs = []
    for k in range(nmesh):
        ns, H = 3, 2.0
        x0 = 0.0 if nmesh == 1 else (-3.0 + 6.0 * k)
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                x = x0 + (-H + 2 * H * ix / ns)
                y = -H + 2 * H * iy / ns
                verts.append((x, y, (0.28 * (x - x0)) if tilt else 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new("G%d" % k); mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new("Grid%d" % k, mesh); sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        objs.append(ob)
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, objs


_seq = [0]


def uvarr():
    _seq[0] += 1
    p = os.path.join(HERE, "_rfp_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32); im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def snapshot(tag, sc, cam, cd, objs):
    st = plock.get_state(sc, cam) or {}
    nodes = plock._find_delta_nodes(cd.name)
    d = {
        "tag": tag,
        "enabled": bool(st.get("enabled")),
        "locked_focal": st.get("locked_focal"),
        "ref_depth": st.get("ref_depth"),
        "S": float(nodes[0].inputs["Scale"].default_value) if nodes else None,
        "C": list(nodes[1].inputs[1].default_value)[:2] if nodes else None,
        "has_sc_nodes": nodes is not None,
        "patched": plock.is_patched(cd.name),
        "cam_loc": list(cam.location),
        "lens": cd.lens,
        "attrs": [[a.name for a in o.data.attributes if a.name.startswith("compify_plock")]
                  for o in objs],
        "verts": [[list(o.matrix_world @ v.co) for v in o.data.vertices] for o in objs],
        "modes": [o.mode for o in objs],
        "popup_queue": len(plock._popup_queue),
    }
    np.save(os.path.join(HERE, "_rfp_%s.npy" % tag), uvarr())
    _rec[tag] = d
    return d


B = os.path.join(HERE, "_rfp_")
print("=" * 84)

# ── 场景 1：锁定中保存 ─────────────────────────────────────────────
sc, cam, cd, mat, objs = build()
plock.lock_group(sc, cam)
cam.location.x = 2.0
cd.lens = 70.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
d = snapshot("p1_locked", sc, cam, cd, objs)
print("p1 锁定存档：enabled=%s S=%s C=%s patched=%s" % (d["enabled"], d["S"], d["C"], d["patched"]))
bpy.ops.wm.save_as_mainfile(filepath=B + "p1_locked.blend")

# ── 场景 2：解锁（已落实构图）后保存 ────────────────────────────────
sc, cam, cd, mat, objs = build()
plock.lock_group(sc, cam)
cam.location.x = 1.6
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
d = snapshot("p2_committed", sc, cam, cd, objs)
print("p2 已落实存档：enabled=%s S=%.4f C=(%.3f,%.3f) patched=%s"
      % (d["enabled"], d["S"], d["C"][0], d["C"][1], d["patched"]))
bpy.ops.wm.save_as_mainfile(filepath=B + "p2_committed.blend")

# ── 场景 3：锁定中，网格处于编辑模式时保存 ───────────────────────────
sc, cam, cd, mat, objs = build()
plock.lock_group(sc, cam)
cam.location.x = 1.2
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
A = objs[0]
bpy.context.view_layer.objects.active = A
A.select_set(True)
bpy.ops.object.mode_set(mode="EDIT")
print("p3 进入编辑模式，mesh 属性数 = %d（编辑模式下 len(data)=%s）"
      % (len(A.data.attributes),
         [len(a.data) for a in A.data.attributes if a.name.startswith("compify_plock_campos")]))
d = snapshot("p3_edit", sc, cam, cd, objs)
print("p3 编辑模式存档：enabled=%s mode=%s" % (d["enabled"], d["modes"]))
bpy.ops.wm.save_as_mainfile(filepath=B + "p3_edit.blend")
try:
    bpy.ops.object.mode_set(mode="OBJECT")
except Exception as e:
    print("  退出编辑模式失败:", e)

# ── 场景 4：锁定中有一个「带修改器」的网格（不可冻结 → 弹窗记录） ──────
sc, cam, cd, mat, objs = build(nmesh=2)
G2 = objs[1]
m = G2.modifiers.new("Subsurf", "SUBSURF")
plock.lock_group(sc, cam)
cam.location.x = 1.0
bpy.context.view_layer.update()
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
d = snapshot("p4_unfreezable", sc, cam, cd, objs)
print("p4 不可冻结存档：popup 队列=%d  _popup_shown=%s"
      % (d["popup_queue"], sorted(plock._popup_shown)))
bpy.ops.wm.save_as_mainfile(filepath=B + "p4_unfreezable.blend")

with open(B + "fingerprint.json", "w", encoding="utf-8") as f:
    json.dump(_rec, f, ensure_ascii=False)
print("RF_PERSIST_A_DONE  ->", B + "fingerprint.json")
