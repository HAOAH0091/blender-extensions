"""定位问题1：offset 为什么卡在 -2.5"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
MU = __import__("mathutils")

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0.0, 0.0, 5.0); cam.rotation_euler = (0.0, 0.0, 0.0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
mesh = bpy.data.meshes.new("G")
mesh.from_pydata([(-1,-1,0),(1,-1,0),(1,1,0),(-1,1,0)], [], [(0,1,2,3)])
mesh.update()
ob = bpy.data.objects.new("Grid", mesh)
sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

print(plock.lock_group(sc, cam).get("message"))
M_lock = ob.matrix_world.copy()
print("M_lock translation:", tuple(M_lock.translation))
print("CENTER_KEY =", ob.get(plock.CENTER_KEY))
print("_mesh_center_local =", tuple(plock._mesh_center_local(ob)))
print("MATRIX_KEY =", ob.get(plock.MATRIX_KEY))

# 逐次推近，每次都从 M_lock 起算并打印中间量
for step in [2.0, 2.5, 2.6, 3.0]:
    M = M_lock.copy()
    M.translation = M_lock.translation + MU.Vector((0, 0, step))
    ob.matrix_world = M
    bpy.context.view_layer.update()

    M_prev = plock._read_matrix_key(ob)
    M_cur = ob.matrix_world.copy()
    c_local = plock._mesh_center_local(ob)
    vi = plock.get_camera_view_matrix(cam).inverted()
    d_prev = plock._view_depth(vi, M_prev @ c_local)
    d_cur = plock._view_depth(vi, M_cur @ c_local)
    print("\n--- 推近 %.1f ---" % step)
    print("  M_prev 平移Z = %.4f" % M_prev.translation.z)
    print("  M_cur  平移Z = %.4f" % M_cur.translation.z)
    print("  c_local = %s" % (tuple(round(x,4) for x in c_local),))
    print("  d_prev=%.5f  d_cur=%.5f  期望offset=%.5f" % (d_prev, d_cur, d_cur-d_prev))
    print("  MIN_DEPTH=%.6f  d_cur<=MIN? %s" % (plock.MIN_DEPTH, d_cur <= plock.MIN_DEPTH))

    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    print("  handler 后 offset =", ob.get(plock.DRAG_OFFSET_KEY))
    ds = []
    for v in ob.data.vertices:
        p = vi @ (ob.matrix_world @ v.co)
        ds.append(-p.z)
    print("  顶点深度 = [%.5f, %.5f]" % (min(ds), max(ds)))
    print("  位姿Z = %.4f" % ob.matrix_world.translation.z)
    print("  CENTER_KEY 现在是 =", ob.get(plock.CENTER_KEY))
    print("  MATRIX_KEY 现在是 =", ob.get(plock.MATRIX_KEY))
