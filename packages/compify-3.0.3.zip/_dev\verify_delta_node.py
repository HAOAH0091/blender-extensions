"""验证投影组的 UV Delta 节点真的生效：
写一个已知常量偏移（+0.5, 0），渲染应与「无偏移」明显不同（棋盘平移 4 格）。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

OUT = os.path.dirname(os.path.abspath(__file__))
RES = 160


def make_checker(size=256, cells=8):
    img = bpy.data.images.new("Chk", size, size, alpha=False)
    px = np.zeros((size, size, 4), dtype=np.float32)
    cell = size // cells
    for y in range(size):
        for x in range(size):
            on = ((x // cell) + (y // cell)) % 2 == 0
            v = 0.95 if on else 0.05
            px[y, x] = (v, v, v, 1.0)
    img.pixels.foreach_set(px.reshape(-1))
    img.pack()
    return img


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = RES; sc.render.resolution_y = RES
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = "PNG"
sc.view_settings.view_transform = "Standard"
try: sc.eevee.taa_render_samples = 1
except Exception: pass

cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
print("组内节点:", [n.bl_idname + ":" + (n.label or n.name) for n in grp.nodes])

img = make_checker()
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

# 网格铺满画面
mesh = bpy.data.meshes.new("Grid")
mesh.from_pydata([(-12,-12,0),(12,-12,0),(12,12,0),(-12,12,0)], [], [(0,1,2,3)])
mesh.update()
ob = bpy.data.objects.new("Grid", mesh)
sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.context.view_layer.update()

_seq = [0]
def render(tag):
    _seq[0] += 1
    path = os.path.join(OUT, "_deltanode_%s_%02d.png" % (tag, _seq[0]))
    # 强制刷新：材质节点改动后必须让 depsgraph 重算
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get().update()
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(path)
    n = im.size[0]*im.size[1]*4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :3].copy()
    bpy.data.images.remove(im)
    return a


def pd(a, b):
    d = np.abs(a - b)
    return float((d.max(axis=2) > 0.02).mean() * 100)


a0 = render("nod")
print("无 delta 属性 → 渲染完成")

# 写常量 delta
n = len(mesh.vertices)
attr = mesh.attributes.new(name=plock.UV_DELTA_ATTR, type="FLOAT_VECTOR", domain="POINT")
attr.data.foreach_set("vector", np.tile([0.5, 0.0, 0.0], n).astype(np.float64))
mesh.update()
a1 = render("half")
print("delta=(+0.5, 0) → 渲染完成，与无偏移差异 %.2f%%" % pd(a0, a1))
print(">>> 节点生效: %s" % ("是" if pd(a0, a1) > 5 else "否 —— 节点没起作用！"))

attr.data.foreach_set("vector", np.tile([0.0, 0.0, 0.0], n).astype(np.float64))
mesh.update()
a2 = render("zero")
print("delta=0 → 与无偏移差异 %.2f%%（应≈0）" % pd(a0, a2))
print("DELTANODE_DONE")
