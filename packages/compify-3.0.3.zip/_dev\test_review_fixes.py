"""回归网：盯独立审查报出的 5 条问题（F1 / F2 / F3 / F7 / F9）。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL，
所以这张网是有判别力的（不是"写个恒真的断言"）。
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]
MU = importlib.import_module("mathutils")

P, F = [], []


def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-56s %s" % ("PASS" if cond else "FAIL", name, detail))


def snapshot(ob):
    n = len(ob.data.vertices)
    buf = [0.0] * (n * 3)
    ob.data.vertices.foreach_get("co", buf)
    return buf


def maxdiff(a, b):
    return max(abs(x - y) for x, y in zip(a, b)) if a and b else 0.0


def world_co(ob):
    return [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]


def make_cam(scene, name, lens=50.0):
    cd = bpy.data.cameras.new(name); cd.lens = lens; cd.sensor_width = 36.0
    cam = bpy.data.objects.new(name, cd)
    scene.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0)
    cam.rotation_euler = (0.0, 0.0, 0.0)          # 朝 -Z
    return cam


def make_pair(scene, prefix, cam, nz=2):
    """给相机建 nz 个平面网格，各自带 UV Adjust 组 + 共用该相机的投影材质。"""
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M_" + prefix)
    mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i in range(nz):
        bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, -float(i)))
        ob = bpy.context.active_object
        ob.name = "%s_O%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene


# ═════════════ F9：ref_depth 不得被「最终被跳过」的对象污染 ═════════════
print("=" * 68)
print("F9  ref_depth 不被跳过对象污染")
sc = fresh()
cam = make_cam(sc, "CamF9"); sc.camera = cam
objs = make_pair(sc, "F9", cam, 3)          # 深度 5/6/7
BAD = [(-0.5, -0.5, -85.0), (0.5, -0.5, -85.0), (0.5, 0.5, 6.0), (-0.5, 0.5, 6.0)]
me = bpy.data.meshes.new("BADM"); me.from_pydata(BAD, [], [(0, 1, 2, 3)]); me.update()
bad_ob = bpy.data.objects.new("BADO", me)
sc.collection.objects.link(bad_ob)
# ⚠️ 必须让它【进入锁定目标】，否则污染路径根本不被触发（判别力不足）
bad_ob.data.materials.append(objs[0].data.materials[0])
bpy.data.node_groups.new("UV Adjust | %s | %s" % (bad_ob.data.name, cam.data.name),
                         "ShaderNodeTree")
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
print("   skipped=%s  ref_depth=%.4f" % ([o for o, _ in r["skipped"]], st["ref_depth"]))
chk("F9  ref_depth = 7.0（只算确认锁定的对象）",
    abs(st["ref_depth"] - 7.0) < 1e-3, "实际 %.4f" % st["ref_depth"])

# ═════════════ F1：变焦 → 拖动(改 ref) → 变焦回原焦距，相机必须归位 ═════════════
print()
print("=" * 68)
print("F1  变焦 dolly 基准：拖动改写 ref_depth 后仍能精确归位")
sc = fresh()
cam = make_cam(sc, "CamF1"); sc.camera = cam
objs = make_pair(sc, "F1", cam, 3)
plock.lock_group(sc, cam)
z0 = cam.location.z
cam.data.lens = 85.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("   变焦后 cam.z = %.4f" % cam.location.z)
# 拖动最深网格 → recompute_ref_depth 会改写 ref_depth
v = plock.get_camera_view_matrix(cam)
axis = v.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
objs[2].location = objs[2].location + axis * 2.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
st = plock.get_state(sc, cam)
print("   拖动后 ref_depth = %.4f（已变）" % st["ref_depth"])
cam.data.lens = 50.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("F1  变焦回到原焦距后相机归位", abs(cam.location.z - z0) < 1e-5,
    "z=%.6f 应为 %.6f" % (cam.location.z, z0))
# reset 也要能归位
cam.data.lens = 85.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
cam.data.lens = 50.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc)
plock.reset_group(sc, cam)
chk("F1  reset 后相机也在原位", abs(cam.location.z - z0) < 1e-4,
    "z=%.6f 应为 %.6f" % (cam.location.z, z0))

# ═════════════ F7：重新生成投影组后 → 不假阳性 + driver 不翻倍 ═════════════
print()
print("=" * 68)
print("F7  重新生成投影组：无假阳性 + reset 不叠加 driver 变量")
sc = fresh()
cam = make_cam(sc, "CamF7", lens=85.0); sc.camera = cam
objs = make_pair(sc, "F7", cam, 2)
GNAME = "Camera Project | " + cam.data.name


def var_counts():
    nt = bpy.data.node_groups.get(GNAME)
    if nt is None or nt.animation_data is None:
        return []
    return [len(fc.driver.variables) for fc in (nt.animation_data.drivers or [])]


def lens_node():
    nt = bpy.data.node_groups.get(GNAME)
    for n in (nt.nodes if nt else []):
        if n.type == "VALUE" and n.label == "Lens":
            return n
    return None


native = var_counts()
plock.lock_group(sc, cam)
ng.ensure_camera_project_group(cam, default_aspect=1.0)     # 模拟面板「重新生成」
bpy.context.view_layer.update()
chk("F7-1 补丁节点被清后 is_patched 不再假阳性",
    not plock.is_patched(cam.data.name), "is_patched=%s" % plock.is_patched(cam.data.name))
plock.reset_group(sc, cam)
after = var_counts()
chk("F7-2 reset 后 driver 变量未叠加", after and max(after) <= max(native or [1]),
    "原生 %s → reset 后 %s" % (native, after))
n = lens_node()
if n:
    cam.data.lens = 170.0
    bpy.context.view_layer.update()
    chk("F7-3 组内 Lens 未被翻倍", abs(n.outputs["Value"].default_value - 170.0) < 1e-3,
        "实际 %.2f" % n.outputs["Value"].default_value)

# 反向：锁定态下再点「重新生成」→ 再次锁定时补丁要能自愈（冻结重新生效）
print()
sc = fresh()
cam = make_cam(sc, "CamF7b"); sc.camera = cam
objs = make_pair(sc, "F7b", cam, 2)
plock.lock_group(sc, cam)
ng.ensure_camera_project_group(cam, default_aspect=1.0)
bpy.context.view_layer.update()
plock.lock_group(sc, cam)                      # 再锁定 → 应重打补丁（自愈）
frozen_ok = plock.is_patched(cam.data.name)
cam.data.lens = 100.0
bpy.context.view_layer.update()
nt = bpy.data.node_groups.get("Camera Project | " + cam.data.name)
ln = None
for _n in nt.nodes:
    if _n.type == "VALUE" and _n.label == "Lens":
        ln = _n
chk("F7-4 重新生成后再次锁定：冻结自愈（lens 不跟随）",
    frozen_ok and ln is not None and abs(ln.outputs["Value"].default_value - 50.0) < 1e-3,
    "is_patched=%s Lens=%.2f" % (frozen_ok, ln.outputs["Value"].default_value if ln else -1))

# ═════════════ F2：一个相机状态损坏，不得让别的相机停摆 ═════════════
print()
print("=" * 68)
print("F2  单个相机记录损坏 → 其它相机仍正常适配")
sc = fresh()
camA = make_cam(sc, "CamA")
camB = make_cam(sc, "CamB")
sc.camera = camA
make_pair(sc, "A", camA, 2)
objsB = make_pair(sc, "B", camB, 2)
bpy.context.view_layer.update()
ra = plock.lock_group(sc, camA)
rb = plock.lock_group(sc, camB)
print("   锁 A:", ra["success"], "| 锁 B:", rb["success"])
groups = plock.load_groups(sc)
order = list(groups.keys())
print("   state 顺序:", order)
groups["CamA"].pop("locked_matrix", None)      # ★ 弄坏 A 的记录
plock.save_groups(sc, groups)
beforeB = snapshot(objsB[0])
camB.location.x += 1.0                          # 移动 B 的相机（B 应被重新适配）
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
d = maxdiff(beforeB, snapshot(objsB[0]))
chk("F2  A 记录损坏时 B 仍被适配（顶点有变化）", d > 1e-6,
    "B 顶点变化 %.6f （0 = 被 A 拖停）" % d)

# ═════════════ F3：重命名锁定网格后仍跟随 / reset 仍能还原 ═════════════
print()
print("=" * 68)
print("F3  重命名锁定网格 → 仍跟随相机 + reset 仍能还原几何")
sc = fresh()
cam = make_cam(sc, "CamF3"); sc.camera = cam
objs = make_pair(sc, "F3", cam, 2)
w0 = world_co(objs[0])
plock.lock_group(sc, cam)
tgt = objs[0]
tgt.name = "F3_RENAMED"                          # ★ 用户改名
bpy.context.view_layer.update()
b4 = snapshot(tgt)
cam.location.x += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
d = maxdiff(b4, snapshot(tgt))
chk("F3-1 改名后网格仍被适配（未脱离锁定）", d > 1e-6, "顶点变化 %.6f" % d)
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
w1 = world_co(tgt)
e = max(max(abs(a[i] - b[i]) for i in range(3)) for a, b in zip(w0, w1))
chk("F3-2 改名后 reset 仍能还原几何", e < 1e-4, "最大偏差 %.2e" % e)

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX_DONE")
