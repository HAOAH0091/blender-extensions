"""变焦场景：三种策略的误差对比
  1 不补（纯实时）
  2 全局单一 vector（方案 D）
  3 逐顶点（现状）
答案决定 D 的实际价值。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(shape):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 3
    verts, faces = [], []
    H = 10.0 if shape == "铺满" else 1.5
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -H + 2*H*ix/ns
            y = -H + 2*H*iy/ns
            z = 0.0
            if shape == "倾斜":
                z = 1.2 * x * 0.25
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def persp(cam, ob):
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


def run(shape, opname, mutate):
    sc, cam, cd, ob = build(shape)
    plock.lock_group(sc, cam)
    frozen = persp(cam, ob)
    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    live = persp(cam, ob)
    delta = frozen - live
    mean = delta.mean(axis=0)

    e_none = np.abs(live - frozen).max()
    e_global = np.abs(live + mean - frozen).max()
    e_vert = 0.0
    print("  %-6s %-10s 不补=%.5f  全局vector=%.5f  逐顶点=%.5f" % (
        shape, opname, e_none, e_global, e_vert))


print("=" * 88)
print("解锁时「让实时投影等于冻结图案」所需的最大 UV 误差")
print("=" * 88)
print("  %-6s %-10s %s" % ("网格", "操作", "三种策略的最大 UV 误差"))
for shape in ("小", "铺满", "倾斜"):
    run(shape, "平移x+2", lambda cam, cd: setattr(cam.location, "x", 2.0))
    run(shape, "变焦85", lambda cam, cd: setattr(cd, "lens", 85.0))
    run(shape, "旋转15°", lambda cam, cd: setattr(cam.rotation_euler, "z", math.radians(15)))
    print()
print("STRATEGY_DONE")
