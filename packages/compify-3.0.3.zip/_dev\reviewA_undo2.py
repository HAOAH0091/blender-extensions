"""审查 A-5（修正版）：撤销/重做的正确边界 —— 锁之后打点，撤销应回到「锁定中」状态
（上一版把点打在锁定之前，undo 回到锁定前是正确语义，不是 bug）
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock
L.report("A-5 撤销 / 重做：锁定中 Ctrl+Z（回到锁定态）")


def re():
    sc = bpy.context.scene
    cams = [o for o in bpy.data.objects if o.type == "CAMERA"]
    cam = cams[0] if cams else None
    if cam:
        sc.camera = cam
    A = bpy.data.objects.get("Grid0")
    return sc, cam, A


def frozen(ob, cam):
    a = ob.data.attributes.get(plock._campos_attr_name(cam.data.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([tuple(a.data[i].vector) for i in range(len(a.data))])


C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
orig = L.lverts(A).copy()
A.name = "Grid0"

r = plock.lock_group(sc, cam)
bpy.ops.ed.undo_push(message="locked")
cam.rotation_euler.y = 0.40
L.run_h(sc, times=2)
geo_rot = float(np.abs(L.lverts(A) - orig).max())
bpy.ops.ed.undo_push(message="rotated")
print("  锁定+旋转相机后：几何Δ=%.3f" % geo_rot)

bpy.ops.ed.undo()
sc, cam, A = re()
locked = plock.is_locked(sc, cam)
ge1 = float(np.abs(L.lverts(A) - orig).max())
nodes = plock._find_delta_nodes(cam.data.name)
print("  撤销到「锁定态」后：相机 rotY=%.3f 几何Δ=%.3f is_locked=%s campos=%s S=%s"
      % (cam.rotation_euler.y, ge1, locked, L.campos_ok(A, cam),
         float(nodes[0].inputs["Scale"].default_value) if nodes else None))
L.chk("撤销后仍处于锁定态", bool(locked), "is_locked=%s" % locked)
L.chk("撤销后几何随撤销一起回退", ge1 < 1e-6,
      "撤销前Δ=%.3f 撤销后Δ=%.3f" % (geo_rot, ge1))
L.chk("撤销后冻结坐标仍有效", L.campos_ok(A, cam), "campos=%s" % L.campos_ok(A, cam))

L.run_h(sc, times=2)
f0 = frozen(A, cam)
u_before = L.uvimg("un")
cam.rotation_euler.y = 0.55
L.run_h(sc, times=2)
f1 = frozen(A, cam)
d = float(np.abs(f1 - f0).max()) if (f0 is not None and f1 is not None) else -1.0
L.chk("撤销后锁定仍有效（旋转相机冻结坐标不变）", d >= 0 and d < 1e-6,
      "冻结坐标Δ=%.2e" % d)
r = plock.unlock_group(sc, cam)
u_after = L.uvimg("un")
L.chk("撤销后解锁仍不跳", L.uvd(u_after, u_before) < 2e-3,
      "Δ=%.6f msg=%s" % (L.uvd(u_after, u_before), r.get("message", "")[:28]))

print()
L.report("A-5b 解锁后反复 undo/redo 穿越：C+k 与锁定态会不会不同步")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
A.name = "Grid0"
plock.lock_group(sc, cam)
bpy.ops.ed.undo_push(message="locked")
cam.location.x += 0.8
L.run_h(sc, times=1)
bpy.ops.ed.undo_push(message="moved")
u_lock = L.uvimg("un")
plock.unlock_group(sc, cam)
bpy.ops.ed.undo_push(message="unlocked")
u_ul = L.uvimg("un")
S, Cc = L.node_sc(cam)
print("  解锁后：S=%.4f C=(%+.4f,%+.4f) 解锁瞬间Δ=%.6f"
      % (S, Cc[0], Cc[1], L.uvd(u_ul, u_lock)))
for i in range(3):
    bpy.ops.ed.undo()
    sc, cam, A = re()
    S, Cc = L.node_sc(cam)
    print("  第%d次撤销后：is_locked=%s S=%.4f C=(%+.4f,%+.4f) campos=%s"
          % (i + 1, plock.is_locked(sc, cam), S, Cc[0], Cc[1], L.campos_ok(A, cam)))
    L.run_h(sc, times=1)
    bpy.ops.ed.redo()
    sc, cam, A = re()
    S, Cc = L.node_sc(cam)
    print("       重做后：is_locked=%s S=%.4f C=(%+.4f,%+.4f) campos=%s"
          % (plock.is_locked(sc, cam), S, Cc[0], Cc[1], L.campos_ok(A, cam)))
u_end = L.uvimg("un")
L.info("末态画面与「解锁瞬间」的差=%.6f（应≈0：回到同一锁定态）" % L.uvd(u_end, u_ul))
L.summary()
