"""审查项 4：用户手动删掉 / 改名投影组里的关键节点，插件能否自愈？

三个阶段（每段 read_factory_settings 重来）：
  P1 删除冻结坐标 Attribute 节点（PATCH 记录仍在）
  P2 把该 Attribute 节点改名（名字变了，节点还在）
  P3 删除 S/C 里的 S 节点（C+k 链残废）
判据：图案是否还冻结 + UI 状态（lock_status）+ 解锁是否还报落实失败
"""
import bpy
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()


def scene1(tag):
    sc = C.reset()
    cam, cd = C.new_cam(sc)
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat, gn = C.probe_mat("Probe", grp)
    A = C.new_grid("A")
    A.data.materials.append(mat)
    C.uv_adjust_group(A, cd)
    bpy.context.view_layer.update()
    r = plock.lock_group(sc, cam)
    print("\n=== %s === 锁定: %s" % (tag, r["message"][:60]))
    return sc, cam, cd, grp, mat, A


def frozen_uv(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([(a.data[i].vector[0] / a.data[i].vector[2],
                      a.data[i].vector[1] / a.data[i].vector[2])
                     for i in range(len(a.data))])


def tell(sc, cam, cd, grp, A, tag):
    print("  is_patched=%s  lock_status=%s" % (
        plock.is_patched(cd.name), plock.lock_status(sc, cam)))
    print("  组内节点数=%d (Attribute 在场=%s, S 在场=%s, C 在场=%s)" % (
        len(grp.nodes), grp.nodes.get(plock.ATTR_NODE_NAME) is not None,
        grp.nodes.get("PLock Delta S") is not None,
        grp.nodes.get("PLock Delta C") is not None))
    fv = frozen_uv(A, cd)
    C.show(A)
    uv = C.render_uv(tag=tag)
    st = C.stats(uv)
    print("  冻结坐标=%s ; 渲染 UV x 极差=%.4f 均值=(%+.3f,%+.3f)" % (
        "有" if fv is not None else "无", st[0], st[2], st[3]))
    return (fv is not None), st


# ---------- P1 删掉 Attribute 节点 ----------
sc, cam, cd, grp, mat, A = scene1("P1 删 Attribute 节点")
fz0, st0 = tell(sc, cam, cd, grp, A, "P1a")
node = grp.nodes.get(plock.ATTR_NODE_NAME)
grp.nodes.remove(node)
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)      # 跑 3 帧，看自愈有没有动作
plock.parallax_lock_update_handler(sc)
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
fz1, st1 = tell(sc, cam, cd, grp, A, "P1b")
C.report("P1 删节点后自愈重打补丁", plock.is_patched(cd.name), "is_patched=%s" % plock.is_patched(cd.name))
C.report("P1 删节点后投影仍是图案", st1[0] > 0.10, "x 极差 %.4f→%.4f" % (st0[0], st1[0]))
r = plock.unlock_group(sc, cam)
print("  解锁消息：%s" % r["message"])

# ---------- P2 改名 Attribute 节点 ----------
sc, cam, cd, grp, mat, A = scene1("P2 改名 Attribute 节点")
node = grp.nodes.get(plock.ATTR_NODE_NAME)
node.name = "My Frozen Pos"         # 用户随手改名
print("  改名后 is_patched=%s" % plock.is_patched(cd.name))
cam.location.x += 2.0
bpy.context.view_layer.update()
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
fz2, st2 = tell(sc, cam, cd, grp, A, "P2b")
C.report("P2 改名后投影仍是图案", st2[0] > 0.10, "x 极差=%.4f" % st2[0])
r = plock.unlock_group(sc, cam)
print("  解锁消息：%s" % r["message"])
fz3, st3 = tell(sc, cam, cd, grp, A, "P2c")

# ---------- P3 删掉 S 节点 ----------
sc, cam, cd, grp, mat, A = scene1("P3 删 S 节点")
grp.nodes.remove(grp.nodes.get("PLock Delta S"))
print("  _find_delta_nodes=%s" % (plock._find_delta_nodes(cd.name),))
fz4, st4 = tell(sc, cam, cd, grp, A, "P3a")
cam.location.x += 2.0
bpy.context.view_layer.update()
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
fz5, st5 = tell(sc, cam, cd, grp, A, "P3b")
r = plock.unlock_group(sc, cam)
print("  解锁消息：%s" % r["message"])
nodes = plock._find_delta_nodes(cd.name)
print("  解锁后 S/C=%s" % (None if nodes is None else
                         (nodes[0].inputs["Scale"].default_value,
                          tuple(nodes[1].inputs[1].default_value)[:2])))
print("\nRD_DELNODE_DONE")
