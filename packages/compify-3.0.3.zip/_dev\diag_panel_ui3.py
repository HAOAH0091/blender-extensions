"""GUI 截图验证（第 3 版）

⚠️ 2026-10-20 后记：**这个脚本验证的「投影组修复按钮」功能已被用户撤销**
   （用户判断：用户不会进节点组内部删节点，那个场景可以忽略）。
   保留本文件是因为它记录的 **GUI 截图验证方法** 有独立价值——
   当时连踩 5 个坑才拍成，坑列在下面的注释和 README_诊断脚本.md 里。
   跑它现在会因为 plock.projection_group_damage 不存在而报错，属预期。

前两版失败原因（都记下来，别重复）：
  ① `--factory-startup` 起 GUI ⇒ splash 挡住窗口        → 改为带 .blend 启动
  ② N 侧栏停在 Tool 页，插件分类只是未激活的竖排标签；
     `region.active_panel_category` 在 5.2 **read-only** → 改用 `call_panel` 弹窗
  ③ 只建 UV Adjust 组、没挂进材质 ⇒ active_groups 空 ⇒「未找到投影材质」，
     整段视差 UI 不渲染                                    → 把组挂进材质
  ④ **弹窗被裁断**：call_panel 按「打开那一刻」的内容算高度，
     之后内容变多（多了警告行+按钮）不会重新变高 ⇒ 两张截图字节数完全相同
                                                          → 状态变化后**重新打开**弹窗
  ⑤ 截图可能拿到上一帧 ⇒ 每步连截两张，取第二张

本版做法：全屏 → 每步 关掉再开弹窗 → 连截两张。
"""
import bpy, sys, os, time

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, "_ui3_log.txt")
open(LOG, "w").close()


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(s + "\n"); f.flush()


def _bye(code=0):
    log("[bye]")
    try:
        sys.stdout.flush()
    except Exception:
        pass
    try:
        bpy.ops.wm.quit_blender()
    except Exception:
        pass
    import threading

    def _hard():
        time.sleep(0.5); os._exit(code)
    t = threading.Timer(0.0, _hard); t.daemon = True; t.start()


log("=== start ===")
ADDON = os.path.dirname(HERE)
PKG = "cmp_ui3"
import importlib.util
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(ADDON, "__init__.py"), submodule_search_locations=[ADDON])
m = importlib.util.module_from_spec(spec)
sys.modules[PKG] = m
spec.loader.exec_module(m)
m.register()
log("插件已注册")
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
names = sys.modules[PKG + ".names"]
NPC = "VIEW3D_PT_compify_uv_adjust"

sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 8)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
mesh = bpy.data.meshes.new("GridA")
mesh.from_pydata([(-2.5, -1, 0), (-0.5, -1, 0), (-0.5, 1, 0), (-2.5, 1, 0)],
                 [], [(0, 1, 2, 3)]); mesh.update()
A = bpy.data.objects.new("GridA", mesh)
sc.collection.objects.link(A)
A.data.materials.append(mat)
uvg = bpy.data.node_groups.new("UV Adjust | GridA | Cam", "ShaderNodeTree")
_uvn = nt.nodes.new("ShaderNodeGroup"); _uvn.node_tree = uvg; _uvn.name = "UV Adjust"
try:
    sc.compify_uv_adjust_camera = cam
except Exception as e:
    log("设 camera 失败:", e)
bpy.context.view_layer.update()
log("场景建好；damage =", plock.projection_group_damage(cd.name))


def shot2(tag):
    """连截两张，取第二张（防拿到上一帧）"""
    bpy.context.view_layer.update()
    p1 = os.path.join(HERE, "_tmp1.png")
    p2 = os.path.join(HERE, "_ui3_%s.png" % tag)
    try:
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=2)
        bpy.ops.screen.screenshot(filepath=p1)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=2)
        bpy.ops.screen.screenshot(filepath=p2)
        s1 = os.path.getsize(p1) if os.path.exists(p1) else -1
        s2 = os.path.getsize(p2) if os.path.exists(p2) else -1
        log("   截图 %s: 第一张 %d / 第二张 %d %s" % (
            tag, s1, s2, "（相同！可能没更新）" if s1 == s2 and s1 > 0 else ""))
        if os.path.exists(p1):
            os.remove(p1)
    except Exception as e:
        log("   截图失败:", e)


def reopen_panel():
    """关掉再重开弹窗 —— 让它按【当前】内容重新计算高度"""
    # 先尝试关闭（再调一次通常会 toggle；不行就 Escape 之类都不可用，只能靠重开）
    try:
        bpy.ops.wm.call_panel(name=NPC, keep_open=False)
    except Exception:
        pass
    bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=2)
    try:
        bpy.ops.wm.call_panel(name=NPC, keep_open=True)
        log("   弹窗已重新打开")
    except Exception as e:
        log("   重开弹窗失败:", e)


STEPS = []


def s1():
    log("--- s1: 全屏 + 打开弹窗（节点完好）---")
    try:
        bpy.ops.wm.window_fullscreen_toggle()
        log("   已切全屏")
    except Exception as e:
        log("   全屏失败:", e)
    reopen_panel()
    return 0.9


def s2():
    log("--- s2: 截图 A（应【无】修复按钮）---")
    shot2("ok")
    log("   damage =", plock.projection_group_damage(cd.name))
    return 0.6


def s3():
    log("--- s3: 删掉 PLock Delta S ---")
    ng = bpy.data.node_groups["Camera Project | " + cd.name]
    ng.nodes.remove(ng.nodes[names.PLOCK_S_NODE])
    log("   damage =", plock.projection_group_damage(cd.name))
    reopen_panel()
    return 0.9


def s4():
    log("--- s4: 截图 B（应【有】修复按钮）---")
    shot2("damaged")
    return 0.5


def s5():
    log("--- s5: 执行修复，再截图 C（按钮应消失）---")
    res = plock.repair_projection_group(sc, cam)
    log("   修复:", res.get("success"), res.get("repaired"))
    reopen_panel()
    return 0.9


def s6():
    log("--- s6: 截图 C ---")
    shot2("fixed")
    log("   damage =", plock.projection_group_damage(cd.name))
    return 0.3


def s7():
    _bye(0)
    return None


STEPS = [s1, s2, s3, s4, s5, s6, s7]


def tick():
    if not STEPS:
        _bye(0); return None
    fn = STEPS.pop(0)
    try:
        d = fn()
    except Exception as e:
        import traceback
        log("STEP ERROR:", e); log(traceback.format_exc()); d = 0.2
    return max(d or 0.2, 0.05)


bpy.app.timers.register(tick, first_interval=1.0, persistent=True)
log("timer 注册")
