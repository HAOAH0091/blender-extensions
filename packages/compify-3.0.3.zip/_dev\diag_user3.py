"""复现用户报的三个视差锁定问题（Blender headless，真实材质链路）
1: 另一网格换上同一投影材质 → 视差锁定不生效
2: 锁定状态下进编辑模式 → UV 坏掉
3: 锁定状态下拖动物体 → 不跟手、容易飞
"""
import bpy, sys, os, math, mathutils
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_diag"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]

print("Blender", bpy.app.version_string)

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
cam_data = bpy.data.cameras.new("TestCam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("TestCamera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, 0.0, 5.0)
cam.rotation_euler = (0.0, 0.0, 0.0)
bpy.context.view_layer.update()

def make_grid(name, z, x, w=1.0, nseg=4):
    mesh = bpy.data.meshes.new(name)
    verts, faces = [], []
    for iy in range(nseg + 1):
        for ix in range(nseg + 1):
            verts.append((x - w + 2*w*ix/nseg, -1 + 2*iy/nseg, z))
    for iy in range(nseg):
        for ix in range(nseg):
            a = iy*(nseg+1)+ix
            faces.append((a, a+1, a+nseg+2, a+nseg+1))
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(obj)
    return obj

def make_proj_material(name):
    """带 Camera Project 组节点的材质（模拟 compify 投影材质）"""
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    grp = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cam_data.name)
    if grp is None:
        grp = NG.ensure_camera_project_group(cam)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs[0], out.inputs[0])
    return m

NG.ensure_camera_project_group(cam)
mat_proj = make_proj_material("ProjMat")

objA = make_grid("GridA", 0.0, 0.0)
objB = make_grid("GridB", -2.0, 0.6, w=0.8)
objA.data.materials.append(mat_proj)

# A 有 UV Adjust 组（用户对它用过投影UV调整）
NG.create_uv_adjust_node_group(scene, cam, objA)

print("\n" + "="*72)
print("【问题1】B 手动换上同一投影材质")
objB.data.materials.append(mat_proj)
print("  B 材质 =", [m.name for m in objB.data.materials])
print("  get_lock_targets     ->", [o.name for o in PL.get_lock_targets(scene, cam)])
print("  objects_using_projection ->", [o.name for o in PL.objects_using_projection(cam_data.name)])

res = PL.lock_group(scene, cam)
print("  lock_group:", res.get("message"))
print("  locked ->", [o.name for o in res.get("locked", [])])
print("  >>> B 在 locked 里:", objB in res.get("locked", []))
print("  >>> B 有 OBJ_CAM_KEY:", objB.get(PL.OBJ_CAM_KEY))
print("  >>> B 有 base 属性:", objB.data.attributes.get(PL.BASE_ATTR) is not None)
print("  >>> B 有 campos 属性:", PL._campos_is_valid(objB, cam_data.name))

bA = [tuple(v.co) for v in objA.data.vertices]
bB = [tuple(v.co) for v in objB.data.vertices]
cam.location = (2.0, 0.0, 5.0)
bpy.context.view_layer.update()
for _ in range(2):
    PL.parallax_lock_update_handler(scene)
aA = [tuple(v.co) for v in objA.data.vertices]
aB = [tuple(v.co) for v in objB.data.vertices]
mA = max(abs(p[i]-q[i]) for p,q in zip(bA,aA) for i in range(3))
mB = max(abs(p[i]-q[i]) for p,q in zip(bB,aB) for i in range(3))
print("  移相机后 A 顶点变化 %.6f (%s)" % (mA, "跟了" if mA>1e-6 else "没跟"))
print("  移相机后 B 顶点变化 %.6f (%s)  <== 问题1" % (mB, "跟了" if mB>1e-6 else "没跟=bug成立"))

# ── 问题2：进入编辑模式 ──
print("\n" + "="*72)
print("【问题2】锁定状态下进入编辑模式")
cam.location = (0.0, 0.0, 5.0)
bpy.context.view_layer.update()
PL.lock_group(scene, cam)

campos_name = PL._campos_attr_name(cam_data.name)
def snapshot(o):
    a = o.data.attributes.get(campos_name)
    base = o.data.attributes.get(PL.BASE_ATTR)
    return {
        "campos": [tuple(a.data[i].vector) for i in range(len(a.data))] if a else None,
        "base":   [tuple(base.data[i].vector) for i in range(len(base.data))] if base else None,
        "cov":    [tuple(v.co) for v in o.data.vertices],
        "n_attr": len(o.data.attributes),
        "attrs":  [x.name for x in o.data.attributes],
    }

snapA0 = snapshot(objA)
print("  锁定后 A: campos 存在=%s base 存在=%s 属性数=%d" %
      (snapA0["campos"] is not None, snapA0["base"] is not None, snapA0["n_attr"]))

bpy.context.view_layer.objects.active = objA
objA.select_set(True)
try:
    bpy.ops.object.mode_set(mode='EDIT')
    print("  已进入编辑模式, objA.mode =", objA.mode)
except Exception as e:
    print("  进编辑模式失败:", e)

# 编辑模式下 Blender 会触发 depsgraph → handler
for _ in range(3):
    bpy.context.view_layer.update()
    PL.parallax_lock_update_handler(scene)

snapA1 = snapshot(objA)
print("  编辑模式下 A: campos 存在=%s base 存在=%s 属性数=%d" %
      (snapA1["campos"] is not None, snapA1["base"] is not None, snapA1["n_attr"]))
if snapA0["campos"] and snapA1["campos"]:
    d = max(abs(p[i]-q[i]) for p,q in zip(snapA0["campos"], snapA1["campos"]) for i in range(3))
    print("  >>> campos 最大变化: %.6f  (%s)" % (d, "被改坏=问题2成立" if d>1e-6 else "未变"))
if set(snapA0["attrs"]) != set(snapA1["attrs"]):
    print("  >>> 属性列表变了! 之前:", snapA0["attrs"])
    print("                      之后:", snapA1["attrs"])

# 编辑模式下移动一个顶点再退出
try:
    import bmesh
    bm = bmesh.from_edit_mesh(objA.data)
    print("  编辑模式 BMesh 顶点数:", len(bm.verts))
    if len(bm.verts):
        bm.verts[0].co.x += 0.3
    bmesh.update_edit_mesh(objA.data)
    print("  已在编辑模式移动 1 个顶点 (+0.3 x)")
except Exception as e:
    print("  bmesh 操作失败:", e)

for _ in range(2):
    bpy.context.view_layer.update()
    PL.parallax_lock_update_handler(scene)

try:
    bpy.ops.object.mode_set(mode='OBJECT')
    print("  已退出编辑模式, mode =", objA.mode)
except Exception as e:
    print("  退出失败:", e)

snapA2 = snapshot(objA)
print("  退出后 A: campos 存在=%s base 存在=%s 属性数=%d" %
      (snapA2["campos"] is not None, snapA2["base"] is not None, snapA2["n_attr"]))
if snapA0["campos"] and snapA2["campos"]:
    d = max(abs(p[i]-q[i]) for p,q in zip(snapA0["campos"], snapA2["campos"]) for i in range(3))
    print("  >>> 退出后 campos 相对锁定时的最大变化: %.6f (%s)" %
          (d, "被改坏=问题2成立" if d>1e-6 else "未变"))
if snapA0["base"] and snapA2["base"]:
    d = max(abs(p[i]-q[i]) for p,q in zip(snapA0["base"], snapA2["base"]) for i in range(3))
    print("  >>> base 相对锁定时的最大变化: %.6f" % d)

# ── 问题3：拖动物体 ──
print("\n" + "="*72)
print("【问题3】锁定状态下拖动物体（模拟每帧鼠标小幅移动）")
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
cam_data = bpy.data.cameras.new("TestCam2")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("TestCamera2", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, 0.0, 5.0)
cam.rotation_euler = (0.0, 0.0, 0.0)
bpy.context.view_layer.update()
objA = make_grid("GridA", 0.0, 0.0)
mat_proj2 = make_proj_material("ProjMat2")
objA.data.materials.append(mat_proj2)
NG.create_uv_adjust_node_group(scene, cam, objA)
r = PL.lock_group(scene, cam)
print("  lock:", r.get("message"))

M0 = objA.matrix_world.copy()
print("  锁定后 drag =", objA.get(PL.DRAG_SCALE_KEY))
print("\n  模拟用户沿相机视线拖动（每帧 +0.05 世界单位，共 10 帧）：")
print("   帧   用户拖到的Z     drag(累乘)   期望drag(绝对)   drag/期望")
prev_d = None
_, st, _ = PL._resolve_state(scene, cam)
ref_depth = st.get("ref_depth", 5.0)
c_local = PL._mesh_center_local(objA)
view = PL.get_camera_view_matrix(cam)
for f in range(10):
    # 用户把物体往相机方向拖（+z 靠近相机 → 深度变小）
    dz = 0.05 * (f + 1)
    M_cur = M0.copy()
    M_cur.translation.z = M0.translation.z + dz
    objA.matrix_world = M_cur
    bpy.context.view_layer.update()
    view_now = PL.get_camera_view_matrix(cam)
    d0 = PL._view_depth(view.inverted(), M0 @ c_local)
    dc = PL._view_depth(view_now.inverted(), M_cur @ c_local)
    expect = dc / d0 if d0 > 0 else 1.0
    PL.apply_user_move(objA, cam, view_now)
    drag = objA.get(PL.DRAG_SCALE_KEY)
    print("   %2d   %+8.3f     %10.6f   %12.6f   %8.3f   %s" %
          (f+1, dz, drag, expect, drag/expect if expect else 0,
           "<== 偏离" if expect and abs(drag/expect-1) > 0.05 else ""))
