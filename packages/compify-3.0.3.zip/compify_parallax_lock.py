"""
Compify 网格视差锁定（Grid Parallax Lock）

相机移动时：
  ① 网格逐顶点变形，适配视锥体（保持构图）—— 用户已确认想要的"网格变形"
  ② 投影 UV 冻结在锁定那一刻 —— 图案死死长在网格表面：不滑动、不变形

② 的机制（关键）：
  compify 的 Camera Project 组数学是 `UV = Affine(相机空间坐标)`，
  第一个节点是 `TexCoord(object=相机)` → 输出"顶点在相机空间的坐标"。
  ⇒ 把【锁定那一刻的相机空间坐标】冻成顶点属性、喂给投影组，
    投影算出来就【永远】等于锁定时的 UV ⇒ 图案完美跟随网格变形。

  （对比：把 TexCoord 的 object 换成"冻结的相机物体"= 只冻结了投影源，
    网格一变形，坐标照样变 → 图案还会滑（残差约 0.0094）——不彻底。）

存储：
  · mesh attribute "compify_plock_base"     FLOAT_VECTOR  — 变形用（相机空间坐标，剥离相机 scale）
  · mesh attribute "compify_plock_campos"   FLOAT_VECTOR  — 图案冻结用（相机空间坐标，含 scale，与 TexCoord 语义一致）
  · scene["compify_plock_groups"]           JSON          — 每相机的锁定状态
  · obj["compify_plock_camera"]             str           — 该 obj 被哪个相机锁定（互斥）
  · Camera Project 组的自定义属性 "compify_plock_patch"    — 组内补丁的还原记录
"""

import bpy
import hashlib
import json
import math
import uuid

# numpy 是 Blender 自带的（用于把逐顶点循环向量化，见 adapt_object）。
# 万一某个环境没有，也不影响功能 —— 会回退到纯 Python 路径。
try:
    import numpy as _np
except Exception:                                    # pragma: no cover
    _np = None
import mathutils
from bpy.app.handlers import persistent

try:
    from .names import (PLOCK_S_NODE, PLOCK_C_NODE, UV_DELTA_ATTR_LEGACY,
                        PLOCK_DELTA_VERSION, PLOCK_DELTA_VERSION_KEY)
except ImportError:      # 被脚本以「裸模块」方式 import（_dev 下的独立测试）
    from names import (PLOCK_S_NODE, PLOCK_C_NODE, UV_DELTA_ATTR_LEGACY,
                       PLOCK_DELTA_VERSION, PLOCK_DELTA_VERSION_KEY)

MIN_DEPTH = 1e-4
CAMERA_CHANGE_THRESHOLD = 1e-4
SCROLL_SCALE = 1.0

# 变焦时"优先移动相机"：
#   True  = 变焦时自动沿视线推拉相机（相机真的会动），网格只补偿剩余部分
#   False = 相机不动，全靠网格变形（旧行为）
# 两种模式下「构图冻结」都成立；差别只在【相机是否物理移动】。
CAMERA_DOLLY_ZOOM = True

# 用户拖动锁定网格 → 按「视差语义」重新锚定（对齐 PSD 拖图层的语义）：
#   · 屏幕坐标保持不变（网格钉在画面原位，横向拖动被拉回）
#   · 深度取用户拖出来的那个 → 改变该网格的视差滚动（= 调"间距"）
#   · 同步缩放，保持画面里的尺寸不变
#   · 新状态【写回基准】—— 否则之后一动相机网格又弹回（PSD v3.12.5 修过的坑）
LAYER_MOVE_ENABLED = True
MATRIX_KEY = "compify_plock_last_matrix"   # 每 mesh：上次"正确位姿"（世界矩阵 16 个 float）
MOVE_THRESHOLD = 1e-6
# 拖动累积的「相机空间缩放」。用**标量**记录，而不是把 base 顶点属性逐个 ×k ——
# 拖动时每帧都会跑到这里，遍历几十万顶点会卡死（用户实测很卡）。
DRAG_SCALE_KEY = "compify_plock_drag_scale"
# ★ 拖动造成的【深度平移量】（相机空间，标量，单位=米）。
#
#   ★★ 语义三层演进（务必读完再看代码，中间那层已经废弃）：
#
#     第 0 层（-v2.7.x）：所有顶点乘同一个 `DRAG_SCALE_KEY` 比例 drag。
#       平面图层等价，立体网格上深度跨度被改变（拉厚 14.35% / 压扁 12%）。
#
#     第 1 层（2026-10-19）：改成「深度统一平移」dd = d_i + offset，
#       每个顶点再按自己的 k_i = dd/d_i 补偿 x/y。跨度不变、形心精确。
#       ❌ 但 2026-10-20 发现它会让**贴图被压歪**：各顶点缩放比不同 ⇒
#          透视插值权重比改变 ⇒ 插出的 UV 偏了（实测用户工程 0.0054）。
#
#     第 2 层（2026-10-20，当前）：offset 仍然记「用户拖了多远（米）」，
#       但 adapt_object 先把它换算成**统一缩放比 s**：
#           s = (mean_d + offset) / mean_d      （见 _depth_ratio）
#           dd = d_i * s                        （所有顶点同比例）
#       这样透视插值权重比恒定 ⇒ **贴图零变形**（实测 3e-8），
#       屏幕坐标依然严格不变（x·s / z·s = x/z）。
#       ⇒ 与「相机推拉」变成同一种数学操作，插件里只剩一种改深度的方式。
#
#   ⚠️ 与 `DRAG_SCALE_KEY` 的分工：
#     · DRAG_OFFSET_KEY = 用户拖动（米制平移量，adapt 时换算成 s）
#     · DRAG_SCALE_KEY  = 旧资产兼容（比例语义），读到时按 ref_depth 近似折算成 offset
DRAG_OFFSET_KEY = "compify_plock_drag_offset"
# ★ 「待清拖动量」标记（短命，只活一帧）。
#
#   为什么需要它（独立审查 2026-10-20 🔴）：用户 G 后右键取消时，Blender 只还原
#   matrix_world，不会通知插件。插件原本靠「位姿 == M_prev」判断，但那个判据是
#   **多义**的 —— 插件自己撞墙、相机飞越图层、父级带回位姿都会造出同样的状态，
#   于是「清残值」会误杀合法调整（实测：撞墙后手一停，用户推了 4 米的深度整段归零）。
#
#   现在改成：apply_user_move 发现「位姿回到锁定位姿 **且** 本帧之前位姿确实在动」
#   时，只往对象上打这个标记；真正清零推迟到 handler 里 adapt_object 成功之后。
#   ⇒ 清账与几何重算原子化：适配失败就不清，下一帧再试（修改器删掉后能自愈）。
PENDING_ZERO_KEY = "compify_plock_pending_zero"
# ★ 「刚重锚过」的短命标记（一帧）。重锚（相机飞越图层）会让 M_prev == M_cur，
#   和「用户右键取消」撞成同一个状态；用它区分，避免把用户的深度调整当残值清掉。
REANCHOR_KEY = "compify_plock_reanchor"
# ★ 相机上累计的「插件已施加、尚未归还」的变焦 dolly 位移（世界空间）。
#   与 state["applied_dolly"] 不同：它**跟着相机走、跨 锁定/解锁/再锁定 存活**，
#   否则「锁定→变焦→解锁→再锁定→重置」会丢掉相机原位（独立审查 第三轮 F2）。
CAM_DOLLY_KEY = "compify_plock_cam_dolly"
# ★ 相机数据块上的持久唯一 id —— 用来在**相机数据改名**后仍能找回锁定记录
#   （state 的 key / 补丁组名 / 冻结属性名都是按相机数据名生成的，改名即失联）。
CAM_UID_KEY = "compify_plock_uid"
# 网格局部形心缓存：局部形心只随顶点变化、不随物体位姿变化，
# 避免每次拖动都遍历顶点求形心。
CENTER_KEY = "compify_plock_center"
# ★ 【原始】局部形心 —— 在**首次锁定时**记录一次，**永不因顶点变形而失效**。
#
#   为什么必须单独存一份（用户实测反馈「推到相机前一定距离就推不动了」）：
#     `CENTER_KEY` 缓存的「当前顶点形心」会被 `adapt_object` 污染 ——
#     它把顶点改写成**变形后**的局部坐标，于是形心从 (0,0,0) 变成 (0,0,2.0)…
#     `apply_user_move` 用 `M_cur @ c_local` 算「用户拖到哪儿」，形心一污染，
#     深度就变成 拖位 + 变形量（越来越"深"），最后 `d_cur` 翻负、撞上
#     `d_cur <= MIN_DEPTH` 的保护性拉回 ⇒ 拖动被"锁死"在相机前某个距离。
#     实测（相机在 z=5、网格在 z=0 面朝相机）：
#        推近 2.0 → c_local=(0,0,0.0)   深度 3.0  正常
#        推近 2.5 → c_local=(0,0,2.0)   深度 0.5  已污染
#        推近 2.6 → c_local=(0,0,2.5)   深度 −0.1 触发拉回，再也推不动
#     用原始形心后：推近 2.6 → 深度 2.4 → offset −2.6，可以一直推到贴着相机。
#
#   ⚠️ 与 CENTER_KEY 的分工：CENTER_KEY 用于"当前几何"的快速查询（可失效重算），
#     ORIG_CENTER_KEY 专门用来把**位姿**换算成深度（位姿 ≠ 顶点几何）。
ORIG_CENTER_KEY = "compify_plock_orig_center"

BASE_ATTR = "compify_plock_base"
# ★ 【首次锁定前】的原始顶点（**局部坐标**副本）——「重置」的最终依据。
#   ⚠️ 为什么不能只靠 BASE_ATTR（独立审查 第五轮 🔴-1）：
#     BASE_ATTR 是「本次锁定链路的相机空间基准」，`lock_group` 会按**当前形状**重取。
#     于是「锁定 → 移相机（网格被适配变形）→ 解锁 → 再锁定」时，
#     base 被换成"适配后的形状" ⇒ 之后 reset 只能回到**适配后的形状**，
#     **原始形状永久丢失，且 UI 无任何途径找回**（唯一会不可逆损坏用户资产的一条）。
#   本属性只在【首次锁定】时写（已存在就不动），与锁定链路解耦 —— reset 用它还原。
ORIG_ATTR = "compify_plock_orig"
# ★ 解锁那一刻的几何签名（6 个 float）—— 用来判断用户**在解锁之后**是否编辑过网格。
#   ⚠️ 为什么要它（独立审查 第六轮 🔴-2）：解锁的语义是「停止跟随、不回退，
#     网格停在当前位置」—— 用户在解锁后完全可能继续自由编辑；
#     此时面板**仍显示 ↺**（因为还有锁定记录）。一点「重置」就会把
#     `matrix_world` 写回锁定基准、把顶点覆盖成 ORIG_ATTR ⇒
#     **用户解锁后的位移与编辑被静默抹掉**，而消息只有一句"已重置 N 个网格"。
UNLOCK_SIG_KEY = "compify_plock_unlock_sig"


def _geom_sig(obj):
    """几何签名：顶点数 + 坐标和 + 平方和（6 个 float）。

    ⚠️ 不用全量顶点副本（那会为每个网格多存一份几 MB 的属性）；
       平方和能捕捉到任何顶点的移动（对称位移也会改变平方和）。
    """
    try:
        n = len(obj.data.vertices)
        if n == 0:
            return None
        buf = [0.0] * (n * 3)
        obj.data.vertices.foreach_get("co", buf)
        if _np is not None:
            a = _np.asarray(buf, dtype=_np.float64).reshape(-1, 3)
            s = a.sum(axis=0)
            q = (a * a).sum()
            return [float(n), float(s[0]), float(s[1]), float(s[2]), float(q)]
        sx = sy = sz = q = 0.0
        for i in range(0, n * 3, 3):
            x, y, z = buf[i], buf[i + 1], buf[i + 2]
            sx += x; sy += y; sz += z; q += x * x + y * y + z * z
        return [float(n), sx, sy, sz, q]
    except Exception:
        return None


def _sig_differs(a, b, eps=1e-4):
    if not a or not b or len(a) != len(b):
        return False
    return any(abs(x - y) > eps for x, y in zip(a, b))
CAMPOS_ATTR = "compify_plock_campos"
GROUPS_KEY = "compify_plock_groups"
OBJ_CAM_KEY = "compify_plock_camera"
# 冻结坐标属性是「按物体一份」的，所以必须记录它归哪个相机写。
# 否则重置相机 A 时会把相机 B 的冻结坐标一起删掉（B 的补丁还在 → 读到空属性 → 投影损坏）。
CAMPOS_OWNER_KEY = "compify_plock_campos_owner"
# ★ 写入冻结坐标时的**顶点数**。
#
#   为什么需要它（用户实测踩到，2026-10-20）：
#   `_campos_is_valid` 原来只比较「属性长度 == 顶点数」。但 **Blender 应用修改器时
#   会把属性一起扩展**到新的顶点数 —— 16 个顶点的网格应用细分后变 49 个，
#   campos 长度也随之变成 49，长度校验"通过"，于是一份**部分错误**的坐标
#   （实测 49 个顶点里 16 个错，最大差 0.164）被当成有效数据保留下来，
#   图案就会错。这正是"应用修改器后图案仍不对"的原因。
#   记录写入时的顶点数即可识别「几何被重建过」：
#     · 应用修改器（细分/布尔/增删顶点）→ 顶点数变 → 判定无效 → 重写 ✓
#     · 锁定期间拖动网格 → 顶点数不变 → 不重写 ✓（图案必须继续粘住网格）
CAMPOS_VCOUNT_KEY = "compify_plock_campos_vcount"


def _campos_attr_name(cam_data_name):
    """冻结坐标属性名 —— **按相机区分**。

    ⚠️ 为什么不能共用一个名字（独立审查 N1）：
    CAMPOS 是"每 mesh 一份"的属性，而一块 mesh 可能同时被【多个相机】投影
    （材质里引用了两个相机的 Camera Project 组）。若共用一个属性名，后锁的相机
    会直接覆盖前一个的冻结坐标 —— 而前一个相机的锁定状态/补丁都没变，
    于是它在同一块 mesh 上的投影会【静默读错坐标】（UI 还显示已锁定，用户看不出）。
    按相机分名字后，每个相机读写自己那一份，互不干扰。

    ⚠️ 后缀不能用「相机名归一化 + 截断」（独立审查 R2）—— 那样会碰撞：
       · `Cam.001` 与 `Cam-001` 归一化后都是 `Cam_001`
       · 超过 24 字符的名字被截断后，前缀相同的两个相机也会撞
       碰撞的后果正是上面 N1 要修的病「后锁的相机覆盖前一个的冻结坐标」，
       只是换了条路径，而且**两个相机都以为自己是好的**（静默错位）。
       Blender 复制数据块默认就产生 `.001` 后缀 —— 这条路径很常见。
       改用**内容哈希**，碰撞概率可忽略；可读性由 `CAMPOS_OWNER_KEY` 保留。
    """
    h = hashlib.sha1((cam_data_name or "cam").encode("utf-8")).hexdigest()[:12]
    return "%s__%s" % (CAMPOS_ATTR, h)
PATCH_KEY = "compify_plock_patch"
ATTR_NODE_NAME = "compify_plock_attr"
UV_ADJUST_PREFIX = "UV Adjust | "
CAM_PROJECT_PREFIX = "Camera Project | "

# 投影组里被 driver 绑到相机数据、会随变焦/移轴变化的 Value 节点
# （节点 label → camera.data 上的对应属性名）—— 锁定后必须一起冻结，
#  否则变焦时投影 UV 仍会变（lens 卡在 zoom_1 = lens/sensor_width 这一步）。
FROZEN_VALUE_LABELS = {
    "Lens": "lens",
    "Sensor Width": "sensor_width",
    "Lens Shift X": "shift_x",
    "Lens Shift Y": "shift_y",
}

_last_view = {}
_base_cache = {}


# ──────────────────────────── 基础工具 ────────────────────────────

def get_camera_view_matrix(camera):
    """相机视图矩阵：只含位置 + 朝向，剥离对象 scale（相机 scale 不参与渲染，但会污染 matrix_world）。"""
    loc, rot, _scale = camera.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def cam_uid(camera):
    """相机【数据块】上的持久唯一 id（改名、存盘都不变）。

    ⚠️ 为什么要它（独立审查 第三轮 F4）：state 的 key、补丁组名、冻结属性名
       全都按**相机数据块名**生成。用户改了数据块名（Blender「重命名对象与数据」
       是常见操作）之后，三样东西全挂在旧名下，而面板/handler 按新名去找
       ⇒ 面板显示"未锁定"、重置按钮消失、锁定静默失效，
       而网格仍带着 `BASE_ATTR`（**没有任何 UI 途径还原**）。
       问题不在改名本身，而在我们**把名字当成了身份**。
    """
    d = getattr(camera, "data", None)
    if d is None:
        return ""
    try:
        uid = d.get(CAM_UID_KEY)
        if not uid:
            uid = uuid.uuid4().hex[:12]
            d[CAM_UID_KEY] = uid
        return uid
    except Exception:
        return ""


def find_camera(scene, cam_data_name, uid=None):
    """按相机数据块名找；找不到（或给了 uid）时用 UID 兜底。"""
    for o in scene.objects:
        if o.type == "CAMERA" and o.data and o.data.name == cam_data_name:
            return o
    if uid:
        for o in scene.objects:
            if o.type == "CAMERA" and o.data and cam_uid(o) == uid:
                return o
    return None


def get_lock_targets(scene, camera):
    """该相机下所有「带投射 UV」的 mesh 对象 —— 两个检索源的**并集**。

    ① UV Adjust 组名反查：`UV Adjust | <mesh_data> | <cam_data>`（主路径）
    ② 材质里引用了该相机 Camera Project 组的 mesh

    ⚠️ ② 补的是一个真实的半生效窗口（用户实测反馈）：用户对网格 A 用过「投影 UV
       调整」后，又**手工**把网格 B 的材质换成同一投影材质。B 没有 UV Adjust 组，
       于是 ① 找不到它 ⇒ B 的**图案冻结生效了**（`_selfheal_and_backfill` 走
       ② 覆盖了它），**几何适配却完全没做** —— 表现是「打开视差锁定对 B 不生效」，
       而且画面上看不出来（B 的图案确实不再随相机滑动），一动相机才暴露。
       锁定目标与图案冻结必须用同一个集合，否则必然出现这种只做一半的状态。

    ⚠️ ② 必须过滤到 `scene.objects`：`objects_using_projection` 扫的是全局
       `bpy.data.objects`（Camera Project 组是全局 datablock），不过滤会把
       **别的场景**里的网格拉进本次锁定的 `targets`。
    """
    if camera is None or camera.data is None:
        return []
    cam_data_name = camera.data.name
    suffix = " | " + cam_data_name
    obj_data_names = set()
    for ng in bpy.data.node_groups:
        if ng.name.startswith(UV_ADJUST_PREFIX) and ng.name.endswith(suffix):
            mid = ng.name[len(UV_ADJUST_PREFIX):len(ng.name) - len(suffix)]
            if mid:
                obj_data_names.add(mid)
    out = []
    seen = set()
    for o in scene.objects:
        if o.type == "MESH" and o.data and o.data.name in obj_data_names:
            out.append(o)
            seen.add(o.as_pointer())

    # ② 手工接投影材质的网格（没有 UV Adjust 组，但确实在用本相机的投影）
    #
    # ⚠️ 必须排除「已经挂着任何 UV Adjust 组」的对象（实测踩过）：
    #    这类对象**归属是明确的**（它的组名指向某个相机）。若把它也算进本相机的
    #    目标，`lock_group` 的「多相机互斥」会把网格从原相机**抢走** ——
    #    `test_n1_two_cameras_one_mesh.py` 当场抓到：一个网格同时挂着 A 的
    #    UV Adjust 组、材质又引用了 B 的投影组，锁 B 时它被从 A 迁移到 B，
    #    导致 A 那份冻结坐标失效（3 项 FAIL）。
    #    用户报的场景是反过来的：B **完全没有** UV Adjust 组，只换了材质。
    try:
        # 收集所有「已归属某相机」的网格数据名（任意相机）
        owned = set()
        for ng in bpy.data.node_groups:
            if not ng.name.startswith(UV_ADJUST_PREFIX):
                continue
            rest = ng.name[len(UV_ADJUST_PREFIX):]
            if " | " in rest:
                mid = rest.rsplit(" | ", 1)[0]
                if mid:
                    owned.add(mid)
        scene_ptrs = None
        for o in objects_using_projection(cam_data_name):
            if o is None or o.type != "MESH" or o.data is None:
                continue
            ptr = o.as_pointer()
            if ptr in seen:
                continue
            if o.data.name in owned:       # 已归属某相机 ⇒ 不在这里抢
                continue
            if scene_ptrs is None:
                scene_ptrs = {x.as_pointer() for x in scene.objects}
            if ptr not in scene_ptrs:      # 别的场景的对象，不能锁
                continue
            out.append(o)
            seen.add(ptr)
    except Exception:
        # 扫描失败不影响主路径（① 已经能用）；宁可少锁也不要整个锁定失败
        pass
    return out


# ★ `objects_using_projection` 的缓存（独立审查 第七轮 🟡 F-4）：
#   ⚠️ 该函数是 O(全库对象 × 材质嵌套节点树)，而 `_selfheal_and_backfill` 每次
#      handler 都要调它 ⇒ 静止时也每帧全扫（实测 123 对象 0.163 ms/次，
#      5 相机 0.401 ms/次，随相机数线性增长）。
#   ⚠️ 我在 v2.7.7 的 CHANGELOG 里写过"加了数量签名缓存"，但**代码里其实没有**
#      （`_proj_cache` 只出现在注释里）—— 那个声明是错的，这里补上实现。
#   失效判据用「结构签名」：对象数 / 材质数 / 节点组数 / 材质槽总数。
#   覆盖了最常见的结构变化（新增对象、新增材质、给对象加材质槽、增删节点组）。
    #   ⚠️ 签名里必须含「材质节点总数」（见 `_proj_signature`）——
    #   否则"给已有对象手工接入投影"这条真实路径不会触发失效，而且原注释写的
    #   "动一下相机即可"是**错的**（缓存按签名判，与相机是否移动无关）。
    #   剩余边界：只改**连线**（不增删节点）仍不失效；那种情况下点一次锁定即会重扫。
_proj_cache = {}
# 每 N 次 backfill 做一次**无缓存真值扫描**（见 _selfheal_and_backfill 的说明）：
# 缓存的作用是省掉"每帧"的开销，但不能成为"该补的永远补不上"的理由。
_BACKFILL_FULL_EVERY = 6
_backfill_tick = [0]
_backfill_warned = set()   # 已提示过「无法参与冻结」的对象名（防刷屏）

# ══════════════════════════════════════════════════════════════════════
# 「无法冻结」网格的弹窗提示
#
# 用户 2026-10-20：锁定期间给新网格赋投影材质时，带修改器 / 带形态键 /
# 共享网格这三类**无法参与图案冻结**（修改器改变顶点域，逐 mesh 的冻结坐标
# 与渲染顶点对不上）⇒ 图案会显示成纯色。这三类需要弹窗告知用户。
# 普通网格能正常冻结，**不弹窗**，静默补写即可。
#
# ⚠️⚠️ 三条硬约束（都是实测踩出来的）：
#  ① **绝不能在 handler 里直接弹窗** —— handler 每帧跑，会刷屏并阻塞。
#     改为「handler 里只登记，timer 回调里再弹」。
#  ② **headless 下绝不能碰弹窗 API** —— 实测 `wm.popup_menu` 在
#     `bpy.app.background=True` 时直接 EXCEPTION_ACCESS_VIOLATION 崩溃。
#     ⚠️ 尤其注意：不能用「bpy.context.window is None」做守卫 ——
#     headless 下 window **并不为 None**（wm.windows 还有 1 个），那个判据会漏。
#     唯一可靠判据是 `bpy.app.background`。
#  ③ 同一对象只提示一次（`_popup_shown`）；若它后来变成可冻结（用户应用了
#     修改器）则把记录清掉，这样以后再次出问题还会提示。
# ══════════════════════════════════════════════════════════════════════
_popup_queue = []          # [(obj_name, reason)]  待弹
_popup_shown = set()       # 已弹过窗的对象名
_popup_timer_on = [False]


def _popup_supported():
    """当前环境能否安全弹窗。唯一可靠判据是 `bpy.app.background`。"""
    return (not bpy.app.background) and hasattr(bpy.app, "timers")


def _queue_unfreezable_popup(obj_name, reasons):
    """登记「该网格无法冻结」提示；真的弹窗交给 timer。

    reasons 可以是单个字符串或字符串列表（一个网格可能同时有多个原因）。
    """
    if isinstance(reasons, str):
        reasons = [reasons]
    if obj_name in _popup_shown:
        return
    for _n, _rs in _popup_queue:
        if _n == obj_name:
            for _r in reasons:
                if _r not in _rs:
                    _rs.append(_r)
            return
    _popup_queue.append((obj_name, list(reasons)))
    _ensure_popup_timer()


def _ensure_popup_timer():
    if _popup_timer_on[0] or not _popup_supported():
        return
    try:
        bpy.app.timers.register(_popup_timer_tick, first_interval=0.05)
        _popup_timer_on[0] = True
    except Exception:
        _popup_timer_on[0] = False


POPUP_TITLE = "Compify 视差锁定"


# ★ 每种「无法冻结」的原因 → 用户该做什么。
#   用户 2026-10-20：「提示弹窗应该提示用户怎么做才能进行视差锁定，
#   而不是说一堆不明就里的话」—— 所以这里只写**操作步骤**，不写原理。
#
#   ⚠️ 这三条步骤都是**实测验证过真的有效**的（_dev/diag_fix_steps.py）：
#     按步骤做完 → 网格不再被阻塞 → handler 自动补上冻结坐标（不用重新锁定）
#     → 图案 UV 误差 0.00000000。改文案时不要让步骤和实际能力脱节。
_UNFREEZE_STEPS = {
    "修改器": [
        "选中它 → 右侧「修改器」面板（扳手图标）",
        "每个修改器点标题栏的下拉箭头 →「应用」",
    ],
    "形态键": [
        "选中它 →「物体数据」面板（绿色三角形）",
        "展开「形态键」→ 删掉全部形态键",
    ],
    "共享网格": [
        "把它和共用网格的物体一起选中",
        "菜单「物体 → 使其独立化 → 数据」",
    ],
}


def unfreezable_popup_lines(items):
    """把 [(对象名, 原因)] 归并成弹窗要显示的文字。

    抽成**纯函数**便于测试：直接断言内容，不必真的弹窗
    （headless 下弹窗会让 Blender 崩溃，见上方 ⚠️ ②）。
    返回 [(text, icon_or_None), ...]；icon 为 "SEPARATOR" 表示分隔线。
    """
    grouped = []
    for _n, _r in items:
        # 兼容两种输入：单个原因字符串，或原因列表
        _rs = [_r] if isinstance(_r, str) else list(_r)
        for g in grouped:
            if g[0] == _n:
                for _x in _rs:
                    if _x not in g[1]:
                        g[1].append(_x)
                break
        else:
            grouped.append([_n, list(_rs)])

    lines = [("视差锁定：这几个网格暂时冻不住图案", "ERROR")]
    lines.append(("按下面的步骤处理，处理好会自动接上（不用重新锁定）：", None))
    lines.append(("", "SEPARATOR"))

    for _n, _rs in grouped:
        lines.append(("▸ %s" % _n, "OBJECT_DATA"))
        for _r in _rs:
            steps = _UNFREEZE_STEPS.get(_r)
            if steps is None:
                lines.append(("    无法冻结（%s）" % _r, None))
                continue
            for _s in steps:
                lines.append(("    %s" % _s, None))
        lines.append(("", "SEPARATOR"))

    lines.append(("暂时不想处理？点面板上的「重置」退出冻结，", None))
    lines.append(("网格会回到普通实时投影，不影响其它操作。", None))
    return lines


def _popup_timer_tick():
    """timer 回调：把排队中的提示合并成**一个**弹窗。"""
    _popup_timer_on[0] = False
    items = list(_popup_queue)
    _popup_queue.clear()
    for _n, _rs in items:
        _popup_shown.add(_n)
    if not items or bpy.app.background:
        return None
    lines = unfreezable_popup_lines(items)
    try:
        def draw(self, context):
            col = self.layout.column(align=True)
            for _txt, _icon in lines:
                if _icon == "SEPARATOR":
                    col.separator()
                    continue
                if _icon:
                    # ⚠️ icon 名字写错会让 label 抛异常 → 整个 draw 失败 → 弹窗不显示。
                    #    "弹窗消失"是静默失败，比显示错字严重得多，所以这里降级重试。
                    try:
                        col.label(text=_txt, icon=_icon)
                        continue
                    except Exception:
                        pass
                col.label(text=_txt)
        bpy.context.window_manager.popup_menu(draw, title=POPUP_TITLE)
    except Exception:
        pass
    return None


def _clear_unfreezable_record(obj_name):
    """该对象已变得可冻结（或已不在投影里）→ 清掉记录，以后可再提示。"""
    _popup_shown.discard(obj_name)
    _backfill_warned.discard(obj_name)


def _reset_popup_state():
    """解锁 / 重置时清空待弹队列（不弹已过期的提示）。"""
    _popup_queue.clear()


def cancel_popup_timer():
    """注销弹窗 timer（插件卸载时调用，避免禁用插件后 timer 还在跑）。"""
    try:
        if hasattr(bpy.app, "timers") and bpy.app.timers.is_registered(_popup_timer_tick):
            bpy.app.timers.unregister(_popup_timer_tick)
    except Exception:
        pass
    _popup_timer_on[0] = False
    _popup_queue.clear()


def _proj_signature():
    try:
        n_slots = 0
        for o in bpy.data.objects:
            if o.type == "MESH" and o.data is not None:
                n_slots += len(o.data.materials)
        # ⚠️ 还要含「材质里的节点总数」（独立审查 第八轮 🟡-1）：
        #   用户给一个**已存在**的对象手工接入投影（在它自己的材质里插一个
        #   Camera Project 组节点）时，对象数/材质数/材质槽数**都不变** ⇒
        #   旧签名判"没变"⇒ 缓存返回旧列表 ⇒ 该对象永远拿不到冻结坐标，
        #   投影退化为常量且无提示。而原注释还写着"动一下相机即可"—— **那句是错的**
        #   （缓存按签名判，与相机是否移动无关）。
        n_nodes = 0
        for m in bpy.data.materials:
            _t = getattr(m, "node_tree", None)
            if _t is not None:
                n_nodes += len(_t.nodes)
        # ⚠️⚠️ 必须带上 `bpy.data.as_pointer()` —— 这是个**真实用户会遇到**的 bug：
        #   模块级缓存在「打开另一个 .blend / 新建文件」时**不会被清**，
        #   而新文件的「对象数/材质数」很可能恰好与缓存里的旧世界相同 ⇒
        #   命中旧缓存、返回**悬空的对象列表** ⇒ 新接入材质的对象永远拿不到冻结坐标。
        #   （回归网 test_review_fixes4 E5-a / test_review_fixes5 E-2 抓到的就是这个。）
        return (bpy.data.as_pointer(), len(bpy.data.objects), len(bpy.data.materials),
                len(bpy.data.node_groups), n_slots, n_nodes)
    except Exception:
        return None


def objects_using_projection_cached(cam_data_name):
    """带结构签名缓存的 `objects_using_projection`（见上方说明）。"""
    sig = _proj_signature()
    if sig is not None:
        ent = _proj_cache.get(cam_data_name)
        if ent is not None and ent[0] == sig:
            return ent[1]
    res = objects_using_projection(cam_data_name)
    if sig is not None:
        _proj_cache[cam_data_name] = (sig, res)
    return res


def objects_using_projection(cam_data_name):
    """所有材质里引用了该相机 Camera Project 组的 mesh 对象（图案冻结要覆盖它们）。

    ⚠️ 为什么扫 bpy.data.objects（全局）而非 scene.objects：
    Camera Project 节点组是【全局 datablock】—— 补丁一打，凡是引用了它的材质
    在所有场景里都立刻走冻结坐标。所以每一个可能用到它的 mesh 都必须有
    冻结坐标属性，否则 Attribute 节点读不到 → 该物体投影糊成常量。
    """
    gname = CAM_PROJECT_PREFIX + cam_data_name
    out = []
    for o in bpy.data.objects:
        if o.type != "MESH" or o.data is None:
            continue
        hit = False
        # ★★ 必须同时看 `material_slots`（独立审查 2026-10-20）：
        #    材质槽的 link 可以是 DATA（默认，绑网格）或 OBJECT（绑物体）。
        #    OBJECT 链接时材质只出现在 `o.material_slots[i].material`，
        #    `o.data.materials` 里看不到 —— 于是这类网格被静默漏掉：
        #    它没有冻结坐标属性 ⇒ Attribute 节点读 0 ⇒ 图案根本不冻结，
        #    但面板仍显示"已锁定"，用户以为锁上了其实没锁。
        #    实测：A 网格 data-linked、B 网格 object-linked 用同一投影材质，
        #         锁定后 A 有 campos、B 没有。
        #    这里取两者的并集（数据里可能有槽没有的材质），按材质指针去重。
        _mats, _mseen = [], set()
        try:
            for _s in o.material_slots:
                _m = _s.material
                if _m is not None and _m.as_pointer() not in _mseen:
                    _mseen.add(_m.as_pointer())
                    _mats.append(_m)
        except Exception:
            pass
        try:
            for _m in o.data.materials:
                if _m is not None and _m.as_pointer() not in _mseen:
                    _mseen.add(_m.as_pointer())
                    _mats.append(_m)
        except Exception:
            pass
        for m in _mats:
            nt = getattr(m, "node_tree", None)
            if nt is None:
                continue
            stack = [nt]
            seen = set()
            while stack and not hit:
                t = stack.pop()
                ptr = t.as_pointer()
                if ptr in seen:
                    continue
                seen.add(ptr)
                for n in t.nodes:
                    if n.type == "GROUP" and n.node_tree is not None:
                        if n.node_tree.name == gname:
                            hit = True
                            break
                        stack.append(n.node_tree)
        if hit:
            out.append(o)
    return out


def block_reasons(obj):
    """返回**全部**阻塞原因（list，可能为空）。

    ★ 为什么要"全部"（用户 2026-10-20 弹窗反馈）：
      一个网格可能同时满足多条 —— 典型是两个对象共享同一份带形态键的网格，
      此时"形态键"和"共享网格"都成立。若只报第一条，用户删完形态键后
      还会再被提示一次（要操作两轮），体验很差。一次说全才是"告诉我怎么做"。
    """
    out = []
    try:
        if len(obj.modifiers) > 0:
            out.append("修改器")
        if obj.data is None:
            return out or ["无网格数据"]
        if obj.data.shape_keys is not None:
            out.append("形态键")
        # ★ 判「共享网格」时必须**排除 fake user**（独立审查 2026-10-20）：
        #   `mesh.users` 把 fake user 也算进去（它只是"防被清掉"的保险，
        #   并不对应任何真实对象）。用户给网格加 fake user 是很常见的习惯，
        #   原实现只看 users>1 ⇒ 单对象 + fake user 就被判成「共享网格」⇒
        #   直接拒绝锁定，消息还说是共享网格，用户完全摸不着头脑。
        #   实测：`users=2`（1 对象 + 1 fake user）→ 锁定 success=False；
        #        关掉 fake user 同一场景立刻成功。
        try:
            _users = int(obj.data.users) - (1 if getattr(obj.data, "use_fake_user", False) else 0)
        except Exception:
            _users = int(obj.data.users)
        if _users > 1:
            out.append("共享网格")
    except Exception:
        return out
    return out


def has_modifier_or_shapekey(obj):
    """返回**第一个**阻塞原因或 None。

    ⚠️ 兼容旧调用点（多个地方只关心"有没有阻塞"）。
       需要全部原因的地方请用 `block_reasons()`。
    """
    rs = block_reasons(obj)
    return rs[0] if rs else None


# ──────────────────────────── 状态存取 ────────────────────────────

def load_groups(scene):
    raw = scene.get(GROUPS_KEY)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_groups(scene, groups):
    scene[GROUPS_KEY] = json.dumps(groups)


def _migrate_cam_key(scene, camera, old_key, new_key, groups):
    """把挂在旧相机数据名下的资产迁到新名下（相机数据块改名后的自愈）。

    迁移四样：投影组名、每个 mesh 上的冻结坐标属性名、反向索引 `OBJ_CAM_KEY`、
    以及补丁里 Attribute 节点的 `attribute_name`。
    最后把 state 的 key 换掉。—— 独立审查 第三轮 F4
    """
    if old_key == new_key:
        return
    # ① 投影组名
    g_old = bpy.data.node_groups.get(CAM_PROJECT_PREFIX + old_key)
    g_new = bpy.data.node_groups.get(CAM_PROJECT_PREFIX + new_key)
    if g_old is not None and g_new is None:
        # 补丁里记的 Attribute 节点名不变，只改属性名引用
        try:
            info = json.loads(g_old.get(PATCH_KEY) or "{}")
            anode = g_old.nodes.get(info.get("attr", ""))
            if anode is not None:
                anode.attribute_name = _campos_attr_name(new_key)
        except Exception:
            pass
        g_old.name = CAM_PROJECT_PREFIX + new_key
    # ①b ★ UV Adjust 组名**也嵌了相机数据名**，而它才是 `get_lock_targets()` 的检索源。
    #     只迁 Camera Project 组名是不够的（独立审查 第七轮 🔴 F-1）：
    #     「改名 → 解锁 → 再锁定」时 `get_lock_targets` 一个网格都找不到
    #     ⇒ 返回「该相机下没有带投射 UV 的网格」，**用户永久失去锁定能力**，
    #     而消息完全没提改名这回事（误导方向）。
    #     组名格式：`UV Adjust | <mesh_data> | <cam_data>`。
    for _g in list(bpy.data.node_groups):
        try:
            _suf = " | " + old_key
            if _g.name.startswith(UV_ADJUST_PREFIX) and _g.name.endswith(_suf):
                _new_gname = _g.name[:-len(_suf)] + " | " + new_key
                if _g.name != _new_gname and bpy.data.node_groups.get(_new_gname) is None:
                    _g.name = _new_gname
            # 组上还挂着元数据（node_group_manager 用它判"归属哪个相机"）
            if _g.get("compify_uv_camera_data_name") == old_key:
                _g["compify_uv_camera_data_name"] = new_key
        except Exception:
            continue

    # ② 各 mesh 上的资产
    a_old, a_new = _campos_attr_name(old_key), _campos_attr_name(new_key)
    for o in bpy.data.objects:
        if o.type != "MESH" or o.data is None:
            continue
        try:
            if o.get(OBJ_CAM_KEY) == old_key:
                o[OBJ_CAM_KEY] = new_key
            if o.get(CAMPOS_OWNER_KEY) == old_key:
                o[CAMPOS_OWNER_KEY] = new_key
            at = o.data.attributes.get(a_old)
            if at is not None and o.data.attributes.get(a_new) is None:
                at.name = a_new
        except Exception:
            continue
    # ③ state key
    groups[new_key] = groups.pop(old_key)
    rec = groups[new_key]
    if isinstance(rec, dict):
        rec["cam_uid"] = cam_uid(camera)
    save_groups(scene, groups)
    # 缓存按指针/名字索引，清掉让下一轮重算。
    # ⚠️ 只清**相关**条目，不要整表 clear（独立审查 第七轮 N-4）：
    #    整表清会让其它场景/其它相机的缓存全部作废 ⇒ 下一轮对所有相机
    #    重跑一次逐顶点适配（性能代价），而迁移本来只影响这一个相机。
    _base_cache.clear()
    for _k in [k for k in list(_last_view) if k[1] in (old_key, new_key)]:
        _last_view.pop(_k, None)
    _proj_cache.pop(old_key, None)
    _proj_cache.pop(new_key, None)


def get_state(scene, camera):
    if camera is None or camera.data is None:
        return None
    return _resolve_state(scene, camera)[1]


def _resolve_state(scene, camera):
    """返回 (key, state, groups)；找不到返回 (None, None, groups)。

    ⚠️ 按名字找不到时用 UID 兜底并**迁移**（独立审查 第三轮 F4）——
       相机数据块改名后，否则面板/handler/reset 全都接不上（静默失效 + 不可逆）。
    """
    if camera is None or camera.data is None:
        return None, None, {}
    groups = load_groups(scene)
    name = camera.data.name
    # ⚠️ 记录可能是**非 dict**（存档半损坏）—— 必须校验，否则 `st.get(...)` 抛
    #    `AttributeError`，而面板 draw 正是在这里取值 ⇒ **整个面板画不出来**
    #    （而不是优雅降级）。—— 独立审查 第五轮 🟡-1
    if name in groups and isinstance(groups.get(name), dict):
        return name, groups[name], groups
    uid = cam_uid(camera)
    if uid:
        # ⚠️ 复制相机数据块（outliner 对 data 按 Shift+D / 复制相机后重指 data）
        #    会把自定义属性**一起复制** ⇒ 两个相机的 `cam_uid` 相同（独立审查 第六轮 🟡-2）。
        #    此时不能谁先来就迁移给谁：会变成"两个相机互抢同一条记录"，
        #    投影组名被来回改名、两边 UI 都显示已锁定，而真正被驱动的只有先命中者。
        #    判据：**记录的名字若本身就是某个在场相机的数据名，说明它属于那个相机**，
        #    不做迁移（请求方就当"没有记录"，行为可预测）。
        _live_names = {o.data.name for o in scene.objects
                       if o.type == "CAMERA" and o.data is not None}
        for k, rec in list(groups.items()):
            if k == name:
                continue
            if isinstance(rec, dict) and rec.get("cam_uid") == uid:
                if k in _live_names:
                    continue                  # 记录名 = 在场相机 → 归属明确，别抢
                _migrate_cam_key(scene, camera, k, name, groups)
                return name, groups.get(name), groups
    return None, None, groups


def is_locked(scene, camera):
    st = get_state(scene, camera)
    return bool(st and st.get("enabled"))


def find_orphan_locks(scene):
    """找「网格上还带着锁定痕迹、但所属相机已不可达」的对象。

    ⚠️ 为什么必须有这个兜底（独立审查 第六轮 🔴-1）：
       state key / 补丁组名 / 冻结属性名**全按相机数据块名生成**，uid 也存在相机数据块上。
       一旦用户：
         · 换掉相机数据块（`cam.data = 另一个 camera data`，含复制相机后重指、删旧数据块），或
         · **删掉相机对象**（很常见）
       ⇒ 名字与 uid 双双失配 ⇒ `has_lock_record()` 为 False ⇒ 面板**不再显示重置按钮**、
         `reset_group()` 直接拒绝。而网格上 `ORIG_ATTR` / `BASE_ATTR` / `OBJ_CAM_KEY`
         全都还在 —— **原形就在那儿，却没有任何 UI 能触发还原**（不可逆）。
       这个函数给出一条**不依赖相机身份**的还原通道。
    返回 [(obj, 原因字符串)]。
    """
    try:
        groups = load_groups(scene)
    except Exception:
        groups = {}
    # ★★ 先做「身份自愈」（独立审查 第八轮 🔴-1）：相机数据块改名后，
    #   网格上的 `OBJ_CAM_KEY` 仍写着**旧名**（重命名不会改自定义属性），
    #   而 `live` 里只有新名 ⇒ 判定成立 ⇒ **面板误报"相机已不存在"**。
    #   而面板的"孤儿"提示在按相机循环之前就会画出来，用户照它点"还原"
    #   ⇒ **健康锁定被连根清掉**（OBJ_CAM_KEY/ORIG_ATTR/BASE_ATTR 全删），
    #   此后网格彻底停止适配，而面板照旧显示 🔒。这是"救命通道反噬"。
    #   所以判定之前，先把每个在场相机的旧资产迁到新名下。
    for _o in bpy.data.objects:
        if _o.type != "CAMERA" or _o.data is None:
            continue
        try:
            _resolve_state(scene, _o)          # 触发 _migrate_cam_key（幂等）
        except Exception:
            continue

    # ⚠️⚠️ 可达性必须按【全局】判，**不能只看本场景**（独立审查 第七轮 🔴 F-2）：
    #   一个网格可以被 link 进第二个场景（Blender 的 Scene Linked Copy / 手动 link），
    #   或相机被暂时 unlink 出 collection（对象仍在 bpy.data）。
    #   只在本场景找相机 ⇒ 这两种情况都被误判成"孤儿" ⇒ 面板弹出红色警示、
    #   引导用户点「还原」⇒ **把别的场景里完好的锁定连根清掉**
    #   （`OBJ_CAM_KEY`/`ORIG_ATTR`/`BASE_ATTR`/campos 全删，而图案补丁还挂着）。
    #   判据：相机只要在**任意**场景/collection 里存在，就算可达 —— 它只是暂时不在场。
    live = set()
    for o in bpy.data.objects:
        if o.type != "CAMERA" or o.data is None:
            continue
        live.add(o.data.name)                      # 全局：所有相机数据名
        try:
            _u = o.data.get(CAM_UID_KEY)
            if _u:
                live.add(_u)
        except Exception:
            pass
    # ⚠️⚠️ **不要**把 state 记录的 key 加进可达集合（我第一版加了，立刻被回归网抓到）：
    #   「记录存在」**不等于**「相机存在」—— 换掉相机数据块之后，记录 key 仍是旧名
    #   "Cam"，若把它当"可达"就永远判不出孤儿 ⇒ 那条救命通道形同虚设。
    #   （这正是我在 R10/F-3 总结过的「记录 ≠ 实体」，又踩了一次。）
    #   可达性只认**真实存在的相机对象**：它们在 bpy.data.objects 里（任意场景/collection），
    #   不在场（未 link 进当前场景）也算可达 —— 那只是"暂时看不见"。

    out = []
    for o in scene.objects:
        if o.type != "MESH" or o.data is None:
            continue
        key = None
        try:
            key = o.get(OBJ_CAM_KEY)
        except Exception:
            pass
        has_orig = o.data.attributes.get(ORIG_ATTR) is not None
        has_base = o.data.attributes.get(BASE_ATTR) is not None
        if not (has_orig or has_base or key):
            continue
        if key and key not in live:
            # 再核一次：该网格是否被【任何场景】里持有此 key 的相机覆盖？
            # （全局兜底，防"相机对象还在、只是不在这个场景"被误判）
            _ok = False
            for _sc in bpy.data.scenes:
                try:
                    if find_camera(_sc, key) is not None:
                        _ok = True
                        break
                except Exception:
                    continue
            if _ok:
                continue
            # ★ 最后一关：用 **uid** 认身份（独立审查 第八轮 🔴-1）。
            #   记录里的 `cam_uid` 跨改名稳定；只要它匹配到某个在场相机，
            #   就说明"相机还在、只是 key 是旧名"（迁移没能生效时也别误报）。
            _rec = groups.get(key) if isinstance(groups, dict) else None
            _u = _rec.get("cam_uid") if isinstance(_rec, dict) else None
            if _u:
                for _co in bpy.data.objects:
                    if _co.type != "CAMERA" or _co.data is None:
                        continue
                    try:
                        if _co.data.get(CAM_UID_KEY) == _u:
                            _ok = True
                            break
                    except Exception:
                        continue
            if _ok:
                continue
            out.append((o, "所属相机「%s」已不存在" % key))
        elif not key and (has_orig or has_base):
            out.append((o, "缺少锁定归属记录"))
    return out


def reset_orphan_locks(scene):
    """还原所有「孤儿锁定」：把几何还原成原形 + 清掉插件留下的全部痕迹。

    不依赖相机身份 —— 是「换数据块 / 删相机」之后**唯一**的还原途径。
    —— 独立审查 第六轮 🔴-1
    """
    orphans = find_orphan_locks(scene)
    if not orphans:
        return {"success": False, "message": "没有发现残留的锁定痕迹", "count": 0}
    # ⚠️ 必须在**清属性之前**把"哪些相机的记录该删"记下来 ——
    #   下面的还原循环会把 `OBJ_CAM_KEY` 删掉，之后再读就永远是 None
    #   （我第一版就把它放在后面，于是记录一条都删不掉；回归网 B-3 当场抓到）。
    _orphan_keys = set()
    for _obj, _why in orphans:
        try:
            _k = _obj.get(OBJ_CAM_KEY)
        except Exception:
            _k = None
        if _k:
            _orphan_keys.add(_k)
    # ⚠️⚠️ 还原必须**真的还原**，否则**绝不能销毁还原依据**（独立审查 第九轮 🔴 F-1）：
    #   旧存档（v2.7.5 及更早）没有 `ORIG_ATTR`；此前这里调 `_restore_geometry(obj, None)`，
    #   而 `old_st=None` 会被直接 `return False`（几何**一动不动**），
    #   紧接着却**无条件**删掉 `BASE_ATTR` ——
    #     ① 把「本来还能救」的网格变成「彻底不可救」（依据被销毁）；
    #     ② 消息还回报「已还原 N 个网格」——**与事实相反**。
    #   实测：几何偏差 8.399999（完全没动）、BASE_ATTR 消失、消息谎报。
    #   而 `groups` 里该相机的记录**还带着可用的 `locked_matrix`**（相机是被删对象、
    #   不是删记录）—— 传进去就能还原（对照组偏差 0.000000）。
    groups_all = {}
    try:
        groups_all = load_groups(scene)
    except Exception:
        groups_all = {}
    names, failed = [], []
    _done_keys = set()          # 只对「确实还原成功」的对象清记录
    for obj, _why in orphans:
        ok = False
        # ⚠️ 先取值、再动手（下面会把这个属性删掉）——
        #   我第一版在删完 `OBJ_CAM_KEY` **之后**才读它进 `_done_keys`，
        #   于是永远读到 None、记录一条都清不掉。**同一个错误（"删之前读"）在同一轮里又犯了一次**，
        #   而它正是审查员本轮指出的那类问题的镜像。—— 回归网 B-3 / 🔴-2c/2f 当场抓到
        try:
            _k = obj.get(OBJ_CAM_KEY)
        except Exception:
            _k = None
        try:
            _st = groups_all.get(_k) if (_k and isinstance(groups_all.get(_k), dict)) else None
            ok = bool(_restore_geometry(obj, _st))     # ← 传入旧相机记录（若还有）
        except Exception:
            ok = False
        if not ok:
            # 还原失败 ⇒ **保留依据**（ORIG/BASE 都不删），只报出来，别假装成功
            failed.append(obj.name)
            continue
        if _k:
            _done_keys.add(_k)
        # 清对象上的插件属性
        for k in (OBJ_CAM_KEY, DRAG_SCALE_KEY, DRAG_OFFSET_KEY, MATRIX_KEY, CENTER_KEY, ORIG_CENTER_KEY, CAMPOS_OWNER_KEY, CAMPOS_VCOUNT_KEY):
            try:
                if k in obj.keys():
                    del obj[k]
            except Exception:
                pass
        # ★ 只清【本对象被判为孤儿的那一个 key】所对应的冻结坐标（独立审查 第十轮 🟡-2）。
        #
        # ⚠️ 这里原来是**前缀扫描**（`name.startswith(CAMPOS_ATTR)` → 全删），
        #   而一块 mesh 可以**同时被多个相机投影**（本项目明确支持 —— N1/S1 就是为此修的：
        #   "冻结坐标按相机分开存，每个相机只读写自己那一份"）。
        #   ⇒ 只因为**其中一台**相机变成孤儿，就会把**另一台仍健康锁定**的相机的
        #     campos 一并删掉：那个相机照旧显示 🔒、`is_patched()` 仍 True、
        #     没有任何提示，而它的 Attribute 节点输出了 (0,0,0) ⇒ 该网格投影**静默损坏**。
        #   对照同一份代码里 `reset_group` 的做法 —— 它用
        #   `_remove_attr(obj, _campos_attr_name(cam_data_name))` **精确匹配**。
        #   **同一语义（"清掉冻结坐标"）两把尺子**，正是本项目反复在修的那类病。
        #   判据本该是：只清「**已不可达的那个 key**」对应的那一份；其它相机的一律不动。
        #   （对象没有 `OBJ_CAM_KEY` 时保守起见什么都不清 —— 留着比误删安全。）
        try:
            if _k:
                _remove_attr(obj, _campos_attr_name(_k))
        except Exception:
            pass
        # ⚠️ BASE_ATTR 也要清（我第一版漏了它 → 对象仍被判为"残留痕迹"，
        #    `find_orphan_locks` 永远非空、警示消不掉）。—— 自查发现
        #    ★ 但现在**只在还原成功时**才清（见上面的 `continue`）。
        for _an in (ORIG_ATTR, BASE_ATTR):
            try:
                if obj.data.attributes.get(_an) is not None:
                    obj.data.attributes.remove(obj.data.attributes[_an])
            except Exception:
                pass
        names.append(obj.name)
    # 撤掉孤儿相机留下的补丁 + 清掉真正不可达的记录。
    #
    # ⚠️⚠️ 必须用**与 `find_orphan_locks` 完全同一把尺子**（独立审查 第八轮 🔴-2）：
    #   原来这里是 `find_camera(scene, …)` —— **场景内**查找，而判定侧（第七轮 F-2 修过）
    #   早改成了**全局**可达。于是「相机只是暂时不在这个场景」（多场景工作流 / unlink 出
    #   collection）时：
    #     判定侧 = 健康 ✓（不报孤儿）  但 清理侧 = 不可达 ✗
    #   ⇒ 点一次「还原」就把**另一个相机**的锁定记录与**全局投影补丁**一起删掉，
    #     而那个相机锁得好好的；消息只报孤儿网格，对这次连带破坏**完全沉默**
    #     （用户回到另一个场景才发现：锁定悄悄没了、图案不再冻结）。
    #   ⇒ 现在只清「确实被判为孤儿 **且还原成功**」的那些 key，其余一律不动。
    #   ⚠️ 加"且还原成功"（独立审查 第九轮 🔴 F-1）：还原失败（旧存档缺原形/基准）
    #      时记录与属性都要**留着** —— 那是用户之后唯一可能用上的线索。
    try:
        groups = load_groups(scene)
        for cam_name in list(groups.keys()):
            if cam_name not in _done_keys:
                continue                     # ← 不在"已成功还原"名单里的，一律不动
            try:
                unpatch_camera_project_group(cam_name)
            except Exception:
                pass
            # ★★ C+k 也要复位成恒等（独立审查 2026-10-20）：
            #    C+k 是**节点组里的数值**，不是对象属性 —— 上面清的都是对象侧痕迹，
            #    完全没碰它。于是「孤儿锁定 → 点还原」之后：
            #      · 记录消失了（groups.pop）
            #      · 补丁撤了（unpatch）
            #      · 但组里的 S/C 还是上一轮落实的偏移值
            #    ⇒ 图案永久偏着，而且**再也没有记录能让它回正**（连重置都不知道有这回事）。
            #    对照 `reset_group`：它明确有 `write_identity_delta(cam_data_name)`。
            #    同一语义（"撤销锁定留下的改动"）必须同一把尺子。
            try:
                write_identity_delta(cam_name)
            except Exception:
                pass
            groups.pop(cam_name, None)
        save_groups(scene, groups)
    except Exception:
        pass
    _base_cache.clear()
    _last_view.clear()
    # ⚠️ 消息必须与事实一致（独立审查 第九轮 🔴 F-1）：一个都没还原成功时
    #   绝不能回报"已还原"（此前的消息在旧存档上就是**假的**）。
    if not names:
        return {"success": False, "count": 0, "objects": [], "failed": failed,
                "message": ("发现 %d 个残留锁定的网格，但**无法还原**（缺少原形/基准数据）；"
                            "已保留现有数据，未做任何修改" % len(failed))}
    _msg = "已还原 %d 个残留锁定的网格：%s" % (len(names), "、".join(names[:6]))
    if failed:
        _msg += ("；⚠️ 另有 %d 个**无法还原**（缺少原形/基准数据，已保留未动）：%s"
                 % (len(failed), "、".join(failed[:4])))
    return {"success": True, "count": len(names), "objects": names, "failed": failed,
            "message": _msg}


def lock_status(scene, camera):
    """面板用的一次性状态查询（避免同一份 JSON 每帧解 4 次）。—— 独立审查 第三轮 F11

    返回 {"locked", "patched", "has_record", "name"}。
    """
    out = {"locked": False, "patched": False, "has_record": False, "name": ""}
    if camera is None or camera.data is None:
        return out
    name = camera.data.name
    out["name"] = name
    _key, st, _groups = _resolve_state(scene, camera)
    out["has_record"] = st is not None
    out["locked"] = bool(st and st.get("enabled"))
    out["patched"] = is_patched(name)
    # ★ 降级检测（独立审查 第八轮 🟡-2）：锁定**之后**用户给对象 Alt+D（共享 mesh data）
    #   或加修改器时，`adapt_object` 会静默 return False ⇒ 该网格**从此不再适配**，
    #   而面板仍显示 🔒、`find_orphan_locks` 也不报。更阴险的是 **冻结坐标还在**，
    #   于是图案仍"正确地"长在那块不再变形的几何上 —— 画面上看不出任何异常。
    #   这里把它数出来，让 UI 能亮 ⚠（CHANGELOG 2.6.0 承诺"跳过**并提示**"）。
    if st and st.get("enabled"):
        try:
            _locked = list(locked_objects(scene, name, st))
            out["degraded"] = sum(
                1 for _o in _locked
                if has_modifier_or_shapekey(_o) is not None)
        except Exception:
            _locked = []
            out["degraded"] = 0
        # ★★ 锁定【期间】才接入投影材质、但无法冻结的网格也要计入降级。
        #    它们不在 `locked_objects` 里（没有 OBJ_CAM_KEY），于是原来完全不计 ——
        #    面板仍显示正常 🔒，而那块的图案其实是常量（Attribute 读 0）。
        #    实测：带修改器/形态键/共享网格的新网格，锁定中换材质后
        #    UV 误差恒为 0.72（= 图案塌成一点），且永远修不好。
        #    这类对象**本质上无法冻结**（修改器改变顶点域，逐顶点属性对不上），
        #    所以不去强行写属性，只把它数出来让 UI 亮 ⚠，用户自己决定怎么处理。
        try:
            _locked_set = set(_locked)
            for _o in objects_using_projection_cached(name):
                try:
                    if _o is None or _o.name not in scene.objects:
                        continue
                    if _o in _locked_set:
                        continue          # 已在上面数过
                    if _o.data is None or len(_o.data.vertices) == 0:
                        continue
                    if has_modifier_or_shapekey(_o) is not None:
                        out["degraded"] += 1
                except Exception:
                    continue
        except Exception:
            pass
    else:
        out["degraded"] = 0
    return out


def has_lock_record(scene, camera):
    """该相机是否还留有一条锁定记录（无论当前是否启用）。

    用途：面板决定是否显示「重置」按钮。
    「解锁」= 停止跟随但**不回退**（网格与图案保持当前状态），所以解锁之后
    仍然必须能重置 —— 否则用户一解锁就永远回不到原形了。—— 独立审查 S6
    """
    if camera is None or camera.data is None:
        return False
    return _resolve_state(scene, camera)[1] is not None


# ──────────────────────────── 顶点属性 ────────────────────────────

def _new_vec_attr(mesh, name):
    old = mesh.attributes.get(name)
    if old is not None:
        mesh.attributes.remove(old)
    return mesh.attributes.new(name=name, type="FLOAT_VECTOR", domain="POINT")


def _write_base_attribute(obj, cam_space_list):
    """变形用基准（相机空间坐标，剥离 scale）。"""
    mesh = obj.data
    attr = _new_vec_attr(mesh, BASE_ATTR)
    flat = []
    for (x0, y0, d) in cam_space_list:
        flat.extend((x0, y0, d))
    attr.data.foreach_set("vector", flat)
    mesh.update()
    _base_cache.clear()


def _write_campos_attribute(obj, camera, cam_data_name, mw_inv=None,
                            pre_scale=1.0, pre_offset=None):
    """图案冻结用：相机空间坐标（含相机 scale），与 TexCoord 的 Object 输出语义一致。

    属性名按相机区分（见 `_campos_attr_name`），所以锁相机 B 不会覆盖相机 A 的那份。

    ⚠️ 编辑模式下**绝对不能写**（用户实测反馈「锁定状态下进编辑模式，UV 完全坏掉」）：
       进编辑模式后 Blender 把网格属性搬进 BMesh，`mesh.attributes[...].data` 的
       len 变成 0（正常行为）。而 `_new_vec_attr` 是「先 remove 再 new」——
       在编辑模式里这么干会破坏 BMesh 的自定义数据层，退出编辑模式后整份冻结
       坐标被清成 (0,0,0)，投影 UV 全部塌到一个点，图案彻底糊掉（实测首顶点
       从 (-1,-1,-5) 变成 (0,0,0)，最大变化 5.0，正好等于相机距离）。
       编辑模式直接跳过；退出编辑模式后 handler 会按当时几何补回来。
    """
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    if mw_inv is None:
        mw_inv = camera.matrix_world.inverted()
    mesh = obj.data
    mwo = obj.matrix_world

    # ⚠️ 方案 D 起「构图落实」由投影组的 C+k 节点完成，不写逐顶点属性。
    #
    # ★ pre_scale / pre_offset：把「已经落实过的构图」并进冻结坐标。
    #   语义（用户）：「锁定时是调整，解锁后实现这个调整」——
    #   再锁定时要冻结的是**用户此刻看到的样子**，即
    #         UV_当前 = persp(p)·S + C
    #   所以新冻结坐标的透视分量应为 persp(p)·S + C（深度 z 不变）。
    #   不并的话重锁那一帧图案会跳（实测 Δ=0.400000，正好等于 C）。
    attr = _new_vec_attr(mesh, _campos_attr_name(cam_data_name))
    n_v = len(mesh.vertices)
    _has_pre = (abs(pre_scale - 1.0) > 1e-12) or (
        pre_offset is not None and (abs(pre_offset[0]) > 1e-12 or abs(pre_offset[1]) > 1e-12))
    if _np is not None and n_v > 0:
        # 向量化：几十万顶点时逐顶点 Python 循环会让锁定瞬间卡住
        vco = _np.empty(n_v * 3, dtype=_np.float64)
        mesh.vertices.foreach_get("co", vco)
        vco = vco.reshape(-1, 3)
        L2C = _np.array(mw_inv @ mwo, dtype=_np.float64)   # 局部 → 相机空间
        cs = vco @ L2C[:3, :3].T + L2C[:3, 3]
        if _has_pre:
            z = cs[:, 2]
            ox = 0.0 if pre_offset is None else float(pre_offset[0])
            oy = 0.0 if pre_offset is None else float(pre_offset[1])
            cs = _np.stack([cs[:, 0] * pre_scale + ox * z,
                            cs[:, 1] * pre_scale + oy * z,
                            z], axis=1)
        attr.data.foreach_set("vector", cs.reshape(-1))
    else:
        flat = []
        for v in mesh.vertices:
            c = mw_inv @ (mwo @ v.co)
            if _has_pre:
                ox = 0.0 if pre_offset is None else float(pre_offset[0])
                oy = 0.0 if pre_offset is None else float(pre_offset[1])
                c = mathutils.Vector((c.x * pre_scale + ox * c.z,
                                      c.y * pre_scale + oy * c.z, c.z))
            flat.extend((c.x, c.y, c.z))
        attr.data.foreach_set("vector", flat)
    mesh.update()
    obj[CAMPOS_OWNER_KEY] = cam_data_name      # 归属诊断用
    # ★ 记下这份坐标是按多少个顶点写的 —— 用来识别"几何被重建过"。
    #   （Blender 应用修改器时会把属性一起扩展成新长度，只比长度会漏判。）
    try:
        obj[CAMPOS_VCOUNT_KEY] = len(mesh.vertices)
    except Exception:
        pass


def _campos_is_valid(obj, cam_data_name):
    """该物体是否已有一份可用的冻结坐标属性（顶点数匹配）。

    ⚠️ 编辑模式下必须判「有效」（用户实测反馈「锁定状态下进编辑模式，UV 坏掉」）：
       进编辑模式后 Blender 把属性数据搬进 BMesh，`attributes[...].data` 的 len
       变成 0 —— 这是**正常行为**，属性并没有丢。若照常判 `0 != 顶点数` 返回 False，
       调用方会去重写，而编辑模式下的重写会破坏 BMesh 层（见
       `_write_campos_attribute` 的说明）⇒ 退出后整份坐标被清零、UV 全糊。
       属性确实还在，退出编辑模式就恢复可读，所以这里直接当有效。
    """
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return True
    a = obj.data.attributes.get(_campos_attr_name(cam_data_name))
    if a is None or len(a.data) != len(obj.data.vertices):
        return False
    # ★ 光比长度不够：Blender 应用修改器时会把属性一起扩展成新长度，
    #   长度校验会"通过"，但内容是部分错的（见 CAMPOS_VCOUNT_KEY 的说明）。
    #   用写入时记录的顶点数识别「几何被重建过」。
    n_now = len(obj.data.vertices)
    try:
        rec = obj.get(CAMPOS_VCOUNT_KEY)
    except Exception:
        rec = None
    if rec is None:
        # 旧数据没有记录 → 信任现有属性（保持旧工程行为不变），并补上记录。
        #   不选择"无记录就重写"：锁定期间 adapt_object 会解变形几何，
        #   此时重算会把冻结坐标钉到新几何上，图案会跟着动。
        try:
            obj[CAMPOS_VCOUNT_KEY] = n_now
        except Exception:
            pass
        return True
    try:
        return int(rec) == n_now
    except Exception:
        return True


def _remove_attr(obj, name):
    mesh = obj.data
    a = mesh.attributes.get(name)
    if a is not None:
        mesh.attributes.remove(a)


# ══════════════════════════════════════════════════════════════════════
# 解锁「落实构图」—— C + k 参数（方案 D）
#
# 语义（用户 2026-10-19）：「锁定时是调整，解锁后实现这个调整」；
#   锁定期间图案粘住网格不滑动，解锁那一帧不能跳，解锁后相机一动图案正常滑动。
#
# 实测结论（_dev/diag_affine.py / diag_analytic.py，15 个场景、残差 < 4e-07）：
#   解锁所需的 UV 修正量总能精确写成   delta = C + k · persp(p)
#     · 平移：k = 0，delta 退化成常量 C
#     · 旋转：C = 0、k = 0（几何已被 adapt_object 变形，实时投影本就等于冻结图案）
#     · 变焦：C = 0，k = 焦距比 − 1（相机 dolly 让 x/z 整体缩放）
#
# 投影组里对应两个**普通数值节点**： UV = persp · S + C   （S = 1 + k）
# 数值由插件写入 ⇒ 任何网格用了该投影材质就自动共享同一构图，
# 不存在「解锁后才换材质的网格拿不到状态」那类缺陷（用户实测报过 B 的问题）。
# ══════════════════════════════════════════════════════════════════════

def _find_delta_nodes(cam_data_name):
    """找投影组里的 S/C 两个节点；组不存在或缺链（旧工程）返回 None。"""
    ng = bpy.data.node_groups.get(CAM_PROJECT_PREFIX + cam_data_name)
    if ng is None:
        return None
    if not ng.get(PLOCK_DELTA_VERSION_KEY):
        return None
    s_node = ng.nodes.get(PLOCK_S_NODE)
    c_node = ng.nodes.get(PLOCK_C_NODE)
    if s_node is None or c_node is None:
        return None
    return s_node, c_node


def _ensure_delta_group(camera):
    """确保投影组带 C+k 链（旧工程保存的组没有）。

    只在缺链时重建 —— `ensure_camera_project_group` 是「清空重建 + 重挂驱动」，
    重建后补丁会失效，所以调用点必须放在「打补丁之前」。

    """
    if _find_delta_nodes(camera.data.name) is not None:
        return True
    try:
        from . import node_groups as _ng_mod
        _ng_mod.ensure_camera_project_group(camera, default_aspect=1.0)
        return _find_delta_nodes(camera.data.name) is not None
    except Exception:
        return False


def write_delta_params(cam_data_name, scale_s, offset_c):
    """把 S（标量）与 C（二维向量）写进投影组的节点数值。

    UV = persp · S + C
      锁定 / 重置：S = 1、C = 0     ⇒ 恒等变换
      解锁落实：    S = 1 + k、C = 实际偏移
    """
    nodes = _find_delta_nodes(cam_data_name)
    if nodes is None:
        return False
    s_node, c_node = nodes
    try:
        s_node.inputs["Scale"].default_value = float(scale_s)
        c_node.inputs[1].default_value = (float(offset_c[0]), float(offset_c[1]), 0.0)
        return True
    except Exception:
        return False


def write_identity_delta(cam_data_name):
    """恒等变换（锁定期间、重置之后）。"""
    return write_delta_params(cam_data_name, 1.0, (0.0, 0.0))


def clear_legacy_delta(obj):
    """清除旧版逐顶点 UV 偏移属性（方案 D 之前留下的）。

    新版组已不含对应 Attribute 节点，留着是垃圾数据。
    """
    try:
        if obj is not None and obj.data is not None:
            _remove_attr(obj, UV_DELTA_ATTR_LEGACY)
    except Exception:
        pass


def _persp_np(pts):
    """(n,3) 相机空间坐标 → (n,2) 透视坐标 (x/z, y/z)。"""
    z = pts[:, 2]
    ok = _np.abs(z) > MIN_DEPTH
    u = _np.where(ok, pts[:, 0] / _np.where(ok, z, 1.0), 0.0)
    v = _np.where(ok, pts[:, 1] / _np.where(ok, z, 1.0), 0.0)
    return _np.stack([u, v], axis=1), ok


def _zoom_z(cam_data):
    """投影组的 zoom 因子 Z = lens / sensor_width（与 node_groups 里的接线一致）。

    ⚠️ 投影组**总是**用 sensor_width（zoom_1 = lens / sensor_width），
       与 camera.sensor_fit 无关 —— 所以这里也只取 sensor_width，保持同源。
    """
    try:
        sw = float(cam_data.sensor_width)
        if abs(sw) < 1e-9:
            sw = 36.0
        return float(cam_data.lens) / sw
    except Exception:
        return 1.0


def fit_delta_params(frozen_persp, live_persp, lens_ratio, shift_term=None):
    """由逐顶点数据最小二乘反解 (S, C)，使 persp·S + C ≈ 目标。

    ★★ 目标是 `frozen_persp / lens_ratio`，**不是** frozen_persp。
       推理：投影组的完整输出是  UV = f(persp·S + C)，
       而 f 里含 zoom 节点乘子 Z = lens / sensor（以及 shift / rotate / …）。
       锁定时画面是   UV_lock = f_lock(persp_lock) = persp_lock · Z_lock
       解锁后画面是   UV_ul   = f_ul(persp_ul·S + C) = (persp_ul·S + C) · Z_ul
       要让两者相等（解锁那一帧画面不变），在 f 的其余部分不变的前提下：
           persp_ul·S + C = persp_lock · Z_lock / Z_ul = persp_lock / lens_ratio
       （Z_ul/Z_lock = lens_ul/lens_lock = lens_ratio）

    ★ 早期版本错在两点：
       ① 目标用成了 frozen_persp（少除一个 lens_ratio）
       ② S 硬套 k = lens_ratio − 1 这个"规律"—— 那是在**不含 zoom 节点**的
          数值模型里拟合出来的；搬进真实投影组后，变焦会多放大 lens_ratio 倍。
          实测用户报的正是：锁定期间调焦距 → 解锁贴图跳变 ~0.10。
       现在改为**不假定任何规律**，直接对 (S, C) 做最小二乘；
       锁定期间 persp 的变化量本身就会被 S 吸收，各种模式（dolly 变焦 /
       纯网格变形变焦 / 平移 / 旋转）都自然成立。

    返回 (S, C) ；数据不足返回 None。
    """
    if _np is None or frozen_persp is None or len(frozen_persp) == 0:
        return None
    ratio = float(lens_ratio) if lens_ratio else 1.0
    if abs(ratio) < 1e-12:
        ratio = 1.0
    target = frozen_persp / ratio
    # ★★ shift 补偿（用户实测，2026-10-20 独立审查）：
    #   投影组的完整输出其实是   UV = (persp·S + C) · Z + s
    #   其中 Z = lens / sensor_width（zoom 节点），s = (shift_x, shift_y)·常数（zoom 之后的加法）。
    #   要让解锁那一帧画面不变：
    #       (live·S + C) · Z_now + s_now = frozen · Z_lock + s_lock
    #   ⇒  live·S + C = (frozen · Z_lock + s_lock − s_now) / Z_now
    #   调用方传入的 ratio = Z_now / Z_lock，shift_term = (s_lock − s_now) / Z_now，
    #   于是 target = frozen / ratio + shift_term。
    #   ⚠️ 早先只传 lens 比、且完全没算 shift ⇒ 锁定期间改 sensor_width 跳 0.093、
    #      改 shift_x 跳 0.038（实测）。现在把这两项都纳入。
    if shift_term is not None:
        target = target + _np.asarray(shift_term, dtype=_np.float64)
    live = live_persp
    n = target.shape[0]
    # 未知量: [Cx, Cy, S] —— target ≈ live·S + C
    A = _np.zeros((2 * n, 3), dtype=_np.float64)
    b = _np.zeros(2 * n, dtype=_np.float64)
    A[:n, 0] = 1.0
    A[:n, 2] = live[:, 0]
    b[:n] = target[:, 0]
    A[n:, 1] = 1.0
    A[n:, 2] = live[:, 1]
    b[n:] = target[:, 1]
    try:
        sol, *_ = _np.linalg.lstsq(A, b, rcond=None)
        Cx, Cy, S = float(sol[0]), float(sol[1]), float(sol[2])
    except Exception:
        return None
    if not all(abs(x) < 1e12 for x in (Cx, Cy, S)):
        return None        # 病态数据，宁可放弃
    # ★★ 退化检查（用户实测边界，2026-10-20 独立审查）：
    #   当相机**贴着/穿过**网格时（所有顶点深度 |z| ≈ 0），透视除法 x/z 数值爆炸，
    #   最小二乘仍能解出"数学上自洽"的 S，但那个 S 毫无意义：
    #     实测 相机落在网格平面上 ⇒ S = 0.000100（正好是 MIN_DEPTH 量级）
    #         倾斜网格部分穿过 ⇒ S = 0.333333（数学正确，画面也正确，应放行）
    #   判据必须只挡真正的退化。S 是"整体系数"：
    #     正常场景 S ∈ {1.0（平移/旋转）, lens_ratio（变焦 dolly）}，量级 ~1
    #     退化场景 S 掉到 1e-4 量级 ⇒ 投影被压成一条线
    #   这里用**宽松**边界 [1e-3, 1e3]：只挡数量级级别的退化，不碰任何正常值。
    if not (1e-3 <= abs(S) <= 1e3):
        return None
    return S, (Cx, Cy)


def _write_orig_attribute(obj):
    """首次锁定时记录「原始顶点」（局部坐标）。

    ⚠️ **已有就保留、绝不覆盖**。这正是修复点：否则「解锁 → 再锁定」会把
       当前（已被适配变形的）形状当成新原形，`reset` 便永久回不去原始形状。
    —— 独立审查 第五轮 🔴-1
    """
    mesh = obj.data
    n = len(mesh.vertices)
    if n == 0:
        return False
    old = mesh.attributes.get(ORIG_ATTR)
    if old is not None and len(old.data) == n:
        return False                      # 已有原形 → 保留（关键）
    if old is not None:
        mesh.attributes.remove(old)
    attr = mesh.attributes.new(name=ORIG_ATTR, type="FLOAT_VECTOR", domain="POINT")
    buf = [0.0] * (n * 3)
    mesh.vertices.foreach_get("co", buf)
    attr.data.foreach_set("vector", buf)
    return True


def _read_orig_attribute(obj):
    """读回原始顶点（局部坐标的扁平 list）；没有则 None。"""
    if obj is None or obj.data is None:
        return None
    a = obj.data.attributes.get(ORIG_ATTR)
    if a is None:
        return None
    n = len(obj.data.vertices)
    if len(a.data) != n or n == 0:
        return None
    buf = [0.0] * (n * 3)
    a.data.foreach_get("vector", buf)
    return buf


def _clear_orig_attribute(obj):
    if obj is None or obj.data is None:
        return
    a = obj.data.attributes.get(ORIG_ATTR)
    if a is not None:
        obj.data.attributes.remove(a)


def _clear_lock_traces(obj):
    """清掉对象上的「本轮锁定痕迹」：原形属性 + 解锁签名。

    ⚠️ 必须**两处都用它**（独立审查 第七轮 🟡-3）：`reset_group` 的 `orig` 分支
       原来 `continue` 之前只清了 `ORIG_ATTR`，`UNLOCK_SIG_KEY` 残留在对象上 ——
       下一次「解锁后编辑」比对会拿到**过期的基线**（误报/漏报）。
       抽成一个函数，就不会再漏其中一半。
    """
    _clear_orig_attribute(obj)
    try:
        if obj is not None and UNLOCK_SIG_KEY in obj.keys():
            del obj[UNLOCK_SIG_KEY]
    except Exception:
        pass


def _read_base_attribute(obj):
    mesh = obj.data
    attr = mesh.attributes.get(BASE_ATTR)
    if attr is None:
        return None
    n = len(mesh.vertices)
    if len(attr.data) != n:
        return None
    key = (obj.name, mesh.as_pointer(), n)
    hit = _base_cache.get(key)
    if hit is not None:
        return hit
    flat = [0.0] * (n * 3)
    attr.data.foreach_get("vector", flat)
    out = [(flat[i * 3], flat[i * 3 + 1], flat[i * 3 + 2]) for i in range(n)]
    _base_cache[key] = out
    return out


# ──────────────────────────── 投影组补丁（图案冻结）────────────────────────────

def _patch_info(cam_data_name):
    """返回补丁信息 dict；记录缺失、损坏、或【对应节点已不在】时返回 None。

    ⚠️ 记录存在 ≠ 补丁还在。`ensure_camera_project_group()`（面板「重新生成投影组」、
    footage 设置流程等 5 处会调）**会清空组内所有节点**，但 `PATCH_KEY` 是节点组上的
    自定义属性、清节点不会清它 ⇒ 记录残留而补丁实际已失效。
    必须校验 Attribute 节点真的在场，否则是**假阳性**：
    下游会误判「已冻结」而跳过重写冻结坐标 ⇒ 图案不再冻结但 UI 仍显示已锁定。
    —— 独立审查 F7 / F8
    """
    ng = bpy.data.node_groups.get(CAM_PROJECT_PREFIX + cam_data_name)
    if ng is None:
        return None
    raw = ng.get(PATCH_KEY)
    if not raw:
        return None
    try:
        info = json.loads(raw)
    except Exception:
        return None
    if not isinstance(info, dict):
        return None
    if ng.nodes.get(info.get("attr", "")) is None:
        return None                     # 节点不在 ⇒ 补丁实际已失效
    return info


def is_patched(cam_data_name):
    """该相机的投影组当前是否【真的】处于「已冻结」状态（记录在 **且** 节点在）。"""
    return _patch_info(cam_data_name) is not None


def patch_camera_project_group(cam_data_name):
    """在 Camera Project 组里，把 TexCoord 的输出替换成冻结坐标属性。

    改法：TexCoord(Object) → [Attribute] → 下游
    ⇒ 投影 UV 恒等于锁定那一刻的值。
    """
    gname = CAM_PROJECT_PREFIX + cam_data_name
    ng = bpy.data.node_groups.get(gname)
    if ng is None:
        return None
    if _patch_info(cam_data_name) is not None:
        # 补丁【完好】（记录在 + 节点在）→ **保持原样**（不要刷新冻结的 lens/sensor/shift）。
        #
        # ⚠️ 曾经按独立审查 S3 的建议「先撤再重打」以刷新冻结值，但那会让
        #    「锁定 → 变焦 → 解锁 → 再锁定」时图案按新焦距缩放 = 用户看到的**跳变**
        #    （图案已经粘在网格上，它的外观必须保持不变）。
        #
        # 冻结值与 state.locked_focal 是【两个不同的东西】：
        #   · 组内冻结的 lens  = 「冻结外观」的参数（决定图案长什么样）
        #   · locked_focal     = 「变焦/几何」的基准（决定 zoom 补偿 = 相机镜头/该值）
        # 各自正确、互不矛盾；锁定那一刻 zoom 恒为 1，不会凭空触发推拉。
        # （S3 的另一半担心「reset 会还原成错误焦距」不成立：unpatch 会重建
        #   driver 并绑回 camera.data，节点会自动跟随相机。）
        return ng

    # 走到这里：要么从没打过补丁，要么【记录残留、但节点已被清掉】
    #（如 `ensure_camera_project_group` 清空了组内所有节点）→ 清掉残留记录，
    # 往下按当前组的状态**重打补丁**（自愈）。否则残留记录会一直造成假阳性，
    # 且 unpatch 会因为找不到节点而把 driver 加重复。—— 独立审查 F7
    #
    # ★★ 自愈时**必须沿用旧的「冻结值」，不能重取当前相机值**（独立审查 第十轮 🔴-1）：
    #   自愈的触发前提是「campos 仍然有效」（`_keep_existing`）⇒ 冻结坐标是**锁定时刻**的；
    #   若此时把组内冻结的 lens/sensor 重取成**当前**值，两者的时刻就不一致了：
    #     campos（含 50mm 语义） ÷ 组内 Lens（= 85） ⇒ 投影 UV 整体放大 85/50 = 1.7 倍
    #   ⇒ **图案按变焦比整体缩放**（实测 3 层场景渲染像素差 27.57、47.2% 像素变化），
    #     而 UI 全程 🔒、`is_patched()` 仍 True、没有任何提示。
    #   这正是 v2.7.2 明令撤销的 S3 那条跳变 —— **换了一条入口又回来了**。
    #   所以在 del 之前先把记录读出来，供下面沿用。
    _stale_frozen = {}
    _raw_stale = ng.get(PATCH_KEY)
    if _raw_stale:
        try:
            _st = json.loads(_raw_stale)
            if isinstance(_st, dict):
                for _f in (_st.get("frozen") or []):
                    if isinstance(_f, dict) and _f.get("path"):
                        _stale_frozen[_f["path"]] = float(_f.get("value", 0.0))
        except Exception:
            _stale_frozen = {}
        try:
            del ng[PATCH_KEY]
        except Exception:
            pass
    tc = None
    for n in ng.nodes:
        if n.type == "TEX_COORD" and getattr(n, "object", None) is not None:
            tc = n
            break
    if tc is None:
        return None
    src = None
    for s in tc.outputs:
        if s.links:
            src = s
            break
    if src is None:
        return None
    dests = [[lk.to_node.name, lk.to_socket.identifier] for lk in src.links]
    if not dests:
        return None

    attr = ng.nodes.new("ShaderNodeAttribute")
    attr.attribute_name = _campos_attr_name(cam_data_name)   # 每相机一份（见 _campos_attr_name）
    attr.label = "Plock: Frozen Cam-Space Pos"
    attr.name = ATTR_NODE_NAME
    attr.location = (tc.location.x + 200.0, tc.location.y - 240.0)

    for lk in list(src.links):
        ng.links.remove(lk)
    for nname, ident in dests:
        node = ng.nodes.get(nname)
        if node is None:
            continue
        sock = node.inputs.get(ident)
        if sock is not None:
            ng.links.new(attr.outputs["Vector"], sock)

    # ── 冻结 lens / sensor / shift（否则变焦时 UV 仍会变）──
    cam_data = bpy.data.cameras.get(cam_data_name)
    frozen = []
    if cam_data is not None:
        for n in ng.nodes:
            if n.type == "VALUE" and n.label in FROZEN_VALUE_LABELS:
                out = n.outputs["Value"]
                path = FROZEN_VALUE_LABELS[n.label]
                # ★ 自愈：优先沿用记录里的旧冻结值（与 campos 同一时刻）；
                #   全新锁定：记录为空 ⇒ 取当前相机值。—— 独立审查 第十轮 🔴-1
                if path in _stale_frozen:
                    val = float(_stale_frozen[path])
                else:
                    val = float(getattr(cam_data, path, out.default_value))
                try:
                    out.driver_remove("default_value")
                except Exception:
                    pass
                out.default_value = val
                frozen.append({"node": n.name, "path": path, "value": val})

    ng[PATCH_KEY] = json.dumps({"tc": tc.name, "src": src.identifier,
                                "attr": attr.name, "dests": dests,
                                "frozen": frozen})
    return ng


def _socket_has_driver(ng, node, socket):
    """该节点输出口上是否已经挂着 driver。

    ⚠️ 不能用 `socket.driver` —— `NodeSocketFloat` 没有这个属性（实测 AttributeError）。
    只能扫节点组的 `animation_data.drivers`，按 data_path 对（形如
    `nodes["Value"].outputs[0].default_value`）。—— 独立审查 R10
    """
    if ng.animation_data is None:
        return False
    try:
        idx = list(node.outputs).index(socket)
    except ValueError:
        return False
    want = 'nodes["%s"].outputs[%d].default_value' % (node.name, idx)
    for fc in (ng.animation_data.drivers or []):
        if fc.data_path == want:
            return True
    return False


def unpatch_camera_project_group(cam_data_name):
    gname = CAM_PROJECT_PREFIX + cam_data_name
    ng = bpy.data.node_groups.get(gname)
    if ng is None:
        return
    raw = ng.get(PATCH_KEY)
    if not raw:
        return
    try:
        info = json.loads(raw)
    except Exception:
        return
    attr = ng.nodes.get(info.get("attr", ""))
    patch_alive = attr is not None       # 补丁真的还在？（可能已被外部清掉）
    if patch_alive:
        for o in attr.outputs:
            for lk in list(o.links):
                ng.links.remove(lk)
        ng.nodes.remove(attr)
    tc = ng.nodes.get(info.get("tc", ""))
    if tc is not None:
        src = tc.outputs.get(info.get("src", ""))
        if src is not None:
            for nname, ident in info.get("dests", []):
                node = ng.nodes.get(nname)
                if node is None:
                    continue
                sock = node.inputs.get(ident)
                if sock is not None:
                    ng.links.new(src, sock)

    # 还原 lens / sensor / shift 的 driver（让变焦重新生效）
    #
    # ⚠️ 两道保险，防止 driver 变量被重复叠加 —— SUM 相加会让 lens 值**翻倍**
    #    （组内 Lens = 相机镜头 × 2），投影彻底错位，且每循环一次再叠一层。
    #    ① 补丁已失效（attr 节点被外部清掉，如「重新生成投影组」）⇒ 组内节点已是
    #       原生状态、driver 本来就完好，不需要也不应该重建。
    #    ② 无论哪条路径，重建前先 driver_remove，保证变量始终只有一份。
    #    —— 独立审查 F7
    # ⚠️ 不能用「补丁节点还在不在」（patch_alive）来决定要不要重建 driver（独立审查 R10）：
    #    补丁节点被**单独删掉**时（外部清理 / 用户手删），Value 节点的 driver 仍是
    #    patch_* 当初摘掉的 —— 此时不重建 ⇒ 投影**永久冻结**，而 UI 说"已重置"。
    #    正确判据是**逐个 Value 节点看它自己的 driver 在不在**：
    #      · 补丁还活着 → driver 被摘过 → None → 重建 ✓
    #      · 组被整体重新生成（ensure_camera_project_group）→ 节点是全新的、driver 在 → 不动 ✓
    #      · 补丁节点被单删 → driver 仍是 None → 重建 ✓
    cam_data = bpy.data.cameras.get(cam_data_name)
    for f in info.get("frozen", []):
        n = ng.nodes.get(f.get("node", ""))
        if n is None:
            continue
        out = n.outputs["Value"]
        out.default_value = float(f.get("value", out.default_value))
        if cam_data is None:
            continue
        if _socket_has_driver(ng, n, out):
            continue            # 该节点已有 driver（组被重新生成过）→ 无需重建
        try:
            drv = out.driver_add("default_value").driver
            drv.type = "SUM"
            var = drv.variables.new()
            var.type = "SINGLE_PROP"
            var.targets[0].id_type = "CAMERA"
            var.targets[0].id = cam_data
            var.targets[0].data_path = f.get("path", "lens")
        except Exception:
            pass

    try:
        del ng[PATCH_KEY]
    except Exception:
        pass


# ──────────────────────────── 变焦 → 相机推拉 ────────────────────────────

def _cam_dolly_add(camera, world_vec):
    """把「本次实际施加给相机的 dolly 增量」累加到相机上的持久记账。

    ⚠️ 为什么不能只用 state["applied_dolly"]（独立审查 第三轮 F2）：
       `applied_dolly` 是**相对当前这次锁定**的（`lock_group` 会把它清零，
       而 `adapt_object` 的归因数学也需要它相对当前锁定），
       但相机**物理上**仍带着之前几次锁定累积的 dolly。
       ⇒ 「锁定 → 变焦 → 解锁 → 再锁定 → 重置」时，记账已被清零，
         重置只归还 0，相机停在被推走的位置（实测 z 5.0 → 11.0，残差 6.0），
         而界面全程显示"已重置"。**相机原位不可逆地丢了。**
       所以另记一份**跟着相机走、跨锁定存活**的累计量，供 reset 归还。
    """
    if not CAMERA_DOLLY_ZOOM:
        return
    try:
        cur = mathutils.Vector(tuple(camera.get(CAM_DOLLY_KEY, (0.0, 0.0, 0.0))))
        tot = cur + mathutils.Vector(world_vec)
        camera[CAM_DOLLY_KEY] = [float(tot.x), float(tot.y), float(tot.z)]
    except Exception:
        pass


def _cam_dolly_get(camera):
    """相机上累计的（尚未归还的）插件 dolly 位移（世界空间）。"""
    try:
        return mathutils.Vector(tuple(camera.get(CAM_DOLLY_KEY, (0.0, 0.0, 0.0))))
    except Exception:
        return mathutils.Vector((0.0, 0.0, 0.0))


def _cam_dolly_clear(camera):
    try:
        if CAM_DOLLY_KEY in camera.keys():
            del camera[CAM_DOLLY_KEY]
    except Exception:
        pass


def _state_applied_dolly(camera, st):
    """本次锁定以来，插件**实际施加给相机**的 dolly 位移（世界空间）。

    ★★ 真相源是【相机上的持久记账】，不是 `state["applied_dolly"]`。
    —— 独立审查 2026-10-20（复制场景 dolly 翻倍）

    为什么必须换：
      `state` 存在**场景**的自定义属性里，而相机是**全局对象**。
      复制场景（LINK_COPY / FULL_COPY）时 state 被复制成两份，
      但相机只有一个、物理上只被推了一次。
        场景A 变焦 → 推 target，只有 A 的 state 更新成 target
        切到场景B → B 的 state 还是 0 ⇒ diff 又等于 target ⇒ **再推一遍**
        实测：同样变焦 50→85，不复制场景相机 z=8.00，复制场景 z=14.00（多推一整份）
      改从相机推导后，无论哪个场景读到的都是相机的真实状态，天然一致。

    与 `CAM_DOLLY_KEY` 的分工：
      CAM_DOLLY_KEY    = 跨【锁定】也存活的累计量（reset 用它把相机还回去）
      dolly_at_lock    = 锁定那一刻 CAM_DOLLY_KEY 的快照
      两者相减 = 「本次锁定以来施加了多少」= 正是这里要的 applied_dolly
    """
    _base_at_lock = st.get("dolly_at_lock")
    if _base_at_lock is not None:
        try:
            _cur = _cam_dolly_get(camera)
            _b = mathutils.Vector(tuple(_base_at_lock))
            return _cur - _b
        except Exception:
            pass
    # 旧存档没有 dolly_at_lock → 退回读 state 里那份副本（旧行为）
    return _safe_vector(st.get("applied_dolly"), (0.0, 0.0, 0.0))


def _safe_view_matrix(lm):
    """把记录里存的 4×4 行表**安全**解析成 Matrix；不合法返回 None。

    ⚠️ 为什么需要它（独立审查 第十一轮）：
      存档可能被外部损坏（手改 JSON / 跨版本残留 / 磁盘错误）——
      `locked_matrix` 行数不足、或元素不是数字时，直接
      `mathutils.Matrix([mathutils.Vector(r) for r in lm])` 会抛
      `TypeError: expects no args or a single arg containing 2-4 numeric sequences`
      / `Vector(): sequence index 0 expected a number, found 'str'`。
      三处调用点（`_locked_axis` / `_restore_geometry` / `reset_group`）都没兜住
      ⇒ 用户点「重置」**直接看到报错**，handler 每帧刷 traceback（被 except 吞掉）。
    ⚠️ 这与第六轮修过的「记录必须是 dict」是**同一类病的另一半**：
      当时只校验了"记录是不是 dict"，**没校验"记录内部的字段是不是合法值"**。
      （又是「同一个语义有两半」—— 本项目第 N 次。）
    """
    if not isinstance(lm, (list, tuple)) or len(lm) != 4:
        return None
    rows = []
    for r in lm:
        if not isinstance(r, (list, tuple)) or len(r) != 4:
            return None
        try:
            rows.append(mathutils.Vector([float(x) for x in r]))
        except (TypeError, ValueError):
            return None
    try:
        return mathutils.Matrix(rows)
    except Exception:
        return None


def _safe_vector(v, default=(0.0, 0.0, 0.0)):
    """把记录里的三元组安全解析成 Vector（含长度/类型兜底）。—— 独立审查 第十一轮"""
    try:
        if isinstance(v, (list, tuple)) and len(v) == 3:
            return mathutils.Vector((float(v[0]), float(v[1]), float(v[2])))
    except (TypeError, ValueError):
        pass
    return mathutils.Vector(default)


def _safe_float(v, default=0.0):
    """把记录里的数值字段安全转成 float（含 str/None/坏值兜底）。

    ⚠️ 同 `_safe_view_matrix`：`ref_depth` / `locked_focal` 被外部改坏（如 `"x"`）时，
      裸 `float(...)` 会抛 `ValueError` ⇒ handler 每帧崩（被吞）、reset 报错。
    """
    try:
        f = float(v)
        if f != f or f in (float("inf"), float("-inf")):
            return default
        return f
    except (TypeError, ValueError):
        return default


def _locked_axis(state):
    """锁定时的光轴（指向场景内）。

    ⚠️ 用 `.get()`：硬取 `state["locked_matrix"]` 时，一条坏记录会让 handler 抛
    KeyError 并被上层吞掉（该相机本轮静默失效）。—— 独立审查 R5
    """
    view_locked = _safe_view_matrix(state.get("locked_matrix"))
    if view_locked is None:
        return mathutils.Vector((0.0, 0.0, -1.0))
    return view_locked.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))


def world_to_parent_local(camera, world_vec):
    """世界向量 → 相机【父级空间】向量。

    ⚠️ camera.location 是相对父级的（父级空间），不是世界的。
    相机被父级（空物体 / 骨架等）带着时，把世界向量直接加到 location 上会错位
    （除非父级恰好是 identity）。—— 独立审查发现
    """
    if camera.parent is None:
        return world_vec
    # ⚠️⚠️ 必须带上 `matrix_parent_inverse`（独立审查 第三轮 F1）：
    #   camera.matrix_world = parent.matrix_world @ matrix_parent_inverse @ matrix_basis
    #   而 `location` 是 matrix_basis 里的平移 ⇒ 世界位移 = (P @ MPI).to_3x3() @ Δ。
    #   **Ctrl+P → Keep Transform（默认做法）恰恰把 MPI 写成父级世界矩阵的逆**，
    #   它默认为**非单位阵** ⇒ 只乘 P 会把 dolly 方向/大小算错。
    #   实测：父级 Ctrl+P 后变焦 50→400mm，构图误差 0.75 → 53.7（越变焦越崩），
    #   而"父级为单位阵"的对照组误差 0.000000 —— 差的正是这一项。
    #   最阴险的是：回到原焦距误差会消失，用户很难归因。
    m = (camera.parent.matrix_world @ camera.matrix_parent_inverse).to_3x3()
    return m.inverted() @ world_vec


def auto_dolly_vector(state, zoom):
    """变焦补偿中【由相机承担】的那段位移（= **目标**位移，按【当前】ref_depth 算）。

    取基准层（ref_depth）为锚点：相机沿光轴移动 ref·(1-k)，
    使基准层靠"相机移动"就能保持构图；其余深度由网格补偿。
    这样：变焦时相机真的在动，而构图仍精确冻结。

    ⚠️ 这是**目标**值，不是"已经施加了多少"。已施加量记在 `state["applied_dolly"]`，
    两者之差才是这一轮要补的位移。—— 独立审查 F1
    """
    if not CAMERA_DOLLY_ZOOM:
        return mathutils.Vector((0.0, 0.0, 0.0))
    ref = _safe_float(state.get("ref_depth", 0.0))
    # k>1（拉长焦=放大）→ 相机后退（负号 = 逆光轴）
    return _locked_axis(state) * (-ref * (float(zoom) - 1.0))


# ──────────────────── 用户拖动锁定网格 → 重新锚定 ────────────────────

def _mesh_center_local(obj):
    """网格顶点在【局部空间】的形心（拖动换算的参考点）。

    ⚠️ 带缓存：局部形心只随**顶点**变化，不随物体位姿变化；而拖动时位姿每帧都变。
    不缓存的话，每次拖动都要遍历全部顶点求形心 —— 几十万顶点 × 每帧 = 卡死。
    （缓存由 adapt_object 失效，因为只有它会改顶点。）

    ⚠️ 别用 `obj.location` 代替：物体原点可能不在网格上（网格有偏移时），
    用它算深度会偏。
    """
    c = obj.get(CENTER_KEY)
    if c is not None and len(c) == 3:
        return mathutils.Vector((c[0], c[1], c[2]))
    mesh = obj.data
    n = len(mesh.vertices)
    if n == 0:
        return mathutils.Vector((0.0, 0.0, 0.0))
    buf = [0.0] * (n * 3)
    mesh.vertices.foreach_get("co", buf)
    v = mathutils.Vector((sum(buf[0::3]) / n,
                          sum(buf[1::3]) / n,
                          sum(buf[2::3]) / n))
    obj[CENTER_KEY] = [v.x, v.y, v.z]
    return v


def _orig_center_local(obj):
    """【原始】网格形心（局部坐标）—— 一旦记录就永不因顶点变形而变。

    用于把**位姿**换算成深度。绝不能用 `_mesh_center_local` 代替：
    后者是「当前顶点形心」，`adapt_object` 会把顶点改写成变形后的局部坐标，
    于是形心跟着漂，深度算错 ⇒ 拖动被锁死在相机前（详见 ORIG_CENTER_KEY 说明）。
    """
    c = obj.get(ORIG_CENTER_KEY)
    if c is not None and len(c) == 3:
        return mathutils.Vector((c[0], c[1], c[2]))
    # 首次：退回当前几何形心（此时尚未变形，等价于原始形心）
    v = _mesh_center_local(obj)
    obj[ORIG_CENTER_KEY] = [v.x, v.y, v.z]
    return v


def _view_depth(view_inv, world_pos):
    """世界点 → 相对相机的深度（正值）。"""
    return -((view_inv @ world_pos).z)


def _depth_mean(base):
    """基准深度列表的平均值 —— 等比拖动的「锚点深度」。

    ★ 为什么是平均值而不是 ref_depth（最深顶点）：
      ref_depth 是**全部网格共享**的视差强度锚点（相机移动时谁完全冻结）。
      拿它当拖动的缩放锚，会变成「拖 1 米 = 按最深层折算的比例」——
      薄的网格被推得过猛、厚的过缓，手感还会随场景里最深的那个网格漂。
      平均值只跟「这个网格自己」有关 ⇒ 拖动手感只取决于它自己。
    """
    if not base:
        return 0.0
    try:
        if _np is not None:
            arr = _np.asarray(base, dtype=_np.float64).reshape(-1, 3)
            return float(arr[:, 2].mean())
    except Exception:
        pass
    try:
        return float(sum(d for (_x, _y, d) in base) / len(base))
    except Exception:
        return 0.0


def _depth_ratio(mean_d, offset):
    """深度平移量 → 统一缩放比 s（等比语义的唯一入口）。

    ★★ 「拖动时贴图不再变形」的关键。两套语义的差别只有一行：

      旧（加法）：dd = d_i + offset
        ⇒ 每个顶点的缩放比 k_i = dd/d_i **各不相同**
        ⇒ 渲染器做透视校正插值时，权重 1/深度 的比例变了
        ⇒ 插出来的 UV 偏了 = **贴图被拉歪**（实测用户工程 0.0054 级）

      新（等比）：dd = d_i * s，s = (mean_d + offset) / mean_d
        ⇒ 所有顶点深度**同比例**变化，权重比恒定
        ⇒ 插值结果与锁定时刻完全一致 ⇒ **贴图零变形**（实测 3e-8）
        ⇒ 屏幕坐标依然严格不变（x·s / z·s = x/z，数学上恒等）

    ⚠️ 等比**不是**新发明的语义 —— 相机推拉（dolly）本来就是等比的
      （实测相机推近时各顶点深度比例极差 6.87e-08）。
      改成等比后，「拖动网格」与「推拉相机」在数学上变成同一种操作，
      插件里只剩一种「改变深度」的方式，不再自相矛盾。
    """
    m = float(mean_d) if mean_d else 0.0
    # ★ 非有限值一律按「无变换」处理（独立审查 2026-10-20）：
    #   旧版没有这一行，一个 NaN 深度会让 m 变 NaN ⇒ s 变 NaN ⇒ dd = d_i*nan
    #   ⇒ **整块网格 25/25 顶点全变 NaN**（加法语义只污染 1 个顶点），
    #   而且会被存进 .blend（reset 也救不回，因为 ORIG_ATTR 在锁定时就已含 NaN）。
    #   k_i = np.where(|d|>MIN, ratio, 1.0) 只兜住「深度太小」，兜不住「ratio 本身是 nan」。
    if not math.isfinite(m) or m <= MIN_DEPTH:
        return 1.0
    off = float(offset)
    if not math.isfinite(off):
        return 1.0
    s = (m + off) / m
    if not math.isfinite(s):
        return 1.0
    if s < 1e-3:
        s = 1e-3            # 防退化：推到/越过相机平面时不许变成 0 或负数（会翻面）
    elif s > 1e6:
        s = 1e6             # 上限：offset=1e100 曾产出 inf 顶点（独立审查 2026-10-20）
    return float(s)


def _mat_close(A, B, eps=MOVE_THRESHOLD):
    for i in range(4):
        for j in range(4):
            if abs(A[i][j] - B[i][j]) > eps:
                return False
    return True


def _read_matrix_key(obj):
    v = obj.get(MATRIX_KEY)
    if not v or len(v) != 16:
        return None
    # ⚠️ 用 `_safe_view_matrix` 兜住「元素被外部改成字符串」——
    #    裸 `mathutils.Vector(v[0:4])` 会抛 `TypeError: ... found 'str'`。
    #    （对象上的自定义属性同样可能被外部工具改坏。）—— 独立审查 第十一轮
    return _safe_view_matrix([v[i * 4:i * 4 + 4] for i in range(4)])


def _write_matrix_key(obj, M):
    obj[MATRIX_KEY] = [float(x) for row in M for x in row]


def _reset_drag_state(obj):
    """把「用户拖动量」归零（offset + 旧比例键）。

    ★ 只在两种地方调用：
      ① 撞墙 / 重锚 —— 那次拖动被判定为无效，留着只会制造矛盾状态
      ② handler 第三步 adapt_object **真的成功**之后（见 pending 流程）

    ⚠️ 绝不能在 apply_user_move 的「位姿回到锁定位姿」分支里直接调 ——
       那个判据是多义的（用户撤销 / 插件撞墙 / 相机飞越 / 父级带回），
       分不清就会把用户的合法调整当残值抹掉。
    """
    try:
        obj[DRAG_OFFSET_KEY] = 0.0
    except Exception:
        pass
    try:
        if DRAG_SCALE_KEY in obj.keys():
            del obj[DRAG_SCALE_KEY]
    except Exception:
        pass


def apply_user_move(obj, camera, view_now):
    """把「用户拖出来的新位置」翻译成视差语义（对齐 PSD 拖图层）。

    `view_now` 必须是【当前】相机的视图矩阵（不是锁定那一刻的）——
    用户是看着当前画面拖的，深度与视线都要按当前相机算。

    推导：要让「屏幕坐标不变 + 深度变 k 倍」同时成立，等价于
    **在相机空间里把整个网格缩放 k 倍** —— 每个顶点沿**自己的视线**移动
    （深的移动多、浅的移动少），即「按视锥体变形」（非刚性）。

    实现要点（性能 + 正确性）：
      · **O(1)**：只改物体位姿 + 一个标量，**不遍历顶点** —— 拖动时每帧都会
        跑到这里，遍历几十万顶点会卡死（用户实测很卡）。
      · **完全不碰 UV**：投影 UV 来自冻结的 `campos` 属性，网格怎么变形都与它无关
        （相机移动时的 adapt_object 也从不动它）。改它会破坏投影 —— 实测踩过。
    返回是否真的处理了。
    """
    if not LAYER_MOVE_ENABLED:
        return False
    # ⚠️ 编辑模式下对 mesh.vertices 的写入会被 Blender 丢弃/回滚，但对 matrix_world
    #    的写入会生效 ⇒ 拖动后得到「顶点没跟、位姿却变了」的不一致状态（静默）。
    #    编辑模式直接不参与（面板 operator 本来就只放行 OBJECT 模式）。—— 独立审查 R12
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    # ★ 与 adapt_object 同一道闸（独立审查 2026-10-20 🟡）：
    #   锁定后才 Alt+D / 加修改器 / 加形态键时，adapt_object 会被守卫挡掉，
    #   但 apply_user_move 原本没有守卫 ⇒ 照样把 offset 写进对象，
    #   而**没有任何一处会消费它**（适配永远不执行）⇒
    #   位姿动了、顶点不动、屏幕偏 25.7px，且松手后也不自愈。
    #   在入口就挡掉，状态根本不会脏。
    if block_reasons(obj):
        return False
    M_prev = _read_matrix_key(obj)
    if M_prev is None:
        _write_matrix_key(obj, obj.matrix_world.copy())      # 首次：只记录基准
        return False
    M_cur = obj.matrix_world.copy()
    if _mat_close(M_cur, M_prev):
        # ★★★ 位姿【回到了锁定位姿】≠「用户按了取消」。这个判据是**多义**的：
        #    能走到这里的原因至少四种 ——
        #      ① 用户 G 之后右键取消 / Ctrl+Z        ← 本该清零
        #      ② 插件自己撞到相机平面时把位姿拉回      ← 绝不能清！
        #      ③ 相机飞越图层平面时 _write_matrix_key 重锚  ← 绝不能清！
        #      ④ 父级空物体 / 骨骼 / 关键帧把位姿带回 ← 绝不能清！
        #
        #    v3.0.2 第一版在这里直接清 offset 并 return True —— 结果 ②③④ 全被
        #    当成 ① ，把用户辛苦调出来的深度整段抹掉。独立审查实测：
        #      · 撞墙后手一停：形变 2.1875 → 0（视觉上物体「啪」地弹回）
        #      · 相机穿过图层再退回来：offset -1.2 → 0（深度调整永久丢失）
        #      · 加修改器时清完失败：几何永久卡在拖动后的形状
        #
        #    正确做法：**这里什么都不做**。清 offset 只能由「用户真的取消了」来触发，
        #    而那件事 Blender 会通过位姿变化告诉我们 —— 但位姿变化也被 ②③④ 复用。
        #    ⇒ 改由 `_pending_zero` 机制在**适配成功之后**落账（见 handler 第三步）。
        #
        #    ⚠️ 那 ①（用户右键取消）怎么办？
        #      位姿回到 M_prev 本帧，offset 仍是旧值 → 几何停在拖动后的位置。
        #      这一步不能直接清，但可以**登记待清**：打一个 PENDING_ZERO 标记，
        #      返回 True 让 handler 把它放进 `moved`，由 handler 用 override=0 试算，
        #      **适配成功后才真正清零**（见 handler 第三步）。
        #
        #      防误触的关键：②③④ 那三种「插件自己把位姿弄回 M_prev」的路径，
        #      都在各自的实现里**同步调 _reset_drag_state 把 offset 归零了**
        #      （撞墙分支、重锚分支）。所以走到这里时如果 offset 还不为 0，
        #      它的来源只可能是「用户拖过、然后位姿被外部还原」—— 就是 ①。
        try:
            # 若上一帧是「重锚」把位姿定到这里的，那不是用户取消 —— 直接放行。
            _re = obj.get(REANCHOR_KEY)
            if _re:
                del obj[REANCHOR_KEY]
                return False
        except Exception:
            pass
        try:
            _stale = _safe_float(obj.get(DRAG_OFFSET_KEY, 0.0), 0.0)
            _legacy = _safe_float(obj.get(DRAG_SCALE_KEY, 1.0), 1.0)
            if abs(_stale) > 1e-9 or abs(_legacy - 1.0) > 1e-9:
                obj[PENDING_ZERO_KEY] = 1
                return True       # 让 handler 用 override=0 试算并落账
        except Exception:
            pass
        return False

    view_inv = view_now.inverted()
    # ⚠️ 必须用【原始】形心：位姿 → 深度的换算不能受顶点变形污染。
    #    用 _mesh_center_local（当前顶点形心）会让 d_cur 越推越"深"，
    #    最后翻负撞上 MIN_DEPTH 保护 ⇒ 拖动被锁死在相机前（用户实测反馈）。
    c_local = _orig_center_local(obj)
    d_prev = _view_depth(view_inv, M_prev @ c_local)
    d_cur = _view_depth(view_inv, M_cur @ c_local)

    if d_prev <= MIN_DEPTH:
        _write_matrix_key(obj, M_cur)          # 基准不可用 → 重新采用当前
        # ★★ 重锚时**保留** offset（独立审查 2026-10-20 🔴 的反面）：
        #    这条路径的典型触发是「相机飞越图层平面」—— 用户的深度调整必须留着
        #    （实测：清了就永久丢失，offset -1.2 → 0，相机退回来也回不去）。
        #    但重锚后 M_prev == M_cur，下一帧会落进「位姿==M_prev 且 offset≠0」
        #    的歧义态 ⇒ 用 REANCHOR_KEY 打一个短命标记，让那个分支知道
        #    「这次回到 M_prev 是重锚造成的，不是用户取消」。
        try:
            obj[REANCHOR_KEY] = 1
        except Exception:
            pass
        return False
    if d_cur <= MIN_DEPTH:
        # 拖到相机后方/平面上：按锁定语义拉回（否则深度翻负会把场景弄坏）。
        # ★★ 这里必须**同时**把拖动量归零（独立审查 2026-10-20 🔴）：
        #    旧版只把位姿拉回、offset 留着。于是这一帧的状态是
        #    「位姿 == M_prev 但 offset ≠ 0」，两个字段互相矛盾 ——
        #    v3.0.2 的位姿判据把这个中间态读成「用户按了取消」，
        #    把用户辛苦推出来的深度整段抹掉（实测：推到贴脸后手一停，形变归零）。
        #    归零之后就不存在这个歧义态，位姿判据也没有被误触的机会。
        #    ⚠️ 语义上也更对：既然撞墙了，这次深度调整就是无效的，不该留着。
        obj.matrix_world = M_prev
        bpy.context.view_layer.update()
        _reset_drag_state(obj)
        return False

    k = d_cur / d_prev
    if abs(k - 1.0) <= 1e-9:
        # 纯横向拖动：深度没变 ⇒ 按锁定语义把网格【拉回原位】（画面里拖不动）。
        # ⚠️ 必须真的拉回：否则用户的横向拖动会"看起来自由"，但之后一动相机
        #    就被抹掉（那正是这个功能要修的毛病）。—— 自测发现
        obj.matrix_world = M_prev
        bpy.context.view_layer.update()
        return False

    # O(1)：只累积「相机空间缩放」标量，**对象位姿一律还原成锁定基准**。
    #
    # ⚠️⚠️ 两个必须一起成立的事实（独立审查 R1 / R8）：
    #  ① `k` **只能记一处**。对象位姿里放一份 Scale(k)、标量里再记一份 —— 那 k 就被
    #     算了两次：位置会互相矛盾（实测对象 scale=2.56 而 drag=1.6），
    #     而且下一轮 `M_prev` 里已含上一轮的 k，k 被反复累乘。
    #  ② 拖动**不该改变对象位姿**。几何由 `adapt_object` 从 base×drag 重算，
    #     位姿只需要保持"锁定时的样子"即可（`mw_inv` 会把它换算回局部）。
    #     原实现把 Scale(k) 写进 matrix_world，于是：
    #       · `reset` 不还原位姿 ⇒ 对象永久变成 k 倍、原点被挪（子物体被一起带走）
    #       · 反复「锁定→拖→重置」**指数累积**（实测 1.6 → 2.56 → 4.096 → 6.5536，
    #         原点跑到 −27.8），用户几乎无法手动救回 —— 唯一会**永久损坏资产**的一条。
    # ⚠️⚠️ `k` 是**相对锁定位姿的绝对倍率**，必须**赋值**，不能累乘。
    #   根因：v2.7.4 为了修「位姿里 Scale(k) 指数累积」，把位姿改成还原 `M_prev`
    #   并**停掉了 `M_prev` 的更新**（见上面 ②）。于是 `d_prev` 恒等于锁定时的深度，
    #   `k = d_cur / d_prev` 每一帧都是「当前相对锁定」的**绝对比**。
    #   而 v2.7.0/v2.7.1 时它确实是增量（那时每帧都 `_write_matrix_key` 更新基准，
    #   累乘恰好 telescoping 收敛），`*= k` 在那时是对的 —— 改语义时漏了这一行。
    #   症状（用户报「移动物体容易飞」）：每帧累乘绝对比 ⇒ 指数放大。
    #   实测连续拖 8 帧（每帧 0.05）：顶点位移 0.05 → 1.80（放大 4.5 倍）。
    #
    # ★ 这里记的是**深度平移量（米）**，不是比例：
    #     offset = d_cur − d_lock
    #   因为 `M_prev` 就是锁定位姿（见上），`d_prev` 恒等于锁定深度，
    #   所以天然是「相对锁定的绝对平移量」，赋值即可，不存在累乘问题。
    #   ⚠️ 注意 offset 只是**输入量**：adapt_object 会再用 _depth_ratio 把它
    #      换算成统一缩放比 s 才作用到顶点（见 DRAG_OFFSET_KEY 的「第 2 层」说明）。
    #      别以为这里是加法就以为顶点也是加法 —— 那个中间态已经废弃了。
    #   同时清掉旧的比例键，避免 adapt_object 的兼容分支又把它折算一遍（双重计算）。
    _new_off = float(d_cur - d_prev)
    # ★★ 「拖动量没变」就直接早退（独立审查 2026-10-20 🟢）：
    #    位姿一旦停在非锁定位姿（用户松手后没动），本函数的 k 每帧都一样，
    #    却照样写属性 + return True ⇒ handler 每帧把它当 moved 重新适配：
    #      实测 5.7 万顶点网格：静止 0.10 ms/帧 → **23.90 ms/帧**，
    #           并且每帧都 save_groups（JSON 序列化 + 写 scene 属性）。
    #    这里：offset 与上次相同 且 位姿也没变 ⇒ 无事可做，返回 False。
    #    ⚠️ 不能靠「更新 MATRIX_KEY」来解决 —— 那会把绝对比变增量、k 累乘
    #       （见本函数下方 2098-2105 行那段踩坑记录）。
    _prev_off = _safe_float(obj.get(DRAG_OFFSET_KEY, 0.0), 0.0)
    if abs(_new_off - _prev_off) <= 1e-9:
        # 拖动量没变：只在位姿确实变了时才需要「跟手」（位姿本身已由用户设定）
        obj.matrix_world = M_cur
        return False
    obj[DRAG_OFFSET_KEY] = _new_off
    try:
        if DRAG_SCALE_KEY in obj.keys():
            del obj[DRAG_SCALE_KEY]
    except Exception:
        pass
    # ★★ 位姿【跟手】，不再还原成 M_prev（用户实测反馈「第二次拖动会跳回原位」）。
    #
    #   为什么必须跟手：位姿和顶点几何必须表达**同一个位置**。
    #   旧实现把位姿还原成锁定位姿、只让顶点变形 ⇒ 视觉上网格在 Z=1.5，
    #   而 `matrix_world.translation` 还停在 Z=0。用户松手再拖时，Blender 从
    #   **位姿**起算，网格「啪」地跳回原始位置，然后才能继续移动 —— 拖拽不连续。
    #   实测：第一次推近 1.5 → 位姿 Z=0.0000 但顶点世界 Z=1.5000（分离 1.5）；
    #         第二次再推 0.1 → 位姿被还原到 0.0000，顶点跳到 0.1000。
    #
    #   为什么之前（v2.7.4）要还原：那时把 `Scale(k)` 写进位姿，导致
    #   「锁定→拖→重置」指数累积、对象永久变大（唯一会不可逆损坏资产的一条）。
    #   现在位姿只做**平移**（不写 Scale），且 reset 会还原位姿，所以没有那个风险。
    #
    #   ⚠️ adapt_object 不受影响：它用 `matrix_world.inverted() @ view_now` 反算
    #      局部坐标，顶点最终仍落在「base + offset」对应的世界位置 ——
    #      位姿怎么动都不改变顶点世界坐标（实测屏幕投影变化 0）。
    obj.matrix_world = M_cur
    bpy.context.view_layer.update()
    return True


def recompute_ref_depth(scene, st, cam_data_name=None):
    """重算基准深度 = 所有锁定网格里【最深顶点】的深度。

    ⚠️ 调用时机（2026-10-20 对齐 PSD 后定稿）——只有两处，别加第三处：
      ① `lock_group`：锁定 / 相机构成变了时；
      ② handler 第三步，且**必须在 `if cam_changed:` 里面**（相机变化时才适配）。
    **绝不能在「用户拖动后」当帧调用** —— 那样会让没被拖动的网格当帧就跳。

    —— 2026-10-20 更正（用户实测：拖 A 会带动 B）：
    旧版这里写着「拖动改变了深度 ⇒ 基准层可能换人 ⇒ 必须重算」。这是错的。
    `ref_depth` 是**全部网格共享**的适配基准（`kk = dd/ref_depth`，kk==1 那层完全
    冻结、更浅的层滑动 = 视差），它就是「锁定那一刻的构图锚点」。
    用户拖 A 只是在调整 A 自己的深度（PSD 拖图层语义），锚点不该跟着漂：
      · 锚点一漂，所有网格的 kk 同时变 ⇒ 别的网格在画面上动
      · 而且「换人」是**离散事件** ⇒ 表现为无法复现的跳变
    实测（A 深度8 / B 深度6，共用投影材质，移相机后拖 A）：
      拖 A +1.0 → ref 8.0→7.0，B 顶点世界坐标变化 0.12857145
      拖 A -1.0 → ref 8.0→9.0，B 顶点世界坐标变化 0.10000014
      拖 B +1.0 → ref 8.0→8.0（不换人），A 变化 0.00000000
    拖动时不重算 ⇒ 三种情形「另一网格」变化全部 0.00000000。
    要换锚点，应该让用户重新锁定（重置后再锁）。
    """
    best = 0.0
    if cam_data_name:
        _objs = locked_objects(scene, cam_data_name, st)     # 反向索引（不怕重命名）
    else:
        _objs = [scene.objects.get(n) for n in (st.get("objects") or [])]
    for o in _objs:
        if o is None or o.type != "MESH" or o.data is None:
            continue
        if len(o.data.vertices) == 0:      # 0 顶点：max() 会抛 ValueError —— 独立审查 R3
            continue
        b = _read_base_attribute(o)
        if not b:
            continue
        # 拖动改过深度，要算进去。
        # ★★ 等比语义（2026-10-20）：最远顶点深度 = d_max × ratio，**不是** d_max + offset。
        #    必须跟 adapt_object 用同一把尺子 —— 两处语义不一致的话，
        #    拖动后移相机会按错误的基准算 kk ⇒ 构图不再冻结。
        _off = _safe_float(o.get(DRAG_OFFSET_KEY, 0.0), 0.0)
        _dmax_probe = max(d for (_x, _y, d) in b)
        if abs(_off) <= 1e-12:
            _lg = _safe_float(o.get(DRAG_SCALE_KEY, 1.0), 1.0)
            _off = (_lg - 1.0) * _dmax_probe if abs(_lg - 1.0) > 1e-9 else 0.0
        # ★★ 这里**不用** _depth_ratio（独立审查 2026-10-20 🔴，事故级）：
        #    _depth_ratio 会把 s 钳到 1e-3 防翻面。而 ref 是「基准深度」，
        #    它一旦被钳成 1e-3·dmax，就会落到**任何一次正常运镜步长之下**：
        #      用户把图层推到贴脸（s 撞到 0.001）→ ref = 0.006
        #      相机前进 0.05 → adapt 里 dolly=(ref−axial)/ref 变负
        #      → max(dolly, MIN_DEPTH)=1e-4 → **整块网格深度 ×1e-4**
        #      实测：屏幕尺寸 0.463 → 27.74（放大 59.9 倍），且写进 .blend。
        #    钳位是给「几何不许翻面」用的，不是给「基准」用的 ——
        #    基准要的是**真实**深度，翻面由 adapt 里的 max(..., MIN_DEPTH) 兜。
        #    所以这里用未钳的原始比例，只在退化时退回 1.0。
        _mean_d = _depth_mean(b)
        if _mean_d > MIN_DEPTH and math.isfinite(_mean_d) and math.isfinite(_off):
            _s_raw = (_mean_d + _off) / _mean_d
        else:
            _s_raw = 1.0
        if not math.isfinite(_s_raw) or _s_raw <= 0.0:
            _s_raw = 1.0
        m = _dmax_probe * _s_raw
        if m > best and math.isfinite(m):
            best = m
    # ★ 保险丝（独立审查 2026-10-20）：ref 相对上一帧变化 >10 倍时**拒绝写入**。
    #   正常场景里 ref 只会随构图缓慢变化；骤变 10 倍一定是算错了。
    #   宁可这帧沿用旧值（画面偏一点），也不能把 1e-4 量级的坏基准写进 .blend。
    if best > MIN_DEPTH:
        _old = _safe_float(st.get("ref_depth", 0.0), 0.0)
        _ok = True
        if _old > MIN_DEPTH:
            _ratio = best / _old
            if _ratio > 10.0 or _ratio < 0.1:
                _ok = False
        if _ok:
            st["ref_depth"] = float(best)
        else:
            best = _old          # 沿用旧值
    return _safe_float(st.get("ref_depth", 0.0))


# ──────────────────────────── 核心：适配 ────────────────────────────

def adapt_object(obj, camera, state, view_now=None, drag_override=None):
    """逐顶点适配。

    drag_override: 若给定，用它替代 obj[DRAG_OFFSET_KEY] 作为本轮拖动量。
        ★ 用途（独立审查 2026-10-20）：用户 G 后右键取消时，要先用 offset=0
          试算一次几何 —— **但此时还不能把 offset 写回 0**。如果这次适配因为
          「编辑模式 / 带修改器 / base 缺失」被闸门挡掉返回 False，写回 0 会让
          几何永久卡在拖动后的形状（实测：加修改器后形变 0.3750 卡死 60 帧）。
          正确顺序是：用 override 试算 → 成功才落账清零。
    """
    base = _read_base_attribute(obj)
    if base is None:
        return False
    # ⚠️ 编辑模式下写顶点会被回滚 ⇒ 跳过（否则位姿/属性会与几何不一致）。—— 独立审查 R12
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    # ⚠️ 修改器 / 形态键守卫（独立审查 第六轮 🟡-3）：`lock_group` 的 targets 筛过一次，
    #    但**锁定之后**才加上的修改器不在那份名单里 —— 不在这里挡，就会在
    #    「修改器算出来的形状」上再叠一层逐顶点改写（**双重变形**），且毫无提示。
    if has_modifier_or_shapekey(obj) is not None:
        return False
    if view_now is None:
        view_now = get_camera_view_matrix(camera)
    # ⚠️ 一律 .get() + 兜底：硬取 state["..."] 在旧存档 / 坏数据下抛 KeyError，
    #    等于把该相机整轮跳过（本来能做部分工作的）。—— 独立审查 F2
    # ⚠️ 这是**第 4 处**同样的解析 —— 我第一轮修的时候**没找到它**：
    #   因为我用变量名 `lm` 去搜，而这里叫 `_lm`。**按变量名搜会漏，要按调用形态搜。**
    #   （又印证「修一类问题时，要问还有几条路能到同一个地方」；而且这次我是
    #     在刚写完这条教训之后立刻又犯的。）—— 独立审查 第十一轮
    view_locked = _safe_view_matrix(state.get("locked_matrix"))
    if view_locked is None:
        return False
    ref_depth = _safe_float(state.get("ref_depth", 0.0))
    focal_locked = _safe_float(state.get("locked_focal", 0.0)) or MIN_DEPTH

    focal_now = camera.data.lens
    zoom = (focal_now / focal_locked) if focal_locked > MIN_DEPTH else 1.0
    zoom = max(zoom, MIN_DEPTH)

    # ⚠️ 归因：变焦时自动施加给相机的那段 dolly 必须【排除】在相机位移之外，
    #    否则它会和 zoom 重复计算（depth 变成 d·k²）。
    eye_now = view_now.translation
    # ⚠️ 用【实际已施加的】dolly 位移，不能用 auto_dolly_vector（那是按当前 ref 算的目标值）——
    #    ref_depth 被拖动改写后，按目标值减会凭空多出一段位移，构图不再冻结。—— 独立审查 F1
    # ★ 从【相机上的持久记账】推导，而不是 state 里那份副本 ——
    #   复制场景时 state 有两份而相机只有一个，用副本会重复归因（dolly 翻倍）。
    _applied = _state_applied_dolly(camera, state)
    eye_user = eye_now - _applied

    cur_rot = view_now.to_3x3()
    eye_delta = eye_user - view_locked.translation
    delta_cs = cur_rot.transposed() @ eye_delta

    axis0 = view_locked.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))
    axial = eye_delta.dot(axis0)
    dolly = (ref_depth - axial) / ref_depth if ref_depth > MIN_DEPTH else 1.0
    # ★★ dolly 下限保护（独立审查 2026-10-20 🔴，事故级）：
    #    原本只有 max(dolly, MIN_DEPTH)，等于「相机走过整个基准深度时，
    #    所有顶点深度被压成 1e-4」—— 实测屏幕尺寸 0.463 → 27.74（放大 60 倍）。
    #    正常场景 ref 是几米、相机一步是几厘米，不会触发；
    #    但基准一旦被算成「比位移还小」（见 recompute_ref_depth 的钳位事故），
    #    这个除法的结果就是灾难。
    #    这里加一道闸：dolly 掉到 1e-2 以下说明「基准与位移不自洽」，
    #    本帧**不缩放**（dolly=1），宁可画面偏一点，也不能把几何压扁。
    if not (dolly > 1e-2):
        dolly = 1.0
    elif dolly > 1e6:
        dolly = 1e6

    # 用户拖动累积的「相机空间深度平移量」（拖动时记录，见 apply_user_move）
    #
    # ★★ 语义演进（两轮，务必按顺序读完再看代码）：
    #
    #   第一轮（2026-10-19）改的是「怎么记」：
    #     原来是每个顶点 dd = d_i * drag（全局比例）—— 深度跨度被改变。
    #     改成「深度统一平移」dd = d_i + offset，每个顶点再用 k_i = dd/d_i
    #     各自补偿 x/y ⇒ 屏幕坐标不变，且拖动量直接等于米数（手感直觉）。
    #
    #   第二轮（2026-10-20，用户实测「拖动时贴图被压歪」）改的是「怎么算」：
    #     加法虽然让「拖 1 米 = 1 米」很直观，但各顶点的深度缩放比 k_i 互不相同
    #     ⇒ 渲染器透视校正插值的权重（1/当前深度）比例变了 ⇒ 插出来的 UV 偏了
    #     ⇒ **贴图被拉歪**（实测用户工程 0.0054，且移相机后仍是歪的）。
    #     改成等比 dd = d_i * _ratio（所有顶点同一个 s）⇒ 权重比恒定
    #     ⇒ 插值与锁定时刻完全一致 ⇒ **贴图零变形**（实测 3e-8）。
    #
    #     ⚠️ 等比后 offset 仍然代表「用户拖了多远」，只是它先被换算成统一的 s
    #        （见 _depth_ratio）。换算锚点是**本网格自己的平均深度**，
    #        不是共享的 ref_depth —— 否则拖动手感会随场景里最深的网格漂。
    #
    # ⚠️ 兼容旧资产：老对象上只有 DRAG_SCALE_KEY（比例），没有 offset 属性。
    #    按「最远顶点」反推平移量：d_max·drag = d_max + offset ⇒ offset = d_max·(drag−1)。
    #    ref_depth 就是最远顶点深度，所以直接 (drag−1)·ref_depth。
    if drag_override is not None:
        offset = _safe_float(drag_override, 0.0)
    else:
        offset = _safe_float(obj.get(DRAG_OFFSET_KEY, 0.0), 0.0)
    if abs(offset) <= 1e-12:
        _legacy_drag = _safe_float(obj.get(DRAG_SCALE_KEY, 1.0), 1.0)
        if abs(_legacy_drag - 1.0) > 1e-9 and ref_depth > MIN_DEPTH:
            offset = (_legacy_drag - 1.0) * ref_depth
    # ★★ 等比语义（2026-10-20）：把「深度平移量 offset」换成「统一缩放比 _ratio」。
    #    offset 仍然是用户拖了多远（米），_ratio 是它在这个网格上的等比表达。
    #    锚点用**本网格自己的平均深度**（_depth_mean），不用共享的 ref_depth ——
    #    理由见 _depth_mean 的说明。
    _ratio = _depth_ratio(_depth_mean(base), offset)

    mesh = obj.data
    # ⚠️ 性能（独立审查 第三轮 F9）：原实现每个顶点做**两次** mathutils 4×4 矩阵乘法
    #    （`view_now @ v` 然后 `mw_inv @ ...`）。实测 40k 顶点 ≈ 24.6 ms/帧 ——
    #    而这正是用户最常做的事（运镜）。两处优化，数学完全不变：
    #      ① 把 `mw_inv @ view_now` 合并成一个矩阵（循环外只算一次）；
    #      ② 用 numpy 向量化（Blender 自带 numpy），整批顶点一次算完。
    #    不可用时回退纯 Python（保证正确性不受环境影响）。
    _M = obj.matrix_world.inverted() @ view_now      # 相机空间 → 物体局部（一次算好）
    n_vert = len(mesh.vertices)
    if _np is not None and n_vert > 0:
        arr = _np.asarray(base, dtype=_np.float64).reshape(-1, 3)
        d_base = arr[:, 2]
        # ★★ 等比语义（2026-10-20 用户实测：拖动时贴图被压歪）：
        #    dd = d_i * _ratio，所有顶点同比例 —— 不再逐顶点各加 offset。
        #    加法会让各顶点缩放比不同 ⇒ 透视插值权重比变了 ⇒ UV 插错 ⇒ 贴图变形。
        #    详见 _depth_ratio 的说明。
        dd = d_base * _ratio
        _safe_d = _np.where(_np.abs(d_base) > MIN_DEPTH, d_base, MIN_DEPTH)
        k_i = _np.where(_np.abs(d_base) > MIN_DEPTH, _ratio, 1.0)
        xd = arr[:, 0] * k_i
        yd = arr[:, 1] * k_i
        kk = (dd / ref_depth) if ref_depth > MIN_DEPTH else _np.ones_like(dd)
        depth = _np.maximum(dd * dolly * zoom, MIN_DEPTH)
        cam = _np.empty((arr.shape[0], 4), dtype=_np.float64)
        cam[:, 0] = xd - delta_cs.x * kk * SCROLL_SCALE
        cam[:, 1] = yd - delta_cs.y * kk * SCROLL_SCALE
        cam[:, 2] = -depth
        cam[:, 3] = 1.0
        local = cam @ _np.array(_M, dtype=_np.float64).T      # (N,4) @ (4,4)
        mesh.vertices.foreach_set("co", _np.ascontiguousarray(local[:, :3]).ravel())
    else:
        flat = []
        ap = flat.append
        for (x0, y0, d) in base:
            # ★★ 等比语义（同 numpy 分支）：所有顶点乘同一个 s
            dd = d * _ratio
            _sd = d if abs(d) > MIN_DEPTH else MIN_DEPTH
            k_i = _ratio if abs(d) > MIN_DEPTH else 1.0
            xd = x0 * k_i
            yd = y0 * k_i
            k = (dd / ref_depth) if ref_depth > MIN_DEPTH else 1.0
            depth = max(dd * dolly * zoom, MIN_DEPTH)
            # ⚠️ 直接乘 _M（= mw_inv @ view_now），**不要再单独乘 view_now** ——
            #    _M 里已经含了 view_now，再乘一次就是 view_now 作用两遍（实测位移翻倍）。
            co = _M @ mathutils.Vector(
                (xd - delta_cs.x * k * SCROLL_SCALE,
                 yd - delta_cs.y * k * SCROLL_SCALE,
                 -depth))
            ap(co.x); ap(co.y); ap(co.z)
        mesh.vertices.foreach_set("co", flat)
    mesh.update()
    # ⚠️ 顶点被改了 ⇒ 局部形心缓存失效（下次拖动要重算）
    try:
        del obj[CENTER_KEY]
    except Exception:
        pass
    return True


# ──────────────────────────── 锁定 / 解锁 / 重置 ────────────────────────────

def lock_group(scene, camera):
    # ★ 先做「身份自愈迁移」：相机数据块被改过名时，把挂在旧名下的资产
    #   （UV Adjust 组名 / OBJ_CAM_KEY / 冻结坐标属性名 / Camera Project 组名）
    #   迁到新名下。**必须在 `get_lock_targets` 之前** ——
    #   而 `get_lock_targets` 正是靠 UV Adjust 组名里的相机数据名来检索的。
    #   （我第一版把它放在后面，于是「改名 → 解锁 → 再锁定」仍然失败：
    #     第一行查不到网格就先 return 了，迁移根本来不及生效。）—— 独立审查 第七轮 🔴 F-1
    _resolve_state(scene, camera)
    targets = get_lock_targets(scene, camera)

    # ⚠️ 取【并集】：`get_lock_targets` 靠 UV Adjust 组名里的 `obj.data.name` 反查，
    #    而用户/Blender 改了 mesh **数据名**（复制物体、重命名数据块、同名加后缀）后
    #    那个名字就对不上了 ⇒ 重新锁定时该网格被**静默丢出锁定集**
    #    （面板仍显示"已锁定"，但它不再受保护）。—— 独立审查 R4
    #    反向索引 `OBJ_CAM_KEY` 跟着对象走，不受名字影响，并进来兜住这些对象。
    _seen = {o.as_pointer() for o in targets}
    for o in bpy.data.objects:
        if o.type != "MESH" or o.data is None:
            continue
        try:
            if o.get(OBJ_CAM_KEY) == camera.data.name and o.as_pointer() not in _seen:
                _seen.add(o.as_pointer())
                targets.append(o)
        except Exception:
            continue

    if not targets:
        # ⚠️ 消息要点出最可能的真实原因（独立审查 第七轮 🔴 F-1）：
        #    相机数据块被改过名时，UV Adjust 组名里嵌的还是旧名，于是这里一个也找不到。
        #    原来只报"没有带投射 UV 的网格"，把用户引向完全错误的方向。
        _hint = ""
        try:
            _orphanish = [o for o in bpy.data.objects
                          if o.type == "MESH" and o.data is not None
                          and o.get(OBJ_CAM_KEY) not in (None, camera.data.name)]
            if _orphanish:
                _hint = ("；提示：有 %d 个网格挂在本相机【旧数据名】「%s」下"
                         "（相机数据块被改过名？）" % (len(_orphanish),
                                                  _orphanish[0].get(OBJ_CAM_KEY)))
        except Exception:
            pass
        return {"success": False,
                "message": "该相机下没有带投射 UV 的网格" + _hint,
                "locked": [], "skipped": [], "frozen": False, "unsupported": []}

    view = get_camera_view_matrix(camera)
    # ★★ 相机矩阵不可逆时必须**返回失败结果**，不能抛异常（独立审查 2026-10-20）：
    #    相机 scale 为 0（动画收缩到 0 / 误输入 / 驱动器把它推成 0）时，
    #    `matrix_world.inverted()` 抛 ValueError("matrix does not have an inverse")，
    #    而 lock_group 的调用方（操作符 execute）没有 try ⇒ 用户看到的是
    #    Python 报错栈，而不是一句"为什么锁不上"。
    try:
        view_inv = view.inverted()
        mw_inv_cam = camera.matrix_world.inverted()
    except Exception as _e:
        return {"success": False,
                "message": "相机矩阵不可逆（scale 为 0？）—— 请先修好相机的变换再锁定",
                "locked": [], "skipped": [], "frozen": False, "unsupported": []}

    # ★★ 互斥「接管」：必须在**第一遍扫之前**把归别的相机的对象几何还原成原形
    #   （独立审查 第九轮 🟡 F-2）。
    #   否则：第一遍扫会把【已被旧相机适配变形】的顶点当成基准采集（`per_obj_cam_space`），
    #   而下面 ① 又把那份 base 写进 `BASE_ATTR`；接着互斥迁移才把几何还原 ⇒
    #   **base 与实际几何不是同一把尺子**（复现：几何 = 原形 (−2.0,…)，base 反算 = 旧相机
    #   变形态 (−0.667,…)）。用户一动新相机，handler 按 base 重算 ⇒
    #   网格**瞬间跳回旧相机适配出的形状**（实测世界位移跳变 1.34、渲染像素差 18.86），
    #   而 UI 全程 🔒、不会报错 —— 用户只看到画面莫名跳了一下。
    try:
        _pre = load_groups(scene)
        _restored_any = False
        for _obj in targets:
            try:
                _prev = _obj.get(OBJ_CAM_KEY)
            except Exception:
                _prev = None
            if _prev and _prev != camera.data.name:
                _old = _pre.get(_prev)
                if isinstance(_old, dict):
                    if _restore_geometry(_obj, _old):
                        _restored_any = True
        # ⚠️ 只有**真的还原过**才 update（独立审查 第九轮 F-2 的修复，自查修正）：
        #   我第一版无条件调用 `view_layer.update()` —— 它在「无跨相机接管」的常见路径上
        #   也执行，等于在 `lock_group` 开头**插了一次额外的依赖图求值**，
        #   而 `depsgraph_update_post` 上挂着本插件的 handler ⇒ 会在 `lock_group`
        #   执行到一半时**先跑一轮适配**（用上一次锁定的 state），
        #   把几何改成"按旧 state 适配后的形状"，随后 lock_group 又拿它当基准
        #   ⇒ 「锁定→旋转→再锁定→变焦」的构图冻结被破坏（实测屏幕位移 0.49）。
        #   回归网 `test_parallax_lock.py`（最老的核心测试）当场抓到。
        if _restored_any:
            bpy.context.view_layer.update()
    except Exception:
        pass

    # ⚠️ 两遍扫：第一遍只做「能不能锁」的判断，第二遍才从【确认锁定】的对象里求 ref_depth。
    #    不能边扫边累加 —— 一个对象若中途因「顶点在相机后方」被 break 跳过，
    #    它之前那个极深的顶点已经把 ref_depth 抬上去了，而且拿不回来
    #    ⇒ 基准深度偏大 ⇒ 全场景滚动速度算错（k = depth/ref_depth 全偏小）。
    #    是否发生还取决于顶点顺序，不可预测。—— 独立审查 F9
    locked, skipped = [], []
    per_obj_cam_space = {}
    for obj in targets:
        reason = has_modifier_or_shapekey(obj)
        if reason:
            skipped.append((obj, reason))
            continue
        # ⚠️ 0 顶点网格：cs_list 会是空的，下面的 max() 会抛 ValueError
        #    （用户点一次锁定就报错、什么也没锁上）。—— 独立审查 R3
        if len(obj.data.vertices) == 0:
            skipped.append((obj, "空网格（无顶点）"))
            continue
        mw = obj.matrix_world
        cs_list = []
        ok = True
        for v in obj.data.vertices:
            cs = view_inv @ (mw @ v.co)
            depth = -cs.z
            if depth <= MIN_DEPTH:
                ok = False
                break
            cs_list.append((cs.x, cs.y, depth))
        if not ok:
            skipped.append((obj, "顶点在相机后方"))
            continue
        per_obj_cam_space[obj.name] = cs_list
        locked.append(obj)

    # 第二遍：基准深度 = 只从【确认锁定】的对象里取最深顶点
    ref_depth = 0.0
    for _name in per_obj_cam_space:
        _m = max(d for (_x, _y, d) in per_obj_cam_space[_name])
        if _m > ref_depth:
            ref_depth = _m

    if not locked:
        # 把真原因并进 message（原来写死成"修改器/形态键"，会把"顶点在相机后方"
        # 等其它原因也误报成修改器问题）—— 独立审查 S4
        reasons = []
        for _o, _r in skipped:
            if _r not in reasons:
                reasons.append(_r)
        detail = ("（原因：" + "、".join(reasons) + "）") if reasons else ""
        # ⚠️ 提前 return 也要带 `frozen` / `unsupported`（独立审查 第五轮 🔴-3）：
        #    以前这条路径只有 locked/skipped，调用方拿不到「图案到底冻没冻」。
        #    更关键的是**消息里必须点明图案不会冻结** —— 共享网格（Alt+D）时
        #    所有目标在第一阶段就出局，用户看到的只是一句"没有可锁定的网格"，
        #    完全不知道"图案会继续随相机滑动"。CHANGELOG 2.7.4 承诺过要报出来。
        _unsup = [((o.name if o is not None else "<场景>"), w) for o, w in skipped]
        return {"success": False,
                "message": ("没有可锁定的网格" + detail +
                            "；⚠️ 图案不会冻结 —— 投影将继续随相机滑动"),
                "locked": [], "skipped": skipped,
                "frozen": False, "unsupported": _unsup}
    if ref_depth <= MIN_DEPTH:
        return {"success": False, "message": "基准深度异常（网格可能在相机后方）；"
                "⚠️ 图案不会冻结 —— 投影将继续随相机滑动",
                "locked": [], "skipped": skipped,
                "frozen": False,
                "unsupported": [((o.name if o is not None else "<场景>"), w)
                                for o, w in skipped]}

    cam_data_name = camera.data.name
    # （身份自愈迁移已在函数开头做过 —— 见那里的注释，必须在 get_lock_targets 之前。）

    # 多相机互斥
    groups = load_groups(scene)
    _migrated_from = set()
    for obj in locked:
        prev = obj.get(OBJ_CAM_KEY)
        if prev and prev != cam_data_name:
            old = groups.get(prev)
            if old:
                # ★ 迁移【之前】先按旧相机的基准把几何还原（独立审查 第五轮 🔴-2）：
                #   否则该对象永远停在「被旧相机适配后」的形状 —— 因为下面一行就把
                #   OBJ_CAM_KEY 改成新相机了，`reset_group(旧相机)` 再也枚举不到它，
                #   而几何变形却留在原地 ⇒ **不可逆**；更糟的是 reset 会返回
                #   `success=True` 且「已重置 0 个网格」——用户以为重置过了。
                #   （几何还原已在函数开头统一做过 —— 必须在第一遍扫之前，
                #     否则 base 会与实际几何错位，见那里的说明。）—— 第九轮 F-2
                old["objects"] = [n for n in old.get("objects", []) if n != obj.name]
                # ⚠️ 成员变了 ⇒ 基准深度可能换人，记下来，等下面把 OBJ_CAM_KEY 更新完
                #    再重算（现在还算不出正确结果：被抢走的对象此刻仍挂着自己）。
                #    不重算的话，剩下的网格会按「已不属于自己」的成员算滚动速度
                #    （实测被抢走最深成员后，滚动慢 7/5 = 1.4 倍，且没有任何提示）。—— 独立审查 R17
                _migrated_from.add(prev)
                groups[prev] = old
                if not old["objects"]:
                    # 该相机已无任何网格 → 才撤补丁 + 关锁定。
                    # ⚠️ 必须判空：若它还留着别的网格，撤补丁会让那些网格的图案冻结
                    #    一起失效（组是共享的）。—— 独立审查 S2
                    old["enabled"] = False
                    unpatch_camera_project_group(prev)

    # ① 变形基准
    for obj in locked:
        # ★ 首次锁定记录「原形」（已有则保留，绝不覆盖）—— 让 reset 永远能回到
        #   真正的原始形状，不受「解锁 → 再锁定」影响。—— 独立审查 第五轮 🔴-1
        _write_orig_attribute(obj)
        _write_base_attribute(obj, per_obj_cam_space[obj.name])
        _write_matrix_key(obj, obj.matrix_world.copy())   # 拖动检测的「上次正确位姿」
        obj[DRAG_SCALE_KEY] = 1.0                          # 旧比例键归 1（兼容）
        obj[DRAG_OFFSET_KEY] = 0.0                         # ★ 深度平移量归 0
        obj[CENTER_KEY] = [c for c in _mesh_center_local(obj)]  # 顺便把形心缓存填上
        # ★ 原始形心：只在没有时记录（已有则保留），供「位姿 → 深度」换算使用。
        #   绝不能跟着 adapt_object 的形心一起失效 —— 否则拖动深度会被变形污染。
        if ORIG_CENTER_KEY not in obj.keys():
            _oc = _mesh_center_local(obj)
            obj[ORIG_CENTER_KEY] = [_oc.x, _oc.y, _oc.z]
        obj[OBJ_CAM_KEY] = cam_data_name

    # ⚠️ 互斥迁移后：被抢走的相机剩下的网格要重算基准深度 + 让视图缓存失效
    #    （必须等上面 OBJ_CAM_KEY 全部更新完才算得对）。—— 独立审查 R17
    for prev in _migrated_from:
        old = groups.get(prev)
        if old and old.get("objects"):
            recompute_ref_depth(scene, old, prev)
        _last_view.pop((scene.as_pointer(), prev), None)

    # ② 图案冻结：给所有用该投影材质的网格写"冻结坐标" + 打组补丁
    #    （并上 locked —— 二者判定口径不同，取并集才不漏）
    _frozen_targets = list(objects_using_projection(cam_data_name))
    _seen = {o.as_pointer() for o in _frozen_targets}
    for o in locked:
        if o.as_pointer() not in _seen:
            _frozen_targets.append(o)
    # ⚠️ 投影组是【共享 datablock】，补丁一打就影响所有引用它的 mesh（独立审查 R7）。
    #    而「冻结坐标」是挂在 **mesh data** 上的属性 —— 共享网格（Alt+D）物理上
    #    无法同时为多个对象各存一份。若其中有对象无法提供冻结坐标：
    #      · 原实现：照样写（用**某一个**对象的世界位置算）⇒ 另一个对象投影静默错位
    #        （实测 DUP 偏差 4.0 单位），且 skipped 里只说"共享网格"、用户看不出。
    #      · 现在：**宁可不打补丁**（图案照旧滑动 = 看得见的旧行为），并把它报出来。
    #        「看得见的失败」永远优于「看不见的错」。
    _unsupported = []
    _out_of_scene = []
    # ⚠️ 投影组不存在 = 补丁无处可打 = 图案根本不会冻结（独立审查 第三轮 F3）。
    #    原实现只看「对象能否提供冻结坐标」，不看组在不在 ⇒ 没有投影组时
    #    `patch_camera_project_group` 静默 return None，而这里仍报 frozen=True、
    #    消息一句干净的"已锁定" —— 正是反复在修的「看着成功其实没生效」。
    if bpy.data.node_groups.get(CAM_PROJECT_PREFIX + cam_data_name) is None:
        _unsupported.append((None, "该相机还没有 Camera Project 投影组（图案无法冻结）"))
    # ⚠️ 冻结坐标属性挂在 mesh data 上、补丁是全局的，所以写入要覆盖所有场景；
    #    但「能不能冻结」的判定**只看本场景**（独立审查 第三轮 F6）——
    #    否则别的场景里一个带修改器的网格会让**当前场景**的图案冻结整体失效，
    #    用户看着莫名其妙的失败。（他场景的对象照样尽力写坐标，只是不阻塞。）
    _in_scene = {o.as_pointer() for o in scene.objects}
    for _o in _frozen_targets:
        if _o is None:
            continue
        # ★★ 空网格（0 顶点）**不该全局禁用图案冻结**（独立审查 2026-10-20）：
        #    它没有顶点 ⇒ 本就没有图案 ⇒ 补丁对它毫无影响。
        #    原实现把它算进 `_unsupported`，而 `_frozen_ok = not _unsupported`
        #    是全局开关 ⇒ 场景里只要有一个 0 顶点的网格挂着投影材质，
        #    同一相机的**所有其他正常网格**都会失去冻结。
        #    实测：GridA 正常 + GridB 清空顶点 → 再锁定 frozen=False、
        #    GridA 的 campos 根本不存在，图案整体不再冻结。
        #    第一阶段（能不能锁）已经把它记进 skipped 了，这里跳过即可。
        if len(_o.data.vertices) == 0:
            continue
        _why = has_modifier_or_shapekey(_o)
        if not _why:
            continue
        if _o.as_pointer() in _in_scene:
            _unsupported.append((_o, _why))
        else:
            _out_of_scene.append((_o, _why))
    _frozen_ok = not _unsupported
    # ⚠️ 判据用「冻结坐标属性是否仍然有效」而不是「补丁是否在」（独立审查 第三轮 F7）：
    #    投影组被外部重新生成后补丁没了，但 meshes 上的冻结坐标属性还**好好地在**。
    #    此时若判成"全新锁定"就会按当前世界位置**重算**坐标 ⇒ 图案跳变（违反 P14）。
    #    用属性有效做判据，就能做到「自愈重打补丁但画面不动」。
    _keep_existing = bool(_frozen_ok) and any(
        _campos_is_valid(o, cam_data_name) for o in _frozen_targets if o is not None)
    # ★★ 重锁语义：冻结的是「用户此刻看到的样子」。
    #    如果这个相机此前「落实过构图」（S≠1 或 C≠0），把那份 C/k 并进冻结坐标，
    #    否则重锁那一帧图案会跳（实测 Δ=0.400000，正好等于 C）。
    #    ⚠️ 必须在 `_ensure_delta_group` 之前读 —— 重建组会把 C/k 复位。
    _pre_s, _pre_c = 1.0, (0.0, 0.0)
    _nodes_prev = _find_delta_nodes(cam_data_name)
    if _nodes_prev is not None:
        try:
            _s_prev = float(_nodes_prev[0].inputs["Scale"].default_value)
            _c_prev = tuple(_nodes_prev[1].inputs[1].default_value)[:2]
            if abs(_s_prev - 1.0) > 1e-12 or abs(_c_prev[0]) > 1e-12 or abs(_c_prev[1]) > 1e-12:
                _pre_s, _pre_c = _s_prev, (_c_prev[0], _c_prev[1])
        except Exception:
            pass

    # ★★ 锁定前确保投影组带 C+k 链（旧工程保存的组没有）。
    #    必须在 patch 之前 —— 重建组会让补丁失效。
    _dk_ok = _ensure_delta_group(camera)
    if _frozen_ok:
        for obj in _frozen_targets:
            # 旧版逐顶点偏移属性是垃圾数据（与新版组不配套），一律清掉。
            clear_legacy_delta(obj)
            if _keep_existing and _campos_is_valid(obj, cam_data_name):
                continue
            _write_campos_attribute(obj, camera, cam_data_name, mw_inv_cam,
                                    pre_scale=_pre_s, pre_offset=_pre_c)
        patch_camera_project_group(cam_data_name)
    # ★★ 锁定期间 S = 1、C = 0 ⇒ 恒等变换，主链输出与旧版完全一致。
    if _dk_ok:
        write_identity_delta(cam_data_name)

    groups[cam_data_name] = {
        "enabled": True,
        "ref_depth": ref_depth,
        "locked_matrix": [[float(x) for x in row] for row in view],
        "locked_focal": float(camera.data.lens),
        # ★ 锁定时刻的 zoom 因子与镜头位移 —— 解锁算落实施量要用。
        #   （独立审查 R14 曾把 locked_sensor_w/h 当死数据删掉，因为它们当时
        #    **只写不读**；现在它们真的被读了：投影组的 Z = lens / sensor_width，
        #    而 shift 是在 Z 之后的加法。用户实测：锁定期间只改 sensor_width
        #    解锁跳 0.093、只改 shift_x 跳 0.038 —— 就是漏了这两项。）
        "locked_zoom_z": _zoom_z(camera.data),
        "locked_shift": [float(camera.data.shift_x), float(camera.data.shift_y)],
        # ★ 实际已施加的 dolly 位移向量（世界空间）—— 撤销/归因一律用它，
        #   不能用 ref_depth×zoom 反推（ref_depth 会被拖动改写）。—— 独立审查 F1
        "applied_dolly": [0.0, 0.0, 0.0],
        # ★ 锁定这一刻「相机上跨锁定累计量」的快照。
        #   applied_dolly 改为由 (相机当前累计 − 本快照) 推导，见 _state_applied_dolly：
        #   state 是**按场景**存的，相机是**全局**的 —— 复制场景后两份 state
        #   会各自以为"还没推过"，于是 dolly 被施加两次（2026-10-20 独立审查）。
        "dolly_at_lock": [float(_cam_dolly_get(camera).x),
                          float(_cam_dolly_get(camera).y),
                          float(_cam_dolly_get(camera).z)],
        # ★ 相机数据块的持久 id —— 改名后靠它找回本记录。—— 独立审查 第三轮 F4
        "cam_uid": cam_uid(camera),
        "objects": [o.name for o in locked],
    }
    save_groups(scene, groups)
    # key 用场景**指针**（场景名不唯一）—— 与 handler 第三步一致。—— 独立审查 F5
    _last_view[(scene.as_pointer(), cam_data_name)] = (view.copy(), float(camera.data.lens))

    msg = "已锁定 %d 个网格（基准深度 %.3f，跳过 %d）" % (len(locked), ref_depth, len(skipped))
    # ⚠️ 互斥迁移要出声（独立审查 第六轮 🟢-1）：把网格从旧相机抢过来时，
    #    旧相机被**静默**关掉（图标悄悄变 🔓），用户完全不知道刚才发生了什么。
    if _migrated_from:
        msg += "；⚠️ 已从相机 %s 接管（其锁定已解除）" % "、".join(sorted(_migrated_from))
    # ⚠️ 他场景对象只报告、不阻塞（独立审查 第六轮 🟢-3）：原来 `_out_of_scene`
    #    被填充但从未输出，属"记录却从不用"的死数据。
    if _out_of_scene:
        msg += "；另 %d 个他场景对象按当前位置写入了冻结坐标（含 %s）" % (
            len(_out_of_scene), "、".join(o.name for o, _ in _out_of_scene[:3]))
    # ★ 跳过原因必须写出来（用户实测反馈后补）：
    #   原来只有**全部失败**时才写原因，**部分跳过**只给一个数字「跳过 N」
    #   ⇒ 用户看到"已锁定 2 个网格（跳过 5）"完全不知道剩下那 5 个为什么没被锁、
    #     也没法自己判断该去修什么（改网格？换个相机？还是这功能本来就不支持）。
    #   这是一个纯信息补充：**不改任何行为**，只让失败变得看得见。
    if skipped:
        _sk = "、".join("%s（%s）" % (o.name, w) for o, w in skipped[:4])
        msg += ("；⚠️ 跳过 %d 个未参与适配：%s%s。"
                "常见原因：带修改器/形态键（改写会与修改器叠加造成双重变形）、"
                "共享网格数据（多对象共用一个 mesh，无法按对象分别记录）、"
                "空网格、顶点在相机后方"
                % (len(skipped), _sk, "…" if len(skipped) > 4 else ""))
    if not _frozen_ok:
        _names = "、".join(("%s(%s)" % (o.name, w)) if o is not None else w
                          for o, w in _unsupported[:4])
        msg += ("；⚠️ 图案冻结未启用（%s%s）—— "
                "冻结坐标无法按对象区分（共享网格/修改器）或投影组不存在时，"
                "强行冻结会让投影错位，故保持实时投影（图案会随相机滑动）"
                % (_names, "…" if len(_unsupported) > 4 else ""))
    return {"success": True, "message": msg,
            "locked": locked, "skipped": skipped,
            "frozen": _frozen_ok,
            "unsupported": [((o.name if o is not None else "<场景>"), w) for o, w in _unsupported]}


def unlock_group(scene, camera):
    """解锁：停止跟随（网格停在当前位置、图案保持冻结 —— 关掉不回退）。"""
    key, st, groups = _resolve_state(scene, camera)
    if not st:
        return {"success": False, "message": "该相机未锁定"}
    st["enabled"] = False
    groups[key] = st
    # ★ 记下「解锁那一刻」的几何签名：之后如果用户自由编辑了网格，
    #   重置时就能提醒他"这会连你的编辑一起还原"。—— 独立审查 第六轮 🔴-2
    for obj in locked_objects(scene, key or camera.data.name, st):
        try:
            _mk = _read_matrix_key(obj)
            sig = _geom_sig(obj)
            if sig is not None:
                obj[UNLOCK_SIG_KEY] = sig + ([float(_mk[i][j]) for i in range(4) for j in range(4)]
                                             if _mk is not None else [])
        except Exception:
            pass
    save_groups(scene, groups)
    # ⚠️ key 必须与 lock_group / handler 一致（场景**指针**）—— 原来写成 `scene.name`，
    #    类型都不对，pop 永远不中，_last_view 残留。—— 独立审查 R18
    _last_view.pop((scene.as_pointer(), key), None)
    _last_view.pop((scene.as_pointer(), camera.data.name), None)
    # ★ 解锁 = 停止跟随 **且恢复实时投影**（用户实测反馈修正）
    #
    # 原实现只置 enabled=False，**不撤投影组的 patch**。于是组内的 Attribute
    # 节点继续读冻结的 `campos`，UV 恒定不变 ⇒ 图案钉死在网格上、不再随相机
    # 变化 —— 用户看到的就是「解锁后投射效果消失了」（贴图没坏，但没投影感）。
    # 实测（移相机后 UV 变化量）：锁定 0.00000000 / 解锁 0.00000000 / 重置 0.2。
    # 现在解锁与重置共用 unpatch，解锁后投影立即回到 TexCoord 实时链路
    # （实测 patch=False，且解锁后再换材质的网格也能正常投上 —— 见下）。
    #
    # ⚠️ 顺带修掉「解锁后新接入投影材质的网格投影坏掉」：
    #    组处于 patch 时，任何使用该材质的网格**都必须**有 `campos` 属性，
    #    否则 Attribute 节点取不到属性 → 返回 (0,0,0) → UV 全塌到一个点。
    #    用户实测：A 锁定 → 解锁 → 把 B 的材质换成同一投影材质 ⇒ B 没有 campos
    #    （解锁后 handler 不再补写）⇒ B 的投影是坏的。
    #    解锁时 unpatch 后组回到实时链路，新接入的网格不再依赖该属性 ⇒ 自然正确。
    #
    # ⚠️ 几何【不回退】：保留用户当前看到的形状（锁定期间网格可能已被适配变形），
    #    只把投影链路还给实时。要连形状一起还原请点「重置」。
    #
    # ★★ 先「落实构图」再撤补丁（用户 2026-10-19 明确语义：
    #    「相当于锁定时是调整，解锁后实现这个调整」）。
    #
    #    锁定期间图案由冻结坐标驱动、UV 恒定；解锁切回实时链路时两者不等
    #    ⇒ 图案在网格表面滑一下（实测 UV 差 0.4）。
    #    落实 = 逐顶点写一个固定 UV 偏移 delta，使「实时 + delta」精确等于冻结图案。
    #      · 解锁那一帧：画面**一点不变**（不跳）
    #      · 解锁之后：实时变、delta 不变 ⇒ 图案随投影**正常滑动**
    #      · 几何 / 深度 / 位姿 **完全不动**（网格变形与 UV 偏移是两套独立计算）
    #    顺序不能反：要读 `campos` 算 delta，而下面会把它清掉。
    _committed = 0
    _commit_failed = []
    # ★★ 解锁落实施量：完整公式是
    #       (live·S + C)·Z_now + s_now = frozen·Z_lock + s_lock
    #   ⇒  live·S + C = frozen·(Z_lock/Z_now) + (s_lock − s_now)/Z_now
    #   所以：
    #     ratio      = Z_now / Z_lock      （Z = lens / sensor_width，两项都要算）
    #     shift_term = (s_lock − s_now) / Z_now
    #   ⚠️ 早期只算 lens 比、且完全没算 shift —— 用户实测：
    #      锁定期间只改 sensor_width（36→24）解锁跳 0.093
    #      只改 shift_x（0→0.15）解锁跳 0.038
    _lens_ratio = 1.0
    _shift_term = None
    try:
        _z_now = _zoom_z(camera.data)
        _z_lock = _safe_float(st.get("locked_zoom_z", 0.0))
        if _z_lock and abs(_z_lock) > 1e-12:
            _lens_ratio = _z_now / _z_lock
        else:
            # 旧工程没有 locked_zoom_z → 退回只看 lens（旧行为）
            _lf = _safe_float(st.get("locked_focal", 0.0))
            if _lf and _lf > MIN_DEPTH:
                _lens_ratio = float(camera.data.lens) / _lf
        _s_lock = st.get("locked_shift") or (0.0, 0.0)
        _s_now = (float(camera.data.shift_x), float(camera.data.shift_y))
        if abs(_z_now) > 1e-12:
            _dx = (float(_s_lock[0]) - _s_now[0]) / _z_now
            _dy = (float(_s_lock[1]) - _s_now[1]) / _z_now
            if abs(_dx) > 1e-12 or abs(_dy) > 1e-12:
                _shift_term = (_dx, _dy)
    except Exception:
        _lens_ratio = 1.0
        _shift_term = None
    try:
        _nodes_ok = _ensure_delta_group(camera)
        _frozen_chunks = []
        _live_chunks = []
        for _o in locked_objects(scene, key or camera.data.name, st):
            try:
                _a = _o.data.attributes.get(_campos_attr_name(key or camera.data.name))
                if _a is None or len(_a.data) != len(_o.data.vertices):
                    continue
                _n = len(_a.data)
                _buf = _np.empty(_n * 3, dtype=_np.float64)
                _a.data.foreach_get("vector", _buf)
                _fz = _buf.reshape(-1, 3)
                _vco = _np.empty(_n * 3, dtype=_np.float64)
                _o.data.vertices.foreach_get("co", _vco)
                _vco = _vco.reshape(-1, 3)
                _L2C = _np.array(camera.matrix_world.inverted() @ _o.matrix_world,
                                 dtype=_np.float64)
                _live3 = _vco @ _L2C[:3, :3].T + _L2C[:3, 3]
                _fp, _ok1 = _persp_np(_fz)
                _lp, _ok2 = _persp_np(_live3)
                _ok = _ok1 & _ok2
                _frozen_chunks.append(_fp[_ok])
                _live_chunks.append(_lp[_ok])
            except Exception:
                _commit_failed.append(_o.name)
        if _nodes_ok and _frozen_chunks:
            _fp = _np.concatenate(_frozen_chunks, axis=0)
            _lp = _np.concatenate(_live_chunks, axis=0)
            _params = fit_delta_params(_fp, _lp, _lens_ratio, _shift_term)
            if _params is not None and write_delta_params(
                    key or camera.data.name, _params[0], _params[1]):
                _committed = 1
            elif _params is None:
                # ★ 拟合退化（典型：相机贴着/穿过网格，所有顶点深度≈0）。
                #   这时不能把无意义的 S 写进去冒充"已落实" —— 实测那种情况
                #   S 会掉到 1e-4 量级，投影被压成一条线。
                #   宁可失败并说清楚，让用户去点「重置」。
                _commit_failed.append("相机离网格过近（深度≈0），构图无法可靠落实")
            else:
                _commit_failed.append("(C+k 写入失败)")
        elif not _nodes_ok:
            _commit_failed.append("(投影组缺少 C+k 链)")
        else:
            _commit_failed.append("(没有可用的冻结坐标)")
    except Exception:
        _commit_failed.append("(落实异常)")
    # 旧版逐顶点偏移属性（若旧工程留下）一律清掉，避免双重偏移。
    try:
        for _o in locked_objects(scene, key or camera.data.name, st):
            clear_legacy_delta(_o)
    except Exception:
        pass
    try:
        unpatch_camera_project_group(camera.data.name)
        # ★ 组已回到实时链路，冻结坐标不再被读取 ⇒ 必须一并清掉。
        #   留着会踩 `lock_group` 里的 `_keep_existing` 判据：它用「属性仍有效」
        #   推断「可以沿用旧坐标、不必重采集」。但解锁期间相机/网格可能已经动过，
        #   沿用旧坐标会让下一次锁定的投影**按旧视角错位**（而且画面不报错）。
        #   清掉之后重锁 = 全新采集，行为可预测。
        #   只删 campos（按相机名精确匹配），保留 ORIG/BASE —— 否则「重置」再也
        #   还原不回锁定前的原形。
        for _o in locked_objects(scene, camera.data.name, st):
            _remove_attr(_o, _campos_attr_name(camera.data.name))
    except Exception:
        pass
    # ★ 记下「构图已落实」这件事 —— handler 靠它给**解锁之后才接入投影材质**的
    #   网格补写 UV 偏移（用户实测：B 后接入时呈现的是未落实的原始投射）。
    #   ⚠️ 必须存在 state 里而不是网格上：这是**该相机投影**的属性，
    #      一个网格有没有接入是之后才发生的动态事件。
    st["uv_delta_committed"] = bool(_committed) and not _commit_failed
    groups[key] = st
    save_groups(scene, groups)
    _reset_popup_state()   # 解锁后不该再弹「无法冻结」的过期提示
    _msg = "已解锁（构图已落实，投影恢复实时；再动相机图案会正常滑动）"
    if _commit_failed:
        # ★ 措辞要如实：这是「没落实成功」，不是「轻微跳动」。
        #   用户看到这句话要知道：解锁瞬间跳了一次、并且可以用「重置」回到初始投影。
        _msg = ("已解锁，但构图未能落实（解锁瞬间图案会跳一次；"
                "可用「重置」彻底回到初始投影）：%s"
                % "；".join(_commit_failed[:3]))
    return {"success": True, "message": _msg}


def _restore_geometry(obj, old_st):
    """按给定锁定状态的基准，把对象的几何还原（撤销视锥体适配变形）。

    优先用 ORIG_ATTR（真正的原形）；否则退回 base + locked_matrix 反算。
    —— 独立审查 第五轮 🔴-2
    """
    if obj is None or obj.data is None:
        return False
    mesh = obj.data
    mk = _read_matrix_key(obj)
    orig = _read_orig_attribute(obj)
    if orig is not None:
        if mk is not None:
            obj.matrix_world = mk
        mesh.vertices.foreach_set("co", orig)
        mesh.update()
        return True
    if not isinstance(old_st, dict):
        return False
    base = _read_base_attribute(obj)
    view_locked = _safe_view_matrix(old_st.get("locked_matrix"))
    if base is None or view_locked is None:
        return False          # 基准或 4×4 矩阵任缺其一 ⇒ 无法还原（由调用方如实报告）
    mw_inv = obj.matrix_world.inverted()
    flat = []
    ap = flat.append
    for (x0, y0, d) in base:
        world = view_locked @ mathutils.Vector((x0, y0, -d))
        co = mw_inv @ world
        ap(co.x); ap(co.y); ap(co.z)
    if mk is not None:
        obj.matrix_world = mk
    mesh.vertices.foreach_set("co", flat)
    mesh.update()
    return True


def reset_group(scene, camera):
    """重置：撤销所有锁定造成的改动 + 解除锁定（一步到位）。"""
    # ⚠️ 公开 API 的入参健壮性（独立审查 第七轮 🟡-5）：其余 API
    #    （is_locked / has_lock_record / get_state / unlock_group / lock_group）
    #    对 None 都安全，只有这里会抛 `AttributeError: 'NoneType' object has no attribute 'data'`。
    #    经 operator 走不到（面板有守卫），但作为公开函数应当一致地优雅失败。
    if camera is None or getattr(camera, "data", None) is None:
        return {"success": False, "message": "无效的相机对象（无数据块）"}
    cam_data_name = camera.data.name
    # ⚠️ 用 _resolve_state（含 UID 兜底）：相机数据块改名后仍要能重置，
    #    否则网格永久变形且 UI 无路可走。—— 独立审查 第三轮 F4
    key, st, groups = _resolve_state(scene, camera)
    if not st:
        return {"success": False, "message": "该相机没有锁定记录"}
    view_locked = _safe_view_matrix(st.get("locked_matrix"))
    if view_locked is None:
        # ⚠️ 原来是 `if not lm` —— 只在"完全没有"时报错；行数不足/元素非数字时
        #    会漏过去，然后 `mathutils.Matrix(...)` 直接抛 TypeError（用户看到报错）。
        #    改用统一的安全解析。—— 独立审查 第十一轮
        return {"success": False,
                "message": "锁定记录损坏（locked_matrix 不是合法的 4×4 数值矩阵）；"
                           "已保留现有数据，未做任何修改"}

    n = 0
    # ⚠️ 用**反向索引**枚举（不受重命名影响）—— 原实现按名字列表找，
    #    用户 F2 改名后这一层的几何**永远不会被还原**（永久变形）。—— 独立审查 F3
    edited = []
    for obj in locked_objects(scene, cam_data_name, st):
        if obj.type != "MESH" or obj.data is None:
            continue
        mesh = obj.data
        mk = _read_matrix_key(obj)
        # ★ 检测「用户在解锁之后的编辑」（独立审查 第六轮 🔴-2）：
        #   解锁的语义是"停在当前位置"，用户接着自由编辑是**合法**的；
        #   此时重置会把他的编辑一起抹掉 —— 那正是这条要报出来的事。
        try:
            usig = obj.get(UNLOCK_SIG_KEY)
            if usig:
                _cur = _geom_sig(obj) or []
                _dirty = _sig_differs(_cur, list(usig[:5]))
                if not _dirty and len(usig) >= 21:
                    # ⚠️ 比的是**当前实际位姿** `matrix_world`，不是 `MATRIX_KEY` ——
                    #    后者是插件自己记的"上次正确位姿"，**不会**跟着用户的拖动变，
                    #    拿它比永远相等（我当时就踩了这个坑，检测形同虚设）。
                    _mw = obj.matrix_world
                    _curm = [float(_mw[i][j]) for i in range(4) for j in range(4)]
                    _dirty = _sig_differs(_curm, list(usig[5:21]), 1e-5)
                if _dirty:
                    edited.append(obj.name)
        except Exception:
            pass
        # ★ 优先用【首次锁定的原形】（局部坐标）还原 —— 与锁定链路解耦：
        #   即使中途「解锁 → 再锁定」把 BASE_ATTR 换成了适配后的形状，
        #   也能回到**真正的原始形状**。—— 独立审查 第五轮 🔴-1
        orig = _read_orig_attribute(obj)
        if orig is not None:
            if mk is not None:
                obj.matrix_world = mk
            mesh.vertices.foreach_set("co", orig)
            mesh.update()
            _clear_lock_traces(obj)          # ← 两处统一（含 UNLOCK_SIG_KEY）
            n += 1
            continue
        base = _read_base_attribute(obj)
        if base is None:
            continue
        mw_inv = obj.matrix_world.inverted()
        flat = []
        ap = flat.append
        for (x0, y0, d) in base:
            world = view_locked @ mathutils.Vector((x0, y0, -d))
            co = mw_inv @ world
            ap(co.x); ap(co.y); ap(co.z)
        # ⚠️ 位姿也要还原：拖动时 apply_user_move 已把位姿设回锁定基准，但万一
        #    handler 没跑过（用户改完立刻点重置），位姿会残留用户拖出来的样子。
        #    不还原 ⇒ 对象永久带着非 1 的 scale、原点被挪（子物体被一起带走）。—— 独立审查 R1
        if mk is not None:
            obj.matrix_world = mk
        mesh.vertices.foreach_set("co", flat)
        mesh.update()
        _clear_lock_traces(obj)
        n += 1

    # 撤销变焦时施加到相机上的 dolly（把相机位置还回去）
    # ⚠️ 归还的是【相机上累计的、跨锁定存活的】位移，不是 state["applied_dolly"] ——
    #    后者在每次 `lock_group` 都会清零，于是「锁定→变焦→解锁→再锁定→重置」
    #    只归还 0，相机永久停在被推走的位置（实测残差 6.0）。—— 独立审查 第三轮 F2
    #    （同样不能用 ref_depth×zoom 反推：拖动会改写 ref_depth。）—— 独立审查 第一轮 F1
    if CAMERA_DOLLY_ZOOM:
        pending = _cam_dolly_get(camera)
        if pending.length > 1e-9:
            camera.location = camera.location - world_to_parent_local(camera, pending)
        _cam_dolly_clear(camera)

    # 撤补丁 + 清属性（扫全局，与写入侧口径一致 —— 补丁是全局生效的）
    unpatch_camera_project_group(cam_data_name)
    _reset_popup_state()
    # ★ C+k 复位成恒等变换 ⇒ 投影回到「纯实时」
    #   （重置的语义是「连落实了构图一起撤销」）。
    write_identity_delta(cam_data_name)
    for obj in bpy.data.objects:
        if obj.type != "MESH" or obj.data is None:
            continue
        # 冻结坐标属性名【按相机区分】→ 只清本相机那一份，天然不会动别的相机。
        # （独立审查 S1 / N1）
        _remove_attr(obj, _campos_attr_name(cam_data_name))
        # 旧版逐顶点 UV 偏移属性（方案 D 之前）也一并清掉。
        clear_legacy_delta(obj)
        if obj.get(CAMPOS_OWNER_KEY) == cam_data_name:
            for _k in (CAMPOS_OWNER_KEY, CAMPOS_VCOUNT_KEY):
                try:
                    del obj[_k]
                except Exception:
                    pass
        if obj.get(OBJ_CAM_KEY) == cam_data_name:
            _remove_attr(obj, BASE_ATTR)
            try:
                del obj[OBJ_CAM_KEY]
            except Exception:
                pass
            for _k in (MATRIX_KEY, DRAG_SCALE_KEY, DRAG_OFFSET_KEY, CENTER_KEY, ORIG_CENTER_KEY):   # 拖动相关状态一并清
                try:
                    del obj[_k]
                except Exception:
                    pass

    groups = load_groups(scene)
    groups.pop(key, None)                       # 用 _resolve_state 解析出的真实 key
    groups.pop(cam_data_name, None)             # 兜底（名字恰好一致时）
    save_groups(scene, groups)
    _base_cache.clear()
    _last_view.pop((scene.as_pointer(), key), None)
    _last_view.pop((scene.as_pointer(), cam_data_name), None)
    _msg = "已重置 %d 个网格 + 解除锁定" % n
    if edited:
        # ★ 必须明示（独立审查 第六轮 🔴-2）：重置的承诺是「撤销锁定造成的改动」，
        #   但解锁之后的编辑**不是**锁定造成的 —— 用户有权知道它们一并被还原了。
        _msg += ("；⚠️ 注意：%s 在【解锁之后】被编辑过，也已一并还原到"
                 "首次锁定前的形状（如需保留，请立即 Ctrl+Z）"
                 % "、".join(edited[:4]))
    return {"success": True, "message": _msg, "edited_after_unlock": edited}


# ──────────────────────────── handler ────────────────────────────

# 防重入：我们自己在 handler 里移动相机，会再次触发 depsgraph
_dolly_guard = False


def _apply_zoom_dolly(scene, camera, st, zoom, cam_data_name, groups):
    """变焦增量 → 移动相机（增量式，保留用户自己的相机位移）。"""
    global _dolly_guard
    # 目标位移（按**当前** ref_depth）与【实际已施加】之差，才是这一轮要补的。
    # ★ 同上：以相机上的持久记账为真相源（复制场景后不会各推一遍）。
    applied = _state_applied_dolly(camera, st)
    target = auto_dolly_vector(st, zoom)
    diff = target - applied
    if diff.length <= 1e-9:
        return False                      # 已对齐（含 zoom 未变的情况）
    _dolly_guard = True
    try:
        camera.location = camera.location + world_to_parent_local(camera, diff)
        st["applied_dolly"] = [float(target.x), float(target.y), float(target.z)]
        # ★ 同时累积到「相机上」的持久记账里（跨 锁定/解锁/再锁定 存活）——
        #   重置要用它把相机还给用户，见 reset_group。—— 独立审查 第三轮 F2
        #   ⚠️ 累加的是【本次实际施加的增量 diff】，不是 target：
        #      target 是"应该总共施加多少"（相对当前锁定），diff 才是这一轮真的推了多少。
        _cam_dolly_add(camera, diff)
        groups[cam_data_name] = st
        save_groups(scene, groups)
        bpy.context.view_layer.update()
    finally:
        _dolly_guard = False
    return True


def _selfheal_and_backfill(scene, camera, st, cam_data_name):
    """补丁自愈 + 给「锁定后才接入投影材质」的对象补写冻结坐标。

    ⚠️ 必须**不受** handler 里 `cam_changed` 早退的影响（独立审查 第六轮 🟡-1）：
       原来这两块放在 `if not todo: continue` **之后**，于是
         · 补丁被外部清掉后，**只有相机动过**才会被重打；
         · 新接入投影材质的对象，**只有相机动过**才会拿到冻结坐标。
       两个「看着成功其实没生效」的静态窗口都会一直开着（画面上还看不出来）。
       这两件事本身幂等，代价是一次 `objects_using_projection` 扫描。

    ⚠️ 性能：该扫描是 O(全库对象 × 材质嵌套节点树)。改用
       `objects_using_projection_cached`（结构签名缓存，见其定义处的说明与边界）。
       ⚠️ 我在 v2.7.7 的 CHANGELOG 里先写了"加了缓存"、代码里却没有 ——
          那种"文档说了有、实现没有"正是本项目反复在修的同一类病
          （独立审查 第七轮 🟡 F-4 抓到，已如实补上实现）。
    """
    try:
        if not is_patched(cam_data_name):
            # 补丁丢了（如「重新生成投影组」清了组内节点）→ 自动重打。
            # 冻结坐标属性还在 ⇒ 重打不会跳变（判据见 lock_group 的 _keep_existing）。
            _fz = [o for o in locked_objects(scene, cam_data_name, st)
                   if _campos_is_valid(o, cam_data_name)]
            if _fz:
                patch_camera_project_group(cam_data_name)
            return
        # 补丁在 → 检查是否有「新接入投影材质」的对象缺冻结坐标。
        #
        # ⚠️ 缓存**不足以**覆盖这条路径（独立审查 第八轮 🟡-1）：
        #   用户给**已存在**的对象手工接入投影时，可能一个数据块计数都不变
        #   （甚至"节点数"也会撞回原值）⇒ 缓存判"没变"⇒ 该对象永远拿不到冻结坐标，
        #   投影退化为常量且无提示。
        #   ⇒ 每 `_BACKFILL_FULL_EVERY` 次做一次**真值扫描**（无缓存），
        #     保证缺失在有限帧内被补上；其余帧走缓存以保住性能。
        # ★★ 冻结坐标必须用【锁定那一刻】的相机位姿，**不是当前位姿**。
        #    锁定期间相机已经移开了；用当前位姿采集出来的坐标 = "现在看到的投影"，
        #    与已有锁定网格的"锁定那一刻的投影"口径不同 ⇒ 图案错位。
        #    实测（A 在锁定中已冻结，B 在锁定期间换材质）：
        #      用当前位姿：UV 误差 0.400000（正好等于相机横移 2 的 UV 偏移）
        #      用锁定位姿：误差 0
        _mw_inv_cam = None
        try:
            _lm = st.get("locked_matrix") if isinstance(st, dict) else None
            if _lm:
                _mw_inv_cam = mathutils.Matrix(_lm).inverted()
        except Exception:
            _mw_inv_cam = None
        if _mw_inv_cam is None:
            # 没有 locked_matrix（异常存档）→ 退化为当前位姿，并在日志里留痕
            _mw_inv_cam = camera.matrix_world.inverted()
            print("[compify] PLock: 缺少 locked_matrix，新接入网格的冻结坐标"
                  "按当前相机位姿采集（可能与已锁定网格错位）")
        _backfill_tick[0] += 1
        _src = (objects_using_projection(cam_data_name)
                if (_backfill_tick[0] % _BACKFILL_FULL_EVERY) == 0
                else objects_using_projection_cached(cam_data_name))
        for _o in _src:
            try:
                if _o.data is None or len(_o.data.vertices) == 0:
                    continue
                if _campos_is_valid(_o, cam_data_name):
                    continue
                _whys = block_reasons(_o)
                if _whys:
                    # ⚠️ 这三类对象**无法精确冻结**：修改器/形态键会改变最终几何，
                    #    而冻结坐标是逐 mesh 顶点的（基座顶点与渲染顶点对不上）；
                    #    共享网格则是一份坐标同时服务多个对象，必然对不齐。
                    #    不写属性 ⇒ 组的 Attribute 读到 0 ⇒ 图案塌成纯色。
                    #
                    #    用户 2026-10-20 要求：这种情况**弹窗**告知（只这三类）。
                    #    控制台也留一条（headless 时唯一能看到的地方）。
                    if _o.name not in _backfill_warned:
                        _backfill_warned.add(_o.name)
                        print("[compify] PLock: 网格「%s」无法参与图案冻结"
                              "（%s，图案会显示为纯色）。"
                              % (_o.name, "、".join(_whys)))
                    _queue_unfreezable_popup(_o.name, _whys)
                    continue
                _write_campos_attribute(_o, camera, cam_data_name, _mw_inv_cam)
                # 能冻结了 ⇒ 之前的"不可冻结"记录作废（以后出问题还要能再提示）
                _clear_unfreezable_record(_o.name)
            except Exception:
                continue
    except Exception:
        pass


def _ready_cameras(scene, groups):
    """逐个产出 (cam_data_name, st, camera)；单条记录损坏时**跳过它**，不影响其它相机。

    ⚠️ per-entry 容错：原实现是裸循环 + 外层 try —— 只要一个相机的记录缺字段
       （如 `locked_matrix` 被外部改坏 / 存档不全），`KeyError` 就会从循环体内抛出、
       被外层吞掉，**排在后面的相机一个都得不到处理**（完全静默，只在控制台留痕）。
       一个坏记录 = 全站视差锁定停摆。—— 独立审查 F2
    """
    for cam_data_name, st in list(groups.items()):
        if not isinstance(st, dict) or not st.get("enabled"):
            continue
        try:
            # UID 兜底：相机数据块被改名后，按名字找不到，用记录里的 uid 找回
            # （否则 handler 静默失效）。—— 独立审查 第三轮 F4
            camera = find_camera(scene, cam_data_name, st.get("cam_uid"))
        except Exception:
            camera = None
        if camera is None:
            continue
        yield cam_data_name, st, camera


def locked_objects(scene, cam_data_name, st=None):
    """枚举「归该相机」的锁定网格。

    ⚠️ 以对象上的**反向索引** `OBJ_CAM_KEY` 为准，而不是 state 里的名字列表 ——
       列表存的是 `obj.name`（对象名），用户随手 F2 改名 / 批量重命名插件后
       handler 与 reset 就再也找不到它：该网格**静默脱离锁定**（构图错位），
       而且 `reset` 也还原不了它的几何（**永久变形**）。
       反向索引跟着对象走，不受重命名影响。
    ⚠️ 口径统一：`get_lock_targets` / 投影组命名用的是**数据名**，
       而记账曾用**对象名** —— 两把尺子必然导致「一半跟着走、一半不跟」。
       这里以对象身份（反向索引）为准，彻底绕开名字口径问题。—— 独立审查 F3 / F4
    """
    out, seen = [], set()
    # ★ 顺手建一张「对象名 → 对象」索引，给下面的名字兜底用 O(1) 查，
    #   不要再对每个名字调一次 `scene.objects.get()`。
    #   实测（独立审查 2026-10-20）：3000 个锁定对象时，
    #   带名字兜底 **189.39 ms** / 不带 **2.84 ms**（66.6 倍），
    #   而兜底查到的对象 100% 已在 `seen` 里 —— 纯浪费，且每帧都跑。
    by_name = {}
    for o in bpy.data.objects:
        if o.type != "MESH" or o.data is None:
            continue
        by_name[o.name] = o
        try:
            if o.get(OBJ_CAM_KEY) == cam_data_name:
                if o.as_pointer() not in seen:
                    seen.add(o.as_pointer())
                    out.append(o)
        except Exception:
            continue
    # 兼容：老存档 / 未写反向索引的对象，退回按名字列表找。
    # ⚠️ 只有「反向索引没找全」时才需要兜底 —— 正常情况下直接跳过整个循环。
    _want = len(st.get("objects") or []) if st else 0
    if st and len(out) < _want:
        for nm in (st.get("objects") or []):
            o = by_name.get(nm)
            if o is None or o.as_pointer() in seen:
                continue
            seen.add(o.as_pointer())
            out.append(o)
    return out


# 防重入总闸：handler 自己会改网格顶点 / 物体位姿 / 相机位置 / 场景属性
# → 每次都触发 depsgraph → 又调回本 handler。
# ⚠️ 没有这道闸，拖动时「拖动缩放」会在**同一次拖动里被反复累乘**
#    （k → k² → k³ …，因为位姿已改、而记录基准还没写回）——
#    网格被推到极远处 = 用户看到的「对象消失」。
_handler_guard = False
# 每个对象「上一次看到的拖动量」—— 用来发现「拖动量变了」这个事件，
# 从而在**同帧**重算 ref_depth（见 handler 第三步的说明）。
# key = obj.as_pointer()，value = float offset。
_drag_seen = {}


@persistent
def parallax_lock_update_handler(scene):
    global _handler_guard
    if _dolly_guard or _handler_guard:
        return
    _handler_guard = True
    try:
        import traceback
        # ★ 先回收 _last_view（独立审查 第六轮 🟡-5）：必须放在 `if not groups: return`
        #   **之前** —— 记录被清空 / 相机被删时正是最需要回收的时刻，
        #   而那条早退会把它整个跳过（放 finally 也不够：业务 return 之前执行不到）。
        try:
            if _last_view:
                _ac = {c.name for c in bpy.data.cameras}
                _as = {s.as_pointer() for s in bpy.data.scenes}
                for _k in [k for k in _last_view if k[1] not in _ac or k[0] not in _as]:
                    _last_view.pop(_k, None)
        except Exception:
            pass
        groups = load_groups(scene)
        if not groups:
            return

        # ★★ 第零步（新增，独立审查 2026-10-20 🔴）：先让 ref_depth 与当前几何对齐。
        #
        #   为什么要排在变焦之前：`_apply_zoom_dolly`（第一步）会用 ref 推相机，
        #   而 ref 原来只在第三步 cam_changed 时重算 ⇒ 变焦用的永远是**上一帧**的 ref。
        #   事故链（实测）：
        #     拖图层到 30m → 动相机（ref 变 32）→ 拖回原位（几何对了，ref 还是 32）
        #     → 变焦：相机沿光轴跑 ref*(zoom-1)=16m（正确应 4m）
        #     → 场景里**未锁定**的物体透视错 -57.9%，锁定层画面却完全正常。
        #   这里在变焦前先对齐一次：ref 永远反映「当前几何 + 当前拖动量」。
        #   ⚠️ 只在自己「可能变了」的时候算（拖动量变化 / 相机变化），不每帧算。
        for cam_data_name, st, camera in _ready_cameras(scene, groups):
            try:
                _key0 = (scene.as_pointer(), cam_data_name)
                _view0 = get_camera_view_matrix(camera)
                _last0 = _last_view.get(_key0)
                _cam_ch0 = (_last0 is None
                            or not _matrices_close(_last0[0], _view0, CAMERA_CHANGE_THRESHOLD)
                            or abs(float(camera.data.lens) - _last0[1]) > 1e-6)
                _drag_ch0 = False
                for _o in locked_objects(scene, cam_data_name, st):
                    try:
                        _cur = _safe_float(_o.get(DRAG_OFFSET_KEY, 0.0), 0.0)
                        _seen = _drag_seen.get(_o.as_pointer())
                        if _seen is None or abs(_cur - _seen) > 1e-9:
                            _drag_seen[_o.as_pointer()] = _cur
                            _drag_ch0 = True
                    except Exception:
                        continue
                if _cam_ch0 or _drag_ch0:
                    _pre0 = _safe_float(st.get("ref_depth", 0.0))
                    recompute_ref_depth(scene, st, cam_data_name)
                    if abs(_safe_float(st.get("ref_depth", 0.0)) - _pre0) > 1e-9:
                        groups[cam_data_name] = st
                        save_groups(scene, groups)
            except Exception:
                traceback.print_exc()
                continue

        # 第一步：变焦检测 → 移动相机（相机真的动起来）
        # ⚠️ 不 return：必须紧接着在同一轮里做网格适配，否则本轮只有相机动、网格不动
        # ⚠️ 三步都按「每相机独立容错」跑：一条坏记录只跳过它自己。—— 独立审查 F2
        for cam_data_name, st, camera in _ready_cameras(scene, groups):
            try:
                lf = _safe_float(st.get("locked_focal", 0.0)) or MIN_DEPTH
                zoom = float(camera.data.lens) / lf
                _apply_zoom_dolly(scene, camera, st, zoom, cam_data_name, groups)
            except Exception:
                traceback.print_exc()
                continue

        # ★ 方案 D 起不再有「第零步」：构图落实由投影组里的 C+k 两个数值承担，
        #   解锁后它们保持常量（这正是「图案跟着实时投影滑动」的原因）。
        #   旧方案要让 handler 每帧扫网格补写逐顶点属性，那一整段已删除。

        # 第二步：用户拖动锁定网格 → 重新锚定（对齐 PSD「拖图层」语义）
        #   ⚠️ 必须排在网格适配【之前】：重锚会改 base 与位姿，适配要用新值。
        _moved_any = False
        _moved = {}          # cam_data_name -> [被拖动的对象]（第三步用来收窄适配范围）
        # ⚠️ 这里曾有 `_ref_changed`（"基准层换人 ⇒ 所有网格都要重算"）。
        #    已在 2026-10-20 随「拖动不重算 ref_depth」一并删除：
        #    拖动不再改基准，所以不存在"换人"这回事，留着就是永远为空的死数据。
        #    第三步因此只有两种收窄：相机动 ⇒ 全部适配；否则 ⇒ 只适配被拖动的那个。
        for cam_data_name, st, camera in _ready_cameras(scene, groups):
            try:
                # ⚠️ 用【当前】相机矩阵，不是锁定那一刻的 —— 用户是看着当前的相机画面拖的，
                #    深度/视线必须按当前相机算；用锁定帧会让「拖不动的方向」「深度比」全错
                #    （相机移动/旋转后尤其明显）。—— 用户报的第 2 个问题
                view_now = get_camera_view_matrix(camera)
                moved = []
                for obj in locked_objects(scene, cam_data_name, st):
                    if apply_user_move(obj, camera, view_now):
                        moved.append(obj)
                if moved:
                    # ★★ 拖动后【不重算 ref_depth】—— 用户实测反馈，2026-10-20
                    #
                    #    症状：拖 A 会带动 B；拖动后「基于视锥体的相对构图」也变了；
                    #          还伴随无法复现的跳变。
                    #
                    #    根因：`ref_depth` = 所有锁定网格里【最深顶点】的深度，是
                    #    **全部网格共享**的适配基准（`kk = dd / ref_depth`；`kk==1`
                    #    的那一层在相机移动时完全冻结，更浅的层滑动 ⇒ 视差）。
                    #    拖动 A 改了它自己的深度 ⇒ `recompute_ref_depth` 取到的最大值
                    #    换人 ⇒ `ref_depth` 跳变 ⇒ **B 的 kk 也变** ⇒ B 被重新适配。
                    #    实测（A 深度8 / B 深度6，共用同一投影材质，移相机后拖 A）：
                    #      拖 A +1.0 → ref 8.0→7.0，B 顶点世界坐标变化 0.12857145
                    #      拖 A -1.0 → ref 8.0→9.0，B 顶点世界坐标变化 0.10000014
                    #      拖 B +1.0 → ref 8.0→8.0（基准层不换人），A 变化 0.00000000
                    #    禁掉这一次重算后，三种情形「另一网格」变化全部 = 0.00000000。
                    #
                    #    为什么不重算才是对的：
                    #      `ref_depth` 是「锁定那一刻完全冻结的那一层」= 构图锚点。
                    #      用户拖 A 是在调整 A 自己的深度（PSD 拖图层语义），
                    #      **不该让锚点漂走** —— 锚点一漂，所有网格的相对视差同时被改，
                    #      别的网格就会在画面上动，而且 ref 换人是**离散事件**，
                    #      所以表现为「不知道什么时候会触发的跳变」。
                    #      要换锚点应该重新锁定（重置后再锁）。
                    #    ⇒ 拖动只改 `obj[DRAG_OFFSET_KEY]`（per-object），ref_depth 冻结，
                    #      其余网格的 kk 恒定 ⇒ 真正「拖谁动谁」。
                    _moved[cam_data_name] = moved
                    groups[cam_data_name] = st
                    _moved_any = True
            except Exception:
                traceback.print_exc()
                continue
        if _moved_any:
            save_groups(scene, groups)

        # 第三步：网格逐顶点适配
        for cam_data_name, st, camera in _ready_cameras(scene, groups):
            try:
                view = get_camera_view_matrix(camera)
                lens_now = float(camera.data.lens)
                # key 用场景**指针**：场景名在 Blender 里不唯一（不同 .blend 可同名、
                # 场景副本可被改回同名），撞名会让另一场景的同名相机被误判"没动过"
                # 而跳过适配。—— 独立审查 F5
                key = (scene.as_pointer(), cam_data_name)
                last = _last_view.get(key)
                cam_changed = (last is None
                               or not _matrices_close(last[0], view, CAMERA_CHANGE_THRESHOLD)
                               or abs(lens_now - last[1]) > 1e-6)
                # ⚠️ 缓存【不能】在这里就写（独立审查 第三轮 F5）：下面 adapt_object 可能
                #    因为「编辑模式」等原因**一个都没适配成功**（返回 False），
                #    而这一轮几何没动、缓存却记成"已处理" ⇒ 相机静止时永远补不上
                #    （切回 OBJECT 模式也不会自动修复）。**而且投影 UV 来自冻结的
                #    campos 属性、与几何无关 ⇒ 图案会跟着那段过期几何"正确地"显示，
                #    用户在画面上看不出任何异常**，直到他再动一次相机才突然对齐。
                #    改为：确实适配成功过才写缓存（见下面 n_ok）。
                # ⚠️ 性能（独立审查 R11）：拖动时**不必**把该相机下所有网格都重适配 ——
                #    只有「被拖动的那些」自己的 base/drag 变了。
                #    （实测：5.7 万顶点网格 + 拖动时 33.8 ms/帧，就是被这条拖累的。）
                # ★ 2026-10-20 更正：这里原先还有一句「其余网格只有在 ref_depth 也
                #   跟着变了（基准层换人）时才需要重算」。**那个前提已经不成立了** ——
                #   拖动不再重算 ref_depth（见第二步），所以拖动期间不存在「基准层换人」，
                #   其余网格的 kk 恒定不变，本来就不需要动。这既修了「拖 A 带动 B」，
                #   也让「拖动时只适配被拖动的那个」从"性能优化"变成"正确性要求"。
                # ★ 自愈 + 补写必须在这里做（独立审查 第六轮 🟡-1）：
                #   它们与「相机有没有动」无关，放到下面的 `if not todo: continue`
                #   之后就会被整体跳过 —— 那两个"看着成功其实没生效"的窗口
                #   只能靠"用户碰巧动了相机"才会关上。
                _selfheal_and_backfill(scene, camera, st, cam_data_name)
                # ★★ 对齐 PSD（2026-10-20，用户拍板）：基准深度在【相机变化时】重算。
                #
                #   PSD 的事实（psd_layer_importer_plus/parallax_utils.py）：
                #     · L857  ref_depth = get_parallax_reference_depth(locked_objects)  ← 每帧现算
                #     · L998  拖动后把新深度写回 locked_depth
                #     · L871  只有 camera_changed_since_last_adapt() 为真时才适配
                #   ⇒ 拖动后基准层**会**换人，但是【延迟生效】的：
                #     拖动当帧根本不使用 ref，所以不抖；等用户再动相机才按新基准适配。
                #
                #   compify 原来在【拖动当帧】就重算并立刻全部重适配
                #   ⇒ 拖 A 会让 B 当帧就跳（用户报的"拖动A影响B + 跳变"）。
                #   上一轮我改成「永不重算」（冻结 ref）—— 抖是止住了，但**偏离了 PSD**。
                #   正确做法是这里：把重算挪到【相机变化时】。
                #
                #   实测（_dev/compare_ref_update.py；三层深度 8/6/4，把 A 拖到深度 3，再移相机 +1.0）：
                #     · 冻结 ref ：拖动当帧 B/C 位移都是 0；之后滚动量 0.173611（ref=8）
                #     · 对齐 PSD ：拖动当帧 B/C 位移都是 0；之后滚动量 0.231481（ref=6，快 33.3%）
                #   ⇒ 两种做法**都不抖**，差异只在"之后移相机的滚动速度"。
                #     两者都保持构图（三层画面位移严格一致）。
                #   ⇒ 「拖谁动谁」不依赖冻结 ref，只依赖「拖动当帧只适配被拖动的那个」。
                _ref_before = _safe_float(st.get("ref_depth", 0.0))

                if cam_changed:
                    recompute_ref_depth(scene, st, cam_data_name)
                    # ⚠️⚠️ 必须持久化（2026-10-20 实测踩到）：
                    #   `recompute_ref_depth` 只改了**内存里**的 st，没写回 scene。
                    #   不写回的话：这一帧 adapt_object 用的是新 ref（6.5），
                    #   下一帧 handler 从 scene 读回旧 ref（8.0）
                    #   ⇒ 网格先按 6.5 站好、再按 8.0 被重算，下次移相机又跳一次。
                    #   实测症状：拖动当帧 B 不动（对的），之后移相机 B 走了 -0.131
                    #   （本该 +0.077），而且 ref 在场景里永远是旧值。
                    #   只在**真的变了**才写，避免每帧 JSON 序列化。
                    if abs(_safe_float(st.get("ref_depth", 0.0)) - _ref_before) > 1e-9:
                        groups[cam_data_name] = st
                        save_groups(scene, groups)
                    todo = locked_objects(scene, cam_data_name, st)
                else:
                    todo = _moved.get(cam_data_name)
                    if not todo:
                        continue          # 相机没动、也没拖动任何网格 → 整轮跳过
                # （ref 重算已前移到「第零步」，见那里的事故链说明 ——
                #   必须排在变焦之前，否则变焦用的是上一帧的旧 ref。）
                n_ok = 0
                for obj in todo:
                    # ★★ 「清 offset」与「几何重算」必须绑成一件事（独立审查 2026-10-20）
                    #
                    #   v3.0.2 第一版在 apply_user_move 里就把 offset 清了，于是：
                    #     · 带修改器 / 在编辑模式 / base 缺失时 adapt 返回 False
                    #       ⇒ offset 已清零、几何没跟着回来 ⇒ **永久卡死**
                    #       （实测：加修改器后形变 0.3750 卡 60 帧不动，删修改器也不自愈）
                    #     · 同一 tick 里别的对象抛异常，moved 列表丢失 ⇒ 同样卡死
                    #
                    #   现在的顺序：先用 override=0 **试算**，adapt_object 真的成功
                    #   返回 True 之后才写 offset=0。失败就什么都不改，下一帧再试，
                    #   这样「删掉修改器 / 退出编辑模式」之后会自然自愈。
                    pend = None
                    try:
                        pend = obj.get(PENDING_ZERO_KEY)
                    except Exception:
                        pend = None
                    _ov = 0.0 if pend else None
                    if adapt_object(obj, camera, st, view_now=view, drag_override=_ov):
                        n_ok += 1
                        if pend:
                            _reset_drag_state(obj)
                            try:
                                del obj[PENDING_ZERO_KEY]
                            except Exception:
                                pass
                if cam_changed and n_ok > 0:
                    _last_view[key] = (view.copy(), lens_now)
            except Exception:
                traceback.print_exc()
                continue
    except Exception:
        import traceback as _tb
        _tb.print_exc()
    finally:
        _handler_guard = False
        # ★ 回收 _last_view（独立审查 第五轮 🟡-6）：相机被删除/改名后它的条目永不释放，
        #   随「创建/删除相机」次数单调增长，且 key 里的场景指针可能被新场景复用
        #   ⇒ 新场景的同名相机会被误判"没动过"而跳过适配。
        #   ⚠️ 必须放在 **finally** —— 原来在函数末尾，而上面有几条 `return` 早退路径
        #      （最典型：`if not groups: return`），走那些路径就完全跳过回收。
        try:
            if _last_view:
                _alive_cam = {c.name for c in bpy.data.cameras}
                # ⚠️ 还要按【场景指针】回收（独立审查 第六轮 🟡-5）：
                #    只按相机名判会让「已删场景」的条目永远删不掉 ——
                #    新场景里的同名相机（例如都叫 "Camera"）还活着，
                #    于是桌面会话反复开关 .blend 会让它单调增长；
                #    而 key 里的场景指针**可能被新场景复用** ⇒ 新场景的同名相机
                #    会被误判"没动过"而永久跳过适配（静默失效）。
                _alive_scn = {s.as_pointer() for s in bpy.data.scenes}
                for _k in [k for k in _last_view
                           if k[1] not in _alive_cam or k[0] not in _alive_scn]:
                    _last_view.pop(_k, None)
        except Exception:
            pass


def _matrices_close(a, b, tol):
    for i in range(4):
        for j in range(4):
            if abs(a[i][j] - b[i][j]) > tol:
                return False
    return True


# ──────────────────────────── 注册 ────────────────────────────

def register_handlers():
    h = bpy.app.handlers.depsgraph_update_post
    if parallax_lock_update_handler not in h:
        h.append(parallax_lock_update_handler)


def unregister_handlers():
    h = bpy.app.handlers.depsgraph_update_post
    if parallax_lock_update_handler in h:
        h.remove(parallax_lock_update_handler)
    _last_view.clear()
    _base_cache.clear()
    # ★ 弹窗 timer 也要注销 —— 否则插件被禁用/重载后 timer 还在跑，
    #   轻则残留回调，重则在模块已被卸载的情况下访问 bpy 而崩溃。
    cancel_popup_timer()
    _popup_shown.clear()
    _backfill_warned.clear()
