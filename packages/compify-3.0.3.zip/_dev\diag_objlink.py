"""搞清楚：什么情况下材质只出现在 material_slots、不出现在 data.materials？

这决定 objects_using_projection 到底会不会漏。

Blender 语义：
  material_slots 是「网格材质列表」的投影，slot.link 只决定用 data 的还是 object 覆盖的。
尝试几种构造：
  ① 正常 append 到 data 后设 link=OBJECT
  ② 先设 link=OBJECT 再 append
  ③ data.materials.clear() 之后
  ④ 材质槽从 data 复制后单独赋值
  ⑤ 用 bpy.ops.object.material_slot_add（需 data 有材质）
"""
import bpy, sys, os

sys.stdout.reconfigure(encoding="utf-8")


def fresh():
    return bpy.data.materials.new("M")


def report(tag, ob):
    dm = [m.name if m else None for m in ob.data.materials]
    sl = [(s.link, s.material.name if s.material else None) for s in ob.material_slots]
    print("  %-34s data.materials=%-18s slots=%s" % (tag, dm, sl))


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene

print("=" * 84)
print("各种构造下 data.materials 与 material_slots 的关系")
print("=" * 84)

# ① 正常 append 后设 OBJECT
me = bpy.data.meshes.new("mA")
ob = bpy.data.objects.new("A", me)
sc.collection.objects.link(ob)
m = fresh()
me.materials.append(m)
report("① append 到 data", ob)
ob.material_slots[0].link = "OBJECT"
report("① 再设 link=OBJECT", ob)

# ③ 清空 data.materials
me2 = bpy.data.meshes.new("mB")
ob2 = bpy.data.objects.new("B", me2)
sc.collection.objects.link(ob2)
m2 = fresh()
me2.materials.append(m2)
ob2.material_slots[0].link = "OBJECT"
ob2.material_slots[0].material = m2
report("③ 设 OBJECT 前", ob2)
me2.materials.clear()
report("③ data.materials.clear() 后", ob2)
print("     → slots 数量 =", len(ob2.material_slots))

# ④ 试图给空 mesh 加 slot
me3 = bpy.data.meshes.new("mC")
ob3 = bpy.data.objects.new("C", me3)
sc.collection.objects.link(ob3)
print("  ④ 空 mesh slots 数 =", len(ob3.material_slots))
try:
    bpy.context.view_layer.objects.active = ob3
    bpy.ops.object.material_slot_add()
    report("④ material_slot_add 后", ob3)
except Exception as e:
    print("  ④ material_slot_add 失败:", type(e).__name__, e)

# ⑤ 直接给 slot 赋材质（data 没有材质）
me4 = bpy.data.meshes.new("mD")
ob4 = bpy.data.objects.new("D", me4)
sc.collection.objects.link(ob4)
me4.materials.append(fresh())
ob4.data.materials.clear()
print("  ⑤ 清空后 slots 数 =", len(ob4.material_slots))
if len(ob4.material_slots):
    try:
        ob4.material_slots[0].link = "OBJECT"
        ob4.material_slots[0].material = fresh()
        report("⑤ 清空后强制赋 OBJECT 材质", ob4)
    except Exception as e:
        print("  ⑤ 失败:", type(e).__name__, e)

# ⑥ 两个物体共享 mesh，一个 OBJECT link 覆盖
me5 = bpy.data.meshes.new("mE")
me5.materials.append(fresh())
o1 = bpy.data.objects.new("E1", me5)
o2 = bpy.data.objects.new("E2", me5)
sc.collection.objects.link(o1)
sc.collection.objects.link(o2)
o2.material_slots[0].link = "OBJECT"
o2.material_slots[0].material = fresh()
print(" ⑥ 共享 mesh + E2 OBJECT 覆盖：")
report("   E1", o1)
report("   E2", o2)

print()
print("=" * 84)
print("结论")
print("=" * 84)
print("  如果所有情形下 data.materials 都非空 ⇒ 只扫 data.materials 不会漏，")
print("  object-linked 那条是误报；否则需要某种特定构造才会漏。")
print("OBJDONE")
