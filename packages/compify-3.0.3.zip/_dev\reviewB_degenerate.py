"""审查 B-1：空网格 / 1 顶点 / 只有边没有面。

跑法：
  G:\\steam\\steamapps\\common\\Blender\\blender.exe --background --factory-startup --python _dev\\reviewB_degenerate.py
"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 90)
print("B-1 退化网格：0 顶点 / 1 顶点 / 只有边")
print("=" * 90)

# ─────────────────────────────────────────────────────────
print("\n### A. 场景里只有一个 0 顶点网格（带投影材质）###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
me = bpy.data.meshes.new("EmptyMesh")
ob = bpy.data.objects.new("EmptyMesh", me)
sc.collection.objects.link(ob)
me.materials.append(mat)
C.attach(ob, cam)
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock 返回 success=%s frozen=%s" % (r["success"], r.get("frozen")))
    print("   message:", r["message"][:120])
    ok = True
except Exception as e:
    ok = False
    print("   ✗ lock_group 抛异常:", type(e).__name__, e)
C.chk("A1 空网格单独存在时 lock 不抛异常", ok)
r = plock.lock_group(sc, cam) if ok else {}
C.chk("A2 空网格不会被当成「可锁定」，success=False", r.get("success") is False,
      str(r.get("success")))
print("   属性:", {k: v[:3] for k, v in C.attrs(ob).items()})

# ─────────────────────────────────────────────────────────
print("\n### B. 正常网格 + 一个 0 顶点网格（都用同一投影材质）###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
em = bpy.data.meshes.new("EmptyMesh2")
eo = bpy.data.objects.new("EmptyMesh2", em)
sc.collection.objects.link(eo)
em.materials.append(mat)
C.attach(eo, cam)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s locked=%d" %
      (r["success"], r.get("frozen"), len(r.get("locked", []))))
print("   unsupported:", [(n if isinstance(n, str) else "<obj>", w) for n, w in r.get("unsupported", [])])
print("   message:", r["message"][:220])
fv0 = C.campos_uv(A, cd.name)
cam.location.x = 2.0
C.run_handler(sc)
fv1 = C.campos_uv(A, cd.name)
d_frozen = float(np.abs(fv1 - fv0).max()) if (fv0 is not None and fv1 is not None) else -1
C.chk("B1 一个空网格【不应该】让整个相机的图案冻结失效（frozen=True 才合理）",
      r.get("frozen") is True, "frozen=%s（空网格把整个冻结关掉了？）" % r.get("frozen"))
C.chk("B2 空网格存在时正常网格的冻结坐标仍在用（图案粘住网格）",
      fv0 is not None and fv1 is not None and d_frozen < 1e-6,
      "逐顶点UV Δ=%.3e (campos 存在=%s)" % (d_frozen, fv0 is not None))

# 面板/状态是否显示为「图案未冻结」
st = plock.lock_status(sc, cam)
print("   lock_status:", {k: st.get(k) for k in ("locked", "patched", "frozen", "degraded")
                          if k in st})

# ─────────────────────────────────────────────────────────
print("\n### C. 只有一个顶点的网格（退化，但顶点数 > 0）###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
me = bpy.data.meshes.new("OneVert")
me.from_pydata([(0.0, 0.0, 0.0)], [], [])
me.update()
o1 = bpy.data.objects.new("OneVert", me)
sc.collection.objects.link(o1)
me.materials.append(mat)
C.attach(o1, cam)
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock: success=%s frozen=%s locked=%d message=%s" %
          (r["success"], r.get("frozen"), len(r.get("locked", [])), r["message"][:100]))
    exc = None
except Exception as e:
    exc = e
    print("   ✗ lock 抛异常:", type(e).__name__, e)
C.chk("C1 单顶点网格 lock 不抛异常", exc is None)
if exc is None and r.get("success"):
    nodes = plock._find_delta_nodes(cd.name)
    S0 = nodes[0].inputs["Scale"].default_value if nodes else None
    C0 = tuple(nodes[1].inputs[1].default_value)[:2] if nodes else None
    print("   锁定中 S=%s C=%s" % (S0, C0))
    cam.data.lens = 85.0
    C.run_handler(sc)
    bpy.context.view_layer.update()
    ru = plock.unlock_group(sc, cam)
    nodes = plock._find_delta_nodes(cd.name)
    S1 = nodes[0].inputs["Scale"].default_value if nodes else None
    C1 = tuple(nodes[1].inputs[1].default_value)[:2] if nodes else None
    print("   解锁后 S=%.6f C=(%.6f, %.6f)" % (S1, C1[0], C1[1]))
    print("   unlock message:", ru["message"][:120])
    C.chk("C2 单顶点网格解锁后 S 应≈1、C≈0（无跳变可落实）",
          abs(S1 - 1.0) < 1e-3 and abs(C1[0]) < 1e-3 and abs(C1[1]) < 1e-3,
          "S=%.6f C=(%.6f,%.6f)" % (S1, C1[0], C1[1]))
    # 解锁后相机再动 → 图案应随投影滑动（UV 应当变化）
    u0 = C.uvimg("one")
    cam.location.x += 1.0
    C.run_handler(sc)
    u1 = C.uvimg("one")
    print("   解锁后再移相机：渲染差 = %.5f（0 = 图案被永久钉死）" % C.uvd(u0, u1))

# ─────────────────────────────────────────────────────────
print("\n### D. 只有边没有面（曲线转 mesh 的常见产物）###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
me = bpy.data.meshes.new("EdgeOnly")
me.from_pydata([(-1, 0, 0), (0, 0, 0), (1, 0, 0)], [(0, 1), (1, 2)], [])
me.update()
o2 = bpy.data.objects.new("EdgeOnly", me)
sc.collection.objects.link(o2)
me.materials.append(mat)
C.attach(o2, cam)
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock: success=%s frozen=%s locked=%d" % (r["success"], r.get("frozen"),
                                                      len(r.get("locked", []))))
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 抛异常:", type(e).__name__, e)
C.chk("D1 只有边的网格 lock 不抛异常", exc is None)
C.chk("D2 只有边的网格能被正常锁定（有顶点、深度正常）",
      exc is None and r.get("success") and len(r.get("locked", [])) == 1,
      "locked=%d" % (len(r.get("locked", [])) if exc is None else -1))
if exc is None and r.get("success"):
    nan_attrs, vn, n_uv, all_at = C.nan_report(o2, cd.name)
    print("   属性:", {k: (v[2], v[3], v[4]) for k, v in all_at.items()})
    C.chk("D3 只有边的网格属性里没有 nan/inf", not nan_attrs and not (vn[0] or vn[1]) and n_uv == 0,
          "nan属性=%s 顶点nan=%s UV_nan=%d" % (nan_attrs, vn, n_uv))

C.summary()
