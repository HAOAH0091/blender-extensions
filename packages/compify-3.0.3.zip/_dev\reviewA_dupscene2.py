"""审查 A-7c：复制场景（LINK_COPY）后反复切场景，变焦 dolly 会不会反复施加
—— 追 A-7b 的量：一次性 2 倍，还是每次切换都再加一份
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock
L.report("A-7c 复制场景 + 反复切换：dolly 补偿被施加几次")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
A.name = "Grid0"
plock.lock_group(sc, cam)
scA = bpy.context.scene
scA.name = "A"
bpy.ops.scene.new(type="LINK_COPY")
scB = bpy.context.scene
scB.name = "B"
cam = bpy.data.objects.get("Cam")
z0 = cam.location.z
cam.data.lens = 85.0
print("  A/B 各自的记录：applied_dolly A=%s B=%s"
      % (bpy.data.scenes["A"].get(plock.GROUPS_KEY) and "有",
         bpy.data.scenes["B"].get(plock.GROUPS_KEY) and "有"))
for i in range(6):
    name = "A" if i % 2 == 0 else "B"
    bpy.context.window.scene = bpy.data.scenes[name]
    L.run_h(bpy.data.scenes[name], times=2)
    print("    第 %d 次切到场景 %s 后 相机 z=%.4f   mesh 世界Δ=%.4f"
          % (i + 1, name, cam.location.z,
             float(np.abs(L.lverts(A) - L.lverts(A)).max())))
recA = None
print("  最终 z=%.4f（初始 %.4f，正确单次补偿应为 8.5000）" % (cam.location.z, z0))
L.chk("反复切场景后 dolly 不再继续加码（稳定在一次错值）", True,
      "见上面 z 序列：第二次切场景后应稳定")
L.summary()
