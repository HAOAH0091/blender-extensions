"""回归网（第五轮独立审查）：盯 🔴-1/2/3 与 🟡-1/2/6。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL。

★ 本文件的核心是 E1：**「重置」必须回到「首次锁定前」的形状**。
  审查员指出：此前所有回归都在测"适配正确"，**没有一条在测"原形可找回"**
  —— 这正是 🔴-1 能长期潜伏的原因。这里把它固化成门禁。
"""
import bpy
import sys
import os
import json
import importlib.util
import mathutils as MU

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-56s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene


def mkcam(sc, name="Cam", loc=(0.0, 0.0, 6.0)):
    cd = bpy.data.cameras.new(name); cd.lens = 50.0; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def mkobjs(sc, cam, spec_list, prefix="P", extra_mat=None):
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i, (x, z) in enumerate(spec_list):
        bpy.ops.mesh.primitive_plane_add(size=2.0, location=(x, 0.0, z))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        if extra_mat is not None:
            ob.data.materials.append(extra_mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        if extra_mat is not None:
            for _c in (extra_mat,):
                pass
        out.append(ob)
    bpy.context.view_layer.update()
    return out


def wco(ob):
    return [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]


def md(a, b):
    return max(max(abs(x[i] - y[i]) for i in range(3)) for x, y in zip(a, b))


def run(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


# ═════════ E1：reset 必须回到【首次锁定前】的形状（门禁）═════════
print("=" * 70)
print("E1  「重置」回到【首次锁定前】的原形（含 解锁→再锁定 路径）")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, [(0.0, 0.0), (0.0, -2.0), (0.0, -4.0)], "A")
orig = [wco(o) for o in objs]
plock.lock_group(sc, cam)
cam.location.x = 1.5
run(sc)
adapted = [wco(o) for o in objs]
plock.unlock_group(sc, cam)
plock.lock_group(sc, cam)                    # ★ 再锁定
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
after = [wco(o) for o in objs]
d_orig = max(md(o, a) for o, a in zip(orig, after))
d_adap = max(md(o, a) for o, a in zip(adapted, after))
print("   与【原始】差 = %.6f | 与【适配后】差 = %.6f" % (d_orig, d_adap))
chk("E1-a 平移路径：解锁→再锁定后 重置 = 原形", d_orig < 1e-5, "偏差 %.6f" % d_orig)
chk("E1-b 且与「适配后形状」不同（排除空对空）", d_adap > 1e-6,
    "与适配后差 %.6f" % d_adap)

# 变焦路径
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, [(0.0, 0.0), (0.0, -2.0)], "B")
orig = [wco(o) for o in objs]
plock.lock_group(sc, cam)
cam.data.lens = 85.0
run(sc)
plock.unlock_group(sc, cam)
plock.lock_group(sc, cam)
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
d2 = max(md(o, a) for o, a in zip(orig, [wco(o) for o in objs]))
chk("E1-c 变焦路径：重置 = 原形", d2 < 1e-5, "偏差 %.6f" % d2)

# 反复循环也不漂
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, [(0.0, 0.0), (0.0, -2.0)], "C")
orig = [wco(o) for o in objs]
for rd in range(3):
    plock.lock_group(sc, cam)
    cam.location.x = 0.7 * (rd + 1)
    run(sc)
    plock.unlock_group(sc, cam)
    plock.lock_group(sc, cam)
    plock.reset_group(sc, cam)
    bpy.context.view_layer.update()
    d = max(md(o, a) for o, a in zip(orig, [wco(o) for o in objs]))
    print("   第 %d 轮后与原始差 = %.6f" % (rd + 1, d))
chk("E1-d 三轮「锁→移→解锁→再锁→重置」不漂移", d < 1e-5, "末轮偏差 %.2e" % d)

# ═════════ E2：互斥迁移后被抢走网格的几何 ═════════
print()
print("=" * 70)
print("E2  互斥迁移：被抢走网格的几何必须回到原形")
sc = fresh()
cA = mkcam(sc, "CamA"); sc.camera = cA
cB = mkcam(sc, "CamB")
grpA = ng.ensure_camera_project_group(cA, default_aspect=1.0)
grpB = ng.ensure_camera_project_group(cB, default_aspect=1.0)


def _mat(name, grp):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    return m


matA = _mat("MA", grpA)
matB = _mat("MB", grpB)
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, 0.0))
P1 = bpy.context.active_object; P1.name = "P1"
P1.data.materials.append(matA); P1.data.materials.append(matB)
for c in (cA, cB):
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (P1.data.name, c.data.name), "ShaderNodeTree")
# ⚠️ 再加一层（只归 A）—— 必须**多层**才会有视差：
#    单层网格时 k = d/ref = 1（均匀补偿），相机平移/变焦后**世界位置本就不变**
#    （只做屏幕滚动 / 相机自己 dolly），那样测出来是**空对空**。
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, -3.0))
P2 = bpy.context.active_object; P2.name = "P2"
P2.data.materials.append(matA)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (P2.data.name, cA.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
w0 = wco(P1)
plock.lock_group(sc, cA)
cA.data.lens = 100.0
run(sc)
chk("E2-a 前置：多层 + 变焦后几何确实变形（非空对空）", md(w0, wco(P1)) > 1e-6,
    "位移 %.6f" % md(w0, wco(P1)))
plock.lock_group(sc, cB)                     # ★ B 抢走 P1
w_after_migrate = wco(P1)
cA.location.x = 0.0
plock.reset_group(sc, cA)
bpy.context.view_layer.update()
print("   迁移后与【原始】差 = %.6f" % md(w0, w_after_migrate))
chk("E2-b 迁移当时就把几何还原（不等 reset）", md(w0, w_after_migrate) < 1e-5,
    "偏差 %.6f" % md(w0, w_after_migrate))

# ═════════ E3：共享网格时必须明说「图案不会冻结」 ═════════
print()
print("=" * 70)
print("E3  共享网格：消息必须说明图案不会冻结 + 返回带 frozen")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = _mat("MS", grp)
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, 0.0))
SRC = bpy.context.active_object; SRC.name = "SRC"
SRC.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (SRC.data.name, cam.data.name), "ShaderNodeTree")
DUP = bpy.data.objects.new("DUP", SRC.data)
sc.collection.objects.link(DUP)
DUP.location = (4.0, 0.0, -2.0)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   message=%r" % r.get("message"))
print("   keys=%s" % list(r.keys()))
chk("E3-a 提前 return 路径带 frozen 字段", "frozen" in r, str(list(r.keys())))
chk("E3-b 消息点明图案不会冻结",
    "冻结" in str(r.get("message")) and ("不会" in str(r.get("message")) or "未" in str(r.get("message"))),
    str(r.get("message"))[-34:])
chk("E3-c 无目标时也带 frozen 字段",
    "frozen" in plock.lock_group(sc, mkcam(sc, "CamEmpty")), "")

# ═════════ E4：损坏存档（记录非 dict）不得让面板崩 ═════════
print()
print("=" * 70)
print("E4  损坏存档（记录是字符串）：判定函数必须安全")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, [(0.0, 0.0)], "D")
plock.lock_group(sc, cam)
bad = json.loads(sc.get(plock.GROUPS_KEY))
bad[cam.data.name] = "notadict"
sc[plock.GROUPS_KEY] = json.dumps(bad)
ok_all = True
for nm, fn in [("lock_status", lambda: plock.lock_status(sc, cam)),
               ("has_lock_record", lambda: plock.has_lock_record(sc, cam)),
               ("is_locked", lambda: plock.is_locked(sc, cam)),
               ("get_state", lambda: plock.get_state(sc, cam))]:
    try:
        v = fn()
    except Exception as e:
        ok_all = False
        print("   ★ %s → %s: %s" % (nm, type(e).__name__, str(e)[:40]))
chk("E4-a 四个判定函数对非 dict 记录都不抛异常", ok_all)
chk("E4-b 非 dict 记录被当作「无记录」", not plock.has_lock_record(sc, cam))

# ═════════ E5：锁定后新接入投影材质的对象要补写冻结坐标 ═════
print()
print("=" * 70)
print("E5  锁定后新接入投影材质的对象：handler 是否补写冻结坐标")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, [(0.0, 0.0)], "E")
plock.lock_group(sc, cam)
# 新对象接入同一投影材质
nt = objs[0].data.materials[0].node_tree
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(1.0, 0.0, -1.5))
NEW = bpy.context.active_object; NEW.name = "NEW"
NEW.data.materials.append(objs[0].data.materials[0])
bpy.data.node_groups.new("UV Adjust | %s | %s" % (NEW.data.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
print("   新对象有冻结坐标:", plock._campos_is_valid(NEW, cam.data.name))
cam.location.x = 0.3
run(sc)
print("   跑 handler 后:", plock._campos_is_valid(NEW, cam.data.name))
chk("E5-a handler 给新接入的对象补写了冻结坐标",
    plock._campos_is_valid(NEW, cam.data.name))

# ═════════ E6：groups 为空时 _last_view 也要回收 ═════
print()
print("=" * 70)
print("E6  场景记录清空后，_last_view 仍要回收")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, [(0.0, 0.0)], "F")
plock.lock_group(sc, cam)
plock._last_view.clear()
plock.lock_group(sc, cam)
_cd = cam.data
bpy.data.objects.remove(cam, do_unlink=True)             # 删掉相机对象
# ⚠️ 连数据块一起删：只删对象的话 `bpy.data.cameras` 里还留着同名数据块，
#    回收判据（按相机名）会认为"相机还在"⇒ 不回收（我的测试自己漏了这步）。
try:
    if _cd is not None and _cd.users == 0:
        bpy.data.cameras.remove(_cd)
except Exception:
    pass
sc[plock.GROUPS_KEY] = "{}"                              # 记录也清空
before = len(plock._last_view)
run(sc)
after = len(plock._last_view)
print("   groups 为空：跑 handler 前 %d 条 → 后 %d 条" % (before, after))
chk("E6-a groups 为空时仍执行回收", after == 0, "残留 %d" % after)

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX4_DONE")
