"""审查 A-11：两个相机【共用同一个相机数据块】（Alt+D 链接复制 / 手工重指 data）
锁定记录按「数据名」索引 ⇒ 两台相机共用一条记录，handler 只能驱动其中一台
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock
L.report("A-11 两台相机共用一个相机数据块：锁定状态能不能分别成立")
C = L.build(n_grid=3)
sc, cam1, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
A.name = "Grid0"
# 第二台相机：Alt+D 式（共享同一个 data）
cam2 = bpy.data.objects.new("Cam2", cd)
sc.collection.objects.link(cam2)
cam2.location = (2.0, 0, 5.0)
sc.camera = cam2
bpy.context.view_layer.update()

r = plock.lock_group(sc, cam2)
st = plock.load_groups(sc).get(cd.name, {})
lm = st.get("locked_matrix")
print("  用 Cam2 锁定：%s" % r["message"][:44])
print("    记录 key=%s（相机数据名）locked_matrix 平移=%s（Cam2 在 x=2，Cam1 在 x=0）"
      % (cd.name, tuple(round(x, 3) for x in (lm[0][3], lm[1][3], lm[2][3])) if lm else None))
print("    is_locked(Cam1)=%s  is_locked(Cam2)=%s"
      % (plock.is_locked(sc, cam1), plock.is_locked(sc, cam2)))
found = plock.find_camera(sc, cd.name, st.get("cam_uid"))
print("    handler 实际驱动哪台：%s" % (found.name if found else None))

# 锁定中改焦距（data 共享 ⇒ 两台相机一起变；插件只应推「被锁的那台」）
g0 = L.lverts(A).copy()
cd.lens = 85.0
L.run_h(sc, times=2)
print("  锁定中把焦距 50→85：Cam1 z=%.3f  Cam2 z=%.3f  mesh 变形Δ=%.3f"
      % (cam1.location.z, cam2.location.z, float(np.abs(L.lverts(A) - g0).max())))
L.chk("变焦补偿推的是「用户锁定的那台」相机", abs(cam1.location.z - 5.0) < 1e-6,
      "被锁的是 Cam2（scene.camera，z=%.3f 未动），被推的却是 Cam1（z=%.3f，多推 %.3f）"
      % (cam2.location.z, cam1.location.z, cam1.location.z - 5.0))
L.chk("两台相机不会同时显示为「已锁定」", not (plock.is_locked(sc, cam1)
                                             and plock.is_locked(sc, cam2)),
      "is_locked(Cam1)=%s is_locked(Cam2)=%s —— 记录按数据名索引，两台共用一条"
      % (plock.is_locked(sc, cam1), plock.is_locked(sc, cam2)))
r = plock.unlock_group(sc, cam2)
print("  用 Cam2 解锁后：Cam1 z=%.3f Cam2 z=%.3f" % (cam1.location.z, cam2.location.z))
r2 = plock.reset_group(sc, cam2)
z_after_reset2 = (cam1.location.z, cam2.location.z)
print("  再用 Cam2 重置后：Cam1 z=%.3f Cam2 z=%.3f" % z_after_reset2)
r3 = plock.reset_group(sc, cam1)
print("  再用 Cam1 重置后：Cam1 z=%.3f Cam2 z=%.3f（Cam1 自己那份 dolly 记账）"
      % (cam1.location.z, cam2.location.z))
L.chk("被推走的相机能被 UI 收回原位", abs(z_after_reset2[0] - 5.0) < 1e-6,
      "走完解锁+重置后 Cam1 仍停在 z=%.3f（残差 %.3f）"
      % (z_after_reset2[0], z_after_reset2[0] - 5.0))
L.summary()
