"""复核 9b（用「非基准深度的层」才能看出适配是否生效）+ 单顶点网格把全局 S 写成 0 的传播。

跑法：blender --background --factory-startup --python _dev\\reviewB_base_rename.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 94)
print("9b 复核 + 退化网格把 S 写成 0 的传播")
print("=" * 94)


def geo(ob):
    return np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])


# ══════════════════════════════════════════════════════
print("\n### 复核 9b：base 属性被改名 → 适配是否静默失效 ###")
for mode in ("ok", "renamed"):
    sc, cam, cd, grp = C.setup()
    mat = C.probe_mat(grp)
    A = C.add_grid("GridNear", cam, mat, ns=3)                       # z=0 深度 5
    DEEP = C.add_grid("GridDeep", cam, mat, ns=3, shape="倾斜")       # z 有起伏
    DEEP.location = (0, 0, -3)                                       # 深度 8 = 基准层
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    if mode == "renamed":
        A.data.attributes.get(plock.BASE_ATTR).name = "hacked_base"
        bpy.context.view_layer.update()
    w0 = geo(A)
    cam.location.x = 2.0
    C.run_handler(sc)
    d = float(np.abs(geo(A) - w0).max())
    print("   %-8s 相机横移 2.0 后（非基准层）几何 Δ=%.6f  base自愈=%s"
          % (mode, d, A.data.attributes.get(plock.BASE_ATTR) is not None))
    if mode == "ok":
        d_ok = d
    else:
        d_bad = d
C.chk("9b base 被改名后仍能适配（否则是静默失效）", d_bad > 1e-6,
      "Δ=%.2e（正常时应为 %.2e）" % (d_bad, d_ok))

# ══════════════════════════════════════════════════════
print("\n### 单顶点网格：解锁时把投影组的 S 写成 0（组级共享 → 影响之后接入的网格）###")
for tag, degenerate in (("对照：正常网格当唯一锁定目标", False),
                        ("单顶点网格当唯一锁定目标", True)):
    sc, cam, cd, grp = C.setup()
    mat = C.probe_mat(grp)
    if degenerate:
        me = bpy.data.meshes.new("OneVert")
        me.from_pydata([(0.0, 0.0, 0.0)], [], [])
        me.update()
        T = bpy.data.objects.new("OneVert", me)
        sc.collection.objects.link(T)
        me.materials.append(mat)
        C.attach(T, cam)
    else:
        T = C.add_grid("GridT", cam, mat, ns=6, H=3.0)
    bpy.context.view_layer.update()
    r = plock.lock_group(sc, cam)
    # 只变焦、不横移：单顶点始终落在相机光轴上（u=v=0），这正是退化输入
    cam.data.lens = 72.0
    C.run_handler(sc)
    ru = plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    nodes = plock._find_delta_nodes(cd.name)
    S = nodes[0].inputs["Scale"].default_value
    Cc = tuple(nodes[1].inputs[1].default_value)[:2]
    # 解锁之后才接入投影材质的**普通网格**（用户最常见的后续动作）
    N = C.add_grid("GridNew", cam, mat, ns=6, H=3.0, uvadjust=False)
    bpy.context.view_layer.update()
    u_new = C.uvimg("s0")
    sd = float(np.std(u_new[..., 0]))
    print("   %-24s locked=%s → 解锁 S=%.6f C=(%+.4f,%+.4f)"
          % (tag, [o.name for o in r.get("locked", [])], S, Cc[0], Cc[1]))
    print("        unlock message:", ru["message"][:110])
    lo = plock.locked_objects(sc, cd.name)
    for _o in lo:
        _a = _o.data.attributes.get(plock._campos_attr_name(cd.name))
        print("        %s campos len=%s 顶点=%d" % (_o.name, len(_a.data) if _a else None,
                                                  len(_o.data.vertices)))
    print("        解锁后新接入网格的投影：UV 编码标准差=%.4f（0 = 纯色/投影没了）" % sd)
    if degenerate:
        S_bad, C_bad, sd_bad = S, Cc, sd
    else:
        S_ok, sd_ok = S, sd
C.chk("单顶点网格不应把全局 S 写成 0（S≈1 才不破坏其它网格的实时投影）",
      abs(S_bad - 1.0) < 1e-3, "单顶点 S=%.6f vs 正常 S=%.6f" % (S_bad, S_ok))
C.chk("退化目标解锁后其它网格仍有投影梯度（非纯色）", sd_bad > sd_ok * 0.5,
      "UV 标准差 %.4f vs 正常 %.4f" % (sd_bad, sd_ok))

C.summary()
