"""量化病态判据：正常场景 vs 病态场景，lstsq 的残差 / S / 有效顶点占比
目标：找出一个不会误伤正常场景的安全检查条件。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(tilt=0.0, cam_loc=(0, 0, 5)):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = cam_loc
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 3; h = 2.0
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -h + 2*h*ix/ns
            y = -h + 2*h*iy/ns
            verts.append((x, y, tilt * x))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def gather(cam, cd, ob, cam_name):
    """复刻 unlock 里的采集逻辑，并额外算残差与有效顶点占比"""
    a = ob.data.attributes.get(plock._campos_attr_name(cam_name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    n = len(a.data)
    buf = np.empty(n*3, dtype=np.float64)
    a.data.foreach_get("vector", buf)
    fz = buf.reshape(-1, 3)
    vco = np.empty(n*3, dtype=np.float64)
    ob.data.vertices.foreach_get("co", vco)
    vco = vco.reshape(-1, 3)
    L2C = np.array(cam.matrix_world.inverted() @ ob.matrix_world, dtype=np.float64)
    live3 = vco @ L2C[:3, :3].T + L2C[:3, 3]
    fp, ok1 = plock._persp_np(fz)
    lp, ok2 = plock._persp_np(live3)
    ok = ok1 & ok2
    n_ok = int(ok.sum())
    z = live3[:, 2]
    out = {
        "n_total": n, "n_ok": n_ok,
        "live_z_min": float(z.min()), "live_z_max": float(z.max()),
        "n_abs_z_lt_001": int((np.abs(z) < 0.01).sum()),
        "n_negative_z": int((z < 0).sum()),
    }
    if n_ok == 0:
        return out
    F = fp[ok]; L = lp[ok]
    params = plock.fit_delta_params(F, L, 1.0)
    out["params"] = params
    if params:
        S, C = params
        pred = L * S + np.array(C)
        out["resid_max"] = float(np.abs(pred - F).max())
        out["resid_mean"] = float(np.abs(pred - F).mean())
        # 相对量：残差相对 UV 量级
        out["uv_scale"] = float(np.abs(F).max())
    return out


def show(tag, d):
    if d is None:
        print("  %-30s 采集失败" % tag); return
    if "params" not in d or d["params"] is None:
        print("  %-30s ok=%d/%d  fit=None" % (tag, d["n_ok"], d["n_total"])); return
    S, C = d["params"]
    print("  %-30s ok=%2d/%2d  live_z∈[%+.3f,%+.3f]  |z|<0.01 的=%d  z<0 的=%d"
          % (tag, d["n_ok"], d["n_total"], d["live_z_min"], d["live_z_max"],
             d["n_abs_z_lt_001"], d["n_negative_z"]))
    print("  %-30s S=%.6f  C=(%+.6f,%+.6f)  残差max=%.3e  UV量级=%.2f  相对残差=%.2e"
          % ("", S, C[0], C[1], d.get("resid_max", -1), d.get("uv_scale", -1),
             d.get("resid_max", -1) / max(d.get("uv_scale", 1), 1e-9)))


print("=" * 96)
print("正常场景 vs 病态场景：lstsq 解的特征")
print("=" * 96)

cases = [
    ("正常·平移x+2",      dict(tilt=0.0), (2.0, 0, 5), None),
    ("正常·变焦85",       dict(tilt=0.0), (0, 0, 5), "zoom85"),
    ("正常·偏移+变焦",    dict(tilt=0.0), (1.5, -0.8, 5), "zoom85"),
    ("正常·倾斜+平移",    dict(tilt=0.3), (2.0, 0, 5), None),
    ("病态·相机在平面上", dict(tilt=0.0), (0, 0, 0), None),
    ("病态·倾斜部分穿过", dict(tilt=0.5), (0, 0, 1.0), None),
    ("病态·全部穿过后",   dict(tilt=0.0), (0, 0, -1.0), None),
    ("半病态·很近",       dict(tilt=0.5), (0, 0, 0.3), None),
]

for tag, kw, loc, act in cases:
    sc, cam, cd, ob = build(**kw)
    plock.lock_group(sc, cam)
    if act == "zoom85":
        cd.lens = 85.0
    cam.location = loc
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    d = gather(cam, cd, ob, cd.name)
    show(tag, d)
    print()

print("FITDIAG_DONE")
