"""回归网（第三轮独立审查）：盯 第三轮 F1 / F2 / F3 / F4 / F5 / F7。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL。
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]
MU = importlib.import_module("mathutils")

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-54s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene


def make_cam(sc, name="Cam", loc=(0.0, 0.0, 5.0), lens=50.0, link=True):
    cd = bpy.data.cameras.new(name); cd.lens = lens; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    if link:
        sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def make_planes(sc, cam, n, prefix="P", with_group=True):
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    if with_group:
        grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
        g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
        o = nt.nodes.new("ShaderNodeOutputMaterial")
        nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i in range(n):
        bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, -float(i)))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out


def comp(ob, view, lens, sensor=36.0):
    """构图度量：归一化像面坐标 u = (cs.x/d)·(lens/sensor)。

    ⚠️ 必须含焦距因子 —— 只量 cs.x/d 会把"正确冻结"误判成错位。
    """
    f = lens / sensor
    out = []
    for v in ob.data.vertices:
        cs = view.inverted() @ (ob.matrix_world @ v.co)
        d = -cs.z
        out.append(None if d <= 1e-6 else (cs.x / d * f, cs.y / d * f))
    return out


# ═══ F1：相机带父级（Ctrl+P Keep Transform）变焦不得破坏构图 ═══
print("=" * 68)
print("F1  Ctrl+P(Keep Transform) 挂父级后变焦，构图仍精确冻结")
sc = fresh()
cam = make_cam(sc, link=False); sc.collection.objects.link(cam); sc.camera = cam
par = bpy.data.objects.new("Parent", None); sc.collection.objects.link(par)
par.location = (3.0, -2.0, 1.0)
par.rotation_euler = (math.radians(15), math.radians(25), math.radians(40))
bpy.context.view_layer.update()
bpy.ops.object.select_all(action="DESELECT")
cam.select_set(True); par.select_set(True)
bpy.context.view_layer.objects.active = par
bpy.ops.object.parent_set(type="OBJECT", keep_transform=True)
bpy.context.view_layer.update()
mpi = cam.matrix_parent_inverse
is_id = all(abs(mpi[i][j] - (1.0 if i == j else 0.0)) < 1e-9 for i in range(4) for j in range(4))
print("   matrix_parent_inverse 单位阵?", is_id, "（Keep Transform 下应为 False）")
objs = make_planes(sc, cam, 2, "F1")
plock.lock_group(sc, cam)
s0 = comp(objs[0], plock.get_camera_view_matrix(cam), cam.data.lens)
errs = []
for lens in (85.0, 200.0, 400.0):
    cam.data.lens = lens
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    s = comp(objs[0], plock.get_camera_view_matrix(cam), cam.data.lens)
    errs.append(max((abs(a[0] - b[0]) + abs(a[1] - b[1])) for a, b in zip(s, s0) if a and b))
print("   变焦 85/200/400 误差:", ["%.6f" % e for e in errs])
chk("F1  带父级(Keep Transform)时变焦构图冻结", max(errs) < 1e-4, "最大 %.6f" % max(errs))

# ═══ F2：lock→zoom→unlock→relock→reset 必须精确归还相机 ═══
print()
print("=" * 68)
print("F2  解锁→再锁定后 重置 仍能精确归还相机")
sc = fresh()
cam = make_cam(sc); sc.camera = cam
objs = make_planes(sc, cam, 2, "F2")
plock.lock_group(sc, cam)
z0 = cam.location.z
cam.data.lens = 100.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc); bpy.context.view_layer.update()
z_zoom = cam.location.z
plock.unlock_group(sc, cam)
plock.lock_group(sc, cam)                     # ★ 关键：中间再锁定一次
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
print("   z: %.4f → 变焦后 %.4f → relock+reset 后 %.4f" % (z0, z_zoom, cam.location.z))
chk("F2  解锁→再锁定后重置仍归还原位", abs(cam.location.z - z0) < 1e-5,
    "Δ=%.4f（修复前 =6.0）" % (cam.location.z - z0))

# ═══ F3：没有投影组时不得谎报 frozen ═══
print()
print("=" * 68)
print("F3  没有投影组时：frozen=False + 消息点名原因")
sc = fresh()
cam = make_cam(sc); sc.camera = cam
objs = make_planes(sc, cam, 1, "F3", with_group=False)   # ★ 不建投影组
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   frozen:", r.get("frozen"), "| is_patched:", plock.is_patched(cam.data.name))
print("   message:", str(r.get("message"))[:90])
chk("F3-a 不谎报 frozen", r.get("frozen") is False, "frozen=%s" % r.get("frozen"))
chk("F3-b 消息里点名原因", "冻结未启用" in str(r.get("message")), "")

# ═══ F4：相机数据块改名后仍能找回记录 + 重置可用 ═══
print()
print("=" * 68)
print("F4  相机数据块改名后：记录可找回、几何可还原")
sc = fresh()
cam = make_cam(sc, "CamOld"); sc.camera = cam
objs = make_planes(sc, cam, 2, "F4")
plock.lock_group(sc, cam)
w0 = [tuple(objs[0].matrix_world @ v.co) for v in objs[0].data.vertices]
cam.data.name = "CamNew"                       # ★ 只改数据块名
bpy.context.view_layer.update()
print("   has_lock_record:", plock.has_lock_record(sc, cam),
      "| is_locked:", plock.is_locked(sc, cam))
chk("F4-a 改名后仍能找回锁定记录（UI 可重置）", plock.has_lock_record(sc, cam),
    "has_lock_record=%s" % plock.has_lock_record(sc, cam))
cam.location.x += 1.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc); bpy.context.view_layer.update()
d = max(max(abs(a[i] - b[i]) for i in range(3))
        for a, b in zip(w0, [tuple(objs[0].matrix_world @ v.co) for v in objs[0].data.vertices]))
chk("F4-b 改名后 handler 仍能适配该相机（锁定未静默失效）", d > 1e-6, "顶点变化 %.6f" % d)
r = plock.reset_group(sc, cam)
bpy.context.view_layer.update()
w1 = [tuple(objs[0].matrix_world @ v.co) for v in objs[0].data.vertices]
e = max(max(abs(a[i] - b[i]) for i in range(3)) for a, b in zip(w0, w1))
chk("F4-c 改名后 reset 仍能还原几何", r.get("success") and e < 1e-4,
    "success=%s 偏差 %.2e" % (r.get("success"), e))

# ═══ F5：一个都没适配成功时，不得把相机记成"已处理" ═══
print()
print("=" * 68)
print("F5  未适配成功则不写相机缓存（否则几何永久停在上一次）")
sc = fresh()
cam = make_cam(sc); sc.camera = cam
objs = make_planes(sc, cam, 2, "F5")
plock.lock_group(sc, cam)
plock._last_view.clear()
# 造一个"必然适配失败"的状态：临时摘掉 base 属性（adapt_object 会返回 False）
saved = {}
for o in objs:
    a = o.data.attributes.get(plock.BASE_ATTR)
    if a is not None:
        n = len(a.data); buf = [0.0] * (n * 3)
        a.data.foreach_get("vector", buf)
        saved[o.name] = buf
        o.data.attributes.remove(a)
cam.location.x += 1.0
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc); bpy.context.view_layer.update()
cached_after_fail = len(plock._last_view)
print("   适配必然失败时 _last_view 条目数 =", cached_after_fail, "（应为 0）")
chk("F5-a 没适配成功就不写缓存", cached_after_fail == 0, "条目数 %d" % cached_after_fail)
# 恢复 base 后，相机没再动 → 应当能补上（而不是"以为已完成"）
for o in objs:
    if o.name in saved:
        a = o.data.attributes.new(name=plock.BASE_ATTR, type="FLOAT_VECTOR", domain="POINT")
        a.data.foreach_set("vector", saved[o.name])
b4 = [tuple(objs[0].matrix_world @ v.co) for v in objs[0].data.vertices]
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
d = max(max(abs(x[i] - y[i]) for i in range(3)) for x, y in
        zip(b4, [tuple(objs[0].matrix_world @ v.co) for v in objs[0].data.vertices]))
chk("F5-b 相机静止时能自动补上（不再永久停住）", d > 1e-6, "顶点变化 %.6f" % d)

# ═══ F7：补丁丢失后 handler 自愈，且不自愈时图案不跳变 ═══
print()
print("=" * 68)
print("F7  补丁丢失 → handler 自愈重打；且冻结 UV 不跳变")
sc = fresh()
cam = make_cam(sc); sc.camera = cam
objs = make_planes(sc, cam, 2, "F7")
plock.lock_group(sc, cam)


def frozen_uv(ob):
    a = ob.data.attributes.get(plock._campos_attr_name(cam.data.name))
    if a is None:
        return None
    n = len(a.data); b = [0.0] * (n * 3)
    a.data.foreach_get("vector", b)
    return b[:6]


# ★★ 先【变焦】再自愈 —— 这样 F7-d 才有判别力（独立审查 第十轮 🔴-1）：
#   若相机仍停在 50mm，那么"重取当前值"和"沿用锁定值"是同一个数，
#   断言恒真 ⇒ **空对空**，抓不到 bug。必须让当前焦距 ≠ 锁定焦距（50 → 85）。
cam.data.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("   变焦到 85mm（相机已 dolly 补偿）")
uv_before = frozen_uv(objs[0])
ng.ensure_camera_project_group(cam, default_aspect=1.0)    # 模拟「重新生成投影组」
bpy.context.view_layer.update()
print("   重新生成后 is_patched:", plock.is_patched(cam.data.name))
chk("F7-a 重新生成后 is_patched 立即为 False（不假阳性）",
    not plock.is_patched(cam.data.name))
cam.location.x += 0.5
bpy.context.view_layer.update(); plock.parallax_lock_update_handler(sc); bpy.context.view_layer.update()
healed = plock.is_patched(cam.data.name)
uv_after = frozen_uv(objs[0])
print("   移动相机后 is_patched:", healed, "（应自愈为 True）")
chk("F7-b 移动相机即自愈重打补丁（不再需要手动 解锁→再锁定）", healed)
jump = max(abs(a - b) for a, b in zip(uv_before, uv_after)) if (uv_before and uv_after) else -1
print("   冻结坐标变化 = %.6f" % jump)
chk("F7-c 自愈过程不重算冻结坐标（画面不跳变）", abs(jump) < 1e-6, "变化 %.2e" % jump)
# ★★ 补上「冻结外观」的**另一半**（独立审查 第十轮 🔴-1）：
#   这个承诺是**两半**的 —— ① 冻结坐标（campos）不被重算；② 组内冻结的 lens/sensor
#   也不能被重取成**当前**值。原来的 F7-c 只验了 ①，
#   于是「自愈时把 Lens 重取成当前焦距 ⇒ 图案按变焦比缩放」这条路径
#   **永远抓不到**（实测渲染像素差 27.57、47.2% 像素变化）。
#   这正是本项目反复总结的「同一个语义有两半，只测了一半」。
_g_f7 = bpy.data.node_groups.get("Camera Project | " + cam.data.name)
_ln2 = None
for _n in (_g_f7.nodes if _g_f7 else []):
    if _n.type == "VALUE" and _n.label == "Lens":
        _ln2 = _n
if _ln2 is not None:
    _lv = _ln2.outputs["Value"].default_value
    print("   自愈后 组内 Lens = %.3f（当前相机 lens = %.3f）" % (_lv, cam.data.lens))
    chk("F7-d 自愈后冻结 Lens 仍是锁定时刻的值（不是当前焦距）",
        abs(_lv - 50.0) < 1e-6,
        "Lens=%.3f 应为 50（＝锁定值）；若等于当前值 %.1f ⇒ 图案会按变焦比缩放"
        % (_lv, cam.data.lens))

# ═══ F9：向量化路径 与 纯 Python 回退路径 必须产出相同几何 ═══
print()
print("=" * 68)
print("F9  numpy 路径 vs 纯 Python 回退路径：几何必须一致")
sc = fresh()
cam = make_cam(sc, loc=(0.0, 0.0, 30.0)); sc.camera = cam
bpy.ops.mesh.primitive_grid_add(x_subdivisions=30, y_subdivisions=30, size=30.0,
                                location=(0.0, 0.0, 0.0))
ob = bpy.context.active_object; ob.name = "F9G"
ob.data.materials.append(bpy.data.materials.new("MF9"))
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = ob.data.materials[0]; mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
o = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
NV = len(ob.data.vertices)
plock.lock_group(sc, cam)
cam.location.x = 1.0
bpy.context.view_layer.update()
st = plock.get_state(sc, cam)
view = plock.get_camera_view_matrix(cam)
# ⚠️ 必须【两条路径都测】：单测 numpy 路径会漏掉回退分支里的错
#    （我自己就在这里栽过 —— 回退路径把 view_now 乘了两遍，只有对比才暴露）。
_got = {}
for tag, npmod in (("np", plock._np), ("py", None)):
    sv = plock._np
    plock._np = npmod
    plock.adapt_object(ob, cam, st, view_now=view)
    buf = [0.0] * (NV * 3)
    ob.data.vertices.foreach_get("co", buf)
    _got[tag] = buf
    plock._np = sv
e = max(abs(a - b) for a, b in zip(_got["np"], _got["py"])) if plock._np is not None else 0.0
print("   顶点数 %d，两条路径最大差 = %.3e" % (NV, e))
chk("F9-a 向量化与纯 Python 路径几何一致（numpy 可用时）",
    plock._np is None or e < 1e-5, "Δ=%.2e" % e)
# 几何必须真的被改了（否则上面的"一致"是空对空）
chk("F9-b 适配确实改了顶点（非空对空）",
    any(abs(_got["np"][i] - 0.0) > 1e-9 for i in range(min(30, NV * 3))),
    "前 3 个顶点 = %s" % [round(x, 3) for x in _got["np"][:3]])

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX3_DONE")
