"""审查 C · 相机装配与渲染边界（第 6/7/8/10 项）

覆盖：
  6 引擎     CYCLES / EEVEE / Workbench
  7 装配     相机被 parent 到空物体 / Copy Location 约束 / 驱动
  8 动画     关键帧相机，在不同帧之间解锁
 10 分辨率   非正方形（192x108，按正确 aspect 输入对比默认 1.0）
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy
from mathutils import Vector


def glue_and_jump(tag, sc, cam, cd, ob, mover):
    """锁定 → mover() → 粘住? → 解锁 → 跳?"""
    plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL = render_uv("l")
    iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
    mover()
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL2 = render_uv("l2")
    iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
    sm = np.intersect1d(iL, iL2)
    glue = (float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max())
            if len(sm) else float("nan"))
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    pU = render_uv("u")
    jump, jmx, jn = diff(pL2, pU)
    print("  %-32s glue=%8.4f JUMP=%8.4f (公共像素 %d) S/C=%s"
          % (tag, glue, jump, jn, nodes_sc(cd)))
    return glue, jump


print("=" * 90)
print("第 7 项 · 相机被 parent / 约束 / 驱动")
print("=" * 90)

print("\n### 7a 相机 parent 到空物体，移动空物体 ###")
sc, cam, cd, mat, ob = build()
emp = bpy.data.objects.new("Rig", None)
sc.collection.objects.link(emp)
bpy.context.view_layer.update()
cam.parent = emp
cam.matrix_parent_inverse = emp.matrix_world.inverted()
bpy.context.view_layer.update()
glue, jump = glue_and_jump("7a parent+移空物体", sc, cam, cd, ob,
                           lambda: setattr(emp.location, "x", 2.0))
chk("7a parent：粘住且不跳", glue < 5e-3 and jump < 2e-3, "glue=%.4f jump=%.4f" % (glue, jump))

print("\n### 7b Copy Location 约束（空物体驱动相机位置）###")
sc, cam, cd, mat, ob = build()
emp = bpy.data.objects.new("Rig", None)
sc.collection.objects.link(emp)
emp.location = (0, 0, 5)
c = cam.constraints.new("COPY_LOCATION")
c.target = emp
cam.location = (0, 0, 0)
bpy.context.view_layer.update()
glue, jump = glue_and_jump("7b 约束+移空物体", sc, cam, cd, ob,
                           lambda: setattr(emp.location, "x", 2.0))
chk("7b 约束（平移）：粘住且不跳", glue < 5e-3 and jump < 2e-3,
    "glue=%.4f jump=%.4f" % (glue, jump))

# 约束下变更焦：插件靠「写 camera.location」施加 dolly，约束会覆盖它
plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pA = render_uv("cl")
cd.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pB = render_uv("cl2")
g2 = diff(pA, pB)[0]
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
pC = render_uv("cl3")
j2 = diff(pB, pC)[0]
print("  7b 约束下变焦：锁定期间画面变化=%.4f 解锁跳变=%.4f" % (g2, j2))
chk("7b 约束下变焦：解锁不跳", j2 < 2e-3, "jump=%.4f" % j2)

print("\n### 7c 相机位置由 driver（空物体 x）驱动 ###")
sc, cam, cd, mat, ob = build()
emp = bpy.data.objects.new("Rig", None)
sc.collection.objects.link(emp)
fc = cam.driver_add("location", 0)
fc.driver.type = "SCRIPTED"
v = fc.driver.variables.new(); v.type = "SINGLE_PROP"
v.targets[0].id = emp; v.targets[0].data_path = "location[0]"
fc.driver.expression = "var"
bpy.context.view_layer.update()
glue, jump = glue_and_jump("7c driver+移空物体", sc, cam, cd, ob,
                           lambda: setattr(emp.location, "x", 2.0))
chk("7c driver：粘住且不跳", glue < 5e-3 and jump < 2e-3, "glue=%.4f jump=%.4f" % (glue, jump))

print("\n" + "=" * 90)
print("第 8 项 · 相机有动画关键帧")
print("=" * 90)
sc, cam, cd, mat, ob = build()
sc.frame_start, sc.frame_end = 1, 20
cam.location = (0, 0, 5); cam.keyframe_insert("location", frame=1)
cam.location = (2.0, 0, 5); cam.keyframe_insert("location", frame=11)
sc.frame_set(1)
plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pL = render_uv("f1")
iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
sc.frame_set(6)            # 动画把相机移到 x=1.0
bpy.context.view_layer.update()
print("  frame 6：相机 x=%.3f（动画值）" % cam.location.x)
pF = render_uv("f6")
iF, uvF, _ = uv_at_verts(sc, cam, ob, pF)
sm = np.intersect1d(iL, iF)
glue = (float(np.abs(uvL[np.isin(iL, sm)] - uvF[np.isin(iF, sm)]).max())
        if len(sm) else float("nan"))
print("  8 关键帧：锁定后跑到 frame 6，图案 UV 变化=%.4f (n=%d)" % (glue, len(sm)))
chk("8 动画帧间：图案粘住网格", glue < 5e-3, "glue=%.4f" % glue)
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
pU = render_uv("f6u")
jump = diff(pF, pU)[0]
print("  8 关键帧：frame 6 解锁，跳变=%.4f" % jump)
chk("8 动画：解锁不跳", jump < 2e-3, "jump=%.4f" % jump)

print("\n" + "=" * 90)
print("第 6 项 · 引擎")
print("=" * 90)
for eng in ("BLENDER_EEVEE", "CYCLES"):
    sc, cam, cd, mat, ob = build(engine=eng)
    p0 = render_uv("e")
    amx, amn, an = align_err(sc, cam, ob, p0)
    glue, jump = glue_and_jump("6 %s" % eng, sc, cam, cd, ob,
                               lambda: setattr(cam.location, "x", 2.0))
    chk("6 %s：对齐+不跳" % eng, amx < 5e-3 and jump < 2e-3,
        "align=%.4f glue=%.4f jump=%.4f" % (amx, glue, jump))

sc, cam, cd, mat, ob = build(engine="BLENDER_WORKBENCH")
p = render_uv("wb")
uv, mask = p
print("  Workbench：可见像素=%d" % mask.sum())
chk("6 Workbench：节点材质图案根本不参与渲染（Blender 限制，非插件 bug）",
    mask.sum() == 0, "可见像素=%d" % mask.sum())

print("\n" + "=" * 90)
print("第 10 项 · 非正方形分辨率 192x108")
print("=" * 90)
for asp, note in ((192.0 / 108.0, "aspect=1.778 正确"), (1.0, "aspect=1 默认")):
    sc, cam, cd, mat, ob = build(res=(192, 108), aspect_input=asp)
    p0 = render_uv("r")
    amx, amn, an = align_err(sc, cam, ob, p0)
    dump("192x108 %s" % note, p0)
    print("  10 %-18s 对齐误差 max=%.4f (n=%d)" % (note, amx, an))
    glue, jump = glue_and_jump("10 192x108 %s" % note, sc, cam, cd, ob,
                               lambda: setattr(cam.location, "x", 2.0))
    chk("10 %s：不跳" % note, jump < 2e-3, "align=%.4f jump=%.4f" % (amx, jump))

report("审查 C 相机装配/引擎/动画/分辨率")
