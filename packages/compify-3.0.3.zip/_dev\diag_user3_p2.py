"""精确定位问题2：进出编辑模式后 campos 为什么变成世界坐标"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_diag2"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
cam_data = bpy.data.cameras.new("C")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, 0.0, 5.0)
cam.rotation_euler = (0, 0, 0)
bpy.context.view_layer.update()

def make_grid(name, z, x, w=1.0, nseg=2):
    mesh = bpy.data.meshes.new(name)
    verts, faces = [], []
    for iy in range(nseg+1):
        for ix in range(nseg+1):
            verts.append((x-w+2*w*ix/nseg, -1+2*iy/nseg, z))
    for iy in range(nseg):
        for ix in range(nseg):
            a = iy*(nseg+1)+ix
            faces.append((a, a+1, a+nseg+2, a+nseg+1))
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(obj)
    return obj

NG.ensure_camera_project_group(cam)
m = bpy.data.materials.new("M"); m.use_nodes = True
nt = m.node_tree
for n in list(nt.nodes): nt.nodes.remove(n)
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cam_data.name)
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs[0], out.inputs[0])

obj = make_grid("G", 0.0, 0.0)
obj.data.materials.append(m)
NG.create_uv_adjust_node_group(scene, cam, obj)
print(PL.lock_group(scene, cam).get("message"))

cn = PL._campos_attr_name(cam_data.name)

# ── 给写入函数打点 ──
_orig_write = PL._write_campos_attribute
_calls = []
def _patched(obj_, camera_, cdn_, mw_inv=None):
    _calls.append((obj_.name, "mw_inv=%s" % ("None" if mw_inv is None else "given")))
    return _orig_write(obj_, camera_, cdn_, mw_inv)
PL._write_campos_attribute = _patched

_orig_newattr = PL._new_vec_attr
_newcalls = []
def _patched_new(mesh_, name_):
    _newcalls.append(name_)
    return _orig_newattr(mesh_, name_)
PL._new_vec_attr = _patched_new

def dump(tag):
    a = obj.data.attributes.get(cn)
    if a is None:
        print("  %-22s campos 不存在!" % tag); return None
    n = len(a.data)
    vals = [tuple(a.data[i].vector) for i in range(n)]
    first = tuple(round(x, 4) for x in vals[0]) if vals else "(空)"
    print("  %-22s n=%-3d 首顶点=%s  (mesh.vertices=%d)" % (tag, n, first, len(obj.data.vertices)))
    return vals if vals else None

print("\n相机空间坐标应为 z ≈ -5.0（相机在 z=5 看 -Z）")
v0 = dump("锁定后")
print("\n--- 只进出编辑模式，不动任何顶点 ---")
calls_before = len(_calls); new_before = len(_newcalls)
bpy.context.view_layer.objects.active = obj
obj.select_set(True)
bpy.ops.object.mode_set(mode='EDIT')
print("  进入编辑模式, mode =", obj.mode)
v1 = dump("编辑模式中")
for _ in range(3):
    bpy.context.view_layer.update()
    PL.parallax_lock_update_handler(scene)
print("  handler 跑 3 次后:")
v2 = dump("编辑模式中(handler后)")
bpy.ops.object.mode_set(mode='OBJECT')
print("  退出编辑模式, mode =", obj.mode)
v3 = dump("退出编辑模式后")
for _ in range(2):
    bpy.context.view_layer.update()
    PL.parallax_lock_update_handler(scene)
v4 = dump("再跑 handler 后")

print("\n写入调用统计：_write_campos_attribute 被调用 %d 次，_new_vec_attr 被调用: %s"
      % (len(_calls) - calls_before, _newcalls[new_before:]))

def diff(a, b):
    if not a or not b: return None
    return max(abs(p[i]-q[i]) for p, q in zip(a, b) for i in range(3))
for name, v in [("编辑模式中", v1), ("handler后", v2), ("退出后", v3), ("再handler后", v4)]:
    d = diff(v0, v)
    print("  %-12s vs 锁定后: 最大变化 %.6f" % (name, d if d is not None else -1))

# campos 现在到底是什么坐标？
a = obj.data.attributes.get(cn)
if a:
    print("\n当前 campos 首顶点 =", tuple(round(x,4) for x in a.data[0].vector))
    print("物体顶点首顶点世界坐标 =", tuple(round(x,4) for x in (obj.matrix_world @ obj.data.vertices[0].co)))
    mwi = cam.matrix_world.inverted()
    print("相机空间坐标 =", tuple(round(x,4) for x in (mwi @ (obj.matrix_world @ obj.data.vertices[0].co))))
