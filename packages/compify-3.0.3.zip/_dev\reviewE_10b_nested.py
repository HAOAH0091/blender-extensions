"""审查E-10b：handler 内部是否做嵌套 depsgraph 求值（view_layer.update）

.apply_user_move 末行 `bpy.context.view_layer.update()`（行 2026）在 handler 里被调用：
横向拖动命中 `k==1` 分支 → 行 1965；拖到相机后方 → 行 1974。
这里把 view_layer.update 打桩计数+计时，看一次拖动帧里套了几次、各花多久。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

N = 3000
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 14)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
ns, H = 2, 0.4
verts, faces = [], []
for iy in range(ns + 1):
    for ix in range(ns + 1):
        verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy * (ns + 1) + ix
        faces.append((a, a + 1, a + ns + 2, a + ns + 1))
for i in range(N):
    me = bpy.data.meshes.new("G%d" % i)
    me.from_pydata(verts, [], faces)
    me.update()
    o = bpy.data.objects.new("Grid%d" % i, me)
    sc.collection.objects.link(o)
    o.location = ((i % 60) * 0.9 - 27, (i // 60) * 0.9, 0.0)
    o.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
bpy.context.view_layer.update()

# 打桩：统计 handler 内部对 view_layer.update 的调用与耗时
VL = bpy.context.view_layer
_orig = VL.update
STAT = {"n": 0, "ms": 0.0}


def patched(*a, **k):
    t0 = time.perf_counter()
    r = _orig(*a, **k)
    STAT["n"] += 1
    STAT["ms"] += (time.perf_counter() - t0) * 1000.0
    return r


VL.update = patched

target = bpy.data.objects["Grid0"]
print("场景 %d 个网格" % N)
for tag, dx, dz in (("横向拖（k==1 分支）", 0.02, 0.0), ("推近拖（k≠1）", 0.0, 0.05)):
    STAT["n"] = 0
    STAT["ms"] = 0.0
    ts = []
    for _ in range(4):
        target.location.x += dx
        target.location.z += dz
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)      # 手工调 handler（= depsgraph 派发那一刻）
        ts.append((time.perf_counter() - t0) * 1000.0)
    print("  %-22s handler 帧均=%7.1f ms；内部 view_layer.update 调用 %d 次、共 %.1f ms" % (
        tag, sum(ts) / len(ts), STAT["n"], STAT["ms"]))

VL.update = _orig
