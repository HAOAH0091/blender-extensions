"""边界：锁定后相机【推进穿过网格】（部分顶点跑到相机背后）

与"锁定那一刻就有顶点在后方"不同 —— 那种会被整体拒绝（已有守卫）。
这里测的是：锁定那一刻全在前方 → 正常冻结；之后相机穿过网格 → 会怎样？

关注：
  1 有没有 nan/inf 写进冻结坐标
  2 解锁时 fit_delta_params（lstsq）会不会被污染
  3 画面是否损坏
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 64


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    # 平面网格位于 z=0，相机在 z=5 朝 -z 看 ⇒ 初始帧所有顶点都在前方
    ns = 3
    h = 2.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def uvimg():
    _seq[0] += 1
    p = os.path.join(HERE, "_thru_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def attr_stats(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None:
        return "属性不存在"
    n = len(a.data)
    buf = np.empty(n * 3, dtype=np.float64)
    a.data.foreach_get("vector", buf)
    v = buf.reshape(-1, 3)
    return ("n=%d  nan=%s  inf=%s  z∈[%.3f, %.3f]"
            % (n, np.isnan(v).any(), np.isinf(v).any(), v[:, 2].min(), v[:, 2].max()))


def finite_uv(img):
    return int(np.isfinite(img).all())


print("=" * 84)
print("边界：锁定后相机推进【穿过】网格（部分顶点跑到背后）")
print("=" * 84)

sc, cam, cd, ob = build()
r = plock.lock_group(sc, cam)
print("\n1) 初始锁定（相机 z=5，网格 z=0，全在前方）")
print("   消息:", str(r.get("message", ""))[:90])
print("   冻结坐标:", attr_stats(ob, cd))
u_locked = uvimg()
print("   渲染 UV 全有限:", finite_uv(u_locked))

# 相机推进到 z=1（仍在网格前）
cam.location.z = 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_near = uvimg()
print("\n2) 相机推进到 z=1（仍在前方，距网格 1 单位）")
print("   冻结坐标:", attr_stats(ob, cd))
print("   渲染 UV 全有限:", finite_uv(u_near))

# 相机推进到 z=-1（穿过网格，所有顶点在背后）
cam.location.z = -1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_through = uvimg()
print("\n3) 相机推进到 z=-1（已穿过网格，全部顶点在背后）")
print("   冻结坐标:", attr_stats(ob, cd))
print("   渲染 UV 全有限:", finite_uv(u_through))
print("   UV 均值:", np.nanmean(u_through, axis=(0, 1)))

# 部分穿过：相机在 z=0 平面上，一半顶点在前后
cam.location.z = 0.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_plane = uvimg()
print("\n4) 相机正好在网格平面上（z=0）")
print("   冻结坐标:", attr_stats(ob, cd))
print("   渲染 UV 全有限:", finite_uv(u_plane))

# 解锁（此时相机在 z=0 平面）
print("\n5) 在相机穿过网格的状态下解锁")
r2 = plock.unlock_group(sc, cam)
print("   消息:", str(r2.get("message", ""))[:100])
nodes = plock._find_delta_nodes(cd.name)
if nodes:
    S = nodes[0].inputs["Scale"].default_value
    C = list(nodes[1].inputs[1].default_value)[:2]
    print("   S=%.6f  C=(%.6f, %.6f)  有限=%s" % (
        S, C[0], C[1],
        math.isfinite(S) and all(math.isfinite(c) for c in C)))
u_unlock = uvimg()
print("   渲染 UV 全有限:", finite_uv(u_unlock))

# 再退回来，看解锁后是否正常
cam.location.z = 5.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_back = uvimg()
print("\n6) 相机退回 z=5（解锁后）")
print("   渲染 UV 全有限:", finite_uv(u_back))
print("   UV 均值:", np.nanmean(u_back, axis=(0, 1)))
print("THRU_DONE")
