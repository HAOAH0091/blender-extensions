import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = sc.render.resolution_y = 96
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd); sc.collection.objects.link(cam)
cam.location = (0, 0, 5); sc.camera = cam
bpy.context.view_layer.update()
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("P"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
o = nt.nodes.new("ShaderNodeOutputMaterial"); e = nt.nodes.new("ShaderNodeEmission")
nt.links.new(g.outputs["Vector"], e.inputs["Color"]); nt.links.new(e.outputs["Emission"], o.inputs["Surface"])
mesh = bpy.data.meshes.new("G0"); mesh.from_pydata([(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)], [], [(0, 1, 2, 3)]); mesh.update()
ob = bpy.data.objects.new("Grid0", mesh); sc.collection.objects.link(ob); ob.data.materials.append(mat)
bpy.context.view_layer.update()

r = plock.lock_group(sc, cam)
print("lock:", r.get("message"))
print("OBJ_CAM_KEY:", ob.get(plock.OBJ_CAM_KEY))
print("attrs:", [(a.name, a.data_type, a.domain, len(a.data)) for a in mesh.attributes])
print("state:", {k: v for k, v in plock.get_state(sc, cam).items() if k != "locked_matrix"})
pts0 = [tuple(ob.matrix_world @ v.co) for v in mesh.vertices]
cam.location.x = 2.0
bpy.context.view_layer.update()
st = plock.get_state(sc, cam)
ok = plock.adapt_object(ob, cam, st)
pts1 = [tuple(ob.matrix_world @ v.co) for v in mesh.vertices]
print("adapt_object ->", ok, " max|Δworld| =", max(max(abs(a - b) for a, b in zip(p, q)) for p, q in zip(pts0, pts1)))
print("campos attr:", [(a.name, len(a.data)) for a in mesh.attributes])
print("RF_DEBUG_DONE")
