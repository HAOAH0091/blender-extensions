"""审查 B-3b/9d：锁定期间几何被重建（应用修改器 / 编辑模式加顶点）——
变形基准 base 属性会不会跟着刷新？campos 有 vcount 自愈，base 有没有？

跑法：blender --background --factory-startup --python _dev\\reviewB_base_stale.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 94)
print("B-3b 锁定期间几何被重建：base（变形基准）是否过期")
print("=" * 94)


def report(tag, ob, cd):
    n = len(ob.data.vertices)
    a_b = ob.data.attributes.get(plock.BASE_ATTR)
    a_c = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    a_o = ob.data.attributes.get(plock.ORIG_ATTR)
    print("   %-24s 顶点数=%3d | base len=%s | campos len=%s | orig len=%s"
          % (tag, n, len(a_b.data) if a_b else None,
             len(a_c.data) if a_c else None, len(a_o.data) if a_o else None))


# ══════════════════════════════════════════════════════════
print("\n### A. 锁定 → 加 SUBSURF → 应用修改器 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)          # 16 顶点
CTRL = C.add_grid("GridCtrl", cam, mat, ns=3, shape="倾斜", x0=2.6)   # 对照：不动它
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s" % (r["success"], r.get("frozen")))
report("锁定后", A, cd)
mod = A.modifiers.new("Subdiv", "SUBSURF")
mod.levels = 1
bpy.context.view_layer.objects.active = A
A.select_set(True)
bpy.context.view_layer.update()
try:
    bpy.ops.object.modifier_apply(modifier=mod.name)
    print("   已应用 SUBSURF")
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 应用修改器失败:", type(e).__name__, e)
C.chk("A0 应用修改器不抛异常", exc is None)
report("应用修改器后", A, cd)
C.run_handler(sc)
report("handler 跑一帧后", A, cd)
n = len(A.data.vertices)
a_b = A.data.attributes.get(plock.BASE_ATTR)
a_c = A.data.attributes.get(plock._campos_attr_name(cd.name))
C.chk("A1 campos 跟着顶点数自愈（已知已修，确认）",
      a_c is not None and len(a_c.data) == n, "campos len=%s / 顶点 %d"
      % (len(a_c.data) if a_c else None, n))
C.chk("A2 base 也跟着顶点数自愈", a_b is not None and len(a_b.data) == n,
      "base len=%s / 顶点 %d" % (len(a_b.data) if a_b else None, n))

w0 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
cw0 = np.array([tuple(CTRL.matrix_world @ v.co) for v in CTRL.data.vertices])
cam.location.x = 2.0
C.run_handler(sc)
w1 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
cw1 = np.array([tuple(CTRL.matrix_world @ v.co) for v in CTRL.data.vertices])
dA = float(np.abs(w1 - w0).max())
dC = float(np.abs(cw1 - cw0).max())
print("   移相机后：被应用修改器的网格 几何Δ=%.6f ；对照网格 几何Δ=%.6f" % (dA, dC))
C.chk("A3 应用修改器后该网格仍被适配（几何随相机变形）", dA > 1e-6,
      "Δ=%.2e（对照 %.2e）" % (dA, dC))
# 图案是否仍然冻结（campos 有效）
fv0 = C.campos_uv(A, cd.name)
cam.location.x = 3.0
C.run_handler(sc)
fv1 = C.campos_uv(A, cd.name)
print("   图案冻结情况：逐顶点 UV Δ=%.3e（0 = 仍冻结）"
      % (float(np.abs(fv1 - fv0).max()) if (fv0 is not None and fv1 is not None) else -1))

# ══════════════════════════════════════════════════════════
print("\n### B. 锁定 → 进编辑模式加一圈顶点 → 回物体模式 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridB", cam, mat, ns=3)
CTRL = C.add_grid("GridCtrlB", cam, mat, ns=3, x0=2.6)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
report("锁定后", A, cd)
bpy.context.view_layer.objects.active = A
bpy.ops.object.mode_set(mode="EDIT")
import bmesh
bm = bmesh.from_edit_mesh(A.data)
bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
bmesh.update_edit_mesh(A.data)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.context.view_layer.update()
report("编辑模式加顶点后", A, cd)
try:
    C.run_handler(sc)
    exc = None
except Exception as e:
    exc = e
    print("   ✗ handler 抛异常:", type(e).__name__, e)
report("handler 跑一帧后", A, cd)
n = len(A.data.vertices)
a_b = A.data.attributes.get(plock.BASE_ATTR)
a_c = A.data.attributes.get(plock._campos_attr_name(cd.name))
C.chk("B1 编辑模式加顶点后 campos 自愈", a_c is not None and len(a_c.data) == n,
      "campos len=%s / 顶点 %d" % (len(a_c.data) if a_c else None, n))
C.chk("B2 编辑模式加顶点后 base 自愈", a_b is not None and len(a_b.data) == n,
      "base len=%s / 顶点 %d" % (len(a_b.data) if a_b else None, n))
w0 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
cw0 = np.array([tuple(CTRL.matrix_world @ v.co) for v in CTRL.data.vertices])
cam.location.x = 2.0
C.run_handler(sc)
w1 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
cw1 = np.array([tuple(CTRL.matrix_world @ v.co) for v in CTRL.data.vertices])
dA = float(np.abs(w1 - w0).max())
dC = float(np.abs(cw1 - cw0).max())
print("   移相机后：改过拓扑的网格 几何Δ=%.6f ；对照 几何Δ=%.6f" % (dA, dC))
C.chk("B3 编辑模式加顶点后该网格仍被适配", dA > 1e-6, "Δ=%.2e（对照 %.2e）" % (dA, dC))

# ══════════════════════════════════════════════════════════
print("\n### C. 若 base 过期，插件有没有任何提示？###")
print("   最近一次 lock 之后 panel lock_status:", plock.lock_status(sc, cam))
print("   （若这里看不出异常，说明过期是静默的）")

C.summary()
