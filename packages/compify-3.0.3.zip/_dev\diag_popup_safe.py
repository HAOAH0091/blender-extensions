"""安全探测：环境判定 + 只在确认安全时才碰弹窗"""
import bpy, sys

sys.stdout.reconfigure(encoding="utf-8")

print("=== 环境判定（这是守卫的依据） ===")
print("  bpy.app.background      :", bpy.app.background)
print("  bpy.context.window      :", bpy.context.window)
print("  window_manager          :", bpy.context.window_manager is not None)
try:
    print("  wm.windows 数量         :", len(bpy.context.window_manager.windows))
except Exception as e:
    print("  wm.windows 读取异常     :", e)
try:
    print("  wm.windows[0].screen    :", bpy.context.window_manager.windows[0].screen.name)
except Exception as e:
    print("  无可用 screen           :", type(e).__name__)

print("\n=== 推荐的守卫条件 ===")
safe = (not bpy.app.background) and bpy.context.window is not None
print("  not bpy.app.background and bpy.context.window is not None  =>", safe)

print("\n=== timer 本身是否可用（不弹窗） ===")
_state = {"ran": False}


def _tick():
    _state["ran"] = True
    return None


if hasattr(bpy.app, "timers"):
    bpy.app.timers.register(_tick, first_interval=0.02)
    print("  timer 注册成功，is_registered =",
          bpy.app.timers.is_registered(_tick))
else:
    print("  app.timers 不可用")

print("\nPOPUP_SAFE_PROBE_DONE")
