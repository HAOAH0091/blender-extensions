"""回归网（第七轮独立审查）：盯 🔴 F-1 / F-2 + 🟡 F-3 / F-4 / F-5 + N-1 / N-4。

每条断言都对应一个曾经**真实存在**的缺陷 —— 修复前可复现 FAIL。
"""
import bpy
import sys
import os
import time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-58s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene


def mkcam(sc, name="Cam", loc=(0.0, 0.0, 6.0)):
    cd = bpy.data.cameras.new(name); cd.lens = 50.0; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def mkobjs(sc, cam, n, prefix="P"):
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i in range(n):
        bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, -float(i) * 2))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out


def run(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def loc(ob):
    return [tuple(v.co) for v in ob.data.vertices]


def md(a, b):
    return max(max(abs(x[i] - y[i]) for i in range(3)) for x, y in zip(a, b))


# ═══ 🔴 F-1：相机数据块改名 → 解锁 → 再锁定 ═══
print("=" * 72)
print("🔴 F-1  相机数据块改名后，解锁→再锁定 仍要能锁上")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 2, "A")
chk("前置：首次能锁上", plock.lock_group(sc, cam)["success"])
plock.unlock_group(sc, cam)
cam.data.name = "CamRenamed"                    # ★ Blender 常规操作
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   改名后再锁定:", r["success"], "|", str(r["message"])[:60])
chk("F-1a 改名后仍能锁定（不再永久失去能力）", bool(r["success"]), "success=%s" % r["success"])

# 另一入口：先改名【再】解锁→再锁定（UV Adjust 组名迁移必须生效）
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 2, "A2")
plock.lock_group(sc, cam)
cam.data.name = "Renamed2"
bpy.context.view_layer.update()
chk("F-1b 改名后（未解锁）handler 仍能适配",
    (lambda: (cam.location.x + 1.0 and run(sc), True)[1])() is True)
bpy.context.view_layer.update()
plock.unlock_group(sc, cam)
r = plock.lock_group(sc, cam)
chk("F-1c 改名 → 解锁 → 再锁定 仍能锁上", bool(r["success"]), str(r["message"])[:40])
chk("F-1d UV Adjust 组名已被迁移到新数据名",
    any(g.name.endswith(" | Renamed2") and g.name.startswith("UV Adjust")
        for g in bpy.data.node_groups),
    str([g.name for g in bpy.data.node_groups if g.name.startswith("UV Adjust")][:2]))

# ═══ 🔴 F-2：孤儿判定不得误伤其它场景 / unlink 的相机 ═══
print()
print("=" * 72)
print("🔴 F-2  孤儿判定必须按全局可达（不得误伤其它场景的健康锁定）")
sc1 = fresh()
cam = mkcam(sc1); sc1.camera = cam
objs = mkobjs(sc1, cam, 2, "B")
plock.lock_group(sc1, cam)
chk("前置：锁定生效（有 ORIG/BASE）",
    objs[0].data.attributes.get(plock.ORIG_ATTR) is not None)
sc2 = bpy.data.scenes.new("Scene2")
bpy.context.window.scene = sc2
sc2.collection.objects.link(objs[0])
bpy.context.view_layer.update()
orph = plock.find_orphan_locks(sc2)
chk("F-2a 跨场景 link 不被误判成孤儿", len(orph) == 0, "误判 %d 个" % len(orph))
# 真的点一次还原（若误判会破坏 Sc1）
plock.reset_orphan_locks(sc2)
bpy.context.view_layer.update()
bpy.context.window.scene = sc1
bpy.context.view_layer.update()
chk("F-2b Sc1 的锁定痕迹仍在（未被误伤）",
    objs[0].get(plock.OBJ_CAM_KEY) == cam.data.name
    and objs[0].data.attributes.get(plock.ORIG_ATTR) is not None,
    "OBJ_CAM=%s orig=%s" % (objs[0].get(plock.OBJ_CAM_KEY),
                            objs[0].data.attributes.get(plock.ORIG_ATTR) is not None))
# unlink 相机
sc1 = fresh()
cam = mkcam(sc1); sc1.camera = cam
objs = mkobjs(sc1, cam, 2, "C")
plock.lock_group(sc1, cam)
sc1.collection.objects.unlink(cam)
bpy.context.view_layer.update()
chk("F-2c 相机 unlink（仍在 bpy.data）不判孤儿",
    len(plock.find_orphan_locks(sc1)) == 0, "误判 %d" % len(plock.find_orphan_locks(sc1)))
# 真孤儿（换数据块）仍要能判出来
sc1 = fresh()
cam = mkcam(sc1); sc1.camera = cam
objs = mkobjs(sc1, cam, 2, "D")
plock.lock_group(sc1, cam)
_old = cam.data
cam.data = bpy.data.cameras.new("Swapped")
bpy.context.view_layer.update()
chk("F-2d 真孤儿（换数据块）仍能判出", len(plock.find_orphan_locks(sc1)) >= 2,
    "%d 个" % len(plock.find_orphan_locks(sc1)))

# ═══ 🟡 F-3：reset 后 UNLOCK_SIG_KEY 两条分支都要清 ═══
print()
print("=" * 72)
print("🟡 F-3  reset 后 UNLOCK_SIG_KEY 必须清干净（两条分支）")
for tag, drop_orig in (("orig 分支", False), ("base 回退分支", True)):
    sc = fresh()
    cam = mkcam(sc); sc.camera = cam
    objs = mkobjs(sc, cam, 2, "E%d" % (0 if not drop_orig else 1))
    plock.lock_group(sc, cam)
    plock.unlock_group(sc, cam)
    if drop_orig:
        for o in objs:
            o.data.attributes.remove(o.data.attributes[plock.ORIG_ATTR])
    bpy.context.view_layer.update()
    plock.reset_group(sc, cam)
    bpy.context.view_layer.update()
    left = [plock.UNLOCK_SIG_KEY in o.keys() for o in objs]
    chk("F-3 %s 清掉签名" % tag, not any(left), str(left))

# ═══ 🟡 F-4：缓存必须有实现、且结构变化要失效 ═══
print()
print("=" * 72)
print("🟡 F-4  objects_using_projection 缓存：有实现 + 结构变化失效")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
objs = mkobjs(sc, cam, 1, "F")
chk("F-4a 存在带缓存的函数", hasattr(plock, "objects_using_projection_cached"))
plock._proj_cache.clear()
n0 = len(plock.objects_using_projection_cached(cam.data.name))
bpy.ops.mesh.primitive_plane_add(size=2.0, location=(1.0, 0.0, -1.0))
NEW = bpy.context.active_object
NEW.data.materials.append(objs[0].data.materials[0])
bpy.context.view_layer.update()
n1 = len(plock.objects_using_projection_cached(cam.data.name))
chk("F-4b 新增对象后缓存失效", n1 == n0 + 1, "%d → %d" % (n0, n1))
# 缓存生效 —— ★ 判据用「语义」而不是「耗时」。
#   原判据是 `cached 耗时 < uncached 耗时`（微秒级比较），机器负载一抖就随机 FAIL，
#   实测在整包回归里偶发误报一次（单跑必过）。量尺不稳比漏判更致命，故改掉：
#   缓存的**契约**是「结构没变就不重复扫描」，所以直接数真值扫描被调了几次。
#   —— 与机器负载完全无关，且判别力更硬（改坏了必然命中数上升）。
_orig_scan = plock.objects_using_projection
_calls = {"n": 0}


def _spy_scan(*a, **k):
    _calls["n"] += 1
    return _orig_scan(*a, **k)


N = 150
plock._proj_cache.clear()
plock.objects_using_projection = _spy_scan
try:
    t0 = time.perf_counter()
    for _ in range(N):
        plock.objects_using_projection_cached(cam.data.name)
    t1 = time.perf_counter()
    for _ in range(N):
        _orig_scan(cam.data.name)
    t2 = time.perf_counter()
finally:
    plock.objects_using_projection = _orig_scan
c, u = (t1 - t0) * 1000 / N, (t2 - t1) * 1000 / N
print("   cached %.4f ms vs uncached %.4f ms（仅供参考，不作判据）" % (c, u))
print("   %d 次 cached 调用里，真值扫描被触发 %d 次" % (N, _calls["n"]))
chk("F-4c 缓存不重复扫描（N 次只扫 1 次）", _calls["n"] == 1,
    "%d 次调用 → %d 次真值扫描" % (N, _calls["n"]))
# 反面验证：清掉缓存后必须重新扫（证明上面的 1 次不是"永远不扫"）
plock._proj_cache.clear()
_calls["n"] = 0
plock.objects_using_projection = _spy_scan
try:
    plock.objects_using_projection_cached(cam.data.name)
finally:
    plock.objects_using_projection = _orig_scan
chk("F-4c2 缓存清空后必须重新扫描", _calls["n"] == 1,
    "清空后 1 次调用 → %d 次真值扫描" % _calls["n"])
# ★ 关键：跨文件（bpy.data 被重置）后缓存必须失效
sig_before = plock._proj_signature()
bpy.ops.wm.read_factory_settings(use_empty=True)
sig_after = plock._proj_signature()
chk("F-4d 换文件后签名必变（防悬空对象列表）", sig_before != sig_after,
    "%s vs %s" % (sig_before, sig_after))

# ═══ 🟡 F-5：公开 API 对 None / 无 data 的健壮性 ═══
print()
print("=" * 72)
print("🟡 F-5  公开 API 对 None / 无 data 输入必须优雅失败")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, 1, "G")
plock.lock_group(sc, cam)
bad_fn = []
for tag, fn in [("reset_group(None)", lambda: plock.reset_group(sc, None)),
                ("lock_group(None)", lambda: plock.lock_group(sc, None)),
                ("unlock_group(None)", lambda: plock.unlock_group(sc, None)),
                ("get_state(None)", lambda: plock.get_state(sc, None)),
                ("is_locked(None)", lambda: plock.is_locked(sc, None)),
                ("has_lock_record(None)", lambda: plock.has_lock_record(sc, None)),
                ("lock_status(None)", lambda: plock.lock_status(sc, None)),
                ("reset_group(无data对象)", lambda: plock.reset_group(sc, bpy.data.objects.new("NoD", None)))]:
    try:
        fn()
    except Exception as e:
        bad_fn.append("%s → %s" % (tag, type(e).__name__))
chk("F-5 全部 API 对坏输入都不抛异常", not bad_fn, str(bad_fn))

# ═══ N-1：redraw_viewport 无 window 时不得抛 ═══
print()
print("=" * 72)
print("N-1  redraw_viewport 在无 window / 无 screen 时不得抛")
import importlib as _il
_props = _il.import_module(PKG + ".properties")
class _Ctx:
    window = None
try:
    _props.redraw_viewport(_Ctx())
    chk("N-1a window=None 不抛异常", True)
except Exception as e:
    chk("N-1a window=None 不抛异常", False, type(e).__name__)
class _Ctx2:
    class window:
        screen = None
try:
    _props.redraw_viewport(_Ctx2())
    chk("N-1b screen=None 不抛异常", True)
except Exception as e:
    chk("N-1b screen=None 不抛异常", False, type(e).__name__)

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX6_DONE")
