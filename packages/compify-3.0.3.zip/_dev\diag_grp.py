"""检查 Camera Project 组内部结构：patch 前/后/重置后
判据：attr 节点是否存在、TexCoord 是否连到目标
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_grp"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    return scene, cam, cd

def make_mat(cd):
    m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    return m

def make_grid(name, x, z=0.0, w=0.8):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata([(x-w,-1,z),(x+w,-1,z),(x+w,1,z),(x-w,1,z)], [], [(0,1,2,3)])
    mesh.update()
    o = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(o)
    return o

def dump_group(cd, tag):
    ng = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    print("\n  [%s] 组=%s" % (tag, ng.name if ng else None))
    if ng is None: return
    raw = ng.get(PL.PATCH_KEY) if hasattr(PL, "PATCH_KEY") else ng.get("compify_plock_patch")
    print("    patch 记录:", (raw[:80] + "...") if raw else "无")
    attrs = [n for n in ng.nodes if n.bl_idname == "ShaderNodeAttribute"]
    texs = [n for n in ng.nodes if n.bl_idname == "ShaderNodeTexCoord"]
    print("    Attribute 节点:", [(n.name, getattr(n, "attribute_name", "?")) for n in attrs])
    print("    TexCoord 节点:", [n.name for n in texs])
    # 看 TexCoord 的输出还连着谁
    for tc in texs:
        for out in tc.outputs:
            dsts = [(lk.to_node.name, lk.to_socket.name) for lk in out.links]
            if dsts:
                print("    TexCoord.%s -> %s" % (out.name, dsts))
    for a in attrs:
        for out in a.outputs:
            dsts = [(lk.to_node.name, lk.to_socket.name) for lk in out.links]
            if dsts:
                print("    Attribute.%s -> %s" % (out.name, dsts))

scene, cam, cd = build()
m = make_mat(cd)
A = make_grid("GridA", 0.0)
A.data.materials.append(m)
NG.create_uv_adjust_node_group(scene, cam, A)

print("="*76)
print("Camera Project 组内部结构变化")
print("="*76)
dump_group(cd, "锁定前")

print("\n  lock:", PL.lock_group(scene, cam).get("message"))
dump_group(cd, "锁定后")

print("\n  unlock:", PL.unlock_group(scene, cam).get("message"))
dump_group(cd, "解锁后")

print("\n  reset:", PL.reset_group(scene, cam).get("message"))
dump_group(cd, "重置后")
print("\n  A 属性:", [a.name for a in A.data.attributes])
