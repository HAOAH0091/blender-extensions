"""回归网（第十轮独立审查）：盯 🔴 F-1 / 🟡 F-2。

⚠️ F-1 用**渲染像素比对**做验证 —— 因为原缺陷就是"图案按变焦比整体缩放"，
   只有像素级才直接反映"图案长什么样没变"。
   数值断言（组内 Lens 值）作为快速守门。
"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
OUT = os.path.join(os.path.dirname(PKG_DIR), "IDES", "workspace", "_plock_selfheal")
os.makedirs(OUT, exist_ok=True)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-56s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    plock._proj_cache.clear()
    return bpy.context.scene


def mkcam(sc, name="Cam", loc=(0.0, 0.0, 10.0)):
    cd = bpy.data.cameras.new(name); cd.lens = 50.0; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def lens_node(cam_data_name):
    g = bpy.data.node_groups.get("Camera Project | " + cam_data_name)
    for n in (g.nodes if g else []):
        if n.type == "VALUE" and n.label == "Lens":
            return n
    return None


def shot(tag):
    rx, ry = sc.render.resolution_x, sc.render.resolution_y
    p = os.path.join(OUT, tag + ".png")
    sc.render.filepath = p
    bpy.ops.render.render(write_still=True)
    sc.render.resolution_x, sc.render.resolution_y = rx, ry
    return p


def pixdiff(a, b):
    try:
        from PIL import Image
    except ImportError:
        return 0.0, -1
    ia, ib = Image.open(a).convert("RGB"), Image.open(b).convert("RGB")
    pa, pb = ia.load(), ib.load()
    w, h = ia.size
    tot = 0.0; bright = 0
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            ca, cb = pa[x, y], pb[x, y]
            tot += sum(abs(ca[i] - cb[i]) for i in range(3))
            if sum(ca) > 40:
                bright += 1
    return tot / ((h // 2) * (w // 2)) / 3.0, bright


# ═════════ 🔴 F-1 ═════════
print("=" * 72)
print("🔴 F-1  自愈重打补丁：不得把冻结 lens/sensor 重取为当前值")
sc = fresh()
cam = mkcam(sc); sc.camera = cam
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("M"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
tex = nt.nodes.new("ShaderNodeTexChecker"); tex.inputs["Scale"].default_value = 8.0
g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
o = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(g.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], o.inputs["Surface"])
objs = []
for i in range(3):
    bpy.ops.mesh.primitive_plane_add(size=6.0, location=(0.0, 0.0, -float(i) * 2))
    ob = bpy.context.active_object
    ob.name = "L%d" % i; ob.data.name = "L%dMesh" % i
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name), "ShaderNodeTree")
    objs.append(ob)
ld = bpy.data.lights.new("L", "SUN"); ld.energy = 5.0
lo = bpy.data.objects.new("L", ld); sc.collection.objects.link(lo)
lo.rotation_euler = (0.6, 0.2, 0.3)
_eng = [i.identifier for i in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in _eng else "BLENDER_EEVEE"
sc.render.resolution_x, sc.render.resolution_y = 320, 180
sc.render.image_settings.file_format = "PNG"
bpy.context.view_layer.update()

plock.lock_group(sc, cam)
chk("前置：锁定后冻结 Lens = 50", abs(lens_node(cam.data.name).outputs["Value"].default_value - 50.0) < 1e-6)
cam.data.lens = 85.0                                   # ★ 变焦（制造"当前值 ≠ 冻结值"）
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
pB = shot("A_zoom85")
chk("前置：变焦到 85 后冻结 Lens 仍 50（变焦不影响冻结外观）",
    abs(lens_node(cam.data.name).outputs["Value"].default_value - 50.0) < 1e-6)

def frozen_uv(ob):
    a = ob.data.attributes.get(plock._campos_attr_name(cam.data.name))
    if a is None:
        return None
    n = len(a.data); b = [0.0] * (n * 3)
    a.data.foreach_get("vector", b)
    return list(b)


uv_b = frozen_uv(objs[0])
ng.ensure_camera_project_group(cam, default_aspect=1.0)   # ★ 触发自愈
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
ln = lens_node(cam.data.name)
lv = ln.outputs["Value"].default_value if ln else None
print("   自愈后 组内 Lens = %s（当前相机 %.1f）" % (("%.2f" % lv) if lv is not None else "None", cam.data.lens))
chk("F-1a 自愈后冻结 Lens 仍是锁定时的 50（不是当前 85）",
    lv is not None and abs(lv - 50.0) < 1e-6, "Lens=%s" % lv)
uv_a = frozen_uv(objs[0])
chk("F-1b 自愈期间冻结坐标未被重算（两半同一时刻）",
    uv_b is not None and uv_a == uv_b)
pC = shot("B_after_selfheal")
d, br = pixdiff(pB, pC)
print("   自愈前后渲染像素差 = %.4f  亮像素 = %d" % (d, br))
chk("F-1c 自愈前后【画面不变】（像素级）", (d < 0.01) or (br == -1),
    "像素差 %.4f（修复前 27.57）" % d)
chk("F-1d 画面非空（防空对空）", br > 200 or br == -1, "亮像素 %d" % br)
# 对照：不能对"全新锁定"也沿用旧值
sc = fresh()
cam = mkcam(sc); sc.camera = cam
grp2 = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat2 = bpy.data.materials.new("M2"); mat2.use_nodes = True
nt2 = mat2.node_tree; nt2.nodes.clear()
g2 = nt2.nodes.new("ShaderNodeGroup"); g2.node_tree = grp2
o2 = nt2.nodes.new("ShaderNodeOutputMaterial")
nt2.links.new(g2.outputs["Vector"], o2.inputs["Surface"])
bpy.ops.mesh.primitive_plane_add(size=6.0, location=(0.0, 0.0, 0.0))
ob2 = bpy.context.active_object; ob2.data.materials.append(mat2)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob2.data.name, cam.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
cam.data.lens = 35.0
plock.lock_group(sc, cam)
chk("F-1e 对照：全新锁定用【当前】值 35（别沿用空记录）",
    abs(lens_node(cam.data.name).outputs["Value"].default_value - 35.0) < 1e-6,
    "%.2f" % lens_node(cam.data.name).outputs["Value"].default_value)

# ═════════ 🟡 F-2 ═════════
print()
print("=" * 72)
print("🟡 F-2  只清孤儿那份 campos，不动其它相机")
sc = fresh()
cA = mkcam(sc, "CamA"); sc.camera = cA
cB = mkcam(sc, "CamB", (4.0, 0.0, 10.0))
grpA = ng.ensure_camera_project_group(cA, default_aspect=1.0)
grpB = ng.ensure_camera_project_group(cB, default_aspect=1.0)
MAT = bpy.data.materials.new("MAT"); MAT.use_nodes = True
nt3 = MAT.node_tree; nt3.nodes.clear()
ga = nt3.nodes.new("ShaderNodeGroup"); ga.node_tree = grpA
gb = nt3.nodes.new("ShaderNodeGroup"); gb.node_tree = grpB
oo = nt3.nodes.new("ShaderNodeOutputMaterial")
nt3.links.new(ga.outputs["Vector"], oo.inputs["Surface"])
bpy.ops.mesh.primitive_plane_add(size=4.0, location=(0.0, 0.0, 0.0))
M = bpy.context.active_object; M.name = "M"
M.data.materials.append(MAT)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (M.data.name, cA.data.name), "ShaderNodeTree")
bpy.ops.mesh.primitive_plane_add(size=4.0, location=(4.0, 0.0, -2.0))
M2 = bpy.context.active_object; M2.name = "M2"
M2.data.materials.append(MAT)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (M2.data.name, cB.data.name), "ShaderNodeTree")
bpy.context.view_layer.update()
plock.lock_group(sc, cA)
plock.lock_group(sc, cB)
A_ATTR = plock._campos_attr_name(cA.data.name)
B_ATTR = plock._campos_attr_name(cB.data.name)
chk("前置：M 上同时挂着 A、B 两份 campos",
    M.data.attributes.get(A_ATTR) is not None and M.data.attributes.get(B_ATTR) is not None)
_cdA = cA.data
bpy.data.objects.remove(cA, do_unlink=True)
bpy.context.view_layer.update()
chk("前置：M 被判为孤儿", any(o.name == "M" for o, _ in plock.find_orphan_locks(sc)))
plock.reset_orphan_locks(sc)
bpy.context.view_layer.update()
print("   M 上: A=%s  B=%s" % (M.data.attributes.get(A_ATTR) is not None,
                              M.data.attributes.get(B_ATTR) is not None))
chk("F-2a M 上【CamB 那份】campos 保留（不误删）",
    M.data.attributes.get(B_ATTR) is not None)
chk("F-2b M 上【CamA 那份】campos 被清掉",
    M.data.attributes.get(A_ATTR) is None)
chk("F-2c M2 上的 B campos 未受影响", M2.data.attributes.get(B_ATTR) is not None)
chk("F-2d CamB 仍健康（UI 正常）",
    plock.lock_status(sc, cB)["locked"] and plock.lock_status(sc, cB)["patched"])

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX9_DONE")
