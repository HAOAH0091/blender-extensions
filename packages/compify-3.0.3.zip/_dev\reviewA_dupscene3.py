"""审查 A-7d：复制场景双倍 dolly 的可见后果 + 能否被「重置」收回
对照 = 同样操作但【不复制场景】的一次补偿
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock
L.report("A-7d 双倍 dolly：画面差异 + 重置能否收回")


def run(dup):
    C = L.build(n_grid=3)
    sc, cam, cd = C["scene"], C["cam"], C["cd"]
    A = C["objs"][0]
    A.name = "Grid0"
    plock.lock_group(sc, cam)
    if dup:
        scA = bpy.context.scene
        scA.name = "A"
        bpy.ops.scene.new(type="LINK_COPY")
        scB = bpy.context.scene
        scB.name = "B"
        cam = bpy.data.objects.get("Cam")
    cam.data.lens = 85.0
    if dup:
        for nm in ("A", "B"):
            bpy.context.window.scene = bpy.data.scenes[nm]
            L.run_h(bpy.data.scenes[nm], times=2)
    else:
        L.run_h(sc, times=2)
    z = cam.location.z
    u_locked = L.uvimg("dup")
    r = plock.reset_group(bpy.context.scene, cam)
    z_after = cam.location.z
    return z, u_locked, z_after, r.get("message", "")[:30]


z1, u1, za1, m1 = run(False)
z2, u2, za2, m2 = run(True)
print("  不复制场景：变焦后相机 z=%.4f  重置后 z=%.4f" % (z1, za1))
print("  复制场景两次：变焦后相机 z=%.4f  重置后 z=%.4f (%s)" % (z2, za2, m2))
L.chk("复制场景不会让 dolly 施加两次", abs(z2 - z1) < 1e-6,
      "Δz=%.4f（应为 0，实际多推了一份 %.4f）" % (z2 - z1, z2 - z1))
L.chk("重置能把相机收回原位（两种情形一致）", abs(za2 - za1) < 1e-6,
      "不复制=%s 复制=%s" % (za1, za2))
d = L.uvd(u1, u2)
L.info("两种情形「锁定中画面」的 UV 探针差=%.6f（>0 表示可见构图已经不同）" % d)
L.summary()
