"""关键验证：delta 能否用「常数偏移 C + 缩放 k·persp(p)」精确表达？
若可以 ⇒ 不需要逐顶点属性，只要 1 个向量 + 1 个标量（普通数值节点）。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(shape):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 4
    verts, faces = [], []
    H = 10.0 if shape == "铺满" else 1.5
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -H + 2*H*ix/ns
            y = -H + 2*H*iy/ns
            z = 0.0 if shape != "倾斜" else 0.35*x
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def persp(cam, ob):
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


def fit(delta, live):
    """最小二乘拟合 delta ≈ C + k * live  ⇒ 解 [Cx,Cy,k]
    分开 x/y 各自拟合 k？先试共用 k：delta = C + k*live
    """
    n = delta.shape[0]
    # 未知量: Cx, Cy, k
    A = np.zeros((2*n, 3))
    b = np.zeros(2*n)
    for i in range(n):
        A[i, 0] = 1.0; A[i, 1] = 0.0; A[i, 2] = live[i, 0]
        b[i] = delta[i, 0]
        A[n+i, 0] = 0.0; A[n+i, 1] = 1.0; A[n+i, 2] = live[i, 1]
        b[n+i] = delta[i, 1]
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    Cx, Cy, k = sol
    pred = np.zeros_like(delta)
    pred[:, 0] = Cx + k*live[:, 0]
    pred[:, 1] = Cy + k*live[:, 1]
    return (Cx, Cy, k), float(np.abs(pred - delta).max())


def run(shape, opname, mutate):
    sc, cam, cd, ob = build(shape)
    plock.lock_group(sc, cam)
    frozen = persp(cam, ob)
    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    live = persp(cam, ob)
    delta = frozen - live
    (Cx, Cy, k), err = fit(delta, live)
    print("  %-5s %-9s C=(%+.4f,%+.4f) k=%+.6f  拟合残差=%.8f  %s" % (
        shape, opname, Cx, Cy, k, err,
        "仿射精确 ✓" if err < 1e-5 else "仿射表达不了 ✗"))


print("=" * 90)
print("delta 能否用「常数 C + 缩放 k·persp(p)」表达？（= 普通数值节点，无逐顶点属性）")
print("=" * 90)
for shape in ("小", "铺满", "倾斜"):
    run(shape, "平移x+2", lambda cam, cd: setattr(cam.location, "x", 2.0))
    run(shape, "变焦85", lambda cam, cd: setattr(cd, "lens", 85.0))
    run(shape, "旋转15°", lambda cam, cd: setattr(cam.rotation_euler, "z", math.radians(15)))
    def combo(cam, cd):
        cam.location.x = 1.5
        cam.rotation_euler.z = math.radians(10)
        cd.lens = 68.0
    run(shape, "组合", combo)
    print()
print("AFFINE_DONE")
