"""最小探针：编辑模式加顶点之后 adapt_object 到底写没写顶点。"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy, bmesh

C.load()
plock = C.PL()


def probe(tag, do_edit):
    sc, cam, cd, grp = C.setup()
    mat = C.probe_mat(grp)
    A = C.add_grid("G", cam, mat, ns=3)
    CTRL = C.add_grid("GC", cam, mat, ns=3, x0=2.6)
    if do_edit:
        bpy.context.view_layer.objects.active = A
        bpy.ops.object.mode_set(mode="EDIT")
        bm = bmesh.from_edit_mesh(A.data)
        bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
        bmesh.update_edit_mesh(A.data)
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.update()
    r = plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    print("\n--- %s (do_edit=%s) lock=%s ---" % (tag, do_edit, r["success"]))
    print("   顶点数 A=%d CTRL=%d" % (len(A.data.vertices), len(CTRL.data.vertices)))
    sp = os.path.dirname(os.path.abspath(__file__))
    b0 = [tuple(v.co) for v in CTRL.data.vertices[:3]]
    a0 = [tuple(v.co) for v in A.data.vertices[:3]]
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    view = plock.get_camera_view_matrix(cam)
    okA = plock.adapt_object(A, cam, st, view_now=view)
    okC = plock.adapt_object(CTRL, cam, st, view_now=view)
    a1 = [tuple(v.co) for v in A.data.vertices[:3]]
    b1 = [tuple(v.co) for v in CTRL.data.vertices[:3]]
    print("   adapt A=%s 顶点0 %s → %s" % (okA, np.round(a0[0], 4), np.round(a1[0], 4)))
    print("   adapt C=%s 顶点0 %s → %s" % (okC, np.round(b0[0], 4), np.round(b1[0], 4)))
    print("   base A 前3 =", [tuple(np.round(x, 3)) for x in
                              [plock._read_base_attribute(A)[i] for i in range(3)]] if
          plock._read_base_attribute(A) else None)
    print("   ref_depth=%s  dolly/zoom 由 state.locked_focal=%s" %
          (st.get("ref_depth"), st.get("locked_focal")))


probe("对照（不编辑）", False)
probe("编辑模式加顶点", True)
print("\nDONE")
