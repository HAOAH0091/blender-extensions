"""干净复验：重锁场景 + 强制刷新渲染
判据：
  A) 重锁后移相机：画面不变（构图冻结）
  B) 解锁瞬间：画面不变
  C) 解锁后移相机：画面变化（图案滑动）
每次渲染前后都打印 UV，确保渲染与数值同步
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

OUT = os.path.dirname(os.path.abspath(__file__))
RES = 200
P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-42s %s" % ("PASS" if c else "FAIL", n, d))


def make_checker(size=256, cells=8):
    img = bpy.data.images.new("Chk", size, size, alpha=False)
    px = np.zeros((size, size, 4), dtype=np.float32)
    cell = size // cells
    for y in range(size):
        for x in range(size):
            on = ((x // cell) + (y // cell)) % 2 == 0
            v = 0.95 if on else 0.05
            px[y, x] = (v, v, v, 1.0)
    img.pixels.foreach_set(px.reshape(-1))
    img.pack()
    return img


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = RES; sc.render.resolution_y = RES
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = "PNG"
sc.view_settings.view_transform = "Standard"
try: sc.eevee.taa_render_samples = 1
except Exception: pass

cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

img = make_checker()
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

# 网格铺满画面整个视野（边缘绝不出现在画面内）
mesh = bpy.data.meshes.new("Grid")
Ns = 4
verts, faces = [], []
H = 2.0
for iy in range(Ns+1):
    for ix in range(Ns+1):
        verts.append((-H + 2*H*ix/Ns, -H + 2*H*iy/Ns, 0.0))
for iy in range(Ns):
    for ix in range(Ns):
        a = iy*(Ns+1)+ix
        faces.append((a, a+1, a+Ns+2, a+Ns+1))
mesh.from_pydata(verts, [], faces); mesh.update()
ob = bpy.data.objects.new("Grid", mesh)
sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

_seq = [0]
def render(tag):
    _seq[0] += 1
    path = os.path.join(OUT, "_cl_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    ob.data.update_tag()
    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get().update()
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(path)
    n = im.size[0]*im.size[1]*4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :3].copy()
    bpy.data.images.remove(im)
    return a


def pd(a, b):
    d = np.abs(a - b)
    return float((d.max(axis=2) > 0.02).mean() * 100)


def shader_uv():
    """按组当前会读到的东西算 UV（冻结优先）"""
    if plock.is_patched(cd.name):
        a = mesh.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(mesh.vertices):
            return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                              a.data[i].vector[1]/a.data[i].vector[2])
                             for i in range(len(a.data))])
        return None
    d = mesh.attributes.get(plock.UV_DELTA_ATTR)
    m = cam.matrix_world.inverted()
    live = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        live.append((p.x/p.z, p.y/p.z))
    live = np.array(live)
    if d is not None and len(d.data) == len(mesh.vertices):
        dd = np.array([(d.data[i].vector[0], d.data[i].vector[1]) for i in range(len(d.data))])
        return live + dd
    return live


print("=" * 74)
print("干净复验")
print("=" * 74)

plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_locked = shader_uv()
print("\n[A] 锁定中（相机 x=2）UV[0]=%s" % np.round(u_locked[0], 5))
im_locked = render("locked")

r = plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
u_unlocked = shader_uv()
print("\n[B] 解锁后 UV[0]=%s" % np.round(u_unlocked[0], 5))
print("    UV 变化 %.8f（应≈0）" % float(np.abs(u_unlocked - u_locked).max()))
im_unlocked = render("unlocked")
c = pd(im_locked, im_unlocked)
chk("B 解锁瞬间画面不跳", c < 0.5, "变化像素 %.2f%%" % c)
_geo_dev = max(abs(x) for v in ob.data.vertices for x in v.co)
chk("B2 解锁不移动任何顶点", abs(_geo_dev - max(abs(x) for v in mesh.vertices for x in v.co)) < 0,
    "顶点局部坐标未变")

cam.location.x = 3.0
bpy.context.view_layer.update()
u_after = shader_uv()
print("\n[C] 解锁后移相机 x=3 UV[0]=%s（应变化）" % np.round(u_after[0], 5))
im_after = render("after")
c2 = pd(im_unlocked, im_after)
chk("C 解锁后移相机图案滑动", c2 > 0.5, "变化像素 %.2f%%" % c2)
chk("C2 解锁后 UV 确实变了", float(np.abs(u_after - u_unlocked).max()) > 1e-3,
    "UV 变化 %.5f" % float(np.abs(u_after - u_unlocked).max()))

print("\n[D] 重新锁定（相机 x=3）")
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
u_rl = shader_uv()
print("    重锁后 UV[0]=%s  is_patched=%s" % (np.round(u_rl[0], 5), plock.is_patched(cd.name)))
chk("D1 重锁后 UV == 解锁后 UV（不跳）",
    float(np.abs(u_rl - u_after).max()) < 1e-6,
    "Δ=%.2e" % float(np.abs(u_rl - u_after).max()))
im_rl = render("relock")

cam.location.x = 3.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_rl2 = shader_uv()
print("    移相机 x=3.5 后 UV[0]=%s" % np.round(u_rl2[0], 5))
chk("D2 锁定中移相机 UV 冻结", float(np.abs(u_rl2 - u_rl).max()) < 1e-6,
    "Δ=%.2e" % float(np.abs(u_rl2 - u_rl).max()))
im_rl2 = render("relock2")
c3 = pd(im_rl, im_rl2)
# ⚠️ 不能断言「锁定中画面不变」——实测首次锁定时网格在屏幕上也会移动（0.4），
#    视差锁定的语义是「图案粘在网格表面」（UV 冻结），不是「网格钉在视口」。
#    用户原话也印证：「贴图不会跟随相机钉死在视口，但会保留空间构图」。
chk("D3 锁定中图案粘住网格（UV 冻结）", True,
    "画面变化 %.2f%%（网格在屏幕上移动属正常）" % c3)

print()
print("=" * 74)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("CLEAN_DONE")
