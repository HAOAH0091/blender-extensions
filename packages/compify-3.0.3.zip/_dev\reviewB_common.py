"""审查员 B（几何与数据边界）公共工具 —— 只读产品代码，不改产品代码。

用法（其他 reviewB_*.py 里）：
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import reviewB_common as C
    C.load()          # 载入 compify_plock_dev 包
    sc, cam, cd, grp, mat = C.setup()   # 干净场景 + 相机 + 投影组 + 探针材质
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
PKG = "compify_plock_dev"
_loaded = {}


def load():
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
    mod = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = mod
    spec.loader.exec_module(mod)
    _loaded["plock"] = sys.modules[PKG + ".compify_parallax_lock"]
    _loaded["ng"] = sys.modules[PKG + ".node_groups"]
    return _loaded["plock"], _loaded["ng"]


def PL():
    return _loaded["plock"]


def NG():
    return _loaded["ng"]


RES = 64
RESULT = []


def chk(name, cond, detail=""):
    RESULT.append((name, bool(cond)))
    print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", name, detail))


def summary():
    p = sum(1 for _, c in RESULT if c)
    print("\nRESULT %d PASS / %d FAIL" % (p, len(RESULT) - p))
    for n, c in RESULT:
        if not c:
            print("   FAILED:", n)
    print("REVIEWB_DONE")


def setup(cam_loc=(0, 0, 5), cam_rot=(0, 0, 0), lens=50.0, res=RES):
    """干净场景 + 相机 + Camera Project 组。返回 (scene, cam, camdata, grp)。"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    plock = PL()
    for d in (plock._proj_cache, plock._base_cache, plock._last_view, plock._backfill_warned):
        try:
            d.clear()
        except Exception:
            pass
    sc = bpy.context.scene
    _eng = [i.identifier for i in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
    sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in _eng else "BLENDER_EEVEE"
    sc.render.resolution_x = res
    sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = lens
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = cam_loc
    cam.rotation_euler = cam_rot
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = NG().ensure_camera_project_group(cam, default_aspect=1.0)
    return sc, cam, cd, grp


def probe_mat(grp, name="Probe"):
    """UV 探针材质：颜色 = (u/4+0.5, v/4+0.5)，用于把 UV 编码进像素。"""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    return mat


def grid_mesh(name, ns=3, H=2.0, shape="平面", x0=0.0, nz=0.0):
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            x = x0 + (-H + 2 * H * ix / ns)
            y = -H + 2 * H * iy / ns
            if shape == "平面":
                z = 0.0
            elif shape == "倾斜":
                z = 0.28 * x
            else:
                z = (iy - ns / 2.0) * 0.5 / max(ns / 3.0, 1.0)
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    return me


def add_grid(name, cam, mat, ns=3, H=2.0, shape="平面", x0=0.0, loc=(0, 0, 0), uvadjust=True):
    me = grid_mesh(name, ns=ns, H=H, shape=shape, x0=x0)
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    ob.location = loc
    me.materials.append(mat)
    if uvadjust:
        attach(ob, cam)
    bpy.context.view_layer.update()
    return ob


def attach(ob, cam):
    """建 UV Adjust 组（get_lock_targets 的主检索路径）。"""
    nm = "UV Adjust | %s | %s" % (ob.data.name, cam.data.name)
    if bpy.data.node_groups.get(nm) is None:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")
    return nm


_seq = [0]


def uvimg(tag="x"):
    _seq[0] += 1
    p = os.path.join(HERE, "_rb_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    sc = bpy.context.scene
    sc.render.filepath = p
    if os.path.exists(p):
        os.remove(p)
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    try:
        os.remove(p)
    except Exception:
        pass
    return (a - 0.5) * 4.0


def uvd(a, b):
    return float(np.abs(a - b).mean())


def attrs(ob):
    """列出 mesh 上所有属性的名字 + 是否有 nan/inf。"""
    out = {}
    for a in ob.data.attributes:
        try:
            n = len(a.data)
            if a.data_type == "FLOAT_VECTOR" and n:
                buf = [0.0] * (n * 3)
                a.data.foreach_get("vector", buf)
                arr = np.array(buf)
                out[a.name] = (a.data_type, a.domain, n, bool(np.isnan(arr).any()),
                               bool(np.isinf(arr).any()), float(np.nanmax(np.abs(arr))) if n else 0.0)
            else:
                out[a.name] = (a.data_type, a.domain, n, False, False, 0.0)
        except Exception as e:
            out[a.name] = ("ERR", str(e), -1, False, False, 0.0)
    return out


def verts_nan(ob):
    n = len(ob.data.vertices)
    if n == 0:
        return False, False
    buf = [0.0] * (n * 3)
    ob.data.vertices.foreach_get("co", buf)
    arr = np.array(buf)
    return bool(np.isnan(arr).any()), bool(np.isinf(arr).any())


def campos_uv(ob, cam_name):
    """读冻结坐标 → 透视 UV（逐顶点）。"""
    a = ob.data.attributes.get(PL()._campos_attr_name(cam_name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    n = len(a.data)
    buf = [0.0] * (n * 3)
    a.data.foreach_get("vector", buf)
    arr = np.array(buf).reshape(-1, 3)
    with np.errstate(divide="ignore", invalid="ignore"):
        uv = arr[:, :2] / arr[:, 2:3]
    return uv


def run_handler(sc):
    bpy.context.view_layer.update()
    PL().parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def nan_report(ob, cam_name):
    "返回 (nan_attr_names, nan_verts, cam_uv_nan_count)"
    a = attrs(ob)
    nan_attrs = [k for k, v in a.items() if isinstance(v, tuple) and len(v) > 5 and (v[3] or v[4])]
    vn = verts_nan(ob)
    uv = campos_uv(ob, cam_name)
    n_uv = int(np.isnan(uv).sum()) if uv is not None else -1
    return nan_attrs, vn, n_uv, a
