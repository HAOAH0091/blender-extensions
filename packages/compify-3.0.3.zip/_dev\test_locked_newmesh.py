"""验证 degraded 计数：面板能否正确亮 ⚠，且正常情况不误报"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-48s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0):
        ns = 2; H = 1.2
        verts, faces = [], []
        for iy in range(ns+1):
            for ix in range(ns+1):
                verts.append((x0-H+2*H*ix/ns, -H+2*H*iy/ns, 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy*(ns+1)+ix
                faces.append((a, a+1, a+ns+2, a+ns+1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob
    A = mk("GridA", -1.6)
    B = mk("GridB", 1.6)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


def _has_campos(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    return a is not None and len(a.data) == len(ob.data.vertices)


def _uv_err(ob, cam, cd, lock_mw):
    """组当前会给出的 UV vs 「锁定时刻的投影」的误差"""
    if plock.is_patched(cd.name):
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            uv = np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                            a.data[i].vector[1]/a.data[i].vector[2])
                           for i in range(len(a.data))])
        else:
            uv = np.zeros((len(ob.data.vertices), 2))
    else:
        m = cam.matrix_world.inverted()
        nodes = plock._find_delta_nodes(cd.name)
        S, C = 1.0, (0.0, 0.0)
        if nodes is not None:
            S = nodes[0].inputs["Scale"].default_value
            C = tuple(nodes[1].inputs[1].default_value)[:2]
        uv = np.array([((lambda p: (p.x/p.z*S+C[0], p.y/p.z*S+C[1]))(
            m @ (ob.matrix_world @ v.co))) for v in ob.data.vertices])
    mi = lock_mw.inverted()
    exp = np.array([((lambda p: (p.x/p.z, p.y/p.z))(mi @ (ob.matrix_world @ v.co)))
                    for v in ob.data.vertices])
    return float(np.abs(uv - exp).max())


print("=" * 76)
print("★ 核心回归：锁定期间换材质，冻结坐标必须按【锁定位姿】采集")
print("=" * 76)
# 用户场景：A 已锁定并冻结，B 在锁定期间换上同一投影材质。
# 若补写时用【当前】相机位姿，B 的冻结坐标 = "现在看到的投影"，
# 与 A 的"锁定那一刻的投影"口径不同 ⇒ 错位（实测 0.400000 = 相机横移量）。
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
e_instant = _uv_err(B, cam, cd, lock_mw)
print("\n  换材质瞬间 B 的 UV 误差 = %.6f（尚未补写，允许错）" % e_instant)
chk("换材质瞬间确实还没有冻结坐标", not _has_campos(B, cd))

# 跑一帧 handler 就应修好（真值扫描在第一次 tick 就会命中）
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("1 帧后 B 拿到冻结坐标", _has_campos(B, cd))
e1 = _uv_err(B, cam, cd, lock_mw)
chk("B 的图案与 A 同口径（按锁定位姿）", e1 < 1e-5, "UV 误差 = %.8f" % e1)
chk("对照 A 仍正确", _uv_err(A, cam, cd, lock_mw) < 1e-5,
    "UV 误差 = %.8f" % _uv_err(A, cam, cd, lock_mw))

# 更严格：拿"按当前位姿采集"做对照，证明这个判据有区分力
_correct = np.array([(B.data.attributes[plock._campos_attr_name(cd.name)].data[i].vector[0],
                      B.data.attributes[plock._campos_attr_name(cd.name)].data[i].vector[1])
                     for i in range(len(B.data.vertices))])
_m = cam.matrix_world.inverted()
_wrong = np.array([((lambda p: (p.x, p.y))(_m @ (B.matrix_world @ v.co)))
                   for v in B.data.vertices])
_diff = float(np.abs(_correct - _wrong).max())
chk("判据有区分力（错用当前位姿会差出可见量）", _diff > 1e-3,
    "两者差 %.6f" % _diff)

print()
print("=" * 76)
print("degraded 计数（面板 ⚠ 的依据）")
print("=" * 76)

# 1 正常：只有普通网格
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock.lock_group(sc, cam)
st = plock.lock_status(sc, cam)
print("\n[1] 只有普通锁定网格")
chk("degraded == 0（不误报）", st["degraded"] == 0, "degraded=%d" % st["degraded"])

# 2 锁定期间新接入普通网格
cam.location.x = 2.0
bpy.context.view_layer.update()
B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
st = plock.lock_status(sc, cam)
print("\n[2] 锁定期间接入【普通】网格")
chk("degraded == 0（普通网格能冻结，不该报）", st["degraded"] == 0,
    "degraded=%d" % st["degraded"])

# 3 锁定期间新接入带修改器网格
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
m = B.modifiers.new("S", "SUBSURF"); m.levels = 1
B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
st = plock.lock_status(sc, cam)
print("\n[3] 锁定期间接入【带修改器】网格")
chk("degraded >= 1（面板会亮 ⚠）", st["degraded"] >= 1, "degraded=%d" % st["degraded"])

# 4 锁定期间新接入带形态键网格
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
B.shape_key_add(name="K1", from_mix=False)
B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
st = plock.lock_status(sc, cam)
print("\n[4] 锁定期间接入【带形态键】网格")
chk("degraded >= 1", st["degraded"] >= 1, "degraded=%d" % st["degraded"])

# 5 解锁后不该报 degraded
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
m = B.modifiers.new("S", "SUBSURF"); m.levels = 1
B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
st = plock.lock_status(sc, cam)
print("\n[5] 解锁之后")
chk("degraded == 0（解锁是正常态，不该常亮 ⚠）", st["degraded"] == 0,
    "degraded=%d" % st["degraded"])

# 6 重置后
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
st = plock.lock_status(sc, cam)
print("\n[6] 重置之后")
chk("degraded == 0", st["degraded"] == 0, "degraded=%d" % st["degraded"])

print()
print("=" * 76)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("DEGRADED_DONE")
