"""复现用户报告：视差锁定期间调焦距 → 解锁 → 贴图跳变（网格没动）

⚠️ 关键：这次要走**完整投影组**（含 zoom / shift / rotate 节点）做 UV 探针，
   上一轮的 verify_ck.uv_at() 只算了 persp*S+C，漏掉了 zoom 节点的乘子 ——
   那正是这个 bug 能溜过去的原因。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 96


def build(shape="平面", cam_loc=(0, 0, 5), cam_rot=(0, 0, 0)):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = cam_loc
    cam.rotation_euler = cam_rot
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    ns = 3
    H = 2.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            x = -H + 2 * H * ix / ns
            y = -H + 2 * H * iy / ns
            if shape == "平面":
                z = 0.0
            elif shape == "倾斜":
                z = 0.35 * x
            else:
                z = (iy - 1.5) * 0.5
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def uvimg():
    _seq[0] += 1
    p = os.path.join(HERE, "_zm_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def scen(tag, shape, cam_loc, cam_rot, zoom_to):
    sc, cam, cd, ob = build(shape, cam_loc, cam_rot)
    plock.lock_group(sc, cam)
    cam.data.lens = zoom_to
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    u_lock = uvimg()
    nodes = plock._find_delta_nodes(cd.name)
    S = nodes[0].inputs["Scale"].default_value
    C = list(nodes[1].inputs[1].default_value)[:2]

    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    u_ul = uvimg()
    jump = float(np.abs(u_ul - u_lock).mean())
    print("  %-26s 变焦%3.0f  锁定中S=%.4f C=(%+.4f,%+.4f)  解锁跳变=%.8f %s" % (
        tag, zoom_to, S, C[0], C[1], jump, "OK" if jump < 1e-3 else "【跳变】"))

    # 网格有没有动
    return jump


print("=" * 92)
print("复现：锁定期间变焦 → 解锁，贴图是否跳变（完整组 UV 探针）")
print("=" * 92)
scen("平面/相机居中", "平面", (0, 0, 5), (0, 0, 0), 85)
scen("平面/85→50", "平面", (0, 0, 5), (0, 0, 0), 50)
scen("倾斜/相机居中", "倾斜", (0, 0, 5), (0, 0, 0), 85)
scen("立体/相机居中", "立体", (0, 0, 5), (0, 0, 0), 85)
scen("平面/相机偏移", "平面", (1.5, -0.8, 5), (0, 0, 0), 85)
scen("立体/相机偏移", "立体", (1.5, -0.8, 5), (0, 0, 0), 85)
scen("平面/相机旋转", "平面", (0, 0, 5), (0, 0, math.radians(12)), 85)
print("ZOOMREPRO_DONE")
