"""把内部术语翻译成「画面上看到什么」——干净重写版

尺子自检（先证明它能测出已知差异）：
  用色 = u*0.2 + 0.5 把 UV ∈ [-2.5, 2.5] 压进 PNG 的 [0,1]，
  避免 UV > 1 被截断（我第一次直接用 u 当颜色，读数就低估了一半）。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 128
SCALE = 0.2      # UV 压缩系数


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.render.image_settings.color_depth = "16"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    for ax in ("X", "Y"):
        mul = nt.nodes.new("ShaderNodeMath"); mul.operation = "MULTIPLY"
        mul.inputs[1].default_value = SCALE
        add = nt.nodes.new("ShaderNodeMath"); add.operation = "ADD"
        add.inputs[1].default_value = 0.5
        nt.links.new(sep.outputs[ax], mul.inputs[0])
        nt.links.new(mul.outputs["Value"], add.inputs[0])
        nt.links.new(add.outputs["Value"], comb.inputs[ax])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    ns = 6; h = 30.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def render_uv(tag):
    _seq[0] += 1
    p = os.path.join(HERE, "_tt_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)
    u = (a[..., 0].copy() - 0.5) / SCALE        # 反解回 UV
    al = a[..., 3].copy()
    bpy.data.images.remove(im)
    return u, al


print("=" * 78)
print("尺子自检：这个探针能测出已知差异吗？")
print("=" * 78)
sc, cam, cd, ob = build()
nodes = plock._find_delta_nodes(cd.name)
S_node, C_node = nodes[0], nodes[1]

C_node.inputs[1].default_value[:2] = (0.0, 0.0)
u_ref, alpha = render_uv("ref")
valid = alpha > 0.5
print("  有效像素占比 = %.1f%%" % (valid.mean() * 100))
print("  UV 覆盖范围: [%.3f, %.3f]  跨度=%.4f" % (
    u_ref[valid].min(), u_ref[valid].max(), u_ref[valid].max() - u_ref[valid].min()))

print("\n  已知差异检验：C 每 +1.0，图案应滑动「1 个 UV 单位」")
ok = True
for c in (-0.1, -0.4, -1.0, -2.0):
    C_node.inputs[1].default_value[:2] = (c, 0.0)
    u, _ = render_uv("m%.1f" % abs(c))
    du = float(np.mean(u[valid] - u_ref[valid]))
    ratio = du / c if c else 0.0
    flag = "✓" if abs(ratio - 1.0) < 0.05 else "✗ 偏离"
    if abs(ratio - 1.0) >= 0.05:
        ok = False
    print("    C=%+.1f  ->  图案滑动 %+.4f UV  (滑动量/C = %.3f)  %s" % (c, du, ratio, flag))
print("  尺子%s" % ("可用（线性，1:1 吻合）" if ok else "【不可用】"))

span = float(u_ref[valid].max() - u_ref[valid].min())
print()
print("=" * 78)
print("结论：用你能看懂的话说")
print("=" * 78)
print("  画面横向能容纳 %.2f 个 UV 单位。" % span)
print("  C = 1.0  ⇒  图案横向滑动约 %.0f%% 屏宽" % (1.0 / span * 100))
print("  C = 0.4  ⇒  图案横向滑动约 %.0f%% 屏宽" % (0.4 / span * 100))
print()
print("  反复锁定/解锁（每轮 C 累积 0.4）：")
for n in (1, 3, 5, 10):
    print("    第 %2d 轮后：图案偏了 %.0f%% 屏宽%s" % (
        n, n * 0.4 / span * 100, "  <- 已经跑出画面" if n * 0.4 / span > 1.0 else ""))
print()
print("TR_DONE")
