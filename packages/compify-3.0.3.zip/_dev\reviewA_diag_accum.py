"""审查 A-1b：追查「每轮解锁 C 值多累 -0.08」的来源（插桩，不下结论）"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import reviewA_lib as L

plock = L.plock
L.report("A-1b 逐轮插桩：C 为什么单调累积")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
ATTR = plock._campos_attr_name(cd.name)


def persp_cam(ob):
    """当前几何 → 当前相机空间 → 透视坐标（首顶点 & 均值）"""
    M = cam.matrix_world.inverted() @ ob.matrix_world
    v = L.lverts(ob).reshape(-1, 3)
    cs = v @ np.array(M)[:3, :3].T + np.array(M)[:3, 3]
    p = cs[:, :2] / cs[:, 2:3]
    return p


def frozen_persp(ob):
    a = ob.data.attributes.get(ATTR)
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    buf = np.empty(len(a.data) * 3, dtype=np.float64)
    a.data.foreach_get("vector", buf)
    v = buf.reshape(-1, 3)
    return v[:, :2] / v[:, 2:3]


for i in range(4):
    S0, C0 = L.node_sc(cam)
    fp_before = frozen_persp(A)
    lp_before = persp_cam(A)
    print("\n--- 第 %d 轮开始：相机 x=%.3f  S=%.6f C=(%+.6f,%+.6f) campos=%s"
          % (i + 1, cam.location.x, S0, C0[0], C0[1],
             "有" if fp_before is not None else "无"))
    if fp_before is not None:
        print("    解锁态下 冻结persp均值=(%+.5f,%+.5f)  实时persp均值=(%+.5f,%+.5f)  差=%+.6f"
              % (fp_before[:, 0].mean(), fp_before[:, 1].mean(),
                 lp_before[:, 0].mean(), lp_before[:, 1].mean(),
                 (fp_before[:, 0] - lp_before[:, 0]).mean()))

    r = plock.lock_group(sc, cam)
    S1, C1 = L.node_sc(cam)
    fp_lock = frozen_persp(A)
    print("  锁定后 S=%.6f C=(%+.6f,%+.6f) |campos| 冻结persp均值=(%+.5f,%+.5f)"
          % (S1, C1[0], C1[1], fp_lock[:, 0].mean(), fp_lock[:, 1].mean()))

    cam.location.x += 0.4
    L.run_h(sc, times=1)
    lp_after = persp_cam(A)
    fp_after = frozen_persp(A)
    print("  移相机+0.4 后 实时persp均值=(%+.5f) 冻结persp均值=(%+.5f) 几何位移=%.3e"
          % (lp_after[:, 0].mean(), fp_after[:, 0].mean(),
             float(np.abs(L.wverts(A) - np.array([tuple(A.matrix_world @ v.co)
                                                  for v in A.data.vertices])).max())))

    r2 = plock.unlock_group(sc, cam)
    S2, C2 = L.node_sc(cam)
    fp_ul = frozen_persp(A)
    lp_ul = persp_cam(A)
    print("  解锁后 S=%.6f C=(%+.6f,%+.6f) campos=%s 实时persp均值=%+.5f"
          % (S2, C2[0], C2[1],
             "有" if fp_ul is not None else "无", lp_ul[:, 0].mean()))
    cam.location.x -= 0.4
    L.run_h(sc, times=1)
print()
print("（解读：每轮 C 增量应等于 -0.08 = 0.4/5；若等于它，说明每轮解锁都把"
      "「移相机造成的真实投影变化」又当成永久偏移存了一次）")
