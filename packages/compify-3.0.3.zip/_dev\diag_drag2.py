"""复现两个拖拽瑕疵
问题1：推向相机时被锁死在某个距离前
问题2：第二次拖动开始时会跳回原始位置
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
MU = __import__("mathutils")


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0); cam.rotation_euler = (0.0, 0.0, 0.0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    mesh = bpy.data.meshes.new("G")
    ns = 2
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-1+2*ix/ns, -1+2*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def depth_stats(cam, ob):
    vi = plock.get_camera_view_matrix(cam).inverted()
    ds = []
    for v in ob.data.vertices:
        p = vi @ (ob.matrix_world @ v.co)
        ds.append(-p.z)
    return np.array(ds)


print("=" * 80)
print("【问题1】推向相机：深度/offset 何时被卡住")
print("=" * 80)
sc, cam, cd, ob = build()
print(plock.lock_group(sc, cam).get("message"))
M_lock = ob.matrix_world.copy()
print("锁定后顶点深度范围: [%.4f, %.4f]" % tuple(depth_stats(cam, ob)[[np.argmin(depth_stats(cam, ob)), np.argmax(depth_stats(cam, ob))]]))
print("MIN_DEPTH =", plock.MIN_DEPTH)
print()
print("  推近量   offset记录  顶点深度[min, max]   位姿Z     物体中心深度  说明")
for step in [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.4, 4.6, 4.8, 4.9]:
    M = M_lock.copy()
    M.translation = M_lock.translation + MU.Vector((0, 0, step))
    ob.matrix_world = M
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    off = ob.get(plock.DRAG_OFFSET_KEY, None)
    ds = depth_stats(cam, ob)
    c = plock._mesh_center_local(ob)
    dc = plock._view_depth(plock.get_camera_view_matrix(cam).inverted(), ob.matrix_world @ c)
    note = ""
    if off is not None and abs((-step) - off) > 1e-3:
        note = "<== offset 被截断"
    if ds.min() <= plock.MIN_DEPTH * 10:
        note += " <== 顶点贴到相机"
    print("  %.1f     %s   [%.5f, %.5f]  %+.4f   %.5f   %s" %
          (step, ("%.5f" % off) if off is not None else "None", ds.min(), ds.max(),
           ob.matrix_world.translation.z, dc, note))

print()
print("=" * 80)
print("【问题2】第二次拖动：位姿是否跳回原位")
print("=" * 80)
sc, cam, cd, ob = build()
plock.lock_group(sc, cam)
M_lock = ob.matrix_world.copy()
print("锁定位姿 Z = %.4f" % M_lock.translation.z)
print("锁定后顶点世界 Z 范围: [%.4f, %.4f]" % (
    min((ob.matrix_world @ v.co).z for v in ob.data.vertices),
    max((ob.matrix_world @ v.co).z for v in ob.data.vertices)))

axis_w = plock.get_camera_view_matrix(cam).to_3x3() @ MU.Vector((0.0, 0.0, -1.0))

print("\n--- 第一次拖动：推近 1.5 ---")
M1 = M_lock.copy()
M1.translation = M_lock.translation + MU.Vector((0, 0, 1.5))
ob.matrix_world = M1
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("  拖动结束后 位姿Z=%.4f  顶点世界Z=[%.4f, %.4f]  offset=%s" % (
    ob.matrix_world.translation.z,
    min((ob.matrix_world @ v.co).z for v in ob.data.vertices),
    max((ob.matrix_world @ v.co).z for v in ob.data.vertices),
    ob.get(plock.DRAG_OFFSET_KEY)))

print("\n--- 第二次拖动：再推 0.1（用户期望从当前位置继续）---")
M2 = ob.matrix_world.copy()
M2.translation = M2.translation + MU.Vector((0, 0, 0.1))
ob.matrix_world = M2
bpy.context.view_layer.update()
print("  用户拖到 位姿Z=%.4f" % ob.matrix_world.translation.z)
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("  处理后   位姿Z=%.4f  顶点世界Z=[%.4f, %.4f]  offset=%s" % (
    ob.matrix_world.translation.z,
    min((ob.matrix_world @ v.co).z for v in ob.data.vertices),
    max((ob.matrix_world @ v.co).z for v in ob.data.vertices),
    ob.get(plock.DRAG_OFFSET_KEY)))
print("\n  >>> 位姿被还原到 %.4f（锁定位姿）⇒ 下次拖动从锁定位起算 = 跳变" %
      ob.matrix_world.translation.z)
print("  >>> 但顶点在 Z=[%.4f, %.4f]（视觉位置）" % (
    min((ob.matrix_world @ v.co).z for v in ob.data.vertices),
    max((ob.matrix_world @ v.co).z for v in ob.data.vertices)))
print("  >>> 位姿与视觉位置分离 %.4f = 跳变的来源" % abs(
    ob.matrix_world.translation.z -
    sum((ob.matrix_world @ v.co).z for v in ob.data.vertices)/len(ob.data.vertices)))
