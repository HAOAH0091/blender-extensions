"""打印 adapt_object 的关键中间量，与手算对照

目标：确认 B 从 1.800 → 1.669 是否符合 PSD 公式，还是哪里错了。
"""
import bpy, sys, os
import importlib.util
import numpy as np
import mathutils

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(zA=0.0, zB=2.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        h = 1.0
        verts = [(x0-h,-h,z0), (x0+h,-h,z0), (x0+h,h,z0), (x0-h,h,z0)]
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], [(0,1,2,3)]); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("A", -1.5, zA)
    B = mk("B", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def wxb(B):
    return float(np.array([list(B.matrix_world @ v.co) for v in B.data.vertices]).mean(axis=0)[0])


sc, cam, cd, A, B = build()
plock.lock_group(sc, cam)

print("=" * 92)
print("基础信息")
print("=" * 92)
vw = plock.get_camera_view_matrix(cam)
print("  get_camera_view_matrix(cam) =")
for r in vw:
    print("    [%9.4f %9.4f %9.4f %9.4f]" % tuple(r))
print("  B.matrix_world =")
for r in B.matrix_world:
    print("    [%9.4f %9.4f %9.4f %9.4f]" % tuple(r))
bB = plock._read_base_attribute(B)
print("  B base = %s" % ([(round(x,4), round(y,4), round(d,4)) for (x,y,d) in bB],))
print("  B 世界 x = %+.6f" % wxb(B))

cam.location.x = 1.2
step(sc)
st = plock.get_state(sc, cam)
print("\n  移到 1.2： B 世界 x = %+.6f  ref=%.4f" % (wxb(B), st.get("ref_depth", 0)))

A.location.z += 1.5
step(sc)
print("  拖 A +1.5： B 世界 x = %+.6f（应不变）" % wxb(B))

# 手动复算 B 的期望位置（用与 adapt_object 相同的公式）
def expect_B(cam, st, B, tag):
    ref = float(st.get("ref_depth", 0))
    vw_now = plock.get_camera_view_matrix(cam)
    vw_lock = plock._safe_view_matrix(st.get("locked_matrix"))
    focal_lock = float(st.get("locked_focal", 0)) or 1e-4
    zoom = max(cam.data.lens / focal_lock, 1e-4)
    eye_now = vw_now.translation
    applied = plock._state_applied_dolly(cam, st)
    eye_user = eye_now - applied
    cur_rot = vw_now.to_3x3()
    eye_delta = eye_user - vw_lock.translation
    delta_cs = cur_rot.transposed() @ eye_delta
    axis0 = vw_lock.to_3x3() @ mathutils.Vector((0,0,-1))
    axial = eye_delta.dot(axis0)
    dolly = max((ref - axial)/ref, 1e-4) if ref > 1e-4 else 1.0

    base = plock._read_base_attribute(B)
    x0, y0, d = base[0]
    off = plock._safe_float(B.get(plock.DRAG_OFFSET_KEY, 0.0), 0.0)
    dd = d + off
    k_i = dd / d
    xd = x0 * k_i
    kk = dd / ref if ref > 1e-4 else 1.0
    depth = max(dd * dolly * zoom, 1e-4)
    cx = xd - delta_cs.x * kk * plock.SCROLL_SCALE
    cy = y0 * k_i - delta_cs.y * kk * plock.SCROLL_SCALE
    _M = B.matrix_world.inverted() @ vw_now
    world = _M @ mathutils.Vector((cx, cy, -depth))
    print("\n  【%s】手算中间量：" % tag)
    print("    ref=%.4f  zoom=%.4f  dolly=%.6f  axial=%.4f" % (ref, zoom, dolly, axial))
    print("    delta_cs=(%+.4f, %+.4f, %+.4f)  eye_delta=(%+.4f,%+.4f,%+.4f)"
          % (delta_cs.x, delta_cs.y, delta_cs.z,
             eye_delta.x, eye_delta.y, eye_delta.z))
    print("    base(x0,y0,d)=(%+.4f,%+.4f,%.4f)  off=%+.4f  dd=%.4f  k_i=%.4f"
          % (x0, y0, d, off, dd, k_i))
    print("    kk=%.6f  depth=%.4f" % (kk, depth))
    print("    cam 空间 x = %+.6f  ⇒  世界 x = %+.6f" % (cx, world.x))
    print("    世界位移 = Δ(1-kk) = 1.0 × (1-%.6f) = %+.6f" % (kk, 1.0 - kk))
    return world.x

# 复算「移到 2.2」的情形
w_before = wxb(B)
cam.location.x = 2.2
step(sc)
w_after = wxb(B)
st2 = plock.get_state(sc, cam)
print("\n  移到 2.2： B 世界 x = %+.6f   ref=%.4f" % (w_after, st2.get("ref_depth", 0)))
print("  B 实际位移 = %+.6f" % (w_after - w_before))
ex = expect_B(cam, st2, B, "ref=%.2f 时手算 B" % st2.get("ref_depth", 0))
print("  手算 vs 实测： %+.6f vs %+.6f   差 %.8f" % (ex, w_after, abs(ex - w_after)))
print("F5_DONE")
