"""插桩：相机在网格平面上解锁时，S=0.0001 是从哪来的？
逐层打印 fit_delta_params 的输入 / 输出。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(tilt=False):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    ns = 3; h = 2.0
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -h + 2*h*ix/ns
            y = -h + 2*h*iy/ns
            z = (0.5 * x) if tilt else 0.0     # 倾斜：x 越大越靠近相机
            verts.append((x, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


# 包一层 fit_delta_params 观察输入输出
_orig_fit = plock.fit_delta_params
_log = []


def _spy(fp, lp, ratio):
    r = _orig_fit(fp, lp, ratio)
    _log.append((len(fp), ratio, r))
    return r


plock.fit_delta_params = _spy

_orig_write = plock.write_delta_params
_wlog = []


def _spy_w(name, s, c):
    _wlog.append((name, s, c))
    return _orig_write(name, s, c)


plock.write_delta_params = _spy_w


def show_nodes(cd, tag):
    nodes = plock._find_delta_nodes(cd.name)
    if nodes:
        S = nodes[0].inputs["Scale"].default_value
        C = list(nodes[1].inputs[1].default_value)[:2]
        print("     %-12s 组内 S=%.8f C=(%.8f, %.8f)" % (tag, S, C[0], C[1]))


print("=" * 84)
print("场景 1：平面网格，相机停在网格平面(z=0)上解锁")
print("=" * 84)
sc, cam, cd, ob = build(tilt=False)
plock.lock_group(sc, cam)
show_nodes(cd, "锁定后")
cam.location.z = 0.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
show_nodes(cd, "移到位后")
_log.clear(); _wlog.clear()
r = plock.unlock_group(sc, cam)
print("   消息:", str(r.get("message", ""))[:100])
print("   fit_delta_params 调用:", _log)
print("   write_delta_params 调用:", _wlog)
show_nodes(cd, "解锁后")

print()
print("=" * 84)
print("场景 2：倾斜网格，相机部分穿过（部分顶点在背后）")
print("=" * 84)
sc, cam, cd, ob = build(tilt=True)
print("   网格世界 z 范围: %.2f ~ %.2f" % (
    min(v.co.z for v in ob.data.vertices), max(v.co.z for v in ob.data.vertices)))
plock.lock_group(sc, cam)
show_nodes(cd, "锁定后")
# 相机推进到 z=1：倾斜网格 z∈[-1,1]，部分顶点会到相机背后
cam.location.z = 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
show_nodes(cd, "移到位后")
_log.clear(); _wlog.clear()
r = plock.unlock_group(sc, cam)
print("   消息:", str(r.get("message", ""))[:100])
print("   fit_delta_params 调用:", _log)
print("   write_delta_params 调用:", _wlog)
show_nodes(cd, "解锁后")

print()
print("=" * 84)
print("场景 3：健康对照（相机不动，正常解锁）")
print("=" * 84)
sc, cam, cd, ob = build(tilt=False)
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
_log.clear(); _wlog.clear()
r = plock.unlock_group(sc, cam)
print("   fit_delta_params 调用:", _log)
print("   write_delta_params 调用:", _wlog)
show_nodes(cd, "解锁后")

plock.fit_delta_params = _orig_fit
plock.write_delta_params = _orig_write
print("\nSPY_DONE")
