"""审查E-1：50 / 200 / 1000 个网格同时锁定 —— 锁定耗时 & 每帧 handler 开销

判据只用 time.perf_counter 实测，不猜。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

# ── 插桩：数每一帧里各函数的调用次数 ──────────────────────────────
CNT = {"full": 0, "cached": 0, "sig": 0}
_o_full = plock.objects_using_projection
_o_cached = plock.objects_using_projection_cached
_o_sig = plock._proj_signature


def full(*a, **k):
    CNT["full"] += 1
    return _o_full(*a, **k)


def cached(*a, **k):
    CNT["cached"] += 1
    return _o_cached(*a, **k)


def sig(*a, **k):
    CNT["sig"] += 1
    return _o_sig(*a, **k)


plock.objects_using_projection = full
plock.objects_using_projection_cached = cached
plock._proj_signature = sig


def build(nmesh):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 12)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("ProjMat")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    ns = 2
    H = 0.5
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    # 铺成网格状排布，避免互相重叠
    cols = max(1, int(nmesh ** 0.5))
    for i in range(nmesh):
        mesh = bpy.data.meshes.new("G%d" % i)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new("Grid%d" % i, mesh)
        sc.collection.objects.link(ob)
        ob.location = ((i % cols) * 1.2 - cols * 0.6, (i // cols) * 1.2 - cols * 0.6, 0.0)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd


def reset_counters():
    CNT["full"] = CNT["cached"] = CNT["sig"] = 0


print("%-6s %-12s %-14s %-12s %-14s %-26s" % (
    "N", "lock_ms", "帧均(动)_ms", "帧最大_ms", "帧均(静)_ms", "每帧调用 full/cached/sig"))
for nmesh in (50, 200, 1000):
    sc, cam, cd = build(nmesh)
    plock._proj_cache.clear()
    plock._base_cache.clear()
    plock._last_view.clear()

    reset_counters()
    t0 = time.perf_counter()
    res = plock.lock_group(sc, cam)
    t_lock = (time.perf_counter() - t0) * 1000.0

    # 动相机 24 帧
    reset_counters()
    ts = []
    for f in range(24):
        cam.location.x += 0.02
        bpy.context.view_layer.update()
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)
        ts.append((time.perf_counter() - t0) * 1000.0)
    call_move = (CNT["full"], CNT["cached"], CNT["sig"])

    # 静止 24 帧（相机不动 = 真实闲置）
    reset_counters()
    ts_idle = []
    for f in range(24):
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)
        ts_idle.append((time.perf_counter() - t0) * 1000.0)
    call_idle = (CNT["full"], CNT["cached"], CNT["sig"])

    print("%-6d %-12.1f %-14.2f %-12.2f %-14.2f %s" % (
        nmesh, t_lock, sum(ts) / len(ts), max(ts), sum(ts_idle) / len(ts_idle),
        "动 %s / 静 %s" % (call_move, call_idle)))

print("\n[锁定结果] locked=%d frozen=%s" % (len(res.get("locked", [])), res.get("frozen")))
