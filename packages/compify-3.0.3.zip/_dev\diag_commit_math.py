"""数值调试：commit 前后 冻结UV vs 实时UV"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0.0, 0.0, 5.0); cam.rotation_euler = (0.0, 0.0, 0.0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

mesh = bpy.data.meshes.new("Grid")
ns = 2
verts, faces = [], []
for iy in range(ns+1):
    for ix in range(ns+1):
        verts.append((-2.0+4.0*ix/ns, -2.0+4.0*iy/ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy*(ns+1)+ix
        faces.append((a, a+1, a+ns+2, a+ns+1))
mesh.from_pydata(verts, [], faces); mesh.update()
ob = bpy.data.objects.new("Grid", mesh)
sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.context.view_layer.update()


def frozen_uv():
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    out = []
    for i in range(len(a.data)):
        x, y, z = a.data[i].vector
        out.append((x/z, y/z))
    return np.array(out)


def live_uv():
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


print(plock.lock_group(sc, cam).get("message"))
print("锁定时 frozen vs live 差:", np.abs(frozen_uv()-live_uv()).max())

cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
fu, lv = frozen_uv(), live_uv()
print("移相机后 frozen[0]=", np.round(fu[0],5), " live[0]=", np.round(lv[0],5))
print("  差:", np.abs(fu-lv).max())

world_before = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
print("commit 前顶点世界 x:", np.round(world_before[:,0],4))

ok = plock.commit_frozen_pattern(ob, cam, cd.name)
bpy.context.view_layer.update()
print("commit 返回:", ok)
world_after = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
print("commit 后顶点世界 x:", np.round(world_after[:,0],4))
print("commit 后 live[0]=", np.round(live_uv()[0],5), " frozen[0]=", np.round(frozen_uv()[0],5))
print("  实时 vs 冻结 差:", np.abs(live_uv()-frozen_uv()).max())

# 再看 Z（深度）
m = cam.matrix_world.inverted()
zs_now = np.array([(m @ (ob.matrix_world @ v.co)).z for v in ob.data.vertices])
print("commit 后相机空间 z:", np.round(zs_now,4))
a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
zs_f = np.array([a.data[i].vector[2] for i in range(len(a.data))])
print("frozen 相机空间 z:", np.round(zs_f,4))
