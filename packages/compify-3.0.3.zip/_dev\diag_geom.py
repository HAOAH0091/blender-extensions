"""确认 C 方案（位姿跟手）是否把网格几何拉变形
判据：边长变化率。物体在画面里应该"整体变大"，但自身比例不能变。
用 正方形网格 4 条外边长度 + 对角对比。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_geom"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]
from mathutils import Vector


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("M"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    mesh = bpy.data.meshes.new("G")
    verts = [(-1,-1,0),(1,-1,0),(1,1,0),(-1,1,0)]
    mesh.from_pydata(verts, [], [(0,1,2,3)]); mesh.update()
    obj = bpy.data.objects.new("GridA", mesh)
    scene.collection.objects.link(obj)
    obj.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    return scene, cam, cd, obj


def world_edges(obj):
    vs = [obj.matrix_world @ v.co for v in obj.data.vertices]
    return [ (vs[0]-vs[1]).length, (vs[1]-vs[2]).length,
             (vs[2]-vs[3]).length, (vs[3]-vs[0]).length ]


def apply_user_move_psdstyle(obj, camera, view_now):
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    M_lock = PL._read_matrix_key(obj)
    if M_lock is None:
        return False
    M_cur = obj.matrix_world.copy()
    view_inv = view_now.inverted()
    c_local = PL._mesh_center_local(obj)
    d_lock = PL._view_depth(view_inv, M_lock @ c_local)
    d_cur = PL._view_depth(view_inv, M_cur @ c_local)
    if d_lock <= PL.MIN_DEPTH or d_cur <= PL.MIN_DEPTH:
        return False
    k = d_cur / d_lock
    obj[PL.DRAG_SCALE_KEY] = float(k)
    axis_w = view_now.to_3x3() @ Vector((0.0, 0.0, -1.0))
    M_new = M_lock.copy()
    M_new.translation = M_lock.translation + axis_w * (d_lock - d_cur)
    obj.matrix_world = M_new
    bpy.context.view_layer.update()
    return True


for label, fn, follow in [("A 现状", PL.apply_user_move, False),
                          ("B 只修累乘", PL.apply_user_move, False),
                          ("C 位姿跟手", apply_user_move_psdstyle, True)]:
    scene, cam, cd, obj = build()
    PL.lock_group(scene, cam)
    M_lock = obj.matrix_world.copy()
    e0 = world_edges(obj)
    c_local = PL._mesh_center_local(obj)
    view = PL.get_camera_view_matrix(cam)
    d_lock = PL._view_depth(view.inverted(), M_lock @ c_local)
    axis_w = view.to_3x3() @ Vector((0, 0, -1))

    # 拖到靠近相机 0.5（10 帧累积）
    Mtmp = M_lock.copy()
    Mtmp.translation = M_lock.translation + axis_w * 0.5
    obj.matrix_world = Mtmp
    bpy.context.view_layer.update()
    vn = PL.get_camera_view_matrix(cam)
    fn(obj, cam, vn)

    e1 = world_edges(obj)
    pose_d = (obj.matrix_world.translation - M_lock.translation).length
    mesh_ratio = [e1[i]/e0[i] for i in range(4)]
    print("\n--- %s ---" % label)
    print("  拖动 0.5 后:")
    print("    位姿位移          %.4f" % pose_d)
    print("    边长 (拖前)        %s" % [round(x,4) for x in e0])
    print("    边长 (拖后)        %s" % [round(x,4) for x in e1])
    print("    各边缩放比         %s" % [round(x,4) for x in mesh_ratio])
    print("    >>> 几何是否为相似变换(4边同比例): %s" %
          ("是" if max(mesh_ratio)-min(mesh_ratio) < 1e-4 else "否=被拉变形"))
    print("    >>> 整体缩放率      %.4f  (期望 ≈ d_lock/d_cur = %.4f)" %
          (sum(mesh_ratio)/4, d_lock/(d_lock-0.5)))
