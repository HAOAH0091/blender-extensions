"""验证：用户拖动锁定网格 → 按视差语义重新锚定（对齐 PSD「拖图层」）。

验证项：
  1. 沿视线拖动 ⇒ 深度改变，但【屏幕坐标不变】（网格钉在画面原位）
  2. 纯横向拖动 ⇒ 被拉回原位（锁定语义：画面里拖不动）
  3. 顶点按【各自的视线】移动（各顶点位移不同 = 非刚性 = 按视锥体变形）
  4. 投影 UV 不变（图案不滑动）
  5. 位姿写回基准 ⇒ 之后一动相机【不会弹回】
  6. 深度变了 ⇒ 之后移相机时该网格的视差滚动确实不同（= 调了"间距"）
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(PKG, os.path.join(D, "__init__.py"),
                                              submodule_search_locations=[D])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-50s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("C")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("C", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, -6.0, 0.0)
    cam.rotation_euler = (math.radians(90), 0, 0)
    sc.camera = cam
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup")
    g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    objs = []
    for i, (x, depth) in enumerate([(-4.0, 10.0), (0.0, 16.0), (4.0, 22.0)]):
        bpy.ops.mesh.primitive_monkey_add(size=2.0, location=(x, -6.0 + depth, 0.0))
        ob = bpy.context.active_object
        ob.name = "MK%d" % i
        ob.rotation_euler = (math.radians(90), 0, 0)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
        objs.append(ob)
    bpy.context.view_layer.update()
    return sc, cam, objs


def view_of(st):
    return mathutils_matrix(st)


def mathutils_matrix(st):
    import mathutils
    return mathutils.Matrix([mathutils.Vector(r) for r in st["locked_matrix"]])


def center_world(obj):
    import mathutils
    n = len(obj.data.vertices)
    buf = [0.0] * (n * 3)
    obj.data.vertices.foreach_get("co", buf)
    c = mathutils.Vector((sum(buf[0::3]) / n, sum(buf[1::3]) / n, sum(buf[2::3]) / n))
    return obj.matrix_world @ c


def screen_norm(obj, view_inv):
    """归一化屏幕坐标（x/d, y/d）——锁定语义的核心判据。"""
    cs = view_inv @ center_world(obj)
    d = -cs.z
    return (cs.x / d, cs.y / d), d


def screen_norm_verts(obj, view_inv):
    """逐顶点归一化屏幕坐标。
    ⚠️ 不能用形心：逐顶点（非刚性）变形下形心不是不动点 ——
       mean(x_i·k_i)/mean(d_i) ≠ mean(x_i)/mean(d_i)。
       旧实现「形心不变」只是全局比例造成的假象（所有顶点同比例，分子分母同消）。
       锁定语义真正要保的是**每个顶点**的屏幕坐标不变。
    """
    out = []
    for v in obj.data.vertices:
        cs = view_inv @ (obj.matrix_world @ v.co)
        d = -cs.z
        out.append((cs.x / d, cs.y / d) if abs(d) > 1e-9 else (0.0, 0.0))
    return out


def proj_uvs_live(obj, cam):
    """按投影组【当前】会读到的东西算 UV：
       组已 patch 且属性在 → 用冻结坐标（图案钉住）
       否则 → 用实时相机空间坐标（实时投影）
    """
    patched = plock.is_patched(cam.data.name)
    if patched:
        a = obj.data.attributes.get(plock._campos_attr_name(cam.data.name))
        if a is not None and len(a.data) == len(obj.data.vertices):
            n = len(a.data); buf = [0.0] * (n * 3)
            a.data.foreach_get("vector", buf)
            src = [(buf[i], buf[i+1], buf[i+2]) for i in range(0, n*3, 3)]
        else:
            src = [(0.0, 0.0, -1.0)] * len(obj.data.vertices)
    else:
        vi = plock.get_camera_view_matrix(cam).inverted()
        src = []
        for v in obj.data.vertices:
            cs = vi @ (obj.matrix_world @ v.co)
            src.append((cs.x, cs.y, cs.z))
    out = []
    for (x, y, z) in src:
        # ⚠️ 必须用着色器同一套符号约定：投影组算的是 x/z、y/z，而相机空间
        #   z 在相机前方是【负】的。以前这里写 `d = -z` 把符号翻了一次 ——
        #   冻结侧和实时侧都翻，差值能抵消，但「解锁落实」的 delta 是按
        #   着色器约定算的，加进来就符号相反（实测 UV 差 0.13~0.27，看着像跳变）。
        d = z
        out.append((x/d, y/d) if abs(d) > 1e-9 else (0.0, 0.0))
    # ★ 未 patch 时投影组还要做「解锁落实」：UV = persp·S + C（方案 D）。
    #   S/C 是组里的普通数值节点，任何网格共享同一份（不再有逐顶点属性）。
    #   不加会把「解锁后」误算成纯实时 => 与再锁定后的冻结值差出偏移，
    #   看起来像"跳变"，其实只是这个辅助函数漏算了一项。
    if not patched:
        nodes = plock._find_delta_nodes(cam.data.name)
        if nodes is not None:
            S = nodes[0].inputs["Scale"].default_value
            C = list(nodes[1].inputs[1].default_value)[:2]
            out = [(u * S + C[0], v * S + C[1]) for (u, v) in out]
    return out


def proj_uvs(obj, cam_data_name, lens, sensor_w):
    """投影 UV（用冻结坐标属性手算）——图案是否滑动看它。"""
    attr = obj.data.attributes.get(plock._campos_attr_name(cam_data_name))
    if attr is None:
        return None
    n = len(attr.data)
    buf = [0.0] * (n * 3)
    attr.data.foreach_get("vector", buf)
    out = []
    for i in range(0, n * 3, 3):
        x, y, z = buf[i], buf[i + 1], buf[i + 2]
        d = -z
        if abs(d) < 1e-9:
            out.append((0.0, 0.0))
        else:
            out.append((x / d * (lens / sensor_w), y / d * (lens / sensor_w)))
    return out


# ══ 场景 A：沿视线拖动 ══
print("=" * 64)
print("A) 沿【视线】拖动 MK0（推远 4 单位）")
sc, cam, objs = build()
r = plock.lock_group(sc, cam)
chk("锁定成功", r["success"], r["message"][:38])
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
view_inv = view.inverted()
target = objs[0]

s0, d0 = screen_norm(target, view_inv)
sv0 = screen_norm_verts(target, view_inv)     # ★ 逐顶点基准（① 的判据）
uv0 = proj_uvs(target, cam.data.name, cam.data.lens, cam.data.sensor_width)
w0 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
_cb = target.data.attributes.get(plock._campos_attr_name(cam.data.name))
campos_before = [0.0] * (len(_cb.data) * 3)
_cb.data.foreach_get("vector", campos_before)

# 沿光轴推远
axis = view.to_3x3() @ __import__("mathutils").Vector((0.0, 0.0, -1.0))
target.location = target.location + axis * 4.0
bpy.context.view_layer.update()
w_user = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
print("   用户拖动：顶点0 世界 =", tuple(round(v, 3) for v in w_user[0]))

plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

s1, d1 = screen_norm(target, view_inv)
uv1 = proj_uvs(target, cam.data.name, cam.data.lens, cam.data.sensor_width)
w1 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]

print("   屏幕坐标 %.5f,%.5f → %.5f,%.5f" % (s0[0], s0[1], s1[0], s1[1]))
print("   形心深度 %.3f → %.3f   (k=%.4f)" % (d0, d1, d1 / d0))
# ★ 判据改用【逐顶点】（2026-10-19 逐顶点语义变更）：
#   非刚性变形下形心会自然微动（实测 2e-4），那不是缺陷；
#   真正要保的是每个顶点的屏幕坐标不变。
sv1 = screen_norm_verts(target, view_inv)
d_sv = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(sv0, sv1))
chk("① 每个顶点的屏幕坐标不变（钉在画面原位）", d_sv < 1e-5, "Δ=%.2e" % d_sv)
print("   （形心屏幕 Δ=%.2e —— 形心不是刚体点，逐顶点变形下本就会微动）"
      % max(abs(s1[0] - s0[0]), abs(s1[1] - s0[1])))
chk("① 深度确实变了（推远了）", d1 > d0 + 1.0, "%.3f → %.3f" % (d0, d1))

# 非刚性：各顶点位移不同
import mathutils
disp = [mathutils.Vector(w1[i]) - mathutils.Vector(w0[i]) for i in range(len(w0))]
mags = [d.length for d in disp]
chk("③ 各顶点位移【不同】（非刚性 = 按视锥体变形）",
    max(mags) - min(mags) > 1e-3,
    "位移范围 %.4f ~ %.4f" % (min(mags), max(mags)))

# 投影 UV 不变（★ 修复后：冻结坐标属性**完全不被动过**）
campos_after = None
_a = target.data.attributes.get(plock._campos_attr_name(cam.data.name))
if _a:
    _n = len(_a.data); campos_after = [0.0] * (_n * 3)
    _a.data.foreach_get("vector", campos_after)
if uv0 and uv1:
    e = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(uv0, uv1))
    chk("④ 投影 UV 不变（图案不滑动）", e < 1e-5, "max=%.2e" % e)
else:
    chk("④ 投影 UV 不变（图案不滑动）", False, "属性缺失")
chk("④b 冻结坐标属性值与锁定时刻完全一致",
    campos_after is not None and campos_before is not None and
    campos_after == campos_before,
    "（网格变形不应改动 UV）")
# ★ 2026-10-19 逐顶点语义：记录的是【深度平移量】offset，不再是比例 drag。
#   期望 offset = 形心深度变化 = d1 - d0（拖动是纯视线平移）。
_off = float(target.get(plock.DRAG_OFFSET_KEY, 0.0))
chk("④c 记录了深度平移量 offset（O(1) 方案）",
    abs(_off - (d1 - d0)) < 1e-4,
    "offset=%.5f  期望(形心深度变化)=%.5f" % (_off, d1 - d0))

# 写回基准：再动相机不应弹回
cam.location.x += 1.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s2, d2 = screen_norm(target, view_inv)
chk("⑤ 之后动相机：网格不再弹回原深度", abs(d2 - d1) < 1e-3,
    "深度 %.3f → %.3f" % (d1, d2))

# ══ 场景 B：横向拖动应被拉回 ══
print()
print("=" * 64)
print("B) 纯【横向】拖动 MK0（+3 单位）→ 应被拉回原位")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
view_inv = view.inverted()
target = objs[0]
w0 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
target.location.x += 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
w1 = [tuple(target.matrix_world @ v.co) for v in target.data.vertices]
import mathutils as mu
err = max((mu.Vector(w1[i]) - mu.Vector(w0[i])).length for i in range(len(w0)))
chk("② 横向拖动被拉回（网格回原位）", err < 1e-4, "max_err=%.2e" % err)

# ══ 场景 C：深度变了 ⇒ 之后移相机的视差不同 ══
print()
print("=" * 64)
print("C) 深度改变后，该网格的视差滚动应与「没拖动」时不同")


def scroll_after_unlock(do_drag):
    """解锁后的视差：世界坐标固定，相机横移 → 屏幕位移 ∝ 1/深度。

    ⚠️ 为什么不能在「锁定态」量这个：锁定态各网格**严格同步滚动**（那正是
    "构图冻结"的定义），深度不参与滚动量 ⇒ 量不出差异。深度改变的效果
    要在【解锁后】的自由视差里才看得到。
    """
    sc, cam, objs = build()
    plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    view = mathutils_matrix(st)
    tgt = objs[0]
    if do_drag:
        axis = view.to_3x3() @ mu.Vector((0.0, 0.0, -1.0))
        tgt.location = tgt.location + axis * 4.0
        bpy.context.view_layer.update()
        plock.parallax_lock_update_handler(sc)
        bpy.context.view_layer.update()
    plock.unlock_group(sc, cam)          # 解锁 → 网格世界坐标固定，恢复自然视差
    bpy.context.view_layer.update()
    v0 = plock.get_camera_view_matrix(cam)
    cs0 = v0.inverted() @ center_world(tgt)
    s0 = cs0.x / -cs0.z
    cam.location.x += 1.0
    bpy.context.view_layer.update()
    v1 = plock.get_camera_view_matrix(cam)
    cs1 = v1.inverted() @ center_world(tgt)
    s1 = cs1.x / -cs1.z
    d = -cs0.z
    return s0, s1, d


s0a, s1a, da = scroll_after_unlock(False)
s0b, s1b, db = scroll_after_unlock(True)
print("   未拖动：深度 %.3f  屏 %.5f → %.5f  (视差位移 %.5f)"
      % (da, s0a, s1a, s1a - s0a))
print("   已拖动：深度 %.3f  屏 %.5f → %.5f  (视差位移 %.5f)"
      % (db, s0b, s1b, s1b - s0b))
chk("⑥ 拖动后深度变了 ⇒ 解锁后的视差位移不同（= 调了'间距'）",
    abs((s1a - s0a) - (s1b - s0b)) > 1e-3,
    "差 %.5f" % abs((s1a - s0a) - (s1b - s0b)))

# ══ D) 性能：拖动过程不应遍历顶点 ══
print()
print("=" * 64)
print("D) 性能：拖动时不遍历顶点（O(1)）")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
MU = importlib.import_module("mathutils")
axis = view.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
tgt = objs[0]
# ★ 2026-10-19：位姿→深度的换算改用 `_orig_center_local`（原始形心），
#   不再用 `_mesh_center_local`（当前顶点形心）—— 后者会被 adapt_object 的
#   顶点变形污染，导致拖动被锁死在相机前（详见 ORIG_CENTER_KEY 说明）。
#   性能契约不变：拖动路径仍然**不遍历顶点**。判据改成两条：
#     ① `_orig_center_local` 走缓存（ORIG_CENTER_KEY 在 lock 时就写好了）
#     ② 完全不调用 `_mesh_center_local`（= 一次顶点遍历都没有）
_cnt = {"call": 0, "miss": 0}
_cnt2 = {"call": 0}
_oc = plock._orig_center_local
_oc2 = plock._mesh_center_local


def _cc(o):
    _cnt["call"] += 1
    if o.get(plock.ORIG_CENTER_KEY) is None:
        _cnt["miss"] += 1
    return _oc(o)


def _cc2(o):
    _cnt2["call"] += 1
    return _oc2(o)


plock._orig_center_local = _cc
plock._mesh_center_local = _cc2
tgt.location = tgt.location + axis * 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
plock._orig_center_local = _oc
plock._mesh_center_local = _oc2
print("   原始形心调用 %d 次，未命中缓存 %d 次；当前顶点形心（=要遍历顶点）调用 %d 次"
      % (_cnt["call"], _cnt["miss"], _cnt2["call"]))
chk("拖动时形心走缓存、不遍历顶点",
    _cnt["call"] > 0 and _cnt["miss"] == 0 and _cnt2["call"] == 0,
    "原始形心 %d/%d 命中缓存；顶点遍历 %d 次"
    % (_cnt["call"] - _cnt["miss"], _cnt["call"], _cnt2["call"]))

# ══ E) 模拟 depsgraph 重入：拖动缩放不得被反复累乘 ══
print()
print("=" * 64)
print("E) 模拟 depsgraph 连锁重入")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
axis = view.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
tgt = objs[0]
_re = []
_ow = plock._write_matrix_key


def _rw(obj, M):
    r = _ow(obj, M)
    if len(_re) < 3:
        _re.append(obj.name)
        plock.parallax_lock_update_handler(sc)     # 模拟 depsgraph 连锁重入
    return r


plock._write_matrix_key = _rw
tgt.location = tgt.location + axis * 4.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
plock._write_matrix_key = _ow
# ★ 2026-10-19：改记【深度平移量 offset】。拖动 4 单位沿视线 ⇒ offset ≈ 4。
#   重入若把 offset 累加多次，会变成 ~8、~12；这里断言它仍是单次的量。
ds = float(tgt.get(plock.DRAG_OFFSET_KEY, 0.0))
print("   重入 %d 次后 offset = %.5f（单次应为 ~4.0）" % (len(_re), ds))
chk("重入不累积（offset 只记一次，未被打成 2 倍、3 倍）",
    3.0 < ds < 5.0, "offset=%.5f" % ds)

# ══ F) 拖动后动相机：所有对象仍在画面合理位置（不消失）══
print()
print("=" * 64)
print("F) 拖动 + 动相机后，所有对象位置合理（不消失）")
sc, cam, objs = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
view = mathutils_matrix(st)
axis = view.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
objs[0].location = objs[0].location + axis * 5.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
for _ in range(3):                     # 多次连锁（模拟 GUI）
    cam.location.x += 0.5
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
ok = True
detail = []
for ob in objs:
    cs = plock.get_camera_view_matrix(cam).inverted() @ center_world(ob)
    depth = -cs.z
    inside = depth > 0.1 and abs(cs.x / depth) < 20 and abs(cs.y / depth) < 20
    ok = ok and inside
    detail.append("%s d=%.1f" % (ob.name, depth))
chk("拖动 + 动相机后所有对象仍在相机前方、画面附近", ok, " | ".join(detail))

# ══ G) 重新锁定不得让投影 UV 跳变 ══


def frozen_lens(camname):
    """投影组里【冻结】的 lens 值（决定图案外观；与 state.locked_focal 不同）。"""
    g = bpy.data.node_groups.get("Camera Project | " + camname)
    for n in g.nodes:
        if n.type == "VALUE" and n.label == "Lens":
            return n.outputs["Value"].default_value
    return None


print()
print("=" * 64)
print("G) 锁定 → 移相机 → 解锁 → 再锁定：投射效果与不跳变")
# ★ 2026-10-19 语义变更：解锁现在会撤掉投影补丁、投影回到实时链路。
#   因此「再锁定后 UV == 最初锁定值」不再成立（也不该成立）——
#   解锁期间相机移动过，实时投影本来就该按新视角变化；再锁定采集的是**新视角**。
#   正确契约变成两条：
#     G1 解锁→再锁定之间 UV 连续（不跳变）
#     G2 解锁后投影确实随相机实时变化（= 用户报的「投射效果消失」已修复）
sc, cam, objs = build()
plock.lock_group(sc, cam)
tgt = objs[0]
uv_lock = proj_uvs_live(tgt, cam)
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
uv_still_locked = proj_uvs_live(tgt, cam)      # 锁定中：仍冻结
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
uv_unlock = proj_uvs_live(tgt, cam)            # 解锁瞬间：应==冻结（不跳）
cam.location.x += 1.0                          # 解锁后【再】移相机
bpy.context.view_layer.update()
uv_unlock_moved = proj_uvs_live(tgt, cam)      # 应随相机变化（= 图案滑动）
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
uv_relock = proj_uvs_live(tgt, cam)            # 再锁定：冻结当前构图


def _d(u, v):
    return max(max(abs(a[0]-b[0]), abs(a[1]-b[1])) for a, b in zip(u, v))


d_frozen = _d(uv_lock, uv_still_locked)
d_unlock = _d(uv_unlock, uv_still_locked)
d_slide = _d(uv_unlock_moved, uv_unlock)
e1 = _d(uv_unlock_moved, uv_relock)
print("   锁定中移相机 UV 变化 %.2e（应≈0：图案粘住网格）" % d_frozen)
print("   解锁瞬间相对冻结态 UV 变化 %.2e（应≈0：不跳）" % d_unlock)
print("   解锁后再移相机 UV 变化 %.2e（应>0：图案滑动）" % d_slide)
print("   解锁→再锁定 UV 差 %.2e（应≈0：不跳变）" % e1)
chk("G0 锁定中图案冻结（移相机 UV 不变）", d_frozen < 1e-6, "Δ=%.2e" % d_frozen)
# ★ 2026-10-19 再次修正契约（用户报「解锁后贴图跳变回原始视图内构图」）：
#   解锁现在会「落实构图」—— 逐顶点 UV 偏移使实时投影恰好等于冻结图案。
#   所以「解锁瞬间 UV == 冻结值」（不跳），而「投射效果」体现在解锁**之后**
#   移相机时 UV 随之变化。两条分开测。
chk("G2 解锁瞬间不跳（实时+delta == 冻结图案）", d_unlock < 1e-6, "Δ=%.2e" % d_unlock)
chk("G2b 解锁后再移相机图案滑动（有投射效果）", d_slide > 1e-3, "Δ=%.2e" % d_slide)
chk("G1 解锁→再锁定不改变投影 UV（不跳变）", e1 < 1e-6, "Δ=%.2e" % e1)

# G3：锁定 → 变焦（相机推拉）→ 解锁 → 再锁定，同样不得跳变
# ★ 新语义：变焦 → 解锁后投影按 85 实时投射 → 再锁定冻结 85。
#   所以「解锁→再锁定」仍然不跳变（中间无人动相机/焦距）。
sc, cam, objs = build()
plock.lock_group(sc, cam)
tgt = objs[0]
cam.data.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
uv_z = proj_uvs_live(tgt, cam)
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
uv_z2 = proj_uvs_live(tgt, cam)
e2 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(uv_z, uv_z2))
fl = frozen_lens(cam.data.name)
print("   变焦后 冻结lens=%s 相机lens=%.1f" % (("N/A(未patch)" if fl is None else "%.1f" % fl), cam.data.lens))
chk("G3 变焦后重新锁定也不跳变", e2 < 1e-6, "Δ=%.2e" % e2)

# ══ H) 相机移动/旋转后，拖动约束要按【当前】相机 ══
print()
print("=" * 64)
print("H) 移动+旋转相机后再拖动：约束按当前相机算")
sc, cam, objs = build()
plock.lock_group(sc, cam)
cam.location.x += 3.0
cam.rotation_euler = (math.radians(90), 0.0, math.radians(25))
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
tgt = objs[0]
view_cur = plock.get_camera_view_matrix(cam)
vinv = view_cur.inverted()
s0, d0 = screen_norm(tgt, vinv)
sv0 = screen_norm_verts(tgt, vinv)     # ★ 逐顶点基准

axis = view_cur.to_3x3() @ MU.Vector((0.0, 0.0, -1.0))
tgt.location = tgt.location + axis * 4.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
s1, d1 = screen_norm(tgt, vinv)
sv1 = screen_norm_verts(tgt, vinv)
off = float(tgt.get(plock.DRAG_OFFSET_KEY, 0.0))
d_sv = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(sv0, sv1))
print("   屏幕形心 (%.5f, %.5f) → (%.5f, %.5f)  深度 %.3f → %.3f  offset=%.5f"
      % (s0[0], s0[1], s1[0], s1[1], d0, d1, off))
# ★ 2026-10-19：① 同款修正 —— 判据改逐顶点（形心在非刚性变形下本就会微动）
chk("H1 沿当前相机光轴拖动：每个顶点屏幕坐标不变",
    d_sv < 1e-5, "Δ=%.2e（形心 Δ=%.2e）" % (d_sv, max(abs(s1[0]-s0[0]), abs(s1[1]-s0[1]))))
# ★ 记录的是深度平移量 offset（不再是比例）。期望 = 形心深度变化。
chk("H2 深度平移量 = 记录的 offset（按当前相机算）",
    abs(off - (d1 - d0)) < 1e-4, "offset=%.5f 期望(形心深度变化)=%.5f" % (off, d1 - d0))

# 横向拖动（相对当前相机）→ 应被拉回
sc, cam, objs = build()
plock.lock_group(sc, cam)
cam.location.x += 3.0
cam.rotation_euler = (math.radians(90), 0.0, math.radians(25))
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
tgt = objs[0]
view_cur = plock.get_camera_view_matrix(cam)
w0 = [tuple(tgt.matrix_world @ v.co) for v in tgt.data.vertices]
right = view_cur.to_3x3() @ MU.Vector((1.0, 0.0, 0.0))
tgt.location = tgt.location + right * 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
w1 = [tuple(tgt.matrix_world @ v.co) for v in tgt.data.vertices]
err = max((MU.Vector(w1[i]) - MU.Vector(w0[i])).length for i in range(len(w0)))
chk("H3 横向拖动（相对当前相机）被拉回原位", err < 1e-4, "max_err=%.2e" % err)

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("USERMOVE_DONE")
