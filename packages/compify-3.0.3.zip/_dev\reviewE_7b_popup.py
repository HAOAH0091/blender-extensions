"""审查E-7：锁定期间「一直不可冻结」的对象 —— 弹窗队列/timer 是否每帧重复注册

注意：`_frozen_ok` 判据下，场景里只要有一个不可冻结网格，**整个相机都不打补丁**，
      于是 `_selfheal_and_backfill` 一进门就 return（is_patched False），队列永远不增长。
      所以真正能触发弹窗的路径是：**先锁定（已打补丁）→ 锁定期间再加入不可冻结网格**。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 12)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

ns, H = 3, 1.0
verts, faces = [], []
for iy in range(ns + 1):
    for ix in range(ns + 1):
        verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy * (ns + 1) + ix
        faces.append((a, a + 1, a + ns + 2, a + ns + 1))
me = bpy.data.meshes.new("OKMesh")
me.from_pydata(verts, [], faces)
me.update()
ok = bpy.data.objects.new("GridOK", me)
sc.collection.objects.link(ok)
ok.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

res = plock.lock_group(sc, cam)
print("锁定: locked=%d is_patched=%s" % (len(res.get("locked", [])), plock.is_patched(cd.name)))

me2 = bpy.data.meshes.new("ModMesh")
me2.from_pydata(verts, [], faces)
me2.update()
bad = bpy.data.objects.new("GridMod", me2)
sc.collection.objects.link(bad)
bad.location = (2.0, 0, 0)
bad.data.materials.append(mat)
bad.modifiers.new("Sub", "SUBSURF")
bpy.context.view_layer.update()

print("\n帧 | _popup_queue | _backfill_warned | timer_on")
for f in range(1, 61):
    plock.parallax_lock_update_handler(sc)
    if f in (1, 2, 3, 6, 12, 30, 60):
        print("%-3d| %-12d | %-16d | %s" % (
            f, len(plock._popup_queue), len(plock._backfill_warned),
            plock._popup_timer_on[0]))
print("_popup_queue = %s" % (plock._popup_queue,))
print("headless: _popup_supported()=%s → 队列永不出队（60 帧后仍 %d 条）" % (
    plock._popup_supported(), len(plock._popup_queue)))

_reg = []


def fake_reg(fn, first_interval=0.0, persistent=False):
    _reg.append(1)
    return None


_orig = bpy.app.timers.register
bpy.app.timers.register = fake_reg
plock._popup_supported = lambda: True
plock._popup_timer_on[0] = False
plock._popup_shown.clear()
plock._popup_queue.clear()
plock._backfill_warned.clear()
for f in range(60):
    plock.parallax_lock_update_handler(sc)
print("打桩(GUI) 60 帧：timers.register=%d 次, _popup_queue=%d, _popup_shown=%d" % (
    len(_reg), len(plock._popup_queue), len(plock._popup_shown)))
bpy.app.timers.register = _orig
plock._popup_supported = lambda: (not bpy.app.background) and hasattr(bpy.app, "timers")

plock._popup_queue.append(("Ghost", ["修改器"]))
plock._popup_shown.add("Ghost")
plock.unlock_group(sc, cam)
print("解锁后: _popup_queue=%d（已清）, _popup_shown=%d（未清）" % (
    len(plock._popup_queue), len(plock._popup_shown)))
