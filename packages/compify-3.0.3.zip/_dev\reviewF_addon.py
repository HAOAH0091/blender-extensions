"""审查 F-3b/4：**真实** addon_enable / addon_disable / script.reload(F8) 路径下
   handler 是否重复注册、禁用后残留什么、重新启用是否恢复。

做法：把插件 .py 复制到一个临时「用户脚本目录」并命名为 compifytest，
      用 BLENDER_USER_SCRIPTS 指过去（不碰用户真实 Blender 配置），
      然后走 bpy.ops.preferences.addon_enable / addon_disable / script.reload。
"""
import bpy, sys, os, shutil, glob

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(HERE)
UDIR = os.environ.get("BLENDER_USER_SCRIPTS", "")
MOD = "compifytest"
DST = os.path.join(UDIR, "addons", MOD)

print("user scripts:", UDIR)
if os.path.isdir(DST):
    shutil.rmtree(DST)
os.makedirs(DST, exist_ok=True)
for f in glob.glob(os.path.join(SRC, "*.py")):
    shutil.copy2(f, DST)
print("copied %d py files -> %s" % (len(glob.glob(os.path.join(DST, "*.py"))), DST))

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-56s %s" % ("PASS" if c else "FAIL", n, d))


def hs():
    return [f for f in bpy.app.handlers.depsgraph_update_post
            if getattr(f, "__module__", "").startswith(MOD)]


def tmr():
    try:
        p = sys.modules[MOD + ".compify_parallax_lock"]
        return bpy.app.timers.is_registered(p._popup_timer_tick)
    except Exception:
        return None


# 让 Blender 重新扫描脚本路径（否则新目录里的 addon 找不到）
try:
    bpy.utils.refresh_script_paths()
    bpy.ops.preferences.addon_refresh()
except Exception as _e:
    print("refresh 失败:", _e)
print("addons dir 是否在 sys.path: %s" % any(p.endswith("addons") for p in sys.path))

print("=" * 84)
print("### [3-b] 真实 addon_disable → addon_enable（文件未变）")
r = bpy.ops.preferences.addon_enable(module=MOD)
print("  enable ->", r, " handlers =", len(hs()))
chk("启用后 handler = 1", len(hs()) == 1, "count=%d" % len(hs()))
bpy.ops.preferences.addon_disable(module=MOD)
chk("禁用后 handler = 0", len(hs()) == 0, "count=%d" % len(hs()))
bpy.ops.preferences.addon_enable(module=MOD)
chk("再次启用后 handler = 1（不重复）", len(hs()) == 1, "count=%d" % len(hs()))

print("")
print("### [3-c] 插件文件在启用期间被更新（mtime 变化）后再 reload / 重启插件")
plock = sys.modules[MOD + ".compify_parallax_lock"]
fn_before = plock.parallax_lock_update_handler
# 模拟「用户装了新版本」：改 mtime
for f in glob.glob(os.path.join(DST, "*.py")):
    os.utime(f, (os.path.getmtime(f) + 5, os.path.getmtime(f) + 5))
r = bpy.ops.script.reload()          # = 用户按 F8 / 「重新加载脚本」
print("  script.reload ->", r, " handlers =", len(hs()))
chk("F8 重载后 handler = 1", len(hs()) == 1, "count=%d" % len(hs()))
r = bpy.ops.script.reload()
chk("再按一次 F8 后 handler = 1", len(hs()) == 1, "count=%d" % len(hs()))
try:
    plock2 = sys.modules[MOD + ".compify_parallax_lock"]
    print("  模块对象是否被替换: %s" % (plock2 is not plock))
except Exception as e:
    print("  ", e)

print("")
print("### [4] 禁用插件后：网格属性 / 投影组补丁 / 图案冻结 残留情况")
plock = sys.modules[MOD + ".compify_parallax_lock"]
ng = sys.modules[MOD + ".node_groups"]
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = sc.render.resolution_y = 96
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd); sc.collection.objects.link(cam)
cam.location = (0, 0, 5); sc.camera = cam
bpy.context.view_layer.update()
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
o = nt.nodes.new("ShaderNodeOutputMaterial"); e = nt.nodes.new("ShaderNodeEmission")
nt.links.new(g.outputs["Vector"], e.inputs["Color"])
nt.links.new(e.outputs["Emission"], o.inputs["Surface"])
mesh = bpy.data.meshes.new("G0"); mesh.from_pydata(
    [(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)], [], [(0, 1, 2, 3)]); mesh.update()
ob = bpy.data.objects.new("Grid0", mesh); sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.context.view_layer.update()
print("  lock:", plock.lock_group(sc, cam).get("message")[:40])
attrs = [a.name for a in mesh.attributes if a.name.startswith("compify_plock")]
patched = plock.is_patched(cam.data.name)
print("  禁用前：网格属性 %s / is_patched=%s" % (attrs, patched))
bpy.ops.preferences.addon_disable(module=MOD)
attrs2 = [a.name for a in mesh.attributes if a.name.startswith("compify_plock")]
print("  禁用后：网格属性 %s" % attrs2)
print("  禁用后：投影组里 plock 节点 %s" % [n.name for n in grp.nodes if "plock" in n.name.lower()])
print("  禁用后：组内补丁记录仍在 = %s" % (grp.get("compify_plock_patch") is not None))
print("  禁用后：场景里的锁定记录仍在 = %s" % (sc.get("compify_plock_groups") is not None))
chk("禁用后 handler 不再运行", len(hs()) == 0, "count=%d" % len(hs()))
bpy.ops.preferences.addon_enable(module=MOD)
plock3 = sys.modules[MOD + ".compify_parallax_lock"]
print("  重新启用后：handler=%d, 面板状态 enabled=%s"
      % (len(hs()), plock3.get_state(sc, cam).get("enabled")))
plock3.parallax_lock_update_handler(sc)
w = [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]
print("  重新启用后 handler 可跑（无异常），顶点数 %d" % len(w))
chk("重新启用后锁定状态仍在", bool(plock3.get_state(sc, cam).get("enabled")))

print("")
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("RF_ADDON_DONE")
