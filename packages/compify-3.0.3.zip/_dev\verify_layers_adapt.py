"""复刻 PSD 的三层场景，验证「跟着相机走 Δ(1-k)」这一语义

三层放在同一视线上（屏幕 x 相同），深度 8/6/4，ref = 8（最深）。
相机横移 Δ，测每层的【世界位移】和【屏幕位移】。

PSD 公式（parallax_utils.py L780-790）预测：
    世界位移 = Δ · (1 - k)      k = locked_depth / ref_depth
    屏幕位移 = -Δ / ref         （所有层相同 ⇒ 构图保持）
"""
import bpy, sys, os
import importlib.util
import numpy as np
from bpy_extras.object_utils import world_to_camera_view

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

SCREEN_X = 0.15
LAYERS = [("A", 8.0), ("B", 6.0), ("C", 4.0)]   # 深度；ref = 8


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.resolution_x = 960
    sc.render.resolution_y = 540
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 10); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    objs = {}
    for (nm, dep) in LAYERS:
        wx = SCREEN_X * dep            # 同一屏幕位置
        z0 = 10.0 - dep
        h = 0.3
        verts = [(wx - h, -h, z0), (wx + h, -h, z0),
                 (wx + h, h, z0), (wx - h, h, z0)]
        mesh = bpy.data.meshes.new(nm)
        mesh.from_pydata(verts, [], [(0, 1, 2, 3)]); mesh.update()
        ob = bpy.data.objects.new(nm, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        objs[nm] = ob
    bpy.context.view_layer.update()
    return sc, cam, cd, objs


def wcen(ob):
    mw = ob.matrix_world
    return np.array([list(mw @ v.co) for v in ob.data.vertices]).mean(axis=0)


def scen(ob, cam, sc):
    p = np.array([list(world_to_camera_view(sc, cam, ob.matrix_world @ v.co))[:2]
                  for v in ob.data.vertices])
    return p.mean(axis=0)


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


print("=" * 94)
print("三层同视线（屏幕 x=%.2f），深度 8 / 6 / 4，ref=8" % SCREEN_X)
print("=" * 94)
print("PSD 公式预测：世界位移 = Δ·(1−k)；屏幕位移 = −Δ/ref（所有层相同）")

for dx in (1.0, 2.0):
    sc, cam, cd, objs = build()
    r = plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    ref = st.get("ref_depth", 0)
    print("\n" + "-" * 94)
    print("【相机横移 Δ = %+.2f】  ref_depth = %.2f" % (dx, ref))
    print("-" * 94)
    w0 = {n: wcen(o) for n, o in objs.items()}
    s0 = {n: scen(o, cam, sc) for n, o in objs.items()}
    cam.location.x += dx
    step(sc)
    w1 = {n: wcen(o) for n, o in objs.items()}
    s1 = {n: scen(o, cam, sc) for n, o in objs.items()}

    print("  %-4s %6s %8s %16s %16s %16s %16s" % (
        "层", "深度", "k", "世界Δx(实测)", "预期Δ·(1-k)", "屏幕Δx(实测)", "预期-Δ/ref"))
    for nm, dep in LAYERS:
        k = dep / ref
        dw = w1[nm][0] - w0[nm][0]
        ds = s1[nm][0] - s0[nm][0]
        print("  %-4s %6.1f %8.4f %+16.8f %+16.8f %+16.8f %+16.8f" % (
            nm, dep, k, dw, dx * (1 - k), ds, -dx / ref))
    print("\n  判定：")
    allw = all(abs((w1[n][0] - w0[n][0]) - dx * (1 - LAYERS[i][1] / ref)) < 1e-5
               for i, (n, _) in enumerate(LAYERS))
    alls = all(abs((s1[n][0] - s0[n][0]) + dx / ref) < 1e-5 for n, _ in LAYERS)
    print("    世界位移符合 Δ·(1-k) ：%s" % ("✓ 全部符合" if allw else "✗"))
    print("    屏幕位移符合 -Δ/ref  ：%s" % ("✓ 全部相同（构图保持）" if alls else "✗"))
    print("    → 最深层 A（k=1）世界坐标【冻结】，越浅的层跟着相机走得越多")
    print("    → 但它们在画面上滚的【量完全相同】，所以相对构图不变")

print()
print("=" * 94)
print("这就是「跟着相机一起适配视锥体」的准确含义")
print("=" * 94)
print("  相机移 Δ ⇒ 每层被放到【当前相机矩阵】下的相机空间位置：")
print("      world = current_camera_matrix @ (cam_space - Δcs·k, -depth)")
print("  所以：k=1 的层恰好被抵消 → 世界不动；k<1 的层 → 世界跟着走 Δ(1-k)")
print("  这正是 PSD parallax_utils.py L783-790 的做法；compify 用同一套公式，")
print("  只是把「一个图层一个深度」换成「一个顶点一个深度」。")
print("LAYERS_DONE")
