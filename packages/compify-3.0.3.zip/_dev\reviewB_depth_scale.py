"""审查 B-4/B-5：相机贴/穿网格平面（深度 0/负、nan）与负缩放 / 180° 旋转。

跑法：blender --background --factory-startup --python _dev\\reviewB_depth_scale.py
"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 94)
print("B-4 深度 0 / 负；B-5 负缩放 / 180° 旋转")
print("=" * 94)

# ══════════════════════════════════════════════════════
print("\n### 4a. 相机正好在网格平面上（所有顶点深度 = 0）###")
sc, cam, cd, grp = C.setup(cam_loc=(0, 0, 0))
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock: success=%s message=%s" % (r["success"], r["message"][:110]))
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 抛异常:", type(e).__name__, e)
C.chk("4a 相机在平面上 lock 不抛异常", exc is None)
na, vn, nuv, _ = C.nan_report(A, cd.name)
print("   属性:", list(C.attrs(A).keys()), " nan属性=%s 顶点nan=%s" % (na, vn))
C.chk("4a-2 不写坏网格（无 nan/inf 属性）", not na and not (vn[0] or vn[1]))

# ══════════════════════════════════════════════════════
print("\n### 4b. 相机穿在倾斜网格里（部分顶点深度 0 / 负）###")
sc, cam, cd, grp = C.setup(cam_loc=(0, 0, 0))
mat = C.probe_mat(grp)
A = C.add_grid("TiltA", cam, mat, ns=6, H=3.0, shape="倾斜")   # z = 0.28x，横跨 −0.84..0.84
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock: success=%s frozen=%s message=%s"
          % (r["success"], r.get("frozen"), r["message"][:170]))
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 抛异常:", type(e).__name__, e)
C.chk("4b 部分顶点在相机后方时 lock 不抛异常", exc is None)
if exc is None:
    a = A.data.attributes.get(plock._campos_attr_name(cd.name))
    print("   campos 属性存在=%s" % (a is not None))
    if a is not None and len(a.data):
        n = len(a.data)
        buf = [0.0] * (n * 3)
        a.data.foreach_get("vector", buf)
        z = np.array(buf).reshape(-1, 3)[:, 2]
        bad = int((np.abs(z) <= plock.MIN_DEPTH).sum())
        negz = int((z < 0).sum())
        print("   campos z: min=%.4f max=%.4f   |z|<=MIN_DEPTH 的顶点数=%d   z<0 的顶点数=%d"
              % (z.min(), z.max(), bad, negz))
        C.chk("4b-2 campos 里没有 z≈0 的顶点（否则着色器 x/0 出 inf）", bad == 0,
              "%d / %d 个顶点 z≈0" % (bad, n))

# ══════════════════════════════════════════════════════
print("\n### 4c. 锁定期间把相机推进到网格平面上 / 穿过它 ###")
sc, cam, cd, grp = C.setup(cam_loc=(0, 0, 5))
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
S = C.add_grid("Stereo", cam, mat, ns=3, shape="立体", x0=2.6)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s" % (r["success"], r.get("frozen")))
worst = 0.0
for z, tag in ((0.0, "z=0（正好在平面上）"), (-1.0, "z=-1（穿过平面）"), (-4.0, "z=-4（在平面后面）")):
    cam.location.z = z
    try:
        C.run_handler(sc)
        exc = None
    except Exception as e:
        exc = e
        print("   ✗ %s handler 抛异常: %s %s" % (tag, type(e).__name__, e))
        continue
    for ob in (A, S):
        na, vn, nuv, all_at = C.nan_report(ob, cd.name)
        n = len(ob.data.vertices)
        buf = [0.0] * (n * 3)
        ob.data.vertices.foreach_get("co", buf)
        arr = np.array(buf)
        mx = float(np.nanmax(np.abs(arr))) if n else 0.0
        worst = max(worst, mx)
        print("   %-22s %-7s 顶点nan=%s inf=%s |坐标|max=%.3e  nan属性=%s"
              % (tag, ob.name, vn[0], vn[1], mx, na))
        C.chk("4c %s %s 顶点无 nan/inf" % (tag, ob.name), not (vn[0] or vn[1]))
        C.chk("4c %s %s 坐标未爆（|co|max < 1e4）" % (tag, ob.name), mx < 1e4, "%.3e" % mx)
print("   全程最大坐标模 = %.3e" % worst)
# 恢复相机，解锁看会不会因坏数据失败
cam.location.z = 5.0
C.run_handler(sc)
ru = plock.unlock_group(sc, cam)
print("   解锁:", ru["message"][:120])
nodes = plock._find_delta_nodes(cd.name)
if nodes:
    print("   解锁后 S=%.6f C=(%.6f,%.6f)" % (
        nodes[0].inputs["Scale"].default_value,
        nodes[1].inputs[1].default_value[0], nodes[1].inputs[1].default_value[1]))

# ══════════════════════════════════════════════════════
print("\n### 4d. 相机 scale 为 0（奇异矩阵）###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
cam.scale = (0.0, 0.0, 0.0)
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock 返回: success=%s message=%s" % (r["success"], r["message"][:120]))
    exc = None
except Exception as e:
    exc = e
    print("   ✗ lock 抛异常:", type(e).__name__, e)
C.chk("4d 相机 scale=0 时 lock 不抛未捕获异常", exc is None,
      "%s: %s" % (type(exc).__name__, exc) if exc else "")


# ══════════════════════════════════════════════════════
def run_case(tag, apply_xform):
    """锁定 → 移相机 → 解锁，用 UV 探针真渲染量「解锁跳变」与「解锁后是否滑动」。"""
    sc, cam, cd, grp = C.setup(cam_loc=(0, 0, 5))
    mat = C.probe_mat(grp)
    A = C.add_grid("GridA", cam, mat, ns=4)
    apply_xform(A)
    bpy.context.view_layer.update()
    r = plock.lock_group(sc, cam)
    if not r["success"]:
        print("   %s lock 失败: %s" % (tag, r["message"][:100]))
        return
    cam.location.x = 1.5
    cam.rotation_euler.z = math.radians(8)
    C.run_handler(sc)
    u_lock = C.uvimg("tr")
    pose0 = A.matrix_world.copy()
    w0 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
    ru = plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    u_ul = C.uvimg("tr")
    jump = C.uvd(u_ul, u_lock)
    w1 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
    dg = float(np.abs(w1 - w0).max())
    cam.location.x += 1.0
    C.run_handler(sc)
    u_mv = C.uvimg("tr")
    slide = C.uvd(u_mv, u_ul)
    nodes = plock._find_delta_nodes(cd.name)
    S = nodes[0].inputs["Scale"].default_value if nodes else float("nan")
    Cc = tuple(nodes[1].inputs[1].default_value)[:2] if nodes else (0, 0)
    na, vn, nuv, _ = C.nan_report(A, cd.name)
    print("   %-16s 解锁跳变=%.5f 解锁后滑动=%.5f 几何Δ=%.2e S=%.4f C=(%+.4f,%+.4f) nan=%s"
          % (tag, jump, slide, dg, S, Cc[0], Cc[1], bool(na or vn[0] or vn[1])))
    C.chk("%s 解锁不跳（Δ<2e-3）" % tag, jump < 2e-3, "Δ=%.5f" % jump)
    C.chk("%s 解锁后图案仍滑动（Δ>5e-3）" % tag, slide > 5e-3, "Δ=%.5f" % slide)
    C.chk("%s 属性无 nan" % tag, not na and not (vn[0] or vn[1]))


print("\n### 5. 负缩放 / 旋转 180° ###")
run_case("scale(-1,1,1)", lambda o: setattr(o, "scale", (-1.0, 1.0, 1.0)))
run_case("scale(-1,-1,-1)", lambda o: setattr(o, "scale", (-1.0, -1.0, -1.0)))
run_case("rot_z=180", lambda o: setattr(o, "rotation_euler", (0.0, 0.0, math.pi)))
run_case("scale=1（对照）", lambda o: None)

C.summary()
