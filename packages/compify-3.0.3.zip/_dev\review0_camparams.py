"""验证：锁定期间改 camera 的 sensor_width / shift / sensor_fit，解锁是否跳变？

我的 fit_delta_params 里 _lens_ratio = lens_now / lens_lock —— **只看 lens**。
但投影组的 zoom 因子是 lens / sensor_width：
    Z = lens / sensor_width
若用户改的是 sensor_width，真实 ratio 应为 (lens_now/sw_now) / (lens_lock/sw_lock)，
而我只算 lens 比 ⇒ 少了一项 ⇒ 解锁跳变。

判据：真渲染 UV 探针（网格铺满，比渲染图；因为比较的是"同一位置的图案有没有变"，
    锁定期间移相机时用逐顶点判据）。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
RES = 64


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-50s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns = 4
    h = 14.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def render_uv(tag):
    _seq[0] += 1
    p = os.path.join(HERE, "_cw_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def sc_vals(cd):
    nodes = plock._find_delta_nodes(cd.name)
    return (nodes[0].inputs["Scale"].default_value,
            tuple(nodes[1].inputs[1].default_value)[:2])


def case(tag, mutate):
    sc, cam, cd, ob = build()
    plock.lock_group(sc, cam)
    cam.location.x = 2.0          # 先平移，确保有非零 delta
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()

    mutate(cd, cam)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    u_lock = render_uv("lock")

    r = plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    u_ul = render_uv("ul")
    jump = float(np.abs(u_ul - u_lock).mean())
    S, C = sc_vals(cd)
    print("\n[%s]" % tag)
    print("   解锁消息: %s" % r["message"][:70])
    print("   S=%.6f  C=(%+.6f,%+.6f)" % (S, C[0], C[1]))
    chk("%s 解锁不跳" % tag, jump < 2e-3, "Δ=%.6f" % jump)
    return jump


print("=" * 86)
print("相机参数在锁定期间被改动 → 解锁是否跳")
print("=" * 86)
case("A 对照：什么都不改", lambda cd, cam: None)
case("B 改 sensor_width 36→24", lambda cd, cam: setattr(cd, "sensor_width", 24.0))
case("C 改 sensor_width 36→52", lambda cd, cam: setattr(cd, "sensor_width", 52.0))
case("D 改 shift_x=0.15", lambda cd, cam: setattr(cd, "shift_x", 0.15))
case("E 改 shift_y=0.12", lambda cd, cam: setattr(cd, "shift_y", 0.12))
case("F 改 sensor_fit=VERTICAL", lambda cd, cam: setattr(cd, "sensor_fit", "VERTICAL"))
case("G 改 lens 50→85（已知正常）", lambda cd, cam: setattr(cd, "lens", 85.0))

print()
print("=" * 86)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("CAMW_DONE")
