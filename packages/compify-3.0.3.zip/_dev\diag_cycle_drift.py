"""验证：反复「锁定→移动→解锁」多轮，S/C 与画面是否累积漂移

关键设计：每轮都从**完全相同的初始状态**开始（相机回到原位、网格重置），
这样 C 每轮应当完全相同。若逐轮变化 ⇒ 累积漂移（真 bug）。
"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 64


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns = 3; h = 2.0
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-h+2*h*ix/ns, -h+2*h*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("Grid")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def uvimg():
    _seq[0] += 1
    p = os.path.join(HERE, "_cyc_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def sc_vals(cd):
    nodes = plock._find_delta_nodes(cd.name)
    if not nodes:
        return None, None
    return (nodes[0].inputs["Scale"].default_value,
            tuple(nodes[1].inputs[1].default_value)[:2])


print("=" * 92)
print("A) 反复 10 轮「锁定→移动x+2→解锁」，每轮都回到同一初始状态")
print("=" * 92)
sc, cam, cd, ob = build()
rows = []
for i in range(1, 11):
    cam.location = (0.0, 0.0, 5.0)
    cam.rotation_euler = (0, 0, 0)
    cd.lens = 50.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()

    plock.lock_group(sc, cam)
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    u_lock = uvimg()

    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    u_ul = uvimg()
    S, C = sc_vals(cd)
    jump = float(np.abs(u_ul - u_lock).mean()) if u_ul.shape == u_lock.shape else -1
    rows.append((i, S, C, jump))
    print("  第%2d 轮: S=%.8f  C=(%+.8f, %+.8f)  解锁跳变=%.6f" % (i, S, C[0], C[1], jump))

Ss = [r[1] for r in rows]
Cx = [r[2][0] for r in rows]
print("\n  S 极差 = %.3e   Cx 极差 = %.3e" % (max(Ss)-min(Ss), max(Cx)-min(Cx)))
print("  >>> %s" % ("无累积漂移 ✓" if (max(Cx)-min(Cx)) < 1e-6 else "【有累积漂移】"))

print()
print("=" * 92)
print("B) 反复 10 轮但不重置相机（每轮从上一轮的终态继续，模拟真实连续操作）")
print("=" * 92)
sc, cam, cd, ob = build()
prev_c = None
for i in range(1, 11):
    plock.lock_group(sc, cam)
    cam.location.x += 0.5
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    S, C = sc_vals(cd)
    print("  第%2d 轮: 相机x=%.2f  S=%.6f  C=(%+.6f, %+.6f)" % (
        i, cam.location.x, S, C[0], C[1]))

print("\nCYCLE_DONE")
