"""审查 C · 宽扫 —— 10 个角度的第一轮信号。

每个 case：
  align  未锁定时 探针 UV vs world_to_camera_view    （图案是否真贴在相机看到的位置）
  glue   锁定中移相机，逐顶点图案 UV 是否不变         （图案是否粘住网格）
  jump   解锁瞬间整图是否不变                        （核心契约）
  slide  解锁后移相机，逐顶点图案 UV 是否变化         （投影是否复活）
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy

ROWS = []


def case(tag, dx=0.4, mutate=None, **kw):
    sc, cam, cd, mat, ob = build(**kw)
    p0 = render_uv("a")
    amx, amn, an = align_err(sc, cam, ob, p0)
    plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL = render_uv("l")
    iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
    if mutate:
        mutate(sc, cam, cd)
    else:
        cam.location.x += dx
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL2 = render_uv("l2")
    iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
    sm = np.intersect1d(iL, iL2)
    glue = (float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max())
            if len(sm) else float("nan"))
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    pU = render_uv("u")
    jump, jmx, jn = diff(pL2, pU)
    iU, uvU, _ = uv_at_verts(sc, cam, ob, pU)
    cam.location.x += dx * 0.5
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pM = render_uv("m")
    iM, uvM, _ = uv_at_verts(sc, cam, ob, pM)
    sm2 = np.intersect1d(iU, iM)
    slide = (float(np.abs(uvU[np.isin(iU, sm2)] - uvM[np.isin(iM, sm2)]).max())
             if len(sm2) else float("nan"))
    ROWS.append((tag, amx, glue, jump, slide, nodes_sc(cd)))
    print("  %-26s align=%8.4f glue=%8.4f JUMP=%8.4f slide=%8.4f  S/C=%s"
          % (tag, amx, glue, jump, slide,
             "%.3f/%+.3f,%+.3f" % (nodes_sc(cd)[0], nodes_sc(cd)[1][0], nodes_sc(cd)[1][1])
             if nodes_sc(cd) else None))


print("=" * 100)
print("宽扫：透视 50mm 为对照，逐项改一个相机/渲染边界条件")
print("=" * 100)

case("A 对照 50mm", dx=0.4)

print("\n### 1 正交相机 ###")
case("D 正交 静态", dx=2.0, cam_type="ORTHO", ortho_scale=6.0)
case("D2 正交 锁中改ortho_scale", cam_type="ORTHO", ortho_scale=6.0,
     mutate=lambda sc, cam, cd: setattr(cd, "ortho_scale", 8.0))

print("\n### 2 超长焦 / 超广角 ###")
case("B 500mm", dx=0.04, lens=500.0)
case("C 8mm", dx=4.0, lens=8.0)

print("\n### 3 sensor_fit / sensor_height ###")
case("E sensor_fit=VERTICAL", dx=0.4, sensor_fit="VERTICAL", sensor_height=24.0)
case("E2 锁中改 sensor_height", dx=0.4, sensor_fit="VERTICAL", sensor_height=24.0,
     mutate=lambda sc, cam, cd: setattr(cd, "sensor_height", 48.0))

print("\n### 4 镜头位移 shift ###")
case("F shift=(0.1,0.05)", dx=0.4, shift=(0.1, 0.05))
case("F2 锁中改 shift_x", dx=0.4,
     mutate=lambda sc, cam, cd: setattr(cd, "shift_x", 0.1))

print("\n### 5 相机 scale ###")
case("G scale=2 均匀", dx=0.4, cam_scale=(2, 2, 2))
case("H scale=(2,1,1) 非均匀", dx=0.4, cam_scale=(2, 1, 1))
case("G2 锁中改 scale=2", dx=0.4,
     mutate=lambda sc, cam, cd: setattr(cam, "scale", (2.0, 2.0, 2.0)))

print("\n### 6 渲染引擎 ###")
case("K CYCLES", dx=0.4, engine="CYCLES")

print("\n### 10 非正方形分辨率 ###")
case("I 192x108 aspect=16/9", dx=0.4, res=(192, 108), aspect_input=192.0 / 108.0)
case("J 192x108 aspect=1(默认)", dx=0.4, res=(192, 108))

print("\n### 附带：锁定期间改传感器宽度（等价于改视场）###")
case("M 锁中改 sensor_width", dx=0.4,
     mutate=lambda sc, cam, cd: setattr(cd, "sensor_width", 24.0))
case("L 锁中改 lens 50→85（已知已修）", dx=0.4,
     mutate=lambda sc, cam, cd: setattr(cd, "lens", 85.0))

print("\n" + "=" * 100)
print("%-26s %8s %8s %8s %8s" % ("case", "align", "glue", "JUMP", "slide"))
for r in ROWS:
    print("%-26s %8.4f %8.4f %8.4f %8.4f" % r[:5])
print("REVIEWC_DONE")
