"""审查E-12：_base_cache 的键含 obj.name —— 锁定期间给网格改名是否多留一份 28MB？

键 = (obj.name, mesh.as_pointer(), n)（行 1435），只有 _write_base_attribute / reset /
unregister 会清。改名后旧键留在字典里，值是一整份顶点列表。
"""
import bpy, sys, os, gc, ctypes, ctypes.wintypes
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


class PMC(ctypes.Structure):
    _fields_ = [("cb", ctypes.wintypes.DWORD), ("PageFaultCount", ctypes.wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


_k32 = ctypes.WinDLL("kernel32.dll")
_k32.GetCurrentProcess.restype = ctypes.wintypes.HANDLE
_ps = ctypes.WinDLL("psapi.dll")
_ps.GetProcessMemoryInfo.argtypes = [ctypes.wintypes.HANDLE, ctypes.POINTER(PMC),
                                     ctypes.wintypes.DWORD]
_ps.GetProcessMemoryInfo.restype = ctypes.wintypes.BOOL


def rss():
    p = PMC()
    p.cb = ctypes.sizeof(PMC)
    _ps.GetProcessMemoryInfo(_k32.GetCurrentProcess(), ctypes.byref(p), p.cb)
    return p.WorkingSetSize / 1048576.0


def cbytes():
    return sum(len(v) * (56 + 72) for v in plock._base_cache.values()) / 1048576.0


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 12)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
bpy.ops.mesh.primitive_grid_add(x_subdivisions=550, y_subdivisions=550, size=8.0)
ob = bpy.context.object
ob.name = "Big"
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
cam.location.x += 0.02
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
gc.collect()
print("锁定+一帧：_base_cache=%d 条 约 %.1f MB  RSS=%.1f MB" % (
    len(plock._base_cache), cbytes(), rss()))

for i in range(5):
    ob.name = "BigR%d" % i
    cam.location.x += 0.005
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
gc.collect()
print("改名 5 次后：_base_cache=%d 条 约 %.1f MB  RSS=%.1f MB  键=%s" % (
    len(plock._base_cache), cbytes(), rss(),
    [k[0] for k in plock._base_cache]))
