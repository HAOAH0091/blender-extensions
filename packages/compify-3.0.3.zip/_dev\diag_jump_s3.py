"""诊断 S3：拖很远（+15）时 A 自己的屏幕投影为什么会跳 0.43

数学预期：
    屏幕位置 = cam.x / |cam.z|
             = (xd − delta_cs.x·kk·SCROLL) / depth
             = x0/d_base − delta_cs.x·SCROLL/ref        ← 与拖动后的深度 dd 无关
    所以拖动不该改变屏幕位置。实测却跳了 0.43 ⇒ 有别的东西在变。

逐帧打印：offset / dd范围 / k_i范围 / depth范围 / 位姿 / kk / 屏幕投影
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])


def mk(name, x0, z0):
    ns = 2; h = 1.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((x0 - h + 2 * h * ix / ns, -h + 2 * h * iy / ns, z0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new(name, mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                             "ShaderNodeTree")
    return ob


A = mk("A", -1.5, 0.0)
B = mk("B", 1.5, 2.0)
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
cam.location.x = 1.2
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

st = plock.get_state(sc, cam)
ref = st.get("ref_depth", 0)
print("ref_depth = %.4f" % ref)
print("A 的 base（锁定相机空间坐标）前 4 个:")
base = plock._read_base_attribute(A)
for i in range(min(4, len(base))):
    print("   (%+.4f, %+.4f, %+.4f)" % base[i])


def snap(ob):
    inv = cam.matrix_world.inverted()
    s = []
    for v in ob.data.vertices:
        p = inv @ (ob.matrix_world @ v.co)
        s.append((p.x / p.z, p.y / p.z) if abs(p.z) > 1e-9 else (0.0, 0.0))
    return np.array(s)


print()
print("=" * 100)
print("逐帧拖动 A：每帧 +1.5（共 10 帧 = +15），观察屏幕投影")
print("=" * 100)
print("%3s %10s %10s %10s %12s %12s %10s %10s" % (
    "帧", "offset", "dd最小", "dd最大", "位姿z", "屏幕x[0]", "屏幕变化", "矩阵差"))
prev = snap(A)
mw_prev = A.matrix_world.copy()
for i in range(1, 11):
    A.location.z += 1.5
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    s = snap(A)
    off = A.get(plock.DRAG_OFFSET_KEY, 0.0)
    base_now = plock._read_base_attribute(A)
    dds = [b[2] for b in base_now]
    dmat = max(abs(a - b) for ra, rb in zip(A.matrix_world, mw_prev)
               for a, b in zip(ra, rb))
    print("%3d %10.4f %10.4f %10.4f %12.4f %12.6f %10.6f %10.6f" % (
        i, off, min(dds), max(dds), A.location.z, s[0][0],
        float(np.abs(s - prev).max()), dmat))
    prev = s
    mw_prev = A.matrix_world.copy()

print()
print("=" * 100)
print("单独看第 1 帧后的「相机空间实际坐标」")
print("=" * 100)
inv = cam.matrix_world.inverted()
for i, v in enumerate(A.data.vertices[:4]):
    p = inv @ (A.matrix_world @ v.co)
    print("  顶点%d 相机空间 (%+.4f, %+.4f, %+.4f)  投影 (%.6f, %.6f)" % (
        i, p.x, p.y, p.z, p.x / p.z, p.y / p.z))
print()
print("DRAG_OFFSET_KEY =", A.get(plock.DRAG_OFFSET_KEY, None))
print("DRAG_SCALE_KEY  =", A.get(plock.DRAG_SCALE_KEY, None))
print("MATRIX_KEY 存在 =", plock._read_matrix_key(A) is not None)
print("JUMPDIAG_DONE")
