"""定位旋转残差：A/B 算的 UV vs 逐顶点 delta 算的 UV，逐顶点对比"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
from mathutils import Matrix, Euler


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    # 倾斜网格（深度有跨度）
    ns = 2
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            x = -1.5 + 3.0*ix/ns
            y = -1.5 + 3.0*iy/ns
            verts.append((x, y, 1.2*x))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh = bpy.data.meshes.new("G")
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def persp(cam, ob):
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


sc, cam, cd, ob = build()
plock.lock_group(sc, cam)
cam_mw_lock = cam.matrix_world.copy()
frozen = persp(cam, ob)

cam.rotation_euler.z = math.radians(15)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
live = persp(cam, ob)
delta = frozen - live
print("旋转 15°（倾斜网格）")
print("  逐顶点 delta 极差: x=%.8f y=%.8f" % (
    delta[:,0].max()-delta[:,0].min(), delta[:,1].max()-delta[:,1].min()))
print("  delta[0] =", np.round(delta[0], 6))

# 解锁（D+ 会写 A = M_lock^-1 M_now, B = I）
w0 = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
w1 = np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])
print("  解锁是否动几何: %.8f" % np.abs(w1-w0).max())

# A/B 算出的 UV
nodes = plock._find_ab_nodes(cd.name)
a_rot, a_loc, b_rot, b_loc = nodes
e = a_rot.inputs["Rotation"].default_value
t = a_loc.inputs[1].default_value
R = Euler((e[0], e[1], e[2]), "XYZ").to_matrix().to_4x4()
A = Matrix.Translation((t[0], t[1], t[2])) @ R
print("  组内 A loc=%s rot(deg)=%s" % (
    tuple(round(x,4) for x in t), tuple(round(math.degrees(x),3) for x in e)))
A_exp = cam_mw_lock.inverted() @ cam.matrix_world
print("  期望 A loc=%s rot(deg)=%s" % (
    tuple(round(x,4) for x in A_exp.translation),
    tuple(round(math.degrees(x),3) for x in A_exp.to_euler("XYZ"))))
print("  A 与期望 最大差: %.8f" % max(
    abs(A[i][j]-A_exp[i][j]) for i in range(4) for j in range(4)))

m_now = cam.matrix_world.inverted()
verts = [ob.matrix_world @ v.co for v in ob.data.vertices]
p_now = [m_now @ w for w in verts]
uv_ab = []
for p in p_now:
    pa = A @ p
    uv_ab.append((p.x/p.z + pa.x/pa.z - p.x/p.z,   # B=I ⇒ 减去 persp(p)
                  p.y/p.z + pa.y/pa.z - p.y/p.z))
uv_ab = np.array(uv_ab)
print("\n  按 A/B 公式算的 UV[0] =", np.round(uv_ab[0], 6))
print("  冻结图案      UV[0] =", np.round(frozen[0], 6))
print("  >>> 差 = %.8f" % np.abs(uv_ab - frozen).max())

# 逐顶点 delta 方案算的 UV
uv_delta = live + delta
print("  逐顶点delta   UV[0] =", np.round(uv_delta[0], 6))
print("  >>> 与冻结差 = %.8f" % np.abs(uv_delta - frozen).max())
print("\n  live[0] =", np.round(live[0], 6))
print("ROTDIAG_DONE")
