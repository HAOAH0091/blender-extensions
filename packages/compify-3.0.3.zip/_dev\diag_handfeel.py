"""量化对比：compify 当前 vs PSD 工具语义
判据：
  ① 跟手比 = 物体位姿位移 / 用户拖动位移   （PSD ≈ 1，compify 当前 = 0）
  ② 屏幕投影保持 = 顶点投影坐标的最大变化   （两者都应 ≈ 0）
  ③ 是否发散 = 连续拖动后 drag 是否失控
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_handfeel"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]

from mathutils import Vector, Matrix


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)

    m = bpy.data.materials.new("M"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])

    mesh = bpy.data.meshes.new("G")
    ns = 3
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-1+2*ix/ns, -1+2*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    obj = bpy.data.objects.new("GridA", mesh)
    scene.collection.objects.link(obj)
    obj.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    return scene, cam, cd, obj


def screen_proj(cam, obj):
    """顶点在相机画面的归一化投影坐标"""
    v = PL.get_camera_view_matrix(cam)
    out = []
    for vv in obj.data.vertices:
        w = obj.matrix_world @ vv.co
        p = v @ w
        z = -p.z
        out.append((p.x / z if z > 1e-6 else 0.0, p.y / z if z > 1e-6 else 0.0))
    return out


def apply_user_move_psdstyle(obj, camera, view_now):
    """照 PSD 工具语义：位姿跟手（沿视线到新深度），drag 记绝对比，基准不更新"""
    if not PL.LAYER_MOVE_ENABLED:
        return False
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    M_lock = PL._read_matrix_key(obj)
    if M_lock is None:
        PL._write_matrix_key(obj, obj.matrix_world.copy())
        return False
    M_cur = obj.matrix_world.copy()
    if PL._mat_close(M_cur, M_lock):
        return False
    view_inv = view_now.inverted()
    c_local = PL._mesh_center_local(obj)
    d_lock = PL._view_depth(view_inv, M_lock @ c_local)
    d_cur = PL._view_depth(view_inv, M_cur @ c_local)
    if d_lock <= PL.MIN_DEPTH or d_cur <= PL.MIN_DEPTH:
        return False
    k = d_cur / d_lock
    if abs(k - 1.0) <= 1e-9:
        return False
    # ① drag = k（绝对比）
    obj[PL.DRAG_SCALE_KEY] = float(k)
    # ② 位姿跟手：沿视线把物体中心送到新深度（屏幕坐标保持）
    axis_cs = Vector((0.0, 0.0, -1.0))
    axis_w = view_now.to_3x3() @ axis_cs        # 视线方向（世界）
    shift = axis_w * (d_lock - d_cur)           # d_cur 更近 ⇒ shift 朝相机
    M_new = M_lock.copy()
    M_new.translation = M_lock.translation + shift
    obj.matrix_world = M_new
    bpy.context.view_layer.update()
    return True


print("="*76)
print("量化对比：拖动 10 帧，每帧沿视线靠近 0.05")
print("="*76)

for label, fn in [("compify 当前", PL.apply_user_move),
                  ("PSD 语义(改后)", apply_user_move_psdstyle)]:
    scene, cam, cd, obj = build()
    PL.lock_group(scene, cam)
    M_lock = obj.matrix_world.copy()
    c_local = PL._mesh_center_local(obj)
    view = PL.get_camera_view_matrix(cam)
    d_lock = PL._view_depth(view.inverted(), M_lock @ c_local)
    axis_w = view.to_3x3() @ Vector((0, 0, -1))

    proj0 = screen_proj(cam, obj)
    print("\n--- %s ---" % label)
    print("  帧  鼠标位移  位姿位移  顶点世界位移   跟手比   drag      屏幕投影最大变化")
    for f in range(10):
        step = 0.05
        user_shift = axis_w * (step * (f + 1))
        Mtmp = M_lock.copy()
        Mtmp.translation = M_lock.translation + user_shift
        obj.matrix_world = Mtmp               # ← 模拟用户拖到这里
        bpy.context.view_layer.update()

        pose_before = obj.matrix_world.translation.copy()
        v_before = [obj.matrix_world @ v.co for v in obj.data.vertices]

        vn = PL.get_camera_view_matrix(cam)
        fn(obj, cam, vn)

        pose_after = obj.matrix_world.translation.copy()
        v_after = [obj.matrix_world @ v.co for v in obj.data.vertices]

        pose_move = (pose_after - M_lock.translation).length
        vert_move = max((a - b).length for a, b in zip(v_after, v_before)) if f else 0.0
        drag = obj.get(PL.DRAG_SCALE_KEY)
        proj = screen_proj(cam, obj)
        dproj = max(max(abs(a[0]-b[0]), abs(a[1]-b[1])) for a, b in zip(proj0, proj))
        handfeel = pose_move / (step * (f + 1))
        print("  %2d  %+8.3f  %8.4f  %12.4f  %7.2f  %8.4f  %14.6f" %
              (f+1, step*(f+1), pose_move, vert_move, handfeel, drag, dproj))
