"""审查E-2：单个大网格 1万 / 10万 / 100万 顶点 —— 锁定 / 每帧适配 / 解锁耗时

判据：>10 秒视为卡死。
"""
import bpy, sys, os, time, math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(nside):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 12)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("ProjMat")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    t0 = time.perf_counter()
    bpy.ops.mesh.primitive_grid_add(x_subdivisions=nside, y_subdivisions=nside,
                                    size=8.0, location=(0, 0, 0))
    ob = bpy.context.object
    ob.name = "Big"
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name),
                             "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob, (time.perf_counter() - t0) * 1000.0


print("%-10s %-9s %-10s %-11s %-11s %-12s %-11s" % (
    "顶点数", "建档_ms", "锁定_ms", "帧均_ms", "帧最大_ms", "解锁_ms", "重置_ms"))
for nside in (100, 320, 1000):
    sc, cam, cd, ob, t_build = build(nside)
    n_v = len(ob.data.vertices)
    plock._proj_cache.clear()
    plock._base_cache.clear()
    plock._last_view.clear()

    t0 = time.perf_counter()
    res = plock.lock_group(sc, cam)
    t_lock = (time.perf_counter() - t0) * 1000.0

    ts = []
    for f in range(6):
        cam.location.x += 0.01
        bpy.context.view_layer.update()
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)
        ts.append((time.perf_counter() - t0) * 1000.0)

    t0 = time.perf_counter()
    plock.unlock_group(sc, cam)
    t_unlock = (time.perf_counter() - t0) * 1000.0

    t0 = time.perf_counter()
    plock.reset_group(sc, cam)
    t_reset = (time.perf_counter() - t0) * 1000.0

    print("%-10d %-9.0f %-10.0f %-11.0f %-11.0f %-12.0f %-11.0f" % (
        n_v, t_build, t_lock, sum(ts) / len(ts), max(ts), t_unlock, t_reset))
    sys.stdout.flush()
