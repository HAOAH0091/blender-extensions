"""验证「位姿跟手 + drag=k」到底会不会双重计算
三种方案同场景对比：
  A 现状       : drag *= k, 位姿还原
  B 只修累乘   : drag = k, 位姿还原
  C 位姿跟手   : drag = k, 位姿沿视线跟到新深度
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_conflict"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]
from mathutils import Vector


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("M"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    mesh = bpy.data.meshes.new("G")
    ns = 3
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-1+2*ix/ns, -1+2*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    obj = bpy.data.objects.new("GridA", mesh)
    scene.collection.objects.link(obj)
    obj.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    return scene, cam, cd, obj


def proj(cam, obj):
    v = PL.get_camera_view_matrix(cam)
    out = []
    for vv in obj.data.vertices:
        p = v @ (obj.matrix_world @ vv.co)
        z = -p.z
        out.append((p.x/z if z > 1e-6 else 0.0, p.y/z if z > 1e-6 else 0.0))
    return out


def move_A(obj, cam, V):
    """A: 现状（drag *= k，位姿还原）"""
    return PL.apply_user_move(obj, cam, V)

def move_B(obj, cam, V):
    """B: 只修累乘（drag = k，位姿还原）"""
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    Mp = PL._read_matrix_key(obj)
    if Mp is None:
        PL._write_matrix_key(obj, obj.matrix_world.copy()); return False
    Mc = obj.matrix_world.copy()
    if PL._mat_close(Mc, Mp): return False
    Vi = V.inverted(); cl = PL._mesh_center_local(obj)
    dp = PL._view_depth(Vi, Mp @ cl); dc = PL._view_depth(Vi, Mc @ cl)
    if dp <= PL.MIN_DEPTH:
        PL._write_matrix_key(obj, Mc); return False
    if dc <= PL.MIN_DEPTH:
        obj.matrix_world = Mp; bpy.context.view_layer.update(); return False
    k = dc / dp
    if abs(k - 1.0) <= 1e-9:
        obj.matrix_world = Mp; bpy.context.view_layer.update(); return False
    obj[PL.DRAG_SCALE_KEY] = float(k)          # ★ 赋值而非累乘
    obj.matrix_world = Mp
    bpy.context.view_layer.update(); return True

def move_C(obj, cam, V):
    """C: 位姿跟手（drag = k，且位姿沿视线送到新深度）"""
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    Mp = PL._read_matrix_key(obj)
    if Mp is None:
        PL._write_matrix_key(obj, obj.matrix_world.copy()); return False
    Mc = obj.matrix_world.copy()
    if PL._mat_close(Mc, Mp): return False
    Vi = V.inverted(); cl = PL._mesh_center_local(obj)
    dp = PL._view_depth(Vi, Mp @ cl); dc = PL._view_depth(Vi, Mc @ cl)
    if dp <= PL.MIN_DEPTH:
        PL._write_matrix_key(obj, Mc); return False
    if dc <= PL.MIN_DEPTH:
        obj.matrix_world = Mp; bpy.context.view_layer.update(); return False
    k = dc / dp
    if abs(k - 1.0) <= 1e-9:
        obj.matrix_world = Mp; bpy.context.view_layer.update(); return False
    obj[PL.DRAG_SCALE_KEY] = float(k)
    # ★ 位姿跟到「视线上、深度 dc 处」的位置
    axis_w = (V.to_3x3() @ Vector((0, 0, -1))).normalized()
    Mnew = Mp.copy()
    Mnew.translation = Mp.translation + axis_w * (dp - dc)
    obj.matrix_world = Mnew
    bpy.context.view_layer.update(); return True


STEPS = 10
STEP_LEN = 0.05
for label, fn in [("A 现状(drag*=k,位姿还原)", move_A),
                  ("B 只修累乘(drag=k,位姿还原)", move_B),
                  ("C 位姿跟手(drag=k,跟到新深度)", move_C)]:
    scene, cam, cd, obj = build()
    PL.lock_group(scene, cam)
    Mlock = obj.matrix_world.copy()
    cl = PL._mesh_center_local(obj)
    V = PL.get_camera_view_matrix(cam)
    dlock = PL._view_depth(V.inverted(), Mlock @ cl)
    axis_w = (V.to_3x3() @ Vector((0, 0, -1))).normalized()
    p0 = proj(cam, obj)

    print("\n" + "="*80)
    print(label)
    print("  帧 | 鼠标拖 | 位姿移 | 顶点移 | 跟手比 | drag   | 期望drag | 屏幕变化")
    drags, poses, verts_m = [], [], []
    for f in range(STEPS):
        target = Mlock.copy()
        target.translation = Mlock.translation + axis_w * (STEP_LEN * (f + 1))
        obj.matrix_world = target
        bpy.context.view_layer.update()
        Vb = [obj.matrix_world @ v.co for v in obj.data.vertices]
        pb = obj.matrix_world.translation.copy()

        Vn = PL.get_camera_view_matrix(cam)
        fn(obj, cam, Vn)

        Va = [obj.matrix_world @ v.co for v in obj.data.vertices]
        pa = obj.matrix_world.translation.copy()
        vmove = max((a - b).length for a, b in zip(Va, Vb))
        pmove = (pa - Mlock.translation).length
        hand = pmove / (STEP_LEN * (f + 1))
        drag = obj.get(PL.DRAG_SCALE_KEY)
        d_now = PL._view_depth(Vn.inverted(), obj.matrix_world @ cl)
        expect = d_now / dlock
        pg = proj(cam, obj)
        dpr = max(max(abs(a[0]-b[0]), abs(a[1]-b[1])) for a, b in zip(p0, pg))
        print("  %2d | %+6.2f | %6.4f | %6.4f | %6.2f | %6.4f | %7.4f | %8.6f" %
              (f+1, STEP_LEN*(f+1), pmove, vmove, hand, drag, expect, dpr))
        drags.append(drag); poses.append(pmove); verts_m.append(vmove)

    print("  drag 序列: %s" % " ".join("%.4f" % x for x in drags))
