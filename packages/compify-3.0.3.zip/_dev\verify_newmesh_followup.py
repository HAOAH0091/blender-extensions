"""B 补写后的后续行为验证
1. 补写后相机再动 → B 图案应滑动（delta 固定不变）
2. 重新锁定 → B 的 delta 并入 campos 后删除，锁定中图案冻结
3. 重置 → B 的 delta 被清掉
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-46s %s" % ("PASS" if c else "FAIL", n, d))


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])


def grid(name, x, w=1.2):
    Ns = 2
    verts, faces = [], []
    for iy in range(Ns+1):
        for ix in range(Ns+1):
            verts.append((x-w+2*w*ix/Ns, -w+2*w*iy/Ns, 0.0))
    for iy in range(Ns):
        for ix in range(Ns):
            a = iy*(Ns+1)+ix
            faces.append((a, a+1, a+Ns+2, a+Ns+1))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new(name, mesh)
    sc.collection.objects.link(ob)
    return ob


A = grid("GridA", -1.8)
B = grid("GridB", 1.8)
A.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()


def uv_of(ob):
    if plock.is_patched(cd.name):
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                              a.data[i].vector[1]/a.data[i].vector[2])
                             for i in range(len(a.data))])
    m = cam.matrix_world.inverted()
    o = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        o.append((p.x/p.z, p.y/p.z))
    o = np.array(o)
    d = ob.data.attributes.get(plock.UV_DELTA_ATTR)
    if d is not None and len(d.data) == len(ob.data.vertices):
        o = o + np.array([(d.data[i].vector[0], d.data[i].vector[1]) for i in range(len(d.data))])
    return o


print("=" * 74)
print("准备：A 锁定 → 移相机 → 解锁 → B 换材质")
print("=" * 74)
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
plock.unlock_group(sc, cam)
B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("  B delta:", B.data.attributes.get(plock.UV_DELTA_ATTR) is not None)

u0 = uv_of(B)
cam.location.x = 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u1 = uv_of(B)
d_slide = float(np.abs(u1 - u0).max())
chk("1 补写后相机再动 → B 图案滑动", d_slide > 1e-3, "UV 变化 %.6f" % d_slide)

u_committed = u1.copy()
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
u_rl = uv_of(B)
chk("2a 重锁瞬间 B 图案不跳", float(np.abs(u_rl - u_committed).max()) < 1e-6,
    "Δ=%.2e" % float(np.abs(u_rl - u_committed).max()))
chk("2b 重锁后 B 的 delta 已并入 campos 并删除",
    B.data.attributes.get(plock.UV_DELTA_ATTR) is None)
cam.location.x = 3.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
u_rl2 = uv_of(B)
chk("2c 锁定中 B 图案冻结", float(np.abs(u_rl2 - u_rl).max()) < 1e-6,
    "Δ=%.2e" % float(np.abs(u_rl2 - u_rl).max()))

plock.reset_group(sc, cam)
bpy.context.view_layer.update()
chk("3 重置后 B 的 delta 已清", B.data.attributes.get(plock.UV_DELTA_ATTR) is None)
chk("4 重置后 A 的 delta 已清", A.data.attributes.get(plock.UV_DELTA_ATTR) is None)

print()
print("=" * 74)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("FOLLOWUP_DONE")
