"""验证：弹窗里要告诉用户的三种操作，是否真的能让网格变得可冻结。

文案不能只是好听 —— 用户照着做必须真的解决。
逐条验证操作是否有效，以及做完后是否**自动**补上冻结坐标（不用重新锁定）。

  ① 带修改器  → 应用修改器（modifier_apply）
  ② 带形态键  → 删除全部形态键（shape_key_remove all）
  ③ 共享网格  → 使其独立化（Make Single User / 复制 mesh 数据）
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-48s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5)
    cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, mesh=None):
        if mesh is None:
            ns = 3
            h = 1.5
            verts, faces = [], []
            for iy in range(ns + 1):
                for ix in range(ns + 1):
                    verts.append((x0 - h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
            for iy in range(ns):
                for ix in range(ns):
                    a = iy * (ns + 1) + ix
                    faces.append((a, a + 1, a + ns + 2, a + ns + 1))
            mesh = bpy.data.meshes.new(name)
            mesh.from_pydata(verts, [], faces)
            mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob

    A = mk("GridA", -2.0)
    B = mk("GridB", 2.0)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


def blocked(ob):
    return plock.has_modifier_or_shapekey(ob)


def has_campos(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    return a is not None and len(a.data) == len(ob.data.vertices)


def uv_err(ob, cam, cd, lock_mw):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return 999.0
    uv = np.array([(a.data[i].vector[0] / a.data[i].vector[2],
                    a.data[i].vector[1] / a.data[i].vector[2])
                   for i in range(len(a.data))])
    mi = lock_mw.inverted()
    exp = np.array([((lambda p: (p.x / p.z, p.y / p.z))(mi @ (ob.matrix_world @ v.co)))
                    for v in ob.data.vertices])
    return float(np.abs(uv - exp).max())


def prep(sccam=None):
    sc, cam, cd, mat, A, B = build()
    plock._backfill_warned.clear()
    plock._popup_shown.clear()
    plock._popup_queue.clear()
    plock.lock_group(sc, cam)
    lock_mw = cam.matrix_world.copy()
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    B.data.materials.clear()
    B.data.materials.append(mat)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B, lock_mw


print("=" * 84)
print("弹窗里要写的三种操作 —— 是否真的有效？")
print("=" * 84)

# ═════════ ① 修改器 → 应用修改器 ═════════
print("\n[①] 带修改器 → 做法：应用修改器")
sc, cam, cd, mat, A, B, lock_mw = prep()
B.modifiers.new("Subdiv", "SUBSURF")
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("前置：确实被阻塞", blocked(B) is not None, "原因=%s" % blocked(B))
chk("前置：此时没有冻结坐标", not has_campos(B, cd))

# 模拟用户操作：选中 B → 应用全部修改器
bpy.ops.object.select_all(action="DESELECT")
B.select_set(True)
bpy.context.view_layer.objects.active = B
for md in list(B.modifiers):
    bpy.ops.object.modifier_apply(modifier=md.name)
bpy.context.view_layer.update()
chk("①a 应用修改器后不再被阻塞", blocked(B) is None, "原因=%s" % blocked(B))

plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("①b 自动补上冻结坐标（不用重新锁定）", has_campos(B, cd))
chk("①c 图案与 A 同口径", uv_err(B, cam, cd, lock_mw) < 1e-5,
    "UV 误差=%.8f" % uv_err(B, cam, cd, lock_mw))

# ═════════ ② 形态键 → 删除形态键 ═════════
print("\n[②] 带形态键 → 做法：删除全部形态键")
sc, cam, cd, mat, A, B, lock_mw = prep()
B.shape_key_add(name="Basis", from_mix=False)
B.shape_key_add(name="K1", from_mix=False)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("前置：确实被阻塞", blocked(B) is not None, "原因=%s" % blocked(B))

bpy.ops.object.select_all(action="DESELECT")
B.select_set(True)
bpy.context.view_layer.objects.active = B
bpy.ops.object.shape_key_remove(all=True)
bpy.context.view_layer.update()
chk("②a 删除形态键后不再被阻塞", blocked(B) is None, "原因=%s" % blocked(B))

plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("②b 自动补上冻结坐标", has_campos(B, cd))
chk("②c 图案与 A 同口径", uv_err(B, cam, cd, lock_mw) < 1e-5,
    "UV 误差=%.8f" % uv_err(B, cam, cd, lock_mw))

# ═════════ ③ 共享网格 → 使其独立化 ═════════
print("\n[③] 共享网格 → 做法：使其独立化（Make Single User）")
sc, cam, cd, mat, A, B, lock_mw = prep()
C = bpy.data.objects.new("GridC", B.data)
sc.collection.objects.link(C)
C.location = (6.0, 0, 0)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("前置：确实被阻塞（共享）", blocked(B) is not None, "原因=%s" % blocked(B))

# 模拟用户操作：选中 B 与 C，Make Single User（数据块复制一份）
bpy.ops.object.select_all(action="DESELECT")
B.select_set(True)
C.select_set(True)
bpy.context.view_layer.objects.active = B
try:
    bpy.ops.object.make_single_user(object=False, obdata=True, material=False)
    via_op = True
except Exception as e:
    via_op = False
    print("   （make_single_user 不可用：%s，改用 data.copy()）" % e)
    B.data = B.data.copy()
bpy.context.view_layer.update()
chk("③a 独立化后不再被阻塞", blocked(B) is None,
    "原因=%s（via_op=%s）" % (blocked(B), via_op))

plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
chk("③b 自动补上冻结坐标", has_campos(B, cd))
chk("③c 图案与 A 同口径", uv_err(B, cam, cd, lock_mw) < 1e-5,
    "UV 误差=%.8f" % uv_err(B, cam, cd, lock_mw))

print()
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("FIXSTEPS_DONE")
