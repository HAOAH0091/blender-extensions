"""审查E-5：把「1000 网格 + 相机静止」的每帧开销拆到具体函数

目的：定位 handler 里每次都全库扫描的位置（行号见正文）。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

N = 1000


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 12)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("ProjMat")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    ns, H = 2, 0.5
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    cols = int(N ** 0.5)
    for i in range(N):
        mesh = bpy.data.meshes.new("G%d" % i)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new("Grid%d" % i, mesh)
        sc.collection.objects.link(ob)
        ob.location = ((i % cols) * 1.2 - cols * 0.6, (i // cols) * 1.2 - cols * 0.6, 0.0)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd


def bench(fn, n=5, label=""):
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        ts.append((time.perf_counter() - t0) * 1000.0)
    print("  %-46s 平均 %6.2f ms  (n=%d)" % (label, sum(ts) / len(ts), n))
    return sum(ts) / len(ts)


sc, cam, cd = build()
plock._proj_cache.clear()
plock.lock_group(sc, cam)
groups = plock.load_groups(sc)
st = groups[cd.name]
objs = plock.locked_objects(sc, cd.name, st)

print("场景：%d 个网格，相机静止，无人拖动" % N)
bench(lambda: plock._proj_signature(), 5, "_proj_signature()  (行537 全库扫)")
bench(lambda: plock.objects_using_projection(cd.name), 5,
      "objects_using_projection()  (行585 全库扫+节点树)")
bench(lambda: plock.objects_using_projection_cached(cd.name), 5,
      "objects_using_projection_cached()")
bench(lambda: plock.locked_objects(sc, cd.name, st), 5,
      "locked_objects()  (行2984 全库扫)")
bench(lambda: plock.load_groups(sc), 5, "load_groups()  (json.loads 每帧)")
bench(lambda: plock.save_groups(sc, groups), 5, "save_groups()  (json.dumps)")
view = plock.get_camera_view_matrix(cam)


def move_all():
    for o in objs:
        plock.apply_user_move(o, cam, view)


bench(move_all, 5, "apply_user_move() × %d（拖动检测）" % len(objs))


def selfheal():
    plock._selfheal_and_backfill(sc, cam, st, cd.name)


bench(selfheal, 5, "_selfheal_and_backfill()")
bench(lambda: plock.parallax_lock_update_handler(sc), 12, "整套 handler（静止帧）")

# 静止帧里到底扫了几次全库？
CNT = {"full": 0, "cached": 0, "sig": 0, "lock": 0, "load": 0}
_o = {}
for nm, d in (("objects_using_projection", "full"),
              ("objects_using_projection_cached", "cached"),
              ("_proj_signature", "sig"), ("locked_objects", "lock"),
              ("load_groups", "load")):
    _o[d] = getattr(plock, nm)

    def wrap(*a, _d=d, _orig=_o[d], **k):
        CNT[_d] += 1
        return _orig(*a, **k)
    setattr(plock, nm, wrap)

plock.parallax_lock_update_handler(sc)
print("\n单帧内调用次数：full=%d cached=%d _proj_signature=%d locked_objects=%d load_groups=%d"
      % (CNT["full"], CNT["cached"], CNT["sig"], CNT["lock"], CNT["load"]))
