"""验证 UV 偏移方案（真渲染 + UV 数值双判据）
判据：
  1. 解锁那一帧：画面像素差 ≈ 0（不跳）
  2. 解锁后再移相机：画面变化 > 0（图案滑动）
  3. 几何 / 深度 / 位姿 完全没动
  4. 换材质 / 重置 仍正常
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
MU = __import__("mathutils")

OUT = os.path.dirname(os.path.abspath(__file__))
RES = 200
P, F = [], []


def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-46s %s" % ("PASS" if cond else "FAIL", name, detail))


def make_checker(size=256, cells=8):
    img = bpy.data.images.new("Chk", size, size, alpha=False)
    px = np.zeros((size, size, 4), dtype=np.float32)
    cell = size // cells
    for y in range(size):
        row = (y // cell) % 2
        for x in range(size):
            on = ((x // cell) + row) % 2 == 0
            v = 0.95 if on else 0.05
            px[y, x] = (v, v, v, 1.0)
    img.pixels.foreach_set(px.reshape(-1))
    img.pack()
    return img


def build(half=7.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass

    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    img = make_checker()
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
    nt.links.new(tex.outputs["Color"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    mesh = bpy.data.meshes.new("Grid")
    ns = 4
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((-half + 2*half*ix/ns, -half + 2*half*iy/ns, 0.0))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob, mat


_seq = [0]
def render_to(tag):
    _seq[0] += 1
    path = os.path.join(OUT, "_uvd_%s_%02d.png" % (tag, _seq[0]))
    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(path)
    n = im.size[0]*im.size[1]*4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :3].copy()
    bpy.data.images.remove(im)
    return a


def pixdiff(a, b):
    d = np.abs(a - b)
    return float(d.max()), float((d.max(axis=2) > 0.02).mean() * 100)


def geom(cam, ob):
    vi = cam.matrix_world.inverted()
    zs, ws = [], []
    for v in ob.data.vertices:
        w = ob.matrix_world @ v.co
        ws.append(tuple(w))
        zs.append((vi @ w).z)
    return np.array(ws), np.array(zs)


print("=" * 78)
print("UV 偏移方案验证")
print("=" * 78)
sc, cam, cd, ob, mat = build()

print("\n[1] 锁定 → 移相机 → 解锁")
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

w0, z0 = geom(cam, ob)
pose0 = ob.matrix_world.copy()
img_locked = render_to("locked")

r = plock.unlock_group(sc, cam)
print("   unlock:", r["message"])
bpy.context.view_layer.update()

w1, z1 = geom(cam, ob)
pose1 = ob.matrix_world.copy()
img_unlocked = render_to("unlocked")

mx, pct = pixdiff(img_locked, img_unlocked)
chk("1 解锁那一帧画面不跳", pct < 0.5, "变化像素 %.2f%% (max=%.3f)" % (pct, mx))

dg = float(np.abs(w1 - w0).max())
dz = float(np.abs(z1 - z0).max())
dp = (pose1.translation - pose0.translation).length
chk("2 几何没被动过", dg < 1e-6, "顶点世界坐标变化 %.8f" % dg)
chk("3 深度没被动过", dz < 1e-6, "相机空间 z 变化 %.8f" % dz)
chk("4 位姿没被动过", dp < 1e-8, "matrix_world 位移 %.8f" % dp)
print("   （delta 属性: %s）" % (
    "已写" if ob.data.attributes.get(plock.UV_DELTA_ATTR) is not None else "未写"))

print("\n[2] 解锁后再移相机 → 图案应滑动")
cam.location.x = 3.0
bpy.context.view_layer.update()
img_after = render_to("after")
mx2, pct2 = pixdiff(img_unlocked, img_after)
chk("5 解锁后移相机图案滑动", pct2 > 0.5, "变化像素 %.2f%%" % pct2)

print("\n[3] 重新锁定 → 应回到冻结（无 delta 残留）")
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
chk("6 重新锁定清掉了 UV 偏移", ob.data.attributes.get(plock.UV_DELTA_ATTR) is None)
img_relock = render_to("relock")
cam.location.x = 3.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
img_relock2 = render_to("relock2")
mx3, pct3 = pixdiff(img_relock, img_relock2)
chk("7 锁定中图案仍冻结", pct3 < 0.5, "变化像素 %.2f%%" % pct3)

print("\n[4] 重置还原")
orig = np.array([tuple(v.co) for v in ob.data.vertices])
plock.reset_group(sc, cam)
bpy.context.view_layer.update()
dev = float(np.abs(np.array([tuple(v.co) for v in ob.data.vertices]) - orig).max())
chk("8 重置后几何还原", dev < 1e-5, "偏差 %.8f" % dev)
chk("9 重置清掉 UV 偏移", ob.data.attributes.get(plock.UV_DELTA_ATTR) is None)

print()
print("=" * 78)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("UVDELTA_DONE")
