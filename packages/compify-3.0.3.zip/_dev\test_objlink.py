"""验证 object-linked 材质槽修复

场景：A 网格材质 data-linked（默认），B 网格同一材质但槽链接改成 OBJECT。
锁定后两者都该拿到冻结坐标属性。

判据区分力：故意跳过修复（只扫 data.materials）时，B 必须缺属性。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-52s %s" % ("PASS" if c else "FAIL", n, d))


def build():
    """造出「旧实现真的会漏」的场景：
        共享同一个 mesh，mesh 材质 = 普通材质（非投影）
        物体 GridB 用 OBJECT link 覆盖成【投影材质】
       ⇒ GridB.data.materials 只有普通材质，但实际渲染用投影材质
       ⇒ 旧实现（只扫 data.materials）漏掉 GridB ⇒ 图案不冻结
    """
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

    proj = bpy.data.materials.new("Proj"); proj.use_nodes = True
    nt = proj.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    plain = bpy.data.materials.new("Plain"); plain.use_nodes = True

    def meshmk(name, x0):
        ns = 2; h = 1.2
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns, -h + 2 * h * iy / ns, 0.0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        return mesh

    # GridA：独占 mesh，data 直接挂投影材质（常规用法）
    meA = meshmk("mA", -2.0)
    meA.materials.append(proj)
    A = bpy.data.objects.new("GridA", meA)
    sc.collection.objects.link(A)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (meA.name, cd.name),
                             "ShaderNodeTree")

    # GridB：独占 mesh，data 挂【普通材质】，靠 OBJECT link 覆盖成投影材质
    meB = meshmk("mB", 1.5)
    meB.materials.append(plain)
    B = bpy.data.objects.new("GridB", meB)
    sc.collection.objects.link(B)
    B.material_slots[0].link = "OBJECT"
    B.material_slots[0].material = proj
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (meB.name, cd.name),
                             "ShaderNodeTree")

    bpy.context.view_layer.update()
    return sc, cam, cd, proj, A, B


def has_campos(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    return a is not None and len(a.data) == len(ob.data.vertices)


print("=" * 84)
print("场景准备")
print("=" * 84)
sc, cam, cd, mat, A, B = build()
print("  GridA 材质槽 link =", A.material_slots[0].link)
print("  GridB 材质槽 link =", B.material_slots[0].link)
print("  A.data.materials =", [m.name if m else None for m in A.data.materials])
print("  B.data.materials =", [m.name if m else None for m in B.data.materials],
      " <- object-linked 时这里是空的")
print("  B.material_slots[0].material =", B.material_slots[0].material.name)

print()
print("=" * 84)
print("[1] objects_using_projection 是否包含 B")
print("=" * 84)
found = plock.objects_using_projection(cd.name)
names = sorted(o.name for o in found)
print("  找到的对象:", names)
chk("A（data-linked）被识别", "GridA" in names)
chk("B（object-linked）被识别", "GridB" in names, "names=%s" % names)

print()
print("=" * 84)
print("[2] 锁定后两个网格都该有冻结坐标")
print("=" * 84)
r = plock.lock_group(sc, cam)
print("  锁定消息:", str(r.get("message", ""))[:70])
print("  frozen=%s locked=%s" % (
    r.get("frozen"), [o.name for o in (r.get("locked") or [])]))
print("  GridA 有 campos:", has_campos(A, cd))
print("  GridB 有 campos:", has_campos(B, cd))
chk("GridA 有冻结坐标", has_campos(A, cd))
chk("GridB 有冻结坐标（本次修复重点）", has_campos(B, cd))

print()
print("=" * 84)
print("[3] 判据区分力：旧实现（只扫 data.materials）必须漏掉 GridB")
print("=" * 84)
_b_data = [m.name if m else None for m in B.data.materials]
_b_slot = [(s.link, s.material.name if s.material else None) for s in B.material_slots]
print("  GridB.data.materials =", _b_data, " <- 旧实现只看这里")
print("  GridB.material_slots =", _b_slot, " <- 实际生效的是这个")
chk("旧实现看不到投影材质（证明测试有区分力）",
    all(m != "Proj" for m in _b_data), "data=%s" % _b_data)
chk("实际生效的材质是投影材质",
    any(s[1] == "Proj" for s in _b_slot), "slots=%s" % _b_slot)

print("=" * 84)
print("[4] B 的冻结坐标内容是否正确（不是写了就算）")
print("=" * 84)
a_b = B.data.attributes.get(plock._campos_attr_name(cd.name))
if a_b is not None and len(a_b.data):
    n = len(a_b.data)
    buf = np.empty(n * 3, dtype=np.float64)
    a_b.data.foreach_get("vector", buf)
    v = buf.reshape(-1, 3)
    print("  n=%d  nan=%s  inf=%s  z∈[%.3f, %.3f]" % (
        n, np.isnan(v).any(), np.isinf(v).any(), v[:, 2].min(), v[:, 2].max()))
    chk("B 的冻结坐标非零且有限", (not np.isnan(v).any()) and (not np.isinf(v).any())
        and float(np.abs(v[:, :2]).max()) > 1e-6,
        "UV max=%.4f" % float(np.abs(v[:, :2]).max()))
    # 校验：B 的冻结 UV 应等于「按锁定相机投影 B 的当前顶点」
    inv = cam.matrix_world.inverted()
    ok = True
    worst = 0.0
    for i, vt in enumerate(B.data.vertices):
        p = inv @ (B.matrix_world @ vt.co)
        if abs(p.z) < 1e-9:
            continue
        exp = (p.x / p.z, p.y / p.z)
        got = (v[i, 0] / v[i, 2] if abs(v[i, 2]) > 1e-9 else 0,
               v[i, 1] / v[i, 2] if abs(v[i, 2]) > 1e-9 else 0)
        d = max(abs(exp[0] - got[0]), abs(exp[1] - got[1]))
        worst = max(worst, d)
        if d > 1e-4:
            ok = False
    print("  与「按锁定相机投影」的最大差 = %.8f" % worst)
    chk("B 的冻结坐标与锁定相机投影一致", ok, "max Δ=%.8f" % worst)
else:
    chk("B 的冻结坐标写入", False)

print()
print("=" * 84)
print("[5] 解锁后 B 也应被正确复原")
print("=" * 84)
r2 = plock.unlock_group(sc, cam)
print("  解锁消息:", str(r2.get("message", ""))[:70])
left = B.data.attributes.get(plock._campos_attr_name(cd.name))
chk("B 的冻结坐标已清理", left is None)

print()
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("OBJ_LINK_DONE")
