"""决定性实验：移相机时，A/B 的【世界位置】跟着相机走了吗？

用户反馈：
  「移动相机时 A 和 B 没有跟着一起适配，AB 是实时适配相机的视锥体的」

之前我只测了【屏幕位移】（A/B 都是 -0.1736，一致 → 构图保持）。
但没测【世界位移】—— 而"跟着相机适配"恰恰体现在世界位置要跟着动。

PSD 的做法（parallax_utils.py L711-718）：
    k     = locked_depth / ref_depth
    Δcs   = 相机位移在相机空间的分量
    D     = locked_depth * dolly * zoom
    local = (x0 - Δcs.x·k, y0 - Δcs.y·k, -D)
    world = camera.matrix_world @ local        ← ★【当前】相机矩阵
⇒ 世界位置 = 当前相机矩阵 × 相机空间坐标 ⇒ 图层跟着相机一起动。

判据：
  · 若 A/B 世界位移 ≈ 相机位移           ⇒ 完全跟随（刚性）
  · 若世界位移 = 相机位移 × (1 - k)      ⇒ PSD 的「按深度部分跟随」
  · 若世界位移 ≈ 0                       ⇒ 留在原地（没适配）
"""
import bpy, sys, os
import importlib.util
import numpy as np
from bpy_extras.object_utils import world_to_camera_view

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

# A/B 放在同一条视线上（屏幕 x 相同），只有深度不同
SCREEN_X = 0.2
DA, DB = 8.0, 6.0


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.resolution_x = 640
    sc.render.resolution_y = 640
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 10); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, wx, depth):
        z0 = 10.0 - depth
        h = 0.35
        verts = [(wx - h, -h, z0), (wx + h, -h, z0),
                 (wx + h, h, z0), (wx - h, h, z0)]
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], [(0, 1, 2, 3)]); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("A", SCREEN_X * DA, DA)
    B = mk("B", SCREEN_X * DB, DB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def wc(ob):
    mw = ob.matrix_world
    return np.array([list(mw @ v.co) for v in ob.data.vertices]).mean(axis=0)


def scr(ob, cam, sc):
    p = np.array([list(world_to_camera_view(sc, cam, ob.matrix_world @ v.co))[:2]
                  for v in ob.data.vertices])
    return p.mean(axis=0)


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


print("=" * 92)
print("Setup：A 深度%.0f（世界x=%.2f） / B 深度%.0f（世界x=%.2f），同一视线" % (
    DA, SCREEN_X * DA, DB, SCREEN_X * DB))
print("=" * 92)

for tag, dx in [("相机横移 +1.0", 1.0), ("相机横移 +2.0", 2.0)]:
    print("\n" + "=" * 92)
    print("【%s】" % tag)
    print("=" * 92)
    sc, cam, cd, A, B = build()
    r = plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    ref = st.get("ref_depth", 0)
    wA0 = wc(A); wB0 = wc(B)
    sA0 = scr(A, cam, sc); sB0 = scr(B, cam, sc)
    print("  锁定：ref_depth=%.2f" % ref)
    print("  锁定世界位置:  A x=%+.6f   B x=%+.6f" % (wA0[0], wB0[0]))

    cam.location.x += dx
    step(sc)

    wA1 = wc(A); wB1 = wc(B)
    sA1 = scr(A, cam, sc); sB1 = scr(B, cam, sc)

    kA = DA / ref
    kB = DB / ref
    print("\n  相机移动量 Δ = %+.4f" % dx)
    print("  %-6s %14s %14s %14s %14s" % (
        "物体", "世界Δx（实测）", "相机Δ×(1-k)", "世界Δx是否跟随", "屏幕Δx"))
    for nm, w0, w1, s0, s1, k in (("A", wA0, wA1, sA0, sA1, kA),
                                  ("B", wB0, wB1, sB0, sB1, kB)):
        dwx = w1[0] - w0[0]
        expect_psd = dx * (1.0 - k)     # PSD 语义：世界位移 = Δ(1-k)
        dsx = s1[0] - s0[0]
        print("  %-6s %+14.8f %+14.8f %14s %+14.8f" % (
            nm, dwx, expect_psd,
            "✓" if abs(dwx - expect_psd) < 1e-6 else "✗ 差%.6f" % (dwx - expect_psd),
            dsx))
        print("         (k=%.4f  相机Δ×k=%+.6f  相机Δ×1=%+.6f)" % (k, dx * k, dx))

    print("\n  判定：")
    print("    · 世界位移 ≈ 0            ⇒ 留在原地（没适配）")
    print("    · 世界位移 ≈ Δ×(1-k)      ⇒ PSD 语义：按深度【部分跟随】")
    print("    · 世界位移 ≈ Δ（全部跟随） ⇒ 刚性跟随（画面完全不动）")
    print("    实测 A 世界位移 = %+.8f  （Δ×(1-kA) = %+.8f，Δ = %+.4f）" % (
        wA1[0] - wA0[0], dx * (1.0 - kA), dx))

print()
print("=" * 92)
print("补充：PSD 公式独立复算（不经过 compify 代码），看两边是否一致")
print("=" * 92)
sc, cam, cd, A, B = build()
plock.lock_group(sc, cam)
st = plock.get_state(sc, cam)
ref = st.get("ref_depth", 0.0)
vw_locked = plock.get_camera_view_matrix(cam)
# 记录锁定时刻的相机空间坐标（PSD 的 x0 / locked_depth）
camA0 = vw_locked @ (A.matrix_world @ A.data.vertices[0].co)
camB0 = vw_locked @ (B.matrix_world @ B.data.vertices[0].co)
print("  锁定相机空间:  A (%.4f, %.4f, %.4f)   B (%.4f, %.4f, %.4f)" % (
    camA0.x, camA0.y, camA0.z, camB0.x, camB0.y, camB0.z))

dx = 1.0
cam.location.x += dx
bpy.context.view_layer.update()
vw_now = plock.get_camera_view_matrix(cam)
eye_delta = cam.matrix_world.translation - vw_locked.inverted().translation if False else None

# PSD 公式：Δcs = 相机位移在当前相机空间分量
# 这里相机不转，所以 Δcs = (Δx, 0, 0) 在相机空间
d_cs = np.array([dx, 0.0, 0.0])

for nm, c0, d0 in (("A", camA0, DA), ("B", camB0, DB)):
    k = d0 / ref
    D = d0 * 1.0 * 1.0          # dolly=1, zoom=1
    local = np.array([c0.x - d_cs[0] * k, c0.y - d_cs[1] * k, -D, 1.0])
    world_psd = cam.matrix_world @ __import__("mathutils").Vector(local[:3])
    print("  %s: k=%.4f  PSD 公式算出的世界 x = %+.6f" % (nm, k, world_psd.x))

print()
print("  实测（compify 跑完 handler 后）:")
print("    A 顶点0 世界 x = %+.6f" % (A.matrix_world @ A.data.vertices[0].co).x)
print("    B 顶点0 世界 x = %+.6f" % (B.matrix_world @ B.data.vertices[0].co).x)
print("CAMADAPT3_DONE")
