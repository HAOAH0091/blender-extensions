"""接缝连续性检验（直接对应「A 和 B 的贴图状态是否一致」）

把 A、B 两个网格【紧贴】摆放（A 右边缘 == B 左边缘，同一世界点、同一深度）。
若两者都按同一个（锁定）相机投射，接缝处图案必须连续；
若 B 用当前相机、A 用锁定相机，接缝处图案会错开。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

OUT = os.path.dirname(os.path.abspath(__file__))
RES = 300
P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-46s %s" % ("PASS" if c else "FAIL", n, d))


def make_checker(size=256, cells=8):
    img = bpy.data.images.new("Chk", size, size, alpha=False)
    px = np.zeros((size, size, 4), dtype=np.float32)
    cell = size // cells
    for y in range(size):
        for x in range(size):
            on = ((x // cell) + (y // cell)) % 2 == 0
            v = 0.95 if on else 0.05
            px[y, x] = (v, v, v, 1.0)
    img.pixels.foreach_set(px.reshape(-1))
    img.pack()
    return img


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = RES; sc.render.resolution_y = RES
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = "PNG"
sc.view_settings.view_transform = "Standard"
try: sc.eevee.taa_render_samples = 1
except Exception: pass

cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

img = make_checker()
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

H = 1.2
# A: [-2.4, 0]，B: [0, 2.4] —— 接缝在世界 x=0, z=0
A = None
for name, x0 in (("GridA", -2.4), ("GridB", 0.0)):
    Ns = 3
    verts, faces = [], []
    for iy in range(Ns+1):
        for ix in range(Ns+1):
            verts.append((x0 + 2.4*ix/Ns, -H + 2*H*iy/Ns, 0.0))
    for iy in range(Ns):
        for ix in range(Ns):
            a = iy*(Ns+1)+ix
            faces.append((a, a+1, a+Ns+2, a+Ns+1))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new(name, mesh)
    sc.collection.objects.link(ob)
    if name == "GridA":
        A = ob
    else:
        B = ob
A.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()


def uv_at(ob, cam_matrix):
    """按投影组算 UV（当前会读到什么就返回什么）"""
    patched = plock.is_patched(cd.name)
    if patched:
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                              a.data[i].vector[1]/a.data[i].vector[2])
                             for i in range(len(a.data))])
    m = cam_matrix.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    out = np.array(out)
    d = ob.data.attributes.get(plock.UV_DELTA_ATTR)
    if d is not None and len(d.data) == len(ob.data.vertices):
        dd = np.array([(d.data[i].vector[0], d.data[i].vector[1]) for i in range(len(d.data))])
        out = out + dd
    return out


def seam_uv(ob, cam_matrix):
    """取该网格在接缝处的两个顶点（世界 x=0 那条边）的 UV，按 y 排序返回"""
    m = cam_matrix.inverted()
    rows = []
    for i, v in enumerate(ob.data.vertices):
        w = ob.matrix_world @ v.co
        if abs(w.x) < 1e-6:
            rows.append((w.y, i))
    rows.sort()
    uv = uv_at(ob, cam_matrix)
    return np.array([uv[i] for _, i in rows])


_seq = [0]
def render(tag):
    _seq[0] += 1
    path = os.path.join(OUT, "_seam_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    for o in (A, B):
        o.data.update_tag()
    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get().update()
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(path)
    n = im.size[0]*im.size[1]*4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :3].copy()
    bpy.data.images.remove(im)
    return a


print("=" * 78)
print("接缝连续性：A[-2.4,0] 与 B[0,2.4] 紧贴，接缝在世界 x=0")
print("=" * 78)
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("\n解锁:", plock.unlock_group(sc, cam)["message"])
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

cam_now = cam.matrix_world.copy()
sa = seam_uv(A, cam_now)
sb = seam_uv(B, cam_now)
gap = float(np.abs(sa - sb).max())
print("\n  A 接缝 UV:\n%s" % np.round(sa, 5))
print("  B 接缝 UV:\n%s" % np.round(sb, 5))
chk("接缝处 A/B 图案连续（同一构图层次）", gap < 1e-4, "最大差 %.8f" % gap)

r = render("committed")
print("  渲染完成: _seam_committed")

# 对照：故意去掉 B 的 delta（还原成「未落实」的原状），看接缝是否错开
_bd = B.data.attributes.get(plock.UV_DELTA_ATTR)
if _bd is not None:
    B.data.attributes.remove(_bd)
bpy.context.view_layer.update()
sa2 = seam_uv(A, cam_now)
sb2 = seam_uv(B, cam_now)
gap2 = float(np.abs(sa2 - sb2).max())
print("\n  【对照】去掉 B 的 delta（修复前的状态）:")
print("    A 接缝 UV[0]=%s  B 接缝 UV[0]=%s" % (np.round(sa2[0], 5), np.round(sb2[0], 5)))
print("    接缝错开 = %.6f" % gap2)
chk("对照：去掉 delta 后接缝确实错开（判据有区分力）", gap2 > 1e-3, "差 %.6f" % gap2)
r2 = render("broken")
print("  渲染完成: _seam_broken")

print()
print("=" * 78)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("SEAM_DONE")
