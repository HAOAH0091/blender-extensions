"""测 EXR 通道精度：渲染常量 0.75，读回看是否被量化成 8bit。"""
import bpy, os, sys
import numpy as np
sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = sc.render.resolution_y = 8
sc.render.film_transparent = False
mat = bpy.data.materials.new("M"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
emi = nt.nodes.new("ShaderNodeEmission")
emi.inputs["Color"].default_value = (0.75, 0.3, 0.1, 1.0)
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
bpy.ops.mesh.primitive_plane_add(size=100)
ob = bpy.context.object
ob.data.materials.append(mat)
cam = bpy.data.objects.new("C", bpy.data.cameras.new("C"))
sc.collection.objects.link(cam); cam.location = (0, 0, 5); sc.camera = cam

for fmt, depth in (("OPEN_EXR", "32"), ("OPEN_EXR", "16")):
    sc.render.image_settings.file_format = fmt
    sc.render.image_settings.color_depth = depth
    sc.render.image_settings.color_mode = "RGBA"
    p = os.path.join(HERE, "_rc_prec_%s.exr" % depth)
    sc.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    buf = np.empty(im.size[0] * im.size[1] * 4, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(-1, 4)[0]
    print("  %s depth=%s → loaded depth=%s is_float=%s 像素=(%.6f, %.6f, %.6f, %.3f)  cs=%s"
          % (fmt, depth, im.depth, im.is_float, a[0], a[1], a[2], a[3],
             im.colorspace_settings.name))
    bpy.data.images.remove(im)
    os.remove(p)

# 直接检查渲染结果的内部值（不经过文件）
sc.render.image_settings.file_format = "OPEN_EXR"
res = bpy.data.images.get("Render Result")
print("  期望 0.75/0.30/0.10")
print("PREC_DONE")
