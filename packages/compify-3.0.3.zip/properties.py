# ====================== BEGIN GPL LICENSE BLOCK ======================
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ======================= END GPL LICENSE BLOCK ========================

"""Shared utilities for Compify (redraw helpers, etc.)."""


def redraw_viewport(context):
    """Tag all 3D Viewport areas for redraw.

    Extracted as a shared helper because the same loop appeared
    in 6+ operators.
    """
    # ⚠️ 加 None 守卫（独立审查 第七轮 N-1）：`--background` / 无 window 的
    #    invoke 上下文里 `context.window` 或 `.screen` 可能是 None，
    #    原来会抛 `AttributeError`，把调用它的 operator 整个打断
    #    （它已经有 9 个调用点，包含新加的面板 operator）。
    try:
        win = getattr(context, "window", None)
        screen = getattr(win, "screen", None) if win is not None else None
        if screen is None:
            return
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()
    except Exception:
        pass
