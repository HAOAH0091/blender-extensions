"""审查E-5b：3000 网格时的逐项拆解（E-1b 空闲帧 218 ms 到底是哪来的）

同时量一个「裸扫 bpy.data.objects + o.get()」的基线，把 RNA 开销与插件开销分开。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

N = 3000
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 14)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
ns, H = 2, 0.4
verts, faces = [], []
for iy in range(ns + 1):
    for ix in range(ns + 1):
        verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy * (ns + 1) + ix
        faces.append((a, a + 1, a + ns + 2, a + ns + 1))
for i in range(N):
    me = bpy.data.meshes.new("G%d" % i)
    me.from_pydata(verts, [], faces)
    me.update()
    o = bpy.data.objects.new("Grid%d" % i, me)
    sc.collection.objects.link(o)
    o.location = ((i % 60) * 0.9 - 27, (i // 60) * 0.9, 0.0)
    o.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
groups = plock.load_groups(sc)
st = groups[cd.name]
objs = plock.locked_objects(sc, cd.name, st)
view = plock.get_camera_view_matrix(cam)


def bench(fn, n=4, label=""):
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        ts.append((time.perf_counter() - t0) * 1000.0)
    print("  %-50s %7.2f ms" % (label, sum(ts) / len(ts)))


print("对象数 = %d（锁定 %d 个）" % (N, len(objs)))


def bare_scan():
    cnt = 0
    for o in bpy.data.objects:
        if o.type == "MESH" and o.data is not None:
            cnt += 1
    return cnt


def bare_get():
    cnt = 0
    for o in bpy.data.objects:
        if o.get("compify_plock_camera"):
            cnt += 1


bench(bare_scan, 4, "基线：裸扫 bpy.data.objects（只看 type/data）")
bench(bare_get, 4, "基线：裸扫 + o.get(OBJ_CAM_KEY)")
bench(lambda: plock.locked_objects(sc, cd.name, st), 4, "locked_objects()  行2984")
bench(lambda: plock._proj_signature(), 4, "_proj_signature()  行537")
bench(lambda: plock.objects_using_projection(cd.name), 4, "objects_using_projection()  行585")
bench(lambda: plock.objects_using_projection_cached(cd.name), 4,
      "objects_using_projection_cached()")
bench(lambda: plock._selfheal_and_backfill(sc, cam, st, cd.name), 4,
      "_selfheal_and_backfill()")


def move_all():
    for o in objs:
        plock.apply_user_move(o, cam, view)


bench(move_all, 4, "apply_user_move() × %d" % len(objs))
bench(lambda: plock.parallax_lock_update_handler(sc), 8, "整套 handler（静止帧）")
