"""验证修复思路（不改进源码，用 monkey-patch 试）
问题3: drag = k（k 已是绝对比），而非 drag *= k
问题2: _write_campos_attribute 加编辑模式守卫 + _campos_is_valid 区分"编辑模式不可读"
问题1: get_lock_targets 并上 objects_using_projection
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_fix"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    return scene, cam, cd

def make_mat(cd, name):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    return m

def make_grid(name, z, x, w=1.0, ns=2):
    mesh = bpy.data.meshes.new(name)
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((x-w+2*w*ix/ns, -1+2*iy/ns, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    o = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(o)
    return o


print("="*74)
print("【问题3 修复验证】drag = k 而非 drag *= k")
print("  做法：等 k 累积一次后，把 drag 覆写为 k（模拟 drag = k）")

from mathutils import Matrix

def apply_user_move_FIXED(obj, camera, view_now):
    """修复版：drag = k（绝对），而不是 *= k"""
    if not PL.LAYER_MOVE_ENABLED:
        return False
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    M_prev = PL._read_matrix_key(obj)
    if M_prev is None:
        PL._write_matrix_key(obj, obj.matrix_world.copy())
        return False
    M_cur = obj.matrix_world.copy()
    if PL._mat_close(M_cur, M_prev):
        return False
    view_inv = view_now.inverted()
    c_local = PL._mesh_center_local(obj)
    d_prev = PL._view_depth(view_inv, M_prev @ c_local)
    d_cur = PL._view_depth(view_inv, M_cur @ c_local)
    if d_prev <= PL.MIN_DEPTH:
        PL._write_matrix_key(obj, M_cur); return False
    if d_cur <= PL.MIN_DEPTH:
        obj.matrix_world = M_prev
        bpy.context.view_layer.update(); return False
    k = d_cur / d_prev
    if abs(k - 1.0) <= 1e-9:
        obj.matrix_world = M_prev
        bpy.context.view_layer.update(); return False
    # ★ 关键：k 是相对锁定位姿的绝对倍率 ⇒ 直接赋值
    obj[PL.DRAG_SCALE_KEY] = float(k)
    obj.matrix_world = M_prev
    bpy.context.view_layer.update()
    return True

for name, fn, label in [("未修复", PL.apply_user_move, "drag *= k"),
                        ("修复后", apply_user_move_FIXED, "drag = k")]:
    print("\n  --- %s（%s）---" % (name, label))
    scene, cam, cd = build()
    mp = make_mat(cd, "M_" + name)
    obj = make_grid("G", 0.0, 0.0)
    obj.data.materials.append(mp)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    PL.lock_group(scene, cam)
    M0 = obj.matrix_world.copy()
    c_local = PL._mesh_center_local(obj)
    view = PL.get_camera_view_matrix(cam)
    d0 = PL._view_depth(view.inverted(), M0 @ c_local)
    print("    帧  拖动量    drag(实际)   drag(应为)   偏差")
    for f in range(8):
        dz = 0.05 * (f + 1)
        Mc = M0.copy(); Mc.translation.z = M0.translation.z + dz
        obj.matrix_world = Mc
        bpy.context.view_layer.update()
        vn = PL.get_camera_view_matrix(cam)
        dc = PL._view_depth(vn.inverted(), Mc @ c_local)
        expect = dc / d0
        fn(obj, cam, vn)
        drag = obj.get(PL.DRAG_SCALE_KEY)
        print("    %2d  %+7.3f  %11.6f  %10.6f   %+7.1f%%" %
              (f+1, dz, drag, expect, (drag/expect-1)*100 if expect else 0))
