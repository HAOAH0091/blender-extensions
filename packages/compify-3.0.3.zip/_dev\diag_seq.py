"""全面序列测试：找出「解锁后投影没效果」到底哪种操作触发
顺带检查我的修复是否引入副作用（编辑模式改拓扑后属性不更新）
"""
import bpy, sys, os, bmesh
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_seq"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]


def build(nobj=1):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    m = bpy.data.materials.new("ProjMat"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])

    objs = []
    for i in range(nobj):
        name = "Grid%d" % i
        mesh = bpy.data.meshes.new(name)
        x = -1.2 + 2.4 * i
        mesh.from_pydata([(x-0.8,-1,0),(x+0.8,-1,0),(x+0.8,1,0),(x-0.8,1,0)],
                         [], [(0,1,2,3)])
        mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        scene.collection.objects.link(ob)
        ob.data.materials.append(m)
        objs.append(ob)
    NG.create_uv_adjust_node_group(scene, cam, objs[0])
    return scene, cam, cd, m, objs


def uv_health(obj, cd):
    """投影 UV 是否健康：
       attr 存在且顶点数匹配且不全零 = 健康(冻结)
       attr 不存在 = 走实时 TexCoord（也健康，只要组已 unpatch）
       其他 = 坏
    """
    ng = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    patched = ng is not None and ng.get(PL.PATCH_KEY) is not None
    n = PL._campos_attr_name(cd.name)
    a = obj.data.attributes.get(n)
    if not patched:
        return "实时(未patch)", True
    if a is None:
        return "【坏】组已patch但无campos属性", False
    if len(a.data) != len(obj.data.vertices):
        return "【坏】campos顶点数 %d != 网格 %d" % (len(a.data), len(obj.data.vertices)), False
    allzero = True
    for i in range(len(a.data)):
        v = a.data[i].vector
        if abs(v[0])>1e-9 or abs(v[1])>1e-9 or abs(v[2])>1e-9:
            allzero = False; break
    if allzero:
        return "【坏】campos 全零", False
    return "冻结(健康)", True


def report(tag, objs, cd):
    print("  %-32s" % tag)
    for o in objs:
        s, ok = uv_health(o, cd)
        print("      %-8s %s" % (o.name, s))


print("="*80)
print("序列 A：单网格 锁定→解锁→移相机→重锁→解锁")
print("="*80)
scene, cam, cd, m, objs = build(1)
A = objs[0]
print("  lock:", PL.lock_group(scene, cam).get("message"))
report("锁定后", objs, cd)
print("  unlock:", PL.unlock_group(scene, cam).get("message")[:20])
report("解锁后", objs, cd)
cam.location = (1.5, 0, 5.0); bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
report("移相机后", objs, cd)
print("  lock:", PL.lock_group(scene, cam).get("message"))
report("重新锁定后", objs, cd)
print("  unlock:", PL.unlock_group(scene, cam).get("message")[:20])
report("再次解锁后", objs, cd)

print("\n" + "="*80)
print("序列 B：锁定→解锁→编辑模式加顶点→退出（检查我的修复是否有副作用）")
print("="*80)
scene, cam, cd, m, objs = build(1)
A = objs[0]
PL.lock_group(scene, cam)
report("锁定后", objs, cd)
PL.unlock_group(scene, cam)
report("解锁后", objs, cd)

bpy.context.view_layer.objects.active = A
A.select_set(True)
bpy.ops.object.mode_set(mode='EDIT')
bm = bmesh.from_edit_mesh(A.data)
# 加一个新顶点（改拓扑）
bm.verts.new((3.0, 0.0, 0.0))
bmesh.update_edit_mesh(A.data)
print("    编辑模式：加了 1 个顶点，现在 bm 顶点数 =", len(bm.verts))
bpy.ops.object.mode_set(mode='OBJECT')
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
print("    退出后网格顶点数 =", len(A.data.vertices))
report("加顶点退出后", objs, cd)

print("\n" + "="*80)
print("序列 C：锁定态下编辑模式加顶点（我自己修复的边界）")
print("="*80)
scene, cam, cd, m, objs = build(1)
A = objs[0]
PL.lock_group(scene, cam)
report("锁定后", objs, cd)
bpy.context.view_layer.objects.active = A
A.select_set(True)
bpy.ops.object.mode_set(mode='EDIT')
bm = bmesh.from_edit_mesh(A.data)
bm.verts.new((3.0, 0.0, 0.0))
bmesh.update_edit_mesh(A.data)
bpy.ops.object.mode_set(mode='OBJECT')
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
for _ in range(2):
    PL.parallax_lock_update_handler(scene)
print("    网格顶点数 =", len(A.data.vertices))
report("锁定态加顶点后", objs, cd)
