"""回归网（第十一轮）：半损坏存档健壮性 + 父级极端变焦 + 量具自检。

⚠️ 本文件还固化一条【量具知识】（防止未来重犯）：
   `--background` 下 `view_layer.update()` **不会**触发 `depsgraph_update_post`
   （即使 handler 已注册）。必须**显式调** `parallax_lock_update_handler(scene)`。
   第十一轮审查员基于"update 会触发"这个错误假设驱动测试，
   导致 3 条假阳性（父级变焦/多相机适配/相机串扰）。
   我自己也犯过镜像错误（漏驱动 ⇒ 连无父级都测出假错）。
"""
import bpy
import sys
import os
import json
import math
import importlib.util
import mathutils as MU

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-56s %s" % ("PASS" if c else "FAIL", n, d))


def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    plock._proj_cache.clear()
    return bpy.context.scene


def drive(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def only_update(sc):
    bpy.context.view_layer.update()


def mkcam(sc, name="Cam", loc=(0.0, 0.0, 10.0), lens=50.0):
    cd = bpy.data.cameras.new(name); cd.lens = lens; cd.sensor_width = 36.0
    c = bpy.data.objects.new(name, cd)
    sc.collection.objects.link(c)
    c.location = loc; c.rotation_euler = (0.0, 0.0, 0.0)
    return c


def mkobjs(sc, cam, n=3, prefix="P", depths=(0.0, -2.0, -4.0)):
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("M" + prefix); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(g.outputs["Vector"], o.inputs["Surface"])
    out = []
    for i, z in enumerate(depths[:n]):
        bpy.ops.mesh.primitive_plane_add(size=6.0, location=(0.0, 0.0, z))
        ob = bpy.context.active_object; ob.name = "%s%d" % (prefix, i)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cam.data.name),
                                 "ShaderNodeTree")
        out.append(ob)
    bpy.context.view_layer.update()
    return out


def compose(objs, cam):
    loc, rot, _s = cam.matrix_world.decompose()
    v = MU.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()
    vi = v.inverted()
    f = cam.data.lens / cam.data.sensor_width
    out = []
    for ob in objs:
        pts = []
        for vt in ob.data.vertices:
            cs = vi @ (ob.matrix_world @ vt.co)
            d = -cs.z
            pts.append(None if d <= 1e-6 else (cs.x / d * f, cs.y / d * f))
        out.append(pts)
    return out


def maxdiff(a, b):
    m = 0.0
    for x, y in zip(a, b):
        if x is None or y is None:
            continue
        m = max(m, abs(x[0] - y[0]), abs(x[1] - y[1]))
    return m


# ═══ 1. 半损坏存档：不得抛异常 ═══
print("=" * 72)
print("1  半损坏存档（locked_matrix / ref_depth / locked_focal 被改坏）")
for case, desc in (("rows", "locked_matrix 只有 1 行"),
                   ("strs", "locked_matrix 元素是字符串"),
                   ("ref", "ref_depth 是字符串"),
                   ("focal", "locked_focal 是字符串"),
                   ("matkey", "对象上的 MATRIX_KEY 被改坏")):
    sc = fresh()
    cam = mkcam(sc); sc.camera = cam
    objs = mkobjs(sc, cam, 2, "Z")
    plock.lock_group(sc, cam)
    gs = json.loads(sc.get(plock.GROUPS_KEY))
    rec = dict(gs[cam.data.name])
    if case == "rows":
        rec["locked_matrix"] = [[1.0, 0.0, 0.0, 0.0]]
    elif case == "strs":
        rec["locked_matrix"] = [["a"] * 4 for _ in range(4)]
    elif case == "ref":
        rec["ref_depth"] = "x"
    elif case == "focal":
        rec["locked_focal"] = "y"
    gs[cam.data.name] = rec
    sc[plock.GROUPS_KEY] = json.dumps(gs)
    if case == "matkey":
        objs[0][plock.MATRIX_KEY] = ["a"] * 16
    cam.data.lens = 85.0                       # 让 handler 走到变焦分支
    bpy.context.view_layer.update()
    errs = []
    try:
        plock.reset_group(sc, cam)
    except Exception as e:
        errs.append("reset:%s" % type(e).__name__)
    for _fn, _tag in ((lambda: plock.parallax_lock_update_handler(sc), "handler"),
                      (lambda: plock.lock_status(sc, cam), "lock_status"),
                      (lambda: plock.find_orphan_locks(sc), "orphan")):
        try:
            _fn()
        except Exception as e:
            errs.append("%s:%s" % (_tag, type(e).__name__))
    chk("1 %s 不抛异常" % desc, not errs, str(errs) if errs else "ok")

# ═══ 2. 父级相机 + 极端变焦：构图必须冻结 ═══
print()
print("=" * 72)
print("2  父级相机（Ctrl+P Keep Transform）+ 极端变焦 400mm：构图冻结")
for mode, tag in ((None, "无父级"), ("keep", "Ctrl+P Keep Transform")):
    for lens1 in (85.0, 400.0):
        sc = fresh()
        cam = mkcam(sc, loc=(0.0, 0.0, 10.0))
        sc.camera = cam
        if mode == "keep":
            emp = bpy.data.objects.new("Emp", None)
            sc.collection.objects.link(emp)
            emp.location = (3.0, 1.0, 0.0)
            emp.rotation_euler = (math.radians(30), 0.0, math.radians(20))
            bpy.context.view_layer.update()
            keep = cam.matrix_world.copy()
            cam.parent = emp
            cam.matrix_parent_inverse = emp.matrix_world.inverted()
            cam.matrix_world = keep
            bpy.context.view_layer.update()
        objs = mkobjs(sc, cam, 3, "Q")
        plock.lock_group(sc, cam)
        s0 = compose(objs, cam)
        cam.data.lens = lens1
        drive(sc)
        s1 = compose(objs, cam)
        d = [maxdiff(a, b) for a, b in zip(s0, s1)]
        chk("2 %s 50→%.0fmm 构图冻结" % (tag, lens1), max(d) < 1e-3,
            "各层Δ=%s" % ["%.4f" % x for x in d])

# ═══ 3. 量具自检：--background 下 update() 不触发 handler ═══
print()
print("=" * 72)
print("3  量具自检：`--background` 下 view_layer.update() 是否触发 handler")
CALLS = {"n": 0}
_orig = plock.parallax_lock_update_handler


def _counter(scene):
    CALLS["n"] += 1
    return _orig(scene)


plock.parallax_lock_update_handler = _counter
plock.register_handlers()
sc = fresh()
cam = mkcam(sc); sc.camera = cam
mkobjs(sc, cam, 2, "T")
plock.lock_group(sc, cam)
CALLS["n"] = 0
cam.data.lens = 85.0
only_update(sc)
n_update = CALLS["n"]
CALLS["n"] = 0
# ⚠️ 要调【模块属性】（此时已被换成 _counter）—— 直接调 _orig 会绕过计数器，
#    测出"0 次"的假结论（我第一版就写错了）。
plock.parallax_lock_update_handler(sc)
n_explicit = CALLS["n"]
plock.parallax_lock_update_handler = _orig
print("   只 update() → %d 次 ；显式调 → %d 次" % (n_update, n_explicit))
chk("3-a 只 update() 不触发（⇒ 测试必须显式驱动）", n_update == 0, "%d 次" % n_update)
chk("3-b 显式调用确实触发", n_explicit >= 1, "%d 次" % n_explicit)

print()
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("REVIEWFIX10_DONE")
