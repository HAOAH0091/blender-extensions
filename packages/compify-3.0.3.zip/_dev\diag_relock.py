"""诊断 [7]：重新锁定后图案为什么不冻结"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

mesh = bpy.data.meshes.new("G")
ns = 2
verts, faces = [], []
for iy in range(ns+1):
    for ix in range(ns+1):
        verts.append((-2+4*ix/ns, -2+4*iy/ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy*(ns+1)+ix
        faces.append((a, a+1, a+ns+2, a+ns+1))
mesh.from_pydata(verts, [], faces); mesh.update()
ob = bpy.data.objects.new("Grid", mesh)
sc.collection.objects.link(ob)
ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()


def camera_transform_node():
    for n in grp.nodes:
        if n.type == "TEX_COORD":
            return n
    return None


def group_input_source():
    """投影组第一个节点的输入来自谁 —— 判断 patch 是否生效"""
    tc = camera_transform_node()
    outs = []
    for s in tc.outputs:
        for lk in s.links:
            outs.append((s.name, lk.to_node.bl_idname, lk.to_node.label))
    return outs


def campos_now():
    a = mesh.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(mesh.vertices):
        return None
    return np.array([tuple(a.data[i].vector) for i in range(len(a.data))])


def uv_frozen():
    c = campos_now()
    if c is None: return None
    return np.array([(c[i][0]/c[i][2], c[i][1]/c[i][2]) for i in range(len(c))])


def uv_live():
    m = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


print("=" * 70)
print("阶段 1：首次锁定（相机 x=0）")
plock.lock_group(sc, cam)
print("  is_patched:", plock.is_patched(cd.name))
print("  TexCoord 输出连到:", group_input_source())
print("  campos[0]:", None if campos_now() is None else np.round(campos_now()[0], 3))

cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("  移相机 x=2 后:")
print("    campos[0]:", np.round(campos_now()[0], 3))
print("    冻结UV[0]:", np.round(uv_frozen()[0], 5), " 实时UV[0]:", np.round(uv_live()[0], 5))

print("\n" + "=" * 70)
print("阶段 2：解锁")
print(" ", plock.unlock_group(sc, cam)["message"])
bpy.context.view_layer.update()
print("  is_patched:", plock.is_patched(cd.name))
print("  TexCoord 输出连到:", group_input_source())
print("  campos:", "已清" if campos_now() is None else "仍在")
d = mesh.attributes.get(plock.UV_DELTA_ATTR)
print("  delta[0]:", None if d is None else tuple(round(x, 5) for x in d.data[0].vector))

cam.location.x = 3.0
bpy.context.view_layer.update()
print("  移相机 x=3 后 实时UV[0]:", np.round(uv_live()[0], 5))

print("\n" + "=" * 70)
print("阶段 3：重新锁定（相机 x=3）")
plock.lock_group(sc, cam)
bpy.context.view_layer.update()
print("  is_patched:", plock.is_patched(cd.name))
print("  TexCoord 输出连到:", group_input_source())
print("  campos[0]:", None if campos_now() is None else np.round(campos_now()[0], 3))
print("  delta:", "已清" if mesh.attributes.get(plock.UV_DELTA_ATTR) is None else "仍在")
print("  冻结UV[0]:", np.round(uv_frozen()[0], 5))

cam.location.x = 3.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("  移相机 x=3.5 后:")
print("    campos[0]:", np.round(campos_now()[0], 3))
print("    冻结UV[0]:", np.round(uv_frozen()[0], 5), " 实时UV[0]:", np.round(uv_live()[0], 5))
print("    >>> 冻结UV 是否恒定: %s" % ("是" if abs(uv_frozen()[0][0] - 1.4) < 0.01 else "否"))
