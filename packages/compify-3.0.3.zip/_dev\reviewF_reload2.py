"""审查 F-3/4/9（v2）：热重载后 handler 重复注册 / 禁用后残留 handler 仍在改网格 /
                     卸载时模块级全局变量是否重置。

⚠️ v1 的坑：我用「函数名」过滤 handlers，但计数包装器把名字换掉了 → 全部漏判；
   且 headless 下 `view_layer.update()` 不会触发 depsgraph_update_post（实测 0 次调用），
   所以「是否被调用」只能靠**直接调用函数对象**来验，不能靠事件循环。
   本版一律按 **对象身份**（is）判定。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-54s %s" % ("PASS" if c else "FAIL", n, d))


def load_pkg():
    for k in [k for k in list(sys.modules) if k == PKG or k.startswith(PKG + ".")]:
        del sys.modules[k]
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
    mod = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = mod
    spec.loader.exec_module(mod)
    return sys.modules[PKG + ".compify_parallax_lock"], sys.modules[PKG + ".node_groups"]


def hl():
    return list(bpy.app.handlers.depsgraph_update_post)


def build(ng_mod):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = sc.render.resolution_y = 96
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd); sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    g = nt.nodes.new("ShaderNodeGroup"); g.node_tree = grp
    o = nt.nodes.new("ShaderNodeOutputMaterial"); e = nt.nodes.new("ShaderNodeEmission")
    nt.links.new(g.outputs["Vector"], e.inputs["Color"])
    nt.links.new(e.outputs["Emission"], o.inputs["Surface"])
    # 倾斜网格（有深度差）——纯平面在横向平移下 adapt 本身就不动顶点，测不出东西
    ns, H = 3, 2.0
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            x = -H + 2 * H * ix / ns
            verts.append((x, -H + 2 * H * iy / ns, 0.28 * x))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh = bpy.data.meshes.new("G0"); mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new("Grid0", mesh); sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


def move_max(ob, before):
    return max(max(abs(a - b) for a, b in zip(p, tuple(ob.matrix_world @ v.co)))
               for p, v in zip(before, ob.data.vertices))


print("=" * 84)
print("### [3] 热重载（模拟 Blender「Reload Scripts / addon 重载」：磁盘重新导入）")
bpy.ops.wm.read_factory_settings(use_empty=True)
for f in hl():
    if "compify_plock_dev" in getattr(f, "__module__", ""):
        bpy.app.handlers.depsgraph_update_post.remove(f)

plock1, ng1 = load_pkg()
fn1 = plock1.parallax_lock_update_handler
plock1.register_handlers()
c1 = sum(1 for f in hl() if f is fn1)
chk("首次注册后列表里 1 份", c1 == 1, "count=%d" % c1)

plock2, ng2 = load_pkg()          # ← 新模块 + 新函数对象（旧的仍在列表里）
fn2 = plock2.parallax_lock_update_handler
plock2.register_handlers()
c2 = len(hl())
has_old = any(f is fn1 for f in hl())
has_new = any(f is fn2 for f in hl())
chk("重载后再注册，handler 仍是 1 份（不重复）", c2 == 1,
    "列表长度=%d（旧函数在=%s，新函数在=%s）" % (c2, has_old, has_new))

print("")
print("### [4] 重载后「禁用」插件：能否把旧的那份也撤掉")
plock2.unregister_handlers()
left_old = sum(1 for f in hl() if f is fn1)
left_new = sum(1 for f in hl() if f is fn2)
print("  unregister 之后：旧函数剩 %d 份，新函数剩 %d 份" % (left_old, left_new))
chk("禁用后 handler 全部撤掉", left_old == 0 and left_new == 0,
    "残留 %d 份（旧模块的函数对象）" % left_old)

# 残留那一份还在不在起作用？直接调用它（headless 下事件循环不触发 handler，
# 所以「还在列表里」= 真机每帧都会被调用；这里用直接调用证明它仍有行为能力）
sc, cam, cd, ob = build(ng1)
plock1.lock_group(sc, cam)
before = [tuple(ob.matrix_world @ v.co) for v in ob.data.vertices]
cam.location.x = 2.0
cd.lens = 85.0
bpy.context.view_layer.update()
fn1(sc)                                  # ← 「已禁用」插件的 handler 仍在跑
d = move_max(ob, before)
chk("禁用后残留 handler 不再改动网格", d < 1e-9,
    "残留 handler 跑一帧后几何位移 = %.4f" % d)

print("")
print("### [9] 卸载时模块级全局变量是否重置")
plock3, ng3 = load_pkg()
plock3.register_handlers()
sc, cam, cd, ob = build(ng3)
plock3.lock_group(sc, cam)
cam.location.x = 1.0
bpy.context.view_layer.update()
plock3.parallax_lock_update_handler(sc)
print("  unregister 前：_proj_cache=%d _backfill_tick=%d _last_view=%d _base_cache=%d"
      % (len(plock3._proj_cache), plock3._backfill_tick[0], len(plock3._last_view),
         len(plock3._base_cache)))
plock3.unregister_handlers()
print("  unregister 后：_proj_cache=%d _backfill_tick=%d _last_view=%d _base_cache=%d"
      % (len(plock3._proj_cache), plock3._backfill_tick[0], len(plock3._last_view),
         len(plock3._base_cache)))
chk("_proj_cache 卸载时清空", len(plock3._proj_cache) == 0, "剩余 %d 条" % len(plock3._proj_cache))
chk("_backfill_tick 卸载时归零", plock3._backfill_tick[0] == 0, "值 %d" % plock3._backfill_tick[0])

print("")
print("=" * 84)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("RF_RELOAD2_DONE")
