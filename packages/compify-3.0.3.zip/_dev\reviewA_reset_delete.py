"""审查 A-2：锁定中直接「重置」（不先解锁），再锁定是否正确
          A-3：锁定中删除被锁定的网格 / 删除相机，再解锁会怎样
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock

L.report("A-2 锁定中直接重置（且此前已落实过构图 C≠0）")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
orig_local = L.lverts(A).copy()
cam0 = tuple(cam.location)
# 先制造一次「已落实」：锁 → 手动移相机 → 解锁（C≠0）
plock.lock_group(sc, cam)
cam.location.x += 0.7
L.run_h(sc, times=1)
plock.unlock_group(sc, cam)
S_c, C_c = L.node_sc(cam)
L.info("第一次解锁后 S=%.4f C=(%+.4f,%+.4f) 相机位置=%s"
       % (S_c, C_c[0], C_c[1], tuple(round(v, 3) for v in cam.location)))
cam_home = tuple(cam.location)
# 再锁定（会把 C 并进冻结坐标），变焦让插件推相机，然后【锁定中直接重置】
plock.lock_group(sc, cam)
cam.data.lens = 85.0
L.run_h(sc, times=2)
cam_zoom = tuple(cam.location)
L.info("变焦后相机位置=%s（dolly 生效？）" % (tuple(round(v, 3) for v in cam_zoom),))
r = plock.reset_group(sc, cam)
S_r, C_r = L.node_sc(cam)
geo = float(np.abs(L.lverts(A) - orig_local).max())
camd = float(np.linalg.norm(np.array(cam.location) - np.array(cam0)))
L.info("重置返回：%s" % r["message"][:60])
L.chk("锁定中重置：几何回到原形", geo < 1e-6, "逐顶点Δ=%.2e" % geo)
L.chk("锁定中重置：C+k 复位恒等", abs(S_r - 1) < 1e-9 and max(map(abs, C_r)) < 1e-9,
      "S=%.6f C=(%.2e,%.2e)" % (S_r, C_r[0], C_r[1]))
camd = float(np.linalg.norm(np.array(cam.location) - np.array(cam_home)))
L.chk("锁定中重置：变焦 dolly 推走的相机被推回", camd < 1e-6,
      "相对变焦前残差=%.2e（变焦前→变焦后位移=%.3f）"
      % (camd, float(np.linalg.norm(np.array(cam_zoom) - np.array(cam_home)))))
L.chk("锁定中重置：记录/属性清干净", not plock.load_groups(sc)
      and not L.campos_ok(A, cam) and A.get(plock.OBJ_CAM_KEY) is None,
      "state=%s campos=%s OBJ_CAM_KEY=%s"
      % (len(plock.load_groups(sc)), L.campos_ok(A, cam), A.get(plock.OBJ_CAM_KEY)))

# 重置后再锁定：画面必须等于「真实实时投影」（不能残留上一轮落实的偏移）
u_true = L.uvimg("rs")
r = plock.lock_group(sc, cam)
u_relock = L.uvimg("rs")
L.chk("重置后再锁定：图案等于真实投影（无残留偏移）",
      L.uvd(u_relock, u_true) < 2e-3,
      "与重置后画面差=%.6f（锁定只该冻结，不该改画面）" % L.uvd(u_relock, u_true))
plock.reset_group(sc, cam)

L.report("A-3 锁定中删除被锁定的网格对象 / 删除相机")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
objs = list(C["objs"])
plock.lock_group(sc, cam)
cam.location.x += 0.7
L.run_h(sc, times=2)
gone = objs[1]
gone_mesh = gone.data
bpy.data.objects.remove(gone, do_unlink=True)
r = None
try:
    r = plock.unlock_group(sc, cam)
    ok, err = True, ""
except Exception as e:
    ok, err = False, repr(e)
L.chk("删除网格后解锁不抛异常", ok, err)
if ok:
    L.info("解锁返回：%s" % r["message"][:70])
left = [a.name for a in gone_mesh.attributes if a.name.startswith("compify_plock")]
L.info("被删对象残留：mesh=%s 上属性=%s"
       % (gone_mesh.name if gone_mesh.name in bpy.data.meshes else "<已释放>", left))
S1, C1 = L.node_sc(cam)
L.info("删除后解锁 S=%.4f C=(%+.4f,%+.4f)" % (S1, C1[0], C1[1]))
r2 = plock.lock_group(sc, cam)
L.chk("删除后重新锁定仍成功且只锁剩下 2 个",
      r2["success"] and len(r2["locked"]) == 2, "%s" % r2["message"][:60])
for o in [x for x in bpy.data.objects if x.type == "MESH"]:
    bpy.data.objects.remove(o, do_unlink=True)
try:
    r3 = plock.unlock_group(sc, cam)
    ok3, err3 = True, "msg=%s" % r3["message"][:60]
except Exception as e:
    ok3, err3 = False, repr(e)
L.chk("网格全删后解锁不抛异常", ok3, err3)
try:
    r4 = plock.reset_group(sc, cam)
    ok4, err4 = True, r4["message"][:50]
except Exception as e:
    ok4, err4 = False, repr(e)
L.chk("无网格时重置不抛异常", ok4, err4)

print()
L.report("A-3b 解锁后删相机的场景：orphan 重置会不会把 C+k 留下（投影残留偏移）")
C = L.build(n_grid=2)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
orig_local = L.lverts(A).copy()
# 制造「已落实构图」：锁 → 移相机 → 解锁（此时 C≠0，图案被永久偏置）
plock.lock_group(sc, cam)
cam.location.x += 0.7
L.run_h(sc, times=1)
plock.unlock_group(sc, cam)
S0, C0 = L.node_sc(cam)
L.info("解锁后 C+k = S=%.4f C=(%+.4f,%+.4f)（这是「已落实」的偏移，靠解锁后重锁/重置才复位）"
       % (S0, C0[0], C0[1]))
cam_name = cd.name
bpy.data.objects.remove(cam, do_unlink=True)
r = plock.reset_orphan_locks(sc)
L.info("orphan 重置返回：%s" % r["message"][:70])
# 渲染需要一个相机：重建一个同数据块的对象（真实用户也会重新加相机）
_cd2 = bpy.data.cameras.get(cam_name)
nc = bpy.data.objects.new("CamBack", _cd2)
sc.collection.objects.link(nc)
nc.location = (0, 0, 5)
nc.rotation_euler = (0, 0, 0)
sc.camera = nc
bpy.context.view_layer.update()
S1, C1 = L.node_sc_by_name(cam_name) if hasattr(L, "node_sc_by_name") else (None, None)
nodes = plock._find_delta_nodes(cam_name)
S1 = float(nodes[0].inputs["Scale"].default_value) if nodes else None
C1 = tuple(round(float(x), 6) for x in nodes[1].inputs[1].default_value)[:2] if nodes else None
u_left = L.uvimg("orph")
plock.write_identity_delta(cam_name)
u_ident = L.uvimg("orph")
off = L.uvd(u_left, u_ident)
L.chk("orphan 重置后 C+k 已复位（投影回到纯实时）",
      abs((S1 or 1) - 1) < 1e-9 and max(map(abs, C1 or (0, 0))) < 1e-9,
      "S=%s C=%s ⇒ 与恒等变换的画面差=%.4f（UV 探针均值）" % (S1, C1, off))

print()
L.report("A-3b' 锁定中删除相机（几何已变形）→ orphan 重置能否还原")
C = L.build(n_grid=2)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
orig_local = L.lverts(A).copy()
plock.lock_group(sc, cam)
cam.rotation_euler.y = 0.35
cam.location.x += 0.7
L.run_h(sc, times=2)
geo_lock = float(np.abs(L.lverts(A) - orig_local).max())
bpy.data.objects.remove(cam, do_unlink=True)
r = plock.reset_orphan_locks(sc)
geo = float(np.abs(L.lverts(A) - orig_local).max())
L.chk("删相机后 orphan 重置能还原几何", r["success"] and geo < 1e-6,
      "锁定中变形 Δ=%.3f → 重置后 Δ=%.2e" % (geo_lock, geo))
res = [a.name for a in A.data.attributes if a.name.startswith("compify_plock")]
L.chk("orphan 重置后属性无残留", not res, "残留=%s" % res)
L.summary()
