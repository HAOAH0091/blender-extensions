"""审查 B-6b：真正的集合实例（源对象不在场景里，只通过 instance_collection 出现）。

跑法：blender --background --factory-startup --python _dev\\reviewB_instance2.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 90)
print("B-6b 集合实例（源集合未连进场景，只被 instance_collection 引用）")
print("=" * 90)

sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3, x0=-2.6)

# 源集合：不连进场景
sub = bpy.data.collections.new("SubColl")
meB = C.grid_mesh("InstMesh", ns=3, H=1.6, x0=0.0)
meB.materials.append(mat)
obB = bpy.data.objects.new("InstSrc", meB)
sub.objects.link(obB)          # ← 只进子集合，不进 scene
C.attach(obB, cam)
emp = bpy.data.objects.new("InstEmpty", None)
emp.instance_type = "COLLECTION"
emp.instance_collection = sub
emp.location = (3.0, 0.0, 0.0)
sc.collection.objects.link(emp)
bpy.context.view_layer.update()
print("   scene.objects =", [o.name for o in sc.objects])
print("   bpy.data.objects 里的 mesh =", [o.name for o in bpy.data.objects if o.type == "MESH"])
print("   objects_using_projection 覆盖 =", [o.name for o in plock.objects_using_projection(cd.name)])

u_pre = C.uvimg("inst2")
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s locked=%s" %
      (r["success"], r.get("frozen"), [o.name for o in r.get("locked", [])]))
C.run_handler(sc)
u_post = C.uvimg("inst2")
print("   锁定（相机未动）前后整幅渲染差 = %.5f" % C.uvd(u_pre, u_post))

h, w = u_pre.shape[:2]
reg = (slice(0, h), slice(int(w * 0.62), w))     # 实例所在右半侧
sd_pre = float(np.std(u_pre[reg]))
sd_post = float(np.std(u_post[reg]))
print("   实例区域 UV 编码 标准差: 锁定前 %.4f → 锁定后 %.4f" % (sd_pre, sd_post))
print("   实例区域 均值: 前 (%.3f,%.3f) → 后 (%.3f,%.3f)"
      % (u_pre[reg][..., 0].mean(), u_pre[reg][..., 1].mean(),
         u_post[reg][..., 0].mean(), u_post[reg][..., 1].mean()))
diff = float(np.abs(u_post[reg] - u_pre[reg]).mean())
print("   实例区域 锁定前后 UV 平均差 = %.5f（0 = 锁定不改变画面）" % diff)
C.chk("实例：锁定这一动作【不改变】实例区域的图案（锁定不跳）", diff < 2e-3,
      "Δ=%.5f" % diff)

# 相机移动后：实例应保持图案（如果它真被冻结了）
cam.location.x = 1.2
C.run_handler(sc)
u_mv = C.uvimg("inst2")
d_mv = float(np.abs(u_mv[reg] - u_post[reg]).mean())
print("   相机横移 1.2 后实例区域变化 = %.5f" % d_mv)

C.summary()
