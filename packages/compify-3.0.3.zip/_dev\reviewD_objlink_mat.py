"""审查项 3（linked material 的一部分）：**object-linked 材质槽**（slot.link='OBJECT'）

现象预期：objects_using_projection 只扫 `o.data.materials`，object 级材质槽它看不见
⇒ B 永远拿不到冻结坐标属性；而投影组补丁是全局的 ⇒ B 的 Attribute 读到 0
⇒ 图案塌成纯色，UI 仍 🔒，无任何提示。
"""
import bpy
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
sc = C.reset()
cam, cd = C.new_cam(sc)
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat, gn = C.probe_mat("Probe", grp)

A = C.new_grid("A")
A.data.materials.append(mat)
C.uv_adjust_group(A, cd)          # 正常路径：A 有 UV Adjust 组

B = C.new_grid("B")               # 同位置，和 A 完全重叠
B.data.materials.append(None)     # 建一个空槽
B.material_slots[0].link = "OBJECT"
B.material_slots[0].material = mat
bpy.context.view_layer.update()

print("B 材质槽: link=%s material=%s ; B.data.materials=%s" % (
    B.material_slots[0].link, B.material_slots[0].material.name,
    [m.name if m else None for m in B.data.materials]))
print("objects_using_projection 命中: %s" % [o.name for o in plock.objects_using_projection(cd.name)])
print("get_lock_targets 命中:        %s" % [o.name for o in plock.get_lock_targets(sc, cam)])

res = plock.lock_group(sc, cam)
print("lock_group: success=%s frozen=%s\n  msg=%s" % (res["success"], res.get("frozen"), res["message"]))

print("campos 属性: A=%s B=%s" % (C.campos_ok(plock, A, cd.name), C.campos_ok(plock, B, cd.name)))

# ---- 真渲染：分别看 A / B 的 UV 场 ----
C.show(A)
uA0 = C.render_uv(tag="A")
C.show(B)
uB0 = C.render_uv(tag="B")

cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

C.show(A)
uA1 = C.render_uv(tag="A")
C.show(B)
uB1 = C.render_uv(tag="B")

sA0, sA1, sB0, sB1 = (C.stats(uA0), C.stats(uA1), C.stats(uB0), C.stats(uB1))
dA = float(np.abs(uA1 - uA0).mean())
dB = float(np.abs(uB1 - uB0).mean())


def frozen_uv(ob):
    """逐顶点冻结坐标 → 透视 UV（平移时整幅图会移动，不能拿整图差判冻结）。"""
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([(a.data[i].vector[0] / a.data[i].vector[2],
                      a.data[i].vector[1] / a.data[i].vector[2])
                     for i in range(len(a.data))])


_fA = frozen_uv(A)
dA_frozen = -1.0 if _fA is None else float(np.abs(_fA - _fA).max())
print("\nA UV 极差(锁定那一刻)=%.4f 均值=(%+.3f,%+.3f) ; 整图差=%.6f"
      % (sA0[0], sA0[2], sA0[3], dA))
print("B UV 极差(锁定那一刻)=%.4f 均值=(%+.3f,%+.3f) ; 整图差=%.6f"
      % (sB0[0], sB0[2], sB0[3], dB))
print("A 冻结坐标存在 → 图案逐顶点冻住（整图差 %.3f 是网格在屏上平移，属正常）"
      % dA if _fA is not None else "A 无冻结坐标")
C.report("A（data-linked）图案冻结", _fA is not None, "冻结坐标在场，整图差 %.3f=网格平移" % dA)
C.report("A 投影还是图案（非纯色）", sA0[0] > 0.10, "x 极差=%.4f" % sA0[0])
C.report("B（object-linked）拿到冻结坐标属性", C.campos_ok(plock, B, cd.name))
C.report("B 投影还是图案（非纯色）", sB0[0] > 0.10, "x 极差=%.4f" % sB0[0])
print("\nRD_OBJLINK_DONE")
