"""边界分析 v2：锁定期间换材质，量化「第几帧才修好」+ 各类不可冻结对象的最终状态"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, mesh=None):
        if mesh is None:
            ns = 3; H = 1.6
            verts, faces = [], []
            for iy in range(ns+1):
                for ix in range(ns+1):
                    verts.append((x0-H+2*H*ix/ns, -H+2*H*iy/ns, 0.0))
            for iy in range(ns):
                for ix in range(ns):
                    a = iy*(ns+1)+ix
                    faces.append((a, a+1, a+ns+2, a+ns+1))
            mesh = bpy.data.meshes.new(name)
            mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob

    A = mk("GridA", -2.0)
    B = mk("GridB", 2.0)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


def has_campos(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    return a is not None and len(a.data) == len(ob.data.vertices)


def uv_err(ob, cam, cd, lock_mw):
    """按组当前会给出的 UV vs 「锁定时刻的投影」的误差"""
    if plock.is_patched(cd.name):
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            uv = np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                            a.data[i].vector[1]/a.data[i].vector[2])
                           for i in range(len(a.data))])
        else:
            uv = np.zeros((len(ob.data.vertices), 2))
    else:
        m = cam.matrix_world.inverted()
        nodes = plock._find_delta_nodes(cd.name)
        S, C = 1.0, (0.0, 0.0)
        if nodes is not None:
            S = nodes[0].inputs["Scale"].default_value
            C = tuple(nodes[1].inputs[1].default_value)[:2]
        uv = np.array([((lambda p: (p.x/p.z*S+C[0], p.y/p.z*S+C[1]))(
            m @ (ob.matrix_world @ v.co))) for v in ob.data.vertices])
    mi = lock_mw.inverted()
    exp = np.array([((lambda p: (p.x/p.z, p.y/p.z))(mi @ (ob.matrix_world @ v.co)))
                    for v in ob.data.vertices])
    return float(np.abs(uv - exp).max())


def frames_until_ok(ob, cam, cd, lock_mw, maxf=14):
    """跑 handler 直到 UV 正确，返回帧数；超时返回 None"""
    for k in range(1, maxf+1):
        plock.parallax_lock_update_handler(bpy.context.scene)
        bpy.context.view_layer.update()
        if uv_err(ob, cam, cd, lock_mw) < 1e-5:
            return k
    return None


import io
import contextlib


def catch_print(fn):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        r = fn()
    return r, buf.getvalue()


print("=" * 84)
print("边界 v2：锁定期间换材质 —— 第几帧修好 / 各类不可冻结对象的最终状态")
print("=" * 84)

for tag, setup in [
    ("普通网格", lambda B, cam: None),
    ("带修改器", lambda B, cam: setattr(B.modifiers.new("S", "SUBSURF"), "levels", 1)),
    ("带形态键", lambda B, cam: B.shape_key_add(name="K1", from_mix=False)),
]:
    print("\n[%s]" % tag)
    sc, cam, cd, mat, A, B = build()
    plock._backfill_warned.clear()      # 每个用例独立（对象会重名）
    plock.lock_group(sc, cam)
    lock_mw = cam.matrix_world.copy()
    setup(B, cam)
    cam.location.x = 2.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()

    B.data.materials.clear(); B.data.materials.append(mat)
    bpy.context.view_layer.update()
    e0 = uv_err(B, cam, cd, lock_mw)
    print("   换材质瞬间 UV 误差 = %.6f  %s" % (e0, "正确" if e0 < 1e-5 else "【错】"))

    msgs = []
    def run():
        return frames_until_ok(B, cam, cd, lock_mw)
    k, out = catch_print(run)
    if out.strip():
        for line in out.strip().splitlines():
            msgs.append(line.strip())
    print("   第几帧修好 = %s" % (k if k is not None else "始终没修好（超过 14 帧）"))
    for m in msgs:
        print("   提示: %s" % m)

# 共享网格
print("\n[两个对象共享 mesh]")
sc, cam, cd, mat, A, B = build()
plock._backfill_warned.clear()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
C = bpy.data.objects.new("GridC", B.data)
sc.collection.objects.link(C)
C.location = (5.5, 0, 0)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
print("   换材质瞬间 B 误差 = %.6f" % uv_err(B, cam, cd, lock_mw))
k, out = catch_print(lambda: frames_until_ok(B, cam, cd, lock_mw))
print("   第几帧修好 = %s" % (k if k is not None else "始终没修好"))
for line in out.strip().splitlines():
    print("   提示: %s" % line.strip())

# 编辑模式
print("\n[编辑模式中换材质]")
sc, cam, cd, mat, A, B = build()
plock.lock_group(sc, cam)
lock_mw = cam.matrix_world.copy()
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
bpy.context.view_layer.objects.active = B
B.select_set(True)
bpy.ops.object.mode_set(mode="EDIT")
B.data.materials.clear(); B.data.materials.append(mat)
bpy.context.view_layer.update()
for _ in range(3):
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
bpy.ops.object.mode_set(mode="OBJECT")
bpy.context.view_layer.update()
print("   退出编辑模式瞬间 B 误差 = %.6f  %s" % (
    uv_err(B, cam, cd, lock_mw),
    "正确" if uv_err(B, cam, cd, lock_mw) < 1e-5 else "【错】"))
k, out = catch_print(lambda: frames_until_ok(B, cam, cd, lock_mw))
print("   第几帧修好 = %s" % (k if k is not None else "始终没修好"))
print("EDGE2_DONE")
