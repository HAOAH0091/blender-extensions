"""审查 A-1：反复「锁定→移相机→解锁」10 轮有没有累积漂移
          + A-8：unlock 之后同一帧内立刻 lock，C+k 数值有没有错
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import reviewA_lib as L

L.report("A-1 反复 10 轮 锁定→移相机→解锁：漂移检查")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
orig_local = L.lverts(A).copy()
orig_world = L.wverts(A).copy()

names_attr = []
end_world = []
jumps = []
locks_geo = []
for i in range(10):
    r = L.plock.lock_group(sc, cam)
    assert r["success"], r["message"]
    locks_geo.append(float(np.abs(L.lverts(A) - orig_local).max()))
    # 锁定中移相机（触发适配变形）
    cam.location.x += 0.4
    L.run_h(sc, times=1)
    u_lock = L.uvimg("cyc")
    r2 = L.plock.unlock_group(sc, cam)
    u_ul = L.uvimg("cyc")
    jumps.append(L.uvd(u_ul, u_lock))
    S, Cc = L.node_sc(cam)
    if i in (0, 4, 9):
        L.info("第%d轮 解锁后 S=%.6f C=(%+.6f,%+.6f)" % (i + 1, S, Cc[0], Cc[1]))
    # 相机回原位（解锁后移动相机不应改变几何）
    cam.location.x -= 0.4
    L.run_h(sc, times=1)
    end_world.append(L.wverts(A).copy())

print()
d_1_10 = float(np.abs(end_world[-1] - end_world[0]).max())
d_1_5 = float(np.abs(end_world[4] - end_world[0]).max())
L.chk("10 轮后几何相对第 1 轮无累积漂移", d_1_10 < 1e-6, "逐顶点世界Δ=%.2e" % d_1_10)
L.info("第 5 轮 Δ=%.2e" % d_1_5)
L.chk("每轮解锁瞬间不跳（10 轮 max）", max(jumps) < 2e-3,
      "max跳变=%.6f min=%.6f" % (max(jumps), min(jumps)))
L.chk("10 轮内几何只在首次锁定后变化", max(locks_geo) < 1.0,
      "锁定瞬间相对原形 Δ=%.4f" % max(locks_geo))

# 属性 / 记录堆积检查
n_attr = sum(1 for a in A.data.attributes if a.name.startswith("compify_plock"))
n_campos = len([a for a in A.data.attributes
                if a.name == L.plock._campos_attr_name(cd.name)])
groups = L.plock.load_groups(sc)
L.chk("属性没有逐轮堆积", n_campos == 0 and n_attr <= 2,
      "campos=%d 全部 compify 属性=%d（解锁后 campos 应已清）" % (n_campos, n_attr))
L.chk("state 记录唯一且 enabled=False", len(groups) == 1
      and list(groups.values())[0].get("enabled") is False
      and "uv_delta_committed" in list(groups.values())[0],
      "记录数=%d enabled=%s" % (len(groups), list(groups.values())[0].get("enabled")))
S, Cc = L.node_sc(cam)
L.info("10 轮末 S=%.6f C=(%+.6f,%+.6f)" % (S, Cc[0], Cc[1]))

# 最后重置：必须回到最初原形
r = L.plock.reset_group(sc, cam)
back = float(np.abs(L.lverts(A) - orig_local).max())
L.chk("10 轮后重置能回到最初原形", back < 1e-6, "逐顶点局部Δ=%.2e  (%s)" % (back, r["message"][:30]))

print()
L.report("A-8 unlock 之后同一帧内立刻 lock（中间不跑 handler）")
C = L.build(n_grid=3)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
L.plock.lock_group(sc, cam)
cam.location.x += 0.5
L.run_h(sc, times=1)
u_before = L.uvimg("sf")
S1, C1 = L.node_sc(cam)
r = L.plock.unlock_group(sc, cam)
S2, C2 = L.node_sc(cam)
r2 = L.plock.lock_group(sc, cam)
S3, C3 = L.node_sc(cam)
u_after = L.uvimg("sf")
jump = L.uvd(u_after, u_before)
L.info("解锁后 S=%.6f C=(%+.6f,%+.6f)" % (S2, C2[0], C2[1]))
L.info("同帧重锁后 S=%.6f C=(%+.6f,%+.6f)" % (S3, C3[0], C3[1]))
L.chk("同帧 unlock→lock 画面不跳", jump < 2e-3, "Δ=%.6f" % jump)
L.chk("重锁后回到恒等变换", abs(S3 - 1.0) < 1e-9 and max(abs(C3[0]), abs(C3[1])) < 1e-9,
      "S=%.6f C=(%.2e,%.2e)" % (S3, C3[0], C3[1]))
# 再解锁一次：此时 campos 是「含旧 S/C 的」坐标，检查跳变
L.run_h(sc, times=1)
u_l2 = L.uvimg("sf")
r3 = L.plock.unlock_group(sc, cam)
u_ul2 = L.uvimg("sf")
L.chk("同帧重锁后再解锁仍不跳", L.uvd(u_ul2, u_l2) < 2e-3, "Δ=%.6f" % L.uvd(u_ul2, u_l2))
L.summary()
