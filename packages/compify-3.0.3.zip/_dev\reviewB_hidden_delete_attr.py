"""审查 B-7/8/9：隐藏网格、锁定期间删除并重建同名对象、顶点属性被改名/删除。

跑法：blender --background --factory-startup --python _dev\\reviewB_hidden_delete_attr.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy

C.load()
plock = C.PL()
print("=" * 94)
print("B-7 隐藏 / B-8 删除并重建 / B-9 属性被改名删除")
print("=" * 94)

# ══════════════════════════════════════════════════════════
print("\n### 7. 隐藏的网格（hide_viewport / hide_render）###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3, x0=-2.6)
H1 = C.add_grid("HidView", cam, mat, ns=3, x0=2.6)
H2 = C.add_grid("HidRender", cam, mat, ns=3, shape="倾斜", x0=0.0)
H1.hide_viewport = True
H2.hide_render = True
bpy.context.view_layer.update()
try:
    r = plock.lock_group(sc, cam)
    print("   lock: success=%s frozen=%s locked=%s" % (r["success"], r.get("frozen"),
                                                     [o.name for o in r.get("locked", [])]))
    print("   跳过:", [(o.name, w) for o, w in r.get("skipped", [])])
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 抛异常:", type(e).__name__, e)
C.chk("7a 隐藏网格不影响 lock", exc is None and r.get("success"))
w_before = {o.name: np.array([tuple(o.matrix_world @ v.co) for v in o.data.vertices]) for o in (A, H1, H2)}
fv_before = {o.name: C.campos_uv(o, cd.name) for o in (A, H1, H2)}
cam.location.x = 2.0
cam.data.lens = 70.0
try:
    C.run_handler(sc)
    exc2 = None
except Exception as e:
    exc2 = e
    print("   ✗ handler 抛异常:", type(e).__name__, e)
C.chk("7b 隐藏网格参与适配时不抛异常", exc2 is None)
for o in (A, H1, H2):
    w_after = np.array([tuple(o.matrix_world @ v.co) for v in o.data.vertices])
    d = float(np.abs(w_after - w_before[o.name]).max())
    fv = C.campos_uv(o, cd.name)
    dfv = float(np.abs(fv - fv_before[o.name]).max()) if (fv is not None and fv_before[o.name] is not None) else -1
    print("   %-10s 几何被适配 Δ=%.6f   冻结坐标变化=%.2e" % (o.name, d, dfv))
C.chk("7c 隐藏网格也照常适配（几何 Δ>1e-6）",
      all(float(np.abs(np.array([tuple(o.matrix_world @ v.co) for v in o.data.vertices])
                       - w_before[o.name]).max()) > 1e-6 for o in (A, H1, H2)))
C.chk("7d 隐藏网格的冻结坐标没被改写",
      all(C.campos_uv(o, cd.name) is not None and
          float(np.abs(C.campos_uv(o, cd.name) - fv_before[o.name]).max()) < 1e-6
          for o in (A, H1, H2)))

# ══════════════════════════════════════════════════════════
print("\n### 8. 锁定期间删除网格，再建一个同名对象 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
r = plock.lock_group(sc, cam)
cam.location.x = 1.0
C.run_handler(sc)
print("   锁定中: locked=%s" % [o.name for o in r.get("locked", [])])
old_mesh = A.data
bpy.data.objects.remove(A, do_unlink=True)
bpy.context.view_layer.update()
try:
    C.run_handler(sc)
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 删除后 handler 抛异常:", type(e).__name__, e)
C.chk("8a 删除锁定对象后 handler 不抛异常", exc is None)
print("   删除后面板: locked=%s degraded=%s orphans=%d"
      % (plock.lock_status(sc, cam).get("locked"), plock.lock_status(sc, cam).get("degraded"),
         len(plock.find_orphan_locks(sc))))
# 重建同名对象（新 mesh）
A2 = C.add_grid("GridA", cam, mat, ns=5, H=1.0, loc=(0.5, 0, 0))
bpy.context.view_layer.update()
print("   重建后 A2 属性:", list(C.attrs(A2).keys()))
try:
    C.run_handler(sc)
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 重建后 handler 抛异常:", type(e).__name__, e)
C.chk("8b 重建同名对象后 handler 不抛异常", exc is None)
lo = plock.locked_objects(sc, cd.name)
print("   locked_objects 现在 =", [o.name for o in lo])
print("   重建对象上有 campos=%s  base=%s  orig=%s"
      % (A2.data.attributes.get(plock._campos_attr_name(cd.name)) is not None,
         A2.data.attributes.get(plock.BASE_ATTR) is not None,
         A2.data.attributes.get(plock.ORIG_ATTR) is not None))
w0 = np.array([tuple(A2.matrix_world @ v.co) for v in A2.data.vertices])
cam.location.x = 3.0
try:
    C.run_handler(sc)
except Exception as e:
    print("   ✗ 移相机后 handler 抛异常:", type(e).__name__, e)
w1 = np.array([tuple(A2.matrix_world @ v.co) for v in A2.data.vertices])
print("   重建对象会被适配变形吗: 几何Δ=%.6f（=0 表示不适配）" % float(np.abs(w1 - w0).max()))
print("   它是否被当成锁定网格:", [o.name for o in plock.locked_objects(sc, cd.name)])
try:
    rr = plock.reset_group(sc, cam)
    print("   重置:", rr["message"][:120])
    exc = None
except Exception as e:
    exc = e
    print("   ✗ 重置抛异常:", type(e).__name__, e)
C.chk("8c 删除+重建后 reset 不抛异常", exc is None)

# ══════════════════════════════════════════════════════════
print("\n### 9. 冻结坐标属性被用户改名 / 删除 ###")
for mode in ("rename", "delete"):
    sc, cam, cd, grp = C.setup()
    mat = C.probe_mat(grp)
    A = C.add_grid("GridA", cam, mat, ns=3)
    r = plock.lock_group(sc, cam)
    cam.location.x = 1.5
    C.run_handler(sc)
    an = plock._campos_attr_name(cd.name)
    uv_before = C.campos_uv(A, cd.name)
    a = A.data.attributes.get(an)
    if mode == "rename":
        a.name = "hacked_" + an
    else:
        A.data.attributes.remove(a)
    bpy.context.view_layer.update()
    try:
        C.run_handler(sc)
        exc = None
    except Exception as e:
        exc = e
        print("   ✗ handler 抛异常:", type(e).__name__, e)
    a2 = A.data.attributes.get(an)
    uv_after = C.campos_uv(A, cd.name)
    d = (float(np.abs(uv_after - uv_before).max())
         if (uv_after is not None and uv_before is not None) else -1)
    print("   %-6s: 自愈后属性存在=%s  逐顶点UV Δ=%.2e  （0 = 图案完全恢复）"
          % (mode, a2 is not None, d))
    C.chk("9-%s 冻结坐标被破坏后能自愈且图案不变" % mode,
          exc is None and a2 is not None and abs(d) < 1e-6, "Δ=%.2e" % d)

print("\n### 9b. 变形基准属性（compify_plock_base）被改名 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
r = plock.lock_group(sc, cam)
b = A.data.attributes.get(plock.BASE_ATTR)
b.name = "hacked_base"
bpy.context.view_layer.update()
w0 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
cam.location.x = 2.0
try:
    C.run_handler(sc)
    exc = None
except Exception as e:
    exc = e
    print("   ✗ handler 抛异常:", type(e).__name__, e)
w1 = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
d = float(np.abs(w1 - w0).max())
print("   移相机后几何 Δ=%.6f（=0 表示适配静默失效）" % d)
print("   base 属性自愈了？", A.data.attributes.get(plock.BASE_ATTR) is not None)
C.chk("9b-base base 被破坏后仍能适配（或至少给出提示）", d > 1e-6,
      "几何Δ=%.2e, 自愈=%s" % (d, A.data.attributes.get(plock.BASE_ATTR) is not None))

print("\n### 9c. 原形属性（compify_plock_orig）被删除后重置 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3, shape="立体")
w_orig = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
plock.lock_group(sc, cam)
cam.location.x = 2.0
C.run_handler(sc)
A.data.attributes.remove(A.data.attributes.get(plock.ORIG_ATTR))
try:
    rr = plock.reset_group(sc, cam)
    print("   reset:", rr["message"][:100], " success=", rr["success"])
    exc = None
except Exception as e:
    exc = e
    print("   ✗ reset 抛异常:", type(e).__name__, e)
w_after = np.array([tuple(A.matrix_world @ v.co) for v in A.data.vertices])
print("   与原始形状偏差 = %.6f" % float(np.abs(w_after - w_orig).max()))
C.chk("9c orig 丢失时 reset 仍能把几何还原到原形（或如实报告失败）",
      exc is None and (float(np.abs(w_after - w_orig).max()) < 1e-3 or not rr["success"]),
      "偏差=%.4f success=%s" % (float(np.abs(w_after - w_orig).max()), rr["success"]))

C.summary()
