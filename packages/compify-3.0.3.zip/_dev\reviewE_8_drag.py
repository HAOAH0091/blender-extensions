"""审查E-8：拖动一个网格时，handler 是否要扫【所有网格的所有顶点】

怀疑点：apply_user_move 命中后 → recompute_ref_depth() 对每个锁定网格求
        max(d for (x,y,d) in base) —— O(全场景顶点数)，每帧。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(nmesh, nside):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 14)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("ProjMat")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    verts, faces = [], []
    H = 0.4
    for iy in range(nside + 1):
        for ix in range(nside + 1):
            verts.append((-H + 2 * H * ix / nside, -H + 2 * H * iy / nside, 0.0))
    for iy in range(nside):
        for ix in range(nside):
            a = iy * (nside + 1) + ix
            faces.append((a, a + 1, a + nside + 2, a + nside + 1))
    cols = int(nmesh ** 0.5) + 1
    objs = []
    for i in range(nmesh):
        me = bpy.data.meshes.new("G%d" % i)
        me.from_pydata(verts, [], faces)
        me.update()
        o = bpy.data.objects.new("Grid%d" % i, me)
        sc.collection.objects.link(o)
        o.location = ((i % cols) * 1.0 - cols * 0.5, (i // cols) * 1.0 - cols * 0.5, 0.0)
        o.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cd.name),
                                 "ShaderNodeTree")
        objs.append(o)
    bpy.context.view_layer.update()
    return sc, cam, cd, objs


print("%-8s %-8s %-10s %-12s %-14s %-14s %-12s" % (
    "网格数", "单格顶点", "总顶点", "锁定_ms", "空闲帧_ms", "拖1格帧_ms", "recompute_ms"))
for nmesh, nside in ((50, 32), (50, 101), (200, 101), (500, 32)):
    sc, cam, cd, objs = build(nmesh, nside)
    tot = sum(len(o.data.vertices) for o in objs)
    plock._proj_cache.clear()
    plock._base_cache.clear()
    plock._last_view.clear()
    t0 = time.perf_counter()
    plock.lock_group(sc, cam)
    t_lock = (time.perf_counter() - t0) * 1000.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)

    idle = []
    for _ in range(4):
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)
        idle.append((time.perf_counter() - t0) * 1000.0)

    target = objs[0]
    drag = []
    for f in range(4):
        target.location.z += 0.05          # 朝相机推近 = 真实拖动
        bpy.context.view_layer.update()
        t0 = time.perf_counter()
        plock.parallax_lock_update_handler(sc)
        drag.append((time.perf_counter() - t0) * 1000.0)

    groups = plock.load_groups(sc)
    st = groups[cd.name]
    t0 = time.perf_counter()
    plock.recompute_ref_depth(sc, st, cd.name)
    t_re = (time.perf_counter() - t0) * 1000.0

    print("%-8d %-8d %-10d %-12.0f %-14.1f %-14.1f %-12.1f" % (
        nmesh, (nside + 1) ** 2, tot, t_lock, sum(idle) / len(idle),
        sum(drag) / len(drag), t_re))
    sys.stdout.flush()
