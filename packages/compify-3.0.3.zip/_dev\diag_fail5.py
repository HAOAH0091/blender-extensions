"""诊断 [5]：ref 一致但 B 位置差 0.38 —— 逻辑上讲不通，必须查清

两条路径对比：
  路径①：setup → 移相机 +1.0
  路径②：setup → 拖 A +1.5 → 移相机 +1.0
逐步打印：ref_depth / A 的 offset / A 的 base d / B 的 k / B 的世界位置
"""
import bpy, sys, os
import importlib.util
import numpy as np
from bpy_extras.object_utils import world_to_camera_view

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(zA=0.0, zB=2.0):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns,
                              -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("A", -1.5, zA)
    B = mk("B", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def info(tag, sc, A, B):
    st = plock.get_state(sc, cam=None) if False else plock.get_state(sc, bpy.context.scene.camera)
    ref = st.get("ref_depth", 0)
    oa = A.get(plock.DRAG_OFFSET_KEY, 0.0)
    ob_ = B.get(plock.DRAG_OFFSET_KEY, 0.0)
    ba = plock._read_base_attribute(A)
    bb = plock._read_base_attribute(B)
    da = max(d for (_x, _y, d) in ba) if ba else None
    db = max(d for (_x, _y, d) in bb) if bb else None
    wb = np.array([list(B.matrix_world @ v.co) for v in B.data.vertices]).mean(axis=0)
    print("    %-22s ref=%.4f | A: off=%+.3f dmax=%.3f | B: off=%+.3f dmax=%.3f | Bworld_x=%+.6f"
          % (tag, ref, oa, da, ob_, db, wb[0]))
    return ref, wb


print("=" * 96)
print("路径①：锁定 → 移相机 +1.0（不拖 A）")
print("=" * 96)
sc, cam, cd, A, B = build()
r = plock.lock_group(sc, cam)
info("锁定后", sc, A, B)
cam.location.x = 1.2
step(sc)
info("移到 1.2", sc, A, B)
cam.location.x = 2.2
step(sc)
ref1, wb1 = info("移到 2.2", sc, A, B)

print()
print("=" * 96)
print("路径②：锁定 → 拖 A +1.5 → 移相机 +1.0")
print("=" * 96)
sc, cam, cd, A, B = build()
r = plock.lock_group(sc, cam)
info("锁定后", sc, A, B)
cam.location.x = 1.2
step(sc)
info("移到 1.2", sc, A, B)
A.location.z += 1.5
step(sc)
info("拖 A +1.5 后", sc, A, B)
cam.location.x = 2.2
step(sc)
ref2, wb2 = info("移到 2.2", sc, A, B)

print()
print("=" * 96)
print("对比")
print("=" * 96)
print("  ref_depth:  路径① %.6f   路径② %.6f   差 %.8f" % (ref1, ref2, abs(ref1 - ref2)))
print("  B 世界 x :  路径① %+.8f  路径② %+.8f  差 %.8f" % (wb1[0], wb2[0], abs(wb1[0] - wb2[0])))
print()
if abs(ref1 - ref2) < 1e-9 and abs(wb1[0] - wb2[0]) > 1e-6:
    print("  ⚠️ ref 相同但 B 位置不同 → 存在 ref 之外的影响因素，必须查")
elif abs(ref1 - ref2) > 1e-9:
    print("  → ref 本来就不同（对齐 PSD 的预期结果）：拖 A 改变了基准层")
    print("    路径① ref=%.4f（A 深度8最深）" % ref1)
    print("    路径② ref=%.4f（A 拖远后深度变浅）" % ref2)
    print("  ⇒ [5] 的判据需要更新：不能要求「B 与对照组完全一致」")
print("DIAG5_DONE")
