"""对比：compify 现状（ref 冻结）vs 对齐 PSD（ref 在相机变化时重算）

PSD 源码事实（parallax_utils.py）：
  · L857  ref_depth = get_parallax_reference_depth(locked_objects)   ← 每帧现算 = max(locked_depth)
  · L998  拖动后 obj["locked_depth"] = current_depth                 ← 新深度写回基准
  · L871  if camera_changed_since_last_adapt(...) ⇒ 才适配
  ⇒ ref 换人【延迟生效】：拖动当帧不用它，只有相机再动时才用。

本脚本测：拖动 A 让它变浅（基准层换成 B）之后，再移相机，三层表现差异。
"""
import bpy, sys, os
import importlib.util
import numpy as np
from bpy_extras.object_utils import world_to_camera_view

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

SCREEN_X = 0.15
LAYERS = [("A", 8.0), ("B", 6.0), ("C", 4.0)]
FOCAL_RATIO = 50.0 / 36.0


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.resolution_x = 960
    sc.render.resolution_y = 540
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 10); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    objs = {}
    for (nm, dep) in LAYERS:
        wx = SCREEN_X * dep; z0 = 10.0 - dep; h = 0.3
        verts = [(wx-h,-h,z0), (wx+h,-h,z0), (wx+h,h,z0), (wx-h,h,z0)]
        mesh = bpy.data.meshes.new(nm)
        mesh.from_pydata(verts, [], [(0,1,2,3)]); mesh.update()
        ob = bpy.data.objects.new(nm, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        objs[nm] = ob
    bpy.context.view_layer.update()
    return sc, cam, cd, objs


def wcen(ob):
    mw = ob.matrix_world
    return np.array([list(mw @ v.co) for v in ob.data.vertices]).mean(axis=0)


def scen(ob, cam, sc):
    p = np.array([list(world_to_camera_view(sc, cam, ob.matrix_world @ v.co))[:2]
                  for v in ob.data.vertices])
    return p.mean(axis=0)


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def run(mode):
    """mode: 'freeze' = 现状 / 'psd' = 相机变化时重算 ref"""
    sc, cam, cd, objs = build()
    plock.lock_group(sc, cam)
    ref_lock = plock.get_state(sc, cam).get("ref_depth", 0)

    # ── 拖 A，让它变浅到深度 3（此时最深的是 B=6）──
    A, B, C = objs["A"], objs["B"], objs["C"]
    before_drag = {n: scen(o, cam, sc) for n, o in objs.items()}
    A.location.z = 10.0 - 3.0          # 深度 8 → 3
    step(sc)
    after_drag = {n: scen(o, cam, sc) for n, o in objs.items()}
    drag_jump = {n: float(np.abs(after_drag[n] - before_drag[n]).max()) for n in objs}

    ref_after_drag = plock.get_state(sc, cam).get("ref_depth", 0)

    # 若走 PSD 语义：ref 应重算成当前最深 = 6
    if mode == "psd":
        st = plock.get_state(sc, cam)
        plock.recompute_ref_depth(sc, st, cd.name)
        plock.save_groups(sc, {cd.name: st})
        step(sc)
    ref_now = plock.get_state(sc, cam).get("ref_depth", 0)

    # ── 移相机 ──
    w0 = {n: wcen(o) for n, o in objs.items()}
    s0 = {n: scen(o, cam, sc) for n, o in objs.items()}
    cam.location.x += 1.0
    step(sc)
    w1 = {n: wcen(o) for n, o in objs.items()}
    s1 = {n: scen(o, cam, sc) for n, o in objs.items()}

    return {
        "ref_lock": ref_lock, "ref_after_drag": ref_after_drag, "ref_now": ref_now,
        "drag_jump": drag_jump,
        "world": {n: w1[n][0]-w0[n][0] for n in objs},
        "screen": {n: s1[n][0]-s0[n][0] for n in objs},
    }


print("=" * 96)
print("Setup：三层同视线，深度 8/6/4，基准=8（A 最深）")
print("操作：把 A 从深度 8 拖到深度 3（此时 B=6 成了最深的那层），然后相机横移 +1.0")
print("=" * 96)

for mode, label in [("freeze", "① compify 现状：ref 冻结（我上一轮的改法）"),
                    ("psd",    "② 对齐 PSD：相机变化时重算 ref")]:
    r = run(mode)
    print("\n" + "-" * 96)
    print(label)
    print("-" * 96)
    print("  ref:  锁定 %.2f  →  拖完后 %.2f  →  正式使用 %.2f" % (
        r["ref_lock"], r["ref_after_drag"], r["ref_now"]))
    print("\n  【拖动当帧】三层画面位置变化（看会不会抖）：")
    for n in ("A", "B", "C"):
        v = r["drag_jump"][n]
        print("    %s: %.8f  %s" % (n, v, "← 被拖的，应该动" if n == "A" else "← 没被拖，应≈0"))
    print("\n  【移相机 +1.0】世界位移 / 画面位移：")
    print("    %-3s %18s %18s" % ("层", "世界Δx", "画面Δx"))
    for n in ("A", "B", "C"):
        print("    %-3s %+18.8f %+18.8f" % (n, r["world"][n], r["screen"][n]))
    # 三层画面位移是否一致（构图保持）
    vals = list(r["screen"].values())
    same = max(vals) - min(vals) < 1e-6
    print("    三层画面位移是否一致：%s  （=构图保持）" % ("✓ 是" if same else "✗ 否"))
    print("    画面滚动的量 |Δ| = %.6f  （理论 1/ref × %.4f = %.6f）" % (
        abs(vals[0]), FOCAL_RATIO, (1.0 / r["ref_now"]) * FOCAL_RATIO))

print()
print("=" * 96)
print("结论")
print("=" * 96)
rf = run("freeze"); rp = run("psd")
print("  拖动当帧：两种做法下 B、C 都不动（证明「不抖」不依赖于冻结 ref）")
print("    freeze:  B=%.8f  C=%.8f" % (rf["drag_jump"]["B"], rf["drag_jump"]["C"]))
print("    psd   :  B=%.8f  C=%.8f" % (rp["drag_jump"]["B"], rp["drag_jump"]["C"]))
print()
print("  移相机后滚动量：")
print("    freeze: ref=%.2f  画面滚 %.6f" % (rf["ref_now"], abs(rf["screen"]["A"])))
print("    psd   : ref=%.2f  画面滚 %.6f" % (rp["ref_now"], abs(rp["screen"]["A"])))
print("    ⇒ 差异 %.1f%%（对齐 PSD 后滚%s）" % (
    abs(abs(rp["screen"]["A"]) / abs(rf["screen"]["A"]) - 1) * 100,
    "更快" if abs(rp["screen"]["A"]) > abs(rf["screen"]["A"]) else "更慢"))
print()
print("  两种做法「三层画面位移都一致」吗：freeze=%s  psd=%s" % (
    max(abs(v) for v in rf["screen"].values()) - min(abs(v) for v in rf["screen"].values()) < 1e-6,
    max(abs(v) for v in rp["screen"].values()) - min(abs(v) for v in rp["screen"].values()) < 1e-6))
print("CMP_DONE")
