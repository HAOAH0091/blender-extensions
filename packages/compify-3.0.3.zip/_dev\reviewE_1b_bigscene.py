"""审查E-1b：大场景 3000 网格 —— 空闲帧（相机静止、不拖动）仍在付出多少

`locked_objects()` 每帧全库扫描（行 2984），随对象数线性增长。
"""
import bpy, sys, os, time
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

N = 3000
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cd.lens = 50.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 14)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
ns, H = 2, 0.4
verts, faces = [], []
for iy in range(ns + 1):
    for ix in range(ns + 1):
        verts.append((-H + 2 * H * ix / ns, -H + 2 * H * iy / ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy * (ns + 1) + ix
        faces.append((a, a + 1, a + ns + 2, a + ns + 1))
cols = 60
for i in range(N):
    me = bpy.data.meshes.new("G%d" % i)
    me.from_pydata(verts, [], faces)
    me.update()
    o = bpy.data.objects.new("Grid%d" % i, me)
    sc.collection.objects.link(o)
    o.location = ((i % cols) * 0.9 - cols * 0.45, (i // cols) * 0.9, 0.0)
    o.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (me.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

t0 = time.perf_counter()
plock.lock_group(sc, cam)
t_lock = (time.perf_counter() - t0) * 1000.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)

idle, moving = [], []
for _ in range(6):
    t0 = time.perf_counter()
    plock.parallax_lock_update_handler(sc)
    idle.append((time.perf_counter() - t0) * 1000.0)
for _ in range(6):
    cam.location.x += 0.01
    bpy.context.view_layer.update()
    t0 = time.perf_counter()
    plock.parallax_lock_update_handler(sc)
    moving.append((time.perf_counter() - t0) * 1000.0)

print("对象数=%d  锁定=%.0f ms  空闲帧均=%.1f ms (max %.1f)  动相机帧均=%.1f ms (max %.1f)"
      % (N, t_lock, sum(idle) / len(idle), max(idle),
         sum(moving) / len(moving), max(moving)))
print("空闲帧 fps 上限 ≈ %.1f；动相机 fps 上限 ≈ %.1f" % (
    1000.0 / (sum(idle) / len(idle)), 1000.0 / (sum(moving) / len(moving))))
