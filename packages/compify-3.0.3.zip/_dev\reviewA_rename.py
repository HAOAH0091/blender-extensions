"""审查 A-4：锁定中改名（网格对象名 / 网格数据名 / 相机对象名 / 相机数据名）→
   解锁、再锁定、重置 是否还对得上
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock


def case(tag, rename, extra_check=None):
    L.report("A-4 %s" % tag)
    C = L.build(n_grid=3)
    sc, cam, cd = C["scene"], C["cam"], C["cd"]
    A, B = C["objs"][0], C["objs"][1]
    orig_a = L.lverts(A).copy()
    plock.lock_group(sc, cam)
    cam.location.x += 0.6
    L.run_h(sc, times=1)
    u_lock = L.uvimg("rn")
    try:
        rename(cam, cd, A, B)
        err = ""
    except Exception as e:
        err = repr(e)
    L.chk("%s：改名不抛异常" % tag, not err, err)
    # 真实 UI 里 unlock 的第一步就是身份自愈迁移 —— 这里按同样顺序先解析一次
    key, st, _ = plock._resolve_state(sc, cam)
    S, Cc = L.node_sc(cam)
    ok_campos = all(L.campos_ok(o, cam) for o in (A, B))
    L.info("改名后 S=%s C=%s 冻结坐标有效=%s 相机数据名=%s"
           % (("%.4f" % S) if S is not None else "组丢失",
              Cc, ok_campos, cd.name))
    L.chk("%s：状态仍能解析到" % tag, st is not None,
          "key=%s enabled=%s" % (key, (st or {}).get("enabled")))
    r = plock.unlock_group(sc, cam)
    u_ul = L.uvimg("rn")
    jump = L.uvd(u_ul, u_lock)
    L.chk("%s：解锁瞬间图案不跳" % tag, jump < 2e-3, "Δ=%.6f" % jump)
    L.chk("%s：解锁成功" % tag, r.get("success"), r.get("message", "")[:56])
    # 再锁定
    r2 = plock.lock_group(sc, cam)
    L.chk("%s：再锁定成功且锁满 3 个" % tag,
          r2.get("success") and len(r2.get("locked") or []) == 3,
          "%s" % r2.get("message", "")[:70])
    # 重置必须回到原形
    r3 = plock.reset_group(sc, cam)
    geo = float(np.abs(L.lverts(A) - orig_a).max())
    L.chk("%s：重置回到原形" % tag, r3.get("success") and geo < 1e-6,
          "Δ=%.2e (%s)" % (geo, r3.get("message", "")[:40]))
    if extra_check:
        extra_check(sc, cam, cd, A, B)


case("网格对象改名", lambda cam, cd, A, B: setattr(A, "name", "RenamedGrid"))
case("网格数据改名", lambda cam, cd, A, B: setattr(A.data, "name", "RenamedMesh"))
case("相机对象改名", lambda cam, cd, A, B: setattr(cam, "name", "CamObj2"))
case("相机数据改名", lambda cam, cd, A, B: setattr(cd, "name", "CamData2"))

print()
L.report("A-4e 相机数据改名后 asset 是否都搬过去了（组名 / 属性名 / 补丁节点）")
C = L.build(n_grid=2)
sc, cam, cd = C["scene"], C["cam"], C["cd"]
A = C["objs"][0]
plock.lock_group(sc, cam)
old = cd.name
old_attr = plock._campos_attr_name(old)
cd.name = "CamNew"
plock._resolve_state(sc, cam)          # 触发身份自愈迁移
new_attr = plock._campos_attr_name(cd.name)
L.info("投影组：%s → %s"
       % (bool(bpy.data.node_groups.get(plock.CAM_PROJECT_PREFIX + old)),
          bool(bpy.data.node_groups.get(plock.CAM_PROJECT_PREFIX + cd.name))))
L.chk("改名后冻结坐标属性跟着改名",
      A.data.attributes.get(old_attr) is None and A.data.attributes.get(new_attr) is not None,
      "旧=%s 新=%s" % (old_attr, new_attr))
L.chk("改名后补丁 Attribute 节点指向新属性名",
      plock._patch_info(cd.name) is not None
      and plock.is_patched(cd.name), "patched=%s" % plock.is_patched(cd.name))
L.chk("改名后 UV Adjust 组名跟着改",
      any(g.name.endswith(" | " + cd.name) and g.name.startswith(plock.UV_ADJUST_PREFIX)
          for g in bpy.data.node_groups),
      [g.name for g in bpy.data.node_groups if g.name.startswith(plock.UV_ADJUST_PREFIX)])
L.summary()
