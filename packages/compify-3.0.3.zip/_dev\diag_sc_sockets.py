"""打印投影组里 S/C 周围的真实链路，确认判据错在哪

我的判据假设：S.inputs[0] <- Perspective4，C.inputs[0] <- S，C.outputs <- Zoom3
但「完好无损的组」也报 C 上游不是 S ⇒ 判据本身错了，先看真相。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
names = sys.modules[PKG + ".names"]
S_NAME = names.PLOCK_S_NODE
C_NAME = names.PLOCK_C_NODE

bpy.ops.wm.read_factory_settings(use_empty=True)
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
bpy.context.scene.collection.objects.link(cam)
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

s = grp.nodes.get(S_NAME)
c = grp.nodes.get(C_NAME)
print("=" * 90)
print("=== S 节点 ===")
print("  name=%r label=%r type=%s op=%s" % (s.name, s.label, s.bl_idname, s.operation))
print("  输入:")
for i, inp in enumerate(s.inputs):
    src = inp.links[0].from_node if inp.links else None
    print("    [%d] %-10s links=%d  from=%s"
          % (i, inp.name, len(inp.links),
             ("%s (label=%r)" % (src.bl_idname, src.label)) if src else "-"))
print("  输出:")
for i, o in enumerate(s.outputs):
    print("    [%d] %-10s links=%d -> %s"
          % (i, o.name, len(o.links),
             [ (l.to_node.bl_idname, l.to_socket.name, l.to_node.label) for l in o.links ]))

print("=" * 90)
print("=== C 节点 ===")
print("  name=%r label=%r type=%s op=%s" % (c.name, c.label, c.bl_idname, c.operation))
print("  输入:")
for i, inp in enumerate(c.inputs):
    src = inp.links[0].from_node if inp.links else None
    print("    [%d] %-10s links=%d  from=%s%s"
          % (i, inp.name, len(inp.links),
             ("%s (label=%r)" % (src.bl_idname, src.label)) if src else "-",
             "  ← 是 S？%s" % (src is s) if src else ""))
print("  输出:")
for i, o in enumerate(c.outputs):
    print("    [%d] %-10s links=%d -> %s"
          % (i, o.name, len(o.links),
             [ (l.to_node.bl_idname, l.to_socket.name, l.to_node.label) for l in o.links ]))

print("=" * 90)
print("=== Zoom 3 / Perspective 4 实际 label ===")
for n in grp.nodes:
    if n.label in ("Zoom 3", "Perspective 4") or n.name in ("Zoom 3", "Perspective 4"):
        print("  %s: name=%r label=%r" % (n.bl_idname, n.name, n.label))
print()
print("所有 VectorMath 节点（name/label/op）:")
for n in grp.nodes:
    if n.bl_idname == "ShaderNodeVectorMath":
        print("  name=%-14r label=%-20r op=%s" % (n.name, n.label, n.operation))
print("SOCK_DONE")
