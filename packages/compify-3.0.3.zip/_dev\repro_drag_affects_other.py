"""复现：拖动 A 为什么会带动 B

假设根因：
  `recompute_ref_depth` 取「所有锁定对象里最深的顶点」= 全局共享基准。
  拖动 A 改变深度 ⇒ 基准层可能换人 ⇒ ref_depth 变
  ⇒ **所有对象**的 kk = dd/ref_depth 都变 ⇒ 全部重适配 ⇒ B 也跟着动
  ⇒ 换人瞬间 ref_depth 离散跳变 ⇒ 画面「不知道哪来的跳」

本脚本量化三件事：
  [1] 拖 A 后，B 的顶点世界坐标变了多少（期望 0，现状非 0）
  [2] ref_depth 在拖动过程中的变化（跳变源）
  [3] B 在屏幕上的投影位置变了多少 = 用户看到的「构图变化」

对照：拖 A 但 A 仍是最深层（不换人）——此时 B 应该不动。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build(zA, zB):
    """A 在 x=-1.5 深度 zA，B 在 x=+1.5 深度 zB（z 越小越近）"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

    # 用户的操作：生成 A 的投影材质，然后「同时连接复制」给 B
    #   ⇒ A/B 用**同一个材质 datablock**（linked duplicate）
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns,
                              -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)      # ← 同一个材质
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("GridA", -1.5, zA)
    B = mk("GridB", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B, mat


def wverts(ob):
    mw = ob.matrix_world
    return np.array([list(mw @ v.co) for v in ob.data.vertices])


def screen(ob, cam):
    """屏幕投影（归一化到 [-1,1]）"""
    inv = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = inv @ (ob.matrix_world @ v.co)
        if abs(p.z) < 1e-9:
            out.append((0.0, 0.0)); continue
        out.append((p.x / p.z, p.y / p.z))
    return np.array(out)


print("=" * 84)
print("场景：A 在 x=-1.5 / B 在 x=+1.5，共用同一个投影材质（linked）")
print("=" * 84)

for tag, (zA, zB), push in [
    ("① 拖 A 到比 B 更近（基准层换人）", (0.0, 2.0), 3.0),
    ("② 拖 A 但仍比 B 深（不换人）", (0.0, 4.0), -1.0),
]:
    sc, cam, cd, A, B, mat = build(zA, zB)
    st = None
    r = plock.lock_group(sc, cam)
    st = plock.get_state(sc, cam)
    print("\n" + "-" * 84)
    print(tag)
    print("-" * 84)
    print("  锁定：%s" % str(r.get("message", ""))[:64])
    print("  ref_depth = %.4f" % st.get("ref_depth", 0))

    # 移相机（用户操作）
    cam.location.x = 1.2
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    st = plock.get_state(sc, cam)
    print("  移相机 x=+1.2 后 ref_depth = %.4f" % st.get("ref_depth", 0))

    wB0 = wverts(B)
    sB0 = screen(B, cam)
    ref0 = st.get("ref_depth", 0)
    zA0 = A.location.z

    # 拖动 A（模拟用户在视口里拖）
    A.location.z = zA0 + push
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    st = plock.get_state(sc, cam)
    ref1 = st.get("ref_depth", 0)

    wB1 = wverts(B)
    sB1 = screen(B, cam)
    dW = float(np.abs(wB1 - wB0).max())
    dS = float(np.abs(sB1 - sB0).max())

    print("  拖动 A 后 ref_depth = %.4f   (变化 %+.4f)%s" % (
        ref1, ref1 - ref0, "   ←★基准层换人" if abs(ref1 - ref0) > 1e-9 else ""))
    print("  [1] B 的顶点世界坐标最大变化 = %.8f   (期望 0)" % dW)
    print("  [2] B 的屏幕投影最大变化   = %.8f   (期望 0)" % dS)
    print("  [3] B 的位姿变化           = %.8f" % float(np.abs(
        np.array(list(B.matrix_world.translation)) -
        np.array([1.5, 0.0, zB])).max()))

print()
print("=" * 84)
print("结论")
print("=" * 84)
print("  若 [1][2] 非 0 ⇒ 拖动 A 确实带动了 B（复现成功）")
print("  若仅①非 0、②为 0 ⇒ 证实根因是「拖动触发 recompute_ref_depth 换人」")
print("REPRO_DONE")
