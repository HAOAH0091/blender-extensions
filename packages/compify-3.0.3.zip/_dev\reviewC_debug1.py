"""调试：解锁后移相机，渲染为何恰好为 0？逐张打印真值。"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy


def dump(tag, sc, cam, ob, probe):
    uv, mask = probe
    print("  [%s] cam=(%.3f,%.3f,%.3f) lens=%.2f | 可见像素=%d | uv u[%.4f,%.4f] v[%.4f,%.4f] mean(%.4f,%.4f)"
          % (tag, cam.location.x, cam.location.y, cam.location.z, cam.data.lens,
             mask.sum(),
             uv[..., 0][mask].min() if mask.any() else 0, uv[..., 0][mask].max() if mask.any() else 0,
             uv[..., 1][mask].min() if mask.any() else 0, uv[..., 1][mask].max() if mask.any() else 0,
             uv[..., 0][mask].mean() if mask.any() else 0, uv[..., 1][mask].mean() if mask.any() else 0))
    bb = [ob.matrix_world @ mathutils.Vector(c) for c in ob.bound_box] if hasattr(bpy, "mathutils") else None
    import mathutils
    bb = [ob.matrix_world @ mathutils.Vector(c) for c in ob.bound_box]
    xs = [p.x for p in bb]; zs = [p.z for p in bb]
    print("        mesh world x[%.2f,%.2f] z[%.2f,%.2f] matrix_world.T=(%.2f,%.2f,%.2f)"
          % (min(xs), max(xs), min(zs), max(zs),
             ob.matrix_world.translation.x, ob.matrix_world.translation.y, ob.matrix_world.translation.z))


sc, cam, cd, mat, ob = build(shape="平面", cam_loc=(0, 0, 5), cam_rot=(0, 0, 0), res=(96, 96), nsub=6)
p = render_uv("d0"); dump("no-lock", sc, cam, ob, p)

plock.lock_group(sc, cam)
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
p = render_uv("d1"); dump("locked", sc, cam, ob, p)

cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
p = render_uv("d2"); dump("locked+moved", sc, cam, ob, p)

plock.unlock_group(sc, cam)
bpy.context.view_layer.update()
p = render_uv("d3"); dump("unlocked", sc, cam, ob, p)
print("  S/C =", nodes_sc(cd), " patch=", plock.is_patched(cd.name))

cam.location.x += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
p = render_uv("d4"); dump("unlocked+moved", sc, cam, ob, p)
print("  S/C =", nodes_sc(cd), " patch=", plock.is_patched(cd.name))
print("DEBUG_DONE")
