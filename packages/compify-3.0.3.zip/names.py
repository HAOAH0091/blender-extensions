MAIN_NODE_NAME = "Compify Footage"
BAKE_IMAGE_NODE_NAME = "Baked Lighting"
UV_LAYER_NAME = 'Compify Baked Lighting'

# UV Adjust node group constants
UV_ADJUST_NODE_GROUP_PREFIX = "UV Adjust"
UV_ADJUST_INPUT_SOCKET_NAME = "Camera Projection UV"
UV_ADJUST_OUTPUT_SOCKET_NAME = "Adjusted UV"

# ★ 解锁「落实构图」用的 C + k 参数（方案 D，2026-10-19 用户拍板）。
#
#   语义（用户）：「锁定时是调整，解锁后实现这个调整」；
#   锁定期间图案粘住网格不滑动，解锁那一帧不能跳，解锁后相机一动图案正常滑动。
#
#   实测结论（_dev/diag_affine.py / diag_analytic.py，15 个场景）：
#     需要的 UV 修正量 delta 总能精确写成
#         delta = C + k · persp(p)
#     其中 C 是二维常量、k 是标量（残差 < 4e-07）。
#     · 平移：k = 0，delta 退化成常量 C
#     · 旋转：C = 0、k = 0（几何已被 adapt_object 变形，实时投影本就等于冻结图案）
#     · 变焦：C = 0，k = 焦距比 − 1（相机 dolly 使得 x/z 整体缩放）
#
#   投影组里对应两个**普通数值节点**（不是逐顶点属性）：
#         UV = persp(p) · S + C          （S = 1 + k）
#   数值全部由插件写入 ⇒ 任何网格用了该投影材质就自动共享同一构图，
#   不存在「解锁后才换材质的网格拿不到状态」那类缺陷（用户实测报过 B 的问题）。
#
#   锁定期间 S = 1、C = 0 ⇒ 恒等变换，主链行为与旧版完全一致。
PLOCK_S_NODE = "PLock Delta S"      # VectorMath(SCALE)：UV = persp · S
PLOCK_C_NODE = "PLock Delta C"      # VectorMath(ADD) ：UV = UV + C
PLOCK_DELTA_VERSION_KEY = "compify_plock_delta_version"
PLOCK_DELTA_VERSION = 1

# 旧版逐顶点属性（方案 D 之前）。只为**清理旧工程残留**保留名字，不再参与计算。
UV_DELTA_ATTR_LEGACY = "compify_plock_uv_delta"

def compify_mat_name(context):
    """
    Get the Compify Material name for the active scene.
    
    Args:
        context: Blender context object
        
    Returns:
        str: The Compify material name (format: "Compify Footage | {scene_name}")
    """
    return "Compify Footage | " + context.scene.name


def compify_baked_texture_name(context):
    """
    Get the Compify baked lighting image name for the active scene.
    
    Args:
        context: Blender context object
        
    Returns:
        str: The Compify bake texture name (format: "Compify Bake | {scene_name}")
    """
    return "Compify Bake | " + context.scene.name


def uv_adjust_node_group_name(obj, camera):
    """
    Get the UV Adjust node group name for a specific object and camera.
    
    Uses data-block names to avoid losing linkage when object names change.
    
    Args:
        obj: Blender object
        camera: Blender camera object
        
    Returns:
        str: The UV Adjust node group name (format: "UV Adjust | {obj_data} | {cam_data}")
    """
    obj_data_name = obj.data.name if getattr(obj, 'data', None) else obj.name
    cam_data_name = camera.data.name if getattr(camera, 'data', None) else camera.name
    return f"{UV_ADJUST_NODE_GROUP_PREFIX} | {obj_data_name} | {cam_data_name}"


def camera_project_node_group_name(camera):
    """
    Get the Camera Project node group name for a specific camera.
    
    Uses camera data-block name for stable association.
    
    Args:
        camera: Blender camera object
        
    Returns:
        str: The Camera Project node group name (format: "Camera Project | {cam_data}")
    """
    cam_data_name = camera.data.name if getattr(camera, 'data', None) else camera.name
    return f"Camera Project | {cam_data_name}"


def baked_material_name(original_material_name):
    """
    Get baked material name from original material name.

    Format: "Baked_{original_material_name}"

    Args:
        original_material_name: Name of the original material

    Returns:
        str: The baked material name
    """
    return f"Baked_{original_material_name}"


def baked_image_name(material_name, object_data_name):
    """
    Get baked image name from material and object data names.

    Format: "Bake_{material_name}_{object_data_name}"
    Uses data-block names for stable association.

    Args:
        material_name: Name of the material being baked
        object_data_name: Data-block name of the object being baked

    Returns:
        str: The baked image name
    """
    return f"Bake_{material_name}_{object_data_name}"
