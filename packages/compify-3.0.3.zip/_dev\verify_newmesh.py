"""真渲染复核：解锁后 B 后接入材质，是否与「按锁定相机看」一致

判据：
  R1 = 解锁后（A 有 delta、B 补写后）的画面
  R2 = 把相机搬回锁定位置、清掉所有 delta 后的画面
  若 R1 ≈ R2 ⇒ A、B 都呈现「锁定相机构图」，是同一个构图层次。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

OUT = os.path.dirname(os.path.abspath(__file__))
RES = 240
P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-48s %s" % ("PASS" if c else "FAIL", n, d))


def make_checker(size=256, cells=8):
    img = bpy.data.images.new("Chk", size, size, alpha=False)
    px = np.zeros((size, size, 4), dtype=np.float32)
    cell = size // cells
    for y in range(size):
        for x in range(size):
            on = ((x // cell) + (y // cell)) % 2 == 0
            v = 0.95 if on else 0.05
            px[y, x] = (v, v, v, 1.0)
    img.pixels.foreach_set(px.reshape(-1))
    img.pack()
    return img


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = RES; sc.render.resolution_y = RES
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = "PNG"
sc.view_settings.view_transform = "Standard"
try: sc.eevee.taa_render_samples = 1
except Exception: pass

cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

img = make_checker()
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])


def grid(name, x):
    Ns = 3; H = 1.2
    verts, faces = [], []
    for iy in range(Ns+1):
        for ix in range(Ns+1):
            verts.append((x-H+2*H*ix/Ns, -H+2*H*iy/Ns, 0.0))
    for iy in range(Ns):
        for ix in range(Ns):
            a = iy*(Ns+1)+ix
            faces.append((a, a+1, a+Ns+2, a+Ns+1))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces); mesh.update()
    ob = bpy.data.objects.new(name, mesh)
    sc.collection.objects.link(ob)
    return ob


A = grid("GridA", -1.6)
B = grid("GridB", 1.6)
A.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

_seq = [0]
def render(tag):
    _seq[0] += 1
    path = os.path.join(OUT, "_nm_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    for o in (A, B):
        o.data.update_tag()
    bpy.context.view_layer.update()
    bpy.context.evaluated_depsgraph_get().update()
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(path)
    n = im.size[0]*im.size[1]*4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :3].copy()
    bpy.data.images.remove(im)
    return a


def pd(a, b):
    d = np.abs(a - b)
    return float((d.max(axis=2) > 0.02).mean() * 100)


print("=" * 78)
print("场景：只有 A 有投影材质 → 锁定 → 移相机 → 解锁 → B 换成同一材质")
print("=" * 78)
LOCK_LOC = cam.location.copy()
plock.lock_group(sc, cam)
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("\n解锁:", plock.unlock_group(sc, cam)["message"])

B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
print("B delta 属性:", B.data.attributes.get(plock.UV_DELTA_ATTR) is not None)
print("A delta 属性:", A.data.attributes.get(plock.UV_DELTA_ATTR) is not None)

# 记录「只有 A 有材质」时的解锁画面（B 是空的）
r_both = render("unlocked")

# 参考：相机搬回锁定位置 + 清掉所有 delta ⇒ 纯实时投射 = 「按锁定相机看」
for o in (A, B):
    a = o.data.attributes.get(plock.UV_DELTA_ATTR)
    if a is not None:
        o.data.attributes.remove(a)
cam.location = LOCK_LOC
bpy.context.view_layer.update()
r_ref = render("reference")

d = pd(r_both, r_ref)
chk("解锁后画面 == 按锁定相机看的画面", d < 0.5, "变化像素 %.2f%%" % d)
print("   （这条成立 ⇒ A、B 的图案都钉在「锁定相机构图」上，是同一层次）")

print()
print("=" * 78)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("NEWMESH_RENDER_DONE")
