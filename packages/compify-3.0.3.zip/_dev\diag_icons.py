"""验证弹窗里用到的 icon 名字是否有效（无效会让 label 抛异常 → 弹窗消失）"""
import bpy, sys
sys.stdout.reconfigure(encoding="utf-8")

fn = bpy.types.UILayout.bl_rna.functions["label"]
param = fn.parameters["icon"]
valid = {e.identifier for e in param.enum_items}
print("可用 icon 数量:", len(valid))

for name in ["ERROR", "OBJECT_DATA", "DOT", "RIGHTARROW", "INFO", "WARNING"]:
    print("  %-14s %s" % (name, "有效" if name in valid else "【无效】"))

# 实际调用一次确认（在真实 layout 上）
import bpy
mat = bpy.data.materials.new("t")
mat.use_nodes = True
nt = mat.node_tree
nn = nt.nodes.new("ShaderNodeValue")
for name in ["ERROR", "OBJECT_DATA"]:
    try:
        class Fake:
            def __init__(self):
                self.layout = None
        # 用 node 的 draw 不便；改验证 enum 即可
        print("  %s 在 enum 里: %s" % (name, name in valid))
    except Exception as e:
        print("  ", name, "异常", e)
print("ICON_CHECK_DONE")
