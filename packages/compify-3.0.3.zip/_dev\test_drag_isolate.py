"""测试：拖动只影响被拖动的对象（对齐 PSD「拖谁动谁」）

用户实测反馈（2026-10-20）：
  A/B 共用同一投影材质 → 锁定 → 移相机 → 拖 A
  ⇒ B 也被带着动，且构图变化 + 无法复现的跳变。

根因：拖动后 `recompute_ref_depth` 改写了**全部网格共享**的 ref_depth
     ⇒ 所有 kk = dd/ref_depth 一起变 ⇒ 别的网格被重新适配。

判据（全部要求「另一网格完全不动」）：
  [1] 拖最深的 A（+／-）→ B 顶点世界坐标 & 屏幕投影变化 = 0
  [2] 拖较浅的 B → A 不变（本来就不该变，作为反证）
  [3] ref_depth 在整个拖动过程中恒定（跳变源消失）
  [4] 拖 A 之后，A 自己的屏幕投影不变（PSD 拖图层：拖的瞬间看不出变化）
  [5] 拖 A 之后再移相机：A 按新深度滚动，**B 仍然完全不变**
  [6] 判据区分力：手动把 ref_depth 改掉（模拟旧行为）→ B 必须动
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []


def chk(n, c, d=""):
    (P if c else F).append(n)
    print("  [%s] %-46s %s" % ("PASS" if c else "FAIL", n, d))


def build(zA, zB):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    # 用户操作：生成 A 的投影材质，然后「同时连接复制」给 B ⇒ 同一个材质 datablock
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def mk(name, x0, z0):
        ns = 2; h = 1.0
        verts, faces = [], []
        for iy in range(ns + 1):
            for ix in range(ns + 1):
                verts.append((x0 - h + 2 * h * ix / ns,
                              -h + 2 * h * iy / ns, z0))
        for iy in range(ns):
            for ix in range(ns):
                a = iy * (ns + 1) + ix
                faces.append((a, a + 1, a + ns + 2, a + ns + 1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                                 "ShaderNodeTree")
        return ob

    A = mk("GridA", -1.5, zA)
    B = mk("GridB", 1.5, zB)
    bpy.context.view_layer.update()
    return sc, cam, cd, A, B


def wverts(ob):
    mw = ob.matrix_world
    return np.array([list(mw @ v.co) for v in ob.data.vertices])


def screen(ob, cam):
    inv = cam.matrix_world.inverted()
    out = []
    for v in ob.data.vertices:
        p = inv @ (ob.matrix_world @ v.co)
        out.append((p.x / p.z, p.y / p.z) if abs(p.z) > 1e-9 else (0.0, 0.0))
    return np.array(out)


def setup(zA=0.0, zB=2.0, cam_move=1.2):
    sc, cam, cd, A, B = build(zA, zB)      # A 深度8（最深）、B 深度6
    plock.lock_group(sc, cam)
    if cam_move:
        cam.location.x = cam_move
        bpy.context.view_layer.update()
        plock.parallax_lock_update_handler(sc)
        bpy.context.view_layer.update()
    return sc, cam, cd, A, B


print("=" * 86)
print("[1][3] 拖 A（最深，+／-）→ B 必须完全不动；ref_depth 必须恒定")
print("=" * 86)
for push in (1.0, -1.0, 2.5):
    sc, cam, cd, A, B = setup()
    ref0 = plock.get_state(sc, cam).get("ref_depth", 0)
    wB0 = wverts(B); sB0 = screen(B, cam)
    A.location.z += push
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    ref1 = plock.get_state(sc, cam).get("ref_depth", 0)
    dW = float(np.abs(wverts(B) - wB0).max())
    dS = float(np.abs(screen(B, cam) - sB0).max())
    print("  拖 A %+.1f: ref %.4f→%.4f" % (push, ref0, ref1))
    chk("拖 A %+.1f → B 顶点不动" % push, dW < 1e-9, "max Δ=%.8f" % dW)
    chk("拖 A %+.1f → B 屏幕投影不动" % push, dS < 1e-9, "max Δ=%.8f" % dS)
    chk("拖 A %+.1f → ref_depth 恒定" % push, abs(ref1 - ref0) < 1e-9,
        "Δ=%.8f" % (ref1 - ref0))

print()
print("=" * 86)
print("[2] 拖较浅的 B → A 不动（反证）")
print("=" * 86)
sc, cam, cd, A, B = setup()
wA0 = wverts(A)
B.location.z += 1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
dA = float(np.abs(wverts(A) - wA0).max())
chk("拖 B → A 顶点不动", dA < 1e-9, "max Δ=%.8f" % dA)

print()
print("=" * 86)
print("[4] 拖 A 的瞬间，A 自己的屏幕投影不变（PSD 拖图层语义）")
print("=" * 86)
sc, cam, cd, A, B = setup()
sA0 = screen(A, cam)
A.location.z += 1.5
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
sA1 = screen(A, cam)
dA = float(np.abs(sA1 - sA0).max())
print("  A 的屏幕投影最大变化 = %.8f" % dA)
chk("拖 A 瞬间 A 的画面位置不变（拖图层语义）", dA < 1e-6, "max Δ=%.8f" % dA)

print()
print("=" * 86)
print("[5] 拖动后移相机：构图保持 + 基准按当前几何重算（对齐 PSD）")
print("=" * 86)
# ⚠️ 判据随实现更新（2026-10-20 对齐 PSD）：
#    旧判据「拖 A 后 B 与不拖 A 完全一致」**不再成立也不该成立** ——
#    对齐 PSD 后，拖动会改变基准深度（因为基准 = 当前最深顶点），
#    所以之后移相机时 B 的滚动速度会变。那不是 bug，是 PSD 的语义。
#    现在的正确判据是：
#      ① 拖动当帧：B 一笔不动（已在 [1] 验证）
#      ② 拖动后移相机：所有层在画面上的位移【完全相同】（构图保持）
#      ③ 基准深度确实按当前几何重算（A 拖浅后基准换成 B）
def after_drag_cam_move(drag_A_to_depth):
    """拖 A 到指定深度，再移相机，返回各层画面位移与 ref"""
    sc, cam, cd, A, B = setup()          # A 深度8 / B 深度6
    if drag_A_to_depth is not None:
        A.location.z += (A_LOCK_DEPTH_DIAG - drag_A_to_depth)
        bpy.context.view_layer.update()
        plock.parallax_lock_update_handler(sc)
        bpy.context.view_layer.update()
    sA0 = screen(A, cam); sB0 = screen(B, cam)
    cam.location.x += 1.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    return (float(np.mean(screen(A, cam)[:, 0] - sA0[:, 0])),
            float(np.mean(screen(B, cam)[:, 0] - sB0[:, 0])),
            plock.get_state(sc, cam).get("ref_depth", 0.0))

A_LOCK_DEPTH_DIAG = 8.0
# ① 不拖：ref 应保持 8
mAn, mBn, refn = after_drag_cam_move(None)
# ② 把 A 拖到深度 3（此时最深的是 B=6）
mAd, mBd, refd = after_drag_cam_move(3.0)

print("  不拖 A ：画面位移 A=%+.8f  B=%+.8f   ref=%.4f" % (mAn, mBn, refn))
print("  拖A到3 ：画面位移 A=%+.8f  B=%+.8f   ref=%.4f" % (mAd, mBd, refd))
chk("不拖时 ref = 8（A 最深）", abs(refn - 8.0) < 1e-6, "ref=%.4f" % refn)
chk("拖 A 到深度3后 ref 重算为 6（B 成最深）", abs(refd - 6.0) < 1e-6, "ref=%.4f" % refd)
chk("拖动后移相机：A/B 画面位移仍严格一致（构图保持）",
    abs(mAd - mBd) < 1e-6, "A=%+.8f B=%+.8f 差=%.10f" % (mAd, mBd, abs(mAd - mBd)))
chk("不拖时 A/B 画面位移也一致", abs(mAn - mBn) < 1e-6,
    "A=%+.8f B=%+.8f" % (mAn, mBn))
chk("拖 A 变浅 ⇒ 滚动更快（基准变小）", abs(mAd) > abs(mAn),
    "不拖 |%+.6f| vs 拖后 |%+.6f|" % (mAn, mAd))

print()
print("=" * 86)
print("[6] 判据区分力：基准深度必须真的影响滚动速度")
print("=" * 86)
# ⚠️ 判据要点：ref 换人是【延迟生效】的 —— 拖动后第一次移相机，
#    位移里同时含「相机滚动」和「补上 ref 变化」两项。
#    所以必须让 ref 先落地（拖完再移一次相机），之后测【纯滚动】。
sc6, cam6, cd6, A6, B6 = setup()
plock.parallax_lock_update_handler(sc6)      # 基线
b0 = screen(B6, cam6)
cam6.location.x += 1.0                       # 不拖的纯滚动 Δ=1.0，ref=8
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc6)
b1 = screen(B6, cam6)
roll_ref8 = abs(float(np.mean(b1[:, 0] - b0[:, 0])))

sc6, cam6, cd6, A6, B6 = setup()
A6.location.z += 5.0                         # A 深度 8 → 3
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc6)
cam6.location.x += 0.5                       # 先移一次让 ref 落地（8 → 6）
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc6)
ref_settled = plock.get_state(sc6, cam6).get("ref_depth", 0)
b0 = screen(B6, cam6)
cam6.location.x += 1.0                       # 纯滚动 Δ=1.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc6)
b1 = screen(B6, cam6)
roll_ref6 = abs(float(np.mean(b1[:, 0] - b0[:, 0])))

c8 = roll_ref8 * 8.0
c6 = roll_ref6 * ref_settled
print("    ref=8 纯滚动 %.10f  滚动×ref = %.10f" % (roll_ref8, c8))
print("    ref=%.0f 纯滚动 %.10f  滚动×ref = %.10f" % (ref_settled, roll_ref6, c6))
chk("基准落地后 ref = 6", abs(ref_settled - 6.0) < 1e-6, "ref=%.4f" % ref_settled)
chk("滚动严格 ∝ 1/基准（两个常数一致）",
    abs(c8 - c6) / max(c8, 1e-12) < 1e-4,
    "%.8f vs %.8f  相对差 %.2e" % (c8, c6, abs(c8 - c6) / max(c8, 1e-12)))
chk("拖 A 变浅 ⇒ 滚动变快", roll_ref6 > roll_ref8,
    "%.6f vs %.6f" % (roll_ref6, roll_ref8))

print()
print("=" * 86)
print("PASS %d / FAIL %d" % (len(P), len(F)))
if F:
    print("FAILED:", F)
print("ISOLATE_DONE")
