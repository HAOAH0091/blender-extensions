"""回归门禁：拖动时的「逐顶点深度适配」精度

用户实测反馈（2026-10-19）：
  「视差锁定对网格的作用是变形以保证效果…最重要是适配变形了…
    简单理解为 PSD 导入工具的视差锁定的顶点版，就是对每个顶点进行视差锁定」

★★ 语义演进（2026-10-20，用户实测「拖动时贴图被压歪」）：

  第一轮（2026-10-19）曾改成「深度统一平移」dd = d + offset ——
  好处是拖动量等于米数，但代价是每个顶点的缩放比 k_i = dd/d 互不相同，
  渲染器透视校正插值的权重（1/当前深度）比例随之改变 ⇒ 插出的 UV 偏了
  ⇒ **贴图被拉歪**（用户工程实测 0.0054，且移相机后仍是歪的）。

  第二轮（2026-10-20）改成**等比**：dd = d * s，s = (mean_d + offset) / mean_d。
  所有顶点同比例 ⇒ 权重比恒定 ⇒ 插值与锁定时刻一致 ⇒ 贴图零变形。
  这也是相机推拉（dolly）本来的行为 —— 插件里只剩一种「改变深度」的方式。

判据（倾斜网格，各顶点深度差异大）：
  1. 每个顶点的新深度 == 原深度 * 统一比例 s（误差 0）
  2. 深度跨度按 s 等比例放大（形体等比缩放，不再只被拉歪）
  3. 屏幕投影不变（图案钉住 —— 视差锁定的核心承诺）
  4. 形心深度位移 == offset（拖动量的语义可预测）
  5. 连续拖动不发散
"""
import bpy
import sys
import os
import math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

P, F = [], []
def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-52s %s" % ("PASS" if cond else "FAIL", name, detail))


def build_tilted():
    """倾斜网格：绕 X 转 55°，顶点深度差异大 —— 全局比例与逐顶点平移会明显分离"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam")
    cd.lens = 50.0
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0)
    cam.rotation_euler = (0.0, 0.0, 0.0)
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    mesh = bpy.data.meshes.new("Tilt")
    ns = 3
    ang = math.radians(55.0)
    verts, faces = [], []
    for iy in range(ns + 1):
        for ix in range(ns + 1):
            lx = -1.0 + 2.0 * ix / ns
            ly = -1.0 + 2.0 * iy / ns
            verts.append((lx, ly * math.cos(ang), ly * math.sin(ang)))
    for iy in range(ns):
        for ix in range(ns):
            a = iy * (ns + 1) + ix
            faces.append((a, a + 1, a + ns + 2, a + ns + 1))
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    ob = bpy.data.objects.new("TiltGrid", mesh)
    sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
    return sc, cam, cd, ob


def cam_space(cam, obj):
    """当前顶点在相机空间的位置 (x, y, depth)
    ⚠️ get_camera_view_matrix 返回的是 camera→world（见 _view_depth 的用法），
       要取逆才是 world→camera。"""
    v_inv = plock.get_camera_view_matrix(cam).inverted()
    out = []
    for vv in obj.data.vertices:
        p = v_inv @ (obj.matrix_world @ vv.co)
        out.append((p.x, p.y, -p.z))
    return np.array(out, dtype=np.float64)


def run():
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(bpy.context.scene)


def main():
    print("=" * 78)
    print("门禁：拖动时的逐顶点深度适配精度")
    print("=" * 78)

    sc, cam, cd, ob = build_tilted()
    r = plock.lock_group(sc, cam)
    chk("锁定成功", r["success"], r.get("message", "")[:40])

    base = plock._read_base_attribute(ob)
    base_arr = np.asarray(base, dtype=np.float64)
    d0 = base_arr[:, 2]
    print("  base 深度: %s" % np.round(d0, 4).tolist())
    print("  深度跨度: %.4f" % (d0.max() - d0.min()))

    view0 = plock.get_camera_view_matrix(cam)
    # 记录锁定时刻的投影
    cs0 = cam_space(cam, ob)
    proj0 = cs0[:, :2] / cs0[:, 2:3]

    # 模拟用户沿视线把物体推 0.6（朝相机方向 ⇒ 深度减小）
    M0 = ob.matrix_world.copy()
    # 相机在 (0,0,5) 朝 -Z ⇒ 视线方向 = 世界 -Z。朝相机推近 = 世界 +Z 平移。
    # 平移 +0.6 ⇒ 深度减少 0.6 ⇒ OFFSET = -0.6
    OFFSET = -0.6
    PUSH = 0.6
    Mt = M0.copy()
    Mt.translation = M0.translation + __import__("mathutils").Vector((0.0, 0.0, PUSH))
    ob.matrix_world = Mt
    bpy.context.view_layer.update()
    run()

    cs1 = cam_space(cam, ob)
    d1 = cs1[:, 2]
    proj1 = cs1[:, :2] / cs1[:, 2:3]

    # 1. 逐顶点深度误差 —— 等比语义：dd = d * s
    mean0 = float(d0.mean())
    ratio = (mean0 + OFFSET) / mean0 if mean0 > 1e-9 else 1.0
    expect_d = d0 * ratio
    err = np.abs(d1 - expect_d)
    chk("1 每顶点新深度 == 原深度 * 统一比例(等比)", err.max() < 5e-3,
        "s=%.6f 最大误差 %.6f" % (ratio, err.max()))

    # 2. 深度跨度等比变化
    span0 = d0.max() - d0.min()
    span1 = d1.max() - d1.min()
    chk("2 深度跨度 == 原跨度 * s（等比缩放）",
        abs(span1 - span0 * ratio) < 5e-3,
        "%.4f -> %.4f (expected %.4f)" % (span0, span1, span0 * ratio))

    # 3. 屏幕投影不变
    dp = np.abs(proj1 - proj0).max()
    chk("3 屏幕投影不变（图案钉住）", dp < 1e-3, "最大变化 %.8f" % dp)

    # 4. 形心深度位移 == offset
    shift = float(d1.mean() - d0.mean())
    chk("4 形心深度位移 == offset（拖动量可预测）", abs(shift - OFFSET) < 5e-3,
        "期望 %.4f 实际 %.4f" % (OFFSET, shift))

    # 5. 连续拖动不发散
    print("\n  连续拖动 6 帧（每帧再推近 0.1）：")
    ok = True
    prev_drag = None
    for f in range(6):
        Mt2 = M0.copy()
        Mt2.translation = M0.translation + __import__("mathutils").Vector((0.0, 0.0, 0.1 * (f + 1)))
        ob.matrix_world = Mt2
        bpy.context.view_layer.update()
        run()
        cur = cam_space(cam, ob)
        drag = ob.get(plock.DRAG_SCALE_KEY, 1.0)
        off = ob.get("compify_plock_drag_offset", 0.0) if "compify_plock_drag_offset" in ob.keys() else None
        print("    帧%d  深度均值 %.4f   drag=%.5f   offset=%s" %
              (f + 1, cur[:, 2].mean(), drag, ("%.4f" % off) if off is not None else "n/a"))
        if f > 0 and prev_drag is not None and abs(drag - prev_drag) > 0.5:
            ok = False
        prev_drag = drag
    chk("5 连续拖动不发散", ok, "drag 未出现跳变")

    print()
    print("=" * 78)
    print("PASS %d / FAIL %d" % (len(P), len(F)))
    if F:
        print("FAILED:", F)
    print("DRAGPREC_DONE")


main()
