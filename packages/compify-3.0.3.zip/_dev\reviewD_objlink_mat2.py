"""审查项 1/3 复核：object-linked 材质槽（slot.link='OBJECT'）的网格
在「同一材质、部分网格参与锁定」场景下会发生什么。

判据：① campos 属性是否存在（结构）② 渲染 UV 场（图案 vs 纯色）
③ 解锁后是否恢复（临时故障 or 永久）。
"""
import bpy
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
SCALE = 0.1


def snap(ob, tag):
    C.show(ob)
    uv, mask, sat = C.render_uv_masked(scale=SCALE, tag=tag)
    s = C.stats_masked(uv, mask)
    print("    %-18s x极差=%.4f y极差=%.4f 均值=(%+.3f,%+.3f)"
          % (tag, s[0], s[1], s[3], s[4]))
    return s


sc = C.reset()
cam, cd = C.new_cam(sc)
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
mat, gn = C.probe_mat("Probe", grp, scale=SCALE)

A = C.new_grid("A")
A.data.materials.append(mat)          # data-linked（正常路径）
C.uv_adjust_group(A, cd)
B = C.new_grid("B")                   # object-linked（用户做了 Link → Object）
B.data.materials.append(None)
B.material_slots[0].link = "OBJECT"
B.material_slots[0].material = mat
bpy.context.view_layer.update()

print("  objects_using_projection = %s" % [o.name for o in plock.objects_using_projection(cd.name)])
print("  get_lock_targets        = %s" % [o.name for o in plock.get_lock_targets(sc, cam)])
r = plock.lock_group(sc, cam)
print("  锁定: frozen=%s | %s" % (r.get("frozen"), r["message"][:50]))
print("  campos: A=%s B=%s" % (C.campos_ok(plock, A, cd.name), C.campos_ok(plock, B, cd.name)))
sA = snap(A, "A（data 材质）")
sB = snap(B, "B（object 材质）")
r = plock.unlock_group(sc, cam)
sB2 = snap(B, "B 解锁后")
C.report("B 拿到冻结坐标", C.campos_ok(plock, B, cd.name))
C.report("B 锁定期间投影仍是图案", sB[0] > 0.05, "x极差=%.4f（均值 %+.3f → 纯色）" % (sB[0], sB[3]))
C.report("B 解锁后恢复", sB2[0] > 0.05, "x极差=%.4f" % sB2[0])
print("\nRD_OBJLINK2_DONE")
