"""审查E-6b：_proj_cache 是否「钉住」已删除的网格数据？条目是否随相机数累积？

量法：RSS（Windows）。200 个 1 万顶点网格 → 让缓存记一份对象列表 → 删对象+删网格
      → 看 RSS 是否回落；再手动 clear 缓存，看差多少。
"""
import bpy, sys, os, gc, ctypes, ctypes.wintypes
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


class PMC(ctypes.Structure):
    _fields_ = [("cb", ctypes.wintypes.DWORD), ("PageFaultCount", ctypes.wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


_k32 = ctypes.WinDLL("kernel32.dll")
_k32.GetCurrentProcess.restype = ctypes.wintypes.HANDLE
_ps = ctypes.WinDLL("psapi.dll")
_ps.GetProcessMemoryInfo.argtypes = [ctypes.wintypes.HANDLE, ctypes.POINTER(PMC),
                                     ctypes.wintypes.DWORD]
_ps.GetProcessMemoryInfo.restype = ctypes.wintypes.BOOL


def rss():
    p = PMC()
    p.cb = ctypes.sizeof(PMC)
    _ps.GetProcessMemoryInfo(_k32.GetCurrentProcess(), ctypes.byref(p), p.cb)
    return p.WorkingSetSize / 1048576.0


bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0, 0, 14)
sc.camera = cam
bpy.context.view_layer.update()
grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup")
gn.node_tree = grp
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

ns = 100
verts, faces = [], []
for iy in range(ns + 1):
    for ix in range(ns + 1):
        verts.append((-0.5 + ix / ns, -0.5 + iy / ns, 0.0))
for iy in range(ns):
    for ix in range(ns):
        a = iy * (ns + 1) + ix
        faces.append((a, a + 1, a + ns + 2, a + ns + 1))
proto = bpy.data.meshes.new("Proto")
proto.from_pydata(verts, [], faces)
proto.update()
proto.materials.append(mat)

NM = 200
objs = []
for i in range(NM):
    me = proto.copy()
    o = bpy.data.objects.new("M%d" % i, me)
    sc.collection.objects.link(o)
    o.location = ((i % 20) * 0.3 - 3, (i // 20) * 0.3, 0.0)
    objs.append(o)
bpy.context.view_layer.update()
gc.collect()
print("建好 %d 个网格（各 %d 顶点，独立数据块 %d 个）RSS=%.1f MB" % (
    NM, len(objs[0].data.vertices), len(bpy.data.meshes), rss()))

res = plock.objects_using_projection_cached(cd.name)
print("缓存命中对象数=%d  _proj_cache=%d 条  RSS=%.1f MB" % (
    len(res), len(plock._proj_cache), rss()))

for o in list(objs):
    bpy.data.objects.remove(o, do_unlink=True)
for m in list(bpy.data.meshes):
    if m.users == 0:
        bpy.data.meshes.remove(m)
bpy.context.view_layer.update()
gc.collect()
print("删掉全部对象与网格  RSS=%.1f MB（_proj_cache 仍 %d 条，持 %d 个对象引用）" % (
    rss(), len(plock._proj_cache),
    sum(len(v[1]) for v in plock._proj_cache.values())))
plock._proj_cache.clear()
gc.collect()
print("手动 clear 缓存后    RSS=%.1f MB" % rss())

print("\n[相机数] 建 20 个相机各查一次投影，再全删")
for i in range(20):
    c2 = bpy.data.objects.new("C%d" % i, bpy.data.cameras.new("CD%d" % i))
    sc.collection.objects.link(c2)
    plock.objects_using_projection_cached("CD%d" % i)
n1 = len(plock._proj_cache)
for i in range(20):
    o = bpy.data.objects.get("C%d" % i)
    if o is not None:
        bpy.data.objects.remove(o, do_unlink=True)
n2 = len(plock._proj_cache)
print("  查 20 个 → _proj_cache=%d 条；相机全删后 = %d 条（不回收）" % (n1, n2))
