"""审查 C · 第 5 项：相机对象 scale（实现里有个刚体假设）

两套坐标混用：
  · 投影组用 TexCoord(object=camera) ⇒ 读的是 camera.matrix_world（**含 scale**）
  · 插件算几何适配用的 get_camera_view_matrix() 把 scale **剥掉**（只留 loc+rot）
  · 而 unlock 的 live 透视坐标又用 camera.matrix_world（含 scale）
本脚本用真渲染量：scale 会不会让图案离开相机真正看到的位置、锁定/解锁是否跳。
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from reviewC_harness import *   # noqa
import bpy


def run(tag, mutate, **kw):
    sc, cam, cd, mat, ob = build(**kw)
    p0 = render_uv("a")
    amx, amn, an = align_err(sc, cam, ob, p0)
    plock.lock_group(sc, cam); plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL = render_uv("l")
    iL, uvL, _ = uv_at_verts(sc, cam, ob, pL)
    mutate(cam, cd)
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()
    pL2 = render_uv("l2")
    iL2, uvL2, _ = uv_at_verts(sc, cam, ob, pL2)
    sm = np.intersect1d(iL, iL2)
    glue = float(np.abs(uvL[np.isin(iL, sm)] - uvL2[np.isin(iL2, sm)]).max()) if len(sm) else float("nan")
    plock.unlock_group(sc, cam)
    bpy.context.view_layer.update()
    pU = render_uv("u")
    jump = diff(pL2, pU)[0]
    print("  %-32s 未锁定对齐=%.4f 粘住=%.4f JUMP=%.4f" % (tag, amx, glue, jump))
    return amx, glue, jump, (sc, cam, ob, p0)


print("### 5 相机 scale ###")
a1 = run("scale=(1,1,1) 对照", lambda cam, cd: setattr(cam.location, "x", 2.0))
a2 = run("scale=(2,2,2) 均匀", lambda cam, cd: setattr(cam.location, "x", 2.0),
         cam_scale=(2, 2, 2))
a3 = run("scale=(2,1,1) 非均匀", lambda cam, cd: setattr(cam.location, "x", 2.0),
         cam_scale=(2, 1, 1))
a4 = run("scale=(1,2,1) 非均匀Y", lambda cam, cd: setattr(cam.location, "x", 2.0),
         cam_scale=(1, 2, 1))
a5 = run("锁定中把 scale 改成 (2,2,2)", lambda cam, cd: setattr(cam, "scale", (2.0, 2.0, 2.0)))

print("\n### 5b scale=(2,1,1) 的逐顶点证据 ###")
sc, cam, ob, p0 = a3[3]
table(sc, cam, ob, p0, n=4)

chk("5 均匀 scale=2：图案仍对齐、不跳",
    a2[0] < 5e-3 and a2[2] < 2e-3, "对齐=%.4f jump=%.4f" % (a2[0], a2[2]))
chk("5 非均匀 scale=(2,1,1)：锁定/解锁不跳",
    a3[2] < 2e-3 and a3[1] < 5e-3, "jump=%.4f glue=%.4f" % (a3[2], a3[1]))
chk("5 非均匀相机 scale：图案仍贴在相机看到的位置", a3[0] < 5e-3,
    "对齐误差 max=%.4f（图案被压缩/拉伸，跟相机取景对不上）" % a3[0])
chk("5 锁定中改 scale：解锁不跳", a5[2] < 2e-3, "jump=%.4f" % a5[2])

report("审查 C · 相机 scale")
