# -*- coding: utf-8 -*-

"""
Compify插件的中文翻译
Translation dictionary for Compify addon
"""

import bpy

# 翻译字典，格式：{locale: {(context, msgid): translation}}
translations_dict = {
    "zh_CN": {
        # 面板标题 - 使用 "*" 上下文
        ("*", "Compify"): "Compify",
        ("*", "Camera Project UV Adjust"): "相机投影UV调整",
        
        # 主面板标签
        ("*", "  Camera"): "  相机",
        
        # 操作按钮标题 - 使用 "*" 上下文（Blender会自动处理Operator标签）
        ("*", "Batch Generate UV Adjust"): "批量生成UV调整",
        ("*", "Refresh & Clean UV Adjust List"): "刷新和清理UV调整列表",
        ("*", "Select Object"): "选择对象",
        ("*", "Select Camera"): "选择相机",
        ("*", "Update UV Adjust"): "更新UV调整",
        ("*", "Delete UV Adjust"): "删除UV调整",
        
        # UV调整面板
        ("*", "Refresh & Clean"): "刷新和清理",
        ("*", "Batch Generate:"): "批量生成:",
        ("*", "Camera"): "相机",
        ("*", "Generate for Selected Objects"): "为选中对象生成",
        ("*", "Selected Mesh Objects: {}"): "选中的网格对象: {}",
        ("*", "No mesh objects selected"): "未选中网格对象",
        
        # 投影材质管理面板
        ("*", "Projection Material Management:"): "投影材质管理:",
        ("*", "No projection materials found"): "未找到投影材质",
        ("*", "Found {} unused node groups"): "发现 {} 个未使用的节点组",
        ("*", "Clean"): "清理",
        ("*", "Shared Group"): "共用组",
        ("*", "Clean Unused Node Groups"): "清理未使用的节点组",
        ("*", "Clean unused node groups."): "清理未使用的节点组。",
        ("*", "Select Material Objects"): "选择材质物体",
        ("*", "Select all objects using this material."): "选择所有使用此材质的物体。",
        
        # UV调整操作 - 已移动到上面的操作按钮标题部分
        
        # 相机对齐面板（来自camera_align.py）
        
        # 相机对齐操作描述
        
        # 属性描述
        ("*", "Bake Resolution"): "烘焙分辨率",
        ("*", "UV Adjust Camera"): "UV调整相机",
        ("*", "Camera to use for UV adjustment calculations"): "用于UV调整计算的相机",
        
        # 操作描述
        ("*", "Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."): "3D合成中对象的相机投影UV调整 - 3D视口侧边栏。",
        ("*", "Refresh UV Adjust node groups list and clean up invalid references"): "刷新UV调整节点组列表并清理无效引用",
        ("*", "Update parameters of a UV Adjust node group"): "更新UV调整节点组的参数",
        ("*", "Batch generate UV adjust node groups."): "批量生成UV调整节点组。",
        ("*", "Select the object associated with this UV adjust."): "选择与此UV调整关联的对象。",
        ("*", "Select the camera associated with this UV adjust."): "选择与此UV调整关联的相机。",
        ("*", "Delete UV adjust."): "删除UV调整。",

        # Baking feature
        ("*", "Bake Material Projection"): "烘焙材质投影",
        ("*", "Bake camera projection, creating new objects with baked textures"): "烘焙相机投影，创建带有烘焙纹理的新对象",
        ("*", "Auto-unwrap UV"): "自动展 UV",
        ("*", "Automatically unwrap UV for objects with existing UV layers"): "对已有 UV 层的对象自动执行展 UV",
        ("*", "UV Handling"): "UV 处理",
    },
    
    "zh_TW": {
        # 繁体中文翻译（可选）
        ("*", "Compify"): "Compify",
        ("*", "Camera Project UV Adjust"): "相機投影UV調整",
        ("*", "  Camera"): "  相機",
        ("*", "Batch Generate UV Adjust"): "批量生成UV調整",
        ("*", "Refresh & Clean UV Adjust List"): "刷新和清理UV調整列表",
        ("*", "Select Object"): "選擇物件",
        ("*", "Select Camera"): "選擇相機",
        ("*", "Update UV Adjust"): "更新UV調整",
        ("*", "Delete UV Adjust"): "刪除UV調整",

        # 3D視口分欄中的列表與狀態文本
        ("*", "Refresh & Clean"): "刷新和清理",
        ("*", "Batch Generate:"): "批量生成:",
        ("*", "Camera"): "相機",
        ("*", "Generate for Selected Objects"): "為選中對象生成",
        ("*", "Selected Mesh Objects: {}"): "選中的網格對象: {}",
        ("*", "No mesh objects selected"): "未選中網格對象",

        # 投影材質管理面板
        ("*", "Projection Material Management:"): "投影材質管理:",
        ("*", "No projection materials found"): "未找到投影材質",
        ("*", "Found {} unused node groups"): "發現 {} 個未使用的節點組",
        ("*", "Clean"): "清理",
        ("*", "Shared Group"): "共用組",
        ("*", "Clean Unused Node Groups"): "清理未使用的節點組",
        ("*", "Clean unused node groups."): "清理未使用的節點組。",
        ("*", "Select Material Objects"): "選擇材質物體",
        ("*", "Select all objects using this material."): "選擇所有使用此材質的物體。",

        # 對齊面板的列標題

        # 操作描述（tooltip）

        # 屬性描述
        ("*", "Bake Resolution"): "烘焙分辨率",
        ("*", "UV Adjust Camera"): "UV調整相機",
        ("*", "Camera to use for UV adjustment calculations"): "用於UV調整計算的相機",

        # 面板/操作的 tooltip 描述
        ("*", "Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."): "3D合成中對象的相機投影UV調整 - 3D視口側邊欄。",
        ("*", "Refresh UV Adjust node groups list and clean up invalid references"): "刷新UV調整節點組列表並清理無效引用",
        ("*", "Update parameters of a UV Adjust node group"): "更新UV調整節點組的參數",
        ("*", "Batch generate UV adjust node groups."): "批量生成UV調整節點組。",
        ("*", "Select the object associated with this UV adjust."): "選擇與此UV調整關聯的物件。",
        ("*", "Select the camera associated with this UV adjust."): "選擇與此UV調整關聯的相機。",
        ("*", "Delete UV adjust."): "刪除UV調整。",
        # 可以继续添加更多繁体中文翻译...

        # Baking feature
        ("*", "Bake Material Projection"): "烘焙材質投影",
        ("*", "Bake camera projection, creating new objects with baked textures"): "烘焙相機投影，創建帶有烘焙紋理的新物件",
        ("*", "Auto-unwrap UV"): "自動展 UV",
        ("*", "Automatically unwrap UV for objects with existing UV layers"): "對已有 UV 層的物件自動執行展 UV",
        ("*", "UV Handling"): "UV 處理",
    }
}

def register(module_name):
    """注册翻译，必须使用插件根模块名作为域"""
    try:
        # 兼容不同版本的中文语言代码：将 zh_CN 映射到 zh_Hans/zh_HANS/zh
        # 将 zh_TW 映射到 zh_Hant/zh_HANT
        aliases = {
            "zh_CN": ["zh_Hans", "zh_HANS", "zh"],
            "zh_TW": ["zh_Hant", "zh_HANT"],
        }
        for src, alist in aliases.items():
            if src in translations_dict:
                for alias in alist:
                    if alias not in translations_dict:
                        translations_dict[alias] = translations_dict[src]
        
        bpy.app.translations.register(module_name, translations_dict)
        print(f"Compify translations registered successfully for domain: {module_name}")
    except Exception as e:
        print(f"Failed to register Compify translations: {e}")


def unregister(module_name):
    """注销翻译，域必须与注册时一致"""
    try:
        bpy.app.translations.unregister(module_name)
        print(f"Compify translations unregistered successfully for domain: {module_name}")
    except Exception as e:
        print(f"Failed to unregister Compify translations: {e}")

if __name__ == "__main__":
    register(__name__)