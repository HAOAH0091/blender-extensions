"""独立审查 A（状态机与生命周期）—— 公共夹具。

不改产品代码；只提供：
  · 按包名 compify_plock_dev 加载插件（照抄 test_ck_unlock_render.py）
  · 搭场景：相机 + N 个平面网格 + UV 探针材质（渲染像素反算 UV）+ UV Adjust 组
  · 判据工具：UV 探针渲染差、逐顶点世界坐标、位姿、C+k 节点值、属性存在性
"""
import bpy
import os
import sys
import math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)


def load():
    spec = importlib.util.spec_from_file_location(
        PKG, os.path.join(PKG_DIR, "__init__.py"),
        submodule_search_locations=[PKG_DIR])
    mod = importlib.util.module_from_spec(spec)
    sys.modules[PKG] = mod
    spec.loader.exec_module(mod)
    return (sys.modules[PKG + ".compify_parallax_lock"],
            sys.modules[PKG + ".node_groups"],
            sys.modules[PKG + ".names"])


plock, ng_mod, names = load()

RES = 64
_seq = [0]
P, F = [], []


def chk(name, cond, detail=""):
    (P if cond else F).append(name)
    print("  [%s] %-44s %s" % ("PASS" if cond else "FAIL", name, detail))
    return bool(cond)


def info(msg):
    print("       · %s" % msg)


def build(shape="plane", cam_loc=(0, 0, 5), cam_rot=(0, 0, 0), lens=50.0,
          n_grid=3, extra=0):
    """返回 dict：scene/cam/cd/mat/objs/grp。"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = RES
    sc.render.resolution_y = RES
    sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    try:
        sc.eevee.taa_render_samples = 1
    except Exception:
        pass
    cd = bpy.data.cameras.new("Cam")
    cd.lens = lens
    cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = cam_loc
    cam.rotation_euler = cam_rot
    sc.camera = cam
    bpy.context.view_layer.update()

    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)

    # UV 探针材质：UV → 颜色（uv/4 + 0.5），渲染后可反算 UV
    mat = bpy.data.materials.new("Probe")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    mr = nt.nodes.new("ShaderNodeMath"); mr.operation = "MULTIPLY"; mr.inputs[1].default_value = 0.25
    mg = nt.nodes.new("ShaderNodeMath"); mg.operation = "MULTIPLY"; mg.inputs[1].default_value = 0.25
    ar = nt.nodes.new("ShaderNodeMath"); ar.operation = "ADD"; ar.inputs[1].default_value = 0.5
    ag = nt.nodes.new("ShaderNodeMath"); ag.operation = "ADD"; ag.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], mr.inputs[0])
    nt.links.new(mr.outputs["Value"], ar.inputs[0])
    nt.links.new(ar.outputs["Value"], comb.inputs["X"])
    nt.links.new(sep.outputs["Y"], mg.inputs[0])
    nt.links.new(mg.outputs["Value"], ag.inputs[0])
    nt.links.new(ag.outputs["Value"], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])

    objs = []
    n = max(1, n_grid)
    H = 2.0
    for i in range(n):
        x0 = 0.0 if n == 1 else (-2.2 + 4.4 * i)
        verts, faces = [], []
        for iy in range(n_grid + 1):
            for ix in range(n_grid + 1):
                x = x0 + (-H + 2 * H * ix / n_grid)
                y = -H + 2 * H * iy / n_grid
                z = 0.0 if shape == "plane" else 0.25 * x
                verts.append((x, y, z))
        for iy in range(n_grid):
            for ix in range(n_grid):
                a = iy * (n_grid + 1) + ix
                faces.append((a, a + 1, a + n_grid + 2, a + n_grid + 1))
        mesh = bpy.data.meshes.new("G%d" % i)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        ob = bpy.data.objects.new("Grid%d" % i, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name),
                                 "ShaderNodeTree")
        objs.append(ob)
    # extra：不属于本相机（无 UV Adjust 组）但材质引用同一投影组的网格
    for k in range(extra):
        mesh = bpy.data.meshes.new("X%d" % k)
        mesh.from_pydata([(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)], [],
                         [(0, 1, 2, 3)])
        mesh.update()
        ob = bpy.data.objects.new("Xtra%d" % k, mesh)
        sc.collection.objects.link(ob)
        ob.data.materials.append(mat)
        objs.append(ob)
    bpy.context.view_layer.update()
    return {"scene": sc, "cam": cam, "cd": cd, "mat": mat, "objs": objs, "grp": grp}


def uvimg(tag="x"):
    """渲染 UV 探针图 → (h,w,2) 的 UV 值。"""
    _seq[0] += 1
    p = os.path.join(HERE, "_ra_%s_%02d.png" % (tag, _seq[0]))
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32)
    im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    try:
        os.remove(p)
    except Exception:
        pass
    return (a - 0.5) * 4.0


def uvd(a, b):
    return float(np.abs(a - b).mean())


def wverts(ob):
    return np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])


def lverts(ob):
    n = len(ob.data.vertices) * 3
    buf = np.empty(n, dtype=np.float64)
    ob.data.vertices.foreach_get("co", buf)
    return buf


def run_h(scene, cam=None, times=1):
    for _ in range(times):
        bpy.context.view_layer.update()
        plock.parallax_lock_update_handler(scene)
        bpy.context.view_layer.update()


def node_sc(cam):
    """读投影组 C+k 的当前值。"""
    nodes = plock._find_delta_nodes(cam.data.name)
    if nodes is None:
        return None, None
    return (float(nodes[0].inputs["Scale"].default_value),
            tuple(round(float(x), 6) for x in nodes[1].inputs[1].default_value)[:2])


def campos_ok(ob, cam):
    a = ob.data.attributes.get(plock._campos_attr_name(cam.data.name))
    if a is None:
        return False
    return len(a.data) == len(ob.data.vertices)


def report(title):
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)


def summary():
    print("\n---- 小结：PASS %d / FAIL %d ----" % (len(P), len(F)))
    for f in F:
        print("  FAIL:", f)
    return len(F)
