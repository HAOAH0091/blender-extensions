import bpy, sys, os, hashlib, inspect
PKG = "compify-master"
m = sys.modules.get(PKG)
if m is None:
    print("!! 插件未加载")
else:
    p = os.path.join(os.path.dirname(m.__file__), "compify_parallax_lock.py")
    b = open(p, "rb").read()
    sub = sys.modules.get(PKG + ".compify_parallax_lock")
    print("=" * 56)
    print("磁盘文件  :", os.path.basename(p), os.path.getsize(p), "bytes")
    print("sha       :", hashlib.sha256(b).hexdigest()[:16])
    print("内存 v3.0.3:", hasattr(sub, "_drag_seen"),
          hasattr(sub, "PENDING_ZERO_KEY"), hasattr(sub, "REANCHOR_KEY"))
    print("adapt 签名:", str(inspect.signature(sub.adapt_object)))
    print("-" * 56)
    print("compify handler 份数（多份就会打架）：")
    n = 0
    for h in bpy.app.handlers.depsgraph_update_post:
        if "compify" in getattr(h, "__module__", ""):
            n += 1
            print("   ", h.__module__, "|", h.__name__)
    print("   => 共", n, "份", "★有问题★" if n > 1 else "OK")
    print("=" * 56)
