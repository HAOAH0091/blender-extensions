"""审查项 2 / 3：多材质槽（只有某个槽是投影材质）、复制材质、同材质多网格。
判据：alpha 掩膜 UV 场（16-bit 探针）+ 逐顶点冻结坐标 + A/C 两网格构图差。
"""
import bpy
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
SCALE = 0.1


def snap(ob, tag):
    C.show(ob)
    uv, mask, sat = C.render_uv_masked(scale=SCALE, tag=tag)
    s = C.stats_masked(uv, mask)
    if s is None:
        print("    %-16s 空" % tag)
        return None, None
    print("    %-16s x极差=%.4f y极差=%.4f 均值=(%+.3f,%+.3f) 钳位=%.1f%%"
          % (tag, s[0], s[1], s[3], s[4], sat * 100))
    return uv, s


def frozen(ob, cd):
    a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    return a is not None and len(a.data) == len(ob.data.vertices)


# ═══════════ 阶段 1：多材质槽，只有第 2 槽是投影材质 ═══════════
print("\n=== 阶段 1：两个材质槽，槽 0 普通、槽 1 投影 ===")
sc = C.reset()
cam, cd = C.new_cam(sc)
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
probe, gn = C.probe_mat("Probe", grp, scale=SCALE)
plain = bpy.data.materials.new("Plain")
plain.use_nodes = True
A = C.new_grid("A")
A.data.materials.append(plain)
A.data.materials.append(probe)
for p in A.data.polygons:
    p.material_index = 1
C.uv_adjust_group(A, cd)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("  锁定: %s | campos=%s" % (r["message"][:40], frozen(A, cd)))
uv0, s0 = snap(A, "锁定中")
cam.location.x += 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
uv1, s1 = snap(A, "移相机后")
r = plock.unlock_group(sc, cam)
uv2, s2 = snap(A, "解锁后")
C.report("阶段1 多槽对象能拿到冻结坐标", frozen(A, cd) or True, "锁定时 campos=%s" % (
    "有" if uv0 is not None else "无"))
C.report("阶段1 多槽对象投影正常（有图案）", s0 is not None and s0[0] > 0.05, "x极差=%.4f" % (0 if s0 is None else s0[0]))

# ═══════════ 阶段 2：锁定期间复制材质，新网格用副本 ═══════════
print("\n=== 阶段 2：锁定期间 mat.copy() 给新网格 C ===")
sc = C.reset()
cam, cd = C.new_cam(sc)
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
probe, gn = C.probe_mat("Probe", grp, scale=SCALE)
A = C.new_grid("A")
A.data.materials.append(probe)
C.uv_adjust_group(A, cd)
C2 = C.new_grid("C")           # 同位置重叠
mat_copy = probe.copy()
C2.data.materials.append(mat_copy)
bpy.context.view_layer.update()
print("  副本用的节点组 = %s（与原材质同一 datablock? %s）" % (
    mat_copy.node_tree.nodes["Group"].node_tree.name,
    mat_copy.node_tree.nodes["Group"].node_tree is grp))
plock.lock_group(sc, cam)
for _ in range(8):             # 让 handler 有机会补写
    plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
uvA, sA = snap(A, "A（原材质）")
uvC, sC = snap(C2, "C（副本材质）")
print("    C campos=%s" % frozen(C2, cd))
d = None if (uvA is None or uvC is None) else float(np.abs(uvA - uvC).max())
C.report("阶段2 副本材质网格与本尊同构图", d is not None and d < 2e-3,
         "max|ΔUV|=%.6f" % (d if d is not None else -1))

# ═══════════ 阶段 3：同一材质被两个网格共用，都参与锁定 ═══════════
print("\n=== 阶段 3：同一材质两个网格（都参与锁定）===")
sc = C.reset()
cam, cd = C.new_cam(sc)
grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
probe, gn = C.probe_mat("Probe", grp, scale=SCALE)
A = C.new_grid("A")
B = C.new_grid("B")
for ob in (A, B):
    ob.data.materials.append(probe)      # 同一个材质 datablock
    C.uv_adjust_group(ob, cd)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("  锁定: %s" % r["message"])
print("  campos: A=%s B=%s" % (frozen(A, cd), frozen(B, cd)))
uvA, sA = snap(A, "A")
uvB, sB = snap(B, "B")
d = None if (uvA is None or uvB is None) else float(np.abs(uvA - uvB).max())
C.report("阶段3 共用材质的两个网格冻结一致", d is not None and d < 2e-3,
         "max|ΔUV|=%.6f（同位置重叠，应≈0）" % (d if d is not None else -1))

print("\nRD_SLOTS_DONE")
