"""复核 9b/B3（上一轮判据用「相机平移」不具区分力——ref 深度层平移时世界坐标本就不动），
外加 B-10：共享网格 / fake user 造成的「误判阻塞」。

跑法：blender --background --factory-startup --python _dev\\reviewB_recheck_shared.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reviewB_common as C
import numpy as np
import bpy, bmesh

C.load()
plock = C.PL()
print("=" * 94)
print("复核 + B-10 共享网格 / fake user")
print("=" * 94)


def geo(ob):
    return np.array([tuple(ob.matrix_world @ v.co) for v in ob.data.vertices])


def adapts(ob, cam, cd, tag):
    """用变焦（会驱动 dolly + zoom，任何深度层都会动）检测适配是否仍然生效。"""
    w0 = geo(ob)
    cam.data.lens = 85.0
    C.run_handler(sc=cam.id_data if False else bpy.context.scene)
    w1 = geo(ob)
    d = float(np.abs(w1 - w0).max())
    print("   %-22s 变焦 50→85 后几何 Δ=%.6f" % (tag, d))
    return d


# ── 复核 9b：base 被改名 ─────────────────────────────────
print("\n### 复核 9b：base 属性被改名后适配是否静默失效 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridA", cam, mat, ns=3)
CTRL = C.add_grid("GridCtrl", cam, mat, ns=3, x0=2.6, shape="倾斜")
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
A.data.attributes.get(plock.BASE_ATTR).name = "hacked_base"
bpy.context.view_layer.update()
dA = adapts(A, cam, cd, "base 被改名的网格")
dC = adapts(CTRL, cam, cd, "对照网格")
C.chk("9b-复核 base 被破坏后仍能适配", dA > 1e-6,
      "Δ=%.2e（对照 %.2e，base 自愈=%s）"
      % (dA, dC, A.data.attributes.get(plock.BASE_ATTR) is not None))

# ── 复核 B3：编辑模式加顶点 ──────────────────────────────
print("\n### 复核 B3：编辑模式加顶点后适配是否仍正常 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("GridB", cam, mat, ns=3)
CTRL = C.add_grid("GridCtrlB", cam, mat, ns=3, x0=2.6, shape="倾斜")
bpy.context.view_layer.update()
plock.lock_group(sc, cam)
bpy.context.view_layer.objects.active = A
bpy.ops.object.mode_set(mode="EDIT")
bm = bmesh.from_edit_mesh(A.data)
bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
bmesh.update_edit_mesh(A.data)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.context.view_layer.update()
C.run_handler(sc)
n = len(A.data.vertices)
b = A.data.attributes.get(plock.BASE_ATTR)
c = A.data.attributes.get(plock._campos_attr_name(cd.name))
print("   顶点=%d base len=%s campos len=%s" % (n, len(b.data) if b else None,
                                               len(c.data) if c else None))
dA = adapts(A, cam, cd, "编辑加顶点后的网格")
dC = adapts(CTRL, cam, cd, "对照")
C.chk("B3-复核 编辑模式加顶点后仍能适配", dA > 1e-6, "Δ=%.2e（对照 %.2e）" % (dA, dC))

# ── B-10a：同一 mesh 被两个对象共用（Alt+D）────────────────
print("\n### 10a. 共享网格（Alt+D）+ 冻结 ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("Shared1", cam, mat, ns=3, x0=-2.6)
B = bpy.data.objects.new("Shared2", A.data)
sc.collection.objects.link(B)
B.location = (2.6, 0, 0)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s locked=%s skipped=%s"
      % (r["success"], r.get("frozen"), [o.name for o in r.get("locked", [])],
         [(o.name, w) for o, w in r.get("skipped", [])]))
print("   message:", r["message"][:160])

# ── B-10b：单个对象，但 mesh 有 fake user（users==2）────────
print("\n### 10b. 只有一个对象用这块 mesh，但开了 fake user ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("FakeUserGrid", cam, mat, ns=3)
A.data.use_fake_user = True
bpy.context.view_layer.update()
print("   mesh.users =", A.data.users, "（1 个对象 + 1 个 fake user）")
print("   block_reasons =", plock.block_reasons(A))
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s locked=%s" % (r["success"], r.get("frozen"),
                                                 [o.name for o in r.get("locked", [])]))
print("   message:", r["message"][:200])
fv0 = C.campos_uv(A, cd.name)
cam.location.x = 2.0
C.run_handler(sc)
fv1 = C.campos_uv(A, cd.name)
print("   图案冻结：campos 存在=%s  逐顶点 UV Δ=%s"
      % (fv0 is not None,
         ("%.2e" % float(np.abs(fv1 - fv0).max())) if (fv0 is not None and fv1 is not None) else "N/A"))
C.chk("10b-1 fake user 不应被误判为「共享网格」而关掉冻结",
      r.get("frozen") is True, "frozen=%s（只 1 个对象在用这块 mesh）" % r.get("frozen"))

# 对照：不开 fake user
print("\n### 10c. 对照：同一场景但不开 fake user ###")
sc, cam, cd, grp = C.setup()
mat = C.probe_mat(grp)
A = C.add_grid("PlainGrid", cam, mat, ns=3)
bpy.context.view_layer.update()
r = plock.lock_group(sc, cam)
print("   lock: success=%s frozen=%s" % (r["success"], r.get("frozen")))
C.chk("10c 对照：普通单对象 frozen=True", r.get("frozen") is True)

C.summary()
