"""复现「删掉投影组节点 ⇒ 材质永久失效」，确认症状与机制

链路：
  _find_delta_nodes()  按名字找 "PLock Delta S" / "PLock Delta C"
  找不到 → _ensure_delta_group() 调 ensure_camera_project_group()
         → 【清空组内所有节点】重建（用户的手工改动被推平）

要确认的三件事：
  [1] 删掉 S 节点后，锁定是否还能工作？（功能失效的具体表现）
  [2] 是否触发了整组重建？（节点数 / 自定义节点被删）
  [3] 重建后能否自愈？（还是永久失效）
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]
names = sys.modules[PKG + ".names"]
S_NAME = names.PLOCK_S_NODE
C_NAME = names.PLOCK_C_NODE
VER_KEY = names.PLOCK_DELTA_VERSION_KEY


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 8); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])
    h = 1.0
    verts = [(-1.5-h,-h,0.0), (-1.5+h,-h,0.0), (-1.5+h,h,0.0), (-1.5-h,h,0.0)]
    mesh = bpy.data.meshes.new("A")
    mesh.from_pydata(verts, [], [(0,1,2,3)]); mesh.update()
    A = bpy.data.objects.new("A", mesh)
    sc.collection.objects.link(A)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (mesh.name, cd.name),
                             "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, A


def step(sc):
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


def gstats(cd):
    ng = bpy.data.node_groups.get("Camera Project | " + cd.name)
    if ng is None:
        return None
    return {
        "nodes": len(ng.nodes),
        "has_S": ng.nodes.get(S_NAME) is not None,
        "has_C": ng.nodes.get(C_NAME) is not None,
        "has_ver": bool(ng.get(VER_KEY)),
        "user_node": ng.nodes.get("USER_MARK") is not None,
        "find_ok": plock._find_delta_nodes(cd.name) is not None,
        "patched": plock.is_patched(cd.name),
    }


print("=" * 94)
print("[基线] 正常锁定")
print("=" * 94)
sc, cam, cd, A = build()
ng = bpy.data.node_groups["Camera Project | " + cd.name]
# 加一个用户自己的节点，用来检测「整组重建会不会推平用户改动」
un = ng.nodes.new(type="ShaderNodeValue")
un.name = "USER_MARK"; un.label = "用户自己加的节点"
print("  组内节点数:", len(ng.nodes), "（含用户节点 USER_MARK）")
r = plock.lock_group(sc, cam)
print("  锁定:", str(r.get("message",""))[:56])
print("  ", gstats(cd))

print()
print("=" * 94)
print("[1] 删掉 PLock Delta S 节点，再尝试锁定/解锁")
print("=" * 94)
ng.nodes.remove(ng.nodes[S_NAME])
print("  删除后:", gstats(cd))
# 解锁再锁定
ru = plock.unlock_group(sc, cam)
print("  解锁:", str(ru.get("message",""))[:70])
print("  解锁后:", gstats(cd))
rl = plock.lock_group(sc, cam)
print("  再锁定:", str(rl.get("message",""))[:80])
print("  再锁后:", gstats(cd))

print()
print("=" * 94)
print("[2] 关键判据")
print("=" * 94)
st = gstats(cd)
print("  S 节点回来了吗：%s" % st["has_S"])
print("  用户自己加的节点还在吗：%s  ← False = 整组被推平重建" % st["user_node"])
print("  版本键还在吗：%s" % st["has_ver"])
print("  当前是否 patched：%s" % st["patched"])

print()
print("=" * 94)
print("[3] 用户把节点改名（不删）会怎样")
print("=" * 94)
sc, cam, cd, A = build()
ng = bpy.data.node_groups["Camera Project | " + cd.name]
ng.nodes[S_NAME].name = "我改的名字"
print("  改名后:", gstats(cd))
rl = plock.lock_group(sc, cam)
print("  锁定:", str(rl.get("message",""))[:80])
print("  改名后锁定:", gstats(cd))
print("REPRO_DONE")
