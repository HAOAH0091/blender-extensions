"""审查 F-8：相机数据块改名（**没有锁定记录时**）后，投影组名/UV Adjust 组名
   仍然是旧名 → 再点锁定会发生什么？迁移代码 `_migrate_cam_key` 只在
   `_resolve_state` 找到锁定记录时才跑。
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

RES = 96


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = sc.render.resolution_y = RES
    sc.render.image_settings.file_format = "PNG"
    sc.view_settings.view_transform = "Standard"
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd); sc.collection.objects.link(cam)
    cam.location = (0, 0, 5); sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Probe"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    sep = nt.nodes.new("ShaderNodeSeparateXYZ"); comb = nt.nodes.new("ShaderNodeCombineXYZ")
    emi = nt.nodes.new("ShaderNodeEmission"); out = nt.nodes.new("ShaderNodeOutputMaterial")
    for ax in ("X", "Y"):
        m = nt.nodes.new("ShaderNodeMath"); m.operation = "MULTIPLY"; m.inputs[1].default_value = 0.25
        a = nt.nodes.new("ShaderNodeMath"); a.operation = "ADD"; a.inputs[1].default_value = 0.5
        nt.links.new(sep.outputs[ax], m.inputs[0]); nt.links.new(m.outputs["Value"], a.inputs[0])
        nt.links.new(a.outputs["Value"], comb.inputs[ax])
    nt.links.new(gn.outputs["Vector"], sep.inputs["Vector"])
    nt.links.new(comb.outputs["Vector"], emi.inputs["Color"])
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    mesh = bpy.data.meshes.new("G0"); mesh.from_pydata(
        [(-2, -2, 0), (2, -2, 0), (2, 2, 0), (-2, 2, 0)], [], [(0, 1, 2, 3)]); mesh.update()
    ob = bpy.data.objects.new("Grid0", mesh); sc.collection.objects.link(ob)
    ob.data.materials.append(mat)
    # UV Adjust 组（get_lock_targets 的检索源）
    bpy.data.node_groups.new("UV Adjust | G0 | Cam", "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, ob


_seq = [0]


def uvarr():
    _seq[0] += 1
    p = os.path.join(HERE, "_rfr_%02d.png" % _seq[0])
    for m in bpy.data.materials:
        if m.use_nodes and m.node_tree:
            m.node_tree.update_tag()
    bpy.context.evaluated_depsgraph_get().update()
    bpy.context.view_layer.update()
    bpy.context.scene.render.filepath = p
    bpy.ops.render.render(write_still=True)
    im = bpy.data.images.load(p)
    n = im.size[0] * im.size[1] * 4
    buf = np.empty(n, dtype=np.float32); im.pixels.foreach_get(buf)
    a = buf.reshape(im.size[1], im.size[0], 4)[..., :2].copy()
    bpy.data.images.remove(im)
    return (a - 0.5) * 4.0


def frozen_gain(ob, cd, cam):
    """锁定中移相机 → 冻结坐标属性不变 ⇒ 图案不动。用「锁定中 UV 是否恒定」判冻结。"""
    a0 = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    if a0 is None or len(a0.data) != len(ob.data.vertices):
        return None
    v0 = np.array([tuple(d.vector) for d in a0.data])
    cam.location.x += 1.0
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(bpy.context.scene)
    bpy.context.view_layer.update()
    a1 = ob.data.attributes.get(plock._campos_attr_name(cd.name))
    v1 = np.array([tuple(d.vector) for d in a1.data])
    cam.location.x -= 1.0
    bpy.context.view_layer.update()
    return float(np.abs(v1 - v0).max())


print("=" * 84)
print("### 场景 A：从未锁定过 → 改相机数据块名 → 点锁定")
sc, cam, cd, ob = build()
cd.name = "Cam2"
print("  改名后 groups:", [g.name for g in bpy.data.node_groups])
r = plock.lock_group(sc, cam)
print("  lock -> success=%s" % r.get("success"))
print("  message: %s" % str(r.get("message"))[:200])
print("  网格是否被锁定（OBJ_CAM_KEY）= %s" % ob.get(plock.OBJ_CAM_KEY))
print("  冻结属性 = %s" % [a.name for a in ob.data.attributes if "campos" in a.name])
print("  是否打上补丁 = %s" % plock.is_patched(cd.name))
print("  组列表: %s" % [g.name for g in bpy.data.node_groups])

print("")
print("### 场景 B：锁定 → 重置（清掉记录）→ 改相机数据块名 → 再锁定")
sc, cam, cd, ob = build()
r0 = plock.lock_group(sc, cam)
print("  初始锁定:", str(r0.get("message"))[:40])
plock.reset_group(sc, cam)
cd.name = "Cam3"
r = plock.lock_group(sc, cam)
print("  lock -> success=%s" % r.get("success"))
print("  message: %s" % str(r.get("message"))[:200])
print("  网格是否被锁定（OBJ_CAM_KEY）= %s" % ob.get(plock.OBJ_CAM_KEY))
print("  是否打上补丁 = %s" % plock.is_patched(cd.name))

print("")
print("### 场景 C：锁定中改名（有记录 → 迁移代码会跑）")
sc, cam, cd, ob = build()
r0 = plock.lock_group(sc, cam)
cd.name = "Cam4"
st = plock.get_state(sc, cam)
print("  改名后能取到 state = %s, groups key = %s"
      % (bool(st), list(plock.load_groups(sc).keys())))
print("  组列表: %s" % [g.name for g in bpy.data.node_groups])
print("  冻结属性 = %s" % [a.name for a in ob.data.attributes if "campos" in a.name])
g = frozen_gain(ob, cd, cam)
print("  锁定中移相机：冻结坐标最大变化 = %s（≈0 才算冻结住）" % g)
print("RF_RENAME_DONE")
