"""收尾验证：删/改名冻结节点造成的损坏是否「永久」（解锁 + 重置都救不回）。

★ 关键时序：真实 Blender 里删节点会立刻触发 depsgraph → handler 跑自愈。
  这里显式跑一次 handler 复现该时序（不跑 = 假象，见上一版结论翻转）。
"""
import bpy
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import reviewD_common as C

plock, ng = C.load_plugin()
SCALE = 0.1


def setup(tag):
    sc = C.reset()
    cam, cd = C.new_cam(sc)
    grp = ng.ensure_camera_project_group(cam, default_aspect=1.0)
    mat, gn = C.probe_mat("Probe", grp, scale=SCALE)
    A = C.new_grid("A")
    A.data.materials.append(mat)
    C.uv_adjust_group(A, cd)
    bpy.context.view_layer.update()
    plock.lock_group(sc, cam)
    print("\n=== %s ===" % tag)
    return sc, cam, cd, grp, A


def snap(A, tag):
    C.show(A)
    uv, mask, sat = C.render_uv_masked(scale=SCALE, tag=tag)
    s = C.stats_masked(uv, mask)
    print("    %-18s x极差=%.4f 均值=(%+.3f,%+.3f)" % (tag, s[0], s[3], s[4]))
    return s


def tick(sc):
    """模拟真实 depsgraph 更新 → handler 跑一次自愈。"""
    bpy.context.view_layer.update()
    plock.parallax_lock_update_handler(sc)
    bpy.context.view_layer.update()


sc, cam, cd, grp, A = setup("删掉冻结坐标 Attribute 节点 + handler 跑一帧")
s_a = snap(A, "锁定中")
grp.nodes.remove(grp.nodes.get(plock.ATTR_NODE_NAME))
tick(sc)
print("    handler 后: is_patched=%s PATCH_KEY 还在=%s" % (
    plock.is_patched(cd.name), grp.get(plock.PATCH_KEY) is not None))
s_b = snap(A, "删除+hander后")
plock.unlock_group(sc, cam)
s_c = snap(A, "解锁后")
r = plock.reset_group(sc, cam)
s_d = snap(A, "重置后")
print("    persp_source=%s" % C.persp_source(grp))
ng.ensure_camera_project_group(cam, default_aspect=1.0)
bpy.context.view_layer.update()
s_e = snap(A, "手动重建组后")
C.report("删节点后图案立刻消失", s_b[0] < 0.05, "x极差 %.4f→%.4f" % (s_a[0], s_b[0]))
C.report("解锁救不回（材质永久坏）", s_c[0] < 0.05, "x极差=%.4f" % s_c[0])
C.report("重置也救不回", s_d[0] < 0.05, "x极差=%.4f" % s_d[0])
C.report("只有手动重建组能救回", s_e[0] > 0.05, "x极差=%.4f" % s_e[0])

sc, cam, cd, grp, A = setup("把冻结坐标 Attribute 节点改名 + handler 跑一帧")
s_a = snap(A, "锁定中")
grp.nodes.get(plock.ATTR_NODE_NAME).name = "My Frozen Pos"
tick(sc)
print("    handler 后: is_patched=%s PATCH_KEY 还在=%s" % (
    plock.is_patched(cd.name), grp.get(plock.PATCH_KEY) is not None))
plock.unlock_group(sc, cam)
s_c = snap(A, "解锁后")
r = plock.reset_group(sc, cam)
s_d = snap(A, "重置后")
print("    persp_source=%s 残留节点在场=%s campos=%s" % (
    C.persp_source(grp), grp.nodes.get("My Frozen Pos") is not None,
    C.campos_ok(plock, A, cd.name)))
C.report("改名后解锁救不回", s_c[0] < 0.05, "x极差=%.4f" % s_c[0])
C.report("改名后重置也救不回", s_d[0] < 0.05, "x极差=%.4f" % s_d[0])

print("\nRD_PERM_DONE")
