"""审查 A-9：两个相机交叉锁定/解锁，是否互相污染
  · 各自锁自己的网格，交叉操作（最常见的真实用法）
  · 同一网格被两台相机先后接管（互斥接管）
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import bpy
import reviewA_lib as L

plock = L.plock


def frozen_of(ob, cdname):
    a = ob.data.attributes.get(plock._campos_attr_name(cdname))
    if a is None or len(a.data) != len(ob.data.vertices):
        return None
    return np.array([tuple(a.data[i].vector) for i in range(len(a.data))])


L.report("A-9a 两台相机各自锁自己的网格，交叉解锁/重置：有没有互相动到")
C = L.build(n_grid=3)
sc, camA, cdA = C["scene"], C["cam"], C["cd"]
GridA = C["objs"][0]
GridA.name = "GridA"
# 第二台相机 + 它自己的网格（网格在相机 B 前方，指向 +Z）
cdB = bpy.data.cameras.new("CamB")
cdB.lens = 50.0
camB = bpy.data.objects.new("CamB", cdB)
sc.collection.objects.link(camB)
camB.location = (8.0, 0, 5.0)
sc.camera = camB
bpy.context.view_layer.update()
grpB = L.ng_mod.ensure_camera_project_group(camB, default_aspect=1.0)
# B 的 UV 探针材质
matB = bpy.data.materials.new("ProbeB")
matB.use_nodes = True
nt = matB.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grpB
emi = nt.nodes.new("ShaderNodeEmission")
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], emi.inputs["Color"])
nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
meshB = bpy.data.meshes.new("GB")
meshB.from_pydata([(7, -2, 0), (9, -2, 0), (9, 2, 0), (7, 2, 0)], [], [(0, 1, 2, 3)])
meshB.update()
GridB = bpy.data.objects.new("GridB", meshB)
sc.collection.objects.link(GridB)
GridB.data.materials.append(matB)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (meshB.name, cdB.name), "ShaderNodeTree")
bpy.context.view_layer.update()

origA = L.lverts(GridA).copy()
origB = L.lverts(GridB).copy()
r = plock.lock_group(sc, camA)
L.chk("A 锁定成功", r["success"], "%s" % r["message"][:40])
# 移动相机 A：A 的网格被适配
camA.rotation_euler.y = 0.3
L.run_h(sc, times=2)
geoA_afterA = float(np.abs(L.lverts(GridA) - origA).max())
r = plock.lock_group(sc, camB)
L.chk("B 锁定成功（A 的网格没被抢走）", r["success"] and len(r["locked"]) == 1,
      "%s" % r["message"][:60])
L.info("A 锁定中：GridA 变形 Δ=%.3f；GridB 变形 Δ=%.3f（B 锁定时不该动 A 的网格）"
       % (geoA_afterA, float(np.abs(L.lverts(GridB) - origB).max())))
fA0 = frozen_of(GridA, cdA.name)
fB0 = frozen_of(GridB, cdB.name)
# 移相机 B，A 的冻结坐标不能变
camB.location.x -= 0.6
L.run_h(sc, times=2)
fA1 = frozen_of(GridA, cdA.name)
fB1 = frozen_of(GridB, cdB.name)
L.chk("移 B 的相机不影响 A 的冻结坐标",
      fA0 is not None and fA1 is not None and float(np.abs(fA1 - fA0).max()) < 1e-6,
      "A 冻结坐标Δ=%.2e" % float(np.abs(fA1 - fA0).max()))
L.chk("B 锁定中图案仍冻结", fB0 is not None and fB1 is not None
      and float(np.abs(fB1 - fB0).max()) < 1e-6,
      "B 冻结坐标Δ=%.2e" % float(np.abs(fB1 - fB0).max()))

# 解锁 A：B 的状态不能被顺手改掉
rA = plock.unlock_group(sc, camA)
SA, CA = L.node_sc(camA)
SB, CB = L.node_sc(camB)
L.info("解锁 A 后：A S=%.4f C=(%+.4f,%+.4f) | B S=%.4f C=(%+.4f,%+.4f) is_lockedB=%s"
       % (SA, CA[0], CA[1], SB, CB[0], CB[1], plock.is_locked(sc, camB)))
L.chk("解锁 A 后 B 仍是恒等（未被写进 A 的落实参数）",
      abs(SB - 1) < 1e-9 and max(map(abs, CB)) < 1e-9,
      "B S=%.6f C=(%.2e,%.2e)" % (SB, CB[0], CB[1]))
L.chk("解锁 A 后 B 的冻结坐标仍在", frozen_of(GridB, cdB.name) is not None, "")
L.chk("解锁 A 后 B 仍锁定", bool(plock.is_locked(sc, camB)), "")
# 重置 A：不能动到 B
rBl = plock.reset_group(sc, camA)
geoB = float(np.abs(L.lverts(GridB) - origB).max())
L.chk("重置 A 不动 B 的网格几何", geoB < 1e-6, "GridB Δ=%.2e" % geoB)
L.chk("重置 A 后 B 仍锁定且冻结坐标在", bool(plock.is_locked(sc, camB))
      and frozen_of(GridB, cdB.name) is not None, "")
rB = plock.unlock_group(sc, camB)
L.chk("最后解锁 B 成功", rB.get("success"), "%s" % rB.get("message", "")[:40])

print()
L.report("A-9b 同一网格被两台相机【互斥接管】：A 的落实参数会不会污染 B")
C = L.build(n_grid=3)
sc, camA, cdA = C["scene"], C["cam"], C["cd"]
M = C["objs"][0]
M.name = "M"
# 再给一台相机 B，并为 M 也登记一份「归属 B」的 UV Adjust 组 ⇒ 两台相机都把 M 当目标
cdB = bpy.data.cameras.new("CamB")
cdB.lens = 50.0
camB = bpy.data.objects.new("CamB", cdB)
sc.collection.objects.link(camB)
camB.location = (0, 0, 6.0)
bpy.context.view_layer.update()
grpB = L.ng_mod.ensure_camera_project_group(camB, default_aspect=1.0)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (M.data.name, cdB.name), "ShaderNodeTree")
orig = L.lverts(M).copy()

plock.lock_group(sc, camA)
camA.rotation_euler.y = 0.25
L.run_h(sc, times=2)
geoA = float(np.abs(L.lverts(M) - orig).max())
r = plock.lock_group(sc, camB)
st = plock.load_groups(sc)
L.info("A 锁定时 M 变形 Δ=%.3f；B 接管后：A.enabled=%s B.enabled=%s M.OBJ_CAM_KEY=%s"
       % (geoA, st.get(cdA.name, {}).get("enabled"), st.get(cdB.name, {}).get("enabled"),
          M.get(plock.OBJ_CAM_KEY)))
L.info("B 接管后 M 上的冻结坐标：A 那份=%s B 那份=%s"
       % (M.data.attributes.get(plock._campos_attr_name(cdA.name)) is not None,
          M.data.attributes.get(plock._campos_attr_name(cdB.name)) is not None))
print("  A 的投影组 S/C =", L.node_sc(camA), " B 的投影组 S/C =", L.node_sc(camB))
r = plock.unlock_group(sc, camB)
SB, CB = L.node_sc(camB)
L.info("解锁 B 后 B 组 S=%s C=%s；M 的 A 组补丁=%s"
       % (SB, CB, plock.is_patched(cdA.name)))
# 再把 M 交回 A：重新锁定 + 重置，几何必须回到最初原形
r = plock.lock_group(sc, camA)
L.chk("A 重新接管 M 成功", r.get("success"), "%s" % r.get("message", "")[:50])
r = plock.reset_group(sc, camA)
geo = float(np.abs(L.lverts(M) - orig).max())
L.chk("A 重置后 M 几何回到最初原形", r.get("success") and geo < 1e-6,
      "Δ=%.2e（接管前 A 已变形 %.3f）" % (geo, geoA))
L.summary()
