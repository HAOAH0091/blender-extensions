"""复现：解锁后新接入投影材质的网格 B，呈现的是「未落实」的原始投射
场景：A 有投影材质 → 锁定 → 移相机 → 解锁 → B 换成同一材质
"""
import bpy, sys, os
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Cam", cd)
    sc.collection.objects.link(cam)
    cam.location = (0.0, 0.0, 5.0); cam.rotation_euler = (0, 0, 0)
    sc.camera = cam
    bpy.context.view_layer.update()
    grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
    mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
    nt = mat.node_tree; nt.nodes.clear()
    gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

    def grid(name, x):
        Ns = 2; H = 1.0
        verts, faces = [], []
        for iy in range(Ns+1):
            for ix in range(Ns+1):
                verts.append((x-H+2*H*ix/Ns, -H+2*H*iy/Ns, 0.0))
        for iy in range(Ns):
            for ix in range(Ns):
                a = iy*(Ns+1)+ix
                faces.append((a, a+1, a+Ns+2, a+Ns+1))
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(verts, [], faces); mesh.update()
        ob = bpy.data.objects.new(name, mesh)
        sc.collection.objects.link(ob)
        return ob

    A = grid("GridA", -1.5)
    B = grid("GridB", 1.5)
    A.data.materials.append(mat)
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (A.data.name, cd.name), "ShaderNodeTree")
    bpy.context.view_layer.update()
    return sc, cam, cd, mat, A, B


def persp(cam_matrix, ob):
    """按投影组语义算透视坐标 (x/z, y/z)，z 用相机空间（负）"""
    m = cam_matrix.inverted()
    out = []
    for v in ob.data.vertices:
        p = m @ (ob.matrix_world @ v.co)
        out.append((p.x/p.z, p.y/p.z))
    return np.array(out)


def shader_uv(cam, ob, cd):
    """按组当前会读到的东西算 UV（patch 时用 campos，否则 实时+delta）"""
    if plock.is_patched(cd.name):
        a = ob.data.attributes.get(plock._campos_attr_name(cd.name))
        if a is not None and len(a.data) == len(ob.data.vertices):
            return np.array([(a.data[i].vector[0]/a.data[i].vector[2],
                              a.data[i].vector[1]/a.data[i].vector[2])
                             for i in range(len(a.data))])
    l = persp(cam.matrix_world, ob)
    d = ob.data.attributes.get(plock.UV_DELTA_ATTR)
    if d is not None and len(d.data) == len(ob.data.vertices):
        dd = np.array([(d.data[i].vector[0], d.data[i].vector[1]) for i in range(len(d.data))])
        return l + dd
    return l


sc, cam, cd, mat, A, B = build()
print("=" * 76)
print("1) A 投影材质 + 锁定")
plock.lock_group(sc, cam)
print("   patched=", plock.is_patched(cd.name))
uv_A_lock = shader_uv(cam, A, cd)
print("   A UV[0] =", np.round(uv_A_lock[0], 5))

print("\n2) 移动相机 x=2")
cam.location.x = 2.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
uv_A_lock2 = shader_uv(cam, A, cd)
print("   A UV[0] =", np.round(uv_A_lock2[0], 5), "(应==锁定值：图案粘住)")
print("   变化 =", float(np.abs(uv_A_lock2 - uv_A_lock).max()))

print("\n3) 解锁")
print("  ", plock.unlock_group(sc, cam)["message"])
bpy.context.view_layer.update()
uv_A_unlock = shader_uv(cam, A, cd)
print("   A UV[0] =", np.round(uv_A_unlock[0], 5))
print("   解锁跳变 = %.8f" % float(np.abs(uv_A_unlock - uv_A_lock2).max()))

print("\n4) B 换成同一投影材质")
B.data.materials.clear()
B.data.materials.append(mat)
bpy.context.view_layer.update()
uv_B = shader_uv(cam, B, cd)
print("   B 有 delta 属性?", B.data.attributes.get(plock.UV_DELTA_ATTR) is not None)
print("   B UV[0] =", np.round(uv_B[0], 5))

# ★ 跑一次 handler（真实用户换了材质后，下一帧 depsgraph 就会触发）
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()
uv_B2 = shader_uv(cam, B, cd)
print("   [跑 handler 后] B 有 delta?", B.data.attributes.get(plock.UV_DELTA_ATTR) is not None)
print("   [跑 handler 后] B UV[0] =", np.round(uv_B2[0], 5))

print("\n5) B「本应」呈现什么？（= 用锁定时的相机投射）")
st = plock.get_state(sc, cam)
lm = st.get("locked_matrix") if st else None
print("   state.locked_matrix 存在:", lm is not None)
if lm is not None:
    ML = __import__("mathutils").Matrix(lm)
    uv_B_committed = persp(ML, B)
    print("   B 若按锁定相机投射 UV[0] =", np.round(uv_B_committed[0], 5))
    print("   >>> B 补写前 vs 应有 差 = %.6f" %
          float(np.abs(uv_B - uv_B_committed).max()))
    print("   >>> B 补写后 vs 应有 差 = %.8f" %
          float(np.abs(uv_B2 - uv_B_committed).max()))

    # 对照 A：A 解锁后是否等于「按锁定相机投射」
    uv_A_committed = persp(ML, A)
    print("\n   对照 A 与 B 的构图是否同层次：")
    print("     A UV[0]=%s  B UV[0]=%s  差=%.8f" % (
        np.round(uv_A_unlock[0], 5), np.round(uv_B2[0], 5),
        float(np.abs(uv_A_unlock - uv_B2).max())))
    print("\n   对照 A：解锁后 UV[0]=%s  按锁定相机投射 UV[0]=%s  差=%.8f" % (
        np.round(uv_A_unlock[0], 5), np.round(uv_A_committed[0], 5),
        float(np.abs(uv_A_unlock - uv_A_committed).max())))
print("REPRO_DONE")
