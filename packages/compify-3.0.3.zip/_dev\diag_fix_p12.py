"""验证问题2、问题1 的修复思路（monkey-patch，不改源码）"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_fix2"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]

# ── 应用修复（monkey-patch）──
_orig_is_valid = PL._campos_is_valid
def _valid_fixed(obj, cam_data_name):
    # ★ 编辑模式下 attributes.data 长度为 0 是 Blender 的正常行为，
    #   不代表属性丢失 ⇒ 不能据此判无效（否则触发重写、破坏 BMesh 层）
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return True
    return _orig_is_valid(obj, cam_data_name)

_orig_write = PL._write_campos_attribute
def _write_fixed(obj, camera, cam_data_name, mw_inv=None):
    # ★ 编辑模式下不写 mesh 属性：_new_vec_attr 是先删后建，会破坏 BMesh 自定义层
    if getattr(obj, "mode", "OBJECT") != "OBJECT":
        return False
    return _orig_write(obj, camera, cam_data_name, mw_inv)

_orig_targets = PL.get_lock_targets
def _targets_fixed(scene, camera):
    base = _orig_targets(scene, camera)
    if camera is None or camera.data is None:
        return base
    seen = {o.as_pointer() for o in base}
    for o in PL.objects_using_projection(camera.data.name):
        if o.as_pointer() not in seen and o.name in scene.objects:
            base.append(o)
            seen.add(o.as_pointer())
    return base


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)
    return scene, cam, cd

def make_mat(cd):
    m = bpy.data.materials.new("M"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])
    return m

def make_grid(name, z, x, w=1.0, ns=2):
    mesh = bpy.data.meshes.new(name)
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            verts.append((x-w+2*w*ix/ns, -1+2*iy/ns, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    o = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(o)
    return o


# ══════════ 问题2 ══════════
print("="*74)
print("【问题2 修复验证】进出编辑模式后 campos 是否完好")
scene, cam, cd = build()
mp = make_mat(cd)
obj = make_grid("G", 0.0, 0.0)
obj.data.materials.append(mp)
NG.create_uv_adjust_node_group(scene, cam, obj)

for label, is_valid_fn, write_fn in [("未修复", _orig_is_valid, _orig_write),
                                     ("已修复", _valid_fixed, _write_fixed)]:
    PL._campos_is_valid = is_valid_fn
    PL._write_campos_attribute = write_fn
    # 重建干净场景
    scene, cam, cd = build()
    mp = make_mat(cd)
    obj = make_grid("G", 0.0, 0.0)
    obj.data.materials.append(mp)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    PL._campos_cache = {}
    PL.lock_group(scene, cam)
    cn = PL._campos_attr_name(cd.name)
    a = obj.data.attributes.get(cn)
    v0 = [tuple(a.data[i].vector) for i in range(len(a.data))]
    print("\n  --- %s ---" % label)
    print("    锁定后 campos n=%d 首顶点=%s" % (len(v0), tuple(round(x,3) for x in v0[0])))

    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    for _ in range(4):
        bpy.context.view_layer.update()
        PL.parallax_lock_update_handler(scene)
    bpy.ops.object.mode_set(mode='OBJECT')
    for _ in range(2):
        bpy.context.view_layer.update()
        PL.parallax_lock_update_handler(scene)
    a2 = obj.data.attributes.get(cn)
    v1 = [tuple(a2.data[i].vector) for i in range(len(a2.data))] if a2 else None
    if v1 and len(v1) == len(v0):
        d = max(abs(p[i]-q[i]) for p,q in zip(v0,v1) for i in range(3))
        print("    退出后 campos n=%d 首顶点=%s" % (len(v1), tuple(round(x,3) for x in v1[0])))
        print("    >>> 最大变化 %.6f  (%s)" % (d, "完好" if d < 1e-6 else "已损坏=bug"))
    else:
        print("    >>> campos 丢失或长度不符! n=%s" % (len(v1) if v1 else None))

# ══════════ 问题1 ══════════
print("\n" + "="*74)
print("【问题1 修复验证】B 手动换投影材质后是否纳入锁定")
for label, fn in [("未修复", _orig_targets), ("已修复", _targets_fixed)]:
    PL.get_lock_targets = fn
    scene, cam, cd = build()
    mp = make_mat(cd)
    A = make_grid("GridA", 0.0, -1.2, w=0.8)
    B = make_grid("GridB", 0.0,  1.2, w=0.8)
    A.data.materials.append(mp)
    B.data.materials.append(mp)
    NG.create_uv_adjust_node_group(scene, cam, A)
    tg = PL.get_lock_targets(scene, cam)
    res = PL.lock_group(scene, cam)
    print("\n  --- %s ---" % label)
    print("    get_lock_targets ->", [o.name for o in tg])
    print("    locked ->", [o.name for o in res.get("locked", [])])
    print("    B 有 base: %s  OBJ_CAM_KEY=%s" %
          (B.data.attributes.get(PL.BASE_ATTR) is not None, B.get(PL.OBJ_CAM_KEY)))
    # 判据：移动 B 是否被拦下
    m0 = B.matrix_world.copy()
    B.location.x += 1.5
    bpy.context.view_layer.update()
    PL.parallax_lock_update_handler(scene)
    d = (B.matrix_world.translation - m0.translation).length
    print("    移动 B 的位姿位移: %.4f  (%s)" %
          (d, "被拦下=锁定生效" if d < 1e-6 else "自由移动=不生效"))
