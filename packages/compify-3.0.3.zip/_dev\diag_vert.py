"""验证：全局 drag（按比例缩放） vs 逐顶点 k_i（按平移补偿）
用户拖动 = 整体沿视线平移 dd。
要"每个顶点屏幕坐标不变"，每个顶点需要自己的 k_i = (d_i+dd)/d_i。
用全局 drag=k 则所有顶点深度乘同一比例 ⇒ 立体网格深度分布失真。
"""
import bpy, sys, os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PKG = "compify_plock_vert"
_HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(_HERE)
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
_mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = _mod
spec.loader.exec_module(_mod)
PL = sys.modules[PKG + ".compify_parallax_lock"]
NG = sys.modules[PKG + ".node_groups"]
from mathutils import Vector


def build_tilted():
    """建一个「倾斜」的网格：不是平面正对相机，各顶点深度差异大"""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    cd = bpy.data.cameras.new("C"); cd.lens = 50.0; cd.sensor_width = 36.0
    cam = bpy.data.objects.new("Camera", cd)
    scene.collection.objects.link(cam)
    cam.location = (0, 0, 5.0); cam.rotation_euler = (0, 0, 0)
    bpy.context.view_layer.update()
    NG.ensure_camera_project_group(cam)

    m = bpy.data.materials.new("M"); m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    gn = nt.nodes.new("ShaderNodeGroup")
    gn.node_tree = bpy.data.node_groups.get(PL.CAM_PROJECT_PREFIX + cd.name)
    o = nt.nodes.new("ShaderNodeOutputMaterial"); nt.links.new(gn.outputs[0], o.inputs[0])

    # 倾斜平面：绕 X 转 55°，顶点深度从 -1.5 到 +1.5（相对）
    import math
    mesh = bpy.data.meshes.new("Tilt")
    ns = 2
    verts, faces = [], []
    for iy in range(ns+1):
        for ix in range(ns+1):
            lx = -1 + 2*ix/ns
            ly = -1 + 2*iy/ns
            # 绕 X 轴旋转 55 度，再平移到 z=0
            ang = math.radians(55)
            z = ly * math.sin(ang)
            y = ly * math.cos(ang)
            verts.append((lx, y, z))
    for iy in range(ns):
        for ix in range(ns):
            a = iy*(ns+1)+ix
            faces.append((a, a+1, a+ns+2, a+ns+1))
    mesh.from_pydata(verts, [], faces); mesh.update()
    obj = bpy.data.objects.new("TiltGrid", mesh)
    scene.collection.objects.link(obj)
    obj.data.materials.append(m)
    NG.create_uv_adjust_node_group(scene, cam, obj)
    return scene, cam, cd, obj


def cam_space(cam, obj):
    v = PL.get_camera_view_matrix(cam)
    out = []
    for vv in obj.data.vertices:
        p = v @ (obj.matrix_world @ vv.co)
        out.append((p.x, p.y, -p.z))     # (x, y, depth)
    return out


def proj(cs):
    return [(x/d if abs(d) > 1e-9 else 0.0, y/d if abs(d) > 1e-9 else 0.0) for x, y, d in cs]


scene, cam, cd, obj = build_tilted()
PL.lock_group(scene, cam)
M_lock = obj.matrix_world.copy()
base = PL._read_base_attribute(obj)
cs0 = cam_space(cam, obj)
p0 = proj(cs0)

print("="*82)
print("倾斜网格（各顶点深度差异大），锁定后相机空间坐标：")
for i, (x, y, d) in enumerate(cs0):
    print("  顶点%d  深度 %.4f   屏幕(%+.4f, %+.4f)" % (i, d, x/d, y/d))

DD = -0.6   # 用户把物体往相机推 0.6（深度减少 0.6，即深度 +(-0.6)）
print("\n用户拖动：整体沿视线平移 %.2f（所有顶点深度都 -0.6）" % DD)

# ── 方案 1：全局 drag（现状逻辑）──
# 用户拖动后，最前面顶点的深度变化比例作为全局 k
d_min = min(d for _, _, d in cs0)
d_max = max(d for _, _, d in cs0)
k_global = (d_min + DD) / d_min
print("\n【现状：全局 drag】k = (%.4f%+.2f)/%.4f = %.6f" % (d_min, DD, d_min, k_global))
print("  顶点   原深度    期望深度(+DD)   实际深度(d*k)   深度误差   屏幕变化")
for i, (x, y, d) in enumerate(cs0):
    expect_d = d + DD
    actual_d = d * k_global
    err = actual_d - expect_d
    nx = x * k_global
    np_ = (nx / actual_d, (y * k_global) / actual_d)
    dp = max(abs(np_[0]-p0[i][0]), abs(np_[1]-p0[i][1]))
    print("   %d   %8.4f  %12.4f  %12.4f  %+9.4f  %10.6f" %
          (i, d, expect_d, actual_d, err, dp))

# ── 方案 2：逐顶点 k_i ──
print("\n【你的描述：逐顶点锁定】每个顶点 k_i = (d_i+DD)/d_i")
print("  顶点   原深度    新深度     k_i       屏幕变化")
for i, (x, y, d) in enumerate(cs0):
    k_i = (d + DD) / d
    new_d = d + DD
    nx = x * k_i
    np_ = (nx / new_d, (y * k_i) / new_d)
    dp = max(abs(np_[0]-p0[i][0]), abs(np_[1]-p0[i][1]))
    print("   %d   %8.4f  %8.4f  %9.6f  %10.8f" %
          (i, d, new_d, k_i, dp))

print("\n" + "="*82)
print("结论：")
kis = [(d+DD)/d for _,_,d in cs0]
print("  逐顶点 k_i 范围: %.6f ~ %.6f  (跨度 %.6f)" % (min(kis), max(kis), max(kis)-min(kis)))
print("  全局 k 只有 1 个值: %.6f" % k_global)
print("  ⇒ 全局 k 无法同时满足所有顶点的深度要求，误差可达 %.4f" %
      max(abs(d*k_global - (d+DD)) for _,_,d in cs0))
