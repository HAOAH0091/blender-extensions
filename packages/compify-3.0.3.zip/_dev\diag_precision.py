"""定位 ① 屏幕坐标 Δ=2e-4 的来源：逐顶点对比期望/实际深度与 x"""
import bpy, sys, os, math
import importlib.util
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

# 复刻 test_user_move 的 build
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
cd = bpy.data.cameras.new("Cam"); cd.lens = 50.0; cd.sensor_width = 36.0
cam = bpy.data.objects.new("Cam", cd)
sc.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
sc.camera = cam
bpy.context.view_layer.update()

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj"); mat.use_nodes = True
nt = mat.node_tree; nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], out.inputs["Surface"])

bpy.ops.mesh.primitive_cube_add(size=2, location=(-3.5, 8.0, 0.5))
ob = bpy.context.active_object
ob.name = "MK0"
ob.data.materials.clear(); ob.data.materials.append(mat)
bpy.data.node_groups.new("UV Adjust | %s | %s" % (ob.data.name, cd.name), "ShaderNodeTree")
bpy.context.view_layer.update()

print(plock.lock_group(sc, cam).get("message"))
base = np.asarray(plock._read_base_attribute(ob), dtype=np.float64)
view = plock.get_camera_view_matrix(cam)
v_inv = view.inverted()

def cs_now():
    return np.array([tuple(v_inv @ (ob.matrix_world @ v.co)) for v in ob.data.vertices])

cs0 = cs_now()
print("\n锁定后 base 前3项:", np.round(base[:3], 4).tolist())
print("锁定后实际相机空间 前3项:", np.round(cs0[:3], 4).tolist())
print("base 与实际差:", np.abs(base - np.array([(p.x,p.y,-p.z) for p in
      [v_inv @ (ob.matrix_world @ v.co) for v in ob.data.vertices]])).max())

# 沿视线推远 4
axis = view.to_3x3() @ __import__("mathutils").Vector((0.0, 0.0, -1.0))
print("\naxis =", tuple(round(x,4) for x in axis), " |axis| =", round(axis.length, 6))
ob.location = ob.location + axis * 4.0
bpy.context.view_layer.update()

M_before = ob.matrix_world.copy()
plock.parallax_lock_update_handler(sc)
bpy.context.view_layer.update()

off = ob.get(plock.DRAG_OFFSET_KEY, None)
print("\noffset 记录 =", off)
cs1 = cs_now()
print("实际深度变化(逐顶点):", np.round(cs1[:,2] - cs0[:,2], 6).tolist())
print("期望深度变化 = %s" % (off,))
print("深度误差:", np.round((cs1[:,2] - cs0[:,2]) - off, 8).tolist())

# 屏幕坐标
p0 = cs0[:, :2] / cs0[:, 2:3]
p1 = cs1[:, :2] / cs1[:, 2:3]
print("\n屏幕坐标差(逐顶点):", np.round(p1 - p0, 8).tolist())

# base 与 cs0 的 x/y 对比（看 base 是否真的等于锁定时刻的相机空间坐标）
print("\nbase x/y vs cs0 x/y 最大差:", np.abs(base[:, :2] - cs0[:, :2]).max())
print("base d vs cs0 d 最大差:", np.abs(base[:, 2] - cs0[:, 2]).max())
