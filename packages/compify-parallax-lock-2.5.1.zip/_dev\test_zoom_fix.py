"""验证变焦修复：锁定后变焦，图案必须不变；重置后变焦恢复正常。"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = r"F:\desktop\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("Cam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

for i, (x, y, z, r) in enumerate([(-5.0, 16.0, 0.0, 1.15), (-2.5, 16.0, 0.0, 1.15),
                                  (0.0, 16.0, 0.0, 1.15), (2.5, 16.0, 0.0, 1.15),
                                  (5.0, 16.0, 0.0, 1.15)]):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
    bpy.context.active_object.rotation_euler = (0, 0, 0)
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()

W = H = 512
img = bpy.data.images.new("Footage", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        v = 0.93 if ((x // 32) + (y // 32)) % 2 else 0.05
        R = G = B = v
        d = math.hypot(x - W / 2, y - H / 2)
        if d < 72:
            R, G, B = 0.95, 0.12, 0.10
        elif d < 80:
            R, G, B = 0.98, 0.98, 0.98
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear(); o.data.materials.append(mat)
    nm = "UV Adjust | %s | %s" % (o.data.name, cam_data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

scene.render.resolution_x = 760
scene.render.resolution_y = 320
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 16
scene.cycles.device = "CPU"
OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace\_plock_zoom2"
os.makedirs(OUT, exist_ok=True)

P, F = [], []
def check(name, cond, d=""):
    (P if cond else F).append(name)
    print("  [%s] %s %s" % ("PASS" if cond else "FAIL", name, d))

def shot(n):
    scene.render.filepath = os.path.join(OUT, n + ".png")
    bpy.ops.render.render(write_still=True)
    print("SHOT", n)

lens_node = next(n for n in grp.nodes if n.type == "VALUE" and n.label == "Lens")
sock = lens_node.outputs["Value"]

# ── 1 锁定前：变焦有效 ──
cam_data.lens = 50.0; bpy.context.view_layer.update()
shot("0_nolock_t50")
cam_data.lens = 85.0; bpy.context.view_layer.update()
shot("0_nolock_t85")
print("  （未锁定：变焦前后应不同）")

# ── 2 锁定 ──
cam_data.lens = 50.0; bpy.context.view_layer.update()
r = plock.lock_group(scene, cam)
check("锁定成功", r["success"], r["message"])
print("  LENS_VALUE_NOW = %.3f" % sock.default_value)
drv = sock.driver_add  # 检测是否有 driver：尝试 driver_remove 会抛错说明没有
has_drv = False
try:
    sock.driver_remove("default_value")
    has_drv = True
except Exception:
    has_drv = False
check("lens driver 已冻结（移除）", not has_drv)

shot("1_lock_t50")

# ── 3 锁定后变焦：图案应不变 ──
cam_data.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
check("冻结后 lens 节点值仍是 50", abs(sock.default_value - 50.0) < 1e-4,
      "实际 %.4f" % sock.default_value)
shot("2_lock_t85")

# ── 4 重置：driver 应恢复，变焦恢复有效 ──
cam_data.lens = 50.0; bpy.context.view_layer.update()
r2 = plock.reset_group(scene, cam)
check("重置成功", r2["success"], r2["message"])
check("PATCH 已清除", not bool(grp.get(plock.PATCH_KEY)))
shot("3_reset_t50")
cam_data.lens = 85.0; bpy.context.view_layer.update()
shot("4_reset_t85")

print("\nPASS %d / FAIL %d" % (len(P), len(F)))
if F: print("FAILED:", F)
print("ZOOM_FIX_DONE", OUT)
