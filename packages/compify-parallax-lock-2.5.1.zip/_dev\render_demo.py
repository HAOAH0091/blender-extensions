"""渲染方案对比序列：4 方案 × 8 相机位置。

方案：
  1_nolock      现状：网格不动 + 投影实时      → 图案滑动
  2_camfreeze   网格跟相机（SCROLL=0）         → 图案钉住，网格画面里不动
  3_scroll      网格滚动（SCROLL=1，当前实现）  → 网格画面里滚动，图案滑动
  4_projfreeze  投影冻结（网格不动）            → 图案钉住，网格画面里移动
"""
import bpy
import sys
import os
import math
import json
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
PKG_DIR = r"F:\desktop\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]

scene = bpy.context.scene
cam = bpy.data.objects["Camera"]
meshes = [o for o in scene.objects if o.type == "MESH"]
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam.data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

# ── 图案：棋盘 + 同心环 ──
W = H = 512
img = bpy.data.images.new("Pat", W, H)
px = [0.0] * (W * H * 4)
cx = cy = W / 2
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        stripe = 1.0 if (x // 56) % 2 == 0 else 0.12
        r = math.hypot(x - cx, y - cy)
        ring = 1.0 if int(r) // 64 % 2 == 0 else 0.0
        if r < 230:
            px[i], px[i + 1], px[i + 2] = 0.95 * ring, 0.06, 0.12   # 红色同心环
        else:
            px[i], px[i + 1], px[i + 2] = 0.10 * stripe, 0.90 * stripe, 0.25  # 绿色垂直条纹
        px[i + 3] = 1.0
img.pixels.foreach_set(px)
img.pack()

# ── 投影材质（等价 compify 的 x/z 透视投影）──
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
tc = nt.nodes.new("ShaderNodeTexCoord"); tc.object = cam
sep = nt.nodes.new("ShaderNodeSeparateXYZ")
m1 = nt.nodes.new("ShaderNodeMath"); m1.operation = "DIVIDE"
m2 = nt.nodes.new("ShaderNodeMath"); m2.operation = "DIVIDE"
n1 = nt.nodes.new("ShaderNodeMath"); n1.operation = "MULTIPLY"; n1.inputs[1].default_value = -1
n2 = nt.nodes.new("ShaderNodeMath"); n2.operation = "MULTIPLY"; n2.inputs[1].default_value = -1
comb = nt.nodes.new("ShaderNodeCombineXYZ")
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(tc.outputs["Object"], sep.inputs["Vector"])
nt.links.new(sep.outputs["X"], m1.inputs[0]); nt.links.new(sep.outputs["Z"], m1.inputs[1])
nt.links.new(sep.outputs["Y"], m2.inputs[0]); nt.links.new(sep.outputs["Z"], m2.inputs[1])
nt.links.new(m1.outputs[0], n1.inputs[0]); nt.links.new(m2.outputs[0], n2.inputs[0])
nt.links.new(n1.outputs[0], comb.inputs["X"]); nt.links.new(n2.outputs[0], comb.inputs["Y"])
nt.links.new(comb.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

scene.render.resolution_x = scene.render.resolution_y = 420
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = False
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.02, 0.02, 0.03, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 12
scene.cycles.device = "CPU"

OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace\_plock_demo"
os.makedirs(OUT, exist_ok=True)

# 冻结物体（投影源）
frozen = bpy.data.objects.new("ProjFrozen", None)
scene.collection.objects.link(frozen)

CAM0 = tuple(cam.location)
N = 8
SPAN = 3.0
xs = [round(-SPAN + 2 * SPAN * k / (N - 1), 4) for k in range(N)]


def reset_mesh():
    # 用基准还原（若锁过）；否则本来就是原始
    for o in meshes:
        b = plock._read_base_attribute(o)
        if b is None:
            continue
        vi = plock.get_camera_view_matrix(cam).inverted()
        # 无基准时不做；这里用 plock.reset 逻辑
    plock._base_cache.clear()


def render(path):
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)


def set_cam(x):
    cam.location = (CAM0[0] + x, CAM0[1], CAM0[2])
    bpy.context.view_layer.update()


manifest = {}

# ── 方案1：现状 ──
set_cam(0.0)
frames = []
for k, x in enumerate(xs):
    set_cam(x)
    p = os.path.join(OUT, "1_nolock_%d.png" % k)
    render(p); frames.append(os.path.basename(p))
manifest["1_nolock"] = frames
print("DONE 1_nolock")

# ── 方案2：网格跟相机 SCROLL=0 ──
set_cam(0.0)
plock.SCROLL_SCALE = 0.0
plock.lock_group(scene, cam)
frames = []
for k, x in enumerate(xs):
    set_cam(x)
    plock.parallax_lock_update_handler(scene)
    p = os.path.join(OUT, "2_camfreeze_%d.png" % k)
    render(p); frames.append(os.path.basename(p))
plock.reset_group(scene, cam); plock.unlock_group(scene, cam)
manifest["2_camfreeze"] = frames
print("DONE 2_camfreeze")

# ── 方案3：网格滚动 SCROLL=1 ──
set_cam(0.0)
plock.SCROLL_SCALE = 1.0
plock.lock_group(scene, cam)
frames = []
for k, x in enumerate(xs):
    set_cam(x)
    plock.parallax_lock_update_handler(scene)
    p = os.path.join(OUT, "3_scroll_%d.png" % k)
    render(p); frames.append(os.path.basename(p))
plock.reset_group(scene, cam); plock.unlock_group(scene, cam)
manifest["3_scroll"] = frames
print("DONE 3_scroll")

# ── 方案4：投影冻结 ──
set_cam(0.0)
frozen.matrix_world = plock.get_camera_view_matrix(cam)
tc.object = frozen
frames = []
for k, x in enumerate(xs):
    set_cam(x)
    p = os.path.join(OUT, "4_projfreeze_%d.png" % k)
    render(p); frames.append(os.path.basename(p))
tc.object = cam
manifest["4_projfreeze"] = frames
print("DONE 4_projfreeze")

with open(os.path.join(OUT, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump({"xs": xs, "frames": manifest}, f)
print("ALL_DONE %d frames" % (N * 4))
