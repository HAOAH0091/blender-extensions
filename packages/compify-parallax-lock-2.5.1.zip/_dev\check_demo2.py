"""数值验证：球体场景，各方案相机右移后「同一顶点的投影 UV」变化量。

UV 不变 = 图案钉住 ✓ ； UV 变 = 图案滑动 ✗
"""
import bpy
import sys
import os
import math
import mathutils

sys.stdout.reconfigure(encoding="utf-8")
scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("C"); cam_data.lens = 50.0; cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

specs = [(-3.0, 16.0, 0.0, 1.6), (0.0, 16.0, 0.0, 1.6), (3.0, 16.0, 0.0, 1.6),
         (-1.5, 24.0, 0.0, 2.0), (1.5, 24.0, 0.0, 2.0)]
for i, (x, y, z, r) in enumerate(specs):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()
ORIG = {o.name: [tuple(v.co) for v in o.data.vertices] for o in meshes}


def view_m(c):
    loc, rot, _ = c.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def uv(world, src):
    cs = view_m(src).inverted() @ world
    return (-cs.x / cs.z, -cs.y / cs.z) if abs(cs.z) > 1e-9 else (0.0, 0.0)


def samples(src):
    out = []
    for o in meshes:
        n = len(o.data.vertices)
        for idx in (0, n // 2, n - 1):
            out.append(uv(o.matrix_world @ o.data.vertices[idx].co, src))
    return out


def restore():
    for o in meshes:
        f = []
        for c in ORIG[o.name]:
            f.extend(c)
        o.data.vertices.foreach_set("co", f)
        o.data.update()
    bpy.context.view_layer.update()


def lock():
    vi = view_m(cam).inverted()
    base = {}; ref = 0.0
    for o in meshes:
        lst = []
        for v in o.data.vertices:
            cs = vi @ (o.matrix_world @ v.co)
            d = -cs.z
            lst.append((cs.x, cs.y, d)); ref = max(ref, d)
        base[o.name] = lst
    return base, ref, view_m(cam)


def adapt(vl, base, ref, scroll):
    vn = view_m(cam); cr = vn.to_3x3()
    eye = vn.translation - vl.translation
    dcs = cr.transposed() @ eye
    for o in meshes:
        mwi = o.matrix_world.inverted(); f = []
        for (x0, y0, d) in base[o.name]:
            k = (d / ref) * scroll
            local = vn @ mathutils.Vector((x0 - dcs.x * k, y0 - dcs.y * k, -d))
            co = mwi @ local
            f.extend((co.x, co.y, co.z))
        o.data.vertices.foreach_set("co", f)
        o.data.update()


X0 = cam.location.x
DX = 2.0

# 1 现状
restore(); S0 = samples(cam)
cam.location.x = X0 + DX; bpy.context.view_layer.update()
S1 = samples(cam)
d1 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(S1, S0))

# 2 网格跟相机
cam.location.x = X0; bpy.context.view_layer.update()
restore(); base, ref, vl = lock(); S0 = samples(cam)
cam.location.x = X0 + DX; bpy.context.view_layer.update()
adapt(vl, base, ref, 0.0); S2 = samples(cam)
d2 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(S2, S0))

# 3 网格滚动
cam.location.x = X0; bpy.context.view_layer.update()
restore(); base, ref, vl = lock(); S0 = samples(cam)
cam.location.x = X0 + DX; bpy.context.view_layer.update()
adapt(vl, base, ref, 1.0); S3 = samples(cam)
d3 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(S3, S0))

# 4 投影冻结（球不动，投影源钉住 = UV 用输入坐标算）
cam.location.x = X0; bpy.context.view_layer.update()
restore(); frozen = bpy.data.objects.new("F", None); scene.collection.objects.link(frozen)
frozen.matrix_world = view_m(cam)
S0 = samples(frozen)
cam.location.x = X0 + DX; bpy.context.view_layer.update()
S4 = samples(frozen)
d4 = max(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for a, b in zip(S4, S0))

print("相机右移 %.1f 后，各顶点投影 UV 最大变化：" % DX)
print("  1 现状（未锁定）      : %.6f  %s" % (d1, "滑动 ✗" if d1 > 1e-6 else "钉住 ✓"))
print("  2 网格跟相机 SCROLL=0 : %.6f  %s" % (d2, "滑动 ✗" if d2 > 1e-6 else "钉住 ✓"))
print("  3 网格滚动 SCROLL=1   : %.6f  %s" % (d3, "滑动 ✗" if d3 > 1e-6 else "钉住 ✓"))
print("  4 投影冻结            : %.6f  %s" % (d4, "滑动 ✗" if d4 > 1e-6 else "钉住 ✓"))
print("CHECK_DONE")
