"""
Compify 网格视差锁定（Grid Parallax Lock）

相机移动时：
  ① 网格逐顶点变形，适配视锥体（保持构图）—— 用户已确认想要的"网格变形"
  ② 投影 UV 冻结在锁定那一刻 —— 图案死死长在网格表面：不滑动、不变形

② 的机制（关键）：
  compify 的 Camera Project 组数学是 `UV = Affine(相机空间坐标)`，
  第一个节点是 `TexCoord(object=相机)` → 输出"顶点在相机空间的坐标"。
  ⇒ 把【锁定那一刻的相机空间坐标】冻成顶点属性、喂给投影组，
    投影算出来就【永远】等于锁定时的 UV ⇒ 图案完美跟随网格变形。

  （对比：把 TexCoord 的 object 换成"冻结的相机物体"= 只冻结了投影源，
    网格一变形，坐标照样变 → 图案还会滑（残差约 0.0094）——不彻底。）

存储：
  · mesh attribute "compify_plock_base"     FLOAT_VECTOR  — 变形用（相机空间坐标，剥离相机 scale）
  · mesh attribute "compify_plock_campos"   FLOAT_VECTOR  — 图案冻结用（相机空间坐标，含 scale，与 TexCoord 语义一致）
  · scene["compify_plock_groups"]           JSON          — 每相机的锁定状态
  · obj["compify_plock_camera"]             str           — 该 obj 被哪个相机锁定（互斥）
  · Camera Project 组的自定义属性 "compify_plock_patch"    — 组内补丁的还原记录
"""

import bpy
import json
import mathutils
from bpy.app.handlers import persistent

MIN_DEPTH = 1e-4
CAMERA_CHANGE_THRESHOLD = 1e-4
SCROLL_SCALE = 1.0

# 变焦时"优先移动相机"：
#   True  = 变焦时自动沿视线推拉相机（相机真的会动），网格只补偿剩余部分
#   False = 相机不动，全靠网格变形（旧行为）
# 两种模式下「构图冻结」都成立；差别只在【相机是否物理移动】。
CAMERA_DOLLY_ZOOM = True

BASE_ATTR = "compify_plock_base"
CAMPOS_ATTR = "compify_plock_campos"
GROUPS_KEY = "compify_plock_groups"
OBJ_CAM_KEY = "compify_plock_camera"
PATCH_KEY = "compify_plock_patch"
ATTR_NODE_NAME = "compify_plock_attr"
UV_ADJUST_PREFIX = "UV Adjust | "
CAM_PROJECT_PREFIX = "Camera Project | "

# 投影组里被 driver 绑到相机数据、会随变焦/移轴变化的 Value 节点
# （节点 label → camera.data 上的对应属性名）—— 锁定后必须一起冻结，
#  否则变焦时投影 UV 仍会变（lens 卡在 zoom_1 = lens/sensor_width 这一步）。
FROZEN_VALUE_LABELS = {
    "Lens": "lens",
    "Sensor Width": "sensor_width",
    "Lens Shift X": "shift_x",
    "Lens Shift Y": "shift_y",
}

_last_view = {}
_base_cache = {}


# ──────────────────────────── 基础工具 ────────────────────────────

def get_camera_view_matrix(camera):
    """相机视图矩阵：只含位置 + 朝向，剥离对象 scale（相机 scale 不参与渲染，但会污染 matrix_world）。"""
    loc, rot, _scale = camera.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def find_camera(scene, cam_data_name):
    for o in scene.objects:
        if o.type == "CAMERA" and o.data and o.data.name == cam_data_name:
            return o
    return None


def get_lock_targets(scene, camera):
    """该相机下所有「带投射 UV」的 mesh 对象（按 UV Adjust 组名反查）。"""
    if camera is None or camera.data is None:
        return []
    cam_data_name = camera.data.name
    suffix = " | " + cam_data_name
    obj_data_names = set()
    for ng in bpy.data.node_groups:
        if ng.name.startswith(UV_ADJUST_PREFIX) and ng.name.endswith(suffix):
            mid = ng.name[len(UV_ADJUST_PREFIX):len(ng.name) - len(suffix)]
            if mid:
                obj_data_names.add(mid)
    out = []
    for o in scene.objects:
        if o.type == "MESH" and o.data and o.data.name in obj_data_names:
            out.append(o)
    return out


def objects_using_projection(scene, cam_data_name):
    """所有材质里引用了该相机 Camera Project 组的 mesh 对象（图案冻结要覆盖它们）。"""
    gname = CAM_PROJECT_PREFIX + cam_data_name
    out = []
    for o in scene.objects:
        if o.type != "MESH" or o.data is None:
            continue
        hit = False
        for m in o.data.materials:
            nt = getattr(m, "node_tree", None)
            if nt is None:
                continue
            stack = [nt]
            seen = set()
            while stack and not hit:
                t = stack.pop()
                ptr = t.as_pointer()
                if ptr in seen:
                    continue
                seen.add(ptr)
                for n in t.nodes:
                    if n.type == "GROUP" and n.node_tree is not None:
                        if n.node_tree.name == gname:
                            hit = True
                            break
                        stack.append(n.node_tree)
        if hit:
            out.append(o)
    return out


def has_modifier_or_shapekey(obj):
    """返回阻塞原因或 None。"""
    if len(obj.modifiers) > 0:
        return "修改器"
    if obj.data is None:
        return "无网格数据"
    if obj.data.shape_keys is not None:
        return "形态键"
    if obj.data.users > 1:
        return "共享网格"
    return None


# ──────────────────────────── 状态存取 ────────────────────────────

def load_groups(scene):
    raw = scene.get(GROUPS_KEY)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_groups(scene, groups):
    scene[GROUPS_KEY] = json.dumps(groups)


def get_state(scene, camera):
    if camera is None or camera.data is None:
        return None
    return load_groups(scene).get(camera.data.name)


def is_locked(scene, camera):
    st = get_state(scene, camera)
    return bool(st and st.get("enabled"))


# ──────────────────────────── 顶点属性 ────────────────────────────

def _new_vec_attr(mesh, name):
    old = mesh.attributes.get(name)
    if old is not None:
        mesh.attributes.remove(old)
    return mesh.attributes.new(name=name, type="FLOAT_VECTOR", domain="POINT")


def _write_base_attribute(obj, cam_space_list):
    """变形用基准（相机空间坐标，剥离 scale）。"""
    mesh = obj.data
    attr = _new_vec_attr(mesh, BASE_ATTR)
    flat = []
    for (x0, y0, d) in cam_space_list:
        flat.extend((x0, y0, d))
    attr.data.foreach_set("vector", flat)
    mesh.update()
    _base_cache.clear()


def _write_campos_attribute(obj, camera, mw_inv=None):
    """图案冻结用：相机空间坐标（含相机 scale），与 TexCoord 的 Object 输出语义一致。"""
    if mw_inv is None:
        mw_inv = camera.matrix_world.inverted()
    mesh = obj.data
    attr = _new_vec_attr(mesh, CAMPOS_ATTR)
    mwo = obj.matrix_world
    flat = []
    for v in mesh.vertices:
        c = mw_inv @ (mwo @ v.co)
        flat.extend((c.x, c.y, c.z))
    attr.data.foreach_set("vector", flat)
    mesh.update()


def _remove_attr(obj, name):
    mesh = obj.data
    a = mesh.attributes.get(name)
    if a is not None:
        mesh.attributes.remove(a)


def _read_base_attribute(obj):
    mesh = obj.data
    attr = mesh.attributes.get(BASE_ATTR)
    if attr is None:
        return None
    n = len(mesh.vertices)
    if len(attr.data) != n:
        return None
    key = (obj.name, mesh.as_pointer(), n)
    hit = _base_cache.get(key)
    if hit is not None:
        return hit
    flat = [0.0] * (n * 3)
    attr.data.foreach_get("vector", flat)
    out = [(flat[i * 3], flat[i * 3 + 1], flat[i * 3 + 2]) for i in range(n)]
    _base_cache[key] = out
    return out


# ──────────────────────────── 投影组补丁（图案冻结）────────────────────────────

def patch_camera_project_group(cam_data_name):
    """在 Camera Project 组里，把 TexCoord 的输出替换成冻结坐标属性。

    改法：TexCoord(Object) → [Attribute] → 下游
    ⇒ 投影 UV 恒等于锁定那一刻的值。
    """
    gname = CAM_PROJECT_PREFIX + cam_data_name
    ng = bpy.data.node_groups.get(gname)
    if ng is None:
        return None
    if ng.get(PATCH_KEY):
        return ng
    tc = None
    for n in ng.nodes:
        if n.type == "TEX_COORD" and getattr(n, "object", None) is not None:
            tc = n
            break
    if tc is None:
        return None
    src = None
    for s in tc.outputs:
        if s.links:
            src = s
            break
    if src is None:
        return None
    dests = [[lk.to_node.name, lk.to_socket.identifier] for lk in src.links]
    if not dests:
        return None

    attr = ng.nodes.new("ShaderNodeAttribute")
    attr.attribute_name = CAMPOS_ATTR
    attr.label = "Plock: Frozen Cam-Space Pos"
    attr.name = ATTR_NODE_NAME
    attr.location = (tc.location.x + 200.0, tc.location.y - 240.0)

    for lk in list(src.links):
        ng.links.remove(lk)
    for nname, ident in dests:
        node = ng.nodes.get(nname)
        if node is None:
            continue
        sock = node.inputs.get(ident)
        if sock is not None:
            ng.links.new(attr.outputs["Vector"], sock)

    # ── 冻结 lens / sensor / shift（否则变焦时 UV 仍会变）──
    cam_data = bpy.data.cameras.get(cam_data_name)
    frozen = []
    if cam_data is not None:
        for n in ng.nodes:
            if n.type == "VALUE" and n.label in FROZEN_VALUE_LABELS:
                out = n.outputs["Value"]
                path = FROZEN_VALUE_LABELS[n.label]
                val = float(getattr(cam_data, path, out.default_value))
                try:
                    out.driver_remove("default_value")
                except Exception:
                    pass
                out.default_value = val
                frozen.append({"node": n.name, "path": path, "value": val})

    ng[PATCH_KEY] = json.dumps({"tc": tc.name, "src": src.identifier,
                                "attr": attr.name, "dests": dests,
                                "frozen": frozen})
    return ng


def unpatch_camera_project_group(cam_data_name):
    gname = CAM_PROJECT_PREFIX + cam_data_name
    ng = bpy.data.node_groups.get(gname)
    if ng is None:
        return
    raw = ng.get(PATCH_KEY)
    if not raw:
        return
    try:
        info = json.loads(raw)
    except Exception:
        return
    attr = ng.nodes.get(info.get("attr", ""))
    if attr is not None:
        for o in attr.outputs:
            for lk in list(o.links):
                ng.links.remove(lk)
        ng.nodes.remove(attr)
    tc = ng.nodes.get(info.get("tc", ""))
    if tc is not None:
        src = tc.outputs.get(info.get("src", ""))
        if src is not None:
            for nname, ident in info.get("dests", []):
                node = ng.nodes.get(nname)
                if node is None:
                    continue
                sock = node.inputs.get(ident)
                if sock is not None:
                    ng.links.new(src, sock)

    # 还原 lens / sensor / shift 的 driver（让变焦重新生效）
    cam_data = bpy.data.cameras.get(cam_data_name)
    for f in info.get("frozen", []):
        n = ng.nodes.get(f.get("node", ""))
        if n is None:
            continue
        out = n.outputs["Value"]
        out.default_value = float(f.get("value", out.default_value))
        if cam_data is None:
            continue
        try:
            drv = out.driver_add("default_value").driver
            drv.type = "SUM"
            var = drv.variables.new()
            var.type = "SINGLE_PROP"
            var.targets[0].id_type = "CAMERA"
            var.targets[0].id = cam_data
            var.targets[0].data_path = f.get("path", "lens")
        except Exception:
            pass

    try:
        del ng[PATCH_KEY]
    except Exception:
        pass


# ──────────────────────────── 变焦 → 相机推拉 ────────────────────────────

def _locked_axis(state):
    """锁定时的光轴（指向场景内）。"""
    view_locked = mathutils.Matrix([mathutils.Vector(r) for r in state["locked_matrix"]])
    return view_locked.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))


def auto_dolly_vector(state, zoom):
    """变焦补偿中【由相机承担】的那段位移。

    取基准层（ref_depth）为锚点：相机沿光轴移动 ref·(1-k)，
    使基准层靠"相机移动"就能保持构图；其余深度由网格补偿。
    这样：变焦时相机真的在动，而构图仍精确冻结。
    """
    if not CAMERA_DOLLY_ZOOM:
        return mathutils.Vector((0.0, 0.0, 0.0))
    ref = float(state.get("ref_depth", 0.0))
    # k>1（拉长焦=放大）→ 相机后退（负号 = 逆光轴）
    return _locked_axis(state) * (-ref * (float(zoom) - 1.0))


# ──────────────────────────── 核心：适配 ────────────────────────────

def adapt_object(obj, camera, state, view_now=None):
    base = _read_base_attribute(obj)
    if base is None:
        return False
    if view_now is None:
        view_now = get_camera_view_matrix(camera)
    view_locked = mathutils.Matrix([mathutils.Vector(r) for r in state["locked_matrix"]])
    ref_depth = float(state["ref_depth"])
    focal_locked = float(state["locked_focal"]) or MIN_DEPTH

    focal_now = camera.data.lens
    zoom = (focal_now / focal_locked) if focal_locked > MIN_DEPTH else 1.0
    zoom = max(zoom, MIN_DEPTH)

    # ⚠️ 归因：变焦时自动施加给相机的那段 dolly 必须【排除】在相机位移之外，
    #    否则它会和 zoom 重复计算（depth 变成 d·k²）。
    eye_now = view_now.translation
    eye_user = eye_now - auto_dolly_vector(state, zoom)

    cur_rot = view_now.to_3x3()
    eye_delta = eye_user - view_locked.translation
    delta_cs = cur_rot.transposed() @ eye_delta

    axis0 = view_locked.to_3x3() @ mathutils.Vector((0.0, 0.0, -1.0))
    axial = eye_delta.dot(axis0)
    dolly = (ref_depth - axial) / ref_depth if ref_depth > MIN_DEPTH else 1.0
    dolly = max(dolly, MIN_DEPTH)

    mw_inv = obj.matrix_world.inverted()
    mesh = obj.data
    flat = []
    ap = flat.append
    for (x0, y0, d) in base:
        k = (d / ref_depth) if ref_depth > MIN_DEPTH else 1.0
        depth = max(d * dolly * zoom, MIN_DEPTH)
        local = view_now @ mathutils.Vector(
            (x0 - delta_cs.x * k * SCROLL_SCALE,
             y0 - delta_cs.y * k * SCROLL_SCALE,
             -depth))
        co = mw_inv @ local
        ap(co.x); ap(co.y); ap(co.z)
    mesh.vertices.foreach_set("co", flat)
    mesh.update()
    return True


# ──────────────────────────── 锁定 / 解锁 / 重置 ────────────────────────────

def lock_group(scene, camera):
    targets = get_lock_targets(scene, camera)
    if not targets:
        return {"success": False, "message": "该相机下没有带投射 UV 的网格",
                "locked": [], "skipped": []}

    view = get_camera_view_matrix(camera)
    view_inv = view.inverted()
    mw_inv_cam = camera.matrix_world.inverted()

    locked, skipped = [], []
    per_obj_cam_space = {}
    ref_depth = 0.0
    for obj in targets:
        reason = has_modifier_or_shapekey(obj)
        if reason:
            skipped.append((obj, reason))
            continue
        mw = obj.matrix_world
        cs_list = []
        ok = True
        for v in obj.data.vertices:
            cs = view_inv @ (mw @ v.co)
            depth = -cs.z
            if depth <= MIN_DEPTH:
                ok = False
                break
            cs_list.append((cs.x, cs.y, depth))
            if depth > ref_depth:
                ref_depth = depth
        if not ok:
            skipped.append((obj, "顶点在相机后方"))
            continue
        per_obj_cam_space[obj.name] = cs_list
        locked.append(obj)

    if not locked:
        return {"success": False,
                "message": "所有目标都带修改器/形态键/共享网格，无法使用该功能",
                "locked": [], "skipped": skipped}
    if ref_depth <= MIN_DEPTH:
        return {"success": False, "message": "基准深度异常（网格可能在相机后方）",
                "locked": [], "skipped": skipped}

    cam_data_name = camera.data.name

    # 多相机互斥
    groups = load_groups(scene)
    for obj in locked:
        prev = obj.get(OBJ_CAM_KEY)
        if prev and prev != cam_data_name:
            old = groups.get(prev)
            if old:
                old["objects"] = [n for n in old.get("objects", []) if n != obj.name]
                if not old["objects"]:
                    old["enabled"] = False
                groups[prev] = old
                unpatch_camera_project_group(prev)

    # ① 变形基准
    for obj in locked:
        _write_base_attribute(obj, per_obj_cam_space[obj.name])
        obj[OBJ_CAM_KEY] = cam_data_name

    # ② 图案冻结：给所有用该投影材质的网格写"冻结坐标" + 打组补丁
    for obj in objects_using_projection(scene, cam_data_name):
        _write_campos_attribute(obj, camera, mw_inv_cam)
    patch_camera_project_group(cam_data_name)

    groups[cam_data_name] = {
        "enabled": True,
        "ref_depth": ref_depth,
        "locked_matrix": [[float(x) for x in row] for row in view],
        "locked_focal": float(camera.data.lens),
        "locked_sensor_w": float(camera.data.sensor_width),
        "locked_sensor_h": float(camera.data.sensor_height),
        "applied_zoom": 1.0,          # 已经施加到相机上的变焦 dolly 对应的 zoom
        "objects": [o.name for o in locked],
    }
    save_groups(scene, groups)
    _last_view[(scene.name, cam_data_name)] = (view.copy(), float(camera.data.lens))

    return {"success": True,
            "message": "已锁定 %d 个网格（基准深度 %.3f，跳过 %d）"
                       % (len(locked), ref_depth, len(skipped)),
            "locked": locked, "skipped": skipped}


def unlock_group(scene, camera):
    """解锁：停止跟随（网格停在当前位置、图案保持冻结 —— 关掉不回退）。"""
    groups = load_groups(scene)
    st = groups.get(camera.data.name)
    if not st:
        return {"success": False, "message": "该相机未锁定"}
    st["enabled"] = False
    groups[camera.data.name] = st
    save_groups(scene, groups)
    _last_view.pop((scene.name, camera.data.name), None)
    return {"success": True, "message": "已解锁（网格/图案保持当前状态，可用重置恢复）"}


def reset_group(scene, camera):
    """重置：撤销所有锁定造成的改动 + 解除锁定（一步到位）。"""
    cam_data_name = camera.data.name
    st = load_groups(scene).get(cam_data_name)
    if not st:
        return {"success": False, "message": "该相机没有锁定记录"}
    view_locked = mathutils.Matrix([mathutils.Vector(r) for r in st["locked_matrix"]])

    n = 0
    for name in st.get("objects", []):
        obj = scene.objects.get(name)
        if obj is None or obj.type != "MESH":
            continue
        base = _read_base_attribute(obj)
        if base is None:
            continue
        mw_inv = obj.matrix_world.inverted()
        mesh = obj.data
        flat = []
        ap = flat.append
        for (x0, y0, d) in base:
            world = view_locked @ mathutils.Vector((x0, y0, -d))
            co = mw_inv @ world
            ap(co.x); ap(co.y); ap(co.z)
        mesh.vertices.foreach_set("co", flat)
        mesh.update()
        n += 1

    # 撤销变焦时施加到相机上的 dolly（把相机位置还回去）
    if CAMERA_DOLLY_ZOOM:
        az = float(st.get("applied_zoom", 1.0))
        if abs(az - 1.0) > 1e-6:
            ref = float(st.get("ref_depth", 0.0))
            camera.location = camera.location + _locked_axis(st) * (ref * (az - 1.0))

    # 撤补丁 + 清属性
    unpatch_camera_project_group(cam_data_name)
    for obj in scene.objects:
        if obj.type == "MESH" and obj.data is not None:
            _remove_attr(obj, CAMPOS_ATTR)
            if obj.get(OBJ_CAM_KEY) == cam_data_name:
                _remove_attr(obj, BASE_ATTR)
                try:
                    del obj[OBJ_CAM_KEY]
                except Exception:
                    pass

    groups = load_groups(scene)
    groups.pop(cam_data_name, None)
    save_groups(scene, groups)
    _base_cache.clear()
    _last_view.pop((scene.name, cam_data_name), None)
    return {"success": True, "message": "已重置 %d 个网格 + 解除锁定" % n}


# ──────────────────────────── handler ────────────────────────────

# 防重入：我们自己在 handler 里移动相机，会再次触发 depsgraph
_dolly_guard = False


def _apply_zoom_dolly(scene, camera, st, zoom, cam_data_name, groups):
    """变焦增量 → 移动相机（增量式，保留用户自己的相机位移）。"""
    global _dolly_guard
    prev = float(st.get("applied_zoom", 1.0))
    delta = float(zoom) - prev
    if abs(delta) <= 1e-6:
        return False
    ref = float(st.get("ref_depth", 0.0))
    v = _locked_axis(st)
    _dolly_guard = True
    try:
        camera.location = camera.location + v * (-ref * delta)
        st["applied_zoom"] = float(zoom)
        groups[cam_data_name] = st
        save_groups(scene, groups)
        bpy.context.view_layer.update()
    finally:
        _dolly_guard = False
    return True


@persistent
def parallax_lock_update_handler(scene):
    if _dolly_guard:
        return
    try:
        groups = load_groups(scene)
        if not groups:
            return

        # 第一步：变焦检测 → 移动相机（相机真的动起来）
        # ⚠️ 不 return：必须紧接着在同一轮里做网格适配，否则本轮只有相机动、网格不动
        for cam_data_name, st in groups.items():
            if not st.get("enabled"):
                continue
            camera = find_camera(scene, cam_data_name)
            if camera is None:
                continue
            lf = float(st.get("locked_focal", 0.0)) or MIN_DEPTH
            zoom = float(camera.data.lens) / lf
            _apply_zoom_dolly(scene, camera, st, zoom, cam_data_name, groups)

        # 第二步：网格逐顶点适配
        for cam_data_name, st in groups.items():
            if not st.get("enabled"):
                continue
            camera = find_camera(scene, cam_data_name)
            if camera is None:
                continue
            view = get_camera_view_matrix(camera)
            lens_now = float(camera.data.lens)
            key = (scene.name, cam_data_name)
            last = _last_view.get(key)
            if last is not None and _matrices_close(last[0], view, CAMERA_CHANGE_THRESHOLD) \
                    and abs(lens_now - last[1]) <= 1e-6:
                continue
            _last_view[key] = (view.copy(), lens_now)
            for name in st.get("objects", []):
                obj = scene.objects.get(name)
                if obj is None or obj.type != "MESH":
                    continue
                adapt_object(obj, camera, st, view_now=view)
    except Exception:
        import traceback
        traceback.print_exc()


def _matrices_close(a, b, tol):
    for i in range(4):
        for j in range(4):
            if abs(a[i][j] - b[i][j]) > tol:
                return False
    return True


# ──────────────────────────── 注册 ────────────────────────────

def register_handlers():
    h = bpy.app.handlers.depsgraph_update_post
    if parallax_lock_update_handler not in h:
        h.append(parallax_lock_update_handler)


def unregister_handlers():
    h = bpy.app.handlers.depsgraph_update_post
    if parallax_lock_update_handler in h:
        h.remove(parallax_lock_update_handler)
    _last_view.clear()
    _base_cache.clear()
