"""渲染可视验证：移相机时投影材质是否还贴合网格。

3 张对比：
  01_initial      初始
  02_nolock_moved 移相机·未锁定（网格世界不动 → 图案应在网格上滑动）
  03_locked_moved 锁定后移相机（网格跟随 → 图案应与 01 相对网格一致）
"""
import bpy
import sys
import os
import math
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
PKG_DIR = r"F:\desktop\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]

scene = bpy.context.scene
cam = bpy.data.objects["Camera"]
meshes = [o for o in scene.objects if o.type == "MESH"]
OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace\_plock_render"
os.makedirs(OUT, exist_ok=True)

# UV Adjust 组名（让目标识别生效）
for o in meshes:
    nm = "UV Adjust | %s | %s" % (o.data.name, cam.data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

# ── footage 图：棋盘 + 同心环，移位时图案滑动肉眼可辨 ──
W = H = 256
img = bpy.data.images.new("Footage", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        checker = ((x // 16) + (y // 16)) % 2
        r = math.hypot(x - W / 2, y - H / 2)
        ring = 1.0 if (int(r) // 12) % 2 == 0 else 0.0
        px[i] = 0.85 if checker else 0.15
        px[i + 1] = ring
        px[i + 2] = 0.9 if (x // 8) % 2 == 0 else 0.1
        px[i + 3] = 1.0
img.pixels.foreach_set(px)
img.pack()

# ── 最小投影材质：TexCoord(Camera) → Image → Emission ──
mat = bpy.data.materials.new("ProjMat")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
tc = nt.nodes.new("ShaderNodeTexCoord")
tex = nt.nodes.new("ShaderNodeTexImage")
tex.image = img
emit = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(tc.outputs["Camera"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], emit.inputs["Color"])
nt.links.new(emit.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear()
    o.data.materials.append(mat)

scene.render.resolution_x = 512
scene.render.resolution_y = 512
# Blender 5.x：先设 media_type=IMAGE，file_format 才有 PNG（否则 enum 里只有 FFMPEG）
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
try:
    scene.render.engine = "BLENDER_EEVEE_NEXT"
except Exception:
    scene.render.engine = "CYCLES"
if scene.render.engine == "CYCLES":
    scene.cycles.samples = 16
    scene.cycles.device = "CPU"
print("ENGINE=%s" % scene.render.engine)


def shot(name):
    scene.render.filepath = os.path.join(OUT, name)
    bpy.ops.render.render(write_still=True)
    print("SHOT_OK %s" % name)


start_loc = tuple(cam.location)

shot("01_initial.png")

# 未锁定移相机
cam.location.x += 3.0
bpy.context.view_layer.update()
shot("02_nolock_moved.png")

# 回位 → 锁定 → 移相机
cam.location = start_loc
bpy.context.view_layer.update()
r = plock.lock_group(scene, cam)
print("LOCK:", r["success"], r["message"])
cam.location.x += 3.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
shot("03_locked_moved.png")

print("RENDER_DONE %s" % OUT)
