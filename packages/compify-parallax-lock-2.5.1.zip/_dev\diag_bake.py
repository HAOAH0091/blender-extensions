"""决定性实验：什么才是「图案不滑动 + 网格仍变形」？

背景（数学事实）：
  投影 UV 只由【顶点相对相机的位置】决定。
  所以「图案不滑动」⟺「顶点相对投影源不动」。
  只要靠"移动顶点"来实现，唯一解就是【刚性跟随】= 父子级 —— 没有任何形变余地。

  ⇒ 要在【网格变形】的同时让图案不滑动，必须冻结的**不是投影源，而是"图案本身"**：
     把锁定那一刻的投影 UV **烘焙到网格**上（图案从此长在网格表面）。

本实验验证「烘焙」是否成立：
  G1 现状：网格滚动(变形) + 投影实时      → 图案应滑动
  G2 烘焙：网格滚动(变形) + 投影UV已冻结自带 → 图案应钉住、无形变
"""
import bpy
import sys
import os
import math
import mathutils

sys.stdout.reconfigure(encoding="utf-8")
scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("C")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam_data.sensor_height = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

specs = [(-5.0, 16.0, 0.0, 1.15), (-2.5, 16.0, 0.0, 1.15), (0.0, 16.0, 0.0, 1.15),
         (2.5, 16.0, 0.0, 1.15), (5.0, 16.0, 0.0, 1.15)]
for i, (x, y, z, r) in enumerate(specs):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
    bpy.ops.object.shade_smooth()
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()
ORIG = {o.name: [tuple(v.co) for v in o.data.vertices] for o in meshes}

# ── 图案 ──
W = H = 512
img = bpy.data.images.new("Pat", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        v = 0.93 if ((x // 32) + (y // 32)) % 2 else 0.05
        R = G = B = v
        d = math.hypot(x - W / 2, y - H / 2)
        if d < 72:
            R, G, B = 0.95, 0.12, 0.10
        elif d < 80:
            R, G, B = 0.98, 0.98, 0.98
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

KX = cam_data.lens / cam_data.sensor_width
KY = cam_data.lens / cam_data.sensor_height


def view_m(x):
    loc, rot, _ = x.matrix_world.decompose()
    return mathutils.Matrix.Translation(loc) @ rot.to_matrix().to_4x4()


def proj_uv(world):
    cs = view_m(cam).inverted() @ world
    if abs(cs.z) < 1e-9:
        return (0.5, 0.5)
    return (0.5 + cs.x / -cs.z * KX, 0.5 + cs.y / -cs.z * KY)


# ── 材质1：实时投影（≈ compify Camera Project）──
def mat_live():
    m = bpy.data.materials.new("Live")
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    tc = nt.nodes.new("ShaderNodeTexCoord"); tc.object = cam
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    dx = nt.nodes.new("ShaderNodeMath"); dx.operation = "DIVIDE"
    dy = nt.nodes.new("ShaderNodeMath"); dy.operation = "DIVIDE"
    mx = nt.nodes.new("ShaderNodeMath"); mx.operation = "MULTIPLY"; mx.inputs[1].default_value = -KX
    my = nt.nodes.new("ShaderNodeMath"); my.operation = "MULTIPLY"; my.inputs[1].default_value = -KY
    ax = nt.nodes.new("ShaderNodeMath"); ax.operation = "ADD"; ax.inputs[1].default_value = 0.5
    ay = nt.nodes.new("ShaderNodeMath"); ay.operation = "ADD"; ay.inputs[1].default_value = 0.5
    comb = nt.nodes.new("ShaderNodeCombineXYZ")
    tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
    em = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(tc.outputs["Object"], sep.inputs["Vector"])
    nt.links.new(sep.outputs["X"], dx.inputs[0]); nt.links.new(sep.outputs["Z"], dx.inputs[1])
    nt.links.new(sep.outputs["Y"], dy.inputs[0]); nt.links.new(sep.outputs["Z"], dy.inputs[1])
    nt.links.new(dx.outputs[0], mx.inputs[0]); nt.links.new(dy.outputs[0], my.inputs[0])
    nt.links.new(mx.outputs[0], ax.inputs[0]); nt.links.new(my.outputs[0], ay.inputs[0])
    nt.links.new(ax.outputs[0], comb.inputs["X"]); nt.links.new(ay.outputs[0], comb.inputs["Y"])
    nt.links.new(comb.outputs["Vector"], tex.inputs["Vector"])
    nt.links.new(tex.outputs["Color"], em.inputs["Color"])
    nt.links.new(em.outputs["Emission"], out.inputs["Surface"])
    return m


# ── 材质2：烘焙 UV（图案长在网格上）──
def mat_baked(uvname):
    m = bpy.data.materials.new("Baked")
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    uvm = nt.nodes.new("ShaderNodeUVMap"); uvm.uv_map = uvname
    tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
    em = nt.nodes.new("ShaderNodeEmission")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(uvm.outputs["UV"], tex.inputs["Vector"])
    nt.links.new(tex.outputs["Color"], em.inputs["Color"])
    nt.links.new(em.outputs["Emission"], out.inputs["Surface"])
    return m


LIVE = mat_live()
BAKED = mat_baked("proof")


def bake_uv():
    """把当前投影 UV 烘焙成 UV 层（每顶点一份）。"""
    for o in meshes:
        mw = o.matrix_world
        uvs = [proj_uv(mw @ v.co) for v in o.data.vertices]
        layer = o.data.uv_layers.get("proof") or o.data.uv_layers.new(name="proof")
        for poly in o.data.polygons:
            for li in poly.loop_indices:
                vi = o.data.loops[li].vertex_index
                layer.data[li].uv = uvs[vi]


def set_mat(m):
    for o in meshes:
        o.data.materials.clear()
        o.data.materials.append(m)


def restore():
    for o in meshes:
        f = []
        for c in ORIG[o.name]:
            f.extend(c)
        o.data.vertices.foreach_set("co", f)
        o.data.update()
    bpy.context.view_layer.update()


def lock_base():
    vi = view_m(cam).inverted()
    base = {}
    ref = 0.0
    for o in meshes:
        lst = []
        for v in o.data.vertices:
            cs = vi @ (o.matrix_world @ v.co)
            d = -cs.z
            lst.append((cs.x, cs.y, d))
            ref = max(ref, d)
        base[o.name] = lst
    return base, ref, view_m(cam)


def deform(vl, base, ref, scroll=1.0):
    vn = view_m(cam)
    dcs = vn.to_3x3().transposed() @ (vn.translation - vl.translation)
    for o in meshes:
        mwi = o.matrix_world.inverted()
        f = []
        for (x0, y0, d) in base[o.name]:
            k = (d / ref) * scroll
            co = mwi @ (vn @ mathutils.Vector((x0 - dcs.x * k, y0 - dcs.y * k, -d)))
            f.extend((co.x, co.y, co.z))
        o.data.vertices.foreach_set("co", f)
        o.data.update()
    bpy.context.view_layer.update()


scene.render.resolution_x = 760
scene.render.resolution_y = 320
scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 20
scene.cycles.device = "CPU"

OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace\_plock_bake"
os.makedirs(OUT, exist_ok=True)


def shot(n):
    scene.render.filepath = os.path.join(OUT, n + ".png")
    bpy.ops.render.render(write_still=True)
    print("SHOT", n)


X0 = cam.location.x
DX = 2.0

# ── G1 现状：滚动 + 实时 ──
cam.location.x = X0; bpy.context.view_layer.update()
restore(); set_mat(LIVE)
base, ref, vl = lock_base()
shot("G1_live_init")
cam.location.x = X0 + DX; bpy.context.view_layer.update()
deform(vl, base, ref, 1.0)
shot("G1_live_moved")

# ── G2 烘焙：滚动 + 烘焙UV ──
cam.location.x = X0; bpy.context.view_layer.update()
restore()
set_mat(LIVE)          # 先按实时算烘焙
bake_uv()              # 把锁定时的投影 UV 烘进网格
set_mat(BAKED)         # 换成使用烘焙 UV
base, ref, vl = lock_base()
shot("G2_baked_init")
cam.location.x = X0 + DX; bpy.context.view_layer.update()
deform(vl, base, ref, 1.0)
shot("G2_baked_moved")

print("BAKE_DONE", OUT)
