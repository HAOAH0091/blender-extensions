"""Compify 网格视差锁定 —— 数学正确性验证（Blender headless，自建可控场景）

验证三件事：
  1. 锁定 → 移相机 → 各顶点屏幕位移【一致】（= 整体滚动、投影形状不变）
  2. 重置 → 顶点恢复锁定前坐标
  3. 旋转 / 变焦 行为符合预期
"""
import bpy
import sys
import os
import math
import mathutils

sys.stdout.reconfigure(encoding="utf-8")
_HERE = os.path.dirname(os.path.abspath(__file__))
ADDONS = os.path.dirname(_HERE)
sys.path.insert(0, ADDONS)

import compify_parallax_lock as PL  # noqa: E402

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %s %s" % ("PASS" if cond else "FAIL", name, detail))


# ── 建场景 ──
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene

cam_data = bpy.data.cameras.new("TestCam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("TestCamera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, 0.0, 5.0)
cam.rotation_euler = (0.0, 0.0, 0.0)   # 朝 -Z
bpy.context.view_layer.update()        # ⚠️ 必须：否则 matrix_world 还是 identity


def make_grid(name, z, x):
    mesh = bpy.data.meshes.new(name)
    verts = [(x - 1, -1, z), (x + 1, -1, z), (x + 1, 1, z), (x - 1, 1, z)]
    mesh.from_pydata(verts, [], [(0, 1, 2, 3)])
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(obj)
    return obj


objs = [make_grid("G0", 0.0, 0.0), make_grid("G1", -2.0, 0.5), make_grid("G2", -4.0, -0.5)]

# 假 UV Adjust 组（名称符合 compify 约定，让 get_lock_targets 识别）
for o in objs:
    bpy.data.node_groups.new("UV Adjust | %s | %s" % (o.data.name, cam_data.name), "ShaderNodeTree")

print("目标识别:", [o.name for o in PL.get_lock_targets(scene, cam)])


def view_inv(c):
    return PL.get_camera_view_matrix(c).inverted()


def screen_coords():
    """各 mesh 所有顶点的屏幕坐标（focal*x/(depth*sensor)），世界坐标经 obj 矩阵。"""
    vi = view_inv(cam)
    out = []
    for o in objs:
        mw = o.matrix_world
        for v in o.data.vertices:
            cs = vi @ (mw @ v.co)
            d = -cs.z
            if abs(d) < 1e-9:
                out.append((0.0, 0.0))
                continue
            out.append((cam_data.lens * cs.x / (d * cam_data.sensor_width),
                        cam_data.lens * cs.y / (d * cam_data.sensor_width)))  # 含焦距因子 = 真实屏幕落点
    return out


def world_coords():
    out = []
    for o in objs:
        mw = o.matrix_world
        for v in o.data.vertices:
            out.append(tuple(mw @ v.co))
    return out


# ── 1) 锁定 ──
print("\n=== 1) 锁定 ===")
res = PL.lock_group(scene, cam)
check("lock_group 成功", res["success"], res["message"])
check("锁定对象数 = 3", len(res["locked"]) == 3, "实际 %d" % len(res["locked"]))
st = PL.get_state(scene, cam)
check("ref_depth > 0", st["ref_depth"] > 0, "ref_depth=%.4f" % st["ref_depth"])
orig_world = world_coords()
S0 = screen_coords()

# ── 2) 相机横移 → 屏幕位移应一致（整体滚动）──
print("\n=== 2) 相机横移 Δx=+1.5 ===")
cam.location = (1.5, 0.0, 5.0)
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
S1 = screen_coords()
deltas = [(S1[i][0] - S0[i][0], S1[i][1] - S0[i][1]) for i in range(len(S0))]
dxs = [d[0] for d in deltas]
dys = [d[1] for d in deltas]
spread_x = max(dxs) - min(dxs)
spread_y = max(dys) - min(dys)
print("  各顶点屏幕位移 X: %s" % [round(x, 6) for x in dxs])
print("  各顶点屏幕位移 Y: %s" % [round(y, 6) for y in dys])
check("屏幕位移一致(Δx spread < 1e-6)", spread_x < 1e-6, "spread=%.2e" % spread_x)
check("屏幕位移一致(Δy spread < 1e-6)", spread_y < 1e-6, "spread=%.2e" % spread_y)
check("确实滚动了(非零)", abs(dxs[0]) > 1e-6, "Δx=%.4f" % dxs[0])

# 理论值：-Δcs.x * focal/(ref_depth*sensor_w)，Δcs.x = +1.5
expected_dx = -1.5 * cam_data.lens / (st["ref_depth"] * cam_data.sensor_width)
check("滚动量符合理论", abs(dxs[0] - expected_dx) < 1e-6,
      "实测 %.6f vs 理论 %.6f" % (dxs[0], expected_dx))

# 投影形状不变：各顶点相对位置（屏幕坐标两两差）应保持
rel_before = [(S0[i][0] - S0[0][0], S0[i][1] - S0[0][1]) for i in range(len(S0))]
rel_after = [(S1[i][0] - S1[0][0], S1[i][1] - S1[0][1]) for i in range(len(S0))]
shape_err = max(abs(rel_before[i][0] - rel_after[i][0]) + abs(rel_before[i][1] - rel_after[i][1])
                for i in range(len(S0)))
check("投影形状不变(相对位置误差<1e-6)", shape_err < 1e-6, "err=%.2e" % shape_err)

# ── 3) 重置 ──
print("\n=== 3) 重置 ===")
res2 = PL.reset_group(scene, cam)
check("reset 成功", res2["success"], res2["message"])
restored = world_coords()
max_err = max(max(abs(restored[i][j] - orig_world[i][j]) for j in range(3)) for i in range(len(orig_world)))
check("顶点完全恢复(<1e-5)", max_err < 1e-5, "max_err=%.2e" % max_err)

# ── 4) 旋转相机 ──
print("\n=== 4) 相机旋转 yaw=20° ===")
PL.lock_group(scene, cam)
S2 = screen_coords()
cam.rotation_euler = (0.0, math.radians(20.0), 0.0)
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
S3 = screen_coords()
drot = [abs(S3[i][0] - S2[i][0]) + abs(S3[i][1] - S2[i][1]) for i in range(len(S2))]
check("旋转后画面不动(最大位移<1e-6)", max(drot) < 1e-6, "max=%.2e" % max(drot))

# ── 5) 变焦 ──
print("\n=== 5) 变焦 lens 50→85 ===")
cam.rotation_euler = (0.0, 0.0, 0.0)
PL.lock_group(scene, cam)
S4 = screen_coords()
cam_data.lens = 85.0
bpy.context.view_layer.update()
PL.parallax_lock_update_handler(scene)
S5 = screen_coords()
dzoom = [abs(S5[i][0] - S4[i][0]) + abs(S5[i][1] - S4[i][1]) for i in range(len(S4))]
check("变焦后画面尺寸不变(最大位移<1e-6)", max(dzoom) < 1e-6, "max=%.2e" % max(dzoom))

# ── 6) 修改器/形态键拒绝 ──
print("\n=== 6) 修改器拦截 ===")
mod = objs[0].modifiers.new("TestMod", "SUBSURF")
res3 = PL.lock_group(scene, cam)
check("带修改器的物体被跳过", len(res3["skipped"]) == 1, "skipped=%d" % len(res3["skipped"]))
objs[0].modifiers.remove(mod)

print("\n" + "=" * 50)
print("PASS %d / FAIL %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("失败项:", FAIL)
print("TEST_DONE")
