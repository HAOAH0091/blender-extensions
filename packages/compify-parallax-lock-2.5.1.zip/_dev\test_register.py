"""验证 compify-parallax-lock 整体加载 + 注册 + handler 挂载。"""
import bpy
import sys
import os
import importlib.util

sys.stdout.reconfigure(encoding="utf-8")

PKG = "compify_parallax_lock_dev"
PKG_DIR = r"F:\desktop\BaiduSyncdisk\addons\compify-parallax-lock"

spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"),
    submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
print("IMPORT_OK")

mod.register()
print("REGISTER_OK")

has_toggle = hasattr(bpy.types, "COMPIFY_OT_parallax_lock_toggle")
has_reset = hasattr(bpy.types, "COMPIFY_OT_parallax_lock_reset")
print("HAS_TOGGLE=%s HAS_RESET=%s" % (has_toggle, has_reset))

plock = sys.modules[PKG + ".compify_parallax_lock"]
h = plock.parallax_lock_update_handler
print("HANDLER_MOUNTED=%s" % (h in bpy.app.handlers.depsgraph_update_post))

# 面板类还在
print("PANEL=%s" % hasattr(bpy.types, "COMPIFY_OT_parallax_lock_toggle"))

mod.unregister()
print("UNREGISTER_OK")
print("HANDLER_REMOVED=%s" % (h not in bpy.app.handlers.depsgraph_update_post))
print("DONE")
