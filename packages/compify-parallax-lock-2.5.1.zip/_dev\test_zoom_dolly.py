"""验证「变焦优先移动相机」：
  ① 顶视图（正交）看相机是否真的移动
  ② 相机视图看构图是否仍然冻结
  ③ 数值：相机位移量 / 构图误差
"""
import bpy
import sys
import os
import math
import importlib.util
import mathutils

sys.stdout.reconfigure(encoding="utf-8")
PKG = "compify_plock_dev"
PKG_DIR = r"F:\desktop\BaiduSyncdisk\addons\compify-parallax-lock"
spec = importlib.util.spec_from_file_location(
    PKG, os.path.join(PKG_DIR, "__init__.py"), submodule_search_locations=[PKG_DIR])
mod = importlib.util.module_from_spec(spec)
sys.modules[PKG] = mod
spec.loader.exec_module(mod)
plock = sys.modules[PKG + ".compify_parallax_lock"]
ng_mod = sys.modules[PKG + ".node_groups"]

scene = bpy.context.scene
for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)

cam_data = bpy.data.cameras.new("Cam")
cam_data.lens = 50.0
cam_data.sensor_width = 36.0
cam = bpy.data.objects.new("Camera", cam_data)
scene.collection.objects.link(cam)
cam.location = (0.0, -6.0, 0.0)
cam.rotation_euler = (math.radians(90), 0, 0)
scene.camera = cam
bpy.context.view_layer.update()

for i, (x, y, z, r) in enumerate([(-5.0, 16.0, 0.0, 1.15), (-2.5, 16.0, 0.0, 1.15),
                                  (0.0, 16.0, 0.0, 1.15), (2.5, 16.0, 0.0, 1.15),
                                  (5.0, 16.0, 0.0, 1.15)]):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r, location=(x, y, z))
    bpy.context.active_object.name = "Ball%d" % i
meshes = [o for o in bpy.data.objects if o.type == "MESH"]
bpy.context.view_layer.update()

W = H = 512
img = bpy.data.images.new("Footage", W, H)
px = [0.0] * (W * H * 4)
for y in range(H):
    for x in range(W):
        i = (y * W + x) * 4
        v = 0.93 if ((x // 32) + (y // 32)) % 2 else 0.05
        R = G = B = v
        d = math.hypot(x - W / 2, y - H / 2)
        if d < 72:
            R, G, B = 0.95, 0.12, 0.10
        elif d < 80:
            R, G, B = 0.98, 0.98, 0.98
        px[i], px[i + 1], px[i + 2], px[i + 3] = R, G, B, 1.0
img.pixels.foreach_set(px)
img.pack()

grp = ng_mod.ensure_camera_project_group(cam, default_aspect=1.0)
mat = bpy.data.materials.new("Proj")
mat.use_nodes = True
nt = mat.node_tree
nt.nodes.clear()
gn = nt.nodes.new("ShaderNodeGroup"); gn.node_tree = grp
tex = nt.nodes.new("ShaderNodeTexImage"); tex.image = img
em = nt.nodes.new("ShaderNodeEmission")
outn = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(gn.outputs["Vector"], tex.inputs["Vector"])
nt.links.new(tex.outputs["Color"], em.inputs["Color"])
nt.links.new(em.outputs["Emission"], outn.inputs["Surface"])
for o in meshes:
    o.data.materials.clear(); o.data.materials.append(mat)
    nm = "UV Adjust | %s | %s" % (o.data.name, cam_data.name)
    if nm not in bpy.data.node_groups:
        bpy.data.node_groups.new(nm, "ShaderNodeTree")

scene.render.image_settings.media_type = "IMAGE"
scene.render.image_settings.file_format = "PNG"
if scene.world is None:
    scene.world = bpy.data.worlds.new("W")
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.03, 0.03, 0.045, 1)
scene.render.engine = "CYCLES"
scene.cycles.samples = 12
scene.cycles.device = "CPU"
OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace\_plock_dolly"
os.makedirs(OUT, exist_ok=True)

# 俯视正交相机（看顶视图）
top_data = bpy.data.cameras.new("TopCam")
top_data.type = "ORTHO"
top_data.ortho_scale = 60.0
top = bpy.data.objects.new("TopCam", top_data)
scene.collection.objects.link(top)
top.location = (0.0, -4.0, 60.0)
top.rotation_euler = (0, 0, 0)
top_data.ortho_scale = 78.0


# 相机的可见替身（渲染时相机对象本身不显示，用锥体代表）
proxy_mesh = bpy.data.meshes.new("CamProxy")
import bmesh
bm = bmesh.new()
bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=4,
                      radius1=0.0, radius2=3.0, depth=9.0)
bm.to_mesh(proxy_mesh); bm.free()
proxy = bpy.data.objects.new("CamProxy", proxy_mesh)
scene.collection.objects.link(proxy)
pm = bpy.data.materials.new("ProxyMat"); pm.use_nodes = True
bsdf = pm.node_tree.nodes["Principled BSDF"]
bsdf.inputs["Base Color"].default_value = (1.0, 0.55, 0.05, 1.0)
bsdf.inputs["Emission Color"].default_value = (1.0, 0.45, 0.0, 1.0)
bsdf.inputs["Emission Strength"].default_value = 2.0
proxy_mesh.materials.append(pm)


def sync_proxy():
    proxy.matrix_world = cam.matrix_world.copy()
    proxy.rotation_euler = cam.rotation_euler
    # 锥体朝 -Z，正好对齐相机朝向
    bpy.context.view_layer.update()


def shot(name, camobj, rx=760, ry=420, proxy_on=False):
    proxy.hide_render = not proxy_on
    scene.camera = camobj
    scene.render.resolution_x, scene.render.resolution_y = rx, ry
    scene.render.filepath = os.path.join(OUT, name + ".png")
    bpy.ops.render.render(write_still=True)
    print("SHOT", name)


def screen_samples():
    vi = plock.get_camera_view_matrix(cam).inverted()
    sx = cam_data.lens / cam_data.sensor_width
    out = []
    for o in meshes:
        n = len(o.data.vertices)
        for idx in (0, n // 2, n - 1):
            cs = vi @ (o.matrix_world @ o.data.vertices[idx].co)
            out.append((cs.x / -cs.z * sx, cs.y / -cs.z * sx))   # 含焦距因子 = 真实屏幕落点
    return out


def maxdiff(a, b):
    return max(max(abs(x[0] - y[0]), abs(x[1] - y[1])) for x, y in zip(a, b))


# ── 1 锁定 + lens 50 ──
cam_data.lens = 50.0; bpy.context.view_layer.update()
r = plock.lock_group(scene, cam)
print("LOCK:", r["success"], r["message"])
loc0 = tuple(cam.location)
S0 = screen_samples()
shot("A_t50_view", cam); sync_proxy(); shot("A_t50_top", top, 420, 760, proxy_on=True)

# ── 2 变焦 85 ──
cam_data.lens = 85.0
bpy.context.view_layer.update()
plock.parallax_lock_update_handler(scene)
bpy.context.view_layer.update()
loc1 = tuple(cam.location)
S1 = screen_samples()
shot("B_t85_view", cam); sync_proxy(); shot("B_t85_top", top, 420, 760, proxy_on=True)

print("\n相机位置: %.4f,%.4f,%.4f  →  %.4f,%.4f,%.4f" % (loc0 + loc1))
print("相机位移量: %.4f" % math.dist(loc0, loc1))
print("理论值 ref(k-1): ref=%.3f k=%.3f → %.4f" %
      (r and float(plock.get_state(scene, cam)["ref_depth"]), 85/50,
       float(plock.get_state(scene, cam)["ref_depth"]) * (85/50 - 1)))
print("构图（屏幕坐标）最大变化: %.8f  %s" %
      (maxdiff(S0, S1), "冻结 ✓" if maxdiff(S0, S1) < 1e-6 else "变了 ✗"))

# ── 3 重置 ──
r2 = plock.reset_group(scene, cam)
bpy.context.view_layer.update()
print("\n重置后相机位置:", tuple(round(v, 4) for v in cam.location))
print("恢复原位:", math.dist(tuple(cam.location), loc0) < 1e-5)
print("DOLLY_DONE", OUT)
