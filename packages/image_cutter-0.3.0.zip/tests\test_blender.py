"""在真 Blender 里跑一遍：加载插件 → 造测试场景 → 生成 → 校验。

    blender --background --factory-startup --python tests/test_blender.py

headless 能测的：模块能不能加载、注册有没有冲突、
算法接进 bpy 之后几何/UV/材质对不对、参数改了会不会重建。
headless 测不了的：视口绘制、鼠标交互（那些得开真窗口）。
"""

import json
import inspect
import math
import os
import sys
import time
import traceback

import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)            # .../addons/image_cutter
ADDONS = os.path.dirname(PKG_DIR)          # .../addons  ← 要让 import image_cutter 成立
for _p in (ADDONS, PKG_DIR, HERE):         # HERE 也要加：fixture.py 在本目录
    if _p not in sys.path:
        sys.path.insert(0, _p)

PASS = []
FAIL = []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %s%s" % ("PASS" if cond else "FAIL", name,
                           ("   " + detail) if detail else ""))


def make_alpha_image(name="ic_test_tex", w=256, h=256):
    """造一张带 alpha 的测试贴图（用共用 fixture：软边五角星 + 洞 + 分离小圆）。"""
    from fixture import make_rgba, to_blender_pixels

    rgba = make_rgba(w, h, soft=True, with_hole=True, with_dot=True)
    rgba[:, :, 0] = 0.85
    rgba[:, :, 1] = 0.35
    rgba[:, :, 2] = 0.55

    img = bpy.data.images.new(name, width=w, height=h, alpha=True)
    # 必须翻转：Blender 的 pixels 是自下而上存的（见 fixture.to_blender_pixels）
    img.pixels.foreach_set(to_blender_pixels(rgba).ravel())
    img.pack()
    return img


def build_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scn = bpy.context.scene

    bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, 0.0))
    plane = bpy.context.active_object
    plane.name = "TestPlane"

    img = make_alpha_image()

    mat = bpy.data.materials.new("TestMat")
    nt = mat.node_tree
    if nt is None:
        mat.use_nodes = True
        nt = mat.node_tree
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.location = (-400, 0)
    out = None
    for n in nt.nodes:
        if n.type == "BSDF_PRINCIPLED":
            out = n
            break
    if out is not None:
        nt.links.new(tex.outputs["Color"], out.inputs["Base Color"])

    plane.data.materials.append(mat)

    bpy.ops.object.select_all(action="DESELECT")
    plane.select_set(True)
    bpy.context.view_layer.objects.active = plane
    return plane, img, mat


print("=" * 74)
print("image_cutter 真机测试（Blender %s）" % bpy.app.version_string)
print("=" * 74)

# --------------------------------------------------------------------------
print("\n[1] 加载插件")
try:
    import image_cutter
    image_cutter.register()
    check("插件注册成功", True)
except Exception as exc:                       # noqa: BLE001
    traceback.print_exc()
    check("插件注册成功", False, str(exc))
    sys.exit(1)

check("Object.image_cutter 已挂上", hasattr(bpy.types.Object, "image_cutter"))
check("面板已注册", hasattr(bpy.types, "IC_PT_main"))

# --------------------------------------------------------------------------
print("\n[1b] 图标名校验（写错会让面板静默少半截，最阴的一类 bug）")

import re  # noqa: E402


def valid_icon_names():
    """从 Blender 自己的 enum 里取合法图标名。"""
    try:
        p = bpy.types.UILayout.bl_rna.functions["label"].parameters["icon"]
        return {i.identifier for i in p.enum_items}
    except Exception:                            # noqa: BLE001
        return set()


def strip_comment(line):
    """去掉行内注释，但别碰引号里的 #。"""
    out = []
    quote = None
    for ch in line:
        if quote:
            out.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "\"'":
            quote = ch
            out.append(ch)
            continue
        if ch == "#":
            break
        out.append(ch)
    return "".join(out)


_icons = valid_icon_names()
check("能拿到 Blender 的图标清单", len(_icons) > 500, "%d 个" % len(_icons))

# 扫插件自己的源码（跳过下划线开头的临时探针脚本）
_src_files = []
for _root, _dirs, _files in os.walk(PKG_DIR):
    _dirs[:] = [d for d in _dirs if d != "__pycache__"]
    for _f in _files:
        if _f.endswith(".py") and not _f.startswith("_"):
            _src_files.append(os.path.join(_root, _f))

_icon_re = re.compile(r"""icon\s*=\s*["']([A-Za-z0-9_]+)["']""")
_bad_icons = []
_used_icons = set()
for _fp in _src_files:
    try:
        _src = open(_fp, encoding="utf-8").read()
    except Exception:                            # noqa: BLE001
        continue
    for _ln, _line in enumerate(_src.splitlines(), 1):
        for _m in _icon_re.finditer(strip_comment(_line)):
            _name = _m.group(1)
            _used_icons.add(_name)
            if _icons and _name not in _icons:
                _bad_icons.append("%s:%d icon=%s"
                                  % (os.path.basename(_fp), _ln, _name))

check("源码里用到的图标名全部合法（本版本）", not _bad_icons,
      ("非法: " + "; ".join(_bad_icons)) if _bad_icons
      else "%d 个图标名都有效" % len(_used_icons))

# 只对「本版本」校验还不够：某个图标可能在 5.2 有、在 4.2~5.0 没有，
# 于是你在 5.2 上测全绿，别的版本上面板照样少半截（真踩过：GP_DRAW_STROKE）。
# 所以再对一遍「跨版本公共图标集」。
_compat_path = os.path.join(HERE, "icon_compat.json")
_compat = set()
if os.path.exists(_compat_path):
    try:
        _compat = set(json.load(open(_compat_path, encoding="utf-8"))["icons"])
    except Exception as exc:                     # noqa: BLE001
        print("    读 icon_compat.json 失败：%s" % exc)
check("跨版本公共图标集已就位", len(_compat) > 300, "%d 个" % len(_compat))

if _compat:
    _not_compat = sorted(i for i in _used_icons if i not in _compat)
    check("图标名在所有支持版本里都存在", not _not_compat,
          ("跨版本不存在: " + ", ".join(_not_compat)) if _not_compat
          else "%d 个都跨版本可用" % len(_used_icons))
_op_names = ("generate", "rebuild", "fix_alpha",
             "select_source", "pen_draw", "pen_clear",
             "pen_cycle_mode", "pen_toggle", "pen_delete")
_bad = []
for _n in _op_names:
    try:
        getattr(bpy.ops.image_cutter, _n).get_rna_type()
    except Exception as _e:                    # noqa: BLE001
        _bad.append("%s(%s)" % (_n, _e))
check("九个操作符全部注册到 RNA", not _bad, "; ".join(_bad))

from image_cutter.ic_ui import pen as ic_pen              # noqa: E402
from image_cutter.ic_ui import props as ic_props         # noqa: E402
check("常驻引导路径绘制层已注册",
      ic_pen._OVERLAY_HANDLE is not None)
check("引导显示开关已注册",
      "guide_show" in ic_props.IC_Settings.bl_rna.properties)
_hd, _ht = ic_pen._closest_on_screen_polyline(
    [(0.0, 0.0), (10.0, 0.0)], 5.0, 3.0
)
check("曲线命中测试给出正确投影",
      abs(_hd - 3.0) < 1e-9 and abs(_ht - 0.5) < 1e-9,
      "d=%.3f t=%.3f" % (_hd, _ht))
_fake_stroke = type("S", (), {"closed": True, "mode": "auto"})()
_fake_settings = type("P", (), {"guide_mode": "carve"})()
check("跟随默认的路径按实际默认模式着色",
      ic_pen._overlay_color(_fake_settings, _fake_stroke)
      == (0.95, 0.38, 0.32, 0.92))
_p0 = (10.0, 20.0, -1.0, -2.0, 3.0, 4.0)
_sym = ic_pen._drag_anchor(_p0, "out", 5.0, 6.0, mirror=True)
_asym = ic_pen._drag_anchor(_p0, "out", 5.0, 6.0, mirror=False)
check("普通拖柄两侧对称", _sym[2:4] == (-5.0, -6.0) and _sym[4:6] == (5.0, 6.0))
check("Alt 拖柄只改被拖一侧", _asym[2:4] == (-1.0, -2.0) and _asym[4:6] == (5.0, 6.0))
_moved = ic_pen._drag_anchor(_p0, "anchor", 5.0, 6.0)
check("拖锚点只移动位置", _moved[:2] == (15.0, 26.0) and _moved[2:] == _p0[2:])
check("点首锚闭合的判定正确",
      ic_pen._closes_on_anchor_click(False, 3, "anchor", 0)
      and not ic_pen._closes_on_anchor_click(True, 3, "anchor", 0)
      and not ic_pen._closes_on_anchor_click(False, 2, "anchor", 0))
check("路径模式按默认→补→挖循环",
      ic_pen._next_mode("auto") == "add"
      and ic_pen._next_mode("add") == "carve"
      and ic_pen._next_mode("carve") == "auto")
_fake_edit_hint = type("E", (), {
    "edit_index": 2, "closed": True, "mode": "carve",
})()
_edit_hint = ic_pen.IC_OT_PenDraw._hint_text(_fake_edit_hint)
check("编辑提示常显当前路径、模式与撤销方式",
      "编辑 3" in _edit_hint and "闭合" in _edit_hint
      and "挖掉" in _edit_hint and "Ctrl+Z" in _edit_hint
      and "Ctrl+Shift+Z" in _edit_hint and "重做" in _edit_hint
      and "点空白加锚点" in _edit_hint
      and "方向键微调" in _edit_hint and "Tab 切锚点" in _edit_hint
      and "右键/回车保存" in _edit_hint
      and "Esc 放弃" in _edit_hint,
      _edit_hint)
_bx, _by = ic_pen._bezier_xy(
    (0.0, 0.0, 0.0, 0.0, 10.0, 0.0),
    (20.0, 0.0, -10.0, 0.0, 0.0, 0.0),
    0.5,
)
check("插点标记能算出曲线上的位置",
      abs(_bx - 10.0) < 1e-9 and abs(_by) < 1e-9,
      "x=%.3f y=%.3f" % (_bx, _by))


class _FakeHover:
    dragging = False
    _cursor_shape = "CROSSHAIR"

    def pixel_at(self, context, event):
        return (12.0, 34.0)

    def _cursor(self, context, shape):
        pass

    def _hit_test(self, context, event):
        return "anchor", 1

    def _segment_hit(self, context, event):
        return 0, 0.5


_fake_hover = _FakeHover()
ic_pen.IC_OT_PenDraw._update_hover(_fake_hover, None, None)
check("悬停优先命中锚点而不是曲线",
      _fake_hover.hover_hit == ("anchor", 1)
      and _fake_hover.hover_seg == (-1, 0.0),
      "%s %s" % (_fake_hover.hover_hit, _fake_hover.hover_seg))
_FakeHover._hit_test = lambda self, context, event: (None, -1)
ic_pen.IC_OT_PenDraw._update_hover(_fake_hover, None, None)
check("没有锚点时可命中曲线段插点",
      _fake_hover.hover_hit == (None, -1)
      and _fake_hover.hover_seg == (0, 0.5))
_seg_calls = []
_fake_seg = type("G", (), {
    "points": [
        (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        (10.0, 0.0, 0.0, 0.0, 0.0, 0.0),
    ],
    "closed": False,
    "_segment_cache_key": None,
    "_segment_cache": {},
    "curve_screen": lambda self, context, a, b: (
        _seg_calls.append((a, b)) or [(0.0, 0.0), (10.0, 0.0)]
    ),
})()
ic_pen.IC_OT_PenDraw.segment_screen(_fake_seg, None, 0)
ic_pen.IC_OT_PenDraw.segment_screen(_fake_seg, None, 0)
check("钢笔悬停复用曲线屏幕投影", len(_seg_calls) == 1, "%d 次" % len(_seg_calls))
_fake_seg.points[1] = (20.0, 0.0, 0.0, 0.0, 0.0, 0.0)
ic_pen.IC_OT_PenDraw.segment_screen(_fake_seg, None, 0)
check("锚点变化后曲线投影缓存失效", len(_seg_calls) == 2,
      "%d 次" % len(_seg_calls))
_draw_src = inspect.getsource(ic_pen._draw_cb)
check("选中与悬停状态都有可见高亮分支",
      'getattr(op, "hover_hit"' in _draw_src
      and 'getattr(op, "hover_seg"' in _draw_src
      and "point_size=15.0" in _draw_src)
_modal_src = inspect.getsource(ic_pen.IC_OT_PenDraw.modal)
check("钢笔支持方向键微调与 Tab 切换锚点",
      '"LEFT_ARROW"' in _modal_src and '"TAB"' in _modal_src
      and "_remember(keep_nudge=True)" in _modal_src
      and "_schedule_nudge_sync" in _modal_src)
_nudge_src = inspect.getsource(ic_pen.IC_OT_PenDraw._schedule_nudge_sync)
check("方向键连按会合并网格重建",
      "first_interval=0.16" in _nudge_src
      and "interactive=True" in _nudge_src)


class _FakeNudge:
    _nudge_timer = None
    _cancel_nudge_timer = ic_pen.IC_OT_PenDraw._cancel_nudge_timer

    def _live_sync(self, context, interactive=False):
        return False


_fake_nudge = _FakeNudge()
ic_pen.IC_OT_PenDraw._schedule_nudge_sync(_fake_nudge, None)
_first_timer = _fake_nudge._nudge_timer
ic_pen.IC_OT_PenDraw._schedule_nudge_sync(_fake_nudge, None)
_second_timer = _fake_nudge._nudge_timer
check("方向键连按不会累积多个定时器",
      callable(_first_timer) and callable(_second_timer)
      and not bpy.app.timers.is_registered(_first_timer)
      and bpy.app.timers.is_registered(_second_timer))
ic_pen.IC_OT_PenDraw._cancel_nudge_timer(_fake_nudge)
check("方向键定时器能被正确取消",
      _fake_nudge._nudge_timer is None
      and not bpy.app.timers.is_registered(_second_timer))
_panel_src = open(
    os.path.join(PKG_DIR, "ic_ui", "panels.py"), encoding="utf-8"
).read()
check("路径列表的编辑/新建按钮有文字，不靠猜图标",
      'text="编辑"' in _panel_src and 'text="画路径"' in _panel_src)
check("面板直接解释闭合/开放的语义",
      "闭合圈内补/挖 · 开放沿线切" in _panel_src)
_clear_invoke_src = inspect.getsource(ic_pen.IC_OT_PenClear.invoke)
check("清空全部路径前会弹确认", "invoke_confirm" in _clear_invoke_src)
_fake_disabled = type("S", (), {"closed": True, "mode": "add",
                                "enabled": False})()
check("停用路径在叠加层里变灰",
      ic_pen._overlay_color(_fake_settings, _fake_disabled)
      == (0.48, 0.50, 0.55, 0.34))
_fake_pen = type("P", (), {
    "points": [_p0],
    "closed": False,
    "selected": 0,
    "mode": "auto",
    "history": [],
    "redo": [],
    "pending_before": None,
    "_nudge_timer": None,
    "_cancel_nudge_timer": lambda self: None,
    "report": lambda self, level, msg: None,
    "_push_history": lambda self, state: (
        self.history.append(state), self.redo.clear()
    ),
    "_restore": lambda self, state: (
        setattr(self, "points", state[0]),
        setattr(self, "closed", state[1]),
        setattr(self, "selected", state[2]),
        setattr(self, "mode", state[3]),
    ),
    "_live_sync": lambda self, context: False,
})()
ic_pen.IC_OT_PenDraw._begin_action(_fake_pen)
_fake_pen.points.append((20.0, 30.0, 0.0, 0.0, 0.0, 0.0))
ic_pen.IC_OT_PenDraw._commit_action(_fake_pen)
ic_pen.IC_OT_PenDraw._undo(_fake_pen)
check("钢笔模态内可撤销上一步",
      len(_fake_pen.points) == 1 and not _fake_pen.history)

# --------------------------------------------------------------------------
print("\n[2] 造场景")
plane, img, mat = build_scene()
check("测试平面已建", plane.name == "TestPlane")
check("测试贴图有 alpha", img.size[0] == 256 and img.depth in (32, 0))

from image_cutter.ic_bpy import imgio                  # noqa: E402
found, _node, _m = imgio.find_image_slot(plane)
check("能从材质里找到图片纹理", found is img)

alpha, info = imgio.read_alpha(img)
check("读到 alpha 通道", alpha.shape == (256, 256), str(alpha.shape))
check("识别出有透明区", info["has_alpha"] is True,
      "min=%.3f max=%.3f" % (info["alpha_min"], info["alpha_max"]))

# --------------------------------------------------------------------------
print("\n[3] 生成网格")
try:
    res = bpy.ops.image_cutter.generate()
    ok = "FINISHED" in res
except Exception as exc:                       # noqa: BLE001
    traceback.print_exc()
    ok = False
    print(exc)

check("生成操作返回成功", ok, str(res) if ok else "")

cut = bpy.data.objects.get("TestPlane_cutout")
check("新对象已建出来", cut is not None)
if cut is None:
    print("\n生成失败，后续跳过")
    print("通过 %d / 失败 %d" % (len(PASS), len(FAIL)))
    sys.exit(1)

me = cut.data
check("网格有顶点", len(me.vertices) > 0, "%d 个" % len(me.vertices))
check("网格有面", len(me.polygons) > 0, "%d 个" % len(me.polygons))
check("UV 层已建", len(me.uv_layers) > 0,
      me.uv_layers[0].name if len(me.uv_layers) else "-")
check("材质已挂", len(me.materials) > 0 and me.materials[0] is mat)
check("打了本插件标记", bool(cut.get("ic_generated")))
check("源平面已记录", cut.image_cutter.source_obj is plane)
check("源平面没被动过", len(plane.data.vertices) == 4,
      "源平面顶点 %d" % len(plane.data.vertices))

s = cut.image_cutter
print("     面 %d / 点 %d / 轮廓 %d 圈 / %s / A %.0fms B %.0fms"
      % (s.stat_faces, s.stat_points, s.stat_rings, s.stat_edge,
         s.stat_ms_a, s.stat_ms_b))
check("状态回显有面数", s.stat_faces > 0, str(s.stat_faces))
check("软边图被识别为 soft", s.stat_edge == "soft", s.stat_edge)
check("记录了原图宽高（引导叠加层要用）",
      s.stat_img_w == 256 and s.stat_img_h == 256,
      "%dx%d" % (s.stat_img_w, s.stat_img_h))
check("引导路径默认在视口显示", bool(s.guide_show))

# --------------------------------------------------------------------------
print("\n[4] 几何正确性")

uv_layer = me.uv_layers[0].data
uvs = np.empty(len(uv_layer) * 2, dtype=np.float32)
uv_layer.foreach_get("uv", uvs)
uvs = uvs.reshape(-1, 2)
check("UV 落在 0..1 内",
      bool(uvs.min() >= -1e-4 and uvs.max() <= 1.0 + 1e-4),
      "范围 %.3f .. %.3f" % (uvs.min(), uvs.max()))

# 网格该和源平面一样大（本地包围盒 2x2）
co = np.empty(len(me.vertices) * 3, dtype=np.float32)
me.vertices.foreach_get("co", co)
co = co.reshape(-1, 3)
sx = co[:, 0].max() - co[:, 0].min()
sy = co[:, 1].max() - co[:, 1].min()
# 网格只盖住形状那一块，不会铺满整张平面 —— 所以这里查的是
# 「落在平面范围内、且不是退化的一小块」
check("网格落在源平面范围内且不退化",
      0.3 < sx <= 2.05 and 0.3 < sy <= 2.05,
      "%.2f x %.2f" % (sx, sy))
check("网格是平的（z 全 0）", bool(np.allclose(co[:, 2], 0.0, atol=1e-6)))

# 法线朝 +Z（翻转绕向有没有做对）
nrm = np.empty(len(me.polygons) * 3, dtype=np.float32)
me.polygons.foreach_get("normal", nrm)
nrm = nrm.reshape(-1, 3)
up = (nrm[:, 2] > 0.9).sum()
check("面法线朝 +Z（绕向没反）", up == len(me.polygons),
      "%d/%d" % (up, len(me.polygons)))

# 洞填上了没：星形中心应被网格盖住
cx_px, cy_px = 256 * 0.40, 256 * 0.44
cx = (cx_px / 256.0 - 0.5) * 2.0
cy = (1.0 - cy_px / 256.0 - 0.5) * 2.0


def point_in_tri3(p, a, b, c):
    d1 = (p[0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (p[1] - b[1])
    d2 = (p[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (p[1] - c[1])
    d3 = (p[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (p[1] - a[1])
    neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (neg and pos)


covered = False
for poly in me.polygons:
    vi = list(poly.vertices)
    if len(vi) == 3:
        a = co[vi[0]]
        b = co[vi[1]]
        c = co[vi[2]]
        if point_in_tri3((cx, cy), a, b, c):
            covered = True
            break
check("★ 圆的中心被网格盖住（中心不留洞）", covered)

# --------------------------------------------------------------------------
print("\n[5] 参数改了会重建")

# headless 里没有事件循环，bpy.app.timers 不会自己跑。
# 所以这里分两段测：① 回调有没有把对象排进队列 ② 队列执行后网格有没有变。
# ② 才是「重建逻辑对不对」，① 是「参数改动的信号有没有接上」。

from image_cutter.ic_ui import ops as ic_ops        # noqa: E402

# 首次生成时 stat_img_long 还是 0，如果 params 在写回图片长边之前就计算，
# 同一套参数在“首次生成”和“再点一次重建”之间会换 spacing（大图甚至换后端）。
first_faces = len(cut.data.polygons)
same_ok, same_msg = ic_ops.rebuild_object(cut, bpy.context, force=True)
check("同一参数重建后面数不变（首次/后续一致）",
      same_ok and len(cut.data.polygons) == first_faces,
      "%d → %d  %s" % (first_faces, len(cut.data.polygons), same_msg))

before_faces = len(me.polygons)
s.density = 0.95                                    # 触发 update 回调
bpy.context.view_layer.update()

queued = cut.name in ic_ops._PENDING
timer_on = False
try:
    timer_on = bpy.app.timers.is_registered(ic_ops._flush_interactive)
except Exception:                                   # noqa: BLE001
    pass
check("改参数后排进了重建队列", queued or timer_on,
      "queued=%s timer=%s" % (queued, timer_on))

# 模拟「还在拖」：先出粗预览，再停手出精确网格。
ic_ops._LAST_TOUCH[cut.name] = time.monotonic()
ic_ops._flush_interactive()
check("拖动中先出交互预览", s.stat_preview,
      "preview_faces=%d" % len(cut.data.polygons))

ic_ops._flush_pending()
after_faces = len(cut.data.polygons)
check("停手后恢复精确网格", not s.stat_preview, "%d 面" % after_faces)
check("执行后三角形变多", after_faces > before_faces,
      "%d → %d" % (before_faces, after_faces))

s.density = 0.2
ic_ops._flush_pending()
thin_faces = len(cut.data.polygons)
check("调疏后三角形变少", thin_faces < after_faces,
      "%d → %d" % (after_faces, thin_faces))

s.density = 0.55
ic_ops._flush_pending()


def _bbox_area(me):
    n = len(me.vertices)
    cc = np.empty(n * 3, dtype=np.float32)
    me.vertices.foreach_get("co", cc)
    cc = cc.reshape(-1, 3)
    return ((cc[:, 0].max() - cc[:, 0].min())
            * (cc[:, 1].max() - cc[:, 1].min()))


# ⚠️ 用「顶点数」判重建太粗：阈值改一点点、形状只缩了一些时，
#    抽稀后顶点数可能一模一样。改用包围盒面积这种连续量。
base_area = _bbox_area(cut.data)
s.threshold = 0.95
ic_ops._flush_pending()
new_area = _bbox_area(cut.data)
check("改阈值也触发重建", abs(new_area - base_area) > 1e-4,
      "包围盒面积 %.4f → %.4f" % (base_area, new_area))

# --------------------------------------------------------------------------
print("\n[5b] 交互预览正确性")

# 阈值变化时即使阶段 A 很快（小图不解码），预览也必须写回新几何，
# 不能只返回旧网格。
ic_ops._clear_preview_state(cut.name)
_exact_v = len(cut.data.vertices)
_exact_area = _bbox_area(cut.data)
s.threshold = 0.62
s.density = 0.72
_ok_prev, _msg_prev = ic_ops.rebuild_object(
    cut, bpy.context, preview=True
)
check("阈值预览成功并标记为预览", _ok_prev and s.stat_preview, _msg_prev)
check("阈值预览确实更新了几何",
      len(cut.data.vertices) != _exact_v
      or abs(_bbox_area(cut.data) - _exact_area) > 1e-5,
      "顶点 %d → %d，包围盒 %.4f → %.4f"
      % (_exact_v, len(cut.data.vertices),
         _exact_area, _bbox_area(cut.data)))

# 同一粗档内的连续密度变化应复用刚写好的预览网格。
_first_prev_faces = len(cut.data.polygons)
s.density = 0.721
_ok_reuse, _msg_reuse = ic_ops.rebuild_object(
    cut, bpy.context, preview=True
)
check("连续密度落在同一粗档时复用预览网格",
      _ok_reuse and "复用当前粗网格" in _msg_reuse,
      _msg_reuse)
check("复用预览不会重复改写网格",
      len(cut.data.polygons) == _first_prev_faces,
      "%d → %d" % (_first_prev_faces, len(cut.data.polygons)))

# 预览帧不能把「完整重建耗时」污染成粗网格耗时，否则自适应档位、
# 面板耗时和下一次缩放都会越来越偏。
_full_a = float(s.stat_ms_a_full)
_full_b = float(s.stat_ms_b_full)
s.density = 0.73
_ok_stat, _msg_stat = ic_ops.rebuild_object(
    cut, bpy.context, preview=True
)
check("预览保留完整重建耗时样本",
      _ok_stat and s.stat_ms_a_full == _full_a
      and s.stat_ms_b_full == _full_b,
      "A %.1f→%.1f  B %.1f→%.1f"
      % (_full_a, s.stat_ms_a_full, _full_b, s.stat_ms_b_full))

s.threshold = 0.5
s.density = 0.55
ic_ops._flush_pending()

# --------------------------------------------------------------------------
print("\n[6] 引导（钢笔画路径）")

n_before = len(cut.data.vertices)

st = s.strokes.add()
st.closed = True
st.mode = "add"
for (px, py) in [(20, 200), (110, 200), (110, 245), (20, 245)]:
    p = st.points.add()
    p.x = px
    p.y = py
s.guide_enabled = True
# 全局默认改成挖，但这一条明确覆盖成补：单条模式必须胜过全局默认。
s.guide_mode = "carve"
s.guide_ver = int(s.guide_ver) + 1

from image_cutter.ic_core import guide as guide_mod  # noqa: E402
st.enabled = False
check("停用单条路径后不参与引导",
      len(ic_ops.collect_strokes(s)) == 0
      and ic_ops.build_guide_mask(s, 256, 256) is None)
st.enabled = True
gm = ic_ops.build_guide_mask(s, 256, 256)
check("引导掩膜已生成", gm is not None and int((gm > 0).sum()) > 100,
      "%d 个像素" % (int((gm > 0).sum()) if gm is not None else 0))
_collected = ic_ops.collect_strokes(s)
check("单条路径模式覆盖全局默认",
      len(_collected) == 1 and _collected[0][2] == 1,
      "%s" % ([x[2] for x in _collected],))
check("引导点串采样正确", len(ic_ops.collect_strokes(s)) == 1)

ok2, msg2 = ic_ops.rebuild_object(cut, bpy.context, force=True)
check("带引导重建成功", ok2, msg2)
check("引导改变了结果", len(cut.data.vertices) != n_before,
      "%d → %d" % (n_before, len(cut.data.vertices)))

s.strokes.clear()
s.guide_ver = int(s.guide_ver) + 1
ok3, msg3 = ic_ops.rebuild_object(cut, bpy.context, force=True)
check("清空引导后能回到自动结果", ok3, msg3)

# 覆盖已有路径时：闭合状态要按调用方给的值保存，模式不能被重置。
# 这里直接测存储层，避免依赖视口模态事件。
s.strokes.clear()
_pts = [(10.0, 10.0, 0.0, 0.0, 0.0, 0.0),
        (80.0, 20.0, 0.0, 0.0, 0.0, 0.0),
        (40.0, 70.0, 0.0, 0.0, 0.0, 0.0)]
_st0 = ic_pen._store_stroke(s, _pts, True)
_st0.mode = "carve"
_st1 = ic_pen._store_stroke(s, _pts, True, 0)
check("编辑保存闭合路径不会把它变成开放",
      bool(_st1.closed) and len(s.strokes) == 1)
check("编辑保存保留单条模式", _st1.mode == "carve", _st1.mode)
_st_mode = ic_pen._store_stroke(s, _pts, True, 0, mode="add")
check("编辑保存可显式更新单条模式", _st_mode.mode == "add", _st_mode.mode)
_st_mode = ic_pen._store_stroke(s, _pts, True, 0, mode="carve")
_st2 = ic_pen._store_stroke(s, _pts, False, 0)
check("显式保存开放状态有效", not bool(_st2.closed))

# 编辑路径时每次拖放都会立即落盘并刷新网格；Esc 再恢复进入编辑前的快照。
_ver_before = int(s.guide_ver)
_same = ic_pen._persist_edit(s, 0, _pts, False, "carve")
check("路径未变化时不重复标脏",
      not _same and int(s.guide_ver) == _ver_before,
      "%d → %d" % (_ver_before, int(s.guide_ver)))
_pts_moved = list(_pts)
_pts_moved[0] = (_pts_moved[0][0] + 7.0, _pts_moved[0][1], 0.0, 0.0, 0.0, 0.0)
_changed = ic_pen._persist_edit(s, 0, _pts_moved, False, "carve")
check("拖完锚点立即写回路径并标脏",
      _changed and int(s.guide_ver) == _ver_before + 1
      and abs(float(s.strokes[0].points[0].x) - _pts_moved[0][0]) < 1e-9,
      "ver %d → %d" % (_ver_before, int(s.guide_ver)))
check("写回后的路径可判定为已同步",
      ic_pen._stroke_matches(s, 0, _pts_moved, False, "carve"))
_fake_edit = type("E", (), {
    "target": cut,
    "edit_index": 0,
    "original_edit": (list(_pts), False, "carve"),
})()
_restored = ic_pen.IC_OT_PenDraw._restore_original(_fake_edit, bpy.context)
check("Esc 恢复编辑前路径",
      _restored
      and ic_pen._stroke_matches(s, 0, _pts, False, "carve")
      and abs(float(s.strokes[0].points[0].x) - _pts[0][0]) < 1e-9)
ic_ops._flush_pending()

# 全部挖掉 → 没有轮廓：必须返回失败，并把旧网格清空；否则面板说没轮廓、
# 视口里却还留着上一次的网格，用户会以为 carve 没生效。
s.strokes.clear()
s.guide_mode = "carve"
st = s.strokes.add()
st.closed = True
for (px, py) in [(-10, -10), (266, -10), (266, 266), (-10, 266)]:
    p = st.points.add()
    p.x = px
    p.y = py
s.guide_ver = int(s.guide_ver) + 1
ok_empty, msg_empty = ic_ops.rebuild_object(cut, bpy.context, force=True)
check("全部挖掉会失败并清空旧网格",
      (not ok_empty) and len(cut.data.polygons) == 0, msg_empty)

# --------------------------------------------------------------------------
print("\n[7] 收尾")
check("材质 alpha 已接上",
      any(ln.to_socket.name == "Alpha" and ln.to_node.type == "BSDF_PRINCIPLED"
          for ln in mat.node_tree.links))

print("\n" + "=" * 74)
print("通过 %d / 失败 %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("失败项：")
    for f in FAIL:
        print("  x", f)
    sys.exit(1)
print("全部通过 [OK]")
