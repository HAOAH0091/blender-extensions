"""侧栏面板。"""

import bpy

from ..ic_bpy import imgio as _imgio
from ..ic_core import triangulate as tri_mod
from .props import expand_limit


_ALPHA_STATUS = {}
_ALPHA_STATUS_MAX = 16


def _alpha_status(img):
    """图片的 alpha 状态，按图片指纹 + dirty 标记缓存。

    面板 draw() 很频繁，不能每次重绘都读整张 RGBA；4K 图一次就要分配
    约 130MB 的临时 float32 缓冲。图片被改过（is_dirty）时才重新读。
    返回 "ok" / "opaque" / "error"。
    """
    try:
        key = (_imgio.image_key(img), bool(getattr(img, "is_dirty", False)))
    except Exception:
        key = (id(img), False)
    hit = _ALPHA_STATUS.get(key)
    if hit is not None:
        return hit

    try:
        _alpha, info = _imgio.read_alpha(img)
        status = "ok" if info.get("has_alpha") else "opaque"
    except Exception:
        status = "error"

    _ALPHA_STATUS[key] = status
    while len(_ALPHA_STATUS) > _ALPHA_STATUS_MAX:
        _ALPHA_STATUS.pop(next(iter(_ALPHA_STATUS)))
    return status


def _active_settings(context):
    obj = context.active_object
    if obj is None or obj.type != "MESH":
        return None, None
    return obj, obj.image_cutter


def _fmt_count(n):
    """1234 → '1.2k'，让面板上的数字一眼能读。"""
    if n >= 1000000:
        return "%.1fM" % (n / 1000000.0)
    if n >= 1000:
        return "%.1fk" % (n / 1000.0)
    return "%d" % n


def _estimate_faces(s):
    """按「面积 / 单个三角形面积」粗估面数，并用周长兜一个下限。

    为什么不直接拿上次的面数：用户正要改密度，上次的数字是旧参数的结果，
    显示它等于没提示。这里用形状面积（阶段 A 已知）+ 目标边长推——
    错缝排布的三角形面积约等于 spacing²×0.43（正三角），数量级够准。

    【为什么要加周长那一项 —— 细长形状会低估 200 倍】

    面积公式假设「每个三角形都接近正三角形」。但**宽度不到 2×spacing 的
    细长形状**里，interior_points 根本撒不进内部点，Delaunay 只能在
    「两排几乎重合的边界加密点」之间拉出细长条，单个三角形面积远小于
    spacing²×0.43。

    审查实测（真实跑出来的）：
        1px 横线 2800 长：面积估 27 面 → 实际 5600 面（**207 倍**）
        1px 竖线 1800 高：估 17 → 实际 3600（212 倍）
        3px 宽横条：估 69 → 实际 408（5.9 倍）

    这正是这个提示要防的事（"拖到头才发现太重"），低估 200 倍等于没提示。

    修法：细长形状的面数大致由「边界加密点」决定 ——
    边界按 spacing×0.9 加密，所以面数下限约为 周长/加密步长 × 2
    （两排点各拉一遍三角形）。取两个估算的较大值，两头都不至于离谱。
    """
    try:
        area_px = getattr(s, "stat_area", 0.0)
        perim_px = getattr(s, "stat_perimeter", 0.0)
        spacing = float(s.spacing())
    except Exception:
        return 0
    if spacing <= 1e-6:
        return 0

    by_area = 0.0
    per_tri = spacing * spacing * 0.43
    if area_px and per_tri > 1e-9:
        by_area = area_px / per_tri

    # 细长形状的下限：**格子模式下，细条的面数由周长决定**
    #
    # 【2026-10-21 换了网格算法，这里的系数必须跟着改】
    #
    # 旧的 Delaunay 版本：细条里 interior_points 撒不进内部点，
    # Delaunay 只能在「两排几乎重合的边界加密点」之间拉细长条，
    # 所以面数 ≈ (周长/加密步长)×2（两排各拉一遍）。
    #
    # 现在的格子版本没有「两排点」这回事：细条上就一排格点，
    # 面数 ≈ 周长 / spacing × 0.9。实测（spacing=15.29，300×2000 横条）：
    #     宽 5px  → 周长/spacing×0.9 = 236，实际 236   ✓
    #     宽 8px  → 236，实际 236                       ✓
    #     宽 16px → 237，实际 265                       ✓（面积项接管）
    #     宽 40px → 240，实际 777（面积项 786 接管）     ✓
    # 块状/圆形（by_area 主导，实测误差都在 0.96~0.99）：
    #     100×100 实际 97 / 估 98    400×400 实际 1551 / 估 1588
    #     圆 r60 实际 107 / 估 112   圆 r350 实际 3777 / 估 3823
    by_perim = 0.0
    if perim_px > 1e-9:
        by_perim = (perim_px / max(spacing, 1e-6)) * 0.9

    est = max(by_area, by_perim)

    # 【1~3px 的极细条仍会低估，这是已知的、可接受的偏差】
    #
    # 格子模式下实测（spacing=15.29，300×2000 横条）：
    #     宽 1px → 实际  44 面，估 236（高估 5.4 倍）
    #     宽 2px → 实际  91 面，估 236（高估 2.6 倍）
    #     宽 3px → 实际 180 面，估 236（高估 1.3 倍）
    #     宽 5px 以上 → 误差 ≤ 1.0 倍
    # 越窄越少（因为格子点落不进去），公式算的是"周长能排多少格点"，
    # 是上限。方向是**高估**（提示"可能很重"），比低估安全。
    #
    # 旧的 Delaunay 版本在 1px 上是低估 207 倍，现在换成高估 5 倍 ——
    # 从"让人拖到头才发现重"变成"稍微保守"，这个方向是对的。
    return int(est) if est > 0 else 0


class IC_PT_Main(bpy.types.Panel):
    bl_label = "图片抠图网格"
    bl_idname = "IC_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "抠图"

    def draw(self, context):
        """⚠️ 包一层：draw() 里抛异常，Blender 会**静默截断** ——
        出错那一行之后的控件全都不画，而且不报错、不留痕。
        （真踩过：一个图标名写错，把「手绘引导」整块吃掉了，查了好几轮。）

        所以这里把真实绘制放进 _draw_impl，出异常时画一个**红框**。
        宁可难看，也不能让内容凭空消失。
        """
        try:
            self._draw_impl(context)
        except Exception as exc:                     # noqa: BLE001
            import traceback
            traceback.print_exc()
            box = self.layout.box()
            box.alert = True
            box.label(text="面板绘制出错（请看系统控制台）", icon="ERROR")
            box.label(text=str(exc)[:120])

    def _draw_impl(self, context):
        layout = self.layout
        obj, s = _active_settings(context)

        if obj is None:
            box = layout.box()
            box.label(text="先选中一个贴了图的平面", icon="INFO")
            box.label(text="材质里要有「图片纹理」节点")
            return

        is_generated = bool(obj.get("ic_generated"))

        if not is_generated:
            # 首次使用：别只丢个按钮就完事。先查清「现在到底缺什么」，
            # 缺什么就直说什么 —— 用户点下去才报错是最差的体验。
            img, _node, _mat = _imgio.find_image_slot(obj)
            status = _alpha_status(img) if img is not None else "missing"

            box = layout.box()
            box.label(text="当前选中：%s" % obj.name, icon="MESH_DATA")

            # 【提示压成一行一条（2026-10-22 精简）】
            # 原来每条提示都摊成 2~3 行，看着像说明书。留「缺什么」+「怎么补」
            # 两个信息点就够，括号里带出原因。
            if img is None:
                # 缺图片纹理节点 —— 这是最常见的卡点
                box.alert = True
                box.label(text="材质里没有「图片纹理」节点", icon="ERROR")
                # 中英混排按「一个英文≈半个中文字」折算，这条原始写法
                # 「新建材质 → 加 Image Texture → 指定图片」约 22 宽，会截断
                box.label(text="新建材质，加 Image Texture 节点")
                return

            if status == "error":
                box.alert = True
                box.label(text="读取贴图失败", icon="ERROR")
                box.label(text="检查图片是否已加载 / 路径是否有效")
                return

            if status == "opaque":
                box.alert = True
                box.label(text="这张图没有透明区", icon="ERROR")
                box.label(text="纯 RGB 图抠不出轮廓（要 alpha）")
                return

            # 一切就绪，直接给按钮
            step = layout.box()
            step.label(text="下一步：点这里生成", icon="RIGHTARROW")
            col = step.column()
            col.scale_y = 1.6
            col.operator("image_cutter.generate", icon="MOD_OPACITY")
            return

        # ---------- 已是生成物：显示参数 ----------
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.operator("image_cutter.rebuild", icon="FILE_REFRESH")

        src = s.source_obj
        box = layout.box()
        box.label(text="来源", icon="IMAGE_DATA")
        if src is not None and src.name in bpy.data.objects:
            r = box.row()
            r.label(text="  %s" % src.name)
            r.operator("image_cutter.select_source", text="", icon="RESTRICT_SELECT_OFF")
        else:
            lost = (s.source_name or "").strip()
            box.label(text="  源平面已丢失：%s" % lost if lost else "  源平面已丢失",
                      icon="ERROR")

        if s.last_error:
            err = layout.box()
            err.alert = True
            err.label(text=s.last_error, icon="ERROR")

        # ---- 形状识别 ----
        col = layout.column(align=True)
        col.label(text="形状识别", icon="MOD_OPACITY")
        col.prop(s, "threshold", slider=True)
        # 【提示方向反过来了（2026-10-22 精简）】
        # 原来在「软边图」上提示"边缘有渐变，调阈值能改胖瘦" —— 但软边图
        # 调阈值本来就有反应，不用告诉；真正会踩坑的是**硬边图**（alpha 只有
        # 0/1，比如抠好的 PNG、像素画），阈值落哪儿结果都一样，用户拖半天
        # 没反应会以为插件坏了。
        # 所以只在硬边时提示一句，软边图不占地方。
        # stat_edge_ratio = 轮廓附近 alpha 落在中间地带的比例，接近 0 就是纯硬边。
        if s.stat_edge_ratio < 0.02 and s.stat_rings > 0:
            t = col.row()
            t.enabled = False
            t.label(text="硬边图：阈值基本不影响结果", icon="INFO")

        # ---- 轮廓 ----
        col = layout.column(align=True)
        col.label(text="轮廓", icon="CURVE_BEZCURVE")
        col.prop(s, "expand", slider=True)
        # 【「轮廓容差」滑块已移除（2026-10-22）】
        # 用户原话：「轮廓容差这个参数感觉已经影响不大了，可以设定为 4.05 的
        # 默认值然后把调整参数隐藏掉」。实测支持（真实图 1.5→4.05 漏画只差
        # 0.022pp，见 props.py 的 tolerance 注释）。
        #
        # 属性保留、只隐藏 UI：老 .blend 里存的值仍生效，需要时从 Python 改。
        #
        # ⚠️ 原来这里有一条「想要更细的边缘：把轮廓容差往左调」的提示，
        #    它的显示条件是 s.tolerance > 3.0。现在 tolerance 固定 4.05，
        #    这条会**永远显示**却在指一个不存在的滑块 —— 必须一起删掉。
        #
        # 【「拐角圆滑」滑块更早已经移除（2026-10-21）】
        # 实测真实图各档效果 <0.3%，却要多花 18~141ms 重算 A 阶段。

        # 外扩那一圈的 UV 落在贴图的透明像素上 —— 几何是撑大了，但采样到的 alpha 仍是 0，
        # 渲染出来那圈还是透的。不提示的话用户会以为「外扩没生效」，反复调大滑块。
        # 外扩的有效上限跟着图尺寸走（长边 20%），这里显示出来 ——
        # 用户拉到上限时得知道「不是滑块坏了，是这张图最多就这么多」。
        # 【外扩的副作用合并成一条（2026-10-22 精简）】
        # 原来是三行（渲染仍透 / 细缝合上 / 最多能扩多少），占掉半个面板。
        # 其中前两条是同一件事的两面 —— expand 是形态学膨胀，副作用都写一起：
        #   · 外扩圈 UV 落在贴图透明处，渲染出来那圈还是透的
        #   · 比 expand 还窄的细缝会被整个合上（实测 1px 网格线在 expand=1 时消失）
        # 上限那条改成**只在接近上限时才显示**：平时它是纯占地方的信息，
        # 用户把滑块拖到底想再拖却不动的那一刻，才是它真正有价值的时候。
        _el = expand_limit(getattr(s, "stat_img_long", 0))
        if s.expand and s.expand > 0:
            warn = col.row()
            warn.enabled = False
            # ⚠️ 文案长度上限约 19 个中文字符（实测：再长面板会用「…」截断）。
            #    第一版写成「更窄的细缝会合上，边缘圈仍透明」，实测末尾被截成
            #    「边缘圈…」，等于把关键信息吃掉一半。压到 15 字以内。
            warn.label(text="外扩 %d：细缝合上，边缘仍透" % s.expand, icon="ERROR")
        if _el > 0 and s.expand >= _el * 0.8:
            _er = col.row()
            _er.enabled = False
            _er.label(text="最多 %d，已接近上限" % _el, icon="INFO")

        # 【重要】源图的镂空不保留：split_outer 只留外环，源图内环全部丢弃，
        # 内部一律填满。这跟 expand 完全无关 —— 实测 expand=0 时甜甜圈的洞里
        # 照样有 158 个三角形。手绘闭合 carve 是例外：阶段 B 会用引导掩膜
        # 把洞里的三角形剔掉，所以文案要区分“源图洞”和“引导洞”。
        #
        # 早先这里写的是「低于 N 像素的镂空会被填死」，把人引向 expand 这个
        # 错误参数：用户按提示把 expand 调到 0，洞还是填死的。文案必须说清
        # 这是设计，不是参数问题。
        # getattr 兜底：热重载（改完代码只 reload 模块、没重新注册 PropertyGroup）
        # 或者打开旧 .blend 时，对象上可能还没有这个新字段。
        # 面板绘制函数里一旦抛异常，整个面板会变成空白/报错，比少一行提示糟糕得多。
        inner_cnt = int(getattr(s, "stat_inner", 0) or 0)
        if inner_cnt > 0:
            holes = col.row()
            holes.enabled = False
            # 长度上限约 19 字（超过会被面板用「…」截断）。
            has_carve = bool(
                getattr(s, "guide_enabled", False)
                and any(
                    (not st.closed)
                    or getattr(st, "mode", "auto") == "carve"
                    or (getattr(st, "mode", "auto") == "auto"
                        and getattr(s, "guide_mode", "") == "carve")
                    for st in getattr(s, "strokes", ())
                )
            )
            if has_carve:
                holes.label(text="内环 %d：源图填实/引导保留" % inner_cnt, icon="ERROR")
            else:
                holes.label(text="有 %d 处镂空，会填实不留洞" % inner_cnt, icon="ERROR")

        # ---- 网格 ----
        col = layout.column(align=True)
        col.label(text="网格", icon="MESH_GRID")
        col.prop(s, "density", slider=True)
        # 边长和预估面数合并成一行 —— 它们回答的是同一个问题「这个密度多重」。
        # 预估面数保留的原因：拖滑块之前就知道会铺多少面，免得拉到头才发现太重。
        sp = col.row()
        sp.enabled = False
        est = _estimate_faces(s)
        if est:
            sp.label(text="边长 %.1f 像素 → 约 %s 面" % (s.spacing(), _fmt_count(est)))
        else:
            sp.label(text="边长 %.1f 像素" % s.spacing())

        # 三角化走哪个后端 —— 【只在退化时提示（2026-10-22 精简）】
        # 正常情况走 mathutils C 实现，这是默认前提，不值得占一行；
        # 显示成 python 才说明加速没生效（某些精简版 Blender 不带
        # mathutils.geometry），那时「同事机器快 40 倍」这类问题才有线索。
        be = tri_mod.backend_name()
        if be != "mathutils-cdt":
            be_row = col.row()
            be_row.alert = True
            be_row.label(text="三角化退化到纯 Python（慢）", icon="ERROR")

        # 参数重建走的是定时器（不进 undo 栈），必须说清楚，否则用户按 Ctrl+Z 发现
        # 参数回退了、网格没回退，会以为插件坏了。
        hint = layout.row()
        hint.enabled = False
        # 图标只能用 tests/icon_compat.json 白名单里的（UNDO 不在其中）
        hint.label(text="参数调整不可撤销，可点「重建」重来", icon="INFO")

        # ---- 引导（钢笔）----
        box = layout.box()
        # ⚠️ 图标名是 "GREASEPENCIL"（无下划线）。写成 GREASE_PENCIL 会抛 TypeError，
        #    而这会让 draw() 从这里往后全部不画 —— 钢笔按钮就是这么消失的。
        box.label(text="手绘引导", icon="GREASEPENCIL")
        col = box.column(align=True)
        col.prop(s, "guide_enabled")
        if len(s.strokes):
            col.prop(s, "guide_show", text="视口显示全部路径")
        if s.guide_enabled:
            col.prop(s, "guide_mode")
        rule = box.row()
        rule.enabled = False
        rule.label(text="闭合圈内补/挖 · 开放沿线切", icon="INFO")
        # 路径列表始终显示：即使暂时关掉「启用引导」，也要能查看/编辑/删除，
        # 不能让人以为路径丢了。
        active_paths = sum(
            1 for st in s.strokes if bool(getattr(st, "enabled", True))
        )
        box.label(
            text="已画 %d 条 · 启用 %d 条"
                 % (len(s.strokes), active_paths)
        )
        if not len(s.strokes):
            empty = box.row()
            empty.enabled = False
            empty.label(text="先在视口描边或圈选，之后可逐条调整", icon="INFO")
        elif active_paths == 0:
            disabled = box.row()
            disabled.enabled = False
            disabled.label(text="所有路径都已停用，当前走纯自动结果", icon="INFO")
        mode_txt = {"auto": "默认", "add": "补", "carve": "挖"}
        mode_icon = {"auto": "AUTO", "add": "ADD", "carve": "REMOVE"}
        for i, st in enumerate(s.strokes):
            stroke_mode = getattr(st, "mode", "auto")
            stroke_enabled = bool(getattr(st, "enabled", True))
            row = box.row(align=True)
            label = "%d %s·%s" % (
                i + 1,
                "闭" if st.closed else "开",
                mode_txt.get(stroke_mode, "默认") if st.closed else "切",
            )
            toggle = row.operator(
                "image_cutter.pen_toggle",
                text="",
                icon="HIDE_OFF" if stroke_enabled else "HIDE_ON",
            )
            toggle.stroke_index = i
            label_cell = row.row()
            label_cell.enabled = stroke_enabled
            label_cell.label(text=label)
            mode_cell = row.row(align=True)
            mode_cell.enabled = bool(st.closed and stroke_enabled)
            op = mode_cell.operator(
                "image_cutter.pen_cycle_mode",
                text="",
                icon=mode_icon.get(stroke_mode, "AUTO"),
            )
            op.stroke_index = i
            op = row.operator(
                "image_cutter.pen_draw",
                text="编辑",
                icon="EDITMODE_HLT",
            )
            op.stroke_index = i
            op = row.operator(
                "image_cutter.pen_delete",
                text="",
                icon="TRASH",
            )
            op.stroke_index = i
        row = box.row(align=True)
        # ⚠️ 图标名必须在**所有支持的 Blender 版本**里都存在。
        #    这里原来写的是 GP_DRAW_STROKE —— 它在 5.1+ 才有，
        #    4.2~5.0 上会抛异常 → draw() 截断 → 按钮直接消失。
        #    CURVE_PATH 从 4.0 到 5.2 都有（见 tests/icon_compat.json）。
        row.operator("image_cutter.pen_draw", text="画路径", icon="CURVE_PATH")
        row.operator("image_cutter.pen_clear", text="", icon="TRASH")

        # ---- 状态 ----
        box = layout.box()
        box.label(text="结果", icon="INFO")
        if getattr(s, "stat_preview", False):
            pv = box.row()
            pv.enabled = False
            pv.label(text="交互预览，停手后自动细化", icon="TIME")
        # 【6 格压成 4 格（2026-10-22 精简）】
        # 原来「轮廓 N 圈」和「画出来的/像素画」各占一格、「认轮廓/铺网格」
        # 也各占一格 —— 4 个数分成两格，占了 6 行位置。
        # 前者是同一个话题（轮廓长什么样），后者是同一个问题（哪段慢）。
        # 合并后仍保留全部数值，只是排得更紧。
        g = box.grid_flow(columns=2, even_columns=True, align=True)
        g.label(text="三角形 %d" % s.stat_faces)
        g.label(text="顶点 %d" % s.stat_points)
        style_txt = {"soft": "软边", "hard": "像素画"}.get(s.stat_edge, "-")
        g.label(text="轮廓 %d 圈 · %s" % (s.stat_rings, style_txt))
        g.label(text="耗时 %.0f+%.0f ms" % (s.stat_ms_a, s.stat_ms_b))

        # 【"环很多"有两种完全不同的原因，不能一概而论】
        #
        # ① 真的碎了（1px 斜线在 expand=0 下碎成 512 块）—— 这时调 expand 有用
        # ② 图里本来就有很多独立小块（文字排版、图标集、头发丝碎屑）
        #    —— 这时调 expand 会把小块直接吃掉
        #
        # 审查实测：真实人物贴图 210 个外环，最大环占 99.99%（其余是发丝碎屑），
        # 按旧文案建议调 expand=1 后，外环从 210 掉到 5 —— 199 个碎屑被膨胀抹掉，
        # 形状被吃掉一大片。而在「32 个间隔 20px 的方块」上，expand=1 完全无效
        # （间隔远大于 1px，还是 32 环）。
        #
        # 所以判据要用「最大环占比」区分这两种情况，而且文案不能无条件推销 expand。
        dom = float(getattr(s, "stat_dominant", 0.0) or 0.0)
        if s.stat_rings >= 32:
            hint = box.row()
            hint.enabled = False
            # 长度上限 ~19 字（超了面板会「…」截断），两条都压到线下。
            if dom >= 0.9:
                # 有明确主体，其余是零碎小片 —— 这是正常素材，不该让用户去改参数
                # 「独立」二字不能省：省略后与下面「碎成 N 块」读起来像同一件事。
                # 实测宽度 180px，面板可用约 187px（见 mesh_line 实测），放得下。
                hint.label(
                    text="含 %d 处独立小碎块（主体占 %.0f%%）"
                         % (s.stat_rings - 1, dom * 100),
                    icon="INFO",
                )
            else:
                # 真的碎成一片，没有主体 —— 这时 expand 才是有效杠杆
                # 原文「碎成 N 块，没有明显主体：可试「边缘外扩」1~2」有 26 字，
                # 会截断成「…边缘外扩…」，正好把可操作建议吃掉。
                hint.label(
                    text="碎成 %d 块：可试「边缘外扩」1~2" % s.stat_rings,
                    icon="INFO",
                )

        if s.stat_faces == 0 and not s.last_error:
            warn = box.row()
            warn.enabled = False
            warn.label(text="还没算出面，调调阈值试试", icon="INFO")
