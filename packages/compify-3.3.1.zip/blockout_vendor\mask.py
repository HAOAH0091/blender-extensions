# Vendored from image_cutter v0.4.0 (..\image_cutter\ic_core\mask.py)
# Kept unchanged apart from this provenance note. Original header follows.
"""alpha → 二值掩膜，并判断这张图是「软边画」还是「像素画」。

为什么要判断软硬边：**软边才该平滑，硬边保留楼梯**。
对像素画平滑会把设计磨没，对绘画不平滑会留下难看的锯齿。
"""

import numpy as np


def build_mask(alpha, threshold=0.5, assume_unit=False):
    """alpha → bool 掩膜。

    alpha: (H, W) float，取值 0..1（或 0..255，函数内自动归一）
    threshold: 超过它算「实心」
    assume_unit: 调用方已保证数据在 0..1 时传 True，省掉整图 max/clip。

    返回 (mask, stats)，stats 里有空像素数等，给 UI 显示用。
    """
    a = np.asarray(alpha, dtype=np.float32)
    if a.size == 0:
        raise ValueError("alpha 为空数组")
    if not assume_unit:
        if a.max() > 1.0001:        # 0..255 进来的，归一
            a = a / 255.0
        a = np.clip(a, 0.0, 1.0)

    mask = a >= float(threshold)
    solid = int(np.count_nonzero(mask))
    stats = {
        "total": int(mask.size),
        "solid": solid,
        "empty": int(mask.size - solid),
    }
    return mask, stats


def edge_style(alpha, mask, sample_cap=200000):
    """判断这张图是「软边」（画出来的）还是「硬边」（像素画）。

    判据：看**轮廓附近**的 alpha 过渡是渐变还是突变。
    具体做法——取那些「自己实心、但四邻里有空心」的边界像素，
    统计它们 alpha 落在中间地带（0.15~0.85）的比例。
    比例高 = 边缘是渐变的 = 软边，该平滑；比例低 = 硬边，保留楼梯。

    sample_cap: 边界像素太多时抽样，避免大图上卡住。
    返回 (style, ratio)：style 是 'soft' / 'hard'，ratio 是中间地带占比。
    """
    a = np.asarray(alpha, dtype=np.float32)
    m = np.asarray(mask, dtype=bool)

    # 【别在整幅图上做 max / clip】
    # 3883×1978 是 770 万像素，a.max() 一次全扫、np.clip 又一次全扫，
    # 两趟下来 ~10ms，而真正要用的只有边界上那几万个值。
    # 所以这里先只对**边界值**做归一化和截断（下面取样后再处理）。
    # 前提：alpha 要么全在 0..1，要么全是 0..255 —— 混着的情况不存在（来自同一张图）。
    # 用一个便宜的判断：先看 dtype 和抽样，避免全图 max。
    _probe = a[::97, ::89]          # 稀疏抽样，几万个点足够判断量纲
    _scale = 255.0 if (_probe.size and float(_probe.max()) > 1.0001) else 1.0

    if m.size == 0 or not m.any():
        return "hard", 0.0

    # 边界像素 = 实心，且「四邻不全是实心」（至少一侧空着 / 或贴着图像边缘）
    # 注意是「四邻全实心」取反，不是「四邻里有实心」——后者会挑出孤立点
    #
    # 【性能：先在缩小的工作区里算，别整幅图铺满布尔数组】
    # 早先是 np.ones_like(m) + 四次全尺寸布尔运算，3883×1978 要跑 33ms
    # （770 万像素 × 5 个临时数组 ≈ 40MB 的分配和读写）。
    # 而真正的边界像素只有几万个。所以先裁到「既有实心又有空」的矩形区域，
    # 只在那里算四邻。裁边用 any(axis) 逐行/逐列，比全图布尔运算便宜得多。
    rows_solid = m.any(axis=1)
    cols_solid = m.any(axis=0)
    if not rows_solid.any():
        return "hard", 0.0
    r0 = int(np.argmax(rows_solid))
    r1 = int(len(rows_solid) - np.argmax(rows_solid[::-1]))
    c0 = int(np.argmax(cols_solid))
    c1 = int(len(cols_solid) - np.argmax(cols_solid[::-1]))

    # 上下左右各留 1 行/列：四邻判定需要邻域，且贴图像边界的形状也算边界
    ra = max(0, r0 - 1)
    rb = min(m.shape[0], r1 + 1)
    ca = max(0, c0 - 1)
    cb = min(m.shape[1], c1 + 1)
    sub_m = m[ra:rb, ca:cb]

    all_nb_solid = np.ones_like(sub_m)
    # 只在「真的贴着图像边缘」时才把这些位置标 False；
    # 缩小区后，切片边界不是图像边界，不能一概而论（否则会凭空造出边界像素）
    if ra == 0:
        all_nb_solid[0, :] = False
    if rb == m.shape[0]:
        all_nb_solid[-1, :] = False
    if ca == 0:
        all_nb_solid[:, 0] = False
    if cb == m.shape[1]:
        all_nb_solid[:, -1] = False
    all_nb_solid[1:, :] &= sub_m[:-1, :]
    all_nb_solid[:-1, :] &= sub_m[1:, :]
    all_nb_solid[:, 1:] &= sub_m[:, :-1]
    all_nb_solid[:, :-1] &= sub_m[:, 1:]
    boundary_sub = sub_m & ~all_nb_solid
    if not boundary_sub.any():
        return "hard", 0.0

    # 回到原图坐标取 alpha 值（边界点少，这个开销可以忽略）
    ys, xs = np.nonzero(boundary_sub)
    vals = a[ys + ra, xs + ca]
    if vals.size > sample_cap:
        step = int(np.ceil(vals.size / sample_cap))
        vals = vals[::step]

    # 只对这**几万个边界值**做归一化 + 截断（而不是对 770 万像素做）
    if _scale != 1.0:
        vals = vals / _scale
    vals = np.clip(vals, 0.0, 1.0)

    mid = ((vals > 0.15) & (vals < 0.85))
    ratio = float(mid.sum()) / float(vals.size) if vals.size else 0.0
    return ("soft" if ratio >= 0.18 else "hard"), ratio


def dilate_mask(mask, radius):
    """形态学膨胀 —— 「边缘外扩」就靠它。

    ⚠️ 外扩**必须**在这一层做，不能在轮廓层把点沿法线往外平移：
    凹口处两侧法线会交叉，推出去轮廓自己打个结，三角化直接崩。
    位图膨胀天然不会自交，膨胀完重新追轮廓，出来就是干净的。

    实现用「横向 + 纵向」的可分离写法，结果是方形结构元素
    （不是正圆，但对这个用途没差别，速度快一个量级）。

    ==========================================================================
    【2026-10-21 加了大半径的快速路径】

    老写法是 2r 轮 Python 循环，每轮都动全图（3883×1978 = 768 万像素）：
        实测每轮固定 1.07 ms，所以耗时 ≈ 2.14 × r
        r=16 → 38ms，r=64 → 147ms，r=128 → 280ms，r=256 → 550ms
    用户拖「边缘外扩」时 expand 在 stage_a_key 里 → 每格都要重跑 A 阶段
    → expand 越大越慢 → 表现就是「拖到高档不跟手」。

    新写法用「前缀和 + 窗口差分」：每行/列算一次累积和，
    再看窗口 [x-r, x+r] 内的和是否 > 0（有 True 就说明该位置被覆盖）。
    **复杂度与 r 无关**，固定约 96ms。

    实测（真实图，结果逐像素完全一致）：
        r      原(ms)   新(ms)   选择
        8       21.4     98.0    原（小 r 时循环反而快，内存局部性好）
        16      42.8    101.3    原
        32      77.5     97.2    原
        64     148.7     95.8    新快 1.6 倍
        128    297.2     96.9    新快 3.1 倍
        256    561.6     96.3    新快 5.8 倍
    交叉点在 r≈45，取 48 分档（留余量避免临界抖动）。

    前缀和用 int16：窗口内的计数上限就是行/列长度（最大 3883），
    int16 上界 32767 够用，比 int32 省一半内存带宽。
    """
    r = int(round(radius))
    if r <= 0:
        return np.array(mask, dtype=bool, copy=True)

    # r < 16 时逐轮循环反而快（内存局部性好、没有额外分配），实测 r=4 时
    # 循环 11.6ms vs 倍增 15.8ms。交叉点在 16 附近。
    if r >= 16:
        return _dilate_by_doubling(mask, r)

    out = np.array(mask, dtype=bool, copy=True)
    for _ in range(r):
        out[:, 1:] |= out[:, :-1]
        out[:, :-1] |= out[:, 1:]
    for _ in range(r):
        out[1:, :] |= out[:-1, :]
        out[:-1, :] |= out[1:, :]
    return out


def _dilate_1d_or(a, k, axis):
    """沿一维膨胀 k（窗口 OR），用二进制倍增：D_a ∘ D_b = D_(a+b)。

    每一步把「当前结果」和「它右移 b 位」做 OR，b 取 1,2,4,8...…
    k 步被压成 log2(k) 步全图操作。方形结构元可组合（正方形拼正方形
    还是正方形），所以这样拆是**精确**的，不是近似。
    """
    out = np.array(a, dtype=bool, copy=True)
    shift = 1
    rem = int(k)
    while rem > 0:
        b = min(shift, rem)
        src = out
        out = out.copy()
        if axis == 1:
            if b < out.shape[1]:
                out[:, b:] |= src[:, :-b]
        else:
            if b < out.shape[0]:
                out[b:, :] |= src[:-b, :]
        rem -= b
        shift *= 2
    return out


def _dilate_by_doubling(mask, r):
    """方窗膨胀：二进制倍增（log 步），等价于 (2r+1)×(2r+1) 方窗。

    【为什么换掉前缀和 —— 2026-10-21 实测】
    上一版用「前缀和 + 窗口差分」，复杂度与 r 无关、固定约 96ms。
    但它每步都要建 (H, W+1) 的 int16 累积数组、再做两次花式索引
    （cs[:, hi] / cs[:, lo]），内存流量是像素数的好几倍。实测：

        r      前缀和ms   倍增ms   提速
        16       34.5      20.8    1.66x
        48      118.1      24.1    4.90x
        64      107.5      32.9    3.27x
        128     115.0      33.0    3.49x
        256     101.7      35.0    2.91x
        512     111.0      37.0    3.00x
        656     111.4      39.1    2.85x

    （两种写法逐像素完全一致，200×200 方块 + 真实 3883×1978 图都验过。）

    ⚠️ 两个踩过的坑，别再犯：
    ① 二维数组的 out[::-1] 反转的是**行**，不是列。第一版想「反转后向右扩
       等于原数组向左扩」，却拿 out[::-1] 当列反转用，结果形状被整体平移
       （实心数 1764 一个不差，位置全错，差异 84 像素）——
       列反转必须写 out[:, ::-1]。
    ② 倍增的 b 要取 min(shift, rem)，不能只按 2 的幂走，
       否则 656 = 512+128+16 会漏掉余数，窗口少扩几像素。
    """
    out = np.asarray(mask, dtype=bool)
    H, W = out.shape
    if H == 0 or W == 0:
        return out.copy()
    out = _dilate_1d_or(out, r, axis=1)                        # 向右
    out = _dilate_1d_or(out[:, ::-1], r, axis=1)[:, ::-1]      # 向左（列反转）
    out = _dilate_1d_or(out, r, axis=0)                        # 向下
    out = _dilate_1d_or(out[::-1, :], r, axis=0)[::-1, :]      # 向上（行反转）
    return out


def apply_guide(mask, guide_mask, mode="follow"):
    """把用户用钢笔画出来的引导并进掩膜。

    guide_mask: (H, W) 三态 int8 ——  0=不管  +1=强制实心  -1=强制空心

    mode 只有两个**真正不同**的行为：
      'follow'    照掩膜符号执行（+1 补、-1 挖）—— 默认，也是唯一正常路径
      'solid_only' 只补不挖（忽略所有 -1，保证绝不碰自动结果）

    ⚠️ 早先还有个 'carve'，但它和 'follow' 行为完全一样 ——
       因为「挖」这个语义已经写在掩膜符号里了（build_guide_mask 按
       guide_mode 决定闭合路径圈内标 +1 还是 -1），apply_guide 只需照做。
       同一个概念在两个层次各有一套"挖"的说法，是纯粹的接口冗余。
       现在 carve 作为**废弃别名**保留（映射到 follow），免得旧 .blend 或
       第三方脚本调用时炸掉，但不再出现在文档与 UI 里。

    返回新掩膜（不改原数组，避免调用方拿到被就地改过的数据）。
    """
    # 兼容旧名字：carve → follow（行为本来就一样，只是名字误导）
    if mode == "carve":
        mode = "follow"
    if mode == "add":
        mode = "follow"
    out = np.array(mask, dtype=bool, copy=True)
    if guide_mask is None:
        return out
    g = np.asarray(guide_mask)
    if g.shape != out.shape:
        raise ValueError("引导掩膜尺寸和主掩膜不一致：%s vs %s" % (g.shape, out.shape))

    keep = g > 0
    drop = g < 0

    # 掩膜的符号已经表达了用户意图（+1 补 / -1 挖），这里只需照做。
    # solid_only 是唯一例外：它承诺「绝不挖掉任何自动结果」，所以忽略 -1。
    out[keep] = True
    if mode != "solid_only":
        out[drop] = False
    return out
