"""Panel and operators for one-click blockout.

Trimming now lives on the object (BlockoutSettings) and is rebuilt by a timer;
there is no geometry-nodes modifier any more.
"""

import json
import os
from pathlib import Path
import subprocess
import tempfile
import textwrap

import bpy

from . import blockout
from . import blockout_installer
from . import blockout_live

_ = bpy.app.translations.pgettext_iface

GRID_ITEMS = (
    ("COARSE", "粗略", "32 段，面数最少"),
    ("STANDARD", "标准", "64 段"),
    ("FINE", "精细", "128 段"),
    ("ULTRA", "超精细", "256 段，面数最多"),
)

DEFAULT_GRID_VALUE = 32


def default_grid():
    """Grid density used by the one-click button, from the add-on preferences."""
    prefs = bpy.context.preferences.addons.get(__package__)
    value = getattr(prefs.preferences, "default_grid", "") if prefs else ""
    try:
        return max(16, min(256, int(value)))
    except (TypeError, ValueError):
        return DEFAULT_GRID_VALUE


def projection_blocked_reason(context):
    """Why the projection generator cannot run; "" when it can."""
    scene = context.scene
    camera = getattr(scene, "compify_uv_adjust_camera", None)
    meshes = [obj for obj in context.selected_objects if obj.type == "MESH"]
    if not meshes:
        return "请先选中一张图平面"
    if camera is None:
        return "请先选择一个摄像机"
    if camera.type != "CAMERA":
        return "选中的不是摄像机，请改选摄像机"
    return ""


def _generate_items(context, items, params, keep_source):
    """Shared generation loop. Returns (created objects, failure strings)."""
    created = []
    failures = []
    for item in items:
        try:
            obj = blockout.generate(context, item["object"], item["camera"],
                                    dict(params))
            created.append(obj)
        except Exception as error:  # noqa: BLE001
            print("[Compify|Blockout] 生成失败 %s：%s"
                  % (item["plate"], error))
            failures.append("%s：%s" % (item["plate"],
                                        blockout_live.human_message(error)))
    if created and keep_source:
        for item in items:
            item["object"].hide_set(True)
            item["object"].hide_render = True
    return created, failures


def _report_generation(context, created, skipped, failures, label):
    """Select the new blockouts, push one undo step, build the summary line."""
    for selected in context.selected_objects:
        selected.select_set(False)
    for obj in created:
        obj.select_set(True)
    context.view_layer.objects.active = created[-1]
    try:
        bpy.ops.ed.undo_push(message=label)
    except RuntimeError:
        pass
    parts = [_("已生成 %d 个模型") % len(created)]
    for record in skipped:
        parts.append(_("%s 已跳过：%s") % (record["plate"], record["reason"]))
    parts.extend(failures)
    return "；".join(parts)


def register_properties():
    bpy.types.Scene.compify_blockout_grid = bpy.props.EnumProperty(
        name="精细度", items=GRID_ITEMS, default="FINE")


def unregister_properties():
    if _install_job is not None:
        _install_job.silent = True
        _install_job.cancel()
    _install_results.clear()
    if hasattr(bpy.types.Scene, "compify_blockout_grid"):
        del bpy.types.Scene.compify_blockout_grid


class CompifyBlockoutPreferences(bpy.types.AddonPreferences):
    """Model tier and on-disk locations for one-click blockout."""

    bl_idname = __package__

    quality: bpy.props.EnumProperty(
        name="模型档位",
        items=(("FAST", "快档（ViT-S）", "约 140MB，速度快"),
               ("ACCURATE", "准档（ViT-B）", "约 420MB，细节更好")),
        default="FAST")
    default_grid: bpy.props.EnumProperty(
        name="生成模型默认网格密度",
        description="分区 ② 的一键生成按钮使用这个密度；每个模型仍可单独调",
        items=(("32", "32 段（粗）", "面数最少，生成最快"),
               ("64", "64 段", "中等"),
               ("128", "128 段", "细"),
               ("256", "256 段（最细）", "面数最多")),
        default="32")
    models_dir: bpy.props.StringProperty(
        name="生成模型位置", subtype="DIR_PATH", default="")
    runtime_dir: bpy.props.StringProperty(
        name="生成模型运行环境位置", subtype="DIR_PATH", default="")

    def draw(self, context):
        layout = self.layout
        options = layout.column()
        options.enabled = _install_job is None
        options.prop(self, "quality")
        layout.prop(self, "default_grid")
        locations = layout.column()
        locations.enabled = _install_job is None
        locations.prop(self, "models_dir", text="生成模型位置")
        locations.prop(self, "runtime_dir", text="生成模型运行环境位置")
        layout.label(text="留空则用默认目录", icon="INFO")

        status = blockout.runtime_status()
        box = layout.box()
        box.label(text="安装状态", icon="PACKAGE")
        for tier in (blockout.TIER_FAST, blockout.TIER_ACCURATE):
            info = status["tiers"][tier]
            ready = _install_ready(info)
            row = box.row()
            row.label(
                text="%s：%s" % (info["label"],
                                "已安装" if ready else "未安装"),
                icon="CHECKMARK" if ready else "ERROR")
            if not ready:
                button = row.row()
                button.enabled = _install_job is None
                op = button.operator("compify.install_blockout_runtime",
                                  text="安装", icon="IMPORT")
                op.tier = tier
        _draw_install_status(box)
        layout.label(text="推理环境：%s" % status["runtime_dir"])
        layout.label(text="模型目录：%s" % status["models_dir"])
        layout.separator()
        cleanup = layout.row()
        cleanup.enabled = _install_job is None
        cleanup.operator("compify.purge_models", text="一键清理", icon="TRASH")


class CompifyPurgeModels(bpy.types.Operator):
    """删除已下载的模型与运行环境，之后重新下载"""

    bl_idname = "compify.purge_models"
    bl_label = "一键清理"

    @classmethod
    def poll(cls, context):
        return _install_job is None

    def invoke(self, context, event):
        reason = blockout.unsafe_clean_reason()
        if reason:
            # Never open the dialog: its confirm button would delete things
            # outside the add-on's own storage.
            print("[Compify|Blockout] %s" % reason)
            self.report({"ERROR"}, reason)
            return {"CANCELLED"}
        return context.window_manager.invoke_props_dialog(
            self, width=460, confirm_text="清理")

    def draw(self, context):
        layout = self.layout
        models = blockout.models_dir()
        runtime = blockout.runtime_dir()
        same = str(models) == str(runtime)
        model_mb = blockout.dir_size(models) / (1024.0 * 1024.0)
        runtime_mb = 0.0 if same else blockout.dir_size(runtime) / (1024.0 * 1024.0)
        layout.label(text="将删除全部模型（约 %.1f MB）" % model_mb, icon="ERROR")
        if not same:
            layout.label(text="和运行环境（约 %.1f MB）" % runtime_mb,
                         icon="ERROR")
        layout.label(text="合计约 %.1f MB，之后需要重新下载。" % (model_mb + runtime_mb))

    def execute(self, context):
        # Confirm re-checks the guard: a path can change while the dialog is up.
        reason = blockout.unsafe_clean_reason()
        if reason:
            print("[Compify|Blockout] %s" % reason)
            self.report({"ERROR"}, reason)
            return {"CANCELLED"}
        models = blockout.models_dir()
        runtime = blockout.runtime_dir()
        targets = [models]
        if str(models) != str(runtime):
            targets.append(runtime)
        removed = 0
        errors = []
        for path in targets:
            size, error = blockout.purge_dir(path)
            removed += size
            if error:
                errors.append(error)
        if errors:
            print("[Compify|Blockout] 清理未完成：%s" % "；".join(errors))
            self.report({"ERROR"}, "清理没做完（已删 %.1f MB）：%s"
                        % (removed / (1024.0 * 1024.0), "；".join(errors)))
            return {"CANCELLED"}
        self.report({"INFO"}, "已清理约 %.1f MB，模型需要重新下载"
                    % (removed / (1024.0 * 1024.0)))
        return {"FINISHED"}


class CompifyBlockoutGenerate(bpy.types.Operator):
    """根据投射摄像机生成带透视起伏的模型"""

    bl_idname = "compify.generate_blockout"
    bl_label = "从投射生成建模"
    bl_options = {"REGISTER", "UNDO"}

    grid_mode: bpy.props.EnumProperty(
        name="精细度", items=GRID_ITEMS, default="FINE")
    strength: bpy.props.FloatProperty(
        name="突出强度", default=1.0, min=0.0, max=2.0, subtype="FACTOR")
    smooth: bpy.props.IntProperty(
        name="表面平滑", default=1, min=0, max=3)
    keep_source: bpy.props.BoolProperty(
        name="保留原图平面", default=True)
    level: bpy.props.IntProperty(
        name="推理精度", default=5, min=0, max=9, options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        # Same rule as plan_batch: a plate without a projection cannot start,
        # so the button greys out instead of failing after a click.
        return not blockout.blocked_reason(context)

    @classmethod
    def description(cls, context, properties):
        reason = blockout.blocked_reason(context)
        return reason or "根据投射摄像机生成带透视起伏的模型"

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        items, skipped = blockout.plan_batch(context)
        column = layout.column(align=True)
        if len(items) == 1:
            column.label(text="摄像机：%s" % items[0]["camera_name"],
                         icon="CAMERA_DATA")
        elif len(items) > 1:
            column.label(text="各自投射摄像机（%d 个）" % len(items),
                         icon="CAMERA_DATA")
        else:
            column.label(
                text=blockout.blocked_reason(context) or "没有可生成的图平面",
                icon="ERROR")
        column.label(
            text="模型档位：%s" % blockout.TIER_LABEL[blockout.active_tier()],
            icon="MODIFIER")
        for item in items:
            warning = item.get("warning") or ""
            if warning:
                column.label(text="%s：%s" % (item["plate"], warning),
                             icon="ERROR")
        column.separator()
        column.prop(self, "grid_mode")
        column.prop(self, "strength")
        column.prop(self, "smooth")
        column.prop(self, "keep_source")
        column.separator()
        column.label(text="生成后可在侧栏调裁形，改动会实时重建", icon="INFO")

    def execute(self, context):
        items, skipped = blockout.plan_batch(context)
        if not items:
            # Same sentence the greyed-out button shows in its tooltip.
            self.report({"ERROR"}, blockout.blocked_reason(context)
                        or _("选中的物体还没有投射材质，请先生成投射"))
            return {"CANCELLED"}
        status = blockout.runtime_status()
        if not status["ready"]:
            self.report({"ERROR"}, blockout.missing_message(status))
            return {"CANCELLED"}

        params_base = {
            "grid": blockout.DEFAULT_GRID[self.grid_mode],
            "strength": float(self.strength),
            "smooth": int(self.smooth),
            "trim": True,
            "threshold": 0.0,
            "outward": 2.0,
            "border_grow": False,
            "border_width": 2,
            "level": int(self.level),
            "tier": blockout.active_tier(),
            "mode": "STATIC",
        }
        created, failures = _generate_items(context, items, params_base,
                                            self.keep_source)
        if not created:
            self.report({"ERROR"}, "；".join(failures) or _("生成失败"))
            return {"CANCELLED"}

        text = _report_generation(context, created, skipped, failures,
                                  self.bl_label)
        self.report({"INFO"}, text)
        return {"FINISHED"}


class CompifyBlockoutGenerateDefault(bpy.types.Operator):
    """按默认设置直接生成模型，不弹参数窗"""

    bl_idname = "compify.generate_blockout_default"
    bl_label = "从投射生成建模"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not blockout.blocked_reason(context)

    @classmethod
    def description(cls, context, properties):
        return blockout.blocked_reason(context) or "按默认设置直接生成模型"

    def execute(self, context):
        items, skipped = blockout.plan_batch(context)
        if not items:
            self.report({"ERROR"}, blockout.blocked_reason(context)
                        or _("没有可生成的图平面"))
            return {"CANCELLED"}
        status = blockout.runtime_status()
        if not status["ready"]:
            self.report({"ERROR"}, blockout.missing_message(status))
            return {"CANCELLED"}
        params = {
            "grid": default_grid(),
            "strength": 1.0,
            "smooth": 1,
            "trim": True,
            "threshold": 0.0,
            "outward": 2.0,
            "border_grow": False,
            "border_width": 2,
            "level": 5,
            "tier": blockout.active_tier(),
            "mode": "STATIC",
        }
        created, failures = _generate_items(context, items, params, True)
        if not created:
            self.report({"ERROR"}, "；".join(failures) or _("生成失败"))
            return {"CANCELLED"}
        text = _report_generation(context, created, skipped, failures,
                                  self.bl_label)
        self.report({"INFO"}, text)
        return {"FINISHED"}


class CompifyBlockoutMigrate(bpy.types.Operator):
    """把旧的「起模参数」修改器转换成对象参数"""

    bl_idname = "compify.blockout_migrate"
    bl_label = "转换旧参数"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != "MESH":
            return False
        return any(mod.type == "NODES" and mod.node_group is not None
                   and mod.node_group.name.startswith(blockout.GROUP_PREFIX)
                   for mod in obj.modifiers)

    def execute(self, context):
        obj = context.active_object
        if not blockout_live.migrate_legacy(obj):
            self.report({"WARNING"}, _("没有需要转换的旧参数"))
            return {"CANCELLED"}
        blockout_live.rebuild(obj)
        self.report({"INFO"}, _("已转换为对象参数并重建"))
        return {"FINISHED"}


class CompifyBlockoutSelect(bpy.types.Operator):
    """选中这些模型"""

    bl_idname = "compify.blockout_select"
    bl_label = "选中模型"

    names_json: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        # The row may shorten a long model name; the tooltip keeps it whole.
        try:
            names = json.loads(properties.names_json or "[]")
        except ValueError:
            names = []
        return "选中 %s" % (names[0] if names else "这个模型")

    def execute(self, context):
        try:
            names = json.loads(self.names_json or "[]")
        except ValueError:
            names = []
        chosen = [bpy.data.objects[n] for n in names if n in bpy.data.objects]
        if not chosen:
            self.report({"WARNING"}, _("没有找到对应的模型"))
            return {"CANCELLED"}
        for obj in context.selected_objects:
            obj.select_set(False)
        for obj in chosen:
            obj.select_set(True)
        context.view_layer.objects.active = chosen[0]
        return {"FINISHED"}



_install_job = None
_install_results = {}


def _install_ready(status):
    if not status["ready"] or not _install_results:
        return status["ready"]
    key = (status["tier"], str(Path(status["model_path"]).resolve()))
    return _install_results.get(key, True)


def _redraw_install_panels():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in {"VIEW_3D", "PREFERENCES"}:
                area.tag_redraw()


def _install_error(context, step, reason, advice, window=None):
    print(f"[Compify|Blockout] {step}：{reason}")
    if bpy.app.background:
        return
    manager = context.window_manager
    windows = tuple(manager.windows)
    window = window if window in windows else context.window
    if window is None and windows:
        window = windows[0]
    if window is None:
        return

    def draw(popup, _context):
        column = popup.layout.column(align=True)
        for entry in (f"步骤：{step}", *str(reason).splitlines(), f"处理：{advice}"):
            for line in textwrap.wrap(entry, width=65):
                column.label(text=line)

    with context.temp_override(window=window):
        manager.popup_menu(draw, title="生成模型安装失败", icon="ERROR")


class _InstallJob:
    def __init__(self, request, tier, select_tier, install_dir, window):
        self.key = (tier, request["models"][tier])
        self.tier = tier
        self.select_tier = select_tier
        self.install_dir = install_dir
        self.window = window
        self.silent = False
        self.event = {"step": "正在准备安装"}
        self.last_result = None
        self.switch = ""
        self.cancelled = False
        self.scratch = tempfile.TemporaryDirectory(prefix="compify-install-")
        directory = Path(self.scratch.name)
        self.cancel_path = directory / "cancel"
        request_path = directory / "request.json"
        self.offset = 0
        self.log_path = directory / "events.jsonl"
        try:
            request_path.write_text(json.dumps(request), encoding="utf-8")
            with self.log_path.open("wb") as output:
                self.worker = subprocess.Popen(
                    [request["launcher"], "-I", "-B", str(Path(blockout_installer.__file__)),
                     str(request_path)],
                    stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
                    creationflags=blockout_installer.NO_WINDOW)
        except OSError:
            self.scratch.cleanup()
            raise

    def cancel(self):
        self.cancel_path.touch()
        self.cancelled = True

    def poll(self):
        state = self.worker.poll()
        with self.log_path.open("rb") as log:
            log.seek(self.offset)
            for line in log:
                if not line.endswith(b"\n"):
                    break
                self.offset += len(line)
                try:
                    event = json.loads(line)
                except (UnicodeError, ValueError):
                    print("[Compify|Blockout]", line.decode("utf-8", errors="replace").strip())
                    continue
                kind = event["kind"]
                if kind in {"done", "error", "cancelled"}:
                    self.last_result = event
                elif kind in {"attempt", "progress", "stage", "install_progress"}:
                    if kind == "attempt":
                        self.switch = event["previous"]
                    elif kind in {"stage", "install_progress"}:
                        self.switch = ""
                    self.event = event
                if kind in {"attempt", "verified"}:
                    print("[Compify|Blockout]", json.dumps(event, ensure_ascii=True))
        if state is not None:
            return self.last_result or {
                "kind": "error", "step": self.event["step"],
                "reason": f"安装进程意外退出（{state}）",
                "advice": "点原按钮重试；若仍失败，请查看 Blender 控制台的详细信息。"}
        return None


def _poll_install():
    global _install_job
    job = _install_job
    result = job.poll()
    _redraw_install_panels()
    if result is None:
        return 0.10
    _install_job = None
    job.scratch.cleanup()
    if job.silent:
        return None
    if result["kind"] == "done":
        _install_results[job.key] = True
        prefs = blockout.preferences()
        if prefs is not None and job.select_tier:
            prefs.quality = job.tier
            if job.install_dir:
                prefs.models_dir = job.install_dir
    elif result["kind"] == "error":
        _install_results[job.key] = False
        _install_error(bpy.context, result["step"], result["reason"], result["advice"],
                       job.window)
    return None


def _start_install(context, tier, *, select_tier=False, install_dir=""):
    global _install_job
    if _install_job is not None:
        return {"CANCELLED"}
    try:
        manifest = blockout.load_manifest()
        blockout_installer.validate_manifest(manifest, (tier,))
    except json.JSONDecodeError as error:
        _install_error(context, "读取安装清单",
                       f"JSON 格式错误（第 {error.lineno} 行，第 {error.colno} 列）",
                       blockout_installer.RETRY_MANIFEST)
        return {"CANCELLED"}
    except (OSError, TypeError, KeyError, ValueError, RuntimeError) as error:
        _install_error(context, "读取安装清单", error, blockout_installer.RETRY_MANIFEST)
        return {"CANCELLED"}
    try:
        launcher = blockout.blender_python()
        if launcher is None:
            raise OSError("找不到 Blender 自带的 Python")
        models = blockout.models_dir()
        if select_tier and install_dir and not os.environ.get(blockout.MODELS_ROOT_ENV):
            models = Path(bpy.path.abspath(install_dir))
        request = {
            "manifest": manifest,
            "runtime": str(blockout.runtime_dir().resolve()),
            "models": {tier: str((models / blockout.TIER_DIR[tier] / "model.onnx").resolve())},
            "launcher": str(launcher),
            "online": getattr(bpy.app, "online_access", True),
        }
        for directory in (Path(request["runtime"]), Path(request["models"][tier]).parent):
            for ancestor in (directory, *directory.parents):
                if ancestor.exists() and not ancestor.is_dir():
                    raise OSError(f"安装目录被已有文件占用：{ancestor}")
        _install_job = _InstallJob(request, tier, select_tier, install_dir, context.window)
    except (OSError, ValueError, RuntimeError) as error:
        _install_error(context, "启动安装", error,
                       "检查安装目录与 Blender 安装是否完整，再点原按钮重试。")
        return {"CANCELLED"}
    bpy.app.timers.register(_poll_install, first_interval=0.05, persistent=True)
    _redraw_install_panels()
    return {"FINISHED"}


def _draw_install_status(layout):
    job = _install_job
    if job is None:
        return
    box = layout.box()
    if job.cancelled:
        box.label(text="正在取消安装…")
        return
    event = job.event
    box.label(text=event["step"])
    if job.switch:
        box.label(text="首源失败，正在尝试备用来源", icon="INFO")
    if event.get("total"):
        done, total = event["done"], event["total"]
        ratio = done / total
        if event["kind"] == "install_progress":
            label = f"已完成 {done}/{total} 项"
        else:
            box.label(text=event.get("host") or event["source"])
            scale, unit = (1_000_000, "MB") if total >= 1_000_000 else (1_000, "KB")
            label = f"{done / scale:.1f} / {total / scale:.1f} {unit} · {ratio:.0%}"
        if hasattr(box, "progress"):
            box.progress(factor=ratio, type="BAR", text=label)
        else:
            box.label(text=label)
    box.operator("compify.cancel_blockout_install", text="取消安装", icon="CANCEL")


class CompifyCancelBlockoutInstall(bpy.types.Operator):
    bl_idname = "compify.cancel_blockout_install"
    bl_label = "取消生成模型安装"

    @classmethod
    def poll(cls, context):
        return _install_job is not None and not _install_job.cancelled

    def execute(self, context):
        try:
            _install_job.cancel()
        except OSError as error:
            _install_error(context, "取消安装", error, blockout_installer.RETRY_LOCAL)
            return {"CANCELLED"}
        _redraw_install_panels()
        return {"FINISHED"}


class CompifyEnableBlockout(bpy.types.Operator):
    """启用生成模型：下载深度模型与运行环境（点击后才开始下载）"""

    bl_idname = "compify.enable_blockout"
    bl_label = "启用生成模型（需下载模型）"
    bl_options = {"REGISTER"}

    tier: bpy.props.EnumProperty(
        name="模型档位",
        items=(("FAST", "快档（约 140MB）", "ViT-S，速度快"),
               ("ACCURATE", "准档（约 420MB）", "ViT-B，细节更好")),
        default="FAST")
    install_dir: bpy.props.StringProperty(
        name="安装位置", subtype="DIR_PATH", default="")

    @classmethod
    def poll(cls, context):
        return _install_job is None

    def invoke(self, context, event):
        if not self.install_dir:
            self.install_dir = str(blockout.models_dir())
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        layout = self.layout
        layout.label(text="将下载：深度模型 + 推理运行环境", icon="IMPORT")
        layout.label(text="快档约 140MB，准档约 420MB", icon="INFO")
        layout.prop(self, "tier")
        layout.prop(self, "install_dir", text="安装位置")
        layout.label(text="默认放在用户数据目录，升级或重装插件不会丢", icon="INFO")
        layout.label(text="现在还没有开始下载，点「确定」后才下载", icon="INFO")

    def execute(self, context):
        return _start_install(context, self.tier, select_tier=True,
                              install_dir=self.install_dir)


class CompifyBlockoutInstall(bpy.types.Operator):
    """下载并安装生成模型运行环境与深度模型"""

    bl_idname = "compify.install_blockout_runtime"
    bl_label = "安装生成模型运行环境"
    bl_options = {"REGISTER"}

    tier: bpy.props.StringProperty(default="")

    @classmethod
    def poll(cls, context):
        return _install_job is None

    def execute(self, context):
        return _start_install(context, self.tier or blockout.active_tier())


def draw_blockout_section(layout, context):
    """Section 2: one generation button, no parameter widgets."""
    status = blockout.runtime_status()
    column = layout.column(align=True)
    if _install_job is not None:
        _draw_install_status(column)
        return
    if not _install_ready(status):
        # Size, missing parts and install path live in the ② help popup.
        column.label(text="生成模型需先下载深度模型", icon="INFO")
        row = column.row()
        row.scale_y = 1.3
        row.operator("compify.enable_blockout",
                     text="启用生成模型（需下载模型）", icon="IMPORT")
        return

    items, skipped = blockout.plan_batch(context)
    selected_meshes = [obj for obj in context.selected_objects
                       if obj.type == "MESH"]
    # One hint line at most, and only when nothing can be generated: the
    # button itself is the entry point.  "还没有投射" belongs to section 3,
    # so those reasons draw nothing here.
    if selected_meshes and not items:
        reasons = {record["reason"] for record in skipped}
        if reasons == {blockout.SKIP_NO_IMAGE}:
            column.label(text="投射里没有图片，重新生成", icon="INFO")
        elif not reasons <= {blockout.SKIP_NO_PROJECTION}:
            column.label(text="部分图平面无法生成", icon="INFO")

    row = column.row()
    row.scale_y = 1.4
    # poll and description come from blocked_reason, so the greyed state and
    # the tooltip always agree with the generation path.
    row.operator("compify.generate_blockout_default", icon="SHADERFX")

    # Same setting as the add-on preference "模型档位"; editing either one
    # moves both.  Without an add-on preferences object (bare module load)
    # fall back to a read-only line instead of touching None.
    prefs = blockout.preferences()
    row = column.row(align=True)
    if prefs is not None:
        row.prop(prefs, "quality", text="生成精度")
    else:
        row.label(text="生成精度：%s" % blockout.TIER_LABEL[status["tier"]],
                  icon="MODIFIER")
    # Land on this add-on's own preferences page, not the settings home.
    prefs_op = row.operator("preferences.addon_show", text="", icon="PREFERENCES")
    prefs_op.module = __package__
