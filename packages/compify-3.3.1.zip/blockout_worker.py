"""Standalone MoGe-2 depth worker for Compify blockout generation.

This file runs in Compify's own Python runtime (see blockout_depth.py), not in
Blender. It reads a request JSON, runs the ONNX model, and writes an NPZ.

Request JSON
------------
{
  "image": "path/to/framed.png",
  "fov_x": 39.6,              # horizontal field of view, degrees
  "max_size": 2048,           # long-edge cap for the model input
  "resolution_level": 5,      # 0..9, maps to the token budget
  "model": "path/to/model.onnx"
}

Output NPZ
----------
depth : (H, W) float32   camera-space depth in model units
mask  : (H, W) float32   validity in 0..1
intrinsics : (3, 3) float32  normalized intrinsics (x and y span 0..1)
size  : (2,) int32       model input width/height
"""

import json
import sys

import numpy as np


MIN_TOKENS = 1200
MAX_TOKENS = 3600


def normalize_view_plane_uv(width, height, dtype):
    aspect_ratio = width / height
    span_x = aspect_ratio / (1.0 + aspect_ratio**2) ** 0.5
    span_y = 1.0 / (1.0 + aspect_ratio**2) ** 0.5
    u = np.linspace(
        -span_x * (width - 1) / width,
        span_x * (width - 1) / width,
        width,
        dtype=dtype,
    )
    v = np.linspace(
        -span_y * (height - 1) / height,
        span_y * (height - 1) / height,
        height,
        dtype=dtype,
    )
    u, v = np.meshgrid(u, v, indexing="xy")
    return np.stack((u, v), axis=-1)


def recover_known_fov_shift(points, mask, fx, fy):
    """Fit the camera Z translation that makes points fit the known FOV."""
    from scipy.optimize import least_squares

    height, width = mask.shape
    intrinsics = np.array(((fx, 0, 0.5), (0, fy, 0.5), (0, 0, 1)))
    u = np.linspace(0.5 / width, 1.0 - 0.5 / width, width, dtype=np.float32)
    v = np.linspace(0.5 / height, 1.0 - 0.5 / height, height, dtype=np.float32)
    u, v = np.meshgrid(u, v, indexing="xy")
    depth_one = np.ones((height, width), dtype=np.float32)
    x = (u - intrinsics[0, 2]) / intrinsics[0, 0] * depth_one
    y = (v - intrinsics[1, 2]) / intrinsics[1, 1] * depth_one
    rays = np.stack((x, y, depth_one), axis=-1)

    valid = (mask > 0.5) & np.isfinite(points).all(-1)
    if valid.sum() < 16:
        return 0.0, np.zeros_like(valid)
    stride = max(1, min(height, width) // 64)
    selected = valid[::stride, ::stride]
    p = points[::stride, ::stride][selected].astype(float)
    q = rays[::stride, ::stride, :2][selected]
    if len(p) < 2:
        p, q = points[valid].astype(float), rays[..., :2][valid]
    initial = np.sum(q * (p[:, :2] - q * p[:, 2:])) / max(np.sum(q * q), 1e-8)
    lower = -float(points[..., 2][valid].min()) + 1e-5
    fitted = least_squares(
        lambda shift: (p[:, :2] / (p[:, 2:] + shift[0]) - q).ravel(),
        [max(initial, lower + 1e-4)],
        bounds=([lower], [np.inf]),
    )
    return float(fitted.x[0]), valid


def postprocess(raw_points, raw_mask, metric_scale, fov_x):
    points = np.asarray(raw_points, dtype=np.float32)
    mask = np.asarray(raw_mask, dtype=np.float32)
    if mask.min() < 0.0 or mask.max() > 1.0:
        mask = 1.0 / (1.0 + np.exp(-np.clip(mask, -80.0, 80.0)))
    height, width = mask.shape
    aspect_ratio = width / height
    fx = 0.5 / np.tan(np.deg2rad(float(fov_x)) / 2.0)
    fy = fx * aspect_ratio
    shift, valid = recover_known_fov_shift(points, mask, fx, fy)
    mask = np.where(valid, mask, 0.0)
    intrinsics = np.array(((fx, 0.0, 0.5), (0.0, fy, 0.5), (0.0, 0.0, 1.0)),
                          dtype=np.float32)
    depth = points[..., 2] + shift
    depth = depth * float(metric_scale)
    usable = np.isfinite(depth) & (depth > 0)
    mask = np.where(usable, mask, 0.0)
    depth = np.where(usable, depth, 1.0)
    return depth.astype(np.float32), mask.astype(np.float32), intrinsics


def frame_image(image, quad, size):
    """Warp the plate into the camera frame; return RGBA image at ``size``."""
    import numpy as np
    from PIL import Image

    source = [
        (0.0, float(image.height)),
        (float(image.width), float(image.height)),
        (float(image.width), 0.0),
        (0.0, 0.0),
    ]
    target = [(float(x) * size[0], (1.0 - float(y)) * size[1]) for x, y in quad]

    matrix = []
    for (sx, sy), (tx, ty) in zip(source, target):
        matrix.append([sx, sy, 1, 0, 0, 0, -tx * sx, -tx * sy, -tx])
        matrix.append([0, 0, 0, sx, sy, 1, -ty * sx, -ty * sy, -ty])
    _, _, values = np.linalg.svd(np.asarray(matrix, dtype=np.float64))
    homography = values[-1].reshape(3, 3)

    # Both source and target are already in pixels, so the inverse is the
    # output-pixel -> source-pixel mapping PIL expects.
    mapping = np.linalg.inv(homography)
    mapping = mapping / mapping[2, 2]
    coeffs = (
        mapping[0, 0], mapping[0, 1], mapping[0, 2],
        mapping[1, 0], mapping[1, 1], mapping[1, 2],
        mapping[2, 0], mapping[2, 1],
    )
    return image.convert("RGBA").transform(
        size, Image.Transform.PERSPECTIVE, coeffs,
        Image.Resampling.BICUBIC,
    )


def run(request):
    import onnxruntime as ort
    from PIL import Image

    plate = Image.open(request["image"]).convert("RGBA")
    size = tuple(int(v) for v in request["size"])
    framed = frame_image(plate, request["quad"], size)
    framed.save(request.get("framed_path") or "framed.png")
    image = framed.convert("RGB")
    max_size = int(request.get("max_size", 2048))
    scale = min(1.0, max_size / max(image.size))
    if scale < 1.0:
        image = image.resize(
            (max(1, round(image.width * scale)),
             max(1, round(image.height * scale))),
            Image.Resampling.LANCZOS,
        )
    array = np.asarray(image, dtype=np.float32) / 255.0
    height, width = array.shape[:2]

    level = min(max(int(request.get("resolution_level", 5)), 0), 9)
    num_tokens = int(MIN_TOKENS + level / 9.0 * (MAX_TOKENS - MIN_TOKENS))

    session = ort.InferenceSession(
        request["model"], providers=["CPUExecutionProvider"])
    input_names = {value.name for value in session.get_inputs()}
    output_names = {value.name for value in session.get_outputs()}
    scale_name = "metric_scale" if "metric_scale" in output_names else "scale"

    feed = {
        "image": np.ascontiguousarray(
            array.transpose(2, 0, 1)[None], dtype=np.float32),
        "num_tokens": np.asarray(num_tokens, dtype=np.int64),
    }
    if "image" not in input_names:
        raise RuntimeError(f"Unexpected model inputs: {sorted(input_names)}")
    values = session.run(
        ["points", "normal", "mask", scale_name], feed,
    )
    points, _normal, mask, metric_scale = values

    depth, validity, intrinsics = postprocess(
        points[0], mask[0], np.asarray(metric_scale).reshape(-1)[0],
        request["fov_x"],
    )
    alpha = np.asarray(framed, dtype=np.uint8)[..., 3]
    return depth, validity, intrinsics, (width, height), alpha


def main():
    request_path, output_path = sys.argv[1], sys.argv[2]
    with open(request_path, "r", encoding="utf-8") as handle:
        request = json.load(handle)
    depth, mask, intrinsics, size, alpha = run(request)
    np.savez_compressed(
        output_path,
        depth=depth,
        mask=mask,
        intrinsics=intrinsics,
        size=np.asarray(size, dtype=np.int32),
        alpha=alpha,
    )
    print("OK", depth.shape)


if __name__ == "__main__":
    main()
