# ====================== BEGIN GPL LICENSE BLOCK ======================
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ======================= END GPL LICENSE BLOCK ========================

bl_info = {
    "name": "Compify",
    "version": (3, 3, 1),
    "author": "Nathan Vegdahl, Ian Hubert",
    "blender": (4, 0, 0),
    "description": "Camera projection UV adjustment for 3D compositing.",
    "location": "3D Viewport > Sidebar",
    # "doc_url": "",
    "category": "Compositing",
}

import bpy
import json
import re

from . import translations

_ = bpy.app.translations.pgettext_iface
from .node_groups import (
    ensure_camera_project_group,
    check_camera_project_group_exists,
    find_object_by_data_name,
    find_objects_using_material,
    find_camera_connected_to_uv_adjust_in_material,
    scene_aspect_ratio,
    sync_camera_project_aspect,
)
from .node_group_manager import (
    get_all_uv_adjust_node_groups,
    clean_invalid_uv_adjust_node_groups,
    clean_orphan_uv_adjust_node_groups,
    update_uv_adjust_node_group_parameters,
    delete_uv_adjust_node_group,
    handle_object_rename_in_node_groups,
    get_node_group_usage_info,
    create_and_add_uv_adjust_node_group,
    refresh_uv_adjust_parameters_for_scene,
    invalidate_uv_cache,
    invalidate_uv_cache_on_load,
)
from .bake_pipeline import (
    bake_material_projection,
    ensure_bake_collection,
    move_object_to_collection,
)
from .bake_visibility import (
    summarize_visibility,
    visibility_issues,
)
from .properties import redraw_viewport
from . import compify_parallax_lock as plock
from . import blockout
from . import blockout_live
from . import panel_list
from .blockout_ui import (
    CompifyBlockoutGenerate,
    CompifyBlockoutGenerateDefault,
    CompifyBlockoutInstall,
    CompifyCancelBlockoutInstall,
    CompifyEnableBlockout,
    CompifyBlockoutMigrate,
    CompifyBlockoutPreferences,
    CompifyPurgeModels,
    CompifyBlockoutSelect,
    draw_blockout_section,
    projection_blocked_reason,
    register_properties as register_blockout_properties,
    unregister_properties as unregister_blockout_properties,
)
from .panel_shared import (
    SHOW_UPDATE_UV_ADJUST_BUTTON,
    set_fold_state as _set_fold_state,
)
from .panel_projections import CompifyPanelProjections
from .panel_models import CompifyPanelModels

# ========================================================
# Helper functions for common checks


_ASPECT_SIG_KEY = "compify_projection_aspect_sig"
_aspect_sync_guard = False


def _remove_handlers_by_name(handler_list, name):
    """Remove every handler with this name (reload-safe)."""
    removed = 0
    for handler in list(handler_list):
        if getattr(handler, "__name__", None) == name:
            try:
                handler_list.remove(handler)
                removed += 1
            except ValueError:
                pass
    return removed


def _ensure_handler(handler_list, handler):
    """Register exactly one instance of a handler.

    Comparing function objects is not enough: after a hot reload the module
    has a new function object while the old one is still in the handler list.
    Removing by name first prevents duplicate calls.
    """
    _remove_handlers_by_name(handler_list, handler.__name__)
    handler_list.append(handler)


@bpy.app.handlers.persistent
def sync_projection_aspect_handler(scene, *_args):
    """Keep projection nodes in sync with the scene's render aspect.

    Changing ``resolution_x/y`` or pixel aspect changes the normalized camera
    coordinates.  The shader and the UV Adjust offset/scale must both follow,
    otherwise the projection silently shifts or scales while every UI state
    still says "valid".
    """
    global _aspect_sync_guard
    if _aspect_sync_guard:
        return
    try:
        aspect = scene_aspect_ratio(scene)
        signature = "%.9f:%d:%d:%.9f:%.9f" % (
            aspect,
            int(scene.render.resolution_x),
            int(scene.render.resolution_y),
            float(scene.render.pixel_aspect_x),
            float(scene.render.pixel_aspect_y),
        )
        if scene.get(_ASPECT_SIG_KEY) == signature:
            return

        _aspect_sync_guard = True
        changed = sync_camera_project_aspect(scene, aspect)
        if changed:
            refresh_uv_adjust_parameters_for_scene(scene)
        # Only remember the signature after the whole update succeeded.  If
        # anything above raised, the old signature stays in place and the
        # handler retries on the next depsgraph update.
        scene[_ASPECT_SIG_KEY] = signature
    except Exception as e:
        print(f"Compify: Warning in aspect sync handler: {e}")
    finally:
        _aspect_sync_guard = False


# ========================================================


class CompifyUVAdjust3DPanel(bpy.types.Panel):
    """Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."""

    bl_label = "Compify"
    bl_idname = "VIEW3D_PT_compify_uv_adjust"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Compify"
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # ---- 分区 1：生成投射材质 ----
        box = layout.box()
        box.label(text="① 生成投射材质", icon="NODETREE")

        selected_meshes = [
            obj for obj in context.selected_objects if obj.type == "MESH"
        ]
        row = box.row()
        row.prop(scene, "compify_uv_adjust_camera", text="摄像机")

        blocked = projection_blocked_reason(context)
        row = box.row()
        row.operator(
            "compify.batch_generate_uv_adjust", text="为选中对象生成"
        )
        camera = scene.compify_uv_adjust_camera
        if not camera or camera.type != "CAMERA":
            row.enabled = False

        # One hint line per section: blocked reason only; the "done" banner was
        # removed, the status bar already reports a successful generation.
        if not selected_meshes:
            box.label(text="选中一张图平面", icon="INFO")
        elif blocked:
            box.label(text=blocked, icon="INFO")

        layout.separator()

        # ---- 分区 2：生成模型 ----
        box = layout.box()
        head2 = box.row(align=True)
        head2.label(text="② 生成模型", icon="SHADERFX")
        draw_blockout_section(box, context)

        layout.separator()

        layout.separator()

        # ---- 分区 3：烘焙 ----
        box = layout.box()
        box.label(text="③ 烘焙", icon="IMAGE_DATA")
        bake_candidates = [
            obj for obj in selected_meshes
            if obj.active_material is not None
            and blockout.projection_camera(obj) is not None
        ]
        if not selected_meshes:
            box.label(text="选中带投射的物体再烘焙", icon="INFO")
        row = box.row()
        row.scale_y = 1.3
        row.operator("compify.bake_selected",
                     text="烘焙选中对象", icon="IMAGE_DATA")
        if not bake_candidates:
            row.enabled = False


# ========================================================


class CompifyBatchGenerateUVAdjust(bpy.types.Operator):
    """Batch generate UV adjust node groups."""

    bl_label = "Batch Generate UV Adjust"
    bl_idname = "compify.batch_generate_uv_adjust"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return (projection_blocked_reason(context)
                or _("为选中的图平面生成投射材质"))

    @classmethod
    def poll(cls, context):
        return (
            context.scene.compify_uv_adjust_camera is not None
            and context.scene.compify_uv_adjust_camera.type == "CAMERA"
            and any(obj.type == "MESH" for obj in context.selected_objects)
        )

    def execute(self, context):
        camera = context.scene.compify_uv_adjust_camera
        scene = context.scene

        # Get all selected mesh objects
        selected_meshes = [
            obj for obj in context.selected_objects if obj.type == "MESH"
        ]

        if not selected_meshes:
            print("[Compify] No mesh objects selected")
            self.report({"WARNING"}, "还没选中任何网格对象")
            return {"CANCELLED"}

        # Check if camera projection node group exists, create if not
        camera_project_created = False
        if not check_camera_project_group_exists(camera):
            try:
                # Calculate aspect ratio from render settings
                aspect_ratio = scene_aspect_ratio(scene)

                # Automatically create camera projection node group
                ensure_camera_project_group(camera, aspect_ratio)
                camera_project_created = True

                self.report(
                    {"INFO"},
                    "已为摄像机「%s」自动创建投射节点组" % camera.name,
                )

            except Exception as e:
                print("[Compify] 创建摄像机投射节点组失败：%s" % (e,))
                self.report(
                    {"ERROR"},
                    "为摄像机「%s」创建投射节点组没成功，请再试一次"
                    % camera.name,
                )
                return {"CANCELLED"}

        success_count = 0
        failed_objects = []

        # Batch process all selected mesh objects
        material_success_count = 0
        for obj in selected_meshes:
            try:
                # Create the UV adjustment node group and add to material
                result = create_and_add_uv_adjust_node_group(scene, camera, obj)

                if result["success"]:
                    success_count += 1
                    if (
                        result["material_result"]
                        and result["material_result"]["success"]
                    ):
                        material_success_count += 1
                else:
                    failed_objects.append(f"{obj.name}: {result['message']}")
                    # Stop on first failure as requested
                    break

            except Exception as e:
                failed_objects.append(f"{obj.name}: {str(e)}")
                # Stop on first failure as requested
                break

        # Report results
        if failed_objects:
            print("[Compify] 生成投射失败：%s" % (failed_objects[0],))
            error_msg = "生成投射没成功，请再试一次"
            if success_count > 0:
                error_msg += "（失败前已成功 %d 个）" % success_count
            if camera_project_created:
                error_msg += "；投射节点组已创建"
            self.report({"ERROR"}, error_msg)
            return {"CANCELLED"}
        else:
            success_msg = "已为 %d 个图平面生成投射" % success_count
            if material_success_count:
                success_msg += "（其中 %d 个已自动接到材质）" % material_success_count
            if material_success_count < success_count:
                success_msg += "；%d 个需要在着色器编辑器里手动接线" % (
                    success_count - material_success_count)
            if camera_project_created:
                success_msg += "；同时为摄像机「%s」创建了投射节点组" % camera.name
            success_msg += " → 下一步去分区 2 生成模型"

            self.report({"INFO"}, success_msg)
            # Invalidate cache so panel picks up the new node groups
            invalidate_uv_cache(context.scene)
            # Redraw the 3D View panel to reflect new node groups
            redraw_viewport(context)
            return {"FINISHED"}


class CompifyOneClickSyncUVAdjust(bpy.types.Operator):
    """One-click sync UV adjust for all objects in this scene that still use a
    shared (old-scene) projection material, creating independent projections for them."""

    bl_label = "One-Click Sync Projections"
    bl_idname = "compify.one_click_sync_uv_adjust"
    bl_options = {"UNDO"}

    def _find_scene_camera_for_group(self, scene, group_info):
        """Find the camera in the current scene that was copied from the group's
        recorded camera (方案六: 按"复制关系"精准定位，不靠泛前缀).

        匹配规则：摄像机的 data 名 == 记录的旧 data 名，或以"旧 data 名 + '.'"开头。
        这样能精准命中复制场景产生的 Camera.001 / Camera.002，而排除名字相似
        但不相干的摄像机（如 Camera_Persp），避免配错。

        Args:
            scene: 当前场景
            group_info: UV Adjust 组的 info dict（含 camera_name = 记录的摄像机 data 名）

        Returns:
            bpy.types.Object | None: 匹配到的摄像机对象，找不到返回 None
        """
        try:
            cam_data_name = group_info.get("camera_name") or ""
            if not cam_data_name:
                return None
            # 精准匹配：复制出来的摄像机 data 名 = 旧名，或 旧名 + '.编号'
            # (FULL_COPY 复制场景时，复制的 datablock 名为 "旧名.001", "旧名.002"...)
            dot_prefix = cam_data_name + "."
            for cam in scene.objects:
                if cam.type != "CAMERA":
                    continue
                if not cam.data:
                    continue
                dn = cam.data.name
                if dn == cam_data_name or dn.startswith(dot_prefix):
                    return cam
            return None
        except Exception as e:
            print(f"Compify: Warning in _find_scene_camera_for_group: {e}")
            return None

    def execute(self, context):
        scene = context.scene
        # Invalidate cache so we get fresh scan results
        invalidate_uv_cache(scene)

        # Scan current scene for groups that belong to an old scene
        groups = get_all_uv_adjust_node_groups(scene)
        candidate_materials = set()
        for gi in groups:
            if gi.get("belongs_to_other_scene"):
                for mat_name in gi.get("materials", []):
                    candidate_materials.add(mat_name)

        if not candidate_materials:
            print("[Compify] English original: No old-scene shared projection materials found to sync.")
            self.report({"INFO"}, "没找到旧场景共享的投射材质，不用同步")
            return {"FINISHED"}

        # Collect objects in this scene that use those shared materials
        scene_obj_names = {o.name for o in scene.objects}
        sync_objs = []
        for mat_name in candidate_materials:
            for obj in find_objects_using_material(mat_name):
                if obj.name in scene_obj_names and obj.type == "MESH":
                    sync_objs.append(obj)

        if not sync_objs:
            print("[Compify] English original: No in-scene objects use the shared projection materials to sync.")
            self.report({"INFO"}, "场景里没有对象在用这些共享投射材质，不用同步")
            return {"FINISHED"}

        # For each object, find a camera in this scene (from the first old group)
        # and ensure the camera project node group exists, then create independent projection.
        camera = None
        for gi in groups:
            if gi.get("belongs_to_other_scene"):
                camera = self._find_scene_camera_for_group(scene, gi)
                if camera:
                    break

        if camera is None:
            print("[Compify] English original: Could not find a camera in this scene to sync projections.")
            self.report(
                {"WARNING"},
                "场景里没有可用于同步的摄像机，请先在 Compify 面板里指定一台",
            )
            return {"CANCELLED"}

        # Ensure the camera project node group exists for this camera
        if not check_camera_project_group_exists(camera):
            ensure_camera_project_group(
                camera, default_aspect=scene_aspect_ratio(scene))

        success_count = 0
        failed = []
        for obj in sync_objs:
            try:
                r = create_and_add_uv_adjust_node_group(scene, camera, obj)
                if r["success"]:
                    success_count += 1
                else:
                    failed.append(f"{obj.name}: {r['message']}")
            except Exception as e:
                failed.append(f"{obj.name}: {str(e)}")

        invalidate_uv_cache(scene)
        redraw_viewport(context)

        if failed:
            print("[Compify] English original: Synced {success_count} object(s). Failed: {len(failed)}")
            self.report(
                {"WARNING"},
                "已同步 %d 个对象，%d 个没成功" % (success_count, len(failed)),
            )
            return {"CANCELLED"}
        else:
            print("[Compify] English original: One-click sync complete: created independent projections.")
            self.report(
                {"INFO"},
                "一键同步完成：按摄像机「%s」为 %d 个对象建了独立投射"
                % (camera.name, success_count),
            )
            return {"FINISHED"}


class CompifyRefreshUVAdjustList(bpy.types.Operator):
    """Refresh UV Adjust node groups list and clean up invalid references"""

    bl_label = "Refresh & Clean UV Adjust List"
    bl_idname = "compify.refresh_uv_adjust_list"
    bl_options = {"UNDO"}

    _invalid_count = 0
    _other_scene_count = 0

    def invoke(self, context, event):
        """在真正执行前，若存在无效投影组则先弹确认框，防止误删。"""
        scene = context.scene
        groups = get_all_uv_adjust_node_groups(scene)
        _invalid = [
            g["node_group"].name for g in groups
            if g["materials"] and not g["is_valid"]
            and not g.get("belongs_to_other_scene")
        ]
        _other_scene = [
            g["node_group"].name for g in groups
            if g.get("belongs_to_other_scene")
        ]
        self._invalid_count = len(_invalid)
        self._other_scene_count = len(_other_scene)
        if _invalid:
            # 用 props dialog 弹一个带"你说人话"文案的确认框
            # 用户点"确定" → 走 execute（真正清理）；点"取消"/ESC → 停在 invoke，不删。
            return context.window_manager.invoke_props_dialog(self, width=420)
        return self.execute(context)

    def draw(self, context):
        """确认框的内容：说清楚删了会怎样。"""
        layout = self.layout
        col = layout.column()
        col.label(
            text=f"发现 {self._invalid_count} 个无效投射：",
            icon="ERROR",
        )
        col.separator()
        col.label(text="删除后，材质里对应的投射连接也会被断开。")
        col.label(text="常见原因：物体/摄像机被删除，或因场景复制/重名改名。")
        if self._other_scene_count:
            col.separator()
            col.label(
                text=f"另有 {self._other_scene_count} 个组属于其它场景，将保留不删。",
                icon="INFO",
            )
        col.separator()
        col.label(text="建议先检查原因再删除。确定继续吗？")

    def execute(self, context):
        try:
            # An aspect change invalidates both the Camera Project shader and
            # the UV Adjust offset/scale.  Refresh them before the list scan so
            # the panel and the clean-up logic see a consistent state.
            aspect_changed = sync_camera_project_aspect(context.scene)
            if aspect_changed:
                refresh_uv_adjust_parameters_for_scene(context.scene)

            # Handle object/camera renames first
            rename_result = handle_object_rename_in_node_groups(context.scene)

            # Clean up invalid node groups
            # 已被 invoke 的确认框拦截：用户点"确定"后 execute 才会走到这里。
            # 纯脚本调用时无确认框，直接清理；此处传 False 避免二次弹窗。
            cleaned_count = clean_invalid_uv_adjust_node_groups(
                context.scene, confirm=False)

            # Get current valid groups count
            valid_groups = [
                g for g in get_all_uv_adjust_node_groups(context.scene) if g["is_valid"]
            ]
            valid_count = len(valid_groups)

            # Build comprehensive report message
            messages = []

            if rename_result["updated"] > 0:
                messages.append(f"Updated {rename_result['updated']} node group names")

            if cleaned_count > 0:
                messages.append(f"Cleaned up {cleaned_count} invalid node groups")

            if rename_result["orphaned"] > 0:
                messages.append(
                    f"Found {rename_result['orphaned']} orphaned node groups"
                )

            other_scene_count = rename_result.get("other_scene", 0)
            if other_scene_count > 0:
                messages.append(
                    f"Kept {other_scene_count} node groups shared with other scenes"
                )

            if aspect_changed:
                messages.append(
                    f"Updated {aspect_changed} projection aspect input(s)"
                )

            messages.append(f"{valid_count} valid node groups remaining")

            # Determine report type based on actions taken
            report_type = {"INFO"}

            final_message = ". ".join(messages) + "."
            self.report(report_type, final_message)

            # Log details if there were significant changes
            if rename_result["details"] and (
                rename_result["updated"] > 0 or rename_result["orphaned"] > 0
            ):
                print("UV Adjust Node Groups Refresh Details:")
                for detail in rename_result["details"]:
                    print(f"  - {detail}")

            # Redraw the 3D View panel to reflect refreshed list
            redraw_viewport(context)

            invalidate_uv_cache(context.scene)
            return {"FINISHED"}

        except Exception as e:
            print("[Compify] 刷新投射列表失败：%s" % (e,))
            self.report({"ERROR"}, "刷新投射列表没成功，请再试一次")
            return {"CANCELLED"}


class CompifyToggleUVGroupFold(bpy.types.Operator):
    """Toggle the fold state of a camera group in the UI."""

    bl_label = "Toggle UV Group Fold"
    bl_idname = "compify.toggle_uv_group_fold"
    bl_options = {"INTERNAL"}

    camera_name: bpy.props.StringProperty()
    new_state: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        _set_fold_state(context.scene, self.camera_name, self.new_state)
        # Force UI redraw in 3D View
        redraw_viewport(context)
        return {"FINISHED"}


class CompifySelectUVAdjustObject(bpy.types.Operator):
    """Select the object associated with this UV adjust."""

    bl_label = "Select Object"
    bl_idname = "compify.select_uv_adjust_object"
    bl_options = {"UNDO"}

    object_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    @classmethod
    def description(cls, context, properties):
        return "选中 %s" % (properties.object_name or "这个物体")

    def execute(self, context):
        obj = find_object_by_data_name(self.object_name, type_filter="MESH")
        if obj and obj.name in context.scene.objects:
            if obj.name not in context.view_layer.objects:
                print("[Compify|UI] object excluded from view layer: %r"
                      % obj.name)
                self.report({"WARNING"}, "这个物体被当前视图层排除了")
                return {"CANCELLED"}
            # Deselect all objects
            bpy.ops.object.select_all(action="DESELECT")
            # Select and activate the target object
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({"INFO"}, "已选中：%s" % obj.name)
            return {"FINISHED"}
        print("[Compify|UI] object not found: %r" % self.object_name)
        self.report({"WARNING"},
                    "找不到这个物体「%s」，可能已被删除" % self.object_name)
        return {"CANCELLED"}


class CompifySelectMaterialObjects(bpy.types.Operator):
    """Select all objects using this material."""

    bl_label = "Select Material Objects"
    bl_idname = "compify.select_material_objects"
    bl_options = {"UNDO"}

    material_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    @classmethod
    def description(cls, context, properties):
        return "选中使用 %s 的全部对象" % (properties.material_name or "这个材质")

    def execute(self, context):
        material = bpy.data.materials.get(self.material_name)
        if not material:
            print("[Compify|UI] material not found: %r" % self.material_name)
            print("[Compify] English original: Material not found")
            self.report({"WARNING"},
                        "找不到这个材质「%s」，可能已被删除" % self.material_name)
            return {"CANCELLED"}

        # Find all objects using this material
        objects_with_material = []
        for obj in context.scene.objects:
            if obj.type == "MESH" and obj.data and obj.data.materials:
                for mat_slot in obj.material_slots:
                    if (
                        mat_slot.material
                        and mat_slot.material.name == self.material_name
                    ):
                        objects_with_material.append(obj)
                        break

        total_found = len(objects_with_material)
        objects_with_material = [
            obj for obj in objects_with_material
            if obj.name in context.view_layer.objects
        ]
        if not objects_with_material:
            if total_found:
                print("[Compify|UI] %d objects of %r excluded from view layer"
                      % (total_found, self.material_name))
                self.report({"WARNING"},
                            "用了这个材质的对象都不在当前视图层里")
            else:
                print("[Compify|UI] no objects use %r" % self.material_name)
                self.report({"WARNING"}, "没有对象用这个材质")
            return {"CANCELLED"}

        # Deselect all objects
        bpy.ops.object.select_all(action="DESELECT")

        # Select all objects using this material
        for obj in objects_with_material:
            obj.select_set(True)

        # Set the first one as active
        context.view_layer.objects.active = objects_with_material[0]

        if len(objects_with_material) == 1:
            self.report({"INFO"}, "已选中：%s" % objects_with_material[0].name)
        else:
            self.report({"INFO"}, "已选中 %d 个对象（材质 %s）"
                        % (len(objects_with_material), self.material_name))

        return {"FINISHED"}


class CompifySelectObjectByName(bpy.types.Operator):
    """Select a single object by its object name.

    Uses bpy.data.objects.get() — matches by object name, not
    data-block name. Unlike CompifySelectUVAdjustObject which
    searches by data name (suitable for copy/paste scenarios).
    """

    bl_label = "Select Object by Name"
    bl_idname = "compify.select_object_by_name"
    bl_options = {"UNDO"}

    object_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    @classmethod
    def description(cls, context, properties):
        return "选中 %s" % (properties.object_name or "这个物体")

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            print("[Compify|UI] object not found: %r" % self.object_name)
            self.report({"WARNING"},
                        "找不到这个物体「%s」，可能已被删除" % self.object_name)
            return {"CANCELLED"}
        if obj.name not in context.scene.objects:
            print("[Compify|UI] object not in scene: %r" % obj.name)
            self.report({"WARNING"}, "这个物体不在当前场景里")
            return {"CANCELLED"}
        if obj.name not in context.view_layer.objects:
            print("[Compify|UI] object excluded from view layer: %r" % obj.name)
            self.report({"WARNING"}, "这个物体被当前视图层排除了")
            return {"CANCELLED"}

        bpy.ops.object.select_all(action="DESELECT")
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({"INFO"}, "已选中：%s" % obj.name)
        return {"FINISHED"}


class CompifySelectUVAdjustCamera(bpy.types.Operator):
    """Select the camera associated with this UV adjust."""

    bl_label = "Select Camera"
    bl_idname = "compify.select_uv_adjust_camera"
    bl_options = {"UNDO"}

    camera_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    @classmethod
    def description(cls, context, properties):
        return "选中摄像机 %s" % (properties.camera_name or "")

    def execute(self, context):
        camera = find_object_by_data_name(self.camera_name, type_filter="CAMERA")
        if camera and camera.name in context.scene.objects and camera.type == "CAMERA":
            if camera.name not in context.view_layer.objects:
                print("[Compify|UI] camera excluded from view layer: %r"
                      % camera.name)
                self.report({"WARNING"}, "这台摄像机不在当前视图层里")
                return {"CANCELLED"}
            # Deselect all objects
            bpy.ops.object.select_all(action="DESELECT")
            # Select and activate the target camera
            camera.select_set(True)
            context.view_layer.objects.active = camera
            self.report({"INFO"}, "已选中摄像机：%s" % camera.name)
            return {"FINISHED"}
        print("[Compify|UI] camera not found: %r" % self.camera_name)
        self.report({"WARNING"},
                    "找不到这台摄像机「%s」，可能已被删除" % self.camera_name)
        return {"CANCELLED"}


class CompifyUpdateUVAdjust(bpy.types.Operator):
    """Update parameters of a UV Adjust node group"""

    bl_label = "Update UV Adjust"
    bl_idname = "compify.update_uv_adjust"
    bl_options = {"UNDO"}

    node_group_name: bpy.props.StringProperty()
    enabled: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        if not self.enabled:
            print("[Compify] English original: Cannot update: object or camera no longer exists")
            self.report({"WARNING"}, "没法更新：物体或摄像机已经不在了")
            return {"CANCELLED"}

        # Get the node group
        node_group = bpy.data.node_groups.get(self.node_group_name)
        if not node_group:
            print("[Compify] 找不到投射组：%s" % (self.node_group_name,))
            self.report({"ERROR"}, "这个投射组已经不在了，请刷新列表")
            return {"CANCELLED"}

        # Try to resolve object and camera intelligently (handling copy/paste cases)
        obj = None
        camera = None

        # Get usage info to find real connections
        usage_info = get_node_group_usage_info(node_group)
        materials = [info["material"] for info in usage_info]

        # Resolve Object
        for mat_name in materials:
            objs = find_objects_using_material(mat_name)
            if objs:
                obj = objs[0]
                break

        # Resolve Camera
        for mat_name in materials:
            mat = bpy.data.materials.get(mat_name)
            if mat:
                cam_obj = find_camera_connected_to_uv_adjust_in_material(
                    mat, node_group
                )
                if cam_obj:
                    camera = cam_obj
                    break

        # Fallback: Prefer metadata properties if resolution failed
        if not obj:
            object_data_name = node_group.get("compify_uv_object_data_name")
            if object_data_name:
                obj = find_object_by_data_name(object_data_name, type_filter="MESH")

        if not camera:
            camera_data_name = node_group.get("compify_uv_camera_data_name")
            if camera_data_name:
                camera = find_object_by_data_name(
                    camera_data_name, type_filter="CAMERA"
                )

        # Fallback: Parse node group name if metadata missing and resolution failed
        if (not obj or not camera) and " | " in node_group.name:
            parts = node_group.name.split(" | ")
            if len(parts) == 3:
                if not obj:
                    obj = find_object_by_data_name(parts[1], type_filter="MESH")
                if not camera:
                    camera = find_object_by_data_name(parts[2], type_filter="CAMERA")

        if not obj or obj.name not in context.scene.objects:
            print("[Compify] English original: Object for node group not found in scene")
            self.report(
                {"ERROR"},
                "找不到这个投射组对应的物体：%s" % node_group.name,
            )
            return {"CANCELLED"}

        if (
            not camera
            or camera.name not in context.scene.objects
            or camera.type != "CAMERA"
        ):
            print("[Compify] English original: Camera for node group not found in scene")
            self.report(
                {"ERROR"},
                "找不到这个投射组对应的摄像机：%s" % node_group.name,
            )
            return {"CANCELLED"}

        # Update metadata if resolved differently (fixes stale metadata)
        try:
            current_obj_data_name = (
                obj.data.name if getattr(obj, "data", None) else obj.name
            )
            if node_group.get("compify_uv_object_data_name") != current_obj_data_name:
                node_group["compify_uv_object_data_name"] = current_obj_data_name

            current_cam_data_name = (
                camera.data.name if getattr(camera, "data", None) else camera.name
            )
            if node_group.get("compify_uv_camera_data_name") != current_cam_data_name:
                node_group["compify_uv_camera_data_name"] = current_cam_data_name
        except Exception as e:
            print(
                f"Compify: Warning - failed to update metadata during UV adjust update: {e}"
            )

        # Update the node group parameters
        try:
            success = update_uv_adjust_node_group_parameters(
                node_group, obj, camera, context.scene
            )
            if success:
                print("[Compify] English original: Updated parameters for node group")
                self.report(
                    {"INFO"}, "已更新投射组参数：%s" % node_group.name
                )
                invalidate_uv_cache(context.scene)
                return {"FINISHED"}
            else:
                self.report({"ERROR"}, "更新参数没成功，请再试一次")
                return {"CANCELLED"}

        except Exception as e:
            print("[Compify] 更新投射组失败：%s" % (e,))
            self.report({"ERROR"}, "更新没成功，请再试一次")
            return {"CANCELLED"}


class CompifyDeleteUVAdjust(bpy.types.Operator):
    """Delete UV adjust."""

    bl_label = "Delete UV Adjust"
    bl_idname = "compify.delete_uv_adjust"
    bl_options = {"UNDO"}

    node_group_name: bpy.props.StringProperty()

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Get the node group
        node_group = bpy.data.node_groups.get(self.node_group_name)
        if not node_group:
            print("[Compify] 找不到投射组：%s" % (self.node_group_name,))
            self.report({"WARNING"}, "这个投射组已经不在了，请刷新列表")
            return {"CANCELLED"}

        # Delete the node group
        try:
            success = delete_uv_adjust_node_group(node_group)
            if success:
                print("[Compify] English original: Deleted node group")
                self.report({"INFO"}, "已删除投射组：%s" % self.node_group_name)
                invalidate_uv_cache(context.scene)
                return {"FINISHED"}
            else:
                self.report({"ERROR"}, "删除没成功，请再试一次")
                return {"CANCELLED"}

        except Exception as e:
            print("[Compify] 删除投射组失败：%s" % (e,))
            self.report({"ERROR"}, "删除没成功，请再试一次")
            return {"CANCELLED"}


class CompifyCleanOrphanUVAdjust(bpy.types.Operator):
    """Clean unused node groups."""

    bl_label = "Clean Unused Node Groups"
    bl_idname = "compify.clean_orphan_uv_adjust"
    bl_options = {"UNDO"}

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        try:
            cleaned_count = clean_orphan_uv_adjust_node_groups(context.scene)
            if cleaned_count > 0:
                print("[Compify] English original: Cleaned {cleaned_count} unused node groups")
                self.report({"INFO"}, "已清理 %d 个没用的投射组" % cleaned_count)
            else:
                print("[Compify] English original: No unused node groups to clean")
                self.report({"INFO"}, "没有需要清理的投射组")
            invalidate_uv_cache(context.scene)
            return {"FINISHED"}

        except Exception as e:
            print("[Compify] 清理投射组失败：%s" % (e,))
            self.report({"ERROR"}, "清理没成功，请再试一次")
            return {"CANCELLED"}




class CompifyToggleUnwrapObject(bpy.types.Operator):
    """Toggle UV unwrap for a specific object in the bake dialog."""

    bl_label = "Toggle Object Unwrap"
    bl_idname = "compify.toggle_unwrap_object"
    bl_options = {"INTERNAL"}

    object_name: bpy.props.StringProperty()

    def execute(self, context):
        try:
            overrides = json.loads(
                context.scene.compify_bake_unwrap_overrides)
        except (json.JSONDecodeError, TypeError):
            overrides = {}

        obj_state = overrides.get(self.object_name)
        if obj_state and not obj_state.get("forced"):
            obj_state["skip"] = not obj_state.get("skip", False)
            overrides[self.object_name] = obj_state

        context.scene.compify_bake_unwrap_overrides = json.dumps(overrides)

        redraw_viewport(context)
        return {"FINISHED"}



def next_bake_index(base):
    """Next free 原名_bake_N, continuing the series instead of ".001"."""
    pattern = re.compile(r"^%s_bake_(\d+)$" % re.escape(base))
    highest = 0
    for other in bpy.data.objects:
        match = pattern.match(other.name)
        if match:
            highest = max(highest, int(match.group(1)))
    return highest + 1


class CompifyBakeSelected(bpy.types.Operator):
    """烘焙选中对象的投射：产物进「烘焙产物」集合，原网格自动隐藏"""

    bl_idname = "compify.bake_selected"
    bl_label = "烘焙选中对象"
    bl_options = {"REGISTER", "UNDO"}

    overwrite: bpy.props.BoolProperty(
        name="覆盖同名产物", default=False,
        description="默认新建一份；勾选后先删除同名产物再烘焙")
    resolution: bpy.props.EnumProperty(
        name="分辨率",
        items=(("1024", "1024", "烘焙贴图 1024×1024"),
               ("2048", "2048", "烘焙贴图 2048×2048"),
               ("4096", "4096", "烘焙贴图 4096×4096")),
        default="2048",
        description="烘焙贴图边长；默认取偏好设置里的值")
    auto_unwrap: bpy.props.BoolProperty(
        name="自动展开 UV",
        default=True,
        description="已有 UV 的对象也重新展开，避免重叠")
    angle_limit: bpy.props.IntProperty(
        name="角度阈值", default=66, min=0, max=89, subtype="ANGLE",
        description="智能 UV 投影的角度上限")
    island_margin: bpy.props.FloatProperty(
        name="UV 岛间距", default=0.0, min=0.0, max=1.0, subtype="FACTOR",
        description="UV 岛之间留出的空隙")
    area_weight: bpy.props.FloatProperty(
        name="面积权重", default=0.0, min=0.0, max=1.0, subtype="FACTOR",
        description="越大越优先照顾面积大的面")
    correct_aspect: bpy.props.BoolProperty(
        name="修正纵横比", default=False,
        description="按像素纵横比修正，避免拉伸")
    scale_to_bounds: bpy.props.BoolProperty(
        name="缩放适配边界", default=True,
        description="把 UV 岛缩放到 0–1 范围内")

    @classmethod
    def poll(cls, context):
        return any(obj.type == "MESH" and obj.active_material is not None
                   for obj in context.selected_objects)

    def _meshes(self, context):
        return [obj for obj in context.selected_objects if obj.type == "MESH"]

    def _precheck(self, context):
        meshes = self._meshes(context)
        if not meshes:
            return "请先选中带投射的物体"
        for obj in meshes:
            if blockout.projection_camera(obj) is None:
                return "「%s」没有投射材质，请先到分区 1 生成投射" % obj.name
            if obj.data.uv_layers.active is None:
                return "「%s」没有 UV，烘焙前需要先展开 UV" % obj.name
        return ""

    def _collision(self, context):
        for obj in self._meshes(context):
            prefix = "%s_bake_" % obj.name
            if any(other.name.startswith(prefix) for other in bpy.data.objects):
                return True
        return False

    def invoke(self, context, event):
        reason = self._precheck(context)
        if reason:
            self.report({"ERROR"}, reason)
            return {"CANCELLED"}
        # Always confirm first: baking writes new objects and takes time.
        cfg = context.scene.compify_config
        self.resolution = str(min((1024, 2048, 4096),
                                  key=lambda v: abs(v - int(cfg.bake_image_res))))
        self.auto_unwrap = bool(cfg.bake_dialog_auto_unwrap)
        self.angle_limit = int(cfg.bake_dialog_angle_limit)
        self.island_margin = float(cfg.bake_dialog_island_margin)
        self.area_weight = float(cfg.bake_dialog_area_weight)
        self.correct_aspect = bool(cfg.bake_dialog_correct_aspect)
        self.scale_to_bounds = bool(cfg.bake_dialog_scale_to_bounds)
        return context.window_manager.invoke_props_dialog(
            self, width=440, confirm_text="烘焙")

    def draw(self, context):
        layout = self.layout
        layout.label(text="将烘焙 %d 个对象" % len(self._meshes(context)),
                     icon="IMAGE_DATA")
        layout.prop(self, "resolution")
        layout.prop(self, "auto_unwrap")
        if self.auto_unwrap:
            uv_box = layout.box()
            uv_box.label(text="UV 展开设置", icon="UV")
            uv_box.prop(self, "angle_limit")
            uv_box.prop(self, "island_margin")
            uv_box.prop(self, "area_weight")
            uv_box.prop(self, "correct_aspect")
            uv_box.prop(self, "scale_to_bounds")
        if self._collision(context):
            layout.label(text="已有同名产物；勾选覆盖会先删旧的", icon="INFO")
        layout.prop(self, "overwrite")

    def execute(self, context):
        reason = self._precheck(context)
        if reason:
            self.report({"ERROR"}, reason)
            return {"CANCELLED"}
        cfg = context.scene.compify_config
        cfg.bake_image_res = int(self.resolution)
        cfg.bake_dialog_auto_unwrap = bool(self.auto_unwrap)
        cfg.bake_dialog_angle_limit = int(self.angle_limit)
        cfg.bake_dialog_island_margin = float(self.island_margin)
        cfg.bake_dialog_area_weight = float(self.area_weight)
        cfg.bake_dialog_correct_aspect = bool(self.correct_aspect)
        cfg.bake_dialog_scale_to_bounds = bool(self.scale_to_bounds)
        meshes = self._meshes(context)
        if self.overwrite:
            for obj in meshes:
                prefix = "%s_bake_" % obj.name
                for existing in [o for o in bpy.data.objects
                                 if o.name.startswith(prefix)]:
                    bpy.data.objects.remove(existing, do_unlink=True)

        try:
            overrides = json.loads(
                context.scene.compify_bake_unwrap_overrides)
        except (json.JSONDecodeError, TypeError):
            overrides = {}
        skip_names = {
            name for name, state in overrides.items()
            if state.get("skip") and not state.get("forced")
        }

        # One bake per selected object, filtered by object name: a material
        # shared with unselected objects must not drag them in.
        collection = ensure_bake_collection(context.scene)
        baked, failed, created = [], [], []
        prefs = context.preferences.edit
        had_global_undo = prefs.use_global_undo
        # Inner calls (modifier apply, the bake itself) would otherwise add
        # their own undo steps; switching them off leaves this operator as the
        # single step Ctrl+Z returns from.
        prefs.use_global_undo = False
        try:
            for obj in meshes:
                material = obj.active_material
                if material is None:
                    failed.append(obj.name)
                    continue
                before = set(bpy.data.objects)
                try:
                    result = bake_material_projection(
                        scene=context.scene,
                        material=material,
                        bake_resolution=int(self.resolution),
                        auto_unwrap=bool(self.auto_unwrap),
                        skip_unwrap_names=skip_names,
                        angle_limit=int(self.angle_limit),
                        island_margin=float(self.island_margin),
                        area_weight=float(self.area_weight),
                        correct_aspect=bool(self.correct_aspect),
                        scale_to_bounds=bool(self.scale_to_bounds),
                        operator=self,
                        object_filter={obj.name},
                    )
                except Exception as error:  # noqa: BLE001
                    print("[Compify] 烘焙「%s」失败：%s" % (obj.name, error))
                    result = None
                fresh = [o for o in bpy.data.objects if o not in before]
                for new_obj in fresh:
                    move_object_to_collection(new_obj, collection)
                    base = new_obj.name.split(".")[0]
                    new_obj.name = "%s_bake_%d" % (
                        base, next_bake_index(base))
                created.extend(fresh)
                if result and result.get("success"):
                    baked.append(obj)
                    obj.hide_set(True)
                    obj.hide_render = True
                else:
                    failed.append(obj.name)
        finally:
            prefs.use_global_undo = had_global_undo

        if not created and not baked:
            note = ("烘焙没有成功（%d 个对象都没烘出结果）" % len(failed)
                    if failed else "烘焙没有产生任何对象")
            self.report({"ERROR"}, note)
            return {"CANCELLED"}
        if baked:
            note = ("已烘焙 %d 个对象；原网格已隐藏，Alt+H 可恢复"
                    % len(baked))
            if failed:
                note = ("已烘焙 %d 个，失败 %d 个；原网格已隐藏，"
                        "Alt+H 可恢复" % (len(baked), len(failed)))
        else:
            note = "烘焙没有成功（%d 个对象都没烘出结果）" % len(failed)
        self.report({"INFO"} if baked else {"ERROR"}, note)
        return {"FINISHED"} if baked else {"CANCELLED"}


class CompifyBakeMaterialProjection(bpy.types.Operator):
    """Bake camera projection to textures for new objects."""

    bl_label = "Bake Material Projection"
    bl_idname = "compify.bake_material_projection"
    bl_description = (
        "Bake camera projection, creating new objects with baked textures")
    bl_options = {"UNDO"}

    material_name: bpy.props.StringProperty(options={"HIDDEN"})
    object_name: bpy.props.StringProperty(
        name="Object Name",
        default="",
        options={"HIDDEN", "SKIP_SAVE"},
        description="If set, only bake this specific object instead of all",
    )
    bake_resolution: bpy.props.IntProperty(
        name="Resolution",
        default=2048,
        min=64,
        max=8192,
        subtype="PIXEL",
        description="Bake texture resolution in pixels",
    )

    auto_unwrap: bpy.props.BoolProperty(
        name="Auto-unwrap UV",
        default=True,
        description=(
            "Automatically unwrap UV for objects with existing UV layers"),
    )
    smart_angle_limit: bpy.props.IntProperty(
        name="Angle Limit",
        default=66,
        min=0,
        max=89,
        subtype="ANGLE",
        description="Angle limit for Smart UV Project",
    )
    smart_island_margin: bpy.props.FloatProperty(
        name="Island Margin",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        description="Island margin for Smart UV Project",
    )
    smart_area_weight: bpy.props.FloatProperty(
        name="Area Weight",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        description="Weight UV faces by area, higher values favor larger faces",
    )
    smart_correct_aspect: bpy.props.BoolProperty(
        name="Correct Aspect",
        default=False,
        description="Correct aspect ratio to avoid UV stretching",
    )
    smart_scale_to_bounds: bpy.props.BoolProperty(
        name="Scale to Bounds",
        default=True,
        description="Scale UV islands to fit within 0-1 bounds",
    )

    def invoke(self, context, event):
        # Validate material
        material = bpy.data.materials.get(self.material_name)
        if not material:
            print("[Compify] English original: Material not found")
            self.report({"ERROR"}, "找不到这个材质，可能已被删除")
            return {"CANCELLED"}

        # Validate Camera Project node exists
        camera_found = False
        if material.node_tree:
            for node in material.node_tree.nodes:
                if (node.type == "GROUP" and node.node_tree
                        and node.node_tree.name.startswith(
                            "Camera Project |")):
                    camera_found = True
                    break

        if not camera_found:
            print("[Compify] English original: Material has no Camera Project node group.")
            self.report(
                {"ERROR"},
                "这个材质里还没有投射节点组，请先点「为选中对象生成」")
            return {"CANCELLED"}

        # Validate objects exist
        self.affected_objects = find_objects_using_material(
            self.material_name)
        scene_objects = set(context.scene.objects)
        self.affected_objects = [
            obj for obj in self.affected_objects if obj in scene_objects]
        if not self.affected_objects:
            print("[Compify] English original: No objects in the scene use this material")
            self.report(
                {"ERROR"},
                "场景里没有对象用这个材质")
            return {"CANCELLED"}

        # Single-object filter
        if self.object_name:
            self.affected_objects = [
                o for o in self.affected_objects
                if o.name == self.object_name
            ]
            if not self.affected_objects:
                print("[Compify] English original: Object not found in material's users")
                self.report(
                    {"ERROR"},
                    "用这个材质的对象里找不到「%s」" % self.object_name)
                return {"CANCELLED"}

        # Detect UV status
        self.has_uv_count = 0
        self.no_uv_count = 0
        self.mesh_count = 0
        for obj in self.affected_objects:
            if obj.type == 'MESH':
                self.mesh_count += 1
                if obj.data.uv_layers.active:
                    self.has_uv_count += 1
                else:
                    self.no_uv_count += 1

        # Default settings from scene config (persisted across dialog opens)
        cfg = context.scene.compify_config
        self.bake_resolution = cfg.bake_image_res
        self.auto_unwrap = cfg.bake_dialog_auto_unwrap
        self.smart_angle_limit = cfg.bake_dialog_angle_limit
        self.smart_island_margin = cfg.bake_dialog_island_margin
        self.smart_area_weight = cfg.bake_dialog_area_weight
        self.smart_correct_aspect = cfg.bake_dialog_correct_aspect
        self.smart_scale_to_bounds = cfg.bake_dialog_scale_to_bounds

        # Initialize per-object unwrap overrides
        overrides = {}
        for obj in self.affected_objects:
            if obj.type == 'MESH':
                has_uv = bool(obj.data.uv_layers.active)
                overrides[obj.name] = {
                    "skip": False,
                    "forced": not has_uv
                }
        context.scene.compify_bake_unwrap_overrides = json.dumps(overrides)

        # The dialog title is the operator's raw bl_label; pass an explicitly
        # translated title so it follows the same language as the dialog body.
        wm = context.window_manager
        try:
            return wm.invoke_props_dialog(
                self, width=420,
                title=_("Bake Material Projection"),
                translate=False)
        except TypeError:
            # Blender versions without the title/translate arguments.
            try:
                return wm.invoke_props_dialog(
                    self, width=420,
                    title=_("Bake Material Projection"))
            except TypeError:
                return wm.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        material = bpy.data.materials.get(self.material_name)

        # Info box
        box = layout.box()
        if material:
            box.label(
                text=_("Material:  {}").format(material.name),
                icon="MATERIAL")
        if self.object_name:
            box.label(
                text=_("Scope: Single object '{}'").format(self.object_name),
                icon="MESH_DATA")
        elif self.affected_objects:
            box.label(
                text=_("Scope: All material users ({})").format(
                    self.mesh_count),
                icon="MESH_DATA")
            box.label(
                text=_("Not the viewport selection."),
                icon="INFO")
            box.label(
                text=_("Will create: {} new object(s)").format(
                    self.mesh_count),
                icon="OBJECT_DATA")
            non_mesh = len(self.affected_objects) - self.mesh_count
            if non_mesh > 0:
                box.label(
                    text=_("({} non-mesh will be skipped)").format(non_mesh),
                    icon="INFO")

        summary = summarize_visibility(
            self.affected_objects, context.view_layer)
        if summary["with_issues"] or summary["no_uv"]:
            check_box = layout.box()
            check_box.label(text=_("Bake check"), icon="INFO")
            if summary["not_in_view_layer"]:
                check_box.label(
                    text=_("{} excluded from the current view layer").format(
                        summary["not_in_view_layer"]),
                    icon="HIDE_ON")
            if summary["hide_viewport"]:
                check_box.label(
                    text=_("{} hidden in the viewport").format(
                        summary["hide_viewport"]),
                    icon="HIDE_ON")
            if summary["hide_render"]:
                check_box.label(
                    text=_("{} hidden from render").format(
                        summary["hide_render"]),
                    icon="HIDE_ON")
            if summary["hide_select"]:
                check_box.label(
                    text=_("{} not selectable").format(
                        summary["hide_select"]),
                    icon="RESTRICT_SELECT_ON")
            if summary["with_issues"]:
                check_box.label(
                    text=_("Bake copies are shown temporarily;"
                           " originals stay unchanged."))
            if summary["no_uv"]:
                check_box.label(
                    text=_("{} missing UV will be auto-unwrapped").format(
                        summary["no_uv"]),
                    icon="ERROR")

        layout.separator()

        # Resolution selector
        layout.prop(self, "bake_resolution", text=_("Resolution"))

        layout.separator()

        # UV handling section
        uv_box = layout.box()
        uv_box.label(text=_("UV Handling"), icon="UV")

        if self.mesh_count == 0:
            uv_box.label(text=_("No mesh objects found"), icon="INFO")
        else:
            uv_box.prop(self, "auto_unwrap", text=_("Auto-unwrap UV"))

            # Smart Project settings (visible when auto_unwrap is checked)
            if self.auto_unwrap:
                sp_box = uv_box.box()
                sp_box.label(
                    text=_("Smart UV Project Settings"), icon="MODIFIER")
                sp_box.prop(
                    self, "smart_angle_limit", text=_("Angle Limit"))
                sp_box.prop(
                    self, "smart_island_margin", text=_("Island Margin"))
                sp_box.prop(
                    self, "smart_area_weight", text=_("Area Weight"))
                sp_box.prop(
                    self, "smart_correct_aspect", text=_("Correct Aspect"))
                sp_box.prop(
                    self, "smart_scale_to_bounds", text=_("Scale to Bounds"))

            # Per-object UV override list
            try:
                overrides = json.loads(
                    context.scene.compify_bake_unwrap_overrides)
            except (json.JSONDecodeError, TypeError):
                overrides = {}

            if overrides:
                obj_box = uv_box.box()
                obj_box.label(
                    text=_("Objects ({}):").format(self.mesh_count),
                    icon="MESH_DATA")

                for obj_name, state in overrides.items():
                    if state.get("forced"):
                        obj_box.label(
                            text=_("  {}  [NO UV - forced]").format(obj_name),
                            icon="ERROR")
                    else:
                        row = obj_box.row()
                        row.label(text=f"  {obj_name}")
                        toggle = row.operator(
                            "compify.toggle_unwrap_object",
                            text=(_("Unwrap") if not state.get("skip")
                                  else _("Keep UV")),
                            icon="UNLOCKED" if not state.get("skip") else "LOCKED",
                            emboss=True,
                        )
                        toggle.object_name = obj_name

        layout.separator()

        # Safety notice
        note = layout.box()
        note.label(
            text=_("Original objects will NOT be modified."), icon="INFO")
        note.label(
            text=_("A new object with baked texture will be created"
                   " for each."))

    def execute(self, context):
        material = bpy.data.materials.get(self.material_name)
        if not material:
            self.report(
                {"ERROR"},
                "找不到这个材质「%s」" % self.material_name)
            return {"CANCELLED"}

        try:
            overrides = json.loads(
                context.scene.compify_bake_unwrap_overrides)
        except (json.JSONDecodeError, TypeError):
            overrides = {}
        skip_names = {
            name for name, state in overrides.items()
            if state.get("skip") and not state.get("forced")
        }

        result = bake_material_projection(
            scene=context.scene,
            material=material,
            bake_resolution=self.bake_resolution,
            auto_unwrap=self.auto_unwrap,
            skip_unwrap_names=skip_names,
            angle_limit=self.smart_angle_limit,
            island_margin=self.smart_island_margin,
            area_weight=self.smart_area_weight,
            correct_aspect=self.smart_correct_aspect,
            scale_to_bounds=self.smart_scale_to_bounds,
            operator=self,
            object_filter={self.object_name} if self.object_name else None,
        )

        # Save dialog settings to scene config (remember for next open)
        cfg = context.scene.compify_config
        cfg.bake_image_res = self.bake_resolution
        cfg.bake_dialog_auto_unwrap = self.auto_unwrap
        cfg.bake_dialog_angle_limit = self.smart_angle_limit
        cfg.bake_dialog_island_margin = self.smart_island_margin
        cfg.bake_dialog_area_weight = self.smart_area_weight
        cfg.bake_dialog_correct_aspect = self.smart_correct_aspect
        cfg.bake_dialog_scale_to_bounds = self.smart_scale_to_bounds

        if result["success"]:
            count = len(result["baked_objects"])
            mat_name = (result["baked_material"].name
                        if result["baked_material"] else "N/A")

            msg_parts = [
                _("Baked {} object(s). New material: '{}'").format(
                    count, mat_name)
            ]
            if result.get("unwrapped_count"):
                msg_parts.append(
                    _("UV unwrapped: {}").format(
                        result["unwrapped_count"]))
            if result.get("forced_unwrap_count"):
                msg_parts.append(
                    _("UV forced unwrap: {}").format(
                        result["forced_unwrap_count"]))
            self.report({"INFO"}, " | ".join(msg_parts))

            redraw_viewport(context)
            return {"FINISHED"}
        else:
            self.report({"ERROR"}, result["message"])
            return {"CANCELLED"}


# ========================================================


class CompifyParallaxLockToggle(bpy.types.Operator):
    """锁定/解锁：摄像机移动时网格逐顶点适配视锥体（保持实拍投射与网格的贴合）"""

    bl_label = "Parallax Lock"
    bl_idname = "compify.parallax_lock_toggle"
    bl_options = {"UNDO"}

    camera_name: bpy.props.StringProperty()
    apply_adjustable: bpy.props.BoolProperty(
        name="应用并继续", default=True,
        description="先应用模型的可调修改器，再参与视差锁定")

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        scene = context.scene
        camera = find_object_by_data_name(self.camera_name, type_filter="CAMERA")
        if camera is None or camera.name not in scene.objects:
            print("[Compify] Camera not found: %s" % self.camera_name)
            self.report({"WARNING"}, "找不到这台摄像机「%s」" % self.camera_name)
            return {"CANCELLED"}
        if plock.is_locked(scene, camera):
            res = plock.unlock_group(scene, camera)
        else:
            res = plock.lock_group(scene, camera)
        if not res["success"]:
            self.report({"ERROR"}, res["message"])
            return {"CANCELLED"}
        msg = res["message"]
        if res.get("skipped"):
            msg += " | 跳过: " + ", ".join("%s(%s)" % (o.name, r) for o, r in res["skipped"])
            self.report({"WARNING"}, msg)
        else:
            self.report({"INFO"}, msg)
        redraw_viewport(context)
        return {"FINISHED"}


class CompifyParallaxReset(bpy.types.Operator):
    """重置：把网格还原到锁定前的形状"""

    bl_label = "Reset Parallax Lock"
    bl_idname = "compify.parallax_lock_reset"
    bl_options = {"UNDO"}

    camera_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        scene = context.scene
        camera = find_object_by_data_name(self.camera_name, type_filter="CAMERA")
        # 与 toggle 保持同一判据：摄像机必须真的在当前场景里（find_ 是全局搜索）
        if camera is None or camera.name not in scene.objects:
            print("[Compify] Camera not found: %s" % self.camera_name)
            self.report({"WARNING"}, "找不到这台摄像机「%s」" % self.camera_name)
            return {"CANCELLED"}
        res = plock.reset_group(scene, camera)
        if not res["success"]:
            self.report({"WARNING"}, res["message"])
            return {"CANCELLED"}
        self.report({"INFO"}, res["message"])
        redraw_viewport(context)
        return {"FINISHED"}


class CompifyParallaxResetOrphans(bpy.types.Operator):
    """还原「摄像机已不存在」的残留锁定网格。

    ⚠️ 独立审查 第六轮 🔴-1：换摄像机数据块 / 删摄像机对象后，锁定痕迹留在网格上，
       而所有按摄像机身份查找的入口（面板按钮、reset operator）全部失联 ——
       原形就在网格上，却没有任何 UI 能触发还原（不可逆）。本 operator 不依赖
       摄像机身份，是那条路径**唯一**的出口。
    """
    bl_idname = "compify.parallax_reset_orphans"
    bl_label = "Reset Orphan Parallax Locks"
    bl_description = "还原所有「所属摄像机已不存在」的残留锁定网格（几何回到原形 + 清除插件痕迹）"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        res = plock.reset_orphan_locks(context.scene)
        if not res.get("success"):
            self.report({"INFO"}, res.get("message", "没有发现残留锁定痕迹"))
            return {"CANCELLED"}
        self.report({"INFO"}, res["message"])
        redraw_viewport(context)
        return {"FINISHED"}


class CompifyBakeConfig(bpy.types.PropertyGroup):
    """烘焙投影对话框的持久化设置（③ Camera Project UV Adjust 用）。

    原 CompifyFootageConfig 精简拆分：footage 相关字段随 ① 素材工作流删除，
    仅保留烘焙对话框需要的 7 项。
    """
    bake_image_res: bpy.props.IntProperty(
        name="Bake Resolution",
        subtype="PIXEL",
        options=set(),
        default=4096,
        min=64,
        max=2**16,
        soft_max=8192,
    )
    bake_dialog_auto_unwrap: bpy.props.BoolProperty(
        name="Auto-unwrap UV",
        default=True,
    )
    bake_dialog_angle_limit: bpy.props.IntProperty(
        default=66, min=0, max=89, subtype="ANGLE",
    )
    bake_dialog_island_margin: bpy.props.FloatProperty(
        default=0.0, min=0.0, max=1.0, subtype="FACTOR",
    )
    bake_dialog_area_weight: bpy.props.FloatProperty(
        default=0.0, min=0.0, max=1.0, subtype="FACTOR",
    )
    bake_dialog_correct_aspect: bpy.props.BoolProperty(default=False)
    bake_dialog_scale_to_bounds: bpy.props.BoolProperty(default=True)


def register():
    bpy.utils.register_class(CompifyUVAdjust3DPanel)
    bpy.utils.register_class(CompifyPanelProjections)
    bpy.utils.register_class(CompifyPanelModels)
    bpy.utils.register_class(CompifyBatchGenerateUVAdjust)
    bpy.utils.register_class(CompifyRefreshUVAdjustList)
    bpy.utils.register_class(CompifyToggleUVGroupFold)
    bpy.utils.register_class(CompifySelectUVAdjustObject)
    bpy.utils.register_class(CompifySelectMaterialObjects)
    bpy.utils.register_class(CompifySelectObjectByName)
    bpy.utils.register_class(CompifySelectUVAdjustCamera)
    bpy.utils.register_class(CompifyUpdateUVAdjust)
    bpy.utils.register_class(CompifyDeleteUVAdjust)
    bpy.utils.register_class(CompifyCleanOrphanUVAdjust)
    bpy.utils.register_class(CompifyToggleUnwrapObject)
    bpy.utils.register_class(CompifyBakeMaterialProjection)
    bpy.utils.register_class(CompifyBakeSelected)
    bpy.utils.register_class(CompifyOneClickSyncUVAdjust)
    bpy.utils.register_class(CompifyParallaxLockToggle)
    bpy.utils.register_class(CompifyParallaxReset)
    bpy.utils.register_class(CompifyParallaxResetOrphans)
    bpy.utils.register_class(CompifyBakeConfig)
    bpy.utils.register_class(blockout_live.BlockoutSettings)
    bpy.types.Object.compify_blockout = bpy.props.PointerProperty(
        type=blockout_live.BlockoutSettings)
    bpy.utils.register_class(CompifyBlockoutGenerate)
    bpy.utils.register_class(CompifyBlockoutGenerateDefault)
    for cls in panel_list.CLASSES:
        bpy.utils.register_class(cls)
    bpy.utils.register_class(CompifyBlockoutMigrate)
    register_blockout_properties()
    bpy.utils.register_class(CompifyBlockoutSelect)
    bpy.utils.register_class(CompifyBlockoutInstall)
    bpy.utils.register_class(CompifyCancelBlockoutInstall)
    bpy.utils.register_class(CompifyEnableBlockout)
    bpy.utils.register_class(CompifyPurgeModels)
    # AddonPreferences only registers when Blender has the add-on registered;
    # in a bare module load it raises, and the feature falls back to defaults.
    try:
        bpy.utils.register_class(CompifyBlockoutPreferences)
    except Exception as _prefs_error:  # noqa: BLE001
        print("[Compify] blockout preferences unavailable:", _prefs_error)
    plock.register_handlers()
    _ensure_handler(
        bpy.app.handlers.depsgraph_update_post,
        sync_projection_aspect_handler)

    # Custom properties.
    bpy.types.Scene.compify_config = bpy.props.PointerProperty(
        type=CompifyBakeConfig
    )
    bpy.types.Scene.compify_uv_adjust_camera = bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="UV Adjust Camera",
        description="Camera to use for UV adjustment calculations",
        poll=lambda scene, obj: obj.type == "CAMERA",
    )
    bpy.types.Scene.compify_uv_group_fold_states = bpy.props.StringProperty(
        name="Compify UV Group Fold States",
        description="JSON storage for UV group fold states",
        default="{}",
    )
    bpy.types.Scene.compify_bake_unwrap_overrides = bpy.props.StringProperty(
        name="Bake Unwrap Overrides",
        description="JSON storage for per-object unwrap toggles",
        default="{}",
    )

    # Register translations (pass plugin root module name)
    translations.register(__name__)

    # 换文件之后清掉 UV 缓存（缓存里只存名字，存在各场景自己的 ID 属性上，
    # 这个 handler 只是再把它们抹一遍，兜住"同一文件被重新读入"等情况）。
    # handler 本身上面加了 @bpy.app.handlers.persistent —— 不加的话，
    # Blender 读新文件时会把它从 load_post 列表里一并清掉。
    _ensure_handler(bpy.app.handlers.load_post, invalidate_uv_cache_on_load)

    # 老安装没有依赖标记：后台探一次（不在 draw 里起子进程）。
    try:
        bpy.app.timers.register(blockout.verify_deps_in_background,
                                first_interval=1.5)
    except Exception:  # noqa: BLE001
        pass



def unregister():
    # Unregister translations first (must use same domain)
    translations.unregister(__name__)

    bpy.utils.unregister_class(CompifyUVAdjust3DPanel)
    bpy.utils.unregister_class(CompifyPanelProjections)
    bpy.utils.unregister_class(CompifyPanelModels)
    bpy.utils.unregister_class(CompifyBatchGenerateUVAdjust)
    bpy.utils.unregister_class(CompifyRefreshUVAdjustList)
    bpy.utils.unregister_class(CompifyToggleUVGroupFold)
    bpy.utils.unregister_class(CompifySelectUVAdjustObject)
    bpy.utils.unregister_class(CompifySelectMaterialObjects)
    bpy.utils.unregister_class(CompifySelectObjectByName)
    bpy.utils.unregister_class(CompifySelectUVAdjustCamera)
    bpy.utils.unregister_class(CompifyUpdateUVAdjust)
    bpy.utils.unregister_class(CompifyDeleteUVAdjust)
    bpy.utils.unregister_class(CompifyCleanOrphanUVAdjust)
    bpy.utils.unregister_class(CompifyBakeSelected)
    bpy.utils.unregister_class(CompifyBakeMaterialProjection)
    bpy.utils.unregister_class(CompifyToggleUnwrapObject)
    bpy.utils.unregister_class(CompifyOneClickSyncUVAdjust)
    bpy.utils.unregister_class(CompifyParallaxLockToggle)
    bpy.utils.unregister_class(CompifyParallaxReset)
    bpy.utils.unregister_class(CompifyParallaxResetOrphans)
    bpy.utils.unregister_class(CompifyBakeConfig)
    bpy.utils.unregister_class(CompifyEnableBlockout)
    bpy.utils.unregister_class(CompifyPurgeModels)
    bpy.utils.unregister_class(CompifyBlockoutInstall)
    bpy.utils.unregister_class(CompifyCancelBlockoutInstall)
    bpy.utils.unregister_class(CompifyBlockoutSelect)
    unregister_blockout_properties()
    bpy.utils.unregister_class(CompifyBlockoutMigrate)
    for cls in reversed(panel_list.CLASSES):
        bpy.utils.unregister_class(cls)
    bpy.utils.unregister_class(CompifyBlockoutGenerateDefault)
    bpy.utils.unregister_class(CompifyBlockoutGenerate)
    if hasattr(bpy.types.Object, "compify_blockout"):
        del bpy.types.Object.compify_blockout
    bpy.utils.unregister_class(blockout_live.BlockoutSettings)
    plock.unregister_handlers()
    _remove_handlers_by_name(
        bpy.app.handlers.depsgraph_update_post,
        sync_projection_aspect_handler.__name__)

    # Custom properties.
    del bpy.types.Scene.compify_config
    del bpy.types.Scene.compify_uv_adjust_camera
    del bpy.types.Scene.compify_uv_group_fold_states
    del bpy.types.Scene.compify_bake_unwrap_overrides

    # 摘掉 load_post 处理器，并清掉各场景上的缓存
    _remove_handlers_by_name(
        bpy.app.handlers.load_post, invalidate_uv_cache_on_load.__name__)
    for _scene in bpy.data.scenes:
        try:
            if "compify_uv_cache" in _scene:
                del _scene["compify_uv_cache"]
        except (AttributeError, TypeError, ReferenceError):
            pass



if __name__ == "__main__":
    register()
