"""Sidebar panel "生成模型管理": one line per model.

Row layout (single line):
    [三角]  [状态图标 + 名称按钮]  [删除]

The triangle opens the six parameters right under the row (one at a time).
The name itself is the select button: pressed (blue) while the model is
selected, plain otherwise, and its tooltip carries the untruncated name.
Deletion still asks for confirmation.  There is no face count, no checkbox
row, no batch bar and no per-row menu.
"""

import json

import bpy

from . import blockout
from . import blockout_live
from . import panel_list
from . import panel_shared

_ = bpy.app.translations.pgettext_iface


class CompifyPanelModels(bpy.types.Panel):
    """生成模型列表"""

    bl_label = "生成模型管理"
    bl_idname = "VIEW3D_PT_compify_models"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = ""
    bl_category = "Compify"
    bl_order = 30

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # After 一键清理 the depth models are gone: say so instead of listing
        # rows that cannot be rebuilt.  The scene objects themselves stay.
        if not blockout.runtime_status()["ready"]:
            layout.label(text="需重新下载模型 · 去偏好设置", icon="INFO")
            return

        mapping = blockout.blockouts_by_source(scene)
        models = [obj for entries in mapping.values() for obj in entries]

        if not models:
            layout.label(text="还没有模型 · 去分区 ② 生成", icon="INFO")
            return

        failing = [obj for obj in models
                   if bool(getattr(obj.compify_blockout, "last_error", ""))]
        if failing:
            layout.label(text="%d 个模型重建失败 · 展开点重试" % len(failing),
                         icon="ERROR")

        for obj in models:
            settings = blockout_live.settings_of(obj)
            if settings is None:
                continue

            icon = "ERROR" if settings.last_error else "MESH_DATA"
            open_now = panel_list.params_open(scene, obj.name)

            row = layout.row(align=True)
            fold = row.operator(
                "compify.blockout_fold_params", text="",
                emboss=False,
                icon="TRIA_DOWN" if open_now else "TRIA_RIGHT")
            fold.name = obj.name

            # Name is the select button (blue while selected).  The split keeps
            # the trash icon on the same x for every row; no face-count column
            # any more, so the name has the width back.
            cell, cell_px = panel_shared.split_name_row(context, row, 26.0)
            select = cell.operator(
                "compify.blockout_select",
                text=panel_shared.fit_text(obj.name, cell_px, icon_px=16.0),
                icon=icon, depress=obj.select_get())
            select.names_json = json.dumps([obj.name])
            delete = cell.operator("compify.blockout_delete", text="",
                                   icon="TRASH")
            delete.names_json = json.dumps([obj.name])

            # Source plate gone: Blender has no yellow text, STATUS_WARNING is
            # the closest non-red signal.  Kept in a row so it reads as part
            # of this model's block.
            source_name = str(obj.get(blockout.PROP_SOURCE) or "")
            if not source_name or bpy.data.objects.get(source_name) is None:
                warn_row = layout.row()
                warn_row.label(text="来源图平面已删除", icon="STATUS_WARNING")

            if settings.last_error:
                # The reason needs the full row: with the retry button next to
                # it the text was cut to "重建失败：请再…" at sidebar width.
                error_row = layout.row()
                error_row.alert = True
                error_row.label(text="重建失败：%s" % settings.last_error,
                                icon="ERROR")
                retry_row = layout.row()
                retry = retry_row.operator("compify.blockout_retry",
                                           text="重试")
                retry.name = obj.name

            if open_now:
                # Sliders span this model's caps; a deferred re-declaration
                # fixes the ranges when they differ (never inside draw).
                blockout_live.request_redeclare_if_needed()
                box = layout.box()
                # Rows gated by 裁形 are skipped entirely, so an unchecked
                # switch leaves no dead control behind.
                for field in panel_list.visible_fields(settings):
                    if field == "threshold":
                        box.label(text="图片层", icon="TEXTURE_DATA")
                    if field == "trim":
                        box.prop(settings, field)      # checkbox, not slider
                    else:
                        box.prop(settings, field, slider=True)
                note = getattr(settings, "cap_note", "")
                if note:
                    box.label(text=note, icon="INFO")
