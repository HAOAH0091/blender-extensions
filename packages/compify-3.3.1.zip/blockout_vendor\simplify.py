# Vendored from image_cutter v0.4.0 (..\image_cutter\ic_core\simplify.py)
# Kept unchanged apart from this provenance note. Original header follows.
"""轮廓抽稀：把一圈几万个点降到几十个，同时形状走样不超过容差。

两层：
  1. **RDP（Douglas-Peucker）** —— 贪心，快速把点数降到几百。它是 O(n log n)，
     先跑它，是为了让第 2 步的复杂度可控。直接对原始点跑 DP 会卡死。
  2. **有界动态规划** —— 在小窗口里搜「段数最少优先、面积误差次之」的解。
     这是 image_to_cutout 那套比常规抽稀更讲究的地方：贪心一次定生死，
     DP 会回头找更省的走法。

为什么两层而不是只跑 DP：DP 每段都要算「段内所有点到线段的距离」，
不经预处理就是 O(n·win²)。1 万点的环在纯 Python 里要好几秒。
"""

import math

import numpy as np


def _dedup(ring, eps=1e-9):
    """去掉相邻的重复点（追踪出来的环常带）。"""
    out = []
    for p in ring:
        if not out or abs(p[0] - out[-1][0]) > eps or abs(p[1] - out[-1][1]) > eps:
            out.append((float(p[0]), float(p[1])))
    # 首尾也去重
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) <= eps and abs(out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def _roll_to_corner(pts):
    """把环旋转到「离质心最远的点」开头。

    为什么：闭合环做抽稀必须选个起点，起点若落在平滑段上会被硬切成角。
    离质心最远的点通常是真正的尖角，从它开始最安全。
    """
    n = len(pts)
    if n < 3:
        return pts
    cx = sum(p[0] for p in pts) / n
    cy = sum(p[1] for p in pts) / n
    best, best_d = 0, -1.0
    for k, p in enumerate(pts):
        d = (p[0] - cx) ** 2 + (p[1] - cy) ** 2
        if d > best_d:
            best, best_d = k, d
    return pts[best:] + pts[:best]


def _rdp(pts, tol):
    """迭代版 Douglas-Peucker。pts 是 (N,2) float 数组。"""
    n = len(pts)
    if n < 3:
        return pts
    keep = np.zeros(n, dtype=bool)
    keep[0] = True
    keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        a = pts[i]
        b = pts[j]
        d = b - a
        seg = pts[i + 1:j]
        length = math.hypot(float(d[0]), float(d[1]))
        if length < 1e-12:
            dist = np.hypot(seg[:, 0] - a[0], seg[:, 1] - a[1])
        else:
            dist = np.abs((seg[:, 0] - a[0]) * d[1] - (seg[:, 1] - a[1]) * d[0]) / length
        k = int(np.argmax(dist))
        if float(dist[k]) > tol:
            m = i + 1 + k
            keep[m] = True
            stack.append((i, m))
            stack.append((m, j))
    return pts[keep]


def _seg_dev(pts, j, i):
    """点 j..i 之间所有点到线段 (j, i) 的最大垂距。"""
    if i - j < 2:
        return 0.0
    a = pts[j]
    b = pts[i]
    seg = pts[j + 1:i]
    d = b - a
    length = math.hypot(float(d[0]), float(d[1]))
    if length < 1e-12:
        return float(np.max(np.hypot(seg[:, 0] - a[0], seg[:, 1] - a[1])))
    return float(np.max(np.abs((seg[:, 0] - a[0]) * d[1] - (seg[:, 1] - a[1]) * d[0]) / length))


def _dp_shortest(pts, tol, max_win=40):
    """有界动态规划：段数最少优先，段数相同时挑偏离小的。

    代价 = 1（每段固定成本） + (偏离/容差)²
    偏离小于容差时几乎不加钱（形状保真），超过容差代价二次增长（超了就不值当）。

    【为什么要把 _seg_dev 批量化 —— 实测过的性能灾难】

    早先内层是这样：`for j in range(j0, i): dev = _seg_dev(pts, j, i)`。
    每个 (j,i) 对都完整走一遍 numpy 调用栈（切片 → 减 → 乘 → 除 → max）。
    小数组上 numpy 的**固定开销远大于计算本身**。

    cProfile 实测（100 个各 14 点的小环，即像素画/图标集那种素材）：
        _seg_dev 被调用 578,000 次，耗时 2.8 秒，占阶段 A 的 94%
        整个阶段 A = 4255ms
    而同一批环只跑 RDP 只要 0.1ms —— 差 4 万倍。

    关键洞察：对固定的 i，所有 j 的 dev 可以**一次算出来**。
    dev(j,i) = 点 j+1..i-1 到线段 (j,i) 的最大垂距。
    把这些候选段堆成一个批量运算，就只剩一次 numpy 调用。

    做法：对每个 i，取窗口内所有 j，构造 (段数, 最大段长) 的二维数组，
    用掩膜把不属于该段的点排除（置 0，因为求的是最大值，0 不影响）。
    """
    n = len(pts)
    if n < 4:
        return pts

    # 【小环直接走 RDP，不跑 DP】
    #
    # 上面那个批量版已经比逐次调 _seg_dev 快 7.8 倍（4255ms → 548ms），
    # 但剩下的开销是「每个点一次 numpy 调用」：100 个 14 点的环仍有
    # 32721 次 numpy.reduce + 16400 次 argmin，累计 460ms。
    #
    # 对这么小的环，DP 相比 RDP 的收益可以忽略（14 个点能差几段？），
    # 而 numpy 的固定开销反而成了全部成本。所以按点数分流：
    # 小环（< MIN_DP_POINTS）直接用 RDP 的结果，大环才值得上 DP。
    #
    # 阈值怎么定的：实测 14 点的环 DP 花了 4.6ms/环，而 RDP 只要 0.001ms；
    # 环长超过约 150 点后 DP 才开始有明显价值（能省掉 10% 以上的段数）。
    # 阈值判断放在这里没意义 —— 进来的 pts 已经过 RDP 抽稀（见 simplify_ring），
    # 通常只剩几十个点。真正的分流在 simplify_ring 里、RDP 之后做。
    win = max(3, min(max_win, n - 1))
    inf = float("inf")
    cost = [inf] * n
    prev = [-1] * n
    cost[0] = 0.0

    # 注：试过给「小环」写纯 Python 版 DP，想赌 numpy 固定开销是主因。
    # 实测失败了 —— 65 点环上纯 Python 版 13.94ms，numpy 批量版 1.86ms，
    # 反而慢 7.5 倍。原因是内层要「对每个 j 再扫一遍中间点」，
    # 65 × 40 × 平均 30 个中间点 = 7.8 万次 Python 级运算，
    # 而 numpy 版是一次批量矩阵运算搞定。教训：小数组上 numpy 未必慢，
    # 要看内层是否还有不必要的遍历 —— 不能凭直觉下结论。
    P = np.asarray(pts, dtype=np.float64)
    px = P[:, 0]
    py = P[:, 1]

    for i in range(1, n):
        j0 = max(0, i - win)
        m = i - j0                       # 候选 j 的个数
        if m <= 0:
            continue
        js = np.arange(j0, i)
        cj = np.asarray([cost[j] for j in js], dtype=np.float64)

        # 线段向量 (j → i)
        dx = px[i] - px[js]
        dy = py[i] - py[js]
        length = np.hypot(dx, dy)
        length_safe = np.where(length < 1e-12, 1.0, length)

        # 候选点索引矩阵：第 k 行是「j = js[k] 对应的中间点 j+1..i-1」
        # 用相对偏移表示，最大宽度 = i - j0 - 1
        width = i - j0 - 1
        if width <= 0:
            dev = np.zeros(m, dtype=np.float64)
        else:
            off = np.arange(1, width + 1)              # 相对 j 的偏移
            idx = js[:, None] + off[None, :]           # (m, width) 绝对索引
            valid = idx < i                            # 只算 j+1..i-1
            idx_clipped = np.where(valid, idx, 0)      # 越界的先夹到 0，再用掩膜压掉

            segx = px[idx_clipped] - px[js][:, None]
            segy = py[idx_clipped] - py[js][:, None]
            # 叉积 / 长度 = 垂距
            cross = np.abs(segx * dy[:, None] - segy * dx[:, None])
            dev_all = cross / length_safe[:, None]
            dev_all = np.where(valid, dev_all, 0.0)
            dev = dev_all.max(axis=1) if width > 0 else np.zeros(m)

        # 退化情况：线段长≈0 时改用端点距（保持与 _seg_dev 行为一致）
        degenerate = length < 1e-12
        if np.any(degenerate):
            for k in np.nonzero(degenerate)[0]:
                j = int(js[k])
                if i - j >= 2:
                    seg = P[j + 1:i]
                    dev[k] = float(np.max(np.hypot(seg[:, 0] - px[j], seg[:, 1] - py[j])))

        r = dev / tol if tol > 1e-9 else np.zeros(m)
        cand = cj + 1.0 + r * r
        cand = np.where(np.isfinite(cj), cand, inf)
        k = int(np.argmin(cand))
        cost[i] = float(cand[k])
        prev[i] = int(js[k])

    out = []
    k = n - 1
    guard = 0
    while k >= 0 and guard <= n + 2:
        guard += 1
        out.append(pts[k])
        if k == 0:
            break
        k = prev[k]
        if k < 0:
            break
    out.reverse()
    return np.asarray(out)


_DP_MIN_POINTS = 60
_DP_BATCH = 128


def _dp_shortest_many(items, tol, max_win=40):
    """批量版 `_dp_shortest`：同点数的环一起做 DP。

    为什么值得单独写一套：DP 的外层是「每个点一次 numpy 调用」。
    100 个 65 点的环要 6400 次调用，单次固定开销远大于 40×40 矩阵的
    实际计算量。把同长度的环叠成一个 (环数, 点, 2) 数组后，每个点只
    调用一次 numpy，100 个环的 DP 实测 388ms → 79ms。

    分组按**精确点数**：不同长度的环窗口不同，混批会改变结果；同长度
    才能逐元素保持与单环版一致。批大小有上限，避免几千个环时临时矩阵
    过大。
    """
    out = [None] * len(items)
    groups = {}
    for idx, pts in enumerate(items):
        n = len(pts)
        if n < 4:
            out[idx] = pts
            continue
        groups.setdefault(n, []).append(idx)

    for n, idxs in groups.items():
        for start in range(0, len(idxs), _DP_BATCH):
            chunk = idxs[start:start + _DP_BATCH]
            if len(chunk) == 1:
                out[chunk[0]] = _dp_shortest(items[chunk[0]], tol, max_win)
                continue

            P = np.asarray([items[i] for i in chunk], dtype=np.float64)
            rows = len(chunk)
            px = P[:, :, 0]
            py = P[:, :, 1]
            win = max(3, min(max_win, n - 1))
            cost = np.full((rows, n), np.inf, dtype=np.float64)
            prev = np.full((rows, n), -1, dtype=np.int64)
            cost[:, 0] = 0.0
            tri = np.arange(win)[:, None] <= np.arange(win)[None, :]
            row_idx = np.arange(rows)

            for i in range(1, n):
                j0 = max(0, i - win)
                m = i - j0
                js = np.arange(j0, i)
                dx = px[:, i][:, None] - px[:, js]
                dy = py[:, i][:, None] - py[:, js]
                length = np.hypot(dx, dy)
                width = i - j0 - 1
                if width <= 0:
                    dev = np.zeros((rows, m))
                else:
                    ks = np.arange(j0 + 1, i)
                    cross = (px[:, ks][:, None, :] * dy[:, :, None]
                             - py[:, ks][:, None, :] * dx[:, :, None])
                    cross -= (px[:, js] * dy - py[:, js] * dx)[:, :, None]
                    np.abs(cross, out=cross)
                    cross /= np.where(length < 1e-12, 1.0, length)[:, :, None]
                    cross[:, ~tri[:m, :width]] = 0.0
                    dev = cross.max(axis=2)

                # 退化线段（长度≈0）改用端点到各中间点的距离。真实数据
                # 里极少，保持与单环版完全一致。
                degenerate = length < 1e-12
                if degenerate.any():
                    for r, k in zip(*np.nonzero(degenerate)):
                        j = int(js[k])
                        if i - j >= 2:
                            dev[r, k] = np.hypot(
                                P[r, j + 1:i, 0] - px[r, j],
                                P[r, j + 1:i, 1] - py[r, j],
                            ).max()

                rr = dev / tol if tol > 1e-9 else np.zeros((rows, m))
                cand = cost[:, js] + 1.0 + rr * rr
                k = np.argmin(cand, axis=1)
                cost[:, i] = cand[row_idx, k]
                prev[:, i] = js[k]

            for r, idx in enumerate(chunk):
                pts = items[idx]
                path = []
                k = n - 1
                guard = 0
                while k >= 0 and guard <= n + 2:
                    guard += 1
                    path.append(pts[k])
                    if k == 0 or prev[r, k] < 0:
                        break
                    k = int(prev[r, k])
                path.reverse()
                out[idx] = np.asarray(path)
    return out


def _prepare_ring(ring, tol):
    """去重 → 选起点 → RDP。返回 (原始点, 待 DP 的点)；无需抽稀时 coarse=None。"""
    pts = _dedup(ring)
    if len(pts) < 5:
        return pts, None

    pts = _roll_to_corner(pts)
    n = len(pts)
    # 环展开成开放折线（首尾同点）才能跑 RDP / DP
    closed = np.asarray(pts + [pts[0]], dtype=np.float64)

    # RDP 的作用是「把点数降下来，让后面的 DP 可控」。
    # 原来的门槛是 n > 200，实测有个致命盲区：
    # 一个 162 点的环刚好不触发 RDP，直接进 DP ——
    # 而 DP 是 O(n × win) 次 numpy 调用，162 点 × 40 窗口 ≈ 6500 次，单环 5.4ms。
    # 100 个这样的环（像素画/图标集）就是 540ms。
    #
    # 降到 120：RDP 对 100~200 点的环也几乎不花时间（实测 0.02ms），
    # 但能把点数压到几十，DP 的开销跟着降一个量级。
    coarse = _rdp(closed, max(tol * 0.75, 1e-6)) if n > 120 else closed
    return pts, coarse


def _finish_ring(pts, fine):
    out = [(float(p[0]), float(p[1])) for p in fine[:-1]]
    return out if len(out) >= 3 else pts


def simplify_rings(rings, tol, refine=True):
    """批量抽稀。同点数的环共享一次批量 DP，结果与逐环调用完全一致。"""
    prepared = [_prepare_ring(r, tol) for r in rings]
    pending = []
    pending_idx = []
    for idx, (_pts, coarse) in enumerate(prepared):
        if coarse is None:
            continue
        if refine and len(coarse) > _DP_MIN_POINTS:
            pending.append(coarse)
            pending_idx.append(idx)

    refined = _dp_shortest_many(pending, tol) if pending else []
    refined_by_idx = dict(zip(pending_idx, refined))

    out = []
    for idx, (pts, coarse) in enumerate(prepared):
        if coarse is None:
            out.append(pts)
            continue
        fine = refined_by_idx.get(idx, coarse)
        out.append(_finish_ring(pts, fine))
    return out


def simplify_ring(ring, tol, refine=True):
    """闭合环抽稀。tol = 容差（像素）。返回点列表（首尾不重复）。"""
    return simplify_rings([ring], tol, refine)[0]
