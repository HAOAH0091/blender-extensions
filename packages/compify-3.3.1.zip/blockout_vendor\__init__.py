"""Vendored copy of image_cutter 0.4.0 modules (mask / outline / simplify).

Source: D:\BaiduSyncdisk\addons\image_cutter\ic_core\
Files kept byte-identical apart from a provenance header line.
"""
