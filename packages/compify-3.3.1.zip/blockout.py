"""One-click blockout generation from an existing camera projection.

Turns a flat projected image plane into a mesh whose depth follows the plate,
using the projection camera's real field of view. Only geometry is produced;
the plate's projection material is reused as-is.

Blender's bundled Python has no Pillow, so image warping and model inference
run in Compify's own runtime (blockout_worker.py). This module only does the
geometry, the camera math and the process plumbing.

Three layers live here:

* ``generate()`` - the synchronous one-shot path (used by tests and scripts).
* ``BlockoutJob`` / ``BatchSession`` - the cancellable, step-driven path used
  by the modal operator so the UI keeps redrawing during inference.
* runtime detection/installation helpers for the bundled model.
"""

import hashlib
import json
import math
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import bpy

from . import blockout_installer
from .blockout_vendor import mask as _mask
from .blockout_vendor import outline as _outline
from .blockout_vendor import simplify as _simplify
from .blockout_vendor import triangulate as _tri

COLLECTION_NAME = "模型"
# Name used by files saved before the rename; ensure_collection() adopts it.
LEGACY_COLLECTION_NAME = "起手模型"
PROP_SOURCE = "compify_blockout_source"
PROP_CAMERA = "compify_blockout_camera"
PROP_PARAMS = "compify_blockout_params"
PROP_ORIGIN = "compify_blockout_origin"
GROUP_PREFIX = "起模参数"  # legacy modifier group name, migration only
PROP_IMAGE = "compify_blockout_image"

DEFAULT_GRID = {"COARSE": 32, "STANDARD": 64, "FINE": 128, "ULTRA": 256}
DEFAULT_PARAMS = {"grid": 128, "strength": 1.0, "trim": False, "smooth": 1,
                  "level": 5, "keep_source": True, "threshold": 0.0,
                  "outward": 2.0, "border_grow": False, "border_width": 2}
# "边缘补边": one quad ring welded to the trimmed border, its rim pushed out
# by this many cells of the final grid. BORDER_MAX is set to the widest value
# that still produced zero self-intersections on every test fixture.
BORDER_MAX = 8.0
BORDER_RELAX = 8
# Widths above 4 need the longer relaxation before the fold guard kicks in;
# preview builds never exceed 4 cells, so the live slider keeps its budget.
BORDER_RELAX_WIDE = 12
# Trim policy is "rather too big than too small": keep a soft alpha, then grow
# the kept area by one cell so the feathered edge is never cut off.
ALPHA_THRESHOLD = 0.0
# Bump when the geometry/trim algorithm changes: old cache entries must not
# be reused with a new pipeline.
PIPELINE_VERSION = 3
MAX_FRAME_SIZE = 2048
# B-path framing: infer on a crop around the plate at its own pixel density.
CROP_PADDING = 0.05
# Contour simplification tolerance, in mask pixels.  The triangulator puts a
# vertex on every remaining contour point, so this sets the boundary density:
# 4.05 is image_cutter's own default (pipeline.Params.tolerance) and gives the
# same mesh (measured 56 ring points / 380 boundary verts / 579 tris against
# image_cutter's 55 / 379 / 585 on a 1773x1735 plate).  0.05 kept nearly every
# pixel and produced a dense fan of slivers along the rim.
CONTOUR_TOL = 4.05
# "边缘补边" builds a quad ring along the trimmed border.  The triangle mesh has
# no quad border to weld to, so the feature is switched off for now: the code
# and its tests stay, only the entry point is unreachable.
_BORDER_ENABLED = False
# Filled by build_mesh: {"Z", "A", "B", "C", "obj"} in milliseconds so a drag
# can show where the time went.
STAGE_TIMES = {}
# Last border-grow statistics (cells requested, width actually used, skipped).
BORDER_LAST = {}
# Long edge of the alpha mask used for trimming (preview rebuilds use a
# coarser one so a slider still feels live).
MASK_CAP = 2048.0
MASK_CAP_PREVIEW = 512.0
# Stage caches. Keys follow the pipeline stages: A = image + threshold +
# outward, B = A + density, Z = depth buffer + smooth.
_Z_CACHE = {}
_A_CACHE = {}
_B_CACHE = {}
# Below this share of the plate's bbox being inside the camera frame we warn.
COVERAGE_WARN_THRESHOLD = 0.5

STAGE_FRAME = "准备取景"
STAGE_DEPTH = "分析景深"
STAGE_MESH = "生成网格"

RUNTIME_ROOT_ENV = "COMPIFY_RUNTIME_ROOT"
MODELS_ROOT_ENV = "COMPIFY_MODELS_ROOT"
# Set COMPIFY_TEST=1 in test runs: purge_dir() then refuses to delete anything
# inside the add-on storage root unless the caller passes allow_real=True.
TEST_MODE_ENV = "COMPIFY_TEST"

TIER_FAST = "FAST"
TIER_ACCURATE = "ACCURATE"
TIER_DIR = {TIER_FAST: "moge-2-vits", TIER_ACCURATE: "moge-2-vitb"}
TIER_LABEL = {TIER_FAST: "快档（ViT-S）", TIER_ACCURATE: "准档（ViT-B）"}

_ = bpy.app.translations.pgettext_iface


# ---------------------------------------------------------------- runtime

def preferences():
    """Addon preferences object, when the addon is enabled normally."""
    try:
        addon = bpy.context.preferences.addons.get(__package__)
    except Exception:  # noqa: BLE001
        return None
    return addon.preferences if addon is not None else None


def storage_root():
    override = os.environ.get(RUNTIME_ROOT_ENV)
    if override:
        return Path(override)
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return Path(base) / "Compify"


def dir_size(path):
    """Bytes used under ``path`` (0 when it does not exist)."""
    total = 0
    root = Path(path)
    if not root.exists():
        return 0
    for entry in root.rglob("*"):
        try:
            if entry.is_file():
                total += entry.stat().st_size
        except OSError:
            continue
    return total


def size_text(num_bytes):
    """Human byte size: 865.0 MB / 512 KB / 12 B."""
    if num_bytes >= 1024 * 1024:
        return "%.1f MB" % (num_bytes / (1024.0 * 1024.0))
    if num_bytes >= 1024:
        return "%.0f KB" % (num_bytes / 1024.0)
    return "%d B" % int(num_bytes)


def dangerous_clean_target(path):
    """True when deleting ``path`` could nuke something that is not ours.

    Besides the literal target, every *ancestor* of the home folder, the
    working directory, the add-on folder and the add-on storage root is
    refused: C:\\Users, %LOCALAPPDATA% and friends would take far more than
    the two model folders with them.
    """
    try:
        target = Path(path).expanduser().resolve()
    except OSError:
        return True
    if not str(target).strip() or not os.path.isabs(str(target)):
        return True
    home = Path.home().resolve()
    try:
        cwd = Path.cwd().resolve()
    except OSError:
        cwd = None
    plugin = Path(__file__).resolve().parent
    try:
        storage = Path(storage_root()).resolve()
    except OSError:
        storage = None
    if target == target.parent or target.parent == target:
        return True                     # drive / filesystem root
    if target == home or home.is_relative_to(target):
        return True                     # home itself or any ancestor of it
    if cwd is not None and (target == cwd or cwd.is_relative_to(target)):
        return True
    if target == plugin or plugin.is_relative_to(target):
        return True                     # would delete the add-on itself
    if storage is not None and (target == storage or storage.is_relative_to(target)):
        return True                     # storage root or any ancestor of it
    return False


def test_mode_active():
    """True while a test run set COMPIFY_TEST=1 (read on every call)."""
    return os.environ.get(TEST_MODE_ENV, "") == "1"


def unsafe_clean_reason():
    """Human reason when the clean targets are unsafe, else empty string."""
    models = models_dir()
    runtime = runtime_dir()
    targets = [models] if str(models) == str(runtime) else [models, runtime]
    for path in targets:
        if dangerous_clean_target(path):
            return "当前模型位置不安全，没法清理；请先在偏好设置里改到普通文件夹"
    return ""


def purge_dir(path, allow_real=False):
    """Delete one directory. Returns (bytes_removed, error_text).

    A file still held by another process (the inference worker, antivirus)
    makes rmtree fail half-way; wait briefly and try once more, then report
    how much was actually removed instead of a flat zero.

    Safety order: the path guard runs first and always; the COMPIFY_TEST gate
    runs second and only protects the add-on's own storage root (a model
    folder moved to another drive is not covered by it).  ``allow_real``
    skips the test gate only — never the path guard.
    """
    target = Path(path)
    if dangerous_clean_target(target):
        return 0, "拒绝清理这个位置：%s" % target
    if not allow_real and test_mode_active():
        try:
            inside_storage = target.resolve().is_relative_to(
                Path(storage_root()).resolve())
        except OSError:
            inside_storage = True
        if inside_storage:
            print("[Compify] COMPIFY_TEST=1：拒绝清理真实目录 %s" % target)
            return 0, "测试模式下不清理真实目录"
    if not target.exists():
        return 0, ""
    before = dir_size(target)
    for attempt in (0, 1):
        try:
            shutil.rmtree(target)
            return before, ""
        except OSError as error:  # noqa: BLE001
            print("[Compify] 清理失败（第 %d 次）：%s（%s）"
                  % (attempt + 1, target, error))
            if attempt == 0:
                time.sleep(0.5)
    remaining = dir_size(target) if target.exists() else 0
    removed = max(0, before - remaining)
    return removed, ("部分文件删不掉（已删 %s），请关闭占用它的程序后再试"
                     % size_text(removed))


def _pref_dir(name, fallback):
    prefs = preferences()
    value = getattr(prefs, name, "") if prefs is not None else ""
    if value:
        return Path(bpy.path.abspath(value))
    return fallback


def models_dir():
    override = os.environ.get(MODELS_ROOT_ENV)
    if override:
        return Path(override)
    return _pref_dir("models_dir", storage_root() / "models")


def runtime_dir():
    override = os.environ.get(RUNTIME_ROOT_ENV)
    if override:
        return Path(override) / "runtime"
    return _pref_dir("runtime_dir", storage_root() / "runtime")


def runtime_python():
    """venv first (old installs), then the downloaded standalone interpreter."""
    venv = runtime_dir() / "venv" / "Scripts" / "python.exe"
    if venv.is_file():
        return venv
    return runtime_dir() / "python" / "python.exe"


def active_tier():
    prefs = preferences()
    tier = getattr(prefs, "quality", TIER_FAST) if prefs is not None else TIER_FAST
    return tier if tier in TIER_DIR else TIER_FAST


def model_path(tier=None):
    tier = tier or active_tier()
    return models_dir() / TIER_DIR[tier] / "model.onnx"


def worker_path():
    return Path(__file__).with_name("blockout_worker.py")


def cache_dir():
    path = storage_root() / "cache" / "blockout"
    path.mkdir(parents=True, exist_ok=True)
    return path


def deps_marker():
    """Written only after the worker dependencies installed successfully."""
    return runtime_dir() / ".deps_ok"


def tier_status(tier):
    """Install state of one model tier plus the shared python runtime."""
    # A python binary alone is not enough: a failed pip run would otherwise
    # report "ready" and the panel would hide the install button.
    has_python = runtime_python().is_file()
    deps_ok = deps_marker().is_file()
    python_ok = has_python and deps_ok
    model_ok = model_path(tier).is_file()
    return {
        "tier": tier,
        "label": TIER_LABEL[tier],
        "python": python_ok,
        "has_python": has_python,
        "deps": deps_ok,
        "model": model_ok,
        "ready": python_ok and model_ok,
        "model_path": str(model_path(tier)),
    }


def runtime_ready(tier=None):
    return runtime_status(tier)["ready"]


def runtime_status(tier=None):
    """What is missing for inference, without touching the disk."""
    tier = tier or active_tier()
    info = tier_status(tier)
    missing = []
    if not info["python"]:
        missing.append("python")
    if not info["model"]:
        missing.append("model")
    info.update({
        "missing": missing,
        "python_path": str(runtime_python()),
        "runtime_dir": str(runtime_dir()),
        "models_dir": str(models_dir()),
        "root": str(storage_root()),
        "tiers": {name: tier_status(name) for name in (TIER_FAST, TIER_ACCURATE)},
    })
    return info


def missing_message(status=None):
    """Human-readable Chinese line for the panel / report."""
    status = status or runtime_status()
    if status["ready"]:
        return _("深度模型已就绪")
    label = status["label"]
    if "python" in status["missing"] and "model" in status["missing"]:
        return _("{tier}未就绪（缺少推理环境与深度模型）").format(tier=label)
    if status.get("has_python") and not status.get("deps"):
        return _("{tier}的推理依赖还没装好，请重新点「启用生成模型」补装").format(
            tier=label)
    if "python" in status["missing"]:
        return _("{tier}未就绪（缺少推理环境）").format(tier=label)
    return _("{tier}未就绪（缺少深度模型，新位置尚未下载模型）").format(tier=label)


# ------------------------------------------------------- runtime installer

def manifest_candidates():
    here = Path(__file__).parent
    return (here / "blockout_runtime.json",
            here / "_dev" / "blockout_runtime.json")


def manifest_path():
    for candidate in manifest_candidates():
        if candidate.is_file():
            return candidate
    return None


def load_manifest():
    path = manifest_path()
    if path is None:
        raise RuntimeError(_(
            "缺少运行环境安装清单 blockout_runtime.json，无法自动安装"))
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


sha256_file = blockout_installer.sha256_file
InstallCancelled = blockout_installer.InstallCancelled
_download = blockout_installer.download


def blender_python():
    """The Python interpreter shipped with this Blender build."""
    version = ".".join(bpy.app.version_string.split(".")[:2])
    candidate = (Path(bpy.app.binary_path).parent / version / "python" / "bin"
                 / ("python.exe" if os.name == "nt" else "python3"))
    return candidate if candidate.is_file() else None


def _runtime_has_deps(python):
    probe = [str(python), "-c", blockout_installer.DEPS_IMPORT]
    try:
        return subprocess.run(probe, capture_output=True,
                              timeout=120).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _probe_deps_and_mark(python):
    try:
        if _runtime_has_deps(python):
            deps_marker().write_text("numpy scipy pillow onnxruntime",
                                     encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass


def verify_deps_in_background():
    """One probe per session; writes the marker when the deps really import.

    The import check runs on a worker thread so the first panel draw does not
    stall for a second or two; this function itself returns immediately.
    """
    import threading

    python = runtime_python()
    if not python.is_file() or deps_marker().is_file():
        return None
    threading.Thread(target=_probe_deps_and_mark, args=(python,),
                     daemon=True).start()
    return None


def install_runtime(tiers=None, log=None, progress=None, should_cancel=None):
    """Synchronous installation entry for scripts."""
    should_cancel = should_cancel or (lambda: False)
    blockout_installer.cancel_if_requested(should_cancel)
    tiers = list(tiers or [active_tier()])
    manifest = load_manifest()
    blockout_installer.validate_manifest(manifest, tiers)

    def emit(kind, **details):
        if progress and kind == "progress":
            progress(details["done"], details["total"])
        elif log and kind in {"stage", "attempt"}:
            log(details["step"])

    blockout_installer.install(manifest, runtime_dir().resolve(),
                               {tier: model_path(tier).resolve() for tier in tiers},
                               blender_python(), emit, should_cancel,
                               getattr(bpy.app, "online_access", True))
    return runtime_status(tiers[-1])


# ------------------------------------------------------------------ camera

def camera_aspect(scene):
    width = float(scene.render.resolution_x)
    height = float(max(scene.render.resolution_y, 1))
    ratio = float(getattr(scene.render, "pixel_aspect_x", 1.0)) / max(
        float(getattr(scene.render, "pixel_aspect_y", 1.0)), 1e-6)
    return (width / height) * ratio


def horizontal_fov_degrees(scene, camera):
    """Horizontal field of view of a perspective camera, in degrees."""
    data = camera.data
    if data.type != "PERSP":
        raise ValueError(_("投射摄像机是正交视角，无法重建透视"))
    aspect = camera_aspect(scene)
    if data.sensor_fit == "VERTICAL":
        fov_y = 2.0 * math.atan(data.sensor_height / (2.0 * data.lens))
        return math.degrees(2.0 * math.atan(math.tan(fov_y / 2.0) * aspect))
    if data.sensor_fit == "HORIZONTAL":
        return math.degrees(2.0 * math.atan(data.sensor_width / (2.0 * data.lens)))
    # AUTO: the sensor width maps to the longer image edge.
    if aspect >= 1.0:
        return math.degrees(2.0 * math.atan(data.sensor_width / (2.0 * data.lens)))
    fov_y = 2.0 * math.atan(data.sensor_width / (2.0 * data.lens))
    return math.degrees(2.0 * math.atan(math.tan(fov_y / 2.0) * aspect))


def find_image(obj):
    """Return the image used by the object's projection material."""
    for slot in obj.material_slots:
        material = slot.material
        if not material or not material.use_nodes:
            continue
        for node in material.node_tree.nodes:
            if node.type == "TEX_IMAGE" and node.image:
                return node.image
    return None


def projection_camera(obj):
    """Camera referenced by the object's own Camera Project group, or None."""
    from .node_groups import extract_camera_from_camera_project_group

    if obj is None or obj.type != "MESH":
        return None
    for slot in obj.material_slots:
        material = slot.material
        if not material or not material.use_nodes:
            continue
        for node in material.node_tree.nodes:
            if (node.type == "GROUP" and node.node_tree
                    and node.node_tree.name.startswith("Camera Project |")):
                camera = extract_camera_from_camera_project_group(
                    node.node_tree)
                if camera is not None:
                    return camera
    return None


def find_camera(context, obj):
    """Return the projection camera for an object, or the scene camera."""
    camera = projection_camera(obj)
    if camera is not None:
        return camera
    for other in context.selected_objects:
        if other is obj:
            continue
        camera = projection_camera(other)
        if camera is not None:
            return camera
    scene = context.scene
    if scene.camera is not None:
        return scene.camera
    cameras = [item for item in scene.objects if item.type == "CAMERA"]
    return cameras[0] if len(cameras) == 1 else None


def plate_corners(scene, camera, obj):
    """Map the plate's UV corners to normalized camera coordinates."""
    from bpy_extras.object_utils import world_to_camera_view

    mesh = obj.data
    uv_layer = mesh.uv_layers.active
    if uv_layer is None:
        raise ValueError(_("图平面没有 UV"))
    corners = {}
    for loop, uv in zip(mesh.loops, uv_layer.data):
        key = (round(float(uv.uv[0]), 3), round(float(uv.uv[1]), 3))
        if key in ((0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)):
            if key not in corners:
                world = obj.matrix_world @ mesh.vertices[loop.vertex_index].co
                corners[key] = world
    if len(corners) != 4:
        raise ValueError(_("图平面必须是规则的四边形"))
    projected = {}
    for key, world in corners.items():
        co = world_to_camera_view(scene, camera, world)
        projected[key] = (float(co.x), float(co.y), float(co.z))
    return projected


# --------------------------------------------------------------- framing

UV_ORDER = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))


def solve_homography(source, target):
    """Return the 3x3 mapping four source points onto four target points."""
    import numpy as np

    matrix = []
    for (x, y), (u, v) in zip(source, target):
        matrix.append([x, y, 1, 0, 0, 0, -u * x, -u * y, -u])
        matrix.append([0, 0, 0, x, y, 1, -v * x, -v * y, -v])
    _, _, values = np.linalg.svd(np.asarray(matrix, dtype=np.float64))
    return values[-1].reshape(3, 3)


def frame_mapping(corners, source_size, size):
    """Return homography data and the output-pixel -> source-pixel mapping."""
    src_width, src_height = source_size
    source = [
        (0.0, float(src_height)),
        (float(src_width), float(src_height)),
        (float(src_width), 0.0),
        (0.0, 0.0),
    ]
    target = [(corners[key][0], corners[key][1]) for key in UV_ORDER]
    homography = solve_homography(source, target)
    return homography, target


def visible_coverage(corners):
    """Share of the plate's bbox that falls inside the camera frame (0..1)."""
    xs = [value[0] for value in corners.values()]
    ys = [value[1] for value in corners.values()]
    span = (max(xs) - min(xs)) * (max(ys) - min(ys))
    if span <= 1e-9:
        return 0.0
    visible_x = max(0.0, min(1.0, max(xs)) - max(0.0, min(xs)))
    visible_y = max(0.0, min(1.0, max(ys)) - max(0.0, min(ys)))
    return (visible_x * visible_y) / span


def coverage_warning(coverage):
    """Chinese warning when most of the plate sits outside the camera frame."""
    if coverage >= COVERAGE_WARN_THRESHOLD:
        return ""
    return _("该图平面约 {pct}% 不在摄像机画面内，结果可能不准").format(
        pct=int(round((1.0 - coverage) * 100.0)))


def _full_frame_setup(scene, fov_full):
    """A path: infer on the whole camera frame (kept as the fallback)."""
    render_w, render_h = scene.render.resolution_x, scene.render.resolution_y
    ratio = min(1.0, MAX_FRAME_SIZE / max(render_w, render_h))
    return {
        "fov": fov_full,
        "size": (max(1, round(render_w * ratio)),
                 max(1, round(render_h * ratio))),
        "frame_rect": None,
    }


def _crop_setup(scene, corners, source_size, fov_full):
    """Default path: crop to the plate's bbox at its native pixel density.

    The plate usually covers a tiny part of the camera frame, so inferring on
    the whole frame gives the plate a few percent of the model's tokens. The
    crop keeps the plate's own resolution (781x809 rather than ~200x200).
    """
    xs = [value[0] for value in corners.values()]
    ys = [value[1] for value in corners.values()]
    x0, x1 = min(xs), max(xs)
    y0, y1 = min(ys), max(ys)
    pad_x = CROP_PADDING * (x1 - x0)
    pad_y = CROP_PADDING * (y1 - y0)
    x0 -= pad_x
    x1 += pad_x
    y0 -= pad_y
    y1 += pad_y
    width = x1 - x0
    height = y1 - y0
    if width <= 1e-6 or height <= 1e-6:
        raise ValueError(_("图平面在摄像机画面中被压成一条线"))

    render_w, render_h = scene.render.resolution_x, scene.render.resolution_y
    crop_aspect = (width * render_w) / (height * render_h)
    target_long = float(min(MAX_FRAME_SIZE, max(source_size)))
    if crop_aspect >= 1.0:
        size = (int(round(target_long)),
                max(16, int(round(target_long / crop_aspect))))
    else:
        size = (max(16, int(round(target_long * crop_aspect))),
                int(round(target_long)))

    fov = math.degrees(2.0 * math.atan(
        math.tan(math.radians(fov_full) / 2.0) * width))
    return {"fov": fov, "size": size, "frame_rect": (x0, y0, width, height)}


# -------------------------------------------------------------- inference

def _image_bytes(image):
    if image.packed_file:
        return image.packed_file.data
    return Path(bpy.path.abspath(image.filepath)).read_bytes()


def _cache_key(image, fov_x, level, size, tier=None):
    hasher = hashlib.sha256()
    hasher.update(_image_bytes(image))
    hasher.update(
        f"v{PIPELINE_VERSION}:{tier or active_tier()}:{fov_x:.4f}:{level}:"
        f"{size[0]}x{size[1]}".encode("ascii"))
    return hasher.hexdigest()[:32]


def _prepare_request(image, fov_x, level, size, target, tier=None):
    """Everything the worker needs, plus the cache key."""
    tier = tier or active_tier()
    key = _cache_key(image, fov_x, level, size, tier)
    cached = cache_dir() / f"{key}.npz"
    return {
        "key": key,
        "cached": cached,
        "tier": tier,
        "payload": {
            "fov_x": float(fov_x),
            "max_size": MAX_FRAME_SIZE,
            "resolution_level": int(level),
            "model": str(model_path(tier)),
            "size": [int(size[0]), int(size[1])],
            "quad": [[float(x), float(y)] for x, y in target],
        },
        "image": image,
    }


def _start_worker(prepared):
    """Spawn the depth worker; returns (process, workdir, output, logs)."""
    image = prepared["image"]
    workdir = Path(tempfile.mkdtemp(prefix="compify-blockout-"))
    plate_path = workdir / "plate.png"
    plate_path.write_bytes(_image_bytes(image))
    request = dict(prepared["payload"])
    request["image"] = str(plate_path)
    request["framed_path"] = str(workdir / "framed.png")
    request_path = workdir / "request.json"
    request_path.write_text(json.dumps(request), encoding="utf-8")
    output_path = workdir / "result.npz"
    log_path = workdir / "worker.log"

    with open(log_path, "w+", encoding="utf-8", errors="replace") as log_file:
        process = subprocess.Popen(
            [str(runtime_python()), str(worker_path()),
             str(request_path), str(output_path)],
            stdout=log_file, stderr=subprocess.STDOUT, text=True,
        )
    return process, workdir, output_path, log_path


def _read_worker_output(output_path, log_path, prepared):
    """Load the worker NPZ, or raise with the tail of its log."""
    import numpy as np

    if not Path(output_path).is_file():
        tail = ""
        try:
            tail = Path(log_path).read_text(
                encoding="utf-8", errors="replace").strip()[-400:]
        except OSError:
            pass
        raise RuntimeError(_("深度推理失败：{}").format(tail or _("没有输出")))
    with np.load(output_path) as data:
        arrays = {name: data[name] for name in data.files}
    if "alpha" not in arrays:
        raise RuntimeError(_("深度结果缺少 alpha 字段"))
    np.savez_compressed(prepared["cached"], **arrays)
    return arrays


def infer_depth(image, fov_x, level, size, corners, target, tier=None):
    """Run the depth worker synchronously (or reuse the cache)."""
    import numpy as np

    prepared = _prepare_request(image, fov_x, level, size, target, tier)
    if prepared["cached"].is_file():
        return _cached_arrays(prepared["cached"])

    if not runtime_ready(prepared["tier"]):
        raise RuntimeError(_("生成模型运行环境未就绪，请先安装深度模型"))

    process, workdir, output, log_path = _start_worker(prepared)
    try:
        code = process.wait()
        if code != 0:
            _read_worker_output(output, log_path, prepared)  # raises
        return _read_worker_output(output, log_path, prepared)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


# ------------------------------------------------------------------ jobs

_DEPTH_MEMORY = {}
_DEPTH_MEMORY_LIMIT = 2


def _cached_arrays(path):
    """Depth arrays from the disk cache, remembered between rebuilds.

    A slider drag rebuilds the same plate many times; decompressing the same
    NPZ every tick costs more than the whole mesh build.
    """
    import numpy as np

    key = str(path)
    arrays = _DEPTH_MEMORY.get(key)
    if arrays is not None:
        return arrays
    with np.load(path) as data:
        arrays = {name: data[name] for name in data.files}
    if len(_DEPTH_MEMORY) >= _DEPTH_MEMORY_LIMIT:
        _DEPTH_MEMORY.pop(next(iter(_DEPTH_MEMORY)))
    _DEPTH_MEMORY[key] = arrays
    return arrays


class BlockoutJob:
    """One plate's depth inference, polled from a timer or run to completion."""

    def __init__(self, context, plate, camera, params, mesh_origin=None):
        self.plate = plate
        self.camera = camera
        self.params = dict(params)
        self.mesh_origin = (None if mesh_origin is None else
                            tuple(float(value) for value in mesh_origin))
        self.stage = STAGE_FRAME
        self.error = None
        self.cancelled = False
        self._process = None
        self._workdir = None
        self._output = None
        self._log = None
        self._prepared = None
        self._arrays = None
        self._context = context
        self.frame_rect = None
        # Cells of the mesh being built; None means "use params' user width".
        self.border_cells = None
        self.coverage = None
        self.coverage_warning = ""
        self.tier = self.params.get("tier") or active_tier()
        self._prepare()

    # -- setup ---------------------------------------------------------
    def _prepare(self):
        scene = self._context.scene
        image = find_image(self.plate)
        if image is None:
            raise ValueError(_("选中的物体还没有投射材质，请先生成投射"))
        # Newly created or just-moved objects only have an updated matrix
        # after a dependency graph refresh; the camera math depends on it.
        self._context.view_layer.update()

        fov_full = horizontal_fov_degrees(scene, self.camera)
        corners = plate_corners(scene, self.camera, self.plate)
        coverage = visible_coverage(corners)
        if coverage <= 0.0:
            raise ValueError(_("该物体不在摄像机画面内，请检查投射摄像机"))

        self.image = image
        self.corners = corners
        self.coverage = coverage
        self.coverage_warning = coverage_warning(coverage)
        self.source_size = tuple(int(v) for v in image.size)
        self.homography, _unused = frame_mapping(
            corners, self.source_size, (1, 1))
        self.plate_distance = max(
            sum(value[2] for value in corners.values()) / 4.0, 1e-3)

        prefer = str(self.params.get("framing") or "crop")
        setup = None
        if prefer != "frame":
            try:
                setup = _crop_setup(
                    scene, corners, self.source_size, fov_full)
            except Exception as error:  # noqa: BLE001
                # Never lose a generation to a crop edge case: fall back to
                # the whole-frame path and say so in the console.
                print("[Compify|Blockout] crop framing unavailable:", error)
        if setup is None:
            setup = _full_frame_setup(scene, fov_full)

        self.frame_rect = setup["frame_rect"]
        self.size = setup["size"]
        self.fov = setup["fov"]
        if self.frame_rect is None:
            self.target = [(corners[key][0], corners[key][1])
                           for key in UV_ORDER]
        else:
            x0, y0, width, height = self.frame_rect
            self.target = [((corners[key][0] - x0) / width,
                            (corners[key][1] - y0) / height)
                           for key in UV_ORDER]

        self._prepared = _prepare_request(
            image, self.fov, self.params.get("level", 5), self.size,
            self.target, self.tier)

        if self._prepared["cached"].is_file():
            self.stage = "ready"
            self._arrays = _cached_arrays(self._prepared["cached"])
            return

        if not runtime_ready(self.tier):
            raise RuntimeError(missing_message(runtime_status(self.tier)))

        self.stage = STAGE_DEPTH
        self._process, self._workdir, self._output, self._log = \
            _start_worker(self._prepared)

    # -- drive ---------------------------------------------------------
    def poll(self):
        """Return "running", "done" or "error"; never blocks."""
        if self.cancelled:
            return "error"
        if self.stage == "ready":
            return "done"
        if self._process is None:
            return "error"
        code = self._process.poll()
        if code is None:
            return "running"
        if code != 0:
            try:
                _read_worker_output(self._output, self._log, self._prepared)
                self.error = _("深度推理失败")
            except Exception as error:  # noqa: BLE001
                self.error = str(error)
            self._cleanup()
            return "error"
        try:
            self._arrays = _read_worker_output(
                self._output, self._log, self._prepared)
        except Exception as error:  # noqa: BLE001
            self.error = str(error)
            self._cleanup()
            return "error"
        self.stage = "ready"
        self._cleanup()
        return "done"

    def wait(self, timeout=None):
        """Blocking wait, used by generate()."""
        deadline = None if timeout is None else time.time() + timeout
        while True:
            state = self.poll()
            if state != "running":
                return state
            if deadline is not None and time.time() > deadline:
                self.cancel()
                raise RuntimeError(_("深度推理超时"))
            time.sleep(0.05)

    def cancel(self):
        """Terminate the worker and remove every temporary artefact."""
        self.cancelled = True
        process = self._process
        if process is not None and process.poll() is None:
            try:
                process.terminate()
                process.wait(timeout=5)
            except Exception:  # noqa: BLE001
                try:
                    process.kill()
                except Exception:  # noqa: BLE001
                    pass
        self._cleanup()

    def _cleanup(self):
        if self._workdir is not None:
            shutil.rmtree(self._workdir, ignore_errors=True)
            self._workdir = None
        self._output = None
        self._log = None

    def finish(self):
        """Build the mesh for this job (caller owns selection/undo)."""
        import numpy as np

        if self._arrays is None:
            raise RuntimeError(_("深度结果尚未就绪"))
        arrays = self._arrays
        # "背景推远" is applied inside build_mesh, after the depth field is
        # blurred: replacing the background first let the blur and the
        # bilinear sampling drag the far plane into the contour ring.
        if getattr(self, "frame_rect", None) is not None:
            _x0, _y0, width, height = self.frame_rect
            arrays = dict(arrays)
            intrinsics = np.array(
                arrays["intrinsics"], dtype=np.float32, copy=True)
            # The worker fits intrinsics for the crop; the geometry below is
            # in full-frame normalized coordinates, so scale them back.
            intrinsics[0, 0] *= width
            intrinsics[1, 1] *= height
            arrays["intrinsics"] = intrinsics
        return build_mesh(
            self._context, self.plate, self.camera, arrays, self.params,
            self.plate_distance, self.homography, self.source_size,
            frame_rect=getattr(self, "frame_rect", None),
            border_cells=getattr(self, "border_cells", None),
            mesh_origin=getattr(self, "mesh_origin", None),
        )


# ------------------------------------------------------------------ mesh

def _sample_vec(array, xs, ys):
    """Vectorised bilinear sample with clamped edges."""
    import numpy as np

    height, width = array.shape[:2]
    xs = np.clip(np.asarray(xs, dtype=np.float32), 0.0, width - 1.0)
    ys = np.clip(np.asarray(ys, dtype=np.float32), 0.0, height - 1.0)
    x0 = np.floor(xs).astype(np.int64)
    y0 = np.floor(ys).astype(np.int64)
    x1 = np.minimum(x0 + 1, width - 1)
    y1 = np.minimum(y0 + 1, height - 1)
    fx = (xs - x0).astype(np.float32)
    fy = (ys - y0).astype(np.float32)
    top = array[y0, x0] * (1 - fx) + array[y0, x1] * fx
    bottom = array[y1, x0] * (1 - fx) + array[y1, x1] * fx
    return top * (1 - fy) + bottom * fy


def _sample(array, x, y):
    """Bilinear sample with clamped edges."""
    import numpy as np

    height, width = array.shape[:2]
    x = np.clip(x, 0.0, width - 1.0)
    y = np.clip(y, 0.0, height - 1.0)
    x0 = np.floor(x).astype(int)
    y0 = np.floor(y).astype(int)
    x1 = np.minimum(x0 + 1, width - 1)
    y1 = np.minimum(y0 + 1, height - 1)
    fx = x - x0
    fy = y - y0
    top = array[y0, x0] * (1 - fx) + array[y0, x1] * fx
    bottom = array[y1, x0] * (1 - fx) + array[y1, x1] * fx
    return top * (1 - fy) + bottom * fy


def _blur_depth(array, iterations):
    """Small separable box blur that keeps the depth field stable."""
    import numpy as np

    result = np.array(array, dtype=np.float32)
    for _ in range(max(0, int(iterations))):
        padded = np.pad(result, 1, mode="edge")
        acc = padded[:-2, 1:-1].copy()          # in-place keeps allocations down
        acc += padded[2:, 1:-1]
        acc += padded[1:-1, :-2]
        acc += padded[1:-1, 2:]
        acc += result
        acc *= np.float32(0.2)
        result = acc
    return result


def _project_uv(u, v, homography, source_size):
    """Plate UV -> normalized camera position through the homography."""
    src_x = u * source_size[0]
    src_y = (1.0 - v) * source_size[1]
    denominator = (homography[2, 0] * src_x
                   + homography[2, 1] * src_y + homography[2, 2])
    cam_x = (homography[0, 0] * src_x + homography[0, 1] * src_y
             + homography[0, 2]) / denominator
    cam_y = (homography[1, 0] * src_x + homography[1, 1] * src_y
             + homography[1, 2]) / denominator
    return cam_x, cam_y


def _matrix_tag(matrix):
    return tuple(round(float(matrix[row][col]), 6)
                 for row in range(4) for col in range(4))


def prep_signature(context, plate, camera, params):
    """Everything a BlockoutJob bakes in; a match means it can be reused."""
    image = find_image(plate)
    scene = context.scene
    return (
        plate.name, camera.name,
        _image_tag(image) if image is not None else None,
        _matrix_tag(plate.matrix_world), _matrix_tag(camera.matrix_world),
        float(camera.data.lens), float(camera.data.shift_x),
        float(camera.data.shift_y), float(camera.data.sensor_width),
        int(scene.render.resolution_x), int(scene.render.resolution_y),
        int(params.get("level", 5)),
        str(params.get("tier") or active_tier()),
    )


def _remember(store, key, value, limit):
    """Insert into a small dict cache, dropping the oldest entry first."""
    if len(store) >= limit:
        store.pop(next(iter(store)))
    store[key] = value


def _image_tag(image):
    """Cheap identity of an image, for the stage-A cache key."""
    packed = image.packed_file
    if packed is not None:
        stamp = ("packed", int(packed.size))
    else:
        try:
            stat = os.stat(bpy.path.abspath(image.filepath))
            stamp = ("file", int(stat.st_size), int(stat.st_mtime))
        except OSError:
            stamp = ("file", str(image.filepath), 0)
    return (image.name, tuple(int(v) for v in image.size), stamp,
            bool(image.is_dirty))


def _build_mask_and_rings(image, stride, cut, grow_px, trim):
    """Stage A: alpha -> binary mask -> dilated mask -> contour rings."""
    import numpy as np

    pw, ph = image.size
    buf = np.empty(pw * ph * 4, dtype=np.float32)
    image.pixels.foreach_get(buf)
    alpha = buf.reshape(ph, pw, 4)[..., 3][::-1]
    small = alpha[::stride, ::stride]
    mask, _stats = _mask.build_mask(small, cut, assume_unit=True)
    if not mask.any():
        raise ValueError(_("这张图没有有效内容"))
    # Undilated copy.  Holes are carved out of the triangulated mesh using the
    # true transparent area; ``mask`` grows by ``grow_px`` and would close a
    # 2-4 px hole before the carve ever sees it.
    mask0 = mask
    holes = _hole_mask(mask0) if trim else np.zeros_like(mask0)
    if grow_px > 0:
        mask = _mask.dilate_mask(mask, grow_px)

    rings = []
    prev_idx = np.empty(0, dtype=np.int64)
    next_idx = np.empty(0, dtype=np.int64)
    if trim:
        raw = _outline.trace_rings(mask, min_points=4)
        if raw:
            simplified = _simplify.simplify_rings(
                [np.asarray(ring, dtype=np.float64) for ring in raw],
                CONTOUR_TOL)
            pieces = []
            prevs = []
            nexts = []
            offset = 0
            for ring in simplified:
                arr = np.asarray(ring, dtype=np.float64)
                if len(arr) < 3:
                    continue
                pieces.append(arr)
                count = len(arr)
                prevs.append((np.arange(count) - 1 + count) % count + offset)
                nexts.append((np.arange(count) + 1) % count + offset)
                offset += count
            if pieces:
                rings = pieces
                prev_idx = np.concatenate(prevs)
                next_idx = np.concatenate(nexts)
    return {"mask": mask, "mask0": mask0, "holes": holes, "rings": rings,
            "prev": prev_idx, "next": next_idx}


def _hole_mask(mask0):
    """Interior transparent regions of the raw silhouette (holes only).

    Carving with ``~mask0`` would also eat the triangles that straddle the
    outer rim (their centroids sit in the transparent band between the
    contour and the alpha edge), which shows up as a notch on a shoulder.
    Filling the silhouette first keeps the carve to enclosed holes.
    """
    import numpy as np

    h, w = mask0.shape
    # Fill the OUTER rings only: an even-odd fill that also takes the inner
    # rings would cancel exactly the holes we are looking for.
    rings, _inner = _outline.split_outer(
        [np.asarray(r, np.float64)
         for r in _outline.trace_rings(mask0, min_points=4)])
    filled = np.zeros((h, w), dtype=bool)
    if not rings:
        return filled
    x0 = np.concatenate([np.asarray(r, np.float64)[:, 0] for r in rings])
    y0 = np.concatenate([np.asarray(r, np.float64)[:, 1] for r in rings])
    x1 = np.concatenate([np.roll(np.asarray(r, np.float64)[:, 0], -1)
                         for r in rings])
    y1 = np.concatenate([np.roll(np.asarray(r, np.float64)[:, 1], -1)
                         for r in rings])
    keep = y0 != y1
    x0, y0, x1, y1 = x0[keep], y0[keep], x1[keep], y1[keep]
    lo = np.ceil(np.minimum(y0, y1) - 0.5).astype(np.int64)
    hi = np.floor(np.maximum(y0, y1) - 0.5).astype(np.int64)
    rows = []
    xs = []
    for i in range(len(x0)):
        if hi[i] < lo[i]:
            continue
        yy = np.arange(lo[i], hi[i] + 1, dtype=np.float64) + 0.5
        rows.append(yy)
        xs.append(x0[i] + (yy - y0[i]) * (x1[i] - x0[i]) / (y1[i] - y0[i]))
    if not rows:
        return filled
    rows = np.concatenate(rows)
    xs = np.concatenate(xs)
    order = np.lexsort((xs, rows))
    rows = rows[order].astype(np.int64)
    xs = xs[order]
    edge = np.ones(len(rows), dtype=bool)
    edge[1:] = rows[1:] != rows[:-1]
    starts = np.nonzero(edge)[0]
    ends = np.append(starts[1:], len(rows))
    for a, b in zip(starts, ends):
        ry = rows[a]
        if ry < 0 or ry >= h:
            continue
        # Staircase contours give two crossings at the same x along a
        # straight side; keeping both pairs them with each other and fills
        # nothing, so collapse duplicates first.
        seg = np.unique(xs[a:b])
        if len(seg) < 2:
            continue
        for k in range(0, len(seg) - 1, 2):
            lo_x = max(int(np.ceil(seg[k] - 0.5)), 0)
            hi_x = min(int(np.floor(seg[k + 1] - 0.5)), w - 1)
            if hi_x >= lo_x:
                filled[ry, lo_x:hi_x + 1] = True
    return filled & ~mask0


def _build_topology(ablob, grid, trim, homography, source_size, frame,
                    width, height):
    """Stage B: triangulate the contour, then map vertices to UV / camera.

    Vertices come from the contour itself (image_cutter's triangulator), so a
    spire narrower than one cell keeps its tip: there is a vertex on the
    contour instead of two snapped grid corners cutting a chord across it.
    """
    import numpy as np

    mask = ablob["mask"]
    mask_h, mask_w = mask.shape
    spacing = max(mask_w, mask_h) / float(grid)

    if trim:
        rings = ablob["rings"]
        # Enclosed holes of the undilated silhouette.  Taking ``~mask0`` whole
        # would also carve the rim band and notch the outline.
        carve_mask = ablob["holes"]
    else:
        # 裁形关: the whole plate is geometry, so the frame rectangle is the
        # only ring and nothing is carved out of it.
        rings = [np.array([[0.0, 0.0], [float(mask_w), 0.0],
                           [float(mask_w), float(mask_h)], [0.0, float(mask_h)]],
                          dtype=np.float64)]
        carve_mask = None

    outer, _inner = _outline.split_outer(
        [np.asarray(r, dtype=np.float64) for r in rings])
    result = _tri.build_mesh(
        [np.asarray(r, dtype=np.float64) for r in outer], spacing,
        carve_mask=carve_mask)
    points = np.asarray(result["points"], dtype=np.float64)
    faces = np.asarray(result["faces"], dtype=np.int64)
    if not len(faces):
        raise ValueError(_("透明区域裁掉后没有剩下几何"))

    uv = np.stack((points[:, 0] / mask_w, 1.0 - points[:, 1] / mask_h), axis=1)
    loops = faces.ravel().astype(np.int32)

    src_x = uv[:, 0] * source_size[0]
    src_y = (1.0 - uv[:, 1]) * source_size[1]
    den = (homography[2, 0] * src_x + homography[2, 1] * src_y
           + homography[2, 2])
    cam_x = (homography[0, 0] * src_x + homography[0, 1] * src_y
             + homography[0, 2]) / den
    cam_y = (homography[1, 0] * src_x + homography[1, 1] * src_y
             + homography[1, 2]) / den
    frame_x0, frame_y0, frame_w, frame_h = frame
    px = ((cam_x - frame_x0) / frame_w) * (width - 1)
    py = (1.0 - (cam_y - frame_y0) / frame_h) * (height - 1)
    return {
        "uv": uv, "cam_x": cam_x, "cam_y": cam_y, "px": px, "py": py,
        "loops": loops,
        "starts": np.arange(0, loops.size, 3, dtype=np.int32),
        "count": int(len(points)),
    }


def _ring_fold_quads(points, a, b, out):
    """Slots of the band quads that intersect another quad.

    ``a`` / ``b`` are the border edges (pairs of vertex ids), ``out`` maps a
    border vertex to its pushed-out position.  Module level so tests can spy
    on it and enumerate the folding slots.
    """
    from mathutils.bvhtree import BVHTree

    verts = []
    index = {}
    rows = []

    def vid(key, co):
        slot = index.get(key)
        if slot is None:
            slot = len(verts)
            index[key] = slot
            verts.append(co)
        return slot

    for slot in range(len(a)):
        va, vb = int(a[slot]), int(b[slot])
        quad = (vid(("b", va), points[va]), vid(("b", vb), points[vb]),
                vid(("r", vb), out[vb]), vid(("r", va), out[va]))
        rows.append(quad)
    tree = BVHTree.FromPolygons(verts, rows, all_triangles=False)
    pairs = tree.overlap(tree)
    owners = [set(quad) for quad in rows]
    seen = set()
    folding = set()
    for first, second in pairs:
        if first == second:
            continue
        key = (min(first, second), max(first, second))
        if key in seen:
            continue
        seen.add(key)
        if owners[first] & owners[second]:
            continue
        folding.add(first)
        folding.add(second)
    return folding


def _grow_border(world, uv, loops, cells):
    """Weld one quad ring to the open border, then push its rim outward.

    ``cells`` is measured in grid cells of the mesh being built.  The rim is
    an outward offset of the border polyline (miter, capped at 2x) relaxed a
    few times so concave corners cannot fold through each other.  Only the
    border vertices are shared; every other vertex and quad is untouched.

    Returns ``(world, uv, loops, stats)`` with fresh arrays; ``stats`` reports
    how many faces and rings were added so the caller can log it.
    """
    import numpy as np

    empty = {"faces": 0, "edges": 0, "rings": 0, "open_chains": 0,
             "width": 0.0, "skipped": False}
    faces = np.asarray(loops, dtype=np.int64).reshape(-1, 4)
    if faces.size == 0 or float(cells) <= 1e-6:
        return world, uv, loops, empty

    points = np.asarray(world, dtype=np.float64)
    texcoords = np.asarray(uv, dtype=np.float64)
    count = faces.shape[0]

    # directed edges in face winding order
    following = np.roll(np.arange(4), -1)
    edges = np.stack((faces, faces[:, following]), axis=2).reshape(-1, 2)
    keys = np.sort(edges, axis=1)
    _unique, inverse, counts = np.unique(
        keys, axis=0, return_inverse=True, return_counts=True)
    border_mask = counts[inverse] == 1
    border = edges[border_mask]
    border_face = np.nonzero(border_mask)[0] // 4
    if not len(border):
        return world, uv, loops, empty

    # face frames
    p0, p1 = points[faces[:, 0]], points[faces[:, 1]]
    p2, p3 = points[faces[:, 2]], points[faces[:, 3]]
    fnorm = np.cross(p2 - p0, p3 - p1)
    length = np.linalg.norm(fnorm, axis=1)
    length[length < 1e-12] = 1e-12
    fnorm /= length[:, None]
    centroids = (p0 + p1 + p2 + p3) * 0.25

    # per-edge outward vector, in the tangent plane of its face
    a, b = border[:, 0], border[:, 1]
    tangent = points[b] - points[a]
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1), 1e-12)[:, None]
    outward = np.cross(fnorm[border_face], tangent)
    outward /= np.maximum(np.linalg.norm(outward, axis=1), 1e-12)[:, None]
    mids = (points[a] + points[b]) * 0.5
    flip = np.einsum("ij,ij->i", outward, mids - centroids[border_face]) < 0.0
    outward[flip] *= -1.0

    edge_lengths = np.linalg.norm(points[b] - points[a], axis=1)
    spacing = float(np.median(edge_lengths)) if len(edge_lengths) else 1.0

    per_vertex = {}
    adjacency = {}
    for index in range(len(a)):
        va, vb = int(a[index]), int(b[index])
        per_vertex.setdefault(va, []).append(outward[index])
        per_vertex.setdefault(vb, []).append(outward[index])
        adjacency.setdefault(va, []).append(vb)
        adjacency.setdefault(vb, []).append(va)

    # ordered border rings; open chains (a border cut by the frame) are left
    # alone and counted once instead of aborting the whole rebuild.
    visited = set()
    rings = []
    open_chains = 0
    for start in adjacency:
        if start in visited:
            continue
        ring = [start]
        visited.add(start)
        previous, current = None, start
        closed = False
        while True:
            options = [v for v in adjacency[current] if v != previous]
            if not options:
                break
            step = options[0]
            if step == start:
                closed = True
                break
            if step in visited:
                break
            visited.add(step)
            ring.append(step)
            previous, current = current, step
        if closed and len(ring) >= 3 and all(len(adjacency[v]) == 2
                                             for v in ring):
            rings.append(ring)
        else:
            open_chains += 1

    # Per-vertex cell size: on a steep plate a global median makes the ring
    # narrow where the grid is stretched out (measured on a 0.5 m/M slope).
    shared = {}
    for face in range(count):
        corners = faces[face]
        for slot in range(4):
            shared.setdefault(int(corners[slot]), set()).update(
                int(corners[other]) for other in range(4) if other != slot)
    directions = {}
    scales = {}
    for vertex, vectors in per_vertex.items():
        if len(vectors) == 2:
            first, second = vectors
            dot = max(-0.9, min(1.0, float(np.dot(first, second))))
            # 2/(1+dot) instead of the textbook sqrt(2/(1+dot)): measured on
            # the test asset it removes corner folds (self-intersections 5->0
            # at width 1, 15->0 at width 2); the corner band is ~40% wider
            # than a perfect miter, which the relaxation pass evens out.
            scale = min(2.0, 2.0 / (1.0 + dot))
            direction = first + second
            length = float(np.linalg.norm(direction))
            if length < 1e-9:
                direction = np.array(first, dtype=np.float64)
                length = float(np.linalg.norm(direction))
        else:
            scale = 1.0
            direction = np.array(vectors[0], dtype=np.float64)
            length = float(np.linalg.norm(direction))
        directions[vertex] = direction / max(length, 1e-12)
        scales[vertex] = scale

    # One cell is the global median border edge.  Per-vertex local spacing
    # (or the inward-neighbour projection) was measured too: on the 1.2-deep
    # steep fixture it widened corners until the ring folded (self-hit at
    # width 1), so the uniform cell is kept and the steep-plate width spread
    # is reported instead.
    border_vertices = set(per_vertex)
    inward = {}
    for vertex, direction in directions.items():
        reference, best = None, 0.0
        for other in shared.get(vertex, ()):
            if other in border_vertices:
                continue
            delta = points[other] - points[vertex]
            score = -float(delta.dot(direction))
            if score > best:
                best = score
                reference = other
        distance = 0.0
        if reference is not None:
            distance = float(np.linalg.norm(
                points[reference] - points[vertex]))
        inward[vertex] = (reference, distance)

    relax = BORDER_RELAX_WIDE if float(cells) > 4.0 else BORDER_RELAX

    def rim_positions(width):
        out = {}
        for vertex, direction in directions.items():
            out[vertex] = points[vertex] + direction * (
                float(width) * spacing * scales[vertex])
        for ring in rings:
            arr = np.array([out[v] for v in ring], dtype=np.float64)
            for _ in range(relax):
                arr = arr * 0.5 + (np.roll(arr, 1, axis=0)
                                   + np.roll(arr, -1, axis=0)) * 0.25
            for vertex, co in zip(ring, arr):
                out[vertex] = co
        return out

    concave = any(len(per_vertex[v]) == 2
                  and float(np.dot(*per_vertex[v])) < 0.2 for v in per_vertex)

    def ring_folds(out):
        """True when the ring band intersects itself (same test as delivery)."""
        return bool(_ring_fold_quads(points, a, b, out))

    # A concave border on a sloped plate folds its offset curve (star + 1.2
    # drop: 18 pairs at width 2).  Pulling single vertices back only turns the
    # quads into self-intersecting slivers, so narrow the whole ring until it
    # is simple; below one cell the ring is dropped instead of shipped folded.
    width = float(cells)
    positions = rim_positions(width)
    fold = (_ring_fold_quads(points, a, b, positions)
            if (concave and rings) else set())
    if fold:
        for _try in range(10):
            if width <= 1.0:
                break
            width = max(1.0, width * 0.8)
            positions = rim_positions(width)
            step = _ring_fold_quads(points, a, b, positions)
            if not step:
                fold = set()
                break
            fold = step
    slots = len(a)
    # Only the intersecting quads are dropped; the whole ring still goes when
    # every quad folds (no usable band left).
    if fold and len(fold) >= slots:
        print("[Compify|Blockout] 边缘补边：凹角处一圈放不下，已跳过")
        return world, uv, loops, {"faces": 0, "edges": len(border),
                                  "rings": len(rings),
                                  "open_chains": open_chains,
                                  "width": 0.0, "skipped": True,
                                  "dropped": 0, "partial": False}
    keep_slots = [slot for slot in range(slots) if slot not in fold]

    used = set()
    for slot in keep_slots:
        used.add(int(a[slot]))
        used.add(int(b[slot]))
    rim = {}
    for vertex in used:
        rim[vertex] = (positions[vertex], directions[vertex])

    # UV continues one interior cell per ring cell, outward.  The reference
    # lies inward, so the outward continuation is the opposite direction: UV
    # must keep going past the border, not fold back over the object (the
    # first 3.1.8 build had this sign flipped).
    rim_uv = {}
    for vertex in rim:
        reference, distance = inward[vertex]
        if reference is not None and distance > 1e-9:
            # One ring cell advances the texture by one interior cell.  The
            # clamp stops a snapped border vertex whose interior neighbour is
            # nearly on top of it from shooting the UV across the image.
            ratio = min(width * spacing / distance, width * 2.0)
            rim_uv[vertex] = texcoords[vertex] - (
                texcoords[reference] - texcoords[vertex]) * ratio
        else:
            rim_uv[vertex] = texcoords[vertex].copy()

    order = sorted(rim)
    index_of = {vertex: len(points) + slot for slot, vertex in enumerate(order)}
    rim_points = np.array([rim[vertex][0] for vertex in order], dtype=np.float64)
    rim_texcoords = np.array([rim_uv[vertex] for vertex in order],
                             dtype=np.float64)

    all_points = np.concatenate((points, rim_points), axis=0)
    quads = []
    for slot in keep_slots:
        va, vb = int(a[slot]), int(b[slot])
        quad = [va, vb, index_of[vb], index_of[va]]
        corners = all_points[quad]
        normal = np.cross(corners[2] - corners[0], corners[3] - corners[1])
        if float(normal.dot(fnorm[border_face[slot]])) < 0.0:
            quad.reverse()
        quads.append(quad)

    new_loops = np.concatenate(
        (np.asarray(loops, dtype=np.int64).ravel(),
         np.asarray(quads, dtype=np.int64).ravel())).astype(np.int32)
    stats = {"faces": len(quads), "edges": len(border),
             "rings": len(rings), "open_chains": open_chains,
             "width": width, "skipped": False,
             "dropped": int(slots - len(keep_slots)),
             "partial": bool(keep_slots) and len(keep_slots) < slots}
    return all_points, np.concatenate((texcoords, rim_texcoords), axis=0), \
        new_loops, stats


def _write_mesh(name, world, blob, material):
    """Build the mesh through foreach_set; from_pydata costs ~10x more."""
    import numpy as np

    mesh = bpy.data.meshes.new(name)
    loops = blob["loops"]
    starts = blob["starts"]
    mesh.vertices.add(int(len(world)))
    mesh.vertices.foreach_set(
        "co", np.ascontiguousarray(world, dtype=np.float32).ravel())
    mesh.loops.add(int(loops.size))
    mesh.loops.foreach_set("vertex_index", loops)
    mesh.polygons.add(int(starts.size))
    mesh.polygons.foreach_set("loop_start", starts)
    mesh.polygons.foreach_set("use_smooth",
                              np.ones(int(starts.size), dtype=bool))
    mesh.update(calc_edges=True)
    uv_layer = mesh.uv_layers.new(name="UVMap")
    uv_layer.data.foreach_set(
        "uv", np.ascontiguousarray(blob["uv"][loops],
                                   dtype=np.float32).ravel())
    if material is not None:
        mesh.materials.append(material)
    return mesh


def build_mesh(
    context, source_object, camera, arrays, params,
    plate_distance, homography, source_size, frame_rect=None,
    border_cells=None, mesh_origin=None,
):
    """Create the blockout mesh and return the object.

    ``frame_rect`` is (x0, y0, width, height) in normalized camera coordinates
    describing which sub-rectangle of the camera view the depth arrays cover.
    None means the arrays cover the whole view (the normal pipeline).
    """
    import numpy as np

    depth = np.asarray(arrays["depth"], dtype=np.float32)
    intrinsics = np.asarray(arrays["intrinsics"], dtype=np.float32)
    height, width = depth.shape
    fx = float(intrinsics[0, 0])
    fy = float(intrinsics[1, 1])

    grid = int(params.get("grid", 128))
    strength = float(params.get("strength", 1.0))
    trim = bool(params.get("trim", False))
    threshold = float(params.get("threshold", ALPHA_THRESHOLD))
    outward = float(params.get("outward", 2.0))
    smooth = int(params.get("smooth", 1))
    preview = bool(params.get("preview"))

    marks = [time.perf_counter()]

    # ---- depth field: cached per (depth buffer, smooth) ------------------
    depth_raw = arrays["depth"]
    z_key = (id(depth_raw), smooth)
    zblob = _Z_CACHE.get(z_key)
    if zblob is not None and zblob["source"] is not depth_raw:
        # A recycled object address must never hand over another plate's depth.
        zblob = None
    if zblob is None:
        usable = np.isfinite(depth) & (depth > 0)
        if not usable.any():
            raise ValueError(_("这张图没有有效内容"))
        blurred = _blur_depth(depth, smooth)
        # Percentile on a stride sample: full-array extraction and sorting of
        # a 3M-pixel depth field costs more than the whole mesh rebuild.
        step = max(1, int(blurred.size // 400000))
        sample = blurred.ravel()[::step][usable.ravel()[::step]]
        zblob = {
            "source": depth_raw,
            "depth": blurred,
            "usable": usable.astype(np.float32),
            "reference": (float(np.percentile(sample, 95.0))
                          if sample.size else 1.0),
        }
        _remember(_Z_CACHE, z_key, zblob, 3)
    marks.append(time.perf_counter())            # 1: depth field

    # ---- stage A: mask + contour, keyed by image + threshold + outward ---
    plate_image = find_image(source_object)
    if plate_image is None or plate_image.size[0] == 0:
        raise ValueError(_("这张图没有图像"))
    pw, ph = plate_image.size
    mask_cap = MASK_CAP_PREVIEW if preview else MASK_CAP
    stride = max(1, int(math.ceil(max(pw, ph) / mask_cap)))
    cut = float(threshold) if threshold > 0.0 else 1.0 / 255.0
    grow_px = int(round(float(outward) / stride))
    if threshold <= 0.0:
        # T=0 keeps every pixel with any alpha; one extra mask pixel covers the
        # soft fringe that a plain binary cut would shave off.
        grow_px += max(1, int(round(1.0 / stride)))
    image_tag = _image_tag(plate_image)
    a_key = (image_tag, stride, round(cut, 4), grow_px, trim)
    # An unsaved edit (texture paint) can change pixels without changing the
    # tag, so never trust the cache while the image is dirty.
    fresh = bool(plate_image.is_dirty)
    ablob = None if fresh else _A_CACHE.get(a_key)
    if ablob is None:
        ablob = _build_mask_and_rings(plate_image, stride, cut, grow_px, trim)
        if not fresh:
            _remember(_A_CACHE, a_key, ablob, 6)
    marks.append(time.perf_counter())            # 2: contour (stage A)

    # ---- stage B: topology - faces, UVs, depth sample points -------------
    frame = (frame_rect if frame_rect is not None
             else (0.0, 0.0, 1.0, 1.0))
    # Only the size may need the zero guard: x0 / y0 = 0 is a legal origin
    # (full-frame framing is exactly (0, 0, 1, 1)).
    frame = (float(frame[0]), float(frame[1]),
             float(frame[2]) if abs(float(frame[2])) > 1e-9 else 1.0,
             float(frame[3]) if abs(float(frame[3])) > 1e-9 else 1.0)
    b_key = (a_key, grid, trim,
             tuple(np.round(np.asarray(homography, dtype=np.float64),
                            6).ravel().tolist()),
             frame, tuple(int(v) for v in source_size),
             int(width), int(height))
    bblob = None if fresh else _B_CACHE.get(b_key)
    if bblob is None:
        bblob = _build_topology(ablob, grid, trim, homography, source_size,
                                frame, width, height)
        if not fresh:
            _remember(_B_CACHE, b_key, bblob, 4)
    marks.append(time.perf_counter())            # 3: topology (stage B)

    # ---- stage C: sample the depth, displace, write the mesh -------------
    z_values = _sample_vec(zblob["depth"], bblob["px"], bblob["py"])
    validity = _sample_vec(zblob["usable"], bblob["px"], bblob["py"])
    bad = (validity < 0.5) | ~np.isfinite(z_values)
    reference = zblob["reference"]
    z_values = np.where(bad, np.float32(reference), z_values)
    scale = plate_distance / max(reference, 1e-6)
    z_full = z_values * scale
    z_pose = plate_distance + (z_full - plate_distance) * strength
    nx = (bblob["cam_x"] - 0.5) / fx * z_pose
    ny = (bblob["cam_y"] - 0.5) / fy * z_pose
    points = np.stack((nx, ny, -z_pose), axis=1)
    matrix = np.array(camera.matrix_world, dtype=np.float64)
    world = points @ matrix[:3, :3].T + matrix[:3, 3]

    # ---- border grow: paused, and guarded -------------------------------
    # _grow_border still writes quads (reshape(-1, 4), starts step 4), while
    # the mesh is triangles now, so this path cannot produce a correct face
    # set.  Rather than half-fixing it here (redoing border grow is its own
    # task), an explicit guard refuses to build instead of silently writing
    # a broken mesh.
    grow_world, grow_uv, grow_loops = world, bblob["uv"], bblob["loops"]
    write_blob = bblob
    border_note = ""
    BORDER_LAST.clear()
    if _BORDER_ENABLED and bool(params.get("border_grow", False)) and trim:
        raise ValueError(_("补边尚未适配三角网格，请先关闭补边"))

    # Store vertices relative to the source's world-space origin.  New output
    # objects use that same origin, so their initial visible geometry remains
    # identical while the object's rotation center is useful to the user.
    source_origin = source_object.matrix_world.translation.copy()
    origin = (source_origin if mesh_origin is None else
              np.asarray(mesh_origin, dtype=np.float64))
    origin_tuple = tuple(float(value) for value in origin)
    # Subtract the target frame while coordinates are still float64.  Writing
    # a source-relative float32 mesh and translating it back later loses detail
    # when the source origin is far from the model's original origin.
    mesh_points = grow_world - np.asarray(origin_tuple, dtype=np.float64)
    mesh = _write_mesh(f"{source_object.name}_起模", mesh_points, write_blob,
                       source_object.active_material)
    # Normals: the ring shares border vertices, so smooth shading tilts their
    # normals.  Measured on the test asset: median <=0.3 deg, max <=2.5 deg at
    # threshold 0.5 (the visible case); only threshold 0, where the rim sits on
    # alpha 0 pixels, reaches ~25 deg.  A whole-layer custom-normal pass fixed
    # that but cost 25 ms per build, over the +20 ms budget, so it is not used.
    marks.append(time.perf_counter())            # 4: placement + mesh write

    blockout = bpy.data.objects.new(f"{source_object.name}_起模", mesh)
    collection = ensure_collection(context.scene)
    collection.objects.link(blockout)
    blockout.location = origin_tuple
    blockout[PROP_SOURCE] = source_object.name
    blockout[PROP_CAMERA] = camera.data.name
    blockout[PROP_PARAMS] = json.dumps(params, ensure_ascii=False)
    blockout[PROP_ORIGIN] = origin_tuple
    settings = getattr(blockout, "compify_blockout", None)
    if settings is not None:
        settings.threshold = float(params.get("threshold", 0.0))
        settings.outward = float(params.get("outward", 2.0))
        settings.density = int(params.get("grid", 128))
        settings.strength = float(params.get("strength", 1.0))
        settings.smooth = int(params.get("smooth", 1))
        settings.trim = bool(params.get("trim", False))
        settings.border_grow = bool(params.get("border_grow", False))
        settings.border_width = int(params.get("border_width", 2))
        try:
            settings.cap_note = border_note
        except AttributeError:
            pass
        settings.built = True
    # Writing those settings fires their update callbacks, which would queue a
    # redundant preview rebuild of a mesh that is already exact.
    try:
        from . import blockout_live as _live
        _live.forget(blockout)
    except Exception:  # noqa: BLE001
        pass
    marks.append(time.perf_counter())           # 5: object + props
    steps = [(b - a) * 1000.0 for a, b in zip(marks, marks[1:])]
    STAGE_TIMES.clear()
    STAGE_TIMES.update({
        "Z": steps[0],
        "A": steps[1],
        "B": steps[2],
        "C": steps[3],
        "obj": steps[4],
        "total": sum(steps),
    })
    return blockout


def ensure_collection(scene):
    collection = bpy.data.collections.get(COLLECTION_NAME)
    if collection is None:
        # Older files still carry the previous name; adopt and rename it so
        # the outliner stops showing the old wording.
        legacy = bpy.data.collections.get(LEGACY_COLLECTION_NAME)
        if legacy is not None:
            legacy.name = COLLECTION_NAME
            collection = legacy
    if collection is None:
        collection = bpy.data.collections.new(COLLECTION_NAME)
        scene.collection.children.link(collection)
    return collection


# --------------------------------------------------------------- lookup

def blockouts_by_source(scene):
    """Map source plate name -> blockout objects present in this scene."""
    mapping = {}
    scene_objects = set(scene.objects)
    for obj in scene.objects:
        if obj.type != "MESH":
            continue
        source = obj.get(PROP_SOURCE)
        if source:
            mapping.setdefault(str(source), []).append(obj)
    return mapping


def blockouts_for_sources(scene, source_names):
    """Blockouts belonging to the given source plate names."""
    mapping = blockouts_by_source(scene)
    found = []
    for name in source_names:
        found.extend(mapping.get(name, ()))
    return found


def stored_params(obj):
    """Parameters of an existing blockout, or the defaults."""
    raw = obj.get(PROP_PARAMS) if obj is not None else None
    if not raw:
        return dict(DEFAULT_PARAMS)
    try:
        data = json.loads(str(raw))
    except (TypeError, ValueError):
        return dict(DEFAULT_PARAMS)
    params = dict(DEFAULT_PARAMS)
    params.update({k: data[k] for k in DEFAULT_PARAMS if k in data})
    return params


# ------------------------------------------------------------- batch plan

SKIP_NO_PROJECTION = "没有投射材质"
SKIP_OFFSCREEN = "不在摄像机画面内"
SKIP_ORTHO = "正交摄像机"
SKIP_NO_IMAGE = "没有可用的图像"


def classify_error(error):
    """Map an exception to a short Chinese skip reason."""
    text = str(error)
    if _("正交视角") in text or "orthographic" in text.lower():
        return SKIP_ORTHO
    if _("不在摄像机画面内") in text:
        return SKIP_OFFSCREEN
    if _("还没有投射材质") in text or _("图像") in text:
        return SKIP_NO_PROJECTION
    if _("没有有效内容") in text:
        return _("这张图没有有效内容")
    return text


def plan_batch(context, objects=None):
    """Split the selected meshes into work items and skip records."""
    objects = list(objects if objects is not None
                   else context.selected_objects)
    ordered = [o for o in objects if o.type == "MESH"]
    items, skipped = [], []
    for obj in ordered:
        camera = projection_camera(obj)
        if camera is None:
            skipped.append({"plate": obj.name, "reason": SKIP_NO_PROJECTION})
            continue
        if find_image(obj) is None:
            skipped.append({"plate": obj.name, "reason": SKIP_NO_IMAGE})
            continue
        items.append({"plate": obj.name, "camera": camera,
                      "object": obj, "camera_name": camera.name})
    return items, skipped


def blocked_reason(context, objects=None):
    """Plain-language reason generation cannot start; "" when it can."""
    pool = list(objects if objects is not None
                else context.selected_objects)
    items, skipped = plan_batch(context, objects)
    if items:
        return ""
    meshes = [obj for obj in pool if obj.type == "MESH"]
    if not meshes:
        return _("请先选中一张图平面")
    reasons = {record["reason"] for record in skipped}
    if reasons == {SKIP_NO_PROJECTION}:
        return _("所选图平面还没有投射材质，请先到分区 1 生成投射")
    if reasons == {SKIP_NO_IMAGE}:
        return _("所选图平面的投射里没有找到图片，请重新生成投射")
    if SKIP_NO_PROJECTION in reasons:
        return _("所选图平面里有的还没有投射材质，请先到分区 1 生成投射")
    records = [{"plate": record["plate"], "status": "skipped",
                "reason": record["reason"]} for record in skipped]
    return summarize(records, len(skipped)) or _("没有可生成的图平面")


def summarize(records, total=0):
    """Short Chinese summary of a finished batch."""
    ok = [r for r in records if r["status"] == "ok"]
    skipped = [r for r in records if r["status"] == "skipped"]
    failed = [r for r in records if r["status"] == "failed"]
    parts = []
    if ok:
        parts.append(_("已生成 {n} 个模型").format(n=len(ok)))
    counts = {}
    for record in skipped:
        counts[record["reason"]] = counts.get(record["reason"], 0) + 1
    for reason, count in counts.items():
        parts.append(_("{n} 个物体{reason}，已跳过").format(
            n=count, reason=reason))
    for record in failed:
        parts.append(_("{name} 生成失败：{reason}").format(
            name=record["plate"], reason=record["reason"]))
    if total and not parts:
        parts.append(_("没有可生成的物体"))
    return "；".join(parts)


class BatchSession:
    """Drives a queue of blockout jobs one at a time, without blocking."""

    SKIP_REASONS = (SKIP_NO_PROJECTION, SKIP_OFFSCREEN, SKIP_ORTHO,
                    SKIP_NO_IMAGE)

    def __init__(self, context, items, params, keep_source=True, skipped=None):
        self.context = context
        self.items = list(items)
        self.params = dict(params)
        self.keep_source = keep_source
        self.records = [
            {"plate": record["plate"], "status": "skipped",
             "reason": record["reason"]}
            for record in (skipped or [])
        ]
        self.created = []
        self._hidden = []
        self._index = 0
        self._job = None
        self.stage = STAGE_FRAME
        self.current_name = ""
        self.done = False

    @property
    def total(self):
        return len(self.items)

    @property
    def position(self):
        return min(self._index + 1, self.total) if self.total else 0

    def cancel(self):
        if self._job is not None:
            self._job.cancel()
            self._job = None
        for obj in self.created:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        self.created = []
        for plate in self._hidden:
            if plate.name in bpy.data.objects:
                plate.hide_set(False)
                plate.hide_render = False
        self._hidden = []
        self.done = True
        return self.records

    def _start_next(self):
        """Start the next queued plate, recording plates that cannot start."""
        while self._index < self.total:
            item = self.items[self._index]
            self.current_name = item["plate"]
            self.stage = STAGE_FRAME
            try:
                self._job = BlockoutJob(
                    self.context, item["object"], item["camera"], self.params)
                return
            except Exception as error:  # noqa: BLE001
                reason = classify_error(error)
                self.records.append({
                    "plate": item["plate"],
                    "status": ("skipped" if reason in self.SKIP_REASONS
                               else "failed"),
                    "reason": reason,
                })
                self._job = None
                self._index += 1
        self.done = True

    def step(self):
        """Advance the queue; returns a progress dict."""
        if self.done:
            return self.progress()
        if self._job is None:
            self._start_next()
            if self.done:
                return self.progress()

        state = self._job.poll()
        self.stage = self._job.stage if state == "running" else STAGE_MESH
        if state == "running":
            return self.progress()

        if state == "error":
            self.records.append({
                "plate": self._job.plate.name,
                "status": "failed",
                "reason": self._job.error or _("深度推理失败"),
            })
            self._job = None
            self._index += 1
            return self.progress()

        # ready -> geometry
        item = self.items[self._index]
        try:
            obj = self._job.finish()
            self.created.append(obj)
            self._apply_source_visibility(item["object"])
            self.records.append({
                "plate": item["plate"], "status": "ok", "reason": ""})
        except Exception as error:  # noqa: BLE001
            self.records.append({
                "plate": item["plate"], "status": "failed",
                "reason": classify_error(error)})
        self._job = None
        self._index += 1
        if self._index >= self.total:
            self.done = True
        return self.progress()

    def _apply_source_visibility(self, plate):
        if self.keep_source:
            plate.hide_set(True)
            plate.hide_render = True
            self._hidden.append(plate)
        else:
            if plate.name in bpy.data.objects:
                bpy.data.objects.remove(plate, do_unlink=True)

    def progress(self):
        return {
            "done": self.done,
            "stage": self.stage,
            "position": self.position,
            "total": self.total,
            "name": self.current_name,
            "cancelled": bool(self.records) and self.done and not self.created
            and self._job is None and self._index < self.total,
        }

    def summary(self):
        return summarize(self.records, self.total)


# -------------------------------------------------------------- pipeline

def begin_job(context, source_object, camera, params):
    return BlockoutJob(context, source_object, camera, params)


def generate(context, source_object, camera, params):
    """Run the whole blockout pipeline for one plate (synchronous)."""
    job = BlockoutJob(context, source_object, camera, params)
    state = job.wait()
    if state != "done":
        raise RuntimeError(job.error or _("深度推理失败"))
    return job.finish()
