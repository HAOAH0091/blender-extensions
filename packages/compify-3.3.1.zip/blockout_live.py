"""Live rebuild for blockout objects: parameters live on the object.

Dragging a slider schedules a timer rebuild: a coarse preview while the value
keeps changing, an exact rebuild once it has been still for PREVIEW_IDLE
seconds. Depth inference stays in the on-disk cache, so only geometry runs.
"""

import json
import math
import os
import time

import bpy

from . import blockout

PENDING = set()
# Object name -> (prep signature, BlockoutJob) so a drag does not redo the
# hashing and camera math for a plate that has not moved.
_PREP = {}
LAST_TOUCH = {}
IMMEDIATE = set()
PREVIEW_IDLE = 0.30
PREVIEW_INTERVAL = 0.065
PREVIEW_DIVISOR = 2

REBUILD_NOT_IN_UNDO = "参数重建不进撤销栈，Ctrl+Z 不会回退网格形状"


def forget(obj):
    """Drop any queued rebuild for this object (used right after generation)."""
    if obj is None:
        return
    name = obj.name
    PENDING.discard(name)
    LAST_TOUCH.pop(name, None)
    IMMEDIATE.discard(name)


def _settings(obj):
    return getattr(obj, "compify_blockout", None)


# --------------------------------------------------------------- messages
# Panel rows show "重建失败：<hint>", so the hint must stay short enough for
# the ~280px sidebar; the full sentence goes to the status bar only.
_HINTS = (
    ("structrna", "请再试一次", "这次重建没成功，请再试一次"),
    ("has been removed", "请再试一次", "这次重建没成功，请再试一次"),
    ("来源图平面已被删除", "请检查来源图平面",
     "来源图平面已删除，请重新指定图平面"),
    ("找不到投射摄像机", "请先选摄像机",
     "找不到投射摄像机，请先在 ① 里选一台"),
    ("没有投射材质", "请先生成投射",
     "这个物体还没有投射材质，请先在 ① 生成"),
    ("不是模型", "请重新生成模型", "这个物体不是生成模型，请重新生成"),
    ("不在摄像机画面内", "物体不在画面内",
     "物体不在摄像机画面内，请调整构图"),
    ("深度结果不可用", "请再试一次", "这次重建没成功，请再试一次"),
)
_HINT_GENERIC = ("请再试一次", "这次重建没成功，请再试一次")


def _plain_chinese(text):
    return not any("a" <= ch.lower() <= "z" for ch in text)


def _pick_text(error):
    text = str(error or "").strip()
    low = text.lower()
    for key, short, long in _HINTS:
        if key.lower() in low:
            return short, long
    if text and _plain_chinese(text) and len(text) <= 10:
        return text, text
    return _HINT_GENERIC


def human_hint(error):
    """Short panel hint (<= 10 chars): what to do next."""
    return _pick_text(error)[0]


def human_message(error):
    """Full sentence for the status bar."""
    return _pick_text(error)[1]


def _fail(settings, reason, ms):
    """Record a short hint on the object, return the full sentence."""
    short, long = _pick_text(reason)
    settings.last_error = short
    print("[Compify|Blockout] 重建失败：%s" % (reason,))
    return False, long, ms


# --------------------------------------------------------------- cache refs
def _pointer(obj):
    try:
        return int(obj.as_pointer()) if obj is not None else 0
    except (ReferenceError, RuntimeError):
        return 0


def _same_object(ref, current):
    """True when ``ref`` still is the very datablock ``current`` names."""
    if ref is None or current is None:
        return False
    try:
        return (_pointer(ref) != 0
                and _pointer(ref) == _pointer(current)
                and ref.name == current.name)
    except ReferenceError:
        return False


def _cache_usable(cached, signature, source, camera, dirty):
    """A cached prep job is only reusable for the very same objects."""
    if cached is None or dirty:
        return False
    sig, job = cached
    if sig != signature:
        return False
    try:
        if getattr(job, "error", None):
            return False
        return (_same_object(job.plate, source)
                and _same_object(job.camera, camera))
    except ReferenceError:
        return False


def _run_job(context, source, camera, params, reuse_job=None,
             border_cells=None, mesh_origin=None):
    if reuse_job is not None:
        job = reuse_job
        job.params = dict(params)
        job.mesh_origin = mesh_origin
    else:
        job = blockout.BlockoutJob(context, source, camera, dict(params),
                                   mesh_origin=mesh_origin)
    # Cells of this build's own grid (preview halves it); never written to
    # PROP_PARAMS, which keeps the user's final-grid width.
    job.border_cells = border_cells
    state = job.wait()
    if state != "done":
        raise RuntimeError(job.error or "深度结果不可用")
    return job, job.finish()


def _origin_of(obj):
    """Read a stored generation origin; legacy meshes use world origin."""
    raw = obj.get(blockout.PROP_ORIGIN)
    if raw is None:
        return (0.0, 0.0, 0.0)
    try:
        origin = tuple(float(value) for value in raw)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError("生成原点记录无效") from error
    if len(origin) != 3 or not all(math.isfinite(value) for value in origin):
        raise ValueError("生成原点记录无效")
    return origin


def _on_change(self, context):
    try:
        schedule_rebuild(self.id_data)
    except Exception as error:  # noqa: BLE001
        print("[Compify|Blockout] 排程失败:", error)


# ------------------------------------------------------------ parameter caps
# The slider shows the SOFT range, the number box accepts up to the HARD one
# (measured in 5.3).  So: hard max = safety limit × 100 (so an over-limit
# typing is still visible and can be caught), soft max = this model's cap.
# Typing past the cap raises that model's cap; typing past the safety limit is
# clamped with a human sentence.  Caps live on the object, so they save with
# the file and stay per model.
DEFAULT_CAPS = {"threshold": 0.95, "outward": 64.0, "density": 256,
                "strength": 2.0, "smooth": 3}
# Measured 2026-11-20 (blender 5.3, RTX 5090): generation at these limits
# finished (density 1024 -> 481,465 verts / 959,808 tris in 0.53 s).
ABS_LIMITS = {"threshold": 1.0, "outward": 500.0, "density": 1024,
              "strength": 50.0, "smooth": 20}
PARAM_MIN = {"threshold": 0.0, "outward": 0.0, "density": 16,
             "strength": 0.0, "smooth": 0}

_ACTIVE_CAPS = dict(DEFAULT_CAPS)
_REDECLARE_PENDING = False
_REDECLARE_FAILED = None
_CLAMPING = False


def _limit_text(field, value):
    if field in ("density", "smooth"):
        return "%d" % int(value)
    return ("%.2f" % value).rstrip("0").rstrip(".")


def _on_param_change(self, context):
    """Raise this model's cap on a bigger typed value; clamp at the safety end."""
    if _CLAMPING:
        return
    raised = False
    note = ""
    for field, hard in ABS_LIMITS.items():
        value = getattr(self, field)
        cap = getattr(self, field + "_cap", DEFAULT_CAPS[field])
        if value > hard:
            _write_cap(self, field, hard)
            note = "最多到 %s，已按 %s 处理" % (_limit_text(field, hard),
                                              _limit_text(field, hard))
            raised = True
        elif value > cap:
            _write_cap(self, field, value)
            raised = True
    try:
        self.cap_note = note
    except AttributeError:
        pass
    if raised:
        request_redeclare()
    _on_change(self, context)


def _write_cap(settings, field, cap):
    """Store the cap (and clamp the value) without re-entering the update."""
    global _CLAMPING
    _CLAMPING = True
    try:
        hard = ABS_LIMITS[field]
        setattr(settings, field + "_cap", min(max(cap, PARAM_MIN[field]), hard))
        if getattr(settings, field) > hard:
            setattr(settings, field, hard)
    except (AttributeError, TypeError, ValueError):
        pass
    finally:
        _CLAMPING = False


def make_settings_class(caps):
    """Build BlockoutSettings with this model's caps baked into the ranges."""
    soft = {field: min(max(float(caps.get(field, DEFAULT_CAPS[field])),
                           float(PARAM_MIN[field])), ABS_LIMITS[field])
            for field in ABS_LIMITS}
    hard = {field: ABS_LIMITS[field] * 100.0 for field in ABS_LIMITS}

    class BlockoutSettings(bpy.types.PropertyGroup):
        """Per-object parameters; ranges follow this model's caps."""

        threshold_cap: bpy.props.FloatProperty(
            name="裁形阈值上限", default=DEFAULT_CAPS["threshold"], min=0.0,
            max=ABS_LIMITS["threshold"], precision=2, subtype="FACTOR")
        outward_cap: bpy.props.FloatProperty(
            name="外扩像素上限", default=DEFAULT_CAPS["outward"], min=0.0,
            max=ABS_LIMITS["outward"], precision=1, subtype="PIXEL")
        density_cap: bpy.props.IntProperty(
            name="网格密度上限", default=DEFAULT_CAPS["density"],
            min=PARAM_MIN["density"], max=ABS_LIMITS["density"])
        strength_cap: bpy.props.FloatProperty(
            name="突出强度上限", default=DEFAULT_CAPS["strength"], min=0.0,
            max=ABS_LIMITS["strength"], subtype="FACTOR")
        smooth_cap: bpy.props.IntProperty(
            name="表面平滑上限", default=DEFAULT_CAPS["smooth"], min=0,
            max=ABS_LIMITS["smooth"])

        threshold: bpy.props.FloatProperty(
            name="裁形阈值", default=0.0, min=0.0, max=hard["threshold"],
            soft_max=soft["threshold"], precision=2, subtype="FACTOR",
            update=_on_param_change)
        outward: bpy.props.FloatProperty(
            name="外扩像素", default=2.0, min=0.0, max=hard["outward"],
            soft_max=soft["outward"], precision=1, subtype="PIXEL",
            update=_on_param_change)
        density: bpy.props.IntProperty(
            name="网格密度", default=128, min=PARAM_MIN["density"],
            max=int(hard["density"]), soft_max=int(soft["density"]),
            update=_on_param_change)
        strength: bpy.props.FloatProperty(
            name="突出强度", default=1.0, min=0.0, max=hard["strength"],
            soft_max=soft["strength"], subtype="FACTOR",
            update=_on_param_change)
        smooth: bpy.props.IntProperty(
            name="表面平滑", default=1, min=0, max=int(hard["smooth"]),
            soft_max=int(soft["smooth"]), update=_on_param_change)
        trim: bpy.props.BoolProperty(
            name="裁形（按透明度）", default=False, update=_on_change)
        border_grow: bpy.props.BoolProperty(
            name="边缘补边", default=False, update=_on_param_change)
        border_width: bpy.props.IntProperty(
            name="补边宽度", default=2, min=1,
            max=int(blockout.BORDER_MAX), subtype="PIXEL",
            update=_on_param_change)


        cap_note: bpy.props.StringProperty(default="")
        last_ms: bpy.props.FloatProperty(default=0.0)
        last_preview_ms: bpy.props.FloatProperty(default=0.0)
        preview: bpy.props.BoolProperty(default=False)
        last_error: bpy.props.StringProperty(default="")
        built: bpy.props.BoolProperty(default=False)

    return BlockoutSettings


BlockoutSettings = make_settings_class(DEFAULT_CAPS)


def _expanded_settings():
    """Settings of the parameter block currently open in the panel, if any."""
    scene = getattr(bpy.context, "scene", None)
    if scene is None:
        return None
    try:
        states = json.loads(getattr(scene, "compify_uv_group_fold_states", "{}"))
    except (TypeError, ValueError):
        return None
    if not isinstance(states, dict):
        return None
    # Old files may carry several open blocks: sorted keeps the pick stable.
    names = sorted(key.split(":", 1)[1] for key, value in states.items()
                   if key.startswith("params:") and value)
    for name in names:
        obj = bpy.data.objects.get(name)
        settings = _settings(obj) if obj is not None else None
        if settings is not None:
            return settings
    return None


def current_caps():
    """Caps that should apply right now (expanded model, else the defaults)."""
    settings = _expanded_settings()
    caps = dict(DEFAULT_CAPS)
    if settings is None:
        return caps
    for field in ABS_LIMITS:
        cap = getattr(settings, field + "_cap", DEFAULT_CAPS[field])
        caps[field] = min(max(float(cap), float(PARAM_MIN[field])),
                          ABS_LIMITS[field])
    return caps


def _tag_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def request_redeclare():
    """Ask for one deferred re-declaration; never run inside a draw callback."""
    global _REDECLARE_PENDING
    if _REDECLARE_PENDING:
        return
    _REDECLARE_PENDING = True
    try:
        bpy.app.timers.register(_redeclare_timer, first_interval=0.0)
    except Exception as error:  # noqa: BLE001
        _REDECLARE_PENDING = False
        print("[Compify|Blockout] 排不上参数上限更新：", error)


def request_redeclare_if_needed():
    """Called from draw: only schedules work, never touches RNA itself."""
    if _REDECLARE_PENDING:
        return
    caps = current_caps()
    if caps == _ACTIVE_CAPS or caps == _REDECLARE_FAILED:
        return
    request_redeclare()


def _redeclare_timer():
    global _REDECLARE_PENDING, _ACTIVE_CAPS, _REDECLARE_FAILED
    global BlockoutSettings
    _REDECLARE_PENDING = False
    caps = current_caps()
    if caps == _ACTIVE_CAPS:
        return None
    try:
        # The Object pointer must go before the class: re-registering a class
        # that a live PointerProperty still references crashes Blender 5.3 on
        # the next access (measured).  Values live on the objects, so they
        # survive; the pointer is rebuilt right after.
        if hasattr(bpy.types.Object, "compify_blockout"):
            del bpy.types.Object.compify_blockout
        bpy.utils.unregister_class(BlockoutSettings)
        BlockoutSettings = make_settings_class(caps)
        bpy.utils.register_class(BlockoutSettings)
        bpy.types.Object.compify_blockout = bpy.props.PointerProperty(
            type=BlockoutSettings)
        _ACTIVE_CAPS = dict(caps)
        _REDECLARE_FAILED = None
        _tag_redraw()
    except Exception as error:  # noqa: BLE001
        # One failure stops the retry loop until the wanted caps change.
        _REDECLARE_FAILED = caps
        print("[Compify|Blockout] 参数上限更新失败：", error)
    return None


def settings_of(obj):
    return _settings(obj)


def _stored_tier(obj):
    """Tier this model was generated with, or "" when unknown.

    Kept on the object so switching 生成精度 never rebuilds an older model
    with a different tier.  Missing or malformed data falls back quietly.
    """
    raw = obj.get(blockout.PROP_PARAMS)
    if not raw:
        return ""
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return ""
    tier = data.get("tier") if isinstance(data, dict) else None
    return str(tier) if tier else ""


def _params(obj):
    s = _settings(obj)
    params = {
        "grid": int(s.density),
        "strength": float(s.strength),
        "smooth": int(s.smooth),
        "trim": bool(s.trim),
        "threshold": float(s.threshold),
        "outward": float(s.outward),
        "border_grow": bool(s.border_grow),
        "border_width": int(s.border_width),
        "tier": _stored_tier(obj) or blockout.active_tier(),
    }
    return params


def _camera_object(scene, obj):
    data_name = str(obj.get(blockout.PROP_CAMERA) or "")
    for camera in scene.objects:
        if camera.type == "CAMERA" and camera.data.name == data_name:
            return camera
    return scene.camera


def rebuild(obj, preview=False, exact_after=True):
    """Rebuild the object's mesh in place.

    Returns ``(ok, status_message, ms)``.  ``status_message`` is the full
    sentence for the status bar; ``last_error`` keeps a short hint for the
    panel row.
    """
    s = _settings(obj)
    if s is None or obj.type != "MESH":
        return False, human_message("不是模型"), 0.0
    source = bpy.data.objects.get(str(obj.get(blockout.PROP_SOURCE) or ""))
    if source is None:
        return _fail(s, "来源图平面已被删除", 0.0)
    context = bpy.context
    camera = _camera_object(context.scene, obj)
    if camera is None:
        return _fail(s, "找不到投射摄像机", 0.0)

    params = _params(obj)
    try:
        # Validate persisted frame metadata before a job can create a temp
        # object.  Missing metadata is the legacy world-origin frame.
        target_origin = _origin_of(obj)
    except Exception as error:  # noqa: BLE001
        return _fail(s, error, 0.0)
    border_cells = float(params["border_width"])
    if preview:
        final_grid = max(1, int(params["grid"]))
        params["grid"] = max(16, int(params["grid"]) // PREVIEW_DIVISOR)
        params["preview"] = True
        # Keep the same world width: the preview grid is coarser, so it needs
        # fewer cells (fractional on purpose: no 2x quantization at width 1).
        border_cells = params["border_width"] * params["grid"] / final_grid

    started = time.perf_counter()
    before_objects = len(context.scene.objects)
    # prep_signature / find_image walk the plate and its material: after an
    # undo they can hit a removed datablock, so they live inside a guarded
    # block that fails in plain language instead of leaking the exception.
    try:
        signature = blockout.prep_signature(context, source, camera, params)
        image = blockout.find_image(source)
    except Exception as error:  # noqa: BLE001
        _PREP.pop(obj.name, None)
        return _fail(s, error, (time.perf_counter() - started) * 1000.0)

    cached = _PREP.get(obj.name)
    dirty = bool(image.is_dirty) if image is not None else False
    reuse = _cache_usable(cached, signature, source, camera, dirty)
    try:
        job, temp = _run_job(context, source, camera, params,
                             cached[1] if reuse else None, border_cells,
                             mesh_origin=target_origin)
    except Exception as error:  # noqa: BLE001
        if not reuse:
            return _fail(s, error, (time.perf_counter() - started) * 1000.0)
        # The cached job pointed at objects that an undo/reload replaced.
        # Drop it and try once from scratch before giving up.
        _PREP.pop(obj.name, None)
        try:
            job, temp = _run_job(context, source, camera, params,
                                 border_cells=border_cells,
                                 mesh_origin=target_origin)
        except Exception as retry_error:  # noqa: BLE001
            return _fail(s, retry_error,
                         (time.perf_counter() - started) * 1000.0)
    if not dirty:
        _PREP[obj.name] = (signature, job)

    elapsed = (time.perf_counter() - started) * 1000.0
    temp = locals().get("temp")
    try:
        # build_mesh wrote directly in the target's fixed frame using float64
        # coordinates; no current object transform is inverted or changed.
        old_mesh = obj.data
        # Alt+D siblings share this data block; never delete theirs.
        drop_old = old_mesh.users <= 1
        obj.data = temp.data
        obj.data.name = "%s_mesh" % obj.name
        if drop_old:
            bpy.data.meshes.remove(old_mesh)
        if temp.name in bpy.data.objects:
            bpy.data.objects.remove(temp, do_unlink=True)
        obj.data.update()
    except Exception as error:  # noqa: BLE001
        if temp is not None and temp.name in bpy.data.objects:
            bpy.data.objects.remove(temp, do_unlink=True)
        return _fail(s, error, elapsed)
    if len(context.scene.objects) != before_objects:
        s.last_error = "请先撤销"
        print("[Compify|Blockout] 对象数变化 %d → %d"
              % (before_objects, len(context.scene.objects)))
        return False, "重建时场景对象数变了，请先撤销再试", elapsed

    s.last_error = ""
    if os.environ.get("COMPIFY_BLOCKOUT_LOG"):
        stages = blockout.STAGE_TIMES
        print("[Compify|Blockout] %s preview=%d total=%.1fms Z=%.1f A=%.1f "
              "B=%.1f C=%.1f obj=%.1f" % (
                  obj.name, int(preview), elapsed, stages.get("Z", 0.0),
                  stages.get("A", 0.0), stages.get("B", 0.0),
                  stages.get("C", 0.0), stages.get("obj", 0.0)))
    if preview:
        s.last_preview_ms = elapsed
        s.preview = True
    else:
        s.last_ms = elapsed
        s.preview = False
        s.built = True
    return True, "", elapsed


def schedule_rebuild(obj, interactive=True):
    if obj is None:
        return
    name = obj.name
    PENDING.add(name)
    if interactive:
        LAST_TOUCH[name] = time.monotonic()
        IMMEDIATE.discard(name)
    else:
        IMMEDIATE.add(name)
        LAST_TOUCH.pop(name, None)
    if not bpy.app.timers.is_registered(_flush):
        bpy.app.timers.register(
            _flush, first_interval=0.0 if IMMEDIATE else PREVIEW_INTERVAL)


def _flush():
    """One object per tick keeps batch generation from stalling the UI."""
    names = list(PENDING)
    PENDING.clear()
    if not names:
        return None
    now = time.monotonic()
    name = names[0]
    for extra in names[1:]:
        PENDING.add(extra)
    obj = bpy.data.objects.get(name)
    if obj is None:
        LAST_TOUCH.pop(name, None)
        IMMEDIATE.discard(name)
        return PREVIEW_INTERVAL if PENDING else None
    idle = now - LAST_TOUCH.get(name, 0.0)
    exact = name in IMMEDIATE or idle >= PREVIEW_IDLE
    started = time.perf_counter()
    try:
        rebuild(obj, preview=not exact)
    except Exception as error:  # noqa: BLE001
        s = _settings(obj)
        if s is not None:
            s.last_error = human_hint(error)
        print("[Compify|Blockout] 预览重建失败：%s" % (error,))
    cost = time.perf_counter() - started
    if exact:
        LAST_TOUCH.pop(name, None)
        IMMEDIATE.discard(name)
    else:
        PENDING.add(name)
    if not PENDING:
        return None
    return min(0.30, max(PREVIEW_INTERVAL, cost * 1.15))


def flush_now():
    """Run the queue synchronously (tests / headless)."""
    while PENDING:
        names = list(PENDING)
        PENDING.clear()
        obj = bpy.data.objects.get(names[0])
        if obj is not None:
            rebuild(obj, preview=False)
        for extra in names[1:]:
            other = bpy.data.objects.get(extra)
            if other is not None:
                rebuild(other, preview=False)


# ------------------------------------------------------------------ migration

def _socket_value(modifier, name):
    group = modifier.node_group
    if group is None:
        return None
    for item in group.interface.items_tree:
        if (getattr(item, "item_type", "") == "SOCKET"
                and getattr(item, "in_out", "") == "INPUT"
                and item.name == name):
            try:
                return modifier.properties.inputs[item.identifier]["value"]
            except (KeyError, TypeError):
                return None
    return None


def migrate_legacy(obj):
    """Convert a blockout that still carries the old GN modifier."""
    if obj is None or obj.type != "MESH":
        return False
    s = _settings(obj)
    if s is None:
        return False
    converted = False
    for modifier in list(obj.modifiers):
        if modifier.type != "NODES" or modifier.node_group is None:
            continue
        if not modifier.node_group.name.startswith(blockout.GROUP_PREFIX):
            continue
        for socket, attribute in (("Threshold", "threshold"),
                                  ("Outward", "outward"),
                                  ("Strength", "strength"),
                                  ("Smooth", "smooth")):
            value = _socket_value(modifier, socket)
            if value is not None:
                setattr(s, attribute, value)
        trim_value = _socket_value(modifier, "裁形")
        if trim_value is None:
            trim_value = _socket_value(modifier, "Trim")
        if trim_value is not None:
            s.trim = bool(trim_value)
        obj.modifiers.remove(modifier)
        converted = True
    if converted:
        s.built = True
    return converted
