# Vendored from image_cutter v0.4.0 (..\image_cutter\ic_core\outline.py)
# Kept unchanged apart from this provenance note. Original header follows.
"""把二值掩膜追成一圈圈闭合轮廓。

做法：不沿着**像素中心**走（Moore 邻域 / 朴素 marching squares），
而是沿着「实心 ↔ 空」之间的**像素边**走。

好处（这是它相对朴素做法的唯一但关键的优点）：
两个形状**只在一个角上碰着**时，会被自动拆成两圈，不会黏成一坨。

实现：Marching Squares 变体。
  · 每个 2×2 像素单元算一个 4 位 code
  · 查表得到该单元的「有向边」段，方向统一为「实心在右手边」
  · 方向统一了，段与段自然首尾相接；外环逆时针、内环顺时针（天然反向）

坐标：像素中心系。像素 (x, y) 的中心是 (x+0.5, y+0.5)。
输出坐标是 0.5 的整数倍，左上原点（y 向下）。
"""

import numpy as np

from numpy.lib.stride_tricks import as_strided

# code = tl*8 | tr*4 | br*2 | bl*1（1 = 实心）
# 值 = 该 code 下的边连接对，边编号 0=上 1=右 2=下 3=左
# 方向统一为「实心在右手边」——这一条是整个算法能串成环的关键
# ⚠️ 这张表极易填错，且**错了不报错**（返回 0 个环、页面干净得像什么都没发生）。
#    自检办法：互补 case 必须反向 —— case N 与 case (15-N) 是同一条边界、方向相反。
#    另外所有段方向必须统一，否则串不成环。
_SQ = (
    (),            # 0  全空
    (3, 2),        # 1  bl
    (2, 1),        # 2  br
    (3, 1),        # 3  bl+br
    (1, 0),        # 4  tr
    (3, 2, 1, 0),  # 5  tr+bl  鞍点
    (2, 0),        # 6  tr+br
    (3, 0),        # 7  tr+br+bl
    (0, 3),        # 8  tl
    (0, 2),        # 9  tl+bl
    (0, 3, 2, 1),  # 10 tl+br  鞍点
    (0, 1),        # 11 tl+br+bl
    (1, 3),        # 12 tl+tr
    (1, 2),        # 13 tl+tr+bl
    (2, 3),        # 14 tl+tr+br
    (),            # 15 全实心
)


def _edge_pt(j, i, e):
    """单元 (j, i) 的第 e 条边的中点，返回 ×2 的整数坐标（避免浮点做字典键）。"""
    if e == 0:
        return (2 * j, 2 * i - 1)      # 上
    if e == 1:
        return (2 * j + 1, 2 * i)      # 右
    if e == 2:
        return (2 * j, 2 * i + 1)      # 下
    return (2 * j - 1, 2 * i)          # 左


_BLOCK = 64


def _boundary_cells(p, block=_BLOCK):
    """返回所有「非全空、非全实心」单元的行主序 (ys, xs, codes)。

    直接对全图算 4 位 code 再 `nonzero`，4096 图要 80ms 上下；而真正的
    边界单元只有轮廓量级，绝大多数像素块里根本没有任何边。所以先按
    block×block 的像素块做 min/max 粗筛，只对候选块算 code。

    ⚠️ 粗筛窗口必须取 block+1（相邻块重叠一格）：轮廓正好压在块边界时，
    两边各自的 block×block 区域都可能是纯色，只有跨块的那一格才有边。
    """
    ph, pw = p.shape
    block = max(1, min(int(block), max(ph, pw)))
    bh = (ph + block - 1) // block
    bw = (pw + block - 1) // block
    eh = bh * block + 1
    ew = bw * block + 1
    if eh > ph or ew > pw:
        pp = np.zeros((max(ph, eh), max(pw, ew)), np.uint8)
        pp[:ph, :pw] = p
    else:
        pp = p
    windows = as_strided(
        pp,
        shape=(bh, bw, block + 1, block + 1),
        strides=(pp.strides[0] * block, pp.strides[1] * block,
                 pp.strides[0], pp.strides[1]),
        writeable=False,
    )
    cand = np.nonzero(windows.max(axis=(2, 3)) > windows.min(axis=(2, 3)))
    if cand[0].size == 0:
        return (np.empty(0, np.int64), np.empty(0, np.int64),
                np.empty(0, np.uint8))

    sub = windows[cand[0], cand[1]]
    code = ((sub[:, :-1, :-1] << 3) | (sub[:, :-1, 1:] << 2)
            | (sub[:, 1:, 1:] << 1) | sub[:, 1:, :-1])
    nz = np.nonzero((code != 0) & (code != 15))
    if nz[0].size == 0:
        return (np.empty(0, np.int64), np.empty(0, np.int64),
                np.empty(0, np.uint8))

    ys = cand[0][nz[0]] * block + nz[1]
    xs = cand[1][nz[0]] * block + nz[2]
    # 候选块是按块行列顺序拼的，这里恢复成和整幅 nonzero 一致的
    # 行主序 —— 环的起点/顺序跟原来完全一样，调用方无感。
    order = np.argsort(ys * np.int64(pp.shape[1] + 1) + xs, kind="stable")
    return ys[order], xs[order], code[nz][order]


def trace_rings(mask, min_points=4):
    """掩膜 → 闭合环列表。

    每个环是 [(x, y), ...]，像素中心系，左上原点。
    min_points: 点数少于此的环当噪声丢掉。

    注意：掩膜全实心时没有任何边，返回空列表（调用方应据此提示"这张图没有透明区"）。
    """
    m = np.asarray(mask, dtype=bool)
    if m.ndim != 2:
        raise ValueError("掩膜必须是二维数组")
    h, w = m.shape
    if h == 0 or w == 0:
        return []

    # 外扩一圈空白，好让贴着图像边缘的形状也能围出完整轮廓。
    # 同时把分配尺寸凑到 block 的整数倍，省掉 _boundary_cells 里再复制一次。
    ph, pw = h + 2, w + 2
    block = max(1, min(_BLOCK, max(ph, pw)))
    bh = (ph + block - 1) // block
    bw = (pw + block - 1) // block
    p = np.zeros((bh * block + 1, bw * block + 1), dtype=np.uint8)
    p[1:h + 1, 1:w + 1] = m

    # 只有「非全空、非全实心」的单元才产生边段；大图上这类单元只占轮廓量级
    ys, xs, codes_arr = _boundary_cells(p, block)
    if ys.size == 0:
        return []
    ncell = ys.size

    # ---- 边段生成：向量化 ----
    # 早先是「逐单元查 _SQ 表、逐段 append」，4096 图上 1.5 万个单元要 85ms，
    # 是 A 阶段最大的单项开销。这里改成：按 16 种 code 各取一次掩膜，
    # 用 numpy 一次算出该 code 下所有单元的两条边端点。
    #
    # 坐标用 ×2 整数（避免浮点做字典键）。单元 (j, i) 的四条边中点：
    #   0=上 (2j, 2i-1) / 1=右 (2j+1, 2i) / 2=下 (2j, 2i+1) / 3=左 (2j-1, 2i)
    jj = xs.astype(np.int64)
    ii = ys.astype(np.int64)
    epx = (
        np.stack([2 * jj, 2 * jj + 1, 2 * jj, 2 * jj - 1], axis=1),      # 各边的 x
    )
    epy = (
        np.stack([2 * ii - 1, 2 * ii, 2 * ii + 1, 2 * ii], axis=1),      # 各边的 y
    )
    EX = epx[0]
    EY = epy[0]

    codes = codes_arr.astype(np.int64)
    src_list = []
    dst_list = []
    for c in range(16):
        table = _SQ[c]
        if not table:
            continue
        sel = codes == c
        if not sel.any():
            continue
        sub_x = EX[sel]
        sub_y = EY[sel]
        for k in range(0, len(table), 2):
            e0 = table[k]
            e1 = table[k + 1]
            # 起点/终点各取对应边的中点。用「一维键」代替元组，
            # 后续串联时查表快得多（Python 里 int 比 tuple 哈希便宜）。
            src_list.append(sub_x[:, e0] * 65536 + sub_y[:, e0])
            dst_list.append(sub_x[:, e1] * 65536 + sub_y[:, e1])

    if not src_list:
        return []

    src = np.concatenate(src_list)
    dst = np.concatenate(dst_list)
    if src.size == 0:
        return []

    # ---- 环串联 ----
    # 段天然构成「每个起点 → 一个或两个终点」的有向图（鞍点才有两个）。
    # 直接按起点建 succ 表、走一条边就 pop 一条，比原来「起点排序 + 二分
    # 查找 + used 数组」少一半 Python 层的下标运算；4096 图 18k 段从
    # 13ms 降到 6~7ms，环的顺序和点序不变。
    succ = {}
    for s, d in zip(src.tolist(), dst.tolist()):
        bucket = succ.get(s)
        if bucket is None:
            succ[s] = [d]
        else:
            bucket.append(d)

    rings = []
    limit = len(src) + 8
    for seed in list(succ):
        # 鞍点的起点会连出两段：第一条环回到起点后还剩一条，要再起一圈。
        while succ.get(seed):
            ring = []
            cur = seed
            guard = 0
            while guard < limit:
                guard += 1
                ring.append((float(cur // 65536) * 0.5,
                             float(cur % 65536) * 0.5))
                bucket = succ.get(cur)
                if not bucket:
                    break
                nxt = bucket.pop(0)
                if nxt == seed:
                    break
                cur = nxt
            if len(ring) >= min_points:
                rings.append(ring)

    return rings


def ring_area(ring):
    """带符号面积。正 = 逆时针（在 y 向下的图像坐标里，视觉上是顺时针）。

    只用来比较大小 / 判断方向，符号含义随坐标系，别跨坐标系硬解释。
    """
    n = len(ring)
    if n < 3:
        return 0.0
    s = 0.0
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        s += x0 * y1 - x1 * y0
    return s * 0.5


def point_in_ring(pt, ring):
    """射线法：点是否在环内。用于判洞、判三角形重心。"""
    x, y = pt
    inside = False
    n = len(ring)
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        if (y0 > y) != (y1 > y):
            xc = (x1 - x0) * (y - y0) / (y1 - y0) + x0
            if x < xc:
                inside = not inside
    return inside


def ring_centroid(ring):
    """环的**面积质心**（不是顶点平均）。

    【为什么不能用顶点平均 —— 实测过的坑】

    split_outer 靠「这个环的质心落在几个更大的环里」判断嵌套层级。
    早先用的是顶点坐标的平均值，它对**凹形环不成立**：
    顶点平均会被顶点密集的那一侧拽过去，可能落到环外。

    一个真实例子（trace_rings 产出的 U 形环，500² 图上的隔离岛）：
        U 形环 1400 个点，顶点平均质心 (250, 257.7)
        —— 落在自己的凹口里，也就是**环外**
    一旦它被误判成「在别的环内」，split_outer 就会把它当洞丢掉，
    整个形状从结果里消失，而且用户完全看不出原因（面数变少而已）。

    面积质心（用带符号面积加权的多边形质心公式）对凸形凹形都保证在环内
    （只在极度扭曲的自交环上才可能出界，而 trace_rings 产出的环不自交）。

    退化情况：面积为 0（共线/少于 3 点）时退回顶点平均。
    """
    n = len(ring)
    if n == 0:
        return (0.0, 0.0)
    if n < 3:
        return (sum(p[0] for p in ring) / n, sum(p[1] for p in ring) / n)

    # 带符号面积 + 加权质心
    a2 = 0.0
    cx = 0.0
    cy = 0.0
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        cross = x0 * y1 - x1 * y0
        a2 += cross
        cx += (x0 + x1) * cross
        cy += (y0 + y1) * cross

    if abs(a2) < 1e-12:
        # 面积为 0：环退化成一条线，顶点平均已经是最合理的答案
        return (sum(p[0] for p in ring) / n, sum(p[1] for p in ring) / n)

    return (cx / (3.0 * a2), cy / (3.0 * a2))


def _representative_points(ring, max_samples=17):
    """挑几个「肯定在环内部」的点，用来判断这个环被谁包着。

    【为什么不能只用一个质心】

    面积质心一般够用，但**凹形 + 顶点擦边**时可能落在环外：
    实测一个 L 形环的质心 (124.39, 175.61) 刚好压在竖条右边界附近，
    point_in_ring 判成 False。那个点确实擦边，本身不算错，
    但拿它去判断嵌套就会得出「这个环不在自己里面」这种荒谬结论。

    所以额外补上「环上的点沿内法线往里缩一点」—— 这些点必然在环内。

    ⚠️ 内法线方向：trace_rings 产出的外环是**逆时针**（带符号面积为正，
       实测一个 100×100 方形环为 +19999），实心在前进方向的**左侧**。
       所以内法线 = 左手法线 = (-ty, tx)。
       写成右手侧 (ty, -tx) 会朝外推 —— 实测那样 19 个代表点只有 1 个在环内，
       等于整套投票全废（好在测试抓到了）。

    返回：质心（若在环内）+ 若干个内缩采样点。
    """
    n = len(ring)
    if n < 3:
        return list(ring)

    # 这一段每次重建都要跑：4K 图上有 1.3 万点的大环，早先逐点调
    # point_in_ring（纯 Python 遍历整环）做「内缩点是否在环内」的校验，
    # 光这一步就占 split_outer 的 70%（实测 26ms）。改成整环转一次
    # numpy、每档内缩批量判定后降到 3~5ms；挑点的顺序和结果不变。
    arr = np.asarray(ring, dtype=np.float64)
    xs = arr[:, 0]
    ys = arr[:, 1]
    xs1 = np.roll(xs, -1)
    ys1 = np.roll(ys, -1)
    cross = xs * ys1 - xs1 * ys
    a2 = float(cross.sum())

    if abs(a2) < 1e-12:
        c = (float(xs.mean()), float(ys.mean()))
    else:
        cx = float(((xs + xs1) * cross).sum())
        cy = float(((ys + ys1) * cross).sum())
        c = (cx / (3.0 * a2), cy / (3.0 * a2))

    pts = []
    if _points_in_ring_arr(np.asarray([c], dtype=np.float64), arr)[0]:
        pts.append(c)

    step = max(1, n // max_samples)

    # 【内缩距离：不能用「跨度」，也不能只用「短边」，必须逐点自适应】
    #
    # 历史教训（两次都踩了）：
    #   ① 用 span*0.02（span = max(宽,高)）
    #      1000×10 的长条 → inset 20px > 环厚 10px，代表点全被推到环外。
    #      实测 h=10/6/4 时只有 1/5 个点在环内。
    #   ② 改用 min(宽,高)*0.25
    #      长条问题好了（h=2 也 5/5），但**凹形反而崩了**：
    #      C 形环的"短边"是开口那一侧，照样把它推进凹口 —— 实测 2/8。
    #
    # 所以不能用一个全局尺度。正确做法是**逐点算「到最近边的距离」**：
    #   从顶点沿内法线走，能走多远才碰到别的边？
    #   走一半就是安全的落脚点。这就是「内缩半径」的几何定义。
    #
    # 为了不引入 O(n²)，用采样点 + 暴力最近边：
    # 采样数 ≤ 19，环点数通常几百到几千，19×n 完全可接受。
    # 而且只在「质心不可信」时才需要这些点，属于慢路径。

    w_span = float(xs.max() - xs.min())
    h_span = float(ys.max() - ys.min())
    short_side = min(w_span, h_span)
    if short_side <= 1e-9:
        short_side = max(w_span, h_span)
    foot = max(short_side * 0.25, 0.5)

    # 【内法线方向必须按环的实际走向决定，不能写死】
    #
    # 早先写死「内法线 = 左手法线 (-ty, tx)」，前提是「环是逆时针、实心在左侧」。
    # trace_rings 产出的外环确实是逆时针（带符号面积 > 0），所以真机上没暴露。
    # 但**只要传进来一个顺时针环，所有代表点就会被推到环外** ——
    # 实测一个 8 点的 C 形顺时针环：8 个代表点全在环外（0/8），
    # 整套多点投票直接失效，split_outer 会把这个环的嵌套深度算成 0。
    #
    # 所以先算带符号面积定方向：逆时针取左手侧，顺时针取右手侧。
    ccw = a2 > 0.0          # 逆时针 = 实心在前进方向左侧

    idx = np.arange(0, n, step, dtype=np.int64)
    prev = np.roll(arr, 1, axis=0)
    nxt = np.roll(arr, -1, axis=0)
    tx = nxt[:, 0] - prev[:, 0]
    ty = nxt[:, 1] - prev[:, 1]
    tl = np.hypot(tx, ty)
    usable = tl >= 1e-9
    tl_safe = np.where(usable, tl, 1.0)
    if ccw:
        nx = -ty / tl_safe       # 左手侧 = 朝内
        ny = tx / tl_safe
    else:
        nx = ty / tl_safe        # 右手侧 = 朝内
        ny = -tx / tl_safe

    # 采样点的内缩候选按「档位」批量判定：第 1 档就能收下绝大多数点，
    # 只有细刺/窄缝里的少数点需要继续往小档走。
    chosen = [None] * int(idx.size)
    active = np.nonzero(usable[idx])[0]
    shrink_steps = (1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125, 0.0156, 0.0078)
    for shrink in shrink_steps:
        if active.size == 0:
            break
        sel = idx[active]
        d = foot * shrink
        cand = np.empty((active.size, 2), dtype=np.float64)
        cand[:, 0] = arr[sel, 0] + nx[sel] * d
        cand[:, 1] = arr[sel, 1] + ny[sel] * d
        inside = _points_in_ring_arr(cand, arr)
        remain = []
        for j, (pos, ok) in enumerate(zip(active.tolist(), inside)):
            if ok:
                chosen[pos] = (float(cand[j, 0]), float(cand[j, 1]))
            else:
                remain.append(pos)
        active = np.asarray(remain, dtype=np.int64)

    if active.size:
        # 8 档都不行：说明这个形状窄到内法线一步都迈不进去（比如 1px 细刺）。
        # 用「微小内缩」，而不是顶点本身 —— 顶点在环的边界上，point_in_ring
        # 对它的结果**不确定**（200 点方形环里 101/200 个顶点被判 False；
        # 400 点 L 形 201/400；1400 点 C 形 281/560）。把未经验证的顶点塞进
        # 投票池会污染多数表决。1e-3 px 的内缩点一定落在环内侧。
        sel = idx[active]
        tiny = 1e-3
        cand = np.empty((active.size, 2), dtype=np.float64)
        cand[:, 0] = arr[sel, 0] + nx[sel] * tiny
        cand[:, 1] = arr[sel, 1] + ny[sel] * tiny
        inside = _points_in_ring_arr(cand, arr)
        for j, (pos, ok) in enumerate(zip(active.tolist(), inside)):
            if ok:
                chosen[pos] = (float(cand[j, 0]), float(cand[j, 1]))
        # 连微小内缩都不在环内：这个点在拓扑上无法给出可靠探针，直接跳过。
        # 少一个探针不影响多数表决（本来就有 10~19 个），
        # 而塞一个未验证的点进去会污染结论。

    pts.extend(p for p in chosen if p is not None)

    return pts if pts else [ring_centroid(ring)]


def _bbox_of(ring):
    """环的轴对齐包围盒 (minx, miny, maxx, maxy)。"""
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    return (min(xs), min(ys), max(xs), max(ys))


# 大环阈值：点数超过它的环走 numpy 批量判定。
# 依据：实测 11452 点的环被查 635 次，纯 Python 每次 0.73ms（遍历 11452 条边）
# → 累计 545ms，占 split_outer 的 97%。批量版一次算完所有点，价格只跟环长有关。
_VEC_RING_MIN = 512


def _points_in_ring_batch(pts, ring):
    """批量版射线法：一次判断多个点是否在同一个环内。

    和 point_in_ring 的语义完全一致（半开区间 (y0 > y) != (y1 > y) 避免顶点重复计数），
    只是把「逐边遍历」换成 numpy 广播。

    对 11452 点的环：判断 1 个点从 0.73ms 降到 0.06ms 量级；
    判断 N 个点时优势更大（一次广播覆盖所有点）。
    """
    if not pts:
        return []
    arr = np.asarray(ring, dtype=np.float64)
    if len(arr) < 3:
        return [False] * len(pts)
    return _points_in_ring_arr(np.asarray(pts, dtype=np.float64), arr)


def _points_in_ring_arr(pts_arr, arr):
    """批量判定的内层：接收**已经转好的** numpy 数组。

    ⚠️ 参数必须是 ndarray —— 这个函数存在的唯一理由就是别重复转换。
       实测教训：早先直接在 split_outer 的循环里调 _points_in_ring_batch(pts, ring)，
       每次都要 np.asarray(ring) 把 11452 点的 Python 列表转成数组，
       379 次转换花了 470ms —— 占 split_outer 的 87%，
       而真正的判定计算只要几十毫秒。转换比计算贵，这是 numpy 的常见陷阱。

    返回：每个点是否在环内的 bool 列表。
    """
    if pts_arr.size == 0:
        return []

    px = pts_arr[:, 0]
    py = pts_arr[:, 1]

    x0 = arr[:, 0]
    y0 = arr[:, 1]
    x1 = np.roll(x0, -1)
    y1 = np.roll(y0, -1)

    # (点数, 边数) 的穿越掩膜
    cond = (y0[None, :] > py[:, None]) != (y1[None, :] > py[:, None])
    dy = y1 - y0
    dy_safe = np.where(np.abs(dy) < 1e-12, 1e-12, dy)
    t = (py[:, None] - y0[None, :]) / dy_safe[None, :]
    xc = x0[None, :] + t * (x1 - x0)[None, :]
    # 只保留真正穿越的边，然后数「交点在这个点右边」的个数，奇数即在内部
    crosses = cond & (px[:, None] < xc)
    return (crosses.sum(axis=1) % 2 == 1).tolist()


def split_outer(points_per_ring):
    """挑出「外环」，丢掉洞。

    判据：一个环，如果有奇数个更大的环把它包在里面，它就是洞。
    这就是「中心不留洞」的实现 —— 洞被丢掉，内部不会被挖空。

    【性能：这道题在真实素材上是 O(n²) 的，必须做三件剪枝】

    实测一张 3883×1978 的人物贴图：trace_rings 出 **380 个环**
    （大量是 4 点的碎屑环），最大环 11452 点。
    朴素的两两判定 = 380² = 14.4 万次，而**单次大环判定要 0.81ms**
    （要遍历 11452 条边），小环只要 0.0004ms —— 差 2000 倍。
    于是 14.4 万 × 平均代价 ≈ 秒级；而多点投票又把它乘了 19 倍
    → 千万次判定 → **Blender 直接崩掉（实测复现）**。

    三道剪枝，任何一道都不能省：
      1. **包围盒预筛**：候选环若包围盒不包含当前点，直接跳过，
         不做 point_in_ring。绝大多数碎屑环在这一步就被排除。
      2. **按面积排序 + 只向"更大的环"查**：内层循环从"所有环"缩到
         "面积更大且包围盒含该点的环"，通常只有 0~2 个。
      3. **代表点按环大小缩放**：小环用 1~3 个点就够（它本来就没凹口），
         大环才值得多采几个。环小的时候多点投票毫无收益。

    返回 (outer, inner)，两个都是环列表，保持原顺序。
    """
    from collections import Counter

    rings = list(points_per_ring)
    n = len(rings)
    if n == 0:
        return [], []
    if n == 1:
        return [rings[0]], []

    areas = [abs(ring_area(r)) for r in rings]
    bboxes = [_bbox_of(r) for r in rings]
    lens = [len(r) for r in rings]

    # 面积从大到小排：外层环一定比内层环大，所以只需向"前面"（更大的）查
    order = sorted(range(n), key=lambda i: areas[i], reverse=True)

    # 代表点数：凹口只可能出现在"点多"的环上。
    # 4 点的碎屑环不可能是凹的，1 个点（质心/顶点）足够。
    probes_cache = {}
    for i in range(n):
        L = lens[i]
        if L <= 8:
            probes_cache[i] = [ring_centroid(rings[i])]
        elif L <= 64:
            probes_cache[i] = _representative_points(rings[i], max_samples=3)
        else:
            probes_cache[i] = _representative_points(rings[i], max_samples=9)

    # 【关键】大环预先转成 numpy 数组，整轮只转一次。
    # 实测：11452 点的环被查 379 次，每次 np.asarray 要 1.2ms，
    # 379 次转换 = 470ms，占 split_outer 的 87%，而判定计算只要几十毫秒。
    # 转一次存起来，这 470ms 就没了。
    arr_cache = {}
    for i in range(n):
        if lens[i] >= _VEC_RING_MIN:
            arr_cache[i] = np.asarray(rings[i], dtype=np.float64)

    # 按面积降序遍历，把已经处理过的（更大的）环放进这个列表当候选池
    bigger = []          # [(area, bbox, ring_idx)]
    depth_of = [0] * n

    for i in order:
        probes = probes_cache[i]
        ai = areas[i]
        # 面积只可能变小（降序），所以候选池里全是"面积 >= 当前"的
        candidates = [(a, bb, j) for (a, bb, j) in bigger if a > ai]
        if not candidates:
            depth_of[i] = 0
            bigger.append((ai, bboxes[i], i))
            continue

        # votes[k] = 第 k 个代表点被几个更大的环包住
        votes = [0] * len(probes)

        for (_, bb, j) in candidates:
            target = rings[j]
            # 剪枝 1：先按包围盒把「不可能被这个环包住」的探针剔掉，
            # 只把剩下的交给 point_in_ring / 批量版。
            xs_bb = (bb[0], bb[2])
            ys_bb = (bb[1], bb[3])
            hit = [k for k, pt in enumerate(probes)
                   if xs_bb[0] <= pt[0] <= xs_bb[1] and ys_bb[0] <= pt[1] <= ys_bb[1]]
            if not hit:
                continue

            sub = [probes[k] for k in hit]
            arr = arr_cache.get(j)
            if arr is not None:
                # 剪枝 2a：大环走 numpy 批量，一次算完这批探针。
                # 用预算好的数组，避免每次都重新转换（那是真正的开销）。
                inside = _points_in_ring_arr(np.asarray(sub, dtype=np.float64), arr)
            else:
                # 剪枝 2b：小环逐点判（纯 Python 在几十条边上比 numpy 快）
                inside = [point_in_ring(pt, target) for pt in sub]

            for k, ok in zip(hit, inside):
                if ok:
                    votes[k] += 1

        if votes:
            # 众数。
            # ⚠️ 注意：Counter.most_common 在**平票**时返回「插入顺序最先出现的」那个值，
            #    不是较小值（实测 Counter([0,1]).most_common(1) → [(0,1)]，
            #    Counter([1,0]).most_common(1) → [(1,1)]）。
            #    早先这里的注释写「平票取较小值」，是错的 —— 会误导后来人
            #    基于一个不存在的不变量去推理。
            #
            #    平票本身意味着「代表点意见分裂」，此时两种判定都缺乏依据；
            #    真要偏向保守可以用 sorted(votes)[len//2]，但实测没有出现的必要，
            #    保持现状（取先出现的）即可。
            depth_of[i] = Counter(votes).most_common(1)[0][0]
        else:
            depth_of[i] = 0
        bigger.append((ai, bboxes[i], i))

    outer, inner = [], []
    for i in range(n):
        (outer if depth_of[i] % 2 == 0 else inner).append(rings[i])
    return outer, inner
