"""Download and verify a Compify runtime without importing Blender."""

import base64
import contextlib
import hashlib
import http.client
from importlib import metadata
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile


CHUNK_SIZE = 1 << 18
DEPS_IMPORT = "import numpy, scipy, PIL, onnxruntime"
DEPS_MARKER = ".deps_ok"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
RETRY_SOURCE = "检查网络后重试；如果一直失败，请保留这里的来源和原因。"
RETRY_LOCAL = "检查安装目录的写入权限、剩余空间及文件占用后重试。"
RETRY_MANIFEST = "请重新安装完整的 Compify 插件后重试。"


class InstallCancelled(RuntimeError):
    pass


class InstallFailure(RuntimeError):
    def __init__(self, step, reason, advice=RETRY_LOCAL):
        self.step, self.reason, self.advice = step, str(reason), advice
        super().__init__(f"{step}：{reason}")


class SourceFailure(RuntimeError):
    pass


def cancel_if_requested(should_cancel):
    if should_cancel():
        raise InstallCancelled("已取消安装")


def sha256_file(path, chunk=1 << 20):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(chunk), b""):
            digest.update(block)
    return digest.hexdigest()


def _check_file_entry(entry):
    if not isinstance(entry["size"], int) or entry["size"] <= 0:
        raise ValueError("文件大小必须为正整数")
    if not re.fullmatch(r"[a-f0-9]{64}", entry["sha256"]):
        raise ValueError("文件缺少有效 SHA-256")


def validate_manifest(manifest, tiers):
    if manifest["version"] != 1:
        raise ValueError("安装清单版本不受支持")
    python = manifest["python"]
    if python.get("url"):
        _check_file_entry(python)
        if python["archive"] not in {"tar.gz", "zip"} or python["root"] != "python":
            raise ValueError("Python 压缩包格式或目录无效")
    for tier in tiers:
        entry = manifest["models"][tier]
        _check_file_entry(entry)
        if not entry["url"]:
            raise ValueError(f"{tier} 缺少模型地址")
    wheels = manifest["wheels"]
    for profile in ("3.10", "3.11", "3.12", "3.13"):
        entries = wheel_entries(wheels, profile)
        if len(entries) != (12 if profile == "3.10" else 7):
            raise ValueError(f"Python {profile} 的依赖轮子清单不完整")
        for entry in entries:
            _check_file_entry(entry)


def wheel_entries(wheels, profile):
    entries = []
    for path, size, checksum in wheels["common"] + wheels[profile]:
        if not re.fullmatch(r"[a-f0-9]{2}/[a-f0-9]{2}/[a-f0-9]{60}/[\w.+-]+\.whl", path):
            raise ValueError(f"轮子地址无效：{path}")
        entries.append({
            "filename": path.rsplit("/", 1)[-1],
            "size": size,
            "sha256": checksum,
            "urls": [wheels["mirror"] + path, wheels["official"] + path],
        })
    return entries


def host_of(url):
    return urllib.parse.urlsplit(url).hostname or "本地文件"


def _source_reason(error):
    if isinstance(error, urllib.error.HTTPError):
        return f"HTTP {error.code} {error.reason}"
    if isinstance(error, urllib.error.URLError):
        error = error.reason
    if isinstance(error, TimeoutError):
        return "连接或读取超时"
    return str(error)


def download(url, destination, expected_sha256=None, progress=None,
             should_cancel=lambda: False, *, expected_size=None,
             on_response=lambda _url: None, on_verify=lambda: None):
    destination = Path(destination)
    cancel_if_requested(should_cancel)
    destination.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    done = 0
    try:
        response = urllib.request.urlopen(url, timeout=15)
    except (OSError, http.client.HTTPException) as error:
        raise SourceFailure(_source_reason(error)) from error
    with response, tempfile.TemporaryDirectory(dir=destination.parent,
                                               prefix=".compify-part-") as scratch:
        on_response(response.geturl())
        status = getattr(response, "status", None)
        if status not in (None, 200):
            raise SourceFailure(f"服务器未返回完整文件（HTTP {status}）")
        announced = response.headers.get("Content-Length")
        size = int(announced) if announced and announced.isdecimal() else None
        if expected_size is not None and size is not None and size != expected_size:
            raise SourceFailure(f"文件大小错误，服务器报告 {size:,} 字节，需要 {expected_size:,} 字节")
        limit = expected_size if expected_size is not None else size
        if progress:
            progress(0, limit or 0)
        partial = Path(scratch) / "download"
        with partial.open("wb") as output:
            while True:
                cancel_if_requested(should_cancel)
                try:
                    block = response.read(CHUNK_SIZE)
                except (OSError, http.client.HTTPException) as error:
                    raise SourceFailure(_source_reason(error)) from error
                if not block:
                    break
                done += len(block)
                if limit is not None and done > limit:
                    raise SourceFailure(f"收到的文件大于预期的 {limit:,} 字节")
                output.write(block)
                digest.update(block)
                if progress:
                    progress(done, limit or 0)
        on_verify()
        if limit is not None and done != limit:
            raise SourceFailure(f"下载中断，收到 {done:,} / {limit:,} 字节")
        if expected_sha256 and digest.hexdigest() != expected_sha256.lower():
            raise SourceFailure("SHA-256 校验失败，文件与安装清单不一致")
        cancel_if_requested(should_cancel)
        partial.replace(destination)
    return destination


def _matches(path, entry):
    try:
        return path.stat().st_size == entry["size"] and sha256_file(path) == entry["sha256"]
    except FileNotFoundError:
        return False


def _obtain(path, label, entry, urls, emit, should_cancel, online):
    step = f"下载{label}"
    if path.is_file():
        emit("stage", step=f"校验已下载的{label}", artifact=path.name)
        if _matches(path, entry):
            emit("verified", artifact=path.name, size=entry["size"], sha256=entry["sha256"],
                 host="本地缓存")
            return path
    if not online:
        raise InstallFailure(step, "Blender 已禁用联网，且没有通过校验的本地文件",
                             "在偏好设置中允许联网后，点原按钮重试。")
    failures = []
    for attempt, url in enumerate(filter(None, urls), 1):
        source = host_of(url)
        host = source
        emit("attempt", step=step, artifact=path.name, source=source,
             attempt=attempt, done=0, total=entry["size"],
             previous=failures[-1] if failures else "")

        def on_response(final_url):
            nonlocal host
            host = host_of(final_url)

        def progress(done, total):
            emit("progress", step=step, artifact=path.name, source=source,
                 host=host, attempt=attempt, done=done, total=total)

        try:
            download(url, path, entry["sha256"], progress, should_cancel,
                     expected_size=entry["size"], on_response=on_response,
                     on_verify=lambda: emit("stage", step=f"校验{label}", artifact=path.name))
        except SourceFailure as error:
            failures.append(f"{source}（实际：{host}）：{error}" if host != source
                            else f"{source}：{error}")
            continue
        except OSError as error:
            raise InstallFailure(f"保存{label}", error) from error
        emit("verified", artifact=path.name, size=entry["size"], sha256=entry["sha256"],
             source=source, host=host, attempt=attempt)
        return path
    raise InstallFailure(step, "\n".join(failures) or "安装清单没有可用来源", RETRY_SOURCE)


def _run(python, args, step, should_cancel, *, required=True, advice=RETRY_LOCAL):
    env = {key: value for key, value in os.environ.items()
           if not key.upper().startswith(("PIP_", "PYTHON"))}
    env["PIP_CONFIG_FILE"] = os.devnull
    with tempfile.TemporaryFile() as output:
        try:
            with subprocess.Popen([str(python), "-I", "-B", "-X", "utf8", *args],
                                  stdin=subprocess.DEVNULL, stdout=output,
                                  stderr=subprocess.STDOUT, env=env,
                                  creationflags=NO_WINDOW) as process:
                deadline = time.monotonic() + 300
                try:
                    while process.poll() is None:
                        cancel_if_requested(should_cancel)
                        if time.monotonic() > deadline:
                            raise InstallFailure(step, "本地进程超过 5 分钟未完成", advice)
                        time.sleep(0.05)
                finally:
                    if process.poll() is None:
                        process.kill()
                        process.wait()
        except OSError as error:
            if required:
                raise InstallFailure(step, error, advice) from error
            return False, str(error)
        output.seek(max(0, output.tell() - 8192))
        text = output.read().decode("utf-8", errors="replace").strip()
    if process.returncode and required:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        detail = next((line for line in reversed(lines) if line.startswith("ERROR:")), "")
        raise InstallFailure(step, detail or (lines[-1] if lines else
                                            f"本地进程退出（{process.returncode}）"), advice)
    return process.returncode == 0, text


def _extract(archive, staging, should_cancel):
    def check_member(name):
        if not (staging / name).resolve().is_relative_to(staging):
            raise ValueError(f"压缩包路径超出安装目录：{name}")
        cancel_if_requested(should_cancel)

    if archive.name.endswith(".tar.gz"):
        with tarfile.open(archive, "r:gz") as bundle:
            for member in bundle:
                check_member(member.name)
                if not (member.isfile() or member.isdir()):
                    raise ValueError(f"压缩包含不支持的条目：{member.name}")
                if hasattr(tarfile, "data_filter"):
                    bundle.extract(member, staging, filter="data")
                else:
                    bundle.extract(member, staging, set_attrs=False)
    else:
        with zipfile.ZipFile(archive) as bundle:
            for member in bundle.infolist():
                check_member(member.filename)
                bundle.extract(member, staging)


def _runtime_parts(runtime):
    venv = Path("venv", "Scripts", "python.exe")
    if (runtime / venv).is_file():
        return venv
    return Path("python", "python.exe")


def _stage_runtime(runtime, stage, manifest, blender_python, emit, should_cancel, online):
    relative = _runtime_parts(runtime)
    existing = runtime / relative
    emit("stage", step="检查推理环境")
    if existing.is_file():
        working, _ = _run(existing, ["-c", DEPS_IMPORT], "检查推理环境",
                          should_cancel, required=False)
        if working:
            return existing, None
        emit("stage", step="准备修复已有推理环境")
        source = runtime / relative.parts[0]

        def copy_checked(src, dst):
            cancel_if_requested(should_cancel)
            return shutil.copy2(src, dst)

        try:
            shutil.copytree(source, stage / source.name, copy_function=copy_checked)
        except OSError as error:
            raise InstallFailure("准备修复已有推理环境", error) from error
    elif manifest["python"].get("url"):
        entry = manifest["python"]
        archive = _obtain(runtime / ".compify-downloads" / f"runtime.{entry['archive']}",
                          "Python 环境", entry, (entry.get("mirror_url"), entry["url"]),
                          emit, should_cancel, online)
        emit("stage", step="解压 Python 环境")
        try:
            _extract(archive, stage, should_cancel)
        except (OSError, ValueError, tarfile.TarError, zipfile.BadZipFile) as error:
            raise InstallFailure("解压 Python 环境", error) from error
    else:
        emit("stage", step="创建虚拟环境")
        relative = Path("venv", "Scripts", "python.exe")
        _run(blender_python, ["-m", "venv", str(stage / "venv")],
             "创建虚拟环境", should_cancel)
    python = stage / relative
    _install_wheels(python, stage, runtime / ".compify-downloads" / "wheels",
                    manifest["wheels"], emit, should_cancel, online)
    return python, stage / relative.parts[0]


def _install_wheels(python, stage, cache, wheels, emit, should_cancel, online):
    emit("stage", step="检查 Python 版本")
    command = ("import json, sys, sysconfig; "
               "print(json.dumps(['%s.%s' % sys.version_info[:2], sysconfig.get_platform(), "
               "sys.prefix, sysconfig.get_path('purelib'), sysconfig.get_path('platlib')]))")
    _, output = _run(python, ["-c", command], "检查 Python 版本", should_cancel)
    profile, platform, prefix, purelib, platlib = json.loads(output.splitlines()[-1])
    if platform != "win-amd64" or profile not in wheels:
        raise InstallFailure("选择推理依赖", f"没有适配 {profile} {platform} 的已校验依赖",
                             "请在偏好设置选择一个新的运行环境目录，再重新安装。")
    site_paths = list(dict.fromkeys((purelib, platlib)))
    prefix = Path(prefix).resolve()
    packages = []
    for entry in wheel_entries(wheels, profile):
        filename = entry["filename"]
        name, version, _ = filename.split("-", 2)
        path = _obtain(cache / filename, f"依赖 {name}", entry,
                       entry["urls"], emit, should_cancel, online)
        requirement = f"{path.as_uri()} --hash=sha256:{entry['sha256']}"
        packages.append((name, version, path, requirement))
    requirements_path = stage / "requirements.txt"

    def report(done, package=None, reused=False):
        emit("install_progress", step="安装推理依赖", done=done, total=len(packages),
             package=package, reused=reused)

    report(0)
    has_pip, _ = _run(python, ["-m", "pip", "--version"], "检查 pip", should_cancel,
                      required=False)
    if not has_pip:
        _run(python, ["-m", "ensurepip"], "准备离线依赖安装", should_cancel)
    pip_install = ["-m", "pip", "install", "--disable-pip-version-check", "--no-input",
                   "--no-index", "--no-cache-dir", "--require-hashes"]
    for done, (name, version, path, requirement) in enumerate(packages, 1):
        cancel_if_requested(should_cancel)
        with zipfile.ZipFile(path) as wheel:
            wheel_metadata = wheel.read(f"{name}-{version}.dist-info/METADATA")
            payload = {item for item in wheel.namelist() if not item.endswith("/") and
                       ".dist-info/" not in item and ".data/" not in item}
        distribution = next(metadata.distributions(name=name, path=site_paths), None)
        reused = _matching_distribution(distribution, version, wheel_metadata, prefix,
                                        should_cancel, payload=payload)
        if not reused:
            requirements_path.write_text(requirement + "\n", encoding="utf-8")
            step = f"安装推理依赖 {name}"
            _run(python, pip_install + ["--no-deps", "--no-compile", "--force-reinstall", "-r",
                                        str(requirements_path)], step, should_cancel)
            distribution = next(metadata.distributions(name=name, path=site_paths), None)
            if not _matching_distribution(distribution, version, wheel_metadata, prefix,
                                          should_cancel):
                raise InstallFailure(step, f"未能核实已安装的 {name} {version}")
        cancel_if_requested(should_cancel)
        report(done, name, reused)
    emit("stage", step="验证推理依赖")
    _check_locked_dependencies(python, [(name, version) for name, version, _, _ in packages],
                               should_cancel)
    _run(python, ["-c", DEPS_IMPORT], "验证推理依赖", should_cancel,
         advice="请检查运行库及系统兼容性，修正原因后重试。")


def _matching_distribution(distribution, version, wheel_metadata, prefix, should_cancel,
                           *, payload=None):
    if distribution is None:
        return False
    try:
        files = distribution.files or ()
        if distribution.version != version or not files:
            return False
        record_metadata = next((item for item in files if item.name == "METADATA" and
                                item.parent.name.endswith(".dist-info")), None)
        if record_metadata is None:
            return False
        installed_metadata = Path(record_metadata.locate()).resolve()
        if (not installed_metadata.is_relative_to(prefix) or
                installed_metadata.read_bytes() != wheel_metadata):
            return False
        if payload is None:
            return True
        hashed = set()
        for item in files:
            cancel_if_requested(should_cancel)
            if item.hash is None:
                continue
            path = Path(item.locate()).resolve()
            if (item.hash.mode != "sha256" or not path.is_relative_to(prefix) or
                    path.stat().st_size != item.size):
                return False
            digest = bytes.fromhex(sha256_file(path))
            if base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=") != item.hash.value:
                return False
            hashed.add(item.as_posix())
        return bool(hashed) and payload <= hashed
    except (OSError, TypeError, ValueError):
        return False


def _check_locked_dependencies(python, packages, should_cancel):
    code = """
import json
import sys
from importlib.metadata import distribution
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

locked = {canonicalize_name(name): version for name, version in json.loads(sys.argv[1])}
for name, version in locked.items():
    installed = distribution(name)
    if installed.version != version:
        sys.exit(f"{name} 需要 {version}，实际安装了 {installed.version}")
    for declaration in installed.requires or ():
        requirement = Requirement(declaration)
        if requirement.marker is not None and not requirement.marker.evaluate({"extra": ""}):
            continue
        dependency = locked.get(canonicalize_name(requirement.name))
        if (requirement.url or requirement.extras or dependency is None or
                not requirement.specifier.contains(dependency, prereleases=True)):
            sys.exit(f"{name} 需要 {requirement}，与当前依赖清单不兼容")
"""
    _run(python, ["-c", code, json.dumps(packages)], "验证推理依赖", should_cancel,
         advice="请核对依赖包清单后重试。")


def _stage_model(python, target, tier, entry, emit, should_cancel, online):
    label = {"FAST": "快档模型", "ACCURATE": "准档模型"}.get(tier, tier)
    emit("stage", step=f"检查{label}")
    if _matches(target, entry):
        candidate = target
    else:
        candidate = _obtain(target.parent / ".compify-downloads" / "model.onnx",
                            label, entry, (entry["url"], entry.get("fallback_url")),
                            emit, should_cancel, online)
    emit("stage", step=f"验证{label}可以加载")
    code = ("import sys, onnxruntime as ort; "
            "ort.InferenceSession(sys.argv[1], providers=['CPUExecutionProvider'])")
    _run(python, ["-c", code, str(candidate)], f"验证{label}", should_cancel,
         advice="请检查推理环境兼容性，修正原因后点原按钮重试。")
    return candidate


def _publish(changes):
    backups = []
    published = []
    try:
        for staged, target in changes:
            if target.exists():
                folder = Path(tempfile.mkdtemp(dir=target.parent, prefix=".compify-backup-"))
                backup = folder / target.name
                try:
                    target.replace(backup)
                except OSError:
                    folder.rmdir()
                    raise
                backups.append((backup, target))
            staged.replace(target)
            published.append((target, staged))
    except OSError:
        failed = []
        for source, target in [*reversed(published), *reversed(backups)]:
            try:
                source.replace(target)
            except OSError:
                failed.append(str(source))
        if failed:
            raise InstallFailure("恢复原安装文件", "文件仍被占用，已保留在：" + "\n".join(failed),
                                 "请关闭占用文件的程序，再从所列位置恢复后重试。")
        raise
    finally:
        for backup, _ in backups:
            if not backup.exists():
                with contextlib.suppress(OSError):
                    backup.parent.rmdir()
    for backup, _ in backups:
        shutil.rmtree(backup.parent, ignore_errors=True)


def install(manifest, runtime, models, blender_python, emit, should_cancel, online=True):
    cancel_if_requested(should_cancel)
    for path in (runtime, *(target.parent for target in models.values())):
        try:
            path.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            raise InstallFailure("准备安装目录", error) from error
    with contextlib.ExitStack() as stack:
        stage = Path(stack.enter_context(tempfile.TemporaryDirectory(
            dir=runtime, prefix=".compify-stage-"))).resolve()
        python, staged_runtime = _stage_runtime(runtime, stage, manifest, blender_python,
                                                emit, should_cancel, online)
        changes = []
        if staged_runtime:
            changes.append((staged_runtime, runtime / staged_runtime.name))
        marker = runtime / DEPS_MARKER
        if staged_runtime or not marker.is_file():
            staged_marker = stage / DEPS_MARKER
            staged_marker.write_text("numpy scipy pillow onnxruntime", encoding="utf-8")
            changes.append((staged_marker, marker))
        for tier, target in models.items():
            candidate = _stage_model(python, target, tier, manifest["models"][tier],
                                     emit, should_cancel, online)
            if candidate != target:
                model_stage = Path(stack.enter_context(tempfile.TemporaryDirectory(
                    dir=target.parent, prefix=".compify-stage-"))) / target.name
                shutil.copyfile(candidate, model_stage)
                changes.append((model_stage, target))
        cancel_if_requested(should_cancel)
        emit("stage", step="写入已验证的安装文件")
        try:
            _publish(changes)
        except OSError as error:
            raise InstallFailure("写入已验证的安装文件", error) from error
        for _, target in changes:
            if target.name == "model.onnx":
                with contextlib.suppress(OSError):
                    (target.parent / ".compify-downloads" / target.name).unlink(missing_ok=True)


def main(request_path):
    step = "读取安装任务"

    def emit(kind, **details):
        nonlocal step
        step = details.get("step", step)
        print(json.dumps({"kind": kind, **details}, ensure_ascii=True), flush=True)

    try:
        request = json.loads(request_path.read_text(encoding="utf-8"))
        models = {tier: Path(path) for tier, path in request["models"].items()}
        cancel = request_path.with_name("cancel")
        install(request["manifest"], Path(request["runtime"]), models, request["launcher"],
                emit, lambda: cancel.exists() or not request_path.exists(), request["online"])
    except InstallCancelled:
        emit("cancelled")
    except InstallFailure as error:
        emit("error", step=error.step, reason=error.reason, advice=error.advice)
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        emit("error", step=step, reason=str(error), advice=RETRY_LOCAL)
    else:
        emit("done", tiers=list(models))


if __name__ == "__main__":
    main(Path(sys.argv[1]))
