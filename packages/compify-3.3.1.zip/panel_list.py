"""Section 3 rows: blockouts with status, per-object params and batch tools."""

import json

import bpy

from . import blockout
from . import blockout_live

_ = bpy.app.translations.pgettext_iface

# 边缘补边自 3.3.0 起暂停（三角化网格没有四边形边可焊）：属性与代码保留，
# 但不再出现在这张表里，所以界面上没有入口。
PARAM_FIELDS = ("density", "strength", "smooth", "trim", "threshold",
                "outward")
# Rows that only make sense in a given switch state: with 裁形 unchecked
# these were dead controls, so they are not drawn at all (and take no space
# in the box).  Each gate is a list of (attribute, wanted) pairs.
FIELD_GATES = {"threshold": (("trim", True),),
               "outward": (("trim", True),)}


def visible_fields(settings):
    """PARAM_FIELDS filtered by the switch that makes each row meaningful."""
    out = []
    for field in PARAM_FIELDS:
        gates = FIELD_GATES.get(field, ())
        if any(bool(getattr(settings, attr, False)) != wanted
               for attr, wanted in gates):
            continue
        out.append(field)
    return out


# ------------------------------------------------------------------ state

def _fold_states(scene):
    raw = getattr(scene, "compify_uv_group_fold_states", "{}")
    try:
        states = json.loads(raw or "{}")
    except ValueError:
        return {}
    return states if isinstance(states, dict) else {}


def params_open(scene, name):
    """Parameters start folded (requirement §6 collapse defaults)."""
    return bool(_fold_states(scene).get("params:%s" % name))


def missing_projection(obj):
    """The plate this blockout came from is gone or no longer has a projection."""
    source_name = str(obj.get(blockout.PROP_SOURCE) or "")
    source = bpy.data.objects.get(source_name)
    if source is None:
        return True
    return blockout.projection_camera(source) is None


# ------------------------------------------------------------------ operators

class CompifyBlockoutFoldParams(bpy.types.Operator):
    """展开或收起这个模型的参数；同一时间只展开一个"""

    bl_idname = "compify.blockout_fold_params"
    bl_label = "模型参数"

    name: bpy.props.StringProperty()
    key: bpy.props.StringProperty()

    def execute(self, context):
        scene = context.scene
        states = _fold_states(scene)
        key = self.key or ("params:%s" % self.name)
        opening = not bool(states.get(key))
        # Only one parameter block is open at a time: close every other
        # "params:" entry, leaving plate:/matfold:/objlist: states alone.
        if opening:
            for other in [k for k in states
                          if k.startswith("params:") and k != key]:
                states[other] = False
        states[key] = opening
        scene.compify_uv_group_fold_states = json.dumps(states)
        # The open model may have wider caps than the class carries right now.
        blockout_live.request_redeclare_if_needed()
        return {"FINISHED"}


class CompifyBlockoutRetry(bpy.types.Operator):
    """按当前参数重建这个模型"""

    bl_idname = "compify.blockout_retry"
    bl_label = "重试重建"

    name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.name)
        if obj is None:
            self.report({"ERROR"}, "对象已不存在")
            return {"CANCELLED"}
        ok, message, _ms = blockout_live.rebuild(obj)
        if not ok:
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        return {"FINISHED"}


class CompifyBlockoutDelete(bpy.types.Operator):
    """删除这些模型"""

    bl_idname = "compify.blockout_delete"
    bl_label = "删除模型"
    bl_options = {"UNDO"}

    names_json: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        try:
            names = json.loads(self.names_json or "[]")
        except ValueError:
            names = []
        removed = 0
        for name in names:
            obj = bpy.data.objects.get(name)
            if obj is None:
                continue
            mesh = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh is not None and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
            removed += 1
        if not removed:
            return {"CANCELLED"}
        self.report({"INFO"}, "已删除 %d 个模型" % removed)
        return {"FINISHED"}


CLASSES = (
    CompifyBlockoutFoldParams,
    CompifyBlockoutRetry,
    CompifyBlockoutDelete,
)
