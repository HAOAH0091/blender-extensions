# -*- coding: utf-8 -*-

"""
Compify插件的中文翻译
Translation dictionary for Compify addon
"""

import bpy

# 翻译字典，格式：{locale: {(context, msgid): translation}}
translations_dict = {
    "zh_CN": {
        # 面板标题 - 使用 "*" 上下文
        ("*", "Compify"): "Compify",
        ("*", "Camera Project UV Adjust"): "摄像机投射UV调整",
        
        # 主面板标签
        ("*", "  Camera"): "  摄像机",
        
        # 操作按钮标题 - 使用 "*" 上下文（Blender会自动处理Operator标签）
        ("*", "Batch Generate UV Adjust"): "批量生成UV调整",
        ("*", "Refresh & Clean UV Adjust List"): "刷新和清理UV调整列表",
        ("*", "Select Object"): "选择对象",
        ("*", "Select Camera"): "选择摄像机",
        ("*", "Update UV Adjust"): "更新UV调整",
        ("*", "Delete UV Adjust"): "删除UV调整",
        
        # UV调整面板
        ("*", "Refresh & Clean"): "刷新和清理",
        ("*", "Batch Generate:"): "批量生成:",
        ("*", "Camera"): "摄像机",
        ("*", "Generate for Selected Objects"): "为选中对象生成",
        ("*", "Selected Mesh Objects: {}"): "选中的网格对象: {}",
        ("*", "No mesh objects selected"): "未选中网格对象",
        
        # 投射管理面板
        ("*", "Projection Material Management:"): "投射管理:",
        ("*", "No projection materials found"): "未找到投射",
        ("*", "Found {} unused node groups"): "发现 {} 个未使用的节点组",
        ("*", "Clean"): "清理",
        ("*", "Shared Group"): "共用组",
        ("*", "Clean Unused Node Groups"): "清理未使用的节点组",
        ("*", "Clean unused node groups."): "清理未使用的节点组。",
        ("*", "Select Material Objects"): "选择材质物体",
        ("*", "Select all objects using this material."): "选择所有使用此材质的物体。",
        
        # UV调整操作 - 已移动到上面的操作按钮标题部分
        
        # 摄像机对齐面板（来自camera_align.py）
        
        # 摄像机对齐操作描述
        
        # 属性描述
        ("*", "Bake Resolution"): "烘焙分辨率",
        ("*", "UV Adjust Camera"): "UV调整摄像机",
        ("*", "Camera to use for UV adjustment calculations"): "用于UV调整计算的摄像机",
        
        # 操作描述
        ("*", "Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."): "3D合成中对象的摄像机投射UV调整 - 3D视口侧边栏。",
        ("*", "Refresh UV Adjust node groups list and clean up invalid references"): "刷新UV调整节点组列表并清理无效引用",
        ("*", "Update parameters of a UV Adjust node group"): "更新UV调整节点组的参数",
        ("*", "Batch generate UV adjust node groups."): "批量生成UV调整节点组。",
        ("*", "Select the object associated with this UV adjust."): "选择与此UV调整关联的对象。",
        ("*", "Select the camera associated with this UV adjust."): "选择与此UV调整关联的摄像机。",
        ("*", "Delete UV adjust."): "删除UV调整。",

        # Baking feature
        ("*", "Bake Material Projection"): "烘焙材质投射",
        ("*", "Bake camera projection, creating new objects with baked textures"): "烘焙摄像机投射，创建带有烘焙纹理的新对象",
        ("*", "Auto-unwrap UV"): "自动展 UV",
        ("*", "Automatically unwrap UV for objects with existing UV layers"): "对已有 UV 层的对象自动执行展 UV",
        ("*", "UV Handling"): "UV 处理",
        ("*", "Scope: Single object '{}'"): "范围：单个对象 '{}'",
        ("*", "Scope: All material users ({})"): "范围：该材质的全部使用者（{}）",
        ("*", "Not the viewport selection."): "不受当前视口选择影响。",
        ("*", "Bake check"): "烘焙前检查",
        ("*", "{} excluded from the current view layer"): "{} 个对象不在当前视图层",
        ("*", "{} hidden in the viewport"): "{} 个对象在视口隐藏",
        ("*", "{} hidden from render"): "{} 个对象不参与渲染",
        ("*", "{} not selectable"): "{} 个对象不可选择",
        ("*", "Bake copies are shown temporarily; originals stay unchanged."): "烘焙使用的是临时显示的副本，原对象保持不变。",
        ("*", "{} missing UV will be auto-unwrapped"): "{} 个对象缺少 UV，将自动展开",
        ("*", "{} excluded from view layer"): "{} 个不在当前视图层",
        ("*", "{} hidden in viewport"): "{} 个在视口隐藏",
        ("*", "{} missing UV"): "{} 个缺少 UV",
        ("*", "Original objects will NOT be modified."): "原对象不会被修改。",
        ("*", "A new object with baked texture will be created for each."): "每个对象都会生成一个带烘焙纹理的新对象。",
        ("*", "Material:  {}"): "材质：  {}",
        ("*", "Will create: {} new object(s)"): "将创建 {} 个新对象",
        ("*", "({} non-mesh will be skipped)"): "（跳过 {} 个非网格对象）",
        ("*", "No mesh objects found"): "未找到网格对象",
        ("*", "Smart UV Project Settings"): "智能 UV 投影设置",
        ("*", "Objects ({}):"): "对象（{}）：",
        ("*", "Objects ({})"): "对象（{}）",
        ("*", "  {}  [NO UV - forced]"): "  {}  [无 UV - 强制展开]",
        ("*", "Unwrap"): "展开",
        ("*", "Keep UV"): "保留 UV",
        ("*", "Object Name"): "对象名称",
        ("*", "If set, only bake this specific object instead of all"): "设置后只烘焙此对象，而不是全部对象",
        ("*", "Resolution"): "分辨率",
        ("*", "Bake texture resolution in pixels"): "烘焙纹理的分辨率（像素）",
        ("*", "Angle Limit"): "角度限制",
        ("*", "Angle limit for Smart UV Project"): "智能 UV 投影的角度限制",
        ("*", "Island Margin"): "UV 岛边距",
        ("*", "Island margin for Smart UV Project"): "智能 UV 投影的 UV 岛边距",
        ("*", "Area Weight"): "面积权重",
        ("*", "Weight UV faces by area, higher values favor larger faces"): "按面积加权 UV 面，数值越大越偏向大面积面",
        ("*", "Correct Aspect"): "校正纵横比",
        ("*", "Correct aspect ratio to avoid UV stretching"): "校正纵横比，避免 UV 拉伸",
        ("*", "Scale to Bounds"): "缩放到边界",
        ("*", "Scale UV islands to fit within 0-1 bounds"): "缩放 UV 岛以适配 0-1 范围",
        ("*", "Material not found"): "未找到材质",
        ("*", "Material has no Camera Project node group. Run 'Generate for Selected Objects' first."): "材质缺少 Camera Project 节点组。请先执行“为选中对象生成”。",
        ("*", "No objects in the scene use this material"): "当前场景中没有对象使用此材质",
        ("*", "Object '{}' not found in material's users"): "材质使用者中未找到对象 '{}'",
        ("*", "Material '{}' not found"): "未找到材质 '{}'",
        ("*", "Baked {} object(s). New material: '{}'"): "已烘焙 {} 个对象。新材质：'{}'",
        ("*", "UV unwrapped: {}"): "重新展开 UV：{} 个",
        ("*", "UV forced unwrap: {}"): "强制展开 UV：{} 个",
        ("*", "Toggle Object Unwrap"): "切换对象 UV 展开",
        ("*", "No objects use this material"): "没有对象使用此材质",
        ("*", "No objects match the specified filter"): "没有对象匹配指定筛选",
        ("*", "Material has no Camera Project node group"): "材质缺少 Camera Project 节点组",
        ("*", "Internal error: image/object count mismatch ({} vs {})"): "内部错误：图片/对象数量不一致（{} 对 {}）",
        ("*", "Failed to clone material for {}"): "为 {} 克隆材质失败",
        ("*", "Internal error: failed to fix render visibility"): "内部错误：无法修复渲染可见性",
        ("*", "Internal error: bake copies are excluded from the current view layer"): "内部错误：烘焙副本被排除在当前视图层之外",
        ("*", "Cycles render engine is not available"): "Cycles 渲染引擎不可用",
        ("*", "Could not enter Edit Mode for UV unwrap: {}. The object is hidden in the viewport or excluded from the current view layer."): "无法进入编辑模式展开 UV：{}。该对象在视口中隐藏，或被排除在当前视图层之外。",
        ("*", "Baking failed: {}"): "烘焙失败：{}",
        ("*", "Baked {} object(s)"): "已烘焙 {} 个对象",
    },
    
    "zh_TW": {
        # 繁体中文翻译（可选）
        ("*", "Compify"): "Compify",
        ("*", "Camera Project UV Adjust"): "相機投射UV調整",
        ("*", "  Camera"): "  相機",
        ("*", "Batch Generate UV Adjust"): "批量生成UV調整",
        ("*", "Refresh & Clean UV Adjust List"): "刷新和清理UV調整列表",
        ("*", "Select Object"): "選擇物件",
        ("*", "Select Camera"): "選擇相機",
        ("*", "Update UV Adjust"): "更新UV調整",
        ("*", "Delete UV Adjust"): "刪除UV調整",

        # 3D視口分欄中的列表與狀態文本
        ("*", "Refresh & Clean"): "刷新和清理",
        ("*", "Batch Generate:"): "批量生成:",
        ("*", "Camera"): "相機",
        ("*", "Generate for Selected Objects"): "為選中對象生成",
        ("*", "Selected Mesh Objects: {}"): "選中的網格對象: {}",
        ("*", "No mesh objects selected"): "未選中網格對象",

        # 投影材質管理面板
        ("*", "Projection Material Management:"): "投射材質管理:",
        ("*", "No projection materials found"): "未找到投射材質",
        ("*", "Found {} unused node groups"): "發現 {} 個未使用的節點組",
        ("*", "Clean"): "清理",
        ("*", "Shared Group"): "共用組",
        ("*", "Clean Unused Node Groups"): "清理未使用的節點組",
        ("*", "Clean unused node groups."): "清理未使用的節點組。",
        ("*", "Select Material Objects"): "選擇材質物體",
        ("*", "Select all objects using this material."): "選擇所有使用此材質的物體。",

        # 對齊面板的列標題

        # 操作描述（tooltip）

        # 屬性描述
        ("*", "Bake Resolution"): "烘焙分辨率",
        ("*", "UV Adjust Camera"): "UV調整相機",
        ("*", "Camera to use for UV adjustment calculations"): "用於UV調整計算的相機",

        # 面板/操作的 tooltip 描述
        ("*", "Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."): "3D合成中對象的相機投射UV調整 - 3D視口側邊欄。",
        ("*", "Refresh UV Adjust node groups list and clean up invalid references"): "刷新UV調整節點組列表並清理無效引用",
        ("*", "Update parameters of a UV Adjust node group"): "更新UV調整節點組的參數",
        ("*", "Batch generate UV adjust node groups."): "批量生成UV調整節點組。",
        ("*", "Select the object associated with this UV adjust."): "選擇與此UV調整關聯的物件。",
        ("*", "Select the camera associated with this UV adjust."): "選擇與此UV調整關聯的相機。",
        ("*", "Delete UV adjust."): "刪除UV調整。",
        # 可以继续添加更多繁体中文翻译...

        # Baking feature
        ("*", "Bake Material Projection"): "烘焙材質投射",
        ("*", "Bake camera projection, creating new objects with baked textures"): "烘焙相機投射，創建帶有烘焙紋理的新物件",
        ("*", "Auto-unwrap UV"): "自動展 UV",
        ("*", "Automatically unwrap UV for objects with existing UV layers"): "對已有 UV 層的物件自動執行展 UV",
        ("*", "UV Handling"): "UV 處理",
        ("*", "Scope: Single object '{}'"): "範圍：單個物件 '{}'",
        ("*", "Scope: All material users ({})"): "範圍：該材質的全部使用者（{}）",
        ("*", "Not the viewport selection."): "不受當前視口選擇影響。",
        ("*", "Bake check"): "烘焙前檢查",
        ("*", "{} excluded from the current view layer"): "{} 個物件不在當前視圖層",
        ("*", "{} hidden in the viewport"): "{} 個物件在視口隱藏",
        ("*", "{} hidden from render"): "{} 個物件不參與渲染",
        ("*", "{} not selectable"): "{} 個物件不可選擇",
        ("*", "Bake copies are shown temporarily; originals stay unchanged."): "烘焙使用的是臨時顯示的副本，原物件保持不變。",
        ("*", "{} missing UV will be auto-unwrapped"): "{} 個物件缺少 UV，將自動展開",
        ("*", "{} excluded from view layer"): "{} 個不在當前視圖層",
        ("*", "{} hidden in viewport"): "{} 個在視口隱藏",
        ("*", "{} missing UV"): "{} 個缺少 UV",
        ("*", "Original objects will NOT be modified."): "原物件不會被修改。",
        ("*", "A new object with baked texture will be created for each."): "每個物件都會生成一個帶烘焙紋理的新物件。",
        ("*", "Material:  {}"): "材質：  {}",
        ("*", "Will create: {} new object(s)"): "將創建 {} 個新物件",
        ("*", "({} non-mesh will be skipped)"): "（跳過 {} 個非網格物件）",
        ("*", "No mesh objects found"): "未找到網格物件",
        ("*", "Smart UV Project Settings"): "智慧 UV 投影設定",
        ("*", "Objects ({}):"): "物件（{}）：",
        ("*", "Objects ({})"): "物件（{}）",
        ("*", "  {}  [NO UV - forced]"): "  {}  [無 UV - 強制展開]",
        ("*", "Unwrap"): "展開",
        ("*", "Keep UV"): "保留 UV",
        ("*", "Object Name"): "物件名稱",
        ("*", "If set, only bake this specific object instead of all"): "設定後只烘焙此物件，而不是全部物件",
        ("*", "Resolution"): "解析度",
        ("*", "Bake texture resolution in pixels"): "烘焙紋理的解析度（像素）",
        ("*", "Angle Limit"): "角度限制",
        ("*", "Angle limit for Smart UV Project"): "智慧 UV 投影的角度限制",
        ("*", "Island Margin"): "UV 島邊距",
        ("*", "Island margin for Smart UV Project"): "智慧 UV 投影的 UV 島邊距",
        ("*", "Area Weight"): "面積權重",
        ("*", "Weight UV faces by area, higher values favor larger faces"): "按面積加權 UV 面，數值越大越偏向大面積面",
        ("*", "Correct Aspect"): "校正長寬比",
        ("*", "Correct aspect ratio to avoid UV stretching"): "校正長寬比，避免 UV 拉伸",
        ("*", "Scale to Bounds"): "縮放到邊界",
        ("*", "Scale UV islands to fit within 0-1 bounds"): "縮放 UV 島以適配 0-1 範圍",
        ("*", "Material not found"): "未找到材質",
        ("*", "Material has no Camera Project node group. Run 'Generate for Selected Objects' first."): "材質缺少 Camera Project 節點組。請先執行「為選中物件生成」。",
        ("*", "No objects in the scene use this material"): "當前場景中沒有物件使用此材質",
        ("*", "Object '{}' not found in material's users"): "材質使用者中未找到物件 '{}'",
        ("*", "Material '{}' not found"): "未找到材質 '{}'",
        ("*", "Baked {} object(s). New material: '{}'"): "已烘焙 {} 個物件。新材質：'{}'",
        ("*", "UV unwrapped: {}"): "重新展開 UV：{} 個",
        ("*", "UV forced unwrap: {}"): "強制展開 UV：{} 個",
        ("*", "Toggle Object Unwrap"): "切換物件 UV 展開",
        ("*", "No objects use this material"): "沒有物件使用此材質",
        ("*", "No objects match the specified filter"): "沒有物件符合指定篩選",
        ("*", "Material has no Camera Project node group"): "材質缺少 Camera Project 節點組",
        ("*", "Internal error: image/object count mismatch ({} vs {})"): "內部錯誤：圖片/物件數量不一致（{} 對 {}）",
        ("*", "Failed to clone material for {}"): "為 {} 複製材質失敗",
        ("*", "Internal error: failed to fix render visibility"): "內部錯誤：無法修復渲染可見性",
        ("*", "Internal error: bake copies are excluded from the current view layer"): "內部錯誤：烘焙副本被排除在當前視圖層之外",
        ("*", "Cycles render engine is not available"): "Cycles 渲染引擎不可用",
        ("*", "Could not enter Edit Mode for UV unwrap: {}. The object is hidden in the viewport or excluded from the current view layer."): "無法進入編輯模式展開 UV：{}。該物件在視口中隱藏，或被排除在當前視圖層之外。",
        ("*", "Baking failed: {}"): "烘焙失敗：{}",
        ("*", "Baked {} object(s)"): "已烘焙 {} 個物件",
    }
}

def register(module_name):
    """注册翻译，必须使用插件根模块名作为域"""
    try:
        # 兼容不同版本的中文语言代码：将 zh_CN 映射到 zh_Hans/zh_HANS/zh
        # 将 zh_TW 映射到 zh_Hant/zh_HANT
        aliases = {
            "zh_CN": ["zh_Hans", "zh_HANS", "zh"],
            "zh_TW": ["zh_Hant", "zh_HANT"],
        }
        for src, alist in aliases.items():
            if src in translations_dict:
                for alias in alist:
                    if alias not in translations_dict:
                        translations_dict[alias] = translations_dict[src]
        
        bpy.app.translations.register(module_name, translations_dict)
        print(f"Compify translations registered successfully for domain: {module_name}")
    except Exception as e:
        print(f"Failed to register Compify translations: {e}")


def unregister(module_name):
    """注销翻译，域必须与注册时一致"""
    try:
        bpy.app.translations.unregister(module_name)
        print(f"Compify translations unregistered successfully for domain: {module_name}")
    except Exception as e:
        print(f"Failed to unregister Compify translations: {e}")

if __name__ == "__main__":
    register(__name__)
