"""Sidebar panel "投射管理": projection materials and their objects.

Split out of the main panel so a long projection list cannot push the bake
section off screen; the panel title folds it natively.

The blockout (model) rows that used to hang under each material live in
panel_models now, so this module never draws a bake or model entry.
"""

import bpy

from .node_groups import find_object_by_data_name, find_objects_using_material
from .node_group_manager import get_all_uv_adjust_node_groups
from . import compify_parallax_lock as plock
from . import blockout
from . import panel_list
from . import panel_shared
from .panel_shared import (
    draw_material_object_sublist,
    get_fold_state,
)

_ = bpy.app.translations.pgettext_iface


class CompifyPanelProjections(bpy.types.Panel):
    """投射材质与图平面的列表"""

    bl_label = "投射管理"
    bl_idname = "VIEW3D_PT_compify_projections"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = ""
    bl_category = "Compify"
    bl_order = 20

    _last_sel = frozenset()

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        cls = type(self)

        layout.operator(
            "compify.refresh_uv_adjust_list", text="刷新和清理",
            icon="FILE_REFRESH")

        # Get all UV Adjust node groups
        uv_groups = get_all_uv_adjust_node_groups(scene)

        # Filter: only show node groups that are used by at least one material
        active_groups = [gi for gi in uv_groups if gi["materials"]]

        if not active_groups:
            layout.label(text="还没有投射 · 去分区 1 生成投射", icon="INFO")
        orphan_groups = [gi for gi in uv_groups if not gi["materials"]]

        # ---- 醒目提示条：检测到"旧场景共享投影"被带进当前场景（P2 一键同步）----
        # 完整复制场景后，旧场景的投射是共享的，会被带进新场景。此时该组
        # belongs_to_other_scene=True（物体/摄像机在旧场景），面板应提示用户一键同步，
        # 而不是当成失效组静默处理。
        sync_candidates = [
            gi for gi in active_groups if gi.get("belongs_to_other_scene")
        ]
        if sync_candidates:
            sync_box = layout.box()
            sync_box.alert = True  # 红色警示样式
            sync_box.label(
                text=_("检测到旧场景的共享投射"),
                icon="ERROR",
            )
            # Details live in the ⓘ popup instead of a second line.
            sync_box.operator(
                "compify.one_click_sync_uv_adjust",
                text=_("一键为此场景物体创建独立投射"),
                icon="RESTRICT_SELECT_OFF",
            )

        if active_groups:
            # Group by camera (level 1)
            groups_by_camera = {}
            for gi in active_groups:
                cam_key = (
                    gi["camera_name"] if gi["camera_name"] else "未命名摄像机"
                )
                groups_by_camera.setdefault(cam_key, []).append(gi)

            # Cache selected objects for highlighting
            selected_set = set(context.selected_objects)

            # Build material->objects lookup for selection detection.
            # Unlike gi["object"] (first-match only), this covers all
            # objects sharing each material.  Filter to current scene
            # so the lookup (and downstream mesh counts) stay accurate.
            scene_object_set = set(context.scene.objects)
            mat_to_objects = {}
            for gi in active_groups:
                for mat_name in gi["materials"]:
                    if mat_name not in mat_to_objects:
                        all_objs = find_objects_using_material(mat_name)
                        mat_to_objects[mat_name] = [
                            o for o in all_objs if o in scene_object_set
                        ]

            def _mat_has_selected(mat_name):
                """True if any object using this material is selected."""
                objs = mat_to_objects.get(mat_name, [])
                return any(o in selected_set for o in objs)

            # Debug: log selection changes (only when set differs from last draw).
            # _last_sel defaults to empty frozenset (not None) so module reload
            # doesn't trigger a spurious first-run traversal.
            current_sel_names = frozenset(o.name for o in selected_set)
            last_sel = getattr(cls, '_last_sel', frozenset())
            if current_sel_names != last_sel:
                highlighted = [
                    m for m, objs in mat_to_objects.items()
                    if any(o in selected_set for o in objs)]
                if highlighted:
                    print(f"[Compify|UI] selected → highlighted materials: "
                          f"{highlighted}")
                cls._last_sel = current_sel_names

            # ★ 残留锁定警示（独立审查 第六轮 🔴-1）：
            #   摄像机被换数据块 / 删除之后，`ORIG_ATTR` / `BASE_ATTR` / `OBJ_CAM_KEY`
            #   还留在网格上，但按摄像机名/uid 都找不到记录 ⇒ 面板不给重置按钮、
            #   几何永久停在变形态。这里给一条**不依赖摄像机身份**的还原通道。
            try:
                _orphans = plock.find_orphan_locks(context.scene)
            except Exception:
                _orphans = []
            if _orphans:
                _obox = layout.box()
                _orow = _obox.row()
                _orow.alert = True
                _orow.label(
                    text="⚠ 发现 %d 个网格残留锁定痕迹（所属摄像机已不存在）" % len(_orphans),
                    icon="ERROR")
                _obox.operator("compify.parallax_reset_orphans",
                               text="还原这些网格（几何回到原形）", icon="LOOP_BACK")

            # Draw grouped, collapsible lists per camera
            for cam_name, items in groups_by_camera.items():
                group_box = layout.box()
                header = group_box.row()

                # Read foldout state from scene property; default expanded
                fold_state = get_fold_state(context.scene, cam_name, True)

                # Fold toggle control via operator
                toggle = header.operator(
                    "compify.toggle_uv_group_fold",
                    text="",
                    emboss=False,
                    icon="TRIA_DOWN" if fold_state else "TRIA_RIGHT",
                )
                toggle.camera_name = cam_name
                toggle.new_state = not fold_state

                # Camera object first: the header button shows blue while that
                # camera is selected, and the lock state below needs it too.
                _cam_obj = find_object_by_data_name(cam_name, type_filter="CAMERA")
                try:
                    cam_selected = bool(_cam_obj and _cam_obj.select_get())
                except Exception:  # noqa: BLE001  (object outside the view layer)
                    cam_selected = False
                cam_op = header.operator(
                    "compify.select_uv_adjust_camera", text=cam_name,
                    depress=cam_selected,
                )
                cam_op.camera_name = cam_name

                # Display count of materials in this camera group
                total_materials = sum(len(gi["materials"]) for gi in items)
                header.label(text=f"({total_materials})")

                # 网格视差锁定：锁定/解锁 + 重置（每摄像机一组）
                # ⚠️ 一次拿全状态（独立审查 第三轮 F11：原来 is_locked / has_lock_record /
                #    is_patched 各解一遍 JSON，每摄像机每帧 4 次）。
                _stt = (plock.lock_status(context.scene, _cam_obj) if _cam_obj
                        else {"locked": False, "patched": False, "has_record": False})
                _locked_now = _stt["locked"]
                # ⚠️ UI 假阳性（独立审查 R13）：只看 state.enabled 不够 ——
                #    补丁被外部清掉时（如面板「重新生成投影组」），图案其实已解冻，
                #    面板却仍显示 🔒。这里把「补丁是否真的在」也纳入图标。
                _patched_now = _stt["patched"]
                # ★ 降级（锁定后 Alt+D / 加修改器）也要亮 ⚠（独立审查 第八轮 🟡-2）：
                #   那种情况下网格已静默停止适配，但冻结坐标还在 ⇒ 画面看不出异常。
                #
                # ⚠️⚠️ 判据必须是**三态**（独立审查 第九轮 🟡 F-3）：
                #   原来写的是 `_patched_now != _locked_now` ⇒ 只要**解锁**就亮 ⚠，
                #   而「解锁」恰恰是插件明确设计的正常态（`unlock_group` 的文案是
                #   "网格/图案保持当前状态…点「重置」可完全还原"，面板也照常给 ↺）
                #   ——**它故意保留补丁**（图案不回退），于是常量匹配 ⇒ ⚠ 常亮且不自愈。
                #   后果：① 用户以为锁定坏了、去点"还原孤儿"白跑一趟；
                #         ② 真正的降级警示被稀释（⚠ 语义失效）。
                #   正解：只有 **①锁定中但补丁没了** 或 **②锁定中且有降级** 才算异常；
                #        解锁（!locked）一律是正常态。
                _degraded = _stt.get("degraded", 0)
                if _locked_now:
                    _icon_state = "ERROR" if ((not _patched_now) or _degraded > 0) else "LOCKED"
                else:
                    _icon_state = "UNLOCKED"
                # 重置按钮的显示条件是「还有锁定记录」而非「当前已锁定」：
                # 解锁只是停止跟随、不回退，解锁后仍必须能重置，否则回不到原形。（独立审查 S6）
                _has_rec = _stt["has_record"]
                _lock_btn = header.operator(
                    "compify.parallax_lock_toggle",
                    text=("⚠" if _icon_state == "ERROR" else ""),
                    icon=_icon_state,
                )
                _lock_btn.camera_name = cam_name
                if _has_rec:
                    _rst_btn = header.operator(
                        "compify.parallax_lock_reset",
                        text="",
                        icon="LOOP_BACK",
                    )
                    _rst_btn.camera_name = cam_name

                # Expanded list of material entries for this camera
                if fold_state:
                    for gi in items:
                        materials = gi["materials"]
                        node_group = gi["node_group"]
                        is_valid = gi["is_valid"]

                        if len(materials) == 1:
                            # Single material: collapsible, click name to
                            # expand object sub-list.
                            mat_name = materials[0]
                            highlight = _mat_has_selected(mat_name)
                            mat_fold_key = f"matfold:{mat_name}"
                            mat_fold_state = get_fold_state(
                                context.scene, mat_fold_key, False)

                            # Count mesh objects for display (reuse lookup)
                            all_objs = mat_to_objects.get(mat_name, [])
                            mesh_objects = [
                                o for o in all_objs if o.type == 'MESH']
                            mesh_count = len(mesh_objects)

                            item = group_box.row()
                            header_row = item.row(align=True)

                            # Material fold toggle — the triangle on the
                            # material name controls object sub-list visibility.
                            mat_toggle = header_row.operator(
                                "compify.toggle_uv_group_fold",
                                text="",
                                emboss=False,
                                icon="TRIA_DOWN" if mat_fold_state else "TRIA_RIGHT",
                            )
                            mat_toggle.camera_name = mat_fold_key
                            mat_toggle.new_state = not mat_fold_state

                            # Name is the select button: blue while anything
                            # under this material is selected.  Red stays for
                            # failure text only.
                            label_text = "%s  (%d)" % (mat_name, mesh_count)
                            if not is_valid:
                                # 显示具体失效原因（P1 诊断提示）
                                _reason = gi.get("status", {}).get("reason", "投射失效")
                                label_text += "  ⚠ %s" % _reason
                            right_px = 26.0 + (
                                26.0 if panel_shared.SHOW_UPDATE_UV_ADJUST_BUTTON
                                else 0.0)
                            cell, cell_px = panel_shared.split_name_row(
                                context, header_row, right_px)
                            select_op = cell.operator(
                                "compify.select_material_objects",
                                text=panel_shared.fit_text(
                                    label_text, cell_px, icon_px=16.0),
                                icon="MATERIAL" if is_valid else "ERROR",
                                depress=highlight,
                            )
                            select_op.material_name = mat_name

                            # 「更新UV调整」按钮：当前由 SHOW_UPDATE_UV_ADJUST_BUTTON
                            # 关掉（见根模块顶部的开关说明）。operator 仍然注册着，
                            # 只是面板上不画 —— 需要时把开关改回 True 就回来了。
                            if panel_shared.SHOW_UPDATE_UV_ADJUST_BUTTON:
                                update_op = cell.operator(
                                    "compify.update_uv_adjust",
                                    text="",
                                    icon="FILE_REFRESH",
                                )
                                update_op.node_group_name = node_group.name
                                update_op.enabled = is_valid

                            delete_op = cell.operator(
                                "compify.delete_uv_adjust",
                                text="",
                                icon="X",
                            )
                            delete_op.node_group_name = node_group.name

                            # Object sub-list: only visible when material
                            # is expanded (fold state = True).
                            if mat_fold_state:
                                draw_material_object_sublist(
                                    context, group_box, mat_name,
                                    show_header=False,
                                    mesh_objects=mesh_objects,
                                    selected_set=selected_set)
                        else:
                            # Multiple materials sharing same node group: show as collapsible group
                            shared_key = f"shared_{node_group.name}"
                            shared_fold_state = get_fold_state(
                                context.scene, shared_key, False
                            )

                            shared_box = group_box.box()
                            shared_header = shared_box.row()

                            # Fold toggle for shared group
                            shared_toggle = shared_header.operator(
                                "compify.toggle_uv_group_fold",
                                text="",
                                emboss=False,
                                icon="TRIA_DOWN" if shared_fold_state else "TRIA_RIGHT",
                            )
                            shared_toggle.camera_name = shared_key
                            shared_toggle.new_state = not shared_fold_state

                            # Shared group label
                            shared_label = _("Shared Group") + f" ({len(materials)})"
                            if is_valid:
                                shared_header.label(text=shared_label, icon="LINKED")
                            else:
                                # 显示具体失效原因（P1 诊断提示）
                                _reason = gi.get("status", {}).get("reason", "投射失效")
                                shared_header.label(
                                    text=f"{shared_label}  ⚠ {_reason}", icon="ERROR")

                            # Update button for shared group
                            # 同单材质条目，由 SHOW_UPDATE_UV_ADJUST_BUTTON 控制显示。
                            if panel_shared.SHOW_UPDATE_UV_ADJUST_BUTTON:
                                update_op = shared_header.operator(
                                    "compify.update_uv_adjust", text="",
                                    icon="FILE_REFRESH"
                                )
                                update_op.node_group_name = node_group.name
                                update_op.enabled = is_valid

                            # Delete button for shared group
                            delete_op = shared_header.operator(
                                "compify.delete_uv_adjust", text="", icon="X"
                            )
                            delete_op.node_group_name = node_group.name

                            # Expanded list of materials in shared group.
                            # Each sub-material is a collapsible entry.
                            if shared_fold_state:
                                for mat_name in materials:
                                    sub_fold_key = f"matfold:{mat_name}"
                                    sub_fold_state = get_fold_state(
                                        context.scene, sub_fold_key, False)

                                    # Count mesh objects (reuse lookup)
                                    sub_all = mat_to_objects.get(mat_name, [])
                                    sub_mesh_objects = [
                                        o for o in sub_all
                                        if o.type == 'MESH']
                                    sub_mesh_count = len(sub_mesh_objects)

                                    sub_highlight = _mat_has_selected(mat_name)
                                    sub_header = shared_box.row(align=True)

                                    # Sub-material fold toggle
                                    sub_toggle = sub_header.operator(
                                        "compify.toggle_uv_group_fold",
                                        text="",
                                        emboss=False,
                                        icon="TRIA_DOWN" if sub_fold_state else "TRIA_RIGHT",
                                    )
                                    sub_toggle.camera_name = sub_fold_key
                                    sub_toggle.new_state = not sub_fold_state

                                    # Name is the select button (blue while
                                    # selected); no separate select icon.
                                    sub_cell, sub_px = panel_shared.split_name_row(
                                        context, sub_header, 0.0)
                                    mat_select_op = sub_cell.operator(
                                        "compify.select_material_objects",
                                        text=panel_shared.fit_text(
                                            "%s  (%d)" % (mat_name, sub_mesh_count),
                                            sub_px, icon_px=16.0),
                                        icon="MATERIAL",
                                        depress=sub_highlight,
                                    )
                                    mat_select_op.material_name = mat_name

                                    if sub_fold_state:
                                        draw_material_object_sublist(
                                            context, shared_box, mat_name,
                                            show_header=False,
                                            mesh_objects=sub_mesh_objects,
                                            selected_set=selected_set)

        # Show orphan node groups warning at bottom
        if orphan_groups:
            layout.separator()
            warning_row = layout.row()
            warning_row.label(
                text=_("Found {} unused node groups").format(len(orphan_groups)),
                icon="INFO",
            )
            warning_row.operator(
                "compify.clean_orphan_uv_adjust", text=_("Clean"), icon="TRASH"
            )
