"""Helpers shared by the three Compify sidebar panels.

Deliberately imports nothing from the add-on root module: the root imports
this one, so anything here must stay a leaf.  Everything needed comes from
node_groups / bake_visibility / blockout / blockout_live.
"""

import json

import bpy

from .node_groups import find_objects_using_material
from .bake_visibility import summarize_visibility, visibility_issues
from . import blockout
from . import blockout_live

_ = bpy.app.translations.pgettext_iface

# ========================================================
# 功能开关：材质行上的「更新UV调整」按钮
#
# 现状（用户判断）：「挪完摄像机/物体之后重新量一遍包围盒、把 offset/scale 写回
# 节点组」这一步，实际上用不上 —— 因为投影对象一旦建好，构图调整走的是
# 摄像机 dolly / 视差锁定，用户不会回来手动重算 UV。
# 所以先把入口藏起来，不删实现；需要时把开关改回 True 即可。
# ========================================================
SHOW_UPDATE_UV_ADJUST_BUTTON = False

# Only used for the "selection changed" debug print below.
_last_obj_sel = frozenset()


# ------------------------------------------------------------------ folding
def get_fold_states(scene):
    """Get fold states dictionary from scene property."""
    try:
        states = json.loads(scene.compify_uv_group_fold_states)
        return states if isinstance(states, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def set_fold_state(scene, key, value):
    """Set a fold state in scene property."""
    states = get_fold_states(scene)
    states[key] = value
    scene.compify_uv_group_fold_states = json.dumps(states)


def get_fold_state(scene, key, default=False):
    """Get a fold state from scene property."""
    states = get_fold_states(scene)
    return states.get(key, default)


# -------------------------------------------------------------- row widths
def text_px(text, size=11.0):
    """Measured width of ``text`` in pixels; 0.0 when blf is unavailable."""
    try:
        import blf
        font = 0
        blf.size(font, size)
        return blf.dimensions(font, text)[0]
    except Exception:  # noqa: BLE001  (background / no UI font)
        return 0.0


def fit_text(text, max_px, icon_px=0.0, pad_px=6.0):
    """Shorten ``text`` with a trailing … until it fits ``max_px`` pixels.

    The full name stays reachable through the operator's description(), which
    is why truncation is allowed at all.  Widths are measured, never guessed.
    """
    if max_px <= 0:
        return text
    budget = max_px - icon_px - pad_px
    if budget <= 8.0:
        return "…"
    if text_px(text) <= budget:
        return text
    cut = text
    while cut and text_px(cut + "…") > budget:
        cut = cut[:-1]
    return (cut + "…") if cut else "…"


def region_width(context, fallback=210.0):
    """Row width in pixels.

    Measured in Blender 5.3: a 280 px sidebar region gives ~202 px rows
    (panel margins, the scrollbar and the fold triangle take the rest), so
    the subtraction is the measured chrome, not a guess.
    """
    try:
        width = float(context.region.width)
    except Exception:  # noqa: BLE001
        width = fallback
    return max(80.0, width - 78.0)


def split_name_row(context, row, right_px):
    """Return (cell, cell_px): name button on the left, fixed width on the right.

    Drawing the name button into ``cell`` and the icon buttons after it keeps
    every row's right-hand icons on the same x, whatever the name length.
    """
    width = region_width(context)
    if right_px <= 0:
        return row, width
    factor = max(0.45, 1.0 - right_px / width)
    return row.split(factor=factor, align=True), width * factor


# ------------------------------------------------------------------ drawing
def draw_material_object_sublist(context, parent_box, mat_name, show_header=True,
                                 mesh_objects=None, selected_set=None):
    """Draw object entries for a material, optionally with a fold-toggle header.

    When show_header=True (default), draws a collapsible header row with
    fold toggle and object count. When show_header=False, the caller
    controls visibility externally and only the object rows are drawn.

    mesh_objects: pre-queried list of objects (avoids duplicate
    find_objects_using_material() call). If None, queries internally.
    selected_set: set of currently selected objects for highlighting.
    """
    global _last_obj_sel

    if mesh_objects is None:
        mat_objects = find_objects_using_material(mat_name)
        # Filter to current scene only
        scene_objects = set(context.scene.objects)
        mat_objects = [o for o in mat_objects if o in scene_objects]
        mesh_objects = [o for o in mat_objects if o.type == 'MESH']
    if not mesh_objects:
        return

    if show_header:
        # Fold key scoped to this material.
        # "objlist:" prefix isolates from existing camera-name keys and
        # shared-group keys ("shared_{node_group.name}").  Collision is
        # impossible since camera names never start with "objlist:".
        obj_list_key = f"objlist:{mat_name}"
        obj_list_fold = get_fold_state(context.scene, obj_list_key, False)

        # Fold toggle row
        toggle_row = parent_box.row()
        toggle = toggle_row.operator(
            "compify.toggle_uv_group_fold",
            text="",
            emboss=False,
            icon="TRIA_DOWN" if obj_list_fold else "TRIA_RIGHT",
        )
        toggle.camera_name = obj_list_key
        # ^ Note: camera_name is reused here as a general-purpose fold key.
        # CompifyToggleUVGroupFold stores it blindly into scene JSON state;
        # the property name reflects its original purpose, not the current one.
        toggle.new_state = not obj_list_fold
        toggle_row.label(
            text=_("Objects ({})").format(len(mesh_objects)),
            icon="MESH_DATA")

        if not obj_list_fold:
            return

    # Status summary
    summary = summarize_visibility(mesh_objects, context.view_layer)
    parts = []
    if summary["not_in_view_layer"]:
        parts.append(_("{} excluded from view layer").format(
            summary["not_in_view_layer"]))
    if summary["hide_viewport"]:
        parts.append(_("{} hidden in viewport").format(
            summary["hide_viewport"]))
    if summary["hide_render"]:
        parts.append(_("{} hidden from render").format(
            summary["hide_render"]))
    if summary["hide_select"]:
        parts.append(_("{} not selectable").format(
            summary["hide_select"]))
    if summary["no_uv"]:
        parts.append(_("{} missing UV").format(summary["no_uv"]))
    if parts:
        warn_row = parent_box.row()
        warn_row.label(
            text="  " + "⚠ " + ", ".join(parts),
            icon="INFO")

    # Object entries
    for obj in mesh_objects:
        is_selected = selected_set is not None and obj in selected_set
        obj_row = parent_box.row(align=True)

        # Status icon (priority: hidden > no-UV > OK).  Selection is the blue
        # name button now, so it no longer takes an icon of its own.
        has_uv = bool(obj.data.uv_layers.active)
        issues = visibility_issues(obj, context.view_layer)
        if issues:
            obj_row.label(text="", icon="HIDE_ON")
        elif not has_uv:
            obj_row.label(text="", icon="ERROR")
        else:
            obj_row.label(text="", icon="CHECKMARK")

        # Object name is the select button: blue while selected, plain when
        # not.  There is no separate select icon any more.
        cell, cell_px = split_name_row(context, obj_row, 20.0 if issues else 0.0)
        select_op = cell.operator(
            "compify.select_object_by_name",
            text=fit_text(obj.name, cell_px, icon_px=0.0),
            depress=is_selected,
        )
        select_op.object_name = obj.name

        # Extra info tip for objects with visibility problems
        if issues:
            cell.label(text="", icon="INFO")

    # Debug: log selected objects in this sub-list (only on change)
    if selected_set:
        current_sel = frozenset(o.name for o in selected_set)
        if current_sel != _last_obj_sel:
            sel_names = [o.name for o in mesh_objects if o in selected_set]
            if sel_names:
                print(f"[Compify|UI] '{mat_name}' objects selected: {sel_names}")
            _last_obj_sel = current_sel
