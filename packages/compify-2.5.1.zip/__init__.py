# ====================== BEGIN GPL LICENSE BLOCK ======================
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ======================= END GPL LICENSE BLOCK ========================

bl_info = {
    "name": "Compify",
    "version": (2, 5, 1),
    "author": "Nathan Vegdahl, Ian Hubert",
    "blender": (4, 0, 0),
    "description": "Do compositing in 3D space.",
    "location": "Scene properties",
    # "doc_url": "",
    "category": "Compositing",
}

import math

import bpy
import json

from .names import (
    compify_mat_name,
    compify_baked_texture_name,
    MAIN_NODE_NAME,
    BAKE_IMAGE_NODE_NAME,
    UV_LAYER_NAME,
)
from . import translations

_ = bpy.app.translations.pgettext_iface
from .node_groups import (
    ensure_footage_group,
    ensure_camera_project_group,
    ensure_feathered_square_group,
    check_camera_project_group_exists,
    find_object_by_data_name,
    find_objects_using_material,
    find_camera_connected_to_uv_adjust_in_material,
)
from .node_group_manager import (
    get_all_uv_adjust_node_groups,
    clean_invalid_uv_adjust_node_groups,
    get_orphan_uv_adjust_node_groups,
    clean_orphan_uv_adjust_node_groups,
    update_uv_adjust_node_group_parameters,
    delete_uv_adjust_node_group,
    handle_object_rename_in_node_groups,
    get_node_group_usage_info,
    add_uv_adjust_to_material,
    create_and_add_uv_adjust_node_group,
    invalidate_uv_cache,
)
from .bake_pipeline import (
    bake_material_projection,
)
from .uv_utils import leftmost_u
from .properties import redraw_viewport
from .camera_align import camera_align_register, camera_align_unregister
from .bake import Baker

# ========================================================
# Helper functions for common checks


def can_prep_scene(context):
    """Check if the scene is ready for Compify prep/bake operations."""
    config = context.scene.compify_config
    return (
        context.mode == "OBJECT"
        and config.footage is not None
        and config.camera is not None
        and config.geo_collection is not None
        and len(config.geo_collection.all_objects) > 0
    )


def can_render_with_compify(context):
    """Check if the scene is ready for Compify render operations."""
    return can_prep_scene(context) and compify_mat_name(context) in bpy.data.materials


# ========================================================
# Helper functions for fold state management using scene properties


def _get_fold_states(scene):
    """Get fold states dictionary from scene property."""
    try:
        states = json.loads(scene.compify_uv_group_fold_states)
        return states if isinstance(states, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def _set_fold_state(scene, key, value):
    """Set a fold state in scene property."""
    states = _get_fold_states(scene)
    states[key] = value
    scene.compify_uv_group_fold_states = json.dumps(states)


def _get_fold_state(scene, key, default=False):
    """Get a fold state from scene property."""
    states = _get_fold_states(scene)
    return states.get(key, default)


def _clear_fold_states(scene):
    """Clear all fold states for the scene."""
    scene.compify_uv_group_fold_states = "{}"


def _draw_material_object_sublist(context, parent_box, mat_name, show_header=True,
                                mesh_objects=None, selected_set=None):
    """Draw object entries for a material, optionally with a fold-toggle header.

    When show_header=True (default), draws a collapsible header row with
    fold toggle and object count. When show_header=False, the caller
    controls visibility externally and only the object rows are drawn.

    mesh_objects: pre-queried list of mesh objects (avoids duplicate
    find_objects_using_material() call). If None, queries internally.
    selected_set: set of currently selected objects for highlighting.
    """
    if mesh_objects is None:
        mat_objects = find_objects_using_material(mat_name)
        # Filter to current scene only
        scene_objects = set(context.scene.objects)
        mat_objects = [o for o in mat_objects if o in scene_objects]
        mesh_objects = [o for o in mat_objects if o.type == 'MESH']
    if not mesh_objects:
        return

    if show_header:
        # Fold key scoped to this material.
        # "objlist:" prefix isolates from existing camera-name keys and
        # shared-group keys ("shared_{node_group.name}"). Collision is
        # impossible since camera names never start with "objlist:".
        obj_list_key = f"objlist:{mat_name}"
        obj_list_fold = _get_fold_state(context.scene, obj_list_key, False)

        # Fold toggle row
        toggle_row = parent_box.row()
        toggle = toggle_row.operator(
            "compify.toggle_uv_group_fold",
            text="",
            emboss=False,
            icon="TRIA_DOWN" if obj_list_fold else "TRIA_RIGHT",
        )
        toggle.camera_name = obj_list_key
        # ^ Note: camera_name is reused here as a general-purpose fold key.
        # CompifyToggleUVGroupFold stores it blindly into scene JSON state;
        # the property name reflects its original purpose, not the current use.
        toggle.new_state = not obj_list_fold
        toggle_row.label(
            text=f"Objects ({len(mesh_objects)})",
            icon="MESH_DATA")

        if not obj_list_fold:
            return

    # Status summary
    no_uv_count = sum(
        1 for o in mesh_objects
        if not o.data.uv_layers.active)
    hidden_count = sum(1 for o in mesh_objects if o.hide_render)
    if hidden_count or no_uv_count:
        warn_row = parent_box.row()
        parts = []
        if hidden_count:
            parts.append(f"{hidden_count} hidden from render")
        if no_uv_count:
            parts.append(f"{no_uv_count} missing UV")
        warn_row.label(
            text="  " + "\u26a0 " + ", ".join(parts),
            icon="INFO")

    # Object entries
    for obj in mesh_objects:
        is_selected = selected_set is not None and obj in selected_set
        obj_row = parent_box.row()
        obj_row.alert = is_selected  # Red text when selected

        # Status icon (priority: selected > hidden > no-UV > OK)
        has_uv = bool(obj.data.uv_layers.active)
        is_renderable = not obj.hide_render
        if is_selected:
            obj_row.label(text="", icon="RESTRICT_SELECT_ON")
        elif not is_renderable:
            obj_row.label(text="", icon="HIDE_ON")
        elif not has_uv:
            obj_row.label(text="", icon="ERROR")
        else:
            obj_row.label(text="", icon="CHECKMARK")

        # Object name
        obj_row.label(text=f"  {obj.name}")

        # Select this object (by object name, not data name)
        select_op = obj_row.operator(
            "compify.select_object_by_name",
            text="",
            icon="RESTRICT_SELECT_OFF",
        )
        select_op.object_name = obj.name

        # Single-object bake button
        bake_op = obj_row.operator(
            "compify.bake_material_projection",
            text="",
            icon="TEXTURE",
        )
        bake_op.material_name = mat_name
        bake_op.object_name = obj.name

        # Extra info tip for hidden objects
        if obj.hide_render:
            obj_row.label(text="", icon="INFO")

    # Debug: log selected objects in this sub-list (only on change)
    if selected_set:
        current_sel = frozenset(o.name for o in selected_set)
        last_sel = getattr(
            CompifyUVAdjust3DPanel, '_last_obj_sel', frozenset())
        if current_sel != last_sel:
            sel_names = [o.name for o in mesh_objects if o in selected_set]
            if sel_names:
                print(f"[Compify|UI] '{mat_name}' objects selected: {sel_names}")
            CompifyUVAdjust3DPanel._last_obj_sel = current_sel


# ========================================================


class CompifyPanel(bpy.types.Panel):
    """Composite in 3D space."""

    bl_label = "Compify"
    bl_idname = "DATA_PT_compify"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "scene"

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout

        # --------
        col = layout.column()
        col.label(text=_("    Footage:"))
        box = col.box()
        box.template_ID(context.scene.compify_config, "footage", open="image.open")
        box.use_property_split = True
        if context.scene.compify_config.footage is not None:
            box.prop(context.scene.compify_config.footage, "source")
            box.prop(
                context.scene.compify_config.footage.colorspace_settings,
                "name",
                text=_("  Color Space"),
            )
        box.prop(context.scene.compify_config, "camera", text=_("  Camera"))

        layout.separator(factor=0.5)

        # --------
        col = layout.column()
        col.label(text=_("    Collections:"))
        box = col.box()
        box.use_property_split = True

        row1 = box.row()
        row1.prop(
            context.scene.compify_config, "geo_collection", text=_("  Footage Geo")
        )
        row1.operator("scene.compify_add_footage_geo_collection", text="", icon="ADD")

        row2 = box.row()
        row2.prop(
            context.scene.compify_config,
            "lights_collection",
            text=_("  Footage Lights"),
        )
        row2.operator(
            "scene.compify_add_footage_lights_collection", text="", icon="ADD"
        )

        layout.separator(factor=1.0)

        layout.use_property_split = True
        layout.prop(context.scene.compify_config, "bake_uv_margin")
        layout.prop(context.scene.compify_config, "bake_image_res")

        layout.separator(factor=1.0)

        # --------
        layout.operator("material.compify_prep_scene")
        layout.operator("material.compify_bake")
        layout.operator("render.compify_render")


class CompifyCameraPanel(bpy.types.Panel):
    """Composite in 3D space."""

    bl_label = "Compify"
    bl_idname = "DATA_PT_compify_camera"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"

    @classmethod
    def poll(cls, context):
        return context.active_object.type == "CAMERA"

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout

        col = layout.column()
        col.operator("material.compify_camera_project_new")


class CompifyUVAdjust3DPanel(bpy.types.Panel):
    """Camera projection UV adjustment for objects in 3D compositing - 3D Viewport Sidebar."""

    bl_label = "Camera Project UV Adjust"
    bl_idname = "VIEW3D_PT_compify_uv_adjust"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Camera Project UV Adjust"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Refresh/Clean button at the top
        layout.operator(
            "compify.refresh_uv_adjust_list",
            text=_("Refresh & Clean"),
            icon="FILE_REFRESH",
        )

        layout.separator()

        # Batch Generate section
        box = layout.box()
        box.label(text=_("Batch Generate:"), icon="NODETREE")

        # Camera selection
        row = box.row()
        row.prop(scene, "compify_uv_adjust_camera", text=_("Camera"))

        # Generate button
        row = box.row()
        row.operator(
            "compify.batch_generate_uv_adjust", text=_("Generate for Selected Objects")
        )

        # Only enable if camera is selected and is actually a camera
        camera = scene.compify_uv_adjust_camera
        if not camera or camera.type != "CAMERA":
            row.enabled = False

        # Show selected mesh count
        selected_meshes = [
            obj for obj in context.selected_objects if obj.type == "MESH"
        ]
        if selected_meshes:
            box.label(
                text=_("Selected Mesh Objects: {}").format(len(selected_meshes)),
                icon="MESH_DATA",
            )
        else:
            box.label(text=_("No mesh objects selected"), icon="INFO")

        layout.separator()

        # Projection Material Management section
        box = layout.box()
        box.label(text=_("Projection Material Management:"), icon="MATERIAL")

        # Get all UV Adjust node groups
        uv_groups = get_all_uv_adjust_node_groups(scene)

        # Filter: only show node groups that are used by at least one material
        active_groups = [gi for gi in uv_groups if gi["materials"]]
        orphan_groups = get_orphan_uv_adjust_node_groups(scene)

        # ---- 醒目提示条：检测到"旧场景共享投影"被带进当前场景（P2 一键同步）----
        # 完整复制场景后，旧场景的投影材质是共享的，会被带进新场景。此时该组
        # belongs_to_other_scene=True（物体/相机在旧场景），面板应提示用户一键同步，
        # 而不是当成失效组静默处理。
        sync_candidates = [
            gi for gi in active_groups if gi.get("belongs_to_other_scene")
        ]
        if sync_candidates:
            sync_box = box.box()
            sync_box.alert = True  # 红色警示样式
            sync_box.label(
                text=_("检测到旧场景的共享投影材质"),
                icon="ERROR",
            )
            sync_box.label(
                text=_("此场景的物体仍共享旧投影材质，投影可能指向旧场景的物体/相机。"),
                icon="INFO",
            )
            sync_box.operator(
                "compify.one_click_sync_uv_adjust",
                text=_("一键为此场景物体创建独立投影"),
                icon="RESTRICT_SELECT_OFF",
            )

        if not active_groups:
            box.label(text=_("No projection materials found"), icon="INFO")
        else:
            # Group by camera (level 1)
            groups_by_camera = {}
            for gi in active_groups:
                cam_key = (
                    gi["camera_name"] if gi["camera_name"] else _("Unknown Camera")
                )
                groups_by_camera.setdefault(cam_key, []).append(gi)

            # Cache selected objects for highlighting
            selected_set = set(context.selected_objects)

            # Build material->objects lookup for selection detection.
            # Unlike gi["object"] (first-match only), this covers all
            # objects sharing each material.  Filter to current scene
            # so the lookup (and downstream mesh counts) stay accurate.
            scene_object_set = set(context.scene.objects)
            mat_to_objects = {}
            for gi in active_groups:
                for mat_name in gi["materials"]:
                    if mat_name not in mat_to_objects:
                        all_objs = find_objects_using_material(mat_name)
                        mat_to_objects[mat_name] = [
                            o for o in all_objs if o in scene_object_set
                        ]

            def _mat_has_selected(mat_name):
                """True if any object using this material is selected."""
                objs = mat_to_objects.get(mat_name, [])
                return any(o in selected_set for o in objs)

            # Debug: log selection changes (only when set differs from last draw).
            # _last_sel defaults to empty frozenset (not None) so module reload
            # doesn't trigger a spurious first-run traversal.
            current_sel_names = frozenset(o.name for o in selected_set)
            last_sel = getattr(
                CompifyUVAdjust3DPanel, '_last_sel', frozenset())
            if current_sel_names != last_sel:
                highlighted = [
                    m for m, objs in mat_to_objects.items()
                    if any(o in selected_set for o in objs)]
                if highlighted:
                    print(f"[Compify|UI] selected → highlighted materials: "
                          f"{highlighted}")
                CompifyUVAdjust3DPanel._last_sel = current_sel_names

            # Draw grouped, collapsible lists per camera
            for cam_name, items in groups_by_camera.items():
                group_box = box.box()
                header = group_box.row()

                # Read foldout state from scene property; default expanded
                fold_state = _get_fold_state(context.scene, cam_name, True)

                # Fold toggle control via operator
                toggle = header.operator(
                    "compify.toggle_uv_group_fold",
                    text="",
                    emboss=False,
                    icon="TRIA_DOWN" if fold_state else "TRIA_RIGHT",
                )
                toggle.camera_name = cam_name
                toggle.new_state = not fold_state

                # Integrate camera selection into the group header
                cam_op = header.operator(
                    "compify.select_uv_adjust_camera", text=cam_name
                )
                cam_op.camera_name = cam_name
                cam_op.enabled = any(gi["camera"] is not None for gi in items)

                # Display count of materials in this camera group
                total_materials = sum(len(gi["materials"]) for gi in items)
                header.label(text=f"({total_materials})")

                # Expanded list of material entries for this camera
                if fold_state:
                    for gi in items:
                        materials = gi["materials"]
                        node_group = gi["node_group"]
                        is_valid = gi["is_valid"]

                        if len(materials) == 1:
                            # Single material: collapsible, click name to
                            # expand object sub-list.
                            mat_name = materials[0]
                            highlight = _mat_has_selected(mat_name)
                            mat_fold_key = f"matfold:{mat_name}"
                            mat_fold_state = _get_fold_state(
                                context.scene, mat_fold_key, False)

                            # Count mesh objects for display (reuse lookup)
                            all_objs = mat_to_objects.get(mat_name, [])
                            mesh_objects = [
                                o for o in all_objs if o.type == 'MESH']
                            mesh_count = len(mesh_objects)

                            item = group_box.box() if highlight else group_box.row()
                            header_row = item.row()
                            header_row.alert = highlight  # Red text when selected

                            # Material fold toggle — the triangle on the
                            # material name controls object sub-list visibility.
                            mat_toggle = header_row.operator(
                                "compify.toggle_uv_group_fold",
                                text="",
                                emboss=False,
                                icon="TRIA_DOWN" if mat_fold_state else "TRIA_RIGHT",
                            )
                            mat_toggle.camera_name = mat_fold_key
                            mat_toggle.new_state = not mat_fold_state

                            # Material label with status icon and object count
                            if is_valid:
                                header_row.label(
                                    text=f"{mat_name}  ({mesh_count})",
                                    icon="MATERIAL")
                            else:
                                # 显示具体失效原因（P1 诊断提示）
                                _reason = gi.get("status", {}).get("reason", "投影失效")
                                header_row.label(
                                    text=f"{mat_name}  ({mesh_count})  ⚠ {_reason}",
                                    icon="ERROR")

                            # Action buttons on the header row
                            select_op = header_row.operator(
                                "compify.select_material_objects",
                                text="",
                                icon="RESTRICT_SELECT_OFF",
                            )
                            select_op.material_name = mat_name

                            bake_op = header_row.operator(
                                "compify.bake_material_projection",
                                text="",
                                icon="TEXTURE",
                            )
                            bake_op.material_name = mat_name

                            update_op = header_row.operator(
                                "compify.update_uv_adjust",
                                text="",
                                icon="FILE_REFRESH",
                            )
                            update_op.node_group_name = node_group.name
                            update_op.enabled = is_valid

                            delete_op = header_row.operator(
                                "compify.delete_uv_adjust",
                                text="",
                                icon="X",
                            )
                            delete_op.node_group_name = node_group.name

                            # Object sub-list: only visible when material
                            # is expanded (fold state = True).
                            if mat_fold_state:
                                _draw_material_object_sublist(
                                    context, group_box, mat_name,
                                    show_header=False,
                                    mesh_objects=mesh_objects,
                                    selected_set=selected_set)
                        else:
                            # Multiple materials sharing same node group: show as collapsible group
                            shared_key = f"shared_{node_group.name}"
                            shared_fold_state = _get_fold_state(
                                context.scene, shared_key, False
                            )

                            shared_box = group_box.box()
                            shared_header = shared_box.row()

                            # Fold toggle for shared group
                            shared_toggle = shared_header.operator(
                                "compify.toggle_uv_group_fold",
                                text="",
                                emboss=False,
                                icon="TRIA_DOWN" if shared_fold_state else "TRIA_RIGHT",
                            )
                            shared_toggle.camera_name = shared_key
                            shared_toggle.new_state = not shared_fold_state

                            # Shared group label
                            shared_label = _("Shared Group") + f" ({len(materials)})"
                            if is_valid:
                                shared_header.label(text=shared_label, icon="LINKED")
                            else:
                                # 显示具体失效原因（P1 诊断提示）
                                _reason = gi.get("status", {}).get("reason", "投影失效")
                                shared_header.label(
                                    text=f"{shared_label}  ⚠ {_reason}", icon="ERROR")

                            # Update button for shared group
                            update_op = shared_header.operator(
                                "compify.update_uv_adjust", text="", icon="FILE_REFRESH"
                            )
                            update_op.node_group_name = node_group.name
                            update_op.enabled = is_valid

                            # Delete button for shared group
                            delete_op = shared_header.operator(
                                "compify.delete_uv_adjust", text="", icon="X"
                            )
                            delete_op.node_group_name = node_group.name

                            # Expanded list of materials in shared group.
                            # Each sub-material is a collapsible entry.
                            if shared_fold_state:
                                for mat_name in materials:
                                    sub_fold_key = f"matfold:{mat_name}"
                                    sub_fold_state = _get_fold_state(
                                        context.scene, sub_fold_key, False)

                                    # Count mesh objects (reuse lookup)
                                    sub_all = mat_to_objects.get(mat_name, [])
                                    sub_mesh_objects = [
                                        o for o in sub_all
                                        if o.type == 'MESH']
                                    sub_mesh_count = len(sub_mesh_objects)

                                    sub_highlight = _mat_has_selected(mat_name)
                                    sub_item = (shared_box.box() if sub_highlight
                                                else shared_box.row())
                                    sub_header = sub_item.row()
                                    sub_header.alert = sub_highlight

                                    # Sub-material fold toggle
                                    sub_toggle = sub_header.operator(
                                        "compify.toggle_uv_group_fold",
                                        text="",
                                        emboss=False,
                                        icon="TRIA_DOWN" if sub_fold_state else "TRIA_RIGHT",
                                    )
                                    sub_toggle.camera_name = sub_fold_key
                                    sub_toggle.new_state = not sub_fold_state

                                    sub_header.label(
                                        text=f"  {mat_name}  ({sub_mesh_count})",
                                        icon="MATERIAL")

                                    mat_select_op = sub_header.operator(
                                        "compify.select_material_objects",
                                        text="",
                                        icon="RESTRICT_SELECT_OFF",
                                    )
                                    mat_select_op.material_name = mat_name

                                    mat_bake_op = sub_header.operator(
                                        "compify.bake_material_projection",
                                        text="",
                                        icon="TEXTURE",
                                    )
                                    mat_bake_op.material_name = mat_name

                                    if sub_fold_state:
                                        _draw_material_object_sublist(
                                            context, shared_box, mat_name,
                                            show_header=False,
                                            mesh_objects=sub_mesh_objects,
                                            selected_set=selected_set)

        # Show orphan node groups warning at bottom
        if orphan_groups:
            box.separator()
            warning_row = box.row()
            warning_row.label(
                text=_("Found {} unused node groups").format(len(orphan_groups)),
                icon="INFO",
            )
            warning_row.operator(
                "compify.clean_orphan_uv_adjust", text=_("Clean"), icon="TRASH"
            )


# ========================================================


def get_compify_material(context):
    """
    Fetches the current scene's compify material if it exists.

    Args:
        context: Blender context object

    Returns:
        bpy.types.Material: The Compify material if it exists, None otherwise
    """
    name = compify_mat_name(context)
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    else:
        return None


def ensure_compify_material(context):
    """
    Ensures that the Compify Footage material exists for this scene.

    Creates the material if it doesn't exist, or returns the existing one.

    Args:
        context: Blender context object

    Returns:
        bpy.types.Material: The Compify material (existing or newly created)

    Note:
        Requires footage and camera to be configured in compify_config
    """
    mat = get_compify_material(context)
    if mat is not None:
        return mat
    else:
        return create_compify_material(
            compify_mat_name(context),
            context.scene.compify_config.camera,
            context.scene.compify_config.footage,
        )


def create_compify_material(name, camera, footage):
    """
    Creates a new Compify Footage material with the full node setup.

    This function creates a complete node-based material for compositing
    footage in 3D space, including camera projection, feathered square,
    and baked lighting nodes.

    Args:
        name: Name for the new material
        camera: Camera object for projection
        footage: Image/movie footage to project

    Returns:
        bpy.types.Material: The newly created Compify material

    Raises:
        ValueError: If footage dimensions are invalid
    """
    # Create a new completely empty node-based material.
    # Create a new completely empty node-based material.
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.blend_method = "HASHED"
    mat.shadow_method = "HASHED"
    for node in mat.node_tree.nodes:
        mat.node_tree.nodes.remove(node)

    # Create the nodes.
    output = mat.node_tree.nodes.new(type="ShaderNodeOutputMaterial")
    camera_project = mat.node_tree.nodes.new(type="ShaderNodeGroup")
    baking_uv_map = mat.node_tree.nodes.new(type="ShaderNodeUVMap")
    input_footage = mat.node_tree.nodes.new(type="ShaderNodeTexImage")
    feathered_square = mat.node_tree.nodes.new(type="ShaderNodeGroup")
    baked_lighting = mat.node_tree.nodes.new(type="ShaderNodeTexImage")
    compify_footage = mat.node_tree.nodes.new(type="ShaderNodeGroup")

    # Label and name the nodes.
    camera_project.label = "Camera Project"
    baking_uv_map.label = "Baking UV Map"
    input_footage.label = "Input Footage"
    feathered_square.label = "Feathered Square"
    baked_lighting.label = BAKE_IMAGE_NODE_NAME
    compify_footage.label = MAIN_NODE_NAME

    camera_project.name = "Camera Project"
    baking_uv_map.label = "Baking UV Map"
    input_footage.name = "Input Footage"
    feathered_square.name = "Feathered Square"
    baked_lighting.name = BAKE_IMAGE_NODE_NAME
    compify_footage.name = MAIN_NODE_NAME

    # Position the nodes.
    hs = 400.0
    x = 0.0

    camera_project.location = (x, 0.0)
    baking_uv_map.location = (x, -200.0)
    x += hs
    input_footage.location = (x, 400.0)
    feathered_square.location = (x, 0.0)
    baked_lighting.location = (x, -200.0)
    x += hs
    compify_footage.location = (x, 0.0)
    compify_footage.width = 200.0
    x += hs
    output.location = (x, 0.0)

    # Configure the nodes.
    camera_project.node_tree = ensure_camera_project_group(camera)
    if footage.size[0] > 0 and footage.size[1] > 0:
        camera_project.inputs["Aspect Ratio"].default_value = (
            footage.size[0] / footage.size[1]
        )
    else:
        # Default to the output render aspect ratio if we're on a bogus footage frame.
        render_x = (
            bpy.context.scene.render.resolution_x
            * bpy.context.scene.render.pixel_aspect_x
        )
        render_y = (
            bpy.context.scene.render.resolution_y
            * bpy.context.scene.render.pixel_aspect_y
        )
        if render_y > 0:
            camera_project.inputs["Aspect Ratio"].default_value = render_x / render_y
        else:
            camera_project.inputs[
                "Aspect Ratio"
            ].default_value = 1.0  # Fallback to 1:1 aspect ratio

    baking_uv_map.uv_map = UV_LAYER_NAME

    input_footage.image = footage
    input_footage.interpolation = "Closest"
    input_footage.projection = "FLAT"
    input_footage.extension = "EXTEND"
    input_footage.image_user.frame_duration = footage.frame_duration
    input_footage.image_user.use_auto_refresh = True

    feathered_square.node_tree = ensure_feathered_square_group()
    feathered_square.inputs["Feather"].default_value = 0.05
    feathered_square.inputs["Dilate"].default_value = 0.0

    compify_footage.node_tree = ensure_footage_group()

    # Hook up the nodes.
    mat.node_tree.links.new(
        camera_project.outputs["Vector"], input_footage.inputs["Vector"]
    )
    mat.node_tree.links.new(
        camera_project.outputs["Vector"], feathered_square.inputs["Vector"]
    )
    mat.node_tree.links.new(
        baking_uv_map.outputs["UV"], baked_lighting.inputs["Vector"]
    )
    mat.node_tree.links.new(
        input_footage.outputs["Color"], compify_footage.inputs["Footage"]
    )
    mat.node_tree.links.new(
        feathered_square.outputs["Value"], compify_footage.inputs["Footage Alpha"]
    )
    mat.node_tree.links.new(
        baked_lighting.outputs["Color"], compify_footage.inputs["Baked Lighting"]
    )
    mat.node_tree.links.new(compify_footage.outputs["Shader"], output.inputs["Surface"])

    return mat


def change_footage_material_clip(config, context):
    if config.footage is None:
        return
    mat = get_compify_material(context)
    if mat is not None:
        footage_node = mat.node_tree.nodes["Input Footage"]
        footage_node.image = config.footage
        footage_node.image_user.frame_duration = config.footage.frame_duration


def change_footage_camera(config, context):
    if config.camera is None or config.camera.type != "CAMERA":
        return
    mat = get_compify_material(context)
    if mat is not None:
        group = ensure_camera_project_group(config.camera)
        mat.node_tree.nodes["Camera Project"].node_tree = group


class CompifyPrepScene(bpy.types.Operator):
    """Prepare the scene for compositing."""

    bl_label = "Prep Scene"
    bl_idname = "material.compify_prep_scene"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return can_prep_scene(context)

    def execute(self, context):
        proxy_collection = context.scene.compify_config.geo_collection
        lights_collection = context.scene.compify_config.lights_collection
        material = ensure_compify_material(context)

        # Deselect all objects.
        for obj in context.scene.objects:
            obj.select_set(False)

        # Set up proxy objects.
        for obj in proxy_collection.all_objects:
            if obj.type == "MESH":
                # Select it.
                obj.select_set(True)
                context.view_layer.objects.active = obj

                # Ensure it has a compify UV layer and that
                # it's selected.
                if UV_LAYER_NAME not in obj.data.uv_layers:
                    obj.data.uv_layers.new(name=UV_LAYER_NAME)
                obj.data.uv_layers.active = obj.data.uv_layers[UV_LAYER_NAME]

                # Set it up with the footage material.
                obj.data.materials.clear()
                obj.data.materials.append(material)

        # UV unwrap the proxy objects.
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.uv.smart_project(
            angle_limit=(math.pi / 180) * 60,  # 60 degrees
            island_margin=0.001,
            area_weight=0.0,
            correct_aspect=False,
            scale_to_bounds=False,
        )
        bpy.ops.object.mode_set(mode="OBJECT")

        # We have to do the UV island margins twice, because Blender's
        # `island_margin` is stupid beyond belief and corresponds to
        # nothing absolute that we can depend on.  So what we're doing
        # here is saying, "Hey, what was the actual margin achieved
        # with `island_margin=0.001`?  Okay, now let's redo it based on
        # that result."  It's still not 100% precise even with this,
        # but with a bit of buffer it's close enough.
        actual_margin = leftmost_u(context.selected_objects, UV_LAYER_NAME)
        actual_margin_pixels = (
            actual_margin * context.scene.compify_config.bake_image_res
        )
        target_margin_with_buffer = context.scene.compify_config.bake_uv_margin * (
            5.0 / 4.0
        )
        correction_factor = target_margin_with_buffer / actual_margin_pixels
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.uv.select_all(action="SELECT")
        bpy.ops.uv.pack_islands(rotate=False, margin=0.001 * correction_factor)
        bpy.ops.object.mode_set(mode="OBJECT")

        return {"FINISHED"}


class CompifyBake(bpy.types.Operator):
    """Does the Compify lighting baking for proxy geometry"""

    bl_label = "Bake Footage Lighting"
    bl_idname = "material.compify_bake"
    bl_options = {"UNDO"}

    _timer = None
    baker = None

    # Note: we use a modal technique inspired by this to keep the baking
    # from blocking the UI:
    # https://blender.stackexchange.com/questions/71454/is-it-possible-to-make-a-sequence-of-renders-and-give-the-user-the-option-to-can

    @classmethod
    def poll(cls, context):
        return can_render_with_compify(context)

    def post(self, scene, context=None):
        self.baker.post(scene, context)

    def cancelled(self, scene, context=None):
        self.baker.cancelled(scene, context)

    def execute(self, context):
        self.baker = Baker()
        self._timer = context.window_manager.event_timer_add(
            0.05, window=context.window
        )
        context.window_manager.modal_handler_add(self)
        return self.baker.execute(context)

    def modal(self, context, event):
        result = self.baker.modal(context, event)
        if result == {"FINISHED"} or result == {"CANCELLED"}:
            context.window_manager.event_timer_remove(self._timer)
        return result


class CompifyRender(bpy.types.Operator):
    """Render, but with Compify baking before rendering each frame"""

    bl_label = "Render Animation with Compify Integration"
    bl_idname = "render.compify_render"

    _timer = None
    render_started = False
    render_done = False
    frame_range = None
    stage = ""
    baker = None

    is_finished = False
    is_cancelled = False

    @classmethod
    def poll(cls, context):
        return can_render_with_compify(context)

    def render_post_callback(self, scene, context=None):
        self.render_done = True

    def cancelled_callback(self, scene, context=None):
        self.is_cancelled = True

    def execute(self, context):
        self.render_started = False
        self.render_done = False
        self.frame_range = (context.scene.frame_start, context.scene.frame_end)
        self.stage = "bake"
        self.baker = Baker()

        self.is_finished = False
        self.is_cancelled = False

        bpy.app.handlers.render_post.append(self.render_post_callback)
        bpy.app.handlers.render_cancel.append(self.cancelled_callback)
        bpy.app.handlers.object_bake_cancel.append(self.cancelled_callback)

        self._timer = context.window_manager.event_timer_add(
            0.05, window=context.window
        )
        context.window_manager.modal_handler_add(self)

        context.scene.frame_set(self.frame_range[0])

        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if self.is_cancelled or self.is_finished:
            bpy.app.handlers.render_post.remove(self.render_post_callback)
            bpy.app.handlers.render_cancel.remove(self.cancelled_callback)
            bpy.app.handlers.object_bake_cancel.remove(self.cancelled_callback)

        if self.is_cancelled:
            return {"CANCELLED"}

        if self.is_finished:
            return {"FINISHED"}

        if event.type == "TIMER":
            # Bake stage.
            if self.stage == "bake":
                if not self.baker.is_baking and not self.baker.is_done:
                    self.baker.execute(context)
                result = self.baker.modal(context, event)
                if result == {"FINISHED"}:
                    self.baker.reset()
                    self.stage = "render"
                else:
                    if result == {"CANCELLED"}:
                        self.is_cancelled = True
                    return result
            # Render stage.
            elif self.stage == "render":
                if not self.render_started:
                    self.render_started = True
                    bpy.ops.render.render("INVOKE_DEFAULT", animation=False)
                elif self.render_done:
                    image_path_start = bpy.path.abspath(context.scene.render.filepath)
                    image_ext = context.scene.render.file_extension
                    image_path = "{}{:04}{}".format(
                        image_path_start, context.scene.frame_current, image_ext
                    )
                    print('Saving image "{}"'.format(image_path))
                    bpy.data.images["Render Result"].save_render(filepath=image_path)

                    if context.scene.frame_current >= self.frame_range[1]:
                        self.is_finished = True
                    else:
                        context.scene.frame_set(context.scene.frame_current + 1)
                        self.render_started = False
                        self.render_done = False
                        self.stage = "bake"

        return {"PASS_THROUGH"}


class CompifyAddFootageGeoCollection(bpy.types.Operator):
    """Add a collection for footage geometry."""

    bl_label = "Add Footage Geo Collection"
    bl_idname = "scene.compify_add_footage_geo_collection"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.scene.compify_config.geo_collection is None

    def execute(self, context):
        collection = bpy.data.collections.new("Footage Geo")
        context.scene.collection.children.link(collection)
        context.scene.compify_config.geo_collection = collection
        return {"FINISHED"}


class CompifyAddFootageLightsCollection(bpy.types.Operator):
    """Add a collection for footage lights."""

    bl_label = "Add Footage Lights Collection"
    bl_idname = "scene.compify_add_footage_lights_collection"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.scene.compify_config.lights_collection is None

    def execute(self, context):
        collection = bpy.data.collections.new("Footage Lights")
        context.scene.collection.children.link(collection)
        context.scene.compify_config.lights_collection = collection
        return {"FINISHED"}


class CompifyCameraProjectGroupNew(bpy.types.Operator):
    """Creates a new camera projection node group from the current selected camera"""

    bl_label = "New Camera Project Node Group"
    bl_idname = "material.compify_camera_project_new"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None and context.active_object.type == "CAMERA"
        )

    def execute(self, context):
        x_res = context.scene.render.resolution_x
        y_res = context.scene.render.resolution_y
        x_asp = context.scene.render.pixel_aspect_x
        y_asp = context.scene.render.pixel_aspect_y

        ensure_camera_project_group(
            context.active_object, (x_res * x_asp) / (y_res * y_asp)
        )
        return {"FINISHED"}


class CompifyBatchGenerateUVAdjust(bpy.types.Operator):
    """Batch generate UV adjust node groups."""

    bl_label = "Batch Generate UV Adjust"
    bl_idname = "compify.batch_generate_uv_adjust"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return (
            context.scene.compify_uv_adjust_camera is not None
            and context.scene.compify_uv_adjust_camera.type == "CAMERA"
            and any(obj.type == "MESH" for obj in context.selected_objects)
        )

    def execute(self, context):
        camera = context.scene.compify_uv_adjust_camera
        scene = context.scene

        # Get all selected mesh objects
        selected_meshes = [
            obj for obj in context.selected_objects if obj.type == "MESH"
        ]

        if not selected_meshes:
            self.report({"WARNING"}, "No mesh objects selected")
            return {"CANCELLED"}

        # Check if camera projection node group exists, create if not
        camera_project_created = False
        if not check_camera_project_group_exists(camera):
            try:
                # Calculate aspect ratio from render settings
                x_res = scene.render.resolution_x
                y_res = scene.render.resolution_y
                x_asp = scene.render.pixel_aspect_x
                y_asp = scene.render.pixel_aspect_y
                aspect_ratio = (x_res * x_asp) / (y_res * y_asp)

                # Automatically create camera projection node group
                ensure_camera_project_group(camera, aspect_ratio)
                camera_project_created = True

                self.report(
                    {"INFO"},
                    f"Automatically created camera projection node group for '{camera.name}'",
                )

            except Exception as e:
                self.report(
                    {"ERROR"},
                    f"Failed to create camera projection node group for '{camera.name}': {str(e)}",
                )
                return {"CANCELLED"}

        success_count = 0
        failed_objects = []

        # Batch process all selected mesh objects
        material_success_count = 0
        for obj in selected_meshes:
            try:
                # Create the UV adjustment node group and add to material
                result = create_and_add_uv_adjust_node_group(scene, camera, obj)

                if result["success"]:
                    success_count += 1
                    if (
                        result["material_result"]
                        and result["material_result"]["success"]
                    ):
                        material_success_count += 1
                else:
                    failed_objects.append(f"{obj.name}: {result['message']}")
                    # Stop on first failure as requested
                    break

            except Exception as e:
                failed_objects.append(f"{obj.name}: {str(e)}")
                # Stop on first failure as requested
                break

        # Report results
        if failed_objects:
            error_msg = f"Failed to process '{failed_objects[0]}'. "
            if success_count > 0:
                error_msg += (
                    f"Successfully processed {success_count} objects before failure."
                )
            if camera_project_created:
                error_msg += f" Camera projection node group was created successfully."

            self.report({"ERROR"}, error_msg)
            return {"CANCELLED"}
        else:
            success_msg = f"Successfully created UV adjustment node groups for {success_count} objects. "
            if material_success_count > 0:
                success_msg += f"Automatically added and connected node groups to materials for {material_success_count} objects. "
            if camera_project_created:
                success_msg += (
                    f"Also created camera projection node group for '{camera.name}'. "
                )

            if material_success_count == success_count:
                success_msg += "All node groups are ready to use in the shader editor."
            elif material_success_count > 0:
                success_msg += f"Remaining {success_count - material_success_count} objects may need manual material setup."
            else:
                success_msg += "You can now manually connect them in the shader editor."

            self.report({"INFO"}, success_msg)
            # Invalidate cache so panel picks up the new node groups
            invalidate_uv_cache(context.scene)
            # Redraw the 3D View panel to reflect new node groups
            redraw_viewport(context)
            return {"FINISHED"}


class CompifyOneClickSyncUVAdjust(bpy.types.Operator):
    """One-click sync UV adjust for all objects in this scene that still use a
    shared (old-scene) projection material, creating independent projections for them."""

    bl_label = "One-Click Sync Projections"
    bl_idname = "compify.one_click_sync_uv_adjust"
    bl_options = {"UNDO"}

    def _find_scene_camera_for_group(self, scene, group_info):
        """Find the camera in the current scene that was copied from the group's
        recorded camera (方案六: 按"复制关系"精准定位，不靠泛前缀).

        匹配规则：相机的 data 名 == 记录的旧 data 名，或以"旧 data 名 + '.'"开头。
        这样能精准命中复制场景产生的 Camera.001 / Camera.002，而排除名字相似
        但不相干的相机（如 Camera_Persp），避免配错。

        Args:
            scene: 当前场景
            group_info: UV Adjust 组的 info dict（含 camera_name = 记录的相机 data 名）

        Returns:
            bpy.types.Object | None: 匹配到的相机对象，找不到返回 None
        """
        try:
            cam_data_name = group_info.get("camera_name") or ""
            if not cam_data_name:
                return None
            # 精准匹配：复制出来的相机 data 名 = 旧名，或 旧名 + '.编号'
            # (FULL_COPY 复制场景时，复制的 datablock 名为 "旧名.001", "旧名.002"...)
            dot_prefix = cam_data_name + "."
            for cam in scene.objects:
                if cam.type != "CAMERA":
                    continue
                if not cam.data:
                    continue
                dn = cam.data.name
                if dn == cam_data_name or dn.startswith(dot_prefix):
                    return cam
            return None
        except Exception as e:
            print(f"Compify: Warning in _find_scene_camera_for_group: {e}")
            return None

    def execute(self, context):
        scene = context.scene
        # Invalidate cache so we get fresh scan results
        invalidate_uv_cache(scene)

        # Scan current scene for groups that belong to an old scene
        groups = get_all_uv_adjust_node_groups(scene)
        candidate_materials = set()
        for gi in groups:
            if gi.get("belongs_to_other_scene"):
                for mat_name in gi.get("materials", []):
                    candidate_materials.add(mat_name)

        if not candidate_materials:
            self.report({"INFO"}, "No old-scene shared projection materials found to sync.")
            return {"FINISHED"}

        # Collect objects in this scene that use those shared materials
        scene_obj_names = {o.name for o in scene.objects}
        sync_objs = []
        for mat_name in candidate_materials:
            for obj in find_objects_using_material(mat_name):
                if obj.name in scene_obj_names and obj.type == "MESH":
                    sync_objs.append(obj)

        if not sync_objs:
            self.report({"INFO"}, "No in-scene objects use the shared projection materials to sync.")
            return {"FINISHED"}

        # For each object, find a camera in this scene (from the first old group)
        # and ensure the camera project node group exists, then create independent projection.
        camera = None
        for gi in groups:
            if gi.get("belongs_to_other_scene"):
                camera = self._find_scene_camera_for_group(scene, gi)
                if camera:
                    break

        if camera is None:
            self.report(
                {"WARNING"},
                "Could not find a camera in this scene to sync projections. "
                "Select/assign a camera in the Compify panel first.",
            )
            return {"CANCELLED"}

        # Ensure the camera project node group exists for this camera
        if not check_camera_project_group_exists(camera):
            ensure_camera_project_group(camera, default_aspect=1.77)

        success_count = 0
        failed = []
        for obj in sync_objs:
            try:
                r = create_and_add_uv_adjust_node_group(scene, camera, obj)
                if r["success"]:
                    success_count += 1
                else:
                    failed.append(f"{obj.name}: {r['message']}")
            except Exception as e:
                failed.append(f"{obj.name}: {str(e)}")

        invalidate_uv_cache(scene)
        redraw_viewport(context)

        if failed:
            self.report(
                {"WARNING"},
                f"Synced {success_count} object(s). Failed: {len(failed)}",
            )
            return {"CANCELLED"}
        else:
            self.report(
                {"INFO"},
                f"One-click sync complete: created independent projections for "
                f"{success_count} object(s) using camera '{camera.name}'.",
            )
            return {"FINISHED"}


class CompifyRefreshUVAdjustList(bpy.types.Operator):
    """Refresh UV Adjust node groups list and clean up invalid references"""

    bl_label = "Refresh & Clean UV Adjust List"
    bl_idname = "compify.refresh_uv_adjust_list"
    bl_options = {"UNDO"}

    _invalid_count = 0

    def invoke(self, context, event):
        """在真正执行前，若存在无效投影组则先弹确认框，防止误删。"""
        scene = context.scene
        _invalid = [
            g["node_group"].name for g in get_all_uv_adjust_node_groups(scene)
            if not g["is_valid"]
        ]
        self._invalid_count = len(_invalid)
        if _invalid:
            # 用 props dialog 弹一个带"你说人话"文案的确认框
            # 用户点"确定" → 走 execute（真正清理）；点"取消"/ESC → 停在 invoke，不删。
            return context.window_manager.invoke_props_dialog(self, width=420)
        return self.execute(context)

    def draw(self, context):
        """确认框的内容：说清楚删了会怎样。"""
        layout = self.layout
        col = layout.column()
        col.label(
            text=f"发现 {self._invalid_count} 个无效投影材质：",
            icon="ERROR",
        )
        col.separator()
        col.label(text="删除后，材质里对应的投影连接也会被断开。")
        col.label(text="常见原因：物体/相机被删除，或因场景复制/重名改名。")
        col.separator()
        col.label(text="建议先检查原因再删除。确定继续吗？")

    def execute(self, context):
        try:
            # Handle object/camera renames first
            rename_result = handle_object_rename_in_node_groups(context.scene)

            # Clean up invalid node groups
            # 已被 invoke 的确认框拦截：用户点"确定"后 execute 才会走到这里。
            # 纯脚本调用时无确认框，直接清理；此处传 False 避免二次弹窗。
            cleaned_count = clean_invalid_uv_adjust_node_groups(
                context.scene, confirm=False)

            # Get current valid groups count
            valid_groups = [
                g for g in get_all_uv_adjust_node_groups(context.scene) if g["is_valid"]
            ]
            valid_count = len(valid_groups)

            # Build comprehensive report message
            messages = []

            if rename_result["updated"] > 0:
                messages.append(f"Updated {rename_result['updated']} node group names")

            if cleaned_count > 0:
                messages.append(f"Cleaned up {cleaned_count} invalid node groups")

            if rename_result["orphaned"] > 0:
                messages.append(
                    f"Found {rename_result['orphaned']} orphaned node groups"
                )

            messages.append(f"{valid_count} valid node groups remaining")

            # Determine report type based on actions taken
            report_type = {"INFO"}

            final_message = ". ".join(messages) + "."
            self.report(report_type, final_message)

            # Log details if there were significant changes
            if rename_result["details"] and (
                rename_result["updated"] > 0 or rename_result["orphaned"] > 0
            ):
                print("UV Adjust Node Groups Refresh Details:")
                for detail in rename_result["details"]:
                    print(f"  - {detail}")

            # Redraw the 3D View panel to reflect refreshed list
            redraw_viewport(context)

            invalidate_uv_cache(context.scene)
            return {"FINISHED"}

        except Exception as e:
            self.report({"ERROR"}, f"Failed to refresh node groups list: {str(e)}")
            return {"CANCELLED"}


class CompifyToggleUVGroupFold(bpy.types.Operator):
    """Toggle the fold state of a camera group in the UI."""

    bl_label = "Toggle UV Group Fold"
    bl_idname = "compify.toggle_uv_group_fold"
    bl_options = {"INTERNAL"}

    camera_name: bpy.props.StringProperty()
    new_state: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        _set_fold_state(context.scene, self.camera_name, self.new_state)
        # Force UI redraw in 3D View
        redraw_viewport(context)
        return {"FINISHED"}


class CompifySelectUVAdjustObject(bpy.types.Operator):
    """Select the object associated with this UV adjust."""

    bl_label = "Select Object"
    bl_idname = "compify.select_uv_adjust_object"
    bl_options = {"UNDO"}

    object_name: bpy.props.StringProperty()
    enabled: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        if not self.enabled:
            self.report({"WARNING"}, f"Object '{self.object_name}' no longer exists")
            return {"CANCELLED"}

        obj = find_object_by_data_name(self.object_name, type_filter="MESH")
        if obj and obj.name in context.scene.objects:
            # Deselect all objects
            bpy.ops.object.select_all(action="DESELECT")
            # Select and activate the target object
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({"INFO"}, f"Selected object: {obj.name}")
            return {"FINISHED"}
        else:
            self.report({"WARNING"}, f"Object '{self.object_name}' not found in scene")
            return {"CANCELLED"}


class CompifySelectMaterialObjects(bpy.types.Operator):
    """Select all objects using this material."""

    bl_label = "Select Material Objects"
    bl_idname = "compify.select_material_objects"
    bl_options = {"UNDO"}

    material_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        material = bpy.data.materials.get(self.material_name)
        if not material:
            self.report({"WARNING"}, f"Material '{self.material_name}' not found")
            return {"CANCELLED"}

        # Find all objects using this material
        objects_with_material = []
        for obj in context.scene.objects:
            if obj.type == "MESH" and obj.data and obj.data.materials:
                for mat_slot in obj.material_slots:
                    if (
                        mat_slot.material
                        and mat_slot.material.name == self.material_name
                    ):
                        objects_with_material.append(obj)
                        break

        if not objects_with_material:
            self.report(
                {"WARNING"}, f"No objects found using material '{self.material_name}'"
            )
            return {"CANCELLED"}

        # Deselect all objects
        bpy.ops.object.select_all(action="DESELECT")

        # Select all objects using this material
        for obj in objects_with_material:
            obj.select_set(True)

        # Set the first one as active
        context.view_layer.objects.active = objects_with_material[0]

        if len(objects_with_material) == 1:
            self.report({"INFO"}, f"Selected object: {objects_with_material[0].name}")
        else:
            self.report(
                {"INFO"},
                f"Selected {len(objects_with_material)} objects using material '{self.material_name}'",
            )

        return {"FINISHED"}


class CompifySelectObjectByName(bpy.types.Operator):
    """Select a single object by its object name.

    Uses bpy.data.objects.get() — matches by object name, not
    data-block name. Unlike CompifySelectUVAdjustObject which
    searches by data name (suitable for copy/paste scenarios).
    """

    bl_label = "Select Object by Name"
    bl_idname = "compify.select_object_by_name"
    bl_options = {"UNDO"}

    object_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            self.report(
                {"WARNING"},
                f"Object '{self.object_name}' not found")
            return {"CANCELLED"}
        if obj.name not in context.scene.objects:
            self.report(
                {"WARNING"},
                f"Object '{self.object_name}' not in current scene")
            return {"CANCELLED"}

        bpy.ops.object.select_all(action="DESELECT")
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({"INFO"}, f"Selected object: {obj.name}")
        return {"FINISHED"}


class CompifySelectUVAdjustCamera(bpy.types.Operator):
    """Select the camera associated with this UV adjust."""

    bl_label = "Select Camera"
    bl_idname = "compify.select_uv_adjust_camera"
    bl_options = {"UNDO"}

    camera_name: bpy.props.StringProperty()
    enabled: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        if not self.enabled:
            self.report({"WARNING"}, f"Camera '{self.camera_name}' no longer exists")
            return {"CANCELLED"}

        camera = find_object_by_data_name(self.camera_name, type_filter="CAMERA")
        if camera and camera.name in context.scene.objects and camera.type == "CAMERA":
            # Deselect all objects
            bpy.ops.object.select_all(action="DESELECT")
            # Select and activate the target camera
            camera.select_set(True)
            context.view_layer.objects.active = camera
            self.report({"INFO"}, f"Selected camera: {camera.name}")
            return {"FINISHED"}
        else:
            self.report({"WARNING"}, f"Camera '{self.camera_name}' not found in scene")
            return {"CANCELLED"}


class CompifyUpdateUVAdjust(bpy.types.Operator):
    """Update parameters of a UV Adjust node group"""

    bl_label = "Update UV Adjust"
    bl_idname = "compify.update_uv_adjust"
    bl_options = {"UNDO"}

    node_group_name: bpy.props.StringProperty()
    enabled: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        if not self.enabled:
            self.report({"WARNING"}, "Cannot update: object or camera no longer exists")
            return {"CANCELLED"}

        # Get the node group
        node_group = bpy.data.node_groups.get(self.node_group_name)
        if not node_group:
            self.report({"ERROR"}, f"Node group '{self.node_group_name}' not found")
            return {"CANCELLED"}

        # Try to resolve object and camera intelligently (handling copy/paste cases)
        obj = None
        camera = None

        # Get usage info to find real connections
        usage_info = get_node_group_usage_info(node_group)
        materials = [info["material"] for info in usage_info]

        # Resolve Object
        for mat_name in materials:
            objs = find_objects_using_material(mat_name)
            if objs:
                obj = objs[0]
                break

        # Resolve Camera
        for mat_name in materials:
            mat = bpy.data.materials.get(mat_name)
            if mat:
                cam_obj = find_camera_connected_to_uv_adjust_in_material(
                    mat, node_group
                )
                if cam_obj:
                    camera = cam_obj
                    break

        # Fallback: Prefer metadata properties if resolution failed
        if not obj:
            object_data_name = node_group.get("compify_uv_object_data_name")
            if object_data_name:
                obj = find_object_by_data_name(object_data_name, type_filter="MESH")

        if not camera:
            camera_data_name = node_group.get("compify_uv_camera_data_name")
            if camera_data_name:
                camera = find_object_by_data_name(
                    camera_data_name, type_filter="CAMERA"
                )

        # Fallback: Parse node group name if metadata missing and resolution failed
        if (not obj or not camera) and " | " in node_group.name:
            parts = node_group.name.split(" | ")
            if len(parts) == 3:
                if not obj:
                    obj = find_object_by_data_name(parts[1], type_filter="MESH")
                if not camera:
                    camera = find_object_by_data_name(parts[2], type_filter="CAMERA")

        if not obj or obj.name not in context.scene.objects:
            self.report(
                {"ERROR"},
                f"Object for node group '{node_group.name}' not found in scene",
            )
            return {"CANCELLED"}

        if (
            not camera
            or camera.name not in context.scene.objects
            or camera.type != "CAMERA"
        ):
            self.report(
                {"ERROR"},
                f"Camera for node group '{node_group.name}' not found in scene",
            )
            return {"CANCELLED"}

        # Update metadata if resolved differently (fixes stale metadata)
        try:
            current_obj_data_name = (
                obj.data.name if getattr(obj, "data", None) else obj.name
            )
            if node_group.get("compify_uv_object_data_name") != current_obj_data_name:
                node_group["compify_uv_object_data_name"] = current_obj_data_name

            current_cam_data_name = (
                camera.data.name if getattr(camera, "data", None) else camera.name
            )
            if node_group.get("compify_uv_camera_data_name") != current_cam_data_name:
                node_group["compify_uv_camera_data_name"] = current_cam_data_name
        except Exception as e:
            print(
                f"Compify: Warning - failed to update metadata during UV adjust update: {e}"
            )

        # Update the node group parameters
        try:
            success = update_uv_adjust_node_group_parameters(
                node_group, obj, camera, context.scene
            )
            if success:
                self.report(
                    {"INFO"}, f"Updated parameters for node group: {node_group.name}"
                )
                invalidate_uv_cache(context.scene)
                return {"FINISHED"}
            else:
                self.report({"ERROR"}, f"Failed to update node group parameters")
                return {"CANCELLED"}

        except Exception as e:
            self.report({"ERROR"}, f"Error updating node group: {str(e)}")
            return {"CANCELLED"}


class CompifyDeleteUVAdjust(bpy.types.Operator):
    """Delete UV adjust."""

    bl_label = "Delete UV Adjust"
    bl_idname = "compify.delete_uv_adjust"
    bl_options = {"UNDO"}

    node_group_name: bpy.props.StringProperty()

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Get the node group
        node_group = bpy.data.node_groups.get(self.node_group_name)
        if not node_group:
            self.report({"WARNING"}, f"Node group '{self.node_group_name}' not found")
            return {"CANCELLED"}

        # Delete the node group
        try:
            success = delete_uv_adjust_node_group(node_group)
            if success:
                self.report({"INFO"}, f"Deleted node group: {self.node_group_name}")
                invalidate_uv_cache(context.scene)
                return {"FINISHED"}
            else:
                self.report({"ERROR"}, f"Failed to delete node group")
                return {"CANCELLED"}

        except Exception as e:
            self.report({"ERROR"}, f"Error deleting node group: {str(e)}")
            return {"CANCELLED"}


class CompifyCleanOrphanUVAdjust(bpy.types.Operator):
    """Clean unused node groups."""

    bl_label = "Clean Unused Node Groups"
    bl_idname = "compify.clean_orphan_uv_adjust"
    bl_options = {"UNDO"}

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        try:
            cleaned_count = clean_orphan_uv_adjust_node_groups(context.scene)
            if cleaned_count > 0:
                self.report({"INFO"}, f"Cleaned {cleaned_count} unused node groups")
            else:
                self.report({"INFO"}, "No unused node groups to clean")
            invalidate_uv_cache(context.scene)
            return {"FINISHED"}

        except Exception as e:
            self.report({"ERROR"}, f"Error cleaning node groups: {str(e)}")
            return {"CANCELLED"}




class CompifyToggleUnwrapObject(bpy.types.Operator):
    """Toggle UV unwrap for a specific object in the bake dialog."""

    bl_label = "Toggle Object Unwrap"
    bl_idname = "compify.toggle_unwrap_object"
    bl_options = {"INTERNAL"}

    object_name: bpy.props.StringProperty()

    def execute(self, context):
        try:
            overrides = json.loads(
                context.scene.compify_bake_unwrap_overrides)
        except (json.JSONDecodeError, TypeError):
            overrides = {}

        obj_state = overrides.get(self.object_name)
        if obj_state and not obj_state.get("forced"):
            obj_state["skip"] = not obj_state.get("skip", False)
            overrides[self.object_name] = obj_state

        context.scene.compify_bake_unwrap_overrides = json.dumps(overrides)

        redraw_viewport(context)
        return {"FINISHED"}


class CompifyBakeMaterialProjection(bpy.types.Operator):
    """Bake camera projection to textures for new objects."""

    bl_label = "Bake Material Projection"
    bl_idname = "compify.bake_material_projection"
    bl_description = (
        "Bake camera projection, creating new objects with baked textures")
    bl_options = {"UNDO"}

    material_name: bpy.props.StringProperty(options={"HIDDEN"})
    object_name: bpy.props.StringProperty(
        name="Object Name",
        default="",
        options={"HIDDEN", "SKIP_SAVE"},
        description="If set, only bake this specific object instead of all",
    )
    bake_resolution: bpy.props.IntProperty(
        name="Resolution",
        default=2048,
        min=64,
        max=8192,
        subtype="PIXEL",
        description="Bake texture resolution in pixels",
    )

    auto_unwrap: bpy.props.BoolProperty(
        name="Auto-unwrap UV",
        default=True,
        description=(
            "Automatically unwrap UV for objects with existing UV layers"),
    )
    smart_angle_limit: bpy.props.IntProperty(
        name="Angle Limit",
        default=66,
        min=0,
        max=89,
        subtype="ANGLE",
        description="Angle limit for Smart UV Project",
    )
    smart_island_margin: bpy.props.FloatProperty(
        name="Island Margin",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        description="Island margin for Smart UV Project",
    )
    smart_area_weight: bpy.props.FloatProperty(
        name="Area Weight",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        description="Weight UV faces by area, higher values favor larger faces",
    )
    smart_correct_aspect: bpy.props.BoolProperty(
        name="Correct Aspect",
        default=False,
        description="Correct aspect ratio to avoid UV stretching",
    )
    smart_scale_to_bounds: bpy.props.BoolProperty(
        name="Scale to Bounds",
        default=True,
        description="Scale UV islands to fit within 0-1 bounds",
    )

    def invoke(self, context, event):
        # Validate material
        material = bpy.data.materials.get(self.material_name)
        if not material:
            self.report({"ERROR"}, "Material not found")
            return {"CANCELLED"}

        # Validate Camera Project node exists
        camera_found = False
        if material.node_tree:
            for node in material.node_tree.nodes:
                if (node.type == "GROUP" and node.node_tree
                        and node.node_tree.name.startswith(
                            "Camera Project |")):
                    camera_found = True
                    break

        if not camera_found:
            self.report(
                {"ERROR"},
                "Material has no Camera Project node group. "
                "Run 'Generate for Selected Objects' first.")
            return {"CANCELLED"}

        # Validate objects exist
        self.affected_objects = find_objects_using_material(
            self.material_name)
        if not self.affected_objects:
            self.report(
                {"ERROR"},
                "No objects in the scene use this material")
            return {"CANCELLED"}

        # Single-object filter
        if self.object_name:
            self.affected_objects = [
                o for o in self.affected_objects
                if o.name == self.object_name
            ]
            if not self.affected_objects:
                self.report(
                    {"ERROR"},
                    f"Object '{self.object_name}' not found "
                    f"in material's users")
                return {"CANCELLED"}

        # Detect UV status
        self.has_uv_count = 0
        self.no_uv_count = 0
        self.mesh_count = 0
        for obj in self.affected_objects:
            if obj.type == 'MESH':
                self.mesh_count += 1
                if obj.data.uv_layers.active:
                    self.has_uv_count += 1
                else:
                    self.no_uv_count += 1

        # Default settings from scene config (persisted across dialog opens)
        cfg = context.scene.compify_config
        self.bake_resolution = cfg.bake_image_res
        self.auto_unwrap = cfg.bake_dialog_auto_unwrap
        self.smart_angle_limit = cfg.bake_dialog_angle_limit
        self.smart_island_margin = cfg.bake_dialog_island_margin
        self.smart_area_weight = cfg.bake_dialog_area_weight
        self.smart_correct_aspect = cfg.bake_dialog_correct_aspect
        self.smart_scale_to_bounds = cfg.bake_dialog_scale_to_bounds

        # Initialize per-object unwrap overrides
        overrides = {}
        for obj in self.affected_objects:
            if obj.type == 'MESH':
                has_uv = bool(obj.data.uv_layers.active)
                overrides[obj.name] = {
                    "skip": False,
                    "forced": not has_uv
                }
        context.scene.compify_bake_unwrap_overrides = json.dumps(overrides)

        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        material = bpy.data.materials.get(self.material_name)

        # Info box
        box = layout.box()
        if material:
            box.label(text=f"Material:  {material.name}", icon="MATERIAL")
        if self.object_name:
            box.label(
                text=f"Baking:   single object '{self.object_name}'",
                icon="MESH_DATA")
        elif self.affected_objects:
            box.label(
                text=f"Objects:   {len(self.affected_objects)}",
                icon="MESH_DATA")
            box.label(
                text=f"Will create: {self.mesh_count} new object(s)",
                icon="OBJECT_DATA")
            non_mesh = len(self.affected_objects) - self.mesh_count
            if non_mesh > 0:
                box.label(
                    text=f"({non_mesh} non-mesh will be skipped)",
                    icon="INFO")

        layout.separator()

        # Resolution selector
        layout.prop(self, "bake_resolution")

        layout.separator()

        # UV handling section
        uv_box = layout.box()
        uv_box.label(text="UV Handling", icon="UV")

        if self.mesh_count == 0:
            uv_box.label(text="No mesh objects found", icon="INFO")
        else:
            uv_box.prop(self, "auto_unwrap")

            # Smart Project settings (visible when auto_unwrap is checked)
            if self.auto_unwrap:
                sp_box = uv_box.box()
                sp_box.label(text="Smart UV Project Settings", icon="MODIFIER")
                sp_box.prop(self, "smart_angle_limit")
                sp_box.prop(self, "smart_island_margin")
                sp_box.prop(self, "smart_area_weight")
                sp_box.prop(self, "smart_correct_aspect")
                sp_box.prop(self, "smart_scale_to_bounds")

            # Per-object UV override list
            try:
                overrides = json.loads(
                    context.scene.compify_bake_unwrap_overrides)
            except (json.JSONDecodeError, TypeError):
                overrides = {}

            if overrides:
                obj_box = uv_box.box()
                obj_box.label(
                    text=f"Objects ({self.mesh_count}):",
                    icon="MESH_DATA")

                for obj_name, state in overrides.items():
                    if state.get("forced"):
                        obj_box.label(
                            text=f"  {obj_name}  [NO UV - forced]",
                            icon="ERROR")
                    else:
                        row = obj_box.row()
                        row.label(text=f"  {obj_name}")
                        toggle = row.operator(
                            "compify.toggle_unwrap_object",
                            text="Unwrap" if not state.get("skip") else "Keep UV",
                            icon="UNLOCKED" if not state.get("skip") else "LOCKED",
                            emboss=True,
                        )
                        toggle.object_name = obj_name

        layout.separator()

        # Safety notice
        note = layout.box()
        note.label(
            text="Original objects will NOT be modified.", icon="INFO")
        note.label(
            text="A new object with baked texture will be created"
                 " for each.")

    def execute(self, context):
        material = bpy.data.materials.get(self.material_name)
        if not material:
            self.report(
                {"ERROR"},
                f"Material '{self.material_name}' not found")
            return {"CANCELLED"}

        try:
            overrides = json.loads(
                context.scene.compify_bake_unwrap_overrides)
        except (json.JSONDecodeError, TypeError):
            overrides = {}
        skip_names = {
            name for name, state in overrides.items()
            if state.get("skip") and not state.get("forced")
        }

        result = bake_material_projection(
            scene=context.scene,
            material=material,
            bake_resolution=self.bake_resolution,
            auto_unwrap=self.auto_unwrap,
            skip_unwrap_names=skip_names,
            angle_limit=self.smart_angle_limit,
            island_margin=self.smart_island_margin,
            area_weight=self.smart_area_weight,
            correct_aspect=self.smart_correct_aspect,
            scale_to_bounds=self.smart_scale_to_bounds,
            operator=self,
            object_filter={self.object_name} if self.object_name else None,
        )

        # Save dialog settings to scene config (remember for next open)
        cfg = context.scene.compify_config
        cfg.bake_image_res = self.bake_resolution
        cfg.bake_dialog_auto_unwrap = self.auto_unwrap
        cfg.bake_dialog_angle_limit = self.smart_angle_limit
        cfg.bake_dialog_island_margin = self.smart_island_margin
        cfg.bake_dialog_area_weight = self.smart_area_weight
        cfg.bake_dialog_correct_aspect = self.smart_correct_aspect
        cfg.bake_dialog_scale_to_bounds = self.smart_scale_to_bounds

        if result["success"]:
            count = len(result["baked_objects"])
            mat_name = (result["baked_material"].name
                        if result["baked_material"] else "N/A")

            msg_parts = [
                f"Baked {count} object(s)."
                f" New material: '{mat_name}'"
            ]
            if result.get("unwrapped_count"):
                msg_parts.append(
                    f"UV unwrapped: {result['unwrapped_count']}")
            if result.get("forced_unwrap_count"):
                msg_parts.append(
                    f"UV forced unwrap: {result['forced_unwrap_count']}")
            self.report({"INFO"}, ". ".join(msg_parts))

            redraw_viewport(context)
            return {"FINISHED"}
        else:
            self.report({"ERROR"}, result["message"])
            return {"CANCELLED"}


# ========================================================


class CompifyFootageConfig(bpy.types.PropertyGroup):
    footage: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Footage Texture",
        update=change_footage_material_clip,
    )
    camera: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Footage Camera",
        poll=lambda scene, obj: obj.type == "CAMERA",
        update=change_footage_camera,
    )
    geo_collection: bpy.props.PointerProperty(
        type=bpy.types.Collection,
        name="Footage Geo Collection",
    )
    lights_collection: bpy.props.PointerProperty(
        type=bpy.types.Collection,
        name="Footage Lights Collection",
    )
    bake_uv_margin: bpy.props.IntProperty(
        name="Bake UV Margin",
        subtype="PIXEL",
        options=set(),  # Not animatable.
        default=4,
        min=0,
        max=2**16,
        soft_max=32,
    )
    bake_image_res: bpy.props.IntProperty(
        name="Bake Resolution",
        subtype="PIXEL",
        options=set(),  # Not animatable.
        default=4096,
        min=64,
        max=2**16,
        soft_max=8192,
    )

    # Bake dialog settings (persisted across dialog opens)
    bake_dialog_auto_unwrap: bpy.props.BoolProperty(
        name="Auto-unwrap UV",
        default=True,
    )
    bake_dialog_angle_limit: bpy.props.IntProperty(
        default=66,
        min=0,
        max=89,
        subtype="ANGLE",
    )
    bake_dialog_island_margin: bpy.props.FloatProperty(
        default=0.0,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
    )
    bake_dialog_area_weight: bpy.props.FloatProperty(
        default=0.0,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
    )
    bake_dialog_correct_aspect: bpy.props.BoolProperty(
        default=False,
    )
    bake_dialog_scale_to_bounds: bpy.props.BoolProperty(
        default=True,
    )


# ========================================================


def register():
    bpy.utils.register_class(CompifyPanel)
    bpy.utils.register_class(CompifyCameraPanel)
    bpy.utils.register_class(CompifyUVAdjust3DPanel)
    bpy.utils.register_class(CompifyAddFootageGeoCollection)
    bpy.utils.register_class(CompifyAddFootageLightsCollection)
    bpy.utils.register_class(CompifyPrepScene)
    bpy.utils.register_class(CompifyBake)
    bpy.utils.register_class(CompifyRender)
    bpy.utils.register_class(CompifyCameraProjectGroupNew)
    bpy.utils.register_class(CompifyBatchGenerateUVAdjust)
    bpy.utils.register_class(CompifyRefreshUVAdjustList)
    bpy.utils.register_class(CompifyToggleUVGroupFold)
    bpy.utils.register_class(CompifySelectUVAdjustObject)
    bpy.utils.register_class(CompifySelectMaterialObjects)
    bpy.utils.register_class(CompifySelectObjectByName)
    bpy.utils.register_class(CompifySelectUVAdjustCamera)
    bpy.utils.register_class(CompifyUpdateUVAdjust)
    bpy.utils.register_class(CompifyDeleteUVAdjust)
    bpy.utils.register_class(CompifyCleanOrphanUVAdjust)
    bpy.utils.register_class(CompifyToggleUnwrapObject)
    bpy.utils.register_class(CompifyBakeMaterialProjection)
    bpy.utils.register_class(CompifyOneClickSyncUVAdjust)
    bpy.utils.register_class(CompifyFootageConfig)

    # Custom properties.
    bpy.types.Scene.compify_config = bpy.props.PointerProperty(
        type=CompifyFootageConfig
    )
    bpy.types.Scene.compify_uv_adjust_camera = bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="UV Adjust Camera",
        description="Camera to use for UV adjustment calculations",
        poll=lambda scene, obj: obj.type == "CAMERA",
    )
    bpy.types.Scene.compify_uv_group_fold_states = bpy.props.StringProperty(
        name="Compify UV Group Fold States",
        description="JSON storage for UV group fold states",
        default="{}",
    )
    bpy.types.Scene.compify_bake_unwrap_overrides = bpy.props.StringProperty(
        name="Bake Unwrap Overrides",
        description="JSON storage for per-object unwrap toggles",
        default="{}",
    )

    # Register translations (pass plugin root module name)
    translations.register(__name__)

    # Other modules.
    camera_align_register()


def unregister():
    # Unregister translations first (must use same domain)
    translations.unregister(__name__)

    bpy.utils.unregister_class(CompifyPanel)
    bpy.utils.unregister_class(CompifyCameraPanel)
    bpy.utils.unregister_class(CompifyUVAdjust3DPanel)
    bpy.utils.unregister_class(CompifyAddFootageGeoCollection)
    bpy.utils.unregister_class(CompifyAddFootageLightsCollection)
    bpy.utils.unregister_class(CompifyPrepScene)
    bpy.utils.unregister_class(CompifyBake)
    bpy.utils.unregister_class(CompifyRender)
    bpy.utils.unregister_class(CompifyCameraProjectGroupNew)
    bpy.utils.unregister_class(CompifyBatchGenerateUVAdjust)
    bpy.utils.unregister_class(CompifyRefreshUVAdjustList)
    bpy.utils.unregister_class(CompifyToggleUVGroupFold)
    bpy.utils.unregister_class(CompifySelectUVAdjustObject)
    bpy.utils.unregister_class(CompifySelectMaterialObjects)
    bpy.utils.unregister_class(CompifySelectObjectByName)
    bpy.utils.unregister_class(CompifySelectUVAdjustCamera)
    bpy.utils.unregister_class(CompifyUpdateUVAdjust)
    bpy.utils.unregister_class(CompifyDeleteUVAdjust)
    bpy.utils.unregister_class(CompifyCleanOrphanUVAdjust)
    bpy.utils.unregister_class(CompifyBakeMaterialProjection)
    bpy.utils.unregister_class(CompifyToggleUnwrapObject)
    bpy.utils.unregister_class(CompifyOneClickSyncUVAdjust)
    bpy.utils.unregister_class(CompifyFootageConfig)

    # Custom properties.
    del bpy.types.Scene.compify_config
    del bpy.types.Scene.compify_uv_adjust_camera
    del bpy.types.Scene.compify_uv_group_fold_states
    del bpy.types.Scene.compify_bake_unwrap_overrides

    # Other modules.
    camera_align_unregister()


if __name__ == "__main__":
    register()
