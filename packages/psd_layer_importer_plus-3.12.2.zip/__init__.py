bl_info = {
    "name": "PSD Layer Importer PLUS",
    "author": "HAOAH (toukou0091@gmail.com)",
    "description": "View3D > Sidebar > PSD图层导入工具。支持导入PSD图层为Blender对象，刷新图层，更改文件路径，以及切换混合模式。",
    "blender": (2, 93, 0),
    "version": (3, 12, 2),  # 3.12.2：设置面板排版重做（卡片分组 + 说明收进悬停提示）
    "location": "View3D > Sidebar > PSD图层导入工具",
    "warning": "",
    "category": "Import-Export",
}

import bpy
from . import PSD_Layer_Importer


def register():
    PSD_Layer_Importer.register()


def unregister():
    PSD_Layer_Importer.unregister()


if __name__ == "__main__":
    register()
