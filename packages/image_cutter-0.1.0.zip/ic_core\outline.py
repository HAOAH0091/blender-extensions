"""把二值掩膜追成一圈圈闭合轮廓。

做法：不沿着**像素中心**走（Moore 邻域 / 朴素 marching squares），
而是沿着「实心 ↔ 空」之间的**像素边**走。

好处（这是它相对朴素做法的唯一但关键的优点）：
两个形状**只在一个角上碰着**时，会被自动拆成两圈，不会黏成一坨。

实现：Marching Squares 变体。
  · 每个 2×2 像素单元算一个 4 位 code
  · 查表得到该单元的「有向边」段，方向统一为「实心在右手边」
  · 方向统一了，段与段自然首尾相接；外环逆时针、内环顺时针（天然反向）

坐标：像素中心系。像素 (x, y) 的中心是 (x+0.5, y+0.5)。
输出坐标是 0.5 的整数倍，左上原点（y 向下）。
"""

import numpy as np

# code = tl*8 | tr*4 | br*2 | bl*1（1 = 实心）
# 值 = 该 code 下的边连接对，边编号 0=上 1=右 2=下 3=左
# 方向统一为「实心在右手边」——这一条是整个算法能串成环的关键
# ⚠️ 这张表极易填错，且**错了不报错**（返回 0 个环、页面干净得像什么都没发生）。
#    自检办法：互补 case 必须反向 —— case N 与 case (15-N) 是同一条边界、方向相反。
#    另外所有段方向必须统一，否则串不成环。
_SQ = (
    (),            # 0  全空
    (3, 2),        # 1  bl
    (2, 1),        # 2  br
    (3, 1),        # 3  bl+br
    (1, 0),        # 4  tr
    (3, 2, 1, 0),  # 5  tr+bl  鞍点
    (2, 0),        # 6  tr+br
    (3, 0),        # 7  tr+br+bl
    (0, 3),        # 8  tl
    (0, 2),        # 9  tl+bl
    (0, 3, 2, 1),  # 10 tl+br  鞍点
    (0, 1),        # 11 tl+br+bl
    (1, 3),        # 12 tl+tr
    (1, 2),        # 13 tl+tr+bl
    (2, 3),        # 14 tl+tr+br
    (),            # 15 全实心
)


def _edge_pt(j, i, e):
    """单元 (j, i) 的第 e 条边的中点，返回 ×2 的整数坐标（避免浮点做字典键）。"""
    if e == 0:
        return (2 * j, 2 * i - 1)      # 上
    if e == 1:
        return (2 * j + 1, 2 * i)      # 右
    if e == 2:
        return (2 * j, 2 * i + 1)      # 下
    return (2 * j - 1, 2 * i)          # 左


def trace_rings(mask, min_points=4):
    """掩膜 → 闭合环列表。

    每个环是 [(x, y), ...]，像素中心系，左上原点。
    min_points: 点数少于此的环当噪声丢掉。

    注意：掩膜全实心时没有任何边，返回空列表（调用方应据此提示"这张图没有透明区"）。
    """
    m = np.asarray(mask, dtype=bool)
    if m.ndim != 2:
        raise ValueError("掩膜必须是二维数组")
    h, w = m.shape
    if h == 0 or w == 0:
        return []

    # 外扩一圈空白，好让贴着图像边缘的形状也能围出完整轮廓
    p = np.zeros((h + 2, w + 2), dtype=np.uint8)
    p[1:-1, 1:-1] = m

    tl = p[:-1, :-1]
    tr = p[:-1, 1:]
    br = p[1:, 1:]
    bl = p[1:, :-1]
    code = (tl << 3) | (tr << 2) | (br << 1) | bl

    # 只有「非全空、非全实心」的单元才产生边段；大图上这类单元只占轮廓量级
    ys, xs = np.nonzero((code != 0) & (code != 15))

    segs = []                          # 有向段：((sx, sy), (ex, ey))，×2 坐标
    for i, j in zip(ys.tolist(), xs.tolist()):
        table = _SQ[int(code[i, j])]
        for k in range(0, len(table), 2):
            segs.append((_edge_pt(j, i, table[k]), _edge_pt(j, i, table[k + 1])))

    if not segs:
        return []

    # 起点 → 段索引，用于串联
    starts = {}
    for idx, (s, _e) in enumerate(segs):
        starts.setdefault(s, []).append(idx)

    used = bytearray(len(segs))
    rings = []

    for seed in range(len(segs)):
        if used[seed]:
            continue
        ring = []
        cur = seed
        guard = 0
        limit = len(segs) + 8
        while cur is not None and not used[cur] and guard < limit:
            guard += 1
            used[cur] = 1
            sx, sy = segs[cur][0]
            ring.append((sx * 0.5, sy * 0.5))
            nxt = segs[cur][1]
            cur = None
            for cand in starts.get(nxt, ()):
                if not used[cand]:
                    cur = cand
                    break
        if len(ring) >= min_points:
            rings.append(ring)

    return rings


def ring_area(ring):
    """带符号面积。正 = 逆时针（在 y 向下的图像坐标里，视觉上是顺时针）。

    只用来比较大小 / 判断方向，符号含义随坐标系，别跨坐标系硬解释。
    """
    n = len(ring)
    if n < 3:
        return 0.0
    s = 0.0
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        s += x0 * y1 - x1 * y0
    return s * 0.5


def point_in_ring(pt, ring):
    """射线法：点是否在环内。用于判洞、判三角形重心。"""
    x, y = pt
    inside = False
    n = len(ring)
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        if (y0 > y) != (y1 > y):
            xc = (x1 - x0) * (y - y0) / (y1 - y0) + x0
            if x < xc:
                inside = not inside
    return inside


def ring_centroid(ring):
    n = len(ring)
    if n == 0:
        return (0.0, 0.0)
    sx = sum(p[0] for p in ring)
    sy = sum(p[1] for p in ring)
    return (sx / n, sy / n)


def split_outer(points_per_ring):
    """挑出「外环」，丢掉洞。

    判据：一个环，如果有奇数个更大的环把它包在里面，它就是洞。
    这就是「中心不留洞」的实现 —— 洞被丢掉，内部不会被挖空。

    返回 (outer, inner)，两个都是环列表，保持原顺序。
    """
    info = []
    for r in points_per_ring:
        a = abs(ring_area(r))
        info.append({"ring": r, "area": a, "c": ring_centroid(r)})

    outer, inner = [], []
    for k, it in enumerate(info):
        depth = 0
        for other_k, other in enumerate(info):
            if other_k == k:
                continue
            if other["area"] > it["area"] and point_in_ring(it["c"], other["ring"]):
                depth += 1
        (outer if depth % 2 == 0 else inner).append(it["ring"])
    return outer, inner
