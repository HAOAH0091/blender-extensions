"""Image Cutter —— 把带 alpha 的平面贴图抠成三角网格。

用法：选中一个贴了图的平面 → 侧栏「抠图」→ 点「生成抠图网格」。
之后所有参数都能随时改，视口立刻跟着变。
"""

bl_info = {
    "name": "Image Cutter（贴图抠网格）",
    "author": "浩 & 小澈",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "3D 视图 > 侧栏 > 抠图",
    "description": "按贴图的透明区抠出形状，铺成带贴图与 UV 的三角网格；参数实时可调，支持钢笔画路径引导",
    "category": "Mesh",
}

import importlib
import sys

import bpy

# 允许热重载：开发时改完文件重装插件即可，不用重启 Blender。
# ⚠️ 必须排除自己（__name__）——把正在导入的包从 sys.modules 里删掉，
#    会让导入器重新解析本文件，无限递归直到 RecursionError。
for _name in list(sys.modules):
    if _name != __name__ and _name.startswith(__name__ + "."):
        del sys.modules[_name]
del _name

from .ic_core import mask, outline, simplify, warp, triangulate, guide, pipeline  # noqa: E402,F401
from .ic_bpy import imgio, build                                                   # noqa: E402,F401
from .ic_ui import props, ops, panels, pen                                         # noqa: E402,F401

_CLASSES = (
    props.IC_GuidePoint,
    props.IC_GuideStroke,
    props.IC_Settings,
    ops.IC_OT_Generate,
    ops.IC_OT_Rebuild,
    ops.IC_OT_FixAlpha,
    ops.IC_OT_SelectSource,
    pen.IC_OT_PenDraw,
    pen.IC_OT_PenClear,
    panels.IC_PT_Main,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.image_cutter = bpy.props.PointerProperty(type=props.IC_Settings)


def unregister():
    if hasattr(bpy.types.Object, "image_cutter"):
        del bpy.types.Object.image_cutter
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
