"""image_cutter 核心算法层。

这一层**不依赖 bpy**，只吃 numpy 数组、吐 numpy/纯 Python 结构。
好处：算法可以脱离 Blender 单独测试，迭代快、出错好定位。

数据流（自下而上）：

    alpha 数组  (float32, H×W, 0..1)
        │  mask.build_mask           ── 阈值一刀切 → 实心/空心
        ▼
    mask        (bool, H×W)          + edge_style 判断软边/硬边
        │  outline.trace_rings       ── 沿像素边追一圈
        ▼
    rings       [ (N,2) float 像素坐标，左上原点 ]
        │  simplify.simplify_ring    ── 抽稀顶点
        │  warp.smooth_ring          ── 拐角圆滑（只对软边图）
        │  warp.expand_ring          ── 边缘外扩
        ▼
    轮廓点串
        │  triangulate.build_mesh    ── 铺三角面（中心不留洞）
        ▼
    verts / faces / uvs             ── 交给 bpy 建 mesh

坐标约定：**像素坐标，左上原点**（x 向右、y 向下），和看图一致。
转 UV 时统一翻 y，见 meshdata.rings_to_uv。
"""

__version__ = "0.1.0"
