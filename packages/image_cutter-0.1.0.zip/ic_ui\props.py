"""面板参数。

设计选择：**参数挂在生成出来的网格对象上**，不是全局设置。
理由：同场景里可以对好几张图、用不同参数各生成一份网格，
拖动滑块时改的是「这个对象自己的参数」，不会互相干扰。

面板显示谁，就改谁 —— 用户选中哪个网格，改的就是哪个。
"""

import bpy

from ..ic_core import pipeline as pipe


def _on_change(self, context):
    """任一分法参数变了就重建网格。"""
    from . import ops
    ops.schedule_rebuild(self.id_data, context)


def _poll_mesh(self, obj):
    return obj is not None and obj.type == "MESH"


class IC_GuidePoint(bpy.types.PropertyGroup):
    """钢笔的一个锚点（像素坐标）+ 两个贝塞尔控制柄（相对锚点的偏移）。"""

    x: bpy.props.FloatProperty()
    y: bpy.props.FloatProperty()
    in_dx: bpy.props.FloatProperty(default=0.0)
    in_dy: bpy.props.FloatProperty(default=0.0)
    out_dx: bpy.props.FloatProperty(default=0.0)
    out_dy: bpy.props.FloatProperty(default=0.0)


class IC_GuideStroke(bpy.types.PropertyGroup):
    """一条钢笔画出来的路径（像素坐标，左上原点）。"""

    closed: bpy.props.BoolProperty(default=False)
    points: bpy.props.CollectionProperty(type=IC_GuidePoint)


def _density_to_spacing(v):
    """UI 的 0..1 密度 → 目标边长（像素）。"""
    return pipe.spacing_from_density(v, min_px=5.0, max_px=48.0)


class IC_Settings(bpy.types.PropertyGroup):
    """挂在网格对象上的一套抠图参数。"""

    source_obj: bpy.props.PointerProperty(
        name="源平面",
        description="这张网格是从哪个平面抠出来的（改它会重建）",
        type=bpy.types.Object,
        poll=_poll_mesh,
        update=_on_change,
    )

    # ---- 形状识别 ----
    threshold: bpy.props.FloatProperty(
        name="透明判定阈值",
        description="alpha 超过这根线的像素算「实心」。调高更瘦，调低更胖",
        default=0.5, min=0.01, max=0.99, precision=2,
        update=_on_change,
    )

    # ---- 轮廓 ----
    tolerance: bpy.props.FloatProperty(
        name="轮廓容差",
        description="越大顶点越少、边越直；越小越贴原图、顶点越多",
        default=1.5, min=0.1, max=8.0, precision=2,
        update=_on_change,
    )
    expand: bpy.props.IntProperty(
        name="边缘外扩",
        description="把轮廓整体往外推几像素，防止边缘裁太紧露出底色",
        default=2, min=0, max=32,
        update=_on_change,
    )
    smooth: bpy.props.IntProperty(
        name="拐角圆滑",
        description="像素楼梯要不要磨圆。画出来的图磨，像素画别磨（会自动判断）",
        default=1, min=0, max=6,
        update=_on_change,
    )

    # ---- 网格 ----
    density: bpy.props.FloatProperty(
        name="网格密度",
        description="往里拖 = 三角形更密更贴细节",
        default=0.55, min=0.0, max=1.0, precision=3, subtype="FACTOR",
        update=_on_change,
    )

    # ---- 引导（钢笔） ----
    guide_mode: bpy.props.EnumProperty(
        name="引导方式",
        items=[
            ("replace", "我画的为准", "钢笔经过的地方按我画的切，其余自动"),
            ("solid_only", "只补不挖", "只用钢笔画的范围补实心，不挖掉任何自动结果"),
        ],
        default="replace",
        update=_on_change,
    )
    guide_enabled: bpy.props.BoolProperty(
        name="启用引导",
        description="关掉就用纯自动结果（画好的路径不会丢）",
        default=True,
        update=_on_change,
    )
    strokes: bpy.props.CollectionProperty(type=IC_GuideStroke)
    guide_ver: bpy.props.IntProperty(default=0)

    # ---- 状态回显（只读，给面板显示） ----
    stat_faces: bpy.props.IntProperty(default=0)
    stat_points: bpy.props.IntProperty(default=0)
    stat_rings: bpy.props.IntProperty(default=0)
    stat_edge: bpy.props.StringProperty(default="")
    stat_edge_ratio: bpy.props.FloatProperty(default=0.0)
    stat_ms_a: bpy.props.FloatProperty(default=0.0)
    stat_ms_b: bpy.props.FloatProperty(default=0.0)
    last_error: bpy.props.StringProperty(default="")
    built: bpy.props.BoolProperty(default=False)

    def spacing(self):
        return _density_to_spacing(self.density)

    def params(self):
        return pipe.Params(
            threshold=float(self.threshold),
            tolerance=float(self.tolerance),
            expand=int(self.expand),
            smooth=int(self.smooth),
            spacing=_density_to_spacing(self.density),
            guide_mode=self.guide_mode,
        )
