"""插件的主要操作：生成、重建、修材质。

【重建策略】

参数一变就重建。但「重建」分两级，靠 pipeline 里那两个阶段键来决定跑多远：

  · 改**网格密度** → 阶段 A（认轮廓）结果照用，只重跑阶段 B（铺网格）
    —— 几十毫秒，拖滑块是跟手的

  · 改**阈值 / 精度 / 外扩 / 圆滑 / 引导** → 阶段 A 失效，两级都跑
    —— 稍慢，但这是形状真的变了，慢是应该的

防抖：滑块拖动时 update 回调每帧都会响，用 80ms 的定时器合批，
拖的过程中只算最后一次。
"""

import json

import bpy
import numpy as np

from ..ic_bpy import build as build_mod
from ..ic_bpy import imgio
from ..ic_core import guide as guide_mod
from ..ic_core import pipeline as pipe

# 只缓存「最近一张图」的中间结果 —— 够用，而且不会把显存/内存吃光
_CACHE = {
    "img_key": None,
    "alpha": None,
    "info": None,
    "stage_a_key": None,
    "stage_a": None,
}

_PENDING = set()
_TIMER_NAME = "image_cutter_rebuild"


# --------------------------------------------------------------------------
# 引导（钢笔画出来的路径）
# --------------------------------------------------------------------------

def collect_strokes(settings):
    """把面板里存的笔画转成 (密集点串, 是否闭合) 列表。"""
    out = []
    for st in settings.strokes:
        anchors = [(float(p.x), float(p.y),
                    float(p.in_dx), float(p.in_dy),
                    float(p.out_dx), float(p.out_dy)) for p in st.points]
        if len(anchors) < 2:
            continue
        sampled = guide_mod.anchors_to_points(anchors)
        if len(sampled) >= 2:
            out.append((sampled, bool(st.closed)))
    return out


def build_guide_mask(settings, width, height):
    """把钢笔路径栅格化成三态掩膜（+1 保留 / -1 剔除）。没有笔画返回 None。"""
    if not settings.guide_enabled:
        return None
    strokes = collect_strokes(settings)
    if not strokes:
        return None
    return guide_mod.rasterize(strokes, width, height)


# --------------------------------------------------------------------------
# 重建
# --------------------------------------------------------------------------

def rebuild_object(obj, context, force=False):
    """按对象上存的参数，把它的网格重建一遍。返回 (ok, message)。"""
    if obj is None or obj.type != "MESH":
        return False, "不是网格对象"

    s = obj.image_cutter
    src = s.source_obj
    if src is None:
        s.last_error = "还没指定源平面"
        return False, s.last_error
    if src.name not in bpy.data.objects:
        s.last_error = "源平面已被删除"
        return False, s.last_error

    img, node, mat = imgio.find_image_slot(src)
    if img is None:
        s.last_error = "源平面的材质里没有「图片纹理」节点"
        return False, s.last_error

    key = imgio.image_key(img)
    if force or _CACHE["img_key"] != key:
        try:
            alpha, info = imgio.read_alpha(img)
        except Exception as exc:                       # noqa: BLE001
            s.last_error = "读图片失败：%s" % exc
            return False, s.last_error
        _CACHE["img_key"] = key
        _CACHE["alpha"] = alpha
        _CACHE["info"] = info
        _CACHE["stage_a_key"] = None
        _CACHE["stage_a"] = None

    alpha = _CACHE["alpha"]
    info = _CACHE["info"]

    if not info["has_alpha"]:
        s.last_error = "这张贴图没有透明区（整张都是不透明的），没东西可抠"
        return False, s.last_error

    params = s.params()
    guide_mask = build_guide_mask(s, info["width"], info["height"])

    akey = params.stage_a_key(key, s.guide_ver)
    if force or _CACHE["stage_a_key"] != akey or _CACHE["stage_a"] is None:
        sa = pipe.run_stage_a(alpha, params, guide_mask, key)
        _CACHE["stage_a_key"] = akey
        _CACHE["stage_a"] = sa
    sa = _CACHE["stage_a"]

    if not sa.rings:
        s.last_error = "没找到任何轮廓 —— 试试调低「透明判定阈值」"
        s.stat_faces = 0
        s.stat_points = 0
        return False, s.last_error

    sb = pipe.run_stage_b(sa, params)

    size_x, size_y = imgio.object_local_size(src)
    verts, uvs = build_mod.px_to_local(
        sb["points"], info["width"], info["height"], size_x, size_y
    )
    build_mod.update_mesh_object(obj, verts, sb["faces"], uvs)

    # 材质：沿用源平面的，并确保 alpha 接上了
    obj.data.materials.clear()
    if mat is not None:
        obj.data.materials.append(mat)
        build_mod.ensure_material_has_alpha(mat, img)

    s.stat_faces = len(sb["faces"])
    s.stat_points = len(sb["points"])
    s.stat_rings = len(sa.rings)
    s.stat_edge = sa.edge_style
    s.stat_edge_ratio = round(sa.edge_ratio, 3)
    s.stat_ms_a = sa.ms.get("stage_a", 0.0)
    s.stat_ms_b = sb["stats"].get("stage_b", 0.0)
    s.built = True
    s.last_error = ""

    # 记下这次用的源图，换图时能察觉
    obj["ic_source_image"] = key
    return True, "面 %d / 点 %d" % (len(sb["faces"]), len(sb["points"]))


def _flush_pending():
    """定时器回调：把攒下来的重建请求一次做完。"""
    try:
        names = list(_PENDING)
        _PENDING.clear()
        ctx = bpy.context
        for name in names:
            obj = bpy.data.objects.get(name)
            if obj is not None and obj.type == "MESH":
                try:
                    rebuild_object(obj, ctx)
                except Exception as exc:                # noqa: BLE001
                    obj.image_cutter.last_error = "重建出错：%s" % exc
    except Exception as exc:                            # noqa: BLE001
        print("[image_cutter] flush 失败：%s" % exc)
    return None


def schedule_rebuild(obj, context=None):
    """把 obj 排进重建队列（80ms 防抖，拖动滑块时只算最后一次）。"""
    if obj is None:
        return
    try:
        _PENDING.add(obj.name)
    except AttributeError:
        return
    try:
        if not bpy.app.timers.is_registered(_flush_pending):
            bpy.app.timers.register(_flush_pending, first_interval=0.08)
    except Exception:                                   # noqa: BLE001
        # 定时器不可用时退化成直接重建，至少功能不丢
        _flush_pending()


# --------------------------------------------------------------------------
# 操作符
# --------------------------------------------------------------------------

def _pick_source(context):
    """挑源平面：优先当前选中的网格。"""
    sel = [o for o in context.selected_objects if o.type == "MESH"]
    if len(sel) == 1:
        return sel[0]
    act = context.active_object
    if act is not None and act.type == "MESH":
        return act
    return None


class IC_OT_Generate(bpy.types.Operator):
    bl_idname = "image_cutter.generate"
    bl_label = "生成抠图网格"
    bl_description = "从选中平面的贴图里抠出形状，铺成一片带贴图的三角网格"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(o.type == "MESH" for o in context.selected_objects) or (
            context.active_object is not None and context.active_object.type == "MESH"
        )

    def execute(self, context):
        src = _pick_source(context)

        # 选中的已经是「本插件生成的网格」→ 就地重建，别越建越多
        if src is not None and src.get("ic_generated"):
            ok, msg = rebuild_object(src, context, force=True)
            self.report({"INFO"} if ok else {"WARNING"}, msg)
            return {"FINISHED"} if ok else {"CANCELLED"}

        if src is None:
            self.report({"ERROR"}, "先选中一个贴了图的平面")
            return {"CANCELLED"}

        img, node, mat = imgio.find_image_slot(src)
        if img is None:
            self.report({"ERROR"}, "这个物体的材质里找不到「图片纹理」节点")
            return {"CANCELLED"}

        try:
            _alpha, info = imgio.read_alpha(img)
        except Exception as exc:                        # noqa: BLE001
            self.report({"ERROR"}, "读图片失败：%s" % exc)
            return {"CANCELLED"}

        if not info["has_alpha"]:
            self.report({"WARNING"}, "这张贴图没有透明区，抠出来会是一整块")
            return {"CANCELLED"}

        name = "%s_cutout" % src.name
        me_name = "%s_mesh" % src.name
        obj = bpy.data.objects.get(name)
        if obj is None:
            # 新对象先建空的，再让 rebuild 灌数据（避免两套建对象逻辑）
            me = bpy.data.meshes.new(me_name)
            obj = bpy.data.objects.new(name, me)
            coll = src.users_collection[0] if src.users_collection else context.scene.collection
            coll.objects.link(obj)

        obj["ic_generated"] = True
        s = obj.image_cutter
        s.source_obj = src
        s.guide_ver = int(s.guide_ver) + 1

        # 放在源平面正前方一点点，免得和源平面重叠闪烁
        obj.location = src.location
        obj.rotation_euler = src.rotation_euler
        obj.scale = src.scale
        obj.location.z += 0.001

        ok, msg = rebuild_object(obj, context, force=True)
        if not ok:
            self.report({"ERROR"}, msg)
            return {"CANCELLED"}

        for o in bpy.context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({"INFO"}, "生成完成：%s" % msg)
        return {"FINISHED"}


class IC_OT_Rebuild(bpy.types.Operator):
    bl_idname = "image_cutter.rebuild"
    bl_label = "重新生成"
    bl_description = "丢掉缓存，从头算一遍"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if obj is None or not obj.get("ic_generated"):
            self.report({"ERROR"}, "请先选中一个由本插件生成的网格")
            return {"CANCELLED"}
        ok, msg = rebuild_object(obj, context, force=True)
        self.report({"INFO"} if ok else {"ERROR"}, msg)
        return {"FINISHED"} if ok else {"CANCELLED"}


class IC_OT_FixAlpha(bpy.types.Operator):
    bl_idname = "image_cutter.fix_alpha"
    bl_label = "修好贴图透明"
    bl_description = "把贴图的 alpha 接到材质输出上，透明边缘才会真的透"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            self.report({"ERROR"}, "先选中一个对象")
            return {"CANCELLED"}
        src = obj.image_cutter.source_obj or obj
        img, node, mat = imgio.find_image_slot(src)
        if img is None:
            self.report({"ERROR"}, "找不到图片纹理节点")
            return {"CANCELLED"}
        changed = build_mod.ensure_material_has_alpha(mat, img)
        self.report({"INFO"} if changed else {"WARNING"},
                    "已接上 alpha" if changed else "alpha 本来就已经接好了")
        return {"FINISHED"}


class IC_OT_SelectSource(bpy.types.Operator):
    bl_idname = "image_cutter.select_source"
    bl_label = "选中源平面"
    bl_description = "跳到生成这张网格的那个平面"

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            return {"CANCELLED"}
        src = obj.image_cutter.source_obj
        if src is None or src.name not in bpy.data.objects:
            self.report({"WARNING"}, "源平面已经不在了")
            return {"CANCELLED"}
        for o in context.selected_objects:
            o.select_set(False)
        src.select_set(True)
        context.view_layer.objects.active = src
        return {"FINISHED"}


# --------------------------------------------------------------------------
# 引导数据的读写（用 custom property 存 JSON，简单可靠）
# --------------------------------------------------------------------------

def save_strokes(settings, strokes):
    """strokes: [(点串, 是否闭合)] → 写进面板的属性里。"""
    settings.strokes.clear()
    for pts, closed in strokes:
        st = settings.strokes.add()
        st.closed = bool(closed)
        for (x, y) in pts:
            p = st.points.add()
            p.x = float(x)
            p.y = float(y)
    settings.guide_ver = int(settings.guide_ver) + 1


def strokes_to_json(settings):
    return json.dumps(
        [{"closed": bool(st.closed),
          "points": [[float(p.x), float(p.y)] for p in st.points]}
         for st in settings.strokes]
    )
