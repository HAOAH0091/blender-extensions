"""开真窗口截「抠图」面板 —— 让面板出现在一个默认可见的标签页下，看清内容。

    blender <blend> --python tests/gui_panel.py -- <输出目录>

为什么要临时改 bl_category：N 面板默认停在 Blender 自带的 "Item" 标签，
我们自己的「抠图」标签不会被渲染。为了截图看到真实内容，
这里把它临时挂到 "Item" 下 —— 画出来的东西和用户在「抠图」标签里看到的完全一样。
"""

import os
import sys
import traceback

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG_DIR)
for p in (ADDONS, PKG_DIR, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

argv = sys.argv
OUT = None
if "--" in argv:
    rest = argv[argv.index("--") + 1:]
    if rest:
        OUT = rest[0]
if not OUT:
    OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace"
OUT = os.path.abspath(OUT)
os.makedirs(OUT, exist_ok=True)


def log(m):
    print("[panel] %s" % m)
    sys.stdout.flush()


def view3d():
    win = bpy.context.window_manager.windows[0]
    for area in win.screen.areas:
        if area.type != "VIEW_3D":
            continue
        region = next((r for r in area.regions if r.type == "UI"), None)
        return win, area, region
    return None, None, None


def shoot(name):
    try:
        bpy.ops.wm.redraw_timer(type="DRAW_WIN_SWAP", iterations=3)
    except Exception as exc:                     # noqa: BLE001
        log("重绘失败：%s" % exc)
    p = os.path.join(OUT, name)
    try:
        bpy.ops.screen.screenshot(filepath=p)
        log("%s  %d B" % (name, os.path.getsize(p)))
    except Exception as exc:                     # noqa: BLE001
        log("截图失败：%s" % exc)


def scroll(times, down=True):
    """滚动侧栏。

    ⚠️ 别写 `getattr(bpy.ops, *op.split("."))()` —— 那是把两个名字同时当属性名传，
       会抛 'module' object is not callable，而且看着像"滚了但没效果"（三张截图字节完全相同）。
    """
    win, area, region = view3d()
    if area is None:
        return
    fn = getattr(getattr(bpy.ops, "view3d"),
                 "ui_scroll_down" if down else "ui_scroll_up", None)
    if fn is None:
        log("没有滚动这个操作符（%s 版本可能不支持）" % bpy.app.version_string)
        return
    try:
        with bpy.context.temp_override(window=win, screen=win.screen,
                                       area=area, region=region):
            for _ in range(times):
                fn()
        log("滚动 x%d" % times)
    except Exception as exc:                     # noqa: BLE001
        log("滚动失败：%s" % exc)


STEPS = {"n": 0}


def tick():
    try:
        n = STEPS["n"]

        if n == 0:
            try:
                import image_cutter
                image_cutter.register()
            except Exception as exc:             # noqa: BLE001
                log("注册失败：%s" % exc)

            # 把面板临时挂到默认可见的 "Item" 标签，截图才是真实渲染
            try:
                from image_cutter.ic_ui import panels
                bpy.utils.unregister_class(panels.IC_PT_Main)
                panels.IC_PT_Main.bl_category = "Item"
                bpy.utils.register_class(panels.IC_PT_Main)
                log("面板已临时挂到 Item 标签（画面内容和「抠图」标签一致）")
            except Exception as exc:             # noqa: BLE001
                log("改标签失败：%s" % exc)

            cut = next((o for o in bpy.data.objects if o.get("ic_generated")), None)
            if cut is not None:
                for o in bpy.context.selected_objects:
                    o.select_set(False)
                cut.select_set(True)
                bpy.context.view_layer.objects.active = cut
                s = cut.image_cutter
                log("已选中 %s；guide_enabled=%s strokes=%d"
                    % (cut.name, s.guide_enabled, len(s.strokes)))
            else:
                log("!! 没有生成物")

            win, area, region = view3d()
            if area is not None:
                try:
                    area.spaces[0].show_region_ui = True
                    log("侧栏 UI region 宽高 = %s"
                        % ((region.width, region.height) if region else "?"))
                except Exception as exc:         # noqa: BLE001
                    log("展开侧栏失败：%s" % exc)

            STEPS["n"] = 1
            return 1.6

        if n == 1:
            shoot("panel_top.png")
            STEPS["n"] = 2
            return 1.2

        if n == 2:
            scroll(8, down=True)
            STEPS["n"] = 3
            return 1.0

        if n == 3:
            shoot("panel_bottom.png")
            STEPS["n"] = 4
            return 0.5

        log("完成")
        os._exit(0)
    except Exception:                            # noqa: BLE001
        traceback.print_exc()
        os._exit(3)
    return 0.3


bpy.app.timers.register(tick, first_interval=1.5, persistent=True)
