"""钢笔工具：对着源平面画路径。

【为什么画在 3D 视口，而不是图片编辑器】

图片编辑器看着更「像画图」，但它的「屏幕 ↔ 图像像素」换算没有现成工具，
得自己摸 zoom / offset，Blender 各版本还不一样，很容易画歪。

3D 视口这边有 `view3d_utils` 现成的坐标工具：鼠标位置 → 射线，
射线和源平面求交 → 世界坐标 → 平面本地坐标 → 像素坐标。
换算链路每一段都有官方函数兜底，而且**画的时候能同时看到网格在变**。

代价是需要正对着平面画才不变形 —— 所以面板上提示先切顶视图（小键盘 7）。

交互照着 PS 钢笔来：

    左键点击        落一个锚点
    按住左键拖      拉出这个锚点的对称控制柄（曲线就出来了）
    C               闭合当前路径并结束
    回车 / 右键     结束当前路径（不闭合）
    Delete          退回上一个锚点
    Esc             整个取消

路径存的是「锚点 + 进出控制柄」，不是采样后的点串 ——
既能无损再编辑，也让存的东西和画的时候看到的是同一份。
"""

import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from ..ic_bpy import imgio
from ..ic_core import guide as guide_mod


def _shader():
    for name in ("UNIFORM_COLOR", "2D_UNIFORM_COLOR"):
        try:
            return gpu.shader.from_builtin(name)
        except Exception:                        # noqa: BLE001
            continue
    return None


def _batch(shader, kind, coords):
    if kind == "LINES" and len(coords) < 2:
        return None
    if len(coords) < 1:
        return None
    try:
        return batch_for_shader(shader, kind, {"pos": coords})
    except Exception:                            # noqa: BLE001
        return None


def _draw(shader, kind, coords, color, width=1.0, point_size=0.0):
    b = _batch(shader, kind, coords)
    if b is None:
        return
    try:
        if kind == "LINES":
            gpu.state.line_width_set(width)
        elif kind == "POINTS" and point_size:
            gpu.state.point_size_set(point_size)
    except Exception:                            # noqa: BLE001
        pass
    shader.bind()
    shader.uniform_float("color", color)
    b.draw(shader)


class IC_OT_PenDraw(bpy.types.Operator):
    """对着源平面画引导路径（PS 钢笔式：点击落点、拖动出曲线）。"""

    bl_idname = "image_cutter.pen_draw"
    bl_label = "画引导路径"
    bl_description = "在 3D 视口里对着源平面点画路径；建议先按小键盘 7 切到顶视图"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == "MESH"
                and bool(obj.get("ic_generated"))
                and context.area is not None and context.area.type == "VIEW_3D")

    def invoke(self, context, event):
        obj = context.active_object
        s = obj.image_cutter
        src = s.source_obj
        if src is None:
            self.report({"ERROR"}, "还没有源平面")
            return {"CANCELLED"}

        img, _node, _mat = imgio.find_image_slot(src)
        if img is None:
            self.report({"ERROR"}, "源平面的材质里找不到图片纹理")
            return {"CANCELLED"}

        self.target = obj
        self.source = src
        self.img_size = (int(img.size[0]), int(img.size[1]))
        self.size = imgio.object_local_size(src)

        self.points = []       # [(px, py, in_dx, in_dy, out_dx, out_dy)]
        self.dragging = False
        self.hover = None
        self.shader = _shader()

        self._handler = bpy.types.SpaceView3D.draw_handler_add(
            _draw_cb, (self, context), "WINDOW", "POST_PIXEL"
        )
        context.window_manager.modal_handler_add(self)
        self.report({"INFO"}, "左键落点 / 按住拖出曲线 / C 闭合 / 回车结束 / Esc 取消")
        return {"RUNNING_MODAL"}

    # ---------------------------------------------------------------- 坐标

    def pixel_at(self, context, event):
        """鼠标位置 → 贴图像素坐标。视线打不到平面时返回 None。"""
        region = context.region
        rv3d = context.region_data
        if region is None or rv3d is None:
            return None

        coord = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

        mw = self.source.matrix_world
        normal = (mw.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
        plane_pt = mw.translation

        denom = direction.dot(normal)
        if abs(denom) < 1e-9:
            return None
        t = (plane_pt - origin).dot(normal) / denom
        if t <= 0:
            return None
        hit = origin + direction * t

        local = mw.inverted() @ hit
        w, h = self.img_size
        sx, sy = self.size
        u = local.x / sx + 0.5
        v = local.y / sy + 0.5
        return (u * w, (1.0 - v) * h)

    def screen_of(self, context, px, py):
        """贴图像素坐标 → 屏幕坐标。"""
        region = context.region
        rv3d = context.region_data
        if region is None or rv3d is None:
            return None
        w, h = self.img_size
        sx, sy = self.size
        u = px / float(w)
        v = 1.0 - py / float(h)
        local = Vector(((u - 0.5) * sx, (v - 0.5) * sy, 0.0))
        world = self.source.matrix_world @ local
        return view3d_utils.location_3d_to_region_2d(region, rv3d, world)

    def curve_screen(self, context, a, b, steps=16):
        """两锚点之间的贝塞尔段 → 屏幕坐标串。"""
        out = []
        p0 = (a[0], a[1])
        c0 = (a[0] + a[4], a[1] + a[5])
        c1 = (b[0] + b[2], b[1] + b[3])
        p1 = (b[0], b[1])
        for k in range(steps + 1):
            t = k / float(steps)
            u = 1.0 - t
            x = (u * u * u * p0[0] + 3 * u * u * t * c0[0]
                 + 3 * u * t * t * c1[0] + t * t * t * p1[0])
            y = (u * u * u * p0[1] + 3 * u * u * t * c0[1]
                 + 3 * u * t * t * c1[1] + t * t * t * p1[1])
            sc = self.screen_of(context, x, y)
            if sc is None:
                return []
            out.append((sc[0], sc[1]))
        return out

    # ---------------------------------------------------------------- 模态

    def modal(self, context, event):
        if context.area is None:
            return self._finish(context, cancelled=True)

        context.area.tag_redraw()

        if event.type == "ESC":
            return self._finish(context, cancelled=True)

        if event.type in {"RET", "NUMPAD_ENTER", "RIGHTMOUSE"}:
            return self._finish(context, closed=False)

        if event.type in {"DEL", "BACKSPACE"}:
            if self.points and not self.dragging:
                self.points.pop()
            return {"RUNNING_MODAL"}

        if event.type == "C" and event.value == "PRESS" and not self.dragging:
            if len(self.points) >= 3:
                return self._finish(context, closed=True)
            return {"RUNNING_MODAL"}

        if event.type == "MOUSEMOVE":
            self.hover = self.pixel_at(context, event)
            if self.dragging and self.points and self.hover is not None:
                last = list(self.points[-1])
                dx = self.hover[0] - last[0]
                dy = self.hover[1] - last[1]
                # PS 的对称柄：拖出来的方向和长度，同时给进出两侧
                last[4] = dx
                last[5] = dy
                last[2] = -dx
                last[3] = -dy
                self.points[-1] = tuple(last)
            return {"RUNNING_MODAL"}

        if event.type == "LEFTMOUSE":
            if event.value == "PRESS":
                hp = self.pixel_at(context, event)
                if hp is None:
                    return {"RUNNING_MODAL"}
                self.points.append((hp[0], hp[1], 0.0, 0.0, 0.0, 0.0))
                self.dragging = True
                self._cursor(context, "CROSSHAIR")
            else:
                self.dragging = False
            return {"RUNNING_MODAL"}

        return {"RUNNING_MODAL"}

    @staticmethod
    def _cursor(context, shape):
        try:
            context.window.cursor_set(shape)
        except Exception:                        # noqa: BLE001
            pass

    def _finish(self, context, cancelled=False, closed=False):
        if self._handler is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._handler, "WINDOW")
            except Exception:                    # noqa: BLE001
                pass
            self._handler = None
        self._cursor(context, "DEFAULT")

        if cancelled:
            return {"CANCELLED"}
        if len(self.points) < 2:
            self.report({"WARNING"}, "路径太短，已丢弃")
            return {"CANCELLED"}

        s = self.target.image_cutter
        st = s.strokes.add()
        st.closed = bool(closed)
        for (px, py, ix, iy, ox, oy) in self.points:
            p = st.points.add()
            p.x = px
            p.y = py
            p.in_dx = ix
            p.in_dy = iy
            p.out_dx = ox
            p.out_dy = oy

        s.guide_enabled = True
        s.guide_ver = int(s.guide_ver) + 1

        from . import ops
        ops.schedule_rebuild(self.target, context)

        self.report({"INFO"}, "已加一条路径（共 %d 条）%s"
                    % (len(s.strokes), "，已闭合" if closed else ""))
        return {"FINISHED"}


def _draw_cb(op, context):
    """视口绘制回调。这里抛异常会让整个视口黑掉，必须全吞。"""
    try:
        shader = op.shader
        if shader is None or context.region is None:
            return
        pts = op.points
        if not pts:
            return

        anchor_col = (1.0, 0.85, 0.20, 1.0)
        curve_col = (0.31, 0.79, 0.69, 1.0)
        handle_col = (0.62, 0.55, 0.98, 0.9)

        seg = []
        for k in range(len(pts) - 1):
            seg.extend(op.curve_screen(context, pts[k], pts[k + 1]))
        if len(seg) >= 2:
            _draw(shader, "LINES", seg, curve_col, width=2.0)

        anchors = []
        for a in pts:
            sc = op.screen_of(context, a[0], a[1])
            if sc is not None:
                anchors.append((sc[0], sc[1]))
        if anchors:
            _draw(shader, "POINTS", anchors, anchor_col, point_size=9.0)

        if op.dragging and pts:
            last = pts[-1]
            ipt = (last[0] + last[2], last[1] + last[3])
            opt = (last[0] + last[4], last[1] + last[5])
            c = op.screen_of(context, last[0], last[1])
            h1 = op.screen_of(context, ipt[0], ipt[1])
            h2 = op.screen_of(context, opt[0], opt[1])
            if c and h1 and h2:
                _draw(shader, "LINES",
                      [(h1[0], h1[1]), (c[0], c[1]), (c[0], c[1]), (h2[0], h2[1])],
                      handle_col, width=1.0)
                _draw(shader, "POINTS", [(h1[0], h1[1]), (h2[0], h2[1])],
                      handle_col, point_size=6.0)

        if op.hover is not None and pts and not op.dragging:
            last = pts[-1]
            a = op.screen_of(context, last[0], last[1])
            b = op.screen_of(context, op.hover[0], op.hover[1])
            if a and b:
                _draw(shader, "LINES", [(a[0], a[1]), (b[0], b[1])],
                      (1.0, 1.0, 1.0, 0.35), width=1.0)
    except Exception:                            # noqa: BLE001
        pass


class IC_OT_PenClear(bpy.types.Operator):
    bl_idname = "image_cutter.pen_clear"
    bl_label = "清空引导路径"
    bl_description = "删掉所有画好的路径，回到纯自动结果"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if obj is None or not obj.get("ic_generated"):
            self.report({"ERROR"}, "先选中本插件生成的网格")
            return {"CANCELLED"}
        s = obj.image_cutter
        n = len(s.strokes)
        s.strokes.clear()
        s.guide_ver = int(s.guide_ver) + 1
        from . import ops
        ops.schedule_rebuild(obj, context)
        self.report({"INFO"}, "已清空 %d 条路径" % n)
        return {"FINISHED"}


def stroke_to_points(stroke):
    """存下来的笔画 → 密集点串（含贝塞尔控制柄）。给 guide 栅格化用。"""
    pts = [(p.x, p.y, p.in_dx, p.in_dy, p.out_dx, p.out_dy) for p in stroke.points]
    if not pts:
        return []
    out = [(pts[0][0], pts[0][1])]
    for k in range(len(pts) - 1):
        a = pts[k]
        b = pts[k + 1]
        c0 = (a[0] + a[4], a[1] + a[5])
        c1 = (b[0] + b[2], b[1] + b[3])
        out.extend(guide_mod.sample_cubic((a[0], a[1]), c0, c1, (b[0], b[1]), 12))
    return out
