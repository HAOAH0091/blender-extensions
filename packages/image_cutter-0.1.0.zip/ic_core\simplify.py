"""轮廓抽稀：把一圈几万个点降到几十个，同时形状走样不超过容差。

两层：
  1. **RDP（Douglas-Peucker）** —— 贪心，快速把点数降到几百。它是 O(n log n)，
     先跑它，是为了让第 2 步的复杂度可控。直接对原始点跑 DP 会卡死。
  2. **有界动态规划** —— 在小窗口里搜「段数最少优先、面积误差次之」的解。
     这是 image_to_cutout 那套比常规抽稀更讲究的地方：贪心一次定生死，
     DP 会回头找更省的走法。

为什么两层而不是只跑 DP：DP 每段都要算「段内所有点到线段的距离」，
不经预处理就是 O(n·win²)。1 万点的环在纯 Python 里要好几秒。
"""

import math

import numpy as np


def _dedup(ring, eps=1e-9):
    """去掉相邻的重复点（追踪出来的环常带）。"""
    out = []
    for p in ring:
        if not out or abs(p[0] - out[-1][0]) > eps or abs(p[1] - out[-1][1]) > eps:
            out.append((float(p[0]), float(p[1])))
    # 首尾也去重
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) <= eps and abs(out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def _roll_to_corner(pts):
    """把环旋转到「离质心最远的点」开头。

    为什么：闭合环做抽稀必须选个起点，起点若落在平滑段上会被硬切成角。
    离质心最远的点通常是真正的尖角，从它开始最安全。
    """
    n = len(pts)
    if n < 3:
        return pts
    cx = sum(p[0] for p in pts) / n
    cy = sum(p[1] for p in pts) / n
    best, best_d = 0, -1.0
    for k, p in enumerate(pts):
        d = (p[0] - cx) ** 2 + (p[1] - cy) ** 2
        if d > best_d:
            best, best_d = k, d
    return pts[best:] + pts[:best]


def _rdp(pts, tol):
    """迭代版 Douglas-Peucker。pts 是 (N,2) float 数组。"""
    n = len(pts)
    if n < 3:
        return pts
    keep = np.zeros(n, dtype=bool)
    keep[0] = True
    keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        a = pts[i]
        b = pts[j]
        d = b - a
        seg = pts[i + 1:j]
        length = math.hypot(float(d[0]), float(d[1]))
        if length < 1e-12:
            dist = np.hypot(seg[:, 0] - a[0], seg[:, 1] - a[1])
        else:
            dist = np.abs((seg[:, 0] - a[0]) * d[1] - (seg[:, 1] - a[1]) * d[0]) / length
        k = int(np.argmax(dist))
        if float(dist[k]) > tol:
            m = i + 1 + k
            keep[m] = True
            stack.append((i, m))
            stack.append((m, j))
    return pts[keep]


def _seg_dev(pts, j, i):
    """点 j..i 之间所有点到线段 (j, i) 的最大垂距。"""
    if i - j < 2:
        return 0.0
    a = pts[j]
    b = pts[i]
    seg = pts[j + 1:i]
    d = b - a
    length = math.hypot(float(d[0]), float(d[1]))
    if length < 1e-12:
        return float(np.max(np.hypot(seg[:, 0] - a[0], seg[:, 1] - a[1])))
    return float(np.max(np.abs((seg[:, 0] - a[0]) * d[1] - (seg[:, 1] - a[1]) * d[0]) / length))


def _dp_shortest(pts, tol, max_win=40):
    """有界动态规划：段数最少优先，段数相同时挑偏离小的。

    代价 = 1（每段固定成本） + (偏离/容差)²
    偏离小于容差时几乎不加钱（形状保真），超过容差代价二次增长（超了就不值当）。
    """
    n = len(pts)
    if n < 4:
        return pts
    win = max(3, min(max_win, n - 1))
    inf = float("inf")
    cost = [inf] * n
    prev = [-1] * n
    cost[0] = 0.0

    for i in range(1, n):
        j0 = max(0, i - win)
        ci = inf
        pi = -1
        for j in range(j0, i):
            cj = cost[j]
            if cj == inf:
                continue
            dev = _seg_dev(pts, j, i)
            r = dev / tol if tol > 1e-9 else 0.0
            c = cj + 1.0 + r * r
            if c < ci:
                ci = c
                pi = j
        cost[i] = ci
        prev[i] = pi

    out = []
    k = n - 1
    guard = 0
    while k >= 0 and guard <= n + 2:
        guard += 1
        out.append(pts[k])
        if k == 0:
            break
        k = prev[k]
        if k < 0:
            break
    out.reverse()
    return np.asarray(out)


def simplify_ring(ring, tol, refine=True):
    """闭合环抽稀。tol = 容差（像素）。返回点列表（首尾不重复）。"""
    pts = _dedup(ring)
    if len(pts) < 5:
        return pts

    pts = _roll_to_corner(pts)
    n = len(pts)
    # 环展开成开放折线（首尾同点）才能跑 RDP / DP
    closed = np.asarray(pts + [pts[0]], dtype=np.float64)

    coarse = _rdp(closed, max(tol * 0.75, 1e-6)) if n > 200 else closed
    if refine and len(coarse) > 4:
        fine = _dp_shortest(coarse, tol)
    else:
        fine = coarse

    out = [(float(p[0]), float(p[1])) for p in fine[:-1]]
    return out if len(out) >= 3 else pts


def simplify_rings(rings, tol, refine=True):
    return [simplify_ring(r, tol, refine) for r in rings]
