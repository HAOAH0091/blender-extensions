"""把各步串成一条流水线，并管住「改一个参数要重算到哪一步」。

【为什么要有缓存边界】

这是整个插件唯一需要认真设计的地方：
「认轮廓」（分割 → 追踪 → 简化 → 平滑）是**慢的**，跟贴图大小成正比；
「铺网格」（撒点 → 三角化）是**快的**，只跟目标密度有关。

如果每拖一下滑块都从头认一遍轮廓，4K 贴图会卡到没法用。
所以缓存按「阶段」切：

    阶段 A（重）：分割 / 追踪 / 简化 / 平滑      键 = 图 + 阈值 + 精度 + 圆滑 + 引导 + 外扩
    阶段 B（轻）：撒点 / 三角化                  键 = 阶段 A 结果 + 网格密度

改网格密度只重跑 B；改阈值才重跑 A。看 stage_b_key()。
"""

import hashlib
import time
from dataclasses import dataclass, field

import numpy as np

from . import mask as mask_mod
from . import outline as outline_mod
from . import simplify as simplify_mod
from . import triangulate as tri_mod
from . import warp as warp_mod


@dataclass
class Params:
    """全部可调参数。单位都是**像素**（贴图自己的像素）。"""

    threshold: float = 0.5      # alpha 超过它算实心
    tolerance: float = 1.5      # 轮廓容差：越大顶点越少、边越直
    expand: int = 2             # 边缘外扩像素
    smooth: int = 1             # 拐角圆滑迭代次数（只对软边图有意义）
    spacing: float = 18.0       # 网格目标边长：越小越密
    guide_mode: str = "replace"  # 引导路径与自动结果的关系

    def stage_a_key(self, img_key, guide_ver=0):
        raw = "|".join([
            str(img_key), str(guide_ver),
            "%.4f" % self.threshold, "%.4f" % self.tolerance,
            str(int(self.expand)), str(int(self.smooth)), self.guide_mode,
        ])
        return hashlib.md5(raw.encode("utf-8")).hexdigest()[:16]

    def stage_b_key(self, stage_a_res, spacing=None):
        sp = self.spacing if spacing is None else spacing
        raw = "%.4f" % sp
        return hashlib.md5(raw.encode("utf-8")).hexdigest()[:16]


@dataclass
class StageA:
    """慢阶段的产物：几何轮廓。"""

    rings: list = field(default_factory=list)      # 外环（洞已丢弃）
    inner_count: int = 0
    raw_ring_count: int = 0
    solid: int = 0
    empty: int = 0
    edge_style: str = "hard"
    edge_ratio: float = 0.0
    ms: dict = field(default_factory=dict)


def run_stage_a(alpha, params, guide_mask=None, img_key="img"):
    """分割 → 追踪 → 丢洞 → 简化 → 平滑。慢，结果该被缓存。"""
    t0 = time.perf_counter()

    m, mstats = mask_mod.build_mask(alpha, params.threshold)
    t_mask = time.perf_counter()

    # 软硬边必须在**膨胀之前**判：外扩会把边界推出形状，那圈像素的 alpha 接近 0，
    # 拿它去统计会把任何图都判成硬边（这是一次真踩到的 bug）。
    # 这个属性只跟贴图本身有关，跟外扩参数没半点关系。
    style, ratio = mask_mod.edge_style(alpha, m)

    if guide_mask is not None:
        m = mask_mod.apply_guide(m, guide_mask, params.guide_mode)
    if params.expand and params.expand > 0:
        m = mask_mod.dilate_mask(m, params.expand)

    rings = outline_mod.trace_rings(m)
    outer, inner = outline_mod.split_outer(rings)
    t_trace = time.perf_counter()
    # 硬边图不平滑 —— 对像素画平滑等于把设计磨掉
    smooth_iters = int(params.smooth) if style == "soft" else 0

    tolerance = max(0.05, float(params.tolerance))
    out = []
    for r in outer:
        if len(r) < 4:
            continue

        # ⚠️ 顺序很重要：**先平滑、再抽稀**。
        # 反过来（先抽稀再平滑）看着也能跑，但抽稀后一圈只剩十几个点，
        # 这时做滑动平均，凹口的那个顶点会被两边邻居往外拽几十像素 ——
        # 凹口被鼓成弧、轮廓围出一圈光晕。这是个几何上真会错的地方，
        # 而且在预览图上看不出来（形状"差不多还是个星"）。
        if smooth_iters > 0:
            r = warp_mod.smooth_ring(r, smooth_iters)

        s = simplify_mod.simplify_ring(r, tolerance)
        if len(s) < 3:
            continue
        out.append(s)
    t_fin = time.perf_counter()

    return StageA(
        rings=out,
        inner_count=len(inner),
        raw_ring_count=len(rings),
        solid=mstats["solid"],
        empty=mstats["empty"],
        edge_style=style,
        edge_ratio=ratio,
        ms={
            "mask": round((t_mask - t0) * 1000, 1),
            "trace": round((t_trace - t_mask) * 1000, 1),
            "simplify": round((t_fin - t_trace) * 1000, 1),
            "stage_a": round((t_fin - t0) * 1000, 1),
        },
    )


def run_stage_b(stage_a, params):
    """撒点 → 三角化。轻，参数一改就能重算。"""
    t0 = time.perf_counter()
    res = tri_mod.build_mesh(stage_a.rings, max(2.0, float(params.spacing)))
    t1 = time.perf_counter()
    res["stats"]["stage_b"] = round((t1 - t0) * 1000, 1)
    return res


def run(alpha, params, guide_mask=None, img_key="img"):
    """一次跑完（不做缓存，给测试 / 一次性调用用）。"""
    a = run_stage_a(alpha, params, guide_mask, img_key)
    b = run_stage_b(a, params)
    return a, b


def spacing_from_density(v, min_px=5.0, max_px=48.0):
    """把 UI 上的「网格密度」0..1 映射成目标边长。

    0 → 48px（稀疏，几个大三角）
    1 → 5px（很密）
    """
    v = min(max(float(v), 0.0), 1.0)
    return max_px - (max_px - min_px) * v
