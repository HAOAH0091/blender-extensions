"""核心算法自检 —— 不依赖 Blender，直接 `python tests/test_core.py` 跑。

测的是算法本身对不对，不是插件能不能装。
这里过不了，接进 Blender 只会把问题藏得更深。
"""

import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

if HERE not in sys.path:
    sys.path.insert(0, HERE)

from ic_core import mask as mask_mod          # noqa: E402
from ic_core import outline as outline_mod    # noqa: E402
from ic_core import pipeline as pipe         # noqa: E402
from ic_core import simplify as simplify_mod  # noqa: E402
from ic_core import triangulate as tri_mod    # noqa: E402
from ic_core import warp as warp_mod          # noqa: E402

PASS = []
FAIL = []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    tag = "PASS" if cond else "FAIL"
    line = "  [%s] %s" % (tag, name)
    if detail:
        line += "   %s" % detail
    print(line)


# --------------------------------------------------------------------------
# 合成测试图
# --------------------------------------------------------------------------

from fixture import make_alpha as make_test_alpha  # noqa: E402  共用素材，别各写一份


def tri_area_sum(pts, faces):
    s = 0.0
    for (i, j, k) in faces:
        a = pts[i]
        b = pts[j]
        c = pts[k]
        s += abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) * 0.5
    return s


def point_in_tri(p, a, b, c):
    d1 = (p[0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (p[1] - b[1])
    d2 = (p[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (p[1] - c[1])
    d3 = (p[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (p[1] - a[1])
    neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (neg and pos)


print("=" * 74)
print("image_cutter 核心算法自检")
print("=" * 74)

# --------------------------------------------------------------------------
print("\n[1] 分割")
alpha = make_test_alpha(soft=True)
m, st = mask_mod.build_mask(alpha, 0.5)
check("阈值分割能切出实心/空心", st["solid"] > 0 and st["empty"] > 0,
      "solid=%d empty=%d" % (st["solid"], st["empty"]))

style, ratio = mask_mod.edge_style(alpha, m)
check("软边图能被认出来", style == "soft", "ratio=%.3f" % ratio)

hard = np.zeros((64, 64), np.float32)
hard[16:48, 16:48] = 1.0
mh, _ = mask_mod.build_mask(hard, 0.5)
style_h, ratio_h = mask_mod.edge_style(hard, mh)
check("像素画被认成硬边", style_h == "hard", "ratio=%.3f" % ratio_h)

# --------------------------------------------------------------------------
print("\n[2] 轮廓追踪")
corner = np.zeros((2, 2), dtype=bool)
corner[0, 0] = True
corner[1, 1] = True
crings = outline_mod.trace_rings(corner)
check("对角相触的两块被拆成 2 圈（不黏连）", len(crings) == 2,
      "rings=%d" % len(crings))

rings = outline_mod.trace_rings(m)
outer, inner = outline_mod.split_outer(rings)
check("星形+洞+小圆 → 追出 3 圈（含洞）", len(rings) == 3, "rings=%d" % len(rings))
check("丢洞后剩 2 圈外轮廓", len(outer) == 2, "outer=%d inner=%d" % (len(outer), len(inner)))

# --------------------------------------------------------------------------
print("\n[3] 抽稀")
dense = outer[0]
simp = simplify_mod.simplify_ring(dense, 1.5)
check("抽稀明显减少顶点", len(simp) < len(dense) * 0.5,
      "%d → %d" % (len(dense), len(simp)))
a0 = abs(outline_mod.ring_area(dense))
a1 = abs(outline_mod.ring_area(simp))
check("抽稀后面积基本不变（走样在容差内）", abs(a1 - a0) / max(a0, 1e-9) < 0.05,
      "面积变化 %.2f%%" % (abs(a1 - a0) / max(a0, 1e-9) * 100))

tol_loose = simplify_mod.simplify_ring(dense, 5.0)
check("容差越大顶点越少", len(tol_loose) <= len(simp),
      "tol1.5→%d  tol5.0→%d" % (len(simp), len(tol_loose)))

# --------------------------------------------------------------------------
print("\n[4] 圆滑与外扩")
sm = warp_mod.smooth_ring(simp, 3)
check("圆滑不改变顶点数", len(sm) == len(simp))
check("圆滑不炸掉坐标", all(abs(p[0]) < 1e5 and abs(p[1]) < 1e5 for p in sm))

big = mask_mod.dilate_mask(m, 3)
check("膨胀让实心像素变多", big.sum() > m.sum(), "%d → %d" % (m.sum(), big.sum()))
r_exp = outline_mod.trace_rings(big)
o_exp, _ = outline_mod.split_outer(r_exp)
bx = abs(outline_mod.ring_area(o_exp[0]))
check("外扩后轮廓面积变大", bx > a0, "%.0f → %.0f" % (a0, bx))

# --------------------------------------------------------------------------
print("\n[5] Delaunay 三角化")
grid = []
for i in range(8):
    for j in range(8):
        grid.append((j * 10.0, i * 10.0))
t0 = time.perf_counter()
tris = tri_mod.delaunay_2d(np.asarray(grid))
t1 = time.perf_counter()

check("三角化有点产出", len(tris) > 0, "%d 个三角形 %.1fms" % (len(tris), (t1 - t0) * 1000))
allv = set()
for t in tris:
    allv.update(t)
check("覆盖全部输入点", len(allv) == len(grid), "%d/%d" % (len(allv), len(grid)))

ga = np.asarray(grid)
area_sum = tri_area_sum(ga, tris)
# 点从 (0,0) 排到 (70,70)，凸包就是 70x70 的正方形
hull_area = 70.0 * 70.0
check("三角形总面积 = 凸包面积（无重叠无缺口）",
      abs(area_sum - hull_area) < 1.0,
      "%.2f vs %.2f" % (area_sum, hull_area))

# --------------------------------------------------------------------------
print("\n[6] 铺网格（完整流程）")
params = pipe.Params(threshold=0.5, tolerance=1.5, expand=2, smooth=1, spacing=14.0)
t0 = time.perf_counter()
sa = pipe.run_stage_a(alpha, params)
sb = pipe.run_stage_b(sa, params)
t1 = time.perf_counter()

pts = sb["points"]
faces = sb["faces"]
check("产出三角形", len(faces) > 0, "%d 面 / %d 点" % (len(faces), len(pts)))
check("识别为软边 → 做了圆滑", sa.edge_style == "soft")

# 「中心不留洞」：星形正中心必须被某个三角形盖住
# ⚠️ fixture 默认出 512x512 的图，这里的中心坐标得按 512 算（按 256 算过一次，是错的）
cx, cy = 512 * 0.40, 512 * 0.44
covered = False
for (i, j, k) in faces:
    if point_in_tri((cx, cy), pts[i], pts[j], pts[k]):
        covered = True
        break
check("★ 星形正中心被网格盖住（中心不留洞）", covered)

# 覆盖面积应接近「外轮廓面积之和」
tot = tri_area_sum(pts, faces)
ring_area_sum = sum(abs(outline_mod.ring_area(r)) for r in sa.rings)
check("铺满程度合理（>85%）", tot > ring_area_sum * 0.85,
      "网格 %.0f / 轮廓 %.0f = %.1f%%" % (tot, ring_area_sum, tot / max(ring_area_sum, 1e-9) * 100))

# 三角形数随密度上升
counts = []
for sp in (40.0, 22.0, 12.0, 7.0):
    p2 = pipe.Params(threshold=0.5, tolerance=1.5, expand=2, smooth=1, spacing=sp)
    b2 = pipe.run_stage_b(sa, p2)
    counts.append(len(b2["faces"]))
check("网格密度越高三角形越多（单调）",
      all(counts[i] < counts[i + 1] for i in range(len(counts) - 1)),
      " → ".join(str(c) for c in counts))

# --------------------------------------------------------------------------
print("\n[7] 引导路径（钢笔）")
from ic_core import guide as guide_mod  # noqa: E402

# 闭合路径 → 圈起来的那块被标成「保留」
closed = ([(60, 60), (140, 60), (140, 140), (60, 140)], True)
gm = guide_mod.rasterize([closed], 200, 200)
check("闭合路径圈出的区域被标为保留", int((gm > 0).sum()) > 5000,
      "%d 像素" % int((gm > 0).sum()))
check("闭合路径内部确实是保留", gm[100, 100] == 1, "中心=%d" % gm[100, 100])
check("闭合路径外部不受影响", gm[10, 10] == 0, "外圈=%d" % gm[10, 10])

# 开放路径 → 只标线本身，不铺成面
openp = ([(20, 20), (180, 20)], False)
gm2 = guide_mod.rasterize([openp], 200, 200)
n_line = int((gm2 > 0).sum())
check("开放路径只标线附近（不是一整块）", 100 < n_line < 1200, "%d 像素" % n_line)
check("开放路径线上有标记", gm2[20, 100] == 1, "%d" % gm2[20, 100])
check("开放路径线下没标记", gm2[60, 100] == 0, "%d" % gm2[60, 100])

# 贝塞尔采样：锚点 + 控制柄 → 点串，且曲线经过端点
anchors = [(0.0, 0.0, 0.0, 0.0, 30.0, 0.0), (100.0, 100.0, -30.0, 0.0, 0.0, 0.0)]
pts = guide_mod.anchors_to_points(anchors, curve_steps=8)
check("贝塞尔采样出点串", len(pts) > 5, "%d 点" % len(pts))
check("曲线经过起点", abs(pts[0][0]) < 1e-6 and abs(pts[0][1]) < 1e-6)
check("曲线到得了终点", abs(pts[-1][0] - 100) < 1e-6 and abs(pts[-1][1] - 100) < 1e-6)
check("曲线被控制柄拉弯了（不是直线）",
      any(abs(p[1]) > 1.0 for p in pts[1:-1]),
      "中间点 y 最大 %.2f" % max(abs(p[1]) for p in pts[1:-1]))

# 引导并进掩膜
base = np.zeros((200, 200), dtype=bool)
base[150:190, 150:190] = True
merged = mask_mod.apply_guide(base, gm, "replace")
check("引导能把区域加进掩膜", merged[100, 100] and not base[100, 100])
keep_only = mask_mod.apply_guide(base, gm, "solid_only")
check("只补不挖模式下不会挖掉原来的", keep_only[170, 170])
cut_all = mask_mod.apply_guide(
    base,
    np.where(np.zeros((200, 200), dtype=np.int8) == 0, 0, 0).astype(np.int8) - 1,
    "replace",
)
check("全剔除的引导能把掩膜清空", not cut_all.any())

# --------------------------------------------------------------------------
print("\n[8] 性能")
params2 = pipe.Params(threshold=0.5, tolerance=1.5, expand=2, smooth=1, spacing=8.0)
t0 = time.perf_counter()
sa2 = pipe.run_stage_a(alpha, params2)
mid = time.perf_counter()
sb2 = pipe.run_stage_b(sa2, params2)
t1 = time.perf_counter()
print("  · 阶段 A（认轮廓） %.0f ms" % ((mid - t0) * 1000))
print("  · 阶段 B（铺网格） %.0f ms" % ((t1 - mid) * 1000))
print("  · 点 %d / 面 %d" % (len(sb2["points"]), len(sb2["faces"])))
check("阶段 A 在 1s 内", (mid - t0) < 1.0, "%.0f ms" % ((mid - t0) * 1000))
check("阶段 B 在 2s 内", (t1 - mid) < 2.0, "%.0f ms" % ((t1 - mid) * 1000))

# --------------------------------------------------------------------------
print("\n" + "=" * 74)
print("通过 %d / 失败 %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("失败项：")
    for f in FAIL:
        print("  x", f)
    sys.exit(1)
print("全部通过 [OK]")
