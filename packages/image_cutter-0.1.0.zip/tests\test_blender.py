"""在真 Blender 里跑一遍：加载插件 → 造测试场景 → 生成 → 校验。

    blender --background --factory-startup --python tests/test_blender.py

headless 能测的：模块能不能加载、注册有没有冲突、
算法接进 bpy 之后几何/UV/材质对不对、参数改了会不会重建。
headless 测不了的：视口绘制、鼠标交互（那些得开真窗口）。
"""

import json
import math
import os
import sys
import traceback

import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)            # .../addons/image_cutter
ADDONS = os.path.dirname(PKG_DIR)          # .../addons  ← 要让 import image_cutter 成立
for _p in (ADDONS, PKG_DIR, HERE):         # HERE 也要加：fixture.py 在本目录
    if _p not in sys.path:
        sys.path.insert(0, _p)

PASS = []
FAIL = []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print("  [%s] %s%s" % ("PASS" if cond else "FAIL", name,
                           ("   " + detail) if detail else ""))


def make_alpha_image(name="ic_test_tex", w=256, h=256):
    """造一张带 alpha 的测试贴图（用共用 fixture：软边五角星 + 洞 + 分离小圆）。"""
    from fixture import make_rgba, to_blender_pixels

    rgba = make_rgba(w, h, soft=True, with_hole=True, with_dot=True)
    rgba[:, :, 0] = 0.85
    rgba[:, :, 1] = 0.35
    rgba[:, :, 2] = 0.55

    img = bpy.data.images.new(name, width=w, height=h, alpha=True)
    # 必须翻转：Blender 的 pixels 是自下而上存的（见 fixture.to_blender_pixels）
    img.pixels.foreach_set(to_blender_pixels(rgba).ravel())
    img.pack()
    return img


def build_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scn = bpy.context.scene

    bpy.ops.mesh.primitive_plane_add(size=2.0, location=(0.0, 0.0, 0.0))
    plane = bpy.context.active_object
    plane.name = "TestPlane"

    img = make_alpha_image()

    mat = bpy.data.materials.new("TestMat")
    mat.use_nodes = True
    nt = mat.node_tree
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.location = (-400, 0)
    out = None
    for n in nt.nodes:
        if n.type == "BSDF_PRINCIPLED":
            out = n
            break
    if out is not None:
        nt.links.new(tex.outputs["Color"], out.inputs["Base Color"])

    plane.data.materials.append(mat)

    bpy.ops.object.select_all(action="DESELECT")
    plane.select_set(True)
    bpy.context.view_layer.objects.active = plane
    return plane, img, mat


print("=" * 74)
print("image_cutter 真机测试（Blender %s）" % bpy.app.version_string)
print("=" * 74)

# --------------------------------------------------------------------------
print("\n[1] 加载插件")
try:
    import image_cutter
    image_cutter.register()
    check("插件注册成功", True)
except Exception as exc:                       # noqa: BLE001
    traceback.print_exc()
    check("插件注册成功", False, str(exc))
    sys.exit(1)

check("Object.image_cutter 已挂上", hasattr(bpy.types.Object, "image_cutter"))
check("面板已注册", hasattr(bpy.types, "IC_PT_main"))

# --------------------------------------------------------------------------
print("\n[1b] 图标名校验（写错会让面板静默少半截，最阴的一类 bug）")

import re  # noqa: E402


def valid_icon_names():
    """从 Blender 自己的 enum 里取合法图标名。"""
    try:
        p = bpy.types.UILayout.bl_rna.functions["label"].parameters["icon"]
        return {i.identifier for i in p.enum_items}
    except Exception:                            # noqa: BLE001
        return set()


def strip_comment(line):
    """去掉行内注释，但别碰引号里的 #。"""
    out = []
    quote = None
    for ch in line:
        if quote:
            out.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "\"'":
            quote = ch
            out.append(ch)
            continue
        if ch == "#":
            break
        out.append(ch)
    return "".join(out)


_icons = valid_icon_names()
check("能拿到 Blender 的图标清单", len(_icons) > 500, "%d 个" % len(_icons))

# 扫插件自己的源码（跳过下划线开头的临时探针脚本）
_src_files = []
for _root, _dirs, _files in os.walk(PKG_DIR):
    _dirs[:] = [d for d in _dirs if d != "__pycache__"]
    for _f in _files:
        if _f.endswith(".py") and not _f.startswith("_"):
            _src_files.append(os.path.join(_root, _f))

_icon_re = re.compile(r"""icon\s*=\s*["']([A-Za-z0-9_]+)["']""")
_bad_icons = []
_used_icons = set()
for _fp in _src_files:
    try:
        _src = open(_fp, encoding="utf-8").read()
    except Exception:                            # noqa: BLE001
        continue
    for _ln, _line in enumerate(_src.splitlines(), 1):
        for _m in _icon_re.finditer(strip_comment(_line)):
            _name = _m.group(1)
            _used_icons.add(_name)
            if _icons and _name not in _icons:
                _bad_icons.append("%s:%d icon=%s"
                                  % (os.path.basename(_fp), _ln, _name))

check("源码里用到的图标名全部合法（本版本）", not _bad_icons,
      ("非法: " + "; ".join(_bad_icons)) if _bad_icons
      else "%d 个图标名都有效" % len(_used_icons))

# 只对「本版本」校验还不够：某个图标可能在 5.2 有、在 4.2~5.0 没有，
# 于是你在 5.2 上测全绿，别的版本上面板照样少半截（真踩过：GP_DRAW_STROKE）。
# 所以再对一遍「跨版本公共图标集」。
_compat_path = os.path.join(HERE, "icon_compat.json")
_compat = set()
if os.path.exists(_compat_path):
    try:
        _compat = set(json.load(open(_compat_path, encoding="utf-8"))["icons"])
    except Exception as exc:                     # noqa: BLE001
        print("    读 icon_compat.json 失败：%s" % exc)
check("跨版本公共图标集已就位", len(_compat) > 300, "%d 个" % len(_compat))

if _compat:
    _not_compat = sorted(i for i in _used_icons if i not in _compat)
    check("图标名在所有支持版本里都存在", not _not_compat,
          ("跨版本不存在: " + ", ".join(_not_compat)) if _not_compat
          else "%d 个都跨版本可用" % len(_used_icons))
_op_names = ("generate", "rebuild", "fix_alpha",
             "select_source", "pen_draw", "pen_clear")
_bad = []
for _n in _op_names:
    try:
        getattr(bpy.ops.image_cutter, _n).get_rna_type()
    except Exception as _e:                    # noqa: BLE001
        _bad.append("%s(%s)" % (_n, _e))
check("六个操作符全部注册到 RNA", not _bad, "; ".join(_bad))

# --------------------------------------------------------------------------
print("\n[2] 造场景")
plane, img, mat = build_scene()
check("测试平面已建", plane.name == "TestPlane")
check("测试贴图有 alpha", img.size[0] == 256 and img.depth in (32, 0))

from image_cutter.ic_bpy import imgio                  # noqa: E402
found, _node, _m = imgio.find_image_slot(plane)
check("能从材质里找到图片纹理", found is img)

alpha, info = imgio.read_alpha(img)
check("读到 alpha 通道", alpha.shape == (256, 256), str(alpha.shape))
check("识别出有透明区", info["has_alpha"] is True,
      "min=%.3f max=%.3f" % (info["alpha_min"], info["alpha_max"]))

# --------------------------------------------------------------------------
print("\n[3] 生成网格")
try:
    res = bpy.ops.image_cutter.generate()
    ok = "FINISHED" in res
except Exception as exc:                       # noqa: BLE001
    traceback.print_exc()
    ok = False
    print(exc)

check("生成操作返回成功", ok, str(res) if ok else "")

cut = bpy.data.objects.get("TestPlane_cutout")
check("新对象已建出来", cut is not None)
if cut is None:
    print("\n生成失败，后续跳过")
    print("通过 %d / 失败 %d" % (len(PASS), len(FAIL)))
    sys.exit(1)

me = cut.data
check("网格有顶点", len(me.vertices) > 0, "%d 个" % len(me.vertices))
check("网格有面", len(me.polygons) > 0, "%d 个" % len(me.polygons))
check("UV 层已建", len(me.uv_layers) > 0,
      me.uv_layers[0].name if len(me.uv_layers) else "-")
check("材质已挂", len(me.materials) > 0 and me.materials[0] is mat)
check("打了本插件标记", bool(cut.get("ic_generated")))
check("源平面已记录", cut.image_cutter.source_obj is plane)
check("源平面没被动过", len(plane.data.vertices) == 4,
      "源平面顶点 %d" % len(plane.data.vertices))

s = cut.image_cutter
print("     面 %d / 点 %d / 轮廓 %d 圈 / %s / A %.0fms B %.0fms"
      % (s.stat_faces, s.stat_points, s.stat_rings, s.stat_edge,
         s.stat_ms_a, s.stat_ms_b))
check("状态回显有面数", s.stat_faces > 0, str(s.stat_faces))
check("软边图被识别为 soft", s.stat_edge == "soft", s.stat_edge)

# --------------------------------------------------------------------------
print("\n[4] 几何正确性")

uv_layer = me.uv_layers[0].data
uvs = np.empty(len(uv_layer) * 2, dtype=np.float32)
uv_layer.foreach_get("uv", uvs)
uvs = uvs.reshape(-1, 2)
check("UV 落在 0..1 内",
      bool(uvs.min() >= -1e-4 and uvs.max() <= 1.0 + 1e-4),
      "范围 %.3f .. %.3f" % (uvs.min(), uvs.max()))

# 网格该和源平面一样大（本地包围盒 2x2）
co = np.empty(len(me.vertices) * 3, dtype=np.float32)
me.vertices.foreach_get("co", co)
co = co.reshape(-1, 3)
sx = co[:, 0].max() - co[:, 0].min()
sy = co[:, 1].max() - co[:, 1].min()
# 网格只盖住形状那一块，不会铺满整张平面 —— 所以这里查的是
# 「落在平面范围内、且不是退化的一小块」
check("网格落在源平面范围内且不退化",
      0.3 < sx <= 2.05 and 0.3 < sy <= 2.05,
      "%.2f x %.2f" % (sx, sy))
check("网格是平的（z 全 0）", bool(np.allclose(co[:, 2], 0.0, atol=1e-6)))

# 法线朝 +Z（翻转绕向有没有做对）
nrm = np.empty(len(me.polygons) * 3, dtype=np.float32)
me.polygons.foreach_get("normal", nrm)
nrm = nrm.reshape(-1, 3)
up = (nrm[:, 2] > 0.9).sum()
check("面法线朝 +Z（绕向没反）", up == len(me.polygons),
      "%d/%d" % (up, len(me.polygons)))

# 洞填上了没：星形中心应被网格盖住
cx_px, cy_px = 256 * 0.40, 256 * 0.44
cx = (cx_px / 256.0 - 0.5) * 2.0
cy = (1.0 - cy_px / 256.0 - 0.5) * 2.0


def point_in_tri3(p, a, b, c):
    d1 = (p[0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (p[1] - b[1])
    d2 = (p[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (p[1] - c[1])
    d3 = (p[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (p[1] - a[1])
    neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (neg and pos)


covered = False
for poly in me.polygons:
    vi = list(poly.vertices)
    if len(vi) == 3:
        a = co[vi[0]]
        b = co[vi[1]]
        c = co[vi[2]]
        if point_in_tri3((cx, cy), a, b, c):
            covered = True
            break
check("★ 圆的中心被网格盖住（中心不留洞）", covered)

# --------------------------------------------------------------------------
print("\n[5] 参数改了会重建")

# headless 里没有事件循环，bpy.app.timers 不会自己跑。
# 所以这里分两段测：① 回调有没有把对象排进队列 ② 队列执行后网格有没有变。
# ② 才是「重建逻辑对不对」，① 是「参数改动的信号有没有接上」。

from image_cutter.ic_ui import ops as ic_ops        # noqa: E402

before_faces = len(me.polygons)
s.density = 0.95                                    # 触发 update 回调
bpy.context.view_layer.update()

queued = cut.name in ic_ops._PENDING
timer_on = False
try:
    timer_on = bpy.app.timers.is_registered(ic_ops._flush_pending)
except Exception:                                   # noqa: BLE001
    pass
check("改参数后排进了重建队列", queued or timer_on,
      "queued=%s timer=%s" % (queued, timer_on))

ic_ops._flush_pending()
after_faces = len(cut.data.polygons)
check("执行后三角形变多", after_faces > before_faces,
      "%d → %d" % (before_faces, after_faces))

s.density = 0.2
ic_ops._flush_pending()
thin_faces = len(cut.data.polygons)
check("调疏后三角形变少", thin_faces < after_faces,
      "%d → %d" % (after_faces, thin_faces))

s.density = 0.55
ic_ops._flush_pending()


def _bbox_area(me):
    n = len(me.vertices)
    cc = np.empty(n * 3, dtype=np.float32)
    me.vertices.foreach_get("co", cc)
    cc = cc.reshape(-1, 3)
    return ((cc[:, 0].max() - cc[:, 0].min())
            * (cc[:, 1].max() - cc[:, 1].min()))


# ⚠️ 用「顶点数」判重建太粗：阈值改一点点、形状只缩了一些时，
#    抽稀后顶点数可能一模一样。改用包围盒面积这种连续量。
base_area = _bbox_area(cut.data)
s.threshold = 0.95
ic_ops._flush_pending()
new_area = _bbox_area(cut.data)
check("改阈值也触发重建", abs(new_area - base_area) > 1e-4,
      "包围盒面积 %.4f → %.4f" % (base_area, new_area))

# --------------------------------------------------------------------------
print("\n[6] 引导（钢笔画路径）")
s.threshold = 0.5
ic_ops._flush_pending()

n_before = len(cut.data.vertices)

st = s.strokes.add()
st.closed = True
for (px, py) in [(20, 200), (110, 200), (110, 245), (20, 245)]:
    p = st.points.add()
    p.x = px
    p.y = py
s.guide_enabled = True
s.guide_ver = int(s.guide_ver) + 1

from image_cutter.ic_core import guide as guide_mod  # noqa: E402
gm = ic_ops.build_guide_mask(s, 256, 256)
check("引导掩膜已生成", gm is not None and int((gm > 0).sum()) > 100,
      "%d 个像素" % (int((gm > 0).sum()) if gm is not None else 0))
check("引导点串采样正确", len(ic_ops.collect_strokes(s)) == 1)

ok2, msg2 = ic_ops.rebuild_object(cut, bpy.context, force=True)
check("带引导重建成功", ok2, msg2)
check("引导改变了结果", len(cut.data.vertices) != n_before,
      "%d → %d" % (n_before, len(cut.data.vertices)))

s.strokes.clear()
s.guide_ver = int(s.guide_ver) + 1
ok3, msg3 = ic_ops.rebuild_object(cut, bpy.context, force=True)
check("清空引导后能回到自动结果", ok3, msg3)

# --------------------------------------------------------------------------
print("\n[7] 收尾")
check("材质 alpha 已接上",
      any(ln.to_socket.name == "Alpha" and ln.to_node.type == "BSDF_PRINCIPLED"
          for ln in mat.node_tree.links))

print("\n" + "=" * 74)
print("通过 %d / 失败 %d" % (len(PASS), len(FAIL)))
if FAIL:
    print("失败项：")
    for f in FAIL:
        print("  x", f)
    sys.exit(1)
print("全部通过 [OK]")
