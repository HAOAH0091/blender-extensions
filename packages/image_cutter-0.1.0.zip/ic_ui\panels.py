"""侧栏面板。"""

import bpy


def _active_settings(context):
    obj = context.active_object
    if obj is None or obj.type != "MESH":
        return None, None
    return obj, obj.image_cutter


class IC_PT_Main(bpy.types.Panel):
    bl_label = "图片抠图网格"
    bl_idname = "IC_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "抠图"

    def draw(self, context):
        """⚠️ 包一层：draw() 里抛异常，Blender 会**静默截断** ——
        出错那一行之后的控件全都不画，而且不报错、不留痕。
        （真踩过：一个图标名写错，把「手绘引导」整块吃掉了，查了好几轮。）

        所以这里把真实绘制放进 _draw_impl，出异常时画一个**红框**。
        宁可难看，也不能让内容凭空消失。
        """
        try:
            self._draw_impl(context)
        except Exception as exc:                     # noqa: BLE001
            import traceback
            traceback.print_exc()
            box = self.layout.box()
            box.alert = True
            box.label(text="面板绘制出错（请看系统控制台）", icon="ERROR")
            box.label(text=str(exc)[:120])

    def _draw_impl(self, context):
        layout = self.layout
        obj, s = _active_settings(context)

        if obj is None:
            box = layout.box()
            box.label(text="先选中一个贴了图的平面", icon="INFO")
            box.label(text="材质里要有「图片纹理」节点")
            return

        is_generated = bool(obj.get("ic_generated"))

        if not is_generated:
            col = layout.column()
            col.scale_y = 1.5
            col.operator("image_cutter.generate", icon="MOD_OPACITY")
            box = layout.box()
            box.label(text="当前选中：%s" % obj.name, icon="MESH_DATA")
            box.label(text="它看起来是个普通平面，点上面")
            box.label(text="的按钮即可抠出网格。")
            return

        # ---------- 已是生成物：显示参数 ----------
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.operator("image_cutter.rebuild", icon="FILE_REFRESH")

        src = s.source_obj
        box = layout.box()
        box.label(text="来源", icon="IMAGE_DATA")
        if src is not None and src.name in bpy.data.objects:
            r = box.row()
            r.label(text="  %s" % src.name)
            r.operator("image_cutter.select_source", text="", icon="RESTRICT_SELECT_OFF")
        else:
            box.label(text="  源平面已丢失", icon="ERROR")

        if s.last_error:
            err = layout.box()
            err.alert = True
            err.label(text=s.last_error, icon="ERROR")

        # ---- 形状识别 ----
        col = layout.column(align=True)
        col.label(text="形状识别", icon="MOD_OPACITY")
        col.prop(s, "threshold", slider=True)

        # ---- 轮廓 ----
        col = layout.column(align=True)
        col.label(text="轮廓", icon="CURVE_BEZCURVE")
        col.prop(s, "tolerance", slider=True)
        col.prop(s, "expand", slider=True)
        col.prop(s, "smooth", slider=True)
        if s.stat_edge == "hard":
            info = col.row()
            info.enabled = False
            info.label(text="这张是像素画，已自动跳过圆滑", icon="INFO")

        # ---- 网格 ----
        col = layout.column(align=True)
        col.label(text="网格", icon="MESH_GRID")
        col.prop(s, "density", slider=True)
        sp = col.row()
        sp.enabled = False
        sp.label(text="目标边长 %.1f 像素" % s.spacing())

        # ---- 引导（钢笔）----
        box = layout.box()
        # ⚠️ 图标名是 "GREASEPENCIL"（无下划线）。写成 GREASE_PENCIL 会抛 TypeError，
        #    而这会让 draw() 从这里往后全部不画 —— 钢笔按钮就是这么消失的。
        box.label(text="手绘引导", icon="GREASEPENCIL")
        col = box.column(align=True)
        col.prop(s, "guide_enabled")
        if s.guide_enabled:
            col.prop(s, "guide_mode")
            box.label(text="已画 %d 条路径" % len(s.strokes))
            row = box.row(align=True)
            # ⚠️ 图标名必须在**所有支持的 Blender 版本**里都存在。
            #    这里原来写的是 GP_DRAW_STROKE —— 它在 5.1+ 才有，
            #    4.2~5.0 上会抛异常 → draw() 截断 → 按钮直接消失。
            #    CURVE_PATH 从 4.0 到 5.2 都有（见 tests/icon_compat.json）。
            row.operator("image_cutter.pen_draw", icon="CURVE_PATH")
            row.operator("image_cutter.pen_clear", text="", icon="TRASH")

        # ---- 状态 ----
        box = layout.box()
        box.label(text="结果", icon="INFO")
        g = box.grid_flow(columns=2, even_columns=True, align=True)
        g.label(text="三角形 %d" % s.stat_faces)
        g.label(text="顶点 %d" % s.stat_points)
        g.label(text="轮廓 %d 圈" % s.stat_rings)
        style_txt = {"soft": "画出来的（已圆滑）",
                     "hard": "像素画（保留楼梯）"}.get(s.stat_edge, "-")
        g.label(text=style_txt)
        g.label(text="认轮廓 %.0f ms" % s.stat_ms_a)
        g.label(text="铺网格 %.0f ms" % s.stat_ms_b)

        if s.stat_faces == 0 and not s.last_error:
            warn = box.row()
            warn.enabled = False
            warn.label(text="还没算出面，调调阈值试试", icon="INFO")
