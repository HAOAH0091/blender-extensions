"""把真实面板的 draw() 挂到一个**可见的标签页**里跑，抓出异常。

    blender <blend> --python tests/_panel_probe.py -- <输出json>
    （必须在 GUI 模式；--background 下面板根本不绘制）

为什么要这么绕：`invoke_props_dialog` 在 timer 里不会被绘制，
而 `--background` 下所有面板都不绘制。唯一稳定让 draw 跑起来的办法，
就是让面板出现在一个**当前可见的标签页**下（这里借 Blender 自带的 "Item"）。
"""

import json
import os
import sys
import traceback

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG_DIR)
for p in (ADDONS, PKG_DIR, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

argv = sys.argv
OUT = None
if "--" in argv:
    rest = argv[argv.index("--") + 1:]
    if rest:
        OUT = rest[0]
if not OUT:
    OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace\_panel_probe.json"
OUT = os.path.abspath(OUT)

REPORT = {"ok": None, "error": None, "calls": 0}


class MockPanel:
    """假 panel —— 有 .layout 就能调真实 draw()。"""

    def __init__(self, layout):
        self.layout = layout


def run_real_draw(layout, context):
    REPORT["calls"] += 1
    if REPORT["ok"] is not None:
        return
    try:
        from image_cutter.ic_ui.panels import IC_PT_Main
        IC_PT_Main.draw(MockPanel(layout), context)
        REPORT["ok"] = True
    except Exception:
        REPORT["ok"] = False
        REPORT["error"] = traceback.format_exc()


class PROBE_PT_panel(bpy.types.Panel):
    """挂在 Blender 自带的 "Item" 标签页下 —— 那个标签默认是打开且可见的。"""

    bl_label = "面板探针"
    bl_idname = "PROBE_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Item"

    def draw(self, context):
        run_real_draw(self.layout, context)
        self.layout.label(text="（探针：上面若有内容，说明真面板画出来了）")


def dump():
    try:
        with open(OUT, "w", encoding="utf-8") as fh:
            json.dump(REPORT, fh, ensure_ascii=False, indent=1)
    except Exception:
        pass


STEPS = {"n": 0}


def tick():
    try:
        n = STEPS["n"]

        if n == 0:
            try:
                import image_cutter
                image_cutter.register()
            except Exception as exc:             # noqa: BLE001
                print("[probe] 插件注册失败：%s" % exc)

            cut = next((o for o in bpy.data.objects if o.get("ic_generated")), None)
            if cut is not None:
                for o in bpy.context.selected_objects:
                    o.select_set(False)
                cut.select_set(True)
                bpy.context.view_layer.objects.active = cut
                print("[probe] 已选中 %s" % cut.name)

            try:
                bpy.utils.register_class(PROBE_PT_panel)
                print("[probe] 探针面板已注册（挂在 Item 标签）")
            except Exception as exc:             # noqa: BLE001
                print("[probe] 注册探针失败：%s" % exc)

            win = bpy.context.window_manager.windows[0]
            for area in win.screen.areas:
                if area.type == "VIEW_3D":
                    try:
                        area.spaces[0].show_region_ui = True
                    except Exception:            # noqa: BLE001
                        pass

            STEPS["n"] = 1
            return 1.5

        if n == 1:
            try:
                bpy.ops.wm.redraw_timer(type="DRAW_WIN_SWAP", iterations=3)
            except Exception as exc:             # noqa: BLE001
                print("[probe] 重绘失败：%s" % exc)
            STEPS["n"] = 2
            return 1.2

        if n == 2:
            p = os.path.join(os.path.dirname(OUT), "panel_probe.png")
            try:
                bpy.ops.screen.screenshot(filepath=p)
            except Exception as exc:             # noqa: BLE001
                print("[probe] 截图失败：%s" % exc)
            dump()
            print("[probe] draw 调用 %d 次" % REPORT["calls"])
            if REPORT["ok"] is True:
                print("[probe] 真面板 draw：成功")
            elif REPORT["ok"] is False:
                print("[probe] 真面板 draw：失败 —— 异常已写进 json")
            else:
                print("[probe] 真面板 draw：压根没被调用（面板没渲染）")
            sys.stdout.flush()
            os._exit(0)
    except Exception:                            # noqa: BLE001
        traceback.print_exc()
        dump()
        os._exit(3)
    return 0.3


bpy.app.timers.register(tick, first_interval=1.5, persistent=True)
