"""测试素材生成 —— 各测试脚本共用，避免各写一份各错一份。

⚠️ 踩过的坑：拿 `r = R·cos(π/k)/cos(θ)` 画「星形」是错的 ——
   那是**正 k 边形**的极坐标方程，画出来是个五边形，不是五角星。
   症状很隐蔽：形状看着"差不多是个多角形"，测试也不会报错，
   只有把图放大看才发现五个尖角根本没出来。

   正确做法：把星形当成 2k 个顶点交替 R / r 的多边形，再做点在多边形内判定。
"""

import math

import numpy as np


def star_polygon(cx, cy, outer_r, inner_r, k=5, phase=-math.pi / 2):
    """五角星的顶点表：2k 个点，半径交替 外/内。"""
    pts = []
    for i in range(2 * k):
        ang = phase + i * math.pi / k
        rad = outer_r if i % 2 == 0 else inner_r
        pts.append((cx + math.cos(ang) * rad, cy + math.sin(ang) * rad))
    return pts


def _points_in_poly(xx, yy, poly):
    """向量化射线法：网格上的点是否在多边形内。"""
    inside = np.zeros(xx.shape, dtype=bool)
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        if y0 == y1:
            continue
        cond = (y0 > yy) != (y1 > yy)
        if not cond.any():
            continue
        xc = (x1 - x0) * (yy - y0) / (y1 - y0) + x0
        inside ^= cond & (xx < xc)
    return inside


def _circle(xx, yy, cx, cy, r):
    return np.hypot(xx - cx, yy - cy) < r


def blur(a, rounds=3):
    """3x3 均值模糊，造软边。"""
    out = a.astype(np.float64)
    for _ in range(rounds):
        pad = np.pad(out, 1, mode="edge")
        out = (pad[:-2, :-2] + pad[:-2, 1:-1] + pad[:-2, 2:]
               + pad[1:-1, :-2] + pad[1:-1, 1:-1] + pad[1:-1, 2:]
               + pad[2:, :-2] + pad[2:, 1:-1] + pad[2:, 2:]) / 9.0
    return out


def make_alpha(w=512, h=512, soft=True, with_hole=True, with_dot=True):
    """测试用 alpha 图：五角星（可带中心洞）+ 可选分离小圆。

    返回 (H, W) float32，取值 0..1。
    """
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    alpha = np.zeros((h, w), np.float64)

    cx, cy = w * 0.40, h * 0.44
    outer = w * 0.345
    inner = outer * 0.382                       # 标准五角星的内外半径比
    poly = star_polygon(cx, cy, outer, inner, k=5)
    alpha[_points_in_poly(xx, yy, poly)] = 1.0

    if with_hole:
        alpha[_circle(xx, yy, cx, cy, w * 0.085)] = 0.0
    if with_dot:
        alpha[_circle(xx, yy, w * 0.79, h * 0.79, w * 0.075)] = 1.0

    if soft:
        alpha = blur(alpha, 3)
    return alpha.astype(np.float32)


def make_rgba(w=512, h=512, soft=True, with_hole=True, with_dot=True):
    """带颜色的 RGBA 图（颜色是渐变，好一眼看出 UV 有没有对上）。

    ⚠️ 返回的是**逻辑顺序**：第 0 行 = 图的上边。
       灌进 Blender 之前必须过一遍 `to_blender_pixels()`。
    """
    alpha = make_alpha(w, h, soft, with_hole, with_dot)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    rgba = np.zeros((h, w, 4), np.float32)
    rgba[:, :, 0] = np.clip(0.20 + 0.80 * (xx / w), 0, 1)
    rgba[:, :, 1] = np.clip(0.10 + 0.60 * (yy / h), 0, 1)
    rgba[:, :, 2] = 0.85
    rgba[:, :, 3] = alpha
    return rgba


def to_blender_pixels(rgba):
    """逻辑顺序（行 0 = 上）→ Blender 存储顺序（行 0 = 下）。

    ⚠️ 这是个大坑：`img.pixels` 是**自下而上**存的（第 0 个像素是左下角），
       而我们从 np.mgrid 算出来的是逻辑顺序（行 0 = 上）。
       直接 foreach_set 会让图**上下颠倒** —— 而且不报错，
       只是形状位置偏了（我因此让自检脚本连着判错两轮）。
    """
    return np.ascontiguousarray(rgba[::-1, :, :])
