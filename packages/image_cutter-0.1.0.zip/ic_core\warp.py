"""轮廓的几何后处理：拐角圆滑。

【为什么外扩不在这里】

「边缘外扩」看着像个几何操作（把轮廓往外推 dist 像素），但**在轮廓层做法线平移会自交**：
凹口处两侧的法线会交叉，推出去以后轮廓自己打个结，三角化直接崩。

正确位置是在**掩膜层做形态学膨胀** —— 位图膨胀天然不会自交，
膨胀完再重新追轮廓，出来的就是干净的外扩轮廓。见 mask.dilate_mask()。
本模块只管圆滑。
"""


def smooth_ring(ring, iters=1):
    """闭合环滑动平均，把像素楼梯磨圆。

    只该对**软边图**用。像素画磨圆等于把设计磨掉。

    注意：滑动平均会让环轻微收缩（每轮约千分之几的面积）。
    迭代次数因此限制在个位数，别再往上加。
    """
    cur = [(float(p[0]), float(p[1])) for p in ring]
    n_iters = int(iters)
    if n_iters <= 0:
        return cur

    for _ in range(n_iters):
        n = len(cur)
        if n < 4:
            break
        nxt = []
        for i in range(n):
            a = cur[(i - 1) % n]
            b = cur[i]
            c = cur[(i + 1) % n]
            nxt.append((
                a[0] * 0.25 + b[0] * 0.5 + c[0] * 0.25,
                a[1] * 0.25 + b[1] * 0.5 + c[1] * 0.25,
            ))
        cur = nxt
    return cur


def ring_bbox(ring):
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    return min(xs), min(ys), max(xs), max(ys)


def rings_bbox(rings):
    xs0, ys0, xs1, ys1 = [], [], [], []
    for r in rings:
        if not r:
            continue
        x0, y0, x1, y1 = ring_bbox(r)
        xs0.append(x0)
        ys0.append(y0)
        xs1.append(x1)
        ys1.append(y1)
    if not xs0:
        return (0.0, 0.0, 0.0, 0.0)
    return min(xs0), min(ys0), max(xs1), max(ys1)
