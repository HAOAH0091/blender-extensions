"""headless 造一个演示场景并存成 .blend。

    blender --background --factory-startup --python tests/make_demo.py -- <输出blend>

为什么要先存文件：GUI 截图时 Blender 启动会弹欢迎屏（splash）挡住整个视口，
而**启动时直接指定文件就不会显示欢迎屏**。所以走「先存 → 再开」。
"""

import os
import sys
import traceback

import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG_DIR)
for p in (ADDONS, PKG_DIR, HERE):          # HERE 也要加：fixture.py 就在本目录
    if p not in sys.path:
        sys.path.insert(0, p)

argv = sys.argv
OUT = None
if "--" in argv:
    rest = argv[argv.index("--") + 1:]
    if rest:
        OUT = rest[0]
if not OUT:
    OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace\ic_demo.blend"
OUT = os.path.abspath(OUT)
os.makedirs(os.path.dirname(OUT), exist_ok=True)


def make_alpha_image(name="demo_tex", w=512, h=512):
    """软边五角星（中间有洞）+ 分离小圆，用共用 fixture。"""
    from fixture import make_rgba, to_blender_pixels

    rgba = make_rgba(w, h, soft=True, with_hole=True, with_dot=True)
    img = bpy.data.images.new(name, width=w, height=h, alpha=True)
    img.pixels.foreach_set(to_blender_pixels(rgba).ravel())
    img.pack()
    return img


def build():
    ctx = bpy.context
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)

    me = bpy.data.meshes.new("PlaneMesh")
    me.from_pydata([(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)], [], [(0, 1, 2, 3)])
    me.update()
    uvl = me.uv_layers.new(name="UVMap")
    flat = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
    for poly in me.polygons:
        for li, vi in zip(poly.loop_indices, poly.vertices):
            uvl.data[li].uv = flat[vi]

    plane = bpy.data.objects.new("StarPlane", me)
    ctx.scene.collection.objects.link(plane)

    img = make_alpha_image()
    mat = bpy.data.materials.new("StarMat")
    mat.use_nodes = True
    nt = mat.node_tree
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.location = (-420, 0)
    bsdf = next((n for n in nt.nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf:
        nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    me.materials.append(mat)

    for o in ctx.selected_objects:
        o.select_set(False)
    plane.select_set(True)
    ctx.view_layer.objects.active = plane
    return plane


try:
    import image_cutter
    image_cutter.register()
    print("[demo] 插件已注册")

    plane = build()
    res = bpy.ops.image_cutter.generate()
    print("[demo] 生成：%s" % res)

    cut = bpy.data.objects.get("StarPlane_cutout")
    if cut is None:
        raise RuntimeError("没生成出对象")
    s = cut.image_cutter
    print("[demo] 面 %d / 点 %d / 轮廓 %d 圈 / %s / A %.0fms B %.0fms"
          % (len(cut.data.polygons), len(cut.data.vertices),
             s.stat_rings, s.stat_edge, s.stat_ms_a, s.stat_ms_b))

    # 源平面藏起来 —— 截图时看到的就是**生成出来的网格**，不含歧义。
    # 用 hide_viewport（显示器图标）而不是 hide_set：后台模式下 hide_set 需要 context。
    plane.hide_viewport = True
    plane.hide_render = True

    bpy.ops.wm.save_as_mainfile(filepath=OUT)
    print("[demo] 已保存：%s" % OUT)
except Exception:                                # noqa: BLE001
    traceback.print_exc()
    sys.exit(3)
