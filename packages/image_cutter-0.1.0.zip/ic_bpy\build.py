"""把算法结果变成 Blender 里的网格对象。"""

import numpy as np

import bpy


def px_to_local(points_px, img_w, img_h, size_x, size_y):
    """像素坐标 → 平面本地坐标 + UV。

    映射关系（贴图怎么贴在平面上，网格就怎么放）：

        像素左上原点            平面本地坐标                UV
        (0,0)  ──────► x       (-sx/2, +sy/2)            (0, 1)
          │                     │
          ▼ y                   ▼ y
        (w,h)                  (+sx/2, -sy/2)           (1, 0)

    像素 y 向下、平面 y 向上，这里就是那一次翻转。
    转 UV 用的是同一套值，所以贴图和新网格永远对得上。
    """
    pts = np.asarray(points_px, dtype=np.float64)
    if len(pts) == 0:
        z = np.zeros((0, 3), dtype=np.float64)
        return z, np.zeros((0, 2), dtype=np.float64)

    u = pts[:, 0] / float(img_w)
    v = 1.0 - pts[:, 1] / float(img_h)

    x = (u - 0.5) * float(size_x)
    y = (v - 0.5) * float(size_y)
    z = np.zeros(len(pts), dtype=np.float64)

    verts = np.column_stack([x, y, z])
    uvs = np.column_stack([u, v])
    return verts, uvs


def _flip_faces(faces):
    """翻转三角形绕向。

    算法层的三角形在「像素坐标（y 向下）」下是逆时针的；
    换算到 Blender（y 向上）之后会变成顺时针，法线朝 -Z，看着是背面。
    所以这里统一翻一下，让法线朝 +Z。
    """
    return [(int(a), int(c), int(b)) for (a, b, c) in faces]


def create_mesh_object(name, verts, faces, uvs, material=None, collection=None):
    """新建一个网格对象。"""
    me = bpy.data.meshes.new(name)
    _fill_mesh(me, verts, faces, uvs)

    obj = bpy.data.objects.new(name, me)
    if material is not None:
        me.materials.append(material)
    target = collection or bpy.context.scene.collection
    target.objects.link(obj)
    return obj


def update_mesh_object(obj, verts, faces, uvs):
    """就地重建已有对象的网格数据（对象身份不变）。"""
    me = obj.data
    _fill_mesh(me, verts, faces, uvs)


def _fill_mesh(me, verts, faces, uvs):
    """往 Mesh 数据块里灌几何 + UV。"""
    me.clear_geometry()

    vlist = [tuple(float(x) for x in v) for v in verts]
    flist = _flip_faces(faces)
    me.from_pydata(vlist, [], flist)
    me.update()

    if len(flist) and len(uvs):
        uvl = me.uv_layers.get("UVMap") or me.uv_layers.new(name="UVMap")
        loop_vi = np.empty(len(me.loops), dtype=np.int32)
        me.loops.foreach_get("vertex_index", loop_vi)
        uv_arr = np.asarray(uvs, dtype=np.float32)
        uvl.data.foreach_set("uv", uv_arr[loop_vi].ravel())

    me.update()

    # 平面网格，平面着色最直观
    for poly in me.polygons:
        poly.use_smooth = False


def ensure_material_has_alpha(mat, image):
    """确保材质把 alpha 接到输出（否则贴图的透明边在 EEVEE 里不生效）。

    做法：只补缺失的那一环 —— 图片节点的 Alpha 输出 → Principled 的 Alpha 输入。
    已有连接不碰，免得覆盖用户自己的节点编排。
    """
    if mat is None or not mat.use_nodes or mat.node_tree is None or image is None:
        return False

    nt = mat.node_tree
    tex = None
    principled = None
    for node in nt.nodes:
        if node.type == "TEX_IMAGE" and node.image is image:
            tex = node
        elif node.type == "BSDF_PRINCIPLED":
            principled = node

    if tex is None or principled is None:
        return False
    if "Alpha" not in principled.inputs:
        return False

    alpha_in = principled.inputs["Alpha"]
    if alpha_in.is_linked:
        return False
    if "Alpha" not in tex.outputs:
        return False

    nt.links.new(tex.outputs["Alpha"], alpha_in)

    # 顺带把混合模式调对，透明边才真的看得见
    try:
        mat.blend_method = "BLEND"
    except (AttributeError, TypeError):
        pass
    try:
        mat.show_transparent_back = False
    except (AttributeError, TypeError):
        pass
    return True
