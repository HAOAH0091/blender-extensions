"""对生成出来的网格做数值体检 —— 别靠眼睛判断「中心到底有没有洞」。

    blender --background <blend> --python tests/check_mesh.py

判据：
  · 星形内部（不含洞）的点，应该几乎全部被三角形盖住
  · 洞里的点，也应该被盖住（这是「中心不留洞」的要求）
  · 星形外的点（但落在包围盒内），应该基本没被盖住
"""

import os
import sys

import bpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG_DIR)
for p in (ADDONS, PKG_DIR, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from fixture import star_polygon  # noqa: E402

# 插件要注册上，对象的自定义属性才有地方挂
try:
    import image_cutter
    image_cutter.register()
except Exception as exc:                      # noqa: BLE001
    print("插件注册跳过：%s" % exc)

W = H = 512
cut = bpy.data.objects.get("StarPlane_cutout")
if cut is None:
    print("找不到 StarPlane_cutout")
    sys.exit(1)

me = cut.data
nv = len(me.vertices)
co = np.empty(nv * 3, dtype=np.float32)
me.vertices.foreach_get("co", co)
co = co.reshape(-1, 3)

quads = []
for poly in me.polygons:
    v = list(poly.vertices)
    for k in range(1, len(v) - 1):
        quads.append((v[0], v[k], v[k + 1]))
tris = np.asarray(quads, dtype=np.int64)
print("对象 %s：顶点 %d，面 %d（三角化后 %d）" % (cut.name, nv, len(me.polygons), len(tris)))


def px_to_local(px, py):
    u = px / float(W)
    v = 1.0 - py / float(H)
    sx, sy = 2.0, 2.0
    return np.array([(u - 0.5) * sx, (v - 0.5) * sy])


def covered(pt):
    """点是否被某个三角形盖住（三层同向判定）。"""
    if len(tris) == 0:
        return False
    a = co[tris[:, 0]][:, :2]
    b = co[tris[:, 1]][:, :2]
    c = co[tris[:, 2]][:, :2]
    p = pt
    d1 = (p[0] - b[:, 0]) * (a[:, 1] - b[:, 1]) - (a[:, 0] - b[:, 0]) * (p[1] - b[:, 1])
    d2 = (p[0] - c[:, 0]) * (b[:, 1] - c[:, 1]) - (b[:, 0] - c[:, 0]) * (p[1] - c[:, 1])
    d3 = (p[0] - a[:, 0]) * (c[:, 1] - a[:, 1]) - (c[:, 0] - a[:, 0]) * (p[1] - a[:, 1])
    neg = (d1 < 0) | (d2 < 0) | (d3 < 0)
    pos = (d1 > 0) | (d2 > 0) | (d3 > 0)
    return bool(np.any(~(neg & pos)))


cx, cy = W * 0.40, H * 0.44
outer = W * 0.345
inner = outer * 0.382
poly = star_polygon(cx, cy, outer, inner, k=5)


def in_star(px, py):
    inside = False
    n = len(poly)
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        if (y0 > py) != (y1 > py):
            xc = (x1 - x0) * (py - y0) / (y1 - y0) + x0
            if px < xc:
                inside = not inside
    return inside


def in_hole(px, py):
    return np.hypot(px - cx, py - cy) < W * 0.085


# 三组采样
inside_pts, hole_pts, outside_pts = [], [], []
rng = np.random.default_rng(7)
for _ in range(4000):
    px = rng.uniform(cx - outer * 1.1, cx + outer * 1.1)
    py = rng.uniform(cy - outer * 1.1, cy + outer * 1.1)
    if in_hole(px, py):
        hole_pts.append((px, py))
    elif in_star(px, py):
        inside_pts.append((px, py))
    else:
        outside_pts.append((px, py))

print("\n采样点覆盖情况：")
rows = [
    ("星形内部（不含洞）", inside_pts),
    ("中心洞里", hole_pts),
    ("星形之外（包围盒内）", outside_pts),
]
for label, pts in rows:
    if not pts:
        print("  %-22s 无样本" % label)
        continue
    hit = sum(1 for (px, py) in pts if covered(px_to_local(px, py)))
    print("  %-22s %5d 点，被网格盖住 %5d 个 = %5.1f%%"
          % (label, len(pts), hit, hit / len(pts) * 100))

# 轮廓圈数 / 洞有没有被丢掉
if hasattr(cut, "image_cutter"):
    s = cut.image_cutter
    print("\n插件状态：轮廓 %d 圈 / 三角形 %d / 顶点 %d / 边缘判定 %s"
          % (s.stat_rings, s.stat_faces, s.stat_points, s.stat_edge))
else:
    print("\n（插件未注册，跳过自定义属性）")

# 拿贴图自己的 alpha 当**地面真值**，跟网格覆盖对比 —— 不靠我重建的形状
imgs = [i for i in bpy.data.images if i.name.startswith("demo_tex")]
if imgs:
    img = imgs[0]
    iw, ih = int(img.size[0]), int(img.size[1])
    buf = np.empty(iw * ih * 4, dtype=np.float32)
    img.pixels.foreach_get(buf)
    iarr = buf.reshape(ih, iw, 4)
    tex_alpha = iarr[:, :, 3][::-1, :]        # 翻成「行 0 = 图的上边」

    def tex_solid(px, py):
        ix = min(iw - 1, max(0, int(px / W * iw)))
        iy = min(ih - 1, max(0, int(py / H * ih)))
        return tex_alpha[iy, ix] > 0.5

    print("\n以**贴图 alpha** 为真值重新比对：")
    for label, pts in rows:
        if not pts:
            continue
        solid = sum(1 for (px, py) in pts if tex_solid(px, py))
        hit = sum(1 for (px, py) in pts if covered(px_to_local(px, py)))
        print("  %-22s 贴图认为实心 %5d / 网格盖住 %5d"
              % (label, solid, hit))

    px = int(cx / W * iw)
    py = int(cy / H * ih)
    print("\n贴图在洞中心 (%d,%d) 的 RGBA = %s"
          % (px, py, np.round(tex_alpha[py, px], 3)))

# ---- 边界对位：网格的横向范围 vs 形状应有的范围 ----
def local_to_px(lx, ly):
    u = lx / 2.0 + 0.5
    v = ly / 2.0 + 0.5
    return u * W, (1.0 - v) * H


xs = co[:, 0]
ys = co[:, 1]
mx0, mx1 = local_to_px(xs.min(), 0)[0], local_to_px(xs.max(), 0)[0]
my0 = local_to_px(0, ys.max())[1]
my1 = local_to_px(0, ys.min())[1]
print("\n网格范围（像素）：x %.0f..%.0f   y %.0f..%.0f" % (mx0, mx1, my0, my1))

pxs = [p[0] for p in poly]
pys = [p[1] for p in poly]
print("五角星理论范围：  x %.0f..%.0f   y %.0f..%.0f"
      % (min(pxs), max(pxs), min(pys), max(pys)))
print("偏差：左 %.1f  右 %.1f  上 %.1f  下 %.1f  像素"
      % (min(pxs) - mx0, mx1 - max(pxs), min(pys) - my0, my1 - max(pys)))

# ---- 哪儿溢出了：画张字符图，别靠猜 ----
print("\n溢出位置图（每格 8x8 像素）：")
print("  # = 形状内   o = 洞   + = 网格盖住但形状外（溢出）   . = 空")
step = 8
for gy in range(0, H, step * 2):
    line = ""
    for gx in range(0, W, step):
        px = gx + step / 2.0
        py = gy + step / 2.0
        if in_hole(px, py):
            line += "o"
        elif in_star(px, py):
            line += "#"
        elif covered(px_to_local(px, py)):
            line += "+"
        else:
            line += "."
    print("  " + line)

# ---- 密度扫描：验证「凹角外溢」是不是只是分辨率问题 ----
# 猜想：保留三角形只看重心在不在形状内 → 密度粗时，凹口附近的边界三角形
#       会鼓出去一截。密度加细应该收敛。
print("\n密度扫描（同一张图，只改网格密度）：")
if hasattr(cut, "image_cutter"):
    # 扫描时抽稀样本，不然 4000 点 × 5 档 × 上千三角形太慢
    outside_pts = outside_pts[::3]
    inside_pts = inside_pts[::2]
    from image_cutter.ic_ui import ops as ic_ops
    s = cut.image_cutter
    saved = s.density
    for dens in (0.2, 0.4, 0.55, 0.75, 1.0):
        s.density = dens
        ic_ops.rebuild_object(cut, bpy.context, force=True)
        me2 = cut.data
        n2 = len(me2.vertices)
        c2 = np.empty(n2 * 3, dtype=np.float32)
        me2.vertices.foreach_get("co", c2)
        c2 = c2.reshape(-1, 3)
        quads2 = []
        for poly2 in me2.polygons:
            vv = list(poly2.vertices)
            for k2 in range(1, len(vv) - 1):
                quads2.append((vv[0], vv[k2], vv[k2 + 1]))
        t2 = np.asarray(quads2, dtype=np.int64)

        out_hit = 0
        for (qpx, qpy) in outside_pts:
            p = px_to_local(qpx, qpy)
            aa = c2[t2[:, 0]][:, :2]
            bb = c2[t2[:, 1]][:, :2]
            cc = c2[t2[:, 2]][:, :2]
            d1 = (p[0]-bb[:,0])*(aa[:,1]-bb[:,1]) - (aa[:,0]-bb[:,0])*(p[1]-bb[:,1])
            d2 = (p[0]-cc[:,0])*(bb[:,1]-cc[:,1]) - (bb[:,0]-cc[:,0])*(p[1]-cc[:,1])
            d3 = (p[0]-aa[:,0])*(cc[:,1]-aa[:,1]) - (cc[:,0]-aa[:,0])*(p[1]-aa[:,1])
            neg = (d1 < 0) | (d2 < 0) | (d3 < 0)
            pos = (d1 > 0) | (d2 > 0) | (d3 > 0)
            if bool(np.any(~(neg & pos))):
                out_hit += 1
        inside_hit = 0
        for (qpx, qpy) in inside_pts:
            p = px_to_local(qpx, qpy)
            aa = c2[t2[:, 0]][:, :2]
            bb = c2[t2[:, 1]][:, :2]
            cc = c2[t2[:, 2]][:, :2]
            d1 = (p[0]-bb[:,0])*(aa[:,1]-bb[:,1]) - (aa[:,0]-bb[:,0])*(p[1]-bb[:,1])
            d2 = (p[0]-cc[:,0])*(bb[:,1]-cc[:,1]) - (bb[:,0]-cc[:,0])*(p[1]-cc[:,1])
            d3 = (p[0]-aa[:,0])*(cc[:,1]-aa[:,1]) - (cc[:,0]-aa[:,0])*(p[1]-aa[:,1])
            neg = (d1 < 0) | (d2 < 0) | (d3 < 0)
            pos = (d1 > 0) | (d2 > 0) | (d3 > 0)
            if bool(np.any(~(neg & pos))):
                inside_hit += 1
        print("  密度 %.2f（边长约 %4.1f px）  面 %5d  |  形状内盖住 %5.1f%%  "
              "形状外溢出 %5d 点"
              % (dens, s.spacing(), len(me2.polygons),
                 inside_hit / len(inside_pts) * 100, out_hit))
    s.density = saved
    ic_ops.rebuild_object(cut, bpy.context, force=True)
