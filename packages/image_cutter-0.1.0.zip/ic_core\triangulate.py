"""把轮廓铺成三角网格。

思路（约束 Delaunay 路线）：
  1. 轮廓点按网格尺度**加密**，当边界点
  2. 形状内部按密度**撒点**
  3. 全部点一起做 Delaunay 三角化
  4. 只保留**重心落在形状内**的三角形

第 4 步是关键：凹形和洞因此天然被正确处理，
不用为「这里凹进去」「那里有个洞」写任何特例。

按需求「中心不留洞」：调用方只传外环（洞在 outline.split_outer 就被丢了），
所以内部一律填满。
"""

import math
import time

import numpy as np

from .outline import point_in_ring


# --------------------------------------------------------------------------
# 批量几何判定（向量化，比逐点跑 Python 循环快一两个数量级）
# --------------------------------------------------------------------------

def points_in_ring(pts, ring):
    """批量射线法。pts: (N,2) float 数组 → (N,) bool。"""
    pts = np.asarray(pts, dtype=np.float64)
    if pts.size == 0 or len(ring) < 3:
        return np.zeros(len(pts), dtype=bool)

    x = pts[:, 0]
    y = pts[:, 1]
    inside = np.zeros(len(pts), dtype=bool)

    n = len(ring)
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        if y0 == y1:
            continue
        cond = (y0 > y) != (y1 > y)
        if not cond.any():
            continue
        xc = (x1 - x0) * (y - y0) / (y1 - y0) + x0
        inside ^= cond & (x < xc)
    return inside


def points_in_any_ring(pts, rings):
    ok = np.zeros(len(pts), dtype=bool)
    for r in rings:
        if len(r) >= 3:
            ok |= points_in_ring(pts, r)
    return ok


def _dist_to_rings(pt, rings):
    """点到所有轮廓线段的最短距离（单点，用于内部撒点时剔掉贴边的）。"""
    best = float("inf")
    x, y = pt
    for ring in rings:
        n = len(ring)
        for k in range(n):
            x0, y0 = ring[k]
            x1, y1 = ring[(k + 1) % n]
            dx = x1 - x0
            dy = y1 - y0
            l2 = dx * dx + dy * dy
            if l2 <= 1e-12:
                d = math.hypot(x - x0, y - y0)
            else:
                t = ((x - x0) * dx + (y - y0) * dy) / l2
                t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
                d = math.hypot(x - (x0 + t * dx), y - (y0 + t * dy))
            if d < best:
                best = d
    return best


# --------------------------------------------------------------------------
# 点集生成
# --------------------------------------------------------------------------

def densify_ring(ring, max_len):
    """按最大边长细分轮廓，让边界贴合网格尺度。

    不这么做的话，会出现「粗边界 + 细网格」的硬拼缝：
    边界还是几十像素一根直线段，内部却铺满小三角，接缝处全是细长条。
    """
    if max_len <= 1e-6:
        return [(float(p[0]), float(p[1])) for p in ring]

    out = []
    n = len(ring)
    for k in range(n):
        x0, y0 = ring[k]
        x1, y1 = ring[(k + 1) % n]
        out.append((float(x0), float(y0)))
        seg = math.hypot(x1 - x0, y1 - y0)
        steps = int(seg / max_len)
        for m in range(1, steps + 1):
            t = m / (steps + 1)
            out.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    return out


def interior_points(rings, spacing, edge_clearance=0.45):
    """在形状内部按间距撒错排点。

    错排（每行偏移半格）= 近似正三角排布，三角化后形状比正方格好看。
    edge_clearance: 离边界近于 spacing×这个系数的点剔掉，避免生成细长三角。
    """
    if spacing <= 1e-6:
        return np.zeros((0, 2), dtype=np.float64)

    xs0 = min(p[0] for r in rings for p in r)
    ys0 = min(p[1] for r in rings for p in r)
    xs1 = max(p[0] for r in rings for p in r)
    ys1 = max(p[1] for r in rings for p in r)

    need = spacing * edge_clearance
    out = []
    row = 0
    y = ys0 + spacing * 0.5
    while y < ys1:
        offset = (row % 2) * spacing * 0.5
        x = xs0 + spacing * 0.5 + offset
        while x < xs1:
            out.append((x, y))
            x += spacing
        y += spacing
        row += 1

    if not out:
        return np.zeros((0, 2), dtype=np.float64)

    cand = np.asarray(out, dtype=np.float64)
    keep = points_in_any_ring(cand, rings)
    cand = cand[keep]
    if len(cand) == 0:
        return cand

    # 剔掉贴边太近的（jl 无法向量化：需要逐点算线段距离）
    survivors = [p for p in cand if _dist_to_rings(p, rings) >= need]
    if not survivors:
        return np.zeros((0, 2), dtype=np.float64)
    return np.asarray(survivors, dtype=np.float64)


# --------------------------------------------------------------------------
# Delaunay（Bowyer-Watson 增量式）
# --------------------------------------------------------------------------

def delaunay_2d(points):
    """Bowyer-Watson 增量式 Delaunay 三角化。

    返回三角形索引列表 [(i, j, k), ...]，索引指向传入的 points。
    只返回用真点构成的三角形（超级三角形的顶点已被剔除）。

    性能说明：每个点插入时，对**当时所有**三角形做一次向量化的内切圆测试，
    再压缩存活数组。是 O(n²) 的元素操作，但全部走 numpy，
    几千点的量级是零点几秒（纯 Python 循环写同样逻辑会慢两个数量级）。
    """
    pts = np.asarray(points, dtype=np.float64)
    n = len(pts)
    if n < 3:
        return []

    mn = pts.min(axis=0)
    mx = pts.max(axis=0)
    size = float(max(mx[0] - mn[0], mx[1] - mn[1]))
    if size <= 1e-9:
        size = 1.0
    cx = (mn[0] + mx[0]) * 0.5
    cy = (mn[1] + mx[1]) * 0.5
    k = size * 30.0

    all_pts = np.vstack([
        pts,
        [cx - k, cy - k],
        [cx + k, cy - k],
        [cx, cy + k],
    ])
    ax = all_pts[:, 0]
    ay = all_pts[:, 1]

    cap = 2 * n + 64
    tris = np.empty((cap, 3), dtype=np.int32)
    count = 1
    tris[0] = (n, n + 1, n + 2)

    for i in range(n):
        px = ax[i]
        py = ay[i]
        view = tris[:count]

        a0 = ax[view[:, 0]] - px
        a1 = ay[view[:, 0]] - py
        b0 = ax[view[:, 1]] - px
        b1 = ay[view[:, 1]] - py
        c0 = ax[view[:, 2]] - px
        c1 = ay[view[:, 2]] - py
        det = ((a0 * a0 + a1 * a1) * (b0 * c1 - b1 * c0)
               - (b0 * b0 + b1 * b1) * (a0 * c1 - a1 * c0)
               + (c0 * c0 + c1 * c1) * (a0 * b1 - a1 * b0))

        bad_mask = det > 0.0
        if not bad_mask.any():
            # 正常不会发生：超级三角形覆盖所有点，至少有一个坏三角形
            continue

        bad_idx = np.nonzero(bad_mask)[0]
        bad_tris = view[bad_idx]

        # 坏三角形的边：去掉成对出现的（内部共享边），剩下的是空洞边界
        e_u = np.concatenate([bad_tris[:, 0], bad_tris[:, 1], bad_tris[:, 2]])
        e_v = np.concatenate([bad_tris[:, 1], bad_tris[:, 2], bad_tris[:, 0]])
        key = (np.minimum(e_u, e_v).astype(np.int64) * (n + 16)
               + np.maximum(e_u, e_v).astype(np.int64))
        _, inv, cnt = np.unique(key, return_inverse=True, return_counts=True)
        boundary_mask = cnt[inv] == 1
        bu = e_u[boundary_mask]
        bv = e_v[boundary_mask]

        # 删掉坏三角形（布尔压缩）
        alive = np.ones(count, dtype=bool)
        alive[bad_idx] = False
        new_count = int(alive.sum())
        tris[:new_count] = view[alive]
        count = new_count

        # 空洞边界 + 新点 → 新三角形（保证 CCW）
        m = len(bu)
        if m == 0:
            continue
        if count + m > cap:
            cap = count + m + 2 * n + 64
            grown = np.empty((cap, 3), dtype=np.int32)
            grown[:count] = tris[:count]
            tris = grown

        new_t = np.empty((m, 3), dtype=np.int32)
        new_t[:, 0] = bu
        new_t[:, 1] = bv
        new_t[:, 2] = i
        p0 = all_pts[new_t[:, 0]]
        p1 = all_pts[new_t[:, 1]]
        p2 = all_pts[new_t[:, 2]]
        cr = ((p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1])
              - (p1[:, 1] - p0[:, 1]) * (p2[:, 0] - p0[:, 0]))
        flip = cr <= 0.0
        if flip.any():
            new_t[flip] = new_t[flip][:, [1, 0, 2]]

        tris[count:count + m] = new_t
        count += m

    view = tris[:count]
    real = np.all(view < n, axis=1)
    return [tuple(int(x) for x in t) for t in view[real]]


# --------------------------------------------------------------------------
# 组装
# --------------------------------------------------------------------------

def build_mesh(rings, spacing, boundary_ratio=0.9):
    """轮廓 → 网格数据。

    rings: 只放**外环**（洞由调用方在 split_outer 阶段丢弃）
    spacing: 目标边长（像素）
    boundary_ratio: 边界加密的目标边长 = spacing × 该系数

    返回 dict：
      points / faces / stats
      faces 里的索引指向 points
    """
    t_start = time.perf_counter()
    rings = [r for r in rings if len(r) >= 3]
    if not rings or spacing <= 1e-6:
        return {"points": np.zeros((0, 2)), "faces": [], "stats": {"boundary": 0, "inner": 0, "faces": 0, "ms": 0.0}}

    boundary = []
    for r in rings:
        boundary.extend(densify_ring(r, spacing * boundary_ratio))
    bpts = np.asarray(boundary, dtype=np.float64)

    inner = interior_points(rings, spacing)
    if len(inner):
        pts = np.vstack([bpts, inner])
    else:
        pts = bpts

    # 去重：边界加密点和内部撒点可能撞在同一个位置，
    # 重合点会让 Delaunay 生成零面积三角形（退化），必须先清掉
    if len(pts) > 1:
        _, uniq_idx = np.unique(np.round(pts, 4), axis=0, return_index=True)
        pts = pts[np.sort(uniq_idx)]

    t_tri0 = time.perf_counter()
    tris = delaunay_2d(pts)

    faces = []
    if tris:
        idx = np.asarray(tris, dtype=np.int64)
        tri_pts = pts[idx]
        cents = tri_pts.mean(axis=1)           # 重心
        keep = points_in_any_ring(cents, rings)

        # 再去掉退化面（面积小到没意义），它们会让 Blender 报错或渲染出黑点
        a = tri_pts[:, 0]
        b = tri_pts[:, 1]
        c = tri_pts[:, 2]
        area2 = np.abs((b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1])
                       - (b[:, 1] - a[:, 1]) * (c[:, 0] - a[:, 0]))
        keep &= area2 > 1e-6

        faces = [tris[k] for k in np.nonzero(keep)[0]]
    t_end = time.perf_counter()

    return {
        "points": pts,
        "faces": faces,
        "stats": {
            "boundary": int(len(bpts)),
            "inner": int(len(inner)),
            "faces": len(faces),
            "ms_triangulate": round((t_end - t_tri0) * 1000.0, 1),
            "ms_total": round((t_end - t_start) * 1000.0, 1),
        },
    }
