"""alpha → 二值掩膜，并判断这张图是「软边画」还是「像素画」。

为什么要判断软硬边：**软边才该平滑，硬边保留楼梯**。
对像素画平滑会把设计磨没，对绘画不平滑会留下难看的锯齿。
"""

import numpy as np


def build_mask(alpha, threshold=0.5):
    """alpha → bool 掩膜。

    alpha: (H, W) float，取值 0..1（或 0..255，函数内自动归一）
    threshold: 超过它算「实心」

    返回 (mask, stats)，stats 里有空像素数等，给 UI 显示用。
    """
    a = np.asarray(alpha, dtype=np.float32)
    if a.size == 0:
        raise ValueError("alpha 为空数组")
    if a.max() > 1.0001:            # 0..255 进来的，归一
        a = a / 255.0
    a = np.clip(a, 0.0, 1.0)

    mask = a >= float(threshold)
    stats = {
        "total": int(mask.size),
        "solid": int(mask.sum()),
        "empty": int(mask.size - mask.sum()),
    }
    return mask, stats


def edge_style(alpha, mask, sample_cap=200000):
    """判断这张图是「软边」（画出来的）还是「硬边」（像素画）。

    判据：看**轮廓附近**的 alpha 过渡是渐变还是突变。
    具体做法——取那些「自己实心、但四邻里有空心」的边界像素，
    统计它们 alpha 落在中间地带（0.15~0.85）的比例。
    比例高 = 边缘是渐变的 = 软边，该平滑；比例低 = 硬边，保留楼梯。

    sample_cap: 边界像素太多时抽样，避免大图上卡住。
    返回 (style, ratio)：style 是 'soft' / 'hard'，ratio 是中间地带占比。
    """
    a = np.asarray(alpha, dtype=np.float32)
    if a.max() > 1.0001:
        a = a / 255.0
    a = np.clip(a, 0.0, 1.0)
    m = np.asarray(mask, dtype=bool)

    if m.size == 0 or not m.any():
        return "hard", 0.0

    # 边界像素 = 实心，且「四邻不全是实心」（至少一侧空着 / 或贴着图像边缘）
    # 注意是「四邻全实心」取反，不是「四邻里有实心」——后者会挑出孤立点
    all_nb_solid = np.ones_like(m)
    all_nb_solid[0, :] = False      # 图像外侧视作空心，贴边的形状也算边界
    all_nb_solid[-1, :] = False
    all_nb_solid[:, 0] = False
    all_nb_solid[:, -1] = False
    all_nb_solid[1:, :] &= m[:-1, :]
    all_nb_solid[:-1, :] &= m[1:, :]
    all_nb_solid[:, 1:] &= m[:, :-1]
    all_nb_solid[:, :-1] &= m[:, 1:]
    boundary = m & ~all_nb_solid
    if not boundary.any():
        return "hard", 0.0

    vals = a[boundary]
    if vals.size > sample_cap:
        step = int(np.ceil(vals.size / sample_cap))
        vals = vals[::step]

    mid = ((vals > 0.15) & (vals < 0.85))
    ratio = float(mid.sum()) / float(vals.size) if vals.size else 0.0
    return ("soft" if ratio >= 0.18 else "hard"), ratio


def dilate_mask(mask, radius):
    """形态学膨胀 —— 「边缘外扩」就靠它。

    ⚠️ 外扩**必须**在这一层做，不能在轮廓层把点沿法线往外平移：
    凹口处两侧法线会交叉，推出去轮廓自己打个结，三角化直接崩。
    位图膨胀天然不会自交，膨胀完重新追轮廓，出来就是干净的。

    实现用「横向 r 轮 + 纵向 r 轮」的可分离写法，结果是方形结构元素
    （不是正圆，但对这个用途没差别，速度快一个量级）。
    """
    r = int(round(radius))
    out = np.array(mask, dtype=bool, copy=True)
    if r <= 0:
        return out
    for _ in range(r):
        out[:, 1:] |= out[:, :-1]
        out[:, :-1] |= out[:, 1:]
    for _ in range(r):
        out[1:, :] |= out[:-1, :]
        out[:-1, :] |= out[1:, :]
    return out


def apply_guide(mask, guide_mask, mode="replace"):
    """把用户用钢笔画出来的引导并进掩膜。

    guide_mask: (H, W) 三态 int8 ——  0=不管  +1=强制实心  -1=强制空心
    mode='replace'  引导覆盖自动结果（"我画的就是准的"）
    mode='solid_only'  只让引导把区域变实心，不挖空（"我补一块进去"）

    返回新掩膜（不改原数组，避免调用方拿到被就地改过的数据）。
    """
    out = np.array(mask, dtype=bool, copy=True)
    if guide_mask is None:
        return out
    g = np.asarray(guide_mask)
    if g.shape != out.shape:
        raise ValueError("引导掩膜尺寸和主掩膜不一致：%s vs %s" % (g.shape, out.shape))

    keep = g > 0
    drop = g < 0
    out[keep] = True
    if mode == "replace":
        out[drop] = False
    return out
