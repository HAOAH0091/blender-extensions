"""与 Blender 打交道的薄层：取图、读像素、建网格、挂材质。

算法全在 ic_core，这边只做「翻译」：把 bpy 的数据结构搬进搬出，
不掺任何几何逻辑，方便算法层单独测试。
"""

import numpy as np

import bpy


def find_image_slot(obj):
    """从物体的材质里找第一个「图片纹理」节点。

    返回 (image, node, material)，找不到返回 (None, None, None)。
    找的是材质节点树里的 TEX_IMAGE 节点 —— 这是「这个平面贴了哪张图」的
    最可靠来源，比看 object.data 靠谱（网格本身不存贴图信息）。
    """
    if obj is None:
        return None, None, None
    for slot in obj.material_slots:
        mat = slot.material
        if mat is None or not mat.use_nodes or mat.node_tree is None:
            continue
        for node in mat.node_tree.nodes:
            if node.type == "TEX_IMAGE" and node.image is not None:
                return node.image, node, mat
    return None, None, None


def image_key(image):
    """给图算一个短标识，用来做缓存键。

    用「名字 + 尺寸 + 路径」组合：改名 / 换图 / 重导都会变，
    但不做逐像素哈希（那太慢，而且我们只在参数变化时重算）。
    """
    if image is None:
        return "none"
    return "%s|%dx%d|%s" % (
        image.name,
        int(image.size[0]),
        int(image.size[1]),
        image.filepath or "",
    )


def read_alpha(image):
    """读图片的 alpha 通道。

    返回 (alpha, info)：
      alpha: (H, W) float32，**左上原点**（和看图一致）
      info:  dict，含尺寸、是否真有 alpha、取值范围

    Blender 的 image.pixels 是 **自下而上** 存的（第一个像素是左下角），
    而且恒为 RGBA 四通道（哪怕原图是 JPG）。所以这里要翻 y。
    """
    if image is None:
        raise ValueError("没有图片")

    if not image.has_data:
        image.reload()

    w, h = int(image.size[0]), int(image.size[1])
    if w <= 0 or h <= 0:
        raise ValueError("图片尺寸为 0，可能没加载成功：%s" % image.name)

    buf = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(buf)
    rgba = buf.reshape(h, w, 4)

    alpha = rgba[:, :, 3][::-1, :]          # 翻成左上原点
    amax = float(alpha.max()) if alpha.size else 0.0
    amin = float(alpha.min()) if alpha.size else 0.0
    opaque = (amin >= 0.999)

    info = {
        "width": w,
        "height": h,
        "has_alpha": not opaque,
        "alpha_min": round(amin, 4),
        "alpha_max": round(amax, 4),
        "depth": int(image.depth),
        "name": image.name,
    }
    return alpha, info


def object_local_size(obj):
    """物体**本地**包围盒的尺寸。用它把像素映射回平面大小。

    用本地坐标而不是 obj.dimensions：后者含缩放，会把网格建歪。
    """
    if obj is None or obj.type != "MESH" or len(obj.data.vertices) == 0:
        return (1.0, 1.0)
    xs = []
    ys = []
    zs = []
    for v in obj.data.vertices:
        xs.append(v.co.x)
        ys.append(v.co.y)
        zs.append(v.co.z)
    sx = (max(xs) - min(xs)) or 1.0
    sy = (max(ys) - min(ys)) or 1.0
    return (float(sx), float(sy))
