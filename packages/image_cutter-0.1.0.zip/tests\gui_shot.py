"""打开一个已存在的 .blend 并截图。

    blender <文件.blend> --python tests/gui_shot.py -- <输出目录>

⚠️ 必须是「命令行直接给文件」这种启动方式 —— 这样 Blender 不显示欢迎屏。
   用 --python 里 bpy.ops.wm.open_mainfile() 打开是不行的，欢迎屏还在。

⚠️ 另一个坑：`--python` 脚本在**顶层**执行时 context 残缺（没有 active_object），
   而 `bpy.app.timers` 回调里的 context 反而是完整的。所以干活全放 timer 里。
"""

import os
import sys
import traceback

import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.dirname(HERE)
ADDONS = os.path.dirname(PKG_DIR)
for p in (ADDONS, PKG_DIR, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

argv = sys.argv
OUT = None
if "--" in argv:
    rest = argv[argv.index("--") + 1:]
    if rest:
        OUT = rest[0]
if not OUT:
    OUT = r"F:\desktop\BaiduSyncdisk\IDES\workspace"
OUT = os.path.abspath(OUT)
os.makedirs(OUT, exist_ok=True)


def log(msg):
    print("[shot] %s" % msg)
    sys.stdout.flush()


def top_view(area, tight=False):
    """把 3D 视口摆成正对着看。

    用官方 operator，并且带**完整**的 context override ——
    只给 area 不给 region 的话 `view3d.view_axis` 的 poll 会直接失败。

    ⚠️ 别手动设 `region_3d.view_distance`：正交模式下它不是「相机距离」，
       设了之后东西会跑出画面（我因此截到过一张空视口）。
       用 `view_all` / `view_selected` 让 Blender 自己算取景范围。
    """
    sp = area.spaces[0]
    region = next((r for r in area.regions if r.type == "WINDOW"), None)

    try:
        win = bpy.context.window_manager.windows[0]
        with bpy.context.temp_override(window=win, screen=win.screen,
                                       area=area, region=region):
            bpy.ops.view3d.view_axis(type="TOP")
            if tight:
                bpy.ops.view3d.view_selected()
            else:
                bpy.ops.view3d.view_all(center=False)
        log("视角已设定（%s）" % ("贴近选中" if tight else "框住全部"))
    except Exception as exc:                     # noqa: BLE001
        log("切视角失败：%s" % exc)

    try:
        sp.shading.type = "MATERIAL"
        sp.overlay.show_overlays = False
        sp.show_region_ui = True
    except Exception as exc:                     # noqa: BLE001
        log("设置视口参数失败（继续）：%s" % exc)


def view3d_area():
    for area in bpy.context.screen.areas:
        if area.type == "VIEW_3D":
            return area
    return None


def shoot(name):
    """截图。

    ⚠️ 必须先强制重绘：timer 里改了视口状态，但屏幕合成还没走完，
       直接截图会拿到**上一帧**（判据：新旧 PNG 字节数一模一样）。
       `redraw_timer` 是官方那条「立刻把窗口重画并交换缓冲」的路子。
    """
    area = view3d_area()
    if area is not None:
        try:
            area.tag_redraw()
        except Exception:                        # noqa: BLE001
            pass
    try:
        bpy.ops.wm.redraw_timer(type="DRAW_WIN_SWAP", iterations=3)
    except Exception as exc:                     # noqa: BLE001
        log("强制重绘失败（继续截图）：%s" % exc)

    p = os.path.join(OUT, name)
    try:
        bpy.ops.screen.screenshot(filepath=p)
    except Exception as exc:                     # noqa: BLE001
        log("截图失败：%s" % exc)
        return
    ok = os.path.exists(p)
    log("截图 %s  %s  %d bytes" % (ok, p, os.path.getsize(p) if ok else 0))
    sys.stdout.flush()


def set_alpha_link(enabled):
    """把「贴图 alpha → 材质输出」这条连线接上 / 摘掉。

    摘掉之后表面就是完全不透明 —— 用它来**证明网格几何本身是填满的**
    （不然洞那里因为贴图 alpha=0 而透明，看不出几何到底有没有洞）。
    """
    cut = bpy.data.objects.get("StarPlane_cutout")
    if cut is None or not cut.data.materials:
        return False
    mat = cut.data.materials[0]
    if not mat.use_nodes or mat.node_tree is None:
        return False
    nt = mat.node_tree
    principled = next((n for n in nt.nodes if n.type == "BSDF_PRINCIPLED"), None)
    if principled is None or "Alpha" not in principled.inputs:
        return False
    sock = principled.inputs["Alpha"]

    existing = [ln for ln in nt.links if ln.to_socket == sock]
    if enabled and not existing:
        tex = next((n for n in nt.nodes if n.type == "TEX_IMAGE"), None)
        if tex is None or "Alpha" not in tex.outputs:
            return False
        nt.links.new(tex.outputs["Alpha"], sock)
        return True
    if not enabled and existing:
        for ln in existing:
            nt.links.remove(ln)
        return True
    return None


def set_wireframe(on):
    area = view3d_area()
    if area is None:
        return
    sp = area.spaces[0]
    try:
        sp.overlay.show_overlays = bool(on)
        if on:
            sp.overlay.show_wireframes = True
            sp.overlay.wireframe_threshold = 1.0
        sp.shading.show_object_outline = False
    except Exception as exc:                     # noqa: BLE001
        log("设置线框失败：%s" % exc)


STEP = {"n": 0}


def tick():
    try:
        n = STEP["n"]

        if n == 0:
            try:
                import image_cutter
                image_cutter.register()
                log("插件已注册（打开的文件里对象已存在）")
            except Exception as exc:             # noqa: BLE001
                log("注册失败：%s" % exc)

            cut = bpy.data.objects.get("StarPlane_cutout")
            if cut is not None:
                try:
                    for o in bpy.context.selected_objects:
                        o.select_set(False)
                    cut.select_set(True)
                    bpy.context.view_layer.objects.active = cut
                except Exception as exc:         # noqa: BLE001
                    log("选中失败：%s" % exc)
                log("对象：面 %d / 点 %d / UV %d 层"
                    % (len(cut.data.polygons), len(cut.data.vertices),
                       len(cut.data.uv_layers)))
            STEP["n"] = 1
            return 0.4

        if n == 1:
            area = view3d_area()
            if area is not None:
                top_view(area, tight=False)
            set_wireframe(False)
            set_alpha_link(True)
            STEP["n"] = 2
            return 1.6

        if n == 2:
            # 靠贴图渲染的样子（洞那里应该是透的 —— 因为 alpha 被保留了）
            shoot("ic_gui_01_textured.png")
            STEP["n"] = 3
            return 1.2

        if n == 3:
            area = view3d_area()
            if area is not None:
                top_view(area, tight=False)
            log("摘掉 alpha 连线（表面转不透明）：%s" % set_alpha_link(False))
            set_wireframe(True)
            STEP["n"] = 4
            return 1.6

        if n == 4:
            # 几何本身的样子：三角形铺满、中心被填上
            shoot("ic_gui_02_wire.png")
            STEP["n"] = 5
            return 1.2

        if n == 5:
            set_alpha_link(True)
            set_wireframe(False)
            area = view3d_area()
            if area is not None:
                top_view(area, tight=True)
            STEP["n"] = 6
            return 1.6

        if n == 6:
            shoot("ic_gui_03_zoom.png")
            STEP["n"] = 7
            return 0.3

        log("完成，退出")
        os._exit(0)
    except Exception:                            # noqa: BLE001
        traceback.print_exc()
        os._exit(3)
    return 0.2


bpy.app.timers.register(tick, first_interval=1.2, persistent=True)
