"""钢笔画出来的引导路径 → 栅格化成掩膜。

路径的语义（用户能理解的说法）：

    · 画一条**闭合**路径 → 圈起来的这一块就当作形状。
      自动追踪的结果在这块区域内被覆盖掉。
      适合「自动追得不对，我自己描一遍」。

    · 画**开放**路径 → 沿线加一条「边界」，先把线本身附近标上，
      再让自动结果去覆盖它。适合「这条边应该从这儿切」。

路径点是像素坐标（左上原点），和贴图对齐。

贝塞尔：ps 钢笔那样带控制柄的曲线，在存储上是「采样后的密集点」。
画的时候实时采成点串，这里就只处理点串，不用再管切线 ——
既简化了数据结构，也让「画的」和「存的」永远是同一份东西。
"""

import math

import numpy as np

from .triangulate import points_in_ring


def sample_cubic(p0, c0, c1, p1, steps=12):
    """三次贝塞尔采样。钢笔拖动时把曲线转成点串用。"""
    out = []
    for k in range(1, steps + 1):
        t = k / float(steps)
        u = 1.0 - t
        x = (u * u * u * p0[0] + 3 * u * u * t * c0[0]
             + 3 * u * t * t * c1[0] + t * t * t * p1[0])
        y = (u * u * u * p0[1] + 3 * u * u * t * c0[1]
             + 3 * u * t * t * c1[1] + t * t * t * p1[1])
        out.append((x, y))
    return out


def anchors_to_points(anchors, curve_steps=12):
    """锚点 + 控制柄 → 密集点串。

    anchors: [(x, y, in_dx, in_dy, out_dx, out_dy), ...]
    这是钢笔的存储格式：锚点位置 + 相对它的两个控制柄偏移。
    采样成点串之后，下游（栅格化 / 轮廓）只认点串，不用管曲线。
    """
    if not anchors:
        return []
    pts = [tuple(float(v) for v in a) for a in anchors]
    out = [(pts[0][0], pts[0][1])]
    for k in range(len(pts) - 1):
        a = pts[k]
        b = pts[k + 1]
        c0 = (a[0] + a[4], a[1] + a[5])      # 前一点的出柄
        c1 = (b[0] + b[2], b[1] + b[3])      # 后一点的入柄
        out.extend(sample_cubic((a[0], a[1]), c0, c1, (b[0], b[1]), curve_steps))
    return out


def stroke_to_points(stroke, curve_steps=12):
    """把一条钢笔画转成密集点串。

    支持两种存法：
      · 只有顶点（折线）
      · 顶点 + 控制柄（贝塞尔）—— 控制柄按「上一段出柄、下一段入柄」成对读
    """
    pts = list(stroke)
    if not pts:
        return []

    if len(pts) >= 3 and all(len(p) >= 6 for p in pts):
        # 每项 = (x, y, in_dx, in_dy, out_dx, out_dy)
        out = [(pts[0][0], pts[0][1])]
        for k in range(len(pts) - 1):
            a = pts[k]
            b = pts[k + 1]
            c0 = (a[0] + a[4], a[1] + a[5])     # 前一点的出柄
            c1 = (b[0] + b[2], b[1] + b[3])     # 后一点的入柄
            out.extend(sample_cubic((a[0], a[1]), c0, c1, (b[0], b[1]), curve_steps))
        return out

    return [(float(p[0]), float(p[1])) for p in pts]


def _dense(poly, step=1.5):
    """把折线按步长加密，保证栅格化不漏缝。"""
    if len(poly) < 2:
        return poly
    out = []
    n = len(poly)
    for k in range(n):
        x0, y0 = poly[k]
        x1, y1 = poly[(k + 1) % n]
        out.append((float(x0), float(y0)))
        seg = math.hypot(x1 - x0, y1 - y0)
        steps = int(seg / step)
        for m in range(1, steps + 1):
            t = m / (steps + 1.0)
            out.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
    return out


def rasterize(strokes, width, height, line_radius=2.0):
    """笔画列表 → 三态掩膜 (H, W) int8。

    strokes: [(点串, 是否闭合)]，点串是像素坐标
    返回 +1 = 强制实心，-1 = 强制空心，0 = 不管

    实现只在每条路径的包围盒内做判定 —— 全图逐像素跑一次 1K 图要上亿次运算，
    限制范围后通常只有几十万次。
    """
    out = np.zeros((height, width), dtype=np.int8)
    if not strokes:
        return out

    for poly, closed in strokes:
        pts = [(float(p[0]), float(p[1])) for p in poly]
        if len(pts) < 2:
            continue

        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        pad = int(math.ceil(line_radius)) + 2
        x0 = max(0, int(math.floor(min(xs))) - pad)
        y0 = max(0, int(math.floor(min(ys))) - pad)
        x1 = min(width, int(math.ceil(max(xs))) + pad + 1)
        y1 = min(height, int(math.ceil(max(ys))) + pad + 1)
        if x1 <= x0 or y1 <= y0:
            continue

        sub_h = y1 - y0
        sub_w = x1 - x0
        yy, xx = np.mgrid[y0:y1, x0:x1]
        cand = np.column_stack([xx.ravel().astype(np.float64),
                                yy.ravel().astype(np.float64)])

        dense = _dense(pts) if closed else [(float(p[0]), float(p[1])) for p in pts]

        # ⚠️ 只能往 `sub` 本身写（二维布尔索引），不能写 `sub.reshape(-1)` ——
        #    切片出来的数组不连续，reshape 会给一份**副本**，写进去就丢了。
        #    症状极具迷惑性：闭合路径正常工作，开放路径静默什么都不画。
        sub = out[y0:y1, x0:x1]

        if closed and len(dense) >= 3:
            inside = points_in_ring(cand, dense)
            sub[inside.reshape(sub_h, sub_w)] = 1
        else:
            # 开放路径：沿线画粗线（只标线本身，不外扩成面）
            if len(pts) == 2:
                dense = [(pts[0][0], pts[0][1]), (pts[1][0], pts[1][1])]
            r2 = (line_radius + 0.5) ** 2
            n = len(dense)
            for k in range(n - 1):
                ax, ay = dense[k]
                bx, by = dense[k + 1]
                dx = bx - ax
                dy = by - ay
                l2 = dx * dx + dy * dy
                if l2 <= 1e-9:
                    continue
                t = ((cand[:, 0] - ax) * dx + (cand[:, 1] - ay) * dy) / l2
                t = np.clip(t, 0.0, 1.0)
                px = ax + t * dx
                py = ay + t * dy
                d2 = (cand[:, 0] - px) ** 2 + (cand[:, 1] - py) ** 2
                sub[d2.reshape(sub_h, sub_w) <= r2] = 1

    return out
