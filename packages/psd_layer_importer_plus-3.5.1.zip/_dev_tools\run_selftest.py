"""PSD Layer Importer PLUS 异步化后端自测脚本。

在 Blender 后台进程运行：
    blender --background --factory-startup --python run_selftest.py

覆盖：
  1. addon register（含新增 3 个进度属性 + async_job 操作符）
  2. 后台线程安全渲染（psd_tools + PIL + numpy）
  3. 主线程逐层应用建对象（含组内层落子集合）
  4. 取消机制（后台线程响应 cancel 停止）

输出 RESULT_JSON_* 标记，脚本末尾汇总 PASS/FAIL。
"""
import sys
import json
import threading
import queue
import time
import os
import shutil

sys.path.insert(0, r"F:\desktop\BaiduSyncdisk\addons")  # 插件所在父目录

import bpy

PSD = r"F:\desktop\BaiduSyncdisk\addons\psd_layer_importer_plus\_dev_tools\test_basic.psd"

results = {}


def harness(name, fn):
    try:
        fn()
        results[name] = "PASS"
    except Exception as e:
        import traceback
        results[name] = f"FAIL: {repr(e)}"
        results[name + "_tb"] = traceback.format_exc()


def t_register():
    import psd_layer_importer_plus as addon
    addon.register()
    props = bpy.context.scene.psd_import_tool
    assert hasattr(props, "refresh_active"), "缺少 refresh_active"
    assert hasattr(props, "refresh_progress"), "缺少 refresh_progress"
    assert hasattr(props, "refresh_status"), "缺少 refresh_status"
    # 操作符注册
    ns = getattr(bpy.ops, "psd", None)
    assert ns is not None, "psd 操作符命名空间缺失"
    for op in ["import_layers", "refresh_layers", "force_refresh_layers",
               "refresh_selected_layers", "async_job"]:
        assert hasattr(ns, op), f"操作符 {op} 未注册"
    addon.unregister()


def t_background_render():
    import psd_layer_importer_plus as addon
    addon.register()
    import psd_layer_importer_plus.psd_utils as U
    import psd_layer_importer_plus.async_runner as AR
    from psd_tools import PSDImage
    psd = PSDImage.open(PSD)
    tree, flat = U.extract_layer_hierarchy(psd)
    assert len(flat) >= 3, f"应至少有 3 层，实际 {len(flat)}"
    base_layer = flat[0]["layer"]
    infos = [{"layer": base_layer, "display_index": i, "image_name": f"x{i}",
              "cache_png": U.get_cache_png_path(PSD, i, f"id{i}", f"lay{i}"),
              "identifier": f"id{i}", "layer_name": f"lay{i}",
              "metadata_hash": "abc", "group_path": [], "snap": {}} for i in range(5)]
    q = queue.Queue(); cancel = threading.Event()
    w = AR._RenderWorker(psd, infos, q, cancel, lambda t: None)
    w.start(); w.join(timeout=10)
    msgs = []
    while not q.empty():
        it = q.get_nowait()
        if isinstance(it, dict):
            msgs.append(it.get("type"))
    assert "done" in msgs, f"后台渲染未完成: {msgs}"
    assert "layer" in msgs, "后台未产出任何成品"
    addon.unregister()


def t_apply_objects():
    import psd_layer_importer_plus as addon
    addon.register()
    import psd_layer_importer_plus.psd_utils as U
    import psd_layer_importer_plus.PSD_Layer_Importer as PSL
    from psd_tools import PSDImage
    psd = PSDImage.open(PSD)
    tree, flat = U.extract_layer_hierarchy(psd)
    col = bpy.data.collections.new("selftest_col")
    bpy.context.scene.collection.children.link(col)
    spawn = 0
    for e in flat:
        layer = e["layer"]
        name_index = len(flat) - 1 - e["display_index"]
        img_name = f"{name_index}_st_{layer.name}"
        cache_png = U.get_cache_png_path(PSD, name_index, U.create_layer_identifier(layer), layer.name)
        usage = 0
        target = U.get_target_collection_for_layer(col, e.get("group_path", []))
        PSL.process_layer_from_cache(
            bpy.context, layer, img_name, target,
            psd.size[0], psd.size[1], e["display_index"],
            cache_png, is_new=True, expected_checksum=None,
        )
        spawn += 1
    # 校验：总对象数（含子集合）应等于层数
    def count(c):
        n = len([o for o in c.objects if o.get("layer_identifier")])
        for ch in c.children:
            n += count(ch)
        return n
    total_obj = count(col)
    assert total_obj == len(flat), f"对象数 {total_obj} != 层数 {len(flat)}"
    addon.unregister()


def t_cancel():
    import psd_layer_importer_plus as addon
    addon.register()
    import psd_layer_importer_plus.psd_utils as U
    import psd_layer_importer_plus.async_runner as AR
    from psd_tools import PSDImage
    psd = PSDImage.open(PSD)
    tree, flat = U.extract_layer_hierarchy(psd)
    base = flat[0]["layer"]
    infos = [{"layer": base, "display_index": i, "image_name": f"x{i}",
              "cache_png": U.get_cache_png_path(PSD, i, f"id{i}", f"lay{i}"),
              "identifier": f"id{i}", "layer_name": f"lay{i}",
              "metadata_hash": "abc", "group_path": [], "snap": {}} for i in range(20)]
    q = queue.Queue(); cancel = threading.Event()
    cancel.set()  # 启动前就取消
    w = AR._RenderWorker(psd, infos, q, cancel, lambda t: None)
    w.start(); w.join(timeout=5)
    msgs = []
    while not q.empty():
        it = q.get_nowait()
        if isinstance(it, dict):
            msgs.append(it.get("type"))
    assert "cancel" in msgs, f"取消未生效: {msgs}"
    addon.unregister()


def t_selected_record():
    """REFRESH_SELECTED 反查 record：选中对象应能定位到所属 PSD 记录的文件路径。"""
    import psd_layer_importer_plus as addon
    addon.register()

    psd_tool = bpy.context.scene.psd_import_tool
    while len(psd_tool.file_records):
        psd_tool.file_records.remove(len(psd_tool.file_records) - 1)
    rec = psd_tool.file_records.add()
    rec.filepath = PSD
    col = bpy.data.collections.new("test_basic")
    bpy.context.scene.collection.children.link(col)
    rec.collection = col

    mesh = bpy.data.meshes.new("m")
    obj = bpy.data.objects.new("sel_obj", mesh)
    col.objects.link(obj)
    obj["layer_identifier"] = "9999"

    for o in bpy.context.scene.objects:
        o.select_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

    # 复现 _find_selected_record 查找逻辑
    selected = [o for o in bpy.context.selected_objects if o.get("layer_identifier")]
    found = None
    for o in selected:
        c = o.users_collection[0] if o.users_collection else None
        if not c:
            continue
        f = next((f for f in psd_tool.file_records
                  if hasattr(f, "collection") and f.collection == c), None)
        if f:
            found = f
            break
    assert found is not None, "选中刷新未能反查到 record"
    assert found.filepath == PSD, f"反查文件路径不符: {found.filepath}"
    addon.unregister()


def t_cross_psd():
    """M1' 跨多 PSD 选中刷新：选中对象跨两个不同的 PSD/collection 时，
    _collect_selected_multi 应逐个 PSD 匹配并生成带所属 PSD 信息的 cache_infos。"""
    import psd_layer_importer_plus as addon
    addon.register()
    import psd_layer_importer_plus.psd_utils as U
    from psd_tools import PSDImage

    # 动态生成第二个 PSD（复制 test_basic.psd）
    psd_b = os.path.join(os.path.dirname(PSD), "test_basic_b.psd")
    shutil.copyfile(PSD, psd_b)

    psd_tool = bpy.context.scene.psd_import_tool
    while len(psd_tool.file_records):
        psd_tool.file_records.remove(len(psd_tool.file_records) - 1)

    colA = bpy.data.collections.new("colA")
    colB = bpy.data.collections.new("colB")
    bpy.context.scene.collection.children.link(colA)
    bpy.context.scene.collection.children.link(colB)

    recA = psd_tool.file_records.add()
    recA.filepath = PSD
    recA.collection = colA
    recB = psd_tool.file_records.add()
    recB.filepath = psd_b
    recB.collection = colB

    def first_visible_ident(psd):
        all_l = U.get_visible_layers(psd)
        return all_l[0][3]

    idA = first_visible_ident(PSDImage.open(PSD))
    idB = first_visible_ident(PSDImage.open(psd_b))

    def mk_obj(col, ident):
        mesh = bpy.data.meshes.new(f"m_{ident[-6:]}")
        o = bpy.data.objects.new(f"obj_{ident[-6:]}", mesh)
        col.objects.link(o)
        o["layer_identifier"] = ident
        return o

    oA = mk_obj(colA, idA)
    oB = mk_obj(colB, idB)
    for o in bpy.context.scene.objects:
        o.select_set(False)
    oA.select_set(True)
    oB.select_set(True)

    # 复刻 _collect_selected_multi 核心：分组 -> 逐个匹配
    # 分组 key 用 id(c)（对象身份），与插件 Fix A 一致，
    # 避免同名 collection 被 setdefault(c.name,...) 合并丢组。
    groups = {}
    for obj in bpy.context.selected_objects:
        if not obj.get("layer_identifier"):
            continue
        c = obj.users_collection[0] if obj.users_collection else None
        if not c:
            continue
        g = groups.setdefault(id(c), {"col": c, "objs": []})
        g["objs"].append(obj)

    infos = []
    for _cid, grp in groups.items():
        col = grp["col"]
        objs = grp["objs"]
        rec = next((f for f in psd_tool.file_records if f.collection == col), None)
        assert rec is not None, f"collection {col.name} 未反查到 record"
        psd = PSDImage.open(rec.filepath)
        base_name = bpy.path.display_name_from_filepath(rec.filepath)
        W, H = psd.size
        all_layers = U.get_visible_layers(psd)
        wanted = {}
        for o in objs:
            oid = o.get("layer_identifier")
            for i, disp, layer, ident in all_layers:
                if ident == oid:
                    wanted[oid] = (layer, disp)
                    break
        total_count = len(all_layers)
        for o in objs:
            oid = o.get("layer_identifier")
            if oid not in wanted:
                continue
            layer, disp = wanted[oid]
            name_index = total_count - 1 - disp
            infos.append({
                "layer": layer, "display_index": disp, "layer_name": layer.name,
                "identifier": oid, "psd_width": W, "psd_height": H,
                "collection": col, "group_path": [],
            })

    assert len(groups) == 2, f"应分 2 组，实际 {len(groups)}"
    assert len(infos) == 2, f"跨 PSD 应匹配到 2 个图层，实际 {len(infos)}"
    cols = sorted(i["collection"].name for i in infos)
    assert cols == ["colA", "colB"], f"info 集合归属不符: {cols}"
    addon.unregister()


harness("register", t_register)
harness("background_render", t_background_render)
harness("apply_objects", t_apply_objects)
harness("cancel", t_cancel)
harness("selected_record", t_selected_record)
harness("cross_psd", t_cross_psd)

all_pass = all(v == "PASS" for v in results.values())
print("RESULT_JSON_START")
print(json.dumps(results, ensure_ascii=False))
print("SELFTEST_ALL_PASS" if all_pass else "SELFTEST_HAS_FAILURE")
print("RESULT_JSON_END")
