"""异步 PSD 导入/刷新执行器。

把耗时的 PSD 解析、逐层像素渲染、校验和计算、缓存 PNG 写入放后台线程；
主线程用计时器驱动的模态操作符，逐层做 bpy 应用（建物体/贴材质/打包/挪集合/记校验和）。

后台线程遵循「不碰 bpy 数据块」的铁律：所有 bpy 调用都来自主线程。
后台只调用 psd_tools / PIL / numpy / hashlib / os（纯计算与磁盘操作）。

界面不冻结的机理：
  - 后台 C 库（numpy/PIL）运行时释放 GIL，主线程能抢到控制权去重绘、响应用户；
  - 主线程每 tick 只消费一个成品（轻量 bpy 应用），做完立即回到事件循环。
"""

import bpy
import threading
import queue
import os
import hashlib
from typing import Optional, Any


# ==================== 延迟导入（避免循环依赖） ====================

def _mods():
    """延迟导入插件各模块，返回可复用函数的命名空间。"""
    from . import PSD_Layer_Importer as PSL
    from . import psd_utils as U
    from . import parallax_utils as PA
    from . import constants as C
    return PSL, U, PA, C


# ==================== 后台渲染工作线程 ====================

class _RenderWorker(threading.Thread):
    """后台线程：逐层渲染，产出「成品」放入队列。不碰任何 bpy。"""

    def __init__(self, psd, cache_infos, out_queue, cancel_event, status_cb):
        super().__init__(daemon=True)
        self.psd = psd
        self.cache_infos = cache_infos  # 主线程预计算：layer/name/cache_png/metadata_hash/snap 等
        self.out_queue = out_queue
        self.cancel_event = cancel_event
        self.status_cb = status_cb

    def run(self):
        _, U, _, _ = _mods()
        total = len(self.cache_infos)
        try:
            for i, info in enumerate(self.cache_infos):
                if self.cancel_event.is_set():
                    self.out_queue.put({"type": "cancel"})
                    return
                layer = info["layer"]
                self._status(f"渲染中 {i+1}/{total}")

                img = None
                try:
                    img = U.render_layer_rgba(layer)
                except Exception as e:
                    self.out_queue.put({
                        "type": "layer", "index": i, "render_error": repr(e),
                        "snap": info.get("snap", {}),
                    })
                    continue

                pixel_hash = U.compute_image_md5(img) or ""
                png_error = None
                try:
                    if img is not None:
                        U.save_image_png(img, info["cache_png"])
                except Exception as e:
                    png_error = repr(e)

                metadata_hash = info.get("metadata_hash", "")
                expected_checksum = None
                if metadata_hash and pixel_hash:
                    expected_checksum = f"{metadata_hash}_{pixel_hash}"

                self._status(f"渲染中 {i+1}/{total}")
                self.out_queue.put({
                    "type": "layer",
                    "index": i,
                    "img_ready": img is not None,
                    "png_error": png_error,
                    "pixel_hash": pixel_hash,
                    "metadata_hash": metadata_hash,
                    "expected_checksum": expected_checksum,
                    "layer_name": info.get("layer_name", ""),
                    "image_name": info["image_name"],
                    "cache_png": info["cache_png"],
                    "identifier": info.get("identifier", ""),
                    "snap": info.get("snap", {}),
                    "group_path": info.get("group_path", []),
                })
            self.out_queue.put({"type": "done", "total": total})
        except Exception as e:
            import traceback
            self.out_queue.put({"type": "error", "msg": repr(e), "tb": traceback.format_exc()})

    def _status(self, text):
        """后台线程上报进度状态。

        不直接碰 bpy（后台线程严禁访问 bpy 数据块），改为往 out_queue 丢一个
        status 消息，由主线程 modal 消费时写入面板属性。极轻量，不会堆积。
        """
        try:
            self.out_queue.put({"type": "status", "text": text})
        except Exception:
            pass


# ==================== 主线程模态操作符 ====================

class PSD_OT_AsyncJob(bpy.types.Operator):
    """驱动后台渲染 + 主线程逐层应用的模态操作符。"""

    bl_idname = "psd.async_job"
    bl_label = "后台处理 PSD 图层"
    bl_description = "后台解析渲染 PSD，主线程逐层应用到场景（不冻结界面）"
    bl_options = {"REGISTER", "UNDO"}

    mode: bpy.props.EnumProperty(
        items=[
            ("IMPORT", "导入", ""),
            ("REFRESH", "刷新", ""),
            ("FORCE_REFRESH", "强制刷新", ""),
            ("REFRESH_SELECTED", "刷新选中", ""),
        ],
        name="模式",
        default="REFRESH",
    )
    file_index: bpy.props.IntProperty(default=-1)

    PROP_ACTIVE = "refresh_active"
    PROP_PROGRESS = "refresh_progress"
    PROP_STATUS = "refresh_status"

    def invoke(self, context, event):
        # 互斥：已有后台任务在运行时拒绝新的，避免缓存写竞争/对象并发
        try:
            if context.scene.psd_import_tool.refresh_active:
                self.report({"WARNING"}, "已有 PSD 后台任务在运行，请先等待或取消")
                return {"CANCELLED"}
        except Exception:
            pass

        self._mode = self.mode
        self._file_index = self.file_index

        # 构建任务上下文（主线程准备，含后台要用的 info）
        ok = self._build(context)
        if not ok:
            err = getattr(self, "_error", "启动失败")
            self._report(context, {"ERROR"}, err)
            return {"CANCELLED"}

        # 启动后台线程
        self._cancel = threading.Event()
        self._done_count = 0
        self._total = len(self._cache_infos)
        self._failed_layers = 0
        self._finished = False
        self._out_queue = queue.Queue()
        self._backlog = []  # 本 tick 取出但超配额未处理的 item，下个 tick 先消费（修复 S1 漏图层）
        self._applications_succeeded = 0  # 真实成功应用的图层数（S1/M3 进度口径）

        self._worker = _RenderWorker(
            self._psd, self._cache_infos, self._out_queue, self._cancel, None
        )
        self._worker.start()

        # 计时器 + 模态
        self._timer = context.window_manager.event_timer_add(0.05, window=context.window)
        context.window_manager.modal_handler_add(self)

        # 初始化进度
        self._set_active(True)
        self._set_status("解析中…")
        self._set_progress(0.0)

        return {"RUNNING_MODAL"}

    # ---------------- 构建（主线程） ----------------

    def _build(self, ctx):
        PSL, U, PA, C = _mods()
        psd_tool = ctx.scene.psd_import_tool

        rec = None
        if 0 <= self._file_index < len(psd_tool.file_records):
            rec = psd_tool.file_records[self._file_index]

        # ---- 文件路径 ----
        if self._mode == "IMPORT":
            filepath = getattr(PSL, "_import_filepath", "")
        elif self._mode == "REFRESH_SELECTED":
            # 选中刷新没有统一 file_index，需要从选中对象反查所属 PSD record
            sel_rec = self._find_selected_record(ctx)
            self._record = sel_rec
            filepath = sel_rec.filepath if sel_rec else ""
        else:
            filepath = rec.filepath if rec else ""
        if not filepath:
            self._error = "未指定 PSD 文件路径"
            return False
        self._filepath = filepath

        # IMPORT 模式：新建 file record 并登记（含相机/文件信息）
        if self._mode == "IMPORT":
            rec = psd_tool.file_records.add()
            rec.filepath = filepath
            try:
                rec.file_mtime = os.path.getmtime(filepath)
            except (OSError, IOError):
                rec.file_mtime = 0.0
            if ctx.scene.camera:
                rec.camera = ctx.scene.camera
                rec.last_camera_transform = str(ctx.scene.camera.matrix_world)
                rec["last_camera_position"] = list(ctx.scene.camera.matrix_world.translation)
            self._record = rec
        elif self._mode == "REFRESH_SELECTED":
            # 已在路径解析处反查，self._record 已是选中对象所属 record
            rec = self._record  # 局部 rec 对齐，供后续读取刷新选项/集合
        else:
            self._record = rec

        # ---- 打开 PSD（主线程，读取型）----
        try:
            self._psd = C.open_psd(filepath)
        except Exception as e:
            self._error = f"无法打开 PSD 文件: {e}"
            return False
        self._psd_width, self._psd_height = self._psd.size
        self._base_name = bpy.path.display_name_from_filepath(filepath)

        # 数据源日志（排查"改了没反应"：确认读的是哪个文件、何时读、是否已解析）
        try:
            mtime = os.path.getmtime(filepath)
        except (OSError, IOError):
            mtime = 0.0
        C._psd_log(
            f"[PSD-入口] 异步处理: mode={self._mode}, file='{filepath}', "
            f"base='{self._base_name}', size={self._psd_width}x{self._psd_height}, "
            f"mtime={mtime}"
        )

        # ---- 刷新选项 ----
        if rec is not None:
            self._update_texture = rec.refresh_update_texture
            self._update_mesh = rec.refresh_update_mesh
            self._update_transform = rec.refresh_update_transform
            self._update_structure = rec.refresh_update_structure
        else:
            self._update_texture = True
            self._update_mesh = False
            self._update_transform = False
            self._update_structure = False

        # ---- 集合 ----
        collection = None
        if rec is not None:
            collection = PA.get_collection_from_record(rec)
        if collection is None:
            # 未记录集合时按名称查找（IMPORT 时可能尚不存在，需创建）
            collection = bpy.data.collections.get(self._base_name)
            if collection is None and self._mode == "IMPORT":
                collection = bpy.data.collections.new(self._base_name)
                try:
                    ctx.scene.collection.children.link(collection)
                except (RuntimeError, ValueError):
                    pass
        self._collection = collection

        # 防御：非 IMPORT 且找不到集合时，提前报错（避免后续 find_layer_object_in_tree(None,...) 崩溃）
        if self._mode != "IMPORT" and collection is None:
            self._error = f"找不到名为 {self._base_name} 的集合"
            return False

        # S2修复：IMPORT 时把集合引用写回 record，保证后续"选中刷新"能按 collection 精确反查
        if self._mode == "IMPORT" and rec is not None and collection is not None:
            try:
                rec.collection = collection
            except Exception:
                pass

        # ---- 提取图层 ----
        self._id_to_path = {}
        if self._mode == "IMPORT":
            hierarchy_tree, flat = U.extract_layer_hierarchy(self._psd)
            if flat:
                U.ensure_collection_tree(collection, hierarchy_tree, self._base_name)
                if rec is not None:
                    rec.group_hierarchy = U.serialize_hierarchy_snapshot(hierarchy_tree)
                for e in flat:
                    self._id_to_path[e["identifier"]] = e["group_path"]
            self._flat_list = flat
        elif self._mode == "REFRESH" and self._update_structure:
            self._id_to_path, flat = U.sync_collection_structure(
                self._psd, rec, collection, self._base_name
            )
            self._flat_list = flat
        elif self._mode == "FORCE_REFRESH" and self._update_structure:
            self._id_to_path, flat = U.sync_collection_structure(
                self._psd, rec, collection, self._base_name
            )
            self._flat_list = flat
        elif self._mode == "REFRESH_SELECTED":
            # M1'：选中刷新支持跨多 PSD。收集选中对象跨的所有 record，
            # 逐 PSD 提取并生成 cache_infos（各 info 自含所属 PSD 的 size/collection）。
            infos, flat = self._collect_selected_multi(ctx)
            if not infos:
                self._error = "选中的图层未匹配到所属 PSD 的可见图层"
                return False
            self._cache_infos = infos
            self._flat_list = flat
            self._total = len(infos)
            # record 相关收尾（选中刷新不写 checksum/layer_order，仅更新引用）
            return True
        else:
            non_group = U.get_visible_layers(self._psd)
            self._flat_list = []
            for i, disp, layer, ident in non_group:
                self._flat_list.append({
                    "layer": layer, "identifier": ident,
                    "group_path": [], "display_index": disp, "i": i,
                })

        if not self._flat_list:
            self._error = "PSD 中没有找到可见的图层"
            return False

        total_count = len(self._flat_list)

        # ---- 预计算 cache info（主线程，因走 bpy.path）----
        infos = []
        for entry in self._flat_list:
            layer = entry["layer"]
            disp_idx = entry["display_index"]
            name_index = total_count - 1 - disp_idx
            image_name = f"{name_index}_{self._base_name}_{layer.name}"
            identifier = entry.get("identifier") or U.create_layer_identifier(layer)
            cache_png = U.get_cache_png_path(filepath, name_index, identifier, layer.name)
            try:
                l, t, r, b = U._get_layer_bbox(layer)
                metadata = f"{layer.name}{l}{t}{r}{b}"
                metadata_hash = hashlib.md5(metadata.encode()).hexdigest()
            except Exception:
                metadata_hash = ""
            infos.append({
                "layer": layer,
                "display_index": disp_idx,
                "name_index": name_index,
                "image_name": image_name,
                "cache_png": cache_png,
                "identifier": identifier,
                "layer_name": layer.name,
                "metadata_hash": metadata_hash,
                "group_path": entry.get("group_path", []),
                # M1'：每个 info 自包含所属 PSD 的尺寸与目标集合，支持跨多 PSD 的选中刷新
                "psd_width": self._psd_width,
                "psd_height": self._psd_height,
                "collection": collection,
                "snap": {
                    "left": int(layer.left), "top": int(layer.top),
                    "width": int(layer.width), "height": int(layer.height),
                },
            })
        self._cache_infos = infos
        self._total = total_count
        return True

    def _collect_selected(self, ctx):
        _, U, _, _ = _mods()
        selected = [o for o in ctx.selected_objects if o.get("layer_identifier")]
        flat = []
        all_layers = U.get_visible_layers(self._psd)
        for obj in selected:
            oid = obj.get("layer_identifier")
            for i, disp, layer, ident in all_layers:
                if ident == oid:
                    flat.append({
                        "layer": layer, "identifier": ident,
                        "group_path": [], "display_index": disp, "i": i,
                    })
                    break
        return flat

    def _collect_selected_multi(self, ctx):
        """M1'：支持跨多个 PSD 的选中刷新。

        把选中对象按所属 collection 分组；对每组反查其 record、打开对应 PSD、
        提取该 PSD 的可见图层并用本组选中对象匹配，生成 cache_infos（各 info 自含
        所属 PSD 的 size/collection）。合并所有组返回 (infos, flat_list)。
        若选中对象只属一个 PSD，结果与单 PSD 流程一致。

        分组 key 用 id(col)（对象身份），避免同名 collection 被合并（A）。
        """
        PSL, U, _, C = _mods()
        psd_tool = ctx.scene.psd_import_tool
        # 按 collection 对象身份分组：{id(col): {"col": col, "objs": [...]}}
        groups = {}
        selected = [o for o in ctx.selected_objects if o.get("layer_identifier")]
        for obj in selected:
            col = obj.users_collection[0] if obj.users_collection else None
            if not col:
                continue
            g = groups.setdefault(id(col), {"col": col, "objs": []})
            g["objs"].append(obj)

        infos = []
        flat_all = []
        self._psd_filepaths = getattr(self, "_psd_filepaths", []) or []
        for _cid, grp in groups.items():
            col = grp["col"]
            objs = grp["objs"]
            rec = self._find_selected_record(ctx, col)
            if not rec:
                continue
            filepath = rec.filepath
            if not filepath:
                continue
            try:
                psd = C.open_psd(filepath)
            except Exception:
                continue
            if filepath not in self._psd_filepaths:
                self._psd_filepaths.append(filepath)
            base_name = bpy.path.display_name_from_filepath(filepath)
            # C：跨同名 PSD 时给图片/缓存名加 filepath 短 hash，避免同名 base 碰撞
            fp_key = hashlib.md5(filepath.encode("utf-8", "replace")).hexdigest()[:6]
            W, H = psd.size
            # 该 PSD 的全部可见图层
            all_layers = U.get_visible_layers(psd)
            # 匹配本组选中对象（oid -> layer）
            wanted = {}
            for o in objs:
                oid = o.get("layer_identifier")
                for i, disp, layer, ident in all_layers:
                    if ident == oid:
                        wanted[oid] = (layer, disp)
                        break
            total_count = len(all_layers)
            for o in objs:
                oid = o.get("layer_identifier")
                if oid not in wanted:
                    continue  # 该对象不属于此 PSD（理论上不会，防御）
                layer, disp = wanted[oid]
                name_index = total_count - 1 - disp
                image_name = f"{name_index}_{base_name}_{fp_key}_{layer.name}"
                cache_png = U.get_cache_png_path(filepath, name_index, oid, layer.name)
                try:
                    l, t, r, b = U._get_layer_bbox(layer)
                    mh = hashlib.md5(f"{layer.name}{l}{t}{r}{b}".encode()).hexdigest()
                except Exception:
                    mh = ""
                infos.append({
                    "layer": layer, "display_index": disp, "name_index": name_index,
                    "image_name": image_name, "cache_png": cache_png,
                    "identifier": oid, "layer_name": layer.name,
                    "metadata_hash": mh, "group_path": [],
                    "psd_width": W, "psd_height": H, "collection": col,
                    "snap": {"left": int(layer.left), "top": int(layer.top),
                             "width": int(layer.width), "height": int(layer.height)},
                })
                flat_all.append({"layer": layer, "identifier": oid,
                                 "group_path": [], "display_index": disp, "i": disp})
        return infos, flat_all

    def _find_selected_record(self, ctx, collection=None):
        """从选中对象反查所属 PSD 记录（与原始 RefreshSelectedLayers 逻辑一致）。

        优先按 collection 引用匹配；失败再按集合名称回退。
        collection 指定时只用该集合；否则遍历选中对象。
        返回 record 或 None。
        """
        _, _, PA, _ = _mods()
        psd_tool = ctx.scene.psd_import_tool

        def _match(col):
            # 按 collection 引用匹配
            rec = next(
                (f for f in psd_tool.file_records
                 if hasattr(f, "collection") and f.collection == col),
                None,
            )
            if rec:
                return rec
            # 名称回退
            rec = next(
                (f for f in psd_tool.file_records
                 if bpy.path.display_name_from_filepath(f.filepath) == col.name),
                None,
            )
            if rec:
                # M2修复：名称回退命中后写回 collection 引用，避免每次都走回退
                try:
                    if hasattr(rec, "collection"):
                        rec.collection = col
                except Exception:
                    pass
                return rec
            return None

        if collection is not None:
            return _match(collection)

        selected = [o for o in ctx.selected_objects if o.get("layer_identifier")]
        seen = set()
        for obj in selected:
            collection = obj.users_collection[0] if obj.users_collection else None
            if not collection or collection.name in seen:
                continue
            seen.add(collection.name)
            rec = _match(collection)
            if rec:
                return rec
        return None

    def _find_by_name(self, collection, layer_name):
        """按图层名在集合树里查找已有对象（用于判断"id 变了但名字还在"）。

        对象名格式为 {name_index}_{base_name}_{layer_name}_object，
        用 layer_name 做子串匹配（避免 name_index 前缀干扰）。
        返回匹配的对象或 None。
        """
        _, U, PA, _ = _mods()
        if collection is None:
            return None
        try:
            objs = PA.get_all_objects_recursive(collection)
        except Exception:
            return None
        # 精确后缀匹配优先（layer_name 在对象名末尾），其次是子串包含
        for o in objs:
            base = o.name
            if base.endswith(f"_{layer_name}") or base.endswith(f"_{layer_name}_object"):
                return o
        for o in objs:
            if layer_name and layer_name in o.name:
                return o
        return None

    # ---------------- 模态 ----------------

    def modal(self, context, event):
        if event.type == "ESC":
            self._teardown(context, cancelled=True)
            return {"CANCELLED"}
        if event.type != "TIMER":
            return {"RUNNING_MODAL"}

        processed = False
        # 每 tick 处理少量图层，避免单次卡太久（保持界面响应）。
        # status 消息极轻量（只更新面板文本），不计入图层处理额度。
        #
        # 【S1修复】不再把超配额的 item 放回 queue（FIFO 会破坏顺序、让 done 抢在 layer 前，
        # 导致漏图层）。改为：先把队列里的全部消息搬到 self._backlog（保持顺序），
        # 再从 backlog 队头依次处理。终止信号(done/error/cancel)只在其前面的 layer 都已
        # 处理完（即它成为 backlog 队头）时才触发，从根本上杜绝"漏图层但报完成"。
        max_per_tick = 2
        processed_layers = 0
        terminate_item = None

        # 1) 搬队列 → backlog（保持 FIFO 顺序，不丢失任何消息）
        while True:
            try:
                item = self._out_queue.get_nowait()
            except queue.Empty:
                break
            self._backlog.append(item)

        # 2) 从 backlog 队头开始处理
        while self._backlog:
            head = self._backlog[0]
            t = head.get("type")
            if t == "status":
                self._backlog.pop(0)
                self._set_status(head.get("text", ""))
                processed = True
                continue
            if t in ("done", "error", "cancel"):
                # 终止信号：出现在队头说明前面的 layer 都已处理完，安全结束
                self._backlog.pop(0)
                terminate_item = head
                processed = True
                break
            # layer
            if processed_layers >= max_per_tick:
                # 本 tick 配额已满，剩余 layer 留在 backlog 供下个 tick 处理（不丢失）
                break
            self._backlog.pop(0)
            processed_layers += 1
            processed = True
            self._handle_item(context, head)

        # 3) 处理终止信号（若有）
        if terminate_item is not None:
            self._handle_item(context, terminate_item)

        # 进度用真实成功应用数（S1/M3 口径），避免漏处理时虚高
        progress_count = self._applications_succeeded
        frac = (progress_count / self._total) if self._total else 1.0
        self._set_progress(frac)
        self._set_status(f"处理中 {progress_count}/{self._total}")

        try:
            for area in context.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
                elif area.type in ("PROPERTIES", "VIEW_3D"):
                    area.tag_redraw()
        except Exception:
            pass

        if self._finished:
            self._teardown(context)
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def _handle_item(self, context, item):
        t = item.get("type")
        if t == "layer":
            self._apply_layer(context, item)
        elif t == "done":
            # 保留真实计数（_done_count 每层+1，_applications_succeeded 是成功应用数），
            # 不再强制置为 total——避免漏处理时虚高（S1/M3）
            self._finished = True
            self._finalize(context)
        elif t == "error":
            self._report(context, {"ERROR"}, f"后台处理出错: {item.get('msg', '')}")
            self._finished = True
        elif t == "cancel":
            self._finished = True

    def _apply_layer(self, context, item):
        PSL, U, _, C = _mods()
        log = C._psd_log
        try:
            idx = item["index"]
            if idx >= len(self._cache_infos):
                return
            info = self._cache_infos[idx]
            layer = info["layer"]
            disp_idx = info["display_index"]
            image_name = info["image_name"]
            cache_png = info["cache_png"]
            expected_checksum = item.get("expected_checksum")

            if item.get("render_error"):
                raise RuntimeError(f"渲染失败: {item['render_error']}")
            if item.get("png_error"):
                raise RuntimeError(f"PNG 写入失败: {item['png_error']}")

            info_col = info.get("collection", self._collection)
            info_w, info_h = info.get("psd_width", self._psd_width), info.get("psd_height", self._psd_height)
            layer_name = info.get("layer_name", layer.name)

            # ===== 匹配决策日志（排查"改了没反应"关键点）=====
            # 先尝试按 layer_id 精确匹配
            existing_obj = U.find_layer_object_in_tree(info_col, info["identifier"])
            matched_mode = "id"
            # 若按 id 没匹配到，尝试按"图层名"搜索场景里是否有同名对象（判断是否 id 变了但名字还在）
            name_match = None
            if existing_obj is None:
                name_match = self._find_by_name(info_col, layer_name)
                if name_match is not None:
                    matched_mode = "name"
            if existing_obj is None and name_match is not None:
                # id 匹配失败但名字匹配到——说明图层本体可能被换（id 变），名字还在。
                log(f"[PSD-匹配] layer='{layer_name}' id={info['identifier']}: 按id未匹配到, 但按名字命中 "
                    f"名称='{name_match.name}' → 疑似图层本体被替换(id变化)")
            elif existing_obj is None:
                log(f"[PSD-匹配] layer='{layer_name}' id={info['identifier']}: 按id未匹配到, 按名字也未命中"
                    f" → 判定为新增图层")
            else:
                log(f"[PSD-匹配] layer='{layer_name}' id={info['identifier']}: 按id命中 "
                    f"existing='{existing_obj.name}' → 走更新")

            force = (self._mode == "REFRESH_SELECTED")
            if existing_obj is not None:
                # 预判校验结果：本次 expected_checksum 与旧记录对比（定位"改了但校验命中跳过"）
                old_ck = None
                if self._record is not None:
                    try:
                        old = next((cs for cs in self._record.layer_checksums
                                    if cs.name == layer_name), None)
                        if old is not None:
                            old_ck = old.value
                    except Exception:
                        old_ck = None
                if self._update_texture and expected_checksum:
                    if old_ck == expected_checksum:
                        log(f"[PSD-校验] layer='{layer_name}': 本次期望值==旧记录"
                            f"({expected_checksum[:16]}...) → 若贴图像上校验亦命中, 将被判定无变化跳过")
                    else:
                        log(f"[PSD-校验] layer='{layer_name}': 本次期望值!=旧记录"
                            f"(旧={old_ck[:16] if old_ck else '无'}, 新={expected_checksum[:16]}...) → 应触发更新")

                PSL.update_existing_layer_object(
                    context, existing_obj, layer,
                    info_w, info_h, disp_idx,
                    self._update_texture, self._update_mesh, self._update_transform,
                    cache_png, expected_checksum, info_col,
                    force=force,
                )
                log(f"[PSD-刷新结果] layer='{layer_name}': 已更新已有对象 '{existing_obj.name}' "
                    f"(贴图更新={'是' if self._update_texture else '否'} checksum={'有' if expected_checksum else '无'})")
                self._report(context, {"INFO"}, f"图层 '{layer_name}': 已更新")
                # 友好提示：只更新贴图且做了 UV 位置校正时，提醒若仍偏移该怎么办
                try:
                    if self._update_texture and not self._update_mesh:
                        adj = PSL.calculate_adjusted_uv(existing_obj, layer)
                        if adj is not None:
                            log(f"[PSD-UV] layer='{layer_name}': 已做UV位置校正(按旧网格对齐新贴图)")
                            self._report(
                                context, {"INFO"},
                                f"图层 '{layer_name}': 贴图已按旧网格位置对齐"
                                f"(若仍有偏移, 建议在刷新选项勾选『网格』或重置变换)"
                            )
                except Exception:
                    pass
            else:
                target_col = U.get_target_collection_for_layer(info_col, info["group_path"])
                PSL.process_layer_from_cache(
                    context, layer, image_name, target_col,
                    info_w, info_h, disp_idx,
                    cache_png, is_new=True, expected_checksum=expected_checksum,
                    force=force,
                )
                if name_match is not None:
                    # 按名字找到了旧的，但现在却新建了——说明 id 变了导致匹配丢失，提示用户
                    msg = (f"图层 '{layer_name}': 未匹配到已有对象(PSD里可能删/改名/调了结构), "
                           f"已作为新图层导入")
                    log(f"[PSD-刷新结果] layer='{layer_name}': {msg}")
                    self._report(context, {"INFO"}, msg)
                else:
                    msg = f"图层 '{layer_name}': 新增"
                    log(f"[PSD-刷新结果] layer='{layer_name}': 新增图层")
                    self._report(context, {"INFO"}, msg)

            if self._mode != "REFRESH_SELECTED" and self._record is not None:
                self._write_checksum(info, expected_checksum)

            self._done_count += 1
            self._applications_succeeded += 1
        except Exception as e:
            self._failed_layers += 1
            self._report(context, {"WARNING"}, f"处理图层 '{item.get('layer_name', '')}' 时出错: {e}")
            self._done_count += 1

    def _write_checksum(self, info, expected_checksum):
        record = self._record
        try:
            layername = info["layer_name"]
            existing = next((cs for cs in record.layer_checksums if cs.name == layername), None)
            value = expected_checksum or ""
            if existing is None:
                nc = record.layer_checksums.add()
                nc.name = layername
                nc.value = value
            else:
                existing.value = value
        except Exception:
            pass

    def _finalize(self, context):
        try:
            if self._mode != "REFRESH_SELECTED" and self._record is not None:
                self._record.layer_order = ",".join(
                    [info["layer_name"] for info in self._cache_infos]
                )
        except Exception:
            pass
        try:
            _, U, _, _ = _mods()
            # B：清理本次处理涉及的所有 PSD 的缓存（跨多 PSD 场景逐个清）
            paths = getattr(self, "_psd_filepaths", None) or []
            if self._filepath and self._filepath not in paths:
                paths.append(self._filepath)
            for p in paths:
                try:
                    U.cleanup_cache_files(p)
                except Exception:
                    pass
        except Exception:
            pass
        msg = f"已处理 {self._applications_succeeded}/{self._total} 个图层"
        if self._failed_layers:
            msg += f"，{self._failed_layers} 个图层出错"
        self._report(context, {"INFO"}, msg)

    # ---------------- 收尾 ----------------

    def _teardown(self, context, cancelled=False):
        if getattr(self, "_timer", None) is not None:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if cancelled and getattr(self, "_cancel", None) is not None:
            self._cancel.set()
        self._set_active(False)
        self._set_progress(0.0)
        if cancelled:
            self._set_status("已取消")
            msg = f"已取消，完成 {self._done_count}/{self._total} 个图层"
            self._report(context, {"INFO"}, msg)

    def cancel(self, context):
        self._teardown(context, cancelled=True)

    # ---------------- 进度属性 ----

    def _set_active(self, v):
        try:
            setattr(bpy.context.scene.psd_import_tool, self.PROP_ACTIVE, bool(v))
        except Exception:
            pass

    def _set_progress(self, v):
        try:
            setattr(bpy.context.scene.psd_import_tool, self.PROP_PROGRESS, float(v))
        except Exception:
            pass

    def _set_status(self, text):
        try:
            setattr(bpy.context.scene.psd_import_tool, self.PROP_STATUS, str(text))
        except Exception:
            pass

    def _report(self, context, level, msg):
        try:
            self.report(level, msg)
        except Exception:
            pass


# ==================== 启动入口 ====================

def launch_async_job(context, mode: str, file_index: int = -1, filepath: str = ""):
    """由各入口操作符调用，启动异步处理。"""
    from . import PSD_Layer_Importer as PSL
    PSL._import_filepath = filepath  # IMPORT 模式暂存路径
    try:
        bpy.ops.psd.async_job("INVOKE_DEFAULT", mode=mode, file_index=file_index)
        return True
    except Exception:
        return False
