"""生成一个用于测试的简单 PSD 文件。

用 psd_tools 的 PSDImage.create_pixel_layer(image, name=...) + create_group：
  - 层 A：红色满画布
  - 层 B：蓝色半透明圆（带 alpha）
  - 组 My_Group 内含层 C：绿色满画布
"""
import sys
import os
from PIL import Image
from psd_tools import PSDImage


def make_psd(path: str) -> None:
    w, h = 200, 200
    psd = PSDImage.new("RGBA", (w, h))

    red = Image.new("RGBA", (w, h), (255, 0, 0, 255))
    psd.create_pixel_layer(red, name="Layer_A_Red")

    blue_img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for y in range(50, 150):
        for x in range(50, 150):
            if (x - 100) ** 2 + (y - 100) ** 2 <= 40 ** 2:
                blue_img.putpixel((x, y), (0, 0, 255, 180))
    psd.create_pixel_layer(blue_img, name="Layer_B_Blue")

    green = Image.new("RGBA", (w, h), (0, 255, 0, 255))
    gl = psd.create_pixel_layer(green, name="Group_Layer_C_Green")
    try:
        psd.create_group([gl], name="My_Group")
    except Exception as e:
        print(f"[warn] group: {e}")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    psd.save(path)
    print(f"已生成 PSD: {path}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "test_basic.psd"
    )
    make_psd(out)
