bl_info = {
    "name": "PSD Layer Importer PLUS",
    "author": "HAOAH (toukou0091@gmail.com)",
    "description": "View3D > Sidebar > PSD图层导入工具。支持导入PSD图层为Blender对象，刷新图层，重置变换，更改文件路径，以及切换混合模式。",
    "blender": (2, 93, 0),
    "version": (3, 5, 1),  # 版本号更新到 3.5.1：修正PSD导入后集合顺序与PSD面板顶对顶
    "location": "View3D > Sidebar > PSD图层导入工具",
    "warning": "",
    "category": "Import-Export",
}

import bpy
from . import PSD_Layer_Importer


def register():
    PSD_Layer_Importer.register()


def unregister():
    PSD_Layer_Importer.unregister()


if __name__ == "__main__":
    register()
