import bpy
from bpy.props import (
    StringProperty,
    PointerProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    FloatProperty,
)
from bpy.types import Panel, Operator, PropertyGroup
from bpy.types import AddonPreferences
import os
import hashlib
import subprocess
import sys
import mathutils
import re
from typing import Optional, Tuple, List, Dict, Any

# 子模块导入
from .constants import (
    _psd_log, PSD_DEBUG, ATTR_LAYER_ID, ATTR_LAYER_BBOX,
    MESH_SCALE_FACTOR, LAYER_Z_OFFSET, MAX_FILENAME_LENGTH,
    PNG_COMPRESS_LEVEL, MIN_LAYER_SIZE, MIN_DEPTH, DEFAULT_ALPHA,
    TRANSFORM_CHANGE_THRESHOLD,
    UV_BOTTOM_LEFT, UV_TOP_LEFT, UV_TOP_RIGHT, UV_BOTTOM_RIGHT,
    ATTR_INITIAL_TRANSFORM, ATTR_PRE_MATCH_TRANSFORM,
    ATTR_PARALLAX_LOCKED, UV_ADJUST_NODEGROUP_PREFIX,
    ensure_dependencies, open_psd,
)
from . import constants  # 模块对象引用，供 AddonPreferences 的 update 回调使用
from .psd_utils import (
    get_visible_layers, extract_layer_hierarchy, ensure_collection_tree,
    find_layer_object_in_tree, serialize_hierarchy_snapshot,
    get_target_collection_for_layer, sync_collection_structure,
    move_layer_object_to_collection, sanitize_filename,
    get_cache_root, get_cache_png_path, cleanup_cache_files,
    _get_layer_bbox, render_layer_rgba, compute_image_md5,
    save_image_png, save_layer_to_png_and_checksum,
    check_packed_image_validity, load_or_update_image_from_cache,
    create_layer_identifier,
)
from .parallax_utils import (
    get_collection_from_record, get_all_objects_recursive,
    get_mesh_dimensions, match_layers_to_camera,
    restore_pre_match_transform, record_parallax_lock_state,
    restore_parallax_lock_state, parallax_scene_update_handler,
)


# ==================== 常量定义 ====================

# 缩放和尺寸相关

# 将用户站点包路径加入 sys.path（兼容手动安装场景）
# ---------------- 数据模型 ----------------


class LayerChecksum(PropertyGroup):
    value: StringProperty(default="")


class PSDFileRecord(PropertyGroup):
    filepath: StringProperty(name="文件路径", default="")
    layer_checksums: CollectionProperty(type=LayerChecksum)
    layer_order: StringProperty(default="")
    camera: PointerProperty(type=bpy.types.Object)
    collection: PointerProperty(
        type=bpy.types.Collection, name="集合", description="关联的Blender集合"
    )
    parallax_locked: BoolProperty(default=False)
    last_camera_transform: StringProperty(default="")
    file_mtime: FloatProperty(default=0.0)

    # 刷新控制选项
    refresh_update_texture: BoolProperty(
        name="更新贴图", description="刷新时更新图像贴图数据", default=True
    )
    refresh_update_mesh: BoolProperty(
        name="更新网格", description="刷新时更新网格顶点尺寸", default=False
    )
    refresh_update_transform: BoolProperty(
        name="更新变换",
        description="刷新时重置对象变换（位置/旋转/缩放）",
        default=False,
    )
    # 刷新时是否同步更新集合结构
    refresh_update_structure: BoolProperty(
        name="更新结构",
        description="刷新时同步更新PSD文件夹结构（集合/子集合）。关闭则只更新图层内容，保持当前集合组织方式不变",
        default=False,
    )
    # 层级结构快照（JSON字符串），用于刷新时检测PSD文件夹结构是否变化
    group_hierarchy: StringProperty(
        name="组层级快照",
        description="PSD文件图层组结构的序列化快照，用于刷新时检测结构变化",
        default="",
    )


class PSDImportProperties(PropertyGroup):
    file_records: CollectionProperty(type=PSDFileRecord)

    # === 异步刷新进度（面板进度条 + 状态栏双保险）===
    refresh_active: BoolProperty(
        name="异步处理中",
        description="是否有后台 PSD 任务正在运行",
        default=False,
    )
    refresh_progress: FloatProperty(
        name="进度",
        description="后台任务进度 0~1",
        min=0.0,
        max=1.0,
        default=0.0,
    )
    refresh_status: StringProperty(
        name="状态",
        description="后台任务当前状态文本",
        default="",
    )


# ---------------- UI 面板 ----------------


class PSD_PT_ImportPanel(Panel):
    bl_label = "PSD图层导入工具"
    bl_idname = "PSD_PT_ImportPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "PSD图层导入工具"

    def draw(self, context):
        layout = self.layout
        psd_tool = context.scene.psd_import_tool

        missing = check_dependencies()
        if missing:
            layout.label(text="缺少以下依赖库:", icon="ERROR")
            layout.label(text=", ".join(missing))
            layout.operator(
                "psd.check_dependencies", text="安装依赖库", icon="FILE_SCRIPT"
            )
            return

        layout.operator("psd.show_help", icon="QUESTION")
        layout.separator()
        layout.operator("psd.import_layers")
        layout.separator()

        # 异步进度条：只有在后台任务运行时才显示
        if psd_tool.refresh_active:
            box = layout.box()
            row = box.row(align=True)
            row.alignment = "CENTER"
            row.label(text="后台处理中", icon="PROPERTIES")
            # 浮点 slider 当作进度条（Blender 面板无原生进度条控件）
            box.prop(psd_tool, "refresh_progress", text="", slider=True)
            box.label(text=psd_tool.refresh_status or "…", icon="ARROW_LEFTRIGHT")
            layout.separator()

        box = layout.box()
        row = box.row(align=True)
        row.label(text="对选中的图层对象执行操作")
        sub_row = row.row(align=True)
        sub_row.scale_x = 0.8
        sub_row.scale_y = 0.8
        self.draw_selected_layer_buttons(sub_row)

        layout.separator()
        layout.label(text="PSD文件列表:")
        for i, record in enumerate(psd_tool.file_records):
            self.draw_file_record(layout, record, i)

    def draw_file_record(self, layout, record, index):
        box = layout.box()
        row = box.row(align=True)
        row.label(text=os.path.basename(record.filepath))
        sub_row = row.row(align=True)
        sub_row.scale_x = 0.8
        sub_row.scale_y = 0.8
        self.draw_file_buttons(sub_row, index)

        # 刷新控制选项 - 采用更美观的按钮组样式
        refresh_split = box.split(factor=0.3, align=True)
        refresh_split.label(text="刷新选项")
        refresh_row = refresh_split.row(align=True)
        refresh_row.prop(record, "refresh_update_texture", text="贴图", toggle=True)
        refresh_row.prop(record, "refresh_update_mesh", text="网格", toggle=True)
        refresh_row.prop(record, "refresh_update_transform", text="变换", toggle=True)
        refresh_row.prop(record, "refresh_update_structure", text="结构", toggle=True)

        parallax_box = box.box()
        parallax_row = parallax_box.row(align=True)
        parallax_row.prop(record, "camera", text="相机")
        parallax_row.operator(
            "psd.match_to_camera", text="", icon="CAMERA_DATA"
        ).file_index = index
        parallax_row.operator(
            "psd.toggle_parallax_lock",
            text="",
            icon="LOCKED" if record.parallax_locked else "UNLOCKED",
        ).file_index = index

    def draw_file_buttons(self, row, index):
        operators = [
            # 刷新相关
            ("psd.refresh_layers", "FILE_REFRESH"),
            ("psd.force_refresh_layers", "ERROR"),
            # 材质相关
            ("psd.toggle_texture_extension", "TEXTURE"),
            ("psd.toggle_blend_mode", "MATERIAL"),
            # 变换/文件/删除
            ("psd.reset_transform", "OBJECT_ORIGIN"),
            ("psd.change_filepath", "FILE_FOLDER"),
            ("psd.delete_psd_file", "X"),
        ]
        for op, icon in operators:
            row.operator(op, text="", icon=icon, emboss=True).file_index = index
            row.separator(factor=1.5)

    def draw_selected_layer_buttons(self, row):
        operators = [
            ("psd.refresh_selected_layers", "FILE_REFRESH", "刷新选中图层"),
            ("psd.reset_selected_transform", "OBJECT_ORIGIN", "重置选中图层变换"),
        ]
        for op, icon, _ in operators:
            row.operator(op, text="", icon=icon, emboss=True)
            row.separator(factor=1.5)


# ---------------- 工具函数 ----------------






def process_layer_from_cache(
    context: Any,
    layer: Any,
    image_name: str,
    collection: Any,
    psd_width: int,
    psd_height: int,
    layer_index: int,
    cache_png: str,
    existing_obj: Any = None,
    is_new: bool = False,
    expected_checksum: Optional[str] = None,
    force: bool = False,
) -> Any:
    # 先创建/更新几何体，保证即使图像加载失败也能看到对象
    obj = create_or_update_mesh_object(
        context,
        existing_obj,
        image_name,
        collection,
        layer,
        psd_width,
        psd_height,
        layer_index,
        is_new,
    )
    try:
        blender_image = load_or_update_image_from_cache(
            image_name, cache_png, pack=True, expected_checksum=expected_checksum,
            force=force,
        )
        if is_new:
            update_material(obj, blender_image)
    except (AttributeError, TypeError, RuntimeError, OSError, IOError) as e:
        # 图像加载失败时，仍然保留对象，但记录警告
        print(f"[PSD导入警告] 图层 '{image_name}' 的图像或材质加载失败: {e}")
    return obj


def create_or_update_mesh_object(
    context: Any,
    existing_obj: Any,
    image_name: str,
    collection: Any,
    layer: Any,
    psd_width: int,
    psd_height: int,
    layer_index: int,
    is_new: bool,
) -> Any:
    # 计算网格实际尺寸（保留 0.01 系数）
    mesh_scale = MESH_SCALE_FACTOR
    mesh_width = layer.width * mesh_scale
    mesh_height = layer.height * mesh_scale
    half_w = mesh_width / 2
    half_h = mesh_height / 2

    if existing_obj:
        # 更新现有对象：修改网格顶点而不是缩放
        mesh = existing_obj.data
        if mesh and len(mesh.vertices) >= 4:
            mesh.vertices[0].co = (-half_w, -half_h, 0.0)
            mesh.vertices[1].co = (-half_w, half_h, 0.0)
            mesh.vertices[2].co = (half_w, half_h, 0.0)
            mesh.vertices[3].co = (half_w, -half_h, 0.0)
            mesh.update()

        # 缩放保持为 (1, 1, 1)
        existing_obj.scale = (1, 1, 1)

        # 确保旧对象存在标准UV，避免显示为单色
        try:
            if mesh and not mesh.uv_layers:
                uv_layer = mesh.uv_layers.new(name="UVMap")
                if len(uv_layer.data) >= 4:
                    # 旧对象沿用旧 face winding (0,1,2,3)，UV 顺序保持原样
                    uv_layer.data[0].uv = UV_BOTTOM_LEFT
                    uv_layer.data[1].uv = UV_TOP_LEFT
                    uv_layer.data[2].uv = UV_TOP_RIGHT
                    uv_layer.data[3].uv = UV_BOTTOM_RIGHT
        except (AttributeError, TypeError, RuntimeError):
            pass
        # 刷新初始变换并立即应用位置/旋转/缩放
        update_initial_transform(
            existing_obj, layer, psd_width, psd_height, layer_index
        )
        set_object_transform(existing_obj, layer, psd_width, psd_height, layer_index)
        return existing_obj

    # 纯数据方式创建平面，避免依赖操作符上下文
    # 顶点基于实际尺寸计算
    mesh = bpy.data.meshes.new(name=f"{image_name}_mesh")
    verts = [
        (-half_w, -half_h, 0.0),
        (-half_w, half_h, 0.0),
        (half_w, half_h, 0.0),
        (half_w, -half_h, 0.0),
    ]
    faces = [(0, 3, 2, 1)]  # 从 +Z 俯视顺时针，法线指向 -Z（朝向默认相机）
    mesh.from_pydata(verts, [], faces)
    mesh.update()

    # 创建标准UV映射，确保图像正确显示
    try:
        uv_layer = mesh.uv_layers.new(name="UVMap")
        uv_data = uv_layer.data
        # 单个四边形的4个loop，顺序与faces一致
        if len(uv_data) >= 4:
            # UV 顺序跟随 face winding (0,3,2,1)
            uv_data[0].uv = UV_BOTTOM_LEFT    # vertex 0: 左下
            uv_data[1].uv = UV_BOTTOM_RIGHT   # vertex 3: 右下
            uv_data[2].uv = UV_TOP_RIGHT      # vertex 2: 右上
            uv_data[3].uv = UV_TOP_LEFT       # vertex 1: 左上
    except (AttributeError, TypeError, RuntimeError):
        pass

    obj = bpy.data.objects.new(f"{image_name}_object", mesh)
    # 链接到目标集合并确保在场景中
    if collection is not None:
        collection.objects.link(obj)
    else:
        context.scene.collection.objects.link(obj)

    set_object_transform(obj, layer, psd_width, psd_height, layer_index)
    obj[ATTR_LAYER_ID] = create_layer_identifier(layer)
    # 存储图层边界信息，用于UV调整计算
    obj[ATTR_LAYER_BBOX] = {
        "left": layer.left,
        "top": layer.top,
        "width": layer.width,
        "height": layer.height,
    }
    return obj


def update_initial_transform(
    obj: Any, layer: Any, psd_width: int, psd_height: int, layer_index: int
) -> None:
    mesh_scale = MESH_SCALE_FACTOR
    # 初始缩放改为 (1, 1, 1)，尺寸由网格顶点控制
    initial_scale = (1, 1, 1)

    center_x = layer.left + layer.width / 2
    center_y = layer.top + layer.height / 2

    x = (center_x - psd_width / 2) * mesh_scale
    y = (psd_height / 2 - center_y) * mesh_scale
    z = layer_index * LAYER_Z_OFFSET

    initial_location = (x, y, z)
    initial_rotation = (0, 0, 0)

    obj[ATTR_INITIAL_TRANSFORM] = {
        "scale": initial_scale,
        "location": initial_location,
        "rotation": initial_rotation,
    }


def set_object_transform(
    obj: Any, layer: Any, psd_width: int, psd_height: int, layer_index: int
) -> None:
    update_initial_transform(obj, layer, psd_width, psd_height, layer_index)
    # 强制设置为 (1, 1, 1)，尺寸由网格顶点控制
    obj.scale = (1, 1, 1)
    obj.location = obj[ATTR_INITIAL_TRANSFORM]["location"]
    obj.rotation_euler = obj[ATTR_INITIAL_TRANSFORM]["rotation"]


def update_material(obj: Any, blender_image: Any) -> None:
    mat_name = f"{obj.name}_material"
    mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    setup_material_nodes(mat, blender_image)


def setup_material_nodes(mat: Any, blender_image: Any) -> None:
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    texture_node = nodes.new("ShaderNodeTexImage")
    mix_shader = nodes.new("ShaderNodeMixShader")
    transparent_bsdf = nodes.new("ShaderNodeBsdfTransparent")
    emission_shader = nodes.new("ShaderNodeEmission")
    output_node = nodes.new("ShaderNodeOutputMaterial")

    texture_node.location = (-600, 0)
    emission_shader.location = (-300, 100)
    transparent_bsdf.location = (-300, -100)
    mix_shader.location = (0, 0)
    output_node.location = (300, 0)

    texture_node.image = blender_image
    # 对常规颜色图层使用sRGB，避免全图发灰或单色
    if hasattr(texture_node, "image_user"):
        pass
    try:
        texture_node.colorspace_settings.name = "sRGB"
    except (AttributeError, TypeError, RuntimeError):
        try:
            if hasattr(texture_node, "color_space"):
                texture_node.color_space = "sRGB"
        except (AttributeError, TypeError, RuntimeError):
            pass

    links.new(texture_node.outputs["Color"], emission_shader.inputs["Color"])
    links.new(emission_shader.outputs["Emission"], mix_shader.inputs[2])
    # 某些PSD层可能没有Alpha通道，连接前做保护
    try:
        links.new(texture_node.outputs["Alpha"], mix_shader.inputs[0])
    except (AttributeError, KeyError, TypeError, RuntimeError):
        mix_shader.inputs[0].default_value = DEFAULT_ALPHA
    links.new(transparent_bsdf.outputs["BSDF"], mix_shader.inputs[1])
    links.new(mix_shader.outputs["Shader"], output_node.inputs["Surface"])

    mat.blend_method = "BLEND"
    mat.use_backface_culling = False
    emission_shader.inputs["Strength"].default_value = 1.0


def calculate_adjusted_uv(
    obj: Any, layer: Any
) -> Optional[Tuple[float, float, float, float]]:
    """
    计算调整后的UV坐标，使旧内容区域在新贴图中正确显示

    当只更新贴图而不更新网格时，新旧图层可能尺寸/位置不同，
    需要通过调整UV使旧网格区域正确采样新贴图中对应的内容区域。

    Returns:
        tuple: (u_min, v_min, u_max, v_max) 或 None（无需调整时）
    """
    old_bbox = obj.get(ATTR_LAYER_BBOX)
    if not old_bbox:
        return None

    old_left = old_bbox.get("left", layer.left)
    old_top = old_bbox.get("top", layer.top)
    old_width = old_bbox.get("width", layer.width)
    old_height = old_bbox.get("height", layer.height)

    new_left, new_top = layer.left, layer.top
    new_width, new_height = layer.width, layer.height

    # 避免除以零
    if new_width <= 0 or new_height <= 0:
        return None

    # 尺寸和位置都没变，无需调整
    if (
        old_left == new_left
        and old_top == new_top
        and old_width == new_width
        and old_height == new_height
    ):
        return None

    # 计算UV坐标
    # u方向：旧图层区域在新贴图中的水平位置
    u_min = (old_left - new_left) / new_width
    u_max = u_min + (old_width / new_width)

    # v方向：需要考虑UV坐标系（原点在左下）与图层坐标系（原点在左上）的转换
    v_max = (new_top + new_height - old_top) / new_height
    v_min = v_max - (old_height / new_height)

    return (u_min, v_min, u_max, v_max)


def create_uv_adjustment_nodegroup(
    name: str, scale_x: float, scale_y: float, offset_x: float, offset_y: float
) -> Any:
    """
    创建UV调整节点组
    内部结构：UV输入 → Multiply(缩放) → Add(偏移) → Vector输出

    Args:
        name: 节点组名称
        scale_x, scale_y: UV缩放参数
        offset_x, offset_y: UV偏移参数

    Returns:
        节点组对象
    """
    # 检查是否已存在同名节点组，存在则更新参数
    ng = bpy.data.node_groups.get(name)
    if ng is None:
        ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    else:
        # 清除现有节点重新创建
        ng.nodes.clear()

    nodes = ng.nodes
    links = ng.links

    # 创建输入输出接口
    # Blender 4.0+ 使用 interface，旧版本使用 inputs/outputs
    try:
        # Blender 4.0+
        if not ng.interface.items_tree.get("Vector"):
            ng.interface.new_socket(
                name="Vector", in_out="INPUT", socket_type="NodeSocketVector"
            )
        if (
            not ng.interface.items_tree.get("Vector", None)
            or len([i for i in ng.interface.items_tree if i.name == "Vector"]) < 2
        ):
            ng.interface.new_socket(
                name="Vector", in_out="OUTPUT", socket_type="NodeSocketVector"
            )
    except AttributeError:
        # Blender 3.x
        if not ng.inputs.get("Vector"):
            ng.inputs.new("NodeSocketVector", "Vector")
        if not ng.outputs.get("Vector"):
            ng.outputs.new("NodeSocketVector", "Vector")

    # 创建节点
    group_input = nodes.new("NodeGroupInput")
    group_input.location = (-400, 0)

    group_output = nodes.new("NodeGroupOutput")
    group_output.location = (400, 0)

    # Separate XYZ - 分离UV分量
    separate_xyz = nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.location = (-200, 0)

    # Multiply X (缩放U)
    multiply_x = nodes.new("ShaderNodeMath")
    multiply_x.operation = "MULTIPLY"
    multiply_x.location = (0, 100)
    multiply_x.inputs[1].default_value = scale_x

    # Multiply Y (缩放V)
    multiply_y = nodes.new("ShaderNodeMath")
    multiply_y.operation = "MULTIPLY"
    multiply_y.location = (0, -100)
    multiply_y.inputs[1].default_value = scale_y

    # Add X (偏移U)
    add_x = nodes.new("ShaderNodeMath")
    add_x.operation = "ADD"
    add_x.location = (150, 100)
    add_x.inputs[1].default_value = offset_x

    # Add Y (偏移V)
    add_y = nodes.new("ShaderNodeMath")
    add_y.operation = "ADD"
    add_y.location = (150, -100)
    add_y.inputs[1].default_value = offset_y

    # Combine XYZ - 合并UV分量
    combine_xyz = nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.location = (300, 0)

    # 连接节点
    links.new(group_input.outputs[0], separate_xyz.inputs[0])
    links.new(separate_xyz.outputs["X"], multiply_x.inputs[0])
    links.new(separate_xyz.outputs["Y"], multiply_y.inputs[0])
    links.new(multiply_x.outputs[0], add_x.inputs[0])
    links.new(multiply_y.outputs[0], add_y.inputs[0])
    links.new(add_x.outputs[0], combine_xyz.inputs["X"])
    links.new(add_y.outputs[0], combine_xyz.inputs["Y"])
    links.new(combine_xyz.outputs[0], group_output.inputs[0])

    return ng


def apply_uv_adjustment_to_material(
    mat: Any,
    scale_x: float,
    scale_y: float,
    offset_x: float,
    offset_y: float,
    nodegroup_name: str,
) -> None:
    """
    在材质中插入UV调整节点组
    智能检测现有连接：
    - 如果 Image Texture.Vector 已有连接，在现有连接链中插入节点组
    - 如果无连接，创建 Texture Coordinate 节点并连接

    Args:
        mat: 材质对象
        scale_x, scale_y: UV缩放参数
        offset_x, offset_y: UV偏移参数
        nodegroup_name: 节点组名称
    """
    if not mat or not mat.use_nodes:
        _psd_log(f"[PSD-材质] apply_uv_adjustment: 跳过(无材质或无节点)")
        return

    _psd_log(f"[PSD-材质] >> apply_uv_adjustment: nodegroup='{nodegroup_name}', scale=({scale_x:.4f},{scale_y:.4f}), offset=({offset_x:.4f},{offset_y:.4f})")

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # 查找 Image Texture 节点
    texture_node = None
    for node in nodes:
        if node.type == "TEX_IMAGE":
            texture_node = node
            break

    if not texture_node:
        _psd_log(f"[PSD-材质] apply_uv_adjustment: 跳过(无TEX_IMAGE节点)")
        return

    # 检查是否已存在UV调整节点组实例（本插件创建的）
    existing_uv_group = None
    for node in nodes:
        if (
            node.type == "GROUP"
            and node.node_tree
            and node.node_tree.name == nodegroup_name
        ):
            existing_uv_group = node
            break

    # 检查 Image Texture.Vector 是否已有连接
    existing_source_node = None
    existing_source_socket = None
    for link in links:
        if link.to_node == texture_node and link.to_socket.name == "Vector":
            # 如果连接来自我们的UV更新节点组，需要找到更上游的连接
            if link.from_node == existing_uv_group:
                # 查找UV更新节点组的输入连接
                for inner_link in links:
                    if (
                        inner_link.to_node == existing_uv_group
                        and inner_link.to_socket == existing_uv_group.inputs[0]
                    ):
                        existing_source_node = inner_link.from_node
                        existing_source_socket = inner_link.from_socket
                        break
            else:
                existing_source_node = link.from_node
                existing_source_socket = link.from_socket
            break

    # 创建或更新节点组
    ng = create_uv_adjustment_nodegroup(
        nodegroup_name, scale_x, scale_y, offset_x, offset_y
    )

    if existing_uv_group is None:
        group_node = nodes.new("ShaderNodeGroup")
        group_node.location = (texture_node.location.x - 150, texture_node.location.y)
    else:
        group_node = existing_uv_group

    group_node.node_tree = ng
    group_node.label = nodegroup_name

    # 断开 Image Texture.Vector 的现有连接
    for link in list(links):
        if link.to_node == texture_node and link.to_socket.name == "Vector":
            links.remove(link)

    # 根据是否有现有连接来决定输入源
    if existing_source_node and existing_source_socket:
        # 有现有连接：插入到现有连接链中
        # 断开节点组输入的旧连接
        for link in list(links):
            if link.to_node == group_node and link.to_socket == group_node.inputs[0]:
                links.remove(link)
        # 连接：现有源节点 → UV更新节点组
        links.new(existing_source_socket, group_node.inputs[0])
    else:
        # 无现有连接：创建或获取 Texture Coordinate 节点
        tex_coord = None
        for node in nodes:
            if node.type == "TEX_COORD":
                tex_coord = node
                break
        if tex_coord is None:
            tex_coord = nodes.new("ShaderNodeTexCoord")
            tex_coord.location = (
                texture_node.location.x - 300,
                texture_node.location.y,
            )
            # 标记这个节点是插件创建的，方便后续清理
            tex_coord["psd_plugin_created"] = True
        # 连接：Texture Coordinate.UV → UV更新节点组
        links.new(tex_coord.outputs["UV"], group_node.inputs[0])

    # 连接：UV更新节点组 → Image Texture.Vector
    links.new(group_node.outputs[0], texture_node.inputs["Vector"])
    _psd_log(f"[PSD-材质] apply_uv_adjustment 完成: 源={'外部连接(' + existing_source_node.name + ')' if existing_source_node else '新建TexCoord'}, 目标=TEX_IMAGE.Vector")


def remove_uv_adjustment_from_material(
    mat: Any, nodegroup_name: Optional[str] = None
) -> None:
    """
    从材质中移除UV调整节点组，恢复原有连接

    智能恢复：
    - 记录UV更新节点组的输入连接（来源节点）
    - 移除节点组后，恢复原来的连接：源节点 → Image Texture.Vector
    - 只删除插件创建的 Texture Coordinate 节点

    Args:
        mat: 材质对象
        nodegroup_name: 节点组名称（可选，不指定则移除所有UV调整节点组）
    """
    if not mat or not mat.use_nodes:
        _psd_log(f"[PSD-材质] remove_uv_adjustment: 跳过(无材质或无节点)")
        return

    _psd_log(f"[PSD-材质] >> remove_uv_adjustment: mat='{mat.name}', nodegroup='{nodegroup_name if nodegroup_name else '(所有UV更新_xxx)'}'")

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # 查找 Image Texture 节点
    texture_node = None
    for node in nodes:
        if node.type == "TEX_IMAGE":
            texture_node = node
            break

    if not texture_node:
        return

    # 查找 UV调整节点组实例，并记录其输入连接
    nodes_to_remove = []
    restore_source_node = None
    restore_source_socket = None

    for node in nodes:
        if node.type == "GROUP" and node.node_tree:
            if nodegroup_name is None or node.node_tree.name == nodegroup_name:
                if node.node_tree.name.startswith("UV更新_"):
                    # 记录这个节点组的输入连接（用于恢复）
                    for link in links:
                        if link.to_node == node and link.to_socket == node.inputs[0]:
                            restore_source_node = link.from_node
                            restore_source_socket = link.from_socket
                            break
                    nodes_to_remove.append(node)

    # 如果没有找到UV更新节点组，直接返回
    if not nodes_to_remove:
        return

    # 查找插件创建的 Texture Coordinate 节点（有标记的才删除）
    tex_coord_to_remove = None
    if restore_source_node and restore_source_node.type == "TEX_COORD":
        if restore_source_node.get("psd_plugin_created"):
            tex_coord_to_remove = restore_source_node
            restore_source_node = None  # 不恢复连接，因为源节点也要删除
            restore_source_socket = None

    # 断开 Image Texture.Vector 的现有连接
    for link in list(links):
        if link.to_node == texture_node and link.to_socket.name == "Vector":
            links.remove(link)

    # 删除节点
    for node in nodes_to_remove:
        # 断开节点的所有连接
        for link in list(links):
            if link.from_node == node or link.to_node == node:
                links.remove(link)
        # 删除节点组数据
        ng_name = node.node_tree.name if node.node_tree else None
        nodes.remove(node)
        # 清理未使用的节点组数据
        if ng_name:
            ng = bpy.data.node_groups.get(ng_name)
            if ng and ng.users == 0:
                bpy.data.node_groups.remove(ng)

    # 删除插件创建的 Texture Coordinate 节点
    if tex_coord_to_remove:
        nodes.remove(tex_coord_to_remove)

    # 恢复原有连接：源节点 → Image Texture.Vector
    if restore_source_node and restore_source_socket:
        links.new(restore_source_socket, texture_node.inputs["Vector"])


def update_existing_layer_object(
    context: Any,
    obj: Any,
    layer: Any,
    psd_width: int,
    psd_height: int,
    layer_index: int,
    update_texture: bool,
    update_mesh: bool,
    update_transform: bool,
    cache_png: Optional[str] = None,
    expected_checksum: Optional[str] = None,
    collection: Any = None,
    force: bool = False,
) -> None:
    """
    根据控制选项更新现有图层对象

    Args:
        context: Blender上下文
        obj: 要更新的对象
        layer: PSD图层数据
        psd_width, psd_height: PSD画布尺寸
        layer_index: 图层索引
        update_texture: 是否更新贴图
        update_mesh: 是否更新网格
        update_transform: 是否更新变换
        cache_png: 缓存PNG路径（update_texture=True时需要）
        expected_checksum: 预期校验和（update_texture=True时需要）
        collection: 集合（备用）
    """
    # 更新贴图
    if update_texture and cache_png:
        try:
            image_name = obj.name.replace("_object", "")
            _psd_log(f"[PSD-图像] 更新贴图: obj='{obj.name}' → image='{image_name}'")
            blender_image = load_or_update_image_from_cache(
                image_name, cache_png, pack=True, expected_checksum=expected_checksum,
                force=force,
            )
        except (AttributeError, TypeError, RuntimeError) as e:
            _psd_log(f"[PSD图像更新] 异常: '{obj.name}' → {e}")

    # UV调整逻辑：只更新贴图而不更新网格时，通过材质节点组调整UV
    if update_texture and not update_mesh:
        uv_coords = calculate_adjusted_uv(obj, layer)
        mat = obj.data.materials[0] if obj.data.materials else None

        if uv_coords:
            u_min, v_min, u_max, v_max = uv_coords
            # 转换为缩放和偏移参数
            scale_x = u_max - u_min
            scale_y = v_max - v_min
            offset_x = u_min
            offset_y = v_min

            # 生成节点组名称（简化命名：序号_PSD文件名前缀）
            # 对象名格式：{序号}_{PSD文件名}_{图层名}_object
            name_parts = obj.name.replace("_object", "").split("_")
            # 取序号和PSD文件名的第一部分，避免名称过长
            short_name = (
                "_".join(name_parts[:2]) if len(name_parts) >= 2 else name_parts[0]
            )
            nodegroup_name = f"UV更新_{short_name}"

            # 获取对象材质并应用UV调整节点组
            if mat:
                apply_uv_adjustment_to_material(
                    mat, scale_x, scale_y, offset_x, offset_y, nodegroup_name
                )
        else:
            # 新旧尺寸一致，不需要UV调整，移除现有的UV调整节点组（如果存在）
            if mat:
                remove_uv_adjustment_from_material(mat)

    # 记录旧的初始变换（用于保持相对位置）
    old_initial_location = None
    current_location = None
    if update_mesh and not update_transform:
        # 需要保持相对位置时，先记录旧的初始位置和当前位置
        if ATTR_INITIAL_TRANSFORM in obj:
            try:
                old_initial_location = mathutils.Vector(
                    obj[ATTR_INITIAL_TRANSFORM]["location"]
                )
                current_location = obj.location.copy()
            except (KeyError, ValueError, TypeError):
                pass

    # 更新网格顶点
    if update_mesh:
        try:
            mesh = obj.data
            if mesh and len(mesh.vertices) >= 4:
                mesh_scale = MESH_SCALE_FACTOR
                mesh_width = layer.width * mesh_scale
                mesh_height = layer.height * mesh_scale
                half_w = mesh_width / 2
                half_h = mesh_height / 2
                mesh.vertices[0].co = (-half_w, -half_h, 0.0)
                mesh.vertices[1].co = (-half_w, half_h, 0.0)
                mesh.vertices[2].co = (half_w, half_h, 0.0)
                mesh.vertices[3].co = (half_w, -half_h, 0.0)
                mesh.update()
        except (AttributeError, TypeError, RuntimeError):
            pass

        # 更新网格时，移除UV调整节点组（恢复默认状态）
        mat = obj.data.materials[0] if obj.data.materials else None
        if mat:
            remove_uv_adjustment_from_material(mat)

        # 更新网格时同步更新 layer_bbox
        obj[ATTR_LAYER_BBOX] = {
            "left": layer.left,
            "top": layer.top,
            "width": layer.width,
            "height": layer.height,
        }

    # 始终更新 initial_transform 记录（用于重置变换功能）
    update_initial_transform(obj, layer, psd_width, psd_height, layer_index)

    # 处理变换更新
    if update_transform:
        # 完全重置变换
        set_object_transform(obj, layer, psd_width, psd_height, layer_index)
    elif (
        update_mesh
        and old_initial_location is not None
        and current_location is not None
    ):
        # 更新了网格但不更新变换：保持相对位置
        try:
            # 计算用户的位置偏移量（相对于旧的图层中心）
            offset = current_location - old_initial_location
            # 应用偏移到新的初始位置
            new_initial_location = mathutils.Vector(
                obj[ATTR_INITIAL_TRANSFORM]["location"]
            )
            obj.location = new_initial_location + offset
        except (AttributeError, TypeError, RuntimeError):
            pass

    # === 材质完整性诊断（只读，不改任何数据）===
    try:
        _psd_log(f"[PSD-材质] >> 材质诊断: obj='{obj.name}'")
        mat = obj.data.materials[0] if obj.data.materials else None
        if mat is None:
            _psd_log(f"[PSD-材质] 对象无材质: obj='{obj.name}'")
        else:
            _psd_log(f"[PSD-材质] 材质存在: mat='{mat.name}', use_nodes={mat.use_nodes}")
            if mat.use_nodes and mat.node_tree:
                node_count = len(mat.node_tree.nodes)
                tex_nodes = [n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE']
                _psd_log(f"[PSD-材质] 节点树: {node_count}个节点, {len(tex_nodes)}个TEX_IMAGE")
                for tn in tex_nodes:
                    img_ref = tn.image.name if tn.image else '(无)'
                    _psd_log(f"[PSD-材质] TEX_IMAGE节点: label='{tn.label}', image='{img_ref}'")
                if update_texture and cache_png:
                    image_name = obj.name.replace("_object", "")
                    updated_img = bpy.data.images.get(image_name)
                    if updated_img and tex_nodes:
                        for tn in tex_nodes:
                            if tn.image and tn.image != updated_img:
                                _psd_log(f"[PSD-材质] 图像引用不一致: 纹理节点='{tn.image.name}', 本次更新='{updated_img.name}'")
                            elif tn.image and tn.image == updated_img:
                                _psd_log(f"[PSD-材质] 图像引用一致: '{tn.image.name}'")
                uv_groups = [n for n in mat.node_tree.nodes if n.type == 'GROUP' and n.node_tree and n.node_tree.name.startswith(UV_ADJUST_NODEGROUP_PREFIX)]
                if uv_groups:
                    _psd_log(f"[PSD-材质] UV调整节点组存在: {[ng.node_tree.name for ng in uv_groups]}")
                else:
                    _psd_log(f"[PSD-材质] 无UV调整节点组")
            else:
                _psd_log(f"[PSD-材质] 材质无节点树或use_nodes=False")
    except Exception as e:
        _psd_log(f"[PSD-异常] 材质诊断异常: obj='{obj.name}', 异常={type(e).__name__}: {e}")


# ---------------- 操作符：导入/刷新/重置 等 ----------------


class PSD_OT_ImportLayers(Operator):
    bl_idname = "psd.import_layers"
    bl_label = "导入PSD图层"
    bl_description = "选择并导入PSD文件"

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        if not self.filepath:
            self.report({"ERROR"}, "未选择PSD文件")
            return {"CANCELLED"}
        # 异步：后台解析渲染，主线程逐层应用
        from .async_runner import launch_async_job
        ok = launch_async_job(context, "IMPORT", -1, self.filepath)
        if not ok:
            self.report({"ERROR"}, "启动后台导入失败，请检查依赖与文件")
            return {"CANCELLED"}
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class PSD_OT_RefreshLayers(Operator):
    bl_idname = "psd.refresh_layers"
    bl_label = "刷新图层"
    bl_description = "刷新并更新修改过的PSD图层"

    file_index: IntProperty()

    def invoke(self, context, event):
        # 检查视差锁定状态
        psd_tool = context.scene.psd_import_tool
        if self.file_index >= 0 and self.file_index < len(psd_tool.file_records):
            psd_file = psd_tool.file_records[self.file_index]
            if psd_file.parallax_locked:
                # 视差锁定状态下弹出警告
                return context.window_manager.invoke_props_dialog(self, width=350)
        # 非视差锁定状态直接执行
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="警告：视差锁定已启用", icon="ERROR")
        layout.separator()
        layout.label(text="在视差锁定状态下刷新图层可能导致：")
        layout.label(text="• 对象变换属性与视差数据不同步")
        layout.label(text="• 视差效果计算错误")
        layout.separator()
        layout.label(text="建议：先关闭视差锁定再进行刷新操作")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}
        # 异步：后台解析渲染，主线程逐层应用（不冻结界面）
        from .async_runner import launch_async_job
        ok = launch_async_job(context, "REFRESH", self.file_index)
        if not ok:
            self.report({"ERROR"}, "启动后台刷新失败，请检查依赖与文件")
            return {"CANCELLED"}
        return {"FINISHED"}
class PSD_OT_ResetTransform(Operator):
    bl_idname = "psd.reset_transform"
    bl_label = "重置PSD图层变换"
    bl_description = "重置指定PSD文件的图层变换"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}

        psd_file = psd_tool.file_records[self.file_index]
        collection = get_collection_from_record(psd_file)
        if not collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        for obj in get_all_objects_recursive(collection):
            if ATTR_INITIAL_TRANSFORM in obj:
                initial_transform = obj[ATTR_INITIAL_TRANSFORM]
                obj.scale = initial_transform["scale"]
                obj.location = initial_transform["location"]
                obj.rotation_euler = initial_transform["rotation"]

        self.report({"INFO"}, "已重所有PSD图层的变换")
        return {"FINISHED"}


class PSD_OT_ChangeFilepath(Operator):
    bl_idname = "psd.change_filepath"
    bl_label = "更改PSD文件路径"
    bl_description = "更改指定PSD文件的文件路径"

    file_index: IntProperty()
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的件索引")
            return {"CANCELLED"}

        psd_tool.file_records[self.file_index].filepath = self.filepath
        try:
            psd_tool.file_records[self.file_index].file_mtime = os.path.getmtime(
                self.filepath
            )
        except (OSError, IOError, TypeError):
            psd_tool.file_records[self.file_index].file_mtime = 0.0
        self.report({"INFO"}, f"已更新文路径: {self.filepath}")
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class PSD_OT_ToggleBlendMode(Operator):
    bl_idname = "psd.toggle_blend_mode"
    bl_label = "切换混合模式"
    bl_description = "在混合和抖动模式之切换PSD文件的所有图层材质"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}

        psd_file = psd_tool.file_records[self.file_index]
        base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
        collection = get_collection_from_record(psd_file)
        if not collection:
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        changed_count = 0
        for obj in get_all_objects_recursive(collection):
            if ATTR_LAYER_ID in obj and obj.type == "MESH":
                for mat in obj.data.materials:
                    if mat and mat.blend_method == "BLEND":
                        mat.blend_method = "HASHED"
                    elif mat and mat.blend_method == "HASHED":
                        mat.blend_method = "BLEND"
                    changed_count += 1

        self.report(
            {"INFO"},
            f"已切换 {base_name} 的所有图层材质混合模式，共处理 {changed_count} 个材质",
        )
        return {"FINISHED"}


class PSD_OT_ToggleTextureExtension(Operator):
    bl_idname = "psd.toggle_texture_extension"
    bl_label = "切换纹理外插方式"
    bl_description = "在Clip、Mirror、Repeat之间轮切PSD文件所有图层材质的纹理外插方式"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}

        psd_file = psd_tool.file_records[self.file_index]
        collection = get_collection_from_record(psd_file)
        if not collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        changed_count = 0
        new_extension = None

        for obj in get_all_objects_recursive(collection):
            if ATTR_LAYER_ID in obj and obj.type == "MESH":
                for mat in obj.data.materials:
                    if mat and mat.use_nodes:
                        for node in mat.node_tree.nodes:
                            if node.type == "TEX_IMAGE":
                                current = node.extension
                                if new_extension is None:
                                    # 根据第一个节点的状态决定目标状态
                                    if current == "CLIP":
                                        new_extension = "MIRROR"
                                    elif current == "MIRROR":
                                        new_extension = "REPEAT"
                                    else:
                                        new_extension = "CLIP"
                                node.extension = new_extension
                                changed_count += 1

        extension_names = {"CLIP": "Clip", "MIRROR": "Mirror", "REPEAT": "Repeat"}
        ext_name = (
            extension_names.get(new_extension, new_extension) if new_extension else "无"
        )
        self.report(
            {"INFO"},
            f"已切换纹理外插方式为 {ext_name}，共处理 {changed_count} 个纹理节点",
        )
        return {"FINISHED"}


class PSD_MT_HelpMenu(bpy.types.Menu):
    bl_idname = "PSD_MT_HelpMenu"
    bl_label = "PSD图层导入工具帮助"

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.label(text="1. 导入PSD图层：")
        col.label(text="   点击'导入PSD图层'按钮，选择PSD文件进行导入。")
        col.label(text="2. 刷新图层：")
        col.label(text="   使用PSD文件列表中的刷新按钮更新图层。")
        col.label(text="3. 强制刷新图层：")
        col.label(text="   使用PSD文件列表中的强制刷新按钮完全重新导入图层。")
        col.label(text="4. 重置变换：")
        col.label(text="   使用PSD文件列表中的重置变换按钮恢复初始位置和比例。")
        col.label(text="5. 更改文件路径：")
        col.label(text="   使用PSD文件列表中的更改文件路径按钮修改PSD位置。")
        col.label(text="6. 切换混合模式：")
        col.label(text="   使用PSD文件列表中的切换混合模式按钮改变图层的显示方式。")
        col.label(text="7. 删除PSD文件信息：")
        col.label(text="   使用PSD文件列表中的删除按钮移除PSD文件相关信息。")
        col.label(text="8. 对选中的图层对象执行操作：")
        col.label(text="   使用顶部的按钮对选中的图层进行刷新或重置变换。")
        col.separator()
        col.label(text="注意：首次使用时，可能需要安装依赖库。")
        col.label(text="如有问题，请联系：toukou0091@gmail.com")


class PSD_OT_ShowHelp(Operator):
    bl_idname = "psd.show_help"
    bl_label = "显示帮助"
    bl_description = "显示插件使用帮助"

    def execute(self, context):
        bpy.ops.wm.call_menu(name="PSD_MT_HelpMenu")
        return {"FINISHED"}


class PSD_OT_CheckDependencies(Operator):
    bl_idname = "psd.check_dependencies"
    bl_label = "检查依赖库"
    bl_description = "检查并安装所需的Python依赖库"

    def execute(self, context):
        missing = check_dependencies()
        if not missing:
            self.report({"INFO"}, "所有依赖库已安装。")
            return {"FINISHED"}

        try:
            pybin = (
                getattr(bpy.app, "binary_path_python", sys.executable) or sys.executable
            )
            for package in missing:
                subprocess.check_call([pybin, "-m", "pip", "uninstall", "-y", package])
                subprocess.check_call(
                    [pybin, "-m", "pip", "install", "--no-cache-dir", package]
                )

            self.report({"INFO"}, "成功安装缺失的依赖库。请重新启用插件。")
        except Exception as e:
            self.report({"ERROR"}, f"安装依赖库时出错: {str(e)}")
        return {"FINISHED"}


class PSD_OT_ForceRefreshLayers(Operator):
    bl_idname = "psd.force_refresh_layers"
    bl_label = "强制刷新图层"
    bl_description = "强制刷新并重新载入PSD图层"

    file_index: IntProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout

        # 检查视差锁定状态并显示警告
        psd_tool = context.scene.psd_import_tool
        if self.file_index >= 0 and self.file_index < len(psd_tool.file_records):
            psd_file = psd_tool.file_records[self.file_index]
            if psd_file.parallax_locked:
                layout.label(text="警告：视差锁定已启用", icon="ERROR")
                layout.separator()
                layout.label(text="在视差锁定状态下刷新图层可能导致：")
                layout.label(text="• 对象变换属性与视差数据不同步")
                layout.label(text="• 视差效果计算错误")
                layout.separator()
                layout.label(text="建议：先关闭视差锁定再进行刷新操作")
                layout.separator()

        layout.label(text="强制刷新所有图层需要消耗比较多的时间，请确认是否执行？")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}
        # 异步：后台解析渲染，主线程逐层应用（不冻结界面）
        from .async_runner import launch_async_job
        ok = launch_async_job(context, "FORCE_REFRESH", self.file_index)
        if not ok:
            self.report({"ERROR"}, "启动后台强制刷新失败，请检查依赖与文件")
            return {"CANCELLED"}
        return {"FINISHED"}
class PSD_OT_DeletePSDFile(Operator):
    bl_idname = "psd.delete_psd_file"
    bl_label = "删除PSD文件信息"
    bl_description = "删除与此PSD文件相关的信息"

    file_index: IntProperty()
    delete_type: EnumProperty(
        items=[
            ("PROPERTIES", "只删除属性", "只删除自定义属性和重命名集合"),
            ("COMPLETE", "彻底删除", "完全删除所有相关信息"),
        ],
        name="删除型",
        description="选择删除的范围",
        default="PROPERTIES",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(text="确定要删除此PSD文件信息吗？")
        layout.prop(self, "delete_type")

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        if self.file_index < 0 or self.file_index >= len(psd_tool.file_records):
            self.report({"ERROR"}, "无效的文件索引")
            return {"CANCELLED"}

        psd_file = psd_tool.file_records[self.file_index]
        collection = get_collection_from_record(psd_file)

        if collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            if self.delete_type == "PROPERTIES":
                for obj in get_all_objects_recursive(collection):
                    if ATTR_LAYER_ID in obj:
                        del obj[ATTR_LAYER_ID]
                    if ATTR_INITIAL_TRANSFORM in obj:
                        del obj[ATTR_INITIAL_TRANSFORM]
                collection.name = f"{collection.name}_delete_{self.file_index}"
            elif self.delete_type == "COMPLETE":
                for obj in list(get_all_objects_recursive(collection)):
                    bpy.data.objects.remove(obj, do_unlink=True)
                bpy.data.collections.remove(collection)

                for image in list(bpy.data.images):
                    if f"_{base_name}_" in image.name:
                        bpy.data.images.remove(image)

        psd_tool.file_records.remove(self.file_index)

        self.report({"INFO"}, f"已删除PSD文件 '{base_name}' 的相关信息")
        return {"FINISHED"}


class PSD_OT_RefreshSelectedLayers(Operator):
    bl_idname = "psd.refresh_selected_layers"
    bl_label = "刷新选中图层"
    bl_description = "刷新选中的PSD图层对象"

    def invoke(self, context, event):
        # 检查选中对象所属的PSD文件是否有视差锁定
        selected_objects = context.selected_objects
        psd_layers = [obj for obj in selected_objects if ATTR_LAYER_ID in obj]

        if psd_layers:
            psd_tool = context.scene.psd_import_tool
            for obj in psd_layers:
                collection = obj.users_collection[0] if obj.users_collection else None
                if collection:
                    psd_file = next(
                        (
                            file
                            for file in psd_tool.file_records
                            if hasattr(file, "collection")
                            and file.collection == collection
                        ),
                        None,
                    )
                    if psd_file and psd_file.parallax_locked:
                        # 发现视差锁定状态，弹出警告
                        return context.window_manager.invoke_props_dialog(
                            self, width=350
                        )

        # 无视差锁定直接执行
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="警告：视差锁定已启用", icon="ERROR")
        layout.separator()
        layout.label(text="在视差锁定状态下刷新图层可能导致：")
        layout.label(text="• 对象变换属性与视差数据不同步")
        layout.label(text="• 视差效果计算错误")
        layout.separator()
        layout.label(text="建议：先关闭视差锁定再进行刷新操作")

    def execute(self, context):
        selected_objects = context.selected_objects
        psd_layers = [obj for obj in selected_objects if obj.get("layer_identifier")]
        if not psd_layers:
            self.report({"WARNING"}, "没有选中PSD图层对象")
            return {"CANCELLED"}
        # 选中刷新：异步后台渲染，主线程逐层应用（不冻结界面）
        from .async_runner import launch_async_job
        ok = launch_async_job(context, "REFRESH_SELECTED", -1)
        if not ok:
            self.report({"ERROR"}, "启动选中刷新失败，请检查依赖与文件")
            return {"CANCELLED"}
        return {"FINISHED"}
class PSD_OT_ResetSelectedTransform(Operator):
    bl_idname = "psd.reset_selected_transform"
    bl_label = "重置选中图层变换"
    bl_description = "重置选中的PSD图层对象的变换属性"

    def execute(self, context):
        selected_objects = context.selected_objects
        psd_layers = [obj for obj in selected_objects if ATTR_INITIAL_TRANSFORM in obj]

        if not psd_layers:
            self.report({"WARNING"}, "没有选中可重置变换的PSD图层对象")
            return {"CANCELLED"}

        for obj in psd_layers:
            initial_transform = obj[ATTR_INITIAL_TRANSFORM]
            obj.location = initial_transform["location"]
            obj.rotation_euler = initial_transform["rotation"]
            obj.scale = initial_transform["scale"]

        self.report({"INFO"}, f"已置 {len(psd_layers)} 个选中图层的变换")
        return {"FINISHED"}


def check_dependencies():
    required_imports = {"psd_tools": "psd-tools", "PIL": "Pillow"}
    missing = []
    for import_name, install_name in required_imports.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(install_name)
    return missing


# ---------------- 相机匹配与视差锁定 ----------------




class PSD_OT_MatchToCamera(Operator):
    bl_idname = "psd.match_to_camera"
    bl_label = "匹配至相机"
    bl_description = "将PSD图层对象匹配到选定的相机视图或恢复原始状态"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        psd_file = psd_tool.file_records[self.file_index]

        if not psd_file.camera:
            self.report({"ERROR"}, "请先选择一个相机")
            return {"CANCELLED"}

        collection = get_collection_from_record(psd_file)
        if not collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        current_camera_transform = str(psd_file.camera.matrix_world)
        if psd_file.last_camera_transform != current_camera_transform:
            for obj in get_all_objects_recursive(collection):
                if ATTR_LAYER_ID in obj and "pre_match_transform" in obj:
                    del obj["pre_match_transform"]
            match_layers_to_camera(collection, psd_file.camera, psd_file)
            psd_file.last_camera_transform = current_camera_transform
            self.report({"INFO"}, "相机已移动，重新匹配图层")
        else:
            if any(
                "pre_match_transform" in obj
                for obj in get_all_objects_recursive(collection)
                if ATTR_LAYER_ID in obj
            ):
                restore_pre_match_transform(collection)
                self.report({"INFO"}, "已恢复图层原始状态")
            else:
                match_layers_to_camera(collection, psd_file.camera, psd_file)
                psd_file.last_camera_transform = current_camera_transform
                self.report({"INFO"}, "已将图层匹配至相机")

        return {"FINISHED"}


class PSD_OT_ToggleParallaxLock(Operator):
    bl_idname = "psd.toggle_parallax_lock"
    bl_label = "锁定视差"
    bl_description = "切换视差锁定状态"

    file_index: IntProperty()

    def execute(self, context):
        psd_tool = context.scene.psd_import_tool
        psd_file = psd_tool.file_records[self.file_index]

        if not psd_file.camera:
            self.report({"ERROR"}, "请先选择一个相机")
            return {"CANCELLED"}

        psd_file.parallax_locked = not psd_file.parallax_locked

        collection = get_collection_from_record(psd_file)
        if not collection:
            base_name = bpy.path.display_name_from_filepath(psd_file.filepath)
            self.report({"ERROR"}, f"找不到名为 {base_name} 的集合")
            return {"CANCELLED"}

        if psd_file.parallax_locked:
            record_parallax_lock_state(collection, psd_file.camera)
            self.report({"INFO"}, "视差锁定已启用")
        else:
            restore_parallax_lock_state(collection)
            self.report({"INFO"}, "视差锁定已禁用")

        return {"FINISHED"}


# ---------------- 注册与反注册 ----------------


class PSD_AddonPreferences(AddonPreferences):
    bl_idname = __package__

    log_to_text: BoolProperty(
        name="写入文本块",
        description="将调试日志写入Blender文本数据块（_PSD_Importer_Debug_Log），随.blend文件保存",
        default=False,
        update=lambda self, ctx: (
            setattr(constants, "LOG_TO_TEXT", self.log_to_text)
            if hasattr(constants, "LOG_TO_TEXT") else None
        ),
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "log_to_text")


classes = (
    PSD_AddonPreferences,
    LayerChecksum,
    PSDFileRecord,
    PSDImportProperties,
    PSD_PT_ImportPanel,
    PSD_OT_ImportLayers,
    PSD_OT_RefreshLayers,
    PSD_OT_ResetTransform,
    PSD_OT_ChangeFilepath,
    PSD_OT_ToggleBlendMode,
    PSD_OT_ToggleTextureExtension,
    PSD_OT_ShowHelp,
    PSD_MT_HelpMenu,
    PSD_OT_CheckDependencies,
    PSD_OT_ForceRefreshLayers,
    PSD_OT_DeletePSDFile,
    PSD_OT_RefreshSelectedLayers,
    PSD_OT_ResetSelectedTransform,
    PSD_OT_MatchToCamera,
    PSD_OT_ToggleParallaxLock,
)


def register():
    try:
        unregister()
    except (AttributeError, TypeError, RuntimeError):
        pass

    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            try:
                bpy.utils.unregister_class(cls)
                bpy.utils.register_class(cls)
            except (AttributeError, TypeError, RuntimeError, ValueError):
                pass
    bpy.types.Scene.psd_import_tool = PointerProperty(type=PSDImportProperties)

    # 注册异步执行器（延迟导入，避免模块加载时的循环依赖）
    try:
        from .async_runner import PSD_OT_AsyncJob
        bpy.utils.register_class(PSD_OT_AsyncJob)
    except (ImportError, AttributeError, TypeError, RuntimeError, ValueError) as e:
        print(f"[PSD] 注册异步执行器失败: {e}")

    try:
        if parallax_scene_update_handler not in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.append(parallax_scene_update_handler)
    except (AttributeError, TypeError, RuntimeError):
        pass

    try:
        for scene in bpy.data.scenes:
            if hasattr(scene, "psd_import_tool"):
                for psd_file in scene.psd_import_tool.file_records:
                    if psd_file.camera:
                        if not psd_file.last_camera_transform:
                            psd_file.last_camera_transform = str(
                                psd_file.camera.matrix_world
                            )
                        if "last_camera_position" not in psd_file:
                            psd_file["last_camera_position"] = list(
                                psd_file.camera.matrix_world.translation
                            )
    except AttributeError:
        pass
    except (TypeError, RuntimeError):
        pass

    # 同步偏好设置中的 LOG_TO_TEXT 到模块变量（偏好从文件恢复时 update 回调可能不触发）
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        constants.LOG_TO_TEXT = prefs.log_to_text
    except (KeyError, AttributeError):
        pass


def unregister():
    try:
        if parallax_scene_update_handler in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(parallax_scene_update_handler)
    except (AttributeError, TypeError, RuntimeError):
        pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except (AttributeError, TypeError, RuntimeError):
            pass

    # 注销异步执行器
    try:
        from .async_runner import PSD_OT_AsyncJob
        bpy.utils.unregister_class(PSD_OT_AsyncJob)
    except (ImportError, AttributeError, TypeError, RuntimeError, ValueError):
        pass

    try:
        del bpy.types.Scene.psd_import_tool
    except (AttributeError, TypeError, KeyError):
        pass


if __name__ == "__main__":
    register()
