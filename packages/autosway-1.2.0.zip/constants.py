"""AutoSway — 常量定义

集中管理所有硬编码值：自定义属性键名、阈值、默认值。
其他模块统一从此导入，避免魔法数字散落各处。
"""

# ==================== 骨骼运行时自定义属性键名 ====================
# 这些属性写在每根被管理的骨骼上，用于 handler 的状态追踪

ASWAY_KEY_BASE_ROT = "_asway_base_rot"      # 用户的基础旋转值（弧度）
ASWAY_KEY_LAST_SWAY = "_asway_last_sway"    # 上一轮计算的摆动值（弧度）
ASWAY_KEY_AXIS_INDEX = "_asway_axis_index"  # 摆动轴向索引（0/1/2）

# 所有运行时属性的集合，用于清除时批量删除
ASWAY_ALL_KEYS = (
    ASWAY_KEY_BASE_ROT,
    ASWAY_KEY_LAST_SWAY,
    ASWAY_KEY_AXIS_INDEX,
)

# ==================== 数值阈值 ====================

# 浮点数比较容差：低于此值视为"未变化"，跳过写入
# rotation_euler 是 float32 精度，1e-6 足够区分有意操作和浮点漂移
ROTATION_THRESHOLD = 1e-6

# ==================== 默认值 ====================

DEFAULT_SWAY_ANGLE = 10.0       # 度
DEFAULT_INCREMENTAL_ANGLE = 5.0  # 度
DEFAULT_LOOP_FRAMES = 40.0
DEFAULT_STAGGERED_FRAMES = 3.0
DEFAULT_OFFSET_FRAME = 0.0
DEFAULT_AXIS = 'Z'

# ==================== 轴向映射 ====================

AXIS_MAP = {'X': 0, 'Y': 1, 'Z': 2}

# ==================== UI 常量 ====================

UI_LIST_ROWS = 6  # 骨骼列表默认显示行数
