# AutoSway 开发者变更日志

本文件面向插件开发者，记录每个版本的代码变更、修复的 bug、架构调整等。

格式遵循 [Keep a Changelog](https://keepachangelog.com/)，版本号遵循 [SemVer](https://semver.org/)。

---

## [1.2.0] - 2026-07-20

### 新增

- **Alt+D 链接复制骨架自动继承摆动动画**：
  - `core.py`：新增 `_find_linked_armatures()`，通过 `data` 指针匹配链接复制体
  - handler 循环：首次初始化复制体的追踪状态并同步旋转值，规避伪用户修改检测
  - `strip_sway_from_bone`：连锁剥离所有链接复制体的摆动值
  - `ui.py`：`_get_visible_group_indices` 加入 `data` 指针匹配，链接复制体面板可见
  - Shift+D 完整复制不受影响（独立 data 块天然隔离）

- **摆动组管理 UI 按当前骨架过滤显示**：
  - `ui.py`：`draw()` 新增 `_get_visible_group_indices()` 过滤层
  - 有骨骼的组按 `armature_name` 匹配当前活动骨架，空组始终可见
  - 防御性兜底：无活动骨架时返回全部组
  - 仅 `ui.py` 单文件改动，不影响 operators/core/properties

### 变更

- `__init__.py`：`bl_info["version"]` 更新为 `(1, 2, 0)`
- `VERSION.md` / `CHANGELOG_DEV.md`：同步归档本次更新

### 测试

- 链接复制体同步摆动验证通过（Alt+D 创建复制体后参数同步、摆动同步）
- 不双倍叠加验证通过（原骨架与复制体各自独立计算，不出现摆动翻倍）
- 参数同步验证通过（修改原骨架参数后复制体同步变化）
- 删除连锁验证通过（删除摆动组后复制体骨骼的摆动同步剥离）
- UI 过滤 3 场景验证通过：两骨架切换显示、空组始终可见、过滤态增删骨骼正常

---

## [1.1.0] - 2026-07-03

### 新增

- **父子级传导模式**：摆动传导改为按骨骼实际父子级深度计算（`compute_bone_depth`）。
  handler 通过 `has_parent_child_in_group` 自动检测组内是否有父子关系，有则使用深度，
  无则回退到列表序号。
- **层级模式 UI**：有父子关系的骨骼组以树形缩进结构显示，带折叠/展开功能。
  使用 `split(factor=0.92)` 递归嵌套实现缩进（经 Blender 5.1 验证可行）。
- **平铺模式保留**：无父子关系时保持原有平铺列表 + 上下移动按钮。
- **混合场景检测**：当一个组同时包含有父子关系的骨骼和独立骨骼时，
  独立骨骼作为根节点（depth=0），UI 添加提示说明。
- **SwayBoneItem.expanded**：新增属性存储骨骼树节点的折叠状态。

### 变更

- **默认参数优化**：摆动角度 20→10、递增角度 1→5、循环帧数 24→40、错帧量 5→3。
- **__init__.py**：`bl_info["version"]` 更新为 `(1, 1, 0)`。

### 修复

- **__init__.py**：移除 `autosway_handler` 未使用导入（S4）。
- **ui.py**：`_draw_bone_node` 递归深度保护，depth > 50 时终止并打出警告日志（W4）。

### 代码优化

- **ui.py**：`group_bones_map` 和 `group_bones_set` 合并为一次遍历构建（S1）。
- **core.py**：handler 中预构建 `group_bones_set`，传递给 `compute_bone_depth`
  和 `has_parent_child_in_group`，避免重复构建（S2）。
- **utils.py**：`get_children_in_group` 接收预构建的 `group_bones_map` 字典，
  O(1) 查找替代 O(n) 内循环（W2）。

### 测试

- 18 根骨骼（多层分叉）的深度计算全部通过，精确匹配理论深度
- 同深度骨骼的 sway 值完全一致（Bone.001 vs Bone.004 偏差 0.00°）
- 平铺模式回归验证通过（无父子关系时行为与 v1.0.0 一致）
- 全功能回归验证通过（手动操控、参数调整、轴向切换、禁用/启用、删除组）

---

## [1.0.0] - 2026-07-02

### 新增

- **初始版本**，从零开发，替代原 autosway_v0.5 插件
- 采用 Handler + 状态追踪模式（借鉴 Parallax Locker），弃用原插件的驱动器方案
- `depsgraph_update_post` + `frame_change_post` 双 handler 驱动摆动计算
- 三段式状态追踪状态机：检测用户修改 → 反推基础旋转 → 重新注入摆动
- 骨骼自定义属性追踪 `_asway_base_rot` / `_asway_last_sway` / `_asway_axis_index`
- 5 个 Operator：新建组、删除组、添加骨骼、移除骨骼、调整顺序
- 多摆动组管理（CollectionProperty），每组独立参数和骨骼列表
- 面板参数 update 回调，修改即触发 handler 重新计算
- 组的启用/禁用，禁用时自动剥离摆动值恢复基础旋转
- 轴向切换检测：自动清理旧轴摆动 + 重置新轴追踪状态
- 跨组骨骼冲突检测（invoke 弹窗确认）
- `load_post` handler：文件加载后自动恢复运行时 handler
- 骨骼缺失检测：UI 标记"缺失"图标，handler 跳过不报错

### 架构决策

- **弃用驱动器方案**：驱动器占有属性导致用户无法手动旋转骨骼和 K 帧，且参数写死在表达式字符串中无法实时更新
- **弃用 NLA 叠加方案**：NLA 的 Action Track 对其定义的属性通道是替换模式，用户一旦 K 帧就覆盖了 NLA 摆动贡献；且 NLA 仅在播放时求值，交互式 Pose Mode 下看不到效果
- **弃用约束代理方案**：需要在场景中生成空物体，视觉干扰大；多骨骼错帧需要多个空物体
- **选择 Handler + 状态追踪**：不占有属性、不生成额外对象、实时响应、实现复杂度低。核心模式直接复用 Parallax Locker 的成熟验证

### 开发中修复的问题

1. **`_asway_base_rot` 首次初始化 bug**：原逻辑仅在检测到用户变化时才写入 base_rot，导致首轮处理后属性不存在，第二轮误判。修复为首轮跳过检测 + 始终持久化 base_rot
2. **`depsgraph_update_post` 在 MCP 脚本执行时不触发**：改为同时注册 `frame_change_post` + `depsgraph_update_post` 双 handler，前者保证帧变化必定触发，后者捕获用户手动旋转
3. **`_RestrictContext` 报错**：`register()` 中访问 `bpy.context.scene` 在插件管理器启用时会失败。移除该访问，改为完全依赖 `load_post` handler 和 `AddGroup` 操作触发 handler 注册
4. **轴向切换时旧轴残留**：handler 检测 `axis_index` 变化时自动清理旧轴并重置新轴追踪状态

### 代码审查后修复（审查官：agent-mpj3kvf3）

#### MAJOR

- `__init__.py`：裸 `except Exception: pass` 改为精确捕获 `ValueError`（已注册），其余异常 print + raise
- `operators.py`：RemoveBone / AddBones 冲突检测 / AddBones 去重检查，全部从只比 `bone_name` 改为 `(bone_name, armature_name)` 联合键
- `core.py`：handler 内自定义属性写入（`base_rot`、`last_sway`、`axis_index`）加 `if bone.get(key) != value` 变化检测，减少不必要的 depsgraph 重复触发
- `core.py` + `constants.py`：删除 `ASWAY_KEY_GROUP` 死写入（定义后只在 handler 中赋值，从未被读取）

#### MINOR

- `utils.py`：删除 3 个未调用的死函数（`find_armature`、`degrees_to_radians`、`has_sway_props`）
- `utils.py`：`ensure_euler_rotation` 删除永远为 True 的 `return` 语句
- `utils.py`：`clear_sway_props` 中的延迟导入改为顶部 import
- `properties.py`：`unregister_scene_props` 加 `hasattr` 存在性检查
- `core.py`：handler 异常分类处理，`AttributeError` 静默跳过，其余异常加 `traceback.print_exc()`
- `core.py`：清理对 `find_armature` 的无用 import

### 测试

- 9 项功能测试全部通过（基础摆动、手动旋转叠加、参数实时调整、轴向切换、禁用/启用、移除骨骼、重排序、删除组、多组独立管理）
- 4 项边界情况测试通过（空组、loop_frames=1、sway_angle=0、删除骨骼后 handler）
- 正弦波 11 帧采样点全部与理论值精确匹配
- 错帧量验证通过
- Blender 5.1 实际环境验证通过
