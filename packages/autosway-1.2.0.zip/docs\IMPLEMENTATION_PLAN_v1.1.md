# AutoSway v1.1.0 实施计划：父子级传导模式

> 版本：v1.1.0 规划稿
> 日期：2026-07-02
> 目标：将摆动传导从"列表顺序"改为"实际父子级深度"，同时在 UI 上体现骨骼层级关系

---

## 一、变更概述

### 1.1 当前行为

```
摆动公式中 bone_index = enumerate(group.bones) 的列表序号
delay = staggered_frames × bone_index
angle = sway_angle + incremental_angle × bone_index
```

问题：列表序号与骨骼实际父子级关系无关。分叉场景下，分支骨骼的 delay 会从主干末端的位置继续跳（而非从分叉点的深度继续），导致波形断裂。

### 1.2 目标行为

```
摆动公式中 bone_index = 骨骼在组内的层级深度
  从组内根骨骼（父级不在组内 或 无父级）开始算步数
  沿父级链向上走，每经过一在组内的父级 +1，直到走到不在组内的父级或 None
```

分叉场景深度示例：

```
Bone(0) → Bone.001(1) → Bone.002(2) → Bone.003(3)
                       ↘ Bone.004(2) → Bone.005(3) → Bone.006(4)
```

Bone.004 的深度是 2（和 Bone.002 同深），波同时到达分叉后的两个分支。

### 1.3 UI 变更

- 有父子级关系时：骨骼列表以缩进树形结构显示，带折叠功能，隐藏上下移动按钮
- 无父子级关系时（全部独立骨骼）：保持平铺列表，显示上下移动按钮，用列表序号做 index

---

## 二、改动详情

### 2.1 utils.py — 新增深度计算 + 层级关系检测

#### 新增函数

```python
def compute_bone_depth(scene, group, bone_item):
    """计算骨骼在组内的层级深度。

    从该骨骼沿父级链向上走，每经过一个在组内的父级 +1。
    直到父级不在组内（或无父级），返回步数。

    Args:
        scene: 当前场景
        group: SwayGroup 实例
        bone_item: SwayBoneItem 实例

    Returns:
        int: 组内深度（0 = 组内根骨骼）
    """
    # 构建组内骨骼的 (bone_name, armature_name) 集合
    group_bones = {(item.bone_name, item.armature_name) for item in group.bones}

    bone = find_bone_in_scene(scene, bone_item.armature_name, bone_item.bone_name)
    if bone is None:
        return 0

    depth = 0
    current = bone.parent
    while current is not None:
        if (current.name, bone_item.armature_name) in group_bones:
            depth += 1
            current = current.parent
        else:
            break

    return depth
```

```python
def has_parent_child_in_group(scene, group):
    """检测组内是否存在任何父子级关系。

    遍历组内每根骨骼，检查其父级是否也在组内。
    只要找到一对就返回 True。

    Returns:
        bool: True 表示组内至少有一对父子关系
    """
    group_bones = {(item.bone_name, item.armature_name) for item in group.bones}

    for item in group.bones:
        bone = find_bone_in_scene(scene, item.armature_name, item.bone_name)
        if bone is None:
            continue
        if bone.parent is not None:
            if (bone.parent.name, item.armature_name) in group_bones:
                return True

    return False
```

```python
def get_children_in_group(scene, group, bone_item):
    """获取某骨骼在组内的直接子级列表。

    Args:
        scene: 当前场景
        group: SwayGroup 实例
        bone_item: 父骨骼条目

    Returns:
        list[SwayBoneItem]: 在组内且是 bone_item 直接子级的条目列表
    """
    group_bones = {(item.bone_name, item.armature_name) for item in group.bones}
    bone = find_bone_in_scene(scene, bone_item.armature_name, bone_item.bone_name)
    if bone is None:
        return []

    children = []
    for child_bone in bone.children:
        if (child_bone.name, bone_item.armature_name) in group_bones:
            # 在组内找到的子骨骼条目
            for item in group.bones:
                if item.bone_name == child_bone.name and item.armature_name == bone_item.armature_name:
                    children.append(item)
                    break

    return children
```

```python
def get_root_bones_in_group(scene, group):
    """获取组内所有根骨骼（父级不在组内 或 无父级）。

    Returns:
        list[SwayBoneItem]: 根骨骼条目列表（保持列表中的出现顺序）
    """
    group_bones = {(item.bone_name, item.armature_name) for item in group.bones}
    roots = []

    for item in group.bones:
        bone = find_bone_in_scene(scene, item.armature_name, item.bone_name)
        if bone is None:
            # 骨骼缺失也当作根（让 handler 跳过它，不让它阻塞子级遍历）
            roots.append(item)
            continue

        parent = bone.parent
        if parent is None:
            roots.append(item)
        elif (parent.name, item.armature_name) not in group_bones:
            roots.append(item)

    return roots
```

#### 影响分析

这些函数都是纯查询，不修改任何状态。handler 每帧调 `compute_bone_depth`，开销为每根骨骼沿父级链向上遍历（链长通常 < 20）。对于 100 根骨骼的组，总遍历量 < 2000 步，远低于 1ms。

`has_parent_child_in_group` 和 `get_root_bones_in_group` 仅在 UI 重绘时调用，不在 handler 中。

---

### 2.2 core.py — handler 使用深度替代列表序号

#### compute_sway 不变

`compute_sway(group, bone_index, frame)` 的接口不变，仍然接收一个 int 型 `bone_index`。变化的是调用方传入的值从"列表序号"变为"组内深度"。

#### handler 修改

```python
# 当前代码：
for idx, bone_item in enumerate(group.bones):
    _process_bone(scene, group, bone_item, idx, frame)

# 改为：
from .utils import compute_bone_depth
for bone_item in group.bones:
    depth = compute_bone_depth(scene, group, bone_item)
    _process_bone(scene, group, bone_item, depth, frame)
```

每帧每根骨骼调一次 `compute_bone_depth`。如果一个组有 50 根骨骼，每根平均遍历 5 级父级链，共 250 次属性查找，开销可忽略。

#### 无父子级时的回退

如果组内没有父子关系（`has_parent_child_in_group` 返回 False），保持使用列表序号。这样无父子关系的骨骼组行为完全不变，上下移动按钮也保留意义。

```python
from .utils import compute_bone_depth, has_parent_child_in_group

use_depth = has_parent_child_in_group(scene, group)

if use_depth:
    for bone_item in group.bones:
        depth = compute_bone_depth(scene, group, bone_item)
        _process_bone(scene, group, bone_item, depth, frame)
else:
    for idx, bone_item in enumerate(group.bones):
        _process_bone(scene, group, bone_item, idx, frame)
```

**优化**：`has_parent_child_in_group` 每帧调用一次即可，不属于内循环。

---

### 2.3 properties.py — SwayBoneItem 新增折叠状态

```python
class SwayBoneItem(bpy.types.PropertyGroup):
    bone_name: StringProperty(name="骨骼名称")
    armature_name: StringProperty(name="骨架名称")

    # v1.1 新增：UI 折叠状态（仅层级模式下使用）
    expanded: BoolProperty(name="展开", default=True)
```

这个属性只在层级模式下生效。平铺模式下不读取它。

**向后兼容**：已保存的 .blend 文件中 SwayBoneItem 没有 `expanded` 字段，Blender 的 PropertyGroup 机制会在加载时自动填充默认值 `True`，不破坏旧数据。

---

### 2.4 ui.py — 层级模式骨骼列表

#### 两种渲染模式

```python
def _draw_bone_list(self, layout, context, group, group_index):
    """根据组内是否存在父子关系，选择渲染模式。"""
    from .utils import has_parent_child_in_group

    has_hierarchy = has_parent_child_in_group(context.scene, group)

    if has_hierarchy:
        self._draw_hierarchical_bones(layout, context, group, group_index)
    else:
        self._draw_flat_bones(layout, context, group, group_index)
```

#### 层级模式（有父子关系）

```
骨骼列表（7 根，层级模式）
▼ Bone                    [×]
  ▼ Bone.001              [×]
    ▼ Bone.002            [×]
      ► Bone.003          [×]
    ► Bone.004            [×]
      ► Bone.005          [×]
        ► Bone.006        [×]
```

- 缩进：每层深度对应一定缩进（Blender 的 `layout.row()` 没有直接缩进，用 `split` 或 `box` 嵌套实现）
- 折叠箭头：有子级的骨骼显示 TRIA_DOWN / TRIA_RIGHT，无子级不显示
- 骨骼名前图标：BONE_DATA（正常）或 ERROR（缺失）
- 移除按钮 [×]：每根都有
- **不显示**上下移动按钮（层级由 Edit Mode 决定）

实现核心：递归绘制

```python
def _draw_hierarchical_bones(self, layout, context, group, group_index):
    """以树形结构绘制骨骼列表。"""
    from .utils import get_root_bones_in_group, get_children_in_group

    roots = get_root_bones_in_group(context.scene, group)
    for root in roots:
        self._draw_bone_node(layout.box(), context, group, group_index, root, depth=0)

def _draw_bone_node(self, layout, context, group, group_index, bone_item, depth):
    """递归绘制单棵骨骼子树。"""
    children = get_children_in_group(context.scene, group, bone_item)

    # 当前骨骼行
    row = layout.row(align=True)

    # 缩进（用空 label 占位实现）
    if depth > 0:
        row.label(text="  " * depth, text_lstrip='', icon='NONE')

    # 折叠箭头（有子级才显示）
    if len(children) > 0:
        icon = 'TRIA_DOWN' if bone_item.expanded else 'TRIA_RIGHT'
        row.prop(bone_item, "expanded", text="", icon=icon, emboss=False)
    else:
        row.label(text="", icon='BLANK1')

    # 骨骼名
    exists = bone_exists(context.scene, bone_item.armature_name, bone_item.bone_name)
    if exists:
        row.label(text=bone_item.bone_name, icon='BONE_DATA')
    else:
        row.label(text=f"{bone_item.bone_name}（缺失）", icon='ERROR')

    # 移除按钮
    op = row.operator("autosway.remove_bone", text="", icon='X')
    op.group_index = group_index
    op.bone_name = bone_item.bone_name
    op.armature_name = bone_item.armature_name

    # 递归子级
    if bone_item.expanded:
        for child in children:
            self._draw_bone_node(layout, context, group, group_index, child, depth + 1)
```

**Blender UI 缩进的实现方式**：Blender 的 `UILayout` 没有标准的缩进参数。常见做法是用嵌套 `box()` 或在行首用 `split(factor=...)` 占位。实际实现时可能需要用 `row.split(factor=depth * 0.05)` 来模拟缩进。具体缩进方式在实现阶段调试确认。

#### 平铺模式（无父子关系）

保持现有行为不变：

```
骨骼列表（3 根）
Bone        ▲ ▼ [×]
Bone.001    ▲ ▼ [×]
Bone.002    ▲ ▼ [×]
```

上下移动按钮正常显示，用列表序号做 index。

---

### 2.5 operators.py — 基本无改动

现有的 5 个 Operator 逻辑不变：

- AddBones：仍然按选中顺序追加到列表尾部
- RemoveBone：从列表移除
- ReorderBones：仅在平铺模式下使用（UI 控制），代码本身无需修改

添加骨骼后，如果是层级模式，UI 会自动按父子关系重新排列显示顺序（因为遍历逻辑从根开始）。但 `group.bones` 的存储顺序不变，只是渲染顺序变了。

---

## 三、数据流变更

### 3.1 当前数据流

```
group.bones（列表）
  ↓ enumerate
bone_index (0, 1, 2, 3, ...)
  ↓ compute_sway
sway value
```

### 3.2 新数据流

```
group.bones（列表，存储顺序不变）
  ↓ 检测 has_parent_child_in_group
  ├── True → compute_bone_depth(每根骨骼) → depth → compute_sway
  └── False → enumerate → bone_index → compute_sway
```

### 3.3 深度计算的缓存考量

`compute_bone_depth` 每帧每根骨骼调一次。可以缓存深度值到骨骼的自定义属性中（如 `_asway_depth`），但有以下考量：

- 深度只在组内骨骼列表变化时才变（增删骨骼、骨骼父子关系变化）
- 帧变化不改变深度
- 参数变化不改变深度

**决定**：不缓存。原因：

1. 深度计算本身非常轻（几次属性查找）
2. 缓存需要处理失效逻辑（用户改了骨骼父子关系后需要重算），增加复杂度
3. 如果缓存错了，摆动效果会出错且难以排查

保持每帧实时计算是最可靠的方案。

---

## 四、边界情况

### 4.1 组内骨骼的父级不在组内

```
组内: [Bone.002, Bone.003]
Bone.001（不在组内）→ Bone.002（组内） → Bone.003（组内）
```

Bone.002 的深度 = 0（父级 Bone.001 不在组内，它是组内根骨骼）
Bone.003 的深度 = 1（父级 Bone.002 在组内，再往上 Bone.001 不在组内）

**正确**。波从 Bone.002 开始传导，Bone.003 延迟一帧量。

### 4.2 组内骨骼的父级被删除

骨骼的 `parent` 变为 None → 它成为组内根骨骼 → depth = 0。handler 自动适应，无需特殊处理。

### 4.3 多骨架场景

深度计算使用 `(bone_name, armature_name)` 联合键。不同骨架的同名骨骼不会互相干扰。但跨骨架不存在父子关系（Blender 的 bone.parent 只在同一骨架内），所以不受影响。

### 4.4 同一骨骼在组内的多个位置

SwayBoneItem 通过联合键去重了（AddBones 已做），不会出现同一骨骼在组内重复的情况。

### 4.5 循环父子关系

Blender 的骨骼不允许循环父子关系（Edit Mode 下就无法创建），所以不需要处理。

### 4.6 全部骨骼无父子关系（平行骨骼）

`has_parent_child_in_group` 返回 False → 使用平铺模式 → 列表序号做 index → 上下移动按钮显示。行为和 v1.0.0 完全一致。

### 4.7 混合情况：部分骨骼有父子，部分独立

```
组内: [Bone, Bone.001, Bone.002, FlagA, FlagB]
Bone → Bone.001 → Bone.002（有父子关系）
FlagA, FlagB（独立，无父子关系）
```

`has_parent_child_in_group` 返回 True → 使用层级模式 → UI 显示树形结构
FlagA 和 FlagB 作为根骨骼显示在顶层（depth=0），Bone 也作为根骨骼（depth=0）

这种情况下 FlagA、FlagB 和 Bone 都是 depth=0，波同时到达它们。Bone.001 depth=1，波延迟一步到达。

这可能不是用户想要的效果（用户可能希望 FlagA、FlagB 按列表顺序排），但这是正确的层级行为。如果用户不想要层级传导，可以把 FlagA、FlagB 放到另一个独立组中。

---

## 五、实施顺序

| 阶段 | 文件 | 内容 | 预计工作量 |
|------|------|------|-----------|
| **P1** | utils.py | 新增 4 个函数：compute_bone_depth、has_parent_child_in_group、get_children_in_group、get_root_bones_in_group | 20 分钟 |
| **P2** | core.py | handler 改为深度计算，加 has_parent_child_in_group 分支 | 10 分钟 |
| **P3** | properties.py | SwayBoneItem 新增 expanded 属性 | 5 分钟 |
| **P4** | ui.py | 双模式骨骼列表（层级树形 / 平铺），条件隐藏移动按钮 | 40 分钟 |
| **P5** | 测试验证 | 见第六节 | 20 分钟 |

总计约 95 分钟。

---

## 六、测试检查清单

### 6.1 功能验证

- [ ] 无父子关系的骨骼组：行为与 v1.0.0 完全一致（列表序号、上下移动按钮可用）
- [ ] 有父子关系的骨骼组：按深度传导，分叉处波形连贯
- [ ] 分叉场景：Bone.004 的 delay 等于 Bone.002 的 delay（同深度的波同时到达）
- [ ] 混合场景（部分有父子、部分独立）：独立骨骼作为根骨骼（depth=0）
- [ ] 删除一根骨骼后：子级骨骼的 depth 自动重算正确（因为父级被删变为根，或父级还在则继承）
- [ ] 添加新骨骼后：如果它有父子关系，UI 自动切换为层级模式

### 6.2 深度计算验证

- [ ] 单链 4 根骨骼：depth = 0, 1, 2, 3
- [ ] 分叉场景：主干和分支同深度的骨骼 depth 相等
- [ ] 组内骨骼的父级不在组内：该骨骼 depth = 0
- [ ] 组内只有一根骨骼：depth = 0
- [ ] 组内有空条目（骨骼缺失）：depth = 0，不报错

### 6.3 UI 验证

- [ ] 层级模式：树形缩进显示
- [ ] 层级模式：折叠/展开箭头可操作
- [ ] 层级模式：不显示上移/下移按钮
- [ ] 平铺模式：保持上下移动按钮
- [ ] 从有父子切到无父子（删除子级骨骼）：UI 自动切回平铺
- [ ] 从无父子切到有父子（添加子级骨骼）：UI 自动切到层级

### 6.4 回归测试

- [ ] v1.0.0 的全部功能不受影响（手动旋转、参数实时调整、轴向切换、禁用/启用、多组管理）
- [ ] 保存/加载 .blend 文件：骨骼列表数据保留，旧文件中 SwayBoneItem 没有 expanded 字段时自动填充默认值

---

## 七、向后兼容

### 7.1 已保存的 .blend 文件

- SwayGroup 数据：完全兼容，无新增字段
- SwayBoneItem 数据：`expanded` 字段在加载旧文件时自动填充默认值 True
- handler 行为：如果旧文件中的骨骼组有父子关系，v1.1.0 会自动切换为深度传导，效果可能和 v1.0.0 不同（更准确）

### 7.2 API 兼容

- `compute_sway(group, bone_index, frame)` 接口不变
- Operator 的 bl_idname 不变
- 面板的 bl_idname 和 bl_category 不变

### 7.3 与继承功能的兼容

之前开发的 `inherit_parent_sway` 功能已回滚，本次改动不涉及继承功能。

---

*本计划待 HAOAH 审阅后进入实施。*