# 执行计划：摆动组管理 UI 按当前骨架过滤

---

## 1. 问题回顾

### 当前现状

AutoSway 的摆动数据存在 `scene.autosway_groups`（场景级集合属性）。面板 `AUTOSWAY_PT_MainPanel.draw()` 直接遍历全部 `autosway_groups`，每个组逐组渲染。

场景中可能有多个骨架（例如角色 + 武器 + 头发），各自都有自己的摆动组。当前面板**不做任何过滤**，所有骨架的摆动组全部堆在一起显示，用户需要在混杂的列表中找自己当前在操作的骨架对应的组。

### 核心矛盾

面板的显示粒度是"场景中所有组"，而用户的操作粒度是"当前骨架的组"。两者不匹配，导致 UI 信息密度过高，查找困难。

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|---------|
| 姿态模式下只显示当前骨架的摆动组 | P0 | 进入姿态模式选中 Armature A → 只看到 Armature A 的组，Armature B 的组隐藏 |
| 非姿态模式下保持显示全部组 | P0 | ⚠ 设计约束：面板 `bl_context="posemode"`，只在姿态模式下渲染。此目标在当前面板配置下**不可观测**，不纳入验收，仅作为逻辑兜底 |
| 空组始终可见 | P1 | 新建的空摆动组不会被过滤掉，用户能正常往里面添加骨骼 |
| 组内骨骼列表不受影响 | P0 | 组展开后仍然显示组内**所有**骨骼，不做二次过滤 |

---

## 3. 设计方案

### 核心思路

在面板绘制入口处增加一层**过滤层**，根据当前姿态模式下的活动骨架判断哪些组应该显示。被过滤掉的组只是不绘制，不删除、不移动数据。

### 关键设计决策

| 决策 | 选项 | 选择理由 |
|------|------|---------|
| 过滤粒度 | **按组过滤** vs 按骨骼过滤 | 按组过滤。用户说的"摆动组"是整个组，而不是组内单根骨骼。按骨骼过滤会导致一个组部分显示，用户更难理解 |
| 过滤依据 | **活动骨架对象名称匹配** vs 其他方式 | 直接用 `bone_item.armature_name` 与当前活动骨架的名称匹配。这是最直接的关联方式，不引入新的数据结构 |
| 空组处理 | **始终显示** vs 跟随过滤 | 空组始终显示。用户创建组后需要能立即看到它并往里加骨骼 |
| 非姿态模式 | **显示全部** vs 不显示 | ⚠ 面板 `bl_context="posemode"`，非姿态模式下不渲染，此分支实际不会执行，作为防御性兜底保留 |

### 索引映射策略

当前所有 Operator 通过 `group_index`（真实索引）操作数据。面板过滤后，循环的索引不再是连续的真实索引。解决方式：

- 在 `draw()` 中构建一个**可见组的真实索引列表**（`list[int]`）
- 用这个列表做循环，传递给 `_draw_group()` 的 `index` 参数仍然是真实索引
- Operator 收到的一直是真实索引，不需要改动

---

## 4. 详细设计

### 4.1 修改涉及的函数

**`ui.py` — `AUTOSWAY_PT_MainPanel.draw()`**

需要改动的部分：

```
# 当前
for i, group in enumerate(groups):
    self._draw_group(layout, context, group, i)

# 改为
visible_indices = self._get_visible_group_indices(context, groups)
if len(visible_indices) == 0:
    显示空状态提示（当前骨架没有摆动组）
    返回
for real_idx in visible_indices:
    group = groups[real_idx]
    self._draw_group(layout, context, group, real_idx)
```

**`ui.py` — 新增 `_get_visible_group_indices()` 方法**

核心过滤逻辑：

```
1. 获取当前活动骨架对象（context.active_object）
2. 防御性判断：如果 active_object 为空或不是骨架，返回所有组的索引
3. 遍历所有组：
   a. 满足以下任一条件则可见：
      - 组内骨骼数为 0（空组）
      - 组内至少有一根骨骼的 armature_name == 当前骨架名称
   b. 收集可见组的真实索引
4. 返回 list[int]
```

### 4.2 涉及的文件

| 文件 | 改动类型 | 改动内容 |
|------|----------|---------|
| `ui.py` | 修改 + 新增方法 | `draw()` 增加过滤逻辑，新增 `_get_visible_group_indices()` |
| `operators.py` | **不改** | 接收的真实索引不受过滤影响 |
| `core.py` | **不改** | 纯计算逻辑，不关心 UI 显示 |
| `properties.py` | **不改** | 数据模型不需要变更 |
| `utils.py` | **不改** | 当前工具函数够用 |

### 4.3 流程图

```
draw() 入口
  ↓
获取 groups
  ↓
如果 len(groups) == 0 → 显示"暂无摆动组"并返回
  ↓
获取当前骨架对象（context.active_object）
  ↓
遍历 groups，按 armature_name 过滤
  → 空组始终加入可见列表
  → 有骨骼的组：检查是否有骨骼 armature_name 匹配当前骨架
  → 返回 visible_indices
  ↓
visible_indices 为空？
  是 → 显示"当前骨架没有摆动组"
  否 → 循环 visible_indices，传真实索引绘制
```

---

## 5. 实现步骤

### 步骤 1：`ui.py` 新增 `_get_visible_group_indices()`

在 `AUTOSWAY_PT_MainPanel` 类中新增一个方法，接收 `(self, context, groups)`。

过滤逻辑如上所述。注意对 `context.active_object` 做 None 检查和 type 检查，防御 Blender 加载/切换过渡期中的短暂空值。返回 `list[int]`。

### 步骤 2：修改 `ui.py` — `draw()` 方法

将直接循环 `enumerate(groups)` 替换为：

```python
# 保留原有的空场景检查
if len(groups) == 0:
    layout.separator()
    layout.label(text="暂无摆动组，点击「新建摆动组」开始", icon='INFO')
    return

# 新增过滤逻辑
visible_indices = self._get_visible_group_indices(context, groups)
if len(visible_indices) == 0:
    layout.label(text="当前骨架没有摆动组", icon='INFO')
    return
for real_idx in visible_indices:
    group = groups[real_idx]
    self._draw_group(layout, context, group, real_idx)
```

### 步骤 3：验证改动

手动测试（详见第 6 节）。

### 步骤 4：提交代码审查

通过 subagent 派给代码审查官。

---

## 6. 测试策略

### 测试场景

| ID | 场景 | 操作步骤 | 预期结果 |
|----|------|---------|---------|
| T1 | 单一骨架，姿态模式 | 选中骨架进入姿态模式，创建一个摆动组并添加骨骼 | 面板正常显示该组 |
| T2 | 两骨架，姿态模式切换 | 创建两个骨架，分别添加骨骼到不同摆动组，在两个骨架间切换姿态模式 | 切换后面板只显示对应骨架的组 |
| T3 | 过滤状态下新建组 | 姿态模式下选中骨架 A → 点"新建摆动组" | 新空组立即可见（空组策略） |
| T4 | 空组可见性 | 在姿态模式下新建一个空摆动组 | 空组在面板中可见 |
| T5 | 跨骨架组可见性 | 一个组的骨骼分别属于两骨架（含 A 和 B），选中骨架 A 进入姿态模式 | 组在骨架 A 的面板中可见；展开后骨骼列表**包含骨架 B 的骨骼**（组内骨骼不做二次过滤，属正常行为） |
| T6 | 骨骼缺失场景 | 组的骨骼所在的骨架被删除，然后在不同骨架姿态模式下 | 该组被过滤掉（不显示） |
| T7 | 过滤状态下添加骨骼 | 骨架 A 姿态模式下选中 A 的骨骼 → 添加到现有组 | 组保持可见，骨骼正确添加，验证 group_index 传递正确 |
| T8 | 过滤状态下删除组 | 骨架 A 姿态模式下显示一个跨骨架组（含 A 和 B 的骨骼）→ 删除该组 | 删除后剩余组的过滤结果正常显示，索引无错位 |

### 手动测试 Checklist

- [ ] 在姿态模式下，面板只显示当前骨架的摆动组
- [ ] 切换到不同骨架，面板显示该骨架的组
- [ ] 过滤状态下新建的空组立即可见
- [ ] 过滤状态下添加骨骼到组，操作正常
- [ ] 过滤状态下删除组，其他组过滤不受影响
- [ ] 组内骨骼列表不受影响，完整显示
- [ ] 跨骨架组的骨骼列表完整显示（含其他骨架的骨骼）
- [ ] Operator 的 `group_index` 正确传递，删除/添加骨骼等操作正常
- [ ] 插件热加载后行为一致（`F8` 刷新后测试）

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 用户进入姿态模式时未选中骨架（`context.active_object` 为空） | 低 | 面板回退显示全部组，行为正确 | 代码中做 None 检查，稳健回退 |
| 骨架名称被用户修改，组的 `armature_name` 未同步 | 低 | 该组的骨骼不再匹配，组被隐藏 | 当前版本无完美缓解。用户需要手动将骨骼重新添加到组，或等未来版本加入骨架改名检测 |
| 用户希望在姿态模式下看到"跨骨架"的组 | 低 | 组被过滤掉，用户觉得困惑 | 当前设计优先满足"所见即当前骨架"，跨骨架需求不在本次范围内 |
| 多个摆动组同名或索引混淆 | 低 | Operator 使用真实索引，不易混淆 | 不改变索引传递方式，风险可控 |

### 回退方案

如果改动后出现严重问题，回退方式：

1. 用 git 回退 `ui.py` 的修改
2. 或手动注释掉新增的过滤逻辑，恢复直接循环 `enumerate(groups)`

改动影响范围只有 `ui.py` 一个文件，回退成本极低。

---

## 8. 参考

- [Blender API: bpy.types.Panel](https://docs.blender.org/api/current/bpy.types.Panel.html) — panel 的 draw 方法
- [Blender API: Context](https://docs.blender.org/api/current/bpy.context.html) — context.mode, context.active_object
- 当前代码：`ui.py` 的 `AUTOSWAY_PT_MainPanel.draw()` 和 `_draw_group()`
- `properties.py` — `SwayBoneItem.armature_name` 是过滤的匹配字段
