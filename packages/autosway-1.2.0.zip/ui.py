"""AutoSway — UI 面板

主面板 + 骨骼列表绘制。
每个摆动组以折叠面板形式展示，包含骨骼列表和摆动参数。

骨骼列表有两种渲染模式：
  - 层级模式：组内骨骼存在父子关系时，以树形缩进结构显示，带折叠功能
  - 平铺模式：组内骨骼全部独立时，保持平铺列表，显示上下移动按钮
"""

import bpy

from .constants import UI_LIST_ROWS
from .utils import (
    bone_exists,
    has_parent_child_in_group,
    get_root_bones_in_group,
    get_children_in_group,
)


class AUTOSWAY_PT_MainPanel(bpy.types.Panel):
    """自动摆动主面板"""

    bl_label = "自动摆动"
    bl_idname = "AUTOSWAY_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "自动摆动"
    bl_context = "posemode"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        groups = scene.autosway_groups

        # === 顶部操作栏 ===
        row = layout.row(align=True)
        row.operator("autosway.add_group", text="新建摆动组", icon='ADD')

        if len(groups) == 0:
            layout.separator()
            layout.label(text="暂无摆动组，点击「新建摆动组」开始", icon='INFO')
            return

        layout.separator()

        # === 逐组绘制（按当前骨架过滤） ===
        visible_indices = self._get_visible_group_indices(context, groups)
        if len(visible_indices) == 0:
            layout.label(text="当前骨架没有摆动组", icon='INFO')
            return

        for real_idx in visible_indices:
            group = groups[real_idx]
            self._draw_group(layout, context, group, real_idx)

    def _get_visible_group_indices(self, context, groups):
        """根据当前活动骨架过滤可见摆动组的真实索引列表。

        空组始终可见（用户创建组后需要能立即添加骨骼）。
        有骨骼的组只显示包含当前骨架骨骼的组。
        防御性兜底：无活动对象或不是骨架时返回全部组索引。
        """
        active_obj = context.active_object

        if active_obj is None or active_obj.type != 'ARMATURE':
            # 防御性兜底：非骨架上下文返回全部组（panel bl_context="posemode" 下通常不会触发）
            return range(len(groups))

        armature_name = active_obj.name
        active_data = active_obj.data
        scene = context.scene
        visible = []

        for i, group in enumerate(groups):
            if len(group.bones) == 0:
                # 空组始终可见
                visible.append(i)
            else:
                for b in group.bones:
                    if not b.armature_name:
                        continue
                    # 直接名称匹配
                    if b.armature_name == armature_name:
                        visible.append(i)
                        break
                    # 链接复制体匹配：检查 data 指针是否相同
                    other = scene.objects.get(b.armature_name)
                    if other is not None and other.type == 'ARMATURE' and other.data == active_data:
                        visible.append(i)
                        break

        return visible

    def _draw_group(self, layout, context, group, index):
        """绘制单个摆动组的折叠面板。"""
        # === 组标题行 ===
        box = layout.box()
        header = box.row(align=True)

        # 折叠箭头
        icon = 'TRIA_DOWN' if group.expanded else 'TRIA_RIGHT'
        header.prop(group, "expanded", text="", icon=icon, emboss=False)

        # 组名
        header.prop(group, "name", text="")

        # 启用开关
        header.prop(group, "enabled", text="", icon='CHECKBOX_HLT' if group.enabled else 'CHECKBOX_DEHLT', emboss=False)

        # 删除按钮
        op = header.operator("autosway.remove_group", text="", icon='TRASH')
        op.group_index = index

        # 折叠时只显示标题行
        if not group.expanded:
            # 显示骨骼数摘要
            header.label(text=f"({len(group.bones)} 根)", icon='BONE_DATA')
            return

        # === 展开内容 ===
        content = box.column()

        # --- 骨骼列表 ---
        if len(group.bones) > 0:
            # 构建组内骨骼映射（每次 draw 只构建一次），set 从 map keys 导出
            group_bones_map = {(item.bone_name, item.armature_name): item for item in group.bones}
            group_bones_set = set(group_bones_map.keys())

            has_hierarchy = has_parent_child_in_group(context.scene, group_bones_set, group)

            if has_hierarchy:
                self._draw_hierarchical_bones(content, context, group, index, group_bones_set, group_bones_map)
            else:
                self._draw_flat_bones(content, context, group, index)

        # 添加骨骼按钮
        op = content.operator("autosway.add_bones", text="添加选中骨骼", icon='ADD')
        op.group_index = index

        # --- 参数区 ---
        content.separator()

        # 轴向选择（三按钮展开）
        row = content.row(align=True)
        row.label(text="轴向:")
        row.prop(group, "axis", expand=True)

        content.prop(group, "sway_angle", slider=True)
        content.prop(group, "incremental_angle", slider=True)
        content.prop(group, "loop_frames", slider=True)
        content.prop(group, "staggered_frames", slider=True)
        content.prop(group, "offset_frame", slider=True)

    # ==================== 层级模式 ====================

    def _draw_hierarchical_bones(self, layout, context, group, group_index, group_bones_set, group_bones_map):
        """以树形结构绘制骨骼列表。"""
        roots = get_root_bones_in_group(group, group_bones_set, context.scene)

        layout.label(text=f"骨骼列表（{len(group.bones)} 根，层级模式）")

        # 混合场景提示
        independent_count = len(roots)
        if independent_count > 1:
            layout.label(text="无父子关系的骨骼作为根节点（depth=0）", icon='INFO')

        col = layout.column(align=True)
        for root in roots:
            self._draw_bone_node(col, context, group, group_index, root, 0, group_bones_map)

    def _draw_bone_node(self, layout, context, group, group_index, bone_item, depth, group_bones_map):
        """递归绘制单棵骨骼子树。"""
        # 递归深度保护：极端场景下防止无限递归
        if depth > 50:
            print(f"[AutoSway] UI 递归深度超限: {bone_item.bone_name} depth={depth}")
            return
        children = get_children_in_group(context.scene, group_bones_map, bone_item)

        # === 当前骨骼行 ===
        row = layout.row(align=True)

        # 缩进：用 split 递归嵌套，每层留 8% 空白
        r = row
        for _ in range(depth):
            r = r.split(factor=0.92, align=True)
            r = r.row(align=True)

        # 折叠箭头（有子级才显示）
        if len(children) > 0:
            icon = 'TRIA_DOWN' if bone_item.expanded else 'TRIA_RIGHT'
            r.prop(bone_item, "expanded", text="", icon=icon, emboss=False)
        else:
            r.label(text="", icon='BLANK1')

        # 骨骼名
        exists = bone_exists(context.scene, bone_item.armature_name, bone_item.bone_name)
        if exists:
            r.label(text=bone_item.bone_name, icon='BONE_DATA')
        else:
            r.label(text=f"{bone_item.bone_name}（缺失）", icon='ERROR')

        # 移除按钮
        op = r.operator("autosway.remove_bone", text="", icon='X')
        op.group_index = group_index
        op.bone_name = bone_item.bone_name
        op.armature_name = bone_item.armature_name

        # === 递归子级 ===
        if bone_item.expanded:
            for child in children:
                self._draw_bone_node(layout, context, group, group_index, child, depth + 1, group_bones_map)

    # ==================== 平铺模式 ====================

    def _draw_flat_bones(self, layout, context, group, group_index):
        """平铺列表模式（无父子关系时使用）。"""
        layout.label(text=f"骨骼列表（{len(group.bones)} 根）")

        col = layout.column(align=True)
        for j, bone_item in enumerate(group.bones):
            row = col.row(align=True)

            # 检查骨骼是否仍然存在
            exists = bone_exists(context.scene, bone_item.armature_name, bone_item.bone_name)

            if exists:
                row.label(text=bone_item.bone_name, icon='BONE_DATA')
            else:
                row.label(text=f"{bone_item.bone_name}（缺失）", icon='ERROR')

            # 上移
            op = row.operator("autosway.reorder_bones", text="", icon='TRIA_UP')
            op.group_index = group_index
            op.bone_index = j
            op.direction = 'UP'

            # 下移
            op = row.operator("autosway.reorder_bones", text="", icon='TRIA_DOWN')
            op.group_index = group_index
            op.bone_index = j
            op.direction = 'DOWN'

            # 移除
            op = row.operator("autosway.remove_bone", text="", icon='X')
            op.group_index = group_index
            op.bone_name = bone_item.bone_name
            op.armature_name = bone_item.armature_name
