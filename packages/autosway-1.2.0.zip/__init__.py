"""AutoSway — Blender 插件注册入口

通过 Handler + 状态追踪实现骨骼自动摆动动画。
借鉴 Parallax Locker 的 depsgraph_update_post 模式：
处理器不占有属性，只做"检测变化 → 反推用户意图 → 重新注入"。
"""

import bpy

from .properties import (
    SwayBoneItem,
    SwayGroup,
    register_scene_props,
    unregister_scene_props,
)
from .core import (
    autosway_load_handler,
    register_handler,
    unregister_handler,
    register_load_handler,
    unregister_load_handler,
)
from .operators import (
    AUTOSWAY_OT_AddGroup,
    AUTOSWAY_OT_RemoveGroup,
    AUTOSWAY_OT_AddBones,
    AUTOSWAY_OT_RemoveBone,
    AUTOSWAY_OT_ReorderBones,
)
from .ui import AUTOSWAY_PT_MainPanel


bl_info = {
    "name": "AutoSway",
    "author": "HAOAH",
    "version": (1, 2, 0),
    "blender": (4, 0, 0),
    "location": "3D 视图 > 侧边栏 > 自动摆动",
    "description": "为骨骼链添加正弦波摆动动画，支持手动控制与多组管理",
    "category": "Animation",
}


# ==================== 类注册顺序 ====================
# PropertyGroup 先注册（数据模型），再注册 UI 和 Operator

classes = (
    # PropertyGroup
    SwayBoneItem,
    SwayGroup,

    # Panel
    AUTOSWAY_PT_MainPanel,

    # Operator
    AUTOSWAY_OT_AddGroup,
    AUTOSWAY_OT_RemoveGroup,
    AUTOSWAY_OT_AddBones,
    AUTOSWAY_OT_RemoveBone,
    AUTOSWAY_OT_ReorderBones,
)


# ==================== 注册 ====================

def register():
    # 1. 注册所有类（精确捕获"已注册"异常，其余向上抛）
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass  # ValueError: already registered as a subclass
        except Exception as e:
            print(f"[AutoSway] 注册失败 {cls.__name__}: {e}")
            raise

    # 2. 注册 Scene 属性
    try:
        register_scene_props()
    except ValueError:
        pass  # 已注册
    except Exception as e:
        print(f"[AutoSway] Scene 属性注册失败: {e}")
        raise

    # 3. 注册 load_post handler（文件加载后检查是否有摆动组并注册 handler）
    #    注意：register() 执行时 bpy.context 是 _RestrictContext，不能访问 scene。
    #    所以"当前场景是否已有摆动组"的检查交给 load_post handler 完成。
    register_load_handler()


# ==================== 注销 ====================

def unregister():
    # 1. 注销 handler
    unregister_handler()

    # 2. 注销 load_post handler
    unregister_load_handler()

    # 3. 注销 Scene 属性
    try:
        unregister_scene_props()
    except Exception as e:
        print(f"[AutoSway] Scene 属性注销失败: {e}")

    # 4. 注销所有类（逆序，安全注销）
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            print(f"[AutoSway] 注销跳过 {cls.__name__}: {e}")


if __name__ == "__main__":
    register()
