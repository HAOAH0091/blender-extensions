# AutoSway

> Blender 骨骼自动摆动插件
> 版本：v1.1.0
> 作者：HAOAH
> Blender 最低版本：4.0

## 这是什么

AutoSway 为骨骼链自动生成正弦波摆动动画。你选中一串骨骼（尾巴、头发、触手、旗帜），设好参数，它们就会自动像波浪一样来回甩。动画师不用手 K 帧。

和同类工具的核心区别：**摆动和手动操控可以同时进行**。你可以在骨骼摆动的同时手动旋转它、给它 K 帧，两者互不干扰。

## 技术方案

采用 **Handler + 状态追踪** 模式（借鉴 Parallax Locker 插件），而非传统的驱动器方案。

传统驱动器方案的致命问题是：驱动器一旦挂到骨骼的 `rotation_euler` 上，这个属性就被驱动器"占有"了，用户无法手动旋转骨骼，也无法给它打关键帧。要调整就得先清除驱动器，改完再重新挂。

AutoSway 用另一种方式：

1. `depsgraph_update_post` + `frame_change_post` 双 handler 监听场景变化
2. 每帧计算正弦摆动值，写入骨骼旋转
3. 通过骨骼自定义属性（`_asway_base_rot`、`_asway_last_sway`）追踪"用户的原始旋转"和"上次注入的摆动量"
4. 下一帧先把旧摆动量减回去（还原用户意图），再注入新摆动量

这样骨骼的旋转属性始终可写，用户随时可以手动旋转或 K 帧，handler 会自动识别用户操作并保留。

## 文件结构

```
autosway/
├── __init__.py          # 注册入口（bl_info、register/unregister）
├── constants.py         # 常量（键名、阈值、默认值、轴向映射）
├── utils.py             # 工具函数（骨骼查找、旋转模式处理、组名去重）
├── properties.py        # 数据模型（SwayGroup、SwayBoneItem）+ update 回调
├── core.py              # 核心（摆动公式、状态追踪状态机、handler 系统）
├── operators.py         # 5 个 Operator
├── ui.py                # 面板 UI
├── IMPLEMENTATION_PLAN.md     # 实施计划（v1.0）
├── IMPLEMENTATION_PLAN_v1.1.md # 实施计划（v1.1：父子级传导）
├── CHANGELOG_DEV.md     # 开发者变更日志
├── VERSION.md           # 版本更新内容
├── README.md            # 本文件（开发者向）
└── USAGE.md             # 用户使用说明
```

## 模块依赖

```
constants.py          ← 无依赖（纯常量）
utils.py              ← constants.py
properties.py         ← constants.py（update 回调延迟导入 core.py）
core.py               ← constants.py, utils.py
operators.py          ← constants.py, core.py, utils.py, properties.py
ui.py                 ← constants.py, utils.py
__init__.py           ← 以上全部
```

## 数据模型

### Scene 级属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `scene.autosway_groups` | `CollectionProperty(SwayGroup)` | 所有摆动组 |
| `scene.autosway_active_group_index` | `IntProperty` | 当前选中组的索引 |

### SwayGroup（PropertyGroup）

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `name` | String | "新摆动组" | 组名 |
| `bones` | Collection(SwayBoneItem) | 空 | 骨骼列表 |
| `sway_angle` | Float | 10.0 | 基础振幅（度） |
| `incremental_angle` | Float | 5.0 | 每根骨骼的振幅增量（度） |
| `loop_frames` | Float | 40.0 | 一个完整周期所需帧数 |
| `staggered_frames` | Float | 3.0 | 相邻骨骼的延迟帧数 |
| `offset_frame` | Float | 0.0 | 全局相位偏移 |
| `axis` | Enum(X/Y/Z) | Z | 摆动轴向 |
| `enabled` | Bool | True | 启用/禁用 |
| `expanded` | Bool | True | UI 折叠状态 |

所有参数字段都绑定了 `update` 回调，修改即触发 `view_layer.update()`，handler 随即重新计算。

### SwayBoneItem（PropertyGroup）

| 字段 | 类型 | 说明 |
|------|------|------|
| `bone_name` | String | 骨骼名称 |
| `armature_name` | String | 所属骨架对象名称 |
| `expanded` | Bool | True | UI 折叠状态（层级模式下使用） |

### 骨骼运行时自定义属性

每根被管理的骨骼上存储以下属性（`pose_bone["key"]`）：

| 键 | 类型 | 说明 |
|----|------|------|
| `_asway_base_rot` | float | 用户的基础旋转值（弧度），剥离摆动后的纯用户意图 |
| `_asway_last_sway` | float | 上一轮计算的摆动值（弧度），用于下一轮反推 |
| `_asway_axis_index` | int | 摆动轴向索引（0/1/2），用于检测轴向切换 |

## 摆动公式

```
angle = sway_angle + incremental_angle × bone_index
delay = staggered_frames × bone_index
effective_frame = frame + offset_frame - delay
sway_radians = radians(-angle × sin(2π × effective_frame / loop_frames))
```

- 负号：让摆动从负方向开始（视觉上更自然）
- 弧度：Blender 的 `rotation_euler` 存储弧度值
- `bone_index`：骨骼在组内的序号（无父子关系时使用列表序号，有父子关系时使用层级深度）

### 传导模式

插件自动检测组内骨骼是否存在父子级关系：

- **有父子关系（层级模式）**：`bone_index = compute_bone_depth()`，沿父级链从根骨骼算步数。
  分叉处的骨骼与主干同深度的骨骼共享相同的 delay 和 angle。
- **无父子关系（平铺模式）**：`bone_index = enumerate(group.bones)`，按列表序号，与 v1.0.0 一致。

深度计算示例（分叉场景）：
```
Bone(0) → Bone.001(1) → Bone.002(2) → Bone.003(3)
                        ↘ Bone.004(2) → Bone.005(3) → Bone.006(4)
```

## Handler 状态机

`_process_bone()` 的三段式逻辑：

```
读取当前旋转 current_rot = bone.rotation_euler[axis]
读取追踪状态 base_rot, last_sway, stored_axis_idx

① 轴向切换检测
   如果 stored_axis_idx != axis_idx:
     清理旧轴（设回 old_base）
     重置新轴追踪状态

② 用户修改检测
   expected = base_rot + last_sway
   如果 |current_rot - expected| > 阈值:
     用户动过 → base_rot = current_rot - last_sway

③ 注入摆动
   new_sway = compute_sway(group, bone_index, frame)
   target = base_rot + new_sway
   如果 |current_rot - target| > 阈值:
     bone.rotation_euler[axis] = target

④ 更新追踪状态（仅在值变化时写入）
```

**幂等性保证**：同一帧、相同参数下，第二轮调用时 `current_rot == expected`，不会反推；`target == current_rot`，不会写入。天然收敛，无需守卫标志。

## Operator 一览

| bl_idname | 功能 |
|-----------|------|
| `autosway.add_group` | 新建摆动组，首个组自动注册 handler |
| `autosway.remove_group` | 删除组，剥离骨骼摆动，末组删除后注销 handler |
| `autosway.add_bones` | 添加选中姿态骨骼到组（含跨组冲突检测） |
| `autosway.remove_bone` | 从组中移除骨骼，剥离其摆动值 |
| `autosway.reorder_bones` | 上移/下移骨骼顺序（影响序号→振幅和错帧） |

## Handler 注册时机

| 事件 | 动作 |
|------|------|
| 插件启用 | 注册 `load_post` handler（不注册运行时 handler，因为 `bpy.context` 是 `_RestrictContext`） |
| 创建第一个摆动组 | 注册 `frame_change_post` + `depsgraph_update_post` |
| 删除最后一个摆动组 | 注销上述两个 handler |
| 加载 .blend 文件 | `load_post` 检查场景中是否有组，有则注册运行时 handler |
| 插件禁用 | 注销所有 handler |

## 已知局限

1. **Undo 后短暂不一致**：Blender 的 Undo 会回滚骨骼旋转值和自定义属性，但 handler 不在 Undo 栈中。Undo 后骨骼可能短暂"静止"，下一次帧变化或 depsgraph 更新时自动恢复。这是所有 handler+状态追踪模式插件的固有局限。

2. **同一骨骼不宜属于多个组**：两组同时操作同一根骨骼的同一属性会导致状态追踪冲突。插件在添加骨骼时检测跨组重复并弹出警告。

3. **四元数旋转模式自动切换**：如果骨骼是四元数或轴角模式，handler 会自动切换为 XYZ 欧拉。切换时 Blender 自动做转换，但极端角度组合可能因万向锁产生跳变。建议用户使用前手动设为欧拉模式。

4. **K 帧记录的是含摆动后的值**：用户给骨骼打关键帧时，记录的是 `base_rot + sway`（即所见即所得）。后续修改摆动参数不会自动更新已打的关键帧。

## Blender 5.1 兼容性

经知识库 5.0→5.1 API 变更日志核对，插件使用的所有接口（`bpy.app.handlers`、`bpy.utils.register_class`、`PoseBone.rotation_euler`、`CollectionProperty`、`Scene` 属性注册）在 5.1 中无变更。API 层面兼容。

## 开发环境

- Blender 5.1+
- Python 3.11+（Blender 内置）
- 无第三方依赖

## 许可

GPL-3.0（与 Blender 一致）
