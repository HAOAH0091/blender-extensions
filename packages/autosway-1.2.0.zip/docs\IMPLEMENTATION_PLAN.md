# AutoSway 插件实施计划

> 版本：v1.0.0 规划稿
> 日期：2026-07-02
> 方法：Handler + 状态追踪（借鉴 Parallax Locker 模式）

---

## 一、概述与目标

### 1.1 插件定位

AutoSway 是一个 Blender 骨骼动画辅助插件。通过正弦函数自动为骨骼链生成波浪摆动效果，同时保持用户对骨骼的完全手动控制权。

### 1.2 核心目标

| 目标 | 说明 |
|------|------|
| 自由操控 | 骨骼可在摆动同时被手动旋转、K 帧，互不干扰 |
| 实时响应 | 面板参数调整后，当前帧立即可见变化 |
| 多组管理 | 同一场景中可管理多个独立的摆动组（不同骨骼链、不同参数） |
| 启停控制 | 每组可独立启用/禁用，禁用后骨骼恢复自由状态 |
| 零额外对象 | 不在场景中生成空物体、辅助骨骼等辅助对象 |

### 1.3 与原插件（autosway_v0_5）的差异

| 维度 | 原插件 | 新插件 |
|------|--------|--------|
| 实现方式 | 驱动器（表达式写死参数值） | Handler + 状态追踪 |
| 参数更新 | 需清除后重新应用 | 修改即生效 |
| 手动控制 | 驱动器占用属性，无法手动调整 | 完全自由 |
| 多组管理 | 不支持 | CollectionProperty 增删改查 |
| 数据存储 | 全局 Scene 属性 | 分组 PropertyGroup |

---

## 二、文件结构

```
autosway/
├── __init__.py          # Blender 插件注册入口（bl_info、register/unregister）
├── properties.py        # 数据模型：SwayGroup、SwayBoneItem、Scene 级属性
├── core.py              # 核心算法：摆动公式、状态追踪、handler 回调
├── operators.py         # 所有 Operator（创建/删除组、添加/移除骨骼、应用/清除摆动）
├── ui.py                # 面板、UIList、属性 update 回调
├── constants.py         # 常量：默认值、阈值、自定义属性键名
├── utils.py             # 工具函数：骨骼查找、轴向映射、弧度转换
└── README.md            # 用户说明
```

### 2.1 各模块依赖关系

```
constants.py          ← 无依赖
utils.py              ← constants.py
properties.py         ← constants.py
core.py               ← constants.py, utils.py, properties.py
operators.py          ← constants.py, core.py, properties.py, utils.py
ui.py                 ← constants.py, properties.py, operators.py, utils.py
__init__.py           ← 以上全部
```

---

## 三、数据模型

### 3.1 SwayGroup（PropertyGroup）—— 单个摆动组

```python
class SwayGroup(bpy.types.PropertyGroup):
    # === 标识 ===
    name: StringProperty(
        name="组名",
        default="新摆动组"
    )

    # === 骨骼列表 ===
    bones: CollectionProperty(type=SwayBoneItem)
    active_bone_index: IntProperty(default=-1)

    # === 摆动参数 ===
    sway_angle: FloatProperty(
        name="摆动角度",
        description="第一根骨骼的基础振幅（度）",
        default=20.0,
        soft_min=-360.0,
        soft_max=360.0,
        update=_on_group_param_update    # 触发 handler 刷新
    )

    incremental_angle: FloatProperty(
        name="递增角度",
        description="每段骨骼的角度增量（度）",
        default=1.0,
        soft_min=-10.0,
        soft_max=10.0,
        update=_on_group_param_update
    )

    loop_frames: FloatProperty(
        name="循环帧数",
        description="完整摆动周期所需帧数",
        default=24.0,
        min=1.0,
        soft_max=240.0,
        update=_on_group_param_update
    )

    staggered_frames: FloatProperty(
        name="错帧量",
        description="相邻骨骼间的动画延迟帧数",
        default=5.0,
        soft_min=-50.0,
        soft_max=50.0,
        update=_on_group_param_update
    )

    offset_frame: FloatProperty(
        name="帧偏移",
        description="全局动画起始偏移帧",
        default=0.0,
        soft_min=-240.0,
        soft_max=240.0,
        update=_on_group_param_update
    )

    # === 轴向 ===
    axis: EnumProperty(
        name="摆动轴向",
        description="选择驱动器控制的旋转轴向",
        items=[
            ('X', "X", "绕 X 轴摆动"),
            ('Y', "Y", "绕 Y 轴摆动"),
            ('Z', "Z", "绕 Z 轴摆动"),
        ],
        default='Z',
        update=_on_group_param_update
    )

    # === 状态 ===
    enabled: BoolProperty(
        name="启用",
        description="启用/禁用该组的摆动效果",
        default=True,
        update=_on_group_enable_toggle    # 启用时触发刷新，禁用时剥离摆动
    )
```

### 3.2 SwayBoneItem（PropertyGroup）—— 单个骨骼条目

```python
class SwayBoneItem(bpy.types.PropertyGroup):
    bone_name: StringProperty(
        name="骨骼名称"
    )
```

### 3.3 Scene 级属性

```python
bpy.types.Scene.autosway_groups = CollectionProperty(type=SwayGroup)
bpy.types.Scene.autosway_active_group_index = IntProperty(default=-1)
```

### 3.4 骨骼运行时自定义属性（state tracking）

每根被管理的骨骼上存储以下自定义属性（`bone["key"]`）：

| 属性键 | 类型 | 用途 |
|--------|------|------|
| `_asway_group_name` | string | 所属组名（用于反向查找） |
| `_asway_base_rot` | float | 用户的纯基础旋转值（剥离摆动后的值，弧度） |
| `_asway_last_sway` | float | 上一轮计算的摆动值（弧度） |
| `_asway_axis_index` | int | 摆动轴向索引（0/1/2，冗余存储便于 handler 直接读取） |

**为什么存这四项：**

- `_asway_group_name`：handler 遍历时可以直接知道这个骨骼属于哪个组，避免 O(n*m) 查找
- `_asway_base_rot`：用户手动旋转骨骼后的新基础值，handler 反推时写入
- `_asway_last_sway`：用于检测"当前值变化了多少是因为我上次改了"和"用户新增了多少"
- `_asway_axis_index`：避免每次都从组配置里查轴向枚举

---

## 四、核心算法

### 4.1 摆动公式

```python
import math

def compute_sway(group, bone_index, frame):
    """计算单根骨骼在当前帧的摆动角度（弧度）。

    Args:
        group: SwayGroup 实例
        bone_index: 骨骼在组内的序号（0-based）
        frame: 当前场景帧号

    Returns:
        float: 摆动角度（弧度）
    """
    angle_deg = group.sway_angle + group.incremental_angle * bone_index
    delay = group.staggered_frames * bone_index
    effective_frame = frame + group.offset_frame - delay

    # sin 值为 -1 到 1，乘负角度后：正值时产生负向旋转，负值时正向旋转
    sway_deg = -angle_deg * math.sin(2 * math.pi * effective_frame / group.loop_frames)
    return math.radians(sway_deg)
```

**公式说明**：
- 符号取负：让摆动从"向后摆"开始（sin(0)=0，无偏移；第一帧在 0 度），视觉效果更自然（相当于从平衡位置开始向一个方向摆）
- 角度转弧度：Blender 的 `rotation_euler` 存储的是弧度值

### 4.2 轴向映射

```python
AXIS_MAP = {'X': 0, 'Y': 1, 'Z': 2}

def get_axis_index(axis_enum):
    """将轴向枚举值 'X'/'Y'/'Z' 映射为 rotation_euler 的索引 0/1/2。"""
    return AXIS_MAP.get(axis_enum, 2)
```

### 4.3 骨骼查找

```python
def find_armature_for_bone(scene, bone_name):
    """在场景中搜索包含指定骨骼的骨架对象。

    遍历所有类型为 'ARMATURE' 的对象，检查其 pose.bones 中是否存在该骨骼名。

    Args:
        scene: 当前场景
        bone_name: 骨骼名称

    Returns:
        bpy.types.Object | None: 找到的骨架对象，未找到返回 None
    """
    for obj in scene.objects:
        if obj.type == 'ARMATURE' and bone_name in obj.pose.bones:
            return obj
    return None
```

**性能考量**：handler 中每帧调用此函数会有 O(骨架数) 的开销。优化策略：

- 方案 A：在 `SwayBoneItem` 中增加 `armature_name` 字段，应用时写入，查找时直接 `scene.objects.get(armature_name)`
- 方案 B：在骨骼的自定义属性中缓存 `_asway_armature_name`
- **采用方案 A**：因为骨骼列表在"添加骨骼"操作时写入，此时可以在 operator 中获取当前选中骨架的名称，无需额外查找

### 4.4 旋转模式保证

```python
def ensure_euler_rotation(bone):
    """确保骨骼使用欧拉旋转模式。

    如果当前是四元数（QUATERNION）或轴角（AXIS_ANGLE），
    尝试切换到默认的欧拉模式 'XYZ'。

    Args:
        bone: PoseBone 实例

    Returns:
        bool: True 表示当前是欧拉模式（或已成功切换）
    """
    if bone.rotation_mode == 'QUATERNION':
        # 四元数转欧拉：保留当前旋转方向
        # rotation_quaternion → rotation_euler
        bone.rotation_mode = 'XYZ'
        return True
    elif bone.rotation_mode == 'AXIS_ANGLE':
        bone.rotation_mode = 'XYZ'
        return True
    # 其他欧拉变体（XYZ, XZY, YXZ, YZX, ZXY, ZYX）都可接受
    return True
```

---

## 五、Handler 系统

### 5.1 处理器注册

```python
from bpy.app.handlers import persistent

@persistent
def autosway_handler(scene):
    """depsgraph_update_post 回调。

    遍历所有启用的摆动组，为每组中每根骨骼计算并注入摆动。
    使用状态追踪区分"用户的改动"和"处理器自己的改动"。
    """
    try:
        groups = scene.autosway_groups
        if len(groups) == 0:
            return

        frame = scene.frame_current

        for group in groups:
            if not group.enabled:
                continue
            if len(group.bones) == 0:
                continue

            for idx, bone_item in enumerate(group.bones):
                _process_bone(scene, group, bone_item, idx, frame)

    except Exception as e:
        # handler 异常必须静默处理，不阻塞 Blender 更新管线
        print(f"[AutoSway] Handler 异常: {e}")
```

### 5.2 单骨骼处理逻辑（核心状态机）

```python
def _process_bone(scene, group, bone_item, bone_index, frame):
    """处理单根骨骼的摆动注入。

    状态追踪的三段式逻辑：
    1. 检测变化 → 反推用户基础旋转
    2. 计算新摆动值
    3. 组合写入 + 更新追踪状态
    """
    # === 查找骨骼 ===
    armature = _get_armature_for_bone_item(scene, bone_item)
    if armature is None:
        return

    bone = armature.pose.bones.get(bone_item.bone_name)
    if bone is None:
        return

    # === 确保欧拉旋转模式 ===
    if not ensure_euler_rotation(bone):
        return

    axis_idx = get_axis_index(group.axis)
    current_rot = bone.rotation_euler[axis_idx]

    # === 读取追踪状态 ===
    base_rot = bone.get("_asway_base_rot", current_rot)
    last_sway = bone.get("_asway_last_sway", 0.0)

    # === 第一步：检测用户是否修改了骨骼 ===
    # expected = 基础旋转 + 上次摆动（即"如果什么都没发生，现在的旋转应该是多少"）
    expected = base_rot + last_sway
    THRESHOLD = 1e-6  # 浮点数比较容差

    if abs(current_rot - expected) > THRESHOLD:
        # 用户动了骨骼（或外部脚本修改了旋转）
        # 反推新的基础旋转 = 当前旋转 - 上次摆动
        base_rot = current_rot - last_sway
        bone["_asway_base_rot"] = base_rot

    # === 第二步：计算新摆动值 ===
    new_sway = compute_sway(group, bone_index, frame)

    # === 第三步：组合写入 ===
    target_rot = base_rot + new_sway

    if abs(current_rot - target_rot) > THRESHOLD:
        bone.rotation_euler[axis_idx] = target_rot

    # === 第四步：更新追踪状态 ===
    bone["_asway_last_sway"] = new_sway
```

### 5.3 防重入分析

handler 在设置 `bone.rotation_euler[axis_idx] = target_rot` 后会触发新的 depsgraph 更新，
导致 handler 再次被调用。分析第二轮的逻辑：

```
第二轮进入 _process_bone：
  current_rot = target_rot（刚写入的值）
  base_rot = 之前存的基础旋转（未变）
  last_sway = 之前存的摆动值（未变）

  expected = base_rot + last_sway = (target_rot - new_sway) + last_sway
           = target_rot（如果 new_sway == last_sway，同帧同参数下确实相等）
           = current_rot

  abs(current_rot - expected) < THRESHOLD → 跳过反推
  new_sway = compute_sway(...) → 相同帧、相同参数 → 和上一轮一样
  target_rot = base_rot + new_sway = current_rot
  abs(current_rot - target_rot) < THRESHOLD → 跳过写入
```

**结论**：同一帧、相同参数下，handler 是天然幂等的，无需额外守卫。

### 5.4 Handler 的注册/注销时机

```python
def register_handler():
    """注册 handler。如果已有活动组，则注册；否则不注册。"""
    if autosway_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(autosway_handler)

def unregister_handler():
    """注销 handler。"""
    if autosway_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(autosway_handler)
```

**注册时机**：
- 创建第一个摆动组时注册
- 从 .blend 加载后，如果场景中已有组，在 `load_post` handler 中注册
- 注册前检查是否已存在，防止重复

**注销时机**：
- 删除最后一个摆动组时注销
- 插件卸载时注销

### 5.5 属性 update 回调

面板参数的 `update` 回调需要触发 handler 重新计算：

```python
def _on_group_param_update(self, context):
    """摆动参数变更时，标记 depsgraph 需要更新。"""
    # 直接触发 view_layer 更新，handler 会在 depsgraph_update_post 中响应
    if context.view_layer:
        context.view_layer.update()


def _on_group_enable_toggle(self, context):
    """组的启用/禁用切换。

    启用：触发 handler 重新计算摆动
    禁用：剥离所有摆动值，恢复骨骼的基础旋转
    """
    if self.enabled:
        _on_group_param_update(self, context)
    else:
        _strip_sway_from_group(context.scene, self)
```

### 5.6 禁用时的摆动剥离（Strip Sway）

```python
def _strip_sway_from_group(scene, group):
    """从组内所有骨骼上剥离摆动值，恢复纯基础旋转。"""
    for bone_item in group.bones:
        armature = _get_armature_for_bone_item(scene, bone_item)
        if armature is None:
            continue
        bone = armature.pose.bones.get(bone_item.bone_name)
        if bone is None:
            continue

        base_rot = bone.get("_asway_base_rot")
        if base_rot is not None:
            axis_idx = bone.get("_asway_axis_index", 0)
            bone.rotation_euler[axis_idx] = base_rot
```

---

## 六、操作符（Operator）

### 6.1 AUTOSWAY_OT_AddGroup —— 新建摆动组

```python
class AUTOSWAY_OT_AddGroup(bpy.types.Operator):
    bl_idname = "autosway.add_group"
    bl_label = "新建摆动组"
    bl_description = "创建一个新的摆动组"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        groups = context.scene.autosway_groups
        group = groups.add()
        group.name = f"摆动组 {len(groups)}"

        # 标记组名唯一性
        group.name = _unique_group_name(groups, group.name)

        context.scene.autosway_active_group_index = len(groups) - 1

        # 如果是第一个组，注册 handler
        if len(groups) == 1:
            register_handler()

        return {'FINISHED'}
```

### 6.2 AUTOSWAY_OT_RemoveGroup —— 删除摆动组

```python
class AUTOSWAY_OT_RemoveGroup(bpy.types.Operator):
    bl_idname = "autosway.remove_group"
    bl_label = "删除摆动组"
    bl_description = "删除当前选中的摆动组，同时剥离组内骨骼的摆动值"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty()

    def execute(self, context):
        groups = context.scene.autosway_groups
        idx = self.group_index

        if 0 <= idx < len(groups):
            # 先剥离该组所有骨骼的摆动
            _strip_sway_from_group(context.scene, groups[idx])

            groups.remove(idx)
            context.scene.autosway_active_group_index = min(idx, len(groups) - 1)

            # 如果没有剩余组，注销 handler
            if len(groups) == 0:
                unregister_handler()

        return {'FINISHED'}
```

### 6.3 AUTOSWAY_OT_AddBones —— 添加选中骨骼

```python
class AUTOSWAY_OT_AddBones(bpy.types.Operator):
    bl_idname = "autosway.add_bones"
    bl_label = "添加选中骨骼"
    bl_description = "将当前选中的姿态骨骼加入摆动组"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty()

    @classmethod
    def poll(cls, context):
        # 必须在姿态模式，且至少选中一根骨骼
        return (context.mode == 'POSE'
                and len(context.selected_pose_bones) > 0)

    def execute(self, context):
        groups = context.scene.autosway_groups
        if self.group_index >= len(groups):
            return {'CANCELLED'}

        group = groups[self.group_index]

        # 获取当前骨架对象
        armature = context.active_object
        if armature is None or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "需要选中骨架对象")
            return {'CANCELLED'}

        # 记录已存在的骨骼名，避免重复添加
        existing = {item.bone_name for item in group.bones}

        added = 0
        for pose_bone in context.selected_pose_bones:
            if pose_bone.name in existing:
                continue

            item = group.bones.add()
            item.bone_name = pose_bone.name
            existing.add(pose_bone.name)
            added += 1

        if added > 0:
            self.report({'INFO'}, f"已添加 {added} 根骨骼")
            # 触发 handler 重新计算
            _on_group_param_update(group, context)
        else:
            self.report({'WARNING'}, "选中的骨骼已在组内")

        return {'FINISHED'}
```

### 6.4 AUTOSWAY_OT_RemoveBone —— 从组中移除骨骼

```python
class AUTOSWAY_OT_RemoveBone(bpy.types.Operator):
    bl_idname = "autosway.remove_bone"
    bl_label = "移除骨骼"
    bl_description = "从摆动组中移除该骨骼，并剥离其摆动值"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty()
    bone_name: StringProperty()

    def execute(self, context):
        groups = context.scene.autosway_groups
        group = groups[self.group_index]

        # 先剥离该骨骼的摆动
        armature = _get_armature_for_bone_item(context.scene,
            _find_bone_item(group, self.bone_name))
        if armature:
            bone = armature.pose.bones.get(self.bone_name)
            if bone:
                _strip_single_bone_sway(bone)

        # 从列表中移除
        for i, item in enumerate(group.bones):
            if item.bone_name == self.bone_name:
                group.bones.remove(i)
                break

        return {'FINISHED'}
```

### 6.5 AUTOSWAY_OT_ReorderBones —— 调整骨骼顺序（可选）

```python
class AUTOSWAY_OT_ReorderBones(bpy.types.Operator):
    bl_idname = "autosway.reorder_bones"
    bl_label = "调整骨骼顺序"
    bl_description = "上移/下移骨骼的顺序（影响递增角度和错帧量的分配）"
    bl_options = {'REGISTER', 'UNDO'}

    group_index: IntProperty()
    bone_index: IntProperty()
    direction: EnumProperty(items=[('UP', "上移", ""), ('DOWN', "下移", "")])

    def execute(self, context):
        group = context.scene.autosway_groups[self.group_index]
        bones = group.bones
        i = self.bone_index

        if self.direction == 'UP' and i > 0:
            bones.move(i, i - 1)
        elif self.direction == 'DOWN' and i < len(bones) - 1:
            bones.move(i, i + 1)

        return {'FINISHED'}
```

---

## 七、UI 设计

### 7.1 面板结构

```
┌──────────────────────────────────────────────────┐
│  自动摆动                              [+ 新建组] │
├──────────────────────────────────────────────────┤
│                                                    │
│  ▸ 尾巴上段                           [☑] [🗑]  │
│    ┌────────────────────────────────────────────┐ │
│    │  骨骼列表（3 根）                           │ │
│    │  ┌──────────────────────────────────┐      │ │
│    │  │ tail_01                  ▲ ▼ [×] │      │ │
│    │  │ tail_02                  ▲ ▼ [×] │      │ │
│    │  │ tail_03                  ▲ ▼ [×] │      │ │
│    │  └──────────────────────────────────┘      │ │
│    │  [+ 添加选中骨骼]                           │ │
│    │                                             │ │
│    │  轴向:  [ X ] [ Y ] [ Z●]                   │ │
│    │  摆动角度:  [══════════] 20.0°              │ │
│    │  递增角度:  [══════════] 1.0°               │ │
│    │  循环帧数:  [══════════] 24                  │ │
│    │  错帧量:    [══════════] 5                   │ │
│    │  帧偏移:    [══════════] 0                   │ │
│    └────────────────────────────────────────────┘ │
│                                                    │
│  ▸ 头发左侧                           [□] [🗑]  │
│                                                    │
└──────────────────────────────────────────────────┘
```

### 7.2 面板代码

```python
class AUTOSWAY_PT_MainPanel(bpy.types.Panel):
    bl_label = "自动摆动"
    bl_idname = "AUTOSWAY_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "自动摆动"
    bl_context = "posemode"   # 仅在姿态模式显示

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        groups = scene.autosway_groups

        # === 顶部操作栏 ===
        row = layout.row(align=True)
        row.operator("autosway.add_group", text="新建组", icon='ADD')

        if len(groups) == 0:
            layout.label(text="暂无摆动组，点击「新建组」开始", icon='INFO')
            return

        # === 逐组绘制 ===
        for i, group in enumerate(groups):
            self._draw_group(layout, context, group, i)

    def _draw_group(self, layout, context, group, index):
        """绘制单个摆动组的折叠面板。"""
        # 组标题行：折叠箭头 + 组名 + 启用开关 + 删除按钮
        row = layout.row(align=True)

        # 折叠控制
        icon = 'TRIA_DOWN' if group.get("_expanded", True) else 'TRIA_RIGHT'
        row.prop(group, 'name', text="")
        row.prop(group, 'enabled', text="", icon='CHECKBOX_HLT' if group.enabled else 'CHECKBOX_DEHLT')

        # 删除按钮
        op = row.operator("autosway.remove_group", text="", icon='TRASH')
        op.group_index = index

        if not group.get("_expanded", True):
            return

        # === 展开内容 ===
        box = layout.box()

        # 骨骼列表
        box.label(text=f"骨骼列表（{len(group.bones)} 根）")
        if len(group.bones) > 0:
            col = box.column(align=True)
            for j, bone_item in enumerate(group.bones):
                row = col.row(align=True)
                row.label(text=bone_item.bone_name, icon='BONE_DATA')

                # 上移/下移
                op = row.operator("autosway.reorder_bones", text="", icon='TRIA_UP')
                op.group_index = index
                op.bone_index = j
                op.direction = 'UP'

                op = row.operator("autosway.reorder_bones", text="", icon='TRIA_DOWN')
                op.group_index = index
                op.bone_index = j
                op.direction = 'DOWN'

                # 移除
                op = row.operator("autosway.remove_bone", text="", icon='X')
                op.group_index = index
                op.bone_name = bone_item.bone_name

        # 添加骨骼按钮
        op = box.operator("autosway.add_bones", text="添加选中骨骼", icon='ADD')
        op.group_index = index

        # 参数区
        box.separator()
        row = box.row(align=True)
        row.prop(group, 'axis', expand=True)

        box.prop(group, 'sway_angle', slider=True)
        box.prop(group, 'incremental_angle', slider=True)
        box.prop(group, 'loop_frames', slider=True)
        box.prop(group, 'staggered_frames', slider=True)
        box.prop(group, 'offset_frame', slider=True)
```

### 7.3 折叠状态存储

使用自定义属性而非 UI 状态变量：

```python
# 在 group 上用一个临时属性记录展开状态
# 不定义为正式的 PropertyGroup 字段，而是运行时 dict
group["_expanded"] = True  # 初始展开
```

---

## 八、注册与生命周期

### 8.1 __init__.py 结构

```python
bl_info = {
    "name": "AutoSway",
    "author": "HAOAH",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "3D 视图 > 侧边栏 > 自动摆动",
    "description": "为骨骼链添加正弦波摆动动画，支持手动控制与多组管理",
    "category": "Animation",
}

def register():
    # 1. 注册所有类（顺序：PropertyGroup → UIList → Panel → Operator）
    # 2. 注册 Scene 属性
    # 3. 注册 load_post handler（加载文件后恢复运行时 handler）
    # 4. 如果场景中已有摆动组，注册 depsgraph handler

def unregister():
    # 1. 注销 depsgraph handler
    # 2. 注销 load_post handler
    # 3. 注销 Scene 属性
    # 4. 注销所有类（逆序）
```

### 8.2 类注册顺序

Blender 要求 PropertyGroup 在其使用方之前注册：

```python
classes = (
    # PropertyGroup（数据模型，最先注册）
    SwayBoneItem,
    SwayGroup,

    # UI（依赖 PropertyGroup）
    AUTOSWAY_UL_BoneList,
    AUTOSWAY_PT_MainPanel,

    # Operator（依赖以上所有）
    AUTOSWAY_OT_AddGroup,
    AUTOSWAY_OT_RemoveGroup,
    AUTOSWAY_OT_AddBones,
    AUTOSWAY_OT_RemoveBone,
    AUTOSWAY_OT_ReorderBones,
)
```

### 8.3 文件加载后恢复

```python
@persistent
def autosway_load_handler(dummy):
    """加载 .blend 文件后，如果场景中有摆动组，注册运行时 handler。"""
    scene = bpy.context.scene
    if len(scene.autosway_groups) > 0:
        register_handler()

# 注册
bpy.app.handlers.load_post.append(autosway_load_handler)
```

### 8.4 新场景处理

场景切换时，`depsgraph_update_post` 的 `scene` 参数会自动指向当前活跃场景。
handler 内部通过该参数访问 `scene.autosway_groups`，所以不同场景有各自独立的摆动组数据，
不需要额外处理。

---

## 九、边界情况与错误处理

### 9.1 骨骼被删除

**场景**：用户删除了一根已在某个摆动组中的骨骼。

**检测**：handler 中 `bone = armature.pose.bones.get(bone_item.bone_name)` 返回 `None`。

**处理**：
- handler 跳过该骨骼，不做任何操作
- UI 面板中，`SwayBoneItem` 的名称仍然显示，但旁边标注红色警告图标
- 用户可通过面板的 [×] 按钮手动移除

```python
# UI 中的骨骼项绘制
if not _bone_exists(scene, bone_item.bone_name):
    row.label(text=f"{bone_item.bone_name}（缺失）", icon='ERROR')
else:
    row.label(text=bone_item.bone_name, icon='BONE_DATA')
```

### 9.2 骨架对象被删除

**场景**：包含摆动骨骼的骨架对象被从场景中删除。

**检测**：`_get_armature_for_bone_item()` 返回 `None`。

**处理**：同 9.1，handler 跳过，UI 标记警告。

### 9.3 骨骼被改名

**场景**：用户重命名了一根骨骼。

**检测**：handler 中按旧名查找失败（`pose.bones.get(old_name)` 返回 `None`）。

**处理**：
- 目前阶段不做自动追踪，标记为"缺失"
- 用户手动移除旧条目，重新添加新名称的骨骼
- 未来可以考虑在 handler 中记录 `bone.as_pointer()` 做指针级别的追踪（更复杂）

### 9.4 多骨架场景

**场景**：场景中有多个骨架，骨骼名在不同骨架中可能重复。

**处理**：
- `SwayBoneItem` 中增加 `armature_name` 字段
- 添加骨骼时写入当前骨架名称
- `_get_armature_for_bone_item()` 直接按名称查找，O(1) 复杂度

### 9.5 旋转模式冲突

**场景**：骨骼当前是四元数旋转模式，不在欧拉模式。

**处理**：
- handler 中调用 `ensure_euler_rotation(bone)` 自动切换
- 切换时 Blender 自动做四元数→欧拉转换，旋转方向保留
- **风险**：欧拉旋转有万向节锁问题，切换到欧拉后特定角度组合可能产生意外结果
- **缓解**：在 UI 文档中说明建议使用欧拉旋转模式

### 9.6 handler 异常

**场景**：handler 中抛出未预料的异常。

**处理**：handler 包裹在 try/except Exception 中，异常仅打印到控制台，不阻塞 Blender 更新。

### 9.7 Undo/Redo

**场景**：用户执行 Undo 回退到 handler 修改之前的状态。

**Blender 行为**：Undo 会回退所有属性变化，包括 handler 写入的 `bone.rotation_euler`。

**影响**：Undo 后骨骼的旋转值可能暂时不包含摆动（直到下一次 depsgraph 更新）。

**缓解**：这是 handler 方案的固有特性。不主动干预。用户 Undo 后看到骨骼短暂"静止"是正常的，
下一次时间轴操作或手动刷新时会立即恢复。

### 9.8 超长骨骼链性能

**场景**：一个组中有 200 根骨骼。

**评估**：每次 depsgraph 更新遍历 200 根骨骼，计算正弦函数，读写自定义属性。
在现代硬件上，这应远低于 1ms。

**保护**：如果后续评估发现瓶颈，可在 handler 入口做帧率节流：

```python
# 可选优化：跳帧处理
import time
_last_handler_time = 0
_MIN_HANDLER_INTERVAL = 0.016  # ~60fps

if time.time() - _last_handler_time < _MIN_HANDLER_INTERVAL:
    return
_last_handler_time = time.time()
```

初始版本不加入此优化，保持代码简洁。

### 9.9 同一骨骼属于多个组

**场景**：用户将同一根骨骼加入两个不同的摆动组。

**处理**：
- 添加骨骼时检查所有其他组，如果已存在则弹出警告
- 在 `AUTOSWAY_OT_AddBones.invoke()` 中检测并提示

```python
def invoke(self, context, event):
    # 检查是否有骨骼已在其他组中
    all_groups = context.scene.autosway_groups
    current_group = all_groups[self.group_index]
    existing = {}

    for i, g in enumerate(all_groups):
        if i == self.group_index:
            continue
        for item in g.bones:
            existing[item.bone_name] = g.name

    conflicts = []
    for pb in context.selected_pose_bones:
        if pb.name in existing:
            conflicts.append(f"{pb.name}（已在「{existing[pb.name]}」中）")

    if conflicts:
        self._conflict_msg = "\n".join(conflicts)
        return context.window_manager.invoke_props_dialog(self, width=350)

    return self.execute(context)
```

### 9.10 摆动值为零（loop_frames 极大等极端参数）

**场景**：用户将 `loop_frames` 设为一个极大值（如 999999），导致有效帧内的 sin 值几乎为零。

**行为**：摆动值为零，骨骼保持基础旋转不动。正确行为，无需特殊处理。

---

## 十、实施顺序

按依赖关系和风险递减排序：

| 阶段 | 模块 | 内容 | 预计工作量 |
|------|------|------|-----------|
| **Phase 1** | constants.py | 常量定义（键名、阈值、默认值） | 5 分钟 |
| **Phase 2** | utils.py | 工具函数（轴向映射、骨骼查找、弧度转换） | 10 分钟 |
| **Phase 3** | properties.py | SwayBoneItem、SwayGroup 定义 | 30 分钟 |
| **Phase 4** | core.py | 摆动公式 + 状态追踪 + handler | 60 分钟 |
| **Phase 5** | operators.py | 5 个 Operator | 45 分钟 |
| **Phase 6** | ui.py | 面板 + UIList | 30 分钟 |
| **Phase 7** | __init__.py | 注册/注销整套逻辑 | 20 分钟 |
| **Phase 8** | 集成测试 | 完整流程验证（见第十一节） | 30 分钟 |

**总计**：约 3.5 小时

---

## 十一、测试检查清单

### 11.1 基础功能

- [ ] 创建摆动组 → 面板中出现新组
- [ ] 添加选中骨骼 → 骨骼列表更新
- [ ] 修改摆动角度 → 骨骼旋转立即响应
- [ ] 修改轴向 → 摆动方向立即切换
- [ ] 删除摆动组 → 组消失 + 骨骼恢复
- [ ] 保存 .blend → 重新打开 → 摆动组数据保留

### 11.2 手动控制

- [ ] 摆动中的骨骼可以手动旋转（R 键），不报错
- [ ] 手动旋转后，摆动继续叠加（不是覆盖）
- [ ] 手动旋转后 K 帧 → 播放动画 → 骨骼按 K 的帧 + 摆动运动
- [ ] 在摆动运动中 K 帧 → K 到的是所见即所得的值

### 11.3 多组管理

- [ ] 创建 3 个不同参数的组 → 各自独立运行
- [ ] 禁用组 A → 组 A 骨骼停止摆动，组 B 继续
- [ ] 删除组 A → 组 A 骨骼停止摆动，组 B 继续

### 11.4 边界情况

- [ ] 空组（无骨骼）→ handler 不报错
- [ ] 删除骨骼 → handler 不报错，UI 显示"缺失"
- [ ] 删除骨架 → handler 不报错，UI 显示"缺失"
- [ ] 添加 50 根骨骼 → 性能无明品卡顿
- [ ] 循环帧数 = 1 → sin 值快速振荡，无除零或 NaN
- [ ] 摆动角度 = 0 → 骨骼保持原位

### 11.5 插件生命周期

- [ ] 启用插件 → 面板出现
- [ ] 禁用插件 → 面板消失 + handler 注销
- [ ] 加载含旧版 autosway 数据的 .blend → 不冲突
- [ ] 撤销操作（Ctrl+Z）→ 不导致崩溃

---

## 十二、未来扩展（不在 v1.0 范围内）

以下功能在 v1.0 中不实现，但架构需为其预留空间：

1. **波形类型**：正弦波 / 三角波 / 锯齿波 / 方波（枚举 + 公式分支）
2. **衰减（Damping）**：摆动幅度随时间递减（增加 `damping_factor` 参数）
3. **多轴向同时摆动**：一根骨骼在 X 和 Z 轴同时摆动（目前每组只支持单轴）
4. **NLA 烘焙**：将摆动效果一键烘焙为关键帧 Action，脱离插件依赖
5. **骨骼组内重排序的拖拽支持**：更直观的 UI 交互
6. **骨骼名自动填充建议**：在骨骼列表中添加搜索/自动补全
7. **预设系统**：保存/加载常用参数组合

---

*本计划由 hanako 起草，待 HAOAH 审阅后进入实施。*
