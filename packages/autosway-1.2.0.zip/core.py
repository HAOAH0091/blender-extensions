"""AutoSway — 核心算法

摆动公式计算 + 状态追踪 + depsgraph_update_post handler。

核心设计借鉴 Parallax Locker 的"检测变化 → 反推用户意图 → 重新注入"模式：
  1. 读取骨骼当前旋转值
  2. 与"基础旋转 + 上次摆动"对比，判断用户是否手动修改过
  3. 如果用户改了，反推出新的基础旋转
  4. 用当前帧号和参数计算新摆动值
  5. 组合写入：基础旋转 + 新摆动
  6. 更新追踪状态
"""

import bpy
import math
from bpy.app.handlers import persistent

from .constants import (
    ASWAY_KEY_BASE_ROT,
    ASWAY_KEY_LAST_SWAY,
    ASWAY_KEY_AXIS_INDEX,
    ASWAY_ALL_KEYS,
    ROTATION_THRESHOLD,
)
from .utils import (
    get_axis_index,
    find_bone_in_scene,
    ensure_euler_rotation,
    clear_sway_props,
    compute_bone_depth,
    has_parent_child_in_group,
)


# ==================== 摆动公式 ====================

def compute_sway(group, bone_index, frame):
    """计算单根骨骼在当前帧的摆动角度（弧度）。

    公式：-角度 × sin(2π × (帧数 + 偏移 - 延迟) / 周期)
    其中角度 = 基础角度 + 递增角度 × 骨骼序号
         延迟 = 错帧量 × 骨骼序号

    Args:
        group: SwayGroup 实例
        bone_index: 骨骼在组内的序号（0-based）
        frame: 当前场景帧号

    Returns:
        float: 摆动角度（弧度）
    """
    angle_deg = group.sway_angle + group.incremental_angle * bone_index
    delay = group.staggered_frames * bone_index
    effective_frame = frame + group.offset_frame - delay

    loop = group.loop_frames
    if loop <= 0:
        return 0.0

    sway_deg = -angle_deg * math.sin(2 * math.pi * effective_frame / loop)
    return math.radians(sway_deg)


# ==================== 链接复制体扫描 ====================

def _find_linked_armatures(scene, armature_name):
    """找到所有共享同一骨骼数据块的骨架物体名列表。

    扫描场景中所有 ARMATURE 类型的物体，data 指针相等即为链接复制体。
    Alt+D 复制共享数据块，Shift+D 复制创建独立数据块，天然区分。
    返回列表包含源骨架自身。

    Args:
        scene: 当前场景
        armature_name: 源骨架物体名

    Returns:
        list[str]: 所有链接复制体的物体名。源骨架不存在则返回空列表
    """
    armature = scene.objects.get(armature_name)
    if armature is None or armature.type != 'ARMATURE':
        return []

    data = armature.data
    return [obj.name for obj in scene.objects
            if obj.type == 'ARMATURE' and obj.data == data]


# ==================== 单骨骼处理（状态机核心） ====================

def _process_bone(scene, group, bone_item, bone_index, frame, armature_name=None):
    """处理单根骨骼的摆动注入。

    三段式状态追踪逻辑：
      ① 检测用户是否修改了骨骼 → 反推基础旋转
      ② 计算新摆动值
      ③ 组合写入 + 更新追踪状态

    Args:
        armature_name: 可选，覆盖 bone_item.armature_name 的骨架查找名。
            用于处理链接复制体时传入对应的骨架名。
    """
    if armature_name is None:
        armature_name = bone_item.armature_name

    # === 查找骨骼 ===
    bone = find_bone_in_scene(scene, armature_name, bone_item.bone_name)
    if bone is None:
        return

    # === 确保欧拉旋转模式 ===
    ensure_euler_rotation(bone)

    axis_idx = get_axis_index(group.axis)
    current_rot = bone.rotation_euler[axis_idx]

    # === 读取追踪状态 ===
    # 首次处理时不存在追踪属性，此时 base_rot = 当前旋转，last_sway = 0
    is_first_pass = ASWAY_KEY_BASE_ROT not in bone
    base_rot = bone.get(ASWAY_KEY_BASE_ROT, current_rot)
    last_sway = bone.get(ASWAY_KEY_LAST_SWAY, 0.0)
    stored_axis_idx = bone.get(ASWAY_KEY_AXIS_INDEX, -1)

    # === 轴向切换检测 ===
    # 如果用户改了轴向，旧轴上的摆动需要清理，新轴的追踪状态需要重置
    if not is_first_pass and stored_axis_idx != axis_idx:
        # 清理旧轴：把旧轴上的摆动值减回去
        old_base = bone.get(ASWAY_KEY_BASE_ROT, 0.0)
        bone.rotation_euler[stored_axis_idx] = old_base
        # 重置新轴的追踪状态
        base_rot = current_rot
        last_sway = 0.0
        is_first_pass = True  # 跳过用户修改检测，直接以当前值作为基础

    # === 第一步：检测用户是否修改了骨骼 ===
    # expected = 基础旋转 + 上次摆动（即"如果什么都没发生，现在的旋转应该是多少"）
    # 首次处理时跳过检测，直接以当前旋转作为基础
    if not is_first_pass:
        expected = base_rot + last_sway
        if abs(current_rot - expected) > ROTATION_THRESHOLD:
            # 用户动了骨骼（或外部脚本修改了旋转）
            # 反推新的基础旋转 = 当前旋转 - 上次摆动
            base_rot = current_rot - last_sway

    # 持久化 base_rot（仅在值变化时写入，避免不必要的 depsgraph 触发）
    if bone.get(ASWAY_KEY_BASE_ROT) != base_rot:
        bone[ASWAY_KEY_BASE_ROT] = base_rot

    # === 第二步：计算新摆动值 ===
    new_sway = compute_sway(group, bone_index, frame)

    # === 第三步：组合写入 ===
    target_rot = base_rot + new_sway

    if abs(current_rot - target_rot) > ROTATION_THRESHOLD:
        bone.rotation_euler[axis_idx] = target_rot

    # === 第四步：更新追踪状态（仅在值变化时写入） ===
    if bone.get(ASWAY_KEY_LAST_SWAY) != new_sway:
        bone[ASWAY_KEY_LAST_SWAY] = new_sway
    if bone.get(ASWAY_KEY_AXIS_INDEX) != axis_idx:
        bone[ASWAY_KEY_AXIS_INDEX] = axis_idx


# ==================== 摆动剥离 ====================

def strip_sway_from_bone(scene, armature_name, bone_name):
    """从单根骨骼上剥离摆动值，恢复纯基础旋转，并清除追踪属性。

    自动连锁剥离所有链接复制体上的同名骨骼。
    """
    linked = _find_linked_armatures(scene, armature_name)
    for arm_name in linked:
        bone = find_bone_in_scene(scene, arm_name, bone_name)
        if bone is None:
            continue

        base_rot = bone.get(ASWAY_KEY_BASE_ROT)
        axis_idx = bone.get(ASWAY_KEY_AXIS_INDEX, 0)

        if base_rot is not None:
            bone.rotation_euler[axis_idx] = base_rot

        clear_sway_props(bone)


def strip_sway_from_group(scene, group):
    """从组内所有骨骼上剥离摆动值。"""
    for bone_item in group.bones:
        strip_sway_from_bone(scene, bone_item.armature_name, bone_item.bone_name)


# ==================== Handler ====================

@persistent
def autosway_handler(scene):
    """depsgraph_update_post / frame_change_post 回调。

    遍历所有启用的摆动组，为每组中每根骨骼计算并注入摆动。
    使用状态追踪区分"用户的改动"和"处理器自己的改动"。
    """
    try:
        groups = scene.autosway_groups
        if len(groups) == 0:
            return

        frame = scene.frame_current

        # 缓存链接复制体扫描结果（key: armature_name，value: 浅拷贝后的 list）
        linked_cache = {}

        for group in groups:
            if not group.enabled:
                continue
            if len(group.bones) == 0:
                continue

            # 构建组内骨骼集合（每帧只构建一次，全组共用）
            group_bones_set = {(item.bone_name, item.armature_name) for item in group.bones}

            # 检测是否存在父子关系，决定使用深度还是列表序号
            use_depth = has_parent_child_in_group(scene, group_bones_set, group)

            # 当前组的轴向索引（链接循环内复用）
            axis_idx = get_axis_index(group.axis)

            for idx, bone_item in enumerate(group.bones):
                if use_depth:
                    bone_index = compute_bone_depth(scene, group_bones_set, bone_item)
                else:
                    bone_index = idx

                # 找到所有链接复制体（优先从缓存取）
                arm_name = bone_item.armature_name
                if arm_name not in linked_cache:
                    linked_cache[arm_name] = _find_linked_armatures(scene, arm_name)
                cached = linked_cache[arm_name]

                # 重组为以源骨架为首的列表（不修改缓存，避免污染共享状态）
                if arm_name in cached:
                    linked = [arm_name] + [n for n in cached if n != arm_name]
                else:
                    linked = list(cached)

                if len(linked) <= 1:
                    _process_bone(scene, group, bone_item, bone_index, frame)
                    continue

                # 先处理源骨架（保证追踪状态最新）
                ref_name = linked[0]
                _process_bone(scene, group, bone_item, bone_index, frame, ref_name)

                # 处理其他链接复制体
                ref_bone = find_bone_in_scene(scene, ref_name, bone_item.bone_name)
                for arm_name in linked[1:]:
                    dup_bone = find_bone_in_scene(scene, arm_name, bone_item.bone_name)
                    if dup_bone is None:
                        continue

                    # 首次处理：从源骨架复制追踪状态并同步旋转值
                    if ASWAY_KEY_BASE_ROT not in dup_bone:
                        if ref_bone is not None and ASWAY_KEY_BASE_ROT in ref_bone:
                            base = ref_bone[ASWAY_KEY_BASE_ROT]
                            last = ref_bone.get(ASWAY_KEY_LAST_SWAY, 0.0)
                            dup_bone[ASWAY_KEY_BASE_ROT] = base
                            dup_bone[ASWAY_KEY_LAST_SWAY] = last
                            dup_bone[ASWAY_KEY_AXIS_INDEX] = ref_bone.get(ASWAY_KEY_AXIS_INDEX, axis_idx)
                            # 确保欧拉旋转模式（防止四元数隐式转换精度偏差）
                            ensure_euler_rotation(dup_bone)
                            # 关键：同步旋转值为 base + last_sway
                            dup_bone.rotation_euler[axis_idx] = base + last

                    _process_bone(scene, group, bone_item, bone_index, frame, arm_name)

    except AttributeError:
        # 场景属性不可用（插件部分卸载等），静默跳过
        pass
    except Exception as e:
        import traceback
        print(f"[AutoSway] Handler 异常: {e}")
        traceback.print_exc()


# ==================== Handler 注册/注销 ====================
# 注册两个 handler：
#   frame_change_post  → 帧变化后必定触发，负责时间驱动的摆动计算
#   depsgraph_update_post → 任何依赖变化时触发，负责检测用户手动旋转骨骼
# 两者共用同一个 autosway_handler 函数，该函数天然幂等，重复调用无副作用。

def register_handler():
    """注册 frame_change_post 和 depsgraph_update_post handler（防重复）。"""
    fc_handlers = bpy.app.handlers.frame_change_post
    if autosway_handler not in fc_handlers:
        fc_handlers.append(autosway_handler)

    dg_handlers = bpy.app.handlers.depsgraph_update_post
    if autosway_handler not in dg_handlers:
        dg_handlers.append(autosway_handler)


def unregister_handler():
    """注销两个 handler。"""
    for handler_list in (
        bpy.app.handlers.frame_change_post,
        bpy.app.handlers.depsgraph_update_post,
    ):
        while autosway_handler in handler_list:
            handler_list.remove(autosway_handler)


# ==================== 文件加载恢复 ====================

@persistent
def autosway_load_handler(dummy):
    """加载 .blend 文件后，如果场景中有摆动组，注册运行时 handler。"""
    scene = bpy.context.scene
    if hasattr(scene, "autosway_groups") and len(scene.autosway_groups) > 0:
        register_handler()


def register_load_handler():
    """注册 load_post handler。"""
    handlers = bpy.app.handlers.load_post
    if autosway_load_handler not in handlers:
        handlers.append(autosway_load_handler)


def unregister_load_handler():
    """注销 load_post handler。"""
    handlers = bpy.app.handlers.load_post
    while autosway_load_handler in handlers:
        handlers.remove(autosway_load_handler)
