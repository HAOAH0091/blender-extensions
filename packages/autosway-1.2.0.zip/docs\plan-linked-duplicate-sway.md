# 执行计划：链接复制骨架自动继承摆动动画

---

## 1. 问题回顾

### 当前现状

AutoSway 的摆动组存储每根骨骼的 `armature_name`（骨架物体名）。handler 每帧按 `armature_name` 查找骨架对象，找到后处理对应骨骼的摆动。

Alt+D（链接复制）创建的骨架与源骨架共享同一块骨骼数据（`A.data == A.001.data`），但各有各的 Pose（姿态）。当前 handler 只按名字找到源骨架，链接复制体被忽略。

### 核心矛盾

存储用"物体名"定位，但链接复制体的名字不同。handler 没有利用 Blender 的数据块共享关系来发现链接复制体。

### 调用链示意

```
Alt+D 复制 A → A.001（共享 A.data）

handler 执行 →
  find_bone_in_scene(scene, "A", "Bone")       → 找到，处理 ✓
  find_bone_in_scene(scene, "A.001", "Bone")   → 不会执行 ✗
```

---

## 2. 改造目标

| 目标 | 优先级 | 验收标准 |
|------|--------|---------|
| Alt+D 链接复制体自动继承摆动 | P0 | 复制后不需要重新添加摆动组，链接复制体自动同步摆动动画 |
| Shift+D 完整复制体保持独立 | P0 | 完整复制体不被自动关联，需手动创建摆动组 |
| 原骨架和链接复制体摆动同步 | P0 | 调整参数后两者同时变化 |
| 首次处理不出现双倍摆动 | P0 | 链接复制体的初始姿态不做二次叠加 |
| 删除组/禁用组/移除骨骼时连锁剥离 | P1 | 源骨架剥离摆动时，链接复制体也同步剥离 |
| UI 不受影响 | P0 | 摆动组管理面板不显示链接复制体的额外条目 |
| 骨骼序号计算正确 | P0 | 链接复制体层级结构与源骨架一致，深度计算无需额外适配 |

---

## 3. 设计方案

### 核心思路

handler 按 `armature_name` 找到源骨架后，用 `armature.data` 扫描场景中所有共享同一数据块的骨架对象，对每个都执行摆动处理。

Shift+D 不共享数据块，天然不会被扫描到，自动区分。

### 对比

| 维度 | 当前实现 | 改造后 |
|------|---------|--------|
| 骨架查找 | 只找 `armature_name` 一个物体 | 找到源骨架后，扫描所有 `data` 相同的骨架 |
| 首次初始化 | 从当前旋转值初始化 | 链接复制体从源骨架复制追踪状态 |
| 摆动剥离 | 只剥离源骨架 | 连锁剥离所有链接复制体 |
| 存储 | `armature_name`（不变） | 不变 |
| UI | 无影响 | 无影响 |

### 关键设计决策

| 决策 | 选项 | 选择理由 |
|------|------|---------|
| 匹配依据 | **`armature.data` 指针相等** vs 名称前缀匹配 | data 指针是 Blender 内部唯一标识，不受重命名影响，且天然区分 Alt+D 和 Shift+D |
| 追踪状态初始化 | **从源骨架复制** vs 从当前旋转推算 | 从源骨架复制可以精确还原 base_rot 和 last_sway，避免"当前值含摆动"的计算误差 |
| 引用骨架不存在时 | **跳过该骨骼** vs 从其他链接体推断 | 源骨架被删除后，链接复制体也失去摆动，符合"组已失效"的语义 |
| 剥离策略 | **连锁剥离** vs 只剥离源骨架 | 用户删除组时期望所有相关骨架恢复静止，不管是不是链接复制体 |

### 索引映射（不变）

处理骨骼时，`bone_index`（根部骨骼 0，子级递增）用于摆动公式计算。链接复制体共享同一套骨骼层级，深度完全一致。用哪个骨架对象计算深度都一样，不需要额外适配。

---

## 4. 详细设计

### 4.1 涉及的文件

| 文件 | 改动类型 | 改动内容 |
|------|----------|---------|
| `core.py` | 修改 + 新增 | 新增 `_find_linked_armatures()`，修改 `_process_bone` 增加可选参数，修改 handler 循环，修改剥离函数 |
| `utils.py` | **不改** | `find_bone_in_scene` 够用 |
| `properties.py` | **不改** | 数据模型不变 |
| `operators.py` | **不改** | 操作符不变 |
| `ui.py` | **不改** | 面板过滤不变 |

### 4.2 新增函数：`_find_linked_armatures()`

```python
def _find_linked_armatures(scene, armature_name):
    """找到所有共享同一骨骼数据块的骨架物体名列表。

    扫描场景中所有 ARMATURE 类型的物体，data 指针相等即为链接复制体。
    返回列表包含源骨架自身。

    Args:
        scene: 当前场景
        armature_name: 源骨架物体名

    Returns:
        list[str]: 所有链接复制体的物体名。源骨架不存在则返回空列表
    """
    armature = scene.objects.get(armature_name)
    if armature is None or armature.type != 'ARMATURE':
        return []

    data = armature.data
    return [obj.name for obj in scene.objects
            if obj.type == 'ARMATURE' and obj.data == data]
```

复杂度 O(n)，n 为场景中骨架总数。为避免每组每根骨骼重复扫描，在 handler 入口处用 dict 缓存扫描结果（key 为 armature_name），后续循环直接取缓存。`strip_sway_from_bone` 同理，每次调用时按需扫描（剥离操作低频率，可接受）。

### 4.3 修改 `_process_bone()`

增加可选参数 `armature_name`，允许调用方覆盖骨骼查找时使用的骨架名。

```python
def _process_bone(scene, group, bone_item, bone_index, frame, armature_name=None):
    """处理单根骨骼的摆动注入。

    Args:
        armature_name: 可选，覆盖 bone_item.armature_name 的骨架查找名。
            用于处理链接复制体时传入对应的骨架名。
    """
    if armature_name is None:
        armature_name = bone_item.armature_name
    bone = find_bone_in_scene(scene, armature_name, bone_item.bone_name)
    # ... 后续逻辑不变
```

### 4.4 修改 handler 循环

```python
# 为每根骨骼找到所有链接复制体
linked = _find_linked_armatures(scene, bone_item.armature_name)

# 确保 linked[0] 一定是源骨架（scene.objects 迭代顺序不可靠）
if bone_item.armature_name in linked:
    linked.remove(bone_item.armature_name)
    linked.insert(0, bone_item.armature_name)

if len(linked) <= 1:
    # 没有链接复制体，走原路径
    _process_bone(scene, group, bone_item, bone_index, frame)
else:
    # 获取当前组的轴向索引（handler 循环层提前取一次，链接循环内复用）
    axis_idx = get_axis_index(group.axis)

    # 先处理源骨架（保证追踪状态最新）
    ref_name = linked[0]
    _process_bone(scene, group, bone_item, bone_index, frame, ref_name)

    # 处理其他链接复制体
    ref_bone = find_bone_in_scene(scene, ref_name, bone_item.bone_name)
    for arm_name in linked[1:]:
        dup_bone = find_bone_in_scene(scene, arm_name, bone_item.bone_name)
        if dup_bone is None:
            continue

        # 首次处理：从源骨架复制追踪状态并同步旋转值
        if ASWAY_KEY_BASE_ROT not in dup_bone:
            if ref_bone is not None and ASWAY_KEY_BASE_ROT in ref_bone:
                base = ref_bone[ASWAY_KEY_BASE_ROT]
                last = ref_bone.get(ASWAY_KEY_LAST_SWAY, 0.0)
                dup_bone[ASWAY_KEY_BASE_ROT] = base
                dup_bone[ASWAY_KEY_LAST_SWAY] = last
                dup_bone[ASWAY_KEY_AXIS_INDEX] = ref_bone.get(ASWAY_KEY_AXIS_INDEX, axis_idx)
                # 确保欧拉旋转模式（防止四元数模式下写入的隐式转换精度偏差）
                ensure_euler_rotation(dup_bone)
                # 关键：同步旋转值为 base + last_sway
                # 这样 _process_bone 内部 current_rot == expected，
                # 不会误判为"用户手动修改"而错误重算 base_rot
                dup_bone.rotation_euler[axis_idx] = base + last

        _process_bone(scene, group, bone_item, bone_index, frame, arm_name)
```

### 4.5 修改剥离函数

`strip_sway_from_bone` 和 `strip_sway_from_group` 需要连锁剥离链接复制体。

```python
def strip_sway_from_bone(scene, armature_name, bone_name):
    linked = _find_linked_armatures(scene, armature_name)
    for arm_name in linked:
        bone = find_bone_in_scene(scene, arm_name, bone_name)
        if bone is None:
            continue
        # ... 原有剥离逻辑 ...
```

### 4.6 流程图

```
handler 处理骨骼 bone_item
  ↓
_find_linked_armatures(scene, bone_item.armature_name)
  → 返回 ["A", "A.001", "A.002"]
  ↓
linked 数量 ≤ 1？→ 走原路径（无链接体）
  ↓
linked 数量 > 1：
  → 先处理 linked[0]（源骨架，更新追踪状态）
  → 遍历 linked[1:]：
      → 骨骼存在？
      → 首次处理？→ 复制追踪状态
      → _process_bone 计算摆动
```

---

## 5. 实现步骤

### 步骤 1：`core.py` 新增 `_find_linked_armatures()`

在 `compute_sway` 函数后面、`_process_bone` 前面新增。输入 `(scene, armature_name)`，返回 `list[str]`。

### 步骤 2：`core.py` 修改 `_process_bone()`

增加 `armature_name=None` 参数，替代原有的 `bone_item.armature_name` 硬编码查找。更新 docstring。

### 步骤 3：`core.py` 修改 handler 循环

在 `autosway_handler` 中：
- handler 入口处建立 `_find_linked_armatures` 的 dict 缓存（避免每组每骨骼重复扫描）。取缓存时做浅拷贝 `list(cache[name])`，避免就地修改污染共享缓存
- 处理每组骨骼前获取 `axis_idx = get_axis_index(group.axis)`
- 确保 `linked[0]` 始终是源骨架名（显式置顶）
- 首次初始化时复制追踪状态 + 同步旋转值为 `base + last_sway`（防止伪"用户修改检测"误触发）

### 步骤 4：`core.py` 修改剥离函数

修改 `strip_sway_from_bone`，遍历链接复制体逐个剥离。

### 步骤 5：验证改动

用 MCP 脚本在 Blender 中创建测试场景，重点验证 T2（首次初始化不双倍偏移）和 T12（轴向切换不污染旧轴）。

### 步骤 6：提交代码审查

---

## 6. 测试策略

### 测试场景

| ID | 场景 | 操作步骤 | 预期结果 |
|----|------|---------|---------|
| T1 | Alt+D 链接复制继承摆动 | 创建骨架 A，添加摆动组 → Alt+D 复制 → 播放动画 | A 和 A.001 同步摆动 |
| T2 | 首次处理不双倍偏移 | 先让 A 摆动几帧 → Alt+D → 继续播放 | A.001 的姿态与 A 一致，不出现双倍幅度 |
| T3 | 参数修改同步 | 修改摆动角度 → 继续播放 | A 和 A.001 同步更新 |
| T4 | Shift+D 不继承 | 创建骨架 B → Shift+D 复制 → 播放动画 | B.001 不动，需单独添加摆动组 |
| T5 | 删除组连锁剥离 | Alt+D 复制后 → 删除摆动组 | A 和 A.001 都恢复静止 |
| T6 | 禁用组连锁剥离 | 禁用摆动组 | A 和 A.001 都恢复静止 |
| T7 | 移除骨骼连锁剥离 | 从组中移除一根骨骼 | A 和 A.001 的该骨骼都恢复静止 |
| T8 | 源骨架被删除 | A 摆动 → 删除 A → 继续播放 | A.001 失去摆动（组失效） |
| T9 | 链接复制体被删除 | A 摆动 → 删除 A.001 → 继续播放 | A 正常摆动，无异常 |
| T10 | 多级链接复制 | A → Alt+D → A.001 → Alt+D A → A.002 | 三个骨架同步摆动 |
| T11 | 链接复制后新增骨骼到组 | A 有摆动组 → Alt+D → 姿态模式新增骨骼到组 | 新增骨骼在链接复制体上首次初始化正确 |
| T12 | 链接复制后切换摆动轴向 | A 摆动 X 轴 → Alt+D → 切换为 Y 轴 | 链接复制体同步切换，旧轴残留不污染 |

### 手动测试 Checklist

- [ ] Alt+D 后播放动画，链接复制体自动摆动
- [ ] 调整参数后两者同步更新
- [ ] Shift+D 后完整复制体不自动摆动
- [ ] 删除组后两者都恢复静止
- [ ] 禁用组后两者都恢复静止
- [ ] 移除骨骼后两者该骨骼都恢复静止
- [ ] 操纵骨骼手动旋转后，反推基础旋转在两者上都正常
- [ ] 链接复制后新增骨骼到组，链接复制体初始化正确
- [ ] 链接复制后切换轴向，两者同步且旧轴不残留
- [ ] 日志无 AutoSway 错误

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 源骨架不存在时 `_find_linked_armatures` 返回空列表 | 低 | 骨骼被跳过，符合预期 | 函数内做 None 检查 |
| 链接复制体的骨骼不存在（如被改名但源骨架未改名） | 极低 | `find_bone_in_scene` 返回 None → 跳过 | 已做 None 检查 |
| 首次初始化复制追踪状态时源骨架数据异常 | 极低 | 链接复制体用当前旋转兜底 | if 条件做 `ASWAY_KEY_BASE_ROT in ref_bone` 检查 |
| 场景中有大量骨架对象时扫描性能 | 低 | O(n) 扫描每次 handler 调用执行多次 | 典型场景 <10 骨架，总量可忽略；极端场景可加缓存 |
| UI 过滤需要提前知道哪些组对当前骨架可见 | 无 | `_find_linked_armatures` 在 core 层，不影响 UI | UI 用 `armature_name` 过滤，行为不变 |

### 回退方案

1. 用 git 回退 `core.py` 的修改
2. 改动影响范围只有 `core.py` 一个文件，回退成本极低

---

## 8. 参考

- Blender API: `Object.data` — 链接复制的数据块引用
- Blender API: `bpy.data.objects` — 场景中所有物体
- 当前代码：`core.py` 的 `autosway_handler`、`_process_bone`、`strip_sway_from_bone`
- `utils.py` 的 `find_bone_in_scene`
