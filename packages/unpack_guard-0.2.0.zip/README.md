# Unpack Guard（解包安全助手）

拦截 Blender 官方解包，检测同名打包贴图并询问处理方式，防止贴图张冠李戴。
带解包方式选择、同名冲突检测、全程进度条、中文界面。

## 它解决什么问题

Blender 官方解包（`File > External Data > Unpack Resources`）会把所有**同名 basename** 的打包贴图
归一到同一个外部文件——同名不同内容的贴图互相覆盖，保存重开后贴图错位（张冠李戴）。
本插件接管解包入口，完整保留官方功能，并在其上叠加：

- **解包方式选择**：完整复刻官方 6 种方式（写到当前目录 / 覆盖写当前目录 / 写回原始位置 /
  覆盖写原始位置 / 关闭自动打包保留 / 移除打包），一项不少。
- **同名冲突检测**：选好解包方式后检测同名冲突，让用户决定：
  - **合并同名素材**：按官方默认方式解包（接受错位风险）
  - **自动重命名防止错位**：给同名贴图改唯一名并安全导出，再解包剩余资源（推荐）
- **进度条**：解包全程顶栏进度条实时刷新，UI 不冻结，`ESC` 可取消。

无同名冲突时自动走官方解包（带进度反馈），行为与官方一致，无感知。

## 安装

Blender 4.2+：

1. `Edit > Preferences > Add-ons`
2. 右上角下拉菜单 → **Install from Disk**
3. 选择 `unpack_guard.zip`（或解压后的 `unpack_guard` 文件夹）
4. 搜索 "Unpack Guard" → 勾选启用

> 升级已安装版本时，先取消勾选再重新勾选启用（或重启 Blender），确保新代码加载。

## 使用

点击 `File > External Data > Unpack Resources`（插件接管后显示为**解包资源（安全）**）：

1. 先弹"解包方式"菜单，选官方 6 种方式之一（中文界面显示中文）。
2. 选好后自动做同名冲突检测：
   - 无冲突 → 直接带进度条执行官方解包。
   - 有冲突 → 弹对话框：显示"N 组同名素材（M 张贴图）"，选"合并"或"自动重命名"。
3. 处理中顶栏显示进度条；`ESC` 可取消（已处理部分保留，未处理任务不动）。

## 调试日志

偏好设置（`Edit > Preferences > Add-ons > Unpack Guard`）里勾选 **"调试日志 (DEBUG)"**，
然后打开 System Console（`Window > Toggle System Console`）即可看到 `[UnpackGuard][...]` 日志，
覆盖：检测扫描、冲突组清单、用户选择、逐张处理映射、官方调用、异常 traceback。
命令行可用环境变量 `UNPACK_GUARD_DEBUG=1` 等效开启。

## 工作原理

- **拦截点**：重写官方菜单类 `TOPBAR_MT_file_external_data.draw`，把 "Unpack Resources" 菜单项
  换绑到我们的 `file.unpack_all_safe`（GUI 点菜单的唯一可靠拦截点；已实测 monkey-patch `bpy.ops`
  是静默无效的，脚本调用官方解包无法拦截，属平台限制）。
- **method 菜单**：`invoke` 先弹 6 种解包方式菜单（复刻官方 `unpack_all_invoke` 的 `op_enum` 行为），
  选中后带该 method 再走冲突检测，最终透传给官方 `bpy.ops.file.unpack_all(method=...)`。
- **进度条**：安全解包 + 官方解包收尾由 **Modal Operator + Timer** 驱动，用
  `WindowManager.progress_begin/update/end` 实时刷新，`ESC` 取消。
- **检测**：扫描场景可达的所有贴图（物体材质递归嵌套组 + world + 合成器 + 几何节点），
  按 basename 分组找"打包且重复"的冲突组。
- **安全解包**：对冲突组执行 `改 filepath(唯一) → img.save() → unpack(REMOVE)`，
  绕开官方解包"只认打包快照 basename"的限制（详见知识库 `[[unpack_all 解包机制]]`）。
- **防二次覆盖**：命名预填所有 basename + 磁盘已有文件（含 UDIM 展开文件），大小写不敏感。
- **多语言**：插件所有界面文案（菜单项、解包方式、冲突对话框、进度提示、偏好面板）都接入
  `bpy.app.translations`，**跟随 Blender 界面语言设置实时切换**——切到简体中文显示中文、
  切到英文显示英文，无需重启；method 标签直接复用官方中文翻译。

## 文件结构

```
unpack_guard/
  __init__.py     # bl_info、注册/注销、菜单换绑、偏好设置
  debug.py        # 日志基础设施（级别开关、System Console 输出）
  detection.py    # detect_conflicts()：只读同名冲突检测
  core.py         # plan_safe_unpack()/run_safe_unpack_task()：唯一改名 + save + REMOVE
  operators.py    # FILE_OT_unpack_all_safe：method 菜单 + 冲突对话框 + Modal 进度条
  translations.py # 界面翻译（菜单项/method 标签中文）
```

## 已知限制

- 只拦截 **GUI 菜单**解包；Python 脚本调用 `bpy.ops.file.unpack_all()` 不经过本插件
  （`bpy.ops` 无法被 Python 赋值覆盖）。
- 单文件解包（贴图旁的 gift box 图标 → `unpack_item`）暂未接管（P1）。
- 菜单重写以 Blender 5.2 官方源码为基准；大版本升级若官方菜单增项需核对 `__init__.py` 的 draw。
- 进度条的**最后一步**是官方 `unpack_all` 内部（C 层，无进度插桩），表现为进度条接近满格 +
  光标等待，属可接受方案。
- `img.save()` 写盘是外部副作用，`Ctrl+Z` 撤销只回滚内存状态（filepath 等），**已写盘的文件不会回滚**。

## 版本

v0.2.0 · 适配 Blender 5.2.x · 中文界面
- v0.2.0：新增 method 菜单（恢复官方 6 种解包方式）、Modal 进度条、中英文界面
- v0.1.0：同名冲突检测 + 安全解包
