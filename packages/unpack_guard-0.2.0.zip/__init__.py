"""Unpack Guard（解包安全助手）

拦截官方"File > External Data > Unpack Resources"解包：
- 检测到同名打包贴图时弹窗询问"合并同名素材 / 自动重命名防止错位"；
- 无同名冲突时静默放行，行为与官方完全一致。
无侧边栏面板；偏好设置在 Edit > Preferences > Add-ons 里。

拦截机制（Blender 5.2.1 实测）：
- GUI 点菜单走 C 层 operator，按 bl_idname 直接执行 → 重写 TOPBAR_MT_file_external_data.draw
  把 "Unpack Resources" 项换绑到我们的 file.unpack_all_safe，这是唯一可靠拦截点。
- 已确认 monkey-patch bpy.ops.file.unpack_all 是静默无效的（bpy.ops 为 C 层动态生成，
  赋值不报错但调用仍走官方），因此脚本调用官方解包无法拦截，属平台限制。
"""
import bpy
from bpy.types import AddonPreferences
from bpy.props import BoolProperty

from . import debug
from . import translations
from .operators import FILE_OT_unpack_all_safe

log = debug.get_logger()

bl_info = {
    "name": "Unpack Guard（解包安全助手）",
    "author": "Blender 美术插件开发",
    "version": (0, 2, 0),
    "blender": (5, 2, 0),
    "location": "File > External Data > Unpack Resources（自动接管）",
    "description": "拦截官方解包，检测同名素材并询问合并或自动重命名防止错位",
    "category": "Import-Export",
}


class UnpackGuardPrefs(AddonPreferences):
    bl_idname = __package__

    debug_log: BoolProperty(
        name="Debug Log (DEBUG)",
        description="Enable to output full DEBUG logs to the System Console for troubleshooting",
        default=False,
        update=lambda self, context: debug.set_debug(self.debug_log),
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "debug_log")
        layout.separator()
        layout.label(
            text=translations.translate(
                "Note: This add-on takes over the menu unpack entry (File > External Data > Unpack Resources)."),
            icon="INFO")
        layout.label(
            text=translations.translate(
                "After clicking, choose the unpack method (official 6 options), then same-name conflicts "
                "are detected and a progress bar is shown throughout."))
        layout.label(
            text=translations.translate(
                "Same-name conflicts mean duplicated basenames of packed textures; auto-rename writes "
                "to //textures/ and is irreversible."))


# ---- 菜单换绑（GUI 拦截，唯一可靠拦截点） ----
_MENU_CLASS_NAME = "TOPBAR_MT_file_external_data"


def _install_menu_patch():
    """重写官方 External Data 菜单 draw，把 Unpack Resources 换绑到 file.unpack_all_safe。

    官方 draw 保存在菜单类属性 _unpack_guard_orig_draw 上（而非模块全局），
    这样即使插件模块被重新加载（开发/热重载场景），unregister 也能正确恢复。
    """
    menu_cls = getattr(bpy.types, _MENU_CLASS_NAME, None)
    if menu_cls is None:
        log.warning("找不到菜单类 %s（可能非 GUI 模式），跳过菜单换绑", _MENU_CLASS_NAME)
        return False
    # 首次安装时保存官方 draw 到菜单类属性
    if getattr(menu_cls, "_unpack_guard_orig_draw", None) is None:
        menu_cls._unpack_guard_orig_draw = menu_cls.draw
        log.debug("已保存官方 %s.draw 到菜单类属性", _MENU_CLASS_NAME)
    if getattr(menu_cls, "_unpack_guard_installed", False):
        log.debug("菜单换绑已安装，跳过")
        return True

    def _safe_draw(self, context):
        # 以 Blender 5.2 space_topbar.py 官方源码为基准，仅替换 unpack 一项
        layout = self.layout
        icon = "CHECKBOX_HLT" if bpy.data.use_autopack else "CHECKBOX_DEHLT"
        layout.operator("file.autopack_toggle", icon=icon)
        pack_all = layout.row()
        pack_all.operator("file.pack_all")
        pack_all.active = not bpy.data.use_autopack
        unpack_all = layout.row()
        # 显式 text 指定翻译后文本：Blender 对 bl_label 自动翻译走 "Operator" context，
        # 这里再显式取一次当前语言文本，保证菜单项文本跟随界面语言切换。
        unpack_all.operator("file.unpack_all_safe",
                            text=translations.translate("Unpack Resources (Safe)"))
        unpack_all.active = not bpy.data.use_autopack
        layout.separator()
        layout.operator("file.pack_libraries")
        layout.operator("file.unpack_libraries")
        layout.separator()
        layout.operator("file.make_paths_relative")
        layout.operator("file.make_paths_absolute")
        layout.separator()
        layout.operator("file.report_missing_files")
        layout.operator("file.find_missing_files", text="Find Missing Files...")

    menu_cls.draw = _safe_draw
    menu_cls._unpack_guard_installed = True
    log.debug("已接管 %s.draw（Unpack Resources 项换绑为 file.unpack_all_safe）", _MENU_CLASS_NAME)
    return True


def _restore_menu_patch():
    """从菜单类属性恢复官方 draw。"""
    menu_cls = getattr(bpy.types, _MENU_CLASS_NAME, None)
    if menu_cls is None:
        log.debug("菜单 draw 恢复: 菜单类不存在")
        return
    orig = getattr(menu_cls, "_unpack_guard_orig_draw", None)
    if orig is not None:
        menu_cls.draw = orig
        menu_cls._unpack_guard_orig_draw = None
        menu_cls._unpack_guard_installed = False
        log.debug("已恢复官方 %s.draw", _MENU_CLASS_NAME)
    else:
        log.warning("菜单 draw 恢复: 找不到已保存的官方 draw（可能未安装过）")


# ---- 注册/注销 ----
def register():
    debug.init_logger(False)
    log.info("Unpack Guard 注册中... v%s", ".".join(map(str, bl_info["version"])))

    # 防御性注册：F3 重载 / Blender 启动自动加载已启用插件时可能重复触发，
    # 先静默注销旧翻译再注册，避免 "translations message cache already contains" 中断。
    try:
        translations.unregister()
    except Exception:
        pass
    translations.register()

    for cls in (FILE_OT_unpack_all_safe, UnpackGuardPrefs):
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            log.debug("类 %s 已注册，跳过（重载场景）", cls.__name__)

    # 读取偏好里的 debug 开关（首次安装可能读不到，无妨）
    try:
        prefs = bpy.context.preferences.addons.get(__package__)
        if prefs is not None:
            debug.set_debug(getattr(prefs.preferences, "debug_log", False))
    except Exception:
        pass

    _install_menu_patch()

    log.info("Unpack Guard 注册完成")


def unregister():
    log.info("Unpack Guard 注销中...")
    _restore_menu_patch()
    for cls in (FILE_OT_unpack_all_safe, UnpackGuardPrefs):
        try:
            bpy.utils.unregister_class(cls)
        except ValueError:
            log.debug("类 %s 未注册，跳过注销（重载场景）", cls.__name__)
    try:
        translations.unregister()
    except Exception:
        pass
    log.info("Unpack Guard 注销完成")


if __name__ == "__main__":
    register()
