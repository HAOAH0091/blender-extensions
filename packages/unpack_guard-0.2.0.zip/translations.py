"""Unpack Guard - 界面翻译（多语言）。

插件所有用户可见文案都以英文原文为 msgid，注册中文翻译，
由 Blender 界面语言设置驱动：中文界面显示中文、英文界面显示英文。
method 6 句与官方英文句完全一致，中文界面会自动命中官方翻译，这里的
中文翻译作兜底（官方翻译缺失时仍显示中文）。

键格式：{locale: {(context, msgid): translation}}，context 用 "*"（默认上下文，通配所有）。
语言代码做别名兼容（zh_HANS/zh_CN/zh、zh_HANT/zh_TW），避免不同 Blender 版本
语言代码不一致导致翻译失效。参照知识库 [[多语言翻译]] 的 compify 模式。
"""
import bpy

# ---- 简体中文对照表（英文 msgid -> 简体中文） ----
_ZH_HANS = {
    # ---- Operator ----
    "Unpack Resources (Safe)": "解包资源（安全）",
    "Unpack resources safely; if same-named textures are detected you will be asked "
    "how to proceed, preventing texture mismatch": "解包资源；若检测到同名素材会先询问处理方式，防止贴图错位",
    # ---- 官方 method 6 句（官方翻译兜底） ----
    "Use files in current directory (create when necessary)": "使用当前目录中的文件（必要时创建）",
    "Write files to current directory (overwrite existing files)": "写入当前目录（覆盖现有文件）",
    "Use files in original location (create when necessary)": "使用原始位置的文件（必要时创建）",
    "Write files to original location (overwrite existing files)": "写入原始位置（覆盖现有文件）",
    "Disable auto-pack, keep all packed files": "关闭自动打包，保留所有打包文件",
    "Remove Pack": "移除打包",
    # ---- 冲突处理选项 ----
    "How to Handle": "处理方式",
    "How to handle same-name conflicts": "同名冲突的处理方式",
    "Merge Same-Named Textures": "合并同名素材",
    "Auto-Rename to Prevent Mismatch": "自动重命名防止错位",
    "Unpack with the official default behavior; same-named textures are merged (may mismatch)": "按官方默认方式解包，同名贴图会合并（可能错位）",
    "Rename same-named textures to unique names and safely export them first, then unpack "
    "the remaining resources": "先给同名贴图改唯一名并安全导出，再解包剩余资源",
    # ---- method 菜单标题 ----
    "Unpack Resources — Packed Files: {n}": "解包资源 — 打包文件 {n} 个",
    # ---- 对话框 ----
    "Detected {count} group(s) of same-named textures ({total} textures in total)": "检测到 {count} 组同名素材（共 {total} 张贴图）",
    "Directly unpacking overwrites each other and causes textures to mismatch. Please choose how to proceed:": "直接解包会互相覆盖，导致贴图错位。请选择处理方式：",
    "Unpack Method: {m}": "解包方式：{m}",
    "Auto-rename writes to disk and is irreversible; it is recommended to save the file first.": "自动重命名会写盘且不可逆，建议先保存文件。",
    "Merging same-named textures is the official default behavior; same-named textures may mismatch.": "合并同名素材 = 官方默认行为，同名贴图可能张冠李戴。",
    # ---- Report / 提示 ----
    "No packed files to unpack": "没有可解包的打包资源",
    "Auto-pack disabled, all packed files kept": "已关闭自动打包，保留所有打包文件",
    "Remove Pack does not write to disk; external references may be missing, please verify": "移除打包：不写盘，外部引用可能缺失，请核对",
    "Packed data removed ({ret})": "已移除打包（{ret}）",
    "Removing packed data failed: {err}": "移除打包失败：{err}",
    "Cancelled: {done}/{total} steps done, remaining tasks untouched; files already written "
    "are not rolled back": "已取消：已完成 {done}/{total} 步，未处理任务保留；已写盘文件不回滚",
    "Unpack finished: safely processed {done}/{total} textures": "解包完成：安全处理 {done}/{total} 张",
    ", planning failed {n}": "，规划失败 {n} 张",
    ", execution failed {n} (see console log)": "，执行失败 {n} 张（详见控制台日志）",
    ", official unpack error: {err}": "，官方解包出错：{err}",
    # ---- 偏好设置 ----
    "Debug Log (DEBUG)": "调试日志 (DEBUG)",
    "Enable to output full DEBUG logs to the System Console for troubleshooting": "开启后输出全量 DEBUG 日志到 System Console，便于排查问题",
    "Note: This add-on takes over the menu unpack entry (File > External Data > Unpack Resources).": "说明: 本插件只接管菜单解包入口（File > External Data > Unpack Resources）。",
    "After clicking, choose the unpack method (official 6 options), then same-name conflicts "
    "are detected and a progress bar is shown throughout.": "点击后先选解包方式（官方 6 种），再检测同名冲突并全程显示进度条。",
    "Same-name conflicts mean duplicated basenames of packed textures; auto-rename writes "
    "to //textures/ and is irreversible.": "同名冲突指打包贴图 basename 重复；自动重命名会写盘到 //textures/ 且不可逆。",
}

# 繁体暂复用简体（简繁大体互通，保证繁体界面不回落英文）；后续可按需细化。
_ZH_HANT = dict(_ZH_HANS)

# 简体/繁体语言代码别名，覆盖不同 Blender 版本
_SIMPLIFIED_LOCALES = ("zh_HANS", "zh_CN", "zh")
_TRADITIONAL_LOCALES = ("zh_HANT", "zh_TW")


def build_translations_dict():
    """build 出 {locale: {("*"|"Operator", msgid): translation}} 字典。

    一个 msgid 同时注册 "*"（默认/常规 UI 文本、tooltip、method 标注）与
    "Operator"（operator 标签 bl_label / bl_description / operator 枚举项 name
    的翻译 context）两个 context key——Blender 对 operator 名称查翻译用
    "Operator" context（wm_operator_type.cc 里 ot->translation_context =
    BLT_I18NCONTEXT_OPERATOR_DEFAULT），只注册 "*" 会查不到。
    """
    d = {}
    for loc in _SIMPLIFIED_LOCALES:
        d[loc] = {}
        for k, v in _ZH_HANS.items():
            d[loc][("*", k)] = v
            d[loc][("Operator", k)] = v
    for loc in _TRADITIONAL_LOCALES:
        d[loc] = {}
        for k, v in _ZH_HANT.items():
            d[loc][("*", k)] = v
            d[loc][("Operator", k)] = v
    return d


# 惰性构建一次，模块重载也安全（字典值幂等）
_translations_dict = None


def get_translations_dict():
    global _translations_dict
    if _translations_dict is None:
        _translations_dict = build_translations_dict()
    return _translations_dict


def register():
    bpy.app.translations.register(__package__, get_translations_dict())


def unregister():
    try:
        bpy.app.translations.unregister(__package__)
    except Exception:
        # 未注册/重复注销时静默，保证 unregister 幂等
        pass


def translate(text):
    """取当前语言翻译；无 i18n 或未命中时原样返回。"""
    try:
        return bpy.app.translations.pgettext_iface(text)
    except Exception:
        return text
