"""Unpack Guard - 同名冲突检测（纯只读，无副作用）。

扫描"场景可达"的所有 TEX_IMAGE 引用贴图，按 filepath 的 basename 分组，
找出 basename 重复且成员为打包状态（packed_file 非空）的冲突组。

覆盖范围：
- 场景物体材质（递归嵌套节点组）
- world 材质
- 合成器（Blender 5.0+ 属性是 scene.compositing_node_group，不是 node_tree）
- 几何节点修改器（modifier.node_group）

日志：内部用 DEBUG 输出扫描明细，INFO 输出汇总。
"""
import bpy
import os
from collections import defaultdict

from .debug import get_logger

log = get_logger()


def collect_tex_images():
    """递归收集场景可达的所有 TEX_IMAGE 引用的 image（按 image.name 去重）。"""
    seen_trees = set()
    seen_images = set()

    def walk(tree):
        if tree is None or tree in seen_trees:
            return
        seen_trees.add(tree)
        for node in tree.nodes:
            if node.type == "TEX_IMAGE" and node.image:
                seen_images.add(node.image.name)
            elif node.type == "GROUP" and node.node_tree:
                walk(node.node_tree)

    scene_count = len(bpy.data.scenes)
    mat_count = 0
    for sc in bpy.data.scenes:
        # 物体材质（含嵌套节点组）
        for ob in sc.objects:
            if ob.data and hasattr(ob.data, "materials"):
                for mat in ob.data.materials:
                    if mat and mat.use_nodes:
                        mat_count += 1
                        walk(mat.node_tree)
            # 几何节点修改器
            if ob.modifiers:
                for mod in ob.modifiers:
                    if getattr(mod, "node_group", None):
                        walk(mod.node_group)
        # world 材质
        if sc.world and sc.world.use_nodes:
            walk(sc.world.node_tree)
        # 合成器（5.0+ 属性改名）
        comp = getattr(sc, "compositing_node_group", None)
        if comp is not None:
            walk(comp)

    log.debug("扫描范围: 场景 %d 个, 材质 %d 个, 递归遍历节点组, 引用贴图 %d 张",
              scene_count, mat_count, len(seen_images))
    return seen_images


def detect_conflicts():
    """返回 {basename: [image_name, ...]}（成员均为"打包"，len>=2 且至少一个被场景引用）。

    只读，不修改任何数据。失败时返回空 dict 并打 ERROR 日志。

    关键（B3）：不只统计"被场景引用"的打包图。因为官方解包会把**所有**打包图（含未被引用的 unused）
    都写回 //textures/<basename>；若某 basename 有"被引用打包图 + 未引用打包 twin"，官方 WRITE_LOCAL
    会让后写者覆盖前者 → 被引用图错位。所以只要某 basename 打包成员>=2 且含至少一个被引用，就整体升级为
    冲突，并把**全部打包成员**（含未引用）交给计划改名（改 unused 无害）。
    """
    log.debug("开始扫描同名冲突...")
    try:
        referenced = collect_tex_images()
        log.debug("被引用贴图 %d 张", len(referenced))

        # 全部打包贴图（含未引用）按 basename 分组；basename 用 bpy.path.basename，
        # 避免 os.path.basename 在 Windows 对 "//textures/x.png"（// 前缀+混合分隔符）返回空串。
        # 分组 key 小写（大小写不敏感：Windows 不区分大小写，foo.png/FOO.PNG 是同一文件），
        # 但必须保留第一个成员的**原始 basename**（含大写的 <UDIM> 模板标记）——若整体小写化，
        # <UDIM> 会变成 <udim>，Blender 不识别该 UDIM 标记，plan 生成的模板名在 save 时失败/回滚。
        all_packed = defaultdict(list)
        first_orig = {}
        for img in bpy.data.images:
            if img.packed_file is not None:
                base = bpy.path.basename(img.filepath) if img.filepath else img.name
                key = base.lower()
                all_packed[key].append(img.name)
                if key not in first_orig:
                    first_orig[key] = base

        conflicts = {}
        for key, names in all_packed.items():
            ref_members = [n for n in names if n in referenced]
            if len(names) >= 2 and ref_members:
                # 整组打包成员全部纳入（含未引用 twin），全部改名；
                # conflicts 的 key 用原始 basename，保证 split_base 能识别 <UDIM> 大标记
                conflicts[first_orig[key]] = names
                shown = names[:10]
                suffix = " ..." if len(names) > 10 else ""
                log.debug("  冲突组 [%s] -> %d 张(含未引用 %d): %s%s",
                          first_orig[key], len(names), len(names) - len(ref_members), shown, suffix)

        total = sum(len(v) for v in conflicts.values())
        log.info("同名冲突检测完成: %d 组 / %d 张", len(conflicts), total)
        return conflicts
    except Exception as e:
        import traceback
        log.error("同名冲突检测失败: %s\n%s", e, traceback.format_exc())
        return {}
