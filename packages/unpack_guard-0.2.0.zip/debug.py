"""Unpack Guard - 调试日志基础设施。

统一用标准库 logging，logger 名 "unpack_guard"，输出到 System Console / 终端。
- 默认 INFO 级别（关键路径可见）
- 勾选偏好设置 debug 或设环境变量 UNPACK_GUARD_DEBUG=1 后升到 DEBUG（全量明细）
- 日志统一前缀 [UnpackGuard][LEVEL]，便于过滤；每行尽量带上下文对象名
"""
import os
import sys
import logging

LOGGER_NAME = "unpack_guard"

_logger = None


def init_logger(debug: bool = False) -> logging.Logger:
    """初始化全局 logger（幂等，重复调用只重置 handler，避免叠加）。"""
    global _logger
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.DEBUG if debug else logging.INFO)
    # 清理已有 handler，避免多次 register 叠加重复输出
    for h in list(logger.handlers):
        logger.removeHandler(h)
        try:
            h.close()
        except Exception:
            pass
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("[UnpackGuard][%(levelname)s] %(message)s"))
    logger.addHandler(handler)
    # 不向 root logger 传播（避免和其他插件日志混在一起）
    logger.propagate = False
    _logger = logger
    return logger


def set_debug(debug: bool) -> None:
    """运行时切换日志级别（偏好设置复选框变更时调用）。"""
    global _logger
    if _logger is not None:
        _logger.setLevel(logging.DEBUG if debug else logging.INFO)
        _logger.debug("调试日志级别已切换为 %s", "DEBUG" if debug else "INFO")


def get_logger() -> logging.Logger:
    """获取全局 logger；未初始化时按环境变量自动初始化。"""
    global _logger
    if _logger is None:
        # headless / 命令行可用环境变量控制 debug
        env_debug = os.environ.get("UNPACK_GUARD_DEBUG", "").strip().lower() in ("1", "true", "yes")
        _logger = init_logger(env_debug)
    return _logger
