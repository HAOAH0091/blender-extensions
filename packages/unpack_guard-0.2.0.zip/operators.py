"""Unpack Guard - 包装 operator 与弹窗对话框。

FILE_OT_unpack_all_safe 接管官方"Unpack Resources"菜单项，完整复刻官方交互：
1. invoke 先弹"解包方式"菜单（官方 6 种 method，中文界面显示中文）——不再吞掉官方选项；
2. 用户选定 method 后再做同名冲突检测：
   - 无冲突 → 带进度条执行官方解包；
   - 有冲突 → 弹对话框让用户选"合并同名素材 / 自动重命名防止错位"；
3. 安全解包/官方解包全程由 Modal Operator + Timer 驱动：顶栏进度条实时刷新、
   UI 不冻结、ESC 可取消。

方法分发语义（对齐官方 unpack_all_exec）：
- KEEP    -> 关闭自动打包，不解包
- REMOVE  -> 直接官方移除打包（不写盘，无错位风险，不弹冲突检测）
- 其余 4 种 -> 冲突检测 -> 无冲突直接官方 / 有冲突弹对话框
"""
import bpy
from bpy.types import Operator
from bpy.props import EnumProperty, IntProperty, BoolProperty

from .debug import get_logger
from .detection import detect_conflicts
from . import core
from . import translations

log = get_logger()

# 官方 RNA 枚举项的真实 name（探测自 5.2.1），作为翻译 msgid 与 method 菜单显示文本。
# 注意：KEEP 官方 name 是 "Disable auto-pack..."（auto-pack 小写），与旧版描述串不同。
_METHOD_LABELS = {
    "USE_LOCAL": "Use files in current directory (create when necessary)",
    "WRITE_LOCAL": "Write files to current directory (overwrite existing files)",
    "USE_ORIGINAL": "Use files in original location (create when necessary)",
    "WRITE_ORIGINAL": "Write files to original location (overwrite existing files)",
    "KEEP": "Disable auto-pack, keep all packed files",
    "REMOVE": "Remove Pack",
}

# 与官方 file.unpack_all 的 method 六选项保持一致；name/description 用官方可读句，
# 使 redo / F6 面板显示可读文本而非 identifier；KEEP 描述对齐官方小写。
_METHOD_ITEMS = [
    (ident, _METHOD_LABELS[ident], _METHOD_LABELS[ident])
    for ident in ("USE_LOCAL", "WRITE_LOCAL", "USE_ORIGINAL", "WRITE_ORIGINAL", "KEEP", "REMOVE")
]

# 菜单排列顺序（与官方一致：USE 系列 -> KEEP -> REMOVE）
_METHOD_ORDER = ("USE_LOCAL", "WRITE_LOCAL", "USE_ORIGINAL", "WRITE_ORIGINAL", "KEEP", "REMOVE")

_ACTION_ITEMS = [
    ("MERGE", "Merge Same-Named Textures",
     "Unpack with the official default behavior; same-named textures are merged (may mismatch)"),
    ("RENAME", "Auto-Rename to Prevent Mismatch",
     "Rename same-named textures to unique names and safely export them first, then unpack the remaining resources"),
]


class FILE_OT_unpack_all_safe(Operator):
    bl_idname = "file.unpack_all_safe"
    bl_label = "Unpack Resources (Safe)"
    bl_description = ("Unpack resources safely; if same-named textures are detected you will be asked "
                      "how to proceed, preventing texture mismatch")
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    method: EnumProperty(name="Method", description="How to unpack", items=_METHOD_ITEMS, default="USE_LOCAL")
    action: EnumProperty(name="How to Handle", description="How to handle same-name conflicts",
                         items=_ACTION_ITEMS, default="RENAME")
    # 标记本次调用是从 method 选择菜单进入的（跳过首步 method 菜单）
    invoked_from_menu: BoolProperty(name="", default=False, options={"HIDDEN"})

    conflict_count: IntProperty(default=0)
    conflict_images: IntProperty(default=0)

    # ---- Modal 运行状态（非 RNA 属性，每次进入前必须重新初始化） ----
    _tasks = None          # 安全解包任务队列 [{image, old_filepath, new_filepath}, ...]
    _plan_errors = None    # 规划期命名失败 {image: msg}
    _failed = None         # 执行期失败 {image: msg}
    _state = ""            # "SAFE_UNPACK" / "OFFICIAL" / "DONE"
    _total = 0
    _done = 0
    _timer = None
    _official_ret = None
    _official_err = None

    # ---- 工具（不依赖实例，均可静态调用） ----
    @staticmethod
    def _count_packed():
        """统计打包资源数（对齐官方 BKE_packedfile_count_all 的简化：Image/VFont/Sound/Volume）。"""
        count = 0
        for attr in ("images", "fonts", "sounds", "volumes"):
            coll = getattr(bpy.data, attr, None)
            if coll is None:
                continue
            for item in coll:
                if getattr(item, "packed_file", None) is not None:
                    count += 1
        return count

    @staticmethod
    def _t(text):
        """取当前语言翻译；无 i18n 或未命中时原样返回。"""
        return translations.translate(text)

    @staticmethod
    def _fmt(template, **kw):
        """翻译后做 str.format 填充（模板里的 {占位符} 需在翻译里保持一致）。"""
        return translations.translate(template).format(**kw)

    @staticmethod
    def _method_name(ident):
        return _METHOD_LABELS.get(ident, ident)

    # ---- 交互 ----
    def _method_menu(self, context):
        """复刻官方 invoke：弹"解包方式"菜单（6 个 method），选中即带该参数再次调用。"""
        packed = self._count_packed()
        if packed == 0:
            self.report({"WARNING"}, self._t("No packed files to unpack"))
            return {"CANCELLED"}
        log.info("弹解包方式菜单：打包资源 %d 个", packed)

        def draw(menu, _ctx):
            layout = menu.layout
            for ident in _METHOD_ORDER:
                op = layout.operator("file.unpack_all_safe", text=self._t(self._method_name(ident)))
                op.method = ident
                op.invoked_from_menu = True

        context.window_manager.popup_menu(
            draw, title=self._fmt("Unpack Resources — Packed Files: {n}", n=packed))
        return {"INTERFACE"}

    def invoke(self, context, event):
        if not self.invoked_from_menu:
            return self._method_menu(context)

        if self.method == "KEEP":
            log.info("[method] KEEP：关闭自动打包，保留所有打包文件")
            bpy.data.use_autopack = False
            self.report({"INFO"}, self._t("Auto-pack disabled, all packed files kept"))
            return {"FINISHED"}

        if self.method == "REMOVE":
            log.info("[method] REMOVE：移除打包（不写盘）")
            self.report({"INFO"},
                        self._t("Remove Pack does not write to disk; external references may be missing, please verify"))
            try:
                ret = bpy.ops.file.unpack_all(method="REMOVE")
                self.report({"INFO"}, self._fmt("Packed data removed ({ret})", ret=ret))
            except Exception as e:
                import traceback
                log.error("官方 unpack_all(REMOVE) 失败: %s\n%s", e, traceback.format_exc())
                self.report({"ERROR"}, self._fmt("Removing packed data failed: {err}", err=e))
            return {"FINISHED"}

        # 其余 4 种（USE/WRITE 系列）：同名冲突检测
        log.info("[method] %s：开始同名冲突检测", self.method)
        conflicts = detect_conflicts()
        if not conflicts:
            log.info("无同名冲突，带进度执行官方解包")
            return self._begin_modal(context, conflicts={})
        total = sum(len(v) for v in conflicts.values())
        log.info("发现 %d 组同名冲突（%d 张），弹出对话框等待用户选择", len(conflicts), total)
        self.conflict_count = len(conflicts)
        self.conflict_images = total
        return context.window_manager.invoke_props_dialog(self, width=520)

    def execute(self, context):
        # 护栏：execute 只应在"同名冲突对话框"OK 后由 Blender 调用（此时 conflict_count 已由 invoke 设置）。
        # 若被脚本/其他路径直接调用（conflict_count 为默认 0），回退到正常 invoke 流程，
        # 避免默认 RENAME 直接写盘。
        if self.conflict_count <= 0:
            log.warning("execute 被直接调用但无冲突对话框上下文，回退到 invoke")
            return self.invoke(context, None)
        # 对话框确认后：MERGE -> 直接官方；RENAME -> 先安全解包再官方
        return self._begin_modal(context)

    def draw(self, context):
        layout = self.layout
        layout.label(
            text=self._fmt("Detected {count} group(s) of same-named textures ({total} textures in total)",
                           count=self.conflict_count, total=self.conflict_images),
            icon="ERROR")
        layout.label(
            text=self._t("Directly unpacking overwrites each other and causes textures to mismatch. Please choose how to proceed:"))
        layout.separator()
        layout.label(
            text=self._fmt("Unpack Method: {m}", m=self._t(self._method_name(self.method))),
            icon="PREFERENCES")
        layout.separator()
        layout.prop(self, "action", expand=True)
        layout.separator()
        if self.action == "RENAME":
            layout.label(
                text=self._t("Auto-rename writes to disk and is irreversible; it is recommended to save the file first."),
                icon="INFO")
        else:
            layout.label(
                text=self._t("Merging same-named textures is the official default behavior; same-named textures may mismatch."),
                icon="QUESTION")

    # ---- Modal 进度条 ----
    def _begin_modal(self, context, conflicts=None):
        """准备任务队列并进入 Modal。

        conflicts 传 None 时重新检测（execute 确认期间场景可能变化）；
        传 {} 表示已确认无冲突/无需安全解包（MERGE 或 invoke 已检测）。
        """
        if conflicts is None:
            conflicts = detect_conflicts()
        tasks, plan_errors = [], {}
        if self.action == "RENAME" and conflicts:
            plan = core.plan_safe_unpack(conflicts)
            tasks = plan["tasks"]
            plan_errors = plan["errors"]
        self._tasks = tasks
        self._plan_errors = plan_errors
        self._failed = {}
        # 总步数 = 安全解包任务数 + 1（官方解包收尾）；防御 clamp 到 progress 上限
        self._total = max(1, min(len(tasks) + 1, 9998))
        self._done = 0
        self._state = "SAFE_UNPACK" if tasks else "OFFICIAL"
        self._official_ret = None
        self._official_err = None
        log.info("进入 Modal：安全解包 %d 张 + 官方解包收尾，总步数 %d", len(tasks), self._total)

        wm = context.window_manager
        wm.modal_handler_add(self)
        self._timer = wm.event_timer_add(0.05, window=context.window)
        wm.progress_begin(0, self._total)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        wm = context.window_manager
        if event.type == "ESC" and event.value == "PRESS":
            return self._finish_modal(context, cancelled=True)
        if event.type != "TIMER":
            return {"RUNNING_MODAL"}

        if self._state == "SAFE_UNPACK":
            if self._tasks:
                task = self._tasks.pop(0)
                r = core.run_safe_unpack_task(task)
                self._done += 1
                wm.progress_update(min(self._done, self._total))
                if not r["ok"]:
                    self._failed[r["image"]] = r["error"]
            else:
                self._state = "OFFICIAL"

        if self._state == "OFFICIAL":
            self._state = "DONE"
            # 最后一步：官方解包收尾（同步；官方内部无进度插桩，表现为光标等待后跳满）
            try:
                log.debug("调用官方 bpy.ops.file.unpack_all(method=%s)", self.method)
                ret = bpy.ops.file.unpack_all(method=self.method)
                log.debug("官方 unpack_all 返回 %s", ret)
                self._official_ret = str(ret)
            except Exception as e:
                import traceback
                log.error("官方 unpack_all 调用失败: %s\n%s", e, traceback.format_exc())
                self._official_err = str(e)
            return self._finish_modal(context, cancelled=False)

        return {"RUNNING_MODAL"}

    def _finish_modal(self, context, cancelled):
        wm = context.window_manager
        if self._timer is not None:
            try:
                wm.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        try:
            wm.progress_end()
        except Exception:
            pass

        if cancelled:
            self.report({"WARNING"},
                        self._fmt("Cancelled: {done}/{total} steps done, remaining tasks untouched; "
                                  "files already written are not rolled back",
                                  done=self._done, total=self._total))
            return {"CANCELLED"}

        safe_total = max(self._total - 1, 0)
        msg = self._fmt("Unpack finished: safely processed {done}/{total} textures",
                        done=self._done, total=safe_total)
        if self._plan_errors:
            msg += self._fmt(", planning failed {n}", n=len(self._plan_errors))
        if self._failed:
            msg += self._fmt(", execution failed {n} (see console log)", n=len(self._failed))
        if self._official_err:
            msg += self._fmt(", official unpack error: {err}", err=self._official_err)
        self.report({"INFO"}, msg)
        return {"FINISHED"}
