"""Unpack Guard - 安全解包核心。

把冲突处理拆成"先计划、后逐张执行"两个阶段，供 Modal 进度条逐张消费：

1. plan_safe_unpack(conflicts)：只读规划，对冲突组生成有序任务列表
   （每项 = 一张贴图的唯一目标名）。不改数据、不写盘。
2. run_safe_unpack_task(task)：执行单张——改 filepath(唯一) -> img.save() -> unpack(REMOVE)。
   save() 后若已自动解除打包则跳过 REMOVE；失败回滚 filepath。
3. safe_unpack(conflicts)：兼容接口 = plan + 全部执行（非 Modal/测试用）。

对传入的冲突组（{basename: [image_name,...]}）执行：
    1. 给每个冲突成员生成全局唯一 basename（组内首个优先保留原名，撞了递进 _1/_2）
    2. img.filepath = "//textures/<唯一名>"；img.save() 从内存导出到磁盘
    3. img.unpack(method='REMOVE') 清打包标记（不重置 filepath）

原理（Blender 5.2.1 实测 + review 加固，见知识库 [[unpack_all 解包机制]]）：
- 官方 unpack(USE_LOCAL) 用"打包快照的原始 basename"，改 filepath 无效；
- 但 img.save() 认当前 filepath 可导出任意路径（UDIM 会整套写 1001~1014，底层自动从 packed 加载像素）；
- img.packed_file 只读；img.unpack(REMOVE) 只清标记不碰 filepath。

唯一命名安全措施（review P0/P1）：
- 预填所有 image 的 basename + //textures/ 磁盘已有文件（大小写不敏感），生成时避让
- 混合组先 filter 打包成员，避免 save() 覆盖外部成员的正确文件
- 组内首个尝试保留原名，撞了递进
"""
import bpy
import os
import re
from collections import defaultdict

from .debug import get_logger

log = get_logger()


def split_base(base):
    """拆 basename 为 主干 + <UDIM>占位符 + 扩展名。兼容 a.<UDIM>.png 和 a_<UDIM>.png。

    udim 一律 .upper() 归一化：Blender 只认大写 <UDIM> 模板标记，小写 <udim> 会被当普通文件名，
    导致 save 失败/写错（防御性，真实源数据恒为大写）。
    """
    m = re.match(r"^(.*?)(\.?<UDIM>)?(\.[A-Za-z0-9]+)$", base, re.IGNORECASE)
    if m:
        stem, udim_raw, ext = m.group(1), m.group(2) or "", m.group(3)
        udim = udim_raw.upper()         # <.udim>/<udim> → <UDIM>，Blender 只认大写标记
        if udim and not udim.startswith("."):
            udim = "<UDIM>"
        return stem, udim, ext
    return base, "", ""


def _udim_tiles_on_disk(stem, k, ext, disk_basenames):
    """检查磁盘 textures 下是否已存在该 UDIM 模板展开的 tile 文件。

    兼容两种展开形态：
    - 点分隔："a.<UDIM>.png" → a_1.1001.png
    - 下划线："a_<UDIM>.png" → a_11001.png（无点）
    仅精确匹配 prefix(="<stem>_<k>") 开头 + 结尾为数字，避免把 stem_10.1001.png 误判为 stem_1 的 tile
    （其中间段 "0.1001" 不是纯数字，不命中）。
    """
    prefix = f"{stem}_{k}".lower()
    ext_low = ext.lower()
    for f in disk_basenames:
        if f.startswith(prefix) and f.endswith(ext_low):
            mid = f[len(prefix):-len(ext_low)] if ext_low else f[len(prefix):]
            # 点分隔 "." + 数字，或下划线展开的纯数字（不误判 stem_10.1001.png 的 "0.1001"）
            if (mid.startswith(".") and mid[1:].isdigit()) or mid.isdigit():
                return True
    return False


def _collect_disk_and_used(tex_abs):
    """收集命名避让依据：磁盘已有文件（大小写不敏感）+ 全部 image 的 basename 占用。

    注意：取 basename 必须用 bpy.path.basename（而非 os.path.basename）——Blender 的相对路径
    形如 "//textures\\foo.png"（混合分隔符、双斜杠前缀），os.path.basename 在 Windows 会把
    "//" 当 UNC 前缀而返回空串，导致相对路径贴图全被并进空 basename 组、plan 生成无扩展名名字。
    """
    disk_basenames = set()
    if os.path.isdir(tex_abs):
        for f in os.listdir(tex_abs):
            disk_basenames.add(f.lower())
    all_basenames = defaultdict(list)
    for img in bpy.data.images:
        b = bpy.path.basename(img.filepath) if img.filepath else img.name
        all_basenames[b.lower()].append(img.name)
    return disk_basenames, all_basenames


def _make_unique(stem, udim, ext, disk_basenames, used_basenames):
    """生成全局唯一 basename。

    **一律带 _N 后缀，保留原名机制已移除**：
    官方解包 WRITE_LOCAL/USE_LOCAL 系列认的是"打包快照 basename"（实测 = 当前 filepath basename），
    且 WRITE_LOCAL 会强制覆盖。若组内某个成员保留原名（如 xxx.png），官方随后解包一个同名打包图
    （可能来自未被检测的 leftover）就会覆盖 //textures/xxx.png，导致该成员读到被覆盖内容而**错位**。
    所以让 plan 产物绝不占用原 basename（全 _N），官方解包 leftover 写原 basename 时覆盖不到。

    UDIM 也一律 _N（模板名保留会干扰后续成员 save，实测）；
    stem 尾部下划线清理，避免生成 xxx__1 的双下划线；
    UDIM 候选额外检查磁盘 tile 文件（如 ID_1.1001.png）避让，防重复运行覆盖已有文件。

    disk_basenames：磁盘已有文件（小写）。used_basenames：本 run 已占用的名字（含预填的所有贴图原生名，小写）。
    """
    stem_clean = stem.rstrip("_")     # 避免 stem 尾下划线生成双下划线 (xxx__1)
    for k in range(1, 9999):
        cand = f"{stem_clean}_{k}{udim}{ext}"
        low = cand.lower()
        if low in used_basenames or low in disk_basenames:
            continue
        if udim and _udim_tiles_on_disk(stem_clean, k, ext, disk_basenames):
            continue
        used_basenames.add(low)
        return cand
    raise RuntimeError(f"无法为 {stem} 生成唯一名")


def plan_safe_unpack(conflicts):
    """规划阶段：对冲突组生成有序任务列表。只读，不改数据、不写盘。

    Returns:
        {"tasks": [{"image", "old_filepath", "new_filepath"}, ...],
         "errors": {image: msg}}
    """
    if not conflicts:
        log.info("plan_safe_unpack: 无可处理冲突组，跳过")
        return {"tasks": [], "errors": {}}

    tex_abs = bpy.path.abspath("//textures/")
    disk_basenames, all_basenames = _collect_disk_and_used(tex_abs)
    log.debug("//textures/ 磁盘已有文件 %d 个", len(disk_basenames))

    # 预填所有贴图的原生 basename（含 leftover/unused），避免生成的 _N 撞上它们。
    # 否则官方 WRITE_LOCAL 解包 leftover 时，会覆盖同名导出的文件 → 错位。
    # （all_basenames 的 key 已是小写）
    used_basenames = set(all_basenames.keys())
    log.debug("预填避让 basename %d 个（含所有贴图原生名）", len(used_basenames))
    tasks, errors = [], {}
    for base, names in conflicts.items():
        # 混合组安全：只处理打包成员
        packed_members = [n for n in names
                          if bpy.data.images.get(n) and bpy.data.images[n].packed_file is not None]
        if not packed_members:
            log.debug("组 [%s] 无打包成员，跳过", base)
            continue
        stem, udim, ext = split_base(base)
        for n in packed_members:
            img = bpy.data.images.get(n)
            if img is None:
                log.warning("[%s] 贴图已不存在，跳过（可能是规划后场景发生变化）", n)
                continue
            old_fp = img.filepath
            try:
                uniq = _make_unique(stem, udim, ext, disk_basenames, used_basenames)
            except Exception as e:
                errors[n] = f"命名失败: {e}"
                log.error("[%s] 命名失败: %s", n, e)
                continue
            new_fp = f"//textures/{uniq}"
            tasks.append({"image": n, "old_filepath": old_fp, "new_filepath": new_fp})
            log.debug("  [计划] %s: %s -> %s", n, old_fp, new_fp)

    log.info("plan_safe_unpack 完成: 计划 %d 张 / 命名失败 %d", len(tasks), len(errors))
    return {"tasks": tasks, "errors": errors}


def run_safe_unpack_task(task):
    """执行单张安全解包任务：改 filepath(唯一) -> img.save() -> unpack(REMOVE)。

    执行前确保 //textures/ 目录存在（img.save() 对打包图通常会自动建目录，这里显式创建更稳，
    避免极端情况下 save 失败）。失败时回滚 filepath（磁盘上已写的文件无法回滚，只回滚内存状态）。
    """
    n = task["image"]
    old_fp = task["old_filepath"]
    new_fp = task["new_filepath"]
    img = bpy.data.images.get(n)
    if img is None:
        msg = f"贴图 {n} 已不存在，跳过"
        log.warning(msg)
        return {"ok": False, "error": msg, "image": n}
    # S2：非 TILED 图若目标 filepath 带 <UDIM>，img.save() 会报 "must contain a valid UDIM marker"。
    # 提前拦截，避免 save 失败留下半成品。
    if "<UDIM>" in new_fp and getattr(img, "source", "") != "TILED":
        msg = f"[{n}] 目标 filepath 含 <UDIM> 但 source 非 TILED，跳过（避免 save 失败）"
        log.warning(msg)
        return {"ok": False, "error": msg, "image": n}
    try:
        os.makedirs(bpy.path.abspath("//textures/"), exist_ok=True)
    except Exception as e:
        log.error("创建目录 %s 失败: %s", bpy.path.abspath("//textures/"), e)
    try:
        img.filepath = new_fp
        img.save()
        # 部分 UDIM 贴图 save() 后 Blender 会自动解除打包标记（packed 变 None）；
        # 此时跳过 REMOVE 即可（save 已完成外部化），否则 REMOVE 会报"图像未打包"误判失败。
        if img.packed_file is not None:
            img.unpack(method="REMOVE")
        else:
            log.debug("   [%s] save 后已自动解除打包，跳过 REMOVE", n)
        log.debug("   完成 [%s] packed=%s", n, img.packed_file is not None)
        return {"ok": True, "image": n, "old_filepath": old_fp, "new_filepath": new_fp}
    except Exception as e:
        import traceback
        log.error("[%s] save/unpack 失败: %s\n%s", n, e, traceback.format_exc())
        try:
            img.filepath = old_fp
            log.debug("   已恢复 [%s] 原 filepath", n)
        except Exception:
            pass
        return {"ok": False, "image": n, "error": f"save/unpack 失败: {e}"}


def safe_unpack(conflicts, dry_run=False):
    """兼容接口：plan + 全部执行（非 Modal / 测试用）。

    Args:
        conflicts: detect_conflicts() 的返回值 {basename: [image_name,...]}
        dry_run: True 只统计计划不改动

    Returns:
        {"fixed": [entry...], "errors": {image: msg}, "planned": [entry...] (dry_run)}
    """
    plan = plan_safe_unpack(conflicts)
    if dry_run:
        log.info("safe_unpack(dry-run) 完成: 计划 %d 张", len(plan["tasks"]))
        return {
            "fixed": [],
            "errors": plan["errors"],
            "planned": [
                {"image": t["image"], "old_filepath": t["old_filepath"], "new_filepath": t["new_filepath"]}
                for t in plan["tasks"]
            ],
        }

    if plan["tasks"]:
        try:
            os.makedirs(bpy.path.abspath("//textures/"), exist_ok=True)
        except Exception as e:
            log.error("创建目录 %s 失败: %s", bpy.path.abspath("//textures/"), e)

    fixed, errors = [], dict(plan["errors"])
    for t in plan["tasks"]:
        r = run_safe_unpack_task(t)
        if r["ok"]:
            fixed.append(r)
        else:
            errors.setdefault(r["image"], r["error"])

    log.info("safe_unpack 完成: 成功 %d / 失败 %d", len(fixed), len(errors))
    return {"fixed": fixed, "errors": errors, "planned": []}
